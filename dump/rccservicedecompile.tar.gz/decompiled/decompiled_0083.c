/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 20750 ; VA 0x00a52410 ; FUN_00a52410 */

void FUN_00a52410(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a51170(uVar1,uVar2);
  return;
}



/* FUNCTION 20751 ; VA 0x00a52450 ; FUN_00a52450 */

void __thiscall FUN_00a52450(int param_1,undefined4 param_2)

{
  FUN_00a4e920(param_1 + 8,param_2);
  return;
}



/* FUNCTION 20752 ; VA 0x00a52470 ; FUN_00a52470 */

void FUN_00a52470(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a515d0(uVar1,uVar2);
  return;
}



/* FUNCTION 20753 ; VA 0x00a524b0 ; FUN_00a524b0 */

void FUN_00a524b0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a517b0(uVar1,uVar2);
  return;
}



/* FUNCTION 20754 ; VA 0x00a524f0 ; FUN_00a524f0 */

void __thiscall FUN_00a524f0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  param_2 = (undefined4 *)*param_2;
  if (*(int **)(param_1 + 0x2c) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x2c) + 8))(&param_2,param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 20755 ; VA 0x00a52520 ; FUN_00a52520 */

void FUN_00a52520(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  FUN_01674ea0(param_1,0x24);
  return;
}



/* FUNCTION 20756 ; VA 0x00a52580 ; FUN_00a52580 */

void __fastcall FUN_00a52580(int param_1)

{
  FUN_00a4e4d0(param_1 + 8);
  return;
}



/* FUNCTION 20757 ; VA 0x00a525a0 ; FUN_00a525a0 */

undefined4 * __thiscall FUN_00a525a0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_14a35e609901ef61391affbc55ca94e6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  return param_2;
}



/* FUNCTION 20758 ; VA 0x00a525f0 ; FUN_00a525f0 */

undefined4 * __thiscall FUN_00a525f0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_1a51b86597b025c2f4b998a4b1528dd7>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  return param_2;
}



/* FUNCTION 20759 ; VA 0x00a52660 ; FUN_00a52660 */

undefined4 * __thiscall FUN_00a52660(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8f1a69fff0aff060eff14970b7b6deca>,void,class_std::shared_ptr<class_std::exception_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  return param_2;
}



/* FUNCTION 20760 ; VA 0x00a526b0 ; FUN_00a526b0 */

undefined4 * __thiscall FUN_00a526b0(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0068;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_a28c0a00a43e99a7590723021c1391a6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0x18);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20761 ; VA 0x00a52740 ; FUN_00a52740 */

undefined4 * __thiscall FUN_00a52740(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0068;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_accba61a656593ab0e063b1837e5dced>,void,class_std::shared_ptr<class_std::exception_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0x18);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20762 ; VA 0x00a527d0 ; FUN_00a527d0 */

void __fastcall FUN_00a527d0(int param_1)

{
  FUN_00a4e690(param_1 + 8);
  return;
}



/* FUNCTION 20763 ; VA 0x00a527f0 ; FUN_00a527f0 */

TypeDescriptor * FUN_00a527f0(void)

{
  return &<lambda_011c894a80405c4d8a40da9c3ab4dad1>::RTTI_Type_Descriptor;
}



/* FUNCTION 20764 ; VA 0x00a52800 ; FUN_00a52800 */

TypeDescriptor * FUN_00a52800(void)

{
  return &<lambda_14a35e609901ef61391affbc55ca94e6>::RTTI_Type_Descriptor;
}



/* FUNCTION 20765 ; VA 0x00a52810 ; FUN_00a52810 */

TypeDescriptor * FUN_00a52810(void)

{
  return &<lambda_1a51b86597b025c2f4b998a4b1528dd7>::RTTI_Type_Descriptor;
}



/* FUNCTION 20766 ; VA 0x00a52820 ; FUN_00a52820 */

TypeDescriptor * FUN_00a52820(void)

{
  return &<lambda_8f1a69fff0aff060eff14970b7b6deca>::RTTI_Type_Descriptor;
}



/* FUNCTION 20767 ; VA 0x00a52830 ; FUN_00a52830 */

TypeDescriptor * FUN_00a52830(void)

{
  return &<lambda_a28c0a00a43e99a7590723021c1391a6>::RTTI_Type_Descriptor;
}



/* FUNCTION 20768 ; VA 0x00a52840 ; FUN_00a52840 */

TypeDescriptor * FUN_00a52840(void)

{
  return &<lambda_accba61a656593ab0e063b1837e5dced>::RTTI_Type_Descriptor;
}



/* FUNCTION 20769 ; VA 0x00a52850 ; FUN_00a52850 */

TypeDescriptor * FUN_00a52850(void)

{
  return &std::function<void___cdecl(enum_RBX::HttpErrorCode,class_RBX::HttpResponse_const&)>::
          RTTI_Type_Descriptor;
}



/* FUNCTION 20770 ; VA 0x00a52860 ; FUN_00a52860 */

void FUN_00a52860(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a3fce0();
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20771 ; VA 0x00a528a0 ; FUN_00a528a0 */

void __thiscall FUN_00a528a0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_3;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  piVar3 = (int *)param_3[5];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_01674ea0(param_3,0x18);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 20772 ; VA 0x00a52910 ; FUN_00a52910 */

undefined ** __thiscall FUN_00a52910(int param_1,int param_2,uint param_3)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined *in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  int *in_stack_00000050;
  int *in_stack_00000078;
  undefined4 in_stack_0000007c;
  undefined4 in_stack_00000080;
  undefined auStack_3a0 [144];
  undefined auStack_310 [144];
  undefined auStack_280 [144];
  undefined auStack_1f0 [144];
  undefined auStack_160 [144];
  undefined4 uStack_d0;
  int *piStack_cc;
  undefined4 uStack_c8;
  int *piStack_c4;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  int *piStack_a0;
  undefined auStack_98 [36];
  undefined4 uStack_74;
  undefined auStack_70 [36];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined **appuStack_40 [2];
  undefined4 auStack_38 [6];
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0150;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_005e5de0(&uStack_18,param_2);
  piVar9 = *(int **)(param_1 + 8);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[2] = piVar9[2] + 1;
    UNLOCK();
    piVar9 = *(int **)(param_1 + 8);
  }
  uStack_d0 = *(undefined4 *)(param_1 + 4);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[2] = piVar9[2] + 1;
    UNLOCK();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[2] = piStack_14[2] + 1;
    UNLOCK();
  }
  uStack_c8 = uStack_18;
  piStack_c4 = piStack_14;
  uStack_8._0_1_ = 7;
  piStack_cc = piVar9;
  uStack_20 = uStack_d0;
  piStack_1c = piVar9;
  FUN_0054ef60(&param_3);
  uStack_a8 = in_stack_00000020;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_a4 = in_stack_00000024;
  piStack_a0 = in_stack_00000028;
  in_stack_00000020 = auStack_98;
  uStack_74 = 0;
  uStack_8._0_1_ = 10;
  if (in_stack_00000050 != (int *)0x0) {
    uStack_74 = (**(code **)*in_stack_00000050)(auStack_98);
  }
  in_stack_00000020 = auStack_70;
  uStack_4c = 0;
  uStack_8._0_1_ = 0xc;
  if (in_stack_00000078 != (int *)0x0) {
    uStack_4c = (**(code **)*in_stack_00000078)(auStack_70);
  }
  uStack_48 = in_stack_0000007c;
  uStack_44 = in_stack_00000080;
  uStack_8._0_1_ = 0xd;
  FUN_00a4ff90(&uStack_d0);
  uStack_8._0_1_ = 0xe;
  appuStack_40[0] = (undefined **)0x0;
  FUN_00a4ff90(auStack_3a0);
  uStack_8._0_1_ = 0xf;
  FUN_00a4ff90(auStack_310);
  uStack_8._0_1_ = 0x10;
  FUN_00a4ff90(auStack_280);
  uStack_8._0_1_ = 0x11;
  cVar3 = FUN_00585a40(auStack_160);
  if (cVar3 == '\0') {
    FUN_00a4ff90(auStack_160);
    uStack_8._0_1_ = 0x12;
    iVar4 = FUN_01674e20(0x90);
    uStack_8._0_1_ = 0x13;
    if (iVar4 == 0) {
      auStack_38[0] = 0;
    }
    else {
      auStack_38[0] = FUN_00a4ff90(auStack_1f0);
    }
    FUN_00a50690();
    FUN_00a50690();
    bVar2 = true;
  }
  else {
    FUN_00a50690();
    bVar2 = false;
  }
  FUN_00a50690();
  appuStack_40[0] = &PTR_FUN_0194356c;
  if (!bVar2) {
    appuStack_40[0] = (undefined **)0x0;
  }
  FUN_00a50690();
  FUN_00a50690();
  FUN_00a50690();
  uStack_8._0_1_ = 0x14;
  if ((-(uint)(param_2 != 0) & param_2 + 0xcU) != 0) {
    FUN_005c2760();
  }
  uVar5 = FUN_008ccd70();
  FUN_008cd330(&param_3,0x428c0000,appuStack_40,uVar5,&DAT_01d62f20,0,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  ppuVar6 = appuStack_40[0];
  if (((appuStack_40[0] != (undefined **)0x0) && (((uint)appuStack_40[0] & 1) == 0)) &&
     (ppuVar6 = *(undefined ***)((uint)appuStack_40[0] & 0xfffffffe), ppuVar6 != (undefined **)0x0))
  {
    ppuVar6 = (undefined **)(*(code *)ppuVar6)(auStack_38,auStack_38,2);
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar1 = piVar9 + 2;
    iVar4 = *piVar1;
    ppuVar6 = (undefined **)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppuVar6 = (undefined **)(**(code **)(*piVar9 + 4))();
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_14 + 2;
    iVar4 = *piVar9;
    ppuVar6 = (undefined **)*piVar9;
    *piVar9 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppuVar6 = (undefined **)(**(code **)(*piStack_14 + 4))();
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    uVar7 = param_3;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_3 - 4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ppuVar6 = (undefined **)FUN_01674ea0(uVar7,uVar8);
  }
  piVar9 = in_stack_00000028;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar4 = *piVar1;
    ppuVar6 = (undefined **)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      ppuVar6 = (undefined **)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        ppuVar6 = (undefined **)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (in_stack_00000050 != (int *)0x0) {
    ppuVar6 = (undefined **)
              (**(code **)(*in_stack_00000050 + 0x10))(in_stack_00000050 != (int *)&stack0x0000002c)
    ;
    in_stack_00000050 = (int *)0x0;
  }
  if (in_stack_00000078 != (int *)0x0) {
    ppuVar6 = (undefined **)
              (**(code **)(*in_stack_00000078 + 0x10))(in_stack_00000078 != (int *)&stack0x00000054)
    ;
  }
  ExceptionList = pvStack_10;
  return ppuVar6;
}



/* FUNCTION 20773 ; VA 0x00a52ce0 ; FUN_00a52ce0 */

int __thiscall FUN_00a52ce0(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  undefined auStack_180 [24];
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 *puStack_160;
  undefined auStack_15c [32];
  undefined4 uStack_13c;
  undefined4 *puStack_138;
  undefined auStack_134 [24];
  undefined4 uStack_11c;
  int *piStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  uint *puStack_10c;
  int *piStack_108;
  int aiStack_f8 [5];
  uint uStack_e4;
  undefined4 uStack_e0;
  int *piStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_b8;
  int *piStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_90;
  int *piStack_8c;
  undefined4 uStack_88;
  int *piStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [24];
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e01f2;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    piStack_108 = (int *)param_4;
    uStack_114 = *(undefined4 *)(param_2 + 0x440);
    puStack_10c = (uint *)param_3;
    uStack_110 = *(undefined4 *)(param_2 + 0x444);
    piStack_118 = aiStack_f8;
    uStack_11c = 0xa52d36;
    ExceptionList = &pvStack_10;
    puStack_18 = (undefined *)uStack_114;
    pcStack_14 = (code *)uStack_110;
    FUN_00a53510();
    piStack_108 = aiStack_f8;
    uStack_8 = 0;
    puStack_10c = auStack_38;
    uStack_110 = 0xa52d4d;
    FUN_009cc590();
    piVar7 = (int *)param_1[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
      piVar7 = (int *)param_1[1];
    }
    uVar3 = *param_1;
    piVar1 = piVar7 + 2;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    piStack_108 = (int *)param_3;
    uStack_80 = puStack_18;
    uStack_8._0_1_ = 3;
    uStack_7c = pcStack_14;
    puStack_10c = (uint *)0xa52d9d;
    uStack_90 = uVar3;
    piStack_8c = piVar7;
    uStack_88 = uVar3;
    piStack_84 = piVar7;
    FUN_0054ef60();
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    piStack_108 = (int *)param_3;
    uStack_58 = puStack_18;
    uStack_8._0_1_ = 5;
    uStack_54 = pcStack_14;
    puStack_10c = (uint *)0xa52dc8;
    uStack_60 = uVar3;
    piStack_5c = piVar7;
    FUN_0054ef60();
    piStack_108 = (int *)DAT_01d660c4;
    puStack_10c = (uint *)0x0;
    puStack_18 = auStack_134;
    pcStack_14 = *(code **)(*(int *)param_1[6] + 4);
    puStack_20 = &uStack_b8;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      piStack_5c[2] = piStack_5c[2] + 1;
      UNLOCK();
    }
    uStack_b8 = uStack_60;
    piStack_b4 = piStack_5c;
    uStack_b0 = uStack_58;
    uStack_ac = uStack_54;
    puStack_138 = (undefined4 *)auStack_50;
    uStack_8._0_1_ = 7;
    uStack_13c = 0xa52e43;
    FUN_0054ef60();
    uStack_110 = 0;
    puStack_138 = &uStack_b8;
    uStack_8._0_1_ = 9;
    uStack_13c = 0xa52e5d;
    uStack_110 = FUN_00a4ed40();
    puStack_138 = (undefined4 *)0xa52e71;
    FUN_00a50620();
    puStack_1c = &uStack_e0;
    puStack_20 = (undefined4 *)auStack_15c;
    if (piStack_84 != (int *)0x0) {
      LOCK();
      piStack_84[2] = piStack_84[2] + 1;
      UNLOCK();
    }
    uStack_e0 = uStack_88;
    piStack_dc = piStack_84;
    uStack_d8 = uStack_80;
    uStack_d4 = uStack_7c;
    puStack_160 = (undefined4 *)auStack_78;
    uStack_8._0_1_ = 0xb;
    uStack_164 = 0xa52ed9;
    FUN_0054ef60();
    puStack_138 = (undefined4 *)0x0;
    puStack_160 = &uStack_e0;
    uStack_8._0_1_ = 0xd;
    uStack_164 = 0xa52ef3;
    puStack_138 = (undefined4 *)FUN_00a4ebe0();
    puStack_160 = (undefined4 *)0xa52f07;
    FUN_00a50620();
    if (param_1[9] != 0) {
      LOCK();
      piVar2 = (int *)(param_1[9] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    uStack_164 = param_1[8];
    puStack_160 = (undefined4 *)param_1[9];
    uStack_168 = 2;
    puStack_1c = (undefined4 *)auStack_180;
    uStack_8._0_1_ = 0xf;
    FUN_0054ef60(auStack_38);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    (*pcStack_14)(param_2);
    FUN_00a50620();
    param_2 = FUN_00a50620();
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar4 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        param_2 = (**(code **)(*piVar7 + 4))();
      }
    }
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      uVar6 = auStack_38[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_38[0] - 4);
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      param_2 = FUN_01674ea0(uVar6,uVar5);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    if (0xf < uStack_e4) {
      uVar6 = uStack_e4 + 1;
      iVar4 = aiStack_f8[0];
      if (0xfff < uVar6) {
        iVar4 = *(int *)(aiStack_f8[0] + -4);
        uVar6 = uStack_e4 + 0x24;
        if (0x1f < (aiStack_f8[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      param_2 = FUN_01674ea0(iVar4,uVar6);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20774 ; VA 0x00a53020 ; FUN_00a53020 */

void __thiscall FUN_00a53020(undefined4 *param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_ec [24];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined **ppuStack_c8;
  undefined4 uStack_c4;
  int *piStack_c0;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined *puStack_a4;
  undefined auStack_a0 [32];
  undefined4 uStack_80;
  undefined *puStack_7c;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined auStack_64 [24];
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0240;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
      puStack_74 = (undefined4 *)param_4;
      puStack_78 = (undefined4 *)param_3;
      puStack_7c = auStack_64;
      uStack_80 = 0xa5306e;
      ExceptionList = &pvStack_10;
      FUN_009cc3c0();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
        piVar4 = (int *)param_1[1];
      }
      uVar2 = *param_1;
      puStack_78 = &uStack_2c;
      uStack_8._0_1_ = 1;
      uStack_8._1_3_ = 0;
      puStack_74 = (undefined4 *)param_2;
      puStack_7c = (undefined *)0xa5309f;
      uStack_34 = uVar2;
      piStack_30 = piVar4;
      FUN_005e5de0();
      piStack_14 = (int *)param_1[6];
      puStack_74 = (undefined4 *)0x0;
      puStack_78 = (undefined4 *)0x0;
      puStack_1c = auStack_a0;
      pcStack_18 = *(code **)(*piStack_14 + 4);
      puStack_7c = (undefined *)0x0;
      puStack_20 = (undefined *)&ppuStack_c8;
      puStack_a4 = (undefined *)&ppuStack_c8;
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[2] = piStack_28[2] + 1;
        UNLOCK();
      }
      ppuStack_c8 = std::
                    _Func_impl_no_alloc<class_<lambda_1a51b86597b025c2f4b998a4b1528dd7>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
                    ::vftable;
      uStack_bc = uStack_2c;
      piStack_b8 = piStack_28;
      if (param_1[9] != 0) {
        LOCK();
        piVar1 = (int *)(param_1[9] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_d0 = param_1[8];
      uStack_cc = param_1[9];
      uStack_d4 = 0;
      puStack_24 = auStack_ec;
      uStack_8._0_1_ = 5;
      uStack_c4 = uVar2;
      piStack_c0 = piVar4;
      FUN_0054ef60(auStack_64);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      (*pcStack_18)(param_2);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[2] + -1;
        piStack_28[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    puStack_74 = param_1 + 0xe;
    puStack_78 = (undefined4 *)0xa53199;
    ExceptionList = &pvStack_10;
    puStack_74 = (undefined4 *)FUN_016dee6d();
    if (puStack_74 != (undefined4 *)0x0) {
      puStack_78 = (undefined4 *)0xa531a6;
      FUN_016df3c9();
    }
    puStack_74 = (undefined4 *)0x2;
    puStack_78 = (undefined4 *)&DAT_018bf820;
    uStack_8 = 6;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = 0;
    puStack_7c = (undefined *)0xa531d5;
    FUN_005542c0();
    puStack_74 = (undefined4 *)auStack_4c;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_78 = *(undefined4 **)(param_2 + 0x444);
    puStack_7c = *(undefined **)(param_2 + 0x440);
    uStack_80 = 0xa531f1;
    FUN_0091c070();
    puStack_74 = (undefined4 *)0xa531f9;
    FUN_005507b0();
    puStack_74 = param_1 + 0xe;
    uStack_8 = 8;
    puStack_78 = (undefined4 *)0xa53209;
    puStack_74 = (undefined4 *)FUN_016deec8();
    if (puStack_74 != (undefined4 *)0x0) {
      puStack_78 = (undefined4 *)0xa53216;
      FUN_016df3c9();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20775 ; VA 0x00a53230 ; FUN_00a53230 */

/* WARNING: Removing unreachable block (ram,0x00a533cb) */
/* WARNING: Removing unreachable block (ram,0x00a533d5) */
/* WARNING: Removing unreachable block (ram,0x00a5343c) */
/* WARNING: Removing unreachable block (ram,0x00a53445) */

void __thiscall FUN_00a53230(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int aiStack_128 [6];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 *puStack_108;
  undefined **appuStack_104 [8];
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined **appuStack_dc [9];
  undefined *puStack_b8;
  int **ppiStack_b4;
  code **ppcStack_b0;
  undefined auStack_a0 [24];
  undefined4 uStack_88;
  int *piStack_84;
  undefined *puStack_80;
  undefined *puStack_7c;
  undefined *puStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  code *pcStack_6c;
  int *piStack_68;
  undefined auStack_64 [8];
  undefined4 uStack_5c;
  int *piStack_58;
  code *pcStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  char cStack_28;
  code *pcStack_24;
  int *piStack_20;
  int *piStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0296;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    pcStack_24 = *(code **)(param_2 + 0x440);
    piStack_20 = *(int **)(param_2 + 0x444);
    ppcStack_b0 = (code **)(param_1 + 10);
    ppiStack_b4 = (int **)0xa53282;
    ExceptionList = &pvStack_10;
    piStack_1c = piStack_20;
    pcStack_18 = pcStack_24;
    FUN_006d05f0();
    ppcStack_b0 = &pcStack_24;
    uStack_8 = 0;
    ppiStack_b4 = &piStack_14;
    puStack_b8 = (undefined *)0xa5329c;
    FUN_0097bf20();
    piVar3 = piStack_14;
    if (piStack_14 != (int *)param_1[0x2b]) {
      ppcStack_b0 = (code **)0x6;
      ppiStack_b4 = (int **)0x1942150;
      pcStack_54 = (code *)0x0;
      piStack_50 = (int *)&DAT_0000000f;
      auStack_64[0] = 0;
      puStack_b8 = (undefined *)0xa532cc;
      FUN_005542c0();
      ppcStack_b0 = (code **)auStack_64;
      ppiStack_b4 = &piStack_14;
      puStack_b8 = (undefined *)0xa532dc;
      FUN_0097be30();
      ppcStack_b0 = (code **)0xa532e4;
      FUN_005507b0();
      if (piStack_14 != (int *)piVar3[5]) {
        ppcStack_b0 = (code **)0xa532f8;
        FUN_00a55c40();
        ppcStack_b0 = (code **)(piStack_14 + 8);
        ppiStack_b4 = (int **)auStack_a0;
        puStack_b8 = (undefined *)0xa53308;
        FUN_009cc590();
        piVar3 = (int *)param_1[1];
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[2] = piVar3[2] + 1;
          UNLOCK();
          piVar3 = (int *)param_1[1];
        }
        uStack_88 = *param_1;
        piStack_14 = piVar3 + 2;
        if (piVar3 != (int *)0x0) {
          LOCK();
          *piStack_14 = *piStack_14 + 1;
          UNLOCK();
        }
        pcStack_54 = pcStack_18;
        piStack_50 = piStack_1c;
        if (piVar3 != (int *)0x0) {
          LOCK();
          *piStack_14 = *piStack_14 + 1;
          UNLOCK();
        }
        pcStack_6c = pcStack_18;
        piStack_68 = piStack_1c;
        piStack_1c = (int *)param_1[6];
        ppcStack_b0 = (code **)DAT_01d660c4;
        ppiStack_b4 = (int **)0x0;
        puStack_78 = (undefined *)appuStack_dc;
        pcStack_18 = *(code **)(*piStack_1c + 4);
        puStack_e0 = &uStack_74;
        uStack_e4 = 0xa53380;
        piStack_84 = piVar3;
        uStack_74 = uStack_88;
        piStack_70 = piVar3;
        uStack_5c = uStack_88;
        piStack_58 = piVar3;
        FUN_00a4fb90();
        uStack_38 = 0;
        uStack_3c = 0;
        appuStack_dc[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_8f1a69fff0aff060eff14970b7b6deca>,void,class_std::shared_ptr<class_std::exception_const_>_>
             ::vftable;
        puStack_7c = (undefined *)appuStack_104;
        puStack_108 = &uStack_5c;
        uStack_10c = 0xa533ee;
        puStack_b8 = (undefined *)appuStack_dc;
        FUN_00a4fb90();
        uStack_48 = 0;
        uStack_4c = 0;
        appuStack_104[0] =
             std::
             _Func_impl_no_alloc<class_<lambda_14a35e609901ef61391affbc55ca94e6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
        puStack_80 = (undefined *)&uStack_10c;
        if (param_1[9] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[9] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uStack_10c = param_1[8];
        puStack_108 = (undefined4 *)param_1[9];
        uStack_110 = 1;
        piStack_20 = aiStack_128;
        uStack_8._0_1_ = 7;
        puStack_e0 = appuStack_104;
        FUN_0054ef60(auStack_a0);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        (*pcStack_18)(param_2);
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_70[2] + -1;
          piStack_70[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            ppcStack_b0 = (code **)0xa534b1;
            (**(code **)(*piStack_70 + 4))();
          }
        }
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_58[2] + -1;
          piStack_58[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            ppcStack_b0 = (code **)0xa534c6;
            (**(code **)(*piStack_58 + 4))();
          }
        }
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar2 = *piStack_14;
          *piStack_14 = *piStack_14 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            ppcStack_b0 = (code **)0xa534db;
            (**(code **)(*piVar3 + 4))();
          }
        }
        ppcStack_b0 = (code **)0xa534e6;
        FUN_005507b0();
      }
    }
    if (cStack_28 != '\0') {
      ppcStack_b0 = (code **)0xa534f4;
      FUN_006e0140();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20776 ; VA 0x00a53510 ; FUN_00a53510 */

undefined * __thiscall
FUN_00a53510(int param_1,undefined *param_2,undefined4 param_3,undefined4 param_4,int param_5,
            int param_6)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  undefined auStack_34 [28];
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e02d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006d05f0(param_1 + 0x28);
  uStack_8 = 0;
  FUN_0097bf20(&iStack_14,&param_3);
  iVar2 = param_5;
  if (iStack_14 == *(int *)(param_1 + 0xac)) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    if (cStack_18 == '\0') {
      ExceptionList = pvStack_10;
      return param_2;
    }
    FUN_006e0140();
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00fc6260(auStack_34,param_5);
  iVar1 = param_6;
  uStack_8._0_1_ = 1;
  if (*(int *)(param_6 + 0x10) != 0) {
    uVar3 = FUN_00a36cd0(auStack_4c,iVar2,0x2d);
    uStack_8._0_1_ = 2;
    FUN_00558c20(auStack_64,uVar3,iVar1);
    uStack_8._0_1_ = 4;
    FUN_005507b0();
    uVar3 = FUN_00a36cd0(auStack_7c,auStack_34,0x2d);
    uStack_8._0_1_ = 5;
    FUN_00558c20(auStack_4c,uVar3,iVar1);
    uStack_8._0_1_ = 7;
    FUN_005507b0();
    FUN_0097be30(&param_5,auStack_64);
    iVar1 = *(int *)(iStack_14 + 0x14);
    if ((param_5 != iVar1) || (FUN_0097be30(&param_5,auStack_4c), param_5 != iVar1)) {
      FUN_0054ef60(param_5 + 0x20);
      FUN_005507b0();
      FUN_005507b0();
      goto LAB_00a536f2;
    }
    FUN_005507b0();
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  FUN_0097be30(&param_5,iVar2);
  iVar2 = *(int *)(iStack_14 + 0x14);
  if (param_5 == iVar2) {
    FUN_0097be30(&param_5,auStack_34);
    if (param_5 == iVar2) {
      *(undefined4 *)(param_2 + 0x10) = 0;
      *(undefined4 *)(param_2 + 0x14) = 0xf;
      *param_2 = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
    }
    else {
      FUN_0054ef60(param_5 + 0x20);
    }
  }
  else {
    FUN_0054ef60(param_5 + 0x20);
  }
LAB_00a536f2:
  FUN_005507b0();
  if (cStack_18 != '\0') {
    FUN_006e0140();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20777 ; VA 0x00a53720 ; FUN_00a53720 */

void __thiscall FUN_00a53720(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e02fe;
  pvStack_10 = ExceptionList;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee78c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee78c0,param_1), DAT_01ee78c0 == -1)) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0xf4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[1] = 1;
      piVar3[2] = 1;
      *piVar3 = (int)std::_Ref_count_obj<class_RBX::CloudLocalizationManager>::vftable;
      FUN_00a500b0();
    }
    piVar1 = piVar3 + 3;
    DAT_01ee78b8 = piVar1;
    DAT_01ee78bc = piVar3;
    if ((piVar1 != (int *)0x0) && ((piVar3[4] == 0 || (*(int *)(piVar3[4] + 4) == 0)))) {
      piVar4 = piVar3;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar3[1] = piVar3[1] + 1;
        piVar4 = DAT_01ee78bc;
        UNLOCK();
        if (DAT_01ee78bc != (int *)0x0) {
          LOCK();
          DAT_01ee78bc[2] = DAT_01ee78bc[2] + 1;
          UNLOCK();
        }
      }
      *piVar1 = (int)piVar1;
      piVar1 = (int *)piVar3[4];
      piVar3[4] = (int)piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          piVar3 = piVar4 + 2;
          iVar2 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    FUN_016f3654(&LAB_01889e80);
    FUN_016f37bf(&DAT_01ee78c0);
  }
  piVar3 = DAT_01ee78bc;
  *param_2 = 0;
  param_2[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = DAT_01ee78bc;
  }
  *param_2 = (int)DAT_01ee78b8;
  param_2[1] = (int)piVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20778 ; VA 0x00a53890 ; FUN_00a53890 */

undefined4 FUN_00a53890(undefined4 param_1)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iStack_48;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0342;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a546b0(&iStack_18,&stack0x00000008);
  iVar2 = DAT_01ee7898;
  if (iStack_18 == DAT_01ee7898) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    puVar1 = auStack_30;
    uStack_8 = 0;
    uVar4 = 1;
  }
  else {
    FUN_00a546b0(&iStack_18,&stack0x00000008);
    if (iStack_18 == iVar2) {
      FUN_016ddcf9("invalid unordered_map<K, T> key");
      goto LAB_00a539e4;
    }
    puVar1 = (uint *)FUN_0054ef60(iStack_18 + 0xc);
    uStack_8 = 1;
    uVar4 = 2;
  }
  uStack_14 = uVar4;
  FUN_0054ef60(puVar1);
  if (((uVar4 & 2) != 0) && (uVar4 = uVar4 & 0xfffffffd, 0xf < uStack_34)) {
    uVar3 = uStack_34 + 1;
    iVar2 = iStack_48;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_48 + -4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (iStack_48 - iVar2) - 4U) {
LAB_00a539e4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (((uVar4 & 1) != 0) && (0xf < uStack_1c)) {
    uVar3 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20779 ; VA 0x00a539f0 ; FUN_00a539f0 */

undefined __thiscall
FUN_00a539f0(int param_1,int param_2,int param_3,undefined4 param_4,int param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined uVar10;
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  undefined auStack_34 [28];
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0378;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006d05f0(param_1 + 0x28);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  uVar5 = FUN_005e6570(&param_2);
  uVar4 = param_4;
  iStack_14 = (uVar5 & *(uint *)(param_1 + 0xc0)) * 8;
  puVar1 = *(undefined4 **)(param_1 + 0xac);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xb4) + iStack_14);
  iStack_14 = iStack_14 + 4;
  puVar6 = puVar2;
  while( true ) {
    puVar9 = puVar1;
    if (puVar2 != puVar1) {
      puVar9 = (undefined4 *)**(undefined4 **)(iStack_14 + *(int *)(param_1 + 0xb4));
    }
    if (puVar6 == puVar9) goto LAB_00a53ba9;
    if ((puVar6[2] == param_2) && (puVar6[3] == param_3)) break;
    puVar6 = (undefined4 *)*puVar6;
  }
  if (puVar6 == puVar1) {
LAB_00a53ba9:
    uVar10 = 0;
    goto LAB_00a53bab;
  }
  piVar7 = (int *)FUN_0097be30(&param_4,param_4);
  if (*piVar7 != puVar6[5]) {
    uVar10 = 1;
    goto LAB_00a53bab;
  }
  FUN_00fc6260(auStack_64,uVar4);
  iVar3 = param_5;
  uStack_8._0_1_ = 1;
  if (*(int *)(param_5 + 0x10) == 0) {
LAB_00a53b5b:
    piVar7 = (int *)FUN_0097be30(&param_4,uVar4);
    iVar3 = puVar6[5];
    if ((*piVar7 == iVar3) && (piVar7 = (int *)FUN_0097be30(&param_4,auStack_64), *piVar7 == iVar3))
    {
      uVar10 = 0;
      FUN_005507b0();
      goto LAB_00a53bab;
    }
  }
  else {
    uVar8 = FUN_00a36cd0(auStack_34,uVar4,0x2d);
    uStack_8._0_1_ = 2;
    FUN_00558c20(auStack_4c,uVar8,iVar3);
    uStack_8._0_1_ = 4;
    FUN_005507b0();
    uVar8 = FUN_00a36cd0(auStack_7c,auStack_64,0x2d);
    uStack_8._0_1_ = 5;
    FUN_00558c20(auStack_34,uVar8,iVar3);
    FUN_005507b0();
    piVar7 = (int *)FUN_0097be30(&param_4,auStack_4c);
    iVar3 = puVar6[5];
    if ((*piVar7 == iVar3) && (piVar7 = (int *)FUN_0097be30(&param_4,auStack_34), *piVar7 == iVar3))
    {
      FUN_005507b0();
      FUN_005507b0();
      goto LAB_00a53b5b;
    }
    FUN_005507b0();
    FUN_005507b0();
  }
  uVar10 = 1;
  FUN_005507b0();
LAB_00a53bab:
  if (cStack_18 != '\0') {
    FUN_006e0140();
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 20780 ; VA 0x00a53bd0 ; FUN_00a53bd0 */

int * __thiscall FUN_00a53bd0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  char cStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e03a0;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)ExceptionList;
  if ((-1 < param_3) && ((0 < param_3 || (param_2 != 0)))) {
    ExceptionList = &pvStack_10;
    FUN_006d0720(param_1 + 0x28);
    uStack_8 = 0;
    FUN_0097bf20(&piStack_18,&param_2);
    piVar5 = piStack_18;
    if (piStack_18 == *(int **)(param_1 + 0x8c)) {
      FUN_00a39da0(&iStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      *(undefined *)(iStack_28 + 0x129) = 1;
      FUN_0097bf20(&piStack_18,&param_2);
      piVar5 = piStack_18;
      if (piStack_18 == *(int **)(param_1 + 0x8c)) {
        iVar2 = **(int **)(param_1 + 0x8c);
        piStack_18 = &param_2;
        puStack_1c = *(undefined4 **)(iVar2 + 4);
        uVar4 = FUN_00a4e7a0(iVar2,puStack_1c,&DAT_018bdeda,&piStack_18,&uStack_11);
        if (*(int *)(param_1 + 0x90) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        *(int *)(param_1 + 0x90) = *(int *)(param_1 + 0x90) + 1;
        *(undefined4 *)(iVar2 + 4) = uVar4;
        *puStack_1c = uVar4;
        FUN_00a4f100(&piStack_20,**(int **)(param_1 + 0x8c) + 8,**(int **)(param_1 + 0x8c));
        piVar5 = piStack_20;
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      piVar5[4] = iStack_28;
      piVar3 = (int *)piVar5[5];
      piVar5[5] = (int)piStack_24;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar2 = *piVar1;
        piVar5 = (int *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          piVar5 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar5 = (int *)(**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piVar3 = piStack_24 + 1;
        iVar2 = *piVar3;
        piVar5 = (int *)*piVar3;
        *piVar3 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          piVar5 = (int *)(**(code **)*piStack_24)();
          LOCK();
          piVar3 = piStack_24 + 2;
          iVar2 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            piVar5 = (int *)(**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    if (cStack_2c != '\0') {
      piVar5 = (int *)FUN_006e00b0();
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 20781 ; VA 0x00a53d60 ; FUN_00a53d60 */

int FUN_00a53d60(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e03b8;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)0x0;
  param_1 = (int *)*param_1;
  iVar2 = 0;
  iVar3 = param_1[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    piVar4 = (int *)(iVar3 + 4);
    iVar2 = *(int *)(iVar3 + 4);
    ExceptionList = &pvStack_10;
    while (iVar2 != 0) {
      LOCK();
      iVar3 = *piVar4;
      if (iVar2 == iVar3) {
        *piVar4 = iVar2 + 1;
        iVar3 = iVar2;
      }
      UNLOCK();
      if (iVar3 == iVar2) {
        iVar2 = *param_1;
        piVar4 = (int *)param_1[1];
        goto LAB_00a53db9;
      }
      iVar2 = *piVar4;
    }
    iVar2 = 0;
    piVar4 = (int *)0x0;
  }
LAB_00a53db9:
  uStack_8 = 0;
  if (iVar2 != 0) {
    iVar2 = FUN_00a512a0(iVar2);
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20782 ; VA 0x00a53e10 ; FUN_00a53e10 */

int FUN_00a53e10(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e03d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a54230(*(undefined4 *)(param_1 + 8),*(int *)(param_1 + 0xc) + 1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20783 ; VA 0x00a53e90 ; FUN_00a53e90 */

void FUN_00a53e90(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  
  FUN_005cf2a0();
  uVar3 = param_1[2];
  piVar5 = (int *)param_1[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[2] = piVar5[2] + 1;
    UNLOCK();
    piVar5 = (int *)param_1[1];
  }
  uVar4 = *param_1;
  piVar1 = piVar5 + 2;
  if (piVar5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a4e550(uVar4,piVar5,param_2,uVar3,0);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  FUN_009eef30();
  return;
}



/* FUNCTION 20784 ; VA 0x00a53f40 ; FUN_00a53f40 */

void FUN_00a53f40(undefined4 param_1,undefined4 param_2)

{
  FUN_00a513a0(param_2);
  return;
}



/* FUNCTION 20785 ; VA 0x00a53f60 ; FUN_00a53f60 */

/* WARNING: Removing unreachable block (ram,0x00a54041) */
/* WARNING: Removing unreachable block (ram,0x00a5404a) */
/* WARNING: Removing unreachable block (ram,0x00a54059) */
/* WARNING: Removing unreachable block (ram,0x00a5401b) */
/* WARNING: Removing unreachable block (ram,0x00a54024) */
/* WARNING: Removing unreachable block (ram,0x00a54033) */
/* WARNING: Removing unreachable block (ram,0x00a54067) */
/* WARNING: Removing unreachable block (ram,0x00a54070) */
/* WARNING: Removing unreachable block (ram,0x00a5407e) */

undefined4
FUN_00a53f60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a518c0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20786 ; VA 0x00a540a0 ; FUN_00a540a0 */

bool __thiscall FUN_00a540a0(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  byte *pbVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  uint uVar14;
  bool bVar15;
  char cStack_18;
  
  FUN_006d05f0(param_1 + 0x28);
  uVar7 = FUN_005e6570(&param_2);
  iVar2 = (uVar7 & *(uint *)(param_1 + 0xe0)) * 8;
  puVar13 = *(undefined4 **)(param_1 + 0xcc);
  puVar3 = *(undefined4 **)(*(int *)(param_1 + 0xd4) + iVar2);
  puVar8 = puVar3;
  while( true ) {
    puVar12 = puVar13;
    if (puVar3 != puVar13) {
      puVar12 = (undefined4 *)**(undefined4 **)(iVar2 + *(int *)(param_1 + 0xd4) + 4);
    }
    puVar9 = puVar13;
    if ((puVar8 == puVar12) || ((puVar8[2] == param_2 && (puVar9 = puVar8, puVar8[3] == param_3))))
    break;
    puVar8 = (undefined4 *)*puVar8;
  }
  if (puVar9 == *(undefined4 **)(param_1 + 0xcc)) {
    bVar15 = false;
  }
  else {
    param_3 = param_4[4];
    puVar13 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar13 = (undefined4 *)*param_4;
    }
    uVar7 = 0;
    uVar14 = 0x811c9dc5;
    if (param_3 != 0) {
      do {
        pbVar1 = (byte *)(uVar7 + (int)puVar13);
        uVar7 = uVar7 + 1;
        uVar14 = (*pbVar1 ^ uVar14) * 0x1000193;
      } while (uVar7 < param_3);
    }
    uVar7 = puVar9[10];
    iVar2 = puVar9[7];
    puVar13 = *(undefined4 **)(iVar2 + (uVar7 & uVar14) * 8);
    puVar3 = (undefined4 *)puVar9[5];
    puVar12 = puVar13;
    puVar8 = param_4;
    while( true ) {
      puVar9 = param_4;
      puVar10 = puVar3;
      if (puVar13 != puVar3) {
        puVar10 = (undefined4 *)**(undefined4 **)((uVar7 & uVar14) * 8 + 4 + iVar2);
      }
      if (puVar12 == puVar10) {
        bVar15 = false;
        goto LAB_00a54209;
      }
      piVar11 = puVar12 + 2;
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      uVar4 = puVar12[7];
      uVar5 = puVar12[6];
      if (0xf < uVar4) {
        piVar11 = (int *)*piVar11;
      }
      cVar6 = FUN_0055c360(piVar11,uVar5,puVar8,param_3);
      if (cVar6 != '\0') break;
      puVar12 = (undefined4 *)*puVar12;
      puVar8 = puVar9;
    }
    piVar11 = puVar12 + 2;
    if (0xf < uVar4) {
      piVar11 = (int *)*piVar11;
    }
    if (0xf < (uint)puVar9[5]) {
      puVar9 = (undefined4 *)*puVar9;
    }
    cVar6 = FUN_0055c360(puVar9,param_3,piVar11,uVar5);
    puVar13 = puVar3;
    if (cVar6 != '\0') {
      puVar13 = puVar12;
    }
    bVar15 = puVar13 != puVar3;
  }
LAB_00a54209:
  if (cStack_18 != '\0') {
    FUN_006e0140();
  }
  return bVar15;
}



/* FUNCTION 20787 ; VA 0x00a54230 ; FUN_00a54230 */

undefined4 * __thiscall FUN_00a54230(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 *puStack_4c;
  int *piStack_48;
  undefined4 *puStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_34;
  int *piStack_30;
  char cStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0420;
  pvStack_10 = ExceptionList;
  puVar5 = *(undefined4 **)(param_2 + 0x440);
  piStack_30 = *(int **)(param_2 + 0x444);
  if ((-1 < (int)piStack_30) && ((0 < (int)piStack_30 || (puVar5 != (undefined4 *)0x0)))) {
    ExceptionList = &pvStack_10;
    puStack_34 = puVar5;
    puStack_24 = param_1;
    puStack_18 = puVar5;
    piStack_14 = piStack_30;
    FUN_006d05f0();
    uStack_8 = 0;
    FUN_0097bf20();
    if (piStack_1c == (int *)param_1[0x1b]) {
      piVar6 = (int *)param_1[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
        piVar6 = (int *)param_1[1];
      }
      uVar3 = *param_1;
      uStack_8._0_1_ = 3;
      uStack_20 = uVar3;
      piStack_1c = piVar6;
      FUN_005e5de0();
      piVar2 = piStack_30;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
      }
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[2] = piStack_30[2] + 1;
        UNLOCK();
      }
      puStack_4c = puStack_34;
      puStack_44 = puStack_18;
      piStack_40 = piStack_14;
      piStack_48 = piStack_30;
      uStack_3c = param_3;
      uStack_8._0_1_ = 6;
      uStack_54 = uVar3;
      piStack_50 = piVar6;
      FUN_00a4eb10(&uStack_54);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_48[2] + -1;
        piStack_48[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_50[2] + -1;
        piStack_50[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_50 + 4))();
        }
      }
      puVar5 = (undefined4 *)FUN_00a54420(puStack_18,piStack_14);
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        puVar5 = (undefined4 *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar5 = (undefined4 *)(**(code **)(*piVar2 + 4))();
        }
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar2 = piVar6 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puVar5 = (undefined4 *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
    else {
      FUN_00a55c40();
      puStack_34 = param_1 + 0xe;
      iVar4 = FUN_016dee6d();
      if (iVar4 != 0) {
        FUN_016df3c9();
      }
      piStack_30 = (int *)CONCAT31(piStack_30._1_3_,1);
      uStack_8._0_1_ = 1;
      FUN_00a51dd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puVar5 = (undefined4 *)FUN_016deec8();
      if (puVar5 != (undefined4 *)0x0) {
        puVar5 = (undefined4 *)FUN_016df3c9();
      }
    }
    if (cStack_28 != '\0') {
      puVar5 = (undefined4 *)FUN_006e0140();
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 20788 ; VA 0x00a54420 ; FUN_00a54420 */

int FUN_00a54420(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  int *in_stack_00000030;
  int aiStack_80 [9];
  int *piStack_5c;
  int aiStack_58 [9];
  int *piStack_34;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0488;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d5a4c0 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00f57020(apppuStack_30,param_1,param_2);
    piStack_34 = (int *)0x0;
    uStack_8._0_1_ = 7;
    if (in_stack_00000030 != (int *)0x0) {
      piStack_34 = (int *)(**(code **)*in_stack_00000030)(aiStack_58);
    }
    piStack_5c = (int *)0x0;
    uStack_8._0_1_ = 9;
    if ((piStack_34 != (int *)0x0) &&
       (piStack_5c = (int *)FUN_00a4ee80(aiStack_58), piStack_34 != (int *)0x0)) {
      (**(code **)(*piStack_34 + 0x10))
                (CONCAT31((int3)((uint)aiStack_58 >> 8),piStack_34 != aiStack_58));
      piStack_34 = (int *)0x0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    ppppuVar4 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    }
    iVar3 = FUN_014ca550(auStack_18,ppppuVar4,uStack_20,aiStack_80,0);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piStack_5c != (int *)0x0) {
      iVar3 = (**(code **)(*piStack_5c + 0x10))(piStack_5c != aiStack_80);
    }
    if (uStack_1c < 0x10) goto LAB_00a5467a;
    uVar5 = uStack_1c + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_00f56da0();
    piStack_34 = (int *)0x0;
    uStack_8._0_1_ = 2;
    if (in_stack_00000030 != (int *)0x0) {
      piStack_34 = (int *)(**(code **)*in_stack_00000030)(aiStack_58);
    }
    piStack_5c = (int *)0x0;
    uStack_8._0_1_ = 4;
    if ((piStack_34 != (int *)0x0) &&
       (piStack_5c = (int *)FUN_00a4ee80(aiStack_58), piStack_34 != (int *)0x0)) {
      (**(code **)(*piStack_34 + 0x10))
                (CONCAT31((int3)((uint)aiStack_58 >> 8),piStack_34 != aiStack_58));
      piStack_34 = (int *)0x0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    ppppuVar4 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    }
    iVar3 = FUN_014ca630(auStack_18,ppppuVar4,uStack_20,&DAT_018bc9b8,0,aiStack_80,0);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piStack_5c != (int *)0x0) {
      iVar3 = (**(code **)(*piStack_5c + 0x10))(piStack_5c != aiStack_80);
    }
    if (uStack_1c < 0x10) goto LAB_00a5467a;
    uVar5 = uStack_1c + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  iVar3 = FUN_01674ea0(ppppuVar4,uVar5);
LAB_00a5467a:
  if (in_stack_00000030 != (int *)0x0) {
    iVar3 = (**(code **)(*in_stack_00000030 + 0x10))(in_stack_00000030 != (int *)&stack0x0000000c);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20789 ; VA 0x00a546b0 ; FUN_00a546b0 */

int * __thiscall FUN_00a546b0(int param_1,int *param_2,byte *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  uVar4 = *(uint *)(param_1 + 0x18) &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + uVar4 * 8);
  puVar3 = puVar2;
  while( true ) {
    puVar5 = puVar1;
    if (puVar2 != puVar1) {
      puVar5 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0xc) + uVar4 * 8 + 4);
    }
    if (puVar3 == puVar5) break;
    if (puVar3[2] == *(int *)param_3) {
      *param_2 = (int)puVar3;
      return param_2;
    }
    puVar3 = (undefined4 *)*puVar3;
  }
  *param_2 = (int)puVar1;
  return param_2;
}



/* FUNCTION 20790 ; VA 0x00a54740 ; FUN_00a54740 */

int * FUN_00a54740(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a547f1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a5477e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dcb7ec);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_4b370a875c0a16b9340970875f9ec23b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20791 ; VA 0x00a54810 ; FUN_00a54810 */

void FUN_00a54810(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0442;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x90);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00a4fbd0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a50480();
        piVar1 = *(int **)(iVar3 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x90);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcb8cc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_533150ab11ad35d49033aa488c2c0ffb>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20792 ; VA 0x00a54970 ; FUN_00a54970 */

int * FUN_00a54970(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a54a27. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a549ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dcb824);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_7d6a24da593de4e8693b60f24f08af9e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20793 ; VA 0x00a54a40 ; FUN_00a54a40 */

void FUN_00a54a40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0462;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x88);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a4fe90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a50550();
        FUN_01674ea0(iVar2,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dcb894);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_9fb8a0c5a538ea8dd99b911375aa70f7>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20794 ; VA 0x00a54b90 ; FUN_00a54b90 */

void FUN_00a54b90(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0442;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x90);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a4ff90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a50690();
        FUN_01674ea0(iVar2,0x90);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dcb85c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_dcc38375129161dee32f2f86a02310b2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20795 ; VA 0x00a54ce0 ; FUN_00a54ce0 */

void __thiscall FUN_00a54ce0(int param_1,int param_2,int param_3,int *param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  char cVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  int **ppiVar11;
  undefined auStack_118 [8];
  undefined auStack_110 [8];
  uint auStack_108 [4];
  undefined4 uStack_f8;
  uint uStack_f4;
  uint auStack_f0 [4];
  int iStack_e0;
  uint uStack_dc;
  undefined auStack_d8 [16];
  int iStack_c8;
  undefined auStack_c0 [16];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined auStack_a8 [16];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined auStack_90 [8];
  undefined auStack_88 [16];
  char cStack_78;
  int *piStack_74;
  undefined auStack_70 [4];
  char cStack_6c;
  int *piStack_68;
  undefined uStack_64;
  undefined *puStack_60;
  int iStack_5c;
  undefined auStack_58 [4];
  int iStack_54;
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  undefined auStack_2c [4];
  undefined auStack_28 [16];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0538;
  pvStack_10 = ExceptionList;
  if ((-1 < param_3) && ((0 < param_3 || (param_2 != 0)))) {
    puStack_34 = (undefined4 *)(param_1 + 0x28);
    ExceptionList = &pvStack_10;
    FUN_006d05f0(puStack_34);
    uStack_8._0_1_ = 0;
    uStack_8._1_3_ = 0;
    iStack_5c = param_1 + 0xa8;
    FUN_0097bf20(&iStack_30,&param_2);
    if (iStack_30 == *(int *)(param_1 + 0xac)) {
      FUN_00a55c40();
      if (param_4[4] == 0) {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        pcVar1 = *(code **)(**(int **)(param_1 + 0x20) + 4);
        FUN_005542c0("ParseLocaleManifestStringFailure_EmptyManifest",0x2e);
        uStack_8._0_1_ = 1;
        (*pcVar1)(auStack_28);
        FUN_005507b0();
      }
      else {
        FUN_016819e0(auStack_88,param_4);
        uStack_8._0_1_ = 2;
        cVar6 = FUN_016816d0();
        if (cVar6 == '\0') {
          cVar6 = FUN_01681870();
          if (cVar6 == '\0') {
            iStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            pcVar1 = *(code **)(**(int **)(param_1 + 0x20) + 4);
            FUN_005542c0("ParseLocaleManifestStringFailure_NotJsonObject",0x2e);
            uStack_8._0_1_ = 7;
            (*pcVar1)(auStack_28);
            FUN_005507b0();
          }
          else {
            FUN_00a3aff0();
            uStack_8._0_1_ = 8;
            FUN_0167eea0(auStack_90,"translations");
            cVar6 = FUN_01681830();
            if (cVar6 == '\0') {
              iStack_18 = 0;
              uStack_14 = 0xf;
              auStack_28[0] = 0;
              pcVar1 = *(code **)(**(int **)(param_1 + 0x20) + 4);
              FUN_005542c0("ParseLocaleManifestStringFailure_TranslationsNotArray",0x35);
              uStack_8._0_1_ = 0x14;
              (*pcVar1)(auStack_28);
LAB_00a55381:
              FUN_005507b0();
            }
            else {
              FUN_016810c0(auStack_58);
              FUN_01680ea0(auStack_2c);
              FUN_01681140(&iStack_30);
              cVar6 = FUN_005e0cd0(&iStack_30);
              iVar2 = param_1 + 0xa8;
              while (cVar6 != '\0') {
                FUN_0167efb0(auStack_70);
                FUN_0167eea0(auStack_110,"assetUrl");
                uStack_98 = 0;
                uStack_94 = 0xf;
                auStack_a8[0] = 0;
                uStack_8._0_1_ = 9;
                FUN_01681580(auStack_d8,auStack_a8);
                uStack_8._0_1_ = 0xb;
                FUN_005507b0();
                FUN_0167eea0(auStack_118,"locale");
                uStack_b0 = 0;
                uStack_ac = 0xf;
                auStack_c0[0] = 0;
                uStack_8._0_1_ = 0xc;
                FUN_01681580(auStack_28,auStack_c0);
                uStack_8._0_1_ = 0xe;
                FUN_005507b0();
                if ((iStack_c8 == 0) || (iStack_18 == 0)) {
                  FUN_005507b0();
                  goto LAB_00a55381;
                }
                uVar7 = FUN_00f854f0(auStack_a8,auStack_28);
                FUN_005511f0(uVar7);
                FUN_005507b0();
                FUN_0054ef60(auStack_28);
                FUN_00f85650(auStack_108);
                uStack_8._0_1_ = 0xf;
                if (iStack_e0 != 0) {
                  uVar7 = FUN_00a36cd0(auStack_a8,auStack_108,0x2d);
                  uStack_8._0_1_ = 0x10;
                  uVar7 = FUN_00558c20(auStack_c0,uVar7,auStack_f0);
                  FUN_005511f0(uVar7);
                  FUN_005507b0();
                  uStack_8._0_1_ = 0xf;
                  FUN_005507b0();
                }
                FUN_0097be30(&piStack_74,auStack_28);
                if (piStack_74 == piStack_50) {
                  iVar2 = *piStack_50;
                  puStack_60 = auStack_28;
                  puVar3 = *(undefined4 **)(iVar2 + 4);
                  uVar7 = FUN_00a370a0(iVar2,puVar3,&DAT_018bdeda,&puStack_60,(int)&param_4 + 3);
                  if (iStack_4c == 0x4924923) goto LAB_00a553ba;
                  iStack_4c = iStack_4c + 1;
                  *(undefined4 *)(iVar2 + 4) = uVar7;
                  *puVar3 = uVar7;
                  FUN_00a377b0(&piStack_68,*piStack_50 + 8,*piStack_50);
                }
                else {
                  piStack_68 = piStack_74;
                  uStack_64 = 0;
                }
                FUN_005511f0(auStack_d8);
                uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
                if (0xf < uStack_dc) {
                  uVar10 = uStack_dc + 1;
                  uVar9 = auStack_f0[0];
                  if (0xfff < uVar10) {
                    uVar9 = *(uint *)(auStack_f0[0] - 4);
                    uVar10 = uStack_dc + 0x24;
                    if (0x1f < (auStack_f0[0] - uVar9) - 4) goto LAB_00a553c4;
                  }
                  FUN_01674ea0(uVar9,uVar10);
                }
                iStack_e0 = 0;
                uStack_dc = 0xf;
                auStack_f0[0] = auStack_f0[0] & 0xffffff00;
                if (0xf < uStack_f4) {
                  uVar10 = uStack_f4 + 1;
                  uVar9 = auStack_108[0];
                  if (0xfff < uVar10) {
                    uVar9 = *(uint *)(auStack_108[0] - 4);
                    uVar10 = uStack_f4 + 0x24;
                    if (0x1f < (auStack_108[0] - uVar9) - 4) {
LAB_00a553c4:
                    /* WARNING: Subroutine does not return */
                      FUN_017167a3();
                    }
                  }
                  FUN_01674ea0(uVar9,uVar10);
                }
                uStack_f8 = 0;
                uStack_f4 = 0xf;
                auStack_108[0] = auStack_108[0] & 0xffffff00;
                FUN_005507b0();
                uStack_8._0_1_ = 8;
                FUN_005507b0();
                FUN_0167f070();
                cVar6 = FUN_005e0cd0(&iStack_30);
                iVar2 = iStack_5c;
              }
              FUN_006d0720(puStack_34);
              uStack_8._0_1_ = 0x11;
              FUN_0097bf20(&param_4,&param_2);
              piVar8 = param_4;
              if (param_4 == *(int **)(iVar2 + 4)) {
                iVar4 = **(int **)(iVar2 + 4);
                puStack_34 = &param_2;
                puVar3 = *(undefined4 **)(iVar4 + 4);
                uVar7 = FUN_00a4e7d0(iVar4,puVar3,&DAT_018bdeda,&puStack_34,(int)&param_4 + 3);
                if (*(int *)(iVar2 + 8) == 0x5555554) {
LAB_00a553ba:
                    /* WARNING: Subroutine does not return */
                  FUN_016ddcd9("list<T> too long");
                }
                *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
                *(undefined4 *)(iVar4 + 4) = uVar7;
                *puVar3 = uVar7;
                FUN_00a4f2d0(&piStack_68,**(int **)(iVar2 + 4) + 8,**(int **)(iVar2 + 4));
                piVar8 = piStack_68;
              }
              if (piVar8 + 4 != &iStack_54) {
                piVar8[4] = iStack_54;
                if (piVar8 + 7 != &iStack_48) {
                  FUN_0056d320();
                  piVar8[7] = iStack_48;
                  piVar8[8] = iStack_44;
                  piVar8[9] = iStack_40;
                  iStack_48 = 0;
                  iStack_44 = 0;
                  iStack_40 = 0;
                }
                piVar8[10] = iStack_3c;
                piVar8[0xb] = iStack_38;
                ppiVar11 = (int **)(piVar8 + 5);
                if (ppiVar11 != &piStack_50) {
                  FUN_00a3fce0();
                  piVar5 = *ppiVar11;
                  *ppiVar11 = piStack_50;
                  iVar2 = piVar8[6];
                  piVar8[6] = iStack_4c;
                  piStack_50 = piVar5;
                  iStack_4c = iVar2;
                }
                uStack_8._0_1_ = 0x13;
                FUN_00a3fce0();
                FUN_005cb500(8);
              }
              if (cStack_6c != '\0') {
                FUN_006e00b0();
              }
            }
            FUN_00a3bd10();
          }
        }
        else {
          iStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          pcVar1 = *(code **)(**(int **)(param_1 + 0x20) + 4);
          FUN_005542c0("ParseLocaleManifestStringFailure_ParseError",0x2b);
          uStack_8._0_1_ = 3;
          (*pcVar1)(auStack_28);
          uStack_8._0_1_ = 2;
          FUN_005507b0();
          uVar7 = FUN_016814a0();
          uVar7 = FUN_0054eff0(uVar7);
          uStack_8._0_1_ = 4;
          FUN_00558d90(auStack_d8,"parsesManifestResponse parse error: ",uVar7);
          uStack_8._0_1_ = 6;
          FUN_005507b0();
          (**(code **)(**(int **)(param_1 + 0x20) + 8))(auStack_d8);
          FUN_005507b0();
        }
        FUN_0167ec40();
      }
    }
    if (cStack_78 != '\0') {
      FUN_006e0140();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20796 ; VA 0x00a553d0 ; FUN_00a553d0 */

int * __thiscall
FUN_00a553d0(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  code *pcVar1;
  char cVar2;
  undefined uVar3;
  char *pcVar4;
  uint *puVar5;
  undefined4 *puVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined8 uStack_4c;
  uint auStack_44 [2];
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined auStack_2c [12];
  undefined8 uStack_20;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0578;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_016819e0(auStack_2c,param_5);
  uStack_4c = 0xf00000000;
  uStack_5c = uStack_5c & 0xffffff00;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  cVar2 = FUN_016816d0();
  if (cVar2 == '\0') {
    cVar2 = FUN_01681870();
    if (cVar2 != '\0') {
      FUN_0167eda0(&uStack_20,&DAT_01d660d8);
      uVar3 = FUN_01681470();
      FUN_0167eda0(&uStack_20,&DAT_01d660f0);
      uStack_11 = FUN_01681470();
      FUN_0167eda0(&uStack_20,&DAT_01d66108);
      uVar10 = FUN_0167e380(0,0);
      puStack_18 = (undefined4 *)FUN_01674e20(0x20);
      if (puStack_18 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puStack_18[1] = 1;
        puStack_18[2] = 1;
        *puStack_18 = std::_Ref_count_obj<struct_RBX::CloudLocalization::Settings>::vftable;
        *(undefined *)(puStack_18 + 4) = uVar3;
        *(undefined *)((int)puStack_18 + 0x11) = uStack_11;
        *(undefined8 *)(puStack_18 + 6) = uVar10;
        puVar6 = puStack_18;
      }
      *param_2 = (int)(puVar6 + 4);
      param_2[1] = (int)puVar6;
      FUN_005507b0();
      goto LAB_00a556d6;
    }
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    pcVar1 = *(code **)(*(int *)param_1[8] + 4);
    FUN_005542c0("ParseCloudLocalizationSettingsHttpResponseFailure_NotJsonObject",0x3f);
    uStack_8._0_1_ = 4;
    (*pcVar1)(auStack_74);
    uStack_8._0_1_ = 1;
    FUN_005507b0();
    FUN_005542c0("parseCloudLocalizationSettingsHttpResponse parse error: Not a JSON object",0x49);
  }
  else {
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar1 = *(code **)(*(int *)param_1[8] + 4);
    FUN_005542c0("ParseCloudLocalizationSettingsHttpResponseFailure_ParseError",0x3c);
    uStack_8._0_1_ = 2;
    (*pcVar1)(auStack_44);
    uStack_8._0_1_ = 1;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    pcVar4 = (char *)FUN_016814a0();
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    pcVar7 = pcVar4;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar4,(int)pcVar7 - (int)(pcVar4 + 1));
    uStack_8._0_1_ = 3;
    puVar5 = (uint *)FUN_00585d40(0,"parseCloudLocalizationSettingsHttpResponse parse error: ",0x38)
    ;
    uStack_3c = *puVar5;
    uStack_38 = puVar5[1];
    uStack_34 = puVar5[2];
    uStack_30 = puVar5[3];
    uStack_20 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
    FUN_005507b0();
    uStack_8._0_1_ = 1;
    uStack_5c = uStack_3c;
    uStack_58 = uStack_38;
    uStack_54 = uStack_34;
    uStack_50 = uStack_30;
    uStack_4c = uStack_20;
    if (0xf < uStack_60) {
      uVar9 = uStack_60 + 1;
      uVar8 = auStack_74[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_74[0] - 4);
        uVar9 = uStack_60 + 0x24;
        if (0x1f < (auStack_74[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
  }
  if ((int)uStack_4c != 0) {
    (**(code **)(*(int *)puStack_18[8] + 8))(&uStack_5c);
  }
  *param_2 = 0;
  param_2[1] = 0;
  if (0xf < uStack_4c._4_4_) {
    uVar9 = uStack_4c._4_4_ + 1;
    uVar8 = uStack_5c;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(uStack_5c - 4);
      uVar9 = uStack_4c._4_4_ + 0x24;
      if (0x1f < (uStack_5c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_4c = 0xf00000000;
  uStack_5c = uStack_5c & 0xffffff00;
LAB_00a556d6:
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20797 ; VA 0x00a55710 ; FUN_00a55710 */

void FUN_00a55710(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799c39;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_1[4] + 0x19);
  FUN_00554150("CloudLocalizationManager_",0x19);
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_00554150(param_1,*puVar1);
  FUN_008783f0(auStack_2c,1,0);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20798 ; VA 0x00a557e0 ; FUN_00a557e0 */

void FUN_00a557e0(undefined4 param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151f950("Error",param_1);
  uVar1 = DAT_01d660bc;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("CloudLocalizationManagerFailure",0x1f);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20799 ; VA 0x00a558b0 ; FUN_00a558b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_00a558b0(undefined4 param_1,undefined4 param_2,uint *param_3)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  int **ppiVar6;
  char *pcVar7;
  char *pcVar8;
  undefined4 *puVar9;
  char *pcVar10;
  float10 fVar11;
  undefined auStack_d0 [4];
  uint uStack_cc;
  int iStack_c8;
  float fStack_c4;
  undefined4 uStack_c0;
  undefined4 **ppuStack_bc;
  undefined4 *puStack_b8;
  undefined4 **ppuStack_b4;
  undefined4 **ppuStack_b0;
  undefined auStack_a4 [16];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined uStack_5c;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined *puStack_44;
  uint uStack_40;
  int iStack_3c;
  undefined2 uStack_38;
  undefined uStack_34;
  int iStack_30;
  int iStack_2c;
  float fStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e05ec;
  pvStack_10 = ExceptionList;
  pcVar10 = "true";
  pcVar8 = "true";
  ppuStack_b0 = (undefined4 **)0x16;
  ppuStack_b4 = (undefined4 **)0x1943158;
  uStack_94 = 0;
  if (*(char *)*param_3 == '\0') {
    pcVar8 = "false";
  }
  uStack_90 = 0xf;
  auStack_a4[0] = 0;
  puStack_b8 = (undefined4 *)0xa55914;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uStack_7c = 0;
  uStack_78 = 0xf;
  uStack_8c = 0;
  pcVar7 = pcVar8;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  ppuStack_b0 = (undefined4 **)((int)pcVar7 - (int)(pcVar8 + 1));
  puStack_b8 = (undefined4 *)0xa5594b;
  ppuStack_b4 = (undefined4 **)pcVar8;
  FUN_005542c0();
  ppuStack_b0 = (undefined4 **)0x19;
  ppuStack_b4 = (undefined4 **)0x1943170;
  uStack_8 = 1;
  uStack_64 = 0;
  if (*(char *)(*param_3 + 1) == '\0') {
    pcVar10 = "false";
  }
  uStack_60 = 0xf;
  auStack_74[0] = 0;
  puStack_b8 = (undefined4 *)0xa55984;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = 0;
  pcVar8 = pcVar10;
  do {
    cVar2 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar2 != '\0');
  ppuStack_b0 = (undefined4 **)((int)pcVar8 - (int)(pcVar10 + 1));
  puStack_b8 = (undefined4 *)0xa559b3;
  ppuStack_b4 = (undefined4 **)pcVar10;
  FUN_005542c0();
  ppuStack_b0 = (undefined4 **)0xb;
  uStack_8 = 3;
  uStack_34 = 0;
  ppuStack_b4 = (undefined4 **)0xa559c5;
  iStack_30 = FUN_00588320();
  iStack_2c = 0;
  fStack_28 = 1.0;
  uStack_24 = 0;
  iStack_20 = 0;
  piStack_1c = &iStack_30;
  uStack_18 = (double)((ulonglong)uStack_18 & 0xffff000000000000);
  ppuStack_b0 = (undefined4 **)&puStack_44;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puStack_b8 = (undefined4 *)auStack_a4;
  ppuStack_bc = &piStack_1c;
  uStack_c0 = 0xa55a16;
  ppuStack_b4 = (undefined4 **)puStack_b8;
  FUN_00636840();
  ppuStack_b0 = (undefined4 **)auStack_74;
  ppuStack_b4 = (undefined4 **)0xa55a22;
  ppiVar6 = (int **)FUN_00585a50();
  ppuStack_b0 = (undefined4 **)auStack_74;
  puStack_b8 = &param_3;
  ppuStack_bc = (undefined4 **)0xa55a35;
  ppuStack_b4 = ppiVar6;
  FUN_005d4110();
  if (param_3 == (uint *)0x0) {
    ppuStack_b0 = (undefined4 **)auStack_74;
    ppuStack_b4 = (undefined4 **)0xa55a47;
    FUN_00605ce0();
    if (uStack_24 < iStack_2c + 1U) {
      ppuStack_b0 = (undefined4 **)(iStack_2c + 1);
      ppuStack_b4 = (undefined4 **)0xa55a5e;
      FUN_005d99d0();
    }
    ppuStack_b4 = &piStack_1c;
    puStack_b8 = &param_3;
    ppuStack_bc = (undefined4 **)0xa55a6f;
    ppuStack_b0 = ppiVar6;
    FUN_005c5550();
  }
  iVar5 = (int)uStack_18;
  if ((int)uStack_18 != 0) {
    if (uStack_18._5_1_ != '\0') {
      ppuStack_b0 = (undefined4 **)0xa55a84;
      FUN_005509f0();
    }
    ppuStack_b0 = (undefined4 **)0x38;
    ppuStack_b4 = (undefined4 **)iVar5;
    puStack_b8 = (undefined4 *)0xa55a8c;
    FUN_01674ea0();
  }
  ppuStack_b0 = (undefined4 **)FUN_005509f0;
  ppuStack_b4 = (undefined4 **)0x2;
  puStack_b8 = (undefined4 *)0x30;
  ppuStack_bc = (undefined4 **)auStack_a4;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_c0 = 0xa55aa8;
  FUN_016f32d1();
  ppuStack_b0 = (undefined4 **)0x0;
  ppuStack_b4 = (undefined4 **)param_2;
  puStack_b8 = (undefined4 *)param_1;
  puStack_44 = auStack_d0;
  auStack_d0[0] = 0;
  uStack_18 = ((double)iStack_2c + (double)(&DAT_018c0d90)[-(iStack_2c >> 0x1f)]) /
              (double)fStack_28;
  fVar11 = (float10)FUN_01725280(uStack_18);
  uStack_18 = (double)fVar11;
  if (uStack_18 + DAT_018c0d60 < _DAT_018c4e98) {
    FUN_016f3eb1();
  }
  uStack_cc = FUN_00588320();
  iStack_c8 = 0;
  param_3 = &uStack_cc;
  fStack_c4 = fStack_28;
  uStack_c0 = 0;
  ppuStack_bc = (undefined4 **)0x0;
  uStack_8._0_1_ = 8;
  if (iStack_2c != 0) {
    FUN_005d2b00();
    uStack_38 = 0;
    uStack_40 = -(uint)(&stack0x00000000 != (undefined *)0xcd) & (uint)&uStack_cc;
    uStack_8._0_1_ = 9;
    if (iStack_2c == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = *(undefined4 **)(iStack_20 + iStack_30 * 4);
    }
    piVar4 = (int *)((int)ppuStack_bc + *param_3 * 4);
    while (iStack_3c = 0, puVar9 != (undefined4 *)0x0) {
      FUN_00605ce0();
      *(undefined4 *)(iStack_3c + 4) = puVar9[1];
      *piVar4 = iStack_3c;
      iStack_c8 = iStack_c8 + 1;
      piVar3 = (int *)*piVar4;
      uStack_18 = (double)CONCAT44(piVar3,(int)uStack_18);
      puVar9 = (undefined4 *)*puVar9;
      piVar1 = (int *)((int)ppuStack_bc + ((uint)piVar3[1] % *param_3) * 4);
      if (*(int *)((int)ppuStack_bc + ((uint)piVar3[1] % *param_3) * 4) == 0) {
        *piVar1 = (int)piVar4;
        piVar4 = piVar3;
      }
      else {
        *piVar4 = *piVar3;
        *piVar3 = *(undefined4 *)*piVar1;
        *(int **)*piVar1 = piVar3;
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0087c510(&DAT_018c5f98,"CloudLocalization","CloudLocalizationSettings");
  ppuStack_b0 = (undefined4 **)0xa55c27;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20800 ; VA 0x00a55c40 ; FUN_00a55c40 */

void __fastcall FUN_00a55c40(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796b90;
  pvStack_10 = ExceptionList;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0056aeb0(1,"boost shared_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar1);
  }
  if (*(char *)(param_1 + 1) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_006e0140();
    *(undefined *)(param_1 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0056aeb0(1,"boost shared_lock doesn\'t own the mutex");
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar1);
}



/* FUNCTION 20801 ; VA 0x00a55cc0 ; FUN_00a55cc0 */

void __fastcall FUN_00a55cc0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796b90;
  pvStack_10 = ExceptionList;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar1);
  }
  if (*(char *)(param_1 + 1) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_006e00b0();
    *(undefined *)(param_1 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0056aeb0(1,"boost unique_lock doesn\'t own the mutex");
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar1);
}



/* FUNCTION 20802 ; VA 0x00a55d40 ; FUN_00a55d40 */

int * FUN_00a55d40(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e060f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::LMS::Runner>::vftable;
    puVar6 = (undefined4 *)0x0;
    iVar1 = *param_2;
    iVar5 = 0;
    if (iVar1 != 0) {
      puVar6 = (undefined4 *)FUN_01674e20(0x10,0,0);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        puVar6[1] = 1;
        puVar6[2] = 1;
        *puVar6 = std::
                  _Ref_count_resource<class_RBX::LMS::AnalyticsProvider*,struct_std::default_delete<class_RBX::LMS::AnalyticsProvider>_>
                  ::vftable;
        puVar6[3] = iVar1;
      }
      *param_2 = 0;
      iVar5 = iVar1;
    }
    FUN_00fdea10(iVar5,puVar6);
  }
  piVar2 = piVar3 + 3;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar3;
  if ((piVar2 != (int *)0x0) && ((piVar3[4] == 0 || (*(int *)(piVar3[4] + 4) == 0)))) {
    piVar4 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *piVar2 = (int)piVar2;
    piVar2 = (int *)piVar3[4];
    piVar3[4] = (int)piVar4;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = piVar4[1] + -1;
      piVar4[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20803 ; VA 0x00a55e80 ; FUN_00a55e80 */

void __fastcall FUN_00a55e80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a55ee8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20804 ; VA 0x00a55ef0 ; FUN_00a55ef0 */

int __thiscall FUN_00a55ef0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1dcc09c);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 20805 ; VA 0x00a55f20 ; FUN_00a55f20 */

bool FUN_00a55f20(void)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e062c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee78dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee78dc);
    if (DAT_01ee78dc == -1) {
      uStack_8 = 0;
      uVar1 = FUN_01679ce0();
      DAT_01ee78d8 = uVar1 % 100;
      FUN_016f37bf(&DAT_01ee78dc);
    }
  }
  ExceptionList = pvStack_10;
  return (int)DAT_01ee78d8 < DAT_01ee78c8;
}



/* FUNCTION 20806 ; VA 0x00a55fb0 ; FUN_00a55fb0 */

void FUN_00a55fb0(void)

{
  char cVar1;
  
  cVar1 = FUN_00a55f20();
  if (cVar1 != '\0') {
    FUN_00a55fd0();
    return;
  }
  return;
}



/* FUNCTION 20807 ; VA 0x00a55fd0 ; FUN_00a55fd0 */

int FUN_00a55fd0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e065f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined4 *)FUN_01674e20(8);
  uStack_8 = 0;
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    puStack_14 = (undefined4 *)FUN_00fde370(param_1);
  }
  uStack_8 = 1;
  FUN_00a55d40(auStack_1c,&puStack_14);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (puStack_14 != (undefined4 *)0x0) {
    (**(code **)*puStack_14)(1);
  }
  iVar3 = thunk_FUN_00fdf610();
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20808 ; VA 0x00a56080 ; FUN_00a56080 */

undefined4 * __thiscall
FUN_00a56080(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0688;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a57d90(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a57d90(auStack_64);
  uStack_8._0_1_ = 2;
  FUN_00a57d90(auStack_3c);
  ppuVar4 = &PTR_FUN_01943b90;
  cVar3 = FUN_00a571d0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_5c != 0) {
    if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
    }
    uStack_5c = 0;
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_60[2] + -1;
    piStack_60[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_60 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20809 ; VA 0x00a561d0 ; FUN_00a561d0 */

undefined4 * __thiscall
FUN_00a561d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e06b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01943b98;
  cVar3 = FUN_00a57710(param_2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20810 ; VA 0x00a56370 ; FUN_00a56370 */

undefined4 * __thiscall FUN_00a56370(undefined4 *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_1ec [88];
  undefined4 uStack_194;
  undefined auStack_18c [88];
  undefined4 uStack_134;
  undefined auStack_12c [88];
  undefined4 uStack_d4;
  undefined auStack_cc [88];
  undefined4 auStack_74 [2];
  undefined auStack_6c [88];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e071b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00a58350(&stack0x0000000c);
  uStack_194 = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00a58350(auStack_1ec);
  uStack_134 = uStack_194;
  uStack_8._0_1_ = 2;
  FUN_00a58350(auStack_18c);
  auStack_74[0] = uStack_134;
  uStack_8._0_1_ = 3;
  FUN_00a58350(auStack_12c);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_74);
  if (cVar2 == '\0') {
    uStack_d4 = auStack_74[0];
    FUN_00a58350(auStack_6c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x60);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_d4;
      FUN_00a58350(auStack_cc);
    }
    param_1[2] = puVar3;
    FUN_00a58dd0();
    FUN_00a58dd0();
    bVar1 = true;
  }
  else {
    FUN_00a58dd0();
    bVar1 = false;
  }
  FUN_00a58dd0();
  ppuVar4 = &PTR_FUN_01943ba8;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a58dd0();
  FUN_00a58dd0();
  FUN_00a58dd0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20811 ; VA 0x00a564f0 ; FUN_00a564f0 */

void __thiscall
FUN_00a564f0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  ulonglong uStack_58;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0738;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uVar3 = *(undefined4 *)param_4[1];
  uVar4 = *(undefined4 *)*param_4;
  uVar5 = param_1[4];
  uVar6 = param_1[5];
  uVar7 = param_1[2];
  uVar8 = param_1[3];
  uStack_50 = 0;
  uVar9 = param_1[0xe];
  ExceptionList = &pvStack_10;
  if (uVar9 != 0) {
    uStack_50 = uVar9;
    if ((uVar9 & 1) == 0) {
      uStack_58 = ZEXT48(&uStack_48);
      puStack_5c = param_1 + 0x10;
      uStack_60 = 0xa56582;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar9 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_1[0x10];
      uStack_44 = param_1[0x11];
      uStack_40 = param_1[0x12];
      uStack_3c = param_1[0x13];
      uStack_38 = *(undefined8 *)(param_1 + 0x14);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar9 = param_1[6];
  if (uVar9 != 0) {
    if ((uVar9 & 1) == 0) {
      (**(code **)(uVar9 & 0xfffffffe))(param_1 + 8,&uStack_68,0);
    }
    else {
      uStack_68 = param_1[8];
      uStack_64 = param_1[9];
      uStack_60 = param_1[10];
      puStack_5c = (undefined4 *)param_1[0xb];
      uStack_58 = *(ulonglong *)(param_1 + 0xc);
    }
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar7,uVar8,uVar5,uVar6,uVar4,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20812 ; VA 0x00a56630 ; FUN_00a56630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a56630(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0770;
  pvStack_10 = ExceptionList;
  if (DAT_01ee78ec == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7b00) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee7b00);
      if (DAT_01ee7b00 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BadgeService",1,uStack_20,0,0,3,0,0);
        _DAT_01ee7af8 = RBX::Creator<class_RBX::BadgeService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee78f0,&DAT_01ee7af8);
        FUN_016f3654(FUN_0188a180);
        FUN_016f37bf(&DAT_01ee7b00);
      }
    }
    DAT_01ee78ec = &DAT_01ee78f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee78ec;
}



/* FUNCTION 20813 ; VA 0x00a56730 ; FUN_00a56730 */

void FUN_00a56730(void)

{
  int iVar1;
  
  if (DAT_01ee7b04 == 0) {
    iVar1 = FUN_00a56630();
    DAT_01ee7b04 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20814 ; VA 0x00a56750 ; FUN_00a56750 */

int FUN_00a56750(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0780;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009707a0();
  uStack_8 = 0;
  *(undefined2 *)(iVar2 + 0xc) = 0;
  puVar1 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar2 + 0x10) = *puVar1;
  *(undefined4 *)(iVar2 + 0x14) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  uVar3 = FUN_00601dc0();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20815 ; VA 0x00a567cc ; Catch_All@00a567cc */

void Catch_All_00a567cc(void)

{
  int unaff_EBP;
  
  FUN_00970b90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20816 ; VA 0x00a567f0 ; FUN_00a567f0 */

void FUN_00a567f0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008c3510();
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 20817 ; VA 0x00a56820 ; FUN_00a56820 */

int __thiscall FUN_00a56820(int *param_1,uint *param_2,int param_3)

{
  uint uVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint *puVar9;
  uint *puVar10;
  int iVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017e07a8;
  pvStack_10 = ExceptionList;
  iVar11 = *param_1;
  iVar4 = (int)param_2 - iVar11 >> 6;
  iVar5 = param_1[1] - iVar11 >> 6;
  if (iVar5 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar5 + 1;
  uVar8 = param_1[2] - iVar11 >> 6;
  uVar6 = uVar1;
  if ((uVar8 <= 0x3ffffff - (uVar8 >> 1)) && (uVar6 = (uVar8 >> 1) + uVar8, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  uVar8 = uVar6 << 6;
  if (uVar6 < 0x4000000) {
    if (0xfff < uVar8) goto LAB_00a568b1;
    if (uVar8 == 0) {
      puVar9 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar9 = (uint *)FUN_01674e20(uVar8);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00a568b1:
    uVar7 = uVar8 + 0x23;
    if (uVar7 <= uVar8) {
      uVar7 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar8 = FUN_01674e20(uVar7);
    if (uVar8 == 0) goto LAB_00a56ae1;
    puVar9 = (uint *)(uVar8 + 0x23 & 0xffffffe0);
    puVar9[-1] = uVar8;
  }
  uStack_8 = 0;
  puVar9[iVar4 * 0x10] = 0;
  FUN_005880d0(param_3);
  uStack_8._0_1_ = 1;
  puVar9[iVar4 * 0x10 + 8] = 0;
  FUN_005880d0(param_3 + 0x20);
  puVar2 = (uint *)param_1[1];
  uStack_8._0_1_ = 0;
  if (param_2 == puVar2) {
    puVar12 = (uint *)*param_1;
    puVar10 = puVar9;
    while (uStack_8._0_1_ = 2, puVar12 != puVar2) {
      *puVar10 = 0;
      uVar8 = *puVar12;
      if (uVar8 != 0) {
        *puVar10 = uVar8;
        if ((uVar8 & 1) == 0) {
          (**(code **)(uVar8 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
        }
        else {
          uVar8 = puVar12[3];
          uVar7 = puVar12[4];
          uVar3 = puVar12[5];
          puVar10[2] = puVar12[2];
          puVar10[3] = uVar8;
          puVar10[4] = uVar7;
          puVar10[5] = uVar3;
          uVar8 = puVar12[7];
          puVar10[6] = puVar12[6];
          puVar10[7] = uVar8;
        }
      }
      puVar10[8] = 0;
      uVar8 = puVar12[8];
      uStack_8._0_1_ = 3;
      if (uVar8 == 0) {
LAB_00a56a03:
        puVar10 = puVar10 + 0x10;
        puVar12 = puVar12 + 0x10;
      }
      else {
        puVar10[8] = uVar8;
        if ((uVar8 & 1) == 0) {
          (**(code **)(uVar8 & 0xfffffffe))(puVar12 + 10,puVar10 + 10,0);
          goto LAB_00a56a03;
        }
        uVar8 = puVar12[0xb];
        uVar7 = puVar12[0xc];
        uVar3 = puVar12[0xd];
        puVar10[10] = puVar12[10];
        puVar10[0xb] = uVar8;
        puVar10[0xc] = uVar7;
        puVar10[0xd] = uVar3;
        uVar8 = puVar12[0xf];
        puVar10[0xe] = puVar12[0xe];
        puVar10[0xf] = uVar8;
        puVar10 = puVar10 + 0x10;
        puVar12 = puVar12 + 0x10;
      }
    }
  }
  else {
    FUN_00a59aa0(*param_1,param_2,puVar9);
    FUN_00a59aa0(param_2,param_1[1],puVar9 + iVar4 * 0x10 + 0x10);
  }
  iVar11 = *param_1;
  if (iVar11 != 0) {
    iVar5 = param_1[1];
    if (iVar11 != iVar5) {
      do {
        FUN_008c3510();
        iVar11 = iVar11 + 0x40;
      } while (iVar11 != iVar5);
      iVar11 = *param_1;
    }
    uVar8 = param_1[2] - iVar11 & 0xffffffc0;
    iVar5 = iVar11;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iVar11 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar11 - iVar5) - 4U) {
LAB_00a56ae1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + uVar1 * 0x10);
  param_1[2] = (int)(puVar9 + uVar6 * 0x10);
  ExceptionList = pvStack_10;
  return *param_1 + iVar4 * 0x40;
}



/* FUNCTION 20818 ; VA 0x00a56ab7 ; Catch_All@00a56ab7 */

void Catch_All_00a56ab7(void)

{
  int unaff_EBP;
  
  FUN_00a59910(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20819 ; VA 0x00a56af0 ; FUN_00a56af0 */

void __thiscall
FUN_00a56af0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00a59940(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00a56ba2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00a56ba2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 20820 ; VA 0x00a56c50 ; FUN_00a56c50 */

undefined4 * __thiscall
FUN_00a56c50(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_24 [8];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e07c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_00a56af0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar4 = (int *)*param_1;
  if (param_3 == (int *)*piVar4) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 < (uint)param_3[4]))))
    {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00a56af0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar4) {
    iVar1 = piVar4[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if ((*(int *)(iVar1 + 0x14) <= (int)param_4[1]) &&
       ((*(int *)(iVar1 + 0x14) < (int)param_4[1] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) < *param_4)))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00a56af0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 < (uint)param_3[4])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_0096e550(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00a56af0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a56af0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_0096e550(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      piVar4 = piStack_18;
      if ((*piVar5 == *param_1) || (cVar3 = FUN_0096e550(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00a56af0(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a56af0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00a56ea0(auStack_24,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20821 ; VA 0x00a56e85 ; Catch_All@00a56e85 */

void Catch_All_00a56e85(void)

{
  int unaff_EBP;
  
  FUN_00a59940(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20822 ; VA 0x00a56ea0 ; FUN_00a56ea0 */

void __thiscall
FUN_00a56ea0(int *param_1,undefined4 *param_2,char param_3,uint *param_4,int param_5)

{
  uint uVar1;
  uint *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_4;
  puStack_c = &LAB_017e07d0;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)*param_1;
  uStack_8 = 0;
  bVar6 = true;
  if (*(char *)((int)puVar5[1] + 0xd) == '\0') {
    uVar1 = param_4[1];
    puVar4 = (undefined4 *)puVar5[1];
    do {
      puVar5 = puVar4;
      if (param_3 == '\0') {
        if (((int)puVar5[5] < (int)uVar1) ||
           (((int)puVar5[5] <= (int)uVar1 && ((uint)puVar5[4] <= *param_4)))) {
          bVar6 = false;
          goto LAB_00a56f25;
        }
        puVar4 = (undefined4 *)*puVar5;
        bVar6 = true;
      }
      else {
        if (((int)uVar1 < (int)puVar5[5]) ||
           (((int)uVar1 <= (int)puVar5[5] && (*param_4 <= (uint)puVar5[4])))) {
          bVar6 = true;
        }
        else {
          bVar6 = false;
        }
        if (bVar6 == false) {
LAB_00a56f25:
          puVar4 = (undefined4 *)puVar5[2];
        }
        else {
          puVar4 = (undefined4 *)*puVar5;
        }
      }
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar5;
  if (bVar6) {
    if (puVar5 == *(undefined4 **)*param_1) {
      bVar6 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00a56f49;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  iVar3 = param_5;
  puVar4 = _param_3;
  if (((int)puVar2[1] < (int)_param_3[5]) ||
     (((int)puVar2[1] <= (int)_param_3[5] && (*puVar2 <= (uint)_param_3[4])))) {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0072e210();
    FUN_01674ea0(*(undefined4 *)(iVar3 + 0x18),0x18);
    FUN_01674ea0(iVar3,0x20);
    *param_2 = puVar4;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00a56f49:
  puVar5 = (undefined4 *)FUN_00a56af0(&param_3,bVar6,puVar5,puVar2,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20823 ; VA 0x00a56fd9 ; Catch_All@00a56fd9 */

void Catch_All_00a56fd9(void)

{
  int unaff_EBP;
  
  FUN_00a59940(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20824 ; VA 0x00a56ff0 ; FUN_00a56ff0 */

undefined4 * __thiscall
FUN_00a56ff0(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  char cVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e07e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar7 = '\x01';
  piVar2 = (int *)*param_1;
  piVar8 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    uVar3 = param_4[1];
    piVar6 = (int *)piVar2[1];
    do {
      piVar8 = piVar6;
      if (param_3 == '\0') {
        if ((piVar8[5] < (int)uVar3) || ((piVar8[5] <= (int)uVar3 && ((uint)piVar8[4] <= *param_4)))
           ) {
          cVar7 = '\0';
          goto LAB_00a5707d;
        }
        piVar6 = (int *)*piVar8;
        cVar7 = '\x01';
      }
      else {
        if (((int)uVar3 < piVar8[5]) || (((int)uVar3 <= piVar8[5] && (*param_4 <= (uint)piVar8[4])))
           ) {
          cVar7 = '\x01';
        }
        else {
          cVar7 = '\0';
        }
        if (cVar7 == '\0') {
LAB_00a5707d:
          piVar6 = (int *)piVar8[2];
        }
        else {
          piVar6 = (int *)*piVar8;
        }
      }
    } while (*(char *)((int)piVar6 + 0xd) == '\0');
  }
  piVar6 = piVar8;
  if (cVar7 != '\0') {
    if (piVar8 == (int *)*piVar2) {
      cVar7 = '\x01';
      goto LAB_00a570a3;
    }
    if (*(char *)((int)piVar8 + 0xd) == '\0') {
      piVar6 = (int *)*piVar8;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar6[2] + 0xd);
        piVar2 = (int *)piVar6[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar6 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar8[1] + 0xd);
        piVar2 = (int *)piVar8[1];
        piVar6 = piVar8;
        while ((piVar4 = piVar2, cVar1 == '\0' && (piVar6 == (int *)*piVar4))) {
          cVar1 = *(char *)(piVar4[1] + 0xd);
          piVar2 = (int *)piVar4[1];
          piVar6 = piVar4;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar4;
        }
      }
    }
    else {
      piVar6 = (int *)piVar8[2];
    }
  }
  if (((int)param_4[1] < piVar6[5]) ||
     (((int)param_4[1] <= piVar6[5] && (*param_4 <= (uint)piVar6[4])))) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00a570a3:
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_007267c0(&param_3,cVar7,piVar8,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20825 ; VA 0x00a5716a ; Catch_All@00a5716a */

void Catch_All_00a5716a(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20826 ; VA 0x00a57180 ; FUN_00a57180 */

void __thiscall FUN_00a57180(int *param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  iVar3 = param_3 - param_2;
  cVar2 = FUN_00575930(iVar3 >> 3);
  if (cVar2 != '\0') {
    iVar1 = *param_1;
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar1,param_2,iVar3);
    param_1[1] = iVar1 + iVar3;
  }
  return;
}



/* FUNCTION 20827 ; VA 0x00a571d0 ; FUN_00a571d0 */

undefined FUN_00a571d0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_0000002c;
  undefined auStack_64 [4];
  int *piStack_60;
  uint uStack_5c;
  undefined auStack_54 [24];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0817;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a57d90(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00a57d90(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00a57d90(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_5c != 0) {
      if (((uStack_5c & 1) == 0) && (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
      }
      uStack_5c = 0;
    }
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_60[2] + -1;
      piStack_60[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 20828 ; VA 0x00a57380 ; FUN_00a57380 */

void __thiscall
FUN_00a57380(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01943bb0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20829 ; VA 0x00a574a0 ; FUN_00a574a0 */

void __thiscall
FUN_00a574a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int param_5)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 uStack_b8;
  int iStack_b4;
  undefined auStack_b0 [24];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 auStack_50 [2];
  undefined4 uStack_48;
  int iStack_44;
  undefined auStack_40 [24];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e0888;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_b8;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  uStack_b8 = param_4;
  iStack_b4 = param_5;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_18 = param_1;
  FUN_0054ef60(&stack0x00000014);
  uStack_98 = in_stack_0000002c;
  uStack_94 = in_stack_00000030;
  uStack_90 = in_stack_00000034;
  uStack_8c = in_stack_00000038;
  auStack_50[0] = param_2;
  puStack_14 = &uStack_48;
  if (iStack_b4 != 0) {
    LOCK();
    *(int *)(iStack_b4 + 4) = *(int *)(iStack_b4 + 4) + 1;
    UNLOCK();
  }
  uStack_48 = uStack_b8;
  iStack_44 = iStack_b4;
  uStack_8 = 3;
  FUN_0054ef60(auStack_b0);
  uStack_28 = uStack_98;
  uStack_24 = uStack_94;
  uStack_20 = uStack_90;
  uStack_1c = uStack_8c;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(auStack_50);
  if (cVar2 == '\0') {
    uStack_88 = auStack_50[0];
    puStack_14 = &uStack_80;
    if (iStack_44 != 0) {
      LOCK();
      *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
      UNLOCK();
    }
    uStack_80 = uStack_48;
    iStack_7c = iStack_44;
    uStack_8 = 5;
    FUN_0054ef60(auStack_40);
    uStack_60 = uStack_28;
    uStack_5c = uStack_24;
    uStack_58 = uStack_20;
    uStack_54 = uStack_1c;
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x38);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_88;
      puVar3[2] = 0;
      puVar3[3] = 0;
      if (iStack_7c != 0) {
        LOCK();
        *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
        UNLOCK();
      }
      puVar3[2] = uStack_80;
      puVar3[3] = iStack_7c;
      uStack_8 = 8;
      FUN_0054ef60(auStack_78);
      puVar3[10] = uStack_60;
      puVar3[0xb] = uStack_5c;
      puVar3[0xc] = uStack_58;
      puVar3[0xd] = uStack_54;
    }
    param_1[2] = puVar3;
    FUN_006511a0();
    FUN_006511a0();
    bVar1 = true;
  }
  else {
    FUN_006511a0();
    bVar1 = false;
  }
  FUN_006511a0();
  ppuVar4 = &PTR_FUN_01943ba0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar4;
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20830 ; VA 0x00a57710 ; FUN_00a57710 */

undefined FUN_00a57710(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined4 *param_11)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined uVar6;
  undefined auStack_60 [12];
  int *piStack_54;
  undefined4 auStack_38 [2];
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e08b8;
  pvStack_10 = ExceptionList;
  auStack_38[0] = param_1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_30 = param_3;
  uStack_28 = param_5;
  uStack_24 = param_6;
  uStack_20 = param_7;
  uStack_1c = param_8;
  uStack_18 = param_9;
  piStack_2c = param_4;
  uStack_14 = param_10;
  uStack_8 = 1;
  uStack_7 = 0;
  cVar3 = FUN_00585a40(auStack_38);
  piVar2 = piStack_2c;
  if (cVar3 == '\0') {
    FUN_00a58060(auStack_38);
    uStack_8 = 2;
    iVar4 = FUN_01674e20(0x28);
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00a58060(auStack_60);
    }
    *param_11 = uVar5;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_54[1] + -1;
      piStack_54[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        iVar4 = piStack_54[2] + -1;
        piStack_54[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
    piVar2 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar6 = 1;
  }
  else {
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar6 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 20831 ; VA 0x00a57890 ; FUN_00a57890 */

undefined4 *
FUN_00a57890(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined *in_stack_00000038;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 *puStack_54;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e08f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iStack_58 = in_stack_00000034;
  puStack_54 = (undefined4 *)in_stack_00000038;
  in_stack_00000038 = auStack_78;
  uStack_60 = in_stack_0000002c;
  uStack_5c = in_stack_00000030;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  puVar2 = (undefined4 *)FUN_00a580c0(param_3,param_4);
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *puVar2;
  param_1[3] = puVar2[1];
  puStack_54 = puVar2 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iStack_58 = 0xa57958;
  FUN_0054ef60();
  param_1[10] = puVar2[8];
  param_1[0xb] = puVar2[9];
  param_1[0xc] = puVar2[10];
  param_1[0xd] = puVar2[0xb];
  puStack_54 = (undefined4 *)0xa57978;
  FUN_006511a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_54 = (undefined4 *)0xa57991;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_54 = (undefined4 *)0xa579a0;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_54 = (undefined4 *)(in_stack_00000028 + 1);
    iVar3 = param_5;
    if (0xfff < puStack_54) {
      iVar3 = *(int *)(param_5 + -4);
      puStack_54 = (undefined4 *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_5 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_54 = (undefined4 *)&UNK_00a579e8;
        FUN_017167a3();
      }
    }
    uStack_5c = 0xa579cd;
    iStack_58 = iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20832 ; VA 0x00a579f0 ; FUN_00a579f0 */

undefined4 *
FUN_00a579f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_24;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)
           FUN_00a58230(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *puVar3;
  param_1[3] = puVar3[1];
  param_1[4] = puVar3[2];
  param_1[5] = puVar3[3];
  param_1[6] = puVar3[4];
  param_1[7] = puVar3[5];
  param_1[8] = puVar3[6];
  param_1[9] = puVar3[7];
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 20833 ; VA 0x00a57b10 ; FUN_00a57b10 */

undefined4 *
FUN_00a57b10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 *param_16,
            ulonglong param_17,uint param_18,undefined4 param_19,undefined4 param_20,
            undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined8 param_24)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  ulonglong uStack_9c;
  uint uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined8 uStack_7c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0928;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_94 = 0;
  ExceptionList = &pvStack_10;
  if (param_18 != 0) {
    uStack_94 = param_18;
    if ((param_18 & 1) == 0) {
      uStack_9c = ZEXT48(&uStack_8c);
      puStack_a0 = &param_20;
      uStack_a4 = 0xa57b77;
      ExceptionList = &pvStack_10;
      (**(code **)(param_18 & 0xfffffffe))();
    }
    else {
      uStack_8c = param_20;
      uStack_88 = param_21;
      uStack_84 = param_22;
      puStack_80 = (undefined4 *)param_23;
      uStack_7c = param_24;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_11 != 0) {
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,&uStack_ac,0);
    }
    else {
      uStack_ac = param_13;
      uStack_a8 = param_14;
      uStack_a4 = param_15;
      puStack_a0 = param_16;
      uStack_9c = param_17;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uVar2 = FUN_00a58460(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  uStack_7c = CONCAT44(uVar2,0xa57c31);
  FUN_00a58350();
  uStack_7c = CONCAT44(0xa57c39,(undefined4)uStack_7c);
  FUN_00a58dd0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[2] + -1;
    param_4[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_7c = CONCAT44(0xa57c4f,(undefined4)uStack_7c);
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_80 = &param_13;
    uStack_7c = CONCAT44(2,puStack_80);
    uStack_84 = 0xa57c70;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_18 != 0) && ((param_18 & 1) == 0)) &&
     (*(code **)(param_18 & 0xfffffffe) != (code *)0x0)) {
    puStack_80 = &param_20;
    uStack_7c = CONCAT44(2,puStack_80);
    uStack_84 = 0xa57c9e;
    (**(code **)(param_18 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20834 ; VA 0x00a57cc0 ; FUN_00a57cc0 */

uint * FUN_00a57cc0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uStack_8 = 0;
  uVar1 = *param_3;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_3[3];
      uVar2 = param_3[4];
      uVar3 = param_3[5];
      param_1[10] = param_3[2];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_3 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_3 + 2,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20835 ; VA 0x00a57d90 ; FUN_00a57d90 */

undefined4 * __thiscall FUN_00a57d90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017e0948;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20836 ; VA 0x00a57e40 ; FUN_00a57e40 */

undefined4 * __thiscall
FUN_00a57e40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e09ab;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00a56630();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundYieldFuncDesc<class_RBX::BadgeService,bool___cdecl(__int64),1>::
             vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088da50();
    iStack_e4 = 0;
    uStack_e0 = *puVar2;
    uStack_dc = puVar2[1];
    iStack_e4 = FUN_005c9e80();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20837 ; VA 0x00a57fc0 ; FUN_00a57fc0 */

undefined4 * __thiscall FUN_00a57fc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e09c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 4);
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20838 ; VA 0x00a58060 ; FUN_00a58060 */

undefined4 * __thiscall FUN_00a58060(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  return param_1;
}



/* FUNCTION 20839 ; VA 0x00a580c0 ; FUN_00a580c0 */

int __thiscall FUN_00a580c0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000020;
  int in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 *puStack_44;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0a00;
  pvStack_10 = ExceptionList;
  puStack_44 = &param_4;
  uStack_8 = 1;
  iStack_48 = 0xa580f6;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined *)param_1;
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  puStack_44 = (undefined4 *)in_stack_00000028;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iStack_48 = in_stack_00000024;
  puStack_14 = auStack_60;
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a585e0(param_2,param_3);
  *(undefined4 *)(param_1 + 0x28) = in_stack_0000002c;
  *(undefined4 *)(param_1 + 0x2c) = in_stack_00000030;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0xa58170;
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_44 = (undefined4 *)0xa58180;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    puStack_44 = (undefined4 *)(uStack_20 + 1);
    iVar2 = aiStack_34[0];
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      puStack_44 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0xa5821f;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xa581ad;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0xa581c6;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_44 = (undefined4 *)0xa581d5;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    iVar2 = param_4;
    if (0xfff < puStack_44) {
      iVar2 = *(int *)(param_4 + -4);
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_00a58224;
        FUN_017167a3();
      }
    }
    uStack_4c = 0xa58202;
    iStack_48 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20840 ; VA 0x00a58230 ; FUN_00a58230 */

int __thiscall
FUN_00a58230(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  *(undefined4 *)(param_1 + 8) = param_4;
  *(undefined4 *)(param_1 + 0xc) = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x10) = param_6;
  *(undefined4 *)(param_1 + 0x14) = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x18) = param_8;
  *(undefined4 *)(param_1 + 0x1c) = param_9;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 20841 ; VA 0x00a58350 ; FUN_00a58350 */

undefined4 * __thiscall FUN_00a58350(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0a20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
    }
    else {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    }
  }
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20842 ; VA 0x00a58460 ; FUN_00a58460 */

undefined4 __thiscall
FUN_00a58460(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 *param_15,ulonglong param_16,
            uint param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
            undefined4 param_21,undefined4 param_22,undefined8 param_23)

{
  int iVar1;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0a50;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_17 != 0) {
    uStack_3c = param_17;
    if ((param_17 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_19;
      uStack_4c = 0xa584cc;
      ExceptionList = &pvStack_10;
      (**(code **)(param_17 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_19;
      uStack_30 = param_20;
      uStack_2c = param_21;
      puStack_28 = (undefined4 *)param_22;
      uStack_24 = param_23;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_10 != 0) {
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_54,0);
    }
    else {
      uStack_54 = param_12;
      uStack_50 = param_13;
      uStack_4c = param_14;
      puStack_48 = param_15;
      uStack_44 = param_16;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a588d0(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_24 = CONCAT44(0xa58572,(undefined4)uStack_24);
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_12;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa58593;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_17 != 0) && ((param_17 & 1) == 0)) &&
     (*(code **)(param_17 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_19;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa585c1;
    (**(code **)(param_17 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20843 ; VA 0x00a585e0 ; FUN_00a585e0 */

int __thiscall FUN_00a585e0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0a88;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_38);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    iVar2 = aiStack_38[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_38[0] + -4);
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_00000024;
  *(undefined4 *)(param_1 + 0x24) = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20844 ; VA 0x00a58740 ; FUN_00a58740 */

undefined4 * __thiscall
FUN_00a58740(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0ab8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    piVar1 = param_3 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[4] = param_6;
  param_1[5] = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[6] = 0;
  if (param_10 != 0) {
    param_1[6] = param_10;
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,param_1 + 8,0);
    }
    else {
      param_1[8] = param_12;
      param_1[9] = param_13;
      param_1[10] = param_14;
      param_1[0xb] = param_15;
      *(undefined8 *)(param_1 + 0xc) = param_16;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = 3;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20845 ; VA 0x00a588d0 ; FUN_00a588d0 */

int __thiscall
FUN_00a588d0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 *param_15,ulonglong param_16,uint param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined4 param_22,undefined8 param_23)

{
  int iVar1;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0af0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    if ((param_10 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_34,0);
    }
    else {
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      puStack_28 = param_15;
      uStack_24 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00a58740(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_17 != 0) {
    *(uint *)(param_1 + 0x38) = param_17;
    if ((param_17 & 1) == 0) {
      uStack_24 = (ulonglong)(param_1 + 0x40);
      puStack_28 = &param_19;
      uStack_2c = 0xa589bb;
      (**(code **)(param_17 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = param_19;
      *(undefined4 *)(param_1 + 0x44) = param_20;
      *(undefined4 *)(param_1 + 0x48) = param_21;
      *(undefined4 *)(param_1 + 0x4c) = param_22;
      *(undefined8 *)(param_1 + 0x50) = param_23;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_24 = CONCAT44(0xa589d7,(undefined4)uStack_24);
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_12;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa589fc;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_17 != 0) && ((param_17 & 1) == 0)) &&
     (*(code **)(param_17 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_19;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa58a2a;
    (**(code **)(param_17 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20846 ; VA 0x00a58a40 ; FUN_00a58a40 */

int * __thiscall FUN_00a58a40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  
  piVar3 = param_2;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar4 = FUN_00575930(param_2[1] - *param_2 >> 3);
  if (cVar4 != '\0') {
    iVar1 = *param_1;
    iVar2 = *piVar3;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar5 = piVar3[1] - iVar2;
    FUN_0170cc70(iVar1,iVar2,iVar5);
    param_1[1] = iVar1 + iVar5;
    return param_1;
  }
  return param_1;
}



/* FUNCTION 20847 ; VA 0x00a58ac0 ; FUN_00a58ac0 */

undefined4 * __fastcall FUN_00a58ac0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0b74;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::BadgeService,class_RBX::ServiceInstance>::vftable;
  uVar2 = FUN_00a56630();
  param_1[3] = uVar2;
  *param_1 = RBX::BadgeService::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x1c] = 0xffffffff;
  param_1[0x1d] = 0xffffffff;
  param_1[0x1e] = 0x3c;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  puVar1 = param_1 + 0x23;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x24] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_00575ab0();
  *puVar1 = uVar2;
  *(undefined *)(param_1 + 0x25) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x26] = uVar2;
  param_1[0x27] = 0;
  param_1[0x28] = 0x3f800000;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  FUN_016dee4c(param_1 + 0x2b,0x102);
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  uStack_8._0_1_ = 8;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("BadgeService",0xc);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20848 ; VA 0x00a58c70 ; FUN_00a58c70 */

void __fastcall FUN_00a58c70(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::BadgeService>::vftable;
  uVar1 = FUN_00a56630(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20849 ; VA 0x00a58cb0 ; FUN_00a58cb0 */

void __fastcall FUN_00a58cb0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x40) {
    FUN_008c3510();
  }
  return;
}



/* FUNCTION 20850 ; VA 0x00a58ce0 ; FUN_00a58ce0 */

void FUN_00a58ce0(void)

{
  FUN_006511a0();
  return;
}



/* FUNCTION 20851 ; VA 0x00a58cf0 ; FUN_00a58cf0 */

void FUN_00a58cf0(void)

{
  FUN_00a58dd0();
  return;
}



/* FUNCTION 20852 ; VA 0x00a58d00 ; thunk_FUN_00a58dd0 */

code * __fastcall thunk_FUN_00a58dd0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  pcVar4 = *(code **)(param_1 + 0x18);
  uStack_8 = 1;
  if (pcVar4 != (code *)0x0) {
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      if (pcVar4 != (code *)0x0) {
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 20853 ; VA 0x00a58d10 ; FUN_00a58d10 */

void __fastcall FUN_00a58d10(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a599a0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20854 ; VA 0x00a58d70 ; FUN_00a58d70 */

void __fastcall FUN_00a58d70(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a59a30();
      piVar3 = *(int **)(iVar2 + 0x14);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x30);
  }
  return;
}



/* FUNCTION 20855 ; VA 0x00a58dd0 ; FUN_00a58dd0 */

code * __fastcall FUN_00a58dd0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  pcVar4 = *(code **)(param_1 + 0x18);
  uStack_8 = 1;
  if (pcVar4 != (code *)0x0) {
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      if (pcVar4 != (code *)0x0) {
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 20856 ; VA 0x00a58e70 ; FUN_00a58e70 */

void __fastcall FUN_00a58e70(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        FUN_00a59a30();
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20857 ; VA 0x00a58f30 ; FUN_00a58f30 */

void __fastcall FUN_00a58f30(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        FUN_00a59a30();
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar7,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20858 ; VA 0x00a58f40 ; thunk_FUN_00a59a30 */

void __fastcall thunk_FUN_00a59a30(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 20859 ; VA 0x00a58f50 ; FUN_00a58f50 */

int __fastcall FUN_00a58f50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a59a30();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a58f83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 20860 ; VA 0x00a58f90 ; FUN_00a58f90 */

uint * __thiscall FUN_00a58f90(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint *puStack_8;
  
  puVar1 = (undefined4 *)*param_1;
  puVar6 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    uVar2 = param_2[1];
    puVar3 = (undefined4 *)puVar1[1];
    do {
      if (((int)uVar2 < (int)puVar3[5]) ||
         (((int)uVar2 <= (int)puVar3[5] && (*param_2 <= (uint)puVar3[4])))) {
        puVar4 = (undefined4 *)*puVar3;
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if (((puVar6 != puVar1) && ((int)puVar6[5] <= (int)uVar2)) &&
       (((int)puVar6[5] < (int)uVar2 || ((uint)puVar6[4] <= *param_2)))) {
      return puVar6 + 6;
    }
  }
  puStack_8 = param_2;
  iVar5 = FUN_00a56750(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_00a56c50(&param_2,puVar6,iVar5 + 0x10,iVar5);
  return param_2 + 6;
}



/* FUNCTION 20861 ; VA 0x00a59030 ; FUN_00a59030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_00a59030(byte *param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0b88;
  pvStack_10 = ExceptionList;
  uVar5 = param_2[1];
  iVar6 = *param_2;
  uVar7 = uVar5;
  if (((int)uVar5 < 1) && ((int)uVar5 < 0)) {
    uVar7 = ~uVar5;
  }
  uVar7 = (uVar7 >> 2) + uVar7 * 0x40 + iVar6 ^ uVar7;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    FUN_00a5ab50();
    _DAT_00000010 = 0;
    _DAT_00000014 = 0;
    _DAT_00000018 = 0;
    _DAT_00000020 = 0;
    uRam00000024 = 0;
    uRam00000028 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = iVar6;
    _DAT_0000000c = uVar5;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar1);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (int *)0x1;
      uVar5 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar5 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar5 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar4 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar4;
            *(undefined4 **)*piVar4 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar5 = uVar7 % *(uint *)(param_1 + 4);
    piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar7;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar4 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar4;
      _DAT_00000000 = *piVar4;
      *piVar4 = 0;
    }
    else {
      _DAT_00000000 = *piVar4;
      *(undefined4 *)*puVar8 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    FUN_00a58d70();
    ExceptionList = pvStack_10;
    return (int *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20862 ; VA 0x00a59220 ; FUN_00a59220 */

int FUN_00a59220(byte *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0bb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_20 != 0) {
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("IsEnabled",9);
    param_1 = param_1 + *param_1 + 1;
    uVar4 = FUN_0055c740(param_1,auStack_38);
    FUN_00562fc0(&iStack_14,uVar4,auStack_38,-(uint)(param_1 != (byte *)0x0) & (uint)(param_1 + 1));
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar7 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    iVar2 = iStack_14;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    iVar3 = *(int *)(iStack_14 + 0x20);
    iVar5 = FUN_0088daf0();
    if (iVar3 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    pcVar6 = (char *)(iVar2 + 0x28);
    if (*(int *)(iVar2 + 0x24) == 0) {
      pcVar6 = (char *)0x0;
    }
    iStack_14 = CONCAT31(iStack_14._1_3_,*pcVar6 == '\0');
    if (*(uint *)(iStack_18 + 8) == 0) {
      uVar4 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar4);
    }
    iVar3 = (**(code **)((*(uint *)(iStack_18 + 8) & 0xfffffffe) + 4))(iStack_18 + 0x10,iStack_14);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20863 ; VA 0x00a593c0 ; FUN_00a593c0 */

void __thiscall FUN_00a593c0(int *param_1,char *param_2)

{
  uint **ppuVar1;
  uint *puVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  undefined uVar6;
  int iVar7;
  char *pcVar8;
  uint *puVar9;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint *puStack_28;
  uint *puStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint *puStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0bf0;
  pvStack_10 = ExceptionList;
  iStack_1c = *param_1 + 0xac;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_016dee6d();
  if (iVar7 != 0) {
    FUN_016df3c9();
  }
  puStack_28 = (uint *)0x0;
  puStack_24 = (uint *)0x0;
  uStack_20 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iVar7 = FUN_00a59030();
  ppuVar1 = (uint **)(iVar7 + 0x18);
  if (&puStack_28 != ppuVar1) {
    puStack_28 = *ppuVar1;
    *ppuVar1 = (uint *)0x0;
    puStack_24 = *(uint **)(iVar7 + 0x1c);
    *(undefined4 *)(iVar7 + 0x1c) = 0;
    uStack_20 = *(undefined4 *)(iVar7 + 0x20);
    *(undefined4 *)(iVar7 + 0x20) = 0;
    puStack_18 = puStack_24;
    if (puStack_28 != puStack_24) {
      puVar9 = puStack_28 + 8;
      do {
        uVar4 = uStack_4c >> 8;
        uStack_4c = uVar4 << 8;
        uVar5 = uStack_4c;
        pcStack_14 = param_2 + 1;
        pcVar8 = param_2;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        FUN_005542c0(param_2,(int)pcVar8 - (int)pcStack_14);
        uStack_8._0_1_ = 2;
        uVar6 = (undefined)uStack_8;
        uStack_8._0_1_ = 2;
        if (*puVar9 == 0) {
          uStack_8._0_1_ = uVar6;
          FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0();
        }
        uStack_4c = uVar4 << 8;
        (**(code **)((*puVar9 & 0xfffffffe) + 4))(puVar9 + 2,uVar5,uStack_48,uStack_44,uStack_40);
        uStack_8._0_1_ = 1;
        puVar2 = puVar9 + 8;
        puVar9 = puVar9 + 0x10;
      } while (puVar2 != puStack_18);
    }
  }
  FUN_00a59a30();
  uStack_8 = 4;
  iVar7 = FUN_016deec8();
  if (iVar7 != 0) {
    FUN_016df3c9();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20864 ; VA 0x00a59560 ; FUN_00a59560 */

/* WARNING: Removing unreachable block (ram,0x00a595fe) */
/* WARNING: Removing unreachable block (ram,0x00a5960e) */
/* WARNING: Removing unreachable block (ram,0x00a59614) */

void __thiscall FUN_00a59560(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0c18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20865 ; VA 0x00a5966b ; Catch@00a5966b */

undefined * Catch_00a5966b(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00a5967c;
}



/* FUNCTION 20866 ; VA 0x00a596a0 ; FUN_00a596a0 */

/* WARNING: Removing unreachable block (ram,0x00a596fa) */
/* WARNING: Removing unreachable block (ram,0x00a5970a) */
/* WARNING: Removing unreachable block (ram,0x00a59710) */

void __fastcall FUN_00a596a0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0c40;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20867 ; VA 0x00a59758 ; Catch@00a59758 */

undefined * Catch_00a59758(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00a59769;
}



/* FUNCTION 20868 ; VA 0x00a59780 ; FUN_00a59780 */

int __thiscall FUN_00a59780(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 20869 ; VA 0x00a597d0 ; FUN_00a597d0 */

undefined4 * __thiscall FUN_00a597d0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BadgeService::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016dedfb(param_1 + 0x2b);
  FUN_00a58e70();
  iVar2 = param_1[0x23];
  piVar1 = param_1 + 0x23;
  uStack_8 = 0;
  FUN_00a599a0(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  param_1[0x24] = 0;
  FUN_01674ea0(*piVar1,0x20);
  LOCK();
  iVar2 = param_1[0x22];
  param_1[0x22] = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  uVar3 = param_1[0x1b];
  if (0xf < uVar3) {
    iVar2 = param_1[0x16];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20870 ; VA 0x00a59910 ; FUN_00a59910 */

void FUN_00a59910(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008c3510();
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 20871 ; VA 0x00a59940 ; FUN_00a59940 */

void FUN_00a59940(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0072e210();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x18),0x18);
  FUN_01674ea0(param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20872 ; VA 0x00a599a0 ; FUN_00a599a0 */

undefined4 __thiscall FUN_00a599a0(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  void **ppvVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar1 = *(char *)((int)param_2 + 0xd);
  ppvVar3 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar3, cVar1 == '\0') {
    FUN_00a599a0(param_2[2]);
    piVar2 = (int *)*param_2;
    uStack_8 = 0;
    FUN_0072e210();
    FUN_01674ea0(param_2[6],0x18);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(param_2,0x20);
    ppvVar3 = (void **)ExceptionList;
    param_2 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20873 ; VA 0x00a59a30 ; FUN_00a59a30 */

void __fastcall FUN_00a59a30(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3510();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 20874 ; VA 0x00a59aa0 ; FUN_00a59aa0 */

undefined4 * FUN_00a59aa0(int param_1,int param_2,undefined4 *param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e0df0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      *param_3 = 0;
      FUN_005880d0(param_1);
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(param_1 + 0x20);
      param_3 = param_3 + 0x10;
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 20875 ; VA 0x00a59b30 ; FUN_00a59b30 */

void __thiscall
FUN_00a59b30(int param_1,int param_2,char *param_3,uint param_4,int param_5,uint param_6)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  char cVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  uint in_stack_00000034;
  undefined auStack_1bc [8];
  int iStack_1b4;
  char *pcStack_1b0;
  uint uStack_1ac;
  int iStack_1a8;
  undefined4 uStack_1a4;
  undefined4 *puStack_1a0;
  int aiStack_19c [6];
  undefined4 uStack_184;
  undefined4 *puStack_180;
  undefined auStack_17c [28];
  undefined4 uStack_160;
  undefined auStack_15c [84];
  undefined4 uStack_108;
  undefined *puStack_104;
  undefined4 *puStack_100;
  undefined4 uStack_fc;
  undefined auStack_f8 [4];
  undefined4 uStack_f4;
  undefined *puStack_f0;
  int iStack_ec;
  char *pcStack_e8;
  uint uStack_e4;
  char *pcStack_e0;
  undefined *puStack_dc;
  char *pcStack_d8;
  undefined auStack_60 [24];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_24;
  undefined4 uStack_20;
  undefined *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0e4b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_14 = param_1;
  if ((DAT_01d66158 == '\0') && (DAT_01f2ddc0 != 0)) {
    puStack_f0 = &DAT_01d66140;
    uStack_f4 = 0xa59b7e;
    ExceptionList = &pvStack_10;
    FUN_0054ef60();
    puStack_f0 = (undefined *)0xa59b86;
    FUN_005e65e0();
    goto LAB_00a59e2c;
  }
  puStack_dc = (undefined *)0xa59b91;
  ExceptionList = &pvStack_10;
  pcStack_d8 = (char *)param_1;
  cVar5 = FUN_008b9b00();
  if (cVar5 == '\0') {
    pcStack_d8 = "Sorry, badges can only be awarded by Roblox game servers";
    puStack_dc = (undefined *)0x2;
    pcStack_e0 = (char *)0xa59ba4;
    FUN_0086f2f0();
    if (param_6 == 0) {
      pcStack_d8 = (char *)0xa59e99;
      pcStack_d8 = (char *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      puStack_dc = &UNK_00a59ea3;
      FUN_0054e5e0();
    }
    puStack_dc = &stack0x0000001c;
    pcStack_d8 = (char *)0x0;
    pcStack_e0 = (char *)0xa59bc0;
    (**(code **)((param_6 & 0xfffffffe) + 4))();
    goto LAB_00a59e2c;
  }
  puStack_dc = (undefined *)0xa59bce;
  pcStack_d8 = (char *)param_1;
  FUN_0064e810();
  pcStack_e0 = auStack_2c;
  pcStack_d8 = param_3;
  puStack_dc = (undefined *)param_2;
  uStack_e4 = 0xa59be2;
  piVar6 = (int *)FUN_0097fc00();
  piVar7 = piStack_28;
  iVar1 = *piVar6;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    param_1 = iStack_14;
    if (iVar2 == 0) {
      pcStack_d8 = (char *)0xa59bfd;
      (**(code **)*piStack_28)();
      LOCK();
      piVar6 = piVar7 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      param_1 = iStack_14;
      if (iVar2 == 1) {
        pcStack_d8 = (char *)0xa59c0c;
        (**(code **)(*piVar7 + 4))();
        param_1 = iStack_14;
      }
    }
  }
  iVar2 = param_5;
  uVar4 = param_4;
  if (iVar1 == 0) {
    pcStack_d8 = param_3;
    puStack_dc = (undefined *)param_2;
    pcStack_e0 = "The player with userId=%lld is not present at the moment";
    uStack_e4 = 2;
    pcStack_e8 = (char *)0xa59c25;
    FUN_0086f2f0();
    puStack_dc = (undefined *)0xa59c31;
    pcStack_d8 = (char *)iVar1;
    FUN_008927d0();
    goto LAB_00a59e2c;
  }
  if ((param_5 < 1) && ((param_5 < 0 || (param_4 == 0)))) {
    pcStack_d8 = (char *)param_5;
    puStack_dc = (undefined *)param_4;
    pcStack_e0 = "The badgeId %lld is invalid";
    uStack_e4 = 2;
    pcStack_e8 = (char *)0xa59c54;
    FUN_0086f2f0();
    pcStack_d8 = (char *)0x0;
    puStack_dc = (undefined *)0xa59c61;
    FUN_008927d0();
    goto LAB_00a59e2c;
  }
  if (((int)param_3 < 1) && (((int)param_3 < 0 || (param_2 == 0)))) {
    pcStack_d8 = (char *)0x0;
    puStack_dc = (undefined *)0xa59c7e;
    FUN_008927d0();
    goto LAB_00a59e2c;
  }
  pcStack_d8 = (char *)(param_1 + 0x7c);
  puStack_dc = (undefined *)0xa59c8f;
  FUN_00591e70();
  iStack_18 = param_1 + 0x8c;
  uStack_8._0_1_ = 3;
  pcStack_d8 = (char *)&param_2;
  puStack_dc = (undefined *)0xa59ca7;
  piVar7 = (int *)FUN_00a58f90();
  puVar10 = (undefined4 *)*piVar7;
  puVar8 = (undefined4 *)puVar10[1];
  puVar11 = puVar10;
  if (*(char *)((int)puVar10[1] + 0xd) == '\0') {
    do {
      if ((iVar2 < (int)puVar8[5]) || ((iVar2 <= (int)puVar8[5] && (uVar4 <= (uint)puVar8[4])))) {
        puVar9 = (undefined4 *)*puVar8;
        puVar11 = puVar8;
      }
      else {
        puVar9 = (undefined4 *)puVar8[2];
      }
      puVar8 = puVar9;
    } while (*(char *)((int)puVar9 + 0xd) == '\0');
    if (((puVar11 == puVar10) || (iVar2 < (int)puVar11[5])) ||
       ((iVar2 <= (int)puVar11[5] && (uVar4 < (uint)puVar11[4])))) goto LAB_00a59cdf;
  }
  else {
LAB_00a59cdf:
    puVar11 = puVar10;
  }
  pcStack_d8 = (char *)&param_2;
  puStack_dc = (undefined *)0xa59ced;
  puVar10 = (undefined4 *)FUN_00a58f90();
  uStack_8._0_1_ = 1;
  puVar10 = (undefined4 *)*puVar10;
  pcStack_d8 = (char *)0xa59cfb;
  FUN_005923a0();
  if (puVar11 == puVar10) {
    pcStack_d8 = *(char **)(iStack_14 + 0x74);
    puStack_dc = *(undefined **)(iStack_14 + 0x70);
    puStack_f0 = auStack_60;
    pcStack_e0 = (char *)param_5;
    uStack_e4 = uVar4;
    pcStack_e8 = param_3;
    iStack_ec = param_2;
    uStack_f4 = 0xa59d43;
    FUN_00fe0500();
    pcStack_d8 = (char *)0x0;
    puStack_dc = (undefined *)0xd;
    pcStack_e0 = auStack_60;
    uStack_8._0_1_ = 4;
    uStack_e4 = 0xa59d5d;
    FUN_014cc090();
    pcVar3 = param_3;
    iVar1 = param_2;
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = 0;
    pcStack_d8 = (char *)0x0;
    puStack_1c = auStack_f8;
    iStack_18 = CONCAT31(iStack_18._1_3_,DAT_01ee78e8);
    uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee78e9);
    puStack_180 = &stack0x00000034;
    uStack_fc = 0;
    uStack_8._0_1_ = 6;
    puStack_24 = auStack_17c;
    uStack_184 = 0xa59da9;
    FUN_0054f510();
    piStack_28 = aiStack_19c;
    uStack_8._0_1_ = 7;
    puStack_1a0 = &param_6;
    uStack_1a4 = 0xa59dbe;
    FUN_0054f510();
    puStack_1a0 = (undefined4 *)iStack_18;
    uStack_8._0_1_ = 8;
    uStack_1a4 = uStack_20;
    iStack_1a8 = param_5;
    uStack_1ac = param_4;
    pcStack_1b0 = pcVar3;
    iStack_1b4 = iVar1;
    FUN_0060e0c0(auStack_1bc,iStack_14);
    uStack_8._0_1_ = 6;
    FUN_00a57b10(auStack_15c,FUN_00a5a380);
    uStack_160 = 0xa59dfb;
    FUN_00a56370();
    uStack_fc = 0;
    puStack_100 = &DAT_01d79f68;
    puStack_104 = auStack_48;
    uStack_108 = 0xa59e11;
    FUN_014cd990();
    pcStack_d8 = (char *)0xa59e19;
    FUN_005507b0();
    pcStack_d8 = (char *)0xa59e24;
    FUN_0056db40();
    pcStack_d8 = (char *)0xa59e2c;
    FUN_005507b0();
  }
  else {
    pcStack_d8 = param_3;
    puStack_dc = (undefined *)param_2;
    pcStack_e0 = (char *)param_5;
    uStack_e4 = uVar4;
    pcStack_e8 = "We already gave out badgeId=%lld to userId=%lld";
    iStack_ec = 2;
    puStack_f0 = (undefined *)0xa59d15;
    FUN_0086f2f0();
    pcStack_d8 = (char *)0x0;
    puStack_dc = (undefined *)0xa59d22;
    FUN_008927d0();
  }
LAB_00a59e2c:
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      pcStack_e0 = &stack0x0000001c;
      pcStack_d8 = (char *)0x2;
      uStack_e4 = 0xa59e4d;
      puStack_dc = pcStack_e0;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    pcStack_e0 = &stack0x0000003c;
    pcStack_d8 = (char *)0x2;
    uStack_e4 = 0xa59e7b;
    puStack_dc = pcStack_e0;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20876 ; VA 0x00a59eb0 ; FUN_00a59eb0 */

void __thiscall
FUN_00a59eb0(int param_1,undefined4 param_2,undefined4 param_3,code *param_4,undefined4 ****param_5,
            undefined4 *param_6,undefined4 param_7,uint param_8)

{
  uint uVar1;
  code *pcVar2;
  undefined uVar3;
  char cVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  uint in_stack_0000003c;
  undefined auStack_200 [8];
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined *puStack_1f0;
  undefined4 *puStack_1ec;
  code *pcStack_1e8;
  undefined4 ***pppuStack_1e4;
  undefined4 *puStack_1e0;
  undefined auStack_1dc [24];
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  code *pcStack_1bc;
  undefined4 ***pppuStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1a4;
  undefined4 *puStack_1a0;
  undefined4 *puStack_19c;
  byte **ppbStack_198;
  char *pcStack_194;
  undefined4 auStack_b4 [2];
  undefined4 **ppuStack_ac;
  undefined4 *puStack_a8;
  undefined auStack_a4 [24];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 **ppuStack_5c;
  undefined4 *puStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 auStack_28 [2];
  undefined4 uStack_20;
  int iStack_1c;
  byte *pbStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_6;
  puStack_c = &LAB_017e0ee6;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (param_6 == (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    if (param_8 == 0) {
      pcStack_194 = (char *)0xa5a33d;
      ExceptionList = &pvStack_10;
      pcStack_194 = (char *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      ppbStack_198 = (byte **)0xa5a347;
      FUN_0054e5e0();
    }
  }
  else {
    uVar1 = param_6[5];
    puStack_1a0 = param_6;
    if (0xf < uVar1) {
      puStack_1a0 = (undefined4 *)*param_6;
    }
    pcStack_194 = (char *)0x0;
    ppbStack_198 = (byte **)&DAT_018bc9b8;
    puStack_19c = (undefined4 *)param_6[4];
    uStack_1a4 = 0xa59f0a;
    ExceptionList = &pvStack_10;
    cVar4 = FUN_0055c360();
    if (cVar4 == '\0') {
      puStack_1a0 = puVar5;
      if (0xf < uVar1) {
        puStack_1a0 = (undefined4 *)*puVar5;
      }
      pcStack_194 = (char *)0x1;
      ppbStack_198 = (byte **)&DAT_018d0474;
      puStack_19c = (undefined4 *)puVar5[4];
      uStack_1a4 = 0xa59f4b;
      cVar4 = FUN_0055c360();
      if (cVar4 == '\0') {
        if (DAT_01d70008 != '\0') {
          pbStack_18 = (byte *)0x0;
          uStack_14 = 0;
          pcStack_194 = (char *)0x0;
          ppbStack_198 = &pbStack_18;
          uStack_8._0_1_ = 5;
          puStack_19c = puVar5;
          puStack_1a0 = (undefined4 *)0xa59fc3;
          cVar4 = FUN_0098f070();
          if (cVar4 == '\0') {
            pcStack_194 = (char *)0x0;
          }
          else {
            pcStack_194 = (char *)(param_1 + 0x7c);
            ppbStack_198 = (byte **)0xa59fdd;
            FUN_00591e70();
            pcStack_194 = (char *)&param_2;
            uStack_8._0_1_ = 6;
            ppbStack_198 = (byte **)0xa59ff0;
            FUN_00a58f90();
            pcStack_194 = (char *)param_6;
            ppbStack_198 = (byte **)&param_4;
            puStack_19c = (undefined4 *)0x0;
            puStack_1a0 = auStack_28;
            uStack_1a4 = 0xa5a004;
            FUN_00a56ff0();
            uStack_8._0_1_ = 5;
            pcStack_194 = (char *)0xa5a010;
            FUN_005923a0();
            pcStack_194 = *(char **)(param_1 + 0x34);
            ppbStack_198 = (byte **)0xa5a018;
            iStack_1c = FUN_008e4390();
            pbVar6 = pbStack_18;
            if (iStack_1c != 0) {
              pcStack_194 = (char *)0x9;
              ppbStack_198 = (byte **)0x1943878;
              uStack_6c = 0;
              uStack_68 = 0xf;
              auStack_7c[0] = 0;
              puStack_19c = (undefined4 *)0xa5a04a;
              FUN_005542c0();
              uStack_8._0_1_ = 7;
              uVar3 = (undefined)uStack_8;
              uStack_8._0_1_ = 7;
              if (*(int *)(pbVar6 + 8) == 0) {
LAB_00a5a359:
                uStack_8._0_1_ = uVar3;
                pcStack_194 = "Unable to find key in unordered_map.";
                ppbStack_198 = (byte **)0xa5a366;
                pcStack_194 = (char *)FUN_0091a050();
                uStack_8 = CONCAT31(uStack_8._1_3_,8);
                ppbStack_198 = (byte **)0xa5a370;
                FUN_00917680();
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
              }
              pbVar6 = pbVar6 + *pbVar6 + 1;
              pcStack_194 = auStack_7c;
              puStack_19c = (undefined4 *)0xa5a06a;
              ppbStack_198 = (byte **)pbVar6;
              puStack_19c = (undefined4 *)FUN_0055c740();
              ppbStack_198 = (byte **)auStack_7c;
              pcStack_194 = (char *)(-(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1));
              puStack_1a0 = &param_6;
              uStack_1a4 = 0xa5a087;
              FUN_00562fc0();
              uVar3 = (undefined)uStack_8;
              if (param_6 == (undefined4 *)0x0) goto LAB_00a5a359;
              pcStack_194 = (char *)(param_6 + 8);
              ppbStack_198 = (byte **)0xa5a0a1;
              FUN_0056a440();
              uStack_8._0_1_ = 10;
              pcStack_194 = (char *)0xa5a0ad;
              FUN_005507b0();
              pcStack_194 = (char *)0xa5a0b8;
              puVar5 = (undefined4 *)FUN_0088baa0();
              pcStack_194 = (char *)0x1;
              pppuStack_1b8 = (undefined4 ***)0x0;
              pppuStack_1e4 = param_5;
              pcStack_1e8 = param_4;
              puStack_1ec = (undefined4 *)puVar5[1];
              puStack_1f0 = (undefined *)*puVar5;
              uStack_1f4 = param_3;
              uStack_1f8 = param_2;
              FUN_0060dcd0(auStack_200,param_1);
              FUN_00a579f0(&puStack_1e0,FUN_00a5b870);
              pppuStack_1e4 = (undefined4 ***)0xa5a0fb;
              FUN_00a561d0();
              pppuStack_1b8 = (undefined4 ***)0xa5a103;
              FUN_0090ca30();
              uStack_8._0_1_ = 5;
              pcStack_194 = (char *)0xa5a112;
              FUN_0056e5b0();
            }
            pcStack_194 = (char *)0x1;
          }
          ppbStack_198 = (byte **)0xa5a11c;
          FUN_008927d0();
          pcStack_194 = (char *)0xa5a124;
          FUN_00550b30();
          goto LAB_00a5a2d0;
        }
        pcStack_194 = (char *)(param_1 + 0x7c);
        ppbStack_198 = (byte **)0xa5a135;
        FUN_00591e70();
        pcStack_194 = (char *)&param_2;
        uStack_8._0_1_ = 0xb;
        ppbStack_198 = (byte **)0xa5a148;
        FUN_00a58f90();
        pcStack_194 = (char *)param_6;
        ppbStack_198 = (byte **)&param_4;
        puStack_19c = (undefined4 *)0x0;
        puStack_1a0 = auStack_28;
        uStack_1a4 = 0xa5a15c;
        FUN_00a56ff0();
        uStack_8._0_1_ = 1;
        pcStack_194 = (char *)0xa5a168;
        FUN_005923a0();
        pcStack_194 = *(char **)(param_1 + 0x34);
        ppbStack_198 = (byte **)0xa5a170;
        param_6 = (undefined4 *)FUN_008e4390();
        if (param_6 != (undefined4 *)0x0) {
          pcStack_194 = (char *)0x1;
          pppuStack_1b8 = param_5;
          pcStack_1bc = param_4;
          uStack_1c0 = param_3;
          uStack_1c4 = param_2;
          param_5 = (undefined4 ****)auStack_1dc;
          puStack_1e0 = puVar5;
          pppuStack_1e4 = (undefined4 ***)0xa5a19f;
          FUN_0054ef60();
          puStack_1ec = &pppuStack_1e4;
          uStack_8._0_1_ = 0xc;
          puStack_1f0 = (undefined *)0xa5a1af;
          pcStack_1e8 = (code *)param_1;
          FUN_0060dcd0();
          uStack_8._0_1_ = 1;
          puStack_1ec = auStack_b4;
          pcStack_1e8 = FUN_00a5b760;
          puStack_1f0 = (undefined *)0xa5a1c7;
          FUN_00a57890();
          uStack_64 = auStack_b4[0];
          param_5 = (undefined4 ****)&ppuStack_5c;
          if (puStack_a8 != (undefined4 *)0x0) {
            LOCK();
            puStack_a8[1] = puStack_a8[1] + 1;
            UNLOCK();
          }
          ppuStack_5c = ppuStack_ac;
          puStack_58 = puStack_a8;
          pppuStack_1b8 = (undefined4 ***)auStack_a4;
          uStack_8._0_1_ = 0xe;
          pcStack_1bc = (code *)0xa5a21a;
          FUN_0054ef60();
          uStack_3c = uStack_8c;
          uStack_38 = uStack_88;
          uStack_34 = uStack_84;
          uStack_30 = uStack_80;
          uStack_1b4 = 0;
          param_5 = &pppuStack_1e4;
          puStack_1ec = (undefined4 *)uStack_64;
          if (puStack_58 != (undefined4 *)0x0) {
            LOCK();
            puStack_58[1] = puStack_58[1] + 1;
            UNLOCK();
          }
          pppuStack_1e4 = (undefined4 ***)ppuStack_5c;
          puStack_1e0 = puStack_58;
          puStack_1f0 = auStack_54;
          uStack_8._0_1_ = 0x10;
          uStack_1f4 = 0xa5a284;
          FUN_0054ef60();
          uStack_1c4 = uStack_3c;
          uStack_1c0 = uStack_38;
          pcStack_1bc = (code *)uStack_34;
          uStack_8._0_1_ = 0xf;
          pppuStack_1b8 = (undefined4 ***)uStack_30;
          puStack_1f0 = (undefined *)0xa5a2a7;
          FUN_00a574a0();
          pppuStack_1b8 = (undefined4 ***)0xa5a2af;
          FUN_006511a0();
          uStack_8._0_1_ = 1;
          pppuStack_1b8 = (undefined4 ***)0xa5a2be;
          FUN_006511a0();
          pppuStack_1b8 = (undefined4 ***)0xa5a2c6;
          FUN_0090ca30();
        }
        pcStack_194 = (char *)0x1;
      }
      else {
        pcStack_194 = (char *)(param_1 + 0x7c);
        ppbStack_198 = (byte **)0xa59f5e;
        FUN_00591e70();
        pcStack_194 = (char *)&param_2;
        uStack_8._0_1_ = 4;
        ppbStack_198 = (byte **)0xa59f71;
        FUN_00a58f90();
        pcStack_194 = (char *)param_6;
        ppbStack_198 = (byte **)&param_4;
        puStack_19c = (undefined4 *)0x0;
        puStack_1a0 = &uStack_20;
        uStack_1a4 = 0xa59f85;
        FUN_00a56ff0();
        uStack_8._0_1_ = 1;
        pcStack_194 = "j";
        FUN_005923a0();
        pcStack_194 = (char *)0x0;
      }
      ppbStack_198 = (byte **)0xa5a2d0;
      FUN_008927d0();
      goto LAB_00a5a2d0;
    }
    if (param_8 == 0) {
      pcStack_194 = (char *)0xa5a34f;
      pcStack_194 = (char *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      ppbStack_198 = (byte **)0xa5a359;
      FUN_0054e5e0();
    }
  }
  ppbStack_198 = (byte **)&stack0x00000024;
  pcStack_194 = (char *)0x0;
  puStack_19c = (undefined4 *)0xa59f2a;
  (**(code **)((param_8 & 0xfffffffe) + 4))();
LAB_00a5a2d0:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (param_8 != 0) {
    if (((param_8 & 1) == 0) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0)) {
      puStack_19c = (undefined4 *)&stack0x00000024;
      pcStack_194 = (char *)0x2;
      puStack_1a0 = (undefined4 *)0xa5a2f1;
      ppbStack_198 = (byte **)puStack_19c;
      (**(code **)(param_8 & 0xfffffffe))();
    }
    param_8 = 0;
  }
  uStack_8 = 0x12;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_19c = (undefined4 *)&stack0x00000044;
    pcStack_194 = (char *)0x2;
    puStack_1a0 = (undefined4 *)0xa5a31f;
    ppbStack_198 = (byte **)puStack_19c;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20877 ; VA 0x00a5a380 ; FUN_00a5a380 */

void FUN_00a5a380(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 uint param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 *param_14,ulonglong param_15,uint param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined8 uStack_30;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0f18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_30 = CONCAT44(&iStack_20,0xa5a3b0);
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 3;
  if (iStack_20 != 0) {
    puStack_14 = (undefined *)auStack_48;
    puStack_18 = (undefined *)auStack_48;
    auStack_48[0] = 0;
    puVar3 = auStack_48;
    if (param_16 != 0) {
      auStack_48[0] = param_16;
      if ((param_16 & 1) == 0) {
        uStack_50 = ZEXT48(&uStack_40);
        puStack_54 = &param_18;
        uStack_58 = 0xa5a403;
        (**(code **)(param_16 & 0xfffffffe))();
        puVar3 = (uint *)puStack_14;
      }
      else {
        uStack_40 = param_18;
        uStack_3c = param_19;
        uStack_38 = param_20;
        puStack_34 = (undefined4 *)param_21;
        uStack_30 = param_22;
        puVar3 = auStack_48;
      }
    }
    puStack_14 = (undefined *)puVar3;
    puStack_18 = (undefined *)auStack_68;
    uStack_8._0_1_ = 4;
    auStack_68[0] = 0;
    puVar3 = auStack_68;
    if (param_9 != 0) {
      auStack_68[0] = param_9;
      if ((param_9 & 1) == 0) {
        (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_60,0);
        puVar3 = (uint *)puStack_18;
      }
      else {
        uStack_60 = param_11;
        uStack_5c = param_12;
        uStack_58 = param_13;
        puStack_54 = param_14;
        uStack_50 = param_15;
        puVar3 = auStack_68;
      }
    }
    puStack_18 = (undefined *)puVar3;
    uStack_8._0_1_ = 3;
    FUN_00a59eb0(param_3,param_4,param_5,param_6,param_7,param_8);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_30 = CONCAT44(0xa5a484,(undefined4)uStack_30);
      (**(code **)*piStack_1c)();
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_30 = CONCAT44(0xa5a494,(undefined4)uStack_30);
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      uStack_30 = CONCAT44(0xa5a4a8,(undefined4)uStack_30);
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_34 = &param_11;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0xa5a4c9;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_34 = &param_18;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0xa5a4f7;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20878 ; VA 0x00a5a510 ; FUN_00a5a510 */

void FUN_00a5a510(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef30;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee78e9);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xa5a595;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xa5a677;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xa5a697);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20879 ; VA 0x00a5a6b0 ; FUN_00a5a6b0 */

void FUN_00a5a6b0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined auStack_9c [24];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_60;
  uint *puStack_5c;
  uint *puStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0738;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee78e9);
  uVar1 = *param_5;
  uVar2 = param_5[1];
  uVar3 = *param_4;
  uVar4 = param_4[1];
  uStack_50 = 0;
  uVar5 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_50 = uVar5;
    if ((uVar5 & 1) == 0) {
      puStack_58 = &uStack_48;
      uStack_54 = 0;
      puStack_5c = param_7 + 2;
      uStack_60 = 0xa5a746;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_48 = param_7[2];
      uStack_44 = param_7[3];
      uStack_40 = param_7[4];
      uStack_3c = param_7[5];
      uStack_38 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_74 = 0;
  uStack_a0 = param_1;
  uVar5 = *param_6;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_6 + 2,&uStack_b8,0);
    }
    else {
      uStack_b8 = param_6[2];
      uStack_b4 = param_6[3];
      uStack_b0 = param_6[4];
      uStack_ac = param_6[5];
      uStack_a8 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_9c,FUN_008e61f0);
  uStack_a0 = 0xa5a7ba;
  FUN_008dc4b0();
  uStack_8 = 0xffffffff;
  uStack_84 = 0xa5a7d3;
  uStack_80 = uVar3;
  uStack_7c = uVar4;
  uStack_78 = uVar1;
  uStack_74 = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20880 ; VA 0x00a5a7f0 ; FUN_00a5a7f0 */

undefined4 * __thiscall
FUN_00a5a7f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0f61;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a5ae70;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20881 ; VA 0x00a5a9a0 ; FUN_00a5a9a0 */

undefined4 * __thiscall
FUN_00a5a9a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0fa1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a5b010;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20882 ; VA 0x00a5ab50 ; FUN_00a5ab50 */

void __fastcall FUN_00a5ab50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a59a30();
      piVar3 = *(int **)(iVar2 + 0x14);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x30);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[2] = 0;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  puVar4[6] = 0;
  puVar4[7] = 0;
  puVar4[8] = 0;
  puVar4[9] = 0;
  *(undefined8 *)(puVar4 + 10) = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 20883 ; VA 0x00a5abd0 ; FUN_00a5abd0 */

undefined4 * FUN_00a5abd0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_005f4770(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 20884 ; VA 0x00a5ac40 ; FUN_00a5ac40 */

void __thiscall FUN_00a5ac40(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088da50();
    iStack_1b8 = 0;
    uStack_1b4 = *puVar4;
    uStack_1b0 = puVar4[1];
    iStack_1b8 = FUN_005c9e80();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20885 ; VA 0x00a5ae70 ; FUN_00a5ae70 */

void FUN_00a5ae70(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e0ff7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&param_2);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = in_stack_00000020;
  uStack_1bc = 0;
  uStack_1b4 = in_stack_00000024;
  uStack_1bc = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088da50();
  uStack_e8 = in_stack_00000028;
  uStack_ec = 0;
  uStack_e4 = in_stack_0000002c;
  uStack_ec = FUN_005c9e80();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20886 ; VA 0x00a5b010 ; FUN_00a5b010 */

void FUN_00a5b010(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_0088da50();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088da50();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_005c9e80();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088da50();
  uStack_e8 = param_6;
  uStack_ec = 0;
  uStack_e4 = param_7;
  uStack_ec = FUN_005c9e80();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20887 ; VA 0x00a5b180 ; FUN_00a5b180 */

void __thiscall FUN_00a5b180(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00a5a510(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20888 ; VA 0x00a5b240 ; FUN_00a5b240 */

void __thiscall FUN_00a5b240(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e107b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)*param_3)();
  if (1 < uVar2) {
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 2;
    cVar1 = (**(code **)(*param_3 + 4))(2,&uStack_f4);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088baa0();
      uStack_18 = *puVar3;
      uStack_14 = puVar3[1];
      uStack_8._0_1_ = 3;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00a5b31c;
    }
    uStack_8._0_1_ = 4;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8._0_1_ = 1;
  }
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  uStack_18 = *puVar3;
  uStack_14 = puVar3[1];
LAB_00a5b31c:
  uStack_20 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00a5a6b0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_20,
               &uStack_18,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20889 ; VA 0x00a5b3e0 ; FUN_00a5b3e0 */

void __thiscall
FUN_00a5b3e0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0xa5b426;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee78e9);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0xa5b488;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_008e61f0);
  uStack_b8 = 0xa5b4f7;
  FUN_008dc4b0();
  uStack_14._0_1_ = 1;
  uStack_94 = 0xa5b507;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0xa5b528;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0xa5b556;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20890 ; VA 0x00a5b570 ; FUN_00a5b570 */

void FUN_00a5b570(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,uint param_7,undefined4 param_8,code *param_9,
                 undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  uint uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined8 uStack_2a8;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_9;
  uVar1 = param_8;
  puStack_c = &LAB_017e10d7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  FUN_00a5ba20(param_1);
  uStack_50 = param_2;
  param_2 = param_2 & 0xffffff00;
  uStack_4c = param_3;
  uStack_48 = param_4;
  uStack_44 = param_5;
  uStack_40 = uStack_50;
  uStack_3c = param_3;
  uStack_38 = param_4;
  uStack_34 = param_5;
  uStack_30 = CONCAT44(param_7,param_6);
  param_6 = 0;
  param_7 = 0xf;
  uStack_8._0_1_ = 1;
  param_9 = *(code **)(*param_1 + 8);
  uStack_28 = uStack_30;
  uStack_2c0 = FUN_0088cb40();
  uStack_2bc = 0;
  uStack_2b8 = uStack_50;
  uStack_2b4 = uStack_4c;
  uStack_2b0 = uStack_48;
  uStack_2ac = uStack_44;
  uStack_2a8 = uStack_28;
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  uStack_2bc = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1f0 = FUN_0088da50();
  uStack_1ec = 0;
  uStack_1e8 = uVar1;
  uStack_1e4 = uVar2;
  uStack_1ec = FUN_005c9e80();
  uStack_8._0_1_ = 3;
  uStack_120 = FUN_0088da50();
  uStack_118 = param_10;
  uStack_11c = 0;
  uStack_114 = param_11;
  uStack_11c = FUN_005c9e80();
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_2c0,&uStack_50,param_1);
  uStack_8._0_1_ = 5;
  (*param_9)(uStack_14,&uStack_20,param_12);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_016f32d1(&uStack_2c0,0xd0,3,FUN_0056e5b0);
  if (0xf < param_7) {
    uVar4 = param_7 + 1;
    uVar3 = param_2;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_2 - 4);
      uVar4 = param_7 + 0x24;
      if (0x1f < (param_2 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20891 ; VA 0x00a5b760 ; FUN_00a5b760 */

/* WARNING: Removing unreachable block (ram,0x00a5b7fd) */
/* WARNING: Removing unreachable block (ram,0x00a5b80b) */
/* WARNING: Removing unreachable block (ram,0x00a5b85d) */
/* WARNING: Removing unreachable block (ram,0x00a5b81b) */

int FUN_00a5b760(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1100;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_00a5b570(param_1,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20)
                       ,param_4,param_5,param_6,param_7,&uStack_18);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20892 ; VA 0x00a5b870 ; FUN_00a5b870 */

int FUN_00a5b870(int *param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017e114f;
  pvStack_10 = ExceptionList;
  piStack_14 = param_1;
  iStack_8 = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a596a0(param_3,param_4,param_5,param_6,param_7,param_8);
  pcVar3 = *(code **)(*piStack_14 + 8);
  uStack_298 = FUN_0088da50();
  uStack_294 = 0;
  uStack_290 = param_3;
  uStack_28c = param_4;
  uStack_294 = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c8 = FUN_0088da50();
  uStack_1c0 = param_5;
  uStack_1c4 = 0;
  uStack_1bc = param_6;
  uStack_1c4 = FUN_005c9e80();
  iStack_8._0_1_ = 2;
  uStack_f8 = FUN_0088da50();
  uStack_f0 = param_7;
  uStack_f4 = 0;
  uStack_ec = param_8;
  uStack_f4 = FUN_005c9e80();
  iStack_8._0_1_ = 3;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_298,&uStack_28,param_6);
  iStack_8._0_1_ = 4;
  (*pcVar3)(&DAT_021268a0,&uStack_20,&uStack_28);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar4 = FUN_016f32d1(&uStack_298,0xd0,3,FUN_0056e5b0);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20893 ; VA 0x00a5ba20 ; FUN_00a5ba20 */

/* WARNING: Removing unreachable block (ram,0x00a5ba94) */
/* WARNING: Removing unreachable block (ram,0x00a5baa2) */
/* WARNING: Removing unreachable block (ram,0x00a5bacc) */
/* WARNING: Removing unreachable block (ram,0x00a5bab2) */

void FUN_00a5ba20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a59560(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,param_10,
               param_11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20894 ; VA 0x00a5bae0 ; FUN_00a5bae0 */

void FUN_00a5bae0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar1 = *param_2;
  iVar6 = *(int *)(iVar1 + 0x1a0);
  iVar4 = FUN_0088da50();
  if (iVar6 == iVar4) {
    puVar5 = (undefined4 *)(iVar1 + 0x1a8);
    iVar6 = *param_2;
    if (*(int *)(iVar1 + 0x1a4) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    iVar1 = *(int *)(iVar6 + 0xd0);
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    iVar4 = FUN_0088da50();
    if (iVar1 == iVar4) {
      puVar5 = (undefined4 *)(iVar6 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar6 + 0xd4) == 0) {
        puVar5 = (undefined4 *)0x0;
      }
      iVar1 = *param_2;
      iVar6 = FUN_0088cb40(*puVar5,puVar5[1],uVar2,uVar3);
      if (iVar1 == iVar6) {
        piVar7 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar7 = (int *)0x0;
        }
        FUN_0054ef60(piVar7);
        FUN_00a5ba20(param_1);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20895 ; VA 0x00a5bb90 ; FUN_00a5bb90 */

void FUN_00a5bb90(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  
  iVar1 = *param_2;
  iVar8 = *(int *)(iVar1 + 0x1a0);
  iVar6 = FUN_0088da50();
  if (iVar8 == iVar6) {
    puVar7 = (undefined4 *)(iVar1 + 0x1a8);
    iVar8 = *param_2;
    if (*(int *)(iVar1 + 0x1a4) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    iVar1 = *(int *)(iVar8 + 0xd0);
    uVar2 = *puVar7;
    uVar3 = puVar7[1];
    iVar6 = FUN_0088da50();
    if (iVar1 == iVar6) {
      puVar7 = (undefined4 *)(iVar8 + 0xd8);
      param_2 = (int *)*param_2;
      if (*(int *)(iVar8 + 0xd4) == 0) {
        puVar7 = (undefined4 *)0x0;
      }
      iVar1 = *param_2;
      uVar4 = *puVar7;
      uVar5 = puVar7[1];
      iVar8 = FUN_0088da50();
      if (iVar1 == iVar8) {
        piVar9 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar9 = (int *)0x0;
        }
        FUN_00a596a0(*piVar9,piVar9[1],uVar4,uVar5,uVar2,uVar3);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20896 ; VA 0x00a5bc50 ; FUN_00a5bc50 */

void __thiscall FUN_00a5bc50(int param_1,int param_2,uint param_3,uint param_4)

{
  int *piVar1;
  double dVar2;
  int *piVar3;
  int iVar4;
  double *pdVar5;
  uint in_stack_0000002c;
  undefined4 uVar6;
  undefined4 in_stack_fffffed8;
  undefined4 in_stack_fffffedc;
  uint in_stack_fffffee0;
  uint uVar7;
  undefined4 in_stack_fffffee4;
  undefined *puVar8;
  undefined4 in_stack_fffffee8;
  undefined4 in_stack_fffffeec;
  undefined *puVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined8 *puVar13;
  undefined4 uVar14;
  undefined auStack_98 [24];
  undefined auStack_80 [32];
  undefined4 uStack_60;
  int *piStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_40;
  int iStack_3c;
  int *piStack_38;
  byte *pbStack_34;
  undefined8 uStack_30;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uVar7 = param_3;
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017e11b4;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  iStack_3c = param_1;
  if (((int)param_3 < 1) && (((int)param_3 < 0 || (param_2 == 0)))) {
    uVar10 = 0;
    uVar12 = 0xf;
    uVar7 = in_stack_fffffee0 & 0xffffff00;
    ExceptionList = &pvStack_1c;
    puStack_20 = &stack0xfffffffc;
    FUN_005542c0("Invalid badgeId",0xf);
    FUN_005e65e0(uVar7,in_stack_fffffee4,in_stack_fffffee8,in_stack_fffffeec,uVar10,uVar12);
    goto LAB_00a5c037;
  }
  param_1 = param_1 + 0xac;
  ExceptionList = &pvStack_1c;
  iStack_40 = param_1;
  iVar4 = FUN_016dee6d(param_1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  pbStack_34 = (byte *)(iStack_3c + 0x94);
  uStack_14._0_1_ = 2;
  iVar4 = iStack_3c + 0x95 + (uint)*pbStack_34;
  FUN_00606ff0(&iStack_24,(uVar7 >> 2) + uVar7 * 0x40 + param_2 ^ uVar7,&param_2,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  iVar4 = iStack_24;
  if (iStack_24 == 0) {
LAB_00a5bdc5:
    pdVar5 = (double *)FUN_01682800(&uStack_30);
    uStack_60 = 0;
    piStack_5c = (int *)0x0;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_48 = 0;
    uStack_30 = (double)DAT_01d66130 + *pdVar5;
    uStack_14 = CONCAT31(uStack_14._1_3_,5);
    uStack_58 = uStack_30;
    iVar4 = FUN_00a59030(&param_2);
    *(undefined4 *)(iVar4 + 8) = 0;
    piStack_38 = *(int **)(iVar4 + 0xc);
    uStack_60 = 0;
    piStack_5c = (int *)0x0;
    iStack_24 = iVar4 + 8;
    *(undefined4 *)(iVar4 + 0xc) = 0;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_38[1] + -1;
      piStack_38[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar4 = piStack_38[2] + -1;
        piStack_38[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    *(undefined4 *)(iStack_24 + 8) = (undefined4)uStack_30;
    *(int **)(iStack_24 + 0xc) = uStack_30._4_4_;
    if ((undefined4 *)(iStack_24 + 0x10) != &uStack_50) {
      FUN_00a59a30();
      uStack_50 = 0;
      uStack_4c = 0;
      uStack_48 = 0;
      *(undefined4 *)(iStack_24 + 0x10) = 0;
      *(undefined4 *)(iStack_24 + 0x14) = 0;
      *(undefined4 *)(iStack_24 + 0x18) = 0;
    }
    uStack_14 = CONCAT31(uStack_14._1_3_,2);
    FUN_00a59a30();
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_5c[1] + -1;
      piStack_5c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_5c)();
        LOCK();
        iVar4 = piStack_5c[2] + -1;
        piStack_5c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_5c + 4))();
        }
      }
    }
    FUN_00a59030(&param_2);
    uVar10 = FUN_00a57cc0(auStack_80,&param_4,&stack0x0000002c);
    uStack_14._0_1_ = 6;
    FUN_00a5d5d0(uVar10);
    FUN_008c3510();
    uStack_14 = CONCAT31(uStack_14._1_3_,7);
    iVar4 = FUN_016deec8(param_1);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
    uStack_14._0_1_ = 1;
    FUN_0060e0c0(&uStack_30,iStack_3c);
    uVar7 = param_3;
    puVar8 = auStack_98;
    uStack_14._0_1_ = 8;
    uVar10 = 0xa5bf68;
    FUN_00fe1100(puVar8,param_2,param_3);
    uVar11 = 0xd;
    puVar9 = auStack_98;
    uStack_14._0_1_ = 9;
    uVar12 = 0xa5bf85;
    FUN_014cc090(puVar9,0xd,0);
    piVar3 = uStack_30._4_4_;
    uVar14 = 0;
    uStack_14 = CONCAT31(uStack_14._1_3_,10);
    if (uStack_30._4_4_ != (int *)0x0) {
      piVar1 = uStack_30._4_4_ + 2;
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar6 = 0;
    if (uStack_30._4_4_ != (int *)0x0) {
      LOCK();
      uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
      UNLOCK();
    }
    FUN_00a57380((undefined4)uStack_30,uStack_30._4_4_,param_2,uVar7);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))(uVar6);
      }
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    FUN_014ccc70(uVar6,in_stack_fffffed8,in_stack_fffffedc,uVar10,puVar8,uVar12,puVar9,uVar11,uVar14
                );
    FUN_0056db40();
    FUN_005507b0();
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  else {
    if (*(int *)(iStack_24 + 0x20) == *(int *)(iStack_24 + 0x24)) {
      puVar13 = &uStack_30;
      uVar10 = 0xa5bd7e;
      iStack_24 = iStack_24 + 0x20;
      pdVar5 = (double *)FUN_01682800(puVar13);
      dVar2 = *(double *)(iVar4 + 0x18);
      if (dVar2 < *pdVar5 || dVar2 == *pdVar5) goto LAB_00a5bdc5;
      FUN_00557fc0(iVar4 + 0x10);
      FUN_0096e3d0(uVar10,puVar13);
    }
    else {
      iStack_24 = iStack_24 + 0x20;
      uVar10 = FUN_00a57cc0(auStack_80,&param_4,&stack0x0000002c);
      uStack_14._0_1_ = 3;
      FUN_00a5d5d0(uVar10);
      FUN_008c3510();
    }
    uStack_14 = CONCAT31(uStack_14._1_3_,4);
    iVar4 = FUN_016deec8(param_1);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
  }
LAB_00a5c037:
  uStack_14 = CONCAT31(uStack_14._1_3_,0xb);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_14 = 0xc;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20897 ; VA 0x00a5c0a0 ; FUN_00a5c0a0 */

void FUN_00a5c0a0(undefined4 param_1,undefined4 param_2,undefined4 ***param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 ***pppuVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined uVar12;
  uint uVar13;
  char *pcVar14;
  undefined auStack_294 [200];
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined auStack_fc [12];
  undefined auStack_f0 [12];
  undefined auStack_e4 [12];
  undefined auStack_d8 [12];
  undefined auStack_cc [12];
  undefined auStack_c0 [12];
  undefined auStack_b4 [24];
  int iStack_9c;
  undefined4 **appuStack_98 [4];
  int iStack_88;
  uint uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  int iStack_5c;
  undefined *puStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 **appuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar6 = param_4;
  puStack_c = &LAB_017e1311;
  pvStack_10 = ExceptionList;
  uVar13 = 0;
  uStack_50 = 0;
  puStack_58 = (undefined *)&param_1;
  puStack_14 = &stack0xfffffd58;
  iStack_88 = 0;
  uStack_84 = 0xf;
  appuStack_98[0] = (undefined4 **)((uint)appuStack_98[0] & 0xffffff00);
  uStack_8 = 0;
  if (param_4 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    puVar4 = &stack0xfffffd58;
    if ((param_3 != (undefined4 ***)0x0) &&
       (ExceptionList = &pvStack_10, puVar4 = &stack0xfffffd58, appuStack_98 != param_3)) {
      pppuVar9 = param_3;
      if ((undefined4 **)0xf < param_3[5]) {
        pppuVar9 = (undefined4 ***)*param_3;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(pppuVar9,param_3[4]);
      puVar4 = puStack_14;
      if (iStack_88 != 0) {
        uStack_1c = 0;
        uStack_18 = 0;
        uStack_8._0_1_ = 1;
        cVar2 = FUN_0098f070(appuStack_98,&uStack_1c,0);
        if (cVar2 == '\0') {
          appuStack_4c[0] = (undefined4 **)((uint)appuStack_4c[0] & 0xffffff00);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          uStack_3c = 0;
          uStack_38 = 0xf;
          uStack_50 = 0x10;
          FUN_0058a190(iStack_88 + 0x15);
          FUN_00554150("Parsed invalid JSON: ",0x15);
          pppuVar9 = appuStack_98;
          if (0xf < uStack_84) {
            pppuVar9 = (undefined4 ***)appuStack_98[0];
          }
          FUN_00554150(pppuVar9,iStack_88);
          pppuVar9 = appuStack_4c;
          if (0xf < uStack_38) {
            pppuVar9 = (undefined4 ***)appuStack_4c[0];
          }
          FUN_00a593c0(pppuVar9);
          FUN_005507b0();
          FUN_00550b30();
        }
        else {
          puVar4 = (undefined *)FUN_01674e20(0x18);
          param_4 = (int *)puVar4;
          if (puVar4 == (undefined *)0x0) {
            puVar4 = (undefined *)0x0;
          }
          else {
            *puVar4 = 0;
            uVar5 = FUN_00588320(0xb);
            *(undefined4 *)(puVar4 + 4) = uVar5;
            *(undefined4 *)(puVar4 + 8) = 0;
            *(undefined4 *)(puVar4 + 0xc) = 0x3f800000;
            *(undefined4 *)(puVar4 + 0x10) = 0;
            *(undefined4 *)(puVar4 + 0x14) = 0;
          }
          uStack_80 = 0;
          iStack_7c = 0;
          FUN_005c1af0(puVar4,param_4);
          uStack_8._0_1_ = 4;
          uStack_3c = 0;
          uStack_38 = 0xf;
          appuStack_4c[0] = (undefined4 **)((uint)appuStack_4c[0] & 0xffffff00);
          FUN_005542c0(&DAT_018c387c,4);
          piVar6 = (int *)FUN_00580040(&param_4,appuStack_4c);
          iVar3 = *piVar6;
          FUN_005507b0();
          if (iVar3 == 0) {
            FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_c0,&DAT_01c243ac);
          }
          uVar5 = FUN_00563690(auStack_78);
          uStack_8._0_1_ = 5;
          uVar7 = FUN_008db9c0(uVar5);
          uStack_8._0_1_ = 6;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0(&DAT_018d8974,4);
          uVar5 = uStack_80;
          uStack_8._0_1_ = 7;
          FUN_005c4c00(auStack_34);
          FUN_00947a40(uVar7);
          FUN_005507b0();
          uStack_8._0_1_ = 8;
          if (iStack_1c8 != 0) {
            (**(code **)(iStack_1c8 + 8))(auStack_1c4);
          }
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          if ((DAT_01d70008 != '\0') && (cVar2 = FUN_00973950(iStack_9c,1), cVar2 != '\0')) {
            uStack_24 = 0;
            uStack_20 = 0xf;
            auStack_34[0] = 0;
            FUN_005542c0("displayName",0xb);
            piVar6 = (int *)FUN_00580040(&param_4,auStack_34);
            iVar3 = *piVar6;
            FUN_005507b0();
            if (iVar3 == 0) {
              FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_cc,&DAT_01c243ac);
            }
            uVar7 = FUN_00563690(auStack_78);
            uStack_8._0_1_ = 9;
            uVar7 = FUN_008db9c0(uVar7);
            uStack_8._0_1_ = 10;
            uStack_3c = 0;
            uStack_38 = 0xf;
            appuStack_4c[0] = (undefined4 **)((uint)appuStack_4c[0] & 0xffffff00);
            FUN_005542c0("DisplayName",0xb);
            uStack_8._0_1_ = 0xb;
            FUN_005c4c00(appuStack_4c);
            FUN_00947a40(uVar7);
            FUN_005507b0();
            FUN_0056e5b0();
            uStack_8._0_1_ = 4;
            FUN_005507b0();
            uStack_24 = 0;
            uStack_20 = 0xf;
            auStack_34[0] = 0;
            FUN_005542c0("displayDescription",0x12);
            piVar6 = (int *)FUN_00580040(&param_4,auStack_34);
            iVar3 = *piVar6;
            FUN_005507b0();
            if (iVar3 == 0) {
              FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_d8,&DAT_01c243ac);
            }
            iVar3 = *(int *)(iVar3 + 0x20);
            iVar8 = FUN_00888530();
            if (iVar3 == iVar8) {
              uStack_68 = 0;
              uStack_64 = 0xf;
              auStack_78[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              puVar4 = auStack_78;
              uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
              uVar13 = 1;
            }
            else {
              puVar4 = (undefined *)FUN_00563690(auStack_b4);
              uStack_8 = 0xd;
              uVar13 = 2;
            }
            uStack_50 = uVar13;
            uVar7 = FUN_008db9c0(puVar4);
            uStack_8 = 0xe;
            uStack_3c = 0;
            uStack_38 = 0xf;
            appuStack_4c[0] = (undefined4 **)((uint)appuStack_4c[0] & 0xffffff00);
            FUN_005542c0("DisplayDescription",0x12);
            uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
            FUN_005c4c00(appuStack_4c);
            FUN_00947a40(uVar7);
            FUN_005507b0();
            FUN_0056e5b0();
            if ((uVar13 & 2) != 0) {
              uVar13 = uVar13 & 0xfffffffd;
              uStack_50 = uVar13;
              FUN_005507b0();
            }
            uStack_8._0_1_ = 4;
            uStack_8._1_3_ = 0;
            if ((uVar13 & 1) != 0) {
              uVar13 = uVar13 & 0xfffffffe;
              uStack_50 = uVar13;
              FUN_005507b0();
            }
          }
          uStack_68 = 0;
          uStack_64 = 0xf;
          auStack_78[0] = 0;
          FUN_005542c0("description",0xb);
          piVar6 = (int *)FUN_00580040(&param_3,auStack_78);
          iVar3 = *piVar6;
          FUN_005507b0();
          if (iVar3 == 0) {
            FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_e4,&DAT_01c243ac);
          }
          param_4 = *(int **)(iVar3 + 0x20);
          piVar6 = (int *)FUN_00888530();
          if (param_4 == piVar6) {
            uStack_3c = 0;
            uStack_38 = 0xf;
            appuStack_4c[0] = (undefined4 **)((uint)appuStack_4c[0] & 0xffffff00);
            FUN_005542c0(&DAT_018bc9b8,0);
            pppuVar9 = appuStack_4c;
            uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
            uVar13 = uVar13 | 4;
          }
          else {
            pppuVar9 = (undefined4 ***)FUN_00563690(auStack_b4);
            uStack_8 = 0x11;
            uVar13 = uVar13 | 8;
          }
          uStack_50 = uVar13;
          uVar7 = FUN_008db9c0(pppuVar9);
          uStack_8 = 0x12;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0("Description",0xb);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
          FUN_005c4c00(auStack_34);
          FUN_00947a40(uVar7);
          FUN_005507b0();
          FUN_0056e5b0();
          if ((uVar13 & 8) != 0) {
            uVar13 = uVar13 & 0xfffffff7;
            FUN_005507b0();
          }
          uStack_8._0_1_ = 4;
          uStack_8._1_3_ = 0;
          if ((uVar13 & 4) != 0) {
            FUN_005507b0();
          }
          uStack_68 = 0;
          uStack_64 = 0xf;
          auStack_78[0] = 0;
          FUN_005542c0("iconImageId",0xb);
          piVar6 = (int *)FUN_00580040(&param_4,auStack_78);
          iVar3 = *piVar6;
          FUN_005507b0();
          if (iVar3 == 0) {
            FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_f0,&DAT_01c243ac);
          }
          iVar8 = *(int *)(iVar3 + 0x20);
          iVar10 = FUN_0088da50();
          if (iVar8 == iVar10) {
            iVar8 = *(int *)(iVar3 + 0x20);
            iVar10 = FUN_0088da50();
            if (iVar8 != iVar10) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            puVar11 = (undefined4 *)(iVar3 + 0x28);
            if (*(int *)(iVar3 + 0x24) == 0) {
              puVar11 = (undefined4 *)0x0;
            }
            uStack_54 = *puVar11;
            uVar13 = puVar11[1];
          }
          else {
            if (*(undefined4 **)(iVar3 + 0x24) != (undefined4 *)0x0) {
              (*(code *)**(undefined4 **)(iVar3 + 0x24))(iVar3 + 0x28,auStack_294);
            }
            iVar3 = *(int *)(iVar3 + 0x24);
            uStack_8._0_1_ = 0x14;
            puVar11 = (undefined4 *)FUN_0088baa0();
            uStack_54 = *puVar11;
            uVar13 = puVar11[1];
            uStack_8._0_1_ = 0x15;
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(auStack_294);
            }
            uStack_8._0_1_ = 4;
          }
          uStack_50 = uVar13;
          uVar7 = FUN_00913280(&uStack_54);
          uStack_8._0_1_ = 0x16;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0("IconImageId",0xb);
          uStack_8._0_1_ = 0x17;
          FUN_005c4c00(auStack_34);
          FUN_00947a40(uVar7);
          FUN_005507b0();
          uStack_8._0_1_ = 4;
          FUN_0056e5b0();
          uStack_68 = 0;
          uStack_64 = 0xf;
          auStack_78[0] = 0;
          FUN_005542c0("enabled",7);
          piVar6 = (int *)FUN_00580040(&param_4,auStack_78);
          iVar3 = *piVar6;
          FUN_005507b0();
          if (iVar3 == 0) {
            FUN_0056aac0();
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_fc,&DAT_01c243ac);
          }
          iVar8 = *(int *)(iVar3 + 0x20);
          iVar10 = FUN_0088daf0();
          if (iVar8 == iVar10) {
            iVar8 = *(int *)(iVar3 + 0x20);
            iVar10 = FUN_0088daf0();
            if (iVar8 != iVar10) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            puVar4 = (undefined *)(iVar3 + 0x28);
            if (*(int *)(iVar3 + 0x24) == 0) {
              puVar4 = (undefined *)0x0;
            }
            uVar12 = *puVar4;
          }
          else {
            if (*(undefined4 **)(iVar3 + 0x24) != (undefined4 *)0x0) {
              (*(code *)**(undefined4 **)(iVar3 + 0x24))(iVar3 + 0x28,auStack_294);
            }
            iVar3 = *(int *)(iVar3 + 0x24);
            uStack_8._0_1_ = 0x18;
            puVar4 = (undefined *)FUN_0088bcc0();
            uVar12 = *puVar4;
            uStack_8._0_1_ = 0x19;
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(auStack_294);
            }
            uStack_8._0_1_ = 4;
          }
          uStack_1cc = FUN_0088daf0();
          iStack_1c8 = 0;
          auStack_1c4[0] = uVar12;
          iStack_1c8 = FUN_005c9ef0();
          uStack_8._0_1_ = 0x1a;
          uStack_24 = 0;
          uStack_20 = 0xf;
          auStack_34[0] = 0;
          FUN_005542c0("IsEnabled",9);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
          FUN_005c4c00(auStack_34);
          FUN_00947a40(&uStack_1cc);
          FUN_005507b0();
          FUN_0056e5b0();
          uStack_8 = 3;
          FUN_00568780(iStack_9c + 0xac);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
          iVar3 = FUN_00a59030(&param_1);
          if (iStack_7c != 0) {
            LOCK();
            *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
            UNLOCK();
          }
          *(undefined4 *)(iVar3 + 8) = uVar5;
          piVar6 = *(int **)(iVar3 + 0xc);
          *(int *)(iVar3 + 0xc) = iStack_7c;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar3 = piVar6[1] + -1;
            piVar6[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar3 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar3 == 1) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          iStack_60 = 0;
          iStack_5c = 0;
          puStack_58 = (undefined *)0x0;
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
          iVar3 = FUN_00a59030(&param_1);
          iVar3 = iVar3 + 0x18;
          uVar5 = 0xa5c9c8;
          FUN_00a5d680(iVar3);
          iVar10 = iStack_5c;
          for (iVar8 = iStack_60; iVar8 != iVar10; iVar8 = iVar8 + 0x40) {
            FUN_00557fc0(&uStack_80);
            FUN_0096e3d0(uVar5,iVar3);
          }
          FUN_00a59a30();
          FUN_0056c890();
          FUN_00550b30();
          FUN_00550b30();
        }
        goto LAB_00a5ca5e;
      }
    }
    puStack_14 = puVar4;
    pcVar14 = "Failed due to empty response";
  }
  else {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xfffffd58;
    iVar3 = FUN_0170d75d(param_4,0,&std::exception::RTTI_Type_Descriptor,
                         &RBX::http_status_error::RTTI_Type_Descriptor,0);
    if ((iVar3 == 0) || (*(int *)(iVar3 + 0x24) != 0x194)) {
      pcVar14 = (char *)(**(code **)(*piVar6 + 4))();
    }
    else {
      pcVar14 = "badgeId is invalid or does not exist.";
    }
  }
  FUN_00a593c0(pcVar14);
LAB_00a5ca5e:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20898 ; VA 0x00a5ca10 ; Catch@00a5ca10 */

undefined4 Catch_00a5ca10(void)

{
  uint uVar1;
  undefined4 *puVar2;
  int unaff_EBP;
  
  puVar2 = (undefined4 *)
           FUN_00558df0(unaff_EBP + -0xb0,"Parsed invalid JSON field: ",unaff_EBP + -0x94);
  uVar1 = puVar2[5];
  *(undefined *)(unaff_EBP + -4) = 0x1d;
  if (0xf < uVar1) {
    puVar2 = (undefined4 *)*puVar2;
  }
  FUN_00a593c0(puVar2);
  FUN_005507b0();
  return 0xa5c9fe;
}



/* FUNCTION 20899 ; VA 0x00a5cb40 ; FUN_00a5cb40 */

/* WARNING: Removing unreachable block (ram,0x00a5cb9d) */
/* WARNING: Removing unreachable block (ram,0x00a5cba9) */
/* WARNING: Removing unreachable block (ram,0x00a5cbb7) */

undefined4 FUN_00a5cb40(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a59220(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20900 ; VA 0x00a5cbd0 ; FUN_00a5cbd0 */

void FUN_00a5cbd0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[0xd];
  pcVar4 = (code *)*puVar2;
  uVar5 = puVar2[0xc];
  uVar6 = puVar2[0xb];
  uVar7 = puVar2[10];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(puVar2[2],puVar2[3],puVar2 + 4,uVar7,uVar6,uVar5,uVar3);
  return;
}



/* FUNCTION 20901 ; VA 0x00a5cc20 ; FUN_00a5cc20 */

void FUN_00a5cc20(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[9];
  pcVar4 = (code *)*puVar2;
  uVar5 = puVar2[8];
  uVar6 = puVar2[7];
  uVar7 = puVar2[6];
  uVar8 = puVar2[5];
  uVar9 = puVar2[4];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(puVar2[2],puVar2[3],uVar9,uVar8,uVar7,uVar6,uVar5,uVar3);
  return;
}



/* FUNCTION 20902 ; VA 0x00a5cc70 ; FUN_00a5cc70 */

int FUN_00a5cc70(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a5c0a0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),param_2,param_3
                        );
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20903 ; VA 0x00a5cd00 ; FUN_00a5cd00 */

void FUN_00a5cd00(undefined4 *param_1)

{
  undefined *puStack_c;
  undefined *puStack_8;
  
  puStack_c = &stack0x00000008;
  puStack_8 = &stack0x0000000c;
  FUN_00a564f0(param_1,*param_1,&puStack_c,0);
  return;
}



/* FUNCTION 20904 ; VA 0x00a5cd30 ; FUN_00a5cd30 */

void __thiscall
FUN_00a5cd30(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11)

{
  int iVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  char cVar4;
  undefined4 uStack_9c;
  int *piStack_98;
  uint uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined auStack_70 [24];
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  char *pcStack_34;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1398;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_38 = (undefined4 *)0xa5cd5c;
  ExceptionList = &pvStack_10;
  pcStack_34 = (char *)param_1;
  cVar4 = FUN_008b9b00();
  if (cVar4 == '\0') {
    pcStack_34 = "Sorry, badges can only be tested if they are disabled on Roblox game servers";
    puStack_38 = (undefined4 *)0x2;
    puStack_3c = (undefined4 *)0xa5cd6f;
    FUN_0086f2f0();
    if (param_4 == 0) {
      pcStack_34 = (char *)0xa5ceda;
      pcStack_34 = (char *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      puStack_38 = (undefined4 *)0xa5cee4;
      FUN_0054e5e0();
    }
  }
  else {
    if ((*(uint *)(param_1 + 0x70) & *(uint *)(param_1 + 0x74)) != 0xffffffff) {
      puStack_38 = &uStack_24;
      puStack_3c = (undefined4 *)0xa5cdb5;
      pcStack_34 = (char *)param_1;
      FUN_0060e0c0();
      puStack_18 = auStack_50;
      uStack_8._0_1_ = 4;
      puStack_54 = &param_11;
      uStack_58 = 0xa5cdca;
      FUN_0054f510();
      puStack_14 = auStack_70;
      uStack_74 = 0;
      puStack_1c = (undefined *)&uStack_9c;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[2] = piStack_20[2] + 1;
        UNLOCK();
      }
      uStack_9c = uStack_24;
      piStack_98 = piStack_20;
      uStack_94 = 0;
      uStack_8._0_1_ = 6;
      puVar2 = &uStack_9c;
      puVar3 = auStack_70;
      if (param_4 != 0) {
        uStack_94 = param_4;
        if ((param_4 & 1) == 0) {
          (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_8c,0);
          puVar2 = (undefined4 *)puStack_1c;
          puVar3 = puStack_14;
        }
        else {
          uStack_8c = param_6;
          uStack_88 = param_7;
          uStack_84 = param_8;
          uStack_80 = param_9;
          uStack_7c = param_10;
          puVar2 = &uStack_9c;
          puVar3 = auStack_70;
        }
      }
      puStack_14 = puVar3;
      puStack_1c = (undefined *)puVar2;
      uStack_8._0_1_ = 5;
      FUN_00a56080();
      uStack_74 = param_3;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_7c = CONCAT44(param_2,0xa5ce59);
      FUN_00a5bc50();
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[2] + -1;
        piStack_20[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pcStack_34 = (char *)0xa5ce6e;
          (**(code **)(*piStack_20 + 4))();
        }
      }
      goto LAB_00a5ce6e;
    }
    if (param_4 == 0) {
      pcStack_34 = (char *)0xa5ceec;
      pcStack_34 = (char *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      puStack_38 = (undefined4 *)&UNK_00a5cef6;
      FUN_0054e5e0();
    }
  }
  puStack_38 = &param_6;
  pcStack_34 = (char *)0x1;
  puStack_3c = (undefined4 *)0xa5cda3;
  (**(code **)((param_4 & 0xfffffffe) + 4))();
LAB_00a5ce6e:
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_6;
    pcStack_34 = (char *)0x2;
    uStack_40 = 0xa5ce8f;
    puStack_38 = puStack_3c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = (undefined4 *)&stack0x00000034;
    pcStack_34 = (char *)0x2;
    uStack_40 = 0xa5cebd;
    puStack_38 = puStack_3c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20905 ; VA 0x00a5cf00 ; FUN_00a5cf00 */

void FUN_00a5cf00(undefined4 param_1,undefined4 param_2,uint param_3)

{
  undefined4 uVar1;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e13c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  (**(code **)((param_3 & 0xfffffffe) + 4))(&stack0x00000014,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20906 ; VA 0x00a5cfb0 ; FUN_00a5cfb0 */

uint FUN_00a5cfb0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a56630();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 20907 ; VA 0x00a5cfd0 ; FUN_00a5cfd0 */

uint FUN_00a5cfd0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a56630();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 20908 ; VA 0x00a5cff0 ; FUN_00a5cff0 */

void FUN_00a5cff0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00a57d90(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar4 + 0x10,iVar4 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar4 + 8) = 0;
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(iVar4,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dcc5ec);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_0ac23d1267f3184ea03c8e48cf4111d9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20909 ; VA 0x00a5d170 ; FUN_00a5d170 */

int * FUN_00a5d170(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a5d227. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a5d1ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dcc190);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_24b71c98c9ffd6b6c8e4c246f8cc174a>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20910 ; VA 0x00a5d240 ; FUN_00a5d240 */

void FUN_00a5d240(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a57fc0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_006511a0();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dcc3ec);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::BadgeService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,__int64,__int64),class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_RBX::BadgeService>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20911 ; VA 0x00a5d390 ; FUN_00a5d390 */

void FUN_00a5d390(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x28);
      if (iVar2 != 0) {
        iVar3 = FUN_00a58060(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcc52c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::BadgeService>,__int64,__int64,__int64),class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_RBX::BadgeService>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20912 ; VA 0x00a5d480 ; FUN_00a5d480 */

void FUN_00a5d480(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x60);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00a58350(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a58dd0();
        FUN_01674ea0(iVar3,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcc1cc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::BadgeService>,__int64,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*,class_boost::function<void___cdecl(bool)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list7<class_boost::_bi::value<class_std::weak_ptr<class_RBX::BadgeService>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_boost::function<void___cdecl(bool)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20913 ; VA 0x00a5d5d0 ; FUN_00a5d5d0 */

void __thiscall FUN_00a5d5d0(int param_1,int param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e13e8;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    ExceptionList = &pvStack_10;
    *puVar1 = 0;
    FUN_005880d0(param_2);
    uStack_8 = 0;
    puVar1[8] = 0;
    FUN_005880d0(param_2 + 0x20);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x40;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00a56820(puVar1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20914 ; VA 0x00a5d660 ; FUN_00a5d660 */

void __thiscall FUN_00a5d660(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x70) = param_2;
  *(undefined4 *)(param_1 + 0x74) = param_3;
  return;
}



/* FUNCTION 20915 ; VA 0x00a5d680 ; FUN_00a5d680 */

void __thiscall FUN_00a5d680(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  if (param_1 != param_2) {
    uVar1 = *param_1;
    *param_1 = *param_2;
    *param_2 = uVar1;
    uVar1 = param_1[1];
    param_1[1] = param_2[1];
    param_2[1] = uVar1;
    uVar1 = param_1[2];
    param_1[2] = param_2[2];
    param_2[2] = uVar1;
  }
  return;
}



/* FUNCTION 20916 ; VA 0x00a5d6c0 ; FUN_00a5d6c0 */

void FUN_00a5d6c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 *param_10,ulonglong param_11,uint param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined8 param_18)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1418;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_3c = param_12;
    if ((param_12 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_14;
      uStack_4c = 0xa5d729;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_14;
      uStack_30 = param_15;
      uStack_2c = param_16;
      puStack_28 = (undefined4 *)param_17;
      uStack_24 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_54,0);
    }
    else {
      uStack_54 = param_7;
      uStack_50 = param_8;
      uStack_4c = param_9;
      puStack_48 = param_10;
      uStack_44 = param_11;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00a5d7f0(param_1,param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_7;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa5d7ac;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_14;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xa5d7da;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20917 ; VA 0x00a5d7f0 ; FUN_00a5d7f0 */

void FUN_00a5d7f0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int iVar1;
  uint *puVar2;
  uint *puVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  int iVar6;
  undefined **ppuVar7;
  longlong lVar8;
  undefined auStack_1c4 [8];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 *puStack_1b0;
  undefined4 *puStack_1ac;
  undefined4 uStack_1a8;
  uint auStack_1a4 [2];
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 *puStack_190;
  ulonglong uStack_18c;
  uint auStack_184 [2];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined8 uStack_16c;
  undefined auStack_164 [96];
  undefined4 uStack_104;
  undefined4 uStack_100;
  char *pcStack_fc;
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 *puStack_e8;
  undefined **ppuStack_e4;
  undefined *puStack_e0;
  undefined auStack_6c [24];
  undefined *puStack_54;
  undefined *apuStack_50 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  puStack_c = &LAB_017e147b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ppuStack_e4 = (undefined **)0xa5d822;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_0097ee20();
  if (iVar6 == 1) {
    puStack_e0 = (undefined *)uStack_14;
    ppuStack_e4 = (undefined **)0xa5d838;
    iVar6 = FUN_0064e810();
    if ((iVar6 != 0) && (*(int *)(iVar6 + 0xf4) != 0)) {
      puStack_e0 = (undefined *)0xa5d84e;
      lVar8 = FUN_00928340();
      if (lVar8 == CONCAT44(param_2,param_1)) goto LAB_00a5d885;
    }
    uStack_f8 = 0x2e;
    ppuStack_e4 = (undefined **)0x0;
    puStack_e0 = (undefined *)0xf;
    pcStack_fc = "UserHasBadgeAsync: can only query local player";
    puStack_f4 = (undefined *)((uint)puStack_f4 & 0xffffff00);
    uStack_100 = 0xa5d878;
    FUN_005542c0();
    uStack_f8 = 0xa5d880;
    FUN_005e65e0();
  }
  else {
LAB_00a5d885:
    if ((param_2 < 1) && (param_2 < 0)) {
      if (param_5 == 0) {
        puStack_e0 = (undefined *)0xa5dae4;
        puStack_e0 = (undefined *)FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
        ppuStack_e4 = (undefined **)&UNK_00a5daee;
        FUN_0054e5e0();
      }
      ppuStack_e4 = (undefined **)&param_7;
      puStack_e0 = (undefined *)0x0;
      puStack_e8 = (undefined4 *)0xa5d8a8;
      (**(code **)((param_5 & 0xfffffffe) + 4))();
    }
    else {
      uStack_40 = 0;
      uStack_3c = 0xf;
      apuStack_50[0]._0_1_ = 0;
      puStack_e0 = (undefined *)param_4;
      uStack_24 = param_3;
      puStack_20 = (undefined *)param_4;
      ppuStack_e4 = &puStack_1c;
      puStack_e8 = &uStack_24;
      uStack_8._0_1_ = 3;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_28 = 0;
      puStack_ec = (undefined4 *)0xa5d8fa;
      FUN_00a57180();
      uStack_8._0_1_ = 4;
      puStack_ec = &uStack_30;
      uStack_f0 = 0xa5d90c;
      FUN_00a58a40();
      puStack_ec = (undefined4 *)param_2;
      puStack_f4 = auStack_6c;
      uStack_f0 = param_1;
      uStack_f8 = 0xa5d917;
      ppuVar7 = (undefined **)FUN_00fe0d20();
      uStack_8._0_1_ = 5;
      if (apuStack_50 != ppuVar7) {
        puStack_e0 = ppuVar7[4];
        if ((undefined *)0xf < ppuVar7[5]) {
          ppuVar7 = (undefined **)*ppuVar7;
        }
        puStack_e8 = (undefined4 *)0xa5d93a;
        ppuStack_e4 = ppuVar7;
        FUN_005542c0();
      }
      uStack_8._0_1_ = 4;
      puStack_e0 = (undefined *)0xa5d946;
      FUN_005507b0();
      puStack_e0 = (undefined *)0x0;
      ppuStack_e4 = (undefined **)0xd;
      puStack_e8 = apuStack_50;
      puStack_ec = (undefined4 *)0xa5d959;
      FUN_014cc090();
      puStack_e0 = (undefined *)0x0;
      puStack_1c = (undefined *)&uStack_100;
      param_2 = CONCAT31(param_2._1_3_,DAT_01ee78e8);
      uStack_34 = CONCAT31(uStack_34._1_3_,DAT_01ee78e9);
      uStack_104 = 0;
      puStack_18 = auStack_164;
      uStack_8._0_1_ = 6;
      puStack_54 = (undefined *)auStack_184;
      puStack_38 = (undefined *)auStack_184;
      auStack_184[0] = 0;
      puVar2 = auStack_184;
      puVar4 = &uStack_100;
      puVar5 = auStack_164;
      if (param_12 != 0) {
        auStack_184[0] = param_12;
        if ((param_12 & 1) == 0) {
          uStack_18c = ZEXT48(&uStack_17c);
          puStack_190 = &param_14;
          uStack_194 = 0xa5d9c5;
          (**(code **)(param_12 & 0xfffffffe))();
          puVar2 = (uint *)puStack_54;
          puVar4 = (undefined4 *)puStack_1c;
          puVar5 = puStack_18;
        }
        else {
          uStack_17c = param_14;
          uStack_178 = param_15;
          uStack_174 = param_16;
          uStack_170 = param_17;
          uStack_16c = param_18;
          puVar2 = auStack_184;
          puVar4 = &uStack_100;
          puVar5 = auStack_164;
        }
      }
      puStack_18 = puVar5;
      puStack_1c = (undefined *)puVar4;
      puStack_54 = (undefined *)puVar2;
      puStack_38 = (undefined *)auStack_1a4;
      puStack_20 = (undefined *)auStack_1a4;
      uStack_8._0_1_ = 7;
      auStack_1a4[0] = 0;
      puVar2 = auStack_1a4;
      puVar3 = auStack_1a4;
      if (param_5 != 0) {
        auStack_1a4[0] = param_5;
        if ((param_5 & 1) == 0) {
          puStack_1ac = &uStack_19c;
          uStack_1a8 = 0;
          puStack_1b0 = &param_7;
          uStack_1b4 = 0xa5da10;
          (**(code **)(param_5 & 0xfffffffe))();
          puVar2 = (uint *)puStack_38;
          puVar3 = (uint *)puStack_20;
        }
        else {
          uStack_19c = param_7;
          uStack_198 = param_8;
          uStack_194 = param_9;
          puStack_190 = param_10;
          uStack_18c = param_11;
          puVar2 = auStack_1a4;
          puVar3 = auStack_1a4;
        }
      }
      puStack_20 = (undefined *)puVar3;
      puStack_38 = (undefined *)puVar2;
      uStack_1a8 = param_2;
      uStack_8._0_1_ = 8;
      puStack_1ac = (undefined4 *)uStack_34;
      puStack_1b0 = (undefined4 *)param_4;
      uStack_1b4 = param_3;
      iStack_1b8 = iVar1;
      uStack_1bc = param_1;
      FUN_0060e0c0(auStack_1c4,uStack_14);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      FUN_00a57b10(puStack_18,FUN_00a5daf0);
      uStack_16c = CONCAT44(0xa5da52,(undefined4)uStack_16c);
      FUN_00a56370();
      uStack_104 = 0xa5da5d;
      FUN_014ccc70();
      puStack_e0 = (undefined *)0xa5da68;
      FUN_0056db40();
      puStack_e0 = (undefined *)0xa5da70;
      FUN_0056d380();
      puStack_e0 = (undefined *)0xa5da78;
      FUN_005507b0();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_e8 = &param_7;
    puStack_e0 = (undefined *)0x2;
    puStack_ec = (undefined4 *)0xa5da99;
    ppuStack_e4 = (undefined **)puStack_e8;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 10;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_e8 = &param_14;
    puStack_e0 = (undefined *)0x2;
    puStack_ec = (undefined4 *)0xa5dac7;
    ppuStack_e4 = (undefined **)puStack_e8;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20918 ; VA 0x00a5daf0 ; FUN_00a5daf0 */

void FUN_00a5daf0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  TypeDescriptor *in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000044;
  char *pcVar7;
  uint uStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  TypeDescriptor *pTStack_78;
  TypeDescriptor *pTStack_74;
  int **ppiStack_70;
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  TypeDescriptor aTStack_48 [2];
  int iStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e14d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppiStack_70 = &piStack_30;
  pTStack_74 = (TypeDescriptor *)0xa5db21;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00587490();
  iVar4 = *piVar3;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppiStack_70 = (int **)0xa5db3c;
      (**(code **)*piStack_2c)();
      LOCK();
      iVar5 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_70 = (int **)0xa5db4c;
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (iVar4 == 0) goto LAB_00a5df81;
  iStack_38 = 0;
  uStack_34 = 0xf;
  aTStack_48[0].pVFTable._0_1_ = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (in_stack_00000020 == 0) {
    if ((in_stack_0000001c != (TypeDescriptor *)0x0) && (aTStack_48 != in_stack_0000001c))
    goto LAB_00a5dbae;
LAB_00a5df4f:
    pTStack_74 = (TypeDescriptor *)0x0;
    ppiStack_70 = (int **)0xf;
    uStack_84 = uStack_84 & 0xffffff00;
    FUN_005542c0("UserHasBadgeAsync: failed due to empty response",0x2f);
    FUN_005e65e0();
  }
  else {
    ppiStack_70 = (int **)0x0;
    pTStack_74 = &RBX::http_status_error::RTTI_Type_Descriptor;
    pTStack_78 = &std::exception::RTTI_Type_Descriptor;
    uStack_7c = 0;
    iStack_80 = in_stack_00000020;
    uStack_84 = 0xa5db85;
    iVar4 = FUN_0170d75d();
    if ((iVar4 != 0) &&
       (in_stack_0000001c = (TypeDescriptor *)(iVar4 + 0xc), aTStack_48 != in_stack_0000001c)) {
LAB_00a5dbae:
      ppiStack_70 = (int **)in_stack_0000001c[2].pVFTable;
      if ((void *)0xf < in_stack_0000001c[2].spare) {
        in_stack_0000001c = (TypeDescriptor *)in_stack_0000001c->pVFTable;
      }
      pTStack_78 = (TypeDescriptor *)0xa5dbc3;
      pTStack_74 = in_stack_0000001c;
      FUN_005542c0();
    }
    if (iStack_38 == 0) goto LAB_00a5df4f;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    ppiStack_70 = (int **)0x0;
    pTStack_74 = (TypeDescriptor *)&iStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    pTStack_78 = aTStack_48;
    uStack_7c = 0xa5dbee;
    cVar2 = FUN_0098f070();
    if (cVar2 != '\0') {
      ppiStack_70 = (int **)0x7;
      pTStack_74 = (TypeDescriptor *)0x18c1604;
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = 0;
      pTStack_78 = (TypeDescriptor *)0xa5dc3d;
      FUN_005542c0();
      ppiStack_70 = (int **)auStack_60;
      pTStack_74 = (TypeDescriptor *)&iStack_14;
      pTStack_78 = (TypeDescriptor *)0xa5dc4c;
      piVar3 = (int *)FUN_00580040();
      iVar4 = *piVar3;
      ppiStack_70 = (int **)0xa5dc56;
      FUN_005507b0();
      if (iVar4 != 0) {
        iVar4 = *(int *)(iVar4 + 0x20);
        ppiStack_70 = (int **)0xa5dc64;
        iVar5 = FUN_0088cb40();
        if (iVar4 == iVar5) {
          uVar6 = FUN_0055d610();
          FUN_0054ef60(uVar6);
          FUN_005e65e0();
          goto LAB_00a5df14;
        }
      }
      ppiStack_70 = (int **)0x6;
      pTStack_74 = (TypeDescriptor *)0x1928ef0;
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = 0;
      pTStack_78 = (TypeDescriptor *)0xa5dcad;
      FUN_005542c0();
      ppiStack_70 = (int **)auStack_60;
      pTStack_74 = (TypeDescriptor *)&iStack_18;
      pTStack_78 = (TypeDescriptor *)0xa5dcbc;
      piVar3 = (int *)FUN_00580040();
      iVar4 = *piVar3;
      ppiStack_70 = (int **)0xa5dcc6;
      FUN_005507b0();
      if (iVar4 == 0) {
        ppiStack_70 = (int **)0x4;
        pTStack_74 = (TypeDescriptor *)&DAT_018be4a0;
        uStack_50 = 0;
        uStack_4c = 0xf;
        auStack_60[0] = 0;
        pTStack_78 = (TypeDescriptor *)0xa5deb4;
        FUN_005542c0();
        ppiStack_70 = (int **)auStack_60;
        pTStack_74 = (TypeDescriptor *)&iStack_14;
        pTStack_78 = (TypeDescriptor *)0xa5dec3;
        FUN_00580040();
        ppiStack_70 = (int **)0xa5decb;
        FUN_005507b0();
        if (iStack_14 != 0) {
          iVar4 = *(int *)(iStack_14 + 0x20);
          ppiStack_70 = (int **)0xa5dedd;
          iVar5 = FUN_008882f0();
          if (iVar4 == iVar5) {
            ppiStack_70 = (int **)0xa5dee8;
            ppiStack_70 = (int **)FUN_0055d670();
            pTStack_74 = (TypeDescriptor *)0xa5def1;
            FUN_00557fc0();
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            ppiStack_70 = (int **)(uint)(*piStack_30 != piStack_30[1]);
            pTStack_74 = (TypeDescriptor *)0xa5df0c;
            FUN_008927d0();
            ppiStack_70 = (int **)0xa5df14;
            FUN_00550b30();
            goto LAB_00a5df14;
          }
        }
        pcVar7 = "UserHasBadgeAsync: Parsed invalid JSON data: ";
      }
      else {
        iVar4 = *(int *)(iVar4 + 0x20);
        ppiStack_70 = (int **)0xa5dcd8;
        iVar5 = FUN_008882f0();
        if (iVar4 == iVar5) {
          ppiStack_70 = (int **)0xa5dd3b;
          ppiStack_70 = (int **)FUN_0055d670();
          pTStack_74 = (TypeDescriptor *)0xa5dd44;
          FUN_00557fc0();
          uStack_8._0_1_ = 5;
          piVar3 = (int *)*piStack_28;
          if (piVar3 != (int *)piStack_28[1]) {
            do {
              iVar4 = *piVar3;
              ppiStack_70 = (int **)0xa5dd5d;
              iVar5 = FUN_008881d0();
              if (iVar4 == iVar5) {
                iVar4 = *piVar3;
                ppiStack_70 = (int **)0xa5dd6c;
                iVar5 = FUN_008881d0();
                if (iVar4 != iVar5) {
                  ppiStack_70 = (int **)0x18c072c;
                    /* WARNING: Subroutine does not return */
                  pTStack_74 = (TypeDescriptor *)&UNK_00a5e002;
                  FUN_016757c0();
                }
                ppiStack_70 = (int **)(piVar3 + 2);
                if (piVar3[1] == 0) {
                  ppiStack_70 = (int **)0x0;
                }
                pTStack_74 = (TypeDescriptor *)0xa5dd88;
                FUN_00557fc0();
                ppiStack_70 = (int **)0x7;
                pTStack_74 = (TypeDescriptor *)0x18cec98;
                uStack_8 = CONCAT31(uStack_8._1_3_,6);
                uStack_50 = 0;
                uStack_4c = 0xf;
                auStack_60[0] = 0;
                pTStack_78 = (TypeDescriptor *)0xa5ddad;
                FUN_005542c0();
                ppiStack_70 = (int **)auStack_60;
                pTStack_74 = (TypeDescriptor *)&iStack_14;
                pTStack_78 = (TypeDescriptor *)0xa5ddbd;
                FUN_00580040();
                ppiStack_70 = (int **)0xa5ddc5;
                FUN_005507b0();
                if (iStack_14 != 0) {
                  iVar4 = *(int *)(iStack_14 + 0x20);
                  ppiStack_70 = (int **)0xa5ddd4;
                  iVar5 = FUN_0088cb40();
                  if (iVar4 == iVar5) {
                    FUN_00563690(&uStack_84);
                    FUN_005e65e0();
                    ppiStack_70 = (int **)0xa5de80;
                    FUN_00550b30();
                    ppiStack_70 = (int **)0xa5de88;
                    FUN_00550b30();
                    goto LAB_00a5df14;
                  }
                }
                uStack_8._0_1_ = 5;
                ppiStack_70 = (int **)0xa5dde8;
                FUN_00550b30();
              }
              piVar3 = piVar3 + 0x34;
            } while (piVar3 != (int *)piStack_28[1]);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          ppiStack_70 = (int **)0xa5de09;
          FUN_00550b30();
          pTStack_74 = (TypeDescriptor *)0x0;
          ppiStack_70 = (int **)0xf;
          uStack_84 = uStack_84 & 0xffffff00;
          FUN_005542c0("UserHasBadgeAsync: endpoint is having issues, please report this to the forums."
                       ,0x4f);
          FUN_005e65e0();
          ppiStack_70 = (int **)0xa5de3b;
          FUN_00550b30();
          ppiStack_70 = (int **)0xa5de43;
          FUN_005507b0();
          if (param_2 != (int *)0x0) {
            LOCK();
            piVar3 = param_2 + 2;
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              ppiStack_70 = (int **)0xa5de5f;
              (**(code **)(*param_2 + 4))();
            }
          }
          goto LAB_00a5dd13;
        }
        pcVar7 = "UserHasBadgeAsync: Parsed invalid JSON errors: ";
      }
      FUN_00558df0(&uStack_84,pcVar7,aTStack_48);
      FUN_005e65e0();
      ppiStack_70 = (int **)0xa5dd03;
      FUN_00550b30();
      ppiStack_70 = (int **)0xa5dd0b;
      FUN_005507b0();
      ppiStack_70 = (int **)0xa5dd13;
      FUN_0056c200();
LAB_00a5dd13:
      ppiStack_70 = (int **)0xa5dd1b;
      FUN_00550990();
      ppiStack_70 = (int **)0xa5dd23;
      FUN_00550990();
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00558df0(&uStack_84,"UserHasBadgeAsync: Parsed invalid JSON: ",aTStack_48);
    FUN_005e65e0();
LAB_00a5df14:
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppiStack_70 = (int **)0xa5df2a;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_70 = (int **)0xa5df3a;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ppiStack_70 = (int **)0xa5df81;
  FUN_005507b0();
LAB_00a5df81:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar4 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      ppiStack_70 = (int **)0xa5df95;
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    pTStack_78 = (TypeDescriptor *)&stack0x0000002c;
    ppiStack_70 = (int **)0x2;
    uStack_7c = 0xa5dfb6;
    pTStack_74 = pTStack_78;
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  uStack_8 = 9;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    pTStack_78 = (TypeDescriptor *)&stack0x0000004c;
    ppiStack_70 = (int **)0x2;
    uStack_7c = 0xa5dfe4;
    pTStack_74 = pTStack_78;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20919 ; VA 0x00a5e010 ; FUN_00a5e010 */

undefined4 * __thiscall FUN_00a5e010(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  if ((undefined4 *)param_2[2] != (undefined4 *)0x0) {
    (**(code **)param_2[2])(param_2 + 3,param_1 + 3);
    param_1[2] = param_2[2];
    return param_1;
  }
  param_1[2] = 0;
  return param_1;
}



/* FUNCTION 20920 ; VA 0x00a5e070 ; FUN_00a5e070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a5e070(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1500;
  pvStack_10 = ExceptionList;
  if (DAT_01ee7b24 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7d38) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee7d38);
      if (DAT_01ee7d38 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ChangeHistoryService",1,uStack_20,0,0,3,0,0);
        _DAT_01ee7d30 = RBX::Creator<class_RBX::ChangeHistoryService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee7b28,&DAT_01ee7d30);
        FUN_016f3654(FUN_0188a310);
        FUN_016f37bf(&DAT_01ee7d38);
      }
    }
    DAT_01ee7b24 = &DAT_01ee7b28;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee7b24;
}



/* FUNCTION 20921 ; VA 0x00a5e170 ; FUN_00a5e170 */

void FUN_00a5e170(void)

{
  int iVar1;
  
  if (DAT_01ee7d3c == 0) {
    iVar1 = FUN_00a5e070();
    DAT_01ee7d3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20922 ; VA 0x00a5e190 ; FUN_00a5e190 */

int FUN_00a5e190(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1510;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a60fd0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *(undefined4 *)(iVar1 + 0x18) = 0;
  puVar2 = (undefined4 *)param_1[2];
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)*puVar2)(param_1 + 3,iVar1 + 0x1c);
    puVar2 = (undefined4 *)param_1[2];
  }
  *(undefined4 **)(iVar1 + 0x18) = puVar2;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 20923 ; VA 0x00a5e211 ; Catch_All@00a5e211 */

void Catch_All_00a5e211(void)

{
  int unaff_EBP;
  
  FUN_00a610f0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20924 ; VA 0x00a5e230 ; FUN_00a5e230 */

int FUN_00a5e230(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1520;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a60fd0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  uVar2 = FUN_00888530();
  *(undefined4 *)(iVar1 + 0x14) = uVar2;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 20925 ; VA 0x00a5e29e ; Catch_All@00a5e29e */

void Catch_All_00a5e29e(void)

{
  int unaff_EBP;
  
  FUN_00a610f0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20926 ; VA 0x00a5e2c0 ; FUN_00a5e2c0 */

undefined4 * __thiscall
FUN_00a5e2c0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1530;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00a5e190(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00a5e2c0(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00a5e2c0(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 20927 ; VA 0x00a5e354 ; Catch_All@00a5e354 */

void Catch_All_00a5e354(void)

{
  int unaff_EBP;
  
  FUN_00a61060(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20928 ; VA 0x00a5e370 ; FUN_00a5e370 */

void FUN_00a5e370(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  
  piVar2 = param_3;
  iVar6 = *param_1;
  iVar3 = (int)param_3 - (int)param_1 >> 2;
  if (iVar3 < 0x29) {
    iVar3 = *param_2;
    if (*(uint *)(iVar3 + 0x38) < *(uint *)(iVar6 + 0x38)) {
      *param_2 = iVar6;
      *param_1 = iVar3;
      iVar3 = *param_2;
    }
    iVar6 = *param_3;
    if (*(uint *)(iVar6 + 0x38) < *(uint *)(iVar3 + 0x38)) {
      *param_3 = iVar3;
      *param_2 = iVar6;
      if (*(uint *)(iVar6 + 0x38) < *(uint *)(*param_1 + 0x38)) {
        *param_2 = *param_1;
        *param_1 = iVar6;
      }
    }
  }
  else {
    iVar4 = iVar3 + 1 >> 3;
    piVar1 = param_1 + iVar4;
    iVar3 = *piVar1;
    if (*(uint *)(iVar3 + 0x38) < *(uint *)(iVar6 + 0x38)) {
      *piVar1 = iVar6;
      *param_1 = iVar3;
      iVar3 = *piVar1;
    }
    iVar6 = param_1[iVar4 * 2];
    if (*(uint *)(iVar6 + 0x38) < *(uint *)(iVar3 + 0x38)) {
      param_1[iVar4 * 2] = iVar3;
      *piVar1 = iVar6;
      if (*(uint *)(iVar6 + 0x38) < *(uint *)(*param_1 + 0x38)) {
        *piVar1 = *param_1;
        *param_1 = iVar6;
      }
    }
    piVar5 = param_2 + -iVar4;
    iVar6 = *param_2;
    if (*(uint *)(iVar6 + 0x38) < *(uint *)(*piVar5 + 0x38)) {
      *param_2 = *piVar5;
      *piVar5 = iVar6;
      iVar6 = *param_2;
    }
    iVar3 = param_2[iVar4];
    if (*(uint *)(iVar3 + 0x38) < *(uint *)(iVar6 + 0x38)) {
      param_2[iVar4] = iVar6;
      *param_2 = iVar3;
      if (*(uint *)(iVar3 + 0x38) < *(uint *)(*piVar5 + 0x38)) {
        *param_2 = *piVar5;
        *piVar5 = iVar3;
      }
    }
    piVar5 = param_3 + -iVar4;
    piVar7 = param_3 + iVar4 * -2;
    param_3 = (int *)*piVar5;
    if (*(uint *)((int)param_3 + 0x38) < *(uint *)(*piVar7 + 0x38)) {
      *piVar5 = *piVar7;
      *piVar7 = (int)param_3;
      param_3 = (int *)*piVar5;
    }
    iVar6 = *piVar2;
    if (*(uint *)(iVar6 + 0x38) < *(uint *)((int)param_3 + 0x38)) {
      *piVar2 = (int)param_3;
      *piVar5 = iVar6;
      if (*(uint *)(iVar6 + 0x38) < *(uint *)(*piVar7 + 0x38)) {
        *piVar5 = *piVar7;
        *piVar7 = iVar6;
      }
    }
    iVar6 = *param_2;
    if (*(uint *)(iVar6 + 0x38) < *(uint *)(*piVar1 + 0x38)) {
      *param_2 = *piVar1;
      *piVar1 = iVar6;
      iVar6 = *param_2;
    }
    iVar3 = *piVar5;
    if (*(uint *)(iVar3 + 0x38) < *(uint *)(iVar6 + 0x38)) {
      *piVar5 = iVar6;
      *param_2 = iVar3;
      if (*(uint *)(iVar3 + 0x38) < *(uint *)(*piVar1 + 0x38)) {
        *param_2 = *piVar1;
        *piVar1 = iVar3;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 20929 ; VA 0x00a5e500 ; FUN_00a5e500 */

void __thiscall
FUN_00a5e500(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x11f7045 < (uint)param_1[1]) {
    FUN_00a60ff0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00a5e5b2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00a5e5b2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 20930 ; VA 0x00a5e660 ; FUN_00a5e660 */

undefined4 * __thiscall
FUN_00a5e660(undefined4 *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1540;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00a5e500(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00a5e500(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00a5e500(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00a5e500(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a5e500(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      FUN_00551320();
      if ((piStack_18 == (int *)*param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00a5e500(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00a5e500(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00a5e860(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20931 ; VA 0x00a5e84b ; Catch_All@00a5e84b */

void Catch_All_00a5e84b(void)

{
  int unaff_EBP;
  
  FUN_00a60ff0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20932 ; VA 0x00a5e860 ; FUN_00a5e860 */

void __thiscall
FUN_00a5e860(int *param_1,undefined4 *param_2,char param_3,uint *param_4,int param_5)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_5;
  puStack_c = &LAB_017e1550;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 0;
  bVar4 = true;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar3[1];
    do {
      puVar3 = puVar2;
      if (param_3 == '\0') {
        bVar4 = *param_4 < (uint)puVar3[4];
      }
      else {
        bVar4 = *param_4 <= (uint)puVar3[4];
      }
      if (bVar4 == false) {
        puVar2 = (undefined4 *)puVar3[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar3;
      }
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar3;
  if (bVar4) {
    if (puVar3 == *(undefined4 **)*param_1) {
      bVar4 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00a5e8eb;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar2 = _param_3;
  if (*param_4 <= (uint)_param_3[4]) {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(iVar1 + 0x18) != 0) {
      (**(code **)(*(int *)(iVar1 + 0x18) + 8))(iVar1 + 0x1c);
    }
    FUN_01674ea0(iVar1,0xe4);
    *param_2 = puVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00a5e8eb:
  puVar3 = (undefined4 *)FUN_00a5e500(&param_3,bVar4,puVar3,param_4,iVar1);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20933 ; VA 0x00a5e973 ; Catch_All@00a5e973 */

void Catch_All_00a5e973(void)

{
  int unaff_EBP;
  
  FUN_00a60ff0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20934 ; VA 0x00a5e990 ; FUN_00a5e990 */

void FUN_00a5e990(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar6 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  FUN_00a5e370(param_2,piVar6,param_3 + -1,param_4);
  piVar4 = piVar6 + 1;
  for (; param_2 < piVar6; piVar6 = piVar6 + -1) {
    uVar1 = *(uint *)(piVar6[-1] + 0x38);
    uVar2 = *(uint *)(*piVar6 + 0x38);
    if ((uVar1 < uVar2) || (uVar1 >= uVar2 && uVar1 != uVar2)) break;
  }
  piVar7 = piVar4;
  piStack_10 = piVar4;
  piStack_8 = piVar4;
  piStack_c = piVar6;
  piVar9 = piVar6;
  if (piVar4 < param_3) {
    uVar1 = *(uint *)(*piVar6 + 0x38);
    do {
      uVar2 = *(uint *)(*piVar4 + 0x38);
      piVar7 = piVar4;
      piStack_10 = piVar4;
      piStack_8 = piVar4;
      if ((uVar2 < uVar1) || (uVar2 >= uVar1 && uVar2 != uVar1)) break;
      piVar4 = piVar4 + 1;
      piVar7 = piVar4;
      piStack_10 = piVar4;
      piStack_8 = piVar4;
    } while (piVar4 < param_3);
  }
joined_r0x00a5ea12:
  do {
    piVar5 = piVar6;
    if (param_3 <= piVar4) {
joined_r0x00a5ea4b:
      while (piVar8 = piVar7, param_2 < piVar6) {
        piVar5 = piVar5 + -1;
        uVar1 = *(uint *)(*piVar5 + 0x38);
        piVar4 = piStack_10;
        if (*(uint *)(*piVar9 + 0x38) <= uVar1) {
          piVar8 = piStack_8;
          piStack_c = piVar6;
          if (*(uint *)(*piVar9 + 0x38) < uVar1) break;
          piVar9 = piVar9 + -1;
          if (piVar9 != piVar5) {
            iVar3 = *piVar9;
            *piVar9 = *piVar5;
            *piVar5 = iVar3;
          }
        }
        piStack_c = piVar6 + -1;
        piVar7 = piStack_8;
        piVar6 = piStack_c;
      }
      if (piVar6 == param_2) {
        if (piVar4 == param_3) {
          *param_1 = piVar9;
          param_1[1] = piVar8;
          return;
        }
        if (piVar8 != piVar4) {
          iVar3 = *piVar9;
          *piVar9 = *piVar8;
          *piVar8 = iVar3;
        }
        iVar3 = *piVar9;
        *piVar9 = *piVar4;
        *piVar4 = iVar3;
        piVar4 = piVar4 + 1;
        piVar7 = piVar8 + 1;
        piStack_10 = piVar4;
        piStack_8 = piVar8 + 1;
        piVar9 = piVar9 + 1;
      }
      else {
        piVar6 = piVar6 + -1;
        piStack_c = piVar6;
        if (piVar4 == param_3) {
          piVar9 = piVar9 + -1;
          if (piVar6 != piVar9) {
            iVar3 = *piVar6;
            *piVar6 = *piVar9;
            *piVar9 = iVar3;
          }
          iVar3 = *piVar9;
          piVar7 = piVar8 + -1;
          *piVar9 = *piVar7;
          *piVar7 = iVar3;
          piStack_8 = piVar7;
        }
        else {
          iVar3 = *piVar4;
          *piVar4 = *piVar6;
          piVar4 = piVar4 + 1;
          *piVar6 = iVar3;
          piVar7 = piVar8;
          piStack_10 = piVar4;
        }
      }
      goto joined_r0x00a5ea12;
    }
    piVar6 = piStack_c;
    if (*(uint *)(*piVar4 + 0x38) <= *(uint *)(*piVar9 + 0x38)) {
      piVar5 = piStack_c;
      piStack_8 = piVar7;
      piStack_10 = piVar4;
      if (*(uint *)(*piVar4 + 0x38) < *(uint *)(*piVar9 + 0x38)) goto joined_r0x00a5ea4b;
      if (piVar7 != piVar4) {
        iVar3 = *piVar7;
        *piVar7 = *piVar4;
        *piVar4 = iVar3;
      }
      piVar7 = piVar7 + 1;
    }
    piVar4 = piVar4 + 1;
    piStack_10 = piVar4;
    piStack_8 = piVar7;
  } while( true );
}



/* FUNCTION 20935 ; VA 0x00a5eb10 ; FUN_00a5eb10 */

void FUN_00a5eb10(int param_1,int param_2,uint param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar1 = param_2;
  iVar2 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar2 = (2 - (uint)(*(uint *)(*(int *)(param_1 + 8 + iVar1 * 8) + 0x38) <
                         *(uint *)(*(int *)(param_1 + 4 + iVar1 * 8) + 0x38))) + iVar1 * 2;
      *(undefined4 *)(param_1 + iVar1 * 4) = *(undefined4 *)(param_1 + iVar2 * 4);
      iVar1 = iVar2;
    } while (iVar2 < iVar3);
  }
  if ((iVar2 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar2 * 4) = *(undefined4 *)(param_1 + -4 + param_3 * 4);
    iVar2 = param_3 - 1;
  }
  while (param_2 < iVar2) {
    iVar3 = iVar2 + -1 >> 1;
    iVar1 = *(int *)(param_1 + iVar3 * 4);
    if (*(uint *)(*param_4 + 0x38) <= *(uint *)(iVar1 + 0x38)) break;
    *(int *)(param_1 + iVar2 * 4) = iVar1;
    iVar2 = iVar3;
  }
  *(int *)(param_1 + iVar2 * 4) = *param_4;
  return;
}



/* FUNCTION 20936 ; VA 0x00a5ebb0 ; FUN_00a5ebb0 */

int __thiscall FUN_00a5ebb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1560;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ChangeHistoryStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20937 ; VA 0x00a5ec82 ; Catch_All@00a5ec82 */

void Catch_All_00a5ec82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20938 ; VA 0x00a5eca0 ; FUN_00a5eca0 */

void FUN_00a5eca0(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int *piStack_14;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  iVar1 = (int)param_2 - (int)param_1;
  piVar5 = param_2;
  iVar6 = param_3;
  do {
    iVar1 = iVar1 >> 2;
    if (iVar1 < 0x21) {
LAB_00a5ed28:
      if (((1 < iVar1) && (param_1 != piVar5)) && (piStack_c = param_1 + 1, piStack_c != piVar5)) {
        piStack_8 = (int *)0x4;
        do {
          iVar1 = *piStack_c;
          piStack_10 = *(int **)(iVar1 + 0x38);
          if (piStack_10 < *(uint *)(*param_1 + 0x38)) {
            FUN_0170cc70(param_1 + 1,param_1,piStack_8);
            *param_1 = iVar1;
          }
          else {
            piVar4 = (int *)((int)piStack_8 + -4 + (int)param_1);
            iVar6 = *piVar4;
            piVar3 = piStack_c;
            piVar7 = piStack_c;
            if (piStack_10 < *(uint *)(iVar6 + 0x38)) {
              do {
                piVar7 = piVar4;
                *piVar3 = iVar6;
                iVar6 = piVar7[-1];
                piVar4 = piVar7 + -1;
                piVar5 = param_2;
                piVar3 = piVar7;
              } while (*(uint *)(iVar1 + 0x38) < *(uint *)(iVar6 + 0x38));
            }
            *piVar7 = iVar1;
          }
          piStack_c = piStack_c + 1;
          piStack_8 = (int *)((int)piStack_8 + 4);
        } while (piStack_c != piVar5);
      }
      return;
    }
    if (iVar6 < 1) {
      if (0x20 < iVar1) {
        iVar1 = (int)piVar5 - (int)param_1;
        uVar2 = iVar1 >> 2;
        piVar5 = (int *)(iVar1 >> 3);
        if (0 < (int)piVar5) {
          piStack_8 = (int *)((int)(uVar2 - 1) >> 1);
          do {
            piStack_c = (int *)param_1[(int)piVar5 + -1];
            piVar5 = (int *)((int)piVar5 + -1);
            piVar4 = piVar5;
            while ((int)piVar4 < (int)piStack_8) {
              piVar3 = (int *)((2 - (uint)(*(uint *)(param_1[(int)piVar4 * 2 + 2] + 0x38) <
                                          *(uint *)(param_1[(int)piVar4 * 2 + 1] + 0x38))) +
                              (int)piVar4 * 2);
              param_1[(int)piVar4] = param_1[(int)piVar3];
              piVar4 = piVar3;
            }
            if ((piVar4 == piStack_8) && ((uVar2 & 1) == 0)) {
              param_1[(int)piVar4] = param_1[uVar2 - 1];
              piVar4 = (int *)(uVar2 - 1);
            }
            while (((int)piVar5 < (int)piVar4 &&
                   (piVar3 = (int *)((int)piVar4 + -1 >> 1),
                   *(uint *)(param_1[(int)piVar3] + 0x38) < *(uint *)((int)piStack_c + 0x38)))) {
              param_1[(int)piVar4] = param_1[(int)piVar3];
              piVar4 = piVar3;
            }
            param_1[(int)piVar4] = (int)piStack_c;
            piStack_10 = piVar5;
          } while (0 < (int)piVar5);
        }
        if ((int)uVar2 < 2) {
          return;
        }
        do {
          if (1 < (int)uVar2) {
            param_2 = *(int **)((int)param_1 + iVar1 + -4);
            *(int *)((int)param_1 + iVar1 + -4) = *param_1;
            FUN_00a5eb10(param_1,0,iVar1 + -4 >> 2,&param_2,param_4);
          }
          iVar1 = iVar1 + -4;
          uVar2 = iVar1 >> 2;
        } while (1 < (int)uVar2);
        return;
      }
      goto LAB_00a5ed28;
    }
    FUN_00a5e990(&piStack_14,param_1,piVar5,param_4);
    iVar6 = (iVar6 >> 1) + (iVar6 >> 2);
    if ((int)((int)piStack_14 - (int)param_1 & 0xfffffffcU) <
        (int)((int)piVar5 - (int)piStack_10 & 0xfffffffcU)) {
      FUN_00a5eca0(param_1,piStack_14,iVar6,param_4);
      param_1 = piStack_10;
    }
    else {
      FUN_00a5eca0(piStack_10,piVar5,iVar6,param_4);
      param_2 = piStack_14;
      piVar5 = piStack_14;
    }
    iVar1 = (int)piVar5 - (int)param_1;
  } while( true );
}



/* FUNCTION 20939 ; VA 0x00a5eee0 ; FUN_00a5eee0 */

undefined4 * __thiscall FUN_00a5eee0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00a62ca0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20940 ; VA 0x00a5efa0 ; FUN_00a5efa0 */

undefined4 * FUN_00a5efa0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e15b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009fb200();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x78);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar4 = FUN_009fb200();
    puVar3[3] = uVar4;
    *(undefined8 *)(puVar3 + 0x16) = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0xf;
    *(undefined *)(puVar3 + 0x18) = 0;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::ChangeHistoryStatsItem::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("ChangeHistory",0xd);
    uStack_8._0_1_ = 5;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 4;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a5ebb0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 9;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20941 ; VA 0x00a5f110 ; FUN_00a5f110 */

void FUN_00a5f110(int param_1)

{
  if (param_1 != 0) {
    FUN_00a60f10(1);
  }
  return;
}



/* FUNCTION 20942 ; VA 0x00a5f130 ; FUN_00a5f130 */

void FUN_00a5f130(undefined4 param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_2 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_2 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_2 + 0x1c) = 0;
  *(undefined4 *)(param_2 + 0x20) = 0xf;
  *(undefined *)(param_2 + 0xc) = 0;
  return;
}



/* FUNCTION 20943 ; VA 0x00a5f190 ; FUN_00a5f190 */

undefined4 * __thiscall
FUN_00a5f190(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined4 uStack_c;
  int *piStack_8;
  
  puVar3 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) == puVar3) {
    uVar8 = FUN_00603a30(param_3,param_4);
    *param_2 = uVar8;
    return param_2;
  }
  if (param_3 != puVar3) {
    uStack_c = *param_4;
    *param_4 = 0;
    piStack_8 = (int *)param_4[1];
    param_4[1] = 0;
    puVar1 = puVar3 + -2;
    *puVar3 = 0;
    puVar3[1] = 0;
    *puVar3 = *puVar1;
    puVar3[1] = puVar3[-1];
    *puVar1 = 0;
    puVar3[-1] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    piVar7 = puVar3 + 1;
    while (puVar1 != param_3) {
      iVar4 = puVar1[-2];
      puVar3 = puVar1 + -2;
      iVar5 = puVar1[-1];
      piVar2 = piVar7 + -2;
      *puVar3 = 0;
      puVar1[-1] = 0;
      piVar7[-3] = iVar4;
      piVar6 = (int *)*piVar2;
      *piVar2 = iVar5;
      puVar1 = puVar3;
      piVar7 = piVar2;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar4 = piVar6[1] + -1;
        piVar6[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar4 = piVar6[2] + -1;
          piVar6[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    FUN_005587e0(&uStack_c);
    piVar7 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    *param_2 = param_3;
    return param_2;
  }
  *puVar3 = 0;
  puVar3[1] = 0;
  *puVar3 = *param_4;
  puVar3[1] = param_4[1];
  *param_4 = 0;
  param_4[1] = 0;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
  *param_2 = param_3;
  return param_2;
}



/* FUNCTION 20944 ; VA 0x00a5f2f0 ; FUN_00a5f2f0 */

undefined4 * FUN_00a5f2f0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e15fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01944058;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_optional_access::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20945 ; VA 0x00a5f3d0 ; FUN_00a5f3d0 */

undefined4 * FUN_00a5f3d0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::vftable
  ;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::
               vftable;
  return param_1;
}



/* FUNCTION 20946 ; VA 0x00a5f430 ; FUN_00a5f430 */

int * FUN_00a5f430(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00af0010(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 20947 ; VA 0x00a5f520 ; FUN_00a5f520 */

void FUN_00a5f520(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int *piStack_8;
  
  piStack_8 = (int *)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
  if (param_1 != (int *)0x0) {
    do {
      iVar8 = *(int *)(param_3 + 4);
      if ((iVar8 == 0) && (puVar4 = *(undefined4 **)(param_3 + 0xc), puVar4 != (undefined4 *)0x0)) {
        *(undefined4 **)(param_3 + 4) = puVar4;
        *(undefined4 *)(param_3 + 0xc) = *puVar4;
        *puVar4 = 0;
        iVar8 = *(int *)(param_3 + 4);
        *(undefined2 *)(param_3 + 8) = 0x101;
      }
      if (iVar8 == 0) {
        *(undefined2 *)(param_3 + 8) = 0;
        puVar4 = (undefined4 *)FUN_01674e20(0x2c);
        *(undefined4 **)(param_3 + 4) = puVar4;
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4[2] = 0;
        puVar4[3] = 0;
        puVar4[4] = 0;
        puVar4[5] = 0;
        puVar4[6] = 0;
        puVar4[7] = 0;
        puVar4[8] = 0;
        puVar4[9] = 0;
        puVar4[10] = 0;
        *(undefined *)(param_3 + 8) = 1;
      }
      else if (*(char *)(param_3 + 9) != '\0') {
        uVar7 = *(uint *)(iVar8 + 0x28);
        if (0xf < uVar7) {
          iVar2 = *(int *)(iVar8 + 0x14);
          uVar6 = uVar7 + 1;
          iVar5 = iVar2;
          if (0xfff < uVar6) {
            iVar5 = *(int *)(iVar2 + -4);
            uVar6 = uVar7 + 0x24;
            if (0x1f < (iVar2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar5,uVar6);
        }
        *(undefined4 *)(iVar8 + 0x24) = 0;
        *(undefined4 *)(iVar8 + 0x28) = 0xf;
        *(undefined *)(iVar8 + 0x14) = 0;
        *(undefined *)(param_3 + 9) = 0;
      }
      iVar8 = *(int *)(param_3 + 4);
      *(undefined8 *)(iVar8 + 8) = *(undefined8 *)(param_1 + 2);
      *(int *)(iVar8 + 0x10) = param_1[4];
      FUN_0054ef60(param_1 + 5);
      iVar8 = *(int *)(param_3 + 4);
      *(undefined *)(param_3 + 9) = 1;
      *(undefined4 *)(param_3 + 4) = 0;
      *(int *)(iVar8 + 4) = param_1[1];
      *piStack_8 = iVar8;
      *(int *)(param_2 + 8) = *(int *)(param_2 + 8) + 1;
      param_1 = (int *)*param_1;
      piVar3 = (int *)*piStack_8;
      uVar7 = (uint)piVar3[1] % *(uint *)(param_2 + 4);
      piVar1 = (int *)(*(int *)(param_2 + 0x14) + uVar7 * 4);
      if (*(int *)(*(int *)(param_2 + 0x14) + uVar7 * 4) == 0) {
        *piVar1 = (int)piStack_8;
        piStack_8 = piVar3;
      }
      else {
        *piStack_8 = *piVar3;
        *piVar3 = *(int *)*piVar1;
        *(int **)*piVar1 = piVar3;
      }
    } while (param_1 != (int *)0x0);
  }
  return;
}



/* FUNCTION 20948 ; VA 0x00a5f680 ; FUN_00a5f680 */

void FUN_00a5f680(undefined4 *param_1,int *param_2,int *param_3,code *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iStack_e4;
  int iStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e161b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    do {
      uStack_8 = 0xffffffff;
      iStack_e4 = param_2[4];
      iStack_e0 = param_2[5];
      puVar4 = (undefined4 *)param_2[6];
      puStack_dc = (undefined4 *)0x0;
      if (puVar4 != (undefined4 *)0x0) {
        (*(code *)*puVar4)(param_2 + 7,auStack_d8);
        puVar4 = (undefined4 *)param_2[6];
      }
      uStack_8 = 0;
      puStack_dc = puVar4;
      (*param_4)(&iStack_e4);
      uStack_8 = 1;
      if (puStack_dc != (undefined4 *)0x0) {
        (*(code *)puStack_dc[2])(auStack_d8);
      }
      piVar2 = (int *)param_2[2];
      if (*(char *)((int)piVar2 + 0xd) == '\0') {
        cVar1 = *(char *)(*piVar2 + 0xd);
        param_2 = piVar2;
        piVar2 = (int *)*piVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*piVar2 + 0xd);
          param_2 = piVar2;
          piVar2 = (int *)*piVar2;
        }
      }
      else {
        cVar1 = *(char *)(param_2[1] + 0xd);
        piVar3 = (int *)param_2[1];
        piVar2 = param_2;
        while ((param_2 = piVar3, cVar1 == '\0' && (piVar2 == (int *)param_2[2]))) {
          cVar1 = *(char *)(param_2[1] + 0xd);
          piVar3 = (int *)param_2[1];
          piVar2 = param_2;
        }
      }
    } while (param_2 != param_3);
  }
  *param_1 = param_4;
  param_1[1] = param_5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20949 ; VA 0x00a5f7a0 ; FUN_00a5f7a0 */

void FUN_00a5f7a0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a5f3d0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00a5f2f0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c848bc);
}



/* FUNCTION 20950 ; VA 0x00a5f7f0 ; FUN_00a5f7f0 */

void * __thiscall FUN_00a5f7f0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    uStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
      uVar4 = *(undefined4 *)(param_2 + 8);
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00a60ca0(uVar4,*puVar7,puVar7[1]);
      pvVar5 = (void *)FUN_00a5f7f0(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 20951 ; VA 0x00a5f8d0 ; FUN_00a5f8d0 */

undefined4 * __thiscall
FUN_00a5f8d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1671;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00a5e070();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ChangeHistoryService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChangeHistoryService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ChangeHistoryService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::ChangeHistoryService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20952 ; VA 0x00a5fa10 ; FUN_00a5fa10 */

undefined4 * __thiscall FUN_00a5fa10(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e16a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01944058;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_optional_access::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20953 ; VA 0x00a5faf0 ; FUN_00a5faf0 */

undefined4 * __thiscall FUN_00a5faf0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e16b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_optional_access::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::vftable
  ;
  param_1[3] = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20954 ; VA 0x00a5fb90 ; FUN_00a5fb90 */

undefined4 * __fastcall FUN_00a5fb90(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e16f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650(PTR_s_ChangeHistoryService_01943c18);
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ChangeHistoryService,class_RBX::ServiceInstance>::
             vftable;
  uVar2 = FUN_00a5e070();
  param_1[3] = uVar2;
  param_1[0x16] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::ChangeHistoryService::vftable;
  param_1[0x16] = RBX::ChangeHistoryService::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  puVar1 = param_1 + 0x1b;
  param_1[0x1a] = 0;
  uStack_8 = 3;
  *puVar1 = 0;
  param_1[0x1c] = 0;
  uVar2 = FUN_00575b50(0,0);
  *puVar1 = uVar2;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  *(undefined2 *)(param_1 + 0x20) = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x1d] = *puVar1;
  param_1[0x1e] = *puVar1;
  param_1[0x1f] = *puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20955 ; VA 0x00a5fcf0 ; FUN_00a5fcf0 */

undefined * __thiscall FUN_00a5fcf0(undefined *param_1,undefined4 param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  undefined4 uStack_8;
  
  *param_1 = 0;
  uStack_8 = 0xb;
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_8)
  ;
  ppuVar2 = ppuVar1 + -1;
  if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar1;
  }
  *(undefined **)(param_1 + 4) = *ppuVar2;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = param_2;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  param_1[0x28] = 0;
  return param_1;
}



/* FUNCTION 20956 ; VA 0x00a5fd80 ; FUN_00a5fd80 */

undefined4 * __thiscall FUN_00a5fd80(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::bad_optional_access::vftable;
  return param_1;
}



/* FUNCTION 20957 ; VA 0x00a5fdc0 ; FUN_00a5fdc0 */

undefined4 * __fastcall FUN_00a5fdc0(undefined4 *param_1)

{
  char *pcStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  pcStack_c = "Attempted to access the value of an uninitialized optional object.";
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&pcStack_c,param_1 + 1);
  *param_1 = boost::bad_optional_access::vftable;
  return param_1;
}



/* FUNCTION 20958 ; VA 0x00a5fe10 ; FUN_00a5fe10 */

void __fastcall FUN_00a5fe10(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ChangeHistoryService>::vftable;
  uVar1 = FUN_00a5e070(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20959 ; VA 0x00a5fe50 ; thunk_FUN_00a5ff30 */

void __fastcall thunk_FUN_00a5ff30(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_00a5f130(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x2c);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[10];
    if (0xf < uVar2) {
      iVar4 = puVar1[5];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[9] = 0;
    puVar1[10] = 0xf;
    *(undefined *)(puVar1 + 5) = 0;
    FUN_01674ea0(puVar1,0x2c);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 20960 ; VA 0x00a5fe60 ; FUN_00a5fe60 */

void __fastcall FUN_00a5fe60(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::vftable
  ;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20961 ; VA 0x00a5fed0 ; FUN_00a5fed0 */

void __fastcall FUN_00a5fed0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00a5f130(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 20962 ; VA 0x00a5ff00 ; FUN_00a5ff00 */

void __fastcall FUN_00a5ff00(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a60220();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x58);
  }
  return;
}



/* FUNCTION 20963 ; VA 0x00a5ff30 ; FUN_00a5ff30 */

void __fastcall FUN_00a5ff30(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  puVar1 = (undefined4 *)param_1[3];
  do {
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = param_1[1];
      if (iVar4 != 0) {
        if (*(char *)((int)param_1 + 9) != '\0') {
          FUN_00a5f130(*param_1,iVar4 + 8);
          iVar4 = param_1[1];
        }
        FUN_01674ea0(iVar4,0x2c);
      }
      return;
    }
    param_1[3] = *puVar1;
    uVar2 = puVar1[10];
    if (0xf < uVar2) {
      iVar4 = puVar1[5];
      uVar5 = uVar2 + 1;
      iVar3 = iVar4;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(iVar4 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    puVar1[9] = 0;
    puVar1[10] = 0xf;
    *(undefined *)(puVar1 + 5) = 0;
    FUN_01674ea0(puVar1,0x2c);
    puVar1 = (undefined4 *)param_1[3];
  } while( true );
}



/* FUNCTION 20964 ; VA 0x00a5ffd0 ; FUN_00a5ffd0 */

void __fastcall FUN_00a5ffd0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00a62bb0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 20965 ; VA 0x00a60050 ; FUN_00a60050 */

void __fastcall FUN_00a60050(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ChangeHistoryService::vftable;
  param_1[0x16] = RBX::ChangeHistoryService::vftable;
  if (param_1[0x1a] != 0) {
    FUN_00a60f10(1);
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x29];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x28];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x27];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x26];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x23];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0056c7e0();
  piVar1 = (int *)param_1[0x19];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[0x16] = RBX::Voxel2::GridListener::vftable;
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20966 ; VA 0x00a60220 ; FUN_00a60220 */

int __fastcall FUN_00a60220(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x44) != '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x44) = 0;
  }
  if (*(char *)(param_1 + 0x3c) != '\0') {
    *(undefined *)(param_1 + 0x3c) = 0;
  }
  FUN_00a62ae0();
  iVar4 = *(int *)(param_1 + 0x18);
  uStack_8 = 0;
  FUN_00a61060(*(undefined4 *)(iVar4 + 4));
  *(int *)(*(int *)(param_1 + 0x18) + 4) = iVar4;
  **(int **)(param_1 + 0x18) = iVar4;
  *(int *)(*(int *)(param_1 + 0x18) + 8) = iVar4;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  iVar4 = FUN_01674ea0(*(undefined4 *)(param_1 + 0x18),0xe4);
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20967 ; VA 0x00a60300 ; FUN_00a60300 */

undefined4 * __thiscall FUN_00a60300(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017939a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[1] = uVar2;
  piVar4 = (int *)param_1[2];
  param_1[2] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  param_1[3] = param_2[3];
  uVar2 = param_2[4];
  uVar3 = param_2[5];
  param_2[4] = 0;
  param_2[5] = 0;
  param_1[4] = uVar2;
  piVar4 = (int *)param_1[5];
  param_1[5] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (param_1 + 6 != param_2 + 6) {
    iVar5 = param_1[6];
    uStack_8 = 1;
    FUN_00a61060(*(undefined4 *)(iVar5 + 4));
    *(int *)(param_1[6] + 4) = iVar5;
    *(int *)param_1[6] = iVar5;
    *(int *)(param_1[6] + 8) = iVar5;
    param_1[7] = 0;
    uVar2 = param_1[6];
    param_1[6] = param_2[6];
    param_2[6] = uVar2;
    uVar2 = param_1[7];
    param_1[7] = param_2[7];
    param_2[7] = uVar2;
  }
  if (param_1 + 8 != param_2 + 8) {
    FUN_00a62ae0();
    param_1[0xb] = param_2[0xb];
    param_1[0xc] = param_2[0xc];
    param_1[0xd] = param_2[0xd];
    param_1[9] = param_2[9];
    param_1[10] = param_2[10];
    param_2[0xd] = 0;
    param_2[10] = 0;
    param_2[0xc] = 0;
  }
  param_1[0xe] = param_2[0xe];
  if (*(char *)(param_1 + 0xf) == '\0') {
    if (*(char *)(param_2 + 0xf) != '\0') {
      param_1[0x10] = param_2[0x10];
      *(undefined *)(param_1 + 0xf) = 1;
    }
  }
  else if (*(char *)(param_2 + 0xf) == '\0') {
    *(undefined *)(param_1 + 0xf) = 0;
  }
  else {
    param_1[0x10] = param_2[0x10];
  }
  if (*(char *)(param_1 + 0x11) == '\0') {
    if (*(char *)(param_2 + 0x11) != '\0') {
      param_1[0x12] = param_2[0x12];
      *(undefined *)(param_1 + 0x11) = 1;
    }
  }
  else if (*(char *)(param_2 + 0x11) == '\0') {
    *(undefined *)(param_1 + 0x11) = 0;
  }
  else {
    param_1[0x12] = param_2[0x12];
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20968 ; VA 0x00a604c0 ; FUN_00a604c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a604c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  float fVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  undefined4 *puVar12;
  float10 fVar13;
  uint auStack_20 [2];
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1708;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  iVar9 = param_2[2];
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = param_2[2];
  }
  param_1[1] = param_2[1];
  piVar8 = (int *)param_1[2];
  param_1[2] = iVar9;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar9 = piVar8[1] + -1;
    piVar8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar9 = piVar8[2] + -1;
      piVar8[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  param_1[3] = param_2[3];
  iVar9 = param_2[5];
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = param_2[5];
  }
  param_1[4] = param_2[4];
  piVar8 = (int *)param_1[5];
  param_1[5] = iVar9;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar9 = piVar8[1] + -1;
    piVar8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar11 = piVar8 + 2;
      iVar9 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (param_1 + 6 != param_2 + 6) {
    uVar7 = param_1[6];
    uStack_8 = 0;
    FUN_00a61060();
    uStack_8 = 0xffffffff;
    *(undefined4 *)(param_1[6] + 4) = uVar7;
    *(undefined4 *)param_1[6] = uVar7;
    *(undefined4 *)(param_1[6] + 8) = uVar7;
    param_1[7] = 0;
    uVar7 = FUN_00a5e2c0(*(undefined4 *)(param_2[6] + 4),param_1[6],param_2);
    *(undefined4 *)(param_1[6] + 4) = uVar7;
    param_1[7] = param_2[7];
    piVar8 = (int *)param_1[6];
    piVar11 = (int *)piVar8[1];
    if (*(char *)((int)piVar11 + 0xd) == '\0') {
      piVar6 = (int *)*piVar11;
      if (*(char *)(*piVar11 + 0xd) == '\0') {
        do {
          piVar11 = piVar6;
          piVar6 = (int *)*piVar11;
        } while (*(char *)(*piVar11 + 0xd) == '\0');
        piVar8 = (int *)param_1[6];
      }
      *piVar8 = (int)piVar11;
      iVar9 = *(int *)(param_1[6] + 4);
      iVar4 = *(int *)(iVar9 + 8);
      cVar3 = *(char *)(iVar4 + 0xd);
      while (cVar3 == '\0') {
        cVar3 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
        iVar9 = iVar4;
        iVar4 = *(int *)(iVar4 + 8);
      }
      *(int *)(param_1[6] + 8) = iVar9;
    }
    else {
      *piVar8 = (int)piVar8;
      *(undefined4 *)(param_1[6] + 8) = param_1[6];
    }
  }
  if (param_1 + 8 != param_2 + 8) {
    fVar2 = (float)param_2[0xb];
    puVar12 = (undefined4 *)param_1[0xd];
    param_1[0xb] = fVar2;
    if (puVar12 == (undefined4 *)0x0) {
      uVar10 = 0;
    }
    else {
      dStack_18 = ((double)(int)param_1[9] + (double)(&DAT_018c0d90)[-((int)param_1[9] >> 0x1f)]) *
                  (double)fVar2;
      fVar13 = (float10)FUN_01725160(dStack_18);
      dStack_18 = (double)fVar13;
      if (dStack_18 < _DAT_018c4e98) {
        uVar10 = FUN_016f3eb1();
      }
      else {
        uVar10 = 0xffffffff;
      }
    }
    param_1[0xc] = uVar10;
    if ((param_1[10] != 0) || (param_2[10] != 0)) {
      if ((uint)param_2[10] < uVar10) {
        puVar1 = puVar12 + param_1[9];
        for (; puVar12 != puVar1; puVar12 = puVar12 + 1) {
          *puVar12 = 0;
        }
      }
      else {
        FUN_005c9310();
        FUN_005d2b00();
      }
      auStack_20[1] = 0;
      uVar7 = SUB84(dStack_18,0);
      dStack_18 = (double)((ulonglong)dStack_18 & 0xffff0000);
      auStack_20[0] = -(uint)(param_1 != (undefined4 *)0xffffffdd) & (uint)(param_1 + 9);
      if (param_1[10] != 0) {
        uVar5 = *(undefined4 *)(param_1[0xd] + param_1[9] * 4);
        *(undefined4 *)(param_1[0xd] + param_1[9] * 4) = 0;
        dStack_18 = (double)(CONCAT44(uVar5,uVar7) & 0xffffffffffff0000);
        param_1[10] = 0;
      }
      uStack_8 = 1;
      if (param_2[10] == 0) {
        uVar7 = 0;
      }
      else {
        uVar7 = *(undefined4 *)(param_2[0xd] + param_2[9] * 4);
      }
      FUN_00a5f520(uVar7,param_1 + 8,auStack_20);
      FUN_00a5ff30();
    }
  }
  param_1[0xe] = param_2[0xe];
  if (*(char *)(param_1 + 0xf) == '\0') {
    if (*(char *)(param_2 + 0xf) != '\0') {
      param_1[0x10] = param_2[0x10];
      *(undefined *)(param_1 + 0xf) = 1;
    }
  }
  else if (*(char *)(param_2 + 0xf) == '\0') {
    *(undefined *)(param_1 + 0xf) = 0;
  }
  else {
    param_1[0x10] = param_2[0x10];
  }
  if (*(char *)(param_1 + 0x11) == '\0') {
    if (*(char *)(param_2 + 0x11) != '\0') {
      param_1[0x12] = param_2[0x12];
      *(undefined *)(param_1 + 0x11) = 1;
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (*(char *)(param_2 + 0x11) == '\0') {
    *(undefined *)(param_1 + 0x11) = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[0x12] = param_2[0x12];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20969 ; VA 0x00a60800 ; FUN_00a60800 */

uint * __thiscall FUN_00a60800(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint *puStack_8;
  
  puVar4 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar4[1];
    do {
      if ((uint)puVar1[4] < *param_2) {
        puVar2 = (undefined4 *)puVar1[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    if ((puVar4 != (undefined4 *)*param_1) && ((uint)puVar4[4] <= *param_2)) {
      return puVar4 + 5;
    }
  }
  puStack_8 = param_2;
  iVar3 = FUN_00a5e230(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_00a5e660(&param_2,puVar4,iVar3 + 0x10,iVar3);
  return param_2 + 5;
}



/* FUNCTION 20970 ; VA 0x00a60880 ; FUN_00a60880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall FUN_00a60880(byte *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1728;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_00a6ce70(param_2);
  FUN_006e16e0(&param_2,uVar6,puVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (undefined8 *)0x0) {
    uVar1 = *puVar5;
    uVar2 = *(undefined4 *)(puVar5 + 1);
    uStack_8 = 0;
    FUN_00a627a0();
    uRam00000024 = 0;
    uRam00000028 = 0xf;
    DAT_00000014 = 0;
    uVar3 = *(uint *)(param_1 + 8);
    uVar7 = uVar3 + 1;
    _DAT_00000008 = uVar1;
    _DAT_00000010 = uVar2;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005c9310(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      param_2 = (undefined8 *)0x1;
      uVar9 = uVar3 >> 1;
      if ((uVar3 >> 1) + uVar3 <= uVar7) {
        uVar9 = 1;
      }
      iVar8 = FUN_005c9310(uVar9 + uVar3);
      if (iVar8 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar8);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar4 = (undefined4 *)*puVar11;
        while (puVar4 != (undefined4 *)0x0) {
          piVar10 = (int *)(*(int *)(param_1 + 0x14) +
                           ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar10 = (int)puVar11;
            puVar11 = puVar4;
          }
          else {
            *puVar11 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar10;
            *(undefined4 **)*piVar10 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar11;
        }
      }
    }
    uVar7 = uVar6 % *(uint *)(param_1 + 4);
    piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    _DAT_00000004 = uVar6;
    if (piVar10 == (int *)0x0) {
      piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar10 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar11 = piVar10;
      _DAT_00000000 = *piVar10;
    }
    else {
      _DAT_00000000 = *piVar10;
      piVar10 = (int *)*puVar11;
    }
    *piVar10 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (undefined8 *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 1;
}



/* FUNCTION 20971 ; VA 0x00a60a40 ; FUN_00a60a40 */

uint * __thiscall FUN_00a60a40(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  undefined **ppuVar6;
  uint uVar7;
  undefined **ppuVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  undefined4 *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e175e;
  pvStack_10 = ExceptionList;
  uVar7 = *param_2;
  uVar11 = (uVar7 >> 3) + uVar7;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar11,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    iStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x58);
    puVar1 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    FUN_0170d1f0(puVar1,0,0x50);
    *puVar1 = uVar7;
    param_2 = (uint *)(piVar4 + 3);
    piVar4[4] = 0;
    piVar4[5] = 0;
    piVar4[6] = 0;
    piVar4[7] = 0;
    piVar4[8] = 0;
    iStack_8._0_1_ = 2;
    piVar4[9] = 0;
    piVar4[10] = 0;
    iVar5 = FUN_00a60fb0();
    piVar4[9] = iVar5;
    *(undefined *)(piVar4 + 0xb) = 0;
    param_2 = (uint *)0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    ppuVar8 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar8 = ppuVar6;
    }
    piVar4[0xc] = (int)*ppuVar8;
    piVar4[0xd] = 0;
    piVar4[0xe] = 0x3f800000;
    piVar4[0xf] = 0;
    piVar4[0x10] = 0;
    piVar4[0x11] = 0;
    *(undefined *)(piVar4 + 0x12) = 0;
    *(undefined *)(piVar4 + 0x14) = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005c9310(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      uVar9 = uVar2 >> 1;
      if (uVar9 + uVar2 <= uVar7) {
        uVar9 = 1;
      }
      iVar5 = FUN_005c9310(uVar9 + uVar2);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar12;
        while (puVar3 != (undefined4 *)0x0) {
          piVar10 = (int *)(*(int *)(param_1 + 0x14) +
                           ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar10 = (int)puVar12;
            puVar12 = puVar3;
          }
          else {
            *puVar12 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar10;
            *(undefined4 **)*piVar10 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar12;
        }
      }
    }
    piVar4[1] = uVar11;
    uVar11 = uVar11 % *(uint *)(param_1 + 4);
    piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (piVar10 == (int *)0x0) {
      piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar10 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar12 = piVar10;
      *piVar4 = *piVar10;
    }
    else {
      *piVar4 = *piVar10;
      piVar10 = (int *)*puVar12;
    }
    *piVar10 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 20972 ; VA 0x00a60ca0 ; FUN_00a60ca0 */

int __thiscall FUN_00a60ca0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  pcVar3 = (code *)*param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20973 ; VA 0x00a60d40 ; FUN_00a60d40 */

void __fastcall FUN_00a60d40(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_optional_access>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::vftable
  ;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20974 ; VA 0x00a60dd8 ; FUN_00a60dd8 */

void FUN_00a60dd8(void)

{
  FUN_00a60e30();
  return;
}



/* FUNCTION 20975 ; VA 0x00a60de3 ; FUN_00a60de3 */

void FUN_00a60de3(void)

{
  FUN_00a60e30();
  return;
}



/* FUNCTION 20976 ; VA 0x00a60deb ; FUN_00a60deb */

void FUN_00a60deb(void)

{
  FUN_00a60e60();
  return;
}



/* FUNCTION 20977 ; VA 0x00a60df3 ; FUN_00a60df3 */

void FUN_00a60df3(void)

{
  FUN_00a60ee0();
  return;
}



/* FUNCTION 20978 ; VA 0x00a60e00 ; FUN_00a60e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a60e00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ChangeHistoryService::RuntimeUndoBehavior>::vftable
  ;
  _DAT_01ee7d40 = _DAT_01ee7d40 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 20979 ; VA 0x00a60e30 ; FUN_00a60e30 */

undefined4 __thiscall FUN_00a60e30(undefined4 param_1,byte param_2)

{
  FUN_00a60d40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 20980 ; VA 0x00a60e60 ; FUN_00a60e60 */

undefined4 * __thiscall FUN_00a60e60(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_optional_access>::vftable
  ;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20981 ; VA 0x00a60ee0 ; FUN_00a60ee0 */

undefined4 __thiscall FUN_00a60ee0(undefined4 param_1,byte param_2)

{
  FUN_00a60050();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 20982 ; VA 0x00a60f10 ; FUN_00a60f10 */

int __thiscall FUN_00a60f10(int param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x28);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  piVar4 = *(int **)(param_1 + 0x20);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00a5ffd0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 20983 ; VA 0x00a60fb0 ; FUN_00a60fb0 */

void FUN_00a60fb0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0xe4);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 20984 ; VA 0x00a60fd0 ; FUN_00a60fd0 */

void __fastcall FUN_00a60fd0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0xe4);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 20985 ; VA 0x00a60ff0 ; FUN_00a60ff0 */

void FUN_00a60ff0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x18) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 0x18) + 8))(param_1 + 0x1c);
  }
  FUN_01674ea0(param_1,0xe4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20986 ; VA 0x00a61050 ; thunk_FUN_00a65740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a65740(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1d26;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7dac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee7dac);
    if (DAT_01ee7dac == -1) {
      uStack_8 = 0;
      FUN_009ca470("RuntimeUndoBehavior");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee7d48 =
           RBX::Reflection::EnumDesc<enum_RBX::ChangeHistoryService::RuntimeUndoBehavior>::vftable;
      FUN_009caf20(&DAT_01d66198,3);
      FUN_016f3654(&LAB_0188a2f0);
      FUN_016f37bf(&DAT_01ee7dac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee7d48;
}



/* FUNCTION 20987 ; VA 0x00a61060 ; FUN_00a61060 */

void FUN_00a61060(int *param_1)

{
  char cVar1;
  int *piVar2;
  void **ppvVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar1 = *(char *)((int)param_1 + 0xd);
  ppvVar3 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar3, cVar1 == '\0') {
    FUN_00a61060(param_1[2]);
    piVar2 = (int *)*param_1;
    uStack_8 = 0;
    if (param_1[6] != 0) {
      (**(code **)(param_1[6] + 8))(param_1 + 7);
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(param_1,0xe4);
    ppvVar3 = (void **)ExceptionList;
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20988 ; VA 0x00a610f0 ; FUN_00a610f0 */

void FUN_00a610f0(undefined4 param_1)

{
  FUN_01674ea0(param_1,0xe4);
  return;
}



/* FUNCTION 20989 ; VA 0x00a61110 ; FUN_00a61110 */

void __thiscall FUN_00a61110(int param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined auStack_dc [200];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e18db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (*(int *)(param_2 + 0x10) != 0) {
    ExceptionList = &pvStack_10;
    FUN_0056ecd0((int *)(param_2 + 0x10));
  }
  puVar6 = *(undefined4 **)(param_2 + 0x18);
  puVar2 = (undefined4 *)*puVar6;
  while (puVar2 != puVar6) {
    iStack_e8 = puVar2[4];
    uStack_e4 = puVar2[5];
    puVar4 = (undefined4 *)puVar2[6];
    puStack_e0 = (undefined4 *)0x0;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar2 + 7,auStack_dc);
      puVar4 = (undefined4 *)puVar2[6];
    }
    uStack_8 = 0;
    puStack_e0 = puVar4;
    FUN_00a614a0(&iStack_e8);
    uStack_8 = 1;
    if (puStack_e0 != (undefined4 *)0x0) {
      (*(code *)puStack_e0[2])(auStack_dc);
    }
    puVar4 = (undefined4 *)puVar2[2];
    uStack_8 = 0xffffffff;
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar2 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar2 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar3 = (undefined4 *)puVar2[1];
      puVar4 = puVar2;
      while ((puVar2 = puVar3, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar3 = (undefined4 *)puVar2[1];
        puVar4 = puVar2;
      }
    }
  }
  if (*(int *)(param_2 + 0x28) == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = *(undefined4 **)(*(int *)(param_2 + 0x34) + *(int *)(param_2 + 0x24) * 4);
  }
  for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
    piVar7 = puVar6 + 5;
    iVar5 = FUN_00a60880(puVar6 + 2);
    if ((int *)(iVar5 + 0xc) != piVar7) {
      if (0xf < (uint)puVar6[10]) {
        piVar7 = (int *)*piVar7;
      }
      FUN_005542c0(piVar7,puVar6[9]);
    }
    *(undefined4 *)(iStack_14 + 0xc) = 2;
  }
  if (*(char *)(iStack_14 + 0x3c) != '\0') {
    *(undefined *)(iStack_14 + 0x3c) = 0;
  }
  if (*(char *)(iStack_14 + 0x44) != '\0') {
    *(undefined *)(iStack_14 + 0x44) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20990 ; VA 0x00a612b0 ; FUN_00a612b0 */

void __thiscall FUN_00a612b0(byte *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e18f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a63090(&iStack_34);
  uStack_8 = 0;
  uStack_1c = 0;
  iVar2 = iStack_34;
  if (iStack_30 - iStack_34 >> 2 != 0) {
    do {
      iVar5 = *(int *)(iVar2 + uStack_1c * 4);
      param_2 = *(uint *)(iVar5 + 4);
      piStack_14 = (int *)(param_2 >> 3);
      iStack_28 = iVar5;
      FUN_00606ea0(&iStack_20,(int)piStack_14 + param_2,&param_2,
                   -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                   (uint)(param_1 + *param_1 + 1 + 1));
      if ((iStack_20 == 0) || (iStack_20 == -0xc)) {
        param_2 = *(uint *)(iVar5 + 4);
        iVar2 = FUN_00a60a40(&param_2);
        FUN_00a604c0(iStack_28);
        *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
        *(undefined4 *)(iVar2 + 0x3c) = *(undefined4 *)(param_1 + 0x18);
        iVar2 = iStack_34;
      }
      else if (*(int *)(iVar5 + 0xc) == 3) {
        if (*(int *)(param_1 + 8) != 0) {
          uStack_24 = param_2 + (int)piStack_14;
          uStack_18 = uStack_24 % *(uint *)(param_1 + 4);
          iStack_28 = uStack_18 * 4;
          piStack_14 = *(int **)(iStack_28 + *(int *)(param_1 + 0x14));
          if ((piStack_14 != (int *)0x0) &&
             (piVar1 = (int *)*piStack_14, (int *)*piStack_14 != (int *)0x0)) {
            while (piVar3 = piVar1, piVar1 = piStack_14,
                  (uint)piVar3[1] % *(uint *)(param_1 + 4) == uStack_18) {
              if ((piVar3[1] == uStack_24) && (param_2 == piVar3[2])) {
                FUN_00a62bb0(piStack_14,*piVar3);
                iVar2 = iStack_34;
                if (*piVar1 != 0) {
                  uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
                  if (uStack_18 == uVar4) break;
                  *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
                }
                if (*(int **)(*(int *)(param_1 + 0x14) + iStack_28) == piVar1) {
                  *(undefined4 *)(*(int *)(param_1 + 0x14) + iStack_28) = 0;
                }
                break;
              }
              piVar1 = (int *)*piVar3;
              piStack_14 = piVar3;
              if ((int *)*piVar3 == (int *)0x0) break;
            }
          }
        }
      }
      else {
        FUN_00a61110(iVar5);
        iVar2 = iStack_34;
      }
      uStack_1c = uStack_1c + 1;
    } while (uStack_1c < (uint)(iStack_30 - iVar2 >> 2));
  }
  if (iVar2 != 0) {
    uVar4 = iStack_2c - iVar2 & 0xfffffffc;
    iVar5 = iVar2;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20991 ; VA 0x00a614a0 ; FUN_00a614a0 */

void FUN_00a614a0(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  
  puVar3 = (undefined4 *)FUN_00a60800(param_1);
  piVar1 = (int *)(param_1 + 8);
  piVar2 = puVar3 + 1;
  *puVar3 = *(undefined4 *)(param_1 + 4);
  if (piVar1 != piVar2) {
    if (*piVar2 != 0) {
      (**(code **)(*piVar2 + 8))(puVar3 + 2);
      *piVar2 = 0;
    }
    if ((undefined4 *)*piVar1 != (undefined4 *)0x0) {
      (**(code **)*piVar1)(param_1 + 0xc,puVar3 + 2);
      *piVar2 = *piVar1;
    }
  }
  return;
}



/* FUNCTION 20992 ; VA 0x00a61500 ; FUN_00a61500 */

int __thiscall FUN_00a61500(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined auStack_98 [16];
  int iStack_88;
  int *piStack_84;
  undefined8 uStack_7c;
  undefined8 uStack_70;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  int iStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined8 *puStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1923;
  pvStack_10 = ExceptionList;
  if ((param_2 != 0) && (*(int *)(param_2 + 8) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_00a70e60(&iStack_24);
    iStack_8 = 0;
    param_2 = (iStack_20 - iStack_24) / 0x18;
    uStack_18 = 0;
    if (param_2 != 0) {
      iStack_14 = 0;
      do {
        FUN_00a70da0(&uStack_58,3);
        iVar5 = iStack_44;
        puStack_34 = &uStack_58;
        uStack_30 = uStack_58;
        iStack_28 = iStack_50;
        uStack_7c = uStack_4c;
        while( true ) {
          if ((((int)uStack_30 == (int)uStack_7c) && (uStack_30._4_4_ == uStack_7c._4_4_)) &&
             (iStack_28 == iVar5)) break;
          iStack_40 = (int)uStack_30 * 8;
          iStack_64 = iStack_40 + 8;
          iStack_3c = uStack_30._4_4_ * 8;
          iStack_60 = iStack_3c + 8;
          uStack_70 = CONCAT44(iStack_3c,iStack_40);
          iStack_68 = iStack_28 * 8;
          iStack_5c = iStack_68 + 8;
          FUN_00a71760(auStack_98,&uStack_70,0,1);
          iStack_8._0_1_ = 1;
          if (iStack_88 != 0) {
            iVar3 = FUN_00a60880(&uStack_30);
            FUN_00a71f60(iVar3 + 0xc);
            *(undefined4 *)(param_1 + 0xc) = 2;
          }
          piVar2 = piStack_84;
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (piStack_84 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_84[1] + -1;
            piStack_84[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_84)();
              LOCK();
              piVar1 = piVar2 + 2;
              iVar3 = *piVar1 + -1;
              *piVar1 = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          FUN_00a6e100();
        }
        if (*(char *)(param_1 + 0x44) != '\0') {
          *(undefined *)(param_1 + 0x44) = 0;
        }
        param_2 = iStack_14 + 0x18;
        uStack_18 = uStack_18 + 1;
        iStack_14 = param_2;
      } while (uStack_18 < (uint)((iStack_20 - iStack_24) / 0x18));
    }
    if (*(char *)(param_1 + 0x44) != '\0') {
      *(undefined *)(param_1 + 0x44) = 0;
    }
    if (iStack_24 != 0) {
      uVar4 = ((iStack_1c - iStack_24) / 0x18) * 0x18;
      iVar5 = iStack_24;
      if (0xfff < uVar4) {
        iVar5 = *(int *)(iStack_24 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iStack_24 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      param_2 = FUN_01674ea0(iVar5,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20993 ; VA 0x00a61710 ; FUN_00a61710 */

void __thiscall FUN_00a61710(int param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined auStack_84 [16];
  int iStack_74;
  int *piStack_70;
  undefined8 uStack_6c;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  undefined8 uStack_54;
  int iStack_4c;
  undefined8 uStack_48;
  int iStack_40;
  undefined8 uStack_38;
  undefined8 *puStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a70da0(&uStack_54,3);
  puStack_2c = &uStack_54;
  uStack_28 = uStack_54;
  iStack_20 = iStack_4c;
  uStack_38 = uStack_48;
  while( true ) {
    if ((((int)uStack_28 == (int)uStack_38) && (uStack_28._4_4_ == uStack_38._4_4_)) &&
       (iStack_20 == iStack_40)) break;
    iStack_1c = (int)uStack_28 * 8;
    iStack_60 = iStack_1c + 8;
    iStack_18 = uStack_28._4_4_ * 8;
    iStack_5c = iStack_18 + 8;
    uStack_6c = CONCAT44(iStack_18,iStack_1c);
    iStack_64 = iStack_20 * 8;
    iStack_58 = iStack_64 + 8;
    FUN_00a71760(auStack_84,&uStack_6c,0,1);
    uStack_8 = 0;
    if ((param_4 == '\0') || (iStack_74 != 0)) {
      iVar3 = FUN_00a60880(&uStack_28);
      FUN_00a71f60(iVar3 + 0xc);
      *(undefined4 *)(param_1 + 0xc) = 2;
    }
    piVar2 = piStack_70;
    uStack_8 = 0xffffffff;
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_70[1] + -1;
      piStack_70[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_70)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_00a6e100();
  }
  if (*(char *)(param_1 + 0x44) != '\0') {
    *(undefined *)(param_1 + 0x44) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20994 ; VA 0x00a61850 ; FUN_00a61850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a61850(int param_1,int *param_2)

{
  int iVar1;
  undefined *puVar2;
  int *piVar3;
  int *piVar4;
  void *pvVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  uint uVar12;
  float10 fVar13;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined auStack_100 [204];
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int iStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1982;
  pvStack_10 = ExceptionList;
  iStack_20 = param_1;
  if ((DAT_01d62c28 != '\0') && (param_2 == (int *)&DAT_0211a590)) {
    ExceptionList = &pvStack_10;
    param_2 = (int *)FUN_008a2020();
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    puVar6 = (undefined4 *)FUN_01674e20();
    puStack_30 = puVar6;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      puStack_28 = puVar6 + 3;
      puVar6[1] = 1;
      puVar6[2] = 1;
      *puVar6 = std::
                _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                ::vftable;
      *(undefined *)puStack_28 = 0;
      uStack_1c = ((double)*(int *)((int)param_2 + 8) +
                  (double)(&DAT_018c0d90)[-(*(int *)((int)param_2 + 8) >> 0x1f)]) /
                  (double)*(float *)((int)param_2 + 0xc);
      puStack_14 = puVar6;
      fVar13 = (float10)FUN_01725280(uStack_1c);
      uStack_1c = (double)fVar13;
      if (uStack_1c + DAT_018c0d60 < _DAT_018c4e98) {
        uVar7 = FUN_016f3eb1();
      }
      else {
        uVar7 = 0xffffffff;
      }
      uStack_1c = (double)CONCAT44(uVar7,(undefined4)uStack_1c);
      ppuVar8 = (undefined **)
                FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,(int)&uStack_1c + 4)
      ;
      ppuVar11 = ppuVar8 + -1;
      if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar11 = ppuVar8;
      }
      puVar6[4] = *ppuVar11;
      puVar6[5] = 0;
      puVar6[6] = *(undefined4 *)((int)param_2 + 0xc);
      puVar6[7] = 0;
      puVar6[8] = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005c9140();
    }
    puStack_2c = puVar6 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    piStack_24 = piVar3;
    puStack_28 = puVar6;
    puVar9 = (undefined4 *)FUN_00a60800();
    uVar7 = FUN_008881d0();
    pvVar5 = ThreadLocalStoragePointer;
    iVar1 = _tls_index;
    *puVar9 = uVar7;
    if ((*(int *)(*(int *)((int)pvVar5 + iVar1 * 4) + 0x34) < DAT_01ea93d0) &&
       (FUN_016f3809(), DAT_01ea93d0 == -1)) {
      _DAT_01ea93c4 = FUN_0057bbb0;
      _DAT_01ea93c8 = FUN_005880a0;
      DAT_01ea93cc = FUN_0057d5e0;
      FUN_016f37bf();
    }
    puVar2 = (undefined *)puVar9[1];
    if (puVar2 == &DAT_01ea93c4) {
      puVar9[2] = puStack_2c;
      piVar3 = (int *)puVar9[3];
      puVar9[3] = puStack_14;
      puVar10 = puStack_14;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar4 = piVar3 + 1;
        iVar1 = *piVar4;
        puVar10 = (undefined4 *)*piVar4;
        *piVar4 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar4 = piVar3 + 2;
          iVar1 = *piVar4;
          puVar10 = (undefined4 *)*piVar4;
          *piVar4 = iVar1 + -1;
          UNLOCK();
          if (iVar1 + -1 == 0) {
            puVar10 = (undefined4 *)(**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else {
      if (puVar2 != (undefined *)0x0) {
        (**(code **)(puVar2 + 8))();
      }
      puVar10 = puVar6 + 3;
      puVar9[3] = puVar6;
      puVar9[2] = puVar10;
      puVar9[1] = &DAT_01ea93c4;
    }
    if (piStack_34 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return puVar10;
    }
    LOCK();
    piVar3 = piStack_34 + 1;
    iVar1 = *piVar3;
    puVar6 = (undefined4 *)*piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 != 0) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    puVar6 = (undefined4 *)(**(code **)*piStack_34)();
    LOCK();
    piVar3 = piStack_34 + 2;
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 != 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    puVar6 = (undefined4 *)(**(code **)(*piStack_34 + 4))();
    ExceptionList = pvStack_10;
    return puVar6;
  }
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)(**(code **)(*param_2 + 8))();
  if ((char)puVar6 != '\0') {
    ExceptionList = pvStack_10;
    return puVar6;
  }
  puVar6 = (undefined4 *)(**(code **)(*piVar3 + 0xc))();
  if ((char)puVar6 != '\0') {
    ExceptionList = pvStack_10;
    return puVar6;
  }
  puVar6 = (undefined4 *)((uint)piVar3[9] >> 4);
  if (((uint)puVar6 & 1) == 0) {
    ExceptionList = pvStack_10;
    return puVar6;
  }
  uVar12 = (uint)piVar3[9] >> 2;
  if (DAT_01d67098 == '\0') {
    if ((uVar12 & 1) != 0) goto LAB_00a61af3;
    piVar4 = (int *)&DAT_01eeebc4;
  }
  else {
    if (((uVar12 & 1) != 0) || (piVar3 == (int *)&DAT_01eeebc4)) goto LAB_00a61af3;
    piVar4 = (int *)&DAT_01eeec34;
  }
  if ((piVar3 != piVar4) && (piVar3 != &DAT_01eee910)) {
    ExceptionList = pvStack_10;
    return puVar6;
  }
LAB_00a61af3:
  uStack_108 = FUN_00888530();
  puStack_104 = (undefined4 *)0x0;
  puVar6 = &uStack_108;
  uVar7 = *(undefined4 *)(param_1 + 4);
  uStack_8 = 4;
  (**(code **)(*piVar3 + 0x14))();
  param_2 = piVar3;
  FUN_00a60800(&param_2);
  FUN_0056ee80();
  uStack_8 = 5;
  if (puStack_104 != (undefined4 *)0x0) {
    puStack_104 = (undefined4 *)(*(code *)puStack_104[2])(auStack_100,uVar7,puVar6);
  }
  ExceptionList = pvStack_10;
  return puStack_104;
}



/* FUNCTION 20995 ; VA 0x00a61bc0 ; FUN_00a61bc0 */

void FUN_00a61bc0(undefined4 *param_1)

{
  if (param_1 != &DAT_0211a3d8) {
    FUN_00a61850();
    return;
  }
  return;
}



/* FUNCTION 20996 ; VA 0x00a61be0 ; FUN_00a61be0 */

void __thiscall FUN_00a61be0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  piVar1 = (int *)*param_2;
  if ((piVar1 != &DAT_0211a3d8) || (*(char *)(*(int *)(param_1 + 4) + 0x22) == '\0')) {
    if ((DAT_01d62c28 == '\0') || (piVar1 != (int *)&DAT_0211a590)) {
      (**(code **)(*piVar1 + 0x1c))(*(undefined4 *)(param_1 + 4),param_2 + 1);
    }
    else {
      iVar2 = param_2[1];
      iVar3 = FUN_008881d0();
      if (iVar2 == iVar3) {
        puVar4 = param_2 + 3;
        if (param_2[2] == 0) {
          puVar4 = (undefined4 *)0x0;
        }
        if (puVar4 != (undefined4 *)0x0) {
          if (puVar4[1] != 0) {
            LOCK();
            piVar1 = (int *)(puVar4[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_008a5d30(*puVar4,puVar4[1]);
          return;
        }
      }
    }
  }
  return;
}



/* FUNCTION 20997 ; VA 0x00a61c70 ; FUN_00a61c70 */

int FUN_00a61c70(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined auStack_40 [20];
  int *piStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1998;
  pvStack_10 = ExceptionList;
  iStack_18 = param_1[1] * 8 + 8;
  iStack_20 = param_1[2] * 8;
  iStack_1c = *param_1 * 8 + 8;
  uStack_28 = CONCAT44(param_1[1] * 8,*param_1 * 8);
  iStack_14 = iStack_20 + 8;
  ExceptionList = &pvStack_10;
  FUN_00a6dba0(8);
  uStack_8 = 0;
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00a6f140(param_2,*puVar1);
  iVar4 = FUN_00a72960(&uStack_28,auStack_40,0);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_2c + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_2c)();
      LOCK();
      piVar2 = piStack_2c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20998 ; VA 0x00a61d50 ; FUN_00a61d50 */

void __fastcall FUN_00a61d50(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  char cVar4;
  undefined4 uVar5;
  undefined *puStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e19e1;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)FUN_01674e20(0x40);
  if (puStack_1c == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_00a5fcf0(param_1);
  }
  *(undefined4 *)(param_1 + 0x68) = uVar5;
  *(undefined4 *)(param_1 + 0x74) = *(undefined4 *)(param_1 + 0x6c);
  puStack_34 = &LAB_008af4eb;
  uStack_30 = 0;
  *(undefined4 *)(param_1 + 0x78) = **(undefined4 **)(param_1 + 0x6c);
  iStack_2c = param_1;
  FUN_00a5f7f0(&puStack_34);
  if (*(char *)(param_1 + 0x81) != '\0') {
    FUN_00a65420(&DAT_01943f60);
    uVar3 = *(uint *)(param_1 + 0x70);
    while (1 < uVar3) {
      FUN_00a633e0();
      uVar3 = *(uint *)(param_1 + 0x70);
    }
    FUN_006eccd0();
  }
  FUN_008a4100();
  puStack_34 = &LAB_008af4eb;
  uStack_30 = 0;
  iStack_2c = param_1;
  puStack_1c = (undefined4 *)FUN_00a5eee0(&iStack_18,&puStack_34);
  uStack_8 = 0;
  cVar4 = FUN_01679300(puStack_1c);
  if (cVar4 != '\0') {
    FUN_01679490();
    FUN_016791c0(puStack_1c);
  }
  uStack_8 = 0xffffffff;
  if (iStack_18 != 0) {
    piVar1 = (int *)(iStack_18 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iStack_18);
    }
  }
  FUN_008a4100();
  puStack_34 = &LAB_00a60d2f;
  uStack_30 = 0;
  iStack_2c = param_1;
  puStack_1c = (undefined4 *)FUN_00a5eee0(&iStack_18,&puStack_34);
  uStack_8 = 1;
  cVar4 = FUN_01679300(puStack_1c);
  if (cVar4 != '\0') {
    FUN_01679490();
    FUN_016791c0(puStack_1c);
  }
  if (iStack_18 != 0) {
    piVar1 = (int *)(iStack_18 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iStack_18);
    }
  }
  iStack_18 = *(int *)(param_1 + 0x5c) + 0x2ac;
  puStack_34 = &LAB_00a3d6e0;
  uStack_30 = 0;
  uStack_8 = 2;
  iStack_2c = param_1;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  uStack_24 = uVar5;
  puStack_1c = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_1c == (undefined4 *)0x0) {
    puStack_1c = (undefined4 *)0x0;
  }
  else {
    *puStack_1c = 0;
    puStack_1c[1] = 1;
    puStack_1c[2] = FUN_00a62d30;
    puStack_1c[3] = _guard_check_icall;
    puStack_1c[4] = 0;
    puStack_1c[5] = iStack_18;
    puStack_1c[6] = puStack_34;
    puStack_1c[7] = uStack_30;
    puStack_1c[8] = iStack_2c;
    puStack_1c[9] = uStack_28;
  }
  FUN_016797d0(puStack_1c);
  puStack_14 = puStack_1c;
  if (puStack_1c != (undefined4 *)0x0) {
    LOCK();
    puStack_1c[1] = puStack_1c[1] + 1;
    UNLOCK();
  }
  uStack_20 = 1;
  uStack_8._0_1_ = 4;
  FUN_01675290(uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar4 = FUN_01679300(&puStack_14);
  if (cVar4 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_14);
  }
  if (puStack_14 != (undefined4 *)0x0) {
    piVar1 = puStack_14 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_14);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20999 ; VA 0x00a62010 ; FUN_00a62010 */

int * __thiscall FUN_00a62010(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1a26;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = 0;
  if ((*(char *)(param_1 + 0x81) != '\0') && (*(int *)(param_1 + 0x74) != *(int *)(param_1 + 0x6c)))
  {
    iVar2 = *(int *)(*(int *)(param_1 + 0x74) + 8);
    puVar4 = (uint *)(iVar2 + 0x28);
    ExceptionList = &pvStack_10;
    if (auStack_38 != puVar4) {
      if (0xf < *(uint *)(iVar2 + 0x3c)) {
        puVar4 = (uint *)*puVar4;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(puVar4,*(undefined4 *)(iVar2 + 0x38));
    }
    puVar5 = (undefined4 *)FUN_01674e20(0x18);
    uStack_8._0_1_ = 1;
    puStack_18 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5[1] = 1;
      puVar5[2] = 1;
      *puVar5 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
      FUN_00569550(2,&uStack_11);
    }
    piVar1 = puVar5 + 3;
    puVar3 = (undefined4 *)*piVar1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_20 = piVar1;
    puStack_1c = puVar5;
    uVar6 = FUN_0088daf0();
    *puVar3 = uVar6;
    puStack_18 = (undefined4 *)FUN_005c9ef0();
    iVar2 = puVar3[1];
    if ((undefined4 *)iVar2 == puStack_18) {
      *(undefined *)(puVar3 + 2) = 1;
    }
    else {
      if (iVar2 != 0) {
        (**(code **)(iVar2 + 8))(puVar3 + 2);
        puVar3[1] = 0;
      }
      *(undefined *)(puVar3 + 2) = 1;
      puVar3[1] = puStack_18;
    }
    FUN_005c16d0(auStack_38);
    *param_2 = (int)piVar1;
    param_2[1] = (int)puVar5;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar7 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 3;
  puStack_18 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(1,&uStack_11);
  }
  piVar1 = puVar5 + 3;
  puVar3 = (undefined4 *)*piVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_20 = piVar1;
  puStack_1c = puVar5;
  uVar6 = FUN_0088daf0();
  *puVar3 = uVar6;
  puStack_18 = (undefined4 *)FUN_005c9ef0();
  iVar2 = puVar3[1];
  if ((undefined4 *)iVar2 == puStack_18) {
    *(undefined *)(puVar3 + 2) = 0;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(puVar3 + 2);
      puVar3[1] = 0;
    }
    *(undefined *)(puVar3 + 2) = 0;
    puVar3[1] = puStack_18;
  }
  param_2[1] = (int)puVar5;
  *param_2 = (int)piVar1;
  ExceptionList = pvStack_10;
  return param_2;
}


