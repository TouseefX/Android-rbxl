/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 26000 ; VA 0x00bb6fb0 ; FUN_00bb6fb0 */

uint FUN_00bb6fb0(int param_1,float param_2,float param_3,float param_4,float param_5)

{
  float fVar1;
  uint in_EAX;
  int iVar2;
  uint uVar3;
  double dVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if (param_1 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (*(char *)(param_1 + 0xa8) != '\0') {
    FUN_00ca0e10();
  }
  fVar1 = *(float *)(param_1 + 0xa4);
  FUN_00ca1550();
  iVar2 = FUN_00c157b0();
  param_5 = param_5 - fVar1;
  dVar4 = (double)(param_4 - *(float *)(iVar2 + 0x2c));
  uVar5 = (uint)DAT_018c0da0;
  uVar6 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  uStack_c = (float)((ulonglong)*(undefined8 *)(iVar2 + 0x24) >> 0x20);
  uStack_10 = (float)*(undefined8 *)(iVar2 + 0x24);
  uVar3 = 0;
  if ((float)(double)CONCAT44((uint)((ulonglong)dVar4 >> 0x20) & uVar6,SUB84(dVar4,0) & uVar5) <
      param_5) {
    uVar3 = (uint)((float)(double)CONCAT44((uint)((ulonglong)(double)(param_3 - uStack_c) >> 0x20) &
                                           uVar6,SUB84((double)(param_3 - uStack_c),0) & uVar5) <
                   param_5 &&
                  (float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - uStack_10) >> 0x20) &
                                          uVar6,SUB84((double)(param_2 - uStack_10),0) & uVar5) <
                  param_5);
  }
  return uVar3;
}



/* FUNCTION 26001 ; VA 0x00bb7070 ; FUN_00bb7070 */

undefined4 __thiscall FUN_00bb7070(int param_1,int param_2)

{
  char cVar1;
  
  if (*(char *)(param_1 + 200) != '\0') {
    return 0;
  }
  if ((((*(char *)(param_1 + 0xc9) != '\0') && (*(char *)(param_1 + 0x3c) != '\0')) &&
      ((*(char *)(param_1 + 0x3d) != '\0' ||
       ((*(int *)(param_1 + 0x38) == 0 || (param_2 != *(int *)(param_1 + 0x38))))))) &&
     (cVar1 = FUN_00bb6fb0(param_2,*(undefined8 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x2c),
                           *(undefined4 *)(param_1 + 0x34)), cVar1 == '\0')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 26002 ; VA 0x00bb70e0 ; FUN_00bb70e0 */

void __thiscall FUN_00bb70e0(int param_1,uint *param_2)

{
  char cVar1;
  uint *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_10 [4];
  int iStack_c;
  int *piStack_8;
  
  puVar2 = param_2;
  iStack_c = param_1;
  if ((int)param_2[1] < 10) {
    piStack_8 = (int *)(param_1 + 0x40 + param_2[1] * 8);
    puVar6 = (undefined4 *)*piStack_8;
    puVar3 = (undefined4 *)puVar6[1];
    puVar7 = puVar6;
    if (*(char *)((int)puVar3 + 0xd) == '\0') {
      puVar5 = puVar3;
      do {
        if ((uint)puVar5[4] < *param_2) {
          puVar4 = (undefined4 *)puVar5[2];
        }
        else {
          if ((*(char *)((int)puVar7 + 0xd) != '\0') && (*param_2 < (uint)puVar5[4])) {
            puVar7 = puVar5;
          }
          puVar4 = (undefined4 *)*puVar5;
          puVar6 = puVar5;
        }
        puVar5 = puVar4;
      } while (*(char *)((int)puVar4 + 0xd) == '\0');
    }
    if (*(char *)((int)puVar7 + 0xd) == '\0') {
      puVar3 = (undefined4 *)*puVar7;
    }
    puVar5 = puVar6;
    if (*(char *)((int)puVar3 + 0xd) == '\0') {
      do {
        if (*param_2 < (uint)puVar3[4]) {
          puVar4 = (undefined4 *)*puVar3;
          puVar7 = puVar3;
        }
        else {
          puVar4 = (undefined4 *)puVar3[2];
        }
        puVar3 = puVar4;
      } while (*(char *)((int)puVar4 + 0xd) == '\0');
    }
    while (puVar5 != puVar7) {
      puVar3 = (undefined4 *)puVar5[2];
      if (*(char *)((int)puVar3 + 0xd) == '\0') {
        cVar1 = *(char *)((int)*puVar3 + 0xd);
        puVar5 = puVar3;
        puVar3 = (undefined4 *)*puVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((int)*puVar3 + 0xd);
          puVar5 = puVar3;
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      else {
        cVar1 = *(char *)((int)puVar5[1] + 0xd);
        puVar4 = (undefined4 *)puVar5[1];
        puVar3 = puVar5;
        while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined4 *)puVar5[2]))) {
          cVar1 = *(char *)((int)puVar5[1] + 0xd);
          puVar4 = (undefined4 *)puVar5[1];
          puVar3 = puVar5;
        }
      }
    }
    FUN_00bb7730(&param_2,puVar6,puVar7);
  }
  *(uint *)(*puVar2 + 0x3c) = puVar2[2];
  FUN_00bb8660(puVar2);
  if ((int)puVar2[2] < 10) {
    FUN_00898570(auStack_10,0,puVar2,param_2);
  }
  return;
}



/* FUNCTION 26003 ; VA 0x00bb7200 ; FUN_00bb7200 */

bool __thiscall FUN_00bb7200(int param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fStack_10;
  float fStack_c;
  
  fVar2 = *(float *)(param_1 + 0x2c);
  fStack_10 = (float)*(undefined8 *)(param_1 + 0x24);
  fVar1 = *param_2;
  if (*param_2 <= fStack_10) {
    fVar1 = fStack_10;
  }
  fVar5 = *param_3;
  if (fVar1 <= *param_3) {
    fVar5 = fVar1;
  }
  fStack_c = (float)((ulonglong)*(undefined8 *)(param_1 + 0x24) >> 0x20);
  fVar1 = param_2[1];
  if (param_2[1] <= fStack_c) {
    fVar1 = fStack_c;
  }
  fVar4 = param_3[1];
  if (fVar1 <= param_3[1]) {
    fVar4 = fVar1;
  }
  fVar1 = param_2[2];
  if (param_2[2] <= fVar2) {
    fVar1 = fVar2;
  }
  fVar3 = param_3[2];
  if (fVar1 <= param_3[2]) {
    fVar3 = fVar1;
  }
  return (fVar4 - fStack_c) * (fVar4 - fStack_c) + (fVar5 - fStack_10) * (fVar5 - fStack_10) +
         (fVar3 - fVar2) * (fVar3 - fVar2) <=
         *(float *)(param_1 + 0x30) * *(float *)(param_1 + 0x30);
}



/* FUNCTION 26004 ; VA 0x00bb7290 ; FUN_00bb7290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00bb7290(int param_1,double param_2)

{
  double dVar1;
  float fVar2;
  
  if ((float)(param_2 * _PTR_018dab58) < (float)DAT_01d67b5c) {
    *(undefined4 *)(param_1 + 0xcc) = 0;
    return;
  }
  dVar1 = (double)(DAT_018ce2f8 / (float)(param_2 * _PTR_018dab58));
  FUN_017267a0();
  fVar2 = (float)dVar1 * DAT_019011dc;
  if ((float)dVar1 * DAT_019011dc <= DAT_018ce2f8) {
    fVar2 = DAT_018ce2f8;
  }
  *(int *)(param_1 + 0xcc) = (int)((float)DAT_01d67b64 * fVar2);
  return;
}



/* FUNCTION 26005 ; VA 0x00bb7320 ; FUN_00bb7320 */

void FUN_00bb7320(void)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 uVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined8 uVar15;
  undefined8 uStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  float fStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  uint uStack_6c;
  int iStack_68;
  uint uStack_60;
  int iStack_5c;
  uint uStack_54;
  int iStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd9c4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef36c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef36c0), DAT_01ef36c0 == -1)) {
    uStack_8 = 0;
    uVar15 = FUN_0152dab0(&DAT_018cb3fc,"doBroadPhaseIslandAssemblyFilter",0xffffffff);
    DAT_01ef36bc = (undefined4)((ulonglong)uVar15 >> 0x20);
    DAT_01ef36b8 = (undefined4)uVar15;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ef36c0);
  }
  uVar11 = DAT_01ef36b8;
  uStack_44 = DAT_01ef36b8;
  uStack_7c = DAT_01ef36b8;
  uStack_48 = DAT_01ef36bc;
  uStack_78 = DAT_01ef36bc;
  uStack_74 = FUN_0152d930(DAT_01ef36b8,DAT_01ef36bc);
  uStack_8 = 1;
  iVar4 = *(int *)(*(int *)(iStack_14 + 0xc) + 0x6ac);
  if (*(int *)(iVar4 + 0x22c) == 0) {
    piVar9 = (int *)0x0;
  }
  else {
    piVar9 = *(int **)(*(int *)(iVar4 + 0x238) + *(int *)(iVar4 + 0x228) * 4);
  }
  iVar4 = iStack_14;
  piStack_18 = piVar9;
  if (piVar9 != (int *)0x0) {
    do {
      piStack_24 = (int *)piVar9[2];
      if (*(char *)(piStack_24 + 6) != '\0') {
        uVar10 = 0;
        piVar5 = (int *)*piStack_24;
        uStack_2c = piStack_24[1] - (int)piVar5 >> 3;
        piStack_18 = piVar9;
        if (uStack_2c != 0) {
          do {
            if (*piVar5 != piStack_24[4]) break;
            uVar10 = uVar10 + 1;
            piVar5 = piVar5 + 2;
          } while (uVar10 < uStack_2c);
        }
LAB_00bb7406:
        piVar5 = piStack_18;
        iVar4 = iStack_14;
        if (uVar10 != uStack_2c) {
          piStack_20 = (int *)(iStack_14 + 0xa0);
          uStack_30 = *(uint *)(*piStack_24 + uVar10 * 8);
          uStack_40 = *(undefined4 *)(*piStack_24 + 4 + uVar10 * 8);
          iVar4 = *piStack_20;
          if (iVar4 == *(int *)(iStack_14 + 0xa4)) {
            puVar6 = (uint *)0x0;
          }
          else {
            uStack_34 = *(uint *)(iStack_14 + 0xb0);
            if (uStack_30 == *(uint *)(iStack_14 + 0xb0)) {
              puVar6 = (uint *)0x0;
            }
            else {
              uVar7 = (uStack_30 >> 3) + uStack_30;
              uStack_3c = (*(int *)(iStack_14 + 0xa4) - iVar4 >> 4) - 1;
              uVar8 = 0;
              do {
                puVar6 = (uint *)((uVar7 & uStack_3c) * 0x10 + iVar4);
                uStack_38 = *puVar6;
                if (uStack_38 == uStack_30) goto LAB_00bb748a;
                if (uStack_38 == uStack_34) break;
                uVar7 = (uVar7 & uStack_3c) + 1 + uVar8;
                uVar8 = uVar8 + 1;
              } while (uVar8 <= uStack_3c);
              puVar6 = (uint *)0x0;
            }
          }
LAB_00bb748a:
          uVar7 = -(uint)(puVar6 != (uint *)0x0) & (uint)(puVar6 + 1);
          iStack_28 = *(int *)(uStack_30 + 0x3c);
          uStack_1c = uStack_30;
          if (*(int *)(uStack_30 + 0x50) < 1) {
            iVar4 = iStack_28;
            if (uVar7 != 0) {
              iVar4 = *(int *)(uVar7 + 8);
            }
            if ((3 < iVar4) && (iStack_28 < 10)) {
              if (*(int *)(iStack_14 + 0x1c) == 3) {
                if (*(char *)(iStack_14 + 0xc9) != '\0') {
                  cVar2 = FUN_00bb6fb0(uStack_30,*(undefined4 *)(iStack_14 + 0x24),
                                       *(undefined4 *)(iStack_14 + 0x28),
                                       *(undefined4 *)(iStack_14 + 0x2c),
                                       *(undefined4 *)(iStack_14 + 0x34));
                  if (cVar2 == '\0') goto LAB_00bb764d;
                }
                if (DAT_01d67b94 == '\0') {
                  uStack_54 = uStack_1c;
                  iStack_50 = iStack_28;
                  if ((uint)((piStack_20[1] - *piStack_20 >> 4) * 3) >> 2 <= (uint)piStack_20[3]) {
                    FUN_00bb8c00();
                  }
                  iVar3 = FUN_006b6b20(&uStack_30);
                  uVar7 = uStack_54;
                  iVar4 = iStack_50;
LAB_00bb7641:
                  *(uint *)(iVar3 + 4) = uVar7;
                  *(int *)(iVar3 + 8) = iVar4;
                  *(undefined4 *)(iVar3 + 0xc) = 3;
                }
                else {
                  uStack_90 = CONCAT44(iStack_28,uStack_1c);
                  uStack_84 = uStack_40;
                  uStack_88 = 3;
                  uStack_60 = uStack_1c;
                  iStack_5c = iStack_28;
                  FUN_00ca1550();
                  iVar4 = FUN_00c157b0();
                  fVar14 = *(float *)(iStack_14 + 0x28) - *(float *)(iVar4 + 0x28);
                  fVar13 = *(float *)(iStack_14 + 0x24) - *(float *)(iVar4 + 0x24);
                  fVar12 = *(float *)(iStack_14 + 0x2c) - *(float *)(iVar4 + 0x2c);
                  puVar1 = *(undefined4 **)(iStack_14 + 0x98);
                  fStack_80 = fVar14 * fVar14 + fVar13 * fVar13 + fVar12 * fVar12;
                  if (*(undefined4 **)(iStack_14 + 0x9c) == puVar1) {
                    FUN_00bb5c00(puVar1,&uStack_90);
                  }
                  else {
                    *puVar1 = (undefined4)uStack_90;
                    puVar1[1] = uStack_90._4_4_;
                    puVar1[2] = uStack_88;
                    puVar1[3] = uStack_84;
                    puVar1[4] = fStack_80;
                    *(int *)(iStack_14 + 0x98) = *(int *)(iStack_14 + 0x98) + 0x14;
                  }
                }
              }
              else if (*(int *)(iStack_14 + 0x1c) == 4) {
                uStack_6c = uStack_30;
                iStack_68 = iStack_28;
                if ((uint)((*(int *)(iStack_14 + 0xa4) - *piStack_20 >> 4) * 3) >> 2 <=
                    *(uint *)(iStack_14 + 0xac)) {
                  FUN_00bb8c00();
                }
                iVar3 = FUN_006b6b20(&uStack_30);
                uVar7 = uStack_6c;
                iVar4 = iStack_68;
                goto LAB_00bb7641;
              }
            }
          }
LAB_00bb764d:
          do {
            uVar10 = uVar10 + 1;
            piVar9 = piVar5;
            if ((uint)(piStack_24[1] - *piStack_24 >> 3) <= uVar10) break;
            piVar5 = piStack_18;
            piVar9 = piStack_18;
          } while (*(int *)(*piStack_24 + uVar10 * 8) == piStack_24[4]);
          goto LAB_00bb7406;
        }
      }
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
    piStack_18 = (int *)0x0;
    uVar11 = uStack_44;
  }
  if ((DAT_01d67b94 != '\0') && (*(int *)(iVar4 + 0x1c) == 3)) {
    FUN_00bb80a0();
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar11,uStack_48,uStack_74);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26006 ; VA 0x00bb7730 ; FUN_00bb7730 */

void __thiscall FUN_00bb7730(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    piVar3 = piVar1;
    piVar5 = (int *)piVar1[1];
    ExceptionList = &pvStack_10;
    if (*(char *)(piVar1[1] + 0xd) == '\0') {
      do {
        FUN_0089c7e0(piVar5[2]);
        piVar3 = (int *)*piVar5;
        FUN_01674ea0(piVar5,0x14);
        piVar5 = piVar3;
      } while (*(char *)((int)piVar3 + 0xd) == '\0');
      piVar3 = (int *)*param_1;
    }
    piVar3[1] = (int)piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar4 = FUN_00553830(param_3);
    FUN_01674ea0(uVar4,0x14);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26007 ; VA 0x00bb7820 ; FUN_00bb7820 */

int __thiscall FUN_00bb7820(int *param_1,uint *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puStack_8;
  
  puVar5 = (undefined4 *)*param_1;
  puVar2 = (undefined4 *)puVar5[1];
  puStack_8 = puVar5;
  if (*(char *)((int)puVar2 + 0xd) == '\0') {
    puVar3 = puVar2;
    do {
      if ((uint)puVar3[4] < *param_2) {
        puVar4 = (undefined4 *)puVar3[2];
      }
      else {
        if ((*(char *)((int)puVar5 + 0xd) != '\0') && (*param_2 < (uint)puVar3[4])) {
          puVar5 = puVar3;
        }
        puVar4 = (undefined4 *)*puVar3;
        puStack_8 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    puVar2 = (undefined4 *)*puVar5;
  }
  if (*(char *)((int)puVar2 + 0xd) == '\0') {
    do {
      if (*param_2 < (uint)puVar2[4]) {
        puVar3 = (undefined4 *)*puVar2;
        puVar5 = puVar2;
      }
      else {
        puVar3 = (undefined4 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  iVar6 = 0;
  puVar2 = puStack_8;
  while (puVar2 != puVar5) {
    puVar3 = (undefined4 *)puVar2[2];
    iVar6 = iVar6 + 1;
    if (*(char *)((int)puVar3 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar3 + 0xd);
      puVar2 = puVar3;
      puVar3 = (undefined4 *)*puVar3;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar3 + 0xd);
        puVar2 = puVar3;
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar4 = (undefined4 *)puVar2[1];
      puVar3 = puVar2;
      while ((puVar2 = puVar4, cVar1 == '\0' && (puVar3 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar4 = (undefined4 *)puVar2[1];
        puVar3 = puVar2;
      }
    }
  }
  FUN_00bb7730(&param_2,puStack_8,puVar5);
  return iVar6;
}



/* FUNCTION 26008 ; VA 0x00bb7900 ; FUN_00bb7900 */

void __fastcall FUN_00bb7900(int param_1)

{
  char cVar1;
  int *piVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined8 uStack_3c;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd9dc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_016830f0(&uStack_30);
  piVar6 = (int *)(param_1 + 0x40);
  iStack_18 = 0;
  iStack_28 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  do {
    iVar5 = iStack_18;
    piStack_1c = piVar6;
    if ((*(int *)(iStack_28 + 0x34) < DAT_01ef36d0) &&
       (FUN_016f3809(&DAT_01ef36d0), DAT_01ef36d0 == -1)) {
      uStack_8 = 0;
      uVar11 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef36cc = (undefined4)((ulonglong)uVar11 >> 0x20);
      DAT_01ef36c8 = (undefined4)uVar11;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef36d0);
    }
    FUN_0152d760(DAT_01ef36c8,DAT_01ef36cc,"Filter AssemblySetPhase: %d - Num Assemblies: %u",iVar5,
                 piVar6[1]);
    piVar7 = *(int **)*piVar6;
    if (piVar7 != (int *)*piVar6) {
      do {
        iVar5 = piVar7[4];
        iStack_24 = iVar5;
        if (DAT_01ef3680 != '\0') {
          iStack_20 = FUN_00ca1550();
          iVar4 = FUN_00c15700();
          if ((iStack_20 != iVar4) && (DAT_01ef3680 != '\0')) {
            FUN_01677490(DAT_01ef3680,
                         "Spatial Filter - filtering incorrect assembly: %p - Filter Phase: %d",
                         iStack_20,iStack_18,0);
          }
        }
        if (DAT_01d6f4f0 == '\0') {
          if ((*(char *)(iStack_14 + 0xca) != '\0') && (DAT_01d6f4e8 != '\0')) {
            *(undefined *)(iVar5 + 0x39) = 1;
          }
        }
        else {
          *(undefined2 *)(iVar5 + 0x39) = 1;
        }
        iStack_20 = FUN_00bb7c70(iVar5,1,uStack_30,uStack_2c);
        if (iStack_20 != iStack_18) {
          uStack_3c = CONCAT44(iStack_18,iVar5);
          if ((uint)((*(int *)(iStack_14 + 0xa4) - *(int *)(iStack_14 + 0xa0) >> 4) * 3) >> 2 <=
              *(uint *)(iStack_14 + 0xac)) {
            FUN_00bb8c00();
          }
          iVar5 = FUN_006b6b20(&iStack_24);
          *(undefined8 *)(iVar5 + 4) = uStack_3c;
          *(int *)(iVar5 + 0xc) = iStack_20;
        }
        piVar6 = (int *)piVar7[2];
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          cVar1 = *(char *)(*piVar6 + 0xd);
          piVar7 = piVar6;
          piVar6 = (int *)*piVar6;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*piVar6 + 0xd);
            piVar7 = piVar6;
            piVar6 = (int *)*piVar6;
          }
        }
        else {
          cVar1 = *(char *)(piVar7[1] + 0xd);
          piVar2 = (int *)piVar7[1];
          piVar6 = piVar7;
          while ((piVar7 = piVar2, cVar1 == '\0' && (piVar6 == (int *)piVar7[2]))) {
            cVar1 = *(char *)(piVar7[1] + 0xd);
            piVar2 = (int *)piVar7[1];
            piVar6 = piVar7;
          }
        }
        iVar5 = iStack_18;
      } while (piVar7 != (int *)*piStack_1c);
    }
    iVar4 = iStack_14;
    iStack_18 = iVar5 + 1;
    piVar6 = piStack_1c + 2;
  } while (iStack_18 < 10);
  piStack_1c = piVar6;
  FUN_00bb7320();
  uVar8 = 0;
  piVar6 = *(int **)(iVar4 + 0xa0);
  piStack_1c = (int *)(*(int *)(iVar4 + 0xa4) - (int)piVar6 >> 4);
  if (piStack_1c != (int *)0x0) {
    do {
      if (*piVar6 != *(int *)(iVar4 + 0xb0)) break;
      uVar8 = uVar8 + 1;
      piVar6 = piVar6 + 4;
    } while (uVar8 < piStack_1c);
  }
  do {
    if ((int *)uVar8 == piStack_1c) {
      *(undefined4 *)(iVar4 + 0xa4) = *(undefined4 *)(iVar4 + 0xa0);
      *(undefined4 *)(iVar4 + 0xac) = 0;
      if ((DAT_01d6f4f0 != '\0') && (*(char *)(iVar4 + 0xca) != '\0')) {
        piVar6 = *(int **)(iVar4 + 0xb8);
        uVar8 = (uint)((int)*(int **)(iVar4 + 0xbc) + (3 - (int)piVar6)) >> 2;
        if (*(int **)(iVar4 + 0xbc) < piVar6) {
          uVar8 = 0;
        }
        if (uVar8 != 0) {
          uVar9 = 0;
          do {
            bVar3 = DAT_01d67b6c;
            iVar5 = *piVar6;
            if ((*(int *)(iVar5 + 0x3c) == 7) || (*(int *)(iVar5 + 0x3c) == 5)) {
              *(byte *)(iVar5 + 0x39) = DAT_01d67b6c;
            }
            else {
              bVar3 = *(byte *)(iVar5 + 0x39);
            }
            uVar10 = uVar9 + 1;
            piVar6 = piVar6 + 1;
            *(char *)(iVar5 + 0x3a) = (char)((int)uVar9 % (int)(uint)bVar3);
            iVar4 = iStack_14;
            uVar9 = uVar10;
          } while (uVar10 != uVar8);
        }
        *(undefined4 *)(iVar4 + 0xbc) = *(undefined4 *)(iVar4 + 0xb8);
      }
      ExceptionList = pvStack_10;
      return;
    }
    iVar5 = *(int *)(iVar4 + 0xa0);
    iStack_28 = uVar8 * 0x10;
    uVar11 = *(undefined8 *)(iVar5 + 4 + iStack_28);
    iStack_34 = *(int *)(iVar5 + 0xc + iStack_28);
    uStack_3c._4_4_ = (int)((ulonglong)uVar11 >> 0x20);
    if (uStack_3c._4_4_ != iStack_34) {
      uStack_3c = uVar11;
      FUN_00bb70e0(&uStack_3c);
      iVar5 = *(int *)(iVar4 + 0xa0);
    }
    piVar6 = (int *)(iVar5 + iStack_28);
    do {
      uVar8 = uVar8 + 1;
      piVar6 = piVar6 + 4;
      if ((uint)(*(int *)(iVar4 + 0xa4) - iVar5 >> 4) <= uVar8) break;
    } while (*piVar6 == *(int *)(iVar4 + 0xb0));
  } while( true );
}



/* FUNCTION 26009 ; VA 0x00bb7c70 ; FUN_00bb7c70 */

char __thiscall
FUN_00bb7c70(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  switch(*(undefined4 *)(param_1 + 0x1c)) {
  case 0:
  case 2:
    return '\x01';
  default:
    return '\x05';
  case 3:
    break;
  case 4:
    iVar4 = FUN_00ca1550();
    uStack_8 = 1;
    param_2 = *(undefined4 *)(iVar4 + 0x1dc);
    cVar2 = FUN_005e0cd0(&uStack_8);
    if (cVar2 != '\0') {
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadcf4
          ) && (FUN_016f3809(&DAT_01eadcf4), DAT_01eadcf4 == -1)) {
        DAT_01eadcf0 = 0xffffffff;
        FUN_016f37bf(&DAT_01eadcf4);
      }
      uStack_c = DAT_01eadcf0;
      cVar2 = FUN_005e0cd0(&uStack_c);
      if (cVar2 != '\0') {
        uStack_10 = 2;
        cVar2 = FUN_005e0cd0(&uStack_10);
        if (cVar2 != '\0') {
          if ((0 < *(int *)(iVar1 + 0x4c)) && (*(int *)(iVar1 + 0x50) < 1)) {
            return '\x03';
          }
          FUN_00ca1550();
          cVar2 = FUN_00c16180();
          if ((cVar2 != '\0') && (*(char *)(iVar1 + 0x35) == '\0')) {
            return '\t';
          }
          iVar4 = FUN_00ca1550();
          if (*(char *)(iVar4 + 0x228) != '\0') {
            return (*(char *)(iVar1 + 0x35) != '\0') * '\x02' + '\x05';
          }
          return (*(char *)(iVar1 + 0x35) != '\0') * '\x02' + '\x04';
        }
      }
    }
    if ((char)param_3 != '\0') {
      FUN_00bb8d80();
    }
    FUN_00cdf460(iVar1);
    if (DAT_01ef3680 == '\0') {
      return '\x01';
    }
    FUN_00ca1550();
    FUN_016774b0();
    return '\x01';
  }
  if (*(char *)(param_1 + 200) == '\0') {
    iVar4 = FUN_00ca1550();
    uStack_8 = *(undefined4 *)(iVar4 + 0x1dc);
    cVar2 = FUN_00a33d60(param_1 + 0x20);
    if (cVar2 == '\0') {
      if (((0 < *(int *)(iVar1 + 0x4c)) && (*(int *)(iVar1 + 0x50) < 1)) &&
         ((*(char *)(param_1 + 0xc9) == '\0' ||
          (cVar2 = FUN_00bb6fb0(iVar1,*(undefined8 *)(param_1 + 0x24),
                                *(undefined4 *)(param_1 + 0x2c),*(undefined4 *)(param_1 + 0x30)),
          cVar2 != '\0')))) {
        return '\x03';
      }
      uVar3 = FUN_00ca1550();
      uVar3 = FUN_00b06640(uVar3);
      iVar4 = FUN_009ade20(uVar3);
      if ((iVar4 == 0) &&
         (cVar2 = FUN_00bb6fb0(iVar1,*(undefined8 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x2c)
                               ,*(undefined4 *)(param_1 + 0x30)), cVar2 != '\0')) {
        iVar4 = FUN_00ca1550();
        uStack_8 = *(undefined4 *)(iVar4 + 0x1dc);
        param_3 = 2;
        cVar2 = FUN_005e0cd0(&param_3);
        if ((cVar2 != '\0') &&
           ((iVar4 = FUN_00ca1550(), *(char *)(iVar4 + 0x22c) != '\x01' &&
            (*(int *)(iVar1 + 0x50) < 1)))) {
          return '\x02';
        }
      }
      if (*(char *)(iVar1 + 0x35) == '\0') {
        FUN_00ca1550();
        cVar2 = FUN_00c16180();
        if (cVar2 != '\0') {
          return '\t';
        }
        if (*(char *)(param_1 + 0xca) == '\0') {
          return '\x05';
        }
        cVar2 = FUN_00bb8480(iVar1);
        if (cVar2 != '\0') {
          return '\x05';
        }
        if (DAT_01d6f4f0 == '\0') {
          if (DAT_01d6f4e8 != '\0') {
            *(undefined *)(iVar1 + 0x39) = DAT_01d67b6c;
            return '\x05';
          }
          return '\x05';
        }
        FUN_00733c70(&param_2);
        return '\x05';
      }
      if ((*(char *)(param_1 + 0xca) != '\0') && (cVar2 = FUN_00bb8480(iVar1), cVar2 == '\0')) {
        if (DAT_01d6f4f0 == '\0') {
          if (DAT_01d6f4e8 != '\0') {
            *(undefined *)(iVar1 + 0x39) = DAT_01d67b6c;
            return '\a';
          }
        }
        else {
          FUN_00733c70(&param_2);
        }
      }
    }
    else {
      if ((char)param_3 != '\0') {
        FUN_00bb8d80();
      }
      FUN_00cdf460(iVar1);
      if (*(char *)(param_1 + 0xc9) == '\0') {
        return '\x01';
      }
      if (*(char *)(param_1 + 0x3c) == '\0') {
        return '\x01';
      }
      if (((*(char *)(param_1 + 0x3d) == '\0') && (*(int *)(param_1 + 0x38) != 0)) &&
         (iVar1 == *(int *)(param_1 + 0x38))) {
        return '\x01';
      }
      cVar2 = FUN_00bb6fb0(iVar1,*(undefined8 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x2c),
                           *(undefined4 *)(param_1 + 0x34));
      if (cVar2 != '\0') {
        return '\x01';
      }
      if (DAT_01d67b9c != '\0') {
        return '\b';
      }
    }
  }
  return '\a';
}



/* FUNCTION 26010 ; VA 0x00bb80a0 ; FUN_00bb80a0 */

void __fastcall FUN_00bb80a0(int param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  
  uVar4 = FUN_016f3cd0();
  FUN_00bb6620(*(int *)(param_1 + 0x94),*(int *)(param_1 + 0x98),
               (*(int *)(param_1 + 0x98) - *(int *)(param_1 + 0x94)) / 0x14,
               *(undefined *)(param_1 + 0x90));
  uStack_24 = 0;
  uStack_2c = 0;
  iStack_20 = *(int *)(param_1 + 0x94);
  iVar6 = *(int *)(param_1 + 0x98) - iStack_20;
  iVar5 = iVar6 >> 0x1f;
  if (iVar6 / 0x14 + iVar5 != iVar5) {
    iStack_28 = 0;
    do {
      puVar1 = (undefined8 *)(iStack_28 + iStack_20);
      if (DAT_01d68fec < *(int *)(iStack_28 + 0xc + iStack_20)) {
        if (uVar4 <= uStack_2c) break;
        uStack_2c = uStack_2c + 1;
      }
      uVar3 = *(undefined4 *)(puVar1 + 1);
      uVar2 = *puVar1;
      if ((uint)((*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 4) * 3) >> 2 <=
          *(uint *)(param_1 + 0xac)) {
        FUN_00bb8c00();
      }
      iVar5 = FUN_006b6b20(puVar1);
      uStack_24 = uStack_24 + 1;
      *(undefined8 *)(iVar5 + 4) = uVar2;
      *(undefined4 *)(iVar5 + 0xc) = uVar3;
      iStack_28 = iStack_28 + 0x14;
      iStack_20 = *(int *)(param_1 + 0x94);
    } while (uStack_24 < (uint)((*(int *)(param_1 + 0x98) - iStack_20) / 0x14));
  }
  *(int *)(param_1 + 0x98) = iStack_20;
  return;
}



/* FUNCTION 26011 ; VA 0x00bb8240 ; FUN_00bb8240 */

void __fastcall FUN_00bb8240(int param_1)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fda10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_01d67b7c != '\0') && (ExceptionList = &pvStack_10, *(char *)(param_1 + 0x10) == '\0')) {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined *)(param_1 + 0x10) = 1;
  }
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if (*(int *)(iVar1 + 0x34) < DAT_01ef36e0) {
    FUN_016f3809(&DAT_01ef36e0);
    cVar2 = DAT_01d7ad48;
    if (DAT_01ef36e0 == -1) {
      uStack_8 = 0;
      uVar5 = FUN_0152dab0(&DAT_018cb3fc,"SpatialFilter::filterStep",0xffffffff);
      if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532a30(uVar5);
      }
      uStack_8 = 0xffffffff;
      DAT_01ef36d8 = (int)uVar5;
      DAT_01ef36dc = (int)((ulonglong)uVar5 >> 0x20);
      FUN_016f37bf(&DAT_01ef36e0);
    }
  }
  uVar4 = DAT_01ef36dc;
  uVar3 = DAT_01ef36d8;
  cVar2 = DAT_01d7ad48;
  uVar5 = FUN_01532c80(DAT_01ef36d8,DAT_01ef36dc);
  uStack_8 = 1;
  FUN_00cea830();
  if (*(int *)(iVar1 + 0x34) < DAT_01ef36f0) {
    FUN_016f3809(&DAT_01ef36f0);
    if (DAT_01ef36f0 == -1) {
      uStack_8._0_1_ = 2;
      uVar6 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef36ec = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01ef36e8 = (undefined4)uVar6;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ef36f0);
    }
  }
  FUN_0152d760(DAT_01ef36e8,DAT_01ef36ec,"Broadphase Islands: %u",
               *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 0x6ac) + 0x22c));
  iVar1 = *(int *)(param_1 + 0x1c);
  if (iVar1 == 0) {
LAB_00bb8344:
    uVar7 = 1;
  }
  else {
    if (iVar1 != 1) {
      if (iVar1 != 2) {
        FUN_00bb7900();
        goto LAB_00bb834d;
      }
      goto LAB_00bb8344;
    }
    uVar7 = 5;
  }
  FUN_00bb84d0(uVar7);
LAB_00bb834d:
  uStack_8 = 3;
  FUN_0152dda0(uVar3,uVar4,uVar5);
  if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar3,uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26012 ; VA 0x00bb8460 ; FUN_00bb8460 */

void __thiscall FUN_00bb8460(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 200) = param_2;
  return;
}



/* FUNCTION 26013 ; VA 0x00bb8470 ; FUN_00bb8470 */

void __fastcall FUN_00bb8470(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00bb8479. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 8) + 0x10))();
  return;
}



/* FUNCTION 26014 ; VA 0x00bb8480 ; FUN_00bb8480 */

undefined4 __thiscall FUN_00bb8480(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 0xcc) == 0) {
    return 1;
  }
  uVar1 = FUN_00bb6fb0(param_2,*(undefined8 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x2c),
                       (float)*(int *)(param_1 + 0xcc) * *(float *)(param_1 + 0x30));
  return uVar1;
}



/* FUNCTION 26015 ; VA 0x00bb84d0 ; FUN_00bb84d0 */

int __thiscall FUN_00bb84d0(int param_1,int param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined8 *puVar4;
  uint uVar5;
  undefined8 *puVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined8 *puStack_24;
  undefined8 *puStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined8 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fda28;
  pvStack_10 = ExceptionList;
  iStack_28 = 0;
  puVar4 = (undefined8 *)0x0;
  puVar6 = (undefined8 *)0x0;
  puStack_14 = (undefined8 *)0x0;
  puStack_24 = (undefined8 *)0x0;
  puStack_20 = (undefined8 *)0x0;
  iVar7 = 0;
  piStack_18 = (int *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  do {
    if ((iVar7 != param_2) && (piVar8 = *(int **)*piStack_18, piVar8 != (int *)*piStack_18)) {
      do {
        iStack_34 = piVar8[4];
        iStack_2c = param_2;
        iStack_30 = iVar7;
        if (puVar4 == puVar6) {
          FUN_00bb5df0(puVar6,&iStack_34);
          puStack_14 = puStack_20;
        }
        else {
          *puVar6 = CONCAT44(iVar7,iStack_34);
          *(int *)(puVar6 + 1) = param_2;
          puStack_24 = (undefined8 *)((int)puVar6 + 0xc);
        }
        piVar2 = (int *)piVar8[2];
        if (*(char *)((int)piVar2 + 0xd) == '\0') {
          cVar1 = *(char *)(*piVar2 + 0xd);
          piVar8 = piVar2;
          piVar2 = (int *)*piVar2;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*piVar2 + 0xd);
            piVar8 = piVar2;
            piVar2 = (int *)*piVar2;
          }
        }
        else {
          cVar1 = *(char *)(piVar8[1] + 0xd);
          piVar3 = (int *)piVar8[1];
          piVar2 = piVar8;
          while ((piVar8 = piVar3, cVar1 == '\0' && (piVar2 == (int *)piVar8[2]))) {
            cVar1 = *(char *)(piVar8[1] + 0xd);
            piVar3 = (int *)piVar8[1];
            piVar2 = piVar8;
          }
        }
        puVar4 = puStack_14;
        puVar6 = puStack_24;
      } while (piVar8 != (int *)*piStack_18);
    }
    iVar7 = iVar7 + 1;
    piStack_18 = piStack_18 + 2;
  } while (iVar7 < 10);
  iVar7 = ((int)puVar6 - iStack_28) * 0x2aaaaaab;
  iVar9 = iStack_28;
  for (iVar10 = ((int)puVar6 - iStack_28) / 0xc; iVar10 != 0; iVar10 = iVar10 + -1) {
    iVar7 = FUN_00bb70e0(iVar9);
    iVar9 = iVar9 + 0xc;
  }
  if (iStack_28 != 0) {
    uVar5 = (((int)puStack_14 - iStack_28) / 0xc) * 0xc;
    iVar7 = iStack_28;
    if (0xfff < uVar5) {
      iVar7 = *(int *)(iStack_28 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_28 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar7 = FUN_01674ea0(iVar7,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 26016 ; VA 0x00bb8660 ; FUN_00bb8660 */

void __thiscall FUN_00bb8660(int param_1,int *param_2)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  int *piVar12;
  int iVar13;
  undefined4 uVar14;
  int iVar15;
  undefined4 uVar16;
  int iVar17;
  undefined4 uStack_34;
  undefined4 uStack_30;
  
  piVar12 = param_2;
  iVar13 = 4;
  piVar1 = param_2 + 1;
  if (*(int *)(param_1 + 0x1c) == 4) {
    iVar13 = 10;
  }
  iVar3 = param_2[2];
  if ((iVar13 <= iVar3) && (*piVar1 < iVar13)) {
    FUN_00ce90e0(*param_2,1);
    goto LAB_00bb86d9;
  }
  if ((*piVar1 < iVar13) || (iVar13 <= iVar3)) {
    if (*piVar1 < 2) {
      if (1 < iVar3) goto LAB_00bb86c4;
    }
    else if (iVar3 < 2) goto LAB_00bb86c4;
  }
  else {
LAB_00bb86c4:
    FUN_00ce90e0(*param_2,0);
  }
LAB_00bb86d9:
  iVar13 = *piVar1;
  if ((iVar13 == 4) || (bVar4 = false, iVar13 == 6)) {
    bVar4 = true;
  }
  if ((((iVar13 == 1) || (iVar13 == 2)) || (iVar13 == 0)) || (bVar6 = false, iVar13 == 3)) {
    bVar6 = true;
  }
  if ((((iVar13 == 4) || (iVar13 == 6)) || ((iVar13 == 5 || ((iVar13 == 7 || (iVar13 == 8)))))) ||
     (bVar8 = false, iVar13 == 9)) {
    bVar8 = true;
  }
  if (((iVar13 == 6) || (iVar13 == 7)) || (bVar10 = false, iVar13 == 8)) {
    bVar10 = true;
  }
  iVar3 = param_2[2];
  if ((iVar3 == 4) || (bVar5 = false, iVar3 == 6)) {
    bVar5 = true;
  }
  if (((iVar3 == 1) || (iVar3 == 2)) || ((iVar3 == 0 || (bVar7 = false, iVar3 == 3)))) {
    bVar7 = true;
  }
  if (((((iVar3 == 4) || (iVar3 == 6)) || (iVar3 == 5)) || ((iVar3 == 7 || (iVar3 == 8)))) ||
     (bVar9 = false, iVar3 == 9)) {
    bVar9 = true;
  }
  if (((iVar3 == 6) || (iVar3 == 7)) || (bVar11 = false, iVar3 == 8)) {
    bVar11 = true;
  }
  if (DAT_01d69070 != '\0') {
    param_2 = (int *)((uint)(iVar13 == 0xc) << 0x18);
    if (((iVar3 == 0xb) == (iVar13 == 0xb)) || (iVar13 == 0xc)) {
      if (iVar3 != 0xc) goto LAB_00bb88a1;
    }
    else if (iVar3 != 0xc) {
      param_2 = (int *)0x1000000;
    }
    iVar17 = *(int *)(param_1 + 0xc);
    uVar16 = *(undefined4 *)(iVar17 + 0x6ac);
    iVar15 = *piVar12;
    if (iVar13 == 0xb) {
      if (DAT_01d69098 != '\0') {
        FUN_00ce61b0(iVar15);
      }
      FUN_00ce6740(iVar15);
      uVar14 = FUN_00ca1550();
      FUN_00bb69e0(uVar16,iVar17,uVar14,0);
    }
    else {
      if (iVar15 == -0xc) {
        iVar15 = 0;
      }
      if (DAT_01d69098 != '\0') {
        FUN_00ce61b0(iVar15);
      }
      FUN_00ce6740(iVar15);
      uVar14 = FUN_00ca1550();
      FUN_00bb69e0(uVar16,iVar17,uVar14,0);
      FUN_00bb6860(uVar16,iVar17);
    }
  }
LAB_00bb88a1:
  if ((1 < *piVar1) && (piVar12[2] < 2)) {
    uVar16 = FUN_00ca1550();
    FUN_00c17230(uVar16);
  }
  if (((DAT_01d67b8c == '\0') && (bVar4)) && (!bVar5)) {
    FUN_00bbddb0();
    FUN_01018040(*piVar12);
  }
  if ((!bVar6) || (bVar7)) {
    if ((!bVar8) || (bVar9)) {
      if ((iVar13 == 0xb) && (iVar3 != 0xb)) {
        FUN_01018390(*piVar12);
        *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + -1;
      }
    }
    else {
      FUN_01018410(*piVar12);
    }
    if ((bVar10) && (!bVar11)) {
      uVar16 = FUN_00ca1550();
      FUN_00bb6b30(param_1,uVar16,0);
    }
  }
  else {
    FUN_010184b0(*piVar12);
  }
  if (((DAT_01d67b8c == '\0') && (bVar5)) && (!bVar4)) {
    FUN_00bbddb0();
    FUN_01017fa0(*piVar12);
  }
  if ((!bVar7) || (bVar6)) {
    if ((!bVar9) || (bVar8)) {
      if ((iVar3 == 0xb) && (iVar13 != 0xb)) {
        FUN_01018370(*piVar12);
        *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 1;
      }
    }
    else {
      FUN_010183b0(*piVar12);
    }
    if ((bVar11) && (!bVar10)) {
      uVar16 = FUN_00ca1550();
      FUN_00bb6a70(param_1,uVar16,0);
    }
  }
  else {
    FUN_01018450(*piVar12);
    if (DAT_01d69070 == '\0') {
      return;
    }
    if (param_2._3_1_ == '\0') {
      iVar13 = *piVar12;
      uVar16 = *(undefined4 *)(*(int *)(param_1 + 0xc) + 0x6ac);
      if (iVar13 == -0xc) {
        iVar13 = 0;
      }
      FUN_00ce67c0(iVar13);
      FUN_00bb6910(uVar16);
    }
  }
  if ((DAT_01d69070 != '\0') && (param_2._3_1_ != '\0')) {
    uVar2 = *(undefined8 *)piVar12;
    uVar16 = *(undefined4 *)(*(int *)(param_1 + 0xc) + 0x6ac);
    iVar13 = piVar12[2];
    iVar17 = *piVar12;
    if (iVar3 == 0xb) {
      FUN_00ce6560(iVar17);
      return;
    }
    if (iVar17 == -0xc) {
      iVar17 = 0;
    }
    FUN_00ce6560(iVar17);
    uStack_34 = (undefined4)uVar2;
    uStack_30 = (undefined4)((ulonglong)uVar2 >> 0x20);
    FUN_00bb6970(uVar16,uStack_34,uStack_30,iVar13);
  }
  return;
}



/* FUNCTION 26017 ; VA 0x00bb8ac0 ; FUN_00bb8ac0 */

void __thiscall FUN_00bb8ac0(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(int *)(param_2 + 4) != 0) {
    if (DAT_01d67ba4 != '\0') {
      cVar1 = FUN_00c1a1b0(param_2);
      uVar2 = FUN_00ca1550();
      FUN_005e66b0(uVar2,cVar1 == '\0');
    }
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
    uStack_c = *(undefined4 *)(param_2 + 0x3c);
    iStack_10 = param_2;
    uStack_8 = 0xc;
    FUN_00bb70e0(&iStack_10);
    FUN_00ffd800(param_1);
  }
  return;
}



/* FUNCTION 26018 ; VA 0x00bb8b30 ; FUN_00bb8b30 */

void __thiscall FUN_00bb8b30(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_00598640(param_1);
  uStack_10 = param_2;
  uStack_c = 0xc;
  uStack_8 = 0xb;
  FUN_00bb70e0(&uStack_10);
  if (DAT_01d67ba4 != '\0') {
    uVar1 = FUN_00ca1550();
    FUN_005e66b0(uVar1,1);
  }
  return;
}



/* FUNCTION 26019 ; VA 0x00bb8b90 ; FUN_00bb8b90 */

void __thiscall FUN_00bb8b90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 1;
  FUN_00598640(param_1);
  uStack_10 = param_2;
  uStack_c = 0xc;
  uStack_8 = FUN_00bb7c70(param_2,0,param_3,param_4);
  FUN_00bb70e0(&uStack_10);
  if (DAT_01d67ba4 != '\0') {
    uVar1 = FUN_00ca1550();
    FUN_005e66b0(uVar1,0);
  }
  return;
}



/* FUNCTION 26020 ; VA 0x00bb8c00 ; FUN_00bb8c00 */

void __fastcall FUN_00bb8c00(int *param_1)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 4) * 2;
  }
  iStack_44 = param_1[4];
  uStack_28 = 0;
  uStack_24 = 0xc;
  uStack_40 = 0xc00000000;
  uStack_38 = 0xc;
  piStack_1c = param_1;
  FUN_006b3040(iVar5,&iStack_44,&uStack_5);
  uStack_18 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 4 != 0) {
    iStack_14 = 0;
    do {
      uVar4 = *(uint *)(iVar5 + iStack_14);
      puStack_c = (uint *)(iVar5 + iStack_14);
      if (uVar4 != param_1[4]) {
        uVar3 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_30 - iStack_34 >> 4) - 1;
        uVar6 = 0;
        do {
          uVar3 = uVar3 & uVar7;
          puVar2 = (uint *)(uVar3 * 0x10 + iStack_34);
          if (*puVar2 == uStack_18) {
            *puVar2 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_00bb8cd1;
          }
          if (*puVar2 == uVar4) goto LAB_00bb8cd1;
          uVar3 = uVar3 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar2 = (uint *)0x0;
LAB_00bb8cd1:
        *puVar2 = uVar4;
        *(undefined8 *)(puVar2 + 1) = *(undefined8 *)(puStack_c + 1);
        puVar2[3] = puStack_c[3];
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      iStack_14 = iStack_14 + 0x10;
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 4));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    param_1[1] = iStack_30;
    iVar1 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_2c = iVar1;
    iStack_34 = iVar5;
  }
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34 & 0xfffffff0;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 26021 ; VA 0x00bb8d70 ; FUN_00bb8d70 */

void __thiscall FUN_00bb8d70(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc9) = param_2;
  return;
}



/* FUNCTION 26022 ; VA 0x00bb8d80 ; FUN_00bb8d80 */

void __thiscall
FUN_00bb8d80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_0074b510(param_1);
  if ((iVar1 == 4) || (uVar2 = 0, iVar1 == 5)) {
    uVar2 = 1;
  }
  FUN_00bb8dc0(param_2,param_3,param_4,uVar2);
  return;
}



/* FUNCTION 26023 ; VA 0x00bb8dc0 ; FUN_00bb8dc0 */

void FUN_00bb8dc0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  iVar1 = *(int *)(param_1 + 0x14);
  if (0 < iVar1) {
    do {
      iVar2 = *(int *)(*(int *)(param_1 + 0x10) + iVar3 * 4);
      FUN_00bb8dc0(-(uint)(iVar2 != 0) & iVar2 - 8U,param_2,param_3,param_4);
      iVar3 = iVar3 + 1;
    } while (iVar3 < iVar1);
  }
  FUN_00ca1550();
  FUN_00c185b0(param_4,param_2,param_3);
  return;
}



/* FUNCTION 26024 ; VA 0x00bb8e20 ; FUN_00bb8e20 */

undefined4 * __thiscall FUN_00bb8e20(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *(undefined *)(param_1 + 6) = *(undefined *)(param_2 + 6);
  return param_1;
}



/* FUNCTION 26025 ; VA 0x00bb8e70 ; FUN_00bb8e70 */

void __thiscall FUN_00bb8e70(int *param_1,int *param_2,int *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  uVar6 = 0;
  piVar4 = param_2;
  if (param_2 != param_3) {
    do {
      piVar4 = (int *)*piVar4;
      uVar6 = uVar6 + 1;
    } while (piVar4 != param_3);
  }
  piVar4 = (int *)*param_1;
  uVar1 = param_1[2] - (int)piVar4 >> 2;
  uVar3 = param_1[1] - (int)piVar4 >> 2;
  if (uVar6 <= uVar1) {
    piVar5 = param_2;
    if (uVar3 < uVar6) {
      for (; 0 < (int)uVar3; uVar3 = uVar3 - 1) {
        piVar5 = (int *)*piVar5;
      }
      if (param_2 != piVar5) {
        do {
          *piVar4 = param_2[2];
          param_2 = (int *)*param_2;
          piVar4 = piVar4 + 1;
        } while (param_2 != piVar5);
      }
      piVar4 = (int *)param_1[1];
      for (; piVar5 != param_3; piVar5 = (int *)*piVar5) {
        *piVar4 = piVar5[2];
        piVar4 = piVar4 + 1;
      }
      param_1[1] = (int)piVar4;
      return;
    }
    piVar5 = piVar4;
    if (param_2 != param_3) {
      do {
        *piVar5 = param_2[2];
        param_2 = (int *)*param_2;
        piVar5 = piVar5 + 1;
      } while (param_2 != param_3);
    }
    param_1[1] = (int)(piVar4 + uVar6);
    return;
  }
  if (uVar6 < 0x40000000) {
    uVar3 = uVar6;
    if ((uVar1 <= 0x3fffffff - (uVar1 >> 1)) && (uVar3 = (uVar1 >> 1) + uVar1, uVar3 < uVar6)) {
      uVar3 = uVar6;
    }
    if (piVar4 != (int *)0x0) {
      FUN_0057d270(piVar4,uVar1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar3 != 0) {
      if (0x3fffffff < uVar3) goto LAB_00bb8fdf;
      iVar2 = FUN_00577ed0(uVar3);
      *param_1 = iVar2;
      param_1[1] = iVar2;
      param_1[2] = *param_1 + uVar3 * 4;
    }
    piVar4 = (int *)*param_1;
    if (param_2 != param_3) {
      do {
        *piVar4 = param_2[2];
        piVar4 = piVar4 + 1;
        param_2 = (int *)*param_2;
      } while (param_2 != param_3);
    }
    param_1[1] = (int)piVar4;
    return;
  }
LAB_00bb8fdf:
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 26026 ; VA 0x00bb8ff0 ; FUN_00bb8ff0 */

void FUN_00bb8ff0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  
  iVar1 = FUN_0068a6a0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *(undefined4 *)*param_4;
  *(undefined8 *)(iVar1 + 0xc) = 0;
  return;
}



/* FUNCTION 26027 ; VA 0x00bb9020 ; FUN_00bb9020 */

void __thiscall FUN_00bb9020(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fda40;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        puStack_14 = &stack0xffffffd0;
        FUN_01674ea0(param_4,0x14);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00bb9020(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26028 ; VA 0x00bb9206 ; Catch_All@00bb9206 */

void Catch_All_00bb9206(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00bb95b0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26029 ; VA 0x00bb9230 ; FUN_00bb9230 */

void __thiscall FUN_00bb9230(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  int iVar9;
  uint uVar10;
  uint uStack_8;
  
  puVar8 = (undefined8 *)param_1[1];
  iVar9 = *param_1;
  uVar10 = (int)puVar8 - iVar9 >> 4;
  uStack_8 = param_1[2] - iVar9 >> 4;
  if (param_2 <= uStack_8) {
    if (uVar10 < param_2) {
      for (iVar9 = param_2 - uVar10; iVar9 != 0; iVar9 = iVar9 + -1) {
        *(undefined4 *)((int)puVar8 + 0xc) = 0;
        *puVar8 = 0;
        *(undefined4 *)(puVar8 + 1) = 0;
        puVar8 = puVar8 + 2;
      }
      param_1[1] = (int)puVar8;
      return;
    }
    if (param_2 != uVar10) {
      param_1[1] = param_2 * 0x10 + iVar9;
    }
    return;
  }
  if (param_2 < 0x10000000) {
    if (0xfffffff - (uStack_8 >> 1) < uStack_8) {
      uStack_8 = param_2;
    }
    else {
      uStack_8 = (uStack_8 >> 1) + uStack_8;
      if (uStack_8 < param_2) {
        uStack_8 = param_2;
      }
    }
    iVar5 = FUN_0078e090(uStack_8);
    puVar8 = (undefined8 *)(uVar10 * 0x10 + iVar5);
    for (iVar9 = param_2 - uVar10; iVar9 != 0; iVar9 = iVar9 + -1) {
      *(undefined4 *)((int)puVar8 + 0xc) = 0;
      *puVar8 = 0;
      *(undefined4 *)(puVar8 + 1) = 0;
      puVar8 = puVar8 + 2;
    }
    puVar6 = (undefined4 *)*param_1;
    puVar7 = (undefined4 *)param_1[1];
    if (puVar6 != puVar7) {
      iVar9 = iVar5 - (int)puVar6;
      do {
        uVar2 = puVar6[1];
        uVar3 = puVar6[2];
        uVar4 = puVar6[3];
        puVar1 = (undefined4 *)((int)puVar6 + iVar9);
        *puVar1 = *puVar6;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
        puVar6 = puVar6 + 4;
      } while (puVar6 != puVar7);
      puVar6 = (undefined4 *)*param_1;
    }
    if (puVar6 != (undefined4 *)0x0) {
      uVar10 = param_1[2] - (int)puVar6 & 0xfffffff0;
      puVar7 = puVar6;
      if (0xfff < uVar10) {
        puVar7 = (undefined4 *)puVar6[-1];
        uVar10 = uVar10 + 0x23;
        if (0x1f < (uint)((int)puVar6 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar7,uVar10);
    }
    *param_1 = iVar5;
    param_1[1] = param_2 * 0x10 + iVar5;
    param_1[2] = uStack_8 * 0x10 + iVar5;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 26030 ; VA 0x00bb9390 ; FUN_00bb9390 */

void FUN_00bb9390(undefined4 param_1,int *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_2 + 4) = iVar1;
  *(int *)*param_2 = iVar1;
  *(int *)(*param_2 + 8) = iVar1;
  param_2[1] = 0;
  FUN_01674ea0(*param_2,0x1b8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26031 ; VA 0x00bb9400 ; FUN_00bb9400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00bb9400(byte *param_1,int *param_2,int param_3,int param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fda58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar4,iVar6,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    FUN_005d2a40();
    iVar6 = param_4;
    FUN_0054ef60(param_4);
    DAT_00000020 = *(undefined *)(iVar6 + 0x18);
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      uVar7 = uVar1 >> 1;
      if (uVar7 + uVar1 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar7 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar8;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar8;
            puVar8 = puVar2;
          }
          else {
            *puVar8 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar5 = uVar4 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar4;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar3;
      _DAT_00000000 = *piVar3;
      *piVar3 = 0;
    }
    else {
      _DAT_00000000 = *piVar3;
      *(undefined4 *)*puVar8 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26032 ; VA 0x00bb95b0 ; FUN_00bb95b0 */

void __thiscall FUN_00bb95b0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_01674ea0(param_3,0x14);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 26033 ; VA 0x00bb9660 ; FUN_00bb9660 */

code * FUN_00bb9660(int *param_1,int *param_2,code *param_3)

{
  int *piVar1;
  
  if (param_1 == param_2) {
    return param_3;
  }
  do {
    if (param_1 == (int *)0x0) {
      piVar1 = (int *)0x0;
    }
    else {
      piVar1 = param_1 + -0xb;
    }
    (*param_3)(piVar1);
    param_1 = (int *)*param_1;
  } while (param_1 != param_2);
  return param_3;
}



/* FUNCTION 26034 ; VA 0x00bb96a0 ; thunk_FUN_00bc0d60 */

undefined * thunk_FUN_00bc0d60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe0ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3a74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef3a74);
    if (DAT_01ef3a74 == -1) {
      uStack_8 = 0;
      FUN_00911610();
      FUN_016f3654(&LAB_01891d40);
      FUN_016f37bf(&DAT_01ef3a74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef3a10;
}



/* FUNCTION 26035 ; VA 0x00bb96b0 ; FUN_00bb96b0 */

void FUN_00bb96b0(int *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)*puVar2;
  do {
    do {
      while( true ) {
        puVar5 = puVar3;
        if (puVar5 == puVar2) {
          return;
        }
        FUN_00ca1b70();
        puVar3 = (undefined4 *)puVar5[2];
        if (*(char *)((int)puVar3 + 0xd) != '\0') break;
        cVar1 = *(char *)((int)*puVar3 + 0xd);
        puVar5 = (undefined4 *)*puVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((int)*puVar5 + 0xd);
          puVar3 = puVar5;
          puVar5 = (undefined4 *)*puVar5;
        }
      }
      puVar3 = (undefined4 *)puVar5[1];
    } while (*(char *)((int)puVar3 + 0xd) != '\0');
    do {
      puVar4 = puVar3;
      puVar3 = puVar4;
      if (puVar5 != (undefined4 *)puVar4[2]) break;
      puVar3 = (undefined4 *)puVar4[1];
      puVar5 = puVar4;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  } while( true );
}



/* FUNCTION 26036 ; VA 0x00bb9720 ; FUN_00bb9720 */

void FUN_00bb9720(int *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)*puVar2;
  while (puVar3 != puVar2) {
    if (*(char *)(puVar3[4] + 0x78) == '\0') {
      FUN_00ca1b70();
    }
    puVar4 = (undefined4 *)puVar3[2];
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar3 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar3 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar3[1] + 0xd);
      puVar5 = (undefined4 *)puVar3[1];
      puVar4 = puVar3;
      while ((puVar3 = puVar5, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar3[2]))) {
        cVar1 = *(char *)((int)puVar3[1] + 0xd);
        puVar5 = (undefined4 *)puVar3[1];
        puVar4 = puVar3;
      }
    }
  }
  return;
}



/* FUNCTION 26037 ; VA 0x00bb9790 ; FUN_00bb9790 */

void FUN_00bb9790(void)

{
  undefined *puVar1;
  int *in_stack_00000028;
  undefined *in_stack_0000002c;
  undefined auStack_48 [36];
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fda80;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uStack_1c = 0xbb97b8;
  ExceptionList = &pvStack_10;
  uStack_20 = FUN_00ca1550();
  uStack_1c = (uint)in_stack_0000002c;
  in_stack_0000002c = auStack_48;
  uStack_24 = 0;
  iStack_8._0_1_ = 1;
  puVar1 = auStack_48;
  if (in_stack_00000028 != (int *)0x0) {
    uStack_24 = (**(code **)*in_stack_00000028)(auStack_48);
    puVar1 = in_stack_0000002c;
  }
  in_stack_0000002c = puVar1;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00bb9950();
  if (in_stack_00000028 != (int *)0x0) {
    uStack_1c = (uint)(in_stack_00000028 != (int *)&stack0x00000004);
    uStack_20 = 0xbb9801;
    (**(code **)(*in_stack_00000028 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26038 ; VA 0x00bb9820 ; FUN_00bb9820 */

void FUN_00bb9820(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  
  iVar2 = param_2;
  if ((param_3 == 0) ||
     (((param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
      (iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar4 != 10)))) {
    param_2 = iVar2;
    FUN_007c5360(&param_2);
  }
  iVar4 = 0;
  if (0 < *(int *)(iVar2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(iVar2 + 0x10) + iVar4 * 4);
      uVar5 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar3 = FUN_00ca1a80(uVar5);
      if (cVar3 == '\0') {
        FUN_00bb9820(param_1,uVar5,param_3);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(iVar2 + 0x14));
  }
  return;
}



/* FUNCTION 26039 ; VA 0x00bb98b0 ; FUN_00bb98b0 */

void FUN_00bb98b0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  
  iVar3 = param_2;
  if ((param_3 == 0) ||
     (((param_2 = iVar3, param_3 == 1 && (*(int *)(param_2 + 0x1b0) != 0)) &&
      (iVar5 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar5 != 10)))) {
    piVar1 = *(int **)(param_1 + 4);
    if (*(int **)(param_1 + 8) == piVar1) {
      param_2 = iVar3;
      FUN_0063d9b0(piVar1,&param_2);
    }
    else {
      *piVar1 = iVar3;
      *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
      param_2 = iVar3;
    }
  }
  iVar5 = 0;
  if (0 < *(int *)(iVar3 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(iVar3 + 0x10) + iVar5 * 4);
      uVar6 = -(uint)(iVar2 != 0) & iVar2 - 8U;
      cVar4 = FUN_00ca1a80(uVar6);
      if (cVar4 == '\0') {
        FUN_00bb98b0(param_1,uVar6,param_3);
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < *(int *)(iVar3 + 0x14));
  }
  return;
}



/* FUNCTION 26040 ; VA 0x00bb9950 ; FUN_00bb9950 */

void FUN_00bb9950(void)

{
  int iVar1;
  undefined *puVar2;
  undefined *puVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  int *in_stack_00000028;
  undefined *in_stack_0000002c;
  int in_stack_00000030;
  undefined auStack_50 [36];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar2 = in_stack_0000002c;
  puStack_c = &LAB_017fda80;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000030 != 0) {
    ExceptionList = &pvStack_10;
    if ((in_stack_00000030 != 1) ||
       (ExceptionList = &pvStack_10, *(int *)(in_stack_0000002c + 0x1b0) == 0)) goto LAB_00bb99b5;
    puStack_24 = (undefined4 *)0xbb9999;
    ExceptionList = &pvStack_10;
    iVar5 = (**(code **)(**(int **)(in_stack_0000002c + 0x1ac) + 8))();
    if (iVar5 == 10) goto LAB_00bb99b5;
  }
  in_stack_0000002c = puVar2;
  if (in_stack_00000028 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
    puStack_24 = (undefined4 *)&UNK_00bb9a44;
    FUN_016ddc9c();
  }
  puStack_24 = &stack0x0000002c;
  uStack_28 = 0xbb99b5;
  (**(code **)(*in_stack_00000028 + 8))();
LAB_00bb99b5:
  iVar5 = 0;
  if (0 < *(int *)(puVar2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(puVar2 + 0x10) + iVar5 * 4);
      uVar6 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      uStack_28 = 0xbb99d5;
      puStack_24 = (undefined4 *)uVar6;
      cVar4 = FUN_00ca1a80();
      if (cVar4 == '\0') {
        puStack_24 = (undefined4 *)in_stack_00000030;
        in_stack_0000002c = auStack_50;
        uStack_2c = 0;
        iStack_8._0_1_ = 1;
        puVar3 = auStack_50;
        uStack_28 = uVar6;
        if (in_stack_00000028 != (int *)0x0) {
          uStack_2c = (**(code **)*in_stack_00000028)(auStack_50);
          puVar3 = in_stack_0000002c;
        }
        in_stack_0000002c = puVar3;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_00bb9950();
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < *(int *)(puVar2 + 0x14));
  }
  if (in_stack_00000028 != (int *)0x0) {
    puStack_24 = (undefined4 *)(uint)(in_stack_00000028 != (int *)&stack0x00000004);
    uStack_28 = 0xbb9a2c;
    (**(code **)(*in_stack_00000028 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26041 ; VA 0x00bb9a50 ; FUN_00bb9a50 */

undefined * __fastcall FUN_00bb9a50(undefined *param_1)

{
  *param_1 = 0;
  *(undefined4 *)(param_1 + 4) = 0xffffffff;
  return param_1;
}



/* FUNCTION 26042 ; VA 0x00bb9a60 ; FUN_00bb9a60 */

int * __thiscall FUN_00bb9a60(int *param_1,int param_2)

{
  float fVar1;
  int iVar2;
  
  *param_1 = param_2;
  param_1[1] = 2;
  param_1[2] = 0x3c;
  iVar2 = DAT_01ef36fc;
  if (DAT_01ef36fc < 1) {
    if (param_2 == 1) {
      iVar2 = 2;
    }
    else if (param_2 == 2) {
      iVar2 = 1;
    }
    else {
      iVar2 = 4;
    }
    param_1[4] = iVar2;
  }
  else {
    param_1[4] = DAT_01ef36fc;
  }
  fVar1 = DAT_018ce2f8;
  param_1[3] = (int)(4 / (longlong)iVar2);
  param_1[5] = iVar2 * 2;
  param_1[6] = iVar2 * 0x3c;
  param_1[7] = (int)(fVar1 / (float)(iVar2 * 0x3c));
  return param_1;
}



/* FUNCTION 26043 ; VA 0x00bb9af0 ; FUN_00bb9af0 */

undefined4 * __thiscall FUN_00bb9af0(undefined4 *param_1,undefined4 *param_2)

{
  float fVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017fdd78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 1;
  uVar4 = 1;
  param_1[10] = 1;
  if (DAT_01ef3704 == 0) {
    uVar4 = 100000000;
  }
  param_1[9] = uVar4;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xb] = 0;
  uVar2 = DAT_018e2378;
  uStack_8 = 8;
  uStack_7 = 0;
  *(undefined *)(param_1 + 0xe) = 0;
  param_1[0xf] = 0;
  *(undefined2 *)(param_1 + 0x10) = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0x40800000;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0x3dcccccd;
  param_1[0x1f] = 0x40000000;
  param_1[0x20] = 0x395a740e;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  *(undefined8 *)(param_1 + 0x24) = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  *(undefined8 *)(param_1 + 0x2c) = uVar2;
  *(undefined8 *)(param_1 + 0x2e) = 0;
  puStack_18 = param_1;
  piVar5 = (int *)FUN_01674e20(4);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)0x0;
  }
  else {
    *piVar5 = (int)(piVar5 + -0xf018000);
  }
  param_1[0x30] = piVar5;
  puStack_1c = param_1 + 0x32;
  param_1[0x31] = DAT_01d67c6c;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  *puStack_1c = 0;
  uStack_8 = 10;
  puStack_1c = (undefined4 *)FUN_01674e20(0x240);
  uStack_8 = 0xb;
  if (puStack_1c == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00c130d0(3);
  }
  param_1[0x35] = uVar4;
  _uStack_8 = CONCAT31(uStack_7,10);
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  *(undefined2 *)(param_1 + 0x3a) = 0;
  FUN_016830f0(param_1 + 0x3c);
  FUN_016830f0(param_1 + 0x3e);
  param_1[0x40] = 0;
  *(undefined8 *)(param_1 + 0x42) = 0;
  param_1[0x44] = 0;
  iVar7 = 0x20;
  do {
    FUN_00bb9a50();
    puVar3 = puStack_18;
    iVar7 = iVar7 + -1;
  } while (iVar7 != 0);
  *(undefined *)(puStack_18 + 0x85) = 0;
  uVar4 = FUN_00588320(0xb);
  puVar3[0x86] = uVar4;
  puVar3[0x87] = 0;
  puVar3[0x88] = 0x3f800000;
  puVar3[0x89] = 0;
  puVar3[0x8a] = 0;
  puVar3[0x8b] = 0;
  puVar3[0x8c] = 0;
  puVar3[0x8d] = 0;
  uStack_8 = 0xe;
  FUN_016f4053(puVar3 + 0x8e,0x18,0x20,FUN_0054f030,FUN_005507b0);
  uStack_8 = 0xf;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00806e90(0x20,&uStack_2c,&uStack_11);
  puVar3[0x171] = 0;
  puVar3[0x172] = 0;
  puVar3[0x173] = 0;
  puVar3[0x175] = 0;
  puVar3[0x178] = 0;
  *(undefined8 *)(puVar3 + 0x176) = 0;
  puVar3[0x17a] = 0;
  puVar3[0x17b] = 0;
  puVar3[0x17c] = 0;
  puVar3[0x17d] = 0;
  puVar3[0x17e] = 2;
  puVar3[0x17f] = 0x3c;
  iVar7 = DAT_01ef36fc;
  if (DAT_01ef36fc < 1) {
    puVar3[0x181] = 4;
    iVar7 = 4;
  }
  else {
    puVar3[0x181] = DAT_01ef36fc;
  }
  fVar1 = DAT_018ce2f8;
  puVar3[0x180] = (int)(4 / (longlong)iVar7);
  puVar3[0x183] = iVar7 * 0x3c;
  puVar3[0x182] = iVar7 * 2;
  puVar3[0x184] = fVar1 / (float)(iVar7 * 0x3c);
  puVar3[0x185] = 0;
  puVar3[0x186] = 0;
  puVar3[0x187] = 0;
  puVar3[0x188] = 0;
  puVar3[0x189] = 0;
  puVar3[0x18a] = 0;
  puVar3[0x18c] = 0;
  puVar3[0x18d] = 0;
  puVar3[0x18b] = 0;
  puVar3[0x18e] = 0;
  puVar3[399] = 0;
  puVar3[400] = 0;
  puVar3[0x191] = 0;
  puVar3[0x192] = 0;
  puVar3[0x194] = 0;
  puVar3[0x195] = 0;
  puVar3[0x193] = 0;
  puVar3[0x197] = 0;
  puVar3[0x198] = 0;
  puVar3[0x196] = 0;
  puVar3[0x19a] = 0;
  puVar3[0x19b] = 0;
  puVar3[0x199] = 0;
  *(undefined *)(puVar3 + 0x19c) = 0;
  uVar4 = FUN_00588320(0xb);
  puVar3[0x19d] = uVar4;
  puVar3[0x19e] = 0;
  puVar3[0x19f] = 0x3f800000;
  puVar3[0x1a0] = 0;
  puVar3[0x1a1] = 0;
  *(undefined *)(puVar3 + 0x1a2) = 0;
  uVar4 = FUN_00588320(0xb);
  puVar3[0x1a3] = uVar4;
  puVar3[0x1a4] = 0;
  puVar3[0x1a5] = 0x3f800000;
  puVar3[0x1a6] = 0;
  puVar3[0x1a7] = 0;
  puVar3[0x1a8] = 0;
  puVar3[0x1a9] = 0;
  puVar3[0x1aa] = 0;
  uStack_8 = 0x1b;
  puStack_1c = (undefined4 *)FUN_01674e20(0x44);
  uStack_8 = 0x1c;
  if (puStack_1c == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01017e50();
  }
  puVar3[0x1ac] = uVar4;
  puVar3[0x1bc] = 0;
  puVar3[0x1bd] = 0xffffffff;
  puVar3[0x1be] = 0;
  puVar3[0x1bf] = 0;
  puVar3[0x1c0] = 0;
  puVar3[0x1c1] = 0;
  puVar3[0x1c2] = 0;
  puVar8 = puVar3 + 0x1c3;
  *puVar8 = 0;
  uStack_8 = 0x1b;
  puVar3[0x1c4] = 0;
  puVar3[0x1c5] = 0;
  puStack_20 = puVar8;
  puStack_1c = puVar8;
  uVar4 = FUN_00575b50(0,0);
  puVar3[0x1c4] = uVar4;
  puVar3[0x1c6] = 0;
  puVar3[0x1c7] = 0;
  puVar3[0x1c8] = 0;
  uStack_8 = 0x1e;
  *puVar8 = 0x3f800000;
  FUN_005cb500(8);
  puVar8 = puVar3 + 0x1cb;
  uStack_8 = 0x1f;
  *puVar8 = 0;
  puVar3[0x1cc] = 0;
  puVar3[0x1cd] = 0;
  puVar3[0x1ce] = 0;
  puVar3[0x1cf] = 0;
  puStack_20 = puVar8;
  puVar6 = (undefined4 *)FUN_01674e20(8);
  *puVar8 = puVar6;
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 **)*puVar8 = puVar8;
  puVar8 = puVar3 + 0x1d0;
  uStack_8 = 0x20;
  *puVar8 = 0;
  puVar3[0x1d1] = 0;
  puVar3[0x1d2] = 0;
  puStack_20 = puVar8;
  uVar4 = FUN_0068a6a0(0,0);
  puVar3[0x1d1] = uVar4;
  puVar3[0x1d3] = 0;
  puVar3[0x1d4] = 0;
  puVar3[0x1d5] = 0;
  uStack_8 = 0x22;
  *puVar8 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = 0x23;
  puStack_20 = (undefined4 *)FUN_01674e20(0x284);
  puVar3 = puStack_18;
  uStack_8 = 0x24;
  if (puStack_20 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00cdad00(puStack_18,param_2[2]);
  }
  uStack_8 = 0x23;
  puVar3[0x1ab] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x25;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_010650b0(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1ad] = uVar4;
  iVar7 = FUN_01674e20(0x30);
  uStack_8 = 0x26;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01065250(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1ae] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x27;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_010653f0(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1af] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x28;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01065930(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b0] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x29;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_010659e0(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b1] = uVar4;
  iVar7 = FUN_01674e20(0x4c);
  uStack_8 = 0x2a;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01065b50(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b2] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x2b;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01066740(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b3] = uVar4;
  iVar7 = FUN_01674e20(0xd0);
  uStack_8 = 0x2c;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00bb6c20(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b4] = uVar4;
  iVar7 = FUN_01674e20(0x10);
  uStack_8 = 0x2d;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01018340(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b5] = uVar4;
  iVar7 = FUN_01674e20(0x18);
  uStack_8 = 0x2e;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01066860(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b6] = uVar4;
  iVar7 = FUN_01674e20(0x90);
  uStack_8 = 0x2f;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01066d10(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b7] = uVar4;
  iVar7 = FUN_01674e20(0x1c);
  uStack_8 = 0x30;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_010682f0(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b8] = uVar4;
  iVar7 = FUN_01674e20(0x18);
  uStack_8 = 0x31;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_010684c0(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1b9] = uVar4;
  iVar7 = FUN_01674e20(0x9c);
  uStack_8 = 0x32;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_01068760(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1ba] = uVar4;
  iVar7 = FUN_01674e20(0x48);
  uStack_8 = 0x33;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0106a790(puVar3);
  }
  uStack_8 = 0x23;
  puVar3[0x1bb] = uVar4;
  iVar7 = FUN_01674e20(0x30);
  uStack_8 = 0x34;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00f37c60(param_2[3]);
  }
  iVar7 = puVar3[0x1ad];
  puVar3[0x1bc] = uVar4;
  uVar4 = puVar3[0x1ae];
  uStack_8 = 0x23;
  *(undefined4 *)(iVar7 + 4) = 0;
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1ae];
  uVar4 = puVar3[0x1af];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1ad];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1af];
  uVar4 = puVar3[0x1b0];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1ae];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b0];
  uVar4 = puVar3[0x1b1];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1af];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b1];
  uVar4 = puVar3[0x1b2];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b0];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b2];
  uVar4 = puVar3[0x1b3];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b1];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b3];
  uVar4 = puVar3[0x1b4];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b2];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b4];
  uVar4 = puVar3[0x1b5];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b3];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b5];
  uVar4 = puVar3[0x1b6];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b4];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b6];
  uVar4 = puVar3[0x1b7];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b5];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b7];
  uVar4 = puVar3[0x1b8];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b6];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b8];
  uVar4 = puVar3[0x1b9];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b7];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1b9];
  uVar4 = puVar3[0x1ba];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b8];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1ba];
  uVar4 = puVar3[0x1bb];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1b9];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1bb];
  uVar4 = puVar3[0x1bc];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1ba];
  *(undefined4 *)(iVar7 + 8) = uVar4;
  iVar7 = puVar3[0x1bc];
  *(undefined4 *)(iVar7 + 4) = puVar3[0x1bb];
  *(undefined4 *)(iVar7 + 8) = 0;
  FUN_00c180b0(1);
  *(undefined4 **)(puVar3[0x35] + 0x1a8) = puVar3;
  FUN_01065210(puVar3[0x35]);
  uStack_3c = *param_2;
  uStack_38 = param_2[1];
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_34 = 0;
  uStack_30 = 1;
  iVar7 = FUN_01674e20(0x5c);
  uStack_8 = 0x35;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0101d1b0(&uStack_44);
  }
  uStack_8 = 0x23;
  puVar3[0x37] = uVar4;
  iVar7 = FUN_01674e20(0x14bc);
  uStack_8 = 0x36;
  if (iVar7 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0101c8b0(puVar3[0x37]);
  }
  puVar3[0x36] = uVar4;
  _uStack_8 = CONCAT31(uStack_7,0x23);
  if (DAT_01ee4203 != '\0') {
    FUN_016774b0(DAT_01ee4203,"Set bulletDispatcher to: %p",uVar4);
    uVar4 = puVar3[0x36];
  }
  FUN_0105d430(uVar4);
  DAT_01ef3700 = DAT_01d67c78;
  DAT_01d67c64 = (float)DAT_01d67c0c / DAT_018d0938;
  *(double *)(puVar3 + 0x2c) = (double)DAT_01d67c14 / DAT_018c0d70;
  *(double *)(puVar3 + 0x26) = (double)DAT_01d69114 / DAT_018ce318;
  DAT_01f2e5cc = 1;
  DAT_01d703e0 = 1;
  DAT_01d703e2 = 1;
  DAT_01d70408 = 1;
  DAT_01d703e3 = 1;
  DAT_01d703e1 = 1;
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 26044 ; VA 0x00bba7a0 ; FUN_00bba7a0 */

void __fastcall FUN_00bba7a0(undefined4 *param_1)

{
  void **ppvVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar2 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (0 < (int)param_1[1]) {
    do {
      ExceptionList = ppvVar1;
      FUN_007b2d40();
      iVar2 = iVar2 + 1;
      ppvVar1 = (void **)ExceptionList;
    } while (iVar2 < (int)param_1[1]);
  }
  FUN_01674ea0(*param_1);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26045 ; VA 0x00bba810 ; FUN_00bba810 */

void __fastcall FUN_00bba810(int *param_1)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (0 < param_1[1]) {
    do {
      piVar1 = *(int **)(*param_1 + 4 + iVar4 * 8);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      iVar4 = iVar4 + 1;
      ppvVar3 = (void **)ExceptionList;
    } while (iVar4 < param_1[1]);
  }
  ExceptionList = ppvVar3;
  FUN_01674ea0(*param_1);
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26046 ; VA 0x00bba8a0 ; FUN_00bba8a0 */

void __fastcall FUN_00bba8a0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_006515c0();
  return;
}



/* FUNCTION 26047 ; VA 0x00bba900 ; FUN_00bba900 */

void __fastcall FUN_00bba900(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x1b8);
  return;
}



/* FUNCTION 26048 ; VA 0x00bba910 ; FUN_00bba910 */

void __fastcall FUN_00bba910(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,0x18,0x20,FUN_005507b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26049 ; VA 0x00bba950 ; FUN_00bba950 */

void __fastcall FUN_00bba950(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x10;
      uVar3 = uVar3 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar3 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[1] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 26050 ; VA 0x00bba9b0 ; FUN_00bba9b0 */

void __fastcall FUN_00bba9b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x60;
      uVar2 = uVar2 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar2 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[1] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 26051 ; VA 0x00bbaa20 ; FUN_00bbaa20 */

void __fastcall FUN_00bbaa20(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[4] != 0) {
    piVar4 = (int *)param_1[2];
    ExceptionList = &pvStack_10;
    do {
      iVar1 = *piVar4;
      uStack_8 = 0;
      FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
      uStack_8 = 0xffffffff;
      *(int *)(*piVar4 + 4) = iVar1;
      *(int *)*piVar4 = iVar1;
      *(int *)(*piVar4 + 8) = iVar1;
      piVar4[1] = 0;
      FUN_01674ea0(*piVar4,0x1b8);
      piVar4 = (int *)(param_1[2] + 8);
      uStack_14 = uStack_14 + 1;
      param_1[2] = (int)piVar4;
      if (piVar4 == (int *)param_1[1]) {
        piVar4 = (int *)*param_1;
        param_1[2] = (int)piVar4;
      }
    } while (uStack_14 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[1] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26052 ; VA 0x00bbab00 ; FUN_00bbab00 */

void __fastcall FUN_00bbab00(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    piVar1 = *(int **)(*(int *)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4) + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0xc);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 26053 ; VA 0x00bbabd0 ; FUN_00bbabd0 */

void __fastcall FUN_00bbabd0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x1b8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26054 ; VA 0x00bbac40 ; FUN_00bbac40 */

void __fastcall FUN_00bbac40(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    piVar1 = *(int **)(*(int *)(param_1[1] + (iVar4 + param_1[3] + -1 & param_1[2] - 1) * 4) + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0xc);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 26055 ; VA 0x00bbac50 ; thunk_FUN_0096cd30 */

void __fastcall thunk_FUN_0096cd30(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_005d31b0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26056 ; VA 0x00bbac60 ; FUN_00bbac60 */

void FUN_00bbac60(void)

{
  FUN_00bba8a0();
  FUN_00bbab00();
  FUN_0070a3d0();
  return;
}



/* FUNCTION 26057 ; VA 0x00bbac80 ; FUN_00bbac80 */

void __fastcall FUN_00bbac80(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  FUN_00bba950();
  uVar2 = 0;
  if (*(int *)(param_1 + 0xb4) != 0) {
    do {
      *(int *)(param_1 + 0xac) = *(int *)(param_1 + 0xac) + 0x60;
      uVar2 = uVar2 + 1;
      if (*(int *)(param_1 + 0xac) == *(int *)(param_1 + 0xa8)) {
        *(undefined4 *)(param_1 + 0xac) = *(undefined4 *)(param_1 + 0xa4);
      }
    } while (uVar2 < *(uint *)(param_1 + 0xb4));
  }
  iVar1 = *(int *)(param_1 + 0xa4);
  if (iVar1 != 0) {
    uVar2 = ((*(int *)(param_1 + 0xa8) - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  return;
}



/* FUNCTION 26058 ; VA 0x00bbad20 ; FUN_00bbad20 */

void __fastcall FUN_00bbad20(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd050;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01065230(*(undefined4 *)(param_1 + 0xd4));
  *(undefined4 *)(*(int *)(param_1 + 0xd4) + 0x1a8) = 0;
  if (*(undefined4 **)(param_1 + 0xd4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xd4))(1);
  }
  iVar3 = *(int *)(param_1 + 0x6b0);
  if (iVar3 != 0) {
    FUN_01017ec0();
    FUN_01674ea0(iVar3,0x44);
  }
  if (*(undefined4 **)(param_1 + 0x6b4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6b4))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6b8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6b8))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6bc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6bc))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6c0) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6c0))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6c4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6c4))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6c8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6c8))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6cc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6cc))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6d0) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6d0))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6d4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6d4))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6d8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6d8))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6dc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6dc))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6e0) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6e0))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6e4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6e4))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6e8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6e8))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6ec) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6ec))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6f0) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6f0))(1);
  }
  if (*(undefined4 **)(param_1 + 0x6ac) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x6ac))(1);
  }
  if (*(undefined4 **)(param_1 + 0xd8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xd8))(1);
  }
  if (*(undefined4 **)(param_1 + 0xdc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xdc))(1);
  }
  if (DAT_01ee4203 != '\0') {
    FUN_016774b0(DAT_01ee4203,"Remove bulletDispatcher to: %p",*(undefined4 *)(param_1 + 0xd8));
  }
  *(undefined4 *)(param_1 + 0x230) = *(undefined4 *)(param_1 + 0x22c);
  FUN_00bba8a0();
  FUN_00bbab00();
  FUN_0070a3d0();
  FUN_0072e310();
  FUN_0061ac80();
  FUN_0056d250();
  uStack_8 = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x664));
  *(undefined4 *)(param_1 + 0x664) = 0;
  *(undefined4 *)(param_1 + 0x668) = 0;
  *(undefined4 *)(param_1 + 0x66c) = 0;
  FUN_00bba810();
  uStack_8 = 1;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x64c));
  *(undefined4 *)(param_1 + 0x64c) = 0;
  *(undefined4 *)(param_1 + 0x650) = 0;
  *(undefined4 *)(param_1 + 0x654) = 0;
  uStack_8 = 2;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x62c));
  *(undefined4 *)(param_1 + 0x62c) = 0;
  *(undefined4 *)(param_1 + 0x630) = 0;
  *(undefined4 *)(param_1 + 0x634) = 0;
  iVar3 = *(int *)(param_1 + 0x620);
  uStack_8 = 0xffffffff;
  if (iVar3 != 0) {
    uVar2 = (*(int *)(param_1 + 0x628) - iVar3 >> 2) * 4;
    iVar1 = iVar3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar1) - 4U) goto LAB_00bbb275;
    }
    FUN_01674ea0(iVar1,uVar2);
    *(undefined4 *)(param_1 + 0x620) = 0;
    *(undefined4 *)(param_1 + 0x624) = 0;
    *(undefined4 *)(param_1 + 0x628) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x614);
  if (iVar3 != 0) {
    uVar2 = (*(int *)(param_1 + 0x61c) - iVar3 >> 2) * 4;
    iVar1 = iVar3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar1) - 4U) goto LAB_00bbb275;
    }
    FUN_01674ea0(iVar1,uVar2);
    *(undefined4 *)(param_1 + 0x614) = 0;
    *(undefined4 *)(param_1 + 0x618) = 0;
    *(undefined4 *)(param_1 + 0x61c) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x5e8);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 0x5f0) - iVar3 & 0xfffffff0;
    iVar1 = iVar3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar1) - 4U) goto LAB_00bbb275;
    }
    FUN_01674ea0(iVar1,uVar2);
    *(undefined4 *)(param_1 + 0x5e8) = 0;
    *(undefined4 *)(param_1 + 0x5ec) = 0;
    *(undefined4 *)(param_1 + 0x5f0) = 0;
  }
  if (*(undefined4 **)(param_1 + 0x5d4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x5d4))(1);
  }
  FUN_00617ad0();
  uStack_8 = 3;
  FUN_016f32d1(param_1 + 0x238,0x18,0x20,FUN_005507b0);
  iVar3 = *(int *)(param_1 + 0x22c);
  uStack_8 = 0xffffffff;
  if (iVar3 != 0) {
    uVar2 = (*(int *)(param_1 + 0x234) - iVar3 >> 2) * 4;
    iVar1 = iVar3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar1) - 4U) {
LAB_00bbb275:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
    *(undefined4 *)(param_1 + 0x22c) = 0;
    *(undefined4 *)(param_1 + 0x230) = 0;
    *(undefined4 *)(param_1 + 0x234) = 0;
  }
  FUN_0096cd30();
  uStack_8 = 4;
  FUN_01674ea0(*(undefined4 *)(param_1 + 200));
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0;
  *(undefined4 *)(param_1 + 0xd0) = 0;
  if (*(int *)(param_1 + 0xc0) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0xc0),4);
  }
  iVar3 = 0;
  uStack_8 = 5;
  if (0 < *(int *)(param_1 + 0x30)) {
    do {
      FUN_007b2d40();
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_1 + 0x30));
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x2c));
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26059 ; VA 0x00bbb280 ; FUN_00bbb280 */

undefined4 * __thiscall FUN_00bbb280(undefined4 *param_1,undefined4 *param_2)

{
  if (param_1 != param_2) {
    *param_1 = *param_2;
    param_1[3] = param_2[3];
    param_1[4] = param_2[4];
    param_1[5] = param_2[5];
    param_1[6] = param_2[6];
    param_1[7] = param_2[7];
  }
  return param_1;
}



/* FUNCTION 26060 ; VA 0x00bbb2c0 ; FUN_00bbb2c0 */

int __thiscall FUN_00bbb2c0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  byte *pbVar7;
  byte *pbVar8;
  bool bVar9;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_20;
  int iStack_1c;
  undefined uStack_18;
  int iStack_14;
  undefined4 *puStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  iVar6 = (param_1[1] - *param_1) / 0xc;
  if ((uint)(iVar6 * 3) >> 2 <= (uint)param_1[3]) {
    if (*param_1 == param_1[1]) {
      iVar6 = 0x10;
    }
    else {
      iVar6 = iVar6 * 2;
    }
    iStack_20 = param_1[4];
    iStack_1c = param_1[5];
    uStack_18 = 0;
    FUN_00806e90(iVar6,&iStack_20,&uStack_5);
    iStack_2c = param_1[4];
    iVar6 = *param_1;
    iStack_28 = param_1[5];
    uStack_c = 0;
    uStack_30 = 0;
    iVar1 = param_1[1] - iVar6 >> 0x1f;
    if ((param_1[1] - iVar6) / 0xc + iVar1 != iVar1) {
      iStack_14 = 0;
      do {
        uVar4 = param_1[5];
        puStack_10 = (undefined4 *)(iStack_14 + iVar6);
        pbVar7 = (byte *)param_1[4];
        pbVar8 = (byte *)*puStack_10;
        if (puStack_10[1] == uVar4) {
          if (uVar4 != 0) {
            while (uVar3 = uVar4 - 4, 3 < uVar4) {
              if (*(int *)pbVar8 != *(int *)pbVar7) goto LAB_00bbb396;
              pbVar8 = pbVar8 + 4;
              pbVar7 = pbVar7 + 4;
              uVar4 = uVar3;
            }
            if (uVar3 == 0xfffffffc) {
LAB_00bbb3ca:
              uVar4 = 0;
            }
            else {
LAB_00bbb396:
              bVar9 = *pbVar8 < *pbVar7;
              if ((*pbVar8 == *pbVar7) &&
                 ((uVar3 == 0xfffffffd ||
                  ((bVar9 = pbVar8[1] < pbVar7[1], pbVar8[1] == pbVar7[1] &&
                   ((uVar3 == 0xfffffffe ||
                    ((bVar9 = pbVar8[2] < pbVar7[2], pbVar8[2] == pbVar7[2] &&
                     ((uVar3 == 0xffffffff ||
                      (bVar9 = pbVar8[3] < pbVar7[3], pbVar8[3] == pbVar7[3]))))))))))))
              goto LAB_00bbb3ca;
              uVar4 = -(uint)bVar9 | 1;
            }
            if (uVar4 != 0) goto LAB_00bbb3d3;
          }
        }
        else {
LAB_00bbb3d3:
          puVar5 = (undefined4 *)FUN_00bbe5f0(puStack_10);
          *puVar5 = *puStack_10;
          puVar5[1] = puStack_10[1];
          *(undefined *)(puVar5 + 2) = *(undefined *)(puStack_10 + 2);
          iVar6 = *param_1;
        }
        uStack_c = uStack_c + 1;
        iStack_14 = iStack_14 + 0xc;
      } while (uStack_c < (uint)((param_1[1] - iVar6) / 0xc));
    }
    if (param_1 != &iStack_3c) {
      *param_1 = iStack_3c;
      iVar1 = param_1[1];
      param_1[1] = iStack_38;
      iVar2 = param_1[2];
      param_1[2] = iStack_34;
      iStack_3c = iVar6;
      iStack_38 = iVar1;
      iStack_34 = iVar2;
    }
    FUN_00617ad0();
  }
  iVar6 = FUN_00bbe5f0(param_2);
  return iVar6 + 8;
}



/* FUNCTION 26061 ; VA 0x00bbb460 ; FUN_00bbb460 */

int * __thiscall FUN_00bbb460(byte *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdd98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_009c91f0(param_2);
  FUN_00607110(&param_2,uVar5,piVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    iVar7 = *piVar1;
    iVar2 = piVar1[1];
    uStack_8 = 0;
    param_2 = (int *)FUN_01674e20(0x14);
    *param_2 = 0;
    piVar1 = param_2 + 2;
    param_2[1] = 0;
    param_2[4] = 0;
    *piVar1 = iVar7;
    param_2[3] = iVar2;
    if (param_2 + 4 != (int *)0x0) {
      param_2[4] = 0;
    }
    uVar3 = *(uint *)(param_1 + 8);
    uVar6 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005d6bb0(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      uVar8 = uVar3 >> 1;
      if (uVar8 + uVar3 <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005d6bb0(uVar8 + uVar3);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar7);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar4 = (undefined4 *)*puVar10;
        while (puVar4 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar10;
            puVar10 = puVar4;
          }
          else {
            *puVar10 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar10;
        }
      }
    }
    param_2[1] = uVar5;
    uVar5 = uVar5 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = param_2;
      }
      *puVar10 = piVar9;
      *param_2 = *piVar9;
    }
    else {
      *param_2 = *piVar9;
      piVar9 = (int *)*puVar10;
    }
    *piVar9 = (int)param_2;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 26062 ; VA 0x00bbb630 ; FUN_00bbb630 */

int * __thiscall FUN_00bbb630(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fddb8;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = (uVar4 >> 2) + uVar4 * 0x40 + iVar5 ^ uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x18);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    if (piVar3 + 4 != (int *)0x0) {
      piVar3[4] = 0;
    }
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 26063 ; VA 0x00bbb810 ; FUN_00bbb810 */

undefined4 FUN_00bbb810(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  byte *pbVar3;
  byte *pbVar4;
  bool bVar5;
  
  uVar2 = param_2[1];
  pbVar3 = (byte *)*param_2;
  pbVar4 = (byte *)*param_1;
  if (param_1[1] != uVar2) {
    return 0;
  }
  if (uVar2 == 0) {
    return 1;
  }
  while (uVar1 = uVar2 - 4, 3 < uVar2) {
    if (*(int *)pbVar4 != *(int *)pbVar3) goto LAB_00bbb846;
    pbVar4 = pbVar4 + 4;
    pbVar3 = pbVar3 + 4;
    uVar2 = uVar1;
  }
  if (uVar1 != 0xfffffffc) {
LAB_00bbb846:
    bVar5 = *pbVar4 < *pbVar3;
    if ((*pbVar4 != *pbVar3) ||
       ((uVar1 != 0xfffffffd &&
        ((bVar5 = pbVar4[1] < pbVar3[1], pbVar4[1] != pbVar3[1] ||
         ((uVar1 != 0xfffffffe &&
          ((bVar5 = pbVar4[2] < pbVar3[2], pbVar4[2] != pbVar3[2] ||
           ((uVar1 != 0xffffffff && (bVar5 = pbVar4[3] < pbVar3[3], pbVar4[3] != pbVar3[3]))))))))))
       )) {
      uVar2 = -(uint)bVar5 | 1;
      goto LAB_00bbb87c;
    }
  }
  uVar2 = 0;
LAB_00bbb87c:
  if (uVar2 != 0) {
    return 0;
  }
  return 1;
}



/* FUNCTION 26064 ; VA 0x00bbb890 ; FUN_00bbb890 */

void FUN_00bbb890(uint *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  uVar1 = *param_1;
  iVar3 = 0;
  iVar2 = (param_1[1] + uVar1) - uVar1;
  if (param_1[1] + uVar1 < uVar1) {
    iVar2 = 0;
  }
  if (iVar2 != 0) {
    do {
      iVar3 = iVar3 + 1;
    } while (iVar3 != iVar2);
  }
  return;
}



/* FUNCTION 26065 ; VA 0x00bbb8e0 ; FUN_00bbb8e0 */

/* WARNING: Removing unreachable block (ram,0x00bbb93a) */
/* WARNING: Removing unreachable block (ram,0x00bbb94a) */
/* WARNING: Removing unreachable block (ram,0x00bbb950) */

void __fastcall FUN_00bbb8e0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdde0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26066 ; VA 0x00bbb992 ; Catch@00bbb992 */

undefined * Catch_00bbb992(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00bbb9a3;
}



/* FUNCTION 26067 ; VA 0x00bbb9c0 ; FUN_00bbb9c0 */

void FUN_00bbb9c0(void)

{
  FUN_00ca1b70();
  return;
}



/* FUNCTION 26068 ; VA 0x00bbb9d0 ; FUN_00bbb9d0 */

void __thiscall FUN_00bbb9d0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_12819d71947c819b9cb7cc01a1ddb500>,void,class_RBX::Primitive*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 26069 ; VA 0x00bbb9f0 ; FUN_00bbb9f0 */

void __thiscall FUN_00bbb9f0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_95bac1457acf3589b00cf7f941416a34>,void,class_RBX::Primitive*>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 26070 ; VA 0x00bbba10 ; FUN_00bbba10 */

void __thiscall FUN_00bbba10(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = *(int *)(param_1 + 4);
  param_2 = (undefined4 *)*param_2;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  if (*(undefined4 **)(iVar1 + 8) != puVar2) {
    *puVar2 = param_2;
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 4;
    return;
  }
  FUN_0063d9b0(puVar2,&param_2);
  return;
}



/* FUNCTION 26071 ; VA 0x00bbba40 ; FUN_00bbba40 */

void __thiscall FUN_00bbba40(int param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  
  uVar1 = *(uint *)(param_1 + 4);
  iVar2 = *param_2;
  iVar3 = *(int *)(param_1 + 8);
  param_2 = (int *)iVar2;
  iVar5 = FUN_00c157d0();
  if ((uVar1 & iVar5 - 1U) == 0) {
    *(bool *)(iVar2 + 0x19c) = iVar5 != 1;
    piVar4 = *(int **)(iVar3 + 4);
    if (*(int **)(iVar3 + 8) != piVar4) {
      *piVar4 = iVar2;
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 4;
      return;
    }
    FUN_0063d9b0(piVar4,&param_2);
  }
  return;
}



/* FUNCTION 26072 ; VA 0x00bbbaa0 ; FUN_00bbbaa0 */

void FUN_00bbbaa0(int *param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00bbbaa0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00bba950();
    uVar4 = 0;
    if (param_1[0x33] != 0) {
      do {
        param_1[0x31] = param_1[0x31] + 0x60;
        uVar4 = uVar4 + 1;
        if (param_1[0x31] == param_1[0x30]) {
          param_1[0x31] = param_1[0x2f];
        }
      } while (uVar4 < (uint)param_1[0x33]);
    }
    iVar3 = param_1[0x2f];
    if (iVar3 != 0) {
      uVar4 = ((param_1[0x30] - iVar3) / 0x60) * 0x60;
      iVar5 = iVar3;
      if (0xfff < uVar4) {
        iVar5 = *(int *)(iVar3 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar4);
    }
    FUN_01674ea0(param_1,0x1b8);
    cVar1 = *(char *)((int)piVar2 + 0xd);
    param_1 = piVar2;
  } while( true );
}



/* FUNCTION 26073 ; VA 0x00bbbb90 ; FUN_00bbbb90 */

TypeDescriptor * FUN_00bbbb90(void)

{
  return &<lambda_12819d71947c819b9cb7cc01a1ddb500>::RTTI_Type_Descriptor;
}



/* FUNCTION 26074 ; VA 0x00bbbba0 ; FUN_00bbbba0 */

TypeDescriptor * FUN_00bbbba0(void)

{
  return &<lambda_95bac1457acf3589b00cf7f941416a34>::RTTI_Type_Descriptor;
}



/* FUNCTION 26075 ; VA 0x00bbbbb0 ; FUN_00bbbbb0 */

void __fastcall FUN_00bbbbb0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26076 ; VA 0x00bbbc10 ; FUN_00bbbc10 */

void FUN_00bbbc10(void)

{
  FUN_01067360();
  return;
}



/* FUNCTION 26077 ; VA 0x00bbbc20 ; FUN_00bbbc20 */

void __thiscall FUN_00bbbc20(int param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  undefined auStack_10 [8];
  int iStack_8;
  
  iStack_8 = param_1;
  if (param_3 == 0) {
    param_3 = FUN_00c155c0();
  }
  if (*(int *)(param_1 + 0x110) != 0) {
    puVar2 = (undefined4 *)FUN_00c15e20(auStack_10);
    FUN_00f3c660(param_2,*puVar2,puVar2[1],param_4);
  }
  iVar4 = 0;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_2 + 0x10) + iVar4 * 4);
      iVar3 = FUN_00c155c0();
      if (iVar3 == param_3) {
        FUN_00bbbc20(-(uint)(iVar1 != 0) & iVar1 - 8U,param_3,param_4);
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 26078 ; VA 0x00bbbcb0 ; FUN_00bbbcb0 */

void __thiscall FUN_00bbbcb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  if (*(int *)(param_1 + 0x110) != 0) {
    puVar1 = (undefined4 *)FUN_00c15e20(auStack_c);
    FUN_00f3c660(param_2,*puVar1,puVar1[1],param_3);
  }
  return;
}



/* FUNCTION 26079 ; VA 0x00bbbcf0 ; FUN_00bbbcf0 */

void __thiscall FUN_00bbbcf0(uint *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fddf8;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[1];
  if ((int)uVar3 < (int)param_1[2]) {
    ExceptionList = &pvStack_10;
    FUN_008ada10(param_2);
    param_1[1] = param_1[1] + 1;
    ExceptionList = pvStack_10;
    return;
  }
  if (((undefined4 *)*param_1 <= param_2) && (param_2 < (undefined4 *)*param_1 + uVar3 * 7)) {
    ExceptionList = &pvStack_10;
    FUN_008ada10(param_2);
    uStack_8 = 0;
    FUN_00bbbcf0(auStack_2c);
    FUN_007b2d40();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_008b9880(uVar3 + 1,0);
  puVar2 = (undefined4 *)((*param_1 - 0x1c) + param_1[1] * 0x1c);
  *puVar2 = *param_2;
  puVar2[1] = param_2[1];
  iVar5 = param_2[3];
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = param_2[3];
  }
  puVar2[2] = param_2[2];
  piVar4 = (int *)puVar2[3];
  puVar2[3] = iVar5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iVar5 = param_2[5];
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = param_2[5];
  }
  puVar2[4] = param_2[4];
  piVar4 = (int *)puVar2[5];
  puVar2[5] = iVar5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  puVar2[6] = param_2[6];
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26080 ; VA 0x00bbbe60 ; FUN_00bbbe60 */

void FUN_00bbbe60(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fde24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef37a0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef37a0);
    if (DAT_01ef37a0 == -1) {
      uStack_8 = 0;
      uVar4 = FUN_0152dab0(&DAT_018cb3fc,"assemble",0xffffffff);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar4);
      }
      uStack_8 = 0xffffffff;
      DAT_01ef3798 = (int)uVar4;
      DAT_01ef379c = (int)((ulonglong)uVar4 >> 0x20);
      FUN_016f37bf(&DAT_01ef37a0);
    }
  }
  uVar2 = DAT_01ef379c;
  uVar1 = DAT_01ef3798;
  uVar4 = FUN_01532c80(DAT_01ef3798,DAT_01ef379c);
  uStack_8 = 1;
  if (DAT_01d69070 == '\0') {
    FUN_01065c70();
  }
  else {
    if (DAT_01d69098 != '\0') {
      FUN_00ce8550();
    }
    cVar3 = FUN_01065e50();
    FUN_01065c70();
    if (cVar3 == '\0') {
      FUN_00ce8080();
    }
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar4);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar1,uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26081 ; VA 0x00bbbfe0 ; FUN_00bbbfe0 */

void FUN_00bbbfe0(void)

{
  FUN_01674fa0();
  return;
}



/* FUNCTION 26082 ; VA 0x00bbc000 ; FUN_00bbc000 */

int __fastcall FUN_00bbc000(int *param_1)

{
  return param_1[1] - *param_1 >> 4;
}



/* FUNCTION 26083 ; VA 0x00bbc010 ; FUN_00bbc010 */

void __fastcall FUN_00bbc010(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = 0x20;
  if (DAT_01d66528 == '\0') {
    puVar4 = (undefined4 *)(param_1 + 0x118);
    do {
      *(undefined *)(puVar4 + -1) = 0;
      *puVar4 = 0xffffffff;
      if (*(int *)(param_1 + 0x21c) != 0) {
        FUN_005d31b0(*(int *)(param_1 + 0x228) + *(int *)(param_1 + 0x218) * 4,0);
        puVar2 = *(undefined4 **)(param_1 + 0x228);
        puVar1 = puVar2 + *(int *)(param_1 + 0x218);
        for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
          *puVar2 = 0;
        }
      }
      puVar4 = puVar4 + 2;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
    return;
  }
  puVar4 = (undefined4 *)(param_1 + 0x538);
  do {
    *puVar4 = 0xffffffff;
    FUN_005542c0(&DAT_018bc9b8,0);
    puVar4 = puVar4 + 1;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  *(undefined4 *)(param_1 + 0x5bc) = *(undefined4 *)(param_1 + 0x5b8);
  *(undefined4 *)(param_1 + 0x5c4) = 0;
  return;
}



/* FUNCTION 26084 ; VA 0x00bbc0d0 ; FUN_00bbc0d0 */

bool __thiscall FUN_00bbc0d0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puStack_c;
  undefined4 uStack_8;
  
  if (DAT_01d66528 != '\0') {
    uStack_8 = param_2[4];
    puStack_c = param_2;
    if (0xf < (uint)param_2[5]) {
      puStack_c = (undefined4 *)*param_2;
    }
    iVar1 = FUN_00bbcde0(&puStack_c);
    return iVar1 != 0;
  }
  iVar1 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
  uVar2 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar2,param_2,-(uint)(iVar1 != 0) & iVar1 + 1U);
  return param_2 != (undefined4 *)0x0;
}



/* FUNCTION 26085 ; VA 0x00bbc160 ; FUN_00bbc160 */

uint __thiscall FUN_00bbc160(int param_1,undefined4 *param_2,undefined4 *param_3,char param_4)

{
  byte bVar1;
  byte bVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined3 uVar8;
  byte *pbVar9;
  int iVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  undefined4 *puStack_10;
  int iStack_c;
  int iStack_8;
  
  puVar3 = param_2;
  if (DAT_01d66528 == '\0') {
    iStack_8 = param_1 + 0x214;
    iVar5 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
    uVar11 = -(uint)(iVar5 != 0) & iVar5 + 1U;
    iStack_c = param_1;
    uVar7 = FUN_005702d0(param_2);
    puVar6 = (undefined4 *)FUN_00562fc0(&param_2,uVar7,puVar3,uVar11);
    puVar4 = param_3;
    puVar3 = param_2;
    if (param_2 != (undefined4 *)0x0) {
      uVar7 = FUN_005702d0(param_3);
      FUN_00562fc0(&param_2,uVar7,puVar4,uVar11);
      puVar6 = param_2;
      if (param_2 != (undefined4 *)0x0) {
        iVar10 = (int)(char)*(byte *)(puVar3 + 8);
        uVar15 = 1 << (*(byte *)(puVar3 + 8) & 0x1f);
        uVar11 = *(uint *)(iStack_c + 0x118 + iVar10 * 8);
        uVar14 = 1 << (*(byte *)(param_2 + 8) & 0x1f);
        iVar5 = (char)*(byte *)(param_2 + 8) + 0x23;
        uVar13 = *(uint *)(iStack_c + iVar5 * 8);
        uVar8 = (undefined3)((uint)iVar5 >> 8);
        if (param_4 != '\0') {
          *(uint *)(iStack_c + 0x118 + iVar10 * 8) = uVar11 | uVar14;
          *(uint *)(iStack_c + iVar5 * 8) = uVar13 | uVar15;
          return CONCAT31(uVar8,1);
        }
        *(uint *)(iStack_c + 0x118 + iVar10 * 8) = uVar11 & ~uVar14;
        *(uint *)(iStack_c + iVar5 * 8) = uVar13 & ~uVar15;
        return CONCAT31(uVar8,1);
      }
    }
  }
  else {
    iStack_c = param_2[4];
    puStack_10 = param_2;
    if (0xf < (uint)param_2[5]) {
      puStack_10 = (undefined4 *)*param_2;
    }
    iVar5 = FUN_00bbcde0(&puStack_10);
    pbVar12 = (byte *)(-(uint)(iVar5 != 0) & iVar5 + 8U);
    iStack_c = param_3[4];
    puStack_10 = param_3;
    if (0xf < (uint)param_3[5]) {
      puStack_10 = (undefined4 *)*param_3;
    }
    puVar6 = (undefined4 *)FUN_00bbcde0(&puStack_10);
    pbVar9 = (byte *)(-(uint)(puVar6 != (undefined4 *)0x0) & (uint)(puVar6 + 2));
    if ((pbVar12 != (byte *)0x0) && (pbVar9 != (byte *)0x0)) {
      bVar2 = *pbVar12;
      bVar1 = *pbVar9;
      uVar15 = 1 << (bVar2 & 0x1f);
      iVar5 = param_1 + (char)bVar2 * 4;
      uVar13 = 1 << (bVar1 & 0x1f);
      param_1 = param_1 + (char)bVar1 * 4;
      uVar11 = *(uint *)(param_1 + 0x538);
      if (param_4 != '\0') {
        uVar13 = *(uint *)(iVar5 + 0x538) | uVar13;
        *(uint *)(iVar5 + 0x538) = uVar13;
        *(uint *)(param_1 + 0x538) = uVar11 | uVar15;
        return CONCAT31((int3)(uVar13 >> 8),1);
      }
      uVar13 = *(uint *)(iVar5 + 0x538) & ~uVar13;
      *(uint *)(iVar5 + 0x538) = uVar13;
      *(uint *)(param_1 + 0x538) = uVar11 & ~uVar15;
      return CONCAT31((int3)(uVar13 >> 8),1);
    }
  }
  return (uint)puVar6 & 0xffffff00;
}



/* FUNCTION 26086 ; VA 0x00bbc330 ; FUN_00bbc330 */

uint __thiscall FUN_00bbc330(int param_1,char *param_2,char *param_3)

{
  char *pcVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  undefined4 uVar6;
  byte *pbVar7;
  char *pcStack_c;
  uint uStack_8;
  
  pcVar1 = param_2;
  if (DAT_01d66528 == '\0') {
    iVar3 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
    uVar5 = -(uint)(iVar3 != 0) & iVar3 + 1U;
    uStack_8 = uVar5;
    uVar6 = FUN_005702d0(param_2);
    pcVar4 = (char *)FUN_00562fc0(&param_2,uVar6,pcVar1,uVar5);
    pcVar2 = param_3;
    pcVar1 = param_2;
    if (param_2 != (char *)0x0) {
      uVar6 = FUN_005702d0(param_3);
      FUN_00562fc0(&param_2,uVar6,pcVar2,uStack_8);
      pcVar4 = param_2;
      if (param_2 != (char *)0x0) {
        return CONCAT31(param_2[0x20] >> 7,
                        (*(uint *)(param_1 + 0x118 + param_2[0x20] * 8) &
                        1 << (pcVar1[0x20] & 0x1fU)) != 0);
      }
    }
  }
  else {
    uStack_8 = *(uint *)(param_2 + 0x10);
    pcStack_c = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcStack_c = *(char **)param_2;
    }
    iVar3 = FUN_00bbcde0(&pcStack_c);
    pbVar7 = (byte *)(-(uint)(iVar3 != 0) & iVar3 + 8U);
    uStack_8 = *(uint *)(param_3 + 0x10);
    pcStack_c = param_3;
    if (0xf < *(uint *)(param_3 + 0x14)) {
      pcStack_c = *(char **)param_3;
    }
    iVar3 = FUN_00bbcde0(&pcStack_c);
    pcVar4 = (char *)(-(uint)(iVar3 != 0) & iVar3 + 8U);
    if ((pbVar7 != (byte *)0x0) && (pcVar4 != (char *)0x0)) {
      uVar5 = 1 << (*pbVar7 & 0x1f);
      return CONCAT31((int3)(uVar5 >> 8),(*(uint *)(param_1 + 0x538 + *pcVar4 * 4) & uVar5) != 0);
    }
  }
  return (uint)pcVar4 & 0xffffff00;
}



/* FUNCTION 26087 ; VA 0x00bbc470 ; FUN_00bbc470 */

int __thiscall FUN_00bbc470(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *param_2;
  if (iVar1 == 0) {
    iVar1 = *(int *)(param_1 + 0x6f4);
  }
  iVar2 = *param_3;
  if (iVar2 == 0) {
    iVar2 = *(int *)(param_1 + 0x6f4);
  }
  if (iVar1 == iVar2) {
    return param_2[1] - param_3[1];
  }
  return iVar1 - iVar2;
}



/* FUNCTION 26088 ; VA 0x00bbc4b0 ; FUN_00bbc4b0 */

void __thiscall FUN_00bbc4b0(int param_1,undefined4 param_2)

{
  undefined8 uVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined8 uStack_18;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar2 = *(int *)(param_1 + 0x6e8);
  piVar3 = *(int **)(iVar2 + 0x78);
  iStack_8 = *piVar3;
  iStack_c = param_1;
  if ((int *)iStack_8 != piVar3) {
    do {
      FUN_00ca1550();
      iVar6 = FUN_00c157b0();
      uVar1 = *(undefined8 *)(iVar6 + 0x24);
      uStack_10 = *(undefined4 *)(iVar6 + 0x2c);
      uStack_18._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
      bVar4 = uStack_18._4_4_ <
              (float)(**(int **)(iStack_c + 0xc0) - (int)*(int **)(iStack_c + 0xc0));
      uStack_18 = uVar1;
      if ((bVar4) || (cVar5 = FUN_00c94470(&uStack_18), cVar5 != '\0')) {
        uVar7 = FUN_00ca1550();
        FUN_00bb9820(param_2,uVar7,0);
      }
      FUN_00551320();
    } while (iStack_8 != *(int *)(iVar2 + 0x78));
  }
  return;
}



/* FUNCTION 26089 ; VA 0x00bbc550 ; FUN_00bbc550 */

byte __thiscall FUN_00bbc550(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  int *piVar7;
  char *pcVar8;
  byte *pbVar9;
  byte *pbVar10;
  int iVar11;
  undefined4 *puVar12;
  bool bVar13;
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  byte bStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  byte bStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar12 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fde40;
  pvStack_10 = ExceptionList;
  iStack_18 = param_1;
  if (DAT_01d66528 == '\0') {
    if (*(uint *)(param_1 + 0x21c) < 0x20) {
      iVar4 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
      ExceptionList = &pvStack_10;
      uVar6 = FUN_005702d0(param_2);
      puVar12 = param_2;
      FUN_00562fc0(&param_2,uVar6,param_2,-(uint)(iVar4 != 0) & iVar4 + 1U);
      if (param_2 == (undefined4 *)0x0) {
        param_2._0_3_ = 0;
        param_2._3_1_ = 0xff;
        puStack_28 = (undefined4 *)0x0;
        pcVar8 = (char *)(iStack_18 + 0x114);
        do {
          if (*pcVar8 == '\0') {
            param_2._3_1_ = (byte)puStack_28;
            FUN_0054ef60(puVar12);
            uStack_68 = uStack_4c;
            bStack_34 = param_2._3_1_;
            uStack_4c = uStack_4c & 0xffffff00;
            uStack_64 = uStack_48;
            uStack_60 = uStack_44;
            uStack_5c = uStack_40;
            bStack_50 = param_2._3_1_;
            uStack_3c = 0;
            uStack_38 = 0xf;
            uStack_8 = 1;
            FUN_00bb9400(&puStack_30,&uStack_68,&uStack_68);
            FUN_005507b0();
            FUN_005507b0();
            *(undefined *)(iStack_18 + 0x114 + (int)puStack_28 * 8) = 1;
            *(int *)(iStack_18 + 0x118 + (int)puStack_28 * 8) = 1 << (param_2._3_1_ & 0x1f);
            break;
          }
          puStack_28 = (undefined4 *)((int)puStack_28 + 1);
          pcVar8 = pcVar8 + 8;
        } while (puStack_28 < 0x20);
        if (*(int *)(iStack_18 + 0x21c) == 0) {
          piVar7 = (int *)0x0;
        }
        else {
          piVar7 = *(int **)(*(int *)(iStack_18 + 0x228) + *(int *)(iStack_18 + 0x218) * 4);
        }
        if (piVar7 == (int *)0x0) {
          ExceptionList = pvStack_10;
          return param_2._3_1_;
        }
        uVar5 = (uint)(char)param_2._3_1_;
        do {
          iVar4 = iStack_18 + *(char *)(piVar7 + 8) * 8;
          *(uint *)(iVar4 + 0x118) = *(uint *)(iVar4 + 0x118) | 1 << (uVar5 & 0x1f);
          *(uint *)(iStack_18 + 0x118 + uVar5 * 8) =
               *(uint *)(iStack_18 + 0x118 + uVar5 * 8) | 1 << ((int)*(char *)(piVar7 + 8) & 0x1fU);
          piVar7 = (int *)*piVar7;
        } while (piVar7 != (int *)0x0);
        ExceptionList = pvStack_10;
        return param_2._3_1_;
      }
    }
  }
  else if (*(uint *)(param_1 + 0x5c4) < 0x20) {
    piStack_14 = (int *)(param_1 + 0x5b8);
    iStack_2c = param_2[4];
    puStack_30 = param_2;
    if (0xf < (uint)param_2[5]) {
      puStack_30 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00bbcde0(&puStack_30);
    if (iVar4 == 0) {
      param_2._3_1_ = 0xff;
      puStack_24 = (undefined4 *)0x0;
      do {
        if (*(int *)(param_1 + 0x248) == 0) {
          param_2._3_1_ = (byte)puStack_24;
          *(int *)(iStack_18 + 0x538 + (int)puStack_24 * 4) = 1 << (param_2._3_1_ & 0x1f);
          if ((undefined4 *)(param_1 + 0x238) != puVar12) {
            puVar1 = puVar12 + 4;
            if (0xf < (uint)puVar12[5]) {
              puVar12 = (undefined4 *)*puVar12;
            }
            FUN_005542c0(puVar12,*puVar1);
          }
          iVar4 = (int)puStack_24 * 3 + 0x47;
          puStack_30 = (undefined4 *)(iStack_18 + iVar4 * 8);
          iStack_2c = puStack_30[4];
          if (0xf < *(uint *)(iStack_18 + 0x14 + iVar4 * 8)) {
            puStack_30 = (undefined4 *)*puStack_30;
          }
          pbVar9 = (byte *)FUN_00bbb2c0(&puStack_30);
          *pbVar9 = param_2._3_1_;
          break;
        }
        puStack_24 = (undefined4 *)((int)puStack_24 + 1);
        param_1 = param_1 + 0x18;
      } while (puStack_24 < 0x20);
      uStack_20 = 0;
      iStack_1c = piStack_14[1];
      puStack_28 = (undefined4 *)*piStack_14;
      iVar4 = iStack_1c - (int)puStack_28 >> 0x1f;
      if ((iStack_1c - (int)puStack_28) / 0xc + iVar4 != iVar4) {
        puStack_24 = puStack_28;
        do {
          uVar5 = piStack_14[5];
          pbVar9 = (byte *)*puStack_24;
          if (puStack_24[1] != uVar5) break;
          pbVar10 = (byte *)piStack_14[4];
          if (uVar5 != 0) {
            while (uVar3 = uVar5 - 4, 3 < uVar5) {
              if (*(int *)pbVar9 != *(int *)pbVar10) goto LAB_00bbc6c6;
              pbVar9 = pbVar9 + 4;
              pbVar10 = pbVar10 + 4;
              uVar5 = uVar3;
            }
            if (uVar3 == 0xfffffffc) {
LAB_00bbc6fa:
              uVar5 = 0;
            }
            else {
LAB_00bbc6c6:
              bVar13 = *pbVar9 < *pbVar10;
              if ((*pbVar9 == *pbVar10) &&
                 ((uVar3 == 0xfffffffd ||
                  ((bVar13 = pbVar9[1] < pbVar10[1], pbVar9[1] == pbVar10[1] &&
                   ((uVar3 == 0xfffffffe ||
                    ((bVar13 = pbVar9[2] < pbVar10[2], pbVar9[2] == pbVar10[2] &&
                     ((uVar3 == 0xffffffff ||
                      (bVar13 = pbVar9[3] < pbVar10[3], pbVar9[3] == pbVar10[3]))))))))))))
              goto LAB_00bbc6fa;
              uVar5 = -(uint)bVar13 | 1;
            }
            if (uVar5 != 0) break;
          }
          puStack_28 = (undefined4 *)*piStack_14;
          puStack_24 = puStack_24 + 3;
          uStack_20 = uStack_20 + 1;
          iStack_1c = piStack_14[1];
        } while (uStack_20 < (uint)((iStack_1c - (int)puStack_28) / 0xc));
      }
LAB_00bbc760:
      do {
        if (uStack_20 == (iStack_1c - (int)puStack_28) / 0xc) {
          ExceptionList = pvStack_10;
          return param_2._3_1_;
        }
        uVar5 = (uint)(char)param_2._3_1_;
        iVar11 = uStack_20 * 0xc;
        iVar2 = *piStack_14;
        iVar4 = iStack_18 + *(char *)(iVar2 + 8 + iVar11) * 4;
        *(uint *)(iVar4 + 0x538) = *(uint *)(iVar4 + 0x538) | 1 << (uVar5 & 0x1f);
        *(uint *)(iStack_18 + 0x538 + uVar5 * 4) =
             *(uint *)(iStack_18 + 0x538 + uVar5 * 4) |
             1 << ((int)*(char *)(iVar2 + 8 + iVar11) & 0x1fU);
        puVar12 = (undefined4 *)(iVar11 + *piStack_14);
        do {
          do {
            uStack_20 = uStack_20 + 1;
            puVar1 = puVar12 + 3;
            if ((uint)((piStack_14[1] - *piStack_14) / 0xc) <= uStack_20) goto LAB_00bbc760;
            pbVar9 = (byte *)*puVar1;
            pbVar10 = (byte *)piStack_14[4];
            uVar5 = piStack_14[5];
            if (puVar12[4] != uVar5) goto LAB_00bbc760;
            puVar12 = puVar1;
          } while (uVar5 == 0);
          while (uVar3 = uVar5 - 4, 3 < uVar5) {
            if (*(int *)pbVar9 != *(int *)pbVar10) goto LAB_00bbc816;
            pbVar9 = pbVar9 + 4;
            pbVar10 = pbVar10 + 4;
            uVar5 = uVar3;
          }
          if (uVar3 == 0xfffffffc) {
LAB_00bbc84a:
            uVar5 = 0;
          }
          else {
LAB_00bbc816:
            bVar13 = *pbVar9 < *pbVar10;
            if ((*pbVar9 == *pbVar10) &&
               ((uVar3 == 0xfffffffd ||
                ((bVar13 = pbVar9[1] < pbVar10[1], pbVar9[1] == pbVar10[1] &&
                 ((uVar3 == 0xfffffffe ||
                  ((bVar13 = pbVar9[2] < pbVar10[2], pbVar9[2] == pbVar10[2] &&
                   ((uVar3 == 0xffffffff ||
                    (bVar13 = pbVar9[3] < pbVar10[3], pbVar9[3] == pbVar10[3]))))))))))))
            goto LAB_00bbc84a;
            uVar5 = -(uint)bVar13 | 1;
          }
        } while (uVar5 == 0);
      } while( true );
    }
  }
  ExceptionList = pvStack_10;
  return 0xff;
}



/* FUNCTION 26090 ; VA 0x00bbc9d0 ; FUN_00bbc9d0 */

void __thiscall FUN_00bbc9d0(int param_1,undefined4 *param_2,char param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_3c;
  char cStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  char cStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fde60;
  pvStack_10 = ExceptionList;
  if (DAT_01d66528 != '\0') {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x538 + param_3 * 4) = param_4;
    piVar5 = (int *)(param_1 + (param_3 * 3 + 0x47) * 8);
    if (piVar5 != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
    }
    iStack_14 = piVar5[4];
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    iStack_18 = (int)piVar5;
    pcVar2 = (char *)FUN_00bbb2c0(&iStack_18);
    *pcVar2 = param_3;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_50 = uStack_34;
  cStack_1c = param_3;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_4c = uStack_30;
  uStack_48 = uStack_2c;
  uStack_44 = uStack_28;
  cStack_38 = param_3;
  uStack_3c = uStack_20;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_8 = 1;
  FUN_00bb9400(&iStack_18,&uStack_50,&uStack_50);
  if (0xf < uStack_3c) {
    uVar4 = uStack_3c + 1;
    uVar3 = uStack_50;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(uStack_50 - 4);
      uVar4 = uStack_3c + 0x24;
      if (0x1f < (uStack_50 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  *(undefined *)(param_1 + 0x114 + param_3 * 8) = 1;
  *(undefined4 *)(param_1 + 0x118 + param_3 * 8) = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26091 ; VA 0x00bbcb20 ; FUN_00bbcb20 */

void __fastcall FUN_00bbcb20(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_00f3dc00();
  puVar1 = *(undefined4 **)(param_1 + 0x5d4);
  *(undefined4 *)(param_1 + 0x5d4) = uVar2;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  return;
}



/* FUNCTION 26092 ; VA 0x00bbcb40 ; FUN_00bbcb40 */

void FUN_00bbcb40(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x60;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 26093 ; VA 0x00bbcb90 ; FUN_00bbcb90 */

void FUN_00bbcb90(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x10;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 26094 ; VA 0x00bbcbd0 ; FUN_00bbcbd0 */

void FUN_00bbcbd0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 8;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 26095 ; VA 0x00bbcc20 ; FUN_00bbcc20 */

void __fastcall FUN_00bbcc20(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[4] != 0) {
    piVar4 = (int *)param_1[2];
    ExceptionList = &pvStack_10;
    do {
      iVar1 = *piVar4;
      uStack_8 = 0;
      FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
      uStack_8 = 0xffffffff;
      *(int *)(*piVar4 + 4) = iVar1;
      *(int *)*piVar4 = iVar1;
      *(int *)(*piVar4 + 8) = iVar1;
      piVar4[1] = 0;
      FUN_01674ea0(*piVar4,0x1b8);
      piVar4 = (int *)(param_1[2] + 8);
      uStack_14 = uStack_14 + 1;
      param_1[2] = (int)piVar4;
      if (piVar4 == (int *)param_1[1]) {
        piVar4 = (int *)*param_1;
        param_1[2] = (int)piVar4;
      }
    } while (uStack_14 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[1] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26096 ; VA 0x00bbcd00 ; FUN_00bbcd00 */

int * __thiscall FUN_00bbcd00(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar6 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_3; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    *piVar2 = *piVar8;
    uVar7 = piVar8[7];
    if (0xf < uVar7) {
      iVar3 = piVar8[2];
      uVar5 = uVar7 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar8[6] = 0;
    piVar8[7] = 0xf;
    *(undefined *)(piVar8 + 2) = 0;
    FUN_01674ea0(piVar8,0x24);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar7 = uVar6;
    if (*piVar2 == 0) {
LAB_00bbcdb1:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar2;
        goto LAB_00bbcdb1;
      }
    }
    piVar8 = (int *)*piVar2;
    uVar6 = uVar7;
    if (piVar8 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 26097 ; VA 0x00bbcde0 ; FUN_00bbcde0 */

undefined4 * __thiscall FUN_00bbcde0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  char cVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  bool bVar14;
  
  iVar2 = *param_1;
  iVar3 = param_1[1];
  if (iVar2 != iVar3) {
    cVar8 = FUN_00bbb810(param_2,param_1 + 4);
    if (cVar8 == '\0') {
      uVar11 = (iVar3 - *param_1) / 0xc - 1;
      uVar9 = FUN_00bbb890(param_2);
      uVar13 = 0;
      pbVar4 = (byte *)*param_2;
      uVar5 = param_2[1];
      do {
        uVar9 = uVar9 & uVar11;
        puVar1 = (undefined4 *)(iVar2 + uVar9 * 0xc);
        pbVar12 = (byte *)*puVar1;
        if (puVar1[1] == uVar5) {
          pbVar6 = pbVar4;
          uVar10 = uVar5;
          if (uVar5 == 0) {
            return puVar1;
          }
          while (uVar7 = uVar10 - 4, 3 < uVar10) {
            if (*(int *)pbVar12 != *(int *)pbVar6) goto LAB_00bbce8b;
            pbVar12 = pbVar12 + 4;
            pbVar6 = pbVar6 + 4;
            uVar10 = uVar7;
          }
          if (uVar7 == 0xfffffffc) {
LAB_00bbcebf:
            uVar10 = 0;
          }
          else {
LAB_00bbce8b:
            bVar14 = *pbVar12 < *pbVar6;
            if ((*pbVar12 == *pbVar6) &&
               ((uVar7 == 0xfffffffd ||
                ((bVar14 = pbVar12[1] < pbVar6[1], pbVar12[1] == pbVar6[1] &&
                 ((uVar7 == 0xfffffffe ||
                  ((bVar14 = pbVar12[2] < pbVar6[2], pbVar12[2] == pbVar6[2] &&
                   ((uVar7 == 0xffffffff ||
                    (bVar14 = pbVar12[3] < pbVar6[3], pbVar12[3] == pbVar6[3]))))))))))))
            goto LAB_00bbcebf;
            uVar10 = -(uint)bVar14 | 1;
          }
          if (uVar10 == 0) {
            return puVar1;
          }
        }
        cVar8 = FUN_00bbb810(puVar1,param_1 + 4);
        if (cVar8 != '\0') {
          return (undefined4 *)0x0;
        }
        uVar9 = uVar9 + 1 + uVar13;
        uVar13 = uVar13 + 1;
      } while (uVar13 <= uVar11);
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 26098 ; VA 0x00bbcf00 ; FUN_00bbcf00 */

void __thiscall FUN_00bbcf00(int param_1,undefined8 param_2)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  int iVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  int iStack_1c;
  uint *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdee8;
  pvStack_10 = ExceptionList;
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(iVar10 + 0x34) < DAT_01ef3800) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01ef3800 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0(&DAT_018cb3fc,"frameStep",0xffffffff);
    DAT_01ef37fc = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ef37f8 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ef3800);
  }
  uVar3 = DAT_01ef37fc;
  uVar2 = DAT_01ef37f8;
  uVar12 = FUN_0152d930(DAT_01ef37f8,DAT_01ef37fc);
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x38) = 1;
  FUN_00bb8240();
  if (DAT_01d70950 == '\0') {
    FUN_01067480(param_2);
  }
  else {
    FUN_01067820(param_2);
  }
  if (DAT_01d69070 == '\0') {
    if (DAT_01d67ca0 == '\0') {
      if (DAT_01d70950 == '\0') goto LAB_00bbd31d;
      if ((*(int *)(iVar10 + 0x34) < DAT_01ef3840) && (FUN_016f3809(), DAT_01ef3840 == -1)) {
        uStack_8._0_1_ = 0xb;
        uVar17 = FUN_0152dab0(&DAT_018cb3fc,"onAssemblyMovedFromStep",0xffffffff);
        DAT_01ef383c = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef3838 = (undefined4)uVar17;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01ef3840);
      }
      uVar16 = DAT_01ef383c;
      uVar14 = DAT_01ef3838;
      uVar17 = FUN_0152d930(DAT_01ef3838,DAT_01ef383c);
      uStack_8._0_1_ = 0xc;
      puVar1 = *(uint **)(*(int *)(param_1 + 0x6dc) + 0x54);
      for (puStack_18 = *(uint **)(*(int *)(param_1 + 0x6dc) + 0x50); puStack_18 != puVar1;
          puStack_18 = puStack_18 + 3) {
        piVar11 = (int *)*puStack_18;
        uVar7 = 0;
        uVar8 = (uint)((int)puStack_18[1] + (3 - (int)piVar11)) >> 2;
        if ((int *)puStack_18[1] < piVar11) {
          uVar8 = 0;
        }
        if (uVar8 != 0) {
          do {
            if ((*(char *)(*piVar11 + 0x222) == '\0') && (*(char *)(*piVar11 + 0x225) == '\0')) {
              FUN_00ce7840();
            }
            uVar7 = uVar7 + 1;
            piVar11 = piVar11 + 1;
          } while (uVar7 != uVar8);
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    }
    else {
      if ((*(int *)(iVar10 + 0x34) < DAT_01ef3810) && (FUN_016f3809(), DAT_01ef3810 == -1)) {
        uStack_8._0_1_ = 2;
        uVar17 = FUN_0152dab0(&DAT_018cb3fc,"updateAnimatedAssemblies",0xffffffff);
        DAT_01ef380c = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef3808 = (undefined4)uVar17;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01ef3810);
      }
      uVar16 = DAT_01ef380c;
      uVar14 = DAT_01ef3808;
      uVar17 = FUN_0152d930(DAT_01ef3808,DAT_01ef380c);
      uStack_8._0_1_ = 3;
      if (DAT_01d70950 == '\0') {
        if ((*(int *)(iVar10 + 0x34) < DAT_01ef3830) && (FUN_016f3809(), DAT_01ef3830 == -1)) {
          uStack_8._0_1_ = 7;
          uVar18 = FUN_0152dab0(&DAT_018cb3fc,"gatherPrimitives",0xffffffff);
          DAT_01ef382c = (undefined4)((ulonglong)uVar18 >> 0x20);
          DAT_01ef3828 = (undefined4)uVar18;
          uStack_8._0_1_ = 3;
          FUN_016f37bf(&DAT_01ef3830);
        }
        uVar15 = DAT_01ef382c;
        uVar13 = DAT_01ef3828;
        uVar18 = FUN_0152d930(DAT_01ef3828,DAT_01ef382c);
        piVar11 = (int *)(param_1 + 0x614);
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        iVar10 = *(int *)(iStack_14 + 0x6dc);
        if ((uint)(*(int *)(param_1 + 0x61c) - *piVar11 >> 2) < *(uint *)(iVar10 + 0x38)) {
          if (0x3fffffff < *(uint *)(iVar10 + 0x38)) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          FUN_007cfd20();
          iVar10 = *(int *)(iStack_14 + 0x6dc);
        }
        iVar4 = iStack_14;
        puStack_18 = (uint *)**(uint **)(iVar10 + 0x34);
        if (puStack_18 != *(uint **)(iVar10 + 0x34)) {
          do {
            uVar6 = FUN_00ca1550();
            FUN_00bb98b0(piVar11,uVar6,0);
            FUN_00551320();
          } while (puStack_18 != *(uint **)(*(int *)(iVar4 + 0x6dc) + 0x34));
        }
        uStack_8._0_1_ = 9;
      }
      else {
        if ((*(int *)(iVar10 + 0x34) < DAT_01ef3820) && (FUN_016f3809(), DAT_01ef3820 == -1)) {
          uStack_8._0_1_ = 4;
          uVar18 = FUN_0152dab0(&DAT_018cb3fc,"filterPrimitives",0xffffffff);
          DAT_01ef381c = (undefined4)((ulonglong)uVar18 >> 0x20);
          DAT_01ef3818 = (undefined4)uVar18;
          uStack_8._0_1_ = 3;
          FUN_016f37bf(&DAT_01ef3820);
        }
        uVar15 = DAT_01ef381c;
        uVar13 = DAT_01ef3818;
        uVar18 = FUN_0152d930(DAT_01ef3818,DAT_01ef381c);
        iVar4 = iStack_14;
        iVar10 = *(int *)(param_1 + 0x6dc);
        uVar8 = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        for (piVar11 = *(int **)(iVar10 + 0x50); piVar11 != *(int **)(iVar10 + 0x54);
            piVar11 = piVar11 + 3) {
          uVar8 = uVar8 + (piVar11[1] - *piVar11 >> 2);
        }
        piVar11 = (int *)(iStack_14 + 0x614);
        if ((uint)(*(int *)(iStack_14 + 0x61c) - *piVar11 >> 2) < uVar8) {
          if (0x3fffffff < uVar8) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          FUN_007cfd20();
        }
        puVar1 = *(uint **)(iVar10 + 0x54);
        for (puStack_18 = *(uint **)(iVar10 + 0x50); puStack_18 != puVar1;
            puStack_18 = puStack_18 + 3) {
          piVar9 = (int *)*puStack_18;
          uVar7 = 0;
          uVar8 = (uint)((int)puStack_18[1] + (3 - (int)piVar9)) >> 2;
          if ((int *)puStack_18[1] < piVar9) {
            uVar8 = 0;
          }
          if (uVar8 != 0) {
            do {
              iStack_1c = *piVar9;
              if ((*(char *)(iStack_1c + 0x222) == '\0') && (*(char *)(iStack_1c + 0x225) == '\0'))
              {
LAB_00bbd0fc:
                piVar5 = *(int **)(iVar4 + 0x618);
                if (*(int **)(iVar4 + 0x61c) == piVar5) {
                  FUN_0063d9b0(piVar5,&iStack_1c);
                }
                else {
                  *piVar5 = iStack_1c;
                  *(int *)(iVar4 + 0x618) = *(int *)(iVar4 + 0x618) + 4;
                }
              }
              else {
                piVar5 = (int *)(iStack_1c + 0x70);
                if (iStack_1c == 0) {
                  piVar5 = (int *)&DAT_00000020;
                }
                if (*(char *)(*piVar5 + 0x3d) != '\0') goto LAB_00bbd0fc;
              }
              uVar7 = uVar7 + 1;
              piVar9 = piVar9 + 1;
            } while (uVar7 != uVar8);
          }
        }
        uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
        uStack_8._0_1_ = 6;
      }
      FUN_0152dda0(uVar13,uVar15,uVar18);
      uStack_8._0_1_ = 3;
      FUN_00cdeca0();
      piVar11[1] = *piVar11;
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
    }
  }
  else {
    if (DAT_01d70950 != '\0') goto LAB_00bbd3aa;
LAB_00bbd31d:
    if ((*(int *)(iVar10 + 0x34) < DAT_01ef3850) && (FUN_016f3809(), DAT_01ef3850 == -1)) {
      uStack_8._0_1_ = 0xe;
      uVar17 = FUN_0152dab0(&DAT_018cb3fc,"onAssemblyMovedFromStep",0xffffffff);
      DAT_01ef384c = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ef3848 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ef3850);
    }
    uVar16 = DAT_01ef384c;
    uVar14 = DAT_01ef3848;
    uVar17 = FUN_0152d930(DAT_01ef3848,DAT_01ef384c);
    iVar10 = iStack_14;
    uStack_8._0_1_ = 0xf;
    puVar1 = *(uint **)(*(int *)(iStack_14 + 0x6dc) + 0x34);
    puStack_18 = (uint *)*puVar1;
    if (puStack_18 != puVar1) {
      do {
        FUN_00ce6600();
        FUN_00551320();
      } while (puStack_18 != *(uint **)(*(int *)(iVar10 + 0x6dc) + 0x34));
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  }
  FUN_0152dda0(uVar14,uVar16,uVar17);
LAB_00bbd3aa:
  *(undefined *)(iStack_14 + 0x38) = 0;
  *(undefined8 *)(iStack_14 + 0xb8) = param_2;
  uStack_8 = 0x11;
  FUN_0152dda0(uVar2,uVar3,uVar12);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26099 ; VA 0x00bbd5e0 ; FUN_00bbd5e0 */

void __thiscall FUN_00bbd5e0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = 0;
  iVar1 = *(int *)(param_1 + 0x22c);
  uVar3 = *(int *)(param_1 + 0x230) - iVar1 >> 2;
  if (uVar3 != 0) {
    while (param_2 != *(int *)(iVar1 + uVar2 * 4)) {
      uVar2 = uVar2 + 1;
      if (uVar3 <= uVar2) {
        return;
      }
    }
    *(undefined4 *)(iVar1 + uVar2 * 4) = *(undefined4 *)(iVar1 + -4 + uVar3 * 4);
    *(int *)(param_1 + 0x230) = *(int *)(param_1 + 0x230) + -4;
  }
  return;
}



/* FUNCTION 26100 ; VA 0x00bbd630 ; FUN_00bbd630 */

void FUN_00bbd630(int param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  byte bVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  byte bStack_6;
  byte bStack_5;
  
  bStack_6 = 0;
  iVar1 = *(int *)(param_1 + 0x2c);
  iVar11 = *(int *)(param_1 + 0x30);
  bStack_5 = 0;
  iStack_c = iVar11;
  if ((iVar1 != 0) && (iVar11 != 0)) {
    bStack_6 = FUN_00c16ba0(iVar11);
    bStack_5 = FUN_00c16ba0(iVar1);
    iVar6 = FUN_00c15700();
    iStack_10 = iVar6;
    iVar7 = FUN_00c15700();
    if ((iVar6 != 0) && (iVar7 != 0)) {
      piVar2 = *(int **)(param_2 + 4);
      if (*(int **)(param_2 + 8) == piVar2) {
        FUN_0063d9b0(piVar2,&iStack_10);
        return;
      }
      *piVar2 = iVar6;
      *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
      return;
    }
  }
  iStack_10 = 0;
  do {
    iVar7 = iStack_10;
    bVar4 = bStack_5;
    iVar6 = param_3;
    if (iStack_10 == 0) {
      bVar4 = bStack_6;
      iVar6 = param_2;
    }
    uStack_18 = (uint)bVar4;
    iStack_14 = iVar11;
    if (iStack_10 == 0) {
      iStack_14 = iVar1;
    }
    if ((iStack_14 != 0) && (iVar8 = FUN_00c160f0(), iVar8 != 0)) {
      iVar8 = FUN_00c155c0();
      iVar10 = 0;
      iVar11 = iStack_c;
      if (0 < *(int *)(iVar8 + 0x14)) {
        do {
          iVar11 = *(int *)(*(int *)(iVar8 + 0x10) + iVar10 * 4);
          cVar5 = FUN_00c1a1b0(-(uint)(iVar11 != 0) & iVar11 - 8U);
          if (cVar5 != '\0') {
            uVar9 = FUN_00ca1550();
            uStack_1c = uVar9;
            cVar5 = FUN_00c16ba0(uVar9);
            if ((cVar5 != '\0') &&
               (((char)uStack_18 == '\0' || (cVar5 = FUN_00c16ba0(uVar9), cVar5 == '\0')))) {
              puVar3 = *(undefined4 **)(iVar6 + 4);
              if (*(undefined4 **)(iVar6 + 8) == puVar3) {
                FUN_0063d9b0(puVar3,&uStack_1c);
              }
              else {
                *puVar3 = uVar9;
                *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 4;
              }
            }
          }
          iVar10 = iVar10 + 1;
          iVar11 = iStack_c;
          iVar7 = iStack_10;
        } while (iVar10 < *(int *)(iVar8 + 0x14));
      }
    }
    iStack_10 = iVar7 + 1;
  } while (iStack_10 < 2);
  return;
}



/* FUNCTION 26101 ; VA 0x00bbd7b0 ; FUN_00bbd7b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00bbd7b0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 0x1b4);
  if (puVar1 != (undefined4 *)0x0) {
    uVar2 = puVar1[1];
    uVar3 = puVar1[2];
    uVar4 = puVar1[3];
    *param_2 = *puVar1;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar1 + 4);
    return;
  }
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf0a8) {
    FUN_016f3809(&DAT_01eaf0a8);
    if (DAT_01eaf0a8 == -1) {
      _DAT_01eaf098 = 0;
      _DAT_01eaf090 = 0;
      _DAT_01eaf09c = 0;
      DAT_01eaf0a0._0_4_ = 0;
      DAT_01eaf0a0._4_4_ = 0;
      FUN_016f37bf(&DAT_01eaf0a8);
    }
  }
  uVar4 = _DAT_01eaf09c;
  uVar3 = _DAT_01eaf098;
  uVar2 = DAT_01eaf090_4;
  *param_2 = _DAT_01eaf090;
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  *(ulonglong *)(param_2 + 4) = CONCAT44(DAT_01eaf0a0._4_4_,(undefined4)DAT_01eaf0a0);
  return;
}



/* FUNCTION 26102 ; VA 0x00bbd880 ; FUN_00bbd880 */

undefined __fastcall FUN_00bbd880(int param_1)

{
  if ((*(char *)(param_1 + 0x222) == '\0') && (*(char *)(param_1 + 0x225) == '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 26103 ; VA 0x00bbd8a0 ; FUN_00bbd8a0 */

undefined4 __thiscall FUN_00bbd8a0(int param_1,char param_2)

{
  if (DAT_01d66528 == '\0') {
    if (param_2 < ' ') {
      return *(undefined4 *)(param_1 + 0x118 + param_2 * 8);
    }
    return 0xffffffff;
  }
  if (param_2 < ' ') {
    return *(undefined4 *)(param_1 + 0x538 + param_2 * 4);
  }
  return 0xffffffff;
}



/* FUNCTION 26104 ; VA 0x00bbd8f0 ; FUN_00bbd8f0 */

float10 __fastcall FUN_00bbd8f0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (DAT_01ef3704 != 0) {
    return (float10)(DAT_018ce2f8 / (float)iVar1);
  }
  if (0 < iVar1) {
    return (float10)(DAT_018ce2f8 - DAT_018ce2f8 / (float)iVar1);
  }
  return (float10)(DAT_018f7864 / (float)iVar1);
}



/* FUNCTION 26105 ; VA 0x00bbd970 ; FUN_00bbd970 */

float10 __thiscall FUN_00bbd970(int param_1,int param_2)

{
  uint uVar1;
  float fVar2;
  
  if (DAT_01ef3704 != 0) {
    return (float10)(DAT_018ce2f8 / (float)*(int *)(param_1 + 4));
  }
  uVar1 = param_2 + *(int *)(param_1 + 8);
  if (uVar1 < 9) {
    fVar2 = (float)*(int *)(&DAT_0195c90c + uVar1 * 4);
    if (0 < *(int *)(&DAT_0195c90c + uVar1 * 4)) {
      return (float10)(DAT_018ce2f8 - DAT_018ce2f8 / fVar2);
    }
    return (float10)(DAT_018f7864 / fVar2);
  }
  fVar2 = (float)*(int *)(param_1 + 4);
  if (0 < *(int *)(param_1 + 4)) {
    return (float10)(DAT_018ce2f8 - DAT_018ce2f8 / fVar2);
  }
  return (float10)(DAT_018f7864 / fVar2);
}



/* FUNCTION 26106 ; VA 0x00bbda40 ; FUN_00bbda40 */

undefined * __thiscall FUN_00bbda40(int param_1,undefined *param_2,char param_3)

{
  undefined *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdf32;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (DAT_01d66528 == '\0') {
    if (*(int *)(param_1 + 0x21c) == 0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x228) + *(int *)(param_1 + 0x218) * 4);
    }
    for (; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      if (*(char *)(puVar2 + 8) == param_3) {
        ExceptionList = &pvStack_10;
        FUN_0054ef60(puVar2 + 2);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
  }
  else {
    if (param_3 < '!') {
      ExceptionList = &pvStack_10;
      puVar1 = (undefined *)FUN_0054ef60(param_1 + (param_3 * 3 + 0x47) * 8);
      uVar3 = 2;
    }
    else {
      uStack_1c = 0;
      uStack_18 = 0xf;
      auStack_2c[0] = 0;
      ExceptionList = &pvStack_10;
      FUN_005542c0(&DAT_018bc9b8,0);
      puVar1 = auStack_2c;
      uVar3 = 1;
    }
    uStack_8 = (uint)(param_3 < '!');
    uStack_14 = uVar3;
    FUN_0054ef60(puVar1);
    if ((uVar3 & 2) != 0) {
      uVar3 = uVar3 & 0xfffffffd;
      FUN_005507b0();
    }
    if ((uVar3 & 1) != 0) {
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26107 ; VA 0x00bbdba0 ; FUN_00bbdba0 */

undefined __thiscall FUN_00bbdba0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 *puStack_c;
  undefined4 uStack_8;
  
  if (DAT_01d66528 == '\0') {
    iVar1 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
    uVar3 = FUN_005702d0(param_2);
    FUN_00562fc0(&param_2,uVar3,param_2,-(uint)(iVar1 != 0) & iVar1 + 1U);
    if (param_2 != (undefined4 *)0x0) {
      return *(undefined *)(param_2 + 8);
    }
  }
  else {
    uStack_8 = param_2[4];
    puStack_c = param_2;
    if (0xf < (uint)param_2[5]) {
      puStack_c = (undefined4 *)*param_2;
    }
    iVar1 = FUN_00bbcde0(&puStack_c);
    puVar2 = (undefined *)(-(uint)(iVar1 != 0) & iVar1 + 8U);
    if (puVar2 != (undefined *)0x0) {
      return *puVar2;
    }
  }
  return 0xff;
}



/* FUNCTION 26108 ; VA 0x00bbdc40 ; FUN_00bbdc40 */

undefined4 __fastcall FUN_00bbdc40(int param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d69070 == '\0') {
                    /* WARNING: Could not recover jumptable at 0x00bbdc57. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(*(int *)(param_1 + 0x6ac) + 0x154) + 0x4c))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 26109 ; VA 0x00bbdc60 ; FUN_00bbdc60 */

int __thiscall FUN_00bbdc60(int param_1,undefined4 param_2)

{
  int iVar1;
  
  switch(param_2) {
  case 0:
    iVar1 = FUN_00ce3530();
    return iVar1;
  case 1:
    iVar1 = FUN_00ce3540();
    return iVar1;
  default:
    return -1;
  case 3:
                    /* WARNING: Could not recover jumptable at 0x00bbdcf0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar1 = (**(code **)(**(int **)(param_1 + 0x6b4) + 0x10))();
    return iVar1;
  case 4:
    iVar1 = *(int *)(param_1 + 0x6e8);
    return *(int *)(iVar1 + 0x8c) + *(int *)(iVar1 + 0x84) + *(int *)(iVar1 + 0x7c) +
           *(int *)(iVar1 + 0x74) + *(int *)(iVar1 + 0x6c);
  case 5:
    return *(int *)(*(int *)(param_1 + 0x6e8) + 0x8c);
  case 6:
    return *(int *)(*(int *)(param_1 + 0x6e8) + 0x84);
  case 7:
    return *(int *)(*(int *)(param_1 + 0x6e8) + 0x7c);
  }
}



/* FUNCTION 26110 ; VA 0x00bbdd20 ; FUN_00bbdd20 */

void FUN_00bbdd20(void)

{
  FUN_00f38210();
  return;
}



/* FUNCTION 26111 ; VA 0x00bbdd30 ; FUN_00bbdd30 */

void FUN_00bbdd30(void)

{
  FUN_00ce3530();
  return;
}



/* FUNCTION 26112 ; VA 0x00bbdd40 ; FUN_00bbdd40 */

undefined4 __fastcall FUN_00bbdd40(int param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d69070 == '\0') {
                    /* WARNING: Could not recover jumptable at 0x00bbdd57. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(int **)(*(int *)(param_1 + 0x6ac) + 0x154) + 0x48))();
    return uVar1;
  }
  return 0;
}



/* FUNCTION 26113 ; VA 0x00bbdd60 ; FUN_00bbdd60 */

int __thiscall FUN_00bbdd60(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = param_1 + 0x689 + (uint)*(byte *)(param_1 + 0x688);
  uVar1 = FUN_009c91f0(param_2);
  FUN_00607110(&param_2,uVar1,param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
  if (param_2 == 0) {
    return param_2;
  }
  return *(int *)(param_2 + 0x10);
}



/* FUNCTION 26114 ; VA 0x00bbddb0 ; FUN_00bbddb0 */

undefined4 __fastcall FUN_00bbddb0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x6b0);
}



/* FUNCTION 26115 ; VA 0x00bbddc0 ; FUN_00bbddc0 */

int __fastcall FUN_00bbddc0(int param_1)

{
  return *(int *)(param_1 + 0x6d0) + 0x1c;
}



/* FUNCTION 26116 ; VA 0x00bbddd0 ; FUN_00bbddd0 */

float10 __fastcall FUN_00bbddd0(int param_1)

{
  return (float10)*(double *)(param_1 + 0xa8);
}



/* FUNCTION 26117 ; VA 0x00bbdde0 ; FUN_00bbdde0 */

float10 __fastcall FUN_00bbdde0(int param_1)

{
  return (float10)*(double *)(param_1 + 0xa0);
}



/* FUNCTION 26118 ; VA 0x00bbddf0 ; FUN_00bbddf0 */

float10 __fastcall FUN_00bbddf0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  double dVar5;
  double dVar6;
  double dVar7;
  
  iVar3 = *(int *)(param_1 + 0x50);
  iVar1 = iVar3;
  if (*(int *)(param_1 + 0x100) != 0) {
    iVar1 = iVar3 - *(int *)(param_1 + 0x100);
    dVar4 = *(double *)(param_1 + 0xf0) - *(double *)(param_1 + 0xf8);
    if (DAT_01d67c90 == '\0') {
      iVar2 = FUN_00bb5bf0();
    }
    else {
      iVar2 = *(int *)(param_1 + 0x60c);
    }
    dVar7 = dVar4 * (double)iVar2;
    dVar5 = (dVar7 - (double)iVar1) + *(double *)(param_1 + 0x108);
    *(double *)(param_1 + 0x108) = dVar5;
    dVar6 = (double)DAT_01d67bcc;
    if (dVar5 <= (double)DAT_01d67bcc) {
      dVar6 = dVar5;
    }
    if (dVar6 <= (double)-DAT_01d67bcc) {
      dVar6 = (double)-DAT_01d67bcc;
    }
    *(double *)(param_1 + 0x108) = dVar6;
    dVar5 = (double)DAT_01d67bd4 / DAT_018c0d70;
    if (dVar6 <= dVar5) {
      if ((double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) ^ DAT_0195cdb0._4_4_,
                           SUB84(dVar5,0) ^ (uint)DAT_0195cdb0) <= dVar6) {
        dVar6 = 0.0;
      }
      else {
        dVar6 = dVar6 + dVar5;
      }
    }
    else {
      dVar6 = dVar6 - dVar5;
    }
    *(double *)(param_1 + 0x108) = dVar6;
    if (((DAT_01ef36f5 != '\0') &&
        (FUN_016774d0(DAT_01ef36f5,"DELTA     WorldSteps       : %d",(float)iVar1,0,0,0),
        DAT_01ef36f5 != '\0')) &&
       (FUN_016774d0(DAT_01ef36f5,"Expected  WorldSteps       : %d",(float)dVar7,0,0,0),
       DAT_01ef36f5 != '\0')) {
      FUN_016774d0(DAT_01ef36f5,"dt: %f",(float)dVar4,0,0,0);
    }
    if (DAT_01ef36f6 != '\0') {
      FUN_016774d0(DAT_01ef36f6,"Number of WorldSteps behind, wsps, deltaTime: %f  %f  %f",
                   (float)*(double *)(param_1 + 0x108),(float)iVar1,(float)dVar7,0);
    }
    iVar1 = *(int *)(param_1 + 0x50);
  }
  if (iVar3 != iVar1) {
    FUN_0086f2f0(1,"getWorldStepId changed %d %d",iVar3,iVar1);
    iVar1 = *(int *)(param_1 + 0x50);
  }
  *(int *)(param_1 + 0x100) = iVar1;
  *(undefined4 *)(param_1 + 0xf8) = *(undefined4 *)(param_1 + 0xf0);
  *(undefined4 *)(param_1 + 0xfc) = *(undefined4 *)(param_1 + 0xf4);
  if (DAT_01d67c90 == '\0') {
    iVar3 = FUN_00bb5bf0();
    return (float10)(float)(*(double *)(param_1 + 0x108) / (double)iVar3);
  }
  return (float10)(float)(*(double *)(param_1 + 0x108) / (double)*(int *)(param_1 + 0x60c));
}



/* FUNCTION 26119 ; VA 0x00bbe0a0 ; FUN_00bbe0a0 */

float10 __fastcall FUN_00bbe0a0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x50) - *(int *)(param_1 + 0x5c);
  iVar1 = *(int *)(param_1 + 0x60);
  if (iVar2 == 0) {
    return (float10)1;
  }
  *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x58);
  *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x50);
  return (float10)((double)(*(int *)(param_1 + 0x58) - iVar1) / (double)iVar2);
}



/* FUNCTION 26120 ; VA 0x00bbe0f0 ; FUN_00bbe0f0 */

uint __thiscall FUN_00bbe0f0(uint *param_1,char param_2)

{
  uint uVar1;
  
  if (DAT_01ef3704 == 0) {
    uVar1 = param_1[2];
    if (param_2 == '\0') {
      if ((int)uVar1 < 8) {
        param_1[2] = uVar1 + 1;
        return CONCAT31((int3)(uVar1 + 1 >> 8),1);
      }
    }
    else if (0 < (int)uVar1) {
      param_1[2] = uVar1 - 1;
      return CONCAT31((int3)(uVar1 - 1 >> 8),1);
    }
  }
  else {
    uVar1 = *param_1;
    if (param_2 == '\0') {
      if ((int)uVar1 < 0x10) {
        *param_1 = uVar1 * 2;
        return CONCAT31((int3)(uVar1 * 2 >> 8),1);
      }
    }
    else if (1 < (int)uVar1) {
      *param_1 = (int)uVar1 / 2;
      return CONCAT31((int3)((uint)((int)uVar1 / 2) >> 8),1);
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 26121 ; VA 0x00bbe160 ; FUN_00bbe160 */

void FUN_00bbe160(void)

{
  FUN_01036710(FUN_01674f30,FUN_01674ea0);
  FUN_01036740(FUN_00bbbfe0,&LAB_00bbbff0);
  return;
}



/* FUNCTION 26122 ; VA 0x00bbe190 ; FUN_00bbe190 */

void __thiscall FUN_00bbe190(int param_1,int *param_2)

{
  bool bVar1;
  char cVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  undefined4 uStack_38;
  uint *puStack_34;
  uint *puStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdf50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar4 = FUN_01675290(DAT_01ef3714);
  uStack_2c = uVar4;
  if ((*(int *)(param_2[0xb] + 0x1a8) == param_1) &&
     ((param_2[0xc] == 0 || (*(int *)(param_2[0xc] + 0x1a8) == param_1)))) {
    uStack_18 = 0;
    uStack_38 = 0;
    puStack_34 = (uint *)0x0;
    puStack_30 = (uint *)0x0;
    uStack_8 = 2;
    iVar5 = (**(code **)(*param_2 + 0x10))();
    if ((iVar5 == 0x1b) || (cVar2 = FUN_00bbea00(param_2), cVar2 == '\0')) {
      bVar1 = true;
    }
    else {
      uStack_28 = param_2[0xb];
      uStack_20 = param_2[0xc];
      bVar1 = false;
      if ((uStack_28 != 0) && (uStack_20 != 0)) {
        uStack_1c = FUN_00c15700();
        uStack_24 = FUN_00c15700();
        if ((uStack_1c == 0) || (uStack_24 == 0)) {
          uVar7 = uStack_24;
          if (uStack_1c != 0) {
            uVar7 = uStack_1c;
          }
          param_1 = iStack_14;
          uStack_24 = uVar7;
          if (uVar7 != 0) {
            uStack_18 = uStack_20;
            if (uStack_1c != 0) {
              uStack_18 = uStack_28;
            }
            uVar6 = FUN_00c160f0();
            if (((uVar7 == uVar6) || (cVar2 = FUN_00c16ba0(uVar7), cVar2 != '\0')) ||
               (param_1 = iStack_14, uVar7 == uStack_18)) {
              if (puStack_30 == puStack_34) {
                FUN_0063d9b0(puStack_34,&uStack_24);
                param_1 = iStack_14;
              }
              else {
                *puStack_34 = uVar7;
                puStack_34 = puStack_34 + 1;
                param_1 = iStack_14;
              }
            }
          }
        }
        else {
          puVar8 = &uStack_1c;
          if (uStack_1c != uStack_24) {
            FUN_00646760(puVar8);
            puVar8 = &uStack_24;
          }
          FUN_00646760(puVar8);
          param_1 = iStack_14;
        }
      }
    }
    if (DAT_01d66c44 == '\0') {
      uVar3 = FUN_00ca09e0(&uStack_38);
      uStack_20 = CONCAT31(uStack_20._1_3_,uVar3);
    }
    else {
      uStack_20 = uStack_20 & 0xffffff00;
    }
    (**(code **)(**(int **)(param_1 + 0x6b4) + 8))(param_2);
    if (!bVar1) {
      FUN_00bbb8e0(param_2,uStack_18,&uStack_38,uStack_20);
      iVar5 = (**(code **)(*param_2 + 0x10))();
      if ((iVar5 - 7U < 0x13) &&
         ((iVar5 = (**(code **)(*param_2 + 0x10))(), 0xd < iVar5 - 0xcU ||
          ((*(byte *)(param_2 + 0x2b) & 1) == 0)))) {
        if (param_2[0xb] != param_2[0xc]) {
          FUN_00cdd030(param_2[0xb],param_2[0xc]);
        }
      }
    }
    if ((DAT_01d62d64 != '\0') && (iVar5 = (**(code **)(*param_2 + 0x10))(), iVar5 - 1U < 4)) {
      *(int *)(param_1 + 0x648) = *(int *)(param_1 + 0x648) + 1;
    }
    *(int *)(param_1 + 0x63c) = *(int *)(param_1 + 0x63c) + 1;
    FUN_00ca41a0();
    iVar5 = (**(code **)(*param_2 + 0x10))();
    if (iVar5 - 1U < 6) {
      FUN_00ca4390();
    }
    FUN_0056d320();
  }
  uStack_8 = 3;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26123 ; VA 0x00bbe3d0 ; FUN_00bbe3d0 */

void __thiscall FUN_00bbe3d0(int param_1,int param_2)

{
  uint *puVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  float fVar9;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar3 = FUN_01675290(DAT_01ef3714);
  puVar1 = (uint *)(param_1 + 0xe0);
  uVar7 = *puVar1;
  *puVar1 = *puVar1 + 1;
  *(int *)(param_1 + 0xe4) = *(int *)(param_1 + 0xe4) + (uint)(0xfffffffe < uVar7);
  uStack_8 = 0;
  uVar7 = -(uint)(param_2 != 0) & param_2 + 0x50U;
  uStack_20 = uVar3;
  uStack_1c = uVar7;
  FUN_00fa04c0(*(undefined4 *)(param_1 + 0xe0),*(undefined4 *)(param_1 + 0xe4));
  iVar4 = FUN_00bbb630((undefined4 *)(param_1 + 0xe0));
  iVar2 = iStack_14;
  *(int *)(iVar4 + 8) = param_2;
  uVar5 = FUN_00c15b60();
  iVar4 = FUN_00bbb460(uVar5);
  iStack_18 = param_2;
  *(int *)(iVar4 + 8) = param_2;
  *(int *)(uVar7 + 0x144) = iVar2 + 0x6a0;
  uVar5 = *(undefined4 *)(iVar2 + 0xcc);
  puVar6 = (undefined4 *)FUN_00bc2af0();
  *puVar6 = uVar5;
  FUN_007c5360(&iStack_18);
  iVar2 = iStack_14;
  *(int *)(param_2 + 0x1a8) = iStack_14;
  FUN_00c19d80();
  FUN_00fa00e0(*(undefined4 *)(iVar2 + 0xc4));
  FUN_01065210(param_2);
  FUN_00ce7230(param_2);
  if (((DAT_01d69070 != '\0') &&
      (iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar4 != 10)) &&
     (3 < (uint)(*(int *)(iVar2 + 0x230) - *(int *)(iVar2 + 0x22c)))) {
    FUN_00bc26c0();
    FUN_00bbd7b0(&fStack_38);
    uVar8 = 0;
    puVar6 = *(undefined4 **)(iVar2 + 0x22c);
    fVar9 = (float)DAT_01d68adc / DAT_018ce320;
    uVar7 = (uint)((int)*(undefined4 **)(iStack_14 + 0x230) + (3 - (int)puVar6)) >> 2;
    if (*(undefined4 **)(iStack_14 + 0x230) < puVar6) {
      uVar7 = 0;
    }
    fStack_38 = fStack_38 - fVar9;
    fStack_34 = fStack_34 - fVar9;
    fStack_30 = fStack_30 - fVar9;
    fStack_2c = fVar9 + fStack_2c;
    fStack_28 = fVar9 + fStack_28;
    fStack_24 = fVar9 + fStack_24;
    if (uVar7 != 0) {
      do {
        (**(code **)(*(int *)*puVar6 + 4))(param_2,&fStack_38,1);
        uVar8 = uVar8 + 1;
        puVar6 = puVar6 + 1;
        uVar3 = uStack_20;
      } while (uVar8 != uVar7);
    }
  }
  uStack_8 = 1;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26124 ; VA 0x00bbe5f0 ; FUN_00bbe5f0 */

undefined4 * __thiscall FUN_00bbe5f0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  byte *pbVar6;
  uint uVar7;
  uint uVar8;
  byte *pbVar9;
  bool bVar10;
  uint uStack_8;
  
  iVar2 = *param_1;
  uVar8 = (param_1[1] - iVar2) / 0xc - 1;
  uVar5 = FUN_00bbb890(param_2);
  uVar3 = param_1[5];
  uStack_8 = 0;
  do {
    uVar5 = uVar5 & uVar8;
    puVar1 = (undefined4 *)(iVar2 + uVar5 * 0xc);
    pbVar9 = (byte *)*puVar1;
    if (puVar1[1] == uVar3) {
      if (uVar3 == 0) goto LAB_00bbe73f;
      pbVar6 = (byte *)param_1[4];
      uVar7 = uVar3;
      while (uVar4 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar9 != *(int *)pbVar6) goto LAB_00bbe67b;
        pbVar9 = pbVar9 + 4;
        pbVar6 = pbVar6 + 4;
        uVar7 = uVar4;
      }
      if (uVar4 == 0xfffffffc) {
LAB_00bbe6af:
        uVar7 = 0;
      }
      else {
LAB_00bbe67b:
        bVar10 = *pbVar9 < *pbVar6;
        if ((*pbVar9 == *pbVar6) &&
           ((uVar4 == 0xfffffffd ||
            ((bVar10 = pbVar9[1] < pbVar6[1], pbVar9[1] == pbVar6[1] &&
             ((uVar4 == 0xfffffffe ||
              ((bVar10 = pbVar9[2] < pbVar6[2], pbVar9[2] == pbVar6[2] &&
               ((uVar4 == 0xffffffff || (bVar10 = pbVar9[3] < pbVar6[3], pbVar9[3] == pbVar6[3])))))
              ))))))) goto LAB_00bbe6af;
        uVar7 = -(uint)bVar10 | 1;
      }
      if (uVar7 == 0) {
LAB_00bbe73f:
        *puVar1 = *param_2;
        puVar1[1] = param_2[1];
        param_1[3] = param_1[3] + 1;
        return puVar1;
      }
    }
    pbVar9 = (byte *)*puVar1;
    uVar7 = param_2[1];
    pbVar6 = (byte *)*param_2;
    if (puVar1[1] == uVar7) {
      if (uVar7 == 0) {
        return puVar1;
      }
      while (uVar4 = uVar7 - 4, 3 < uVar7) {
        if (*(int *)pbVar9 != *(int *)pbVar6) goto LAB_00bbe6eb;
        pbVar9 = pbVar9 + 4;
        pbVar6 = pbVar6 + 4;
        uVar7 = uVar4;
      }
      if (uVar4 == 0xfffffffc) {
LAB_00bbe71f:
        uVar7 = 0;
      }
      else {
LAB_00bbe6eb:
        bVar10 = *pbVar9 < *pbVar6;
        if ((*pbVar9 == *pbVar6) &&
           ((uVar4 == 0xfffffffd ||
            ((bVar10 = pbVar9[1] < pbVar6[1], pbVar9[1] == pbVar6[1] &&
             ((uVar4 == 0xfffffffe ||
              ((bVar10 = pbVar9[2] < pbVar6[2], pbVar9[2] == pbVar6[2] &&
               ((uVar4 == 0xffffffff || (bVar10 = pbVar9[3] < pbVar6[3], pbVar9[3] == pbVar6[3])))))
              ))))))) goto LAB_00bbe71f;
        uVar7 = -(uint)bVar10 | 1;
      }
      if (uVar7 == 0) {
        return puVar1;
      }
    }
    uVar5 = uVar5 + 1 + uStack_8;
    uStack_8 = uStack_8 + 1;
    if (uVar8 < uStack_8) {
      return (undefined4 *)0x0;
    }
  } while( true );
}



/* FUNCTION 26125 ; VA 0x00bbe770 ; FUN_00bbe770 */

void __fastcall FUN_00bbe770(int param_1)

{
  int *piVar1;
  double dVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  double *pdVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  double dStack_3c;
  double dStack_34;
  double dStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdf74;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x5d4) != 0) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef39f0)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef39f0), DAT_01ef39f0 == -1)) {
      uStack_8 = 0;
      uVar9 = FUN_0152dab0();
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar9);
      }
      uStack_8 = 0xffffffff;
      DAT_01ef39e8 = (int)uVar9;
      DAT_01ef39ec = (int)((ulonglong)uVar9 >> 0x20);
      FUN_016f37bf(&DAT_01ef39f0);
    }
    uStack_24 = DAT_01ef39e8;
    uStack_20 = DAT_01ef39ec;
    uVar9 = FUN_01532c80(DAT_01ef39e8,DAT_01ef39ec);
    uStack_8 = 1;
    FUN_016827e0();
    pcVar3 = *(code **)(**(int **)(param_1 + 0x5d4) + 4);
    uVar5 = FUN_00c15e20(&dStack_3c);
    iStack_18 = (*pcVar3)(param_1,uVar5);
    pdVar6 = (double *)FUN_016827e0();
    piVar1 = (int *)(param_1 + 0x5e8);
    dStack_3c = (double)DAT_01d67c54 / DAT_018c0d70;
    dVar2 = *pdVar6;
    dStack_34 = DAT_018c0d60 - dStack_3c;
    *(int *)(param_1 + 0x5e0) = *(int *)(param_1 + 0x5e0) + 1;
    dStack_3c = dStack_3c * (dVar2 - dStack_2c) * DAT_018c0d70;
    *(double *)(param_1 + 0x5d8) = *(double *)(param_1 + 0x5d8) * dStack_34 + dStack_3c;
    iVar7 = DAT_01d67c4c;
    iVar8 = *piVar1;
    iStack_1c = DAT_01d67c44;
    iStack_14 = DAT_01d67c4c;
    if (DAT_01d67c4c != *(int *)(param_1 + 0x5ec) - iVar8 >> 4) {
      *(int *)(param_1 + 0x5ec) = iVar8;
      FUN_00bb9230(iVar7,piVar1);
      iVar8 = *piVar1;
    }
    iVar7 = iStack_18 / iStack_1c;
    if (iStack_14 + -1 <= iStack_18 / iStack_1c) {
      iVar7 = iStack_14 + -1;
    }
    pdVar6 = (double *)(iVar7 * 0x10 + iVar8);
    *(int *)(pdVar6 + 1) = *(int *)(pdVar6 + 1) + 1;
    *pdVar6 = dStack_34 * *pdVar6 + dStack_3c;
    if ((DAT_01d6f4e8 != '\0') || (DAT_01d6f4f0 != '\0')) {
      FUN_00bb7290(*(undefined8 *)(param_1 + 0x5d8));
    }
    uVar4 = uStack_20;
    uVar5 = uStack_24;
    uStack_8 = 2;
    FUN_0152dda0(uStack_24,uStack_20,uVar9);
    if (DAT_01d7ad40 != '\0') {
      FUN_01532d10(uVar5,uVar4,uVar9);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26126 ; VA 0x00bbe9d0 ; FUN_00bbe9d0 */

void FUN_00bbe9d0(void)

{
  FUN_01065e50();
  return;
}



/* FUNCTION 26127 ; VA 0x00bbe9e0 ; FUN_00bbe9e0 */

undefined4 FUN_00bbe9e0(int param_1)

{
  if ((param_1 != 0x1a) && (param_1 != 0)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 26128 ; VA 0x00bbea00 ; FUN_00bbea00 */

undefined4 FUN_00bbea00(int *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x10))();
  if ((iVar1 - 0xcU < 0xe) && ((*(byte *)(param_1 + 0x2b) & 2) == 0)) {
    return 0;
  }
  iVar1 = (**(code **)(*param_1 + 0x10))();
  if ((((5 < iVar1 - 1U) && (iVar1 = (**(code **)(*param_1 + 0x10))(), 0x12 < iVar1 - 7U)) &&
      (iVar1 = (**(code **)(*param_1 + 0x10))(), iVar1 != 0x1a)) && (iVar1 != 0)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 26129 ; VA 0x00bbea60 ; FUN_00bbea60 */

undefined4 __fastcall FUN_00bbea60(int param_1)

{
  FUN_00bbbe60();
  *(undefined *)(param_1 + 0xe9) = 1;
  return 0;
}



/* FUNCTION 26130 ; VA 0x00bbea80 ; FUN_00bbea80 */

void FUN_00bbea80(int *param_1)

{
  int iVar1;
  undefined *puVar2;
  undefined *puVar3;
  undefined *puStack_4c;
  undefined *puStack_48;
  undefined auStack_38 [52];
  
  puStack_48 = (undefined *)0xbbea97;
  iVar1 = FUN_00ffd890();
  if (iVar1 == 0) {
    puVar2 = (undefined *)0x0;
  }
  else {
    puVar2 = (undefined *)(iVar1 + -8);
  }
  puStack_48 = (undefined *)0xbbeaaa;
  iVar1 = FUN_00ffd860();
  if (iVar1 == 0) {
    puVar3 = (undefined *)0x0;
  }
  else {
    puVar3 = (undefined *)(iVar1 + -8);
  }
  if (((puVar2 != (undefined *)0x0) && (puVar3 != (undefined *)0x0)) && (puVar2 != puVar3)) {
    if (DAT_01d66ff4 != '\0') {
      puStack_48 = (undefined *)0xbbeadd;
      iVar1 = (**(code **)(*param_1 + 0x10))();
      if (iVar1 == 4) {
        puStack_4c = (undefined *)0xbbeaea;
        puStack_48 = puVar2;
        puStack_48 = (undefined *)FUN_00ffdc10();
        puStack_4c = (undefined *)0xbbeaf3;
        FUN_00fa0180();
        puStack_4c = (undefined *)0xbbeafe;
        puStack_48 = puVar2;
        FUN_00bbf1c0();
        puStack_4c = (undefined *)0xbbeb0a;
        puStack_48 = puVar3;
        FUN_01066610();
        return;
      }
    }
    puStack_48 = (undefined *)0xbbeb1a;
    iVar1 = (**(code **)(*param_1 + 0x10))();
    if (iVar1 - 1U < 4) {
      puStack_4c = puVar2;
      puStack_48 = puVar3;
      puStack_48 = (undefined *)FUN_00ffdc30(auStack_38);
      puStack_4c = (undefined *)0xbbeb36;
      FUN_00fa0180();
      puStack_4c = (undefined *)0xbbeb41;
      puStack_48 = puVar2;
      FUN_00bbf1c0();
      puStack_4c = (undefined *)0xbbeb4d;
      puStack_48 = puVar3;
      FUN_01066610();
      return;
    }
    puStack_48 = (undefined *)0xbbeb5b;
    iVar1 = (**(code **)(*param_1 + 0x10))();
    if (iVar1 - 5U < 2) {
      if (DAT_01d70918 == '\0') {
        (**(code **)(*param_1 + 0x40))(&puStack_4c);
        FUN_00fa0230();
      }
      else {
        puStack_48 = (undefined *)0xbbeb77;
        iVar1 = (**(code **)(*param_1 + 0x10))();
        if (iVar1 == 6) {
          puStack_4c = auStack_38;
          puStack_48 = puVar2;
          puStack_48 = (undefined *)FUN_01063730();
          puStack_4c = (undefined *)0xbbeb91;
          FUN_00fa0180();
          puStack_4c = (undefined *)0xbbeb9a;
          puStack_48 = puVar2;
          FUN_00bbf1c0();
          return;
        }
        puStack_48 = (undefined *)0xbbeba8;
        iVar1 = (**(code **)(*param_1 + 0x10))();
        if (iVar1 == 5) {
          puStack_4c = auStack_38;
          puStack_48 = puVar2;
          puStack_48 = (undefined *)FUN_010649c0();
          puStack_4c = (undefined *)0xbbebc2;
          FUN_00fa0180();
          puStack_4c = (undefined *)0xbbebcb;
          puStack_48 = puVar2;
          FUN_00bbf1c0();
          return;
        }
      }
      puStack_4c = (undefined *)0xbbebec;
      puStack_48 = puVar2;
      FUN_00bbf1c0();
    }
  }
  return;
}



/* FUNCTION 26131 ; VA 0x00bbebd4 ; FUN_00bbebd4 */

void __fastcall FUN_00bbebd4(undefined4 param_1,int param_2)

{
  undefined *puVar1;
  
  puVar1 = &stack0xfffffff8;
  (**(code **)(param_2 + 0x40))(&stack0xfffffff8);
  FUN_00fa0230(puVar1);
  FUN_00bbf1c0();
  return;
}



/* FUNCTION 26132 ; VA 0x00bbec00 ; FUN_00bbec00 */

bool __thiscall FUN_00bbec00(int param_1,double param_2,undefined4 param_3,undefined *param_4)

{
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_0094f6a0(&iStack_8,&param_3);
  if (iStack_8 != *(int *)(param_1 + 0x38)) {
    if (param_4 != (undefined *)0x0) {
      *param_4 = *(undefined *)(iStack_8 + 0x10);
    }
    return param_2 < (double)*(float *)(iStack_8 + 0xc) + DAT_0195cda0;
  }
  return false;
}



/* FUNCTION 26133 ; VA 0x00bbec60 ; FUN_00bbec60 */

void __thiscall FUN_00bbec60(int param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  int iVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  uint *puVar10;
  int iVar11;
  uint uVar12;
  int *piVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fdfc4;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01ef37b0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef37b0), cVar6 = DAT_01d7ad48,
     DAT_01ef37b0 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0(&DAT_018cb3fc,"notifyMovingAssemblies",0xffffffff);
    if ((cVar6 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar14);
    }
    uStack_8 = 0xffffffff;
    DAT_01ef37a8 = (int)uVar14;
    DAT_01ef37ac = (int)((ulonglong)uVar14 >> 0x20);
    FUN_016f37bf(&DAT_01ef37b0);
  }
  uVar8 = DAT_01ef37ac;
  uVar7 = DAT_01ef37a8;
  cVar6 = DAT_01d7ad48;
  uVar14 = FUN_01532c80(DAT_01ef37a8,DAT_01ef37ac);
  uStack_8 = 1;
  if (DAT_01d70950 == '\0') {
    if (param_2 != '\0') {
      if (DAT_01d70970 == '\0') {
        puVar1 = (undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x28);
        FUN_00bb9660(*puVar1,puVar1,FUN_00bbb9c0);
        puVar1 = (undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x1c);
        FUN_00bb9660(*puVar1,puVar1,FUN_00bbb9c0);
      }
      else {
        FUN_00bbf180(*(int *)(param_1 + 0x6ec) + 0x3c);
        FUN_00bbf180(*(int *)(param_1 + 0x6ec) + 0x30);
      }
    }
    FUN_00bb96b0(*(int *)(param_1 + 0x6dc) + 0x34);
    FUN_00bb96b0(*(int *)(param_1 + 0x6dc) + 0x3c);
    if (param_2 != '\0') {
      FUN_00bb96b0(*(int *)(param_1 + 0x6e4) + 0x10);
    }
  }
  else {
    if (param_2 != '\0') {
      if (DAT_01d70970 == '\0') {
        puVar1 = (undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x28);
        FUN_00bb9660(*puVar1,puVar1,FUN_00bbb9c0);
        puVar1 = (undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x1c);
        FUN_00bb9660(*puVar1,puVar1,FUN_00bbb9c0);
        FUN_00bb9720(*(int *)(param_1 + 0x6e4) + 0x10);
      }
      else {
        if ((*(int *)(iVar2 + 0x34) < DAT_01ef37c0) &&
           (FUN_016f3809(&DAT_01ef37c0), DAT_01ef37c0 == -1)) {
          uStack_8._0_1_ = 2;
          uVar15 = FUN_0152da50(&DAT_018cb3fc);
          DAT_01ef37bc = (undefined4)((ulonglong)uVar15 >> 0x20);
          DAT_01ef37b8 = (undefined4)uVar15;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01ef37c0);
        }
        FUN_0152d760(DAT_01ef37b8,DAT_01ef37bc,"High Priority Assemblies %d",
                     *(int *)(*(int *)(param_1 + 0x6ec) + 0x40) -
                     *(int *)(*(int *)(param_1 + 0x6ec) + 0x3c) >> 2);
        if ((*(int *)(iVar2 + 0x34) < DAT_01ef37d0) &&
           (FUN_016f3809(&DAT_01ef37d0), DAT_01ef37d0 == -1)) {
          uStack_8._0_1_ = 3;
          uVar15 = FUN_0152da50(&DAT_018cb3fc);
          DAT_01ef37cc = (undefined4)((ulonglong)uVar15 >> 0x20);
          DAT_01ef37c8 = (undefined4)uVar15;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01ef37d0);
        }
        FUN_0152d760(DAT_01ef37c8,DAT_01ef37cc,"Low Priority Assemblies %d",
                     *(int *)(*(int *)(param_1 + 0x6ec) + 0x34) -
                     *(int *)(*(int *)(param_1 + 0x6ec) + 0x30) >> 2);
        if ((*(int *)(iVar2 + 0x34) < DAT_01ef37e0) &&
           (FUN_016f3809(&DAT_01ef37e0), DAT_01ef37e0 == -1)) {
          uStack_8._0_1_ = 4;
          uVar15 = FUN_0152da50(&DAT_018cb3fc);
          DAT_01ef37dc = (undefined4)((ulonglong)uVar15 >> 0x20);
          DAT_01ef37d8 = (undefined4)uVar15;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01ef37e0);
        }
        FUN_0152d760(DAT_01ef37d8,DAT_01ef37dc,"MovingHumanoid Assemblies %d",
                     *(undefined4 *)(*(int *)(param_1 + 0x6e4) + 0x14));
        FUN_00bbf180(*(int *)(param_1 + 0x6ec) + 0x3c);
        FUN_00bbf180(*(int *)(param_1 + 0x6ec) + 0x30);
        FUN_00bb9720(*(int *)(param_1 + 0x6e4) + 0x10);
      }
    }
    iVar11 = 0;
    puVar3 = *(uint **)(*(int *)(param_1 + 0x6dc) + 0x54);
    for (puVar10 = *(uint **)(*(int *)(param_1 + 0x6dc) + 0x50); puVar10 != puVar3;
        puVar10 = puVar10 + 3) {
      piVar4 = (int *)puVar10[1];
      piVar13 = (int *)*puVar10;
      iVar11 = iVar11 + ((int)piVar4 - (int)piVar13 >> 2);
      uVar12 = 0;
      uVar9 = (uint)((int)piVar4 + (3 - (int)piVar13)) >> 2;
      if (piVar4 < piVar13) {
        uVar9 = 0;
      }
      if (uVar9 != 0) {
        do {
          iVar5 = *piVar13;
          FUN_00ca1ae0(iVar5,0);
          uVar12 = uVar12 + 1;
          *(undefined *)(iVar5 + 0x227) = 0;
          piVar13 = piVar13 + 1;
        } while (uVar12 != uVar9);
      }
    }
    if ((*(int *)(iVar2 + 0x34) < DAT_01ef37f0) && (FUN_016f3809(&DAT_01ef37f0), DAT_01ef37f0 == -1)
       ) {
      uStack_8._0_1_ = 5;
      uVar15 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef37ec = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01ef37e8 = (undefined4)uVar15;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ef37f0);
    }
    FUN_0152d760(DAT_01ef37e8,DAT_01ef37ec,"MovingPrimitives %d",iVar11);
  }
  uStack_8 = 6;
  FUN_0152dda0(uVar7,uVar8,uVar14);
  if ((cVar6 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar7,uVar8,uVar14);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26134 ; VA 0x00bbefaf ; FUN_00bbefaf */

void FUN_00bbefaf(void)

{
  int unaff_EBP;
  
  FUN_01532d10();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 26135 ; VA 0x00bbf180 ; FUN_00bbf180 */

void FUN_00bbf180(uint *param_1)

{
  uint uVar1;
  int *piVar2;
  uint uVar3;
  
  piVar2 = (int *)*param_1;
  uVar3 = 0;
  uVar1 = (uint)((int)param_1[1] + (3 - (int)piVar2)) >> 2;
  if ((int *)param_1[1] < piVar2) {
    uVar1 = 0;
  }
  if (uVar1 != 0) {
    do {
      if (*(char *)(*piVar2 + 0x78) == '\0') {
        FUN_00ca1b70();
      }
      uVar3 = uVar3 + 1;
      piVar2 = piVar2 + 1;
    } while (uVar3 != uVar1);
  }
  return;
}



/* FUNCTION 26136 ; VA 0x00bbf1c0 ; FUN_00bbf1c0 */

void FUN_00bbf1c0(int param_1)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  
  if (param_1 != 0) {
    FUN_00c3e3a0();
    iVar4 = 0;
    if (0 < *(int *)(param_1 + 0x14)) {
      do {
        iVar1 = *(int *)(*(int *)(param_1 + 0x10) + iVar4 * 4);
        uVar3 = -(uint)(iVar1 != 0) & iVar1 - 8U;
        cVar2 = FUN_00ca1a80(uVar3);
        if (cVar2 == '\0') {
          FUN_00bbf1c0(uVar3);
        }
        iVar4 = iVar4 + 1;
      } while (iVar4 < *(int *)(param_1 + 0x14));
    }
  }
  return;
}



/* FUNCTION 26137 ; VA 0x00bbf220 ; FUN_00bbf220 */

void FUN_00bbf220(int param_1)

{
  if (DAT_01d70950 != '\0') {
    *(undefined *)(param_1 + 0x78) = 1;
    return;
  }
  FUN_01068210();
  return;
}



/* FUNCTION 26138 ; VA 0x00bbf250 ; FUN_00bbf250 */

void FUN_00bbf250(void)

{
  FUN_01065160();
  return;
}



/* FUNCTION 26139 ; VA 0x00bbf260 ; FUN_00bbf260 */

void FUN_00bbf260(void)

{
  FUN_010651a0();
  return;
}



/* FUNCTION 26140 ; VA 0x00bbf270 ; FUN_00bbf270 */

void FUN_00bbf270(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  for (piVar1 = (int *)FUN_00c159e0(); piVar1 != (int *)0x0; piVar1 = (int *)FUN_00c161b0(piVar1)) {
    iVar2 = piVar1[1];
    if (param_1 == iVar2) {
      iVar2 = piVar1[2];
    }
    if ((iVar2 != 0) && (iVar2 = FUN_00c155c0(), iVar2 != 0)) {
      uVar3 = FUN_00c19fc0(iVar2);
      FUN_010694d0(uVar3,0);
    }
    (**(code **)(*piVar1 + 0x24))();
  }
  if ((param_1 != 0) && (iVar2 = FUN_00c155c0(), iVar2 != 0)) {
    uVar3 = FUN_00c19fc0(iVar2);
    FUN_010694d0(uVar3,0);
  }
  return;
}



/* FUNCTION 26141 ; VA 0x00bbf310 ; FUN_00bbf310 */

void FUN_00bbf310(void)

{
  FUN_01066940();
  return;
}



/* FUNCTION 26142 ; VA 0x00bbf320 ; FUN_00bbf320 */

void FUN_00bbf320(void)

{
  FUN_01066970();
  return;
}



/* FUNCTION 26143 ; VA 0x00bbf330 ; FUN_00bbf330 */

void FUN_00bbf330(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_1c [24];
  
  if (DAT_01d69070 != '\0') {
    FUN_00ce7450(param_1);
    uVar1 = FUN_00c15960();
    uVar2 = FUN_00bbd7b0(auStack_1c);
    FUN_00bbf390(param_1,uVar2,uVar1);
    return;
  }
  FUN_00ce7450(param_1);
  return;
}



/* FUNCTION 26144 ; VA 0x00bbf390 ; FUN_00bbf390 */

void FUN_00bbf390(undefined4 param_1,float *param_2,float *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  float10 fVar4;
  double dVar5;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  double dStack_24;
  double dStack_1c;
  double dStack_14;
  int iStack_c;
  float fStack_8;
  
  fStack_8 = (float)DAT_01d68adc / DAT_018ce320;
  dVar5 = (double)((param_2[1] - param_3[1]) * (param_2[1] - param_3[1]) +
                   (*param_2 - *param_3) * (*param_2 - *param_3) +
                  (param_2[2] - param_3[2]) * (param_2[2] - param_3[2]));
  if (NAN(dVar5) == (dVar5 == 0.0)) {
    uVar1 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    dStack_14 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar1,
                                 SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    dStack_24 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & uVar1,
                                 SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
    fVar4 = (float10)FUN_01160810();
    dStack_1c = (double)fVar4;
    dVar5 = DAT_018f76b0;
    if ((NAN(dStack_14) || NAN(dStack_1c)) == (dStack_14 == dStack_1c)) {
      dVar5 = dStack_14 * DAT_018f76b0;
    }
    if (dVar5 < dStack_24) goto LAB_00bbf4ff;
  }
  dVar5 = (double)((param_2[4] - param_3[4]) * (param_2[4] - param_3[4]) +
                   (param_2[3] - param_3[3]) * (param_2[3] - param_3[3]) +
                  (param_2[5] - param_3[5]) * (param_2[5] - param_3[5]));
  if (NAN(dVar5) != (dVar5 == 0.0)) {
    return;
  }
  uVar1 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  dStack_24 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & uVar1,
                               SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
  dStack_14 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & uVar1,
                               SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
  fVar4 = (float10)FUN_01160810();
  dStack_1c = (double)fVar4;
  dVar5 = DAT_018f76b0;
  if ((NAN(dStack_24) || NAN(dStack_1c)) == (dStack_24 == dStack_1c)) {
    dVar5 = dStack_24 * DAT_018f76b0;
  }
  if (dStack_14 <= dVar5) {
    return;
  }
LAB_00bbf4ff:
  puVar2 = *(undefined4 **)(iStack_c + 0x22c);
  fStack_54 = *param_2 - fStack_8;
  fStack_50 = param_2[1] - fStack_8;
  uVar3 = 0;
  fStack_3c = *param_3 - fStack_8;
  fStack_4c = param_2[2] - fStack_8;
  uVar1 = (uint)((int)*(undefined4 **)(iStack_c + 0x230) + (3 - (int)puVar2)) >> 2;
  if (*(undefined4 **)(iStack_c + 0x230) < puVar2) {
    uVar1 = 0;
  }
  fStack_48 = fStack_8 + param_2[3];
  fStack_44 = (float)*(undefined8 *)(param_2 + 4);
  fStack_40 = (float)((ulonglong)*(undefined8 *)(param_2 + 4) >> 0x20);
  _fStack_44 = CONCAT44(fStack_8 + fStack_40,fStack_8 + fStack_44);
  fStack_38 = param_3[1] - fStack_8;
  fStack_34 = param_3[2] - fStack_8;
  fStack_30 = fStack_8 + param_3[3];
  fStack_2c = (float)*(undefined8 *)(param_3 + 4);
  fStack_28 = (float)((ulonglong)*(undefined8 *)(param_3 + 4) >> 0x20);
  _fStack_2c = CONCAT44(fStack_8 + fStack_28,fStack_8 + fStack_2c);
  if (uVar1 != 0) {
    do {
      (*(code *)**(undefined4 **)*puVar2)(param_1,&fStack_54,&fStack_3c);
      uVar3 = uVar3 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar3 != uVar1);
  }
  FUN_00bc26c0();
  return;
}



/* FUNCTION 26145 ; VA 0x00bbf620 ; FUN_00bbf620 */

void FUN_00bbf620(void)

{
  FUN_010656b0();
  return;
}



/* FUNCTION 26146 ; VA 0x00bbf630 ; FUN_00bbf630 */

void FUN_00bbf630(void)

{
  FUN_010657b0();
  return;
}



/* FUNCTION 26147 ; VA 0x00bbf640 ; FUN_00bbf640 */

void FUN_00bbf640(void)

{
  FUN_00ce7670();
  return;
}



/* FUNCTION 26148 ; VA 0x00bbf650 ; FUN_00bbf650 */

void __thiscall FUN_00bbf650(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  
  if ((param_2 != 0) && (iVar1 = FUN_00c155c0(), iVar1 != 0)) {
    uVar2 = FUN_00c19fc0(iVar1);
    FUN_010694d0(uVar2,0);
  }
  for (iVar1 = FUN_00c159e0(); iVar1 != 0; iVar1 = FUN_00c161b0(iVar1)) {
    iVar3 = *(int *)(iVar1 + 4);
    if (param_2 == iVar3) {
      iVar3 = *(int *)(iVar1 + 8);
    }
    if ((iVar3 != 0) && (iVar3 = FUN_00c155c0(), iVar3 != 0)) {
      uVar2 = FUN_00c19fc0(iVar3);
      FUN_010694d0(uVar2,0);
    }
  }
  FUN_00ce7880(param_2);
  if ((DAT_01d69070 != '\0') && (DAT_01d69098 == '\0')) {
    puVar5 = *(undefined4 **)(param_1 + 0x22c);
    uVar6 = 0;
    uVar4 = (uint)((int)*(undefined4 **)(param_1 + 0x230) + (3 - (int)puVar5)) >> 2;
    if (*(undefined4 **)(param_1 + 0x230) < puVar5) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      do {
        (**(code **)(*(int *)*puVar5 + 8))(param_2);
        uVar6 = uVar6 + 1;
        puVar5 = puVar5 + 1;
      } while (uVar6 != uVar4);
    }
  }
  return;
}



/* FUNCTION 26149 ; VA 0x00bbf740 ; FUN_00bbf740 */

void __thiscall FUN_00bbf740(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar2 = *(undefined4 **)(param_1 + 0x22c);
  uVar1 = (uint)((int)*(undefined4 **)(param_1 + 0x230) + (3 - (int)puVar2)) >> 2;
  uVar3 = 0;
  if (*(undefined4 **)(param_1 + 0x230) < puVar2) {
    uVar1 = 0;
  }
  if (uVar1 != 0) {
    do {
      (**(code **)(*(int *)*puVar2 + 8))(param_2);
      uVar3 = uVar3 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar3 != uVar1);
  }
  return;
}



/* FUNCTION 26150 ; VA 0x00bbf790 ; FUN_00bbf790 */

/* WARNING: Removing unreachable block (ram,0x00bbf8a6) */
/* WARNING: Removing unreachable block (ram,0x00bbf873) */
/* WARNING: Removing unreachable block (ram,0x00bbf8b5) */
/* WARNING: Removing unreachable block (ram,0x00bbf8e7) */
/* WARNING: Removing unreachable block (ram,0x00bbf8c5) */

void __thiscall FUN_00bbf790(int param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int *piStack_28;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fdfd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    if (0x3fffffff < uVar1) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_007cfd20(uVar1);
  }
  piStack_28 = (int *)0x0;
  puStack_14 = (undefined4 *)FUN_00c15a50();
  while (puStack_14 != (undefined4 *)0x0) {
    if (piStack_28 == (int *)0x0) {
      FUN_0063d9b0(0,&puStack_14);
    }
    else {
      *piStack_28 = (int)puStack_14;
      piStack_28 = piStack_28 + 1;
    }
    (**(code **)(**(int **)(param_1 + 0x6b4) + 0xc))(puStack_14);
    puStack_14 = (undefined4 *)FUN_00c15a50();
  }
  puVar2 = (undefined4 *)0x0;
  uVar1 = (int)piStack_28 + 3U >> 2;
  if (uVar1 != 0) {
    uVar3 = 0;
    puStack_14 = puVar2;
    do {
      (**(code **)(**(int **)(param_1 + 0x6b4) + 8))(*puVar2);
      uVar3 = uVar3 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar3 != uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26151 ; VA 0x00bbf8f0 ; FUN_00bbf8f0 */

void FUN_00bbf8f0(uint param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe004;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3870) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef3870), DAT_01ef3870 == -1)) {
    uStack_8 = 0;
    uVar6 = FUN_0152dab0(&DAT_018cb3fc,"onlyAddCurrentAssemblies",0xffffffff);
    DAT_01ef386c = (undefined4)((ulonglong)uVar6 >> 0x20);
    DAT_01ef3868 = (undefined4)uVar6;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ef3870);
  }
  uVar4 = DAT_01ef386c;
  uVar3 = DAT_01ef3868;
  uVar6 = FUN_0152d930(DAT_01ef3868,DAT_01ef386c);
  uStack_8 = 1;
  puVar1 = (undefined4 *)param_2[1];
  for (param_2 = (undefined4 *)*param_2; param_2 != puVar1; param_2 = param_2 + 1) {
    uVar5 = FUN_00ca1560();
    if (param_1 % uVar5 == 0) {
      FUN_00ca1f70(0);
      FUN_00ca2240(param_1);
      puVar2 = *(undefined4 **)(param_3 + 4);
      if (*(undefined4 **)(param_3 + 8) == puVar2) {
        FUN_006030d0(puVar2,param_2);
      }
      else {
        *puVar2 = *param_2;
        *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 4;
      }
    }
    else {
      FUN_00ca1f70(1);
    }
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26152 ; VA 0x00bbfa50 ; FUN_00bbfa50 */

void __thiscall
FUN_00bbfa50(int param_1,double param_2,undefined4 param_3,undefined4 *param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  double dVar11;
  undefined8 uVar12;
  undefined **appuStack_6c [2];
  int *piStack_64;
  int iStack_60;
  int *piStack_5c;
  int *piStack_58;
  double dStack_54;
  float fStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined uStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe03c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3a00) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef3a00), DAT_01ef3a00 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","HumanoidAdornRaycasts",0xffffffff);
    DAT_01ef39fc = (int)((ulonglong)uVar12 >> 0x20);
    DAT_01ef39f8 = (int)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ef3a00);
  }
  iVar3 = DAT_01ef39fc;
  iVar1 = DAT_01ef39f8;
  iStack_20 = DAT_01ef39f8;
  iStack_24 = DAT_01ef39fc;
  uVar12 = FUN_0152d930(DAT_01ef39f8,DAT_01ef39fc);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iStack_1c = 0;
  if (*(int *)(param_1 + 0x30) != 0) {
    dStack_54 = DAT_0195cda0;
    do {
      if (param_5 <= iStack_1c) break;
      puVar5 = *(undefined4 **)(param_1 + 0x20);
      if (puVar5 != (undefined4 *)0x0) {
        puVar5 = (undefined4 *)*puVar5;
      }
      piVar7 = *(int **)(puVar5[1] + (puVar5[2] - 1 & *(uint *)(param_1 + 0x2c)) * 4);
      piStack_5c = (int *)piVar7[1];
      if (piStack_5c != (int *)0x0) {
        LOCK();
        piStack_5c[2] = piStack_5c[2] + 1;
        UNLOCK();
        piStack_5c = (int *)piVar7[1];
      }
      iStack_60 = *piVar7;
      piVar7 = (int *)piVar7[2];
      piVar8 = *(int **)(*(int *)(*(int *)(param_1 + 0x24) +
                                 (*(int *)(param_1 + 0x28) - 1U & *(uint *)(param_1 + 0x2c)) * 4) +
                        4);
      piStack_58 = piVar7;
      piStack_18 = piStack_5c;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar2 = piVar8[2] + -1;
        piVar8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      piVar8 = (int *)(param_1 + 0x30);
      *piVar8 = *piVar8 + -1;
      if (*piVar8 == 0) {
        *(undefined4 *)(param_1 + 0x2c) = 0;
      }
      else {
        *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + 1;
      }
      iVar2 = *(int *)(param_1 + 0xc);
      uVar10 = *(uint *)(param_1 + 0x18) &
               ((((*(byte *)(piVar7 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar7 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar7 + 10))
                * 0x1000193 ^ (uint)*(byte *)((int)piVar7 + 0xb)) * 0x1000193;
      if (*(int **)(iVar2 + 4 + uVar10 * 8) == piVar7) {
        if (*(int **)(iVar2 + uVar10 * 8) == piVar7) {
          *(undefined4 *)(iVar2 + uVar10 * 8) = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + uVar10 * 8) = *(undefined4 *)(param_1 + 4);
        }
        else {
          *(int *)(iVar2 + 4 + uVar10 * 8) = piVar7[1];
        }
      }
      else if (*(int **)(iVar2 + uVar10 * 8) == piVar7) {
        *(int *)(iVar2 + uVar10 * 8) = *piVar7;
      }
      *(int *)piVar7[1] = *piVar7;
      *(int *)(*piVar7 + 4) = piVar7[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar7,0xc);
      iStack_3c = 0;
      piStack_38 = (int *)0x0;
      if (piStack_18 != (int *)0x0) {
        piVar7 = piStack_18 + 1;
        iVar2 = piStack_18[1];
        while (iVar2 != 0) {
          LOCK();
          iVar6 = *piVar7;
          if (iVar2 == iVar6) {
            *piVar7 = iVar2 + 1;
            iVar6 = iVar2;
          }
          UNLOCK();
          if (iVar6 == iVar2) {
            iStack_3c = iStack_60;
            piStack_38 = piStack_18;
            break;
          }
          iVar2 = *piVar7;
        }
      }
      piVar7 = piStack_38;
      uStack_8._0_1_ = 3;
      if ((iStack_3c != 0) &&
         ((iStack_24 = iStack_3c, FUN_0094f6a0(&iStack_28,&iStack_24),
          iStack_28 == *(int *)(param_1 + 0x38) ||
          ((double)*(float *)(iStack_28 + 0xc) + dStack_54 <= param_2)))) {
        iStack_20 = (**(code **)*param_4)();
        iStack_24 = FUN_009b4d50();
        if (iStack_24 != 0) {
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
          }
          FUN_00f9b980(iStack_3c,piVar7);
          uStack_8._0_1_ = 4;
          uVar4 = FUN_00d22b90(iStack_24,param_3,appuStack_6c);
          iStack_48 = CONCAT31(iStack_48._1_3_,uVar4);
          fStack_4c = (float)param_2;
          iStack_20 = iStack_3c;
          FUN_0094f6a0(&piStack_2c,&iStack_20);
          if (piStack_2c == *(int **)(param_1 + 0x38)) {
            piStack_30 = &iStack_20;
            iStack_24 = **(int **)(param_1 + 0x38);
            piStack_34 = *(int **)(iStack_24 + 4);
            piStack_30 = (int *)FUN_00bb8ff0(iStack_24,piStack_34,&DAT_018bdeda,&piStack_30,
                                             &uStack_11);
            if (*(int *)(param_1 + 0x3c) == 0xccccccb) {
                    /* WARNING: Subroutine does not return */
              FUN_016ddcd9("list<T> too long");
            }
            *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 1;
            *(int **)(iStack_24 + 4) = piStack_30;
            *piStack_34 = (int)piStack_30;
            FUN_00bb9020(&piStack_44,**(int **)(param_1 + 0x38) + 8,**(int **)(param_1 + 0x38));
          }
          else {
            piStack_44 = piStack_2c;
            uStack_40 = 0;
          }
          iStack_1c = iStack_1c + 1;
          piStack_44[3] = (int)fStack_4c;
          piStack_44[4] = iStack_48;
          piStack_34 = piStack_64;
          if (piStack_64 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_64[1] + -1;
            piStack_64[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_64)();
              LOCK();
              iVar2 = piStack_34[2] + -1;
              piStack_34[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_34 + 4))();
              }
            }
          }
          appuStack_6c[0] = RBX::HitTestFilter::vftable;
        }
      }
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar2 = piVar7[1] + -1;
        piVar7[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar2 = piVar7[2] + -1;
          piVar7[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    } while (*(int *)(param_1 + 0x30) != 0);
    iStack_24 = iVar3;
    iStack_20 = iVar1;
  }
  piVar7 = *(int **)(param_1 + 0x38);
  if ((int *)*piVar7 != piVar7) {
    dStack_54 = DAT_018d8a10;
    piVar8 = (int *)*piVar7;
    dVar11 = DAT_018d8a10;
    do {
      if (param_2 <= (double)(float)piVar8[3] + dVar11) {
        piVar9 = (int *)*piVar8;
      }
      else {
        uVar10 = *(uint *)(param_1 + 0x4c) &
                 ((((*(byte *)(piVar8 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                   (uint)*(byte *)((int)piVar8 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar8 + 10)
                  ) * 0x1000193 ^ (uint)*(byte *)((int)piVar8 + 0xb)) * 0x1000193;
        iVar1 = *(int *)(param_1 + 0x40);
        if (*(int **)(iVar1 + 4 + uVar10 * 8) == piVar8) {
          if (*(int **)(iVar1 + uVar10 * 8) == piVar8) {
            *(int **)(iVar1 + uVar10 * 8) = piVar7;
            *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + uVar10 * 8) =
                 *(undefined4 *)(param_1 + 0x38);
          }
          else {
            *(int *)(iVar1 + 4 + uVar10 * 8) = piVar8[1];
          }
        }
        else if (*(int **)(iVar1 + uVar10 * 8) == piVar8) {
          *(int *)(iVar1 + uVar10 * 8) = *piVar8;
        }
        piVar9 = (int *)*piVar8;
        *(int **)piVar8[1] = piVar9;
        *(int *)(*piVar8 + 4) = piVar8[1];
        *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + -1;
        FUN_01674ea0(piVar8,0x14);
        piVar7 = *(int **)(param_1 + 0x38);
        dVar11 = dStack_54;
      }
      piVar8 = piVar9;
    } while (piVar9 != piVar7);
  }
  uStack_8 = 5;
  FUN_0152dda0(iStack_20,iStack_24,uVar12);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26153 ; VA 0x00bbff80 ; FUN_00bbff80 */

undefined4 __thiscall FUN_00bbff80(int param_1,int param_2,byte param_3)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  
  cVar1 = *(char *)(param_2 + 0x22a);
  if (DAT_01d66528 == '\0') {
    if (cVar1 < ' ') {
      uVar2 = 1 << (param_3 & 0x1f);
      return CONCAT31((int3)(uVar2 >> 8),(*(uint *)(param_1 + 0x118 + cVar1 * 8) & uVar2) != 0);
    }
  }
  else if (cVar1 < ' ') {
    uVar2 = 1 << (param_3 & 0x1f);
    return CONCAT31((int3)(uVar2 >> 8),(*(uint *)(param_1 + 0x538 + cVar1 * 4) & uVar2) != 0);
  }
  iVar3 = 1 << (param_3 & 0x1f);
  return CONCAT31((int3)((uint)iVar3 >> 8),iVar3 != 0);
}



/* FUNCTION 26154 ; VA 0x00bbfff0 ; FUN_00bbfff0 */

undefined4 __thiscall FUN_00bbfff0(int param_1,int param_2,int param_3)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  
  bVar1 = *(byte *)(param_3 + 0x22a);
  cVar2 = *(char *)(param_2 + 0x22a);
  if (DAT_01d66528 == '\0') {
    if (cVar2 < ' ') {
      uVar3 = 1 << (bVar1 & 0x1f);
      return CONCAT31((int3)(uVar3 >> 8),(*(uint *)(param_1 + 0x118 + cVar2 * 8) & uVar3) != 0);
    }
  }
  else if (cVar2 < ' ') {
    uVar3 = 1 << (bVar1 & 0x1f);
    return CONCAT31((int3)(uVar3 >> 8),(*(uint *)(param_1 + 0x538 + cVar2 * 4) & uVar3) != 0);
  }
  iVar4 = 1 << (bVar1 & 0x1f);
  return CONCAT31((int3)((uint)iVar4 >> 8),iVar4 != 0);
}



/* FUNCTION 26155 ; VA 0x00bc0070 ; FUN_00bc0070 */

uint * __thiscall FUN_00bc0070(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  uint *puVar5;
  undefined4 uVar6;
  uint uVar7;
  uint *puVar8;
  uint *puVar9;
  int iVar10;
  uint uStack_28;
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe068;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puVar5 = (uint *)FUN_00587490(&uStack_28);
  iVar2 = iStack_14;
  uStack_8._0_1_ = 1;
  if (uStack_28 != 0) {
    uVar7 = *(uint *)(param_1 + 0x18) &
            ((((uStack_28 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ (int)uStack_28 >> 8 & 0xffU) *
              0x1000193 ^ (int)uStack_28 >> 0x10 & 0xffU) * 0x1000193 ^
            (int)uStack_28 >> 0x18 & 0xffU) * 0x1000193;
    uStack_20 = *(uint *)(param_1 + 0xc);
    puVar3 = *(uint **)(uStack_20 + uVar7 * 8);
    iStack_18 = uVar7 * 8 + 4;
    puVar4 = *(uint **)(iStack_14 + 4);
    puVar8 = puVar3;
    while( true ) {
      puVar5 = puVar4;
      if (puVar3 != puVar4) {
        puVar5 = (uint *)**(undefined4 **)(iStack_18 + uStack_20);
      }
      puVar9 = puVar4;
      if ((puVar8 == puVar5) || (puVar9 = puVar8, puVar8[2] == uStack_28)) break;
      puVar8 = (uint *)*puVar8;
    }
    if (puVar9 == puVar4) {
      uStack_20 = uStack_28;
      FUN_00708ea0(&uStack_1c,&uStack_20,param_3);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      uVar7 = *(uint *)(iVar2 + 0x28);
      uStack_8._0_1_ = 2;
      if (uVar7 <= *(int *)(iVar2 + 0x30) + 1U) {
        FUN_00716150(1);
        uVar7 = *(uint *)(iVar2 + 0x28);
      }
      *(uint *)(iVar2 + 0x2c) = *(uint *)(iVar2 + 0x2c) & uVar7 - 1;
      iVar10 = *(int *)(iVar2 + 0x24);
      uVar7 = *(int *)(iVar2 + 0x30) + *(int *)(iVar2 + 0x2c) & *(int *)(iVar2 + 0x28) - 1U;
      iStack_14 = uVar7 * 4;
      if (*(int *)(iVar10 + uVar7 * 4) == 0) {
        uVar6 = FUN_01674e20(0xc);
        *(undefined4 *)(iStack_14 + *(int *)(iVar2 + 0x24)) = uVar6;
        iVar10 = *(int *)(iVar2 + 0x24);
      }
      puVar5 = *(uint **)(iVar10 + iStack_14);
      *puVar5 = uStack_28;
      puVar5[1] = (uint)piStack_24;
      puVar5[2] = uStack_1c;
      *(int *)(iVar2 + 0x30) = *(int *)(iVar2 + 0x30) + 1;
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    puVar5 = (uint *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      puVar5 = (uint *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar5 = (uint *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puVar5 = (uint *)(**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 26156 ; VA 0x00bc0230 ; FUN_00bc0230 */

undefined4 __fastcall FUN_00bc0230(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x50);
  iVar2 = *(int *)(param_1 + 0x5c);
  if (DAT_01d67c90 == '\0') {
    iVar3 = FUN_00bb5bf0();
  }
  else {
    iVar3 = *(int *)(param_1 + 0x60c);
  }
  return CONCAT31((int3)((uint)(iVar3 * DAT_01d67c04) >> 8),
                  iVar3 * DAT_01d67c04 * 0x3c < iVar1 - iVar2);
}



/* FUNCTION 26157 ; VA 0x00bc0270 ; FUN_00bc0270 */

void FUN_00bc0270(void)

{
  FUN_010680d0();
  return;
}



/* FUNCTION 26158 ; VA 0x00bc0280 ; FUN_00bc0280 */

ulonglong __thiscall FUN_00bc0280(int param_1,uint *param_2)

{
  uint *puVar1;
  char *pcVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 extraout_EDX;
  int extraout_EDX_00;
  char cVar5;
  char cVar6;
  uint *puVar7;
  uint uVar8;
  uint *puVar9;
  int iVar10;
  undefined8 uVar11;
  uint *puStack_14;
  uint uStack_10;
  int iStack_c;
  undefined4 *puStack_8;
  
  puVar1 = param_2;
  iStack_c = param_1;
  if (DAT_01d66528 == '\0') {
    iVar10 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
    uVar3 = FUN_005702d0(param_2);
    FUN_00562fc0(&param_2,uVar3,puVar1,-(uint)(iVar10 != 0) & iVar10 + 1U);
    puVar1 = param_2;
    uVar3 = extraout_EDX;
    if (param_2 != (uint *)0x0) {
      uVar8 = (uint)(char)*(byte *)(param_2 + 8);
      *(undefined *)(param_1 + 0x114 + uVar8 * 8) = 0;
      *(undefined4 *)(param_1 + 0x118 + uVar8 * 8) = 0xffffffff;
      FUN_00bbcd00(&param_2,param_2);
      iVar10 = extraout_EDX_00;
      if (*(int *)(param_1 + 0x21c) == 0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x228) + *(int *)(param_1 + 0x218) * 4);
      }
      for (; puVar4 != (undefined4 *)0x0; puVar4 = (undefined4 *)*puVar4) {
        iVar10 = param_1 + *(char *)(puVar4 + 8) * 8;
        *(uint *)(iVar10 + 0x118) = *(uint *)(iVar10 + 0x118) | 1 << (uVar8 & 0x1f);
      }
      return CONCAT44(iVar10,1);
    }
  }
  else {
    puStack_8 = (undefined4 *)(param_1 + 0x5b8);
    uStack_10 = param_2[4];
    puStack_14 = param_2;
    if (0xf < param_2[5]) {
      puStack_14 = (uint *)*param_2;
    }
    uVar11 = FUN_00bbcde0(&puStack_14);
    uVar3 = (undefined4)((ulonglong)uVar11 >> 0x20);
    puVar1 = (uint *)(-(uint)((int)uVar11 != 0) & (int)uVar11 + 8U);
    if (puVar1 != (uint *)0x0) {
      iVar10 = (uint)*(byte *)puVar1 << 8;
      puVar1 = (uint *)*puStack_8;
      puStack_8[1] = puVar1;
      puVar9 = (uint *)(iStack_c + 0x538);
      puStack_8[3] = 0;
      puVar7 = (uint *)(iStack_c + 0x24c);
      puVar4 = puStack_8;
      do {
        cVar6 = (char)((uint)iVar10 >> 8);
        cVar5 = (char)iVar10;
        if (cVar5 == cVar6) {
          *puVar9 = 0xffffffff;
          puVar1 = puVar7 + -5;
          if (0xf < *puVar7) {
            puVar1 = (uint *)*puVar1;
          }
          puVar7[-1] = 0;
          *(undefined *)puVar1 = 0;
        }
        else {
          uStack_10 = puVar7[-1];
          if (uStack_10 != 0) {
            puStack_14 = puVar7 + -5;
            if (0xf < *puVar7) {
              puStack_14 = (uint *)*puStack_14;
            }
            pcVar2 = (char *)FUN_00bbb2c0(&puStack_14);
            *pcVar2 = cVar5;
            puVar1 = (uint *)(int)cVar6;
            *puVar9 = *puVar9 | 1 << ((uint)puVar1 & 0x1f);
            puVar4 = puStack_8;
          }
        }
        iVar10 = CONCAT31((int3)((uint)iVar10 >> 8),cVar5 + '\x01');
        puVar9 = puVar9 + 1;
        puVar7 = puVar7 + 6;
      } while ((char)(cVar5 + '\x01') < ' ');
      return CONCAT44(puVar4,CONCAT31((int3)((uint)puVar1 >> 8),1));
    }
  }
  return CONCAT44(uVar3,puVar1) & 0xffffffffffffff00;
}



/* FUNCTION 26159 ; VA 0x00bc0420 ; FUN_00bc0420 */

void __thiscall FUN_00bc0420(int param_1,int *param_2)

{
  bool bVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  int aiStack_28 [6];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe090;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ca41a0();
  FUN_010680d0(param_2);
  aiStack_28[0] = 0;
  aiStack_28[1] = 0;
  aiStack_28[2] = 0;
  aiStack_28[3] = 0;
  aiStack_28[4] = 0;
  aiStack_28[5] = 0;
  uStack_8 = 1;
  iVar4 = (**(code **)(*param_2 + 0x10))();
  if (iVar4 == 0x1b) {
LAB_00bc04b8:
    bVar1 = true;
  }
  else {
    cVar3 = FUN_00bbea00(param_2);
    if (cVar3 == '\0') goto LAB_00bc04b8;
    bVar1 = false;
    FUN_00bbd630(param_2,aiStack_28,aiStack_28 + 3);
  }
  if (DAT_01d66c44 == '\0') {
    cVar3 = FUN_00ca09e0(aiStack_28);
    if (cVar3 == '\0') {
      cVar3 = FUN_00ca09e0(aiStack_28 + 3);
      if (cVar3 == '\0') goto LAB_00bc04e9;
    }
    param_2 = (int *)0x1;
  }
  else {
LAB_00bc04e9:
    param_2 = (int *)0x0;
  }
  (**(code **)(**(int **)(param_1 + 0x6b4) + 0xc))(piVar2);
  if (!bVar1) {
    FUN_00bbb8e0(piVar2,aiStack_28,aiStack_28 + 3,param_2);
    iVar4 = (**(code **)(*piVar2 + 0x10))();
    if (iVar4 - 7U < 0x13) {
      iVar4 = (**(code **)(*piVar2 + 0x10))();
      if ((0xd < iVar4 - 0xcU) || ((*(byte *)(piVar2 + 0x2b) & 1) == 0)) {
        if (piVar2[0xb] != piVar2[0xc]) {
          FUN_00ce8ea0(piVar2[0xb],piVar2[0xc]);
        }
      }
    }
  }
  if (DAT_01d62d64 != '\0') {
    iVar4 = (**(code **)(*piVar2 + 0x10))();
    if (iVar4 - 1U < 4) {
      *(int *)(param_1 + 0x648) = *(int *)(param_1 + 0x648) + -1;
    }
  }
  *(int *)(param_1 + 0x63c) = *(int *)(param_1 + 0x63c) + -1;
  if (aiStack_28[3] != 0) {
    uVar5 = aiStack_28[5] - aiStack_28[3] & 0xfffffffc;
    iVar4 = aiStack_28[3];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_28[3] + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (aiStack_28[3] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    aiStack_28[3] = 0;
    aiStack_28[4] = 0;
    aiStack_28[5] = 0;
  }
  if (aiStack_28[0] != 0) {
    uVar5 = aiStack_28[2] - aiStack_28[0] & 0xfffffffc;
    iVar4 = aiStack_28[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_28[0] + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (aiStack_28[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26160 ; VA 0x00bc0610 ; FUN_00bc0610 */

void __thiscall FUN_00bc0610(int *param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  float fVar10;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  uint uStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piStack_8 = param_1;
  if (*(int *)((int)param_1 + 0x6f0) != 0) {
    puVar3 = (undefined4 *)(param_2 + 0x68);
    if (param_2 == 0) {
      puVar3 = (undefined4 *)&DAT_00000018;
    }
    (**(code **)(**(int **)(*(int *)((int)param_1 + 0x6f0) + 0x2c) + 0x30))(*puVar3,puVar3[1]);
  }
  FUN_00c14350();
  iVar5 = DAT_01d702a0;
  uVar4 = FUN_00c155c0();
  uVar4 = FUN_00c19fc0(uVar4);
  FUN_0106a3d0(uVar4,iVar5 + -1);
  FUN_00ce9460();
  FUN_00ce79a0(param_2);
  FUN_01065230(param_2);
  if (((DAT_01d69070 != '\0') &&
      (iVar5 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))(), iVar5 != 10)) &&
     ((*(int *)((int)param_1 + 0x230) - *(int *)((int)param_1 + 0x22c) & 0xfffffffcU) != 0)) {
    FUN_00bbd7b0(&fStack_34);
    puVar3 = *(undefined4 **)((int)param_1 + 0x22c);
    piStack_c = (int *)((uint)((int)*(undefined4 **)((int)param_1 + 0x230) + (3 - (int)puVar3)) >> 2
                       );
    fVar10 = (float)DAT_01d68adc / DAT_018ce320;
    if (*(undefined4 **)((int)param_1 + 0x230) < puVar3) {
      piStack_c = (int *)0x0;
    }
    fStack_34 = fStack_34 - fVar10;
    fStack_30 = fStack_30 - fVar10;
    fStack_2c = fStack_2c - fVar10;
    fStack_28 = fVar10 + fStack_28;
    fStack_24 = fVar10 + fStack_24;
    fStack_20 = fVar10 + fStack_20;
    if (piStack_c != (int *)0x0) {
      piVar9 = (int *)0x0;
      do {
        (**(code **)(*(int *)*puVar3 + 4))(param_2,&fStack_34,0);
        piVar9 = (int *)((int)piVar9 + 1);
        puVar3 = puVar3 + 1;
        param_1 = piStack_8;
      } while (piVar9 != piStack_c);
    }
  }
  piVar9 = (int *)FUN_00bc2af0();
  iVar5 = *piVar9;
  *(undefined4 *)(*(int *)((int)param_1 + 200) + iVar5 * 4) =
       *(undefined4 *)(*(int *)((int)param_1 + 200) + -4 + *(int *)((int)param_1 + 0xcc) * 4);
  piVar9 = (int *)FUN_00bc2af0();
  *piVar9 = iVar5;
  FUN_0078c900(*(int *)((int)param_1 + 0xcc) + -1,0);
  puVar3 = (undefined4 *)FUN_00bc2af0();
  *puVar3 = 0xffffffff;
  piVar9 = (int *)(param_2 + 0x68);
  if (param_2 == 0) {
    piVar9 = (int *)&DAT_00000018;
  }
  iVar5 = (uint)*(byte *)((int)param_1 + 0x670) + (int)param_1 + 0x671;
  uStack_18 = piVar9[1];
  iStack_1c = *piVar9;
  FUN_00606ff0(&piStack_c,(uStack_18 >> 2) + uStack_18 * 0x40 + iStack_1c ^ uStack_18,&iStack_1c,
               -(uint)(iVar5 != 0) & iVar5 + 1U);
  piVar1 = piStack_8;
  uVar6 = (uint)piStack_c[1] % *(uint *)((int)piStack_8 + 0x674);
  piStack_8 = *(int **)(*(int *)((int)piStack_8 + 0x684) + uVar6 * 4);
  for (piVar9 = (int *)*piStack_8; piVar8 = (int *)*piStack_c, piVar9 != piStack_c;
      piVar9 = (int *)*piVar9) {
    piStack_8 = piVar9;
  }
  do {
    piStack_c = piVar8;
    *piStack_8 = *piVar9;
    FUN_01674ea0(piVar9,0x18);
    *(int *)((int)piVar1 + 0x678) = *(int *)((int)piVar1 + 0x678) + -1;
    uVar7 = uVar6;
    if (*piStack_8 == 0) {
LAB_00bc0888:
      if (*(int **)(*(int *)((int)piVar1 + 0x684) + uVar6 * 4) == piStack_8) {
        *(undefined4 *)(*(int *)((int)piVar1 + 0x684) + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piStack_8 + 4) % *(uint *)((int)piVar1 + 0x674);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)((int)piVar1 + 0x684) + uVar7 * 4) = piStack_8;
        goto LAB_00bc0888;
      }
    }
    piVar9 = (int *)*piStack_8;
    uVar6 = uVar7;
    piVar8 = piStack_c;
  } while (piVar9 != piStack_c);
  uStack_14 = FUN_00c15b60();
  piStack_8 = (int *)((int)piVar1 + 0x688);
  if (*(int *)((int)piVar1 + 0x690) != 0) {
    uStack_10 = FUN_009c91f0(uStack_14);
    piStack_c = (int *)(uStack_10 % *(uint *)((int)piVar1 + 0x68c));
    uStack_18 = (int)piStack_c * 4;
    piVar9 = *(int **)(uStack_18 + *(int *)((int)piVar1 + 0x69c));
    if ((piVar9 != (int *)0x0) && (iVar5 = *piVar9, iVar5 != 0)) {
      while ((int *)(*(uint *)(iVar5 + 4) % *(uint *)((int)piStack_8 + 4)) == piStack_c) {
        if ((*(uint *)(iVar5 + 4) == uStack_10) &&
           (cVar2 = FUN_009c8f50(iVar5 + 8), piVar1 = piStack_8, cVar2 != '\0')) {
          FUN_0061ae50(piVar9,*(undefined4 *)*piVar9);
          if (*piVar9 != 0) {
            piVar8 = (int *)(*(uint *)(*piVar9 + 4) % *(uint *)((int)piVar1 + 4));
            if (piStack_c == piVar8) break;
            *(int **)(*(int *)((int)piVar1 + 0x14) + (int)piVar8 * 4) = piVar9;
          }
          puVar3 = (undefined4 *)(*(int *)((int)piVar1 + 0x14) + uStack_18);
          if ((int *)*puVar3 == piVar9) {
            *puVar3 = 0;
          }
          break;
        }
        piVar9 = (int *)*piVar9;
        iVar5 = *piVar9;
        if (iVar5 == 0) break;
      }
    }
  }
  FUN_00f9ffb0(*(undefined *)(param_2 + 0x223));
  *(undefined4 *)(param_2 + 0x1a8) = 0;
  FUN_00fa04c0(0,0);
  *(undefined4 *)(param_2 + 0x194) = 0;
  if (*(int *)(param_2 + 0x1b4) != 0) {
    FUN_01674ea0(*(int *)(param_2 + 0x1b4),0x18);
    *(undefined4 *)(param_2 + 0x1b4) = 0;
  }
  return;
}



/* FUNCTION 26161 ; VA 0x00bc09c0 ; FUN_00bc09c0 */

undefined4 __thiscall FUN_00bc09c0(int param_1,uint *param_2,uint *param_3)

{
  undefined uVar1;
  int iVar2;
  char *pcVar3;
  undefined *puVar4;
  undefined4 uVar5;
  uint *puVar6;
  uint uVar7;
  undefined auStack_54 [24];
  undefined uStack_3c;
  undefined auStack_38 [28];
  uint *puStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe0b0;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (DAT_01d66528 == '\0') {
    iVar2 = param_1 + 0x215 + (uint)*(byte *)(param_1 + 0x214);
    uVar7 = -(uint)(iVar2 != 0) & iVar2 + 1U;
    ExceptionList = &pvStack_10;
    uVar5 = FUN_005702d0(param_3);
    FUN_00562fc0(&uStack_18,uVar5,puVar6,uVar7);
    puVar6 = param_2;
    if (uStack_18 == 0) {
      uVar5 = FUN_005702d0(param_2);
      FUN_00562fc0(&param_2,uVar5,puVar6,uVar7);
      if (param_2 != (uint *)0x0) {
        uVar1 = *(undefined *)(param_2 + 8);
        FUN_00bbcd00(&param_2,param_2);
        FUN_0054ef60(param_3);
        uStack_8 = 0;
        uStack_3c = uVar1;
        FUN_00bb8e20(auStack_54);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00bb9400(&puStack_1c,auStack_38,auStack_38);
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  else {
    uStack_18 = param_3[4];
    if (0xf < param_3[5]) {
      param_3 = (uint *)*param_3;
    }
    ExceptionList = &pvStack_10;
    puStack_1c = param_3;
    param_3 = (uint *)uStack_18;
    iVar2 = FUN_00bbcde0(&puStack_1c);
    if (iVar2 == 0) {
      uStack_18 = param_2[4];
      puStack_1c = param_2;
      if (0xf < param_2[5]) {
        puStack_1c = (uint *)*param_2;
      }
      iVar2 = FUN_00bbcde0(&puStack_1c);
      pcVar3 = (char *)(-(uint)(iVar2 != 0) & iVar2 + 8U);
      if (pcVar3 != (char *)0x0) {
        if ((uint *)(param_1 + (*pcVar3 * 3 + 0x47) * 8) != puVar6) {
          if (0xf < puVar6[5]) {
            puVar6 = (uint *)*puVar6;
          }
          FUN_005542c0(puVar6,param_3);
        }
        iVar2 = 0;
        *(undefined4 *)(param_1 + 0x5bc) = *(undefined4 *)(param_1 + 0x5b8);
        puVar6 = (uint *)(iStack_14 + 0x24c);
        *(undefined4 *)(param_1 + 0x5c4) = 0;
        do {
          uStack_18 = puVar6[-1];
          if (uStack_18 != 0) {
            puStack_1c = puVar6 + -5;
            if (0xf < *puVar6) {
              puStack_1c = (uint *)*puStack_1c;
            }
            puVar4 = (undefined *)FUN_00bbb2c0(&puStack_1c);
            *puVar4 = (char)iVar2;
          }
          iVar2 = iVar2 + 1;
          puVar6 = puVar6 + 6;
        } while (iVar2 < 0x20);
        ExceptionList = pvStack_10;
        return 1;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 26162 ; VA 0x00bc0bc0 ; FUN_00bc0bc0 */

void FUN_00bc0bc0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [8];
  undefined auStack_1c [8];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe0d0;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b06640(param_1);
  FUN_0060dcd0(auStack_24,uVar1);
  uStack_8 = 0;
  uVar1 = FUN_00b06640(param_2);
  FUN_0060dcd0(auStack_1c,uVar1);
  uStack_14 = param_3;
  uStack_8 = 1;
  FUN_00bbbcf0(&uStack_2c);
  FUN_007b2d40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26163 ; VA 0x00bc0c50 ; FUN_00bc0c50 */

void __thiscall FUN_00bc0c50(int param_1,int param_2,undefined4 param_3)

{
  *(char *)(param_2 + 0xc) = (char)param_3;
  FUN_00ce9040(param_2,param_3);
  if ((char)param_3 != '\0') {
    FUN_00ff5760(*(undefined4 *)(param_1 + 0x6f0));
  }
  return;
}



/* FUNCTION 26164 ; VA 0x00bc0c90 ; FUN_00bc0c90 */

void __thiscall FUN_00bc0c90(int param_1,float param_2)

{
  bool bVar1;
  bool bVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  bVar1 = DAT_018e452c != *(float *)(param_1 + 0xc4);
  bVar2 = *(float *)(param_1 + 0xc4) <= DAT_018e452c;
  *(float *)(param_1 + 0xc4) = param_2;
  iVar5 = 0;
  if (0 < *(int *)(param_1 + 0xcc)) {
    do {
      FUN_00fa00e0(param_2);
      if ((((bVar2 && bVar1) && (DAT_018e452c < param_2)) &&
          (*(int *)(*(int *)(param_1 + 200) + iVar5 * 4) != 0)) &&
         (iVar3 = FUN_00c155c0(), iVar3 != 0)) {
        uVar4 = FUN_00c19fc0(iVar3);
        FUN_010694d0(uVar4,0);
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < *(int *)(param_1 + 0xcc));
  }
  return;
}



/* FUNCTION 26165 ; VA 0x00bc0d40 ; FUN_00bc0d40 */

void __thiscall FUN_00bc0d40(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(*(int *)(param_1 + 0x6f0) + 0x2c) + 0x3c))(param_2,param_3);
  return;
}



/* FUNCTION 26166 ; VA 0x00bc0d60 ; FUN_00bc0d60 */

undefined * FUN_00bc0d60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe0ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3a74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef3a74);
    if (DAT_01ef3a74 == -1) {
      uStack_8 = 0;
      FUN_00911610();
      FUN_016f3654(&LAB_01891d40);
      FUN_016f37bf(&DAT_01ef3a74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef3a10;
}



/* FUNCTION 26167 ; VA 0x00bc0df0 ; FUN_00bc0df0 */

float10 __thiscall FUN_00bc0df0(int param_1,float param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  float *pfVar8;
  undefined2 extraout_var;
  char cVar9;
  char cVar10;
  int iVar11;
  int iVar12;
  bool bVar13;
  float10 fVar14;
  float fVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 uStack_7c;
  undefined auStack_58 [16];
  undefined auStack_48 [8];
  uint uStack_40;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  uint uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  float fStack_1c;
  float afStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe150;
  pvStack_10 = ExceptionList;
  iVar11 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar11 + 0x34) < DAT_01ef3990) {
    uStack_7c = 2.3312815856074756e-299;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01ef3990 == -1) {
      uStack_7c = -NAN;
      uStack_8 = 0;
      uStack_7c = (double)FUN_0152dab0(&DAT_018cb3fc);
      fStack_1c = (float)((ulonglong)uStack_7c >> 0x20);
      uVar7 = SUB84(uStack_7c,0);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30();
      }
      uStack_8 = 0xffffffff;
      uStack_7c = 2.3312815856075027e-299;
      DAT_01ef3988 = uVar7;
      DAT_01ef398c = fStack_1c;
      FUN_016f37bf();
    }
  }
  iVar2 = (int)DAT_01ef398c;
  uVar7 = DAT_01ef3988;
  uStack_7c = (double)CONCAT44(DAT_01ef398c,DAT_01ef3988);
  uStack_40 = DAT_01ef3988;
  iStack_3c = (int)DAT_01ef398c;
  uVar16 = FUN_01532c80();
  MXCSR = (float)((uint)MXCSR | 0x8000);
  uStack_8 = 1;
  cVar9 = SUB41(param_2,0);
  fStack_1c = MXCSR;
  if (cVar9 != '\0') {
    afStack_18[0] = (float)*(int *)(param_1 + 0x4c) / (float)*(int *)(param_1 + 0x88);
    if (DAT_01ef3704 == 0) {
      fVar15 = (float)*(int *)(param_1 + 0x24);
      fStack_1c = DAT_018f7864;
      if (*(int *)(param_1 + 0x24) < 1) goto LAB_00bc0ede;
      fStack_1c = DAT_018ce2f8 - DAT_018ce2f8 / fVar15;
    }
    else {
      fVar15 = (float)*(int *)(param_1 + 0x24);
      fStack_1c = DAT_018ce2f8;
LAB_00bc0ede:
      fStack_1c = fStack_1c / fVar15;
    }
    fStack_1c = fStack_1c * DAT_018ce320;
    if (*(int *)(iVar11 + 0x34) < DAT_01ef39a0) {
      uStack_7c = 2.3312998134125564e-299;
      FUN_016f3809();
      if (DAT_01ef39a0 == -1) {
        uStack_8._0_1_ = 2;
        uStack_7c._4_4_ = &DAT_018cb3fc;
        uStack_7c._0_4_ = 0xbc1503;
        uVar17 = FUN_0152da50();
        DAT_01ef399c = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef3998 = (undefined4)uVar17;
        uStack_7c = (double)CONCAT44(uStack_7c._4_4_,&DAT_01ef39a0);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf();
      }
    }
    uStack_7c = (double)(afStack_18[0] * DAT_018ce320);
    FUN_0152d760(DAT_01ef3998,DAT_01ef399c,"High Priority Rate: %3.0f %%");
    if (*(int *)(iVar11 + 0x34) < DAT_01ef39b0) {
      uStack_7c = 2.3313180412176246e-299;
      FUN_016f3809();
      if (DAT_01ef39b0 == -1) {
        uStack_8._0_1_ = 3;
        uStack_7c._4_4_ = &DAT_018cb3fc;
        uStack_7c._0_4_ = 0xbc154c;
        uVar17 = FUN_0152da50();
        DAT_01ef39ac = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef39a8 = (undefined4)uVar17;
        uStack_7c = (double)CONCAT44(uStack_7c._4_4_,&DAT_01ef39b0);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf();
      }
    }
    uStack_7c = (double)(fStack_1c * afStack_18[0]);
    FUN_0152d760(DAT_01ef39a8,DAT_01ef39ac,"Low Priority Rate: %3.0f %%");
    if (*(int *)(iVar11 + 0x34) < DAT_01ef39c0) {
      uStack_7c = 2.331336269022693e-299;
      FUN_016f3809();
      if (DAT_01ef39c0 == -1) {
        uStack_8._0_1_ = 4;
        uStack_7c._4_4_ = &DAT_018cb3fc;
        uStack_7c._0_4_ = 0xbc1595;
        uVar17 = FUN_0152da50();
        DAT_01ef39bc = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef39b8 = (undefined4)uVar17;
        uStack_7c = (double)CONCAT44(uStack_7c._4_4_,&DAT_01ef39c0);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf();
      }
    }
    uStack_7c = (double)fStack_1c;
    FUN_0152d760(DAT_01ef39b8,DAT_01ef39bc,"Steps Including Low Priority: %3.0f %%");
    if (*(int *)(iVar11 + 0x34) < DAT_01ef39d0) {
      uStack_7c = 2.331354496827761e-299;
      FUN_016f3809();
      if (DAT_01ef39d0 == -1) {
        uStack_8._0_1_ = 5;
        uStack_7c._4_4_ = &DAT_018cb3fc;
        uStack_7c._0_4_ = 0xbc15de;
        uVar17 = FUN_0152da50();
        DAT_01ef39cc = (undefined4)((ulonglong)uVar17 >> 0x20);
        DAT_01ef39c8 = (undefined4)uVar17;
        uStack_7c = (double)CONCAT44(uStack_7c._4_4_,&DAT_01ef39d0);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf();
      }
    }
    uStack_7c = (double)*(float *)(param_1 + 0x84);
    FUN_0152d760(DAT_01ef39c8,DAT_01ef39cc,"Steps Simulated: %d/%d (dropped %0.1f)",
                 *(undefined4 *)(param_1 + 0x4c),*(undefined4 *)(param_1 + 0x88));
    DAT_01d703fc = ((float)DAT_01d67bb4 / DAT_018ce320) * DAT_01952ddc;
    DAT_01d70400 = (float)DAT_01d67bbc / DAT_018ce320;
    DAT_01d70404 = (float)DAT_01d67bc4 / DAT_018ce320;
    *(float *)(param_1 + 0x78) = (float)DAT_01d67bf8 / DAT_018ce320;
    DAT_01d67c64 = (float)DAT_01d67c0c / DAT_018d0938;
    puVar3 = (undefined4 *)FUN_00c15e20(auStack_48);
    *(undefined4 *)(param_1 + 0xf0) = *puVar3;
    *(undefined4 *)(param_1 + 0xf4) = puVar3[1];
  }
  uStack_7c = (double)CONCAT44(0xbc1095,(undefined4)uStack_7c);
  FUN_00bbbe60();
  uStack_7c = (double)CONCAT44(param_4,param_3);
  FUN_00bbcf00();
  uVar17 = CONCAT44(fStack_1c,afStack_18[0]);
  if (cVar9 == '\0') goto LAB_00bc1334;
  if (*(int *)(iVar11 + 0x34) < DAT_01ef39e0) {
    uStack_7c = 2.3313727246328294e-299;
    FUN_016f3809();
    if (DAT_01ef39e0 == -1) {
      uStack_7c = 0.0;
      uStack_8._0_1_ = 6;
      uVar5 = FUN_005ef640(0,0,0);
      uStack_7c = (double)CONCAT26(extraout_var,CONCAT24(1,(int)&uStack_7c + 4));
      uStack_7c = (double)CONCAT62(uStack_7c._2_6_,1);
      pfVar8 = (float *)FUN_0056a920(CONCAT22((short)((uint)&uStack_7c >> 0x10),0x578));
      afStack_18[0] = *pfVar8;
      uStack_7c = (double)CONCAT44(uVar5,afStack_18);
      FUN_005672c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_7c = 2.3313727246328586e-299;
      FUN_016f37bf();
    }
  }
  uStack_7c = (double)CONCAT44(FUN_005f1e70,&uStack_30);
  FUN_005f0a90();
  if (((uStack_30 == 0) && (iStack_2c == -0x80000000)) ||
     ((uStack_30 == 0xffffffff && (iStack_2c == 0x7fffffff)))) {
    bVar13 = true;
  }
  else {
    bVar13 = false;
  }
  if (bVar13) {
LAB_00bc1118:
    bVar13 = true;
  }
  else {
    if ((uStack_30 == 0xfffffffe) && (iStack_2c == 0x7fffffff)) {
      bVar13 = true;
    }
    else {
      bVar13 = false;
    }
    if (bVar13) goto LAB_00bc1118;
    bVar13 = false;
  }
  if (bVar13) {
LAB_00bc1191:
    iStack_3c = iStack_2c;
    uStack_40 = uStack_30;
    uStack_7c = (double)CONCAT44(&uStack_38,auStack_58);
    uStack_38 = DAT_01ef39d8;
    iStack_34 = DAT_01ef39dc;
    piVar4 = (int *)FUN_00602640();
    iVar11 = *piVar4;
    iVar1 = piVar4[1];
    if ((iVar11 == -2) && (iVar1 == 0x7fffffff)) {
      bVar13 = true;
    }
    else {
      bVar13 = false;
    }
    if (bVar13) {
      uVar5 = 0;
    }
    else {
      if ((iVar11 == 0) && (iVar1 == -0x80000000)) {
        bVar13 = true;
      }
      else {
        bVar13 = false;
      }
      if (bVar13) {
        uVar5 = 1;
      }
      else {
        if ((iVar11 == -1) && (iVar1 == 0x7fffffff)) {
          bVar13 = true;
        }
        else {
          bVar13 = false;
        }
        uVar5 = 5;
        if (bVar13) {
          uVar5 = 2;
        }
      }
    }
    uStack_7c = (double)CONCAT44(uVar5,0xbc1215);
    FUN_0056b510();
  }
  else {
    if (((DAT_01ef39d8 == 0) && (DAT_01ef39dc == -0x80000000)) ||
       ((DAT_01ef39d8 == 0xffffffff && (DAT_01ef39dc == 0x7fffffff)))) {
      bVar13 = true;
    }
    else {
      bVar13 = false;
    }
    if (bVar13) {
LAB_00bc116f:
      bVar13 = true;
    }
    else {
      if ((DAT_01ef39d8 == 0xfffffffe) && (DAT_01ef39dc == 0x7fffffff)) {
        bVar13 = true;
      }
      else {
        bVar13 = false;
      }
      if (bVar13) goto LAB_00bc116f;
      bVar13 = false;
    }
    if (bVar13) goto LAB_00bc1191;
    uStack_7c = (double)CONCAT44((iStack_2c - DAT_01ef39dc) - (uint)(uStack_30 < DAT_01ef39d8),
                                 uStack_30 - DAT_01ef39d8);
    FUN_005ef640(0,0,0);
  }
  uStack_7c = 4.94065645841247e-321;
  uVar17 = FUN_016f3900(uStack_28,uStack_24);
  iVar11 = 0;
  if (0 < *(int *)(param_1 + 0x4c)) {
    do {
      uStack_7c = (double)uVar17;
      fStack_1c = (float)((ulonglong)uStack_7c >> 0x20);
      afStack_18[0] = SUB84(uStack_7c,0);
      uVar6 = *(uint *)(param_1 + 0x50);
      switch(DAT_01ef3704) {
      case 0:
        iVar1 = *(int *)(&DAT_0195c90c + *(int *)(param_1 + 0x28) * 4);
        *(int *)(param_1 + 0x24) = iVar1;
        bVar13 = 0 < iVar1 == ((int)uVar6 % iVar1 == 0);
        goto LAB_00bc12d3;
      default:
        *(undefined4 *)(param_1 + 0x24) = 1;
        goto LAB_00bc12f4;
      case 2:
        *(undefined4 *)(param_1 + 0x24) = 100000000;
        goto LAB_00bc12e0;
      case 3:
        *(undefined4 *)(param_1 + 0x24) = 2;
        uVar6 = uVar6 & 0x80000001;
        bVar13 = uVar6 == 0;
        if ((int)uVar6 < 0) {
          uVar6 = uVar6 - 1 | 0xfffffffe;
LAB_00bc12cd:
          bVar13 = uVar6 == 0xffffffff;
        }
        break;
      case 4:
        *(undefined4 *)(param_1 + 0x24) = 4;
        uVar6 = uVar6 & 0x80000003;
        bVar13 = uVar6 == 0;
        if ((int)uVar6 < 0) {
          uVar6 = uVar6 - 1 | 0xfffffffc;
          goto LAB_00bc12cd;
        }
        break;
      case 5:
        *(undefined4 *)(param_1 + 0x24) = 8;
        uVar6 = uVar6 & 0x80000007;
        bVar13 = uVar6 == 0;
        if ((int)uVar6 < 0) {
          uVar6 = uVar6 - 1 | 0xfffffff8;
          goto LAB_00bc12cd;
        }
        break;
      case 6:
        *(undefined4 *)(param_1 + 0x24) = 0x10;
        uVar6 = uVar6 & 0x8000000f;
        bVar13 = uVar6 == 0;
        if ((int)uVar6 < 0) {
          uVar6 = uVar6 - 1 | 0xfffffff0;
          goto LAB_00bc12cd;
        }
      }
      bVar13 = !bVar13;
LAB_00bc12d3:
      if (bVar13) {
LAB_00bc12e0:
        if (DAT_01d67c80 != '\0') goto LAB_00bc12f4;
        cVar10 = '\x01';
      }
      else {
LAB_00bc12f4:
        cVar10 = '\0';
      }
      uVar6 = *(uint *)(param_1 + 0x50) & 0x80000003;
      if ((int)uVar6 < 0) {
        uVar6 = (uVar6 - 1 | 0xfffffffc) + 1;
      }
      *(uint *)(param_1 + 0x54) = uVar6;
      FUN_00bc2b00(cVar10,uVar6);
      uVar17 = CONCAT44(fStack_1c,afStack_18[0]);
      *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + 1;
      if (cVar10 == '\0') {
        *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 1;
      }
      iVar11 = iVar11 + 1;
    } while (iVar11 < *(int *)(param_1 + 0x4c));
  }
LAB_00bc1334:
  fStack_1c = (float)((ulonglong)uVar17 >> 0x20);
  afStack_18[0] = (float)uVar17;
  if ((DAT_01d69070 == '\0') && (DAT_01d6f4e0 == '\0')) {
    uStack_7c = (double)CONCAT44(0xbc1351,(undefined4)uStack_7c);
    FUN_00ce86a0();
    uVar17 = CONCAT44(fStack_1c,afStack_18[0]);
  }
  fStack_1c = (float)((ulonglong)uVar17 >> 0x20);
  afStack_18[0] = (float)uVar17;
  uStack_7c = (double)CONCAT44(param_2,0xbc1359);
  FUN_00bbec60();
  if (DAT_01d70950 != '\0') {
    iVar11 = *(int *)(param_1 + 0x6dc);
    iVar1 = *(int *)(iVar11 + 0x54);
    for (iVar12 = *(int *)(iVar11 + 0x50); iVar12 != iVar1; iVar12 = iVar12 + 0xc) {
      uStack_7c = (double)CONCAT44(0xbc137c,(undefined4)uStack_7c);
      FUN_0056d320();
    }
    *(undefined4 *)(iVar11 + 0x54) = *(undefined4 *)(iVar11 + 0x50);
  }
  if ((DAT_01d67cb0 != '\0') && (cVar9 != '\0')) {
    uStack_7c = (double)CONCAT44(0xbc13a3,(undefined4)uStack_7c);
    FUN_00bbe770();
  }
  if ((DAT_01d6f4e0 != '\0') || ((DAT_01d67cb0 != '\0' && (DAT_01d69070 != '\0')))) {
    uStack_7c = (double)CONCAT44(0xbc13c9,(undefined4)uStack_7c);
    FUN_00ce86a0();
  }
  if (cVar9 == '\0') {
    param_2 = 0.0;
  }
  else if (DAT_01d67c90 == '\0') {
    uStack_7c = (double)CONCAT44(0xbc13f2,(undefined4)uStack_7c);
    fVar14 = (float10)FUN_00bb5be0();
    param_2 = (float)(fVar14 * (float10)*(int *)(param_1 + 0x4c));
  }
  else {
    param_2 = (float)*(int *)(param_1 + 0x4c) * *(float *)(param_1 + 0x610);
  }
  uStack_8 = 7;
  uStack_7c = (double)uVar16;
  FUN_0152dda0(uVar7,iVar2);
  if (DAT_01d7ad40 != '\0') {
    uStack_7c = (double)uVar16;
    FUN_01532d10(uVar7,iVar2);
  }
  ExceptionList = pvStack_10;
  return (float10)param_2;
}



/* FUNCTION 26168 ; VA 0x00bc16a0 ; FUN_00bc16a0 */

void __thiscall
FUN_00bc16a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  double *pdVar3;
  undefined8 uVar4;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe17c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef38f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef38f0);
    if (DAT_01ef38f0 == -1) {
      uStack_8 = 0;
      uVar4 = FUN_0152dab0(&DAT_018cb3fc,"newStepContacts",0xffffffff);
      DAT_01ef38ec = (undefined4)((ulonglong)uVar4 >> 0x20);
      DAT_01ef38e8 = (undefined4)uVar4;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef38f0);
    }
  }
  uStack_18 = DAT_01ef38e8;
  uStack_14 = DAT_01ef38ec;
  uVar4 = FUN_0152d930(DAT_01ef38e8,DAT_01ef38ec);
  uStack_8 = 1;
  uVar1 = FUN_01675290(DAT_01ef3710);
  uStack_1c = uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 == '\0') {
    puVar2 = &uStack_2c;
    uStack_2c = 0;
  }
  else {
    puVar2 = (undefined8 *)FUN_016827e0(&uStack_2c);
  }
  uStack_24 = *(undefined4 *)puVar2;
  uStack_20 = *(undefined4 *)((int)puVar2 + 4);
  if (DAT_01d69070 != '\0') {
    if (DAT_01d69148 == '\0') {
      FUN_00ce9fc0();
    }
    else {
      FUN_00bc1c50(param_4,param_2);
    }
  }
  FUN_01069980(param_2);
  FUN_00ce9530(param_3,param_4,param_2);
  FUN_01069650(param_3,param_2);
  if (param_5 != '\0') {
    pdVar3 = (double *)FUN_016827e0(&uStack_2c);
    *(double *)(param_1 + 0xa8) =
         (DAT_018c0d60 - *(double *)(param_1 + 0xb0)) * *(double *)(param_1 + 0xa8) +
         *(double *)(param_1 + 0xb0) *
         (*pdVar3 - (double)CONCAT44(uStack_20,uStack_24)) * DAT_018c0d70;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_01675290(uVar1);
  uStack_8 = 4;
  FUN_0152dda0(uStack_18,uStack_14,uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26169 ; VA 0x00bc1890 ; FUN_00bc1890 */

void __thiscall FUN_00bc1890(int param_1,int param_2,int param_3,undefined4 param_4,uint param_5)

{
  undefined4 uVar1;
  void *pvVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe1bc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01ef3710);
  iStack_8 = 0;
  *(undefined *)(param_1 + 0x38) = 1;
  uStack_14 = uVar3;
  FUN_01068390();
  FUN_00f38480(param_4,param_5);
  pvVar2 = ThreadLocalStoragePointer;
  iVar7 = _tls_index;
  *(undefined *)(param_1 + 0x38) = 0;
  if ((*(int *)(*(int *)((int)pvVar2 + iVar7 * 4) + 0x34) < DAT_01ef3860) &&
     (FUN_016f3809(&DAT_01ef3860), DAT_01ef3860 == -1)) {
    iStack_8._0_1_ = 1;
    uVar11 = FUN_0152dab0(&DAT_018cb3fc,"updateBroadphase",0xffffffff);
    DAT_01ef385c = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01ef3858 = (undefined4)uVar11;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_016f37bf(&DAT_01ef3860);
  }
  uVar1 = DAT_01ef385c;
  uStack_18 = DAT_01ef3858;
  uVar11 = FUN_0152d930(DAT_01ef3858,DAT_01ef385c);
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  if (DAT_01d69070 == '\0') {
    if (DAT_01d67ca0 == '\0') {
      if (DAT_01d70970 == '\0') {
        iVar7 = *(int *)(param_1 + 0x6ec);
        piVar9 = *(int **)(iVar7 + 0x28);
        if (piVar9 != (int *)(iVar7 + 0x28)) {
          do {
            if (piVar9 == (int *)0x0) {
              piVar5 = (int *)0x0;
            }
            else {
              piVar5 = piVar9 + -0xb;
            }
            FUN_00ce6600(piVar5);
            piVar9 = (int *)*piVar9;
          } while (piVar9 != (int *)(iVar7 + 0x28));
          iVar7 = *(int *)(param_1 + 0x6ec);
        }
        piVar9 = *(int **)(iVar7 + 0x1c);
        if (piVar9 != (int *)(iVar7 + 0x1c)) {
          do {
            if (piVar9 == (int *)0x0) {
              piVar5 = (int *)0x0;
            }
            else {
              piVar5 = piVar9 + -0xb;
            }
            FUN_00ce6600(piVar5);
            piVar9 = (int *)*piVar9;
          } while (piVar9 != (int *)(iVar7 + 0x1c));
        }
      }
      else {
        iVar7 = *(int *)(param_1 + 0x6ec);
        puVar8 = *(undefined4 **)(iVar7 + 0x3c);
        uVar6 = (*(int *)(iVar7 + 0x40) - (int)puVar8) + 3U >> 2;
        if (*(undefined4 **)(iVar7 + 0x40) < puVar8) {
          uVar6 = 0;
        }
        if (uVar6 != 0) {
          uVar10 = 0;
          do {
            FUN_00ce6600(*puVar8);
            uVar10 = uVar10 + 1;
            puVar8 = puVar8 + 1;
          } while (uVar10 != uVar6);
          iVar7 = *(int *)(param_1 + 0x6ec);
          uVar3 = uStack_14;
        }
        puVar8 = *(undefined4 **)(iVar7 + 0x30);
        uVar6 = (uint)((int)*(undefined4 **)(iVar7 + 0x34) + (3 - (int)puVar8)) >> 2;
        if (*(undefined4 **)(iVar7 + 0x34) < puVar8) {
          uVar6 = 0;
        }
        if (uVar6 != 0) {
          uVar10 = 0;
          do {
            FUN_00ce6600(*puVar8);
            uVar10 = uVar10 + 1;
            puVar8 = puVar8 + 1;
            uVar3 = uStack_14;
          } while (uVar10 != uVar6);
        }
      }
      goto LAB_00bc1b4a;
    }
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    uVar6 = *(uint *)(param_2 + 8);
    if (uVar6 == 0) {
LAB_00bc1a0d:
      uVar4 = 0;
    }
    else {
      if (0x3fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      FUN_007cfd20(uVar6);
      if (*(int *)(param_2 + 8) == 0) goto LAB_00bc1a0d;
      uVar4 = *(undefined4 *)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    param_5 = param_5 & 0xffffff00;
    FUN_00bb8e70(uVar4,0,param_5);
    FUN_00cdeca0(&uStack_24);
    FUN_0056d320();
    goto LAB_00bc1b4a;
  }
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  uVar6 = *(uint *)(param_3 + 8);
  if (uVar6 == 0) {
LAB_00bc198b:
    uVar4 = 0;
  }
  else {
    if (0x3fffffff < uVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar6);
    if (*(int *)(param_3 + 8) == 0) goto LAB_00bc198b;
    uVar4 = *(undefined4 *)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
  }
  param_5 = param_5 & 0xffffff00;
  FUN_00bb8e70(uVar4,0,param_5);
  FUN_00ce0920(&uStack_24);
  FUN_0056d320();
LAB_00bc1b4a:
  iStack_8 = CONCAT31(iStack_8._1_3_,5);
  FUN_0152dda0(uStack_18,uVar1,uVar11);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26170 ; VA 0x00bc1be0 ; FUN_00bc1be0 */

void FUN_00bc1be0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_00c19fc0(param_1);
    FUN_010694d0(uVar1,param_2);
  }
  return;
}



/* FUNCTION 26171 ; VA 0x00bc1c10 ; FUN_00bc1c10 */

void FUN_00bc1c10(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    iVar1 = FUN_00c155c0();
    if (iVar1 != 0) {
      uVar2 = FUN_00c19fc0(iVar1);
      FUN_010694d0(uVar2,param_2);
    }
  }
  return;
}



/* FUNCTION 26172 ; VA 0x00bc1c50 ; FUN_00bc1c50 */

void __thiscall FUN_00bc1c50(int param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined8 uVar8;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe1e4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef3880) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef3880), DAT_01ef3880 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0(&DAT_018cb3fc,"GatherAssemblies",0xffffffff);
    DAT_01ef387c = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01ef3878 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ef3880);
  }
  uVar5 = DAT_01ef387c;
  uVar4 = DAT_01ef3878;
  uVar8 = FUN_0152d930(DAT_01ef3878,DAT_01ef387c);
  iVar1 = *(int *)(param_1 + 0x6ec);
  uStack_8 = 1;
  if (DAT_01d70970 == '\0') {
    for (puVar2 = *(undefined4 **)(iVar1 + 0x28); puVar2 != (undefined4 *)(iVar1 + 0x28);
        puVar2 = (undefined4 *)*puVar2) {
      if (puVar2 == (undefined4 *)0x0) {
        puStack_14 = (undefined4 *)0x0;
      }
      else {
        puStack_14 = puVar2 + -0xb;
      }
      if (DAT_01d69148 == '\0') {
LAB_00bc1dac:
        piVar3 = *(int **)(param_1 + 0x624);
        if (*(int **)(param_1 + 0x628) == piVar3) {
          FUN_0063d9b0(piVar3,&puStack_14);
        }
        else {
          *piVar3 = (int)puStack_14;
          *(int *)(param_1 + 0x624) = *(int *)(param_1 + 0x624) + 4;
        }
      }
      else {
        uVar6 = FUN_00ca1560();
        if (param_2 % uVar6 == 0) {
          FUN_00ca2240(param_2);
          goto LAB_00bc1dac;
        }
      }
    }
    if ((char)param_3 == '\0') {
      puVar7 = (undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x1c);
      for (puVar2 = (undefined4 *)*puVar7; puVar2 != puVar7; puVar2 = (undefined4 *)*puVar2) {
        if (puVar2 == (undefined4 *)0x0) {
          param_3 = (undefined4 *)0x0;
        }
        else {
          param_3 = puVar2 + -0xb;
        }
        piVar3 = *(int **)(param_1 + 0x624);
        if (*(int **)(param_1 + 0x628) == piVar3) {
          FUN_0063d9b0(piVar3,&param_3);
        }
        else {
          *piVar3 = (int)param_3;
          *(int *)(param_1 + 0x624) = *(int *)(param_1 + 0x624) + 4;
        }
      }
    }
  }
  else if (DAT_01d69148 == '\0') {
    FUN_007a2730(*(undefined4 *)(param_1 + 0x624),*(undefined4 *)(iVar1 + 0x3c),
                 *(undefined4 *)(iVar1 + 0x40),param_3);
    if ((char)param_3 == '\0') {
      FUN_007a2730(*(undefined4 *)(param_1 + 0x624),
                   *(undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x30),
                   *(undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x34),param_3);
    }
  }
  else {
    FUN_00bbf8f0(param_2,(undefined4 *)(iVar1 + 0x3c),param_1 + 0x620);
    if ((char)param_3 == '\0') {
      FUN_00bbf8f0(param_2,*(int *)(param_1 + 0x6ec) + 0x30,param_1 + 0x620);
    }
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar4,uVar5,uVar8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26173 ; VA 0x00bc1eb0 ; FUN_00bc1eb0 */

void __thiscall FUN_00bc1eb0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined ***pppuVar2;
  double *pdVar3;
  int *piVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined8 uVar8;
  undefined **ppuStack_f4;
  undefined **appuStack_f0 [6];
  undefined4 uStack_d8;
  undefined4 *puStack_d4;
  int *piStack_d0;
  undefined8 uStack_cc;
  int aiStack_b8 [9];
  int *piStack_94;
  undefined4 uStack_90;
  int *piStack_8c;
  undefined8 uStack_88;
  char cStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  double dStack_68;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined **ppuStack_50;
  int iStack_4c;
  int iStack_48;
  undefined ***pppuStack_2c;
  undefined ***pppuStack_28;
  undefined4 uStack_24;
  undefined ***pppuStack_20;
  int iStack_1c;
  char cStack_15;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe296;
  pvStack_10 = ExceptionList;
  iVar7 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (*(int *)(iVar7 + 0x34) < DAT_01ef3890) {
    uStack_cc._4_4_ = (undefined ***)&DAT_01ef3890;
    uStack_cc._0_4_ = (char *)0xbc24c2;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    cVar6 = DAT_01d7ad48;
    if (DAT_01ef3890 == -1) {
      uStack_cc._4_4_ = (undefined ***)0xffffffff;
      uStack_cc._0_4_ = "updateBroadphase";
      piStack_d0 = (int *)&DAT_018cb3fc;
      uStack_8 = 0;
      puStack_d4 = (undefined4 *)0xbc24f0;
      uStack_cc = FUN_0152dab0();
      piStack_14 = (int *)((ulonglong)uStack_cc >> 0x20);
      uVar5 = (undefined4)uStack_cc;
      if ((cVar6 != '\0') && (DAT_01d7ad40 != '\0')) {
        piStack_d0 = (int *)0xbc250e;
        FUN_01532a30();
      }
      uStack_cc._4_4_ = (undefined ***)&DAT_01ef3890;
      uStack_8 = 0xffffffff;
      uStack_cc._0_4_ = (char *)0xbc2532;
      DAT_01ef3888 = uVar5;
      DAT_01ef388c = piStack_14;
      FUN_016f37bf();
      param_1 = iStack_1c;
    }
  }
  cVar6 = DAT_01d7ad48;
  uStack_cc._4_4_ = (undefined ***)DAT_01ef388c;
  uStack_cc._0_4_ = (char *)DAT_01ef3888;
  cStack_15 = DAT_01d7ad48;
  uStack_60 = DAT_01ef3888;
  uStack_90 = DAT_01ef3888;
  piStack_5c = DAT_01ef388c;
  piStack_8c = DAT_01ef388c;
  piStack_d0 = (int *)0xbc1f23;
  uStack_88 = FUN_01532c80();
  cStack_80 = cVar6;
  uStack_8 = 1;
  cVar6 = (char)param_3;
  if (DAT_01d69070 != '\0') {
    uStack_cc._4_4_ = (undefined ***)&uStack_24;
    uStack_cc._0_4_ = (char *)0xbc1f4f;
    FUN_016827e0();
    if (DAT_01d69148 == '\0') {
      uStack_cc._4_4_ = (undefined ***)param_3;
      uStack_cc._0_4_ = (char *)param_2;
      piStack_d0 = (int *)0xbc1f69;
      FUN_00bc1c50();
    }
    uStack_cc._0_4_ = (char *)0xbc1f7b;
    uStack_cc._4_4_ = (undefined ***)(param_1 + 0x620);
    FUN_00ce0920();
    *(undefined4 *)(param_1 + 0x624) = *(undefined4 *)(param_1 + 0x620);
    uStack_70 = CONCAT44(uStack_70._4_4_,(undefined4)uStack_70);
    if ((DAT_01d5bff8 != '\0') &&
       (uStack_70 = CONCAT44(uStack_70._4_4_,(undefined4)uStack_70), cVar6 == '\0')) {
      uStack_cc._4_4_ = (undefined ***)&dStack_68;
      uStack_cc._0_4_ = (char *)0xbc1f9e;
      pdVar3 = (double *)FUN_016827e0();
      *(double *)(param_1 + 0xa0) =
           (DAT_018c0d60 - *(double *)(param_1 + 0xb0)) * *(double *)(param_1 + 0xa0) +
           (*pdVar3 - (double)CONCAT44(pppuStack_20,uStack_24)) * DAT_018c0d70 *
           *(double *)(param_1 + 0xb0);
    }
    goto LAB_00bc2467;
  }
  if (DAT_01d70970 == '\0') {
    if (*(int *)(iVar7 + 0x34) < DAT_01ef38c0) {
      uStack_cc._4_4_ = (undefined ***)&DAT_01ef38c0;
      uStack_cc._0_4_ = (char *)0xbc25d9;
      FUN_016f3809();
      if (DAT_01ef38c0 == -1) {
        uStack_cc._4_4_ = (undefined ***)&DAT_018cb3fc;
        uStack_8._0_1_ = 4;
        uStack_cc._0_4_ = (char *)0xbc25f7;
        uVar8 = FUN_0152da50();
        DAT_01ef38bc = (undefined4)((ulonglong)uVar8 >> 0x20);
        DAT_01ef38b8 = (undefined4 *)uVar8;
        uStack_cc._0_4_ = (char *)&DAT_01ef38c0;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piStack_d0 = (int *)0xbc2610;
        FUN_016f37bf();
      }
    }
    uStack_cc._4_4_ = *(undefined ****)(*(int *)(param_1 + 0x6ec) + 0x24);
    uStack_cc._0_4_ = "High Priority Assemblies: %3d";
    piStack_d0 = (int *)DAT_01ef38bc;
    puStack_d4 = DAT_01ef38b8;
    uStack_d8 = 0xbc2094;
    FUN_0152d760();
    if (cVar6 == '\0') {
      if (*(int *)(iVar7 + 0x34) < DAT_01ef38d0) {
        uStack_cc._4_4_ = (undefined ***)&DAT_01ef38d0;
        uStack_cc._0_4_ = (char *)0xbc2622;
        FUN_016f3809();
        if (DAT_01ef38d0 == -1) {
          uStack_cc._4_4_ = (undefined ***)&DAT_018cb3fc;
          uStack_8._0_1_ = 5;
          uStack_cc._0_4_ = (char *)0xbc2640;
          uVar8 = FUN_0152da50();
          DAT_01ef38cc = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01ef38c8 = (undefined4 *)uVar8;
          uStack_cc._0_4_ = (char *)&DAT_01ef38d0;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          piStack_d0 = (int *)0xbc2659;
          FUN_016f37bf();
        }
      }
      uStack_cc._4_4_ = *(undefined ****)(*(int *)(param_1 + 0x6ec) + 0x18);
      piStack_d0 = (int *)DAT_01ef38cc;
      puStack_d4 = DAT_01ef38c8;
      goto LAB_00bc20c8;
    }
  }
  else {
    if (*(int *)(iVar7 + 0x34) < DAT_01ef38a0) {
      uStack_cc._4_4_ = (undefined ***)&DAT_01ef38a0;
      uStack_cc._0_4_ = (char *)0xbc2547;
      FUN_016f3809();
      if (DAT_01ef38a0 == -1) {
        uStack_cc._4_4_ = (undefined ***)&DAT_018cb3fc;
        uStack_8._0_1_ = 2;
        uStack_cc._0_4_ = (char *)0xbc2565;
        uVar8 = FUN_0152da50();
        DAT_01ef389c = (undefined4)((ulonglong)uVar8 >> 0x20);
        DAT_01ef3898 = (undefined4 *)uVar8;
        uStack_cc._0_4_ = (char *)&DAT_01ef38a0;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piStack_d0 = (int *)0xbc257e;
        FUN_016f37bf();
      }
    }
    uStack_cc._4_4_ =
         (undefined ***)
         (*(int *)(*(int *)(param_1 + 0x6ec) + 0x40) - *(int *)(*(int *)(param_1 + 0x6ec) + 0x3c) >>
         2);
    uStack_cc._0_4_ = "High Priority Assemblies: %3d";
    piStack_d0 = (int *)DAT_01ef389c;
    puStack_d4 = DAT_01ef3898;
    uStack_d8 = 0xbc2023;
    FUN_0152d760();
    if (cVar6 == '\0') {
      if (*(int *)(iVar7 + 0x34) < DAT_01ef38b0) {
        uStack_cc._4_4_ = (undefined ***)&DAT_01ef38b0;
        uStack_cc._0_4_ = (char *)0xbc2590;
        FUN_016f3809();
        if (DAT_01ef38b0 == -1) {
          uStack_cc._4_4_ = (undefined ***)&DAT_018cb3fc;
          uStack_8._0_1_ = 3;
          uStack_cc._0_4_ = (char *)0xbc25ae;
          uVar8 = FUN_0152da50();
          DAT_01ef38ac = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01ef38a8 = (undefined4 *)uVar8;
          uStack_cc._0_4_ = (char *)&DAT_01ef38b0;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          piStack_d0 = (int *)0xbc25c7;
          FUN_016f37bf();
        }
      }
      uStack_cc._4_4_ =
           (undefined ***)
           (*(int *)(*(int *)(param_1 + 0x6ec) + 0x34) - *(int *)(*(int *)(param_1 + 0x6ec) + 0x30)
           >> 2);
      piStack_d0 = (int *)DAT_01ef38ac;
      puStack_d4 = DAT_01ef38a8;
LAB_00bc20c8:
      uStack_cc._0_4_ = "Low Priority Assemblies: %3d";
      uStack_d8 = 0xbc20cd;
      FUN_0152d760();
    }
  }
  uStack_cc._4_4_ = (undefined ***)&dStack_68;
  uStack_cc._0_4_ = (char *)0xbc20d9;
  FUN_016827e0();
  if (*(int *)(iVar7 + 0x34) < DAT_01ef38e0) {
    uStack_cc._4_4_ = (undefined ***)&DAT_01ef38e0;
    uStack_cc._0_4_ = (char *)0xbc266b;
    FUN_016f3809();
    if (DAT_01ef38e0 == -1) {
      uStack_cc._4_4_ = (undefined ***)0xffffffff;
      uStack_cc._0_4_ = "gatherPrimitives";
      piStack_d0 = (int *)&DAT_018cb3fc;
      uStack_8._0_1_ = 6;
      puStack_d4 = (undefined4 *)0xbc2690;
      uVar8 = FUN_0152dab0();
      DAT_01ef38dc = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01ef38d8 = (undefined4)uVar8;
      puStack_d4 = &DAT_01ef38e0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_d8 = 0xbc26a9;
      FUN_016f37bf();
    }
  }
  uStack_cc._4_4_ = (undefined ***)DAT_01ef38dc;
  uStack_cc._0_4_ = (char *)DAT_01ef38d8;
  uStack_58 = DAT_01ef38d8;
  uStack_78 = DAT_01ef38d8;
  uStack_54 = DAT_01ef38dc;
  uStack_74 = DAT_01ef38dc;
  piStack_d0 = (int *)0xbc210b;
  uStack_70 = FUN_0152d930();
  piStack_94 = (int *)0x0;
  if (DAT_01d69148 == '\0') {
    iStack_4c = param_1 + 0x614;
    ppuStack_50 = std::
                  _Func_impl_no_alloc<class_<lambda_12819d71947c819b9cb7cc01a1ddb500>,void,class_RBX::Primitive*>
                  ::vftable;
  }
  else {
    iStack_48 = param_1 + 0x614;
    ppuStack_50 = std::
                  _Func_impl_no_alloc<class_<lambda_95bac1457acf3589b00cf7f941416a34>,void,class_RBX::Primitive*>
                  ::vftable;
    iStack_4c = (int)param_2;
  }
  param_2 = (undefined4 *)(param_1 + 0x614);
  pppuStack_2c = &ppuStack_50;
  uStack_cc._4_4_ = (undefined ***)aiStack_b8;
  uStack_cc._0_4_ = (char *)0xbc2167;
  FUN_00733f40();
  if (pppuStack_2c != (undefined ***)0x0) {
    uStack_cc._4_4_ =
         (undefined ***)CONCAT31((int3)((uint)&ppuStack_50 >> 8),pppuStack_2c != &ppuStack_50);
    uStack_cc._0_4_ = (char *)0xbc217e;
    (*(code *)(*pppuStack_2c)[4])();
  }
  iVar7 = *(int *)(param_1 + 0x6ec);
  if (DAT_01d70970 == '\0') {
    piVar4 = *(int **)(iVar7 + 0x28);
    piStack_14 = (int *)(iVar7 + 0x28);
    iVar7 = param_1;
    if (piVar4 != piStack_14) {
      do {
        uStack_cc._4_4_ = (undefined ***)0x0;
        pppuStack_20 = appuStack_f0;
        ppuStack_f4 = (undefined **)appuStack_f0;
        uStack_cc._0_4_ = (char *)0x0;
        uStack_8._0_1_ = 0xf;
        pppuVar2 = appuStack_f0;
        if (piStack_94 != (int *)0x0) {
          uStack_cc._0_4_ = (char *)(**(code **)*piStack_94)();
          pppuVar2 = pppuStack_20;
        }
        pppuStack_20 = pppuVar2;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        ppuStack_f4 = (undefined **)0xbc232d;
        FUN_00bb9790();
        piVar4 = (int *)*piVar4;
        iVar7 = iStack_1c;
      } while (piVar4 != piStack_14);
    }
    if (cVar6 == '\0') {
      piStack_14 = (int *)(*(int *)(iVar7 + 0x6ec) + 0x1c);
      piVar4 = (int *)*piStack_14;
      if (piVar4 != piStack_14) {
        do {
          uStack_cc._4_4_ = (undefined ***)0x0;
          pppuStack_20 = appuStack_f0;
          ppuStack_f4 = (undefined **)appuStack_f0;
          uStack_cc._0_4_ = (char *)0x0;
          uStack_8._0_1_ = 0x10;
          pppuVar2 = appuStack_f0;
          if (piStack_94 != (int *)0x0) {
            uStack_cc._0_4_ = (char *)(**(code **)*piStack_94)();
            pppuVar2 = pppuStack_20;
          }
          pppuStack_20 = pppuVar2;
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          ppuStack_f4 = (undefined **)0xbc2391;
          FUN_00bb9790();
          piVar4 = (int *)*piVar4;
        } while (piVar4 != piStack_14);
      }
    }
  }
  else {
    piVar4 = *(int **)(iVar7 + 0x3c);
    piStack_14 = *(int **)(iVar7 + 0x40);
    iVar7 = param_1;
    if (piVar4 != piStack_14) {
      do {
        pppuStack_28 = &ppuStack_50;
        pppuStack_2c = (undefined ***)0x0;
        uStack_8._0_1_ = 9;
        if (piStack_94 != (int *)0x0) {
          uStack_cc._4_4_ = &ppuStack_50;
          uStack_cc._0_4_ = (char *)0xbc21c7;
          pppuStack_2c = (undefined ***)(**(code **)*piStack_94)();
        }
        uStack_8._0_1_ = 10;
        uStack_cc._4_4_ = (undefined ***)0xbc21d5;
        uStack_cc._0_4_ = (char *)FUN_00ca1550();
        uStack_cc._4_4_ = (undefined ***)0x0;
        pppuStack_20 = &ppuStack_f4;
        piStack_d0 = (int *)0x0;
        uStack_8._0_1_ = 0xb;
        pppuVar2 = &ppuStack_f4;
        if (pppuStack_2c != (undefined ***)0x0) {
          piStack_d0 = (int *)(*(code *)**pppuStack_2c)(&ppuStack_f4);
          pppuVar2 = pppuStack_20;
        }
        pppuStack_20 = pppuVar2;
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        FUN_00bb9950();
        if (pppuStack_2c != (undefined ***)0x0) {
          uStack_cc._4_4_ =
               (undefined ***)CONCAT31((int3)((uint)&ppuStack_50 >> 8),pppuStack_2c != &ppuStack_50)
          ;
          uStack_cc._0_4_ = (char *)0xbc221c;
          (*(code *)(*pppuStack_2c)[4])();
        }
        piVar4 = piVar4 + 1;
        iVar7 = iStack_1c;
      } while (piVar4 != piStack_14);
    }
    if (cVar6 == '\0') {
      piVar4 = *(int **)(*(int *)(iVar7 + 0x6ec) + 0x30);
      piStack_14 = *(int **)(*(int *)(iVar7 + 0x6ec) + 0x34);
      if (piVar4 != piStack_14) {
        do {
          pppuStack_20 = &ppuStack_50;
          pppuStack_2c = (undefined ***)0x0;
          uStack_8._0_1_ = 0xc;
          if (piStack_94 != (int *)0x0) {
            uStack_cc._4_4_ = &ppuStack_50;
            uStack_cc._0_4_ = (char *)0xbc2275;
            pppuStack_2c = (undefined ***)(**(code **)*piStack_94)();
          }
          uStack_8._0_1_ = 0xd;
          uStack_cc._4_4_ = (undefined ***)0xbc2283;
          uStack_cc._0_4_ = (char *)FUN_00ca1550();
          uStack_cc._4_4_ = (undefined ***)0x0;
          pppuStack_28 = &ppuStack_f4;
          piStack_d0 = (int *)0x0;
          uStack_8._0_1_ = 0xe;
          pppuVar2 = &ppuStack_f4;
          if (pppuStack_2c != (undefined ***)0x0) {
            piStack_d0 = (int *)(*(code *)**pppuStack_2c)(&ppuStack_f4);
            pppuVar2 = pppuStack_28;
          }
          pppuStack_28 = pppuVar2;
          uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
          FUN_00bb9950();
          if (pppuStack_2c != (undefined ***)0x0) {
            uStack_cc._4_4_ =
                 (undefined ***)
                 CONCAT31((int3)((uint)&ppuStack_50 >> 8),pppuStack_2c != &ppuStack_50);
            uStack_cc._0_4_ = (char *)0xbc22ca;
            (*(code *)(*pppuStack_2c)[4])();
          }
          piVar4 = piVar4 + 1;
        } while (piVar4 != piStack_14);
      }
    }
  }
  if (piStack_94 != (int *)0x0) {
    uStack_cc._4_4_ =
         (undefined ***)CONCAT31((int3)((uint)aiStack_b8 >> 8),piStack_94 != aiStack_b8);
    uStack_cc._0_4_ = (char *)0xbc23ba;
    (**(code **)(*piStack_94 + 0x10))();
    piStack_94 = (int *)0x0;
  }
  uStack_8._0_1_ = 0x11;
  piStack_d0 = (int *)uStack_54;
  puStack_d4 = (undefined4 *)uStack_58;
  uStack_d8 = 0xbc23d9;
  uStack_cc = uStack_70;
  FUN_0152dda0();
  iVar7 = iStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_cc._4_4_ = (undefined ***)param_2;
  uStack_cc._0_4_ = (char *)0xbc23f2;
  FUN_00cdeca0();
  *(undefined4 *)(param_1 + 0x618) = *param_2;
  if ((DAT_01d5bff8 != '\0') && (cVar6 == '\0')) {
    uStack_cc._4_4_ = (undefined ***)&uStack_24;
    uStack_cc._0_4_ = (char *)0xbc240d;
    pdVar3 = (double *)FUN_016827e0();
    *(double *)(iVar7 + 0xa0) =
         (DAT_018c0d60 - *(double *)(iVar7 + 0xb0)) * *(double *)(iVar7 + 0xa0) +
         (*pdVar3 - dStack_68) * DAT_018c0d70 * *(double *)(iVar7 + 0xb0);
  }
  if (DAT_01d709fc != '\0') {
    uStack_cc._4_4_ = (undefined ***)0xbc2467;
    (**(code **)(**(int **)(*(int *)(iVar7 + 0x6ac) + 0x154) + 0x54))();
  }
LAB_00bc2467:
  piVar4 = piStack_5c;
  uVar1 = uStack_60;
  uVar5 = (undefined4)uStack_88;
  piStack_d0 = piStack_5c;
  puStack_d4 = (undefined4 *)uStack_60;
  uStack_8 = 0x12;
  uStack_d8 = 0xbc2485;
  uStack_cc = uStack_88;
  FUN_0152dda0();
  if ((cStack_15 != '\0') && (DAT_01d7ad40 != '\0')) {
    uStack_cc._4_4_ = (undefined ***)uStack_88._4_4_;
    uStack_cc._0_4_ = (char *)uVar5;
    piStack_d0 = piVar4;
    puStack_d4 = (undefined4 *)uVar1;
    uStack_d8 = 0xbc24a2;
    FUN_01532d10();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26174 ; VA 0x00bc26c0 ; FUN_00bc26c0 */

void __fastcall FUN_00bc26c0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a655f;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x1b4) != 0) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_00c15960();
    puVar4 = *(undefined4 **)(param_1 + 0x1b4);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *puVar4 = *puVar5;
    puVar4[1] = uVar1;
    puVar4[2] = uVar2;
    puVar4[3] = uVar3;
    *(undefined8 *)(puVar4 + 4) = *(undefined8 *)(puVar5 + 4);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  if (puVar4 != (undefined4 *)0x0) {
    puVar5 = (undefined4 *)FUN_00c15960();
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *puVar4 = *puVar5;
    puVar4[1] = uVar1;
    puVar4[2] = uVar2;
    puVar4[3] = uVar3;
    *(undefined8 *)(puVar4 + 4) = *(undefined8 *)(puVar5 + 4);
    *(undefined4 **)(param_1 + 0x1b4) = puVar4;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26175 ; VA 0x00bc2770 ; FUN_00bc2770 */

void __thiscall FUN_00bc2770(int param_1,char param_2)

{
  if (param_2 != '\0') {
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 1;
    return;
  }
  *(undefined4 *)(param_1 + 100) = 0;
  return;
}



/* FUNCTION 26176 ; VA 0x00bc2790 ; FUN_00bc2790 */

void __thiscall FUN_00bc2790(int param_1,char param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe2af;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x110);
  if ((iVar2 != 0) != (bool)param_2) {
    if (param_2 != '\0') {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar2 == 0) {
        *(undefined4 *)(param_1 + 0x110) = 0;
        ExceptionList = pvStack_10;
        return;
      }
      uVar3 = FUN_00f3ae70();
      *(undefined4 *)(param_1 + 0x110) = uVar3;
      ExceptionList = pvStack_10;
      return;
    }
    if (iVar2 != 0) {
      ExceptionList = &pvStack_10;
      FUN_00bba950();
      _param_2 = 0;
      if (*(int *)(iVar2 + 0x20) != 0) {
        piVar6 = *(int **)(iVar2 + 0x18);
        do {
          iVar1 = *piVar6;
          uStack_8 = 1;
          FUN_00bbbaa0(*(undefined4 *)(iVar1 + 4));
          uStack_8 = 0xffffffff;
          *(int *)(*piVar6 + 4) = iVar1;
          *(int *)*piVar6 = iVar1;
          *(int *)(*piVar6 + 8) = iVar1;
          piVar6[1] = 0;
          FUN_01674ea0(*piVar6,0x1b8);
          piVar6 = (int *)(*(int *)(iVar2 + 0x18) + 8);
          _param_2 = _param_2 + 1;
          *(int **)(iVar2 + 0x18) = piVar6;
          if (piVar6 == *(int **)(iVar2 + 0x14)) {
            piVar6 = *(int **)(iVar2 + 0x10);
            *(int **)(iVar2 + 0x18) = piVar6;
          }
        } while (_param_2 < *(uint *)(iVar2 + 0x20));
      }
      iVar1 = *(int *)(iVar2 + 0x10);
      if (iVar1 != 0) {
        uVar5 = *(int *)(iVar2 + 0x14) - iVar1 & 0xfffffff8;
        iVar4 = iVar1;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar1 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      FUN_01674ea0(iVar2,0x50);
    }
    *(undefined4 *)(param_1 + 0x110) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26177 ; VA 0x00bc2910 ; FUN_00bc2910 */

int __thiscall FUN_00bc2910(int param_1,float param_2)

{
  int iVar1;
  float10 fVar2;
  float10 fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  if (DAT_01ef3701 != '\0') {
    *(undefined4 *)(param_1 + 0x4c) = 1;
    return 1;
  }
  if (DAT_01d633d0 == '\0') {
    if (DAT_01d67c88 == '\0') {
      *(undefined4 *)(param_1 + 0x4c) = 8;
      return 8;
    }
    iVar1 = *(int *)(param_1 + 0x604) * 2;
    *(int *)(param_1 + 0x4c) = iVar1;
    return iVar1;
  }
  iVar1 = DAT_01ef36f8;
  if (DAT_01ef36f8 != 0) {
    *(int *)(param_1 + 0x4c) = DAT_01ef36f8;
    return iVar1;
  }
  if (DAT_01d67c90 == '\0') {
    iVar1 = FUN_00bb5bf0();
    fVar4 = *(float *)(param_1 + 0x68) + (float)iVar1 * param_2;
  }
  else {
    fVar4 = (float)*(int *)(param_1 + 0x60c) * param_2 + *(float *)(param_1 + 0x68);
  }
  fVar2 = (float10)FUN_01725280((double)fVar4);
  *(int *)(param_1 + 0x88) = (int)fVar2;
  if (DAT_01d67c70 == '\0') {
    fVar5 = (float)DAT_01d67bdc;
  }
  else {
    fVar3 = (float10)FUN_00bbd8f0();
    fVar5 = DAT_018e3f8c;
    if (DAT_0191a25c < (float)fVar3) {
      fVar5 = (float)DAT_01d67bdc;
    }
  }
  if ((float)fVar2 <= fVar5) {
    fVar5 = (float)fVar2;
  }
  fVar4 = fVar4 - fVar5;
  fVar6 = DAT_0195cda8;
  if (fVar4 <= DAT_0195cda8) {
    fVar6 = fVar4;
  }
  *(float *)(param_1 + 0x68) = fVar6;
  *(float *)(param_1 + 0x84) = fVar4 - fVar6;
  if (0.0 < fVar5) {
    iVar1 = (int)fVar5;
    *(int *)(param_1 + 0x4c) = iVar1;
    if (DAT_01ef36f4 != '\0') {
      FUN_016774b0(DAT_01ef36f4,"World Steps this Iteration: %d",iVar1);
      iVar1 = *(int *)(param_1 + 0x4c);
    }
    return iVar1;
  }
  return 0;
}



/* FUNCTION 26178 ; VA 0x00bc2ac0 ; FUN_00bc2ac0 */

void FUN_00bc2ac0(undefined4 param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00c19fc0(param_1);
  FUN_0106a3d0(uVar1,param_2 + -1);
  return;
}



/* FUNCTION 26179 ; VA 0x00bc2af0 ; FUN_00bc2af0 */

int __fastcall FUN_00bc2af0(int param_1)

{
  return param_1 + 0x1ec;
}



/* FUNCTION 26180 ; VA 0x00bc2b00 ; FUN_00bc2b00 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall
FUN_00bc2b00(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  double *pdVar5;
  int iVar6;
  float *pfVar7;
  undefined4 *puVar8;
  float *pfVar9;
  float10 fVar10;
  float fVar11;
  double dVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined4 uVar20;
  double adStack_4c [2];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  float *pfStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe360;
  pvStack_10 = ExceptionList;
  iStack_18 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if ((*(int *)(iStack_18 + 0x34) < DAT_01ef3900) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef3900), cVar2 = DAT_01d7ad48,
     DAT_01ef3900 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0(&DAT_018cb3fc,"worldStep",0xffffffff);
    if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar17);
    }
    uStack_8 = 0xffffffff;
    DAT_01ef38f8 = (int)uVar17;
    DAT_01ef38fc = (int)((ulonglong)uVar17 >> 0x20);
    FUN_016f37bf(&DAT_01ef3900);
    param_1 = iStack_20;
  }
  cStack_12 = DAT_01d7ad48;
  uStack_30 = DAT_01ef38f8;
  uStack_2c = DAT_01ef38fc;
  uVar17 = FUN_01532c80(DAT_01ef38f8,DAT_01ef38fc);
  uStack_8 = 1;
  iVar3 = FUN_01675290(DAT_01ef3710);
  uStack_8._0_1_ = 2;
  *(undefined *)(param_1 + 0x38) = 1;
  iStack_20 = iVar3;
  FUN_016827e0(adStack_4c);
  cStack_11 = DAT_01d5bff8;
  uStack_1c = *(undefined4 *)(param_1 + 0x50);
  if ((*(int *)(iStack_18 + 0x34) < DAT_01ef38f0) &&
     (FUN_016f3809(&DAT_01ef38f0), DAT_01ef38f0 == -1)) {
    uStack_8._0_1_ = 3;
    uVar18 = FUN_0152dab0(&DAT_018cb3fc,"newStepContacts",0xffffffff);
    DAT_01ef38ec = (undefined4)((ulonglong)uVar18 >> 0x20);
    DAT_01ef38e8 = (float *)uVar18;
    uStack_8._0_1_ = 2;
    FUN_016f37bf(&DAT_01ef38f0);
  }
  pfStack_28 = DAT_01ef38e8;
  uStack_24 = DAT_01ef38ec;
  uVar18 = FUN_0152d930(DAT_01ef38e8,DAT_01ef38ec);
  uStack_8._0_1_ = 4;
  uVar4 = FUN_01675290(DAT_01ef3710);
  uStack_34 = uVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (cStack_11 == '\0') {
    pdVar5 = adStack_4c + 1;
    adStack_4c[1] = 0.0;
  }
  else {
    pdVar5 = (double *)FUN_016827e0(adStack_4c + 1);
  }
  uStack_3c = *(undefined4 *)pdVar5;
  uStack_38 = *(undefined4 *)((int)pdVar5 + 4);
  if (DAT_01d69070 != '\0') {
    if (DAT_01d69148 == '\0') {
      FUN_00ce9fc0();
    }
    else {
      FUN_00bc1c50(param_3,param_2);
    }
  }
  FUN_01069980(param_2);
  FUN_00ce9530(uStack_1c,param_3,param_2);
  FUN_01069650(uStack_1c,param_2);
  if (cStack_11 != '\0') {
    pdVar5 = (double *)FUN_016827e0(adStack_4c + 1);
    *(double *)(param_1 + 0xa8) =
         (DAT_018c0d60 - *(double *)(param_1 + 0xb0)) * *(double *)(param_1 + 0xa8) +
         *(double *)(param_1 + 0xb0) *
         (*pdVar5 - (double)CONCAT44(uStack_38,uStack_3c)) * DAT_018c0d70;
  }
  uStack_8._0_1_ = 6;
  FUN_01675290(uVar4);
  uStack_8._0_1_ = 7;
  FUN_0152dda0(pfStack_28,uStack_24,uVar18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01068390();
  if (DAT_01d67c90 == '\0') {
    fVar10 = (float10)FUN_00bb5be0();
    pfStack_28 = (float *)(float)fVar10;
    FUN_00f38430(param_2,*(undefined4 *)(param_1 + 0xc4),pfStack_28,param_3,param_4,param_5);
  }
  else {
    FUN_00f38430(param_2,*(undefined4 *)(param_1 + 0xc4),*(undefined4 *)(param_1 + 0x610),param_3,
                 param_4,param_5);
  }
  iVar6 = iStack_18;
  *(undefined *)(param_1 + 0x38) = 0;
  if ((DAT_01d67ca0 != '\0') || (DAT_01d69070 != '\0')) {
    FUN_00bc1eb0(param_3,param_2);
    if ((DAT_01d69148 != '\0') && (DAT_01d69070 != '\0')) {
      FUN_00ce9fc0();
    }
    goto LAB_00bc3167;
  }
  if ((*(int *)(iStack_18 + 0x34) < DAT_01ef3910) &&
     (FUN_016f3809(&DAT_01ef3910), DAT_01ef3910 == -1)) {
    uStack_8._0_1_ = 8;
    uVar18 = FUN_0061f560(&DAT_018cb3fc,"updateBroadphase",DAT_01d7ad48,0xffffffff);
    DAT_01ef390c = (undefined4)((ulonglong)uVar18 >> 0x20);
    DAT_01ef3908 = (undefined4)uVar18;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016f37bf(&DAT_01ef3910);
  }
  cVar2 = DAT_01d7ad48;
  uStack_24 = DAT_01ef3908;
  param_5 = DAT_01ef390c;
  uVar18 = FUN_01532c80(DAT_01ef3908,DAT_01ef390c);
  uStack_8._0_1_ = 9;
  if (DAT_01d70970 == '\0') {
    if ((*(int *)(iVar6 + 0x34) < DAT_01ef3940) && (FUN_016f3809(&DAT_01ef3940), DAT_01ef3940 == -1)
       ) {
      uStack_8._0_1_ = 0xc;
      uVar19 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef393c = (undefined4)((ulonglong)uVar19 >> 0x20);
      DAT_01ef3938 = (undefined4)uVar19;
      uStack_8._0_1_ = 9;
      FUN_016f37bf(&DAT_01ef3940);
    }
    FUN_0152d760(DAT_01ef3938,DAT_01ef393c,"High Priority Assemblies %d",
                 *(undefined4 *)(*(int *)(param_1 + 0x6ec) + 0x24));
    if ((*(int *)(iVar6 + 0x34) < DAT_01ef3950) && (FUN_016f3809(&DAT_01ef3950), DAT_01ef3950 == -1)
       ) {
      uStack_8._0_1_ = 0xd;
      uVar19 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef394c = (undefined4)((ulonglong)uVar19 >> 0x20);
      DAT_01ef3948 = (undefined4)uVar19;
      uStack_8._0_1_ = 9;
      FUN_016f37bf(&DAT_01ef3950);
    }
    iVar6 = *(int *)(*(int *)(param_1 + 0x6ec) + 0x18);
    uVar4 = DAT_01ef3948;
    uVar20 = DAT_01ef394c;
  }
  else {
    if ((*(int *)(iVar6 + 0x34) < DAT_01ef3920) && (FUN_016f3809(&DAT_01ef3920), DAT_01ef3920 == -1)
       ) {
      uStack_8._0_1_ = 10;
      uVar19 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef391c = (undefined4)((ulonglong)uVar19 >> 0x20);
      DAT_01ef3918 = (undefined4)uVar19;
      uStack_8._0_1_ = 9;
      FUN_016f37bf(&DAT_01ef3920);
    }
    FUN_0152d760(DAT_01ef3918,DAT_01ef391c,"High Priority Assemblies %d",
                 *(int *)(*(int *)(param_1 + 0x6ec) + 0x40) -
                 *(int *)(*(int *)(param_1 + 0x6ec) + 0x3c) >> 2);
    if ((*(int *)(iVar6 + 0x34) < DAT_01ef3930) && (FUN_016f3809(&DAT_01ef3930), DAT_01ef3930 == -1)
       ) {
      uStack_8._0_1_ = 0xb;
      uVar19 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef392c = (undefined4)((ulonglong)uVar19 >> 0x20);
      DAT_01ef3928 = (undefined4)uVar19;
      uStack_8._0_1_ = 9;
      FUN_016f37bf(&DAT_01ef3930);
    }
    iVar6 = *(int *)(*(int *)(param_1 + 0x6ec) + 0x34) - *(int *)(*(int *)(param_1 + 0x6ec) + 0x30)
            >> 2;
    uVar4 = DAT_01ef3928;
    uVar20 = DAT_01ef392c;
  }
  FUN_0152d760(uVar4,uVar20,"Low Priority Assemblies %d",iVar6);
  FUN_016827e0(&uStack_3c);
  iVar6 = *(int *)(param_1 + 0x6ec);
  if (DAT_01d70970 == '\0') {
    pfVar9 = *(float **)(iVar6 + 0x28);
    pfStack_28 = (float *)(iVar6 + 0x28);
    if (pfVar9 != pfStack_28) {
      do {
        if (pfVar9 == (float *)0x0) {
          pfVar7 = (float *)0x0;
        }
        else {
          pfVar7 = pfVar9 + -0xb;
        }
        FUN_00ce6600(pfVar7);
        pfVar9 = (float *)*pfVar9;
      } while (pfVar9 != pfStack_28);
    }
    if ((char)param_2 == '\0') {
      pfStack_28 = (float *)(*(int *)(param_1 + 0x6ec) + 0x1c);
      pfVar9 = (float *)*pfStack_28;
      if (pfVar9 != pfStack_28) {
        do {
          if (pfVar9 == (float *)0x0) {
            pfVar7 = (float *)0x0;
          }
          else {
            pfVar7 = pfVar9 + -0xb;
          }
          FUN_00ce6600(pfVar7);
          pfVar9 = (float *)*pfVar9;
        } while (pfVar9 != pfStack_28);
      }
      if (DAT_01d5bff8 != '\0') {
        pdVar5 = (double *)FUN_016827e0(adStack_4c + 1);
        dVar12 = (DAT_018c0d60 - *(double *)(param_1 + 0xb0)) * *(double *)(param_1 + 0xa0) +
                 (*pdVar5 - (double)CONCAT44(uStack_38,uStack_3c)) * DAT_018c0d70 *
                 *(double *)(param_1 + 0xb0);
        goto LAB_00bc3085;
      }
    }
  }
  else {
    puVar8 = *(undefined4 **)(iVar6 + 0x3c);
    pfStack_28 = (float *)((uint)((int)*(undefined4 **)(iVar6 + 0x40) + (3 - (int)puVar8)) >> 2);
    if (*(undefined4 **)(iVar6 + 0x40) < puVar8) {
      pfStack_28 = (float *)0x0;
    }
    if (pfStack_28 != (float *)0x0) {
      pfVar9 = (float *)0x0;
      do {
        FUN_00ce6600(*puVar8);
        pfVar9 = (float *)((int)pfVar9 + 1);
        puVar8 = puVar8 + 1;
        iVar3 = iStack_20;
      } while (pfVar9 != pfStack_28);
    }
    if ((char)param_2 == '\0') {
      puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x6ec) + 0x30);
      puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x6ec) + 0x34);
      pfStack_28 = (float *)((uint)((int)puVar1 + (3 - (int)puVar8)) >> 2);
      if (puVar1 < puVar8) {
        pfStack_28 = (float *)0x0;
      }
      if (pfStack_28 != (float *)0x0) {
        pfVar9 = (float *)0x0;
        do {
          FUN_00ce6600(*puVar8);
          pfVar9 = (float *)((int)pfVar9 + 1);
          puVar8 = puVar8 + 1;
          iVar3 = iStack_20;
        } while (pfVar9 != pfStack_28);
      }
      if (DAT_01d5bff8 != '\0') {
        pdVar5 = (double *)FUN_016827e0(adStack_4c + 1);
        dVar12 = (DAT_018c0d60 - *(double *)(param_1 + 0xb0)) * *(double *)(param_1 + 0xa0) +
                 *(double *)(param_1 + 0xb0) *
                 (*pdVar5 - (double)CONCAT44(uStack_38,uStack_3c)) * DAT_018c0d70;
LAB_00bc3085:
        *(double *)(param_1 + 0xa0) = dVar12;
      }
    }
  }
  if (DAT_01d709fc != '\0') {
    if (DAT_01d69070 == '\0') {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x6ac) + 0x154) + 0x54))();
      if ((*(int *)(iStack_18 + 0x34) < DAT_01ef3960) &&
         (FUN_016f3809(&DAT_01ef3960), DAT_01ef3960 == -1)) {
        uStack_8._0_1_ = 0xe;
        uVar19 = FUN_0152da50(&DAT_018cb3fc);
        DAT_01ef395c = (undefined4)((ulonglong)uVar19 >> 0x20);
        DAT_01ef3958 = (undefined4)uVar19;
        uStack_8._0_1_ = 9;
        FUN_016f37bf(&DAT_01ef3960);
      }
      uVar4 = (**(code **)(**(int **)(*(int *)(param_1 + 0x6ac) + 0x154) + 0x60))();
      FUN_0152d760(DAT_01ef3958,DAT_01ef395c,"Pairs Traversed LastFrame: %d",uVar4);
    }
    else {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x6ac) + 0x158) + 0x24))();
    }
  }
  uVar4 = uStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  FUN_0152dda0(uStack_24,param_5,uVar18);
  if ((cVar2 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,param_5,uVar18);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
LAB_00bc3167:
  if ((char)param_2 == '\0') {
    pdVar5 = (double *)FUN_016827e0(&param_4);
    fVar16 = *(float *)(param_1 + 0x78);
    fVar15 = (float)((*pdVar5 - adStack_4c[0]) * DAT_018c0d70);
    fVar14 = DAT_018ce2f8 - fVar16;
    fVar11 = DAT_018ce2f8 - *(float *)(param_1 + 0x80);
    fVar13 = *(float *)(param_1 + 0x70);
    *(float *)(param_1 + 0x70) = fVar15;
    *(float *)(param_1 + 0x7c) =
         fVar11 * *(float *)(param_1 + 0x7c) + *(float *)(param_1 + 0x80) * fVar15;
    fVar13 = (fVar15 - fVar13) * fVar16 + fVar14 * *(float *)(param_1 + 0x74);
    fVar16 = fVar16 * fVar15 + *(float *)(param_1 + 0x6c) * fVar14;
    *(float *)(param_1 + 0x74) = fVar13;
    *(float *)(param_1 + 0x6c) = fVar16;
    if (DAT_01ef36f7 != '\0') {
      FUN_016774d0(DAT_01ef36f7,"%4.4f, %4.4f, %4.4f, %4.4f",fVar16,fVar13,0,0);
    }
  }
  iVar6 = iStack_18;
  if (DAT_01d69160 != '\0') {
    *(double *)(param_1 + 0x90) =
         (DAT_018c0d60 - *(double *)(param_1 + 0x98)) * *(double *)(param_1 + 0x90) +
         *(double *)(param_1 + 0x98) * (double)*(int *)(param_1 + 0x638);
  }
  if (DAT_01d67c98 != '\0') {
    if ((*(int *)(iStack_18 + 0x34) < DAT_01ef3970) &&
       (FUN_016f3809(&DAT_01ef3970), DAT_01ef3970 == -1)) {
      uStack_8._0_1_ = 0x10;
      uVar18 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef396c = (undefined4)((ulonglong)uVar18 >> 0x20);
      DAT_01ef3968 = (undefined4)uVar18;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_016f37bf(&DAT_01ef3970);
    }
    FUN_0152d760(DAT_01ef3968,DAT_01ef396c,"Assemblies invalidated by movement: %d",
                 *(undefined4 *)(param_1 + 0x48));
    if ((*(int *)(iVar6 + 0x34) < DAT_01ef3980) && (FUN_016f3809(&DAT_01ef3980), DAT_01ef3980 == -1)
       ) {
      uStack_8._0_1_ = 0x11;
      uVar18 = FUN_0152da50(&DAT_018cb3fc);
      DAT_01ef397c = (undefined4)((ulonglong)uVar18 >> 0x20);
      DAT_01ef3978 = (undefined4)uVar18;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_016f37bf(&DAT_01ef3980);
    }
    FUN_0152d760(DAT_01ef3978,DAT_01ef397c,"Assemblies invalidated by animation: %d",
                 *(undefined4 *)(param_1 + 0x44));
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  FUN_01675290(iVar3);
  uVar20 = uStack_2c;
  uVar4 = uStack_30;
  uStack_8 = 0x13;
  FUN_0152dda0(uStack_30,uStack_2c,uVar17);
  if ((cStack_12 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,uVar20,uVar17);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26181 ; VA 0x00bc3670 ; FUN_00bc3670 */

undefined4 * __thiscall FUN_00bc3670(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::range_error::vftable;
  return param_1;
}



/* FUNCTION 26182 ; VA 0x00bc36c0 ; FUN_00bc36c0 */

undefined4 * __thiscall FUN_00bc36c0(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 26183 ; VA 0x00bc36f0 ; FUN_00bc36f0 */

undefined4 FUN_00bc36f0(void)

{
  uint uVar1;
  byte *pbVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  code *pcVar6;
  undefined auStack_38 [12];
  uint uStack_2c;
  int iStack_24;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 auStack_10 [3];
  
  FUN_00bc3c70(&uStack_1c,0,".text");
  auStack_10[0] = 0;
  if (((DAT_01f6e3d8 == (code *)0x0) || (pcVar6 = DAT_01f6e3d8, DAT_01f6e390 == 0)) &&
     (pcVar6 = DAT_01f6e3d0, DAT_01f6e3d4 != (code *)0x0)) {
    pcVar6 = DAT_01f6e3d4;
  }
  if (pcVar6 == (code *)0x0) {
    iVar5 = FUN_00c158a0(0xc000007a);
  }
  else {
    if (((DAT_01f6e3d8 == (code *)0x0) || (pcVar6 = DAT_01f6e3d8, DAT_01f6e390 == 0)) &&
       (pcVar6 = DAT_01f6e3d0, DAT_01f6e3d4 != (code *)0x0)) {
      pcVar6 = DAT_01f6e3d4;
    }
    uVar4 = GetCurrentProcess();
    iVar5 = (*pcVar6)(uVar4,uStack_1c,0,auStack_38,0x1c,auStack_10);
  }
  if (iVar5 < 0) {
    cVar3 = FUN_00bc37e0();
    if (cVar3 != '\0') {
      for (uVar1 = 0; (0x80U >> uVar1 & 1) == 0; uVar1 = uVar1 + 1) {
      }
      pbVar2 = (byte *)((int)&DAT_01f046a8 + ((int)uVar1 >> 3));
      *pbVar2 = *pbVar2 | '\x01' << (uVar1 & 7);
    }
  }
  else if ((uStack_2c < uStack_18) || (iStack_24 != 0x20)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 26184 ; VA 0x00bc37e0 ; FUN_00bc37e0 */

undefined FUN_00bc37e0(void)

{
  char cVar1;
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  undefined auStack_34 [12];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_6;
  
  uStack_6 = 1;
  uStack_10 = FUN_00731e20();
  uStack_c = FUN_01160a40(DAT_018ce2f8,0,0,0,DAT_018ce2f8,0,0,0,DAT_018ce2f8);
  cVar1 = FUN_01160b00(uStack_c);
  if (cVar1 == '\0') {
    uStack_18 = FUN_009c7dc0(auStack_34);
    uStack_14 = FUN_005c4760(DAT_018ce2f8,0,0);
    cVar1 = FUN_006e2910(uStack_14);
    if (cVar1 == '\0') {
      uStack_20 = FUN_009c7de0(auStack_4c);
      uStack_1c = FUN_005c4760(0,DAT_018ce2f8,0);
      cVar1 = FUN_006e2910(uStack_1c);
      if (cVar1 == '\0') {
        uStack_28 = FUN_00b0fe70(auStack_64);
        uStack_24 = FUN_005c4760(0,0,DAT_018ce2f8);
        cVar1 = FUN_006e2910(uStack_24);
        if (cVar1 == '\0') {
          return 0;
        }
      }
    }
  }
  return 1;
}



/* FUNCTION 26185 ; VA 0x00bc3980 ; FUN_00bc3980 */

undefined4 __thiscall
FUN_00bc3980(int param_1,undefined4 param_2,int param_3,int param_4,int *param_5,int param_6,
            int param_7,int *param_8)

{
  int iVar1;
  undefined8 uStack_10;
  int iStack_8;
  
  *param_5 = param_3;
  uStack_10 = 0;
  *param_8 = param_6;
  iVar1 = *param_5;
  iStack_8 = param_1;
  while( true ) {
    if (iVar1 == param_4) {
      return 0;
    }
    if ((param_6 == param_7) ||
       (iVar1 = FUN_016e0a4b(param_6,iVar1,param_4 - iVar1,&uStack_10,iStack_8 + 8), iVar1 == -2))
    break;
    if (iVar1 == -1) {
      return 2;
    }
    if (iVar1 == 0) {
      iVar1 = 1;
    }
    *param_5 = *param_5 + iVar1;
    *param_8 = *param_8 + 2;
    iVar1 = *param_5;
    param_6 = *param_8;
  }
  return 1;
}



/* FUNCTION 26186 ; VA 0x00bc3a20 ; FUN_00bc3a20 */

uint __thiscall FUN_00bc3a20(int param_1,undefined4 param_2,int param_3,int param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined8 uStack_14;
  int iStack_c;
  uint uStack_8;
  
  iVar1 = param_4;
  uVar2 = 0;
  uStack_8 = 0;
  uStack_14 = 0;
  iStack_c = param_1;
  if (param_5 != 0) {
    do {
      uVar2 = uStack_8;
      if (param_3 == iVar1) break;
      iVar3 = FUN_016e0a4b(&param_4,param_3,iVar1 - param_3,&uStack_14,iStack_c + 8);
      if (iVar3 < 0) break;
      if (iVar3 == 0) {
        iVar3 = 1;
      }
      param_3 = param_3 + iVar3;
      uVar2 = uStack_8 + 1;
      uStack_8 = uVar2;
    } while (uVar2 < param_5);
  }
  uVar4 = 0x7fffffff;
  if (uVar2 < 0x7fffffff) {
    uVar4 = uVar2;
  }
  return uVar4;
}



/* FUNCTION 26187 ; VA 0x00bc3ab0 ; FUN_00bc3ab0 */

bool __thiscall
FUN_00bc3ab0(int param_1,undefined4 *param_2,int param_3,undefined2 *param_4,int *param_5,
            int param_6,int param_7,int *param_8)

{
  undefined2 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_10 [8];
  int iStack_8;
  
  *param_5 = param_3;
  *param_8 = param_6;
  puVar1 = (undefined2 *)*param_5;
  iStack_8 = param_1;
  do {
    if ((puVar1 == param_4) || (param_6 == param_7)) {
      return puVar1 != param_4;
    }
    if (param_7 - param_6 < 5) {
      uVar2 = *param_2;
      uVar3 = param_2[1];
      iVar4 = FUN_016df4a3(auStack_10,*puVar1,param_2,iStack_8 + 8);
      if (iVar4 < 0) {
        return (bool)2;
      }
      if (param_7 - *param_8 < iVar4) {
        *param_2 = uVar2;
        param_2[1] = uVar3;
        return (undefined2 *)*param_5 != param_4;
      }
      FUN_0170c6f0(*param_8,auStack_10,iVar4);
      *param_5 = *param_5 + 2;
      *param_8 = *param_8 + iVar4;
    }
    else {
      iVar4 = FUN_016df4a3(param_6,*puVar1,param_2,iStack_8 + 8);
      if (iVar4 < 0) {
        return (bool)2;
      }
      *param_5 = *param_5 + 2;
      *param_8 = *param_8 + iVar4;
    }
    puVar1 = (undefined2 *)*param_5;
    param_6 = *param_8;
  } while( true );
}



/* FUNCTION 26188 ; VA 0x00bc3bc0 ; FUN_00bc3bc0 */

undefined4 __thiscall
FUN_00bc3bc0(int param_1,undefined4 *param_2,int param_3,int param_4,int *param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_c [8];
  
  *param_5 = param_3;
  uVar1 = *param_2;
  uVar2 = param_2[1];
  iVar3 = FUN_016df4a3(auStack_c,0,param_2,param_1 + 8);
  if (iVar3 < 1) {
    return 2;
  }
  iVar3 = iVar3 + -1;
  if (param_4 - *param_5 < iVar3) {
    *param_2 = uVar1;
    param_2[1] = uVar2;
    return 1;
  }
  if (0 < iVar3) {
    FUN_0170c6f0(*param_5,auStack_c,iVar3);
    *param_5 = *param_5 + iVar3;
  }
  return 0;
}



/* FUNCTION 26189 ; VA 0x00bc3c50 ; FUN_00bc3c50 */

void FUN_00bc3c50(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bc3e00(param_1,param_2,0x10,0,param_3);
  return;
}



/* FUNCTION 26190 ; VA 0x00bc3c70 ; FUN_00bc3c70 */

int * FUN_00bc3c70(int *param_1,undefined4 param_2,byte *param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  byte *pbVar5;
  byte *pbVar6;
  byte *pbVar7;
  uint uVar8;
  bool bVar9;
  
  iVar2 = GetModuleHandleA(param_2);
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar2 != 0) {
    iVar4 = *(int *)(iVar2 + 0x3c) + iVar2;
    uVar8 = 0;
    pbVar6 = (byte *)(*(ushort *)(iVar4 + 0x14) + 0x18 + iVar4);
    pbVar5 = param_3;
    pbVar7 = pbVar6;
    if (*(short *)(iVar4 + 6) != 0) {
LAB_00bc3cd8:
      do {
        bVar1 = *pbVar5;
        bVar9 = bVar1 < *pbVar6;
        if (bVar1 == *pbVar6) {
          if (bVar1 != 0) {
            bVar1 = pbVar5[1];
            bVar9 = bVar1 < pbVar6[1];
            if (bVar1 != pbVar6[1]) goto LAB_00bc3cf8;
            pbVar6 = pbVar6 + 2;
            pbVar5 = pbVar5 + 2;
            if (bVar1 != 0) goto LAB_00bc3cd8;
          }
          uVar3 = 0;
        }
        else {
LAB_00bc3cf8:
          uVar3 = -(uint)bVar9 | 1;
        }
        if (uVar3 == 0) {
          iVar4 = *(int *)(pbVar7 + 0xc);
          param_1[1] = *(int *)(pbVar7 + 8);
          *param_1 = iVar4 + iVar2;
          return param_1;
        }
        uVar8 = uVar8 + 1;
        pbVar6 = pbVar7 + 0x28;
        pbVar5 = param_3;
        pbVar7 = pbVar6;
      } while (uVar8 < *(ushort *)(iVar4 + 6));
    }
    *param_1 = 0;
    param_1[1] = 0;
  }
  return param_1;
}



/* FUNCTION 26191 ; VA 0x00bc3d40 ; FUN_00bc3d40 */

uint FUN_00bc3d40(uint param_1,int param_2,int param_3,uint param_4)

{
  uint uVar1;
  char *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_8;
  
  uVar1 = 0;
  uVar4 = 0;
  uVar6 = 0;
  uStack_8 = 0;
  if (param_1 < param_1 + param_2) {
    pcVar2 = (char *)(param_1 + 2);
    iVar3 = (((param_1 + param_2) - param_1) - 1 >> 4) + 1;
    do {
      uVar5 = ((uVar4 << 10 | uVar4 >> 0x16) - (int)pcVar2[-2]) - param_3;
      uVar4 = (uVar6 << 0xf | uVar6 >> 0x11) ^ pcVar2[-1] + param_3;
      uVar6 = (uVar4 << 0xf | uVar4 >> 0x11) ^ uStack_8;
      uVar4 = *pcVar2 - param_3 ^ ~uStack_8;
      uStack_8 = (uVar4 << 0xf | uVar4 >> 0x11) + uVar6;
      uVar4 = (uVar5 * 0x8000 | uVar5 >> 0x11) ^ uVar1;
      uVar1 = (uVar1 << 5 | uVar1 >> 0x1b) + ((param_3 - pcVar2[1]) - uVar4);
      pcVar2 = pcVar2 + 0x10;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  return (uVar1 ^ uStack_8) + uVar6 + uVar4 ^ param_4;
}



/* FUNCTION 26192 ; VA 0x00bc3de0 ; FUN_00bc3de0 */

void FUN_00bc3de0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00bc3e00(param_1,param_2,param_3,0,0);
  return;
}



/* FUNCTION 26193 ; VA 0x00bc3e00 ; FUN_00bc3e00 */

uint FUN_00bc3e00(int *param_1,int param_2,int param_3,int *param_4,int *param_5)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uStack_10 = 0x1594fe2d;
  uStack_c = 0xd2c21b15;
  uStack_8 = 0xcd180241;
  iVar5 = -0x344b5409;
  if (param_5 != (int *)0x0) {
    uStack_10 = param_5[1];
    iVar5 = *param_5;
    uStack_c = param_5[2];
    uStack_8 = param_5[3];
  }
  piVar1 = (int *)(param_3 + (int)param_1);
  param_2 = param_2 - (int)param_1;
  do {
    uVar4 = param_2 + (int)param_1;
    piVar6 = param_1 + ((uVar4 >> 8 & 0xf) + 1) * 0x800;
    if (piVar1 < param_1 + ((uVar4 >> 8 & 0xf) + 1) * 0x800) {
      piVar6 = piVar1;
    }
    for (; param_1 < piVar6; param_1 = param_1 + 4) {
      uVar3 = uVar4 + 8;
      uVar2 = (*param_1 + param_2 + (int)param_1) * 0x1594fe2d + iVar5;
      iVar5 = (uVar2 * 0x80000 | uVar2 >> 0xd) * -0x344b5409;
      uStack_10 = ((param_2 - param_1[1]) + (int)(param_1 + 1)) * 0x344b5409 + uStack_10;
      uStack_10 = (uStack_10 * 0x20000 | uStack_10 >> 0xf) * 0x1594fe2d;
      uVar4 = uVar4 + 0x10;
      uStack_c = (param_1[2] ^ uVar3) * 0x1594fe2d + uStack_c;
      uStack_c = (uStack_c * 0x2000 | uStack_c >> 0x13) * -0x344b5409;
      uStack_8 = ((param_1[3] - param_2) - (int)(param_1 + 3)) * 0x344b5409 + uStack_8;
      uStack_8 = (uStack_8 * 0x8000 | uStack_8 >> 0x11) * 0x1594fe2d;
    }
    if (param_4 == (int *)0x0) {
      iVar5 = (int)param_1 + iVar5 + param_2 + param_1[-1] + -4;
    }
  } while (param_1 < piVar1);
  uVar4 = (uStack_8 << 0x12 | uStack_8 >> 0xe) + (uStack_c << 0xc | uStack_c >> 0x14) +
          (uStack_10 << 7 | uStack_10 >> 0x19) + (iVar5 << 1 | (uint)(iVar5 < 0));
  uVar4 = (uVar4 >> 0xf ^ uVar4) * -0x32e7fdbf;
  uVar4 = (uVar4 >> 0xd ^ uVar4) * -0x2d3de4eb;
  if (param_4 != (int *)0x0) {
    param_4[3] = uStack_8;
    *param_4 = iVar5;
    param_4[1] = uStack_10;
    param_4[2] = uStack_c;
  }
  return uVar4 ^ uVar4 >> 0x10;
}



/* FUNCTION 26194 ; VA 0x00bc3f70 ; FUN_00bc3f70 */

void FUN_00bc3f70(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  FUN_00bc3e00(param_1,param_2,param_3 + -0x10,param_4,0);
  return;
}



/* FUNCTION 26195 ; VA 0x00bc3f90 ; FUN_00bc3f90 */

int FUN_00bc3f90(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = param_1 * -3 + 0xbf410579;
  if ((-param_1 & 1U) == 0) {
    uVar1 = param_1 * -3 + 0x87b9aec1;
  }
  if ((uVar1 & 4) == 0) {
    iVar4 = param_1 + -0x618938f4;
    iVar2 = param_1 + -0x1eb655dc;
  }
  else {
    iVar4 = param_1 + -0x5a7bc9d6;
    iVar2 = param_1 + -0x17a8e6be;
  }
  iVar3 = 0x344b5409;
  if ((-param_1 & 1U) == 0) {
    iVar2 = iVar4;
  }
  uVar5 = iVar2 * -0xb & 0x10;
  uVar1 = 0x344b5409 - iVar2;
  if (uVar5 == 0) {
    uVar1 = 0xea6b01d3 - iVar2;
  }
  if ((uVar1 & 2) == 0) {
    iVar4 = -0x1eb655dc;
    if (uVar5 == 0) {
      iVar4 = 0x2b29fc5a;
    }
    iVar4 = iVar4 + iVar2;
  }
  else {
    iVar4 = iVar2 + -0x618938f4;
    if (uVar5 == 0) {
      iVar4 = iVar2 + -0x17a8e6be;
    }
  }
  if ((iVar4 * -3 & 8U) == 0) {
    iVar3 = 0x2d3de4eb;
  }
  iVar4 = iVar4 - iVar3;
  iVar2 = iVar4 + 0x1594fe2d;
  if ((iVar4 * 0x15 & 0x20U) == 0) {
    iVar2 = iVar4 + -0x344b5409;
  }
  return iVar2;
}



/* FUNCTION 26196 ; VA 0x00bc4040 ; FUN_00bc4040 */

void FUN_00bc4040(uint param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  uVar2 = 0;
  uVar4 = 1;
  iVar3 = 0x20;
  do {
    uVar1 = uVar4 | uVar2;
    if (((uVar2 * -0x344b5409 + 0xd2c21b15 ^ uVar2 * 0x1594fe2c + 0xcd180241) & uVar4) ==
        (uVar4 & param_1)) {
      uVar1 = uVar2;
    }
    uVar2 = uVar1;
    uVar4 = uVar4 * 2;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  return;
}



/* FUNCTION 26197 ; VA 0x00bc4090 ; FUN_00bc4090 */

undefined4 * __thiscall FUN_00bc4090(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000014c;
  undefined4 auStack_458 [87];
  undefined4 uStack_2fc;
  undefined *puStack_2f8;
  undefined *puStack_2f4;
  undefined4 *puStack_2f0;
  undefined auStack_2dc [320];
  uint uStack_19c;
  undefined auStack_194 [24];
  undefined4 uStack_17c;
  undefined auStack_174 [320];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe38e;
  pvStack_10 = ExceptionList;
  puStack_2f0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_2f4 = (undefined *)0xbc40d4;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00bc5dc0();
  uStack_17c = param_2;
  puStack_2f0 = (undefined4 *)auStack_2dc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_2f4 = (undefined *)0xbc40fc;
  FUN_00bc5dc0();
  puStack_2f0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_458;
  auStack_458[0] = uStack_17c;
  FUN_00bc5dc0(auStack_174);
  ppuVar2 = &PTR_FUN_0195d97c;
  cVar1 = FUN_00bc48e0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_2f8 = auStack_2c;
      puStack_2f0 = (undefined4 *)0x2;
      uStack_2fc = 0xbc415c;
      puStack_2f4 = puStack_2f8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_2f0 = (undefined4 *)0xbc4171;
  FUN_00bc7710();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_19c != 0) {
    if (((uStack_19c & 1) == 0) && (*(code **)(uStack_19c & 0xfffffffe) != (code *)0x0)) {
      puStack_2f8 = auStack_194;
      puStack_2f0 = (undefined4 *)0x2;
      uStack_2fc = 0xbc4198;
      puStack_2f4 = puStack_2f8;
      (**(code **)(uStack_19c & 0xfffffffe))();
    }
    uStack_19c = 0;
  }
  puStack_2f0 = (undefined4 *)0xbc41b0;
  FUN_00bc7710();
  uStack_8 = 5;
  if (in_stack_0000014c != 0) {
    if (((in_stack_0000014c & 1) == 0) &&
       (*(code **)(in_stack_0000014c & 0xfffffffe) != (code *)0x0)) {
      puStack_2f8 = &stack0x00000154;
      puStack_2f0 = (undefined4 *)0x2;
      uStack_2fc = 0xbc41da;
      puStack_2f4 = puStack_2f8;
      (**(code **)(in_stack_0000014c & 0xfffffffe))();
    }
    in_stack_0000014c = 0;
  }
  puStack_2f0 = (undefined4 *)0xbc41ef;
  FUN_00bc7710();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26198 ; VA 0x00bc4210 ; FUN_00bc4210 */

undefined4 * __thiscall FUN_00bc4210(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000154;
  undefined4 auStack_470 [89];
  undefined4 uStack_30c;
  undefined *puStack_308;
  undefined *puStack_304;
  undefined4 *puStack_300;
  undefined auStack_2ec [328];
  uint uStack_1a4;
  undefined auStack_19c [24];
  undefined4 uStack_184;
  undefined auStack_17c [328];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe3be;
  pvStack_10 = ExceptionList;
  puStack_300 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_304 = (undefined *)0xbc4254;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00bc60d0();
  uStack_184 = param_2;
  puStack_300 = (undefined4 *)auStack_2ec;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_304 = (undefined *)0xbc427c;
  FUN_00bc60d0();
  puStack_300 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_470;
  auStack_470[0] = uStack_184;
  FUN_00bc60d0(auStack_17c);
  ppuVar2 = &PTR_FUN_0195d984;
  cVar1 = FUN_00bc4aa0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_308 = auStack_2c;
      puStack_300 = (undefined4 *)0x2;
      uStack_30c = 0xbc42dc;
      puStack_304 = puStack_308;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_300 = (undefined4 *)0xbc42f1;
  FUN_00bc77e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_1a4 != 0) {
    if (((uStack_1a4 & 1) == 0) && (*(code **)(uStack_1a4 & 0xfffffffe) != (code *)0x0)) {
      puStack_308 = auStack_19c;
      puStack_300 = (undefined4 *)0x2;
      uStack_30c = 0xbc4318;
      puStack_304 = puStack_308;
      (**(code **)(uStack_1a4 & 0xfffffffe))();
    }
    uStack_1a4 = 0;
  }
  puStack_300 = (undefined4 *)0xbc4330;
  FUN_00bc77e0();
  uStack_8 = 5;
  if (in_stack_00000154 != 0) {
    if (((in_stack_00000154 & 1) == 0) &&
       (*(code **)(in_stack_00000154 & 0xfffffffe) != (code *)0x0)) {
      puStack_308 = &stack0x0000015c;
      puStack_300 = (undefined4 *)0x2;
      uStack_30c = 0xbc435a;
      puStack_304 = puStack_308;
      (**(code **)(in_stack_00000154 & 0xfffffffe))();
    }
    in_stack_00000154 = 0;
  }
  puStack_300 = (undefined4 *)0xbc436f;
  FUN_00bc77e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26199 ; VA 0x00bc4390 ; FUN_00bc4390 */

int * __thiscall FUN_00bc4390(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00bd3190();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 26200 ; VA 0x00bc43e0 ; FUN_00bc43e0 */

void __thiscall
FUN_00bc43e0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe3e0;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uStack_44 = 0;
  uVar3 = param_1[0x50];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_44 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      puStack_50 = param_1 + 0x52;
      uStack_54 = 0xbc4457;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_3c = param_1[0x52];
      uStack_38 = param_1[0x53];
      uStack_34 = param_1[0x54];
      uStack_30 = param_1[0x55];
      uStack_2c = *(undefined8 *)(param_1 + 0x56);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = param_1[0x48];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x4a,&uStack_5c,0);
    }
    else {
      uStack_5c = param_1[0x4a];
      uStack_58 = param_1[0x4b];
      uStack_54 = param_1[0x4c];
      puStack_50 = (undefined4 *)param_1[0x4d];
      uStack_4c = *(ulonglong *)(param_1 + 0x4e);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00bc6e60(param_1 + 2);
  puVar4 = (undefined4 *)param_4[1];
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar5 = *puVar4;
  uVar6 = puVar4[1];
  puVar4 = (undefined4 *)*param_4;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar7 = *puVar4;
  uVar8 = puVar4[1];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar7,uVar8,uVar5,uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26201 ; VA 0x00bc4570 ; FUN_00bc4570 */

void __thiscall
FUN_00bc4570(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe400;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uVar3 = *(undefined4 *)param_4[1];
  uVar4 = *(undefined4 *)*param_4;
  uStack_48 = 0;
  uVar5 = param_1[0x52];
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_48 = uVar5;
    if ((uVar5 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = param_1 + 0x54;
      uStack_58 = 0xbc45ff;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_1[0x54];
      uStack_3c = param_1[0x55];
      uStack_38 = param_1[0x56];
      uStack_34 = param_1[0x57];
      uStack_30 = *(undefined8 *)(param_1 + 0x58);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar5 = param_1[0x4a];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(param_1 + 0x4c,&uStack_60,0);
    }
    else {
      uStack_60 = param_1[0x4c];
      uStack_5c = param_1[0x4d];
      uStack_58 = param_1[0x4e];
      puStack_54 = (undefined4 *)param_1[0x4f];
      uStack_50 = *(ulonglong *)(param_1 + 0x50);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00bc6e60(param_1 + 2);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar4,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26202 ; VA 0x00bc46d0 ; FUN_00bc46d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bc46d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe430;
  pvStack_10 = ExceptionList;
  if (DAT_01ef5b18 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef5d30) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef5d30);
      if (DAT_01ef5d30 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"HttpRbxApiService",1,uStack_20,0,0,3,0,0);
        _DAT_01ef5d28 = RBX::Creator<class_RBX::HttpRbxApiService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef5b20,&DAT_01ef5d28);
        FUN_016f3654(FUN_01892150);
        FUN_016f37bf(&DAT_01ef5d30);
      }
    }
    DAT_01ef5b18 = &DAT_01ef5b20;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef5b18;
}



/* FUNCTION 26203 ; VA 0x00bc47d0 ; FUN_00bc47d0 */

void FUN_00bc47d0(void)

{
  int iVar1;
  
  if (DAT_01ef5d34 == 0) {
    iVar1 = FUN_00bc46d0();
    DAT_01ef5d34 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26204 ; VA 0x00bc47f0 ; FUN_00bc47f0 */

int __thiscall FUN_00bc47f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::HttpRbxApiJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26205 ; VA 0x00bc48c4 ; Catch_All@00bc48c4 */

void Catch_All_00bc48c4(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26206 ; VA 0x00bc48e0 ; FUN_00bc48e0 */

undefined FUN_00bc48e0(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_0000014c;
  int *in_stack_0000016c;
  undefined auStack_2dc [320];
  uint uStack_19c;
  undefined auStack_194 [24];
  undefined4 auStack_17c [2];
  undefined auStack_174 [320];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe480;
  pvStack_10 = ExceptionList;
  auStack_17c[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bc5dc0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_17c);
  uVar1 = auStack_17c[0];
  if (cVar2 == '\0') {
    FUN_00bc5dc0(auStack_174);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x168);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00bc5dc0(auStack_2dc);
    }
    *in_stack_0000016c = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_19c != 0) {
      if (((uStack_19c & 1) == 0) && (*(code **)(uStack_19c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_19c & 0xfffffffe))(auStack_194,auStack_194,2);
      }
      uStack_19c = 0;
    }
    FUN_00bc7710();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00bc7710();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00bc7710();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000014c != 0) {
    if (((in_stack_0000014c & 1) == 0) &&
       (*(code **)(in_stack_0000014c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000014c & 0xfffffffe))(&stack0x00000154,&stack0x00000154,2);
    }
    in_stack_0000014c = 0;
  }
  FUN_00bc7710();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 26207 ; VA 0x00bc4aa0 ; FUN_00bc4aa0 */

undefined FUN_00bc4aa0(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000154;
  int *in_stack_00000174;
  undefined auStack_2ec [328];
  uint uStack_1a4;
  undefined auStack_19c [24];
  undefined4 auStack_184 [2];
  undefined auStack_17c [328];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe4c0;
  pvStack_10 = ExceptionList;
  auStack_184[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bc60d0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_184);
  uVar1 = auStack_184[0];
  if (cVar2 == '\0') {
    FUN_00bc60d0(auStack_17c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x170);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00bc60d0(auStack_2ec);
    }
    *in_stack_00000174 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_1a4 != 0) {
      if (((uStack_1a4 & 1) == 0) && (*(code **)(uStack_1a4 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_1a4 & 0xfffffffe))(auStack_19c,auStack_19c,2);
      }
      uStack_1a4 = 0;
    }
    FUN_00bc77e0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00bc77e0();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00bc77e0();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000154 != 0) {
    if (((in_stack_00000154 & 1) == 0) &&
       (*(code **)(in_stack_00000154 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000154 & 0xfffffffe))(&stack0x0000015c,&stack0x0000015c,2);
    }
    in_stack_00000154 = 0;
  }
  FUN_00bc77e0();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 26208 ; VA 0x00bc4c60 ; FUN_00bc4c60 */

undefined4 * FUN_00bc4c60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  uint in_stack_0000012c;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined8 in_stack_00000144;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe4fe;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000012c != 0) && (ExceptionList = &pvStack_10, (in_stack_0000012c & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_0000012c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  FUN_00bc6e60(&stack0x00000014);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_00bc5c80(param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  FUN_00bc5ba0();
  FUN_00bc7710();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = 5;
  if (((in_stack_0000012c != 0) && ((in_stack_0000012c & 1) == 0)) &&
     (*(code **)(in_stack_0000012c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000012c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26209 ; VA 0x00bc4dc0 ; FUN_00bc4dc0 */

undefined4 *
FUN_00bc4dc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint in_stack_00000134;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined4 in_stack_00000144;
  undefined4 *in_stack_00000148;
  ulonglong in_stack_0000014c;
  uint in_stack_00000154;
  undefined4 in_stack_0000015c;
  undefined4 in_stack_00000160;
  undefined4 in_stack_00000164;
  undefined *in_stack_00000168;
  undefined8 in_stack_0000016c;
  undefined auStack_2dc [264];
  undefined4 uStack_1d4;
  undefined4 *puStack_1d0;
  undefined4 *puStack_1cc;
  undefined4 uStack_1c8;
  uint auStack_1c4 [2];
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 *puStack_1b0;
  ulonglong uStack_1ac;
  uint auStack_1a4 [2];
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 *puStack_190;
  undefined8 uStack_18c;
  uint uStack_3c;
  undefined auStack_34 [24];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe551;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_1a4;
  puStack_18 = (undefined *)auStack_1a4;
  uStack_8 = 3;
  auStack_1a4[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_1a4;
  if (in_stack_00000154 != 0) {
    auStack_1a4[0] = in_stack_00000154;
    if ((in_stack_00000154 & 1) == 0) {
      uStack_1ac = ZEXT48(&uStack_19c);
      puStack_1b0 = &stack0x0000015c;
      uStack_1b4 = 0xbc4e37;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000154 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
    }
    else {
      uStack_19c = in_stack_0000015c;
      uStack_198 = in_stack_00000160;
      uStack_194 = in_stack_00000164;
      puStack_190 = (undefined4 *)in_stack_00000168;
      uStack_18c = in_stack_0000016c;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_1a4;
    }
  }
  puStack_1c = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_1c4;
  puStack_14 = (undefined *)auStack_1c4;
  uStack_8._0_1_ = 4;
  auStack_1c4[0] = 0;
  puVar2 = auStack_1c4;
  if (in_stack_00000134 != 0) {
    auStack_1c4[0] = in_stack_00000134;
    if ((in_stack_00000134 & 1) == 0) {
      puStack_1cc = &uStack_1bc;
      uStack_1c8 = 0;
      puStack_1d0 = &stack0x0000013c;
      uStack_1d4 = 0xbc4e8e;
      (**(code **)(in_stack_00000134 & 0xfffffffe))();
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_1bc = in_stack_0000013c;
      uStack_1b8 = in_stack_00000140;
      uStack_1b4 = in_stack_00000144;
      puStack_1b0 = in_stack_00000148;
      uStack_1ac = in_stack_0000014c;
      puVar2 = auStack_1c4;
    }
  }
  puStack_18 = (undefined *)puVar2;
  puStack_14 = auStack_2dc;
  uStack_8._0_1_ = 5;
  FUN_00bc6e60(&stack0x0000001c);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uVar3 = FUN_00bc5f00(param_3,param_4,param_5,param_6);
  uStack_8._0_1_ = 6;
  *param_1 = param_2;
  uStack_18c = CONCAT44(uVar3,0xbc4efb);
  FUN_00bc5dc0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    puStack_190 = (undefined4 *)auStack_34;
    uStack_18c = CONCAT44(2,puStack_190);
    uStack_194 = 0xbc4f1c;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_18c = CONCAT44(0xbc4f31,(undefined4)uStack_18c);
  FUN_00bc7710();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_18c = CONCAT44(0xbc4f48,(undefined4)uStack_18c);
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_18c = CONCAT44(0xbc4f59,(undefined4)uStack_18c);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_18c = CONCAT44(0xbc4f61,(undefined4)uStack_18c);
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_00000134 != 0) {
    if (((in_stack_00000134 & 1) == 0) &&
       (*(code **)(in_stack_00000134 & 0xfffffffe) != (code *)0x0)) {
      puStack_190 = &stack0x0000013c;
      uStack_18c = CONCAT44(2,puStack_190);
      uStack_194 = 0xbc4f88;
      (**(code **)(in_stack_00000134 & 0xfffffffe))();
    }
    in_stack_00000134 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_00000154 != 0) && ((in_stack_00000154 & 1) == 0)) &&
     (*(code **)(in_stack_00000154 & 0xfffffffe) != (code *)0x0)) {
    puStack_190 = &stack0x0000015c;
    uStack_18c = CONCAT44(2,puStack_190);
    uStack_194 = 0xbc4fbf;
    (**(code **)(in_stack_00000154 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26210 ; VA 0x00bc4fe0 ; FUN_00bc4fe0 */

undefined4 *
FUN_00bc4fe0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint *puVar2;
  uint *puVar3;
  undefined4 uVar4;
  undefined *in_stack_00000134;
  uint in_stack_00000138;
  undefined4 in_stack_00000140;
  undefined4 in_stack_00000144;
  undefined4 in_stack_00000148;
  undefined4 *in_stack_0000014c;
  ulonglong in_stack_00000150;
  uint in_stack_00000158;
  undefined4 in_stack_00000160;
  undefined4 in_stack_00000164;
  undefined4 in_stack_00000168;
  undefined *in_stack_0000016c;
  undefined8 in_stack_00000170;
  undefined auStack_2e4 [268];
  undefined4 uStack_1d8;
  undefined4 *puStack_1d4;
  undefined4 *puStack_1d0;
  undefined4 uStack_1cc;
  uint auStack_1c8 [2];
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  ulonglong uStack_1b0;
  uint auStack_1a8 [2];
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 *puStack_194;
  undefined8 uStack_190;
  uint uStack_3c;
  undefined auStack_34 [24];
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe5a1;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_1a8;
  puStack_14 = (undefined *)auStack_1a8;
  uStack_8 = 3;
  auStack_1a8[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_1a8;
  if (in_stack_00000158 != 0) {
    auStack_1a8[0] = in_stack_00000158;
    if ((in_stack_00000158 & 1) == 0) {
      uStack_1b0 = ZEXT48(&uStack_1a0);
      puStack_1b4 = &stack0x00000160;
      uStack_1b8 = 0xbc5056;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000158 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
    }
    else {
      uStack_1a0 = in_stack_00000160;
      uStack_19c = in_stack_00000164;
      uStack_198 = in_stack_00000168;
      puStack_194 = (undefined4 *)in_stack_0000016c;
      uStack_190 = in_stack_00000170;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_1a8;
    }
  }
  puStack_1c = (undefined *)puVar2;
  puStack_14 = (undefined *)auStack_1c8;
  puStack_18 = (undefined *)auStack_1c8;
  uStack_8._0_1_ = 4;
  auStack_1c8[0] = 0;
  puVar2 = auStack_1c8;
  puVar3 = auStack_1c8;
  if (in_stack_00000138 != 0) {
    auStack_1c8[0] = in_stack_00000138;
    if ((in_stack_00000138 & 1) == 0) {
      puStack_1d0 = &uStack_1c0;
      uStack_1cc = 0;
      puStack_1d4 = &stack0x00000140;
      uStack_1d8 = 0xbc50ad;
      (**(code **)(in_stack_00000138 & 0xfffffffe))();
      puVar2 = (uint *)puStack_18;
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_1c0 = in_stack_00000140;
      uStack_1bc = in_stack_00000144;
      uStack_1b8 = in_stack_00000148;
      puStack_1b4 = in_stack_0000014c;
      uStack_1b0 = in_stack_00000150;
      puVar2 = auStack_1c8;
      puVar3 = auStack_1c8;
    }
  }
  puStack_14 = (undefined *)puVar3;
  puStack_18 = (undefined *)puVar2;
  uStack_8._0_1_ = 5;
  uStack_1cc = in_stack_00000134;
  in_stack_00000134 = auStack_2e4;
  FUN_00bc6e60(&stack0x0000001c);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uVar4 = FUN_00bc6220(param_3,param_4,param_5,param_6);
  uStack_8._0_1_ = 6;
  *param_1 = param_2;
  uStack_190 = CONCAT44(uVar4,0xbc5128);
  FUN_00bc60d0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    puStack_194 = (undefined4 *)auStack_34;
    uStack_190 = CONCAT44(2,puStack_194);
    uStack_198 = 0xbc5149;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_190 = CONCAT44(0xbc515e,(undefined4)uStack_190);
  FUN_00bc77e0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[2] + -1;
    param_4[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_190 = CONCAT44(0xbc5174,(undefined4)uStack_190);
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_190 = CONCAT44(0xbc517c,(undefined4)uStack_190);
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (in_stack_00000138 != 0) {
    if (((in_stack_00000138 & 1) == 0) &&
       (*(code **)(in_stack_00000138 & 0xfffffffe) != (code *)0x0)) {
      puStack_194 = &stack0x00000140;
      uStack_190 = CONCAT44(2,puStack_194);
      uStack_198 = 0xbc51a3;
      (**(code **)(in_stack_00000138 & 0xfffffffe))();
    }
    in_stack_00000138 = 0;
  }
  uStack_8 = 9;
  if (((in_stack_00000158 != 0) && ((in_stack_00000158 & 1) == 0)) &&
     (*(code **)(in_stack_00000158 & 0xfffffffe) != (code *)0x0)) {
    puStack_194 = &stack0x00000160;
    uStack_190 = CONCAT44(2,puStack_194);
    uStack_198 = 0xbc51da;
    (**(code **)(in_stack_00000158 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26211 ; VA 0x00bc51f0 ; FUN_00bc51f0 */

int * __fastcall FUN_00bc51f0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0090c030();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00bc528b:
    thunk_FUN_0090c030();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_0090c030();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00bc528b;
    FUN_008dcdf0(&piStack_8);
    iVar3 = FUN_0090c030();
    *param_1 = iVar3;
    iVar2 = FUN_0090c030();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26212 ; VA 0x00bc52c0 ; FUN_00bc52c0 */

int * __fastcall FUN_00bc52c0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_00bd30e0();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00bc535b:
    thunk_FUN_00bd30e0();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_00bd30e0();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00bc535b;
    FUN_00bc4390(&piStack_8);
    iVar3 = FUN_00bd30e0();
    *param_1 = iVar3;
    iVar2 = FUN_00bd30e0();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26213 ; VA 0x00bc5390 ; FUN_00bc5390 */

int FUN_00bc5390(uint *param_1,uint *param_2,int param_3)

{
  uint *puVar1;
  uint *puVar2;
  uint *puVar3;
  
  if (param_1 != param_2) {
    puVar3 = (uint *)(param_3 + 0x6c);
    puVar2 = param_1 + 0x20;
    do {
      FUN_00bc7cb0(puVar2 + -0x20);
      *(undefined *)(puVar3 + -1) = *(undefined *)(puVar2 + -6);
      if (puVar3 != puVar2 + -5) {
        puVar1 = puVar2 + -5;
        if (0xf < *puVar2) {
          puVar1 = (uint *)*puVar1;
        }
        FUN_005542c0(puVar1,puVar2[-1]);
      }
      puVar1 = puVar2 + 1;
      if (puVar3 + 6 != puVar1) {
        if (0xf < puVar2[6]) {
          puVar1 = (uint *)*puVar1;
        }
        FUN_005542c0(puVar1,puVar2[5]);
      }
      puVar1 = puVar2 + 7;
      if (puVar3 + 0xc != puVar1) {
        if (0xf < puVar2[0xc]) {
          puVar1 = (uint *)*puVar1;
        }
        FUN_005542c0(puVar1,puVar2[0xb]);
      }
      *(undefined *)(puVar3 + 0x12) = *(undefined *)(puVar2 + 0xd);
      puVar1 = puVar2 + 0xe;
      if (puVar3 + 0x13 != puVar1) {
        if (0xf < puVar2[0x13]) {
          puVar1 = (uint *)*puVar1;
        }
        FUN_005542c0(puVar1,puVar2[0x12]);
      }
      puVar3[0x19] = puVar2[0x14];
      puVar3[0x1a] = puVar2[0x15];
      FUN_008c4480(puVar2 + 0x16);
      FUN_008c4480(puVar2 + 0x1e);
      param_3 = param_3 + 0x118;
      puVar3 = puVar3 + 0x46;
      puVar1 = puVar2 + 0x26;
      puVar2 = puVar2 + 0x46;
    } while (puVar1 != param_2);
  }
  return param_3;
}



/* FUNCTION 26214 ; VA 0x00bc5480 ; thunk_FUN_0090c030 */

undefined * thunk_FUN_0090c030(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c557c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0bd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0bd4);
    if (DAT_01ee0bd4 == -1) {
      uStack_8 = 0;
      FUN_00bc5af0();
      FUN_016f3654(&LAB_01883080);
      FUN_016f37bf(&DAT_01ee0bd4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0b70;
}



/* FUNCTION 26215 ; VA 0x00bc5490 ; FUN_00bc5490 */

undefined4 * FUN_00bc5490(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe5c9;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  piVar1 = *(int **)(param_4 + 4);
  ExceptionList = &pvStack_10;
  piStack_1c = piVar1;
  (**(code **)(*piVar1 + 4))();
  puVar7 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar7 = (undefined4 *)*param_3;
  }
  puVar7 = (undefined4 *)(param_3[4] + (int)puVar7);
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puStack_14 = puVar7;
  (**(code **)(*piVar1 + 4))();
  uStack_8._0_1_ = 3;
  piStack_24 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
  if (puVar6 != (undefined4 *)0x0) {
    (**(code **)*puVar6)(1);
  }
  uStack_18 = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
  if (puVar6 != (undefined4 *)0x0) {
    (**(code **)*puVar6)(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar6 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar6 = (undefined4 *)*param_2;
  }
  puVar6 = (undefined4 *)(param_2[4] + (int)puVar6);
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  do {
    if ((param_2 == puVar6) || (puVar2 = param_3, puVar3 = param_2, param_3 == puVar7)) {
      param_1[1] = puVar6;
      *param_1 = puVar6;
LAB_00bc55cc:
      uStack_8 = 6;
      puVar7 = (undefined4 *)(**(code **)(*piStack_1c + 8))();
      if (puVar7 != (undefined4 *)0x0) {
        (**(code **)*puVar7)(1);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    for (; puVar3 != puVar6; puVar3 = (undefined4 *)((int)puVar3 + 1)) {
      if (puVar2 == puVar7) goto LAB_00bc55fd;
      cVar4 = FUN_00564a80(CONCAT31((int3)((uint)puVar6 >> 8),*(undefined *)puVar3),auStack_28);
      cVar5 = FUN_00564a80(*(undefined *)puVar2,auStack_28);
      puVar7 = puStack_14;
      if (cVar4 != cVar5) break;
      puVar2 = (undefined4 *)((int)puVar2 + 1);
    }
    if (puVar2 == puVar7) {
LAB_00bc55fd:
      *param_1 = param_2;
      param_1[1] = puVar3;
      goto LAB_00bc55cc;
    }
    param_2 = (undefined4 *)((int)param_2 + 1);
  } while( true );
}



/* FUNCTION 26216 ; VA 0x00bc5610 ; FUN_00bc5610 */

void FUN_00bc5610(uint param_1)

{
  code *pcVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined4 uStack_298;
  undefined4 *puStack_294;
  undefined auStack_290 [184];
  undefined4 uStack_1d8;
  undefined *puStack_1d4;
  undefined *puStack_1d0;
  undefined4 *puStack_1cc;
  undefined auStack_1b8 [212];
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe61c;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_1cc = (undefined4 *)0xbc563c;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0088cb40();
  puStack_1cc = &stack0x00000024;
  puStack_1d0 = (undefined *)0xbc565b;
  FUN_0054ef60();
  puStack_1cc = (undefined4 *)0xbc5660;
  puVar4 = (undefined4 *)FUN_005c9d30();
  uStack_8._0_1_ = 2;
  puStack_e0 = (undefined4 *)0x0;
  uStack_e4 = uVar3;
  if (puVar4 != (undefined4 *)0x0) {
    puStack_1cc = (undefined4 *)auStack_dc;
    puStack_1d0 = auStack_1b8;
    puStack_1d4 = (undefined *)0xbc5696;
    (*(code *)*puVar4)();
  }
  uStack_8._0_1_ = 3;
  puStack_e0 = puVar4;
  if (param_1 == 0) {
    puStack_1cc = (undefined4 *)0xbc580f;
    puStack_1cc = (undefined4 *)FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    puStack_1d0 = (undefined *)0xbc5819;
    FUN_0054e5e0();
  }
  puStack_14 = (undefined *)&uStack_298;
  pcVar1 = *(code **)((param_1 & 0xfffffffe) + 4);
  puStack_294 = (undefined4 *)0x0;
  uStack_298 = uStack_e4;
  puVar2 = &uStack_298;
  if (puVar4 != (undefined4 *)0x0) {
    (*(code *)puVar4[1])(auStack_dc,auStack_290);
    puVar2 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar2;
  puStack_294 = puStack_e0;
  if (puStack_e0 != (undefined4 *)0x0) {
    (*(code *)puStack_e0[2])(auStack_dc);
    puStack_e0 = (undefined4 *)0x0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uStack_e4 = FUN_00888530();
  if (puStack_e0 != (undefined4 *)0x0) {
    (*(code *)puStack_e0[2])(auStack_dc);
    puStack_e0 = (undefined4 *)0x0;
  }
  uStack_8._0_1_ = 3;
  (*pcVar1)(&stack0x0000000c);
  uStack_8._0_1_ = 6;
  if (puStack_e0 != (undefined4 *)0x0) {
    puStack_1cc = (undefined4 *)auStack_dc;
    puStack_1d0 = (undefined *)0xbc5779;
    (*(code *)puStack_e0[2])();
  }
  uStack_8._0_1_ = 7;
  if (puVar4 != (undefined4 *)0x0) {
    puStack_1cc = (undefined4 *)auStack_1b8;
    puStack_1d0 = (undefined *)0xbc5796;
    (*(code *)puVar4[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_1d4 = &stack0x0000000c;
    puStack_1cc = (undefined4 *)0x2;
    uStack_1d8 = 0xbc57ba;
    puStack_1d0 = puStack_1d4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  if (0xf < in_stack_00000038) {
    puStack_1cc = (undefined4 *)(in_stack_00000038 + 1);
    iVar5 = in_stack_00000024;
    if (0xfff < puStack_1cc) {
      iVar5 = *(int *)(in_stack_00000024 + -4);
      puStack_1cc = (undefined4 *)(in_stack_00000038 + 0x24);
      if (0x1f < (in_stack_00000024 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_1cc = (undefined4 *)&UNK_00bc581e;
        FUN_017167a3();
      }
    }
    puStack_1d4 = (undefined *)0xbc57f1;
    puStack_1d0 = (undefined *)iVar5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26217 ; VA 0x00bc5820 ; thunk_FUN_00bd30e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00bd30e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ffea6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef5dac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef5dac);
    if (DAT_01ef5dac == -1) {
      uStack_8 = 0;
      FUN_009ca470("ThrottlingPriority");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef5d48 = RBX::Reflection::EnumDesc<enum_RBX::ThrottlingPriority>::vftable;
      FUN_009caf20(&DAT_01d67e20,3);
      FUN_016f3654(&LAB_01892130);
      FUN_016f37bf(&DAT_01ef5dac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef5d48;
}



/* FUNCTION 26218 ; VA 0x00bc5830 ; FUN_00bc5830 */

undefined4 * __thiscall
FUN_00bc5830(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined8 param_14,undefined4 param_15)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe66f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bc46d0();
  FUN_009cb820(uVar1,param_4,param_13,param_14,param_15);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::HttpRbxApiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ThrottlingPriority,enum_RBX::HttpService::HttpContentType,enum_RBX::HttpRequestType),5>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_12;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_11;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_10;
  }
  param_1[0x14] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00bc87f0(param_5,param_6,param_7,param_8,param_9);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26219 ; VA 0x00bc5930 ; FUN_00bc5930 */

undefined4 * __thiscall
FUN_00bc5930(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined8 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe6a9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bc46d0();
  FUN_009cb820(uVar1,param_4,param_10,param_11,param_12);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::HttpRbxApiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::ThrottlingPriority,enum_RBX::HttpRequestType),3>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_9;
  }
  param_1[0x11] = puVar2;
  uStack_8._0_1_ = 2;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_8;
  }
  param_1[0x12] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00bc8d00(param_5,param_6,param_7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26220 ; VA 0x00bc5a00 ; FUN_00bc5a00 */

undefined4 * __thiscall
FUN_00bc5a00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined8 param_13,undefined4 param_14)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe6f4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00bc46d0();
  FUN_009cb820(uVar1,param_4,param_12,param_13,param_14);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::HttpRbxApiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,enum_RBX::ThrottlingPriority,enum_RBX::HttpService::HttpContentType,enum_RBX::HttpRequestType),4>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_11;
  }
  param_1[0x11] = puVar2;
  uStack_8._0_1_ = 2;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_10;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_9;
  }
  param_1[0x13] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00bc9010(param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26221 ; VA 0x00bc5af0 ; FUN_00bc5af0 */

undefined4 * __fastcall FUN_00bc5af0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("HttpRequestType");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HttpRequestType>::vftable;
  FUN_009cada0(0,"Default");
  FUN_009cada0(2,"MarketplaceService");
  FUN_009cada0(7,"Players");
  FUN_009cada0(0xf,&DAT_01931fd4);
  FUN_009cada0(0x10,"Avatar");
  FUN_009cada0(0x17,"Analytics");
  FUN_009cada0(0x19,"Localization");
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26222 ; VA 0x00bc5ba0 ; FUN_00bc5ba0 */

undefined4 * __thiscall FUN_00bc5ba0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe710;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_00bc6e60(param_2 + 2);
  param_1[0x48] = 0;
  uVar2 = param_2[0x48];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x48] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x4b];
      uVar4 = param_2[0x4c];
      uVar5 = param_2[0x4d];
      param_1[0x4a] = param_2[0x4a];
      param_1[0x4b] = uVar3;
      param_1[0x4c] = uVar4;
      param_1[0x4d] = uVar5;
      *(undefined8 *)(param_1 + 0x4e) = *(undefined8 *)(param_2 + 0x4e);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x4a,param_1 + 0x4a,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26223 ; VA 0x00bc5c80 ; FUN_00bc5c80 */

undefined4 __thiscall FUN_00bc5c80(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  uint in_stack_00000124;
  undefined4 in_stack_0000012c;
  undefined4 in_stack_00000130;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined8 in_stack_0000013c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe743;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000124 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000124 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000124 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  FUN_00bc6e60(&stack0x0000000c);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bc63e0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = 4;
  if (((in_stack_00000124 != 0) && ((in_stack_00000124 & 1) == 0)) &&
     (*(code **)(in_stack_00000124 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000124 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26224 ; VA 0x00bc5dc0 ; FUN_00bc5dc0 */

undefined4 * __thiscall FUN_00bc5dc0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe768;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_00bc6e60(param_2 + 2);
  param_1[0x48] = 0;
  uVar2 = param_2[0x48];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x48] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x4a,param_1 + 0x4a,0);
    }
    else {
      uVar3 = param_2[0x4b];
      uVar4 = param_2[0x4c];
      uVar5 = param_2[0x4d];
      param_1[0x4a] = param_2[0x4a];
      param_1[0x4b] = uVar3;
      param_1[0x4c] = uVar4;
      param_1[0x4d] = uVar5;
      *(undefined8 *)(param_1 + 0x4e) = *(undefined8 *)(param_2 + 0x4e);
    }
  }
  param_1[0x50] = 0;
  uVar2 = param_2[0x50];
  uStack_8 = 2;
  if (uVar2 != 0) {
    param_1[0x50] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x53];
      uVar4 = param_2[0x54];
      uVar5 = param_2[0x55];
      param_1[0x52] = param_2[0x52];
      param_1[0x53] = uVar3;
      param_1[0x54] = uVar4;
      param_1[0x55] = uVar5;
      *(undefined8 *)(param_1 + 0x56) = *(undefined8 *)(param_2 + 0x56);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x52,param_1 + 0x52,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26225 ; VA 0x00bc5f00 ; FUN_00bc5f00 */

undefined4 __thiscall
FUN_00bc5f00(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  uint in_stack_0000012c;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined8 in_stack_00000144;
  uint in_stack_0000014c;
  undefined4 in_stack_00000154;
  undefined4 in_stack_00000158;
  undefined4 in_stack_0000015c;
  undefined4 in_stack_00000160;
  undefined8 in_stack_00000164;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe7b6;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000014c != 0) && (ExceptionList = &pvStack_10, (in_stack_0000014c & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_0000014c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((in_stack_0000012c != 0) && ((in_stack_0000012c & 1) == 0)) {
    (**(code **)(in_stack_0000012c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 5;
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00bc68f0(param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_0000012c != 0) {
    if (((in_stack_0000012c & 1) == 0) &&
       (*(code **)(in_stack_0000012c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000012c & 0xfffffffe))();
    }
    in_stack_0000012c = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000014c != 0) && ((in_stack_0000014c & 1) == 0)) &&
     (*(code **)(in_stack_0000014c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000014c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26226 ; VA 0x00bc60d0 ; FUN_00bc60d0 */

undefined4 * __thiscall FUN_00bc60d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe7d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_00bc6e60(param_2 + 2);
  param_1[0x48] = param_2[0x48];
  param_1[0x4a] = 0;
  uVar2 = param_2[0x4a];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x4a] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x4c,param_1 + 0x4c,0);
    }
    else {
      uVar3 = param_2[0x4d];
      uVar4 = param_2[0x4e];
      uVar5 = param_2[0x4f];
      param_1[0x4c] = param_2[0x4c];
      param_1[0x4d] = uVar3;
      param_1[0x4e] = uVar4;
      param_1[0x4f] = uVar5;
      *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(param_2 + 0x50);
    }
  }
  param_1[0x52] = 0;
  uVar2 = param_2[0x52];
  uStack_8 = 2;
  if (uVar2 != 0) {
    param_1[0x52] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x55];
      uVar4 = param_2[0x56];
      uVar5 = param_2[0x57];
      param_1[0x54] = param_2[0x54];
      param_1[0x55] = uVar3;
      param_1[0x56] = uVar4;
      param_1[0x57] = uVar5;
      *(undefined8 *)(param_1 + 0x58) = *(undefined8 *)(param_2 + 0x58);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x54,param_1 + 0x54,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26227 ; VA 0x00bc6220 ; FUN_00bc6220 */

undefined4 __thiscall
FUN_00bc6220(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 in_stack_0000012c;
  uint in_stack_00000130;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined4 in_stack_00000144;
  undefined8 in_stack_00000148;
  uint in_stack_00000150;
  undefined4 in_stack_00000158;
  undefined4 in_stack_0000015c;
  undefined4 in_stack_00000160;
  undefined4 in_stack_00000164;
  undefined8 in_stack_00000168;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe826;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000150 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000150 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000150 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((in_stack_00000130 != 0) && ((in_stack_00000130 & 1) == 0)) {
    (**(code **)(in_stack_00000130 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 5;
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00bc6ac0(param_2,param_3,param_4,param_5);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000130 != 0) {
    if (((in_stack_00000130 & 1) == 0) &&
       (*(code **)(in_stack_00000130 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000130 & 0xfffffffe))();
    }
    in_stack_00000130 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000150 != 0) && ((in_stack_00000150 & 1) == 0)) &&
     (*(code **)(in_stack_00000150 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000150 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26228 ; VA 0x00bc63e0 ; FUN_00bc63e0 */

int __thiscall FUN_00bc63e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  uint in_stack_00000124;
  undefined4 in_stack_0000012c;
  undefined4 in_stack_00000130;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined8 in_stack_0000013c;
  undefined auStack_138 [280];
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe86e;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00bc6e60(&stack0x0000000c);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00bc6e60(auStack_138);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *(undefined4 *)(param_1 + 0x120) = 0;
  if (in_stack_00000124 != 0) {
    *(uint *)(param_1 + 0x120) = in_stack_00000124;
    if ((in_stack_00000124 & 1) == 0) {
      (**(code **)(in_stack_00000124 & 0xfffffffe))(&stack0x0000012c,param_1 + 0x128,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x128) = in_stack_0000012c;
      *(undefined4 *)(param_1 + 300) = in_stack_00000130;
      *(undefined4 *)(param_1 + 0x130) = in_stack_00000134;
      *(undefined4 *)(param_1 + 0x134) = in_stack_00000138;
      *(undefined8 *)(param_1 + 0x138) = in_stack_0000013c;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = 7;
  if (((in_stack_00000124 != 0) && ((in_stack_00000124 & 1) == 0)) &&
     (*(code **)(in_stack_00000124 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000124 & 0xfffffffe))(&stack0x0000012c,&stack0x0000012c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26229 ; VA 0x00bc6570 ; FUN_00bc6570 */

undefined4 __thiscall FUN_00bc6570(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe898;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26230 ; VA 0x00bc6680 ; FUN_00bc6680 */

int __thiscall
FUN_00bc6680(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  uint in_stack_0000012c;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined8 in_stack_00000144;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe8d3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00bc6570(param_2,param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x120) = 0;
  if (in_stack_0000012c != 0) {
    *(uint *)(param_1 + 0x120) = in_stack_0000012c;
    if ((in_stack_0000012c & 1) == 0) {
      (**(code **)(in_stack_0000012c & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x128) = in_stack_00000134;
      *(undefined4 *)(param_1 + 300) = in_stack_00000138;
      *(undefined4 *)(param_1 + 0x130) = in_stack_0000013c;
      *(undefined4 *)(param_1 + 0x134) = in_stack_00000140;
      *(undefined8 *)(param_1 + 0x138) = in_stack_00000144;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = 4;
  if (((in_stack_0000012c != 0) && ((in_stack_0000012c & 1) == 0)) &&
     (*(code **)(in_stack_0000012c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000012c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26231 ; VA 0x00bc67c0 ; FUN_00bc67c0 */

undefined4 * __thiscall FUN_00bc67c0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_0000012c;
  undefined auStack_134 [280];
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe90b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  piStack_14 = param_3;
  if (param_3 != (int *)0x0) {
    piVar1 = param_3 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00bc6e60(auStack_134);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00bc7880();
  param_1[0x48] = in_stack_0000012c;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00bc7880();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26232 ; VA 0x00bc68f0 ; FUN_00bc68f0 */

int __thiscall
FUN_00bc68f0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  uint in_stack_0000012c;
  undefined4 in_stack_00000134;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined8 in_stack_00000144;
  uint in_stack_0000014c;
  undefined4 in_stack_00000154;
  undefined4 in_stack_00000158;
  undefined4 in_stack_0000015c;
  undefined4 in_stack_00000160;
  undefined8 in_stack_00000164;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe956;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000012c != 0) && (ExceptionList = &pvStack_10, (in_stack_0000012c & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_0000012c & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_00bc6e60(&stack0x00000014);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  FUN_00bc6680(param_2,param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *(undefined4 *)(param_1 + 0x140) = 0;
  if (in_stack_0000014c != 0) {
    *(uint *)(param_1 + 0x140) = in_stack_0000014c;
    if ((in_stack_0000014c & 1) == 0) {
      (**(code **)(in_stack_0000014c & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x148) = in_stack_00000154;
      *(undefined4 *)(param_1 + 0x14c) = in_stack_00000158;
      *(undefined4 *)(param_1 + 0x150) = in_stack_0000015c;
      *(undefined4 *)(param_1 + 0x154) = in_stack_00000160;
      *(undefined8 *)(param_1 + 0x158) = in_stack_00000164;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_0000012c != 0) {
    if (((in_stack_0000012c & 1) == 0) &&
       (*(code **)(in_stack_0000012c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000012c & 0xfffffffe))();
    }
    in_stack_0000012c = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000014c != 0) && ((in_stack_0000014c & 1) == 0)) &&
     (*(code **)(in_stack_0000014c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000014c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26233 ; VA 0x00bc6ac0 ; FUN_00bc6ac0 */

int __thiscall
FUN_00bc6ac0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 in_stack_0000012c;
  uint in_stack_00000130;
  undefined4 in_stack_00000138;
  undefined4 in_stack_0000013c;
  undefined4 in_stack_00000140;
  undefined4 in_stack_00000144;
  undefined8 in_stack_00000148;
  uint in_stack_00000150;
  undefined4 in_stack_00000158;
  undefined4 in_stack_0000015c;
  undefined4 in_stack_00000160;
  undefined4 in_stack_00000164;
  undefined8 in_stack_00000168;
  undefined auStack_280 [268];
  undefined4 uStack_174;
  undefined4 *puStack_170;
  undefined4 *puStack_16c;
  undefined *puStack_168;
  undefined auStack_15c [280];
  undefined4 uStack_44;
  int *piStack_40;
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fe9b9;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  iStack_3c = param_1;
  if (in_stack_00000130 != 0) {
    uStack_38 = in_stack_00000130;
    if ((in_stack_00000130 & 1) == 0) {
      puStack_16c = &uStack_30;
      puStack_168 = (undefined *)0x0;
      puStack_170 = &stack0x00000138;
      uStack_174 = 0xbc6b32;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000130 & 0xfffffffe))();
    }
    else {
      uStack_30 = in_stack_00000138;
      uStack_2c = in_stack_0000013c;
      uStack_28 = in_stack_00000140;
      uStack_24 = in_stack_00000144;
      uStack_20 = in_stack_00000148;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_168 = &stack0x00000014;
  uStack_8._0_1_ = 4;
  puStack_16c = (undefined4 *)0xbc6b48;
  FUN_00bc6e60();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  uStack_44 = param_2;
  piStack_40 = param_3;
  puStack_168 = (undefined *)in_stack_0000012c;
  uStack_8._0_1_ = 7;
  puStack_18 = auStack_280;
  FUN_00bc6e60(auStack_15c);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00bc67c0(uStack_14,param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  *(undefined4 *)(param_1 + 0x128) = 0;
  if (uStack_38 != 0) {
    *(uint *)(param_1 + 0x128) = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_16c = (undefined4 *)(param_1 + 0x130);
      puStack_168 = (undefined *)0x0;
      puStack_170 = &uStack_30;
      uStack_174 = 0xbc6c00;
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x130) = uStack_30;
      *(undefined4 *)(param_1 + 0x134) = uStack_2c;
      *(undefined4 *)(param_1 + 0x138) = uStack_28;
      *(undefined4 *)(param_1 + 0x13c) = uStack_24;
      *(undefined8 *)(param_1 + 0x140) = uStack_20;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_168 = (undefined *)0xbc6c18;
      (**(code **)(*param_3 + 4))();
    }
  }
  puStack_168 = (undefined *)0xbc6c23;
  FUN_00bc7880();
  uStack_8._0_1_ = 9;
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_170 = &uStack_30;
      puStack_168 = (undefined *)0x2;
      uStack_174 = 0xbc6c48;
      puStack_16c = puStack_170;
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  *(undefined4 *)(param_1 + 0x148) = 0;
  if (in_stack_00000150 != 0) {
    *(uint *)(param_1 + 0x148) = in_stack_00000150;
    if ((in_stack_00000150 & 1) == 0) {
      puStack_16c = (undefined4 *)(param_1 + 0x150);
      puStack_168 = (undefined *)0x0;
      puStack_170 = &stack0x00000158;
      uStack_174 = 0xbc6cac;
      (**(code **)(in_stack_00000150 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x150) = in_stack_00000158;
      *(undefined4 *)(param_1 + 0x154) = in_stack_0000015c;
      *(undefined4 *)(param_1 + 0x158) = in_stack_00000160;
      *(undefined4 *)(param_1 + 0x15c) = in_stack_00000164;
      *(undefined8 *)(param_1 + 0x160) = in_stack_00000168;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_168 = (undefined *)0xbc6cc5;
      (**(code **)(*param_3 + 4))();
    }
  }
  puStack_168 = (undefined *)0xbc6ccd;
  FUN_00bc7880();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_00000130 != 0) {
    if (((in_stack_00000130 & 1) == 0) &&
       (*(code **)(in_stack_00000130 & 0xfffffffe) != (code *)0x0)) {
      puStack_170 = &stack0x00000138;
      puStack_168 = (undefined *)0x2;
      uStack_174 = 0xbc6cf4;
      puStack_16c = puStack_170;
      (**(code **)(in_stack_00000130 & 0xfffffffe))();
    }
    in_stack_00000130 = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_00000150 != 0) && ((in_stack_00000150 & 1) == 0)) &&
     (*(code **)(in_stack_00000150 & 0xfffffffe) != (code *)0x0)) {
    puStack_170 = &stack0x00000158;
    puStack_168 = (undefined *)0x2;
    uStack_174 = 0xbc6d2b;
    puStack_16c = puStack_170;
    (**(code **)(in_stack_00000150 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26234 ; VA 0x00bc6d50 ; FUN_00bc6d50 */

uint * __thiscall FUN_00bc6d50(uint *param_1,code *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fe9d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != (code *)0x0) {
    if (FUN_00ea0ea0 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = (int)param_2 * 0x118;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    uVar3 = *param_1;
    uStack_8 = 1;
    for (; param_2 != (code *)0x0; param_2 = param_2 + -1) {
      FUN_00bc6ff0();
      uVar3 = uVar3 + 0x118;
    }
    param_1[1] = uVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26235 ; VA 0x00bc6e40 ; Catch_All@00bc6e40 */

void Catch_All_00bc6e40(void)

{
  FUN_00bc8030();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26236 ; VA 0x00bc6e60 ; FUN_00bc6e60 */

int __thiscall FUN_00bc6e60(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fea3b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009e2820(param_2);
  *(undefined *)(param_1 + 0x68) = *(undefined *)(param_2 + 0x68);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x6c);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 0x84);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x9c);
  *(undefined *)(param_1 + 0xb4) = *(undefined *)(param_2 + 0xb4);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(param_2 + 0xb8);
  *(undefined4 *)(param_1 + 0xd0) = *(undefined4 *)(param_2 + 0xd0);
  *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)(param_2 + 0xd4);
  *(undefined4 *)(param_1 + 0xd8) = 0;
  uVar1 = *(uint *)(param_2 + 0xd8);
  uStack_8._0_1_ = 4;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0xd8) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xe0,param_1 + 0xe0,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0xe4);
      uVar3 = *(undefined4 *)(param_2 + 0xe8);
      uVar4 = *(undefined4 *)(param_2 + 0xec);
      *(undefined4 *)(param_1 + 0xe0) = *(undefined4 *)(param_2 + 0xe0);
      *(undefined4 *)(param_1 + 0xe4) = uVar2;
      *(undefined4 *)(param_1 + 0xe8) = uVar3;
      *(undefined4 *)(param_1 + 0xec) = uVar4;
      *(undefined8 *)(param_1 + 0xf0) = *(undefined8 *)(param_2 + 0xf0);
    }
  }
  *(undefined4 *)(param_1 + 0xf8) = 0;
  uVar1 = *(uint *)(param_2 + 0xf8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0xf8) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x104);
      uVar3 = *(undefined4 *)(param_2 + 0x108);
      uVar4 = *(undefined4 *)(param_2 + 0x10c);
      *(undefined4 *)(param_1 + 0x100) = *(undefined4 *)(param_2 + 0x100);
      *(undefined4 *)(param_1 + 0x104) = uVar2;
      *(undefined4 *)(param_1 + 0x108) = uVar3;
      *(undefined4 *)(param_1 + 0x10c) = uVar4;
      *(undefined8 *)(param_1 + 0x110) = *(undefined8 *)(param_2 + 0x110);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x100,param_1 + 0x100,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26237 ; VA 0x00bc6ff0 ; FUN_00bc6ff0 */

int __fastcall FUN_00bc6ff0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017feaa9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_014cc1b0(0,0);
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0xf;
  *(undefined *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0xf;
  *(undefined *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0xf;
  *(undefined *)(param_1 + 0xb8) = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  uStack_8 = 6;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_005542c0(&DAT_018bc9b8,0);
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined *)(param_1 + 0xb4) = 1;
  *(undefined *)(param_1 + 0x68) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined4 *)(param_1 + 0xd0) = 0;
  *(undefined *)(param_1 + 0x30) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26238 ; VA 0x00bc7120 ; FUN_00bc7120 */

undefined4 * __fastcall FUN_00bc7120(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017feb7d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::HttpRbxApiService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00bc46d0();
  param_1[3] = uVar1;
  *param_1 = RBX::HttpRbxApiService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  FUN_00bccae0(param_1 + 0x34);
  uStack_8._0_1_ = 7;
  FUN_00bcee80(param_1 + 0x36);
  uStack_8._0_1_ = 8;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0xf;
  *(undefined *)(param_1 + 0x38) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  *(undefined2 *)(param_1 + 0x3e) = 0;
  *(undefined *)((int)param_1 + 0xfa) = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  uStack_8._0_1_ = 0xc;
  param_1[0x42] = 0;
  FUN_01682800(param_1 + 0x44);
  puStack_18 = (undefined4 *)FUN_01674e20(0x10);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 1;
    puStack_18[2] = 1;
    *puStack_18 = std::
                  _Ref_count_obj<class_RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy>::
                  vftable;
    puStack_18[3] = 0;
    puStack_18[3] = RBX::HttpRbxApiService::DefaultHttpRequestExecutionPolicy::vftable;
    puVar3 = puStack_18;
  }
  param_1[0x48] = puVar3;
  param_1[0x47] = puVar3 + 3;
  uStack_8._0_1_ = 0xd;
  uVar2 = FUN_01679ce0();
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  *(bool *)(param_1 + 0x46) = (int)(uVar2 % 100) < DAT_01d67cbc;
  FUN_005542c0("HttpRbxApiService",0x11);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26239 ; VA 0x00bc73f0 ; FUN_00bc73f0 */

void __fastcall FUN_00bc73f0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 26240 ; VA 0x00bc7470 ; FUN_00bc7470 */

void __fastcall FUN_00bc7470(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::HttpRbxApiService>::vftable;
  uVar1 = FUN_00bc46d0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26241 ; VA 0x00bc74b0 ; FUN_00bc74b0 */

void FUN_00bc74b0(void)

{
  FUN_00bc8030();
  return;
}



/* FUNCTION 26242 ; VA 0x00bc74c0 ; FUN_00bc74c0 */

void __fastcall FUN_00bc74c0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x118) {
    FUN_00bc7880();
  }
  return;
}



/* FUNCTION 26243 ; VA 0x00bc74f0 ; FUN_00bc74f0 */

void FUN_00bc74f0(void)

{
  FUN_00bc7710();
  return;
}



/* FUNCTION 26244 ; VA 0x00bc7500 ; FUN_00bc7500 */

void __fastcall FUN_00bc7500(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x148);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x150,param_1 + 0x150,2);
      }
    }
    *(undefined4 *)(param_1 + 0x148) = 0;
  }
  FUN_00bc7710();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26245 ; VA 0x00bc7570 ; FUN_00bc7570 */

void __fastcall FUN_00bc7570(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x150);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x158,param_1 + 0x158,2);
      }
    }
    *(undefined4 *)(param_1 + 0x150) = 0;
  }
  FUN_00bc77e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26246 ; VA 0x00bc75e0 ; thunk_FUN_00bc7710 */

int __fastcall thunk_FUN_00bc7710(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x120);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x128,param_1 + 0x128,2);
      }
    }
    *(undefined4 *)(param_1 + 0x120) = 0;
  }
  iVar5 = FUN_00bc7880();
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 26247 ; VA 0x00bc75f0 ; FUN_00bc75f0 */

void __fastcall FUN_00bc75f0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x140);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x148,param_1 + 0x148,2);
      }
    }
    *(undefined4 *)(param_1 + 0x140) = 0;
  }
  FUN_00bc7710();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26248 ; VA 0x00bc7660 ; FUN_00bc7660 */

void __fastcall FUN_00bc7660(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x148);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x150,param_1 + 0x150,2);
      }
    }
    *(undefined4 *)(param_1 + 0x148) = 0;
  }
  FUN_00bc77e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26249 ; VA 0x00bc76d0 ; FUN_00bc76d0 */

int __fastcall FUN_00bc76d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00bc7880();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00bc7703. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}


