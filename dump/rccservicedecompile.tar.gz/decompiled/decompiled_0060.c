/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 15000 ; VA 0x008c68f0 ; FUN_008c68f0 */

int __thiscall FUN_008c68f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined4 in_stack_ffffffa4;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  undefined4 in_stack_ffffffb0;
  undefined4 uVar8;
  int *piVar9;
  undefined auStack_38 [12];
  undefined **ppuStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bed28;
  pvStack_10 = ExceptionList;
  piVar9 = &iStack_20;
  uVar8 = 0x8c691f;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00587490(piVar9);
  uStack_8 = 0;
  iVar4 = iStack_20;
  if (iStack_20 != 0) {
    if (param_4 == 0) {
      bVar7 = DAT_01d63008 == '\0';
      uVar2 = *(undefined *)(param_1 + 0x74);
      uVar8 = *(undefined4 *)(iStack_14 + 0x70);
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      if (bVar7) {
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
      }
      else {
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
      }
      FUN_00d1b340(iStack_14,auStack_38,param_3,iStack_14 + 0x50,uVar8,4,0,uVar2,1,!bVar7);
      iVar4 = FUN_005507b0();
    }
    else {
      if (DAT_01d6cae8 == '\0') {
        iVar4 = FUN_00d1af10(param_1,400);
      }
      else {
        FUN_0054ef60(param_4);
        iVar4 = FUN_00d1b0e0(param_1,400,in_stack_ffffffa4,in_stack_ffffffa8,in_stack_ffffffac,
                             in_stack_ffffffb0,uVar8,piVar9);
      }
      if (*(int *)(param_1 + 0x50) != 0) {
        uVar8 = *(undefined4 *)(param_1 + 0x70);
        uVar5 = FUN_005500e0(param_4);
        uStack_8._0_1_ = 1;
        puVar6 = (undefined4 *)FUN_008c0b50(auStack_18,uVar5);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uVar5 = *puVar6;
        uVar3 = puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        FUN_00d1bdb0(param_1 + 0x50,iStack_20,2,0,0,uVar8,uVar5,uVar3);
        FUN_00550b30();
        ppuStack_2c = std::exception::vftable;
        iVar4 = FUN_0170c289(&uStack_28);
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar9 = piStack_1c + 1;
    iVar1 = *piVar9;
    iVar4 = *piVar9;
    *piVar9 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_1c)();
      LOCK();
      piVar9 = piStack_1c + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15001 ; VA 0x008c6ac0 ; FUN_008c6ac0 */

int __thiscall
FUN_008c6ac0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017be9b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  uStack_2c = param_7;
  piStack_28 = param_8;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_34 = param_5;
  piStack_30 = param_6;
  uStack_8 = 4;
  uStack_7 = 0;
  uVar3 = *(uint *)(param_1 + 0x18);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x20,&uStack_4c,0);
    }
    else {
      uStack_4c = *(undefined4 *)(param_1 + 0x20);
      uStack_48 = *(undefined4 *)(param_1 + 0x24);
      uStack_44 = *(undefined4 *)(param_1 + 0x28);
      uStack_40 = *(undefined4 *)(param_1 + 0x2c);
      uStack_3c = *(undefined8 *)(param_1 + 0x30);
    }
  }
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar4 = FUN_008d56f0(param_1,param_2,param_3);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c6bb1;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c6bc1;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c6bd7;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_28 = (int *)0x8c6be7;
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_28 = (int *)0x8c6bfd;
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_28 = (int *)0x8c6c0c;
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15002 ; VA 0x008c6c20 ; FUN_008c6c20 */

/* WARNING: Removing unreachable block (ram,0x008c6c8d) */
/* WARNING: Removing unreachable block (ram,0x008c6c99) */
/* WARNING: Removing unreachable block (ram,0x008c6ca7) */

undefined4 __thiscall FUN_008c6c20(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bed50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15003 ; VA 0x008c6ce0 ; FUN_008c6ce0 */

void __thiscall FUN_008c6ce0(uint *param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bed70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
    ExceptionList = &pvStack_10;
    FUN_005caf00(&param_2);
    (*pcVar1)(param_1 + 2);
    uStack_8 = 2;
    if (param_3 != 0) {
      (**(code **)(param_3 + 8))(&stack0x0000000c);
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar2);
}



/* FUNCTION 15004 ; VA 0x008c6d70 ; FUN_008c6d70 */

/* WARNING: Removing unreachable block (ram,0x008c6e63) */
/* WARNING: Removing unreachable block (ram,0x008c6e6c) */
/* WARNING: Removing unreachable block (ram,0x008c6e7b) */
/* WARNING: Removing unreachable block (ram,0x008c6e3d) */
/* WARNING: Removing unreachable block (ram,0x008c6e46) */
/* WARNING: Removing unreachable block (ram,0x008c6e55) */
/* WARNING: Removing unreachable block (ram,0x008c6e89) */
/* WARNING: Removing unreachable block (ram,0x008c6e92) */
/* WARNING: Removing unreachable block (ram,0x008c6ea0) */

undefined4 __thiscall
FUN_008c6d70(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017beda0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))
                    (param_1 + 2,param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15005 ; VA 0x008c6ed0 ; FUN_008c6ed0 */

/* WARNING: Removing unreachable block (ram,0x008c6fb1) */
/* WARNING: Removing unreachable block (ram,0x008c6fba) */
/* WARNING: Removing unreachable block (ram,0x008c6fc9) */
/* WARNING: Removing unreachable block (ram,0x008c6fdf) */
/* WARNING: Removing unreachable block (ram,0x008c6fe8) */
/* WARNING: Removing unreachable block (ram,0x008c6ff6) */

undefined4 __thiscall
FUN_008c6ed0(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bedd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  (**(code **)((*param_1 & 0xfffffffe) + 4))
            (param_1 + 2,param_2,param_3,param_4,0,param_6,param_7,param_8,param_9,param_10,param_11
             ,param_12);
  uVar1 = FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15006 ; VA 0x008c7030 ; FUN_008c7030 */

/* WARNING: Removing unreachable block (ram,0x008c70ce) */
/* WARNING: Removing unreachable block (ram,0x008c70de) */
/* WARNING: Removing unreachable block (ram,0x008c70e4) */

void __thiscall FUN_008c7030(int *param_1,int param_2)

{
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bedf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 3;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15007 ; VA 0x008c7132 ; Catch@008c7132 */

undefined * Catch_008c7132(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_008c7143;
}



/* FUNCTION 15008 ; VA 0x008c715b ; FUN_008c715b */

void FUN_008c715b(void)

{
  FUN_008c7460();
  return;
}



/* FUNCTION 15009 ; VA 0x008c7170 ; FUN_008c7170 */

undefined4 __thiscall FUN_008c7170(undefined4 param_1,byte param_2)

{
  FUN_0056cee0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15010 ; VA 0x008c71a0 ; FUN_008c71a0 */

undefined4 __thiscall FUN_008c71a0(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_0056cee0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15011 ; VA 0x008c71e0 ; FUN_008c71e0 */

undefined4 __thiscall FUN_008c71e0(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15012 ; VA 0x008c7210 ; FUN_008c7210 */

undefined4 __thiscall FUN_008c7210(undefined4 param_1,byte param_2)

{
  FUN_008c3950();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 15013 ; VA 0x008c7240 ; FUN_008c7240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008c7240(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ContentProvider::AssetFetchStatus>::vftable;
  _DAT_01ee0400 = _DAT_01ee0400 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 15014 ; VA 0x008c7270 ; FUN_008c7270 */

undefined4 * __thiscall FUN_008c7270(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Associated_state<struct_`private:_enum_RBX::HttpRequestResult___thiscall_RBX::ContentProvider::loadContentFromStudio(class_RBX::ContentId&,enum_RBX::ContentProvider::RequestType,float,struct_RBX::CachedContent*,class_boost::function<void___cdecl(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>)>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,enum_RBX::HttpResultJob,bool)'::`9'::PromiseResult>
             ::vftable;
  if ((*(char *)((int)param_1 + 0x7d) != '\0') && (param_1[0x1e] == 0)) {
    FUN_016df30e(param_1 + 7);
  }
  FUN_016df150(param_1 + 0x13);
  FUN_016dedfb(param_1 + 7);
  uStack_8 = 0;
  FUN_016dfdcc(param_1 + 5);
  piVar2 = (int *)param_1[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x84);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15015 ; VA 0x008c7330 ; FUN_008c7330 */

undefined4 __thiscall FUN_008c7330(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x98);
  }
  return param_1;
}



/* FUNCTION 15016 ; VA 0x008c7360 ; FUN_008c7360 */

undefined4 __thiscall FUN_008c7360(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb8);
  }
  return param_1;
}



/* FUNCTION 15017 ; VA 0x008c7390 ; FUN_008c7390 */

undefined4 __thiscall FUN_008c7390(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  return param_1;
}



/* FUNCTION 15018 ; VA 0x008c73c0 ; FUN_008c73c0 */

undefined4 __thiscall FUN_008c73c0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 15019 ; VA 0x008c73e0 ; FUN_008c73e0 */

undefined4 __thiscall FUN_008c73e0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 15020 ; VA 0x008c7410 ; FUN_008c7410 */

undefined4 __thiscall FUN_008c7410(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 15021 ; VA 0x008c7430 ; FUN_008c7430 */

undefined4 __thiscall FUN_008c7430(undefined4 param_1,byte param_2)

{
  FUN_00577ac0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 15022 ; VA 0x008c7460 ; FUN_008c7460 */

undefined4 __thiscall FUN_008c7460(undefined4 param_1,byte param_2)

{
  FUN_008c3fb0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 15023 ; VA 0x008c7490 ; FUN_008c7490 */

undefined4 __thiscall FUN_008c7490(undefined4 param_1,byte param_2)

{
  FUN_00d88a30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 15024 ; VA 0x008c74c0 ; FUN_008c74c0 */

void FUN_008c74c0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x58);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 15025 ; VA 0x008c74f0 ; FUN_008c74f0 */

void __thiscall FUN_008c74f0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006b2190(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x1c;
  param_1[2] = param_2 + param_4 * 0x1c;
  return;
}



/* FUNCTION 15026 ; VA 0x008c7590 ; FUN_008c7590 */

void __thiscall FUN_008c7590(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008c3d70();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x40 + param_2;
  param_1[2] = param_4 * 0x40 + param_2;
  return;
}



/* FUNCTION 15027 ; VA 0x008c7610 ; FUN_008c7610 */

void __fastcall FUN_008c7610(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 15028 ; VA 0x008c7670 ; FUN_008c7670 */

int __fastcall FUN_008c7670(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_008c39c0();
  iVar4 = FUN_016dedfb(param_1 + 0x18);
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x008c769b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 15029 ; VA 0x008c76a0 ; FUN_008c76a0 */

void __fastcall FUN_008c76a0(int param_1)

{
  (*(code *)**(undefined4 **)(param_1 + 0x10 + *(int *)(*(int *)(param_1 + 0x10) + 4)))(0);
  return;
}



/* FUNCTION 15030 ; VA 0x008c76c0 ; FUN_008c76c0 */

void FUN_008c76c0(void)

{
  FUN_006b35b0();
  return;
}



/* FUNCTION 15031 ; VA 0x008c76d0 ; FUN_008c76d0 */

void FUN_008c76d0(void)

{
  FUN_00577ac0();
  return;
}



/* FUNCTION 15032 ; VA 0x008c76e0 ; FUN_008c76e0 */

void FUN_008c76e0(void)

{
  FUN_00f4c350();
  return;
}



/* FUNCTION 15033 ; VA 0x008c76f0 ; FUN_008c76f0 */

void FUN_008c76f0(void)

{
  FUN_00f47270();
  return;
}



/* FUNCTION 15034 ; VA 0x008c7700 ; FUN_008c7700 */

void __fastcall FUN_008c7700(int param_1)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 4))(0);
  return;
}



/* FUNCTION 15035 ; VA 0x008c7710 ; FUN_008c7710 */

void __thiscall FUN_008c7710(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_008bd9e0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 15036 ; VA 0x008c7730 ; FUN_008c7730 */

void __thiscall FUN_008c7730(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006b2190(param_2,param_3,param_1);
  return;
}



/* FUNCTION 15037 ; VA 0x008c7750 ; FUN_008c7750 */

void FUN_008c7750(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00651cc0();
      param_1 = param_1 + 0x60;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 15038 ; VA 0x008c7780 ; FUN_008c7780 */

void FUN_008c7780(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008c4380();
      param_1 = param_1 + 0x58;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 15039 ; VA 0x008c77b0 ; FUN_008c77b0 */

void FUN_008c77b0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008c3d70();
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 15040 ; VA 0x008c77e0 ; FUN_008c77e0 */

void __thiscall FUN_008c77e0(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_008c78a0(param_2);
  return;
}



/* FUNCTION 15041 ; VA 0x008c7810 ; FUN_008c7810 */

void __thiscall FUN_008c7810(int param_1,undefined4 *param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x7d) = 1;
  if (param_3 != '\0') {
    uVar1 = *param_2;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 0;
    FUN_016df287(param_1 + 0x4c,uVar1,param_1 + 0x78);
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x78) = 1;
  uStack_8 = 0;
  iVar2 = FUN_016df117(param_1 + 0x4c);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15042 ; VA 0x008c78a0 ; FUN_008c78a0 */

void FUN_008c78a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x58);
  return;
}



/* FUNCTION 15043 ; VA 0x008c7900 ; FUN_008c7900 */

void FUN_008c7900(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x58);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  FUN_00637950();
  FUN_01674ea0(param_1,0x78);
  return;
}



/* FUNCTION 15044 ; VA 0x008c7970 ; FUN_008c7970 */

int * __thiscall FUN_008c7970(int *param_1,char param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a998;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 7;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(piStack_18);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  cStack_14 = '\x01';
  iStack_8 = 0;
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x1d) != '\0')) {
    uVar4 = FUN_005deb10(auStack_20,2);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar4);
  }
  piVar5 = param_1 + 5;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  cVar2 = FUN_016dfded(piVar5);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (cVar2 == '\0') {
    *(undefined *)(param_1 + 0x1d) = 1;
    if (*(char *)((int)param_1 + 0x7e) == '\0') {
      *(undefined *)((int)param_1 + 0x7e) = 1;
      (**(code **)(*param_1 + 0x10))(&piStack_18);
    }
    if (param_1[0x1e] == 0) {
      do {
        iVar3 = FUN_016df1c8(param_1 + 0x13,piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      } while (param_1[0x1e] == 0);
    }
    iStack_8._0_1_ = 2;
    cVar2 = FUN_016dfded(piVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (cVar2 == '\0') {
      iStack_8 = 3;
      if (cStack_14 != '\0') {
        iVar3 = FUN_016deec8(piStack_18);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      }
      ExceptionList = pvStack_10;
      return param_1 + 2;
    }
  }
  else {
    FUN_005dbd40(piVar5);
    FUN_016dfe36();
  }
  FUN_005dbd40(piVar5);
  FUN_016dfe36();
  pcVar1 = (code *)swi(3);
  piVar5 = (int *)(*pcVar1)();
  return piVar5;
}



/* FUNCTION 15045 ; VA 0x008c7ac0 ; FUN_008c7ac0 */

void __thiscall FUN_008c7ac0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_0072e960(param_2);
  FUN_008bed40(*param_1,param_1[1],uVar3,param_1);
  FUN_008c74f0(uVar3,(iVar1 - iVar2) / 0x1c,param_2);
  return;
}



/* FUNCTION 15046 ; VA 0x008c7b20 ; FUN_008c7b20 */

void __thiscall FUN_008c7b20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a9d0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  uStack_8 = 0;
  if ((piVar1 == (int *)0x0) ||
     ((*(char *)(param_1 + 1) != '\0' && (*(char *)(piVar1 + 0x1d) != '\0')))) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005deb10(auStack_30,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar3);
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_016dfd4d(auStack_28,&param_2);
  piStack_18 = piVar1 + 7;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cStack_14 = 0;
  iVar2 = FUN_016dee6d(piStack_18);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  cStack_14 = '\x01';
  uStack_8._0_1_ = 4;
  FUN_016dfd4d(auStack_20,auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (*(char *)((int)piVar1 + 0x7d) == '\0') {
    uStack_8._0_1_ = 6;
    FUN_016dfd2b(piVar1 + 5,auStack_20);
    uStack_8._0_1_ = 5;
    (**(code **)(*piVar1 + 0x14))(&piStack_18,param_4);
    uStack_8._0_1_ = 7;
    FUN_016dfdcc(auStack_20);
    uStack_8._0_1_ = 8;
    if (cStack_14 != '\0') {
      iVar2 = FUN_016deec8(piStack_18);
      if (iVar2 != 0) {
        FUN_016df3c9(iVar2);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_016dfdcc(auStack_28);
    uStack_8 = 10;
    FUN_016dfdcc(&param_2);
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_005deb10(auStack_30,3);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar3);
}



/* FUNCTION 15047 ; VA 0x008c7c70 ; FUN_008c7c70 */

void __fastcall FUN_008c7c70(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_008bd9e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 15048 ; VA 0x008c7cf0 ; FUN_008c7cf0 */

undefined4 * FUN_008c7cf0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bf096;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar2 = param_1 + 0x15;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = 0;
      param_3[1] = 0;
      *param_3 = puVar2[-0x15];
      param_3[1] = puVar2[-0x14];
      puVar2[-0x15] = 0;
      puVar2[-0x14] = 0;
      uStack_8 = 1;
      param_3[2] = 0;
      FUN_005880d0(puVar2 + -0x13);
      param_3[10] = 0;
      param_3[0xb] = 0;
      param_3[10] = puVar2[-0xb];
      param_3[0xb] = puVar2[-10];
      puVar2[-0xb] = 0;
      puVar2[-10] = 0;
      uStack_8 = 3;
      param_3[0xc] = 0;
      FUN_005880d0(puVar2 + -9);
      param_3[0x14] = 0;
      param_3[0x15] = 0;
      puVar1 = puVar2 + 1;
      param_3[0x14] = puVar2[-1];
      param_3[0x15] = *puVar2;
      param_3 = param_3 + 0x16;
      puVar2[-1] = 0;
      *puVar2 = 0;
      puVar2 = puVar2 + 0x16;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 15049 ; VA 0x008c7e20 ; FUN_008c7e20 */

undefined4 * FUN_008c7e20(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bf0b0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar5 = param_1 + 5;
    ExceptionList = &pvStack_10;
    do {
      param_3[4] = 0;
      param_3[5] = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *param_3 = puVar5[-5];
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      *(undefined8 *)(param_3 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      param_3[6] = puVar5[1];
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(puVar5 + 3);
      param_3 = param_3 + 0x10;
      puVar1 = puVar5 + 0xb;
      puVar5 = puVar5 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 15050 ; VA 0x008c7ee0 ; FUN_008c7ee0 */

void FUN_008c7ee0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bf0b0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar6 = param_1 + 10;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_0054ef60(puVar6 + -10);
      *(undefined4 *)(param_3 + 0x18) = puVar6[-4];
      *(undefined4 *)(param_3 + 0x20) = 0;
      uVar2 = puVar6[-2];
      uStack_8 = 1;
      if (uVar2 != 0) {
        *(uint *)(param_3 + 0x20) = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar6,param_3 + 0x28,0);
        }
        else {
          uVar3 = puVar6[1];
          uVar4 = puVar6[2];
          uVar5 = puVar6[3];
          *(undefined4 *)(param_3 + 0x28) = *puVar6;
          *(undefined4 *)(param_3 + 0x2c) = uVar3;
          *(undefined4 *)(param_3 + 0x30) = uVar4;
          *(undefined4 *)(param_3 + 0x34) = uVar5;
          uVar3 = puVar6[5];
          *(undefined4 *)(param_3 + 0x38) = puVar6[4];
          *(undefined4 *)(param_3 + 0x3c) = uVar3;
        }
      }
      param_3 = param_3 + 0x40;
      puVar1 = puVar6 + 6;
      puVar6 = puVar6 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15051 ; VA 0x008c7fa0 ; FUN_008c7fa0 */

void __fastcall FUN_008c7fa0(int *param_1)

{
  int iVar1;
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  cStack_14 = 0;
  piStack_18 = param_1 + 7;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016dee6d(piStack_18);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  cStack_14 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)param_1 + 0x7e) == '\0') {
    *(undefined *)((int)param_1 + 0x7e) = 1;
    (**(code **)(*param_1 + 0x10))(&piStack_18);
  }
  if (param_1[0x1e] == 0) {
    do {
      iVar1 = FUN_016df1c8(param_1 + 0x13,piStack_18);
      if (iVar1 != 0) {
        FUN_016df3c9(iVar1);
      }
    } while (param_1[0x1e] == 0);
  }
  uStack_8 = 1;
  if ((cStack_14 != '\0') && (iVar1 = FUN_016deec8(piStack_18), iVar1 != 0)) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15052 ; VA 0x008c8070 ; FUN_008c8070 */

void __thiscall FUN_008c8070(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_30;
  undefined auStack_28 [8];
  undefined4 uStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf0c8;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  iStack_4c = param_1[0x1f];
  piStack_14 = param_1 + 0xe;
  iStack_50 = param_1[0x1e];
  iStack_48 = param_1[0x20];
  iStack_54 = param_1[0x1d];
  iStack_44 = param_1[0x21];
  iStack_58 = param_1[0x1c];
  uStack_3c = 1;
  uStack_38 = 0;
  uStack_30 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  FUN_016830f0(auStack_28);
  piVar3 = piStack_14;
  iVar2 = *(int *)piStack_14[1];
  piStack_14 = *(int **)(iVar2 + 4);
  uVar4 = FUN_008bd940(iVar2,piStack_14,param_2,&iStack_58);
  if (piVar3[2] == 0x2e8ba2d) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  piVar3[2] = piVar3[2] + 1;
  *(undefined4 *)(iVar2 + 4) = uVar4;
  *piStack_14 = uVar4;
  FUN_008be5f0(auStack_18,*(int *)piVar3[1] + 8,*(int *)piVar3[1]);
  if (((uint)piStack_1c[0x18] < (uint)piStack_1c[0x10]) && (*(char *)(piStack_1c + 0x16) == '\0')) {
    *(undefined *)(piStack_1c + 0x16) = 1;
    FUN_008c0cc0(&uStack_20,piStack_1c);
    piVar3 = piStack_1c;
    uStack_8 = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    FUN_008bcd10(uStack_20,piStack_1c,0);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    FUN_0151ddd0();
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15053 ; VA 0x008c8200 ; FUN_008c8200 */

uint FUN_008c8200(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 << 6;
  if (param_1 < 0x4000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 15054 ; VA 0x008c8270 ; FUN_008c8270 */

void FUN_008c8270(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bf101;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iStack_34 = 0;
  uStack_30 = 0xf;
  iVar3 = param_1[4];
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    puVar1 = param_1;
    if (7 < (uint)param_1[5]) {
      puVar1 = (undefined4 *)*param_1;
    }
    puVar6 = param_1;
    if (7 < (uint)param_1[5]) {
      puVar6 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    uVar2 = FUN_01686580();
    FUN_01685a20(puVar6,(int)puVar1 + iVar3 * 2,apppuStack_44,uVar2);
  }
  ppppuVar4 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar4 = (undefined4 ****)apppuStack_44[0];
  }
  if (*(char *)(iStack_34 + -1 + (int)ppppuVar4) != '/') {
    ppppuVar4 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar4 = (undefined4 ****)apppuStack_44[0];
    }
    if (*(char *)(iStack_34 + -1 + (int)ppppuVar4) != '\\') {
      iVar3 = FUN_01687bc0();
      iStack_1c = 0;
      uStack_18 = 0xf;
      apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
      FUN_005542c0(&DAT_018c36fc,1);
      iStack_8._0_1_ = 1;
      if (iStack_1c != 0) {
        ppppuVar4 = apppuStack_2c;
        if (0xf < uStack_18) {
          ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
        }
        iVar7 = iStack_1c + (int)ppppuVar4;
        ppppuVar4 = apppuStack_2c;
        if (0xf < uStack_18) {
          ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
        }
        uVar2 = FUN_01686580();
        FUN_01685950(ppppuVar4,iVar7,param_1,uVar2);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_18) {
        uVar5 = uStack_18 + 1;
        ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
        if (0xfff < uVar5) {
          ppppuVar4 = (undefined4 ****)apppuStack_2c[0][-1];
          uVar5 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar4,uVar5);
      }
      iStack_1c = 0;
      uStack_18 = 0xf;
      apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
      if (iVar3 != 0) {
        FUN_01687c10(iVar3);
      }
    }
  }
  if (0xf < uStack_30) {
    uVar5 = uStack_30 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_44[0][-1];
      uVar5 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15055 ; VA 0x008c8420 ; FUN_008c8420 */

undefined4 * FUN_008c8420(void)

{
  return &DAT_01d63188;
}



/* FUNCTION 15056 ; VA 0x008c8430 ; FUN_008c8430 */

void FUN_008c8430(undefined4 param_1)

{
  undefined auStack_20 [24];
  undefined *puStack_8;
  
  if (DAT_01d62f90 != '\0') {
    puStack_8 = auStack_20;
    FUN_0054ef60(param_1);
    FUN_008c7030();
  }
  return;
}



/* FUNCTION 15057 ; VA 0x008c8460 ; FUN_008c8460 */

bool FUN_008c8460(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  code *apcStack_48 [2];
  undefined auStack_40 [24];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf120;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  apcStack_48[0] = (code *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iVar1 = FUN_008d7910(aiStack_28,2,&DAT_bf800000,param_2,apcStack_48,param_3,&DAT_01d62f20,0,
                       param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (apcStack_48[0] != (code *)0x0) {
    if ((((uint)apcStack_48[0] & 1) == 0) &&
       (*(code **)((uint)apcStack_48[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)apcStack_48[0] & 0xfffffffe))(auStack_40,auStack_40,2);
    }
    apcStack_48[0] = (code *)0x0;
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return iVar1 == 1;
}



/* FUNCTION 15058 ; VA 0x008c8540 ; FUN_008c8540 */

int FUN_008c8540(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int aiStack_c0 [24];
  undefined **appuStack_60 [18];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf143;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008cdc80(&uStack_18,param_1,param_3,1);
  uStack_8 = 0;
  FUN_00565000(uStack_18,1,1);
  uStack_8._0_1_ = 1;
  FUN_00f26000(aiStack_c0,param_2);
  *(undefined ***)((int)aiStack_c0 + *(int *)(aiStack_c0[0] + 4)) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)((int)aiStack_c0 + *(int *)(aiStack_c0[0] + 4) + -4) = *(int *)(aiStack_c0[0] + 4) + -0x60
  ;
  FUN_0056b950();
  *(undefined ***)((int)aiStack_c0 + *(int *)(aiStack_c0[0] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_c0 + *(int *)(aiStack_c0[0] + 4) + -4) = *(int *)(aiStack_c0[0] + 4) + -0x18
  ;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  appuStack_60[0] = std::ios_base::vftable;
  iVar3 = FUN_016de551(appuStack_60);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15059 ; VA 0x008c8650 ; FUN_008c8650 */

void FUN_008c8650(uint param_1)

{
  undefined uVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined8 in_stack_00000054;
  undefined auStack_1d0 [64];
  undefined auStack_190 [64];
  undefined auStack_150 [64];
  undefined auStack_110 [64];
  undefined auStack_d0 [64];
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  uint uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined **appuStack_50 [2];
  undefined4 auStack_48 [6];
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf1d9;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_90;
  uStack_8 = 2;
  auStack_90[0] = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c != 0) {
    auStack_90[0] = in_stack_0000001c;
    if ((in_stack_0000001c & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&uStack_88,0);
    }
    else {
      uStack_88 = in_stack_00000024;
      uStack_84 = in_stack_00000028;
      uStack_80 = in_stack_0000002c;
      uStack_7c = in_stack_00000030;
      uStack_78 = in_stack_00000034;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  uStack_70 = 0;
  if (in_stack_0000003c != 0) {
    uStack_70 = in_stack_0000003c;
    if ((in_stack_0000003c & 1) == 0) {
      (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_68,0);
    }
    else {
      uStack_68 = in_stack_00000044;
      uStack_64 = in_stack_00000048;
      uStack_60 = in_stack_0000004c;
      uStack_5c = in_stack_00000050;
      uStack_58 = in_stack_00000054;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_008c12e0(auStack_90);
  uStack_8._0_1_ = 5;
  appuStack_50[0] = (undefined **)0x0;
  FUN_008c12e0(auStack_1d0);
  uStack_8._0_1_ = 6;
  FUN_008c12e0(auStack_190);
  uStack_8._0_1_ = 7;
  FUN_008c12e0(auStack_150);
  uStack_8._0_1_ = 8;
  cVar2 = FUN_00585a40(auStack_d0);
  if (cVar2 == '\0') {
    FUN_008c12e0(auStack_d0);
    uStack_8._0_1_ = 9;
    puStack_18 = (uint *)FUN_01674e20(0x40);
    uStack_8._0_1_ = 10;
    if (puStack_18 == (uint *)0x0) {
      auStack_48[0] = 0;
    }
    else {
      auStack_48[0] = FUN_008c12e0(auStack_110);
    }
    FUN_008c3510();
    FUN_008c3510();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3510();
    cStack_11 = '\0';
  }
  FUN_008c3510();
  appuStack_50[0] = &PTR_FUN_019298dc;
  if (cStack_11 == '\0') {
    appuStack_50[0] = (undefined **)0x0;
  }
  FUN_008c3510();
  FUN_008c3510();
  FUN_008c3510();
  uStack_8._0_1_ = 0xb;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 0xc;
  FUN_009cbbb0(auStack_30);
  uStack_8._0_1_ = 0xd;
  FUN_008cd330(auStack_30,0x41a00000,appuStack_50,&DAT_01d63080,&DAT_01d62f20,1,1);
  uStack_8._0_1_ = 0xb;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8._0_1_ = 0xe;
  if (appuStack_50[0] != (undefined **)0x0) {
    if ((((uint)appuStack_50[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_50[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
    }
    appuStack_50[0] = (undefined **)0x0;
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    uVar3 = param_1;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_1 - 4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar3) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15060 ; VA 0x008c89a0 ; FUN_008c89a0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * FUN_008c89a0(int param_1)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint in_stack_00000018;
  undefined auStack_118 [20];
  int iStack_104;
  undefined **appuStack_100 [15];
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_b4;
  undefined **appuStack_b0 [18];
  undefined auStack_68 [4];
  int *piStack_64;
  undefined auStack_60 [4];
  int *piStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  int aiStack_40 [2];
  int aiStack_38 [5];
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf25d;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  FUN_009cbbb0(auStack_58);
  aiStack_38[0] = 0;
  aiStack_38[1] = 0;
  aiStack_38[2] = 0;
  aiStack_38[3] = 0;
  uStack_8._0_1_ = 3;
  cVar3 = FUN_008c8460(auStack_58,aiStack_38,&DAT_01d63080,1);
  if (cVar3 == '\0') {
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to load %s",uVar5);
  }
  if (aiStack_38[0] == 0) {
    piStack_18 = (int *)0x21;
    puStack_14 = (undefined4 *)FUN_0151a8d0(auStack_118,aiStack_38[2]);
    uStack_8._0_1_ = 4;
    if (7 < (uint)puStack_14[5]) {
      puStack_14 = (undefined4 *)*puStack_14;
    }
    puVar4 = (undefined4 *)FUN_008c07f0(auStack_68,&puStack_14,&piStack_18);
    piStack_20 = (int *)*puVar4;
    piVar9 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_1c = piVar9;
    piStack_18 = piStack_20;
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_64[1] + -1;
      piStack_64[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar6 = piStack_64[2] + -1;
        piStack_64[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    FUN_00550800();
  }
  else {
    puVar4 = (undefined4 *)FUN_008c0870(auStack_60,aiStack_38[0]);
    piStack_20 = (int *)*puVar4;
    piVar9 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_1c = piVar9;
    piStack_18 = piStack_20;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_5c[1] + -1;
      piStack_5c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_5c)();
        LOCK();
        iVar6 = piStack_5c[2] + -1;
        piStack_5c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_5c + 4))();
        }
      }
    }
  }
  FUN_0056b650();
  uStack_8._0_1_ = 6;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_44) {
    uVar7 = uStack_44 + 1;
    uVar8 = auStack_58[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_58[0] - 4);
      uVar7 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  appuStack_100[0] = &PTR_018be314;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puStack_14 = (undefined4 *)0x3;
  appuStack_b0[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_b4 = 0x48;
  FUN_00554f20(appuStack_100 + 1,0);
  uStack_8 = 9;
  *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_100[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_c4 = 0;
  uStack_c0 = 4;
  uStack_8._0_1_ = 10;
  FUN_0056f130(*(undefined4 *)(*(int *)(*piStack_18 + 4) + 0x38 + (int)piStack_18));
  uVar5 = FUN_0058c400(aiStack_40);
  uStack_8._0_1_ = 0xb;
  FUN_0114fa10(aiStack_38 + 4,uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (0xf < (uint)aiStack_38[3]) {
    uVar8 = aiStack_38[3] + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar8) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar8 = aiStack_38[3] + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  puStack_14 = *(undefined4 **)(*(int *)(aiStack_38[4] + 100) + 4);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_24[1] + -1;
    piStack_24[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar6 = piStack_24[2] + -1;
      piStack_24[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_104 + (int)appuStack_100[0][1]) = appuStack_100[0][1] + -8;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  appuStack_b0[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_b0);
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar6 = piVar9[1] + -1;
    piVar9[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    iVar6 = param_1;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(param_1 + -4);
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 15061 ; VA 0x008c8d90 ; FUN_008c8d90 */

void FUN_008c8d90(undefined4 param_1,code *param_2,undefined4 param_3,uint param_4,uint *param_5,
                 uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf288;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee019f);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x8c8e07;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_008bd490();
  uStack_8._0_1_ = 2;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x8c8eec;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a8 = param_4;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_a8 = 0x8c8f13;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15062 ; VA 0x008c8f30 ; FUN_008c8f30 */

void FUN_008c8f30(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 param_5,uint *param_6,uint *param_7)

{
  int *piVar1;
  uint uVar2;
  uint uStack_248;
  uint uStack_244;
  uint uStack_240;
  uint uStack_23c;
  undefined8 uStack_238;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_164;
  undefined auStack_160 [200];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  uint *puStack_58;
  uint *puStack_54;
  undefined4 uStack_50;
  uint auStack_4c [2];
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf2b8;
  pvStack_10 = ExceptionList;
  param_1 = auStack_4c;
  auStack_4c[0] = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_4c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_54 = &uStack_44;
      uStack_50 = 0;
      puStack_58 = param_7 + 2;
      uStack_5c = 0x8c8f9f;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_44 = param_7[2];
      uStack_40 = param_7[3];
      uStack_3c = param_7[4];
      uStack_38 = param_7[5];
      uStack_34 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_70 = 0;
  param_1 = (uint *)auStack_160;
  uStack_238 = CONCAT44(0x8c8fd0,(undefined4)uStack_238);
  uStack_230 = FUN_00888530();
  uStack_22c = 0;
  uStack_8._0_1_ = 1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_248,0);
    }
    else {
      uStack_248 = param_6[2];
      uStack_244 = param_6[3];
      uStack_240 = param_6[4];
      uStack_23c = param_6[5];
      uStack_238 = *(undefined8 *)(param_6 + 6);
    }
  }
  uStack_8._0_1_ = 0;
  FUN_008bf820(param_1);
  uStack_164 = 0x8c903d;
  FUN_008bd310();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_90 = param_5;
  uStack_94 = 0x8c904e;
  FUN_00d88580();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_94 = *param_4;
  uStack_90 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_98 = 0x8c9084;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15063 ; VA 0x008c90a0 ; FUN_008c90a0 */

void __fastcall FUN_008c90a0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[0x1b];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[0x16];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[0x1a] = 0;
      piVar6[0x1b] = 0xf;
      *(undefined *)(piVar6 + 0x16) = 0;
      FUN_00637950();
      FUN_01674ea0(piVar6,0x78);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 15064 ; VA 0x008c9130 ; FUN_008c9130 */

void __fastcall FUN_008c9130(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  iVar1 = *(int *)(param_1 + 100);
  piVar5 = (int *)(iVar1 + 0x80);
  piVar2 = (int *)*piVar5;
  piVar7 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*piVar5 + 4) = *piVar5;
  *(undefined4 *)(iVar1 + 0x84) = 0;
  if (piVar7 != (int *)*piVar5) {
    do {
      uVar3 = piVar7[0x1b];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar3) {
        iVar1 = piVar7[0x16];
        uVar6 = uVar3 + 1;
        iVar4 = iVar1;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar1 + -4);
          uVar6 = uVar3 + 0x24;
          if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[0x1a] = 0;
      piVar7[0x1b] = 0xf;
      *(undefined *)(piVar7 + 0x16) = 0;
      FUN_00637950();
      FUN_01674ea0(piVar7,0x78);
      piVar7 = piVar2;
    } while (piVar2 != (int *)*piVar5);
  }
  return;
}



/* FUNCTION 15065 ; VA 0x008c91d0 ; FUN_008c91d0 */

undefined4 * __thiscall
FUN_008c91d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf301;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_008ca550;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15066 ; VA 0x008c9370 ; FUN_008c9370 */

void FUN_008c9370(undefined4 param_1)

{
  FUN_00d88580(param_1);
  return;
}



/* FUNCTION 15067 ; VA 0x008c9380 ; FUN_008c9380 */

void FUN_008c9380(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_008da460();
    *param_2 = uVar3;
    iVar4 = FUN_008da510();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 15068 ; VA 0x008c93e0 ; FUN_008c93e0 */

void FUN_008c93e0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008da460();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15069 ; VA 0x008c9420 ; FUN_008c9420 */

void __thiscall FUN_008c9420(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088d190();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_00630cf0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15070 ; VA 0x008c9650 ; FUN_008c9650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008c9650(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  undefined *puStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar6 = &uStack_28c;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_008882f0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38)
       && (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
    puStack_e8 = &DAT_01ea8c2c;
    puVar6 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_008882f0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(iStack_1c + 0x44);
  if (iVar2 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_00d88470();
    puStack_1b8 = (undefined *)0x0;
    FUN_00d88580(iVar2);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c)
       && (FUN_016f3809(&DAT_01ee047c), DAT_01ee047c == -1)) {
      _DAT_01ee0470 = FUN_008c9370;
      _DAT_01ee0474 = FUN_008c9370;
      DAT_01ee0478 = FUN_008ca540;
      FUN_016f37bf(&DAT_01ee047c);
    }
    puStack_1b8 = &DAT_01ee0470;
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_00d88470();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_1b8 != (undefined *)0x0)) {
    (**(code **)(puStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15071 ; VA 0x008c9970 ; FUN_008c9970 */

/* WARNING: Type propagation algorithm not settling */

int FUN_008c9970(uint param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000024;
  int in_stack_00000028;
  int *in_stack_0000002c;
  int in_stack_00000030;
  int *in_stack_00000034;
  int in_stack_00000038;
  int *in_stack_0000003c;
  int *piVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  undefined auStack_dc [20];
  int iStack_c8;
  undefined **appuStack_c4 [14];
  int aiStack_8c [5];
  undefined4 uStack_78;
  undefined **appuStack_74 [18];
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf37a;
  pvStack_10 = ExceptionList;
  appuStack_c4[0] = &PTR_018be314;
  uStack_8 = 4;
  uStack_14 = 1;
  appuStack_74[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_78 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_c4 + 1,0);
  uStack_8 = 6;
  *(undefined ***)(appuStack_c4[0][1] + (int)appuStack_c4) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_c8 + (int)appuStack_c4[0][1]) = appuStack_c4[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_c4[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  aiStack_8c[1] = 0;
  aiStack_8c[2] = 4;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if ((in_stack_00000028 == 0) || (in_stack_00000038 != 0)) {
    if (in_stack_0000003c != (int *)0x0) {
      LOCK();
      in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
      UNLOCK();
    }
    if (in_stack_00000034 != (int *)0x0) {
      LOCK();
      in_stack_00000034[1] = in_stack_00000034[1] + 1;
      UNLOCK();
    }
    iVar1 = in_stack_00000028;
    piVar6 = in_stack_0000002c;
    iVar7 = in_stack_00000030;
    piVar8 = in_stack_00000034;
    iVar9 = in_stack_00000038;
    piVar10 = in_stack_0000003c;
    if (in_stack_0000002c != (int *)0x0) {
      LOCK();
      in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
      UNLOCK();
    }
LAB_008c9c97:
    FUN_008c6d70(in_stack_00000024,iVar1,piVar6,iVar7,piVar8,iVar9,piVar10);
  }
  else {
    iVar1 = FUN_008c9de0(appuStack_c4,in_stack_00000028,&param_1,in_stack_0000001c);
    if (DAT_01d62fc8 != '\0') {
      if (iVar1 == 1) {
        piVar10 = (int *)0x0;
        iVar9 = 0;
        FUN_005956d0(0,0,0);
        piVar8 = &stack0x00000038;
        iVar7 = 0x8c9a84;
        FUN_00557fc0(piVar8);
        piVar6 = &stack0x00000030;
        iVar1 = 0x8c9a92;
        FUN_00557fc0(piVar6);
        FUN_00557fc0(&stack0x00000028);
        goto LAB_008c9c97;
      }
      if (iVar1 == -1) {
        uVar2 = 4;
        if (*(int *)((int)aiStack_8c + (int)appuStack_c4[0][1]) != 0) {
          uVar2 = 0;
        }
        FUN_00554460(uVar2,0);
      }
    }
    uVar2 = FUN_0058c400(auStack_dc);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    puVar3 = (undefined4 *)FUN_008c0970(auStack_2c,uVar2);
    uStack_24 = *puVar3;
    piVar8 = (int *)puVar3[1];
    *puVar3 = 0;
    puVar3[1] = 0;
    piStack_20 = piVar8;
    uStack_14 = uStack_24;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_28[1] + -1;
      piStack_28[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar1 = piStack_28[2] + -1;
        piStack_28[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 10;
    FUN_005507b0();
    uVar2 = uStack_14;
    FUN_008c0870(&uStack_1c,uStack_14);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (in_stack_0000003c != (int *)0x0) {
      LOCK();
      in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
      UNLOCK();
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    FUN_008c6d70(in_stack_00000024,uStack_1c,piStack_18,uVar2,piVar8,in_stack_00000038,
                 in_stack_0000003c);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_18[1] + -1;
      piStack_18[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar1 = piStack_18[2] + -1;
        piStack_18[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar1 = piVar8[1] + -1;
      piVar8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar1 = piVar8[2] + -1;
        piVar8[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  *(undefined ***)(appuStack_c4[0][1] + (int)appuStack_c4) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_c8 + (int)appuStack_c4[0][1]) = appuStack_c4[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_c4[0][1] + (int)appuStack_c4) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_c8 + (int)appuStack_c4[0][1]) = appuStack_c4[0][1] + -8;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  appuStack_74[0] = std::ios_base::vftable;
  iVar1 = FUN_016de551(appuStack_74);
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar1 = FUN_01674ea0(uVar4,uVar5);
  }
  piVar8 = in_stack_0000002c;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    piVar6 = in_stack_0000002c + 1;
    iVar7 = *piVar6;
    iVar1 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar7 = *piVar6;
      iVar1 = *piVar6;
      *piVar6 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        iVar1 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    piVar6 = in_stack_00000034 + 1;
    iVar7 = *piVar6;
    iVar1 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar7 = *piVar6;
      iVar1 = *piVar6;
      *piVar6 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        iVar1 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    piVar6 = in_stack_0000003c + 1;
    iVar7 = *piVar6;
    iVar1 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar1 = (**(code **)*in_stack_0000003c)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar1 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 15072 ; VA 0x008c9de0 ; FUN_008c9de0 */

undefined4 FUN_008c9de0(undefined4 param_1,undefined4 param_2,int param_3,char param_4)

{
  char cVar1;
  int iVar2;
  
  if ((DAT_01d62fc0 != '\0') && (cVar1 = FUN_008da580(param_2), cVar1 != '\0')) {
    if (*(int *)(param_3 + 0x10) == 0) {
      if (DAT_01d62fd0 != '\0') {
        return 0xffffffff;
      }
    }
    else {
      iVar2 = FUN_008ca2e0(param_1,param_2,param_3);
      if (iVar2 == 0) {
        return 0;
      }
      if (param_4 == '\0') {
        return 0xffffffff;
      }
      if (DAT_01d62fd0 != '\0') {
        return 0xffffffff;
      }
      FUN_005956d0(0,0,0);
    }
  }
  if ((*(int *)(param_3 + 0x10) == 0) || (param_4 != '\0')) {
    return 1;
  }
  iVar2 = FUN_008c9e80(param_1,param_2,param_3);
  if ((DAT_01d62fc8 != '\0') && (iVar2 != 0)) {
    return 0xffffffff;
  }
  return 0;
}



/* FUNCTION 15073 ; VA 0x008c9e80 ; FUN_008c9e80 */

undefined4 FUN_008c9e80(undefined4 param_1,int *param_2,int *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  uint uVar10;
  bool bVar11;
  undefined8 uVar12;
  char *pcVar13;
  undefined auStack_428 [288];
  undefined auStack_308 [276];
  undefined auStack_1f4 [256];
  undefined auStack_f4 [52];
  undefined auStack_c0 [32];
  int aiStack_a0 [8];
  undefined auStack_80 [24];
  undefined auStack_68 [16];
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined auStack_40 [12];
  undefined4 uStack_34;
  undefined8 uStack_28;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf3a0;
  pvStack_10 = ExceptionList;
  if (DAT_01d62fa8 == '\0') {
    if (DAT_01d62fb0 == '\0') {
      return 0xffffffff;
    }
    iStack_18 = 0;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008d5660(auStack_c0,&iStack_18,0x20,param_3);
    if (iVar3 != 0) {
LAB_008c9edb:
      if (DAT_01d84e8e == '\0') {
        ExceptionList = pvStack_10;
        return 0xffffffff;
      }
      pcVar13 = "Bad key";
      goto LAB_008ca2bf;
    }
    iVar3 = FUN_00cf79c0(auStack_428,1,iStack_18,auStack_c0);
    if (iVar3 != 1) {
      if (DAT_01d84e8e == '\0') {
        ExceptionList = pvStack_10;
        return 0xffffffff;
      }
      pcVar13 = "Failed to initialize key";
      goto LAB_008ca2bf;
    }
    FUN_005956d0(0,0,2);
    puVar4 = (uint *)FUN_005957d0(auStack_40);
    uVar8 = puVar4[2] + *puVar4;
    iVar3 = puVar4[3] + puVar4[1] + (uint)CARRY4(puVar4[2],*puVar4);
    FUN_005956d0(0,0,0);
    if ((iVar3 < 1) && ((iVar3 < 0 || (uVar8 < 0x18)))) {
      if (DAT_01d84e8e == '\0') {
        ExceptionList = pvStack_10;
        return 0xffffffff;
      }
      pcVar13 = "Missing file header";
      goto LAB_008ca2bf;
    }
    uVar12 = FUN_016f3900(uVar8 - 9,iVar3 - (uint)(uVar8 < 9),0x10,0);
    uStack_1c = (int)((ulonglong)uVar12 >> 0x20) << 4 | (uint)uVar12 >> 0x1c;
    uVar10 = (uint)uVar12 * 0x10;
    uStack_28 = 0;
    FUN_005af630(&uStack_28,8,0);
    if ((*(byte *)(*(int *)(*param_2 + 4) + 0xc + (int)param_2) & 6) == 0) {
      iStack_18 = uStack_1c + (0xffffffe7 < uVar10);
      if ((((uVar8 == uVar10 + 0x18) && (iVar3 == iStack_18)) && (uStack_28._4_4_ <= (int)uStack_1c)
          ) && ((uStack_28._4_4_ < (int)uStack_1c || ((uint)uStack_28 <= uVar10)))) {
        iVar3 = uStack_1c - (uVar10 < 0x10);
        if ((iVar3 <= uStack_28._4_4_) &&
           ((iVar3 < uStack_28._4_4_ || (uVar10 - 0x10 < (uint)uStack_28)))) {
          FUN_005af630(auStack_68,0x10,0);
          FUN_007158e0(uVar10,&cStack_11);
          uStack_8 = 0;
          FUN_007158e0(uVar10,&cStack_11);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_005af630(uStack_34,uVar10,uStack_1c);
          iVar3 = FUN_00cf7950(auStack_80,2,auStack_68);
          if (iVar3 == 1) {
            FUN_00cf72a0(auStack_80,auStack_428,uStack_34,uVar10,uStack_4c);
            FUN_005af750(uStack_4c,(uint)uStack_28,uStack_28._4_4_);
            uVar9 = 0;
          }
          else {
            if (DAT_01d84e8e != '\0') {
              FUN_016774b0(DAT_01d84e8e,"Failed to initialize cipher",0);
            }
            uVar9 = 0xffffffff;
          }
          FUN_0056d2d0();
          FUN_0056d2d0();
          ExceptionList = pvStack_10;
          return uVar9;
        }
      }
      if (DAT_01d84e8e == '\0') {
        ExceptionList = pvStack_10;
        return 0xffffffff;
      }
      pcVar13 = "Corrupt file";
      goto LAB_008ca2bf;
    }
  }
  else {
    uStack_1c = 0;
    ExceptionList = &pvStack_10;
    if (DAT_01d62fb8 == '\0') {
LAB_008c9efd:
      if (param_3[4] != 0x20) goto LAB_008c9edb;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_008d5660(aiStack_a0,&uStack_1c,0x20,param_3);
      if (iVar3 != 0) goto LAB_008c9edb;
      if (DAT_01d62fb8 == '\0') goto LAB_008c9efd;
    }
    if ((*(byte *)(*(int *)(*param_2 + 4) + 0xc + (int)param_2) & 6) == 0) {
      FUN_005956d0(0,0,2);
      puVar4 = (uint *)FUN_005957d0(auStack_58);
      uVar8 = puVar4[2];
      uVar10 = *puVar4;
      uVar6 = uVar8 + *puVar4;
      uVar1 = puVar4[3];
      uVar2 = puVar4[1];
      FUN_005956d0(0,0,0);
      FUN_005af630(auStack_40,0x18,0);
      uVar7 = uVar6 - 0x18;
      iVar3 = uVar1 + uVar2 + (uint)CARRY4(uVar8,uVar10) + -1 + (uint)(0x17 < uVar6);
      if (DAT_01d62fb8 == '\0') {
        if (0xf < (uint)param_3[5]) {
          param_3 = (int *)*param_3;
        }
      }
      else {
        param_3 = aiStack_a0;
      }
      FUN_0154e040(auStack_f4,auStack_40,param_3);
      cStack_11 = '\0';
      while (-1 < iVar3) {
        if (iVar3 < 1) {
          if (uVar7 == 0) break;
          uVar8 = uVar7;
          iStack_18 = iVar3;
          if ((-1 < iVar3) && ((0 < iVar3 || (0x111 < uVar7)))) goto LAB_008c9fc3;
        }
        else {
LAB_008c9fc3:
          iStack_18 = 0;
          uVar8 = 0x111;
        }
        FUN_005af630(auStack_308,uVar8,iStack_18);
        iVar5 = FUN_0154e080(auStack_f4,auStack_1f4,&uStack_20,&cStack_11,auStack_308,uVar8,
                             iStack_18,0,0,0);
        if (iVar5 != 0) {
          if (DAT_01d84e8e == '\0') {
            ExceptionList = pvStack_10;
            return 0xffffffff;
          }
          pcVar13 = "Error Decoding stream";
          goto LAB_008ca2bf;
        }
        FUN_005af750(auStack_1f4,uStack_20,uStack_1c);
        bVar11 = uVar7 < uVar8;
        uVar7 = uVar7 - uVar8;
        iVar3 = (iVar3 - iStack_18) - (uint)bVar11;
        if (cStack_11 == '\x03') {
          ExceptionList = pvStack_10;
          return 0;
        }
      }
      if (DAT_01d84e8e == '\0') {
        ExceptionList = pvStack_10;
        return 0xffffffff;
      }
      pcVar13 = "Error reading stream";
      goto LAB_008ca2bf;
    }
  }
  if (DAT_01d84e8e == '\0') {
    ExceptionList = pvStack_10;
    return 0xffffffff;
  }
  pcVar13 = "Failed to read file";
LAB_008ca2bf:
  FUN_016774b0(DAT_01d84e8e,pcVar13,0);
  ExceptionList = pvStack_10;
  return 0xffffffff;
}



/* FUNCTION 15074 ; VA 0x008ca2e0 ; FUN_008ca2e0 */

undefined4 FUN_008ca2e0(undefined4 param_1,int *param_2,int *param_3)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  char *pcVar7;
  undefined auStack_2ac [276];
  undefined auStack_198 [256];
  undefined auStack_98 [52];
  undefined auStack_64 [24];
  int aiStack_4c [8];
  undefined auStack_2c [24];
  undefined4 uStack_14;
  undefined4 uStack_10;
  int iStack_c;
  char cStack_5;
  
  if (DAT_01d62fc0 != '\0') {
    iStack_c = 0;
    iVar1 = FUN_008d5660(aiStack_4c,&iStack_c,0x20,param_3);
    if (iVar1 == 0) {
      if ((*(byte *)(*(int *)(*param_2 + 4) + 0xc + (int)param_2) & 6) == 0) {
        FUN_005956d0(0,0,2);
        puVar2 = (uint *)FUN_005957d0(auStack_64);
        uVar4 = puVar2[2] + *puVar2;
        iVar1 = (puVar2[3] + puVar2[1] + (uint)CARRY4(puVar2[2],*puVar2)) - (uint)(uVar4 < 8);
        if ((iVar1 < 1) && ((iVar1 < 0 || (uVar4 == 8)))) {
          if (DAT_01d84e8e == '\0') {
            return 0xffffffff;
          }
          pcVar7 = "Stream does not contain magic number";
        }
        else {
          FUN_005956d0(8,0,0);
          FUN_005af630(auStack_2c,0x18,0);
          uVar5 = uVar4 - 0x20;
          iVar1 = iVar1 + -1 + (uint)(0x17 < uVar4 - 8);
          if (DAT_01d62fb8 == '\0') {
            if (0xf < (uint)param_3[5]) {
              param_3 = (int *)*param_3;
            }
          }
          else {
            param_3 = aiStack_4c;
          }
          FUN_0154e040(auStack_98,auStack_2c,param_3);
          cStack_5 = '\0';
          while (-1 < iVar1) {
            if (iVar1 < 1) {
              if (uVar5 == 0) break;
              uVar4 = uVar5;
              iStack_c = iVar1;
              if ((-1 < iVar1) && ((0 < iVar1 || (0x111 < uVar5)))) goto LAB_008ca420;
            }
            else {
LAB_008ca420:
              iStack_c = 0;
              uVar4 = 0x111;
            }
            FUN_005af630(auStack_2ac,uVar4,iStack_c);
            iVar3 = FUN_0154e080(auStack_98,auStack_198,&uStack_14,&cStack_5,auStack_2ac,uVar4,
                                 iStack_c,0,0,0);
            if (iVar3 != 0) {
              if (DAT_01d84e8e == '\0') {
                return 0xffffffff;
              }
              pcVar7 = "Error Decoding stream";
              goto LAB_008ca4c6;
            }
            FUN_005af750(auStack_198,uStack_14,uStack_10);
            bVar6 = uVar5 < uVar4;
            uVar5 = uVar5 - uVar4;
            iVar1 = (iVar1 - iStack_c) - (uint)bVar6;
            if (cStack_5 == '\x03') {
              return 0;
            }
          }
          if (DAT_01d84e8e == '\0') {
            return 0xffffffff;
          }
          pcVar7 = "Error reading stream";
        }
      }
      else {
        if (DAT_01d84e8e == '\0') {
          return 0xffffffff;
        }
        pcVar7 = "Failed to read file";
      }
    }
    else {
      if (DAT_01d84e8e == '\0') {
        return 0xffffffff;
      }
      pcVar7 = "Bad key";
    }
LAB_008ca4c6:
    FUN_016774b0(DAT_01d84e8e,pcVar7,0);
  }
  return 0xffffffff;
}



/* FUNCTION 15075 ; VA 0x008ca4e0 ; FUN_008ca4e0 */

int __thiscall FUN_008ca4e0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00560a10(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x38);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 15076 ; VA 0x008ca540 ; FUN_008ca540 */

void FUN_008ca540(int *param_1)

{
  (**(code **)(*param_1 + 4))(0);
  return;
}



/* FUNCTION 15077 ; VA 0x008ca550 ; FUN_008ca550 */

void FUN_008ca550(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf3e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088d190();
  uStack_ec = 0;
  FUN_0054ef60(&param_2);
  uStack_ec = FUN_00630cf0();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  uStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15078 ; VA 0x008ca690 ; FUN_008ca690 */

void FUN_008ca690(undefined4 param_1,int param_2)

{
  uint in_stack_0000001c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(aiStack_28);
  FUN_008d49a0();
  if (0xf < uStack_14) {
    if (0xfff < uStack_14 + 1) {
      if (0x1f < (aiStack_28[0] - *(int *)(aiStack_28[0] + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15079 ; VA 0x008ca760 ; FUN_008ca760 */

void __thiscall FUN_008ca760(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  *(undefined *)(param_1 + 300) = 1;
  if ((undefined4 *)(param_1 + 0x130) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  *(undefined4 *)(param_1 + 0x148) = param_3;
  return;
}



/* FUNCTION 15080 ; VA 0x008ca7a0 ; FUN_008ca7a0 */

void __fastcall FUN_008ca7a0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar1 = puVar3 + 4;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  puVar2 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0055c360(puVar4,*puVar2,puVar3,*puVar1);
  return;
}



/* FUNCTION 15081 ; VA 0x008ca7f0 ; FUN_008ca7f0 */

void __thiscall FUN_008ca7f0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = FUN_009cc8a0(param_3 + 2);
  uVar3 = *(uint *)(param_1 + 0x18) & uVar3;
  piVar1 = (int *)(*(int *)(param_1 + 0xc) + uVar3 * 8);
  if ((int *)piVar1[1] == param_3) {
    if ((int *)*piVar1 == param_3) {
      *piVar1 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + uVar3 * 8) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar1[1] = param_3[1];
    }
  }
  else if ((int *)*piVar1 == param_3) {
    *piVar1 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_008c78a0(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 15082 ; VA 0x008ca870 ; FUN_008ca870 */

void __thiscall FUN_008ca870(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint in_stack_0000002c;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf41b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8._0_1_ = 2;
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_110);
    if (cVar2 != '\0') {
      uVar4 = FUN_008898b0();
      FUN_0054ef60(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      FUN_005507b0();
      goto LAB_008ca96a;
    }
    uStack_8._0_1_ = 5;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(param_1 + 0x40));
LAB_008ca96a:
  uStack_8._0_1_ = 6;
  FUN_008c8d90(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),aiStack_40,
               &param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15083 ; VA 0x008caa50 ; FUN_008caa50 */

void __thiscall FUN_008caa50(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint in_stack_0000002c;
  undefined4 uStack_208;
  int iStack_204;
  undefined auStack_200 [200];
  undefined4 uStack_138;
  int iStack_134;
  undefined auStack_130 [200];
  undefined auStack_68 [32];
  undefined **ppuStack_48;
  undefined4 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf476;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_3)();
  if (uVar3 < 2) {
LAB_008cab47:
    if (*(int *)(param_1 + 0x44) == 0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    FUN_00d88580(*(int *)(param_1 + 0x44));
  }
  else {
    uStack_44 = 0;
    LOCK();
    DAT_01e90cd8 = DAT_01e90cd8 + 1;
    UNLOCK();
    ppuStack_48 = RBX::Lua::WeakFunctionRef::vftable;
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_8._0_1_ = 2;
    uStack_138 = FUN_00888530();
    iStack_134 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(2,&uStack_138);
    if (cVar2 == '\0') {
      uStack_8._0_1_ = 5;
      if (iStack_134 != 0) {
        (**(code **)(iStack_134 + 8))(auStack_130);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00d88a30();
      goto LAB_008cab47;
    }
    uVar4 = FUN_00d88220();
    FUN_00d88580(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (iStack_134 != 0) {
      (**(code **)(iStack_134 + 8))(auStack_130);
    }
    FUN_00d88a30();
  }
  uStack_8._0_1_ = 6;
  iVar5 = (**(code **)*param_3)();
  if (iVar5 != 0) {
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 7;
    uStack_208 = FUN_00888530();
    iStack_204 = 0;
    uStack_8._0_1_ = 8;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_208);
    if (cVar2 != '\0') {
      puVar6 = (undefined4 *)FUN_00887e80();
      piVar7 = (int *)puVar6[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)puVar6[1];
      }
      uStack_18 = *puVar6;
      uStack_8._0_1_ = 9;
      piStack_14 = piVar7;
      if (iStack_204 != 0) {
        (**(code **)(iStack_204 + 8))(auStack_200);
      }
      FUN_00550b30();
      goto LAB_008cac43;
    }
    uStack_8._0_1_ = 10;
    if (iStack_204 != 0) {
      (**(code **)(iStack_204 + 8))(auStack_200);
    }
    uStack_8._0_1_ = 6;
    FUN_00550b30();
  }
  puVar6 = *(undefined4 **)(param_1 + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_28,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  piVar7 = (int *)puVar6[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = (int *)puVar6[1];
  }
  uStack_18 = *puVar6;
  piStack_14 = piVar7;
LAB_008cac43:
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_008c8f30(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               auStack_68,&param_4,&stack0x0000002c);
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = piVar7[1] + -1;
    piVar7[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  FUN_00d88a30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15084 ; VA 0x008cad40 ; FUN_008cad40 */

undefined4 __thiscall FUN_008cad40(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5650(param_3,uVar3);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15085 ; VA 0x008cae00 ; FUN_008cae00 */

undefined4 __thiscall FUN_008cae00(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_2c,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 15086 ; VA 0x008caeb0 ; FUN_008caeb0 */

undefined4 __fastcall FUN_008caeb0(int param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01256300();
  uVar2 = FUN_008cc740(aiStack_2c);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar2);
  (*pcVar1)();
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 15087 ; VA 0x008caf70 ; FUN_008caf70 */

undefined4 FUN_008caf70(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uStack_98;
  int iStack_94;
  undefined4 uStack_90;
  int iStack_8c;
  int iStack_88;
  int *piStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bf4b8;
  pvStack_1c = ExceptionList;
  uStack_6c = param_2;
  iStack_70 = 0x8cafac;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  piStack_84 = aiStack_60;
  iStack_70 = (int)pcStack_28 + 0x44;
  uStack_78 = 2;
  iStack_7c = param_3;
  uStack_80 = param_2;
  iStack_88 = 0x8cafca;
  iStack_74 = iVar1 - param_3;
  puStack_2c = (undefined *)FUN_009d09d0();
  iStack_88 = (int)pcStack_28 + 0x40;
  uStack_14 = 0;
  uStack_90 = 1;
  iStack_94 = param_3;
  uStack_98 = param_2;
  iStack_8c = iVar1 - param_3;
  uVar2 = FUN_008cc740(auStack_48);
  puStack_30 = (undefined *)&uStack_80;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  piStack_84 = (int *)puStack_2c;
  iStack_88 = 0x8cb010;
  FUN_0054ef60();
  puStack_2c = (undefined *)&uStack_98;
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*pcStack_28)();
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (0xf < uStack_4c) {
    uVar4 = uStack_4c + 1;
    iVar1 = aiStack_60[0];
    if (0xfff < uVar4) {
      iVar1 = *(int *)(aiStack_60[0] + -4);
      uVar4 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar4);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 15088 ; VA 0x008cb0c0 ; FUN_008cb0c0 */

/* WARNING: Type propagation algorithm not settling */

void FUN_008cb0c0(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_174 [164];
  int iStack_d0;
  undefined **appuStack_cc [15];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_80;
  undefined **ppuStack_7c;
  undefined auStack_34 [4];
  int *piStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf522;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (*param_2 == 0) {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_01675290(DAT_01f6dd5c);
    uStack_8 = 0;
    puVar3 = (undefined4 *)FUN_0151a8d0(auStack_2c,param_2[2]);
    uStack_8._0_1_ = 1;
    if (7 < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_0054ebd0(puVar3,0x21,0x40,1);
    FUN_00550800();
    appuStack_cc[0] = &PTR_018be314;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_14 = 2;
    ppuStack_7c = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_80 = 0x48;
    FUN_00554f20(appuStack_cc + 1,0);
    uStack_8 = 6;
    *(undefined ***)(appuStack_cc[0][1] + (int)appuStack_cc) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_d0 + (int)appuStack_cc[0][1]) = appuStack_cc[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_cc[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_90 = 0;
    uStack_8c = 4;
    uStack_8._0_1_ = 7;
    FUN_0056f130(auStack_174);
    uVar4 = FUN_0058c400(auStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    piVar5 = (int *)FUN_008c0970(auStack_34,uVar4);
    iVar8 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *param_2 = iVar8;
    piVar5 = (int *)param_2[1];
    param_2[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar8 = piVar5[1] + -1;
      piVar5[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar8 = piVar5[2] + -1;
        piVar5[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar5 = piStack_30 + 2;
        iVar8 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (0xf < uStack_18) {
      uVar7 = uStack_18 + 1;
      uVar6 = auStack_2c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_2c[0] - 4);
        uVar7 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_00570540();
    FUN_00551650();
    uStack_8 = 9;
    FUN_01675290(uVar2);
  }
  iVar8 = param_2[1];
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar8 != 0) {
    LOCK();
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
    UNLOCK();
    iVar8 = param_2[1];
  }
  *param_1 = *param_2;
  param_1[1] = iVar8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15089 ; VA 0x008cb320 ; FUN_008cb320 */

undefined * FUN_008cb320(undefined *param_1,undefined4 param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  switch(param_2) {
  case 0:
  case 1:
    pcVar2 = "arial.ttf";
    break;
  case 2:
    pcVar2 = "arialbd.ttf";
    break;
  case 3:
    pcVar2 = "SourceSansPro-Regular.ttf";
    break;
  case 4:
    pcVar2 = "SourceSansPro-Bold.ttf";
    break;
  case 5:
    pcVar2 = "SourceSansPro-Light.ttf";
    break;
  case 6:
    pcVar2 = "SourceSansPro-It.ttf";
    break;
  case 7:
    pcVar2 = "AccanthisADFStd-Regular.otf";
    break;
  case 8:
    pcVar2 = "Guru-Regular.otf";
    break;
  case 9:
    pcVar2 = "ComicNeue-Angular-Bold.ttf";
    break;
  case 10:
    pcVar2 = "Inconsolata-Regular.ttf";
    break;
  case 0xb:
    pcVar2 = "HWYGOTH.ttf";
    break;
  case 0xc:
    pcVar2 = "zekton_rg.ttf";
    break;
  case 0xd:
    pcVar2 = "PressStart2P-Regular.ttf";
    break;
  case 0xe:
    pcVar2 = "Balthazar-Regular.ttf";
    break;
  case 0xf:
    pcVar2 = "RomanAntique.otf";
    break;
  case 0x10:
    pcVar2 = "SourceSansPro-Semibold.ttf";
    break;
  case 0x11:
    pcVar2 = "GothamSSm-Book.otf";
    break;
  case 0x12:
    pcVar2 = "GothamSSm-Medium.otf";
    break;
  case 0x13:
    pcVar2 = "GothamSSm-Bold.otf";
    break;
  case 0x14:
    pcVar2 = "GothamSSm-Black.otf";
    break;
  case 0x15:
    pcVar2 = "AmaticSC-Regular.ttf";
    break;
  case 0x16:
    pcVar2 = "Bangers-Regular.ttf";
    break;
  case 0x17:
    pcVar2 = "Creepster-Regular.ttf";
    break;
  case 0x18:
    pcVar2 = "DenkOne-Regular.ttf";
    break;
  case 0x19:
    pcVar2 = "Fondamento-Regular.ttf";
    break;
  case 0x1a:
    pcVar2 = "FredokaOne-Regular.ttf";
    break;
  case 0x1b:
    pcVar2 = "GrenzeGotisch-Regular.ttf";
    break;
  case 0x1c:
    pcVar2 = "IndieFlower-Regular.ttf";
    break;
  case 0x1d:
    pcVar2 = "JosefinSans-Regular.ttf";
    break;
  case 0x1e:
    pcVar2 = "Jura-Regular.ttf";
    break;
  case 0x1f:
    pcVar2 = "Kalam-Regular.ttf";
    break;
  case 0x20:
    pcVar2 = "LuckiestGuy-Regular.ttf";
    break;
  case 0x21:
    pcVar2 = "Merriweather-Regular.ttf";
    break;
  case 0x22:
    pcVar2 = "Michroma-Regular.ttf";
    break;
  case 0x23:
    pcVar2 = "Nunito-Regular.ttf";
    break;
  case 0x24:
    pcVar2 = "Oswald-Regular.ttf";
    break;
  case 0x25:
    pcVar2 = "PatrickHand-Regular.ttf";
    break;
  case 0x26:
    pcVar2 = "PermanentMarker-Regular.ttf";
    break;
  case 0x27:
    pcVar2 = "Roboto-Regular.ttf";
    break;
  case 0x28:
    pcVar2 = "RobotoCondensed-Regular.ttf";
    break;
  case 0x29:
    pcVar2 = "RobotoMono-Regular.ttf";
    break;
  case 0x2a:
    pcVar2 = "Sarpanch-Regular.ttf";
    break;
  case 0x2b:
    pcVar2 = "SpecialElite-Regular.ttf";
    break;
  case 0x2c:
    pcVar2 = "TitilliumWeb-Regular.ttf";
    break;
  case 0x2d:
    pcVar2 = "Ubuntu-Regular.ttf";
    break;
  case 0x2e:
    pcVar2 = "AmaticSC-Bold.ttf";
    break;
  case 0x2f:
    pcVar2 = "Fondamento-Italic.ttf";
    break;
  case 0x30:
    pcVar2 = "GrenzeGotisch-Bold.ttf";
    break;
  case 0x31:
    pcVar2 = "Merriweather-Italic.ttf";
    break;
  case 0x32:
    pcVar2 = "Oswald-Bold.ttf";
    break;
  case 0x33:
    pcVar2 = "Roboto-Bold.ttf";
    break;
  case 0x34:
    pcVar2 = "Roboto-Italic.ttf";
    break;
  case 0x35:
    pcVar2 = "Sarpanch-Bold.ttf";
    break;
  case 0x36:
    pcVar2 = "TitilliumWeb-Bold.ttf";
    break;
  case 0x37:
    pcVar2 = "Ubuntu-Italic.ttf";
    break;
  case 0x38:
    pcVar2 = "NotoSansCJKjp-Regular.otf";
    break;
  case 0x39:
    pcVar2 = "TwemojiMozilla.ttf";
    break;
  default:
    pcVar2 = (char *)0x0;
  }
  pcVar3 = "arial.ttf";
  if (pcVar2 != (char *)0x0) {
    pcVar3 = pcVar2;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  return param_1;
}



/* FUNCTION 15090 ; VA 0x008cb670 ; FUN_008cb670 */

undefined * FUN_008cb670(undefined *param_1,undefined4 *param_2)

{
  byte bVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  byte *pbVar5;
  uint uVar6;
  undefined4 uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  byte *pbVar11;
  undefined4 ****ppppuVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined **ppuVar15;
  bool bVar16;
  undefined auStack_70 [24];
  undefined2 auStack_58 [8];
  int iStack_48;
  undefined4 uStack_44;
  undefined4 ***apppuStack_40 [2];
  undefined *apuStack_38 [2];
  int iStack_30;
  undefined *puStack_2c;
  undefined *apuStack_28 [2];
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf568;
  pvStack_10 = ExceptionList;
  puVar13 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar13 = (undefined4 *)*param_2;
  }
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_01685730();
  uVar6 = param_2[4];
  uVar9 = 9;
  if (uVar6 < 9) {
    uVar9 = uVar6;
  }
  puVar10 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar10 = (undefined4 *)*param_2;
  }
  iVar4 = FUN_0055c2d0(puVar10,uVar9,"rbxapp://",9);
  if (iVar4 == 0) {
    pbVar5 = (byte *)((int)puVar13 + 9);
    pbVar11 = &DAT_019290f0;
    do {
      bVar1 = *pbVar5;
      bVar16 = bVar1 < *pbVar11;
      if (bVar1 != *pbVar11) {
LAB_008cb702:
        uVar6 = -(uint)bVar16 | 1;
        goto LAB_008cb707;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar5[1];
      bVar16 = bVar1 < pbVar11[1];
      if (bVar1 != pbVar11[1]) goto LAB_008cb702;
      pbVar5 = pbVar5 + 2;
      pbVar11 = pbVar11 + 2;
    } while (bVar1 != 0);
    uVar6 = 0;
LAB_008cb707:
    if (uVar6 == 0) {
      FUN_01518d10(auStack_58,1,0,&DAT_018bc9b8);
      iStack_8 = 0;
      iVar4 = FUN_01687bc0();
      iStack_30 = 0;
      puStack_2c = (undefined *)0xf;
      apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
      FUN_005542c0("gamerpic.png",0xc);
      iStack_8._0_1_ = 1;
      if (iStack_30 != 0) {
        ppppuVar12 = apppuStack_40;
        if (0xf < puStack_2c) {
          ppppuVar12 = (undefined4 ****)apppuStack_40[0];
        }
        iVar14 = (int)ppppuVar12 + iStack_30;
        ppppuVar12 = apppuStack_40;
        if (0xf < puStack_2c) {
          ppppuVar12 = (undefined4 ****)apppuStack_40[0];
        }
        uVar7 = FUN_01686580();
        FUN_01685950(ppppuVar12,iVar14,auStack_58,uVar7);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < puStack_2c) {
        uVar6 = (int)puStack_2c + 1;
        ppppuVar12 = (undefined4 ****)apppuStack_40[0];
        if (0xfff < uVar6) {
          ppppuVar12 = (undefined4 ****)apppuStack_40[0][-1];
          uVar6 = (int)puStack_2c + 0x24;
          if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar12))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar12,uVar6);
      }
      iStack_30 = 0;
      puStack_2c = (undefined *)0xf;
      apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
      if (iVar4 != 0) {
        FUN_01687c10(iVar4);
      }
      piVar8 = (int *)FUN_0168e1c0(auStack_20,auStack_58,&uStack_18);
      if ((*piVar8 != 0) && (*piVar8 != 1)) {
        FUN_0151a940(param_1,auStack_58);
        FUN_00550800();
        ExceptionList = pvStack_10;
        return param_1;
      }
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      FUN_00550800();
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  else {
    uVar9 = 0xb;
    if (uVar6 < 0xb) {
      uVar9 = uVar6;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    iVar4 = FUN_0055c2d0(param_2,uVar9,"rbxasset://",0xb);
    if (iVar4 == 0) {
      uStack_44 = 7;
      auStack_58[0] = 0;
      iStack_8 = 2;
      iStack_48 = iVar4;
      uVar7 = FUN_01686580();
      FUN_01685950((int)puVar13 + 0xb,0,auStack_58,uVar7);
      iStack_8 = 3;
      cVar3 = FUN_0153d390(auStack_58);
      iStack_8 = 0xffffffff;
      FUN_00550800();
      if (cVar3 != '\0') {
        ppuVar15 = apuStack_38;
        apuStack_38[0] = &DAT_01d63140;
        apuStack_38[1] = &DAT_01d63170;
        iStack_30 = (int)&DAT_01d63158;
        puStack_2c = &DAT_01d63128;
        do {
          puVar2 = *ppuVar15;
          if ((puVar2 != (undefined *)0x0) && (*(int *)(puVar2 + 0x10) != 0)) {
            iStack_48 = 0;
            uStack_44 = 7;
            auStack_58[0] = 0;
            iStack_8 = 4;
            uVar7 = FUN_01686580();
            FUN_01685950((int)puVar13 + 0xb,0,auStack_58,uVar7);
            iStack_8 = 5;
            FUN_005514a0(auStack_70,puVar2,auStack_58);
            iStack_8 = CONCAT31(iStack_8._1_3_,7);
            FUN_00550800();
            piVar8 = (int *)FUN_0168e1c0(auStack_20,auStack_70,&uStack_18);
            if ((*piVar8 != 0) && (*piVar8 != 1)) {
              cVar3 = FUN_0153cf20(auStack_70,puVar2);
              if (cVar3 != '\0') {
                FUN_0151a940(param_1,auStack_70);
                FUN_00550800();
                ExceptionList = pvStack_10;
                return param_1;
              }
            }
            iStack_8 = 0xffffffff;
            FUN_00550800();
          }
          ppuVar15 = ppuVar15 + 1;
        } while (ppuVar15 != apuStack_28);
      }
    }
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15091 ; VA 0x008cba30 ; FUN_008cba30 */

uint * FUN_008cba30(uint *param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint uStack_30;
  uint uStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  puVar5 = &param_2;
  if (0xf < in_stack_0000001c) {
    puVar5 = param_2;
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_01683a50(puVar5,in_stack_00000018,0,&uStack_30);
  if (cVar4 == '\0') {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    if (in_stack_0000001c < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar6 = in_stack_0000001c + 1;
    puVar5 = param_2;
    if (0xfff < uVar6) {
      puVar5 = (undefined4 *)param_2[-1];
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar6);
    ExceptionList = pvStack_10;
    return param_1;
  }
  puStack_18 = (uint *)&DAT_01920830;
  iStack_14 = 0x1a3;
  do {
    iVar7 = iStack_14 >> 1;
    puStack_28 = puStack_18 + iVar7 * 4;
    if ((uStack_2c < puStack_28[1]) || ((uStack_2c <= puStack_28[1] && (uStack_30 <= *puStack_28))))
    {
      puStack_20 = puStack_18;
      if ((puStack_28[1] < uStack_2c) ||
         ((puStack_28[1] <= uStack_2c && (*puStack_28 <= uStack_30)))) goto joined_r0x008cbb7a;
    }
    else {
      puStack_18 = puStack_28 + 4;
      iVar7 = iStack_14 + (-1 - iVar7);
    }
    puStack_24 = puStack_18;
    puStack_20 = puStack_18;
    iStack_14 = iVar7;
  } while (0 < iVar7);
LAB_008cbb4a:
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
LAB_008cbb58:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
joined_r0x008cbb7a:
  while (iVar3 = iVar7, 0 < iVar3) {
    iVar7 = iVar3 >> 1;
    if ((puStack_20[iVar7 * 4 + 1] <= uStack_2c) &&
       ((puStack_20[iVar7 * 4 + 1] < uStack_2c || (puStack_20[iVar7 * 4] < uStack_30)))) {
      puStack_20 = puStack_20 + iVar7 * 4 + 4;
      iVar7 = iVar3 + (-1 - iVar7);
    }
  }
  puStack_24 = puStack_28 + 4;
  iVar7 = (int)((iStack_14 * 0x10 - (int)puStack_24) + (int)puStack_18) >> 4;
  while (iVar3 = iVar7, 0 < iVar3) {
    iVar7 = iVar3 >> 1;
    if ((puStack_24[iVar7 * 4 + 1] < uStack_2c) ||
       ((puStack_24[iVar7 * 4 + 1] <= uStack_2c && (puStack_24[iVar7 * 4] <= uStack_30)))) {
      puStack_24 = puStack_24 + iVar7 * 4 + 4;
      iVar7 = iVar3 + (-1 - iVar7);
    }
  }
  puStack_1c = puStack_20;
  if (puStack_20 < puStack_24) {
    uVar6 = puStack_20[1];
    uVar1 = puStack_20[2];
    uVar2 = puStack_20[3];
    *param_1 = *puStack_20;
    param_1[1] = uVar6;
    param_1[2] = uVar1;
    param_1[3] = uVar2;
    *(undefined *)(param_1 + 4) = 1;
    goto LAB_008cbb58;
  }
  goto LAB_008cbb4a;
}



/* FUNCTION 15092 ; VA 0x008cbc30 ; FUN_008cbc30 */

undefined * FUN_008cbc30(undefined *param_1,char *param_2)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  int *piVar6;
  undefined auStack_6c [24];
  undefined2 auStack_54 [8];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [24];
  undefined auStack_24 [8];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf5b1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_008ce340(auStack_6c,1);
  uStack_8 = 0;
  FUN_0054f050(auStack_6c);
  uStack_8._0_1_ = 1;
  pcVar5 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pcVar5 = *(char **)param_2;
  }
  if (*pcVar5 != '\0') {
    iVar3 = FUN_01687bc0();
    uVar4 = FUN_01686580();
    FUN_01685950(pcVar5,0,auStack_3c,uVar4);
    if (iVar3 != 0) {
      FUN_01687c10(iVar3);
    }
  }
  uStack_44 = 0;
  uStack_40 = 7;
  auStack_54[0] = 0;
  iVar3 = *(int *)(param_2 + 0x10);
  uStack_8._0_1_ = 2;
  if (iVar3 != 0) {
    pcVar5 = param_2;
    if (0xf < *(uint *)(param_2 + 0x14)) {
      pcVar5 = *(char **)param_2;
    }
    if (0xf < *(uint *)(param_2 + 0x14)) {
      param_2 = *(char **)param_2;
    }
    uVar4 = FUN_01686580();
    FUN_01685950(param_2,pcVar5 + iVar3,auStack_54,uVar4);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 1;
  cVar2 = FUN_0153d390(auStack_54);
  if (cVar2 == '\0') {
LAB_008cbd2f:
    bVar1 = true;
  }
  else {
    cVar2 = FUN_0153cf20(auStack_3c,auStack_6c);
    if (cVar2 == '\0') goto LAB_008cbd2f;
    bVar1 = false;
  }
  uStack_8 = 1;
  FUN_00550800();
  if (!bVar1) {
    uStack_1c = 0;
    uStack_18 = FUN_01685730();
    piVar6 = (int *)FUN_0168e1c0(auStack_24,auStack_3c,&uStack_1c);
    if ((*piVar6 != 0) && (*piVar6 != 1)) {
      FUN_0151a940(param_1,auStack_3c);
      goto LAB_008cbda7;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
LAB_008cbda7:
  FUN_00550800();
  FUN_00550800();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15093 ; VA 0x008cbdd0 ; FUN_008cbdd0 */

undefined FUN_008cbdd0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 ***apppuStack_30 [4];
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf5d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8 = 0;
  FUN_009cbbb0(apppuStack_30);
  uVar7 = uStack_1c;
  ppppuVar8 = (undefined4 ****)apppuStack_30[0];
  uStack_18 = 0xb;
  if (uStack_20 < 0xb) {
    uStack_18 = uStack_20;
  }
  ppppuVar4 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
  }
  uStack_8 = 1;
  iVar3 = FUN_0055c2d0(ppppuVar4,uStack_18,"rbxasset://",0xb);
  if (iVar3 == 0) {
LAB_008cbeeb:
    puVar6 = (undefined4 *)FUN_008cb670(aiStack_48,apppuStack_30);
    if (param_2 != puVar6) {
      FUN_005507b0();
      uVar5 = puVar6[1];
      uVar1 = puVar6[2];
      uVar2 = puVar6[3];
      *param_2 = *puVar6;
      param_2[1] = uVar5;
      param_2[2] = uVar1;
      param_2[3] = uVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      iVar3 = aiStack_48[0];
      if (0xfff < uVar7) {
        iVar3 = *(int *)(aiStack_48[0] + -4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar7);
    }
    iVar3 = param_2[4];
LAB_008cbf60:
    uStack_11 = 0;
    ppppuVar8 = (undefined4 ****)apppuStack_30[0];
    uVar7 = uStack_1c;
    if (iVar3 == 0) goto LAB_008cbf70;
  }
  else {
    uVar9 = 9;
    if (uStack_20 < 9) {
      uVar9 = uStack_20;
    }
    ppppuVar4 = apppuStack_30;
    if (0xf < uVar7) {
      ppppuVar4 = ppppuVar8;
    }
    iVar3 = FUN_0055c2d0(ppppuVar4,uVar9,"rbxapp://",9);
    if (iVar3 == 0) goto LAB_008cbeeb;
    uVar9 = 4;
    if (uStack_20 < 4) {
      uVar9 = uStack_20;
    }
    ppppuVar4 = apppuStack_30;
    if (0xf < uVar7) {
      ppppuVar4 = ppppuVar8;
    }
    iVar3 = FUN_0055c2d0(ppppuVar4,uVar9,&DAT_018c71bc,4);
    if (iVar3 != 0) {
      ppppuVar4 = apppuStack_30;
      if (0xf < uVar7) {
        ppppuVar4 = ppppuVar8;
      }
      iVar3 = FUN_0055c2d0(ppppuVar4,uStack_18,"rbxthumb://",0xb);
      if (iVar3 == 0) goto LAB_008cbf6c;
      uVar5 = FUN_008cbc30(aiStack_48,apppuStack_30);
      FUN_005511f0(uVar5);
      FUN_005507b0();
      iVar3 = param_2[4];
      goto LAB_008cbf60;
    }
  }
LAB_008cbf6c:
  uStack_11 = 1;
LAB_008cbf70:
  if (0xf < uVar7) {
    uVar9 = uVar7 + 1;
    ppppuVar4 = ppppuVar8;
    if (0xfff < uVar9) {
      ppppuVar4 = (undefined4 ****)ppppuVar8[-1];
      uVar9 = uVar7 + 0x24;
      if (0x1f < (uint)((int)ppppuVar8 + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar9);
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 15094 ; VA 0x008cbfc0 ; FUN_008cbfc0 */

void FUN_008cbfc0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf488;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)*param_2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d190();
  if (iVar1 == iVar2) {
    FUN_0054ef60();
    uStack_8 = 0;
    FUN_008c7030(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 15095 ; VA 0x008cc060 ; FUN_008cc060 */

undefined4 __thiscall FUN_008cc060(int param_1,undefined4 *param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined auStack_c4 [120];
  undefined auStack_4c [24];
  undefined auStack_34 [24];
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf5f3;
  pvStack_10 = ExceptionList;
  uStack_18 = CONCAT44(param_1,(undefined4)uStack_18);
  ExceptionList = &pvStack_10;
  if (DAT_01d62f98 != '\0') {
    uVar6 = 0x16;
    if ((uint)param_2[4] < 0x16) {
      uVar6 = param_2[4];
    }
    puVar5 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar5 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0055c2d0(puVar5,uVar6,"rbxencryptedassetid://",0x16);
    if (iVar4 == 0) {
      puVar5 = (undefined4 *)FUN_009cc5b0(auStack_4c);
      uStack_8 = 0;
      piStack_1c = (int *)FUN_0171689d();
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      *piStack_1c = 0;
      uVar9 = FUN_0171d7b1(puVar5,&param_2,10);
      if (puVar5 == param_2) {
        FUN_016ddcb9("invalid stoll argument");
LAB_008cc2df:
        FUN_016ddcf9("stoll argument out of range");
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
      }
      if (*piStack_1c == 0x22) goto LAB_008cc2df;
      puVar5 = (undefined4 *)FUN_009cc3c0(auStack_34,uVar9);
      if (puVar7 != puVar5) {
        FUN_005507b0();
        uVar6 = puVar5[1];
        uVar8 = puVar5[2];
        uVar2 = puVar5[3];
        *puVar7 = *puVar5;
        puVar7[1] = uVar6;
        puVar7[2] = uVar8;
        puVar7[3] = uVar2;
        *(undefined8 *)(puVar7 + 4) = *(undefined8 *)(puVar5 + 4);
        puVar5[4] = 0;
        puVar5[5] = 0xf;
        *(undefined *)puVar5 = 0;
      }
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      param_1 = uStack_18._4_4_;
    }
  }
  uVar6 = 0xb;
  if ((uint)puVar7[4] < 0xb) {
    uVar6 = puVar7[4];
  }
  puVar5 = puVar7;
  if (0xf < (uint)puVar7[5]) {
    puVar5 = (undefined4 *)*puVar7;
  }
  iVar4 = FUN_0055c2d0(puVar5,uVar6,"rbxthumb://",0xb);
  if (iVar4 == 0) {
    uVar6 = FUN_009cc9a0();
    ExceptionList = pvStack_10;
    return uVar6;
  }
  iVar4 = FUN_008f7870(param_1);
  if (iVar4 == 0) {
    uStack_18 = 0;
    uStack_18._4_4_ = 0;
    uStack_18._0_4_ = 0;
    uVar6 = (undefined4)uStack_18;
    uVar8 = uStack_18._4_4_;
  }
  else {
    uVar6 = *(undefined4 *)(iVar4 + 0x440);
    uVar8 = *(undefined4 *)(iVar4 + 0x444);
  }
  iVar4 = 0xb8;
  if (DAT_01d62f58 != '\0') {
    iVar4 = 0xd0;
  }
  param_2 = (undefined4 *)(iVar4 + param_1);
  FUN_009cbc80(param_2,uVar6,uVar8);
  FUN_009cc1b0(param_2);
  if (DAT_01d62f60 != '\0') {
    cVar3 = FUN_008b4230();
    if (cVar3 != '\0') {
      puVar5 = puVar7 + 4;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_0151bda0(auStack_c4,puVar7,*puVar5);
      uStack_8 = 1;
      cVar3 = FUN_014cd370(auStack_c4);
      if (cVar3 != '\0') {
LAB_008cc2b6:
        FUN_0056d9d0();
        ExceptionList = pvStack_10;
        return 1;
      }
      if (DAT_01d62f68 != '\0') {
        puVar7 = &DAT_01d7a028;
        if (0xf < DAT_01d7a03c) {
          puVar7 = DAT_01d7a028;
        }
        cVar3 = FUN_0151c660(puVar7);
        if (cVar3 != '\0') goto LAB_008cc2b6;
      }
      uStack_8 = 0xffffffff;
      FUN_0056d9d0();
    }
  }
  uVar6 = FUN_009cc980(param_2);
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 15096 ; VA 0x008cc2f0 ; FUN_008cc2f0 */

undefined FUN_008cc2f0(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  char cVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined4 ****ppppuVar9;
  undefined uVar10;
  undefined4 *puVar11;
  undefined1 *puVar12;
  undefined8 uVar13;
  char *pcVar14;
  undefined4 uVar15;
  undefined auStack_1ac [120];
  undefined auStack_134 [24];
  undefined auStack_11c [24];
  undefined auStack_104 [72];
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 ***apppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  int *piStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf65f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_008cc060(param_1);
  if (cVar4 == '\0') {
    uVar15 = 0x13;
    pcVar14 = "Could not normalize";
LAB_008cc722:
    FUN_005542c0(pcVar14,uVar15);
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar1 = param_1[4];
  uVar2 = param_1[5];
  uVar7 = 7;
  if (uVar1 < 7) {
    uVar7 = uVar1;
  }
  puVar11 = param_1;
  if (0xf < uVar2) {
    puVar11 = (undefined4 *)*param_1;
  }
  iVar6 = FUN_0055c2d0(puVar11,uVar7,"file://",7);
  if (iVar6 == 0) {
    ExceptionList = pvStack_10;
    return 1;
  }
  uVar7 = 4;
  if (uVar1 < 4) {
    uVar7 = uVar1;
  }
  puVar11 = param_1;
  if (0xf < uVar2) {
    puVar11 = (undefined4 *)*param_1;
  }
  iVar6 = FUN_0055c2d0(puVar11,uVar7,&DAT_018c71bc,4);
  if (iVar6 != 0) {
    uVar15 = 0x13;
    pcVar14 = "Unrecognized scheme";
    goto LAB_008cc722;
  }
  iVar6 = FUN_0058eea0(&DAT_01929074,0);
  if (iVar6 != -1) {
    uVar15 = 0xc;
    pcVar14 = "Contains \'#\'";
    goto LAB_008cc722;
  }
  if (0xf < uVar2) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0151bda0(auStack_134,param_1,uVar1);
  uStack_8 = 0;
  iVar6 = FUN_008f7870(puStack_18);
  if (iVar6 == 0) {
    FUN_005542c0("Outside of DataModel",0x14);
    FUN_0056d9d0();
    ExceptionList = pvStack_10;
    return 0;
  }
  uVar13 = FUN_005ea010();
  FUN_01675640(apppuStack_5c,&DAT_018bed48,uVar13);
  uStack_8._0_1_ = 1;
  cStack_11 = '\0';
  FUN_0151cb00(&puStack_3c);
  uStack_8._0_1_ = 2;
  puStack_1c = puStack_3c;
  puStack_20 = puStack_38;
  puVar11 = puStack_3c;
  if (puStack_3c != puStack_38) {
    do {
      uStack_8._0_1_ = 3;
      puStack_1c = puVar11;
      piStack_40 = (int *)FUN_016de181(1);
      uStack_8._0_1_ = 5;
      piStack_2c = piStack_40;
      (**(code **)(*piStack_40 + 4))();
      uStack_8._0_1_ = 6;
      puStack_18 = puVar11;
      if (0xf < (uint)puVar11[5]) {
        puStack_18 = (undefined4 *)*puVar11;
      }
      puStack_18 = (undefined4 *)(puVar11[4] + (int)puStack_18);
      if (0xf < (uint)puVar11[5]) {
        puVar11 = (undefined4 *)*puVar11;
      }
      puVar12 = &DAT_019290a0;
      do {
        if (puVar11 == puStack_18) goto LAB_008cc50a;
        uStack_24 = CONCAT31(uStack_24._1_3_,*puVar12);
        piVar8 = (int *)FUN_0054e7d0(auStack_30);
        cVar4 = (**(code **)(*piVar8 + 0x18))(uStack_24);
        uStack_28 = CONCAT31(uStack_28._1_3_,*(undefined *)puVar11);
        piVar8 = (int *)FUN_0054e7d0(auStack_30);
        cVar5 = (**(code **)(*piVar8 + 0x18))(uStack_28);
        piVar8 = piStack_40;
        if (cVar4 != cVar5) {
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          puVar11 = (undefined4 *)(**(code **)(*piStack_40 + 8))();
          if (puVar11 != (undefined4 *)0x0) {
            (**(code **)*puVar11)(1);
          }
          bVar3 = false;
          goto LAB_008cc554;
        }
        puVar12 = puVar12 + 1;
        puVar11 = (undefined4 *)((int)puVar11 + 1);
      } while (puVar12 != &DAT_019290ad);
      if (puVar11 == puStack_18) {
LAB_008cc50a:
        if (puVar12 != &DAT_019290ad) goto LAB_008cc536;
        bVar3 = true;
      }
      else {
LAB_008cc536:
        bVar3 = false;
      }
      piVar8 = piStack_40;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puVar11 = (undefined4 *)(**(code **)(*piStack_40 + 8))();
      if (puVar11 != (undefined4 *)0x0) {
        (**(code **)*puVar11)(1);
      }
LAB_008cc554:
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      puVar11 = (undefined4 *)(**(code **)(*piVar8 + 8))();
      if (puVar11 != (undefined4 *)0x0) {
        (**(code **)*puVar11)(1);
      }
      puVar11 = puStack_1c;
      uStack_8._0_1_ = 2;
      if (bVar3) {
        if ((cStack_11 != '\0') ||
           (cVar4 = FUN_00684460(puStack_1c + 6,apppuStack_5c), cVar4 != '\0')) {
          FUN_005542c0("Contains duplicate serverplaceid parameter",0x2a);
          uVar10 = 0;
          goto LAB_008cc6d8;
        }
        cStack_11 = '\x01';
      }
      puStack_1c = puVar11 + 0xc;
      puVar11 = puStack_1c;
    } while (puStack_1c != puStack_20);
    if (cStack_11 != '\0') goto LAB_008cc6d6;
  }
  FUN_0151b2c0(&puStack_3c);
  uStack_8._0_1_ = 10;
  ppppuVar9 = apppuStack_5c;
  if (0xf < uStack_48) {
    ppppuVar9 = (undefined4 ****)apppuStack_5c[0];
  }
  FUN_0151b780(&DAT_019290a0,0xd,ppppuVar9,uStack_4c);
  uStack_64 = 0;
  uStack_60 = 0xf;
  auStack_74[0] = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xb;
  FUN_0151bcc0(auStack_1ac,auStack_134,auStack_11c,auStack_104,auStack_a4,auStack_74);
  uStack_8._0_1_ = 0xd;
  FUN_005507b0();
  uVar15 = FUN_0151bb70(auStack_bc);
  uStack_8._0_1_ = 0xe;
  FUN_0054ef60(uVar15);
  uStack_8._0_1_ = 0xf;
  FUN_009cbbb0(auStack_8c);
  FUN_005511f0(auStack_8c);
  FUN_005507b0();
  FUN_005507b0();
  FUN_0056d9d0();
  FUN_005507b0();
LAB_008cc6d6:
  uVar10 = 1;
LAB_008cc6d8:
  FUN_008c7c70();
  FUN_005507b0();
  FUN_0056d9d0();
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 15097 ; VA 0x008cc740 ; FUN_008cc740 */

undefined4
FUN_008cc740(undefined4 param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar1 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
    if (cVar1 != '\0') {
      uVar2 = FUN_0088a920();
      FUN_0054ef60(uVar2);
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*param_6 != 0) {
    FUN_0054ef60(*param_6);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 15098 ; VA 0x008cc860 ; FUN_008cc860 */

undefined4 * __thiscall FUN_008cc860(int **param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [8];
  int *piStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf678;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if (&piStack_18 != param_1) {
    piStack_18 = *param_1;
    ExceptionList = &pvStack_10;
    *param_1 = (int *)0x0;
  }
  piVar2 = piStack_18;
  uStack_14 = 1;
  uStack_8 = 1;
  if ((piStack_18 != (int *)0x0) && (*(char *)(piStack_18 + 0x1d) == '\0')) {
    puVar3 = (undefined4 *)(**(code **)(*piStack_18 + 8))(1);
    *param_2 = *puVar3;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[1] = puVar3[1];
    param_2[2] = puVar3[2];
    puVar3[1] = 0;
    puVar3[2] = 0;
    uStack_8 = 2;
    LOCK();
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      if ((undefined4 *)piVar2[0x20] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar2[0x20])(piVar2);
        ExceptionList = pvStack_10;
        return param_2;
      }
      (**(code **)*piVar2)(1);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar4 = FUN_005deb10(auStack_20,4);
                    /* WARNING: Subroutine does not return */
  FUN_016dfe59(uVar4);
}



/* FUNCTION 15099 ; VA 0x008cc950 ; FUN_008cc950 */

uint * __thiscall FUN_008cc950(int param_1,uint *param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf6a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01f6dd5c);
  iStack_8 = 0;
  uStack_14 = uVar1;
  FUN_008cec70(&uStack_2c,param_1 + 0xb8);
  iStack_8._0_1_ = 1;
  if (iStack_1c == 0) {
    FUN_0054ef60(param_1 + 0xb8);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = uStack_2c;
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(uStack_2c - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (uStack_2c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  else {
    iVar2 = FUN_0058eea0("https",0);
    if (iVar2 == -1) {
      iVar2 = FUN_0058eea0(&DAT_018c71bc,0);
      if (iVar2 != -1) {
        FUN_00591430(iVar2,4,"https",5);
      }
    }
    param_2[4] = 0;
    param_2[5] = 0;
    *param_2 = uStack_2c;
    param_2[1] = uStack_28;
    param_2[2] = uStack_24;
    param_2[3] = uStack_20;
    *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_18,iStack_1c);
  }
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_18 = 0xf;
  iStack_1c = 0;
  iStack_8 = 2;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15100 ; VA 0x008cca80 ; FUN_008cca80 */

undefined4 FUN_008cca80(undefined4 param_1,int *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf6c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)*param_2)();
  if (iVar2 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8 = 0;
    uStack_f8 = FUN_00888530();
    iStack_f4 = 0;
    uStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_2 + 4))(1,&uStack_f8);
    if (cVar1 != '\0') {
      uVar3 = FUN_008898b0();
      FUN_0054ef60(uVar3);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_f4 != 0) {
      (**(code **)(iStack_f4 + 8))(auStack_f0);
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  if (*param_3 != 0) {
    FUN_0054ef60(*param_3);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 15101 ; VA 0x008ccbc0 ; FUN_008ccbc0 */

undefined4 * FUN_008ccbc0(undefined4 *param_1,int *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf6e3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)*param_2)();
  if (iVar2 != 0) {
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = 0;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_2 + 4))(1,&uStack_ec);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_00887e80();
      iVar2 = puVar3[1];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar2 != 0) {
        LOCK();
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
        UNLOCK();
        iVar2 = puVar3[1];
      }
      *param_1 = *puVar3;
      param_1[1] = iVar2;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
  }
  puVar3 = (undefined4 *)*param_3;
  if (puVar3 != (undefined4 *)0x0) {
    iVar2 = puVar3[1];
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
      iVar2 = puVar3[1];
    }
    *param_1 = *puVar3;
    param_1[1] = iVar2;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 15102 ; VA 0x008ccd30 ; FUN_008ccd30 */

undefined * FUN_008ccd30(void)

{
  return &DAT_01d63098;
}



/* FUNCTION 15103 ; VA 0x008ccd40 ; FUN_008ccd40 */

undefined * FUN_008ccd40(void)

{
  return &DAT_01d630c8;
}



/* FUNCTION 15104 ; VA 0x008ccd50 ; FUN_008ccd50 */

undefined4 * FUN_008ccd50(void)

{
  return &DAT_01d63080;
}



/* FUNCTION 15105 ; VA 0x008ccd60 ; FUN_008ccd60 */

undefined * FUN_008ccd60(void)

{
  return &DAT_01d630e0;
}



/* FUNCTION 15106 ; VA 0x008ccd70 ; FUN_008ccd70 */

undefined * FUN_008ccd70(void)

{
  return &DAT_01d630f8;
}



/* FUNCTION 15107 ; VA 0x008ccd80 ; FUN_008ccd80 */

undefined * FUN_008ccd80(void)

{
  return &DAT_01d630b0;
}



/* FUNCTION 15108 ; VA 0x008ccd90 ; FUN_008ccd90 */

undefined * FUN_008ccd90(void)

{
  return &DAT_01d63068;
}



/* FUNCTION 15109 ; VA 0x008ccda0 ; FUN_008ccda0 */

undefined * FUN_008ccda0(void)

{
  return &DAT_01d63020;
}



/* FUNCTION 15110 ; VA 0x008ccdb0 ; FUN_008ccdb0 */

undefined * FUN_008ccdb0(void)

{
  return &DAT_01d63050;
}



/* FUNCTION 15111 ; VA 0x008ccdc0 ; FUN_008ccdc0 */

undefined * FUN_008ccdc0(void)

{
  return &DAT_01d63038;
}



/* FUNCTION 15112 ; VA 0x008ccdd0 ; FUN_008ccdd0 */

undefined4 *
FUN_008ccdd0(undefined4 *param_1,undefined4 param_2,uint *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined uStack0000002c;
  char cStack0000002f;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  int *in_stack_00000038;
  undefined4 in_stack_0000003c;
  int *in_stack_00000040;
  undefined4 in_stack_00000044;
  int *in_stack_00000048;
  undefined auStack_284 [104];
  undefined auStack_21c [104];
  undefined auStack_1b4 [104];
  undefined auStack_14c [104];
  undefined auStack_e4 [104];
  undefined4 auStack_7c [2];
  uint uStack_74;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf769;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_7c;
  uStack_8 = 3;
  auStack_7c[0] = param_2;
  uStack_74 = 0;
  uVar7 = *param_3;
  ExceptionList = &pvStack_10;
  if (uVar7 != 0) {
    uStack_74 = uVar7;
    if ((uVar7 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar7 & 0xfffffffe))(param_3 + 2,&uStack_6c,0);
    }
    else {
      uStack_6c = param_3[2];
      uStack_68 = param_3[3];
      uStack_64 = param_3[4];
      uStack_60 = param_3[5];
      uStack_5c = *(undefined8 *)(param_3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_54 = param_4;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_5);
  uStack_38 = uStack0000002c;
  uStack_34 = in_stack_00000030;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  piStack_2c = in_stack_00000038;
  uStack_30 = in_stack_00000034;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    in_stack_00000040[1] = in_stack_00000040[1] + 1;
    UNLOCK();
  }
  piStack_24 = in_stack_00000040;
  uStack_28 = in_stack_0000003c;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    in_stack_00000048[1] = in_stack_00000048[1] + 1;
    UNLOCK();
  }
  uStack_20 = in_stack_00000044;
  piStack_1c = in_stack_00000048;
  uStack_8._0_1_ = 5;
  FUN_008c1510(auStack_7c);
  uStack_8._0_1_ = 6;
  *param_1 = 0;
  FUN_008c1510(auStack_284);
  uStack_8._0_1_ = 7;
  FUN_008c1510(auStack_21c);
  uStack_8._0_1_ = 8;
  FUN_008c1510(auStack_1b4);
  uStack_8._0_1_ = 9;
  cVar4 = FUN_00585a40(auStack_e4);
  if (cVar4 == '\0') {
    FUN_008c1510(auStack_e4);
    uStack_8._0_1_ = 10;
    _uStack0000002c = FUN_01674e20(0x68);
    uStack_8._0_1_ = 0xb;
    if (_uStack0000002c == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_008c1510(auStack_14c);
    }
    param_1[2] = uVar5;
    FUN_008c3700();
    FUN_008c3700();
    _uStack0000002c = CONCAT13(1,_uStack0000002c);
  }
  else {
    FUN_008c3700();
    _uStack0000002c = _uStack0000002c & 0xffffff;
  }
  FUN_008c3700();
  ppuVar6 = &PTR_FUN_0192988c;
  if (cStack0000002f == '\0') {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  FUN_008c3700();
  FUN_008c3700();
  FUN_008c3700();
  if (0xf < in_stack_00000028) {
    uVar8 = in_stack_00000028 + 1;
    uVar7 = param_5;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_5 - 4);
      uVar8 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  piVar3 = in_stack_00000038;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000040;
  if (in_stack_00000040 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000040[1] + -1;
    in_stack_00000040[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000040)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000048;
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15113 ; VA 0x008cd0c0 ; FUN_008cd0c0 */

uint __thiscall FUN_008cd0c0(int param_1,undefined4 param_2)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf788;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016dee6d(param_1 + 8);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = 0;
  uStack_14 = FUN_009cc8a0(param_2);
  uStack_14 = *(uint *)(param_1 + 0x50) & uStack_14;
  puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x44) + uStack_14 * 8);
  while( true ) {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    puVar7 = puVar9;
    if (*(undefined4 **)(*(int *)(param_1 + 0x44) + uStack_14 * 8) != puVar9) {
      puVar7 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0x44) + 4 + uStack_14 * 8);
    }
    if (puVar8 == puVar7) goto LAB_008cd192;
    cVar3 = FUN_009cbaa0(puVar8 + 2,param_2);
    if (cVar3 != '\0') break;
    puVar8 = (undefined4 *)*puVar8;
  }
  uStack_1c = (double)CONCAT44(puVar8,(undefined4)uStack_1c);
  puVar7 = puVar8;
  while( true ) {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    puVar5 = puVar9;
    if (*(undefined4 **)(*(int *)(param_1 + 0x44) + uStack_14 * 8) != puVar9) {
      puVar5 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0x44) + 4 + uStack_14 * 8);
    }
    if (puVar7 == puVar5) goto LAB_008cd18d;
    cVar3 = FUN_009cbaa0(param_2,puVar7 + 2);
    if (cVar3 == '\0') break;
    puVar7 = (undefined4 *)*puVar7;
  }
  puVar9 = *(undefined4 **)(param_1 + 0x3c);
LAB_008cd18d:
  if (uStack_1c._4_4_ == puVar7) {
LAB_008cd192:
    puVar7 = puVar9;
    puVar8 = puVar9;
  }
  iVar4 = 0;
  if (puVar8 != puVar7) {
    do {
      puVar8 = (undefined4 *)*puVar8;
      iVar4 = iVar4 + 1;
    } while (puVar8 != puVar7);
    if (iVar4 != 0) goto LAB_008cd1bb;
  }
  FUN_008c8070(param_2);
LAB_008cd1bb:
  uVar6 = FUN_009cc8a0(param_2);
  uVar6 = *(uint *)(param_1 + 0x50) & uVar6;
  puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x44) + uVar6 * 8);
  while( true ) {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    puVar7 = puVar9;
    if (*(undefined4 **)(*(int *)(param_1 + 0x44) + uVar6 * 8) != puVar9) {
      puVar7 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0x44) + 4 + uVar6 * 8);
    }
    puVar5 = puVar9;
    if (puVar8 == puVar7) goto LAB_008cd222;
    cVar3 = FUN_009cbaa0(puVar8 + 2,param_2);
    if (cVar3 != '\0') break;
    puVar8 = (undefined4 *)*puVar8;
  }
  cVar3 = FUN_009cbaa0(param_2,puVar8 + 2);
  if (cVar3 == '\0') {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    puVar5 = puVar9;
  }
  else {
    puVar9 = *(undefined4 **)(param_1 + 0x3c);
    puVar5 = puVar8;
  }
LAB_008cd222:
  if (puVar5 == puVar9) {
    FUN_016ddcf9("invalid unordered_map<K, T> key");
    pcVar2 = (code *)swi(3);
    uVar6 = (*pcVar2)();
    return uVar6;
  }
  if ((uint)puVar5[0xc] < (uint)puVar5[0xe]) {
    puVar5[0xf] = puVar5[10] * puVar5[0xf];
  }
  puVar5[0xe] = puVar5[0xe] + 1;
  if ((uint)puVar5[0x10] < (uint)puVar5[0xd]) {
    iVar4 = puVar5[0xf];
    iVar1 = puVar5[0xb];
    uVar6 = FUN_0171d737();
    uVar6 = (puVar5[8] - iVar1) * iVar4 + uVar6 % (iVar1 * iVar4 * 2 + 1U);
    iVar4 = puVar5[0x10];
    if ((uint)puVar5[9] <= uVar6) {
      uVar6 = puVar5[9];
    }
    uVar10 = puVar5[0xd] - iVar4;
    if (iVar4 + uVar6 <= (uint)puVar5[0xd]) {
      uVar10 = uVar6;
    }
    puVar5[0x10] = iVar4 + uVar10;
  }
  else {
    uVar10 = 0;
  }
  uStack_1c = ((double)(int)uVar10 + (double)(&DAT_018c0d90)[-((int)uVar10 >> 0x1f)]) * DAT_018e0008
  ;
  *(double *)(puVar5 + 0x12) = uStack_1c;
  puVar8 = (undefined4 *)FUN_016830f0(&uStack_1c);
  puVar5[0x14] = *puVar8;
  puVar5[0x15] = puVar8[1];
  uStack_8 = 1;
  iVar4 = FUN_016deec8(param_1 + 8);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 15114 ; VA 0x008cd320 ; FUN_008cd320 */

int __fastcall FUN_008cd320(int param_1)

{
  return param_1 + 0xb8;
}



/* FUNCTION 15115 ; VA 0x008cd330 ; FUN_008cd330 */

void __thiscall
FUN_008cd330(undefined4 ***param_1,undefined4 ****param_2,undefined4 ***param_3,
            undefined4 ****param_4,undefined4 *param_5,undefined4 ***param_6,undefined4 ***param_7,
            undefined4 param_8)

{
  bool bVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 ***pppuVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  undefined auStack_1e4 [16];
  undefined4 uStack_1d4;
  undefined4 **ppuStack_1d0;
  undefined4 **ppuStack_1cc;
  uint *puStack_1c8;
  undefined4 **ppuStack_1c4;
  undefined4 ***pppuStack_1c0;
  uint **ppuStack_1bc;
  undefined4 **ppuStack_1b8;
  uint **ppuStack_1b4;
  uint *puStack_1b0;
  undefined4 ***pppuStack_1ac;
  undefined4 ***pppuStack_1a8;
  undefined4 ***pppuStack_1a4;
  undefined4 ***pppuStack_1a0;
  undefined auStack_194 [40];
  undefined auStack_16c [40];
  undefined auStack_144 [40];
  undefined4 **appuStack_11c [2];
  undefined4 *apuStack_114 [6];
  undefined auStack_fc [8];
  undefined4 **appuStack_f4 [2];
  undefined4 **appuStack_ec [6];
  uint auStack_d4 [2];
  undefined4 **ppuStack_cc;
  undefined4 uStack_c8;
  undefined4 **ppuStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  int iStack_b0;
  uint auStack_ac [2];
  undefined4 **ppuStack_a4;
  undefined4 uStack_a0;
  undefined4 **ppuStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 ***apppuStack_8c [4];
  undefined4 ***pppuStack_7c;
  uint uStack_78;
  undefined auStack_74 [8];
  undefined4 **appuStack_6c [2];
  undefined4 **ppuStack_64;
  undefined4 **ppuStack_60;
  undefined4 **ppuStack_5c;
  undefined4 **ppuStack_58;
  undefined8 uStack_54;
  undefined4 **ppuStack_4c;
  uint *puStack_48;
  uint *puStack_44;
  uint *puStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  uint uStack_30;
  uint *puStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int iStack_20;
  char *pcStack_1c;
  undefined4 **ppuStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf88a;
  pvStack_10 = ExceptionList;
  pppuStack_1a0 = param_2;
  pppuStack_1a4 = (undefined4 ****)0x8cd360;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puStack_2c = (uint *)0x0;
  puStack_28 = (undefined4 *)0x0;
  uStack_24 = 0;
  iStack_20 = 0;
  auStack_ac[0] = 0;
  cStack_11 = '\0';
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_3c = 0xf00000000;
  ppuStack_4c = (undefined4 **)((uint)ppuStack_4c & 0xffffff00);
  uStack_8 = 3;
  if (DAT_01d62f98 == '\0') {
LAB_008cd438:
    if (DAT_01d62fd8 != '\0') {
      iVar4 = (int)param_1 + *(byte *)(param_1 + 0x26) + 0x99;
      pppuStack_1a0 = apppuStack_8c;
      pppuStack_1a4 = (undefined4 ***)0x8cd460;
      pppuStack_1a8 = (undefined4 ***)FUN_009cc8a0();
      pppuStack_1a0 = (undefined4 ***)(-(uint)(iVar4 != 0) & iVar4 + 1U);
      pppuStack_1a4 = apppuStack_8c;
      pppuStack_1ac = &ppuStack_18;
      puStack_1b0 = (uint *)0x8cd484;
      FUN_00607080();
      if ((undefined4 ***)ppuStack_18 == (undefined4 ***)0x0) {
        ppppuVar6 = (undefined4 ****)(param_1 + 0x20);
        if ((undefined4 ****)&ppuStack_4c != ppppuVar6) {
          pppuStack_1a0 = (undefined4 ***)param_1[0x24];
          if ((undefined4 **)0xf < param_1[0x25]) {
            ppppuVar6 = (undefined4 ****)*ppppuVar6;
          }
          pppuStack_1a8 = (undefined4 ****)0x8cd4df;
          pppuStack_1a4 = ppppuVar6;
          FUN_005542c0();
        }
        uStack_30 = CONCAT31(uStack_30._1_3_,1);
      }
      else {
        pppuStack_1a0 = apppuStack_8c;
        pppuStack_1a4 = (undefined4 ****)0x8cd49c;
        iVar4 = FUN_008c4650();
        ppppuVar6 = (undefined4 ****)(iVar4 + 0x18);
        if ((undefined4 ****)&ppuStack_4c == ppppuVar6) goto LAB_008cd4e9;
        pppuStack_1a0 = *(undefined4 ****)(iVar4 + 0x28);
        if (0xf < *(uint *)(iVar4 + 0x2c)) {
          ppppuVar6 = (undefined4 ****)*ppppuVar6;
        }
        pppuStack_1a8 = (undefined4 ****)0x8cd4bb;
        pppuStack_1a4 = ppppuVar6;
        FUN_005542c0();
      }
      goto LAB_008cd4e3;
    }
LAB_008cd4e9:
    if (DAT_01d62fc0 != '\0') goto LAB_008cd4f2;
  }
  else {
    pppuStack_1a0 = (undefined4 ****)0x16;
    pppuStack_1a8 = (undefined4 ****)0x16;
    if (pppuStack_7c < (undefined4 ****)0x16) {
      pppuStack_1a8 = pppuStack_7c;
    }
    pppuStack_1a4 = (undefined4 ***)0x1928990;
    pppuStack_1ac = apppuStack_8c;
    if (0xf < uStack_78) {
      pppuStack_1ac = apppuStack_8c[0];
    }
    puStack_1b0 = (uint *)0x8cd3e3;
    iVar4 = FUN_0055c2d0();
    if (iVar4 != 0) goto LAB_008cd438;
    pppuStack_1a0 = &ppuStack_64;
    pppuStack_1a4 = (undefined4 ****)0x8cd3f9;
    pppuVar5 = (undefined4 ***)FUN_009cc7e0();
    if (&ppuStack_4c != pppuVar5) {
      pppuStack_1a0 = (undefined4 ***)0x8cd409;
      FUN_005507b0();
      ppuStack_4c = *pppuVar5;
      puStack_48 = (uint *)pppuVar5[1];
      puStack_44 = (uint *)pppuVar5[2];
      puStack_40 = (uint *)pppuVar5[3];
      uStack_3c = *(undefined8 *)(pppuVar5 + 4);
      pppuVar5[4] = (undefined4 **)0x0;
      pppuVar5[5] = (undefined4 **)0xf;
      *(undefined *)pppuVar5 = 0;
    }
    pppuStack_1a0 = (undefined4 ****)0x8cd433;
    FUN_005507b0();
LAB_008cd4e3:
    if ((int)uStack_3c == 0) goto LAB_008cd4e9;
LAB_008cd4f2:
    cStack_11 = '\x01';
  }
  appuStack_11c[0] = (undefined4 ***)0x0;
  uStack_8._0_1_ = 4;
  if (DAT_01d63008 != '\0') {
    pppuStack_1a0 = (undefined4 ***)param_5;
    pppuStack_1a4 = param_2;
    pppuStack_1a8 = param_4;
    pppuStack_1ac = &ppuStack_cc;
    puStack_1b0 = (uint *)0x8cd52a;
    pppuStack_1a0 = (undefined4 ***)FUN_008d7690();
    uStack_8._0_1_ = 5;
    appuStack_6c[0] = (undefined4 ***)0x0;
    pppuStack_1a4 = (undefined4 ***)0x8cd53e;
    FUN_005880d0();
    appuStack_f4[0] = (undefined4 ***)0x0;
    pppuStack_1a0 = appuStack_6c;
    uStack_8._0_1_ = 7;
    pppuStack_1a4 = (undefined4 ***)0x8cd55b;
    FUN_005880d0();
    pppuStack_1a0 = appuStack_11c;
    pppuStack_1a4 = (undefined4 ***)0x8cd56a;
    FUN_005880d0();
    pppuStack_1a0 = appuStack_f4;
    pppuStack_1a4 = (undefined4 ****)0x8cd57c;
    FUN_005880d0();
    uStack_8._0_1_ = 8;
    if ((((undefined4 ***)appuStack_f4[0] != (undefined4 ***)0x0) &&
        (((uint)appuStack_f4[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_f4[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = appuStack_ec;
      pppuStack_1a0 = (undefined4 ****)0x2;
      pppuStack_1ac = (undefined4 ****)0x8cd5a3;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)appuStack_f4[0] & 0xfffffffe))();
    }
    uStack_8._0_1_ = 9;
    if ((((undefined4 ***)appuStack_6c[0] != (undefined4 ***)0x0) &&
        (((uint)appuStack_6c[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = &ppuStack_64;
      pppuStack_1a0 = (undefined4 ****)0x2;
      pppuStack_1ac = (undefined4 ****)0x8cd5c7;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)appuStack_6c[0] & 0xfffffffe))();
    }
    uStack_8._0_1_ = 10;
    if ((((undefined4 ***)ppuStack_cc != (undefined4 ***)0x0) && (((uint)ppuStack_cc & 1) == 0)) &&
       (*(code **)((uint)ppuStack_cc & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = &ppuStack_c4;
      pppuStack_1a0 = (undefined4 ****)0x2;
      pppuStack_1ac = (undefined4 ****)0x8cd5f1;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)ppuStack_cc & 0xfffffffe))();
    }
    uStack_8._0_1_ = 4;
  }
  uStack_8._0_1_ = 4;
  if (cStack_11 == '\0') {
    appuStack_6c[0] = (undefined4 ***)0x0;
    ppppuVar6 = (undefined4 ****)appuStack_11c;
    if (DAT_01d63008 == '\0') {
      ppppuVar6 = param_4;
    }
    pppuVar5 = *ppppuVar6;
    if (pppuVar5 != (undefined4 ***)0x0) {
      appuStack_6c[0] = pppuVar5;
      if (((uint)pppuVar5 & 1) == 0) {
        pppuStack_1a4 = &ppuStack_64;
        pppuStack_1a0 = (undefined4 ***)0x0;
        pppuStack_1a8 = ppppuVar6 + 2;
        pppuStack_1ac = (undefined4 ****)0x8cd746;
        (**(code **)((uint)pppuVar5 & 0xfffffffe))();
      }
      else {
        ppuStack_64 = ppppuVar6[2];
        ppuStack_60 = ppppuVar6[3];
        ppuStack_5c = ppppuVar6[4];
        ppuStack_58 = ppppuVar6[5];
        uStack_54 = *(undefined8 *)(ppppuVar6 + 6);
      }
    }
    appuStack_f4[0] = (undefined4 ***)0x0;
    pppuStack_1a0 = appuStack_6c;
    uStack_8._0_1_ = 0xf;
    pppuStack_1a4 = (undefined4 ***)0x8cd766;
    FUN_005880d0();
    pppuStack_1a0 = (undefined4 ***)auStack_ac;
    pppuStack_1a4 = (undefined4 ***)0x8cd775;
    FUN_005880d0();
    pppuStack_1a0 = appuStack_f4;
    pppuStack_1a4 = (undefined4 ***)0x8cd787;
    FUN_005880d0();
    uStack_8._0_1_ = 0x10;
    if ((((undefined4 ***)appuStack_f4[0] != (undefined4 ***)0x0) &&
        (((uint)appuStack_f4[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_f4[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = appuStack_ec;
      pppuStack_1a0 = (undefined4 ***)0x2;
      pppuStack_1ac = (undefined4 ***)0x8cd7ae;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)appuStack_f4[0] & 0xfffffffe))();
    }
    uStack_8._0_1_ = 0x11;
    if ((((undefined4 ***)appuStack_6c[0] != (undefined4 ***)0x0) &&
        (((uint)appuStack_6c[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = &ppuStack_64;
      pppuStack_1a0 = (undefined4 ***)0x2;
      pppuStack_1ac = (undefined4 ***)0x8cd7d2;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)appuStack_6c[0] & 0xfffffffe))();
    }
  }
  else {
    if (DAT_01d62fa0 == '\0') {
      ppppuVar6 = (undefined4 ****)appuStack_11c;
      if (DAT_01d63008 == '\0') {
        ppppuVar6 = param_4;
      }
      FUN_0054f510(ppppuVar6);
      uStack_8._0_1_ = 0xd;
      FUN_0054ef60(&ppuStack_4c);
      uStack_8._0_1_ = 4;
      FUN_008bfab0(auStack_1e4,FUN_008c9970);
      FUN_008bd660();
      goto LAB_008cd7d9;
    }
    pppuStack_1a0 = (undefined4 ***)uStack_30;
    ppppuVar6 = (undefined4 ****)appuStack_11c;
    if (DAT_01d63008 == '\0') {
      ppppuVar6 = param_4;
    }
    ppuStack_1bc = (uint **)&ppuStack_4c;
    pppuStack_1c0 = (undefined4 ***)0x8cd633;
    FUN_0054ef60();
    ppuStack_1bc = (uint **)param_7;
    ppuStack_1c4 = &ppuStack_cc;
    puStack_1c8 = (uint *)0x8cd646;
    pppuStack_1c0 = ppppuVar6;
    pppuStack_1a0 = (undefined4 ***)FUN_008d74a0();
    uStack_8._0_1_ = 0xb;
    pppuStack_1a4 = (undefined4 ***)0x8cd656;
    FUN_008c4530();
    uStack_8._0_1_ = 0xc;
    if ((((undefined4 ***)ppuStack_cc != (undefined4 ***)0x0) && (((uint)ppuStack_cc & 1) == 0)) &&
       (*(code **)((uint)ppuStack_cc & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = &ppuStack_c4;
      pppuStack_1a0 = (undefined4 ***)0x2;
      pppuStack_1ac = (undefined4 ***)0x8cd67d;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)ppuStack_cc & 0xfffffffe))();
    }
  }
  uStack_8._0_1_ = 4;
LAB_008cd7d9:
  pppuStack_1a0 = (undefined4 ***)param_8;
  puStack_1b0 = auStack_ac;
  pppuStack_1a4 = param_7;
  pppuStack_1a8 = param_6;
  pppuStack_1ac = (undefined4 ***)param_5;
  ppuStack_1b4 = &puStack_2c;
  ppuStack_1b8 = param_3;
  pppuStack_1c0 = apppuStack_8c;
  ppuStack_1bc = (uint **)0x1;
  ppuStack_1c4 = (undefined4 **)0x8cd809;
  iVar4 = FUN_008d7910();
  if (iVar4 == 1) {
    if (puStack_2c == (uint *)0x0) {
      pppuStack_1a0 = param_7;
      auStack_d4[0] = 0;
      pppuStack_1a4 = param_1;
      if (auStack_ac[0] != 0) {
        auStack_d4[0] = auStack_ac[0];
        if ((auStack_ac[0] & 1) == 0) {
          ppuStack_1cc = &ppuStack_cc;
          puStack_1c8 = (uint *)0x0;
          ppuStack_1d0 = &ppuStack_a4;
          uStack_1d4 = 0x8cd9e1;
          (**(code **)(auStack_ac[0] & 0xfffffffe))();
        }
        else {
          ppuStack_cc = ppuStack_a4;
          uStack_c8 = uStack_a0;
          ppuStack_c4 = ppuStack_9c;
          uStack_c0 = uStack_98;
          uStack_bc = uStack_94;
        }
      }
      if (iStack_20 != 0) {
        LOCK();
        *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
        UNLOCK();
      }
      uStack_b4 = uStack_24;
      iStack_b0 = iStack_20;
      puStack_1c8 = auStack_d4;
      uStack_8._0_1_ = 0x13;
      ppuStack_1cc = (undefined4 **)0x8cda2b;
      FUN_008c1490();
      puStack_1c8 = (uint *)auStack_194;
      uStack_8._0_1_ = 0x14;
      ppuStack_1c4 = (undefined4 **)0x0;
      ppuStack_1cc = (undefined4 **)0x8cda47;
      FUN_008c1490();
      puStack_1c8 = (uint *)auStack_16c;
      uStack_8._0_1_ = 0x15;
      ppuStack_1cc = (undefined4 **)0x8cda5d;
      FUN_008c1490();
      puStack_1c8 = (uint *)auStack_144;
      uStack_8._0_1_ = 0x16;
      ppuStack_1cc = (undefined4 **)0x8cda73;
      FUN_008c1490();
      puStack_1c8 = (uint *)auStack_fc;
      uStack_8._0_1_ = 0x17;
      ppuStack_1cc = (undefined4 **)0x8cda83;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        puStack_1c8 = (uint *)auStack_fc;
        ppuStack_1cc = (undefined4 **)0x8cda99;
        FUN_008c1490();
        puStack_1c8 = (uint *)0x28;
        uStack_8._0_1_ = 0x18;
        ppuStack_1cc = (undefined4 **)0x8cdaa4;
        iVar4 = FUN_01674e20();
        uStack_8._0_1_ = 0x19;
        if (iVar4 == 0) {
          ppuStack_1bc = (uint **)0x0;
        }
        else {
          puStack_1c8 = (uint *)auStack_74;
          ppuStack_1cc = (undefined4 **)0x8cdabd;
          ppuStack_1bc = (uint **)FUN_008c1490();
        }
        puStack_1c8 = (uint *)0x8cdacc;
        FUN_008c3670();
        puStack_1c8 = (uint *)0x8cdad7;
        FUN_008c3670();
        bVar1 = true;
      }
      else {
        puStack_1c8 = (uint *)0x8cdae8;
        FUN_008c3670();
        bVar1 = false;
      }
      puStack_1c8 = (uint *)0x8cdaf7;
      FUN_008c3670();
      ppuStack_1c4 = (undefined4 **)&PTR_FUN_0192992c;
      if (!bVar1) {
        ppuStack_1c4 = (undefined4 **)0x0;
      }
      puStack_1c8 = (uint *)0x8cdb11;
      FUN_008c3670();
      puStack_1c8 = (uint *)0x8cdb1c;
      FUN_008c3670();
      uStack_8._0_1_ = 4;
      puStack_1c8 = (uint *)0x8cdb2b;
      FUN_008c3670();
      puStack_1c8 = (uint *)0x8cdb30;
      FUN_00d1bff0();
    }
    else {
      pcStack_1c = (char *)0x0;
      ppuStack_18 = (undefined4 ***)0x0;
      uStack_8._0_1_ = 0x12;
      pppuStack_1a8 = param_7;
      pppuStack_1a4 = (undefined4 ***)0x0;
      pppuStack_1a0 = (undefined4 ***)0x0;
      if (puStack_28 != (undefined4 *)0x0) {
        LOCK();
        puStack_28[1] = puStack_28[1] + 1;
        UNLOCK();
      }
      puStack_1b0 = puStack_2c;
      ppuStack_1b4 = (uint **)0x1;
      pppuStack_1ac = (undefined4 ***)puStack_28;
      ppuStack_1bc = (uint **)auStack_ac;
      pppuStack_1c0 = (undefined4 ****)0x8cd97d;
      ppuStack_1b8 = param_1;
      FUN_00d1bdb0();
    }
  }
  else if (iVar4 == 2) {
    pppuStack_1a0 = (undefined4 ***)0x18;
    pppuStack_1a4 = (undefined4 ***)0x8cd822;
    puVar7 = (undefined4 *)FUN_01674e20();
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7[1] = 1;
      pppuStack_1a0 = (undefined4 ***)(puVar7 + 4);
      puVar7[2] = 1;
      *puVar7 = std::_Ref_count_obj<class_std::runtime_error>::vftable;
      puVar7[3] = std::exception::vftable;
      *(undefined8 *)pppuStack_1a0 = 0;
      pppuStack_1a4 = (undefined4 ***)&pcStack_1c;
      pcStack_1c = "Temp read failed.";
      ppuStack_18 = (undefined4 **)CONCAT31(ppuStack_18._1_3_,1);
      pppuStack_1a8 = (undefined4 ***)0x8cd868;
      FUN_0170c226();
      puVar7[3] = std::runtime_error::vftable;
    }
    pppuStack_1a4 = (undefined4 ***)(puVar7 + 3);
    uStack_34 = 0;
    uStack_30 = 0;
    pppuStack_1a8 = param_7;
    uStack_8._0_1_ = 0x1b;
    ppuStack_1b4 = (uint **)0x24;
    ppuStack_1b8 = (undefined4 **)0x8cd8a9;
    pppuStack_1a0 = (undefined4 ***)puVar7;
    puVar7 = (undefined4 *)FUN_01674e20();
    uStack_8._0_1_ = 0x1c;
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7[1] = 1;
      puVar7[2] = 1;
      *puVar7 = std::
                _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>
                ::vftable;
      ppuStack_1b4 = (uint **)0x0;
      puVar7[7] = 0;
      puVar7[8] = 0xf;
      ppuStack_1b8 = (undefined4 **)&DAT_018bc9b8;
      *(undefined *)(puVar7 + 3) = 0;
      ppuStack_1bc = (uint **)0x8cd8ed;
      FUN_005542c0();
    }
    puStack_1b0 = puVar7 + 3;
    ppuStack_1b4 = (uint **)0x2;
    ppuStack_1bc = (uint **)auStack_ac;
    uStack_8._0_1_ = 0x1a;
    pppuStack_1c0 = (undefined4 ****)0x8cd913;
    ppuStack_1b8 = param_1;
    pppuStack_1ac = (undefined4 ***)puVar7;
    FUN_00d1bdb0();
  }
  uStack_8._0_1_ = 0x1d;
  if ((undefined4 ***)appuStack_11c[0] != (undefined4 ***)0x0) {
    if ((((uint)appuStack_11c[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_11c[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = (undefined4 ***)apuStack_114;
      pppuStack_1a0 = (undefined4 ***)0x2;
      pppuStack_1ac = (undefined4 ***)0x8cdb5a;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)((uint)appuStack_11c[0] & 0xfffffffe))();
    }
    appuStack_11c[0] = (undefined4 ***)0x0;
  }
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_3c._4_4_) {
    pppuStack_1a0 = (undefined4 ***)(uStack_3c._4_4_ + 1);
    pppuVar5 = (undefined4 ***)ppuStack_4c;
    if (0xfff < pppuStack_1a0) {
      pppuVar5 = (undefined4 ***)ppuStack_4c[-1];
      pppuStack_1a0 = (undefined4 ***)(uStack_3c._4_4_ + 0x24);
      if (0x1f < (uint)((int)ppuStack_4c + (-4 - (int)pppuVar5))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_1a0 = (undefined4 ***)0x8cdc25;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    pppuStack_1a8 = (undefined4 ***)0x8cdb9c;
    pppuStack_1a4 = pppuVar5;
    FUN_01674ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  if (auStack_ac[0] != 0) {
    if (((auStack_ac[0] & 1) == 0) && (*(code **)(auStack_ac[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_1a8 = &ppuStack_a4;
      pppuStack_1a0 = (undefined4 ***)0x2;
      pppuStack_1ac = (undefined4 ***)0x8cdbc6;
      pppuStack_1a4 = pppuStack_1a8;
      (**(code **)(auStack_ac[0] & 0xfffffffe))();
    }
    auStack_ac[0] = 0;
  }
  pppuStack_1a0 = (undefined4 ***)0x8cdbdb;
  FUN_0056b650();
  if (0xf < uStack_78) {
    pppuStack_1a0 = (undefined4 ***)(uStack_78 + 1);
    ppppuVar6 = (undefined4 ****)apppuStack_8c[0];
    if (0xfff < pppuStack_1a0) {
      ppppuVar6 = (undefined4 ****)apppuStack_8c[0][-1];
      pppuStack_1a0 = (undefined4 ***)(uStack_78 + 0x24);
      if (0x1f < (uint)((int)apppuStack_8c[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_1a0 = (undefined4 ***)&UNK_008cdc2a;
        FUN_017167a3();
      }
    }
    pppuStack_1a8 = (undefined4 ***)0x8cdc0b;
    pppuStack_1a4 = ppppuVar6;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15116 ; VA 0x008cdc30 ; FUN_008cdc30 */

undefined * FUN_008cdc30(undefined *param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d62f38 != '\0') {
    uVar1 = GetCurrentProcessId();
    FUN_01675640(param_1,"ContentProvider_%d",uVar1);
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0("ContentProvider",0xf);
  return param_1;
}



/* FUNCTION 15117 ; VA 0x008cdc80 ; FUN_008cdc80 */

int * FUN_008cdc80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [8];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf8c0;
  pvStack_10 = ExceptionList;
  if (DAT_01d62f48 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_008cde70(param_1,param_2,param_3,&DAT_01d62f20,param_4);
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (DAT_01d62fe0 != '\0') {
    iStack_18 = 0;
    iStack_14 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_8 = 3;
    ExceptionList = &pvStack_10;
    cVar3 = FUN_008c8460(param_2,&uStack_30,param_3,param_4);
    if (cVar3 == '\0') {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to load %s",uVar4);
    }
    uVar4 = FUN_008cb0c0(auStack_20,&uStack_30);
    FUN_005587e0(uVar4);
    FUN_00550b30();
    iVar2 = iStack_14;
    iVar1 = iStack_18;
    if (iStack_18 != 0) {
      iStack_18 = 0;
      iStack_14 = 0;
      param_1[1] = iVar2;
      *param_1 = iVar1;
      FUN_0056b650();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to retrieve cache of %s",uVar4);
  }
  ExceptionList = &pvStack_10;
  FUN_008d9340(&iStack_18,param_2,0x41200000,param_3,param_4);
  if (iStack_18 == 0) {
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_8 = 1;
    cVar3 = FUN_008c8460(param_2,&uStack_30,param_3,param_4);
    if (cVar3 == '\0') {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to load %s",uVar4);
    }
    uVar4 = FUN_008cb0c0(auStack_20,&uStack_30);
    FUN_005587e0(uVar4);
    FUN_00550b30();
    if (iStack_18 == 0) {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to retrieve cache of %s",uVar4);
    }
    FUN_0056b650();
  }
  *param_1 = iStack_18;
  param_1[1] = iStack_14;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15118 ; VA 0x008cde70 ; FUN_008cde70 */

uint * FUN_008cde70(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                   undefined4 param_5)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint auStack_68 [2];
  undefined auStack_60 [24];
  int aiStack_48 [5];
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [8];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf900;
  pvStack_10 = ExceptionList;
  if (DAT_01d62f48 == '\0') {
    *param_1 = 0;
    param_1[1] = 0;
    return param_1;
  }
  if (DAT_01d62fe0 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_8 = 6;
    ExceptionList = &pvStack_10;
    cVar2 = FUN_008c8460(param_2,&uStack_30,param_3,param_5);
    if (cVar2 == '\0') {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to load %s",uVar4);
    }
    uVar4 = FUN_008cb0c0(auStack_20,&uStack_30);
    FUN_005587e0(uVar4);
    FUN_00550b30();
    uVar1 = uStack_14;
    uVar6 = uStack_18;
    if (uStack_18 != 0) {
      uStack_18 = 0;
      uStack_14 = 0;
      param_1[1] = uVar1;
      *param_1 = uVar6;
      FUN_0056b650();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to retrieve cache of %s",uVar4);
  }
  ExceptionList = &pvStack_10;
  FUN_008d9600(&uStack_18,param_2,0x41200000,param_3,param_4,param_5);
  auStack_68[0] = uStack_18;
  if (uStack_18 == 0) {
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_0054ef60(param_2);
    uStack_8._0_1_ = 3;
    iVar3 = FUN_008d7910(aiStack_48,2,&DAT_bf800000,&uStack_30,auStack_68,param_3,param_4,0,param_5)
    ;
    uStack_8._0_1_ = 4;
    if (auStack_68[0] != 0) {
      if (((auStack_68[0] & 1) == 0) && (*(code **)(auStack_68[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_68[0] & 0xfffffffe))(auStack_60,auStack_60,2);
      }
      auStack_68[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_34) {
      uVar6 = uStack_34 + 1;
      iVar5 = aiStack_48[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_48[0] + -4);
        uVar6 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    if (iVar3 != 1) {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to load %s",uVar4);
    }
    uVar4 = FUN_008cb0c0(auStack_20,&uStack_30);
    FUN_005587e0(uVar4);
    FUN_00550b30();
    if (uStack_18 == 0) {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Unable to retrieve cache of %s",uVar4);
    }
    FUN_0056b650();
  }
  *param_1 = uStack_18;
  param_1[1] = uStack_14;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15119 ; VA 0x008ce100 ; FUN_008ce100 */

undefined4 *
FUN_008ce100(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_40 [24];
  int aiStack_28 [4];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf920;
  pvStack_10 = ExceptionList;
  aiStack_28[0] = 0;
  aiStack_28[1] = 0;
  aiStack_28[2] = 0;
  aiStack_28[3] = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_008c8460(param_2,aiStack_28,param_3,param_4);
  if (cVar3 != '\0') {
    if (aiStack_28[0] == 0) {
      param_4 = 0x21;
      param_3 = (undefined4 *)FUN_0151a8d0(auStack_40,aiStack_28[2]);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (7 < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      puVar4 = (undefined4 *)FUN_008c07f0(auStack_18,&param_3,&param_4);
      *param_1 = *puVar4;
      uVar5 = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      param_1[1] = uVar5;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_14[1] + -1;
        piStack_14[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      FUN_00550800();
    }
    else {
      puVar4 = (undefined4 *)FUN_008c0870(auStack_18,aiStack_28[0]);
      *param_1 = *puVar4;
      uVar5 = puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      param_1[1] = uVar5;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_14[1] + -1;
        piStack_14[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    FUN_0056b650();
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to load %s",uVar5);
}



/* FUNCTION 15120 ; VA 0x008ce270 ; FUN_008ce270 */

undefined4 * __thiscall FUN_008ce270(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017bf949;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xa0) == 0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0xac) + *(int *)(param_1 + 0x9c) * 4);
  }
  for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
    if (param_2[2] == param_2[1]) {
      FUN_008be0b0(param_2[1],puVar1 + 2);
    }
    else {
      FUN_0054ef60(puVar1 + 2);
      param_2[1] = param_2[1] + 0x18;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15121 ; VA 0x008ce320 ; FUN_008ce320 */

undefined4 FUN_008ce320(undefined4 param_1)

{
  FUN_00d1c200(param_1);
  return param_1;
}



/* FUNCTION 15122 ; VA 0x008ce340 ; FUN_008ce340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined2 * FUN_008ce340(undefined2 *param_1,char param_2)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_68 [24];
  undefined auStack_50 [24];
  undefined4 ***apppuStack_38 [4];
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf9a0;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar5 + 0x34) < DAT_01ee01e4) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee01e4), DAT_01ee01e4 == -1)) {
    FUN_016f3654(&LAB_01881c70);
    FUN_016f37bf(&DAT_01ee01e4);
  }
  if (DAT_01ee01e0 != '\0') {
    puVar6 = &DAT_01d632e8;
    if (0xf < DAT_01d632fc) {
      puVar6 = DAT_01d632e8;
    }
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 10) = 7;
    *param_1 = 0;
    uStack_8 = 0;
    uVar1 = FUN_01686580();
    FUN_01685950(puVar6,0,param_1,uVar1);
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (DAT_01d62f38 == '\0') {
    iStack_28 = 0;
    uStack_24 = 0xf;
    apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
    FUN_005542c0("ContentProvider",0xf);
  }
  else {
    uVar1 = GetCurrentProcessId();
    FUN_01675640(apppuStack_38,"ContentProvider_%d",uVar1);
  }
  uStack_8 = 1;
  ppppuVar3 = apppuStack_38;
  if (0xf < uStack_24) {
    ppppuVar3 = (undefined4 ****)apppuStack_38[0];
  }
  if (param_2 == '\0') {
    if ((*(int *)(iVar5 + 0x34) < DAT_01ee01d8) && (FUN_016f3809(&DAT_01ee01d8), DAT_01ee01d8 == -1)
       ) {
      uStack_8._0_1_ = 3;
      FUN_0153e080(&DAT_01ee01c0,0,ppppuVar3);
      FUN_016f3654(&LAB_018824e0);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ee01d8);
    }
    puVar6 = &DAT_01ee01c0;
  }
  else {
    if ((*(int *)(iVar5 + 0x34) < DAT_01ee01bc) && (FUN_016f3809(&DAT_01ee01bc), DAT_01ee01bc == -1)
       ) {
      uStack_8._0_1_ = 2;
      FUN_0153e080(&DAT_01ee01a4,1,ppppuVar3);
      FUN_016f3654(&LAB_01882480);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ee01bc);
    }
    puVar6 = &DAT_01ee01a4;
  }
  FUN_0054f050(puVar6);
  uStack_8._0_1_ = 5;
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_38[0][-1];
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  iStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  uStack_18 = 0;
  uStack_14 = FUN_01685730();
  piVar2 = (int *)FUN_0168e1c0(auStack_20,auStack_50,&uStack_18);
  if ((*piVar2 != 0) && (*piVar2 != 1)) {
    FUN_008c8270(auStack_50);
    LOCK();
    iVar5 = DAT_01ee01dc;
    if (DAT_01ee01dc == 0) {
      DAT_01ee01dc = 1;
      iVar5 = 0;
    }
    UNLOCK();
    if (iVar5 == 0) {
      puVar6 = (undefined4 *)FUN_005569d0(auStack_68);
      if ((undefined4 **)puVar6 != &DAT_01d632e8) {
        FUN_005507b0();
        DAT_01d632e8 = (undefined4 *)*puVar6;
        uRam01d632ec = puVar6[1];
        uRam01d632f0 = puVar6[2];
        uRam01d632f4 = puVar6[3];
        _DAT_01d632f8 = *(undefined8 *)(puVar6 + 4);
        puVar6[4] = 0;
        puVar6[5] = 0xf;
        *(undefined *)puVar6 = 0;
      }
      FUN_005507b0();
      DAT_01ee01e0 = '\x01';
    }
    FUN_0054f050(auStack_50);
    FUN_00550800();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  uStack_8._0_1_ = 6;
  iStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (iStack_28 != 0) {
    ppppuVar3 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar3 = (undefined4 ****)apppuStack_38[0];
    }
    iVar5 = iStack_28 + (int)ppppuVar3;
    ppppuVar3 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar3 = (undefined4 ****)apppuStack_38[0];
    }
    uVar1 = FUN_01686580();
    FUN_01685950(ppppuVar3,iVar5,param_1,uVar1);
  }
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_38[0][-1];
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  FUN_00550800();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15123 ; VA 0x008ce720 ; FUN_008ce720 */

void * FUN_008ce720(int *param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  void *pvVar3;
  int iVar4;
  uint uVar5;
  undefined **ppuVar6;
  void *pvVar7;
  int aiStack_4c [5];
  uint uStack_38;
  undefined *puStack_34;
  int aiStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = -1;
  puStack_c = &LAB_017bf9c8;
  pvStack_10 = ExceptionList;
  pvVar3 = ExceptionList;
  if (*param_1 != 0) {
    ppuVar6 = &PTR_DAT_01d631e8;
    ExceptionList = &pvStack_10;
    do {
      cVar2 = FUN_00893290(*param_1);
      if (cVar2 != '\0') {
        (**(code **)(**(int **)(*ppuVar6 + 0x34) + 0xc))(aiStack_30,*param_1);
        iStack_8 = 0;
        if (iStack_20 != 0) {
          FUN_0054ef60(aiStack_30);
          puStack_34 = ppuVar6[1];
          iStack_8._0_1_ = 1;
          FUN_008c0130(&piStack_18,aiStack_4c,aiStack_4c);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (0xf < uStack_38) {
            uVar5 = uStack_38 + 1;
            iVar4 = aiStack_4c[0];
            if (0xfff < uVar5) {
              iVar4 = *(int *)(aiStack_4c[0] + -4);
              uVar5 = uStack_38 + 0x24;
              if (0x1f < (aiStack_4c[0] - iVar4) - 4U) goto LAB_008ce8a8;
            }
            FUN_01674ea0(iVar4,uVar5);
          }
        }
        iStack_8 = -1;
        if (0xf < uStack_1c) {
          uVar5 = uStack_1c + 1;
          iVar4 = aiStack_30[0];
          if (0xfff < uVar5) {
            iVar4 = *(int *)(aiStack_30[0] + -4);
            uVar5 = uStack_1c + 0x24;
            if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
LAB_008ce8a8:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar5);
        }
      }
      ppuVar6 = ppuVar6 + 2;
    } while (ppuVar6 != (undefined **)&DAT_01d632d8);
    pvVar3 = (void *)(**(code **)(*(int *)*param_1 + 0x40))(&piStack_18);
    iStack_8 = 2;
    if (piStack_18 != (int *)0x0) {
      pvVar7 = (void *)0x0;
      pvVar3 = (void *)(piStack_18[1] - *piStack_18 >> 3);
      if (pvVar3 != (void *)0x0) {
        do {
          FUN_008ce720(*piStack_18 + (int)pvVar7 * 8,param_2);
          pvVar7 = (void *)((int)pvVar7 + 1);
          pvVar3 = (void *)(piStack_18[1] - *piStack_18 >> 3);
        } while (pvVar7 < pvVar3);
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar4 = *piVar1;
      pvVar3 = (void *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pvVar3 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 15124 ; VA 0x008ce8b0 ; FUN_008ce8b0 */

void FUN_008ce8b0(void)

{
  FUN_00d1c530();
  return;
}



/* FUNCTION 15125 ; VA 0x008ce8c0 ; FUN_008ce8c0 */

undefined4 * __thiscall FUN_008ce8c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  uint *puVar9;
  undefined4 *puVar10;
  undefined4 uStack_1f8;
  int iStack_1f4;
  undefined auStack_1f0 [200];
  undefined4 uStack_128;
  int iStack_124;
  undefined auStack_120 [200];
  undefined auStack_58 [4];
  char cStack_54;
  undefined auStack_50 [4];
  char cStack_4c;
  undefined uStack_48;
  undefined *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined uStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfa19;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    puStack_14[1] = 1;
    puStack_14[2] = 1;
    *puStack_14 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_14[3] = 0;
    puStack_14[4] = 0;
    puStack_14[5] = 0;
  }
  puStack_1c = puStack_14 + 3;
  uStack_8 = 0;
  uStack_48 = 0;
  uStack_20 = 0xb;
  puStack_18 = puStack_14;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_20);
  ppuVar8 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar5;
  }
  puStack_44 = *ppuVar8;
  uStack_40 = 0;
  uStack_3c = 0x3f800000;
  uStack_38 = 0;
  uStack_34 = 0;
  piVar1 = (int *)(param_1 + 0x70);
  uStack_8._0_1_ = 1;
  uStack_2c = 0;
  piStack_30 = piVar1;
  if (piVar1 != (int *)0x0) {
    iVar6 = GetCurrentThreadId();
    puStack_28 = (undefined4 *)(param_1 + 0x74);
    if (*(int *)(param_1 + 0x74) == iVar6) {
      *piVar1 = *piVar1 + 1;
    }
    else {
      FUN_005874f0();
      LOCK();
      *(int *)(param_1 + 0x74) = iVar6;
      UNLOCK();
      *piVar1 = 1;
    }
    puVar4 = puStack_1c;
    uStack_2c = 1;
    puVar10 = *(undefined4 **)(param_1 + 0x80);
    uStack_8._0_1_ = 4;
    for (puVar3 = (undefined4 *)*puVar10; puVar3 != puVar10; puVar3 = (undefined4 *)*puVar3) {
      FUN_00676530(auStack_50,puVar3 + 2,puVar3 + 2);
      if (cStack_4c != '\0') {
        uStack_128 = FUN_0088cb40();
        iStack_124 = 0;
        FUN_0054ef60(puVar3 + 2);
        iStack_124 = FUN_005c9d30();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        if (puVar4[2] == puVar4[1]) {
          FUN_005ca4f0(puVar4[1],&uStack_128);
        }
        else {
          FUN_005caf00(&uStack_128);
          puVar4[1] = puVar4[1] + 0xd0;
        }
        uStack_8._0_1_ = 6;
        if (iStack_124 != 0) {
          (**(code **)(iStack_124 + 8))(auStack_120);
        }
        uStack_8._0_1_ = 4;
      }
    }
    if (*(int *)(iStack_24 + 0x90) == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = *(undefined4 **)(*(int *)(iStack_24 + 0x9c) + *(int *)(iStack_24 + 0x8c) * 4);
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      puVar3 = puVar10 + 2;
      FUN_00676530(auStack_58,puVar3,puVar3);
      if (cStack_54 != '\0') {
        uStack_1f8 = FUN_0088cb40();
        iStack_1f4 = 0;
        FUN_0054ef60(puVar3);
        iStack_1f4 = FUN_005c9d30();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        if (puVar4[2] == puVar4[1]) {
          FUN_005ca4f0(puVar4[1],&uStack_1f8);
        }
        else {
          FUN_005caf00(&uStack_1f8);
          puVar4[1] = puVar4[1] + 0xd0;
        }
        uStack_8._0_1_ = 8;
        if (iStack_1f4 != 0) {
          (**(code **)(iStack_1f4 + 8))(auStack_1f0);
        }
        uStack_8._0_1_ = 4;
      }
    }
    puStack_1c = (undefined4 *)0x0;
    puStack_18 = (undefined4 *)0x0;
    *param_2 = puVar4;
    param_2[1] = puStack_14;
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    *piStack_30 = *piStack_30 + -1;
    if (*piStack_30 == 0) {
      LOCK();
      *puStack_28 = 0;
      UNLOCK();
      puVar9 = (uint *)(piStack_30 + 2);
      LOCK();
      uVar2 = *puVar9;
      *puVar9 = *puVar9 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar9;
        *puVar9 = *puVar9 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar7 = FUN_00554e40();
          SetEvent(uVar7);
        }
      }
    }
    FUN_00612580();
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar7 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar7);
}



/* FUNCTION 15126 ; VA 0x008cebe0 ; FUN_008cebe0 */

undefined4 FUN_008cebe0(undefined4 param_1)

{
  FUN_008ce8c0(param_1);
  return param_1;
}



/* FUNCTION 15127 ; VA 0x008cec00 ; FUN_008cec00 */

undefined4 __thiscall FUN_008cec00(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01f6dd5c);
  uStack_8 = 0;
  FUN_008cec70(param_2,param_1 + 0xb8);
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15128 ; VA 0x008cec70 ; FUN_008cec70 */

undefined4 FUN_008cec70(undefined4 param_1,undefined4 param_2)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018c912c,3);
  uStack_8 = 0;
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151b590(param_1,param_2,ppppuVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_28[0][-1];
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15129 ; VA 0x008ced20 ; FUN_008ced20 */

undefined4 FUN_008ced20(undefined4 param_1,undefined4 param_2)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("assetgame",9);
  uStack_8 = 0;
  ppppuVar1 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0151b590(param_1,param_2,ppppuVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_28[0][-1];
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15130 ; VA 0x008cedd0 ; FUN_008cedd0 */

bool FUN_008cedd0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  code *apcStack_48 [2];
  undefined auStack_40 [24];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf120;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  apcStack_48[0] = (code *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  iVar1 = FUN_008d7910(aiStack_28,0,&DAT_bf800000,0,apcStack_48,param_2,&DAT_01d62f20,0,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (apcStack_48[0] != (code *)0x0) {
    if ((((uint)apcStack_48[0] & 1) == 0) &&
       (*(code **)((uint)apcStack_48[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)apcStack_48[0] & 0xfffffffe))(auStack_40,auStack_40,2);
    }
    apcStack_48[0] = (code *)0x0;
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return iVar1 == 1;
}



/* FUNCTION 15131 ; VA 0x008ceeb0 ; FUN_008ceeb0 */

undefined4 FUN_008ceeb0(undefined param_1)

{
  switch(param_1) {
  case 0x30:
    return 0;
  case 0x31:
    return 1;
  case 0x32:
    return 2;
  case 0x33:
    return 3;
  case 0x34:
    return 4;
  case 0x35:
    return 5;
  case 0x36:
    return 6;
  case 0x37:
    return 7;
  case 0x38:
    return 8;
  case 0x39:
    return 9;
  default:
    return 0xffffffff;
  case 0x41:
  case 0x61:
    return 10;
  case 0x42:
  case 0x62:
    return 0xb;
  case 0x43:
  case 99:
    return 0xc;
  case 0x44:
  case 100:
    return 0xd;
  case 0x45:
  case 0x65:
    return 0xe;
  case 0x46:
  case 0x66:
    return 0xf;
  }
}



/* FUNCTION 15132 ; VA 0x008cefc0 ; FUN_008cefc0 */

void FUN_008cefc0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined auStack_70 [72];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfa50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8 = 0;
  cVar1 = FUN_008cc060(aiStack_28);
  if (cVar1 != '\0') {
    FUN_0054ef60(aiStack_28);
    uStack_8._0_1_ = 1;
    FUN_0054ef60(param_2);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00d1e480(auStack_70);
    FUN_00637950();
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15133 ; VA 0x008cf090 ; FUN_008cf090 */

void FUN_008cf090(void)

{
  FUN_008c5f80();
  return;
}



/* FUNCTION 15134 ; VA 0x008cf0a0 ; FUN_008cf0a0 */

void FUN_008cf0a0(void)

{
  FUN_008c65c0();
  return;
}



/* FUNCTION 15135 ; VA 0x008cf0b0 ; FUN_008cf0b0 */

void FUN_008cf0b0(int *param_1)

{
  undefined4 *puVar1;
  undefined auStack_d4 [200];
  
  puVar1 = *(undefined4 **)(*param_1 + 0x24);
  if (puVar1 != (undefined4 *)0x0) {
    (*(code *)*puVar1)(*param_1 + 0x28,auStack_d4);
  }
  FUN_008c6ce0();
  return;
}



/* FUNCTION 15136 ; VA 0x008cf100 ; FUN_008cf100 */

/* WARNING: Removing unreachable block (ram,0x008cf15d) */
/* WARNING: Removing unreachable block (ram,0x008cf169) */
/* WARNING: Removing unreachable block (ram,0x008cf177) */

undefined4 FUN_008cf100(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c4f80(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15137 ; VA 0x008cf190 ; FUN_008cf190 */

void FUN_008cf190(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  iVar2 = *param_1;
  uVar3 = *(undefined4 *)(iVar2 + 0x20);
  if (*(int *)(iVar2 + 0x38) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x38) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = *(undefined4 *)(iVar2 + 0x34);
  uVar5 = *(undefined4 *)(iVar2 + 0x38);
  if (*(int *)(iVar2 + 0x30) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x30) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = *(undefined4 *)(iVar2 + 0x2c);
  uVar7 = *(undefined4 *)(iVar2 + 0x30);
  if (*(int *)(iVar2 + 0x28) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x28) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008c6d70(uVar3,*(undefined4 *)(iVar2 + 0x24),*(undefined4 *)(iVar2 + 0x28),uVar6,uVar7,uVar4,
               uVar5);
  return;
}



/* FUNCTION 15138 ; VA 0x008cf220 ; FUN_008cf220 */

int FUN_008cf220(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfa68;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490();
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_0054ef60(iVar2 + 8);
    iVar3 = FUN_008c7030();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15139 ; VA 0x008cf2b0 ; FUN_008cf2b0 */

/* WARNING: Removing unreachable block (ram,0x008cf317) */
/* WARNING: Removing unreachable block (ram,0x008cf325) */
/* WARNING: Removing unreachable block (ram,0x008cf34d) */
/* WARNING: Removing unreachable block (ram,0x008cf335) */

void FUN_008cf2b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008c5520(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15140 ; VA 0x008cf360 ; FUN_008cf360 */

void FUN_008cf360(undefined4 param_1,undefined4 param_2)

{
  FUN_008c59e0(param_2);
  return;
}



/* FUNCTION 15141 ; VA 0x008cf380 ; FUN_008cf380 */

void FUN_008cf380(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar3 = *(int *)(iVar2 + 0x24);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar2 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 8) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008d0520(*(undefined4 *)(iVar2 + 4),*(undefined4 *)(iVar2 + 8),iVar2 + 0xc,iVar3 == 1);
  if (*(char *)(iVar2 + 0x28) != '\0') {
    if (*(uint *)(iVar2 + 0x30) == 0) {
      uVar4 = FUN_0054fda0();
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar4);
    }
    (**(code **)((*(uint *)(iVar2 + 0x30) & 0xfffffffe) + 4))(iVar2 + 0x38);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15142 ; VA 0x008cf420 ; FUN_008cf420 */

void FUN_008cf420(undefined4 param_1,undefined4 param_2)

{
  FUN_008c5dd0(param_2);
  return;
}



/* FUNCTION 15143 ; VA 0x008cf440 ; FUN_008cf440 */

int FUN_008cf440(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfa68;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_008f7870();
    FUN_0054ef60(iVar2 + 8);
    FUN_008bd1e0();
    iStack_18 = FUN_0090ca30();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 15144 ; VA 0x008cf4f0 ; FUN_008cf4f0 */

void FUN_008cf4f0(undefined4 param_1,int param_2)

{
  int *piVar1;
  
  if ((-(uint)(param_2 != 0) & param_2 + 0xcU) != 0) {
    piVar1 = (int *)FUN_005c41d0();
    if (*piVar1 != 0) {
      FUN_0054ef60(param_1);
      FUN_008c7030();
    }
  }
  return;
}



/* FUNCTION 15145 ; VA 0x008cf530 ; FUN_008cf530 */

void FUN_008cf530(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined8 uStack_14;
  undefined4 uStack_c;
  
  uStack_c = param_2;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) != 0) {
      uStack_24 = puVar1[4];
      uStack_20 = puVar1[5];
      uStack_1c = puVar1[6];
      uStack_18 = puVar1[7];
      uStack_14 = *(undefined8 *)(puVar1 + 8);
      (*pcVar2)();
      return;
    }
    (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_24,0);
  }
  (*pcVar2)();
  return;
}



/* FUNCTION 15146 ; VA 0x008cf590 ; FUN_008cf590 */

void FUN_008cf590(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_008c4880(param_2,param_3);
  return;
}



/* FUNCTION 15147 ; VA 0x008cf5b0 ; FUN_008cf5b0 */

/* WARNING: Removing unreachable block (ram,0x008cf640) */
/* WARNING: Removing unreachable block (ram,0x008cf649) */
/* WARNING: Removing unreachable block (ram,0x008cf658) */
/* WARNING: Removing unreachable block (ram,0x008cf666) */
/* WARNING: Removing unreachable block (ram,0x008cf66f) */
/* WARNING: Removing unreachable block (ram,0x008cf67d) */

undefined4
FUN_008cf5b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c64a0(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15148 ; VA 0x008cf6a0 ; FUN_008cf6a0 */

void FUN_008cf6a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_008c68f0(param_2,param_3,param_4);
  return;
}



/* FUNCTION 15149 ; VA 0x008cf6c0 ; FUN_008cf6c0 */

/* WARNING: Removing unreachable block (ram,0x008cf7a1) */
/* WARNING: Removing unreachable block (ram,0x008cf7aa) */
/* WARNING: Removing unreachable block (ram,0x008cf7b9) */
/* WARNING: Removing unreachable block (ram,0x008cf77b) */
/* WARNING: Removing unreachable block (ram,0x008cf784) */
/* WARNING: Removing unreachable block (ram,0x008cf793) */
/* WARNING: Removing unreachable block (ram,0x008cf7c7) */
/* WARNING: Removing unreachable block (ram,0x008cf7d0) */
/* WARNING: Removing unreachable block (ram,0x008cf7de) */

undefined4
FUN_008cf6c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c4a00(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15150 ; VA 0x008cf800 ; FUN_008cf800 */

/* WARNING: Removing unreachable block (ram,0x008cf8de) */
/* WARNING: Removing unreachable block (ram,0x008cf8e7) */
/* WARNING: Removing unreachable block (ram,0x008cf8f6) */
/* WARNING: Removing unreachable block (ram,0x008cf8b8) */
/* WARNING: Removing unreachable block (ram,0x008cf8c1) */
/* WARNING: Removing unreachable block (ram,0x008cf8d0) */
/* WARNING: Removing unreachable block (ram,0x008cf904) */
/* WARNING: Removing unreachable block (ram,0x008cf90d) */
/* WARNING: Removing unreachable block (ram,0x008cf91b) */

undefined4
FUN_008cf800(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c4c90(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15151 ; VA 0x008cf940 ; FUN_008cf940 */

/* WARNING: Removing unreachable block (ram,0x008cfa21) */
/* WARNING: Removing unreachable block (ram,0x008cfa2a) */
/* WARNING: Removing unreachable block (ram,0x008cfa39) */
/* WARNING: Removing unreachable block (ram,0x008cf9fb) */
/* WARNING: Removing unreachable block (ram,0x008cfa04) */
/* WARNING: Removing unreachable block (ram,0x008cfa13) */
/* WARNING: Removing unreachable block (ram,0x008cfa47) */
/* WARNING: Removing unreachable block (ram,0x008cfa50) */
/* WARNING: Removing unreachable block (ram,0x008cfa5e) */

undefined4
FUN_008cf940(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c4e20(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15152 ; VA 0x008cfa80 ; FUN_008cfa80 */

/* WARNING: Removing unreachable block (ram,0x008cfb61) */
/* WARNING: Removing unreachable block (ram,0x008cfb6a) */
/* WARNING: Removing unreachable block (ram,0x008cfb79) */
/* WARNING: Removing unreachable block (ram,0x008cfb3b) */
/* WARNING: Removing unreachable block (ram,0x008cfb44) */
/* WARNING: Removing unreachable block (ram,0x008cfb53) */
/* WARNING: Removing unreachable block (ram,0x008cfb87) */
/* WARNING: Removing unreachable block (ram,0x008cfb90) */
/* WARNING: Removing unreachable block (ram,0x008cfb9e) */

undefined4
FUN_008cfa80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c50e0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15153 ; VA 0x008cfbc0 ; FUN_008cfbc0 */

/* WARNING: Removing unreachable block (ram,0x008cfca1) */
/* WARNING: Removing unreachable block (ram,0x008cfcaa) */
/* WARNING: Removing unreachable block (ram,0x008cfcb9) */
/* WARNING: Removing unreachable block (ram,0x008cfc7b) */
/* WARNING: Removing unreachable block (ram,0x008cfc84) */
/* WARNING: Removing unreachable block (ram,0x008cfc93) */
/* WARNING: Removing unreachable block (ram,0x008cfcc7) */
/* WARNING: Removing unreachable block (ram,0x008cfcd0) */
/* WARNING: Removing unreachable block (ram,0x008cfcde) */

undefined4
FUN_008cfbc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c5690(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15154 ; VA 0x008cfd00 ; FUN_008cfd00 */

/* WARNING: Removing unreachable block (ram,0x008cfdde) */
/* WARNING: Removing unreachable block (ram,0x008cfde7) */
/* WARNING: Removing unreachable block (ram,0x008cfdf6) */
/* WARNING: Removing unreachable block (ram,0x008cfdb8) */
/* WARNING: Removing unreachable block (ram,0x008cfdc1) */
/* WARNING: Removing unreachable block (ram,0x008cfdd0) */
/* WARNING: Removing unreachable block (ram,0x008cfe04) */
/* WARNING: Removing unreachable block (ram,0x008cfe0d) */
/* WARNING: Removing unreachable block (ram,0x008cfe1b) */

undefined4
FUN_008cfd00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c57f0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15155 ; VA 0x008cfe40 ; FUN_008cfe40 */

/* WARNING: Removing unreachable block (ram,0x008cff21) */
/* WARNING: Removing unreachable block (ram,0x008cff2a) */
/* WARNING: Removing unreachable block (ram,0x008cff39) */
/* WARNING: Removing unreachable block (ram,0x008cfefb) */
/* WARNING: Removing unreachable block (ram,0x008cff04) */
/* WARNING: Removing unreachable block (ram,0x008cff13) */
/* WARNING: Removing unreachable block (ram,0x008cff47) */
/* WARNING: Removing unreachable block (ram,0x008cff50) */
/* WARNING: Removing unreachable block (ram,0x008cff5e) */

undefined4
FUN_008cfe40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c5b20(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15156 ; VA 0x008cff80 ; FUN_008cff80 */

/* WARNING: Removing unreachable block (ram,0x008d00e0) */
/* WARNING: Removing unreachable block (ram,0x008d00e9) */
/* WARNING: Removing unreachable block (ram,0x008d00f8) */
/* WARNING: Removing unreachable block (ram,0x008d00ba) */
/* WARNING: Removing unreachable block (ram,0x008d00c3) */
/* WARNING: Removing unreachable block (ram,0x008d00d2) */
/* WARNING: Removing unreachable block (ram,0x008d0106) */
/* WARNING: Removing unreachable block (ram,0x008d010f) */
/* WARNING: Removing unreachable block (ram,0x008d011d) */

int FUN_008cff80(undefined4 param_1,int param_2,int param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfad0;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  ExceptionList = &pvStack_10;
  if (param_2 != 1) {
    ExceptionList = &pvStack_10;
    if (DAT_01d62f90 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_0054ef60(param_1);
      param_3 = FUN_008c7030();
    }
    if (DAT_01d62f88 == '\0') {
      param_3 = FUN_0086f2f0();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    param_3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      param_3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    param_3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      param_3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_3 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    param_3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      param_3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_3 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 15157 ; VA 0x008d0140 ; FUN_008d0140 */

/* WARNING: Removing unreachable block (ram,0x008d0221) */
/* WARNING: Removing unreachable block (ram,0x008d022a) */
/* WARNING: Removing unreachable block (ram,0x008d0239) */
/* WARNING: Removing unreachable block (ram,0x008d01fb) */
/* WARNING: Removing unreachable block (ram,0x008d0204) */
/* WARNING: Removing unreachable block (ram,0x008d0213) */
/* WARNING: Removing unreachable block (ram,0x008d0247) */
/* WARNING: Removing unreachable block (ram,0x008d0250) */
/* WARNING: Removing unreachable block (ram,0x008d025e) */

undefined4
FUN_008d0140(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c6740(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15158 ; VA 0x008d0280 ; FUN_008d0280 */

/* WARNING: Removing unreachable block (ram,0x008d0361) */
/* WARNING: Removing unreachable block (ram,0x008d036a) */
/* WARNING: Removing unreachable block (ram,0x008d0379) */
/* WARNING: Removing unreachable block (ram,0x008d033b) */
/* WARNING: Removing unreachable block (ram,0x008d0344) */
/* WARNING: Removing unreachable block (ram,0x008d0353) */
/* WARNING: Removing unreachable block (ram,0x008d0387) */
/* WARNING: Removing unreachable block (ram,0x008d0390) */
/* WARNING: Removing unreachable block (ram,0x008d039e) */

undefined4
FUN_008d0280(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008c6ac0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15159 ; VA 0x008d03c0 ; FUN_008d03c0 */

int FUN_008d03c0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bfb10;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  uStack_7 = 0;
  FUN_0054ef60(puVar3 + 2);
  _uStack_8 = CONCAT31(uStack_7,2);
  iVar5 = (*pcVar4)();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15160 ; VA 0x008d0520 ; FUN_008d0520 */

int __thiscall FUN_008d0520(int param_1,int param_2,int *param_3,undefined4 param_4,byte param_5)

{
  int *piVar1;
  void **ppvVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uStack_124;
  int iStack_120;
  uint auStack_11c [50];
  undefined auStack_54 [20];
  int *piStack_40;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bfb56;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed0;
  uStack_8 = 0;
  uStack_7 = 0;
  if (param_2 == 0) {
    iVar5 = 0;
    ppvVar2 = &pvStack_10;
    puStack_14 = &stack0xfffffed0;
    goto joined_r0x008d07f2;
  }
  ExceptionList = &pvStack_10;
  FUN_00d88580(param_2);
  piStack_1c = piStack_40;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_28 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    *piStack_40 = *piStack_40 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  if (piStack_40 != (int *)0x0) {
    if ((piStack_40[2] != 0) && (param_1 != 0)) {
      iVar5 = *(int *)(param_1 + 0x34);
      if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if (((param_1 != 0) &&
          (iVar5 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da))) && (iStack_18 = FUN_0055ea10(), iStack_18 != 0)) {
        puVar4 = (undefined4 *)FUN_01674e20(0x18);
        if (puVar4 == (undefined4 *)0x0) {
          puVar4 = (undefined4 *)0x0;
        }
        else {
          puVar4[1] = 1;
          puVar4[2] = 1;
          *puVar4 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
          puVar4[3] = 0;
          puVar4[4] = 0;
          puVar4[5] = 0;
        }
        uStack_8 = 3;
        puStack_24 = puVar4 + 3;
        puStack_20 = puVar4;
        uStack_124 = FUN_0088d190();
        iStack_120 = 0;
        FUN_0054ef60(param_4);
        iStack_120 = FUN_00630cf0();
        _uStack_8 = CONCAT31(uStack_7,4);
        if (puVar4[5] == puVar4[4]) {
          FUN_005ca4f0(puVar4[4],&uStack_124);
        }
        else {
          FUN_005caf00(&uStack_124);
          puVar4[4] = puVar4[4] + 0xd0;
        }
        uStack_8 = 5;
        if (iStack_120 != 0) {
          (**(code **)(iStack_120 + 8))(auStack_11c);
        }
        uStack_8 = 3;
        uStack_124 = FUN_008da460();
        iStack_120 = 0;
        auStack_11c[0] = param_5 ^ 1;
        iStack_120 = FUN_008da510();
        _uStack_8 = CONCAT31(uStack_7,6);
        if (puVar4[5] == puVar4[4]) {
          FUN_005ca4f0(puVar4[4],&uStack_124);
        }
        else {
          FUN_005caf00(&uStack_124);
          puVar4[4] = puVar4[4] + 0xd0;
        }
        uStack_8 = 7;
        if (iStack_120 != 0) {
          (**(code **)(iStack_120 + 8))(auStack_11c);
        }
        uStack_8 = 8;
        FUN_0094b750(auStack_34,auStack_54,puVar4 + 3);
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_30[1] + -1;
          piStack_30[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            iVar5 = piStack_30[2] + -1;
            piStack_30[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piStack_30 + 4))();
              FUN_00550b30();
              goto LAB_008d07b8;
            }
          }
        }
        FUN_00550b30();
      }
    }
LAB_008d07b8:
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar5 = *piStack_40;
      *piStack_40 = *piStack_40 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piStack_40,0x10);
      }
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  iVar5 = FUN_00d88a30();
  ppvVar2 = (void **)ExceptionList;
joined_r0x008d07f2:
  ExceptionList = ppvVar2;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15161 ; VA 0x008d0787 ; Catch@008d0787 */

undefined * Catch_008d0787(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x28) + 4))();
  FUN_0086f2f0(3,"ContentProvider: Unexpected error while invoking PreloadAsync callback: %s",uVar1)
  ;
  return &DAT_008d07a5;
}



/* FUNCTION 15162 ; VA 0x008d0830 ; FUN_008d0830 */

bool __fastcall FUN_008d0830(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = 0x16;
  if ((uint)param_1[4] < 0x16) {
    uVar2 = param_1[4];
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  iVar1 = FUN_0055c2d0(param_1,uVar2,"rbxencryptedassetid://",0x16);
  return iVar1 == 0;
}



/* FUNCTION 15163 ; VA 0x008d0860 ; FUN_008d0860 */

void FUN_008d0860(void)

{
  FUN_00d1c6e0();
  return;
}



/* FUNCTION 15164 ; VA 0x008d0870 ; FUN_008d0870 */

bool FUN_008d0870(int param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_48 [24];
  undefined uStack_30;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfb70;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0058eea0(&DAT_018c39ac,0);
  if (iVar3 == 0) {
    ExceptionList = pvStack_10;
    return true;
  }
  iVar3 = FUN_0058eea0("https://",0);
  if (iVar3 == 0) {
    ExceptionList = pvStack_10;
    return true;
  }
  iVar3 = FUN_0058eea0("rbxasset://",0);
  if (iVar3 == 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = 0;
    FUN_005542c0("rbxasset://",0xb);
    bVar1 = true;
    cStack_11 = '\x01';
    if (*(uint *)(param_1 + 0x10) <= uStack_20) goto LAB_008d08fc;
  }
  else {
LAB_008d08fc:
    cStack_11 = '\0';
  }
  if (bVar1) {
    FUN_005507b0();
  }
  bVar1 = false;
  if (cStack_11 != '\0') {
    ExceptionList = pvStack_10;
    return true;
  }
  uVar4 = FUN_0058eea0("rbxassetid://",0);
  if (uVar4 == 0) {
    uStack_1c = 0xf;
    uStack_30 = 0;
    uStack_20 = uVar4;
    FUN_005542c0("rbxassetid://",0xd);
    bVar1 = true;
    cStack_11 = '\x01';
    if (*(uint *)(param_1 + 0x10) <= uStack_20) goto LAB_008d0957;
  }
  else {
LAB_008d0957:
    cStack_11 = '\0';
  }
  if (bVar1) {
    FUN_005507b0();
  }
  bVar1 = false;
  if (cStack_11 != '\0') {
    ExceptionList = pvStack_10;
    return true;
  }
  if (DAT_01d62f98 != '\0') {
    uVar4 = FUN_0058eea0("rbxencryptedassetid://",0);
    if (uVar4 == 0) {
      uStack_1c = 0xf;
      uStack_30 = 0;
      uStack_20 = uVar4;
      FUN_005542c0("rbxencryptedassetid://",0x16);
      bVar1 = true;
      cStack_11 = '\x01';
      if (*(uint *)(param_1 + 0x10) <= uStack_20) goto LAB_008d09bb;
    }
    else {
LAB_008d09bb:
      cStack_11 = '\0';
    }
    if (bVar1) {
      FUN_005507b0();
    }
    if (cStack_11 != '\0') {
      ExceptionList = pvStack_10;
      return true;
    }
  }
  bVar1 = false;
  uVar4 = FUN_0058eea0("rbxthumb://",0);
  if (uVar4 == 0) {
    uStack_1c = 0xf;
    uStack_30 = 0;
    uStack_20 = uVar4;
    FUN_005542c0("rbxthumb://",0xb);
    bVar1 = true;
    cStack_11 = '\x01';
    if (uStack_20 < *(uint *)(param_1 + 0x10)) goto LAB_008d0a1a;
  }
  cStack_11 = '\0';
LAB_008d0a1a:
  if (bVar1) {
    FUN_005507b0();
  }
  if (cStack_11 != '\0') {
    ExceptionList = pvStack_10;
    return true;
  }
  FUN_0054ef60(param_1);
  uStack_8 = 0;
  FUN_009cbbb0(auStack_48);
  uStack_8 = 1;
  cVar2 = FUN_009cc920();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return cVar2 != '\0';
}



/* FUNCTION 15165 ; VA 0x008d0a90 ; FUN_008d0a90 */

int * FUN_008d0a90(int *param_1)

{
  undefined4 *puVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfb97;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008ce270(&uStack_20);
  uStack_8 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puStack_14 = puVar1;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    FUN_008be9f0(uStack_20,uStack_1c,param_1);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15166 ; VA 0x008d0b40 ; FUN_008d0b40 */

void FUN_008d0b40(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined auStack_188 [56];
  undefined auStack_150 [56];
  undefined auStack_118 [56];
  undefined auStack_e0 [56];
  undefined auStack_a8 [56];
  undefined auStack_70 [24];
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined **appuStack_38 [2];
  undefined4 auStack_30 [6];
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfc16;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8._0_1_ = 1;
  uStack_58 = 0;
  if (param_3 != 0) {
    uStack_58 = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_50,0);
    }
    else {
      uStack_50 = param_5;
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_008c0f90(auStack_70);
  uStack_8._0_1_ = 3;
  appuStack_38[0] = (undefined **)0x0;
  FUN_008c0f90(auStack_188);
  uStack_8._0_1_ = 4;
  FUN_008c0f90(auStack_150);
  uStack_8._0_1_ = 5;
  FUN_008c0f90(auStack_118);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_a8);
  if (cVar1 == '\0') {
    FUN_008c0f90(auStack_a8);
    uStack_8._0_1_ = 7;
    puStack_18 = (undefined *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (undefined *)0x0) {
      auStack_30[0] = 0;
    }
    else {
      auStack_30[0] = FUN_008c0f90(auStack_e0);
    }
    FUN_008c3170();
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3170();
    cStack_11 = '\0';
  }
  FUN_008c3170();
  appuStack_38[0] = &PTR_FUN_019298e4;
  if (cStack_11 == '\0') {
    appuStack_38[0] = (undefined **)0x0;
  }
  FUN_008c3170();
  FUN_008c3170();
  FUN_008c3170();
  uStack_8._0_1_ = 9;
  FUN_008cd330(param_1,param_2,appuStack_38,param_10,&DAT_01d62f20,param_11,param_12);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (appuStack_38[0] != (undefined **)0x0) {
    if ((((uint)appuStack_38[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_38[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_38[0] & 0xfffffffe))(auStack_30,auStack_30,2);
    }
    appuStack_38[0] = (undefined **)0x0;
  }
  uStack_8 = 0xb;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15167 ; VA 0x008d0d60 ; FUN_008d0d60 */

void FUN_008d0d60(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined auStack_188 [56];
  undefined auStack_150 [56];
  undefined auStack_118 [56];
  undefined auStack_e0 [56];
  undefined auStack_a8 [56];
  undefined auStack_70 [24];
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined **appuStack_38 [2];
  undefined4 auStack_30 [6];
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfc86;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8._0_1_ = 1;
  uStack_58 = 0;
  if (param_3 != 0) {
    uStack_58 = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_50,0);
    }
    else {
      uStack_50 = param_5;
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_008c0f90(auStack_70);
  uStack_8._0_1_ = 3;
  appuStack_38[0] = (undefined **)0x0;
  FUN_008c0f90(auStack_188);
  uStack_8._0_1_ = 4;
  FUN_008c0f90(auStack_150);
  uStack_8._0_1_ = 5;
  FUN_008c0f90(auStack_118);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_a8);
  if (cVar1 == '\0') {
    FUN_008c0f90(auStack_a8);
    uStack_8._0_1_ = 7;
    puStack_18 = (undefined *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (undefined *)0x0) {
      auStack_30[0] = 0;
    }
    else {
      auStack_30[0] = FUN_008c0f90(auStack_e0);
    }
    FUN_008c3170();
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3170();
    cStack_11 = '\0';
  }
  FUN_008c3170();
  appuStack_38[0] = &PTR_FUN_019298f4;
  if (cStack_11 == '\0') {
    appuStack_38[0] = (undefined **)0x0;
  }
  FUN_008c3170();
  FUN_008c3170();
  FUN_008c3170();
  uStack_8._0_1_ = 9;
  FUN_008cd330(param_1,param_2,appuStack_38,param_10,&DAT_01d62f20,param_11,param_12);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (appuStack_38[0] != (undefined **)0x0) {
    if ((((uint)appuStack_38[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_38[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_38[0] & 0xfffffffe))(auStack_30,auStack_30,2);
    }
    appuStack_38[0] = (undefined **)0x0;
  }
  uStack_8 = 0xb;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15168 ; VA 0x008d0f80 ; FUN_008d0f80 */

undefined4 __thiscall
FUN_008d0f80(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 *param_7,undefined4 *param_8,undefined4 param_9,
            undefined4 ******param_10)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined4 *****pppppuVar8;
  uint uVar9;
  code *pcVar10;
  undefined4 *****pppppuStack_194;
  undefined4 *****pppppuStack_190;
  undefined4 ****ppppuStack_18c;
  undefined auStack_17c [120];
  undefined auStack_104 [72];
  int aiStack_bc [5];
  uint uStack_a8;
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  undefined auStack_8c [8];
  undefined4 ***apppuStack_84 [6];
  undefined4 ****ppppuStack_6c;
  undefined uStack_68;
  int iStack_64;
  uint auStack_60 [2];
  undefined4 *****pppppuStack_58;
  undefined **ppuStack_54;
  undefined auStack_50 [4];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  code *apcStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****appppuStack_28 [3];
  undefined4 ****ppppuStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bfd1a;
  pvStack_10 = ExceptionList;
  ppppuStack_18c = *(undefined4 *****)(param_1 + 0x148);
  pppppuStack_190 = (undefined4 *****)(param_1 + 0x130);
  if (0xf < *(uint *)(param_1 + 0x144)) {
    pppppuStack_190 = (undefined4 *****)*pppppuStack_190;
  }
  pppppuStack_194 = (undefined4 *****)0x18c3cd0;
  ExceptionList = &pvStack_10;
  iStack_64 = param_1;
  FUN_01675640(aiStack_bc);
  uStack_8 = 0;
  ppppuStack_18c = (undefined4 ****)0x8d0fde;
  FUN_005caee0();
  uStack_8._0_1_ = 1;
  ppppuStack_18c = (undefined4 ****)param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  pppppuStack_194 = (undefined4 *****)0x2;
  pppppuStack_190 = (undefined4 *****)param_2;
  FUN_0151b780(&DAT_018c1fd8);
  ppppuStack_18c = (undefined4 ****)param_7[4];
  pppppuStack_190 = (undefined4 *****)param_7;
  if (0xf < (uint)param_7[5]) {
    pppppuStack_190 = (undefined4 *****)*param_7;
  }
  pppppuStack_194 = (undefined4 *****)0xc;
  FUN_0151b780("expectedType");
  ppppuStack_18c = (undefined4 ****)param_8[4];
  pppppuStack_190 = (undefined4 *****)param_8;
  if (0xf < (uint)param_8[5]) {
    pppppuStack_190 = (undefined4 *****)*param_8;
  }
  pppppuStack_194 = (undefined4 *****)0xb;
  FUN_0151b780("assetFormat");
  ppppuStack_18c = (undefined4 ****)&DAT_018bdf50;
  if ((char)param_10 == '\0') {
    ppppuStack_18c = (undefined4 ****)&DAT_018bdf48;
  }
  pppppuStack_190 = (undefined4 *****)0x19296d0;
  pppppuStack_194 = (undefined4 *****)0x8d109b;
  FUN_0151b710();
  ppppuStack_18c = (undefined4 ****)&DAT_018bdf48;
  pppppuStack_190 = (undefined4 *****)0x19296e0;
  pppppuStack_194 = (undefined4 *****)0x8d10ad;
  FUN_0151b710();
  ppppuStack_18c = (undefined4 ****)0x0;
  pppppuStack_190 = (undefined4 *****)&DAT_018bc9b8;
  uStack_30 = 0;
  uStack_2c = 0xf;
  apcStack_40[0] = (code *)((uint)apcStack_40[0] & 0xffffff00);
  pppppuStack_194 = (undefined4 *****)0x8d10ce;
  FUN_005542c0();
  ppppuStack_18c = (undefined4 ****)0xb;
  pppppuStack_190 = (undefined4 *****)0x19296f4;
  uStack_8._0_1_ = 2;
  uStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  pppppuStack_194 = (undefined4 *****)0x8d10f3;
  FUN_005542c0();
  ppppuStack_18c = (undefined4 ****)0x4;
  pppppuStack_190 = (undefined4 *****)&DAT_018c71bc;
  uStack_8._0_1_ = 3;
  uStack_48 = 0;
  piStack_44 = (int *)0xf;
  pppppuStack_58 = (undefined4 *****)((uint)pppppuStack_58 & 0xffffff00);
  pppppuStack_194 = (undefined4 *****)0x8d1118;
  FUN_005542c0();
  ppppuStack_18c = (undefined4 ****)apcStack_40;
  uStack_8._0_1_ = 4;
  pppppuStack_190 = (undefined4 *****)apppuStack_84;
  pppppuStack_194 = appppuStack_28;
  FUN_0151bcc0(auStack_17c,&pppppuStack_58,aiStack_bc);
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < piStack_44) {
    ppppuStack_18c = (undefined4 ****)((int)piStack_44 + 1);
    pppppuVar8 = pppppuStack_58;
    if (0xfff < ppppuStack_18c) {
      pppppuVar8 = (undefined4 *****)pppppuStack_58[-1];
      ppppuStack_18c = (undefined4 ****)((int)piStack_44 + 0x24);
      if (0x1f < (uint)((int)pppppuStack_58 + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_18c = (undefined4 ****)0x8d167c;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppppuStack_194 = (undefined4 *****)0x8d1177;
    pppppuStack_190 = pppppuVar8;
    FUN_01674ea0();
  }
  uStack_48 = 0;
  piStack_44 = (int *)&DAT_0000000f;
  pppppuStack_58 = (undefined4 *****)((uint)pppppuStack_58 & 0xffffff00);
  uStack_8._0_1_ = 7;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_14) {
    ppppuStack_18c = (undefined4 ****)(uStack_14 + 1);
    pppppuVar8 = (undefined4 *****)appppuStack_28[0];
    if (0xfff < ppppuStack_18c) {
      pppppuVar8 = (undefined4 *****)appppuStack_28[0][-1];
      ppppuStack_18c = (undefined4 ****)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_18c = (undefined4 ****)0x8d1681;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppppuStack_194 = (undefined4 *****)0x8d11c1;
    pppppuStack_190 = pppppuVar8;
    FUN_01674ea0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
  uStack_8._0_1_ = 8;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_2c) {
    ppppuStack_18c = (undefined4 ****)(uStack_2c + 1);
    pcVar10 = apcStack_40[0];
    if (0xfff < ppppuStack_18c) {
      pcVar10 = *(code **)(apcStack_40[0] + -4);
      ppppuStack_18c = (undefined4 ****)(uStack_2c + 0x24);
      if ((code *)0x1f < apcStack_40[0] + (-4 - (int)pcVar10)) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_18c = (undefined4 ****)0x8d1686;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppppuStack_194 = (undefined4 *****)0x8d120b;
    pppppuStack_190 = (undefined4 *****)pcVar10;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  apcStack_40[0] = (code *)((uint)apcStack_40[0] & 0xffffff00);
  switch(param_3) {
  case 0:
  case 2:
    cVar4 = '\0';
    break;
  case 1:
  case 3:
    cVar4 = '\x01';
    break;
  default:
    cVar4 = param_10._3_1_;
  }
  ppppuStack_18c = (undefined4 ****)auStack_a4;
  pppppuStack_190 = (undefined4 *****)0x8d124c;
  ppppuStack_18c = (undefined4 ****)FUN_0151bb70();
  uStack_8._0_1_ = 9;
  pppppuStack_190 = (undefined4 *****)0x8d125c;
  FUN_0054ef60();
  ppppuStack_18c = (undefined4 ****)param_7;
  uStack_8._0_1_ = 10;
  pppppuStack_190 = (undefined4 *****)0x8d126c;
  FUN_0054ef60();
  ppppuStack_18c = (undefined4 ****)param_8;
  uStack_8._0_1_ = 0xb;
  pppppuStack_190 = (undefined4 *****)0x8d127c;
  FUN_0054ef60();
  uStack_8._0_1_ = 0xd;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_90) {
    ppppuStack_18c = (undefined4 ****)(uStack_90 + 1);
    uVar9 = auStack_a4[0];
    if (0xfff < ppppuStack_18c) {
      uVar9 = *(uint *)(auStack_a4[0] - 4);
      ppppuStack_18c = (undefined4 ****)(uStack_90 + 0x24);
      if (0x1f < (auStack_a4[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_18c = (undefined4 ****)0x8d168b;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppppuStack_194 = (undefined4 *****)0x8d12b7;
    pppppuStack_190 = (undefined4 *****)uVar9;
    FUN_01674ea0();
  }
  uStack_94 = 0;
  uStack_90 = 0xf;
  auStack_a4[0] = auStack_a4[0] & 0xffffff00;
  if (cVar4 == '\0') {
    ppppuStack_18c = (undefined4 ****)0x84;
    pppppuStack_190 = (undefined4 *****)0x8d1362;
    ppppuStack_6c = (undefined4 ****)FUN_01674e20();
    param_10 = (undefined4 ******)ppppuStack_6c;
    if ((undefined4 *****)ppppuStack_6c == (undefined4 *****)0x0) {
      ppppuStack_6c = (undefined4 *****)0x0;
    }
    else {
      *ppppuStack_6c =
           (undefined4 ***)
           std::
           _Associated_state<struct_`private:_enum_RBX::HttpRequestResult___thiscall_RBX::ContentProvider::loadContentFromStudio(class_RBX::ContentId&,enum_RBX::ContentProvider::RequestType,float,struct_RBX::CachedContent*,class_boost::function<void___cdecl(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>)>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,enum_RBX::HttpResultJob,bool)'::`9'::PromiseResult>
           ::vftable;
      ppppuStack_18c = (undefined4 *****)ppppuStack_6c + 5;
      ((undefined4 *****)ppppuStack_6c)[1] = (undefined4 ****)0x1;
      ((undefined4 *****)ppppuStack_6c)[3] = (undefined4 ****)0x0;
      ((undefined4 *****)ppppuStack_6c)[4] = (undefined4 ****)0x0;
      uStack_8._0_1_ = 0xf;
      pppppuStack_190 = (undefined4 *****)0x8d1396;
      FUN_016dfd92();
      pppppuStack_194 = (undefined4 *****)ppppuStack_6c + 7;
      pppppuStack_190 = (undefined4 *****)0x2;
      FUN_016dee4c();
      thunk_FUN_016def21((undefined4 *****)ppppuStack_6c + 0x13);
      *(undefined *)((undefined4 *****)ppppuStack_6c + 0x1d) = 0;
      ((undefined4 *****)ppppuStack_6c)[0x1e] = (undefined4 ****)0x0;
      *(undefined2 *)((undefined4 *****)ppppuStack_6c + 0x1f) = 0;
      *(undefined *)((int)ppppuStack_6c + 0x7e) = 0;
      ((undefined4 *****)ppppuStack_6c)[0x20] = (undefined4 ****)0x0;
    }
    uVar9 = uStack_14;
    uStack_18 = uStack_18 & 0xffffff00;
    uStack_14 = uStack_14 & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x10;
    ppppuStack_1c = ppppuStack_6c;
    if ((undefined4 *****)ppppuStack_6c == (undefined4 *****)0x0) {
      pppppuStack_190 = (undefined4 *****)auStack_8c;
      ppppuStack_18c = (undefined4 ****)0x4;
      pppppuStack_194 = (undefined4 *****)0x8d169e;
      uStack_8._0_1_ = uVar3;
      ppppuStack_18c = (undefined4 ****)FUN_005deb10();
                    /* WARNING: Subroutine does not return */
      pppppuStack_190 = (undefined4 *****)0x8d16a7;
      FUN_016dfe59();
    }
    uStack_14 = CONCAT31(SUB43(uVar9,1),1);
    LOCK();
    ((undefined4 *****)ppppuStack_6c)[1] =
         (undefined4 ****)((int)((undefined4 *****)ppppuStack_6c)[1] + 1);
    UNLOCK();
    uStack_68 = 1;
    param_10 = (undefined4 ******)&ppppuStack_1c;
    ppppuStack_18c = &param_10;
    pppppuStack_190 = (undefined4 *****)0x8d140e;
    cVar4 = FUN_00585a40();
    if (cVar4 == '\0') {
      pppppuStack_58 = param_10;
      auStack_60[0] = 0x192994d;
    }
    else {
      auStack_60[0] = 0;
    }
    ppppuStack_18c = (undefined4 ****)apcStack_40;
    uStack_8._0_1_ = 0x12;
    pppppuStack_190 = (undefined4 *****)0x8d1442;
    uVar5 = FUN_0151bb70();
    ppppuStack_18c = (undefined4 ****)0x0;
    pppppuStack_190 = (undefined4 *****)0x0;
    pppppuStack_194 = (undefined4 ******)0x0;
    uStack_8._0_1_ = 0x13;
    FUN_00d1b340(auStack_104,uVar5,param_4,auStack_60,param_9,4,0);
    uStack_8._0_1_ = 0x12;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x12;
    if (0xf < uStack_2c) {
      ppppuStack_18c = (undefined4 ****)(uStack_2c + 1);
      pcVar10 = apcStack_40[0];
      if (0xfff < ppppuStack_18c) {
        pcVar10 = *(code **)(apcStack_40[0] + -4);
        ppppuStack_18c = (undefined4 ****)(uStack_2c + 0x24);
        if ((code *)0x1f < apcStack_40[0] + (-4 - (int)pcVar10)) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_18c = (undefined4 ****)0x8d16ac;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      pppppuStack_194 = (undefined4 ******)0x8d14a6;
      pppppuStack_190 = (undefined4 *****)pcVar10;
      FUN_01674ea0();
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    apcStack_40[0] = (code *)((uint)apcStack_40[0] & 0xffffff00);
    uStack_8._0_1_ = 0x14;
    if (((auStack_60[0] != 0) && ((auStack_60[0] & 1) == 0)) &&
       (*(code **)(auStack_60[0] & 0xfffffffe) != (code *)0x0)) {
      pppppuStack_194 = &pppppuStack_58;
      ppppuStack_18c = (undefined4 ****)0x2;
      pppppuStack_190 = pppppuStack_194;
      (**(code **)(auStack_60[0] & 0xfffffffe))();
    }
    ppppuStack_18c = (undefined4 ****)&uStack_4c;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    pppppuStack_190 = (undefined4 *****)0x8d14ef;
    FUN_008cc860();
    if (param_5 != 0) {
      ppppuStack_18c = (undefined4 ****)&uStack_48;
      pppppuStack_190 = (undefined4 *****)0x8d14ff;
      FUN_0056ecd0();
    }
    piVar2 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_44[1] + -1;
      piStack_44[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        ppppuStack_18c = (undefined4 ****)0x8d151b;
        (**(code **)*piStack_44)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          ppppuStack_18c = (undefined4 ****)0x8d152b;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x15;
    if ((undefined4 *****)ppppuStack_6c != (undefined4 *****)0x0) {
      LOCK();
      ppppuVar7 = (undefined4 ****)((int)ppppuStack_6c[1] + -1);
      ppppuStack_6c[1] = ppppuVar7;
      UNLOCK();
      if (ppppuVar7 == (undefined4 ****)0x0) {
        if ((undefined4 ****)ppppuStack_6c[0x20] == (undefined4 ****)0x0) {
          ppppuVar7 = (undefined4 ****)*ppppuStack_6c;
          ppppuStack_18c = (undefined4 *****)0x1;
        }
        else {
          ppppuVar7 = (undefined4 ****)*ppppuStack_6c[0x20];
          ppppuStack_18c = ppppuStack_6c;
        }
        pppppuStack_190 = (undefined4 *****)0x8d1556;
        (*(code *)*ppppuVar7)();
      }
    }
    uStack_8._0_1_ = 0x16;
    if (((((undefined4 *****)ppppuStack_1c != (undefined4 *****)0x0) &&
         (((char)uStack_18 == '\0' || (*(char *)(ppppuStack_1c + 0x1d) == '\0')))) &&
        ((undefined4 ****)ppppuStack_1c[0x1e] == (undefined4 ****)0x0)) &&
       (*(char *)(ppppuStack_1c + 0x1f) == '\0')) {
      ppppuStack_18c = (undefined4 ****)&DAT_01ea8f84;
      pppppuStack_190 = (undefined4 *****)FUN_005dbc60;
      pppppuStack_194 = (undefined4 *****)&DAT_01ea8f80;
      iVar6 = FUN_016de3db();
      if (iVar6 == 0) {
        ppppuStack_18c = (undefined4 ****)0x8d16b1;
        FUN_0171d16a();
        goto LAB_008d16b1;
      }
      ppppuStack_18c = (undefined4 ****)&DAT_01ea8f84;
      pppppuStack_190 = (undefined4 *****)0x1;
      pppppuStack_194 = (undefined4 ******)0x8d15ab;
      FUN_005dbdd0();
      ppppuStack_18c = (undefined4 ****)0x0;
      FUN_005dbd80(&ppuStack_54);
      FUN_005dbc80(&pppppuStack_194);
      FUN_008c7b20();
      ppppuStack_18c = (undefined4 ****)auStack_50;
      ppuStack_54 = std::exception::vftable;
      pppppuStack_190 = (undefined4 *****)0x8d15e1;
      FUN_0170c289();
    }
    uStack_8._0_1_ = 0x17;
    uVar5 = uStack_4c;
    if ((undefined4 *****)ppppuStack_1c != (undefined4 *****)0x0) {
      LOCK();
      pppppuVar8 = (undefined4 *****)(ppppuStack_1c + 1);
      ppppuVar7 = *pppppuVar8;
      *pppppuVar8 = (undefined4 ****)((int)*pppppuVar8 + -1);
      UNLOCK();
      if (ppppuVar7 == (undefined4 ****)0x1) {
        if ((undefined4 ****)ppppuStack_1c[0x20] == (undefined4 ****)0x0) {
          ppppuVar7 = (undefined4 ****)*ppppuStack_1c;
          ppppuStack_18c = (undefined4 *****)0x1;
        }
        else {
          ppppuVar7 = (undefined4 ****)*ppppuStack_1c[0x20];
          ppppuStack_18c = ppppuStack_1c;
        }
        pppppuStack_190 = (undefined4 *****)0x8d160e;
        (*(code *)*ppppuVar7)();
      }
    }
  }
  else {
    ppppuStack_18c = (undefined4 ****)apcStack_40;
    pppppuStack_190 = (undefined4 *****)0x8d12ee;
    uVar5 = FUN_0151bb70();
    ppppuStack_18c = (undefined4 ****)0x0;
    pppppuStack_190 = (undefined4 *****)0x0;
    pppppuStack_194 = param_10;
    uStack_8._0_1_ = 0xe;
    FUN_00d1b340(auStack_104,uVar5,param_4,param_6,param_9,4,0);
    if (0xf < uStack_2c) {
      ppppuStack_18c = (undefined4 ****)(uStack_2c + 1);
      pcVar10 = apcStack_40[0];
      if (0xfff < ppppuStack_18c) {
        pcVar10 = *(code **)(apcStack_40[0] + -4);
        ppppuStack_18c = (undefined4 ****)(uStack_2c + 0x24);
        if ((code *)0x1f < apcStack_40[0] + (-4 - (int)pcVar10)) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_18c = (undefined4 ****)0x8d1690;
          FUN_017167a3();
        }
      }
      pppppuStack_194 = (undefined4 ******)0x8d134e;
      pppppuStack_190 = (undefined4 *****)pcVar10;
      FUN_01674ea0();
    }
    uVar5 = 0;
  }
  ppppuStack_18c = (undefined4 ****)0x8d1619;
  FUN_00637950();
  ppppuStack_18c = (undefined4 ****)0x8d1624;
  FUN_0056d9d0();
  ppppuStack_18c = (undefined4 ****)0x8d162c;
  FUN_005507b0();
  if (0xf < uStack_a8) {
    ppppuStack_18c = (undefined4 ****)(uStack_a8 + 1);
    iVar6 = aiStack_bc[0];
    if (0xfff < ppppuStack_18c) {
      iVar6 = *(int *)(aiStack_bc[0] + -4);
      ppppuStack_18c = (undefined4 ****)(uStack_a8 + 0x24);
      if (0x1f < (aiStack_bc[0] - iVar6) - 4U) {
LAB_008d16b1:
                    /* WARNING: Subroutine does not return */
        ppppuStack_18c = (undefined4 ****)&UNK_008d16b6;
        FUN_017167a3();
      }
    }
    pppppuStack_194 = (undefined4 *****)0x8d165f;
    pppppuStack_190 = (undefined4 *****)iVar6;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 15169 ; VA 0x008d16d0 ; FUN_008d16d0 */

void FUN_008d16d0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,uint *param_11,undefined4 *param_12)

{
  uint *puVar1;
  undefined4 *puVar2;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bfd40;
  pvStack_10 = ExceptionList;
  uStack_18 = param_12;
  puStack_1c = param_11;
  param_12 = &uStack_24;
  uStack_24 = 0;
  puStack_20 = (undefined4 *)0x0;
  uStack_28 = param_10;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  param_11 = auStack_48;
  auStack_48[0] = 0;
  ExceptionList = &pvStack_10;
  puVar1 = auStack_48;
  puVar2 = &uStack_24;
  if (param_3 != 0) {
    auStack_48[0] = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_40,0);
      puVar1 = param_11;
      puVar2 = param_12;
    }
    else {
      uStack_40 = param_5;
      uStack_3c = param_6;
      uStack_38 = param_7;
      uStack_34 = param_8;
      uStack_30 = param_9;
      ExceptionList = &pvStack_10;
      puVar1 = auStack_48;
      puVar2 = &uStack_24;
    }
  }
  param_12 = puVar2;
  param_11 = puVar1;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008d17b0(param_1,param_2);
  iStack_8 = 2;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_20 = &param_5;
    uStack_18 = 2;
    uStack_24 = 0x8d1795;
    puStack_1c = puStack_20;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15170 ; VA 0x008d17b0 ; FUN_008d17b0 */

code * FUN_008d17b0(int *param_1,int **param_2,code *param_3,undefined4 param_4,int param_5,
                   undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                   int *param_10,int *param_11,int *param_12,int *param_13,undefined4 param_14)

{
  int iVar1;
  int iVar2;
  int ***pppiVar3;
  undefined4 *puVar4;
  char cVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  int *piVar9;
  int **ppiStack_1d4;
  undefined4 auStack_1d0 [7];
  int *piStack_1b4;
  int *piStack_1b0;
  int *piStack_1ac;
  int *piStack_1a8;
  int *apiStack_19c [14];
  int *apiStack_164 [14];
  int *apiStack_12c [14];
  int *apiStack_f4 [14];
  int *apiStack_bc [14];
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  int iStack_74;
  int iStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  uint uStack_58;
  code *pcStack_50;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  int **ppiStack_30;
  int *piStack_28;
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfe41;
  pvStack_10 = ExceptionList;
  piStack_1a8 = (int *)0x18;
  uStack_8 = 1;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  piStack_1ac = (int *)0x8d17fa;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 2;
  piStack_1c = piVar6;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
    piStack_28 = (int *)0x0;
  }
  else {
    piStack_1a8 = (int *)&cStack_11;
    piVar6[1] = 1;
    piVar6[2] = 1;
    *piVar6 = (int)std::
                   _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>
                   ::vftable;
    piStack_1b0 = (int *)0x8d182e;
    piStack_1ac = (int *)((iVar1 - iVar2) / 0x18);
    piStack_28 = piVar6;
    FUN_008c25b0();
  }
  piStack_7c = piVar6 + 3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piStack_78 = piVar6;
  if (*param_1 == param_1[1]) {
    piVar9 = piVar6 + 1;
    if (piVar6 != (int *)0x0) {
      LOCK();
      *piVar9 = *piVar9 + 1;
      UNLOCK();
    }
    piStack_1b0 = (int *)0x8d1877;
    piStack_1ac = piStack_7c;
    piStack_1a8 = piVar6;
    FUN_008c6c20();
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar9;
      *piVar9 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        piStack_1a8 = (int *)0x8d1892;
        (**(code **)*piVar6)();
        LOCK();
        iVar1 = piVar6[2] + -1;
        piVar6[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_1a8 = (int *)0x8d18a9;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  else {
    piStack_1a8 = (int *)0x10;
    puStack_18 = (undefined4 *)((param_1[1] - *param_1) / 0x18);
    piStack_1ac = (int *)0x8d18cb;
    piStack_1c = (int *)FUN_01674e20();
    if (piStack_1c == (int *)0x0) {
      piVar9 = (int *)0x0;
    }
    else {
      piStack_1c[1] = 1;
      piStack_1c[2] = 1;
      *piStack_1c = (int)std::_Ref_count_obj<unsigned_int>::vftable;
      piStack_1c[3] = (int)puStack_18;
      piVar9 = piStack_1c;
    }
    piStack_84 = piVar9 + 3;
    uStack_20 = 0;
    piStack_6c = (int *)0x0;
    if (param_11 != (int *)0x0) {
      piStack_6c = param_11;
    }
    iVar1 = param_1[1] - *param_1 >> 0x1f;
    piStack_80 = piVar9;
    if ((param_1[1] - *param_1) / 0x18 + iVar1 != iVar1) {
      iStack_24 = 0;
      do {
        piVar6 = piStack_28;
        piStack_1a8 = (int *)param_14;
        piStack_1ac = param_13;
        piStack_64 = piVar9;
        if (param_11 == (int *)0x0) {
          piStack_1c = (int *)(iStack_24 + *param_1);
          piStack_1b0 = param_10;
          puStack_18 = auStack_1d0;
          ppiStack_30 = &piStack_68;
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
          }
          piStack_68 = piVar9 + 3;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          piStack_60 = piStack_28 + 3;
          piStack_5c = piStack_28;
          uStack_8._0_1_ = 0xf;
          pcStack_50 = (code *)0x0;
          uStack_58 = uStack_20;
          puVar4 = auStack_1d0;
          if (param_3 != (code *)0x0) {
            pcStack_50 = param_3;
            if (((uint)param_3 & 1) == 0) {
              ppiStack_1d4 = (int **)0x0;
              (**(code **)((uint)param_3 & 0xfffffffe))(&param_5,&iStack_48);
              puVar4 = puStack_18;
            }
            else {
              iStack_48 = param_5;
              uStack_44 = param_6;
              uStack_40 = param_7;
              uStack_3c = param_8;
              uStack_38 = param_9;
              puVar4 = auStack_1d0;
            }
          }
          puStack_18 = puVar4;
          ppiStack_1d4 = &piStack_68;
          uStack_8._0_1_ = 0x10;
          FUN_008c1620();
          uStack_8._0_1_ = 0x11;
          *puStack_18 = 0;
          ppiStack_1d4 = apiStack_f4;
          FUN_008c1620();
          ppiStack_1d4 = apiStack_12c;
          uStack_8._0_1_ = 0x12;
          FUN_008c1620();
          ppiStack_1d4 = apiStack_164;
          uStack_8._0_1_ = 0x13;
          FUN_008c1620();
          ppiStack_1d4 = apiStack_bc;
          uStack_8._0_1_ = 0x14;
          cVar5 = FUN_00585a40();
          if (cVar5 == '\0') {
            ppiStack_1d4 = apiStack_bc;
            FUN_008c1620();
            ppiStack_1d4 = (int **)0x38;
            uStack_8._0_1_ = 0x15;
            iStack_74 = FUN_01674e20();
            uStack_8._0_1_ = 0x16;
            if (iStack_74 == 0) {
              uVar7 = 0;
            }
            else {
              ppiStack_1d4 = apiStack_19c;
              uVar7 = FUN_008c1620();
            }
            puStack_18[2] = uVar7;
            ppiStack_1d4 = (int **)0x8d1c93;
            FUN_008c3820();
            ppiStack_1d4 = (int **)0x8d1c9e;
            FUN_008c3820();
            cStack_11 = '\x01';
          }
          else {
            ppiStack_1d4 = (int **)0x8d1caf;
            FUN_008c3820();
            cStack_11 = '\0';
          }
          ppiStack_1d4 = (int **)0x8d1cbe;
          FUN_008c3820();
          ppuVar8 = &PTR_FUN_0192990c;
          if (cStack_11 == '\0') {
            ppuVar8 = (undefined **)0x0;
          }
          *puStack_18 = ppuVar8;
          ppiStack_1d4 = (int **)0x8d1cdb;
          FUN_008c3820();
          ppiStack_1d4 = (int **)0x8d1ce6;
          FUN_008c3820();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          ppiStack_1d4 = (int **)0x8d1cf2;
          FUN_008c3820();
          ppiStack_1d4 = param_2;
          FUN_008d0b40(piStack_1c);
        }
        else {
          piStack_1c = (int *)(*param_1 + iStack_24);
          piStack_1b0 = *(int **)(*piStack_6c + uStack_20 * 4);
          ppiStack_30 = &piStack_68;
          piStack_1b4 = param_10;
          puStack_18 = &ppiStack_1d4;
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
          }
          piStack_68 = piVar9 + 3;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
          }
          piStack_60 = piStack_28 + 3;
          piStack_5c = piStack_28;
          uStack_8._0_1_ = 6;
          uStack_58 = uStack_20;
          pcStack_50 = (code *)0x0;
          pppiVar3 = &ppiStack_1d4;
          if (param_3 != (code *)0x0) {
            pcStack_50 = param_3;
            if (((uint)param_3 & 1) == 0) {
              (**(code **)((uint)param_3 & 0xfffffffe))(&param_5,&iStack_48,0);
              pppiVar3 = (int ***)puStack_18;
            }
            else {
              iStack_48 = param_5;
              uStack_44 = param_6;
              uStack_40 = param_7;
              uStack_3c = param_8;
              uStack_38 = param_9;
              pppiVar3 = &ppiStack_1d4;
            }
          }
          puStack_18 = pppiVar3;
          uStack_8._0_1_ = 7;
          FUN_008c1620(&piStack_68);
          uStack_8._0_1_ = 8;
          *puStack_18 = 0;
          FUN_008c1620(apiStack_19c);
          uStack_8._0_1_ = 9;
          FUN_008c1620(apiStack_164);
          uStack_8._0_1_ = 10;
          FUN_008c1620(apiStack_12c);
          uStack_8._0_1_ = 0xb;
          cVar5 = FUN_00585a40(apiStack_bc);
          if (cVar5 == '\0') {
            FUN_008c1620(apiStack_bc);
            uStack_8._0_1_ = 0xc;
            iStack_70 = FUN_01674e20(0x38);
            uStack_8._0_1_ = 0xd;
            if (iStack_70 == 0) {
              uVar7 = 0;
            }
            else {
              uVar7 = FUN_008c1620(apiStack_f4);
            }
            puStack_18[2] = uVar7;
            FUN_008c3820();
            FUN_008c3820();
            cStack_11 = '\x01';
          }
          else {
            FUN_008c3820();
            cStack_11 = '\0';
          }
          FUN_008c3820();
          ppuVar8 = &PTR_FUN_01929904;
          if (cStack_11 == '\0') {
            ppuVar8 = (undefined **)0x0;
          }
          *puStack_18 = ppuVar8;
          FUN_008c3820();
          FUN_008c3820();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_008c3820();
          FUN_008d2130(piStack_1c,param_2);
        }
        uStack_20 = uStack_20 + 1;
        iStack_24 = iStack_24 + 0x18;
      } while (uStack_20 < (uint)((param_1[1] - *param_1) / 0x18));
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar1 = piVar9[1] + -1;
      piVar9[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_1a8 = (int *)0x8d1d4b;
        (**(code **)*piVar9)();
        LOCK();
        iVar1 = piVar9[2] + -1;
        piVar9[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_1a8 = (int *)0x8d1d5c;
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[1] + -1;
      piVar6[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_1a8 = (int *)0x8d1d72;
        (**(code **)*piVar6)();
        LOCK();
        iVar1 = piVar6[2] + -1;
        piVar6[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_1a8 = (int *)0x8d1d82;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  if (((param_3 != (code *)0x0) && (((uint)param_3 & 1) == 0)) &&
     (param_3 = *(code **)((uint)param_3 & 0xfffffffe), param_3 != (code *)0x0)) {
    piStack_1b0 = &param_5;
    piStack_1a8 = (int *)0x2;
    piStack_1b4 = (int *)0x8d1da8;
    piStack_1ac = piStack_1b0;
    param_3 = (code *)(*param_3)();
  }
  piVar6 = param_12;
  if (param_12 != (int *)0x0) {
    LOCK();
    piVar9 = param_12 + 1;
    iVar1 = *piVar9;
    param_3 = (code *)*piVar9;
    *piVar9 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piStack_1a8 = (int *)0x8d1dc8;
      param_3 = (code *)(**(code **)*param_12)();
      LOCK();
      piVar9 = piVar6 + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_1a8 = (int *)0x8d1dd7;
        param_3 = (code *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 15171 ; VA 0x008d1df0 ; FUN_008d1df0 */

void FUN_008d1df0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 **param_12,
                 undefined4 **param_13)

{
  uint *puVar1;
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bfe6f;
  pvStack_10 = ExceptionList;
  uStack_20 = param_13;
  iStack_8 = 0;
  puStack_24 = param_12;
  param_13 = &puStack_2c;
  param_12 = &puStack_2c;
  uStack_30 = 0x18;
  uStack_38 = CONCAT44(0x8d1e2d,(undefined4)uStack_38);
  ExceptionList = &pvStack_10;
  puStack_28 = (undefined4 *)FUN_01674e20();
  iStack_8._0_1_ = 1;
  if (puStack_28 == (undefined4 *)0x0) {
    puStack_28 = (undefined4 *)0x0;
  }
  else {
    uStack_30 = param_11;
    puStack_28[1] = 1;
    puStack_28[2] = 1;
    *puStack_28 = std::
                  _Ref_count_obj<class_std::vector<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const*,class_std::allocator<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const*>_>_const_>
                  ::vftable;
    uStack_38 = CONCAT44(0x8d1e5c,(undefined4)uStack_38);
    param_12 = (undefined4 **)puStack_28;
    FUN_008c24d0();
  }
  puStack_2c = puStack_28 + 3;
  uStack_30 = param_10;
  iStack_8._0_1_ = 2;
  param_12 = (undefined4 **)auStack_50;
  auStack_50[0] = 0;
  puVar1 = auStack_50;
  if (param_3 != 0) {
    auStack_50[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_48,0);
      puVar1 = (uint *)param_12;
    }
    else {
      uStack_48 = param_5;
      uStack_44 = param_6;
      uStack_40 = param_7;
      uStack_3c = param_8;
      uStack_38 = param_9;
      puVar1 = auStack_50;
    }
  }
  param_12 = (undefined4 **)puVar1;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008d17b0(param_1,param_2);
  iStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_5;
    uStack_20 = 2;
    puStack_2c = (undefined4 *)0x8d1ef1;
    puStack_24 = puStack_28;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15172 ; VA 0x008d1f10 ; FUN_008d1f10 */

void FUN_008d1f10(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined auStack_188 [56];
  undefined auStack_150 [56];
  undefined auStack_118 [56];
  undefined auStack_e0 [56];
  undefined auStack_a8 [56];
  undefined auStack_70 [24];
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined **appuStack_38 [2];
  undefined4 auStack_30 [6];
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfee6;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8._0_1_ = 1;
  uStack_58 = 0;
  if (param_3 != 0) {
    uStack_58 = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_50,0);
    }
    else {
      uStack_50 = param_5;
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_008c0f90(auStack_70);
  uStack_8._0_1_ = 3;
  appuStack_38[0] = (undefined **)0x0;
  FUN_008c0f90(auStack_188);
  uStack_8._0_1_ = 4;
  FUN_008c0f90(auStack_150);
  uStack_8._0_1_ = 5;
  FUN_008c0f90(auStack_118);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_a8);
  if (cVar1 == '\0') {
    FUN_008c0f90(auStack_a8);
    uStack_8._0_1_ = 7;
    puStack_18 = (undefined *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (undefined *)0x0) {
      auStack_30[0] = 0;
    }
    else {
      auStack_30[0] = FUN_008c0f90(auStack_e0);
    }
    FUN_008c3170();
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3170();
    cStack_11 = '\0';
  }
  FUN_008c3170();
  appuStack_38[0] = &PTR_FUN_019298fc;
  if (cStack_11 == '\0') {
    appuStack_38[0] = (undefined **)0x0;
  }
  FUN_008c3170();
  FUN_008c3170();
  FUN_008c3170();
  uStack_8._0_1_ = 9;
  FUN_008cd330(param_1,param_2,appuStack_38,param_10,&DAT_01d62f20,param_11,param_12);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (appuStack_38[0] != (undefined **)0x0) {
    if ((((uint)appuStack_38[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_38[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_38[0] & 0xfffffffe))(auStack_30,auStack_30,2);
    }
    appuStack_38[0] = (undefined **)0x0;
  }
  uStack_8 = 0xb;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15173 ; VA 0x008d2130 ; FUN_008d2130 */

void FUN_008d2130(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined8 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13)

{
  char cVar1;
  undefined auStack_188 [56];
  undefined auStack_150 [56];
  undefined auStack_118 [56];
  undefined auStack_e0 [56];
  undefined auStack_a8 [56];
  undefined auStack_70 [24];
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined **appuStack_38 [2];
  undefined4 auStack_30 [6];
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bff56;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_70;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8._0_1_ = 1;
  uStack_58 = 0;
  if (param_3 != 0) {
    uStack_58 = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_50,0);
    }
    else {
      uStack_50 = param_5;
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_008c0f90(auStack_70);
  uStack_8._0_1_ = 3;
  appuStack_38[0] = (undefined **)0x0;
  FUN_008c0f90(auStack_188);
  uStack_8._0_1_ = 4;
  FUN_008c0f90(auStack_150);
  uStack_8._0_1_ = 5;
  FUN_008c0f90(auStack_118);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_a8);
  if (cVar1 == '\0') {
    FUN_008c0f90(auStack_a8);
    uStack_8._0_1_ = 7;
    puStack_18 = (undefined *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (undefined *)0x0) {
      auStack_30[0] = 0;
    }
    else {
      auStack_30[0] = FUN_008c0f90(auStack_e0);
    }
    FUN_008c3170();
    FUN_008c3170();
    cStack_11 = '\x01';
  }
  else {
    FUN_008c3170();
    cStack_11 = '\0';
  }
  FUN_008c3170();
  appuStack_38[0] = &PTR_FUN_019298ec;
  if (cStack_11 == '\0') {
    appuStack_38[0] = (undefined **)0x0;
  }
  FUN_008c3170();
  FUN_008c3170();
  FUN_008c3170();
  uStack_8._0_1_ = 9;
  FUN_008cd330(param_1,param_2,appuStack_38,param_10,param_11,param_12,param_13);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (appuStack_38[0] != (undefined **)0x0) {
    if ((((uint)appuStack_38[0] & 1) == 0) &&
       (*(code **)((uint)appuStack_38[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)appuStack_38[0] & 0xfffffffe))(auStack_30,auStack_30,2);
    }
    appuStack_38[0] = (undefined **)0x0;
  }
  uStack_8 = 0xb;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15174 ; VA 0x008d2350 ; FUN_008d2350 */

void FUN_008d2350(char *param_1,undefined4 *param_2,char *param_3,undefined4 *param_4)

{
  int iVar1;
  bool bVar2;
  char *pcStack_6c;
  char *pcStack_68;
  char *pcStack_64;
  int *piStack_60;
  char *pcStack_5c;
  int *piStack_58;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bff89;
  pvStack_10 = ExceptionList;
  bVar2 = false;
  puStack_18 = (undefined *)0x0;
  if (DAT_01d62f88 == '\0') {
    piStack_58 = param_4;
    pcStack_5c = param_3;
    piStack_60 = param_2;
    pcStack_64 = param_1;
    pcStack_68 = (char *)0x8d2476;
    ExceptionList = &pvStack_10;
    FUN_0086ee70();
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8e != '\0') {
      if (0xf < (uint)param_4[5]) {
        param_4 = (undefined4 *)*param_4;
      }
      if (param_2[10] == 0) {
        piStack_60 = (int *)&DAT_018bc9b8;
        ExceptionList = &pvStack_10;
      }
      else {
        piStack_58 = param_2 + 6;
        if (0xf < (uint)param_2[0xb]) {
          piStack_58 = (int *)*piStack_58;
        }
        piStack_60 = aiStack_48;
        pcStack_5c = " in %s";
        pcStack_64 = (char *)0x8d23c4;
        ExceptionList = &pvStack_10;
        piStack_60 = (int *)FUN_01675640();
        bVar2 = true;
        uStack_8 = 0;
        puStack_18 = (undefined *)0x1;
        if (0xf < (uint)piStack_60[5]) {
          piStack_60 = (int *)*piStack_60;
        }
      }
      pcStack_14 = param_3;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        pcStack_14 = *(char **)param_3;
      }
      if (*(int *)(param_1 + 0x10) == 0) {
        param_1 = "Unknown";
      }
      else if (0xf < *(uint *)(param_1 + 0x14)) {
        param_1 = *(char **)param_1;
      }
      piStack_58 = (int *)0x0;
      pcStack_64 = pcStack_14;
      pcStack_6c = "Asset (%s) \"%s\" load failed%s: %s";
      pcStack_68 = param_1;
      pcStack_5c = (char *)param_4;
      FUN_016773b0(DAT_01d84e8e);
      uStack_8 = 0xffffffff;
      if ((bVar2) && (0xf < uStack_34)) {
        piStack_58 = (int *)(uStack_34 + 1);
        iVar1 = aiStack_48[0];
        if (0xfff < piStack_58) {
          iVar1 = *(int *)(aiStack_48[0] + -4);
          piStack_58 = (int *)(uStack_34 + 0x24);
          if (0x1f < (aiStack_48[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
            piStack_58 = (int *)0x8d2506;
            FUN_017167a3();
          }
        }
        piStack_60 = (undefined4 *)0x8d2462;
        pcStack_5c = (char *)iVar1;
        FUN_01674ea0();
      }
    }
  }
  piStack_58 = (int *)param_3;
  pcStack_5c = (char *)0x8d2482;
  FUN_0054ef60();
  piStack_58 = aiStack_30;
  uStack_8 = 1;
  pcStack_5c = (char *)0x8d2492;
  FUN_009cbbb0();
  uStack_8 = 2;
  if (DAT_01d62f90 != '\0') {
    puStack_18 = (undefined *)&pcStack_6c;
    FUN_0054ef60(aiStack_30);
    FUN_008c7030();
  }
  if (0xf < uStack_1c) {
    piStack_58 = (int *)(uStack_1c + 1);
    iVar1 = aiStack_30[0];
    if (0xfff < piStack_58) {
      iVar1 = *(int *)(aiStack_30[0] + -4);
      piStack_58 = (int *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_58 = (int *)&UNK_008d250b;
        FUN_017167a3();
      }
    }
    piStack_60 = (int *)0x8d24ed;
    pcStack_5c = (char *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15175 ; VA 0x008d2510 ; FUN_008d2510 */

void FUN_008d2510(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008da460();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15176 ; VA 0x008d2550 ; FUN_008d2550 */

void FUN_008d2550(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da84d4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01da84d0;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15177 ; VA 0x008d25d0 ; FUN_008d25d0 */

void FUN_008d25d0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffb2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x80);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_008c0e00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 0x58);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar4 + 0x60,iVar4 + 0x60,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x58) = 0;
        }
        piVar2 = *(int **)(iVar4 + 0x50);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_00637950();
        FUN_01674ea0(iVar4,0x80);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da7c44);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_001710717fc060a31910f05c34f412c2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15178 ; VA 0x008d2760 ; FUN_008d2760 */

void FUN_008d2760(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c0ef0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c30d0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da80a4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_0618238c0fef674e6f9e3e2dd67c8908>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15179 ; VA 0x008d28b0 ; FUN_008d28b0 */

void FUN_008d28b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da7bd4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_0a6d73363ba80a32e7cf09bd8c98d569>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15180 ; VA 0x008d2920 ; FUN_008d2920 */

void FUN_008d2920(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c0f90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7e74);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_1875240deda8ce04eb4f3558eeb465cb>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15181 ; VA 0x008d2a70 ; FUN_008d2a70 */

void FUN_008d2a70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x70);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1030(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3210();
        FUN_01674ea0(iVar2,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7f8c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_1c23b910d8f48fd0a80267d1eeac753d>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15182 ; VA 0x008d2bc0 ; FUN_008d2bc0 */

void FUN_008d2bc0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x40);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1150(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3340();
        FUN_01674ea0(iVar2,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7d24);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_2ef90feb4d436b49aca8b6738d7bbf03>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15183 ; VA 0x008d2d10 ; FUN_008d2d10 */

void FUN_008d2d10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c0f90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7e3c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_49f2aca97d0de76110d3a10ddf272c98>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15184 ; VA 0x008d2e60 ; FUN_008d2e60 */

void FUN_008d2e60(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0037;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da8034);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_4f11479ca8d5c6935f3f2878ac5dbc8c>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15185 ; VA 0x008d2fd0 ; FUN_008d2fd0 */

void FUN_008d2fd0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1220(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3410();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da806c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_5309a4c790218720dccb6ca9edc88e84>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15186 ; VA 0x008d3120 ; FUN_008d3120 */

void FUN_008d3120(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x70);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1030(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3210();
        FUN_01674ea0(iVar2,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7f54);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_58ac792776c6eaf5cecb6908fd97bfc4>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15187 ; VA 0x008d3270 ; FUN_008d3270 */

void FUN_008d3270(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c0f90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7e04);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_5b0a54132ea9b2e12fbda6189485d330>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15188 ; VA 0x008d33c0 ; FUN_008d33c0 */

void FUN_008d33c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da7b9c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_606e7eb98d85d0310233c2a97d8d508a>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15189 ; VA 0x008d3420 ; FUN_008d3420 */

void FUN_008d3420(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x70);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1030(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3210();
        FUN_01674ea0(iVar2,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7f1c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_75e8965e4e9419f58abb7a76a08f85de>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15190 ; VA 0x008d3570 ; FUN_008d3570 */

void FUN_008d3570(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x40);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c12e0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3510();
        FUN_01674ea0(iVar2,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7eac);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_78c0d501d9cff38dca723e714bb0f74f>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15191 ; VA 0x008d36c0 ; FUN_008d36c0 */

void FUN_008d36c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c13b0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c35a0();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7fc4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_7e704d5c80ac81ec0c7439cf9082e0c9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15192 ; VA 0x008d3810 ; FUN_008d3810 */

void FUN_008d3810(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1490(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3670();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7c7c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_8266248fff8898fa823ac56e112f8f9e>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15193 ; VA 0x008d3960 ; FUN_008d3960 */

void FUN_008d3960(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c007f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x68);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1510(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3700();
        FUN_01674ea0(iVar2,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da80dc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_b23a1e96aca35b68754f152def9e2b83>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15194 ; VA 0x008d3ab0 ; FUN_008d3ab0 */

void FUN_008d3ab0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7ffc);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_be3575790304e4de960ed1380b2fbe01>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15195 ; VA 0x008d3b80 ; FUN_008d3b80 */

void FUN_008d3b80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1620(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3820();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7d5c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_bfde38827764dd6ddf4890b173372034>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15196 ; VA 0x008d3cd0 ; FUN_008d3cd0 */

int * FUN_008d3cd0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x008d3d7b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x008d3d0e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1da79f4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c51da5573e36300d4dad23e9e3f6d848>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15197 ; VA 0x008d3d90 ; FUN_008d3d90 */

void FUN_008d3d90(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x70);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1030(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3210();
        FUN_01674ea0(iVar2,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7ee4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_ccd984be212a48ff22838af206d41134>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15198 ; VA 0x008d3ee0 ; FUN_008d3ee0 */

void FUN_008d3ee0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c009f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x78);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_008c1700(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 0x50);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar4 + 0x58,iVar4 + 0x58,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x50) = 0;
        }
        piVar2 = *(int **)(iVar4 + 0x4c);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_00637950();
        FUN_01674ea0(iVar4,0x78);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da7c0c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_cea81c5681fb441066c995c3d1d489f8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15199 ; VA 0x008d4070 ; FUN_008d4070 */

void FUN_008d4070(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c0f90(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3170();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7dcc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_df76bf001c2d2f5eccc1d92e4c2558a8>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15200 ; VA 0x008d41c0 ; FUN_008d41c0 */

void FUN_008d41c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1620(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3820();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7d94);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_e11c634630207011850a844f9ae06da0>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15201 ; VA 0x008d4310 ; FUN_008d4310 */

void FUN_008d4310(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0037;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da7cb4);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_e6aaf13c72c948745920660ba15193f9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15202 ; VA 0x008d4480 ; FUN_008d4480 */

void FUN_008d4480(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da7cec);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_f156a853f96ce34d3828e3b8d8e781b1>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15203 ; VA 0x008d4550 ; FUN_008d4550 */

void FUN_008d4550(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00c2;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0xf0);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_008c1ae0(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (puVar1[9] != 0) {
          ExceptionList = &pvStack_10;
          (**(code **)(puVar1[9] + 8))(puVar1 + 10);
        }
        uVar2 = *puVar1;
        uStack_8 = 2;
        if (uVar2 != 0) {
          if ((uVar2 & 1) == 0) {
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0xf0);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da7a2c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::Reflection::Variant>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15204 ; VA 0x008d46e0 ; FUN_008d46e0 */

void FUN_008d46e0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x48);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_008c1da0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3d70();
        FUN_01674ea0(iVar3,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da8114);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_boost::function<void___cdecl(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>)>_const&,enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>),class_boost::_bi::list7<class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<bool>,class_boost::_bi::value<class_boost::function<void___cdecl(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>)>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,struct_boost::arg<4>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15205 ; VA 0x008d4830 ; FUN_008d4830 */

void FUN_008d4830(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da7ad4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,int),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15206 ; VA 0x008d49a0 ; FUN_008d49a0 */

int FUN_008d49a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint in_stack_00000018;
  undefined4 uStack_90;
  int iStack_8c;
  undefined4 uStack_78;
  undefined *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_54;
  int iStack_50;
  undefined *puStack_4c;
  undefined4 uStack_3c;
  int iStack_38;
  undefined auStack_34 [24];
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0118;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_50 = 0x8d49cd;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870();
  if (iVar3 != 0) {
    puStack_4c = (undefined *)0x1;
    puStack_74 = auStack_1c;
    uStack_78 = 0x8d49eb;
    puVar4 = (undefined4 *)FUN_0060e0c0();
    puStack_14 = &uStack_3c;
    uStack_3c = *puVar4;
    iStack_38 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    puStack_70 = &param_1;
    uStack_8._0_1_ = 2;
    puStack_74 = (undefined *)0x8d4a2a;
    FUN_0054ef60();
    puStack_70 = (undefined4 *)0x0;
    puStack_14 = &uStack_90;
    if (iStack_38 != 0) {
      LOCK();
      *(int *)(iStack_38 + 8) = *(int *)(iStack_38 + 8) + 1;
      UNLOCK();
    }
    uStack_90 = uStack_3c;
    iStack_8c = iStack_38;
    uStack_8._0_1_ = 4;
    FUN_0054ef60(auStack_34);
    uStack_8._0_1_ = 3;
    FUN_008bc9d0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puStack_70 = (undefined4 *)0x8d4a7e;
    FUN_005d11a0();
    puStack_70 = (undefined4 *)0x8d4a85;
    iVar3 = FUN_0090ca30();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_4c = (undefined *)0x8d4a9b;
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    puStack_4c = (undefined *)(in_stack_00000018 + 1);
    iVar3 = param_1;
    if (0xfff < puStack_4c) {
      iVar3 = *(int *)(param_1 + -4);
      puStack_4c = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_4c = &UNK_008d4ae3;
        FUN_017167a3();
      }
    }
    uStack_54 = 0x8d4ac8;
    iStack_50 = iVar3;
    iVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15207 ; VA 0x008d4af0 ; FUN_008d4af0 */

void __thiscall FUN_008d4af0(int param_1,uint param_2)

{
  uint uVar1;
  uint *puVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  uint auStack_74 [2];
  undefined auStack_6c [24];
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0150;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01f6dd5c);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  uStack_24 = uVar4;
  FUN_00d1cc40(param_2);
  param_2 = 0;
  iVar7 = *(int *)(param_1 + 0x94) - *(int *)(param_1 + 0x90);
  iVar9 = iVar7 >> 0x1f;
  if (iVar7 / 0x58 + iVar9 != iVar9) {
    iVar9 = 0;
    do {
      cVar3 = FUN_008d8620(*(int *)(param_1 + 0x90) + iVar9);
      if (cVar3 != '\0') {
        iVar7 = *(int *)(param_1 + 0x90) + iVar9;
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_008be800(iVar7 + 0x58,*(undefined4 *)(param_1 + 0x94),iVar7,uStack_20);
        FUN_008c4380();
        *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + -0x58;
        param_2 = param_2 - 1;
        iVar9 = iVar9 + -0x58;
      }
      param_2 = param_2 + 1;
      iVar9 = iVar9 + 0x58;
      uVar4 = uStack_24;
    } while (param_2 < (uint)((*(int *)(param_1 + 0x94) - *(int *)(param_1 + 0x90)) / 0x58));
  }
  piVar8 = (int *)(param_1 + 0x14);
  uVar5 = *(int *)(param_1 + 0x18) - *piVar8 >> 6;
  if (uVar5 != 0) {
    uStack_18 = 0;
    puStack_14 = (uint *)0x0;
    do {
      iVar9 = *piVar8;
      if (*(int *)((int)puStack_14 + iVar9 + 0x18) != 0) {
        uVar1 = *(uint *)((int)puStack_14 + iVar9 + 0x20);
        if (uVar1 == 0) {
          uVar4 = FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar4);
        }
        (**(code **)((uVar1 & 0xfffffffe) + 4))
                  (iVar9 + 0x28 + (int)puStack_14,*(undefined4 *)((int)puStack_14 + iVar9 + 0x18));
      }
      uStack_18 = uStack_18 + 1;
      puStack_14 = puStack_14 + 0x10;
    } while (uStack_18 < uVar5);
    uStack_18 = 0;
    uStack_20 = 0;
    if (uVar5 != 0) {
      iVar9 = 0;
      iStack_1c = uVar5 << 6;
      do {
        puStack_28 = (undefined4 *)(*piVar8 + iVar9);
        if (puStack_28[6] != 0) {
          uStack_18 = uStack_18 + 1;
          iStack_1c = iStack_1c + -0x40;
          puStack_14 = (uint *)(iStack_1c + *piVar8);
          if (puStack_28 != puStack_14) {
            puVar6 = puStack_14;
            if (0xf < puStack_14[5]) {
              puVar6 = (undefined4 *)*puStack_14;
            }
            FUN_005542c0(puVar6,puStack_14[4]);
          }
          puStack_28[6] = puStack_14[6];
          puVar2 = puStack_28 + 8;
          uVar1 = puStack_14[8];
          auStack_54[0] = 0;
          if (uVar1 != 0) {
            auStack_54[0] = uVar1;
            if ((uVar1 & 1) == 0) {
              puVar6 = puStack_14 + 10;
              puStack_14 = puVar2;
              (**(code **)(uVar1 & 0xfffffffe))(puVar6,&uStack_4c,0);
              puVar2 = puStack_14;
            }
            else {
              uStack_4c = puStack_14[10];
              uStack_48 = puStack_14[0xb];
              uStack_44 = puStack_14[0xc];
              uStack_40 = puStack_14[0xd];
              uStack_3c = puStack_14[0xe];
              uStack_38 = puStack_14[0xf];
            }
          }
          puStack_14 = puVar2;
          if (puStack_14 != auStack_54) {
            auStack_74[0] = 0;
            uStack_8._0_1_ = 3;
            FUN_005880d0(auStack_54);
            FUN_005880d0(puStack_14);
            FUN_005880d0(auStack_74);
            uStack_8._0_1_ = 4;
            if (auStack_74[0] != 0) {
              if (((auStack_74[0] & 1) == 0) &&
                 (*(code **)(auStack_74[0] & 0xfffffffe) != (code *)0x0)) {
                (**(code **)(auStack_74[0] & 0xfffffffe))(auStack_6c,auStack_6c,2);
              }
              auStack_74[0] = 0;
            }
          }
          uStack_8._0_1_ = 5;
          if (auStack_54[0] != 0) {
            if (((auStack_54[0] & 1) == 0) &&
               (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
              (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
            }
            auStack_54[0] = 0;
          }
          uStack_20 = uStack_20 - 1;
          uStack_8._0_1_ = 0;
          iVar9 = iVar9 + -0x40;
        }
        uStack_20 = uStack_20 + 1;
        iVar9 = iVar9 + 0x40;
        uVar4 = uStack_24;
      } while (uStack_20 < uVar5 - uStack_18);
    }
    FUN_008beaf0(uVar5 - uStack_18,piVar8);
  }
  uStack_8 = 6;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15208 ; VA 0x008d4df0 ; FUN_008d4df0 */

void FUN_008d4df0(undefined4 param_1,undefined4 param_2)

{
  FUN_00d1d0f0(param_1,param_2);
  FUN_00f495a0(param_1,param_2);
  FUN_008a4210(param_1,param_2);
  FUN_00f45260(param_1,param_2);
  return;
}



/* FUNCTION 15209 ; VA 0x008d4e30 ; FUN_008d4e30 */

undefined4 * FUN_008d4e30(undefined4 *param_1,undefined4 param_2)

{
  undefined uVar1;
  char cVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined auStack_d8 [24];
  uint uStack_c0;
  uint uStack_bc;
  uint uStack_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined auStack_a8 [16];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  uint uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined auStack_74 [8];
  undefined auStack_6c [8];
  undefined auStack_64 [8];
  undefined auStack_5c [12];
  undefined auStack_50 [8];
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c01c6;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  uStack_14 = 0;
  puVar7 = (undefined4 *)0x0;
  uStack_20 = 0;
  puStack_1c = (undefined4 *)0x0;
  puStack_18 = (undefined4 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_5c,param_2);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_016819d0();
  if (cVar2 == '\0') {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  else {
    FUN_0167eea0(auStack_64,"errors");
    cVar2 = FUN_01681830();
    if (cVar2 == '\0') {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
    }
    else {
      FUN_016810c0(auStack_28);
      FUN_01680ea0(auStack_24);
      FUN_01681140(auStack_30);
      cVar2 = FUN_005e0cd0(auStack_30);
      while (cVar2 != '\0') {
        FUN_0167efb0(auStack_50);
        cVar2 = FUN_01681870();
        if (cVar2 != '\0') {
          FUN_0167eea0(auStack_6c,&DAT_018d4688);
          cVar2 = FUN_01681850();
          if (cVar2 == '\0') {
            uStack_2c = 0xffffffff;
          }
          else {
            uStack_2c = FUN_0167e450();
          }
          FUN_0167eea0(auStack_74,"message");
          cVar2 = FUN_0167e580();
          if (cVar2 == '\0') {
            uStack_38 = 0;
            uStack_34 = 0xf;
            auStack_48[0] = auStack_48[0] & 0xffffff00;
            FUN_005542c0(&DAT_018bc9b8,0);
            puVar3 = auStack_48;
            uVar6 = uStack_14 | 8;
          }
          else {
            uStack_98 = 0;
            uStack_94 = 0xf;
            auStack_a8[0] = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            uStack_14 = uVar6 | 2;
            puVar3 = (uint *)FUN_01681580(auStack_d8,auStack_a8);
            uVar6 = uVar6 | 6;
          }
          uStack_c0 = *puVar3;
          uStack_bc = puVar3[1];
          uStack_b8 = puVar3[2];
          uStack_b4 = puVar3[3];
          uStack_14 = uVar6;
          uStack_b0 = puVar3[4];
          uStack_ac = puVar3[5];
          puVar3[4] = 0;
          puVar3[5] = 0xf;
          *(undefined *)puVar3 = 0;
          uStack_8 = 4;
          if ((uVar6 & 8) != 0) {
            uStack_14 = uVar6 & 0xfffffff7;
            FUN_005507b0();
            uVar6 = uStack_14;
          }
          if ((uVar6 & 4) != 0) {
            uStack_14 = uVar6 & 0xfffffffb;
            FUN_005507b0();
            uVar6 = uStack_14;
          }
          uStack_8._0_1_ = 6;
          if ((uVar6 & 2) != 0) {
            uStack_14 = uVar6 & 0xfffffffd;
            FUN_005507b0();
          }
          FUN_0054ef60(&uStack_c0);
          uStack_90 = uStack_2c;
          uStack_8._0_1_ = 7;
          FUN_0054ef60(auStack_48);
          uStack_8._0_1_ = 6;
          uVar1 = (undefined)uStack_8;
          uStack_8._0_1_ = 6;
          if (0xf < uStack_34) {
            uVar4 = uStack_34 + 1;
            uVar6 = auStack_48[0];
            if (0xfff < uVar4) {
              uVar6 = *(uint *)(auStack_48[0] - 4);
              uVar4 = uStack_34 + 0x24;
              if (0x1f < (auStack_48[0] - uVar6) - 4) goto LAB_008d51ff;
            }
            FUN_01674ea0(uVar6,uVar4);
          }
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = auStack_48[0] & 0xffffff00;
          uStack_8._0_1_ = 8;
          if (puStack_18 == puVar7) {
            FUN_008be2c0(puVar7,&uStack_90);
            uVar6 = uStack_78;
          }
          else {
            *puVar7 = uStack_90;
            puVar7[5] = 0;
            puVar7[6] = 0;
            puVar7[1] = uStack_8c;
            puVar7[2] = uStack_88;
            puVar7[3] = uStack_84;
            puVar7[4] = uStack_80;
            uStack_8c = uStack_8c & 0xffffff00;
            puVar7[5] = uStack_7c;
            puVar7[6] = uStack_78;
            puStack_1c = puVar7 + 7;
            uVar6 = 0xf;
          }
          puVar7 = puStack_1c;
          uStack_8._0_1_ = 6;
          if (0xf < uVar6) {
            uVar5 = uVar6 + 1;
            uVar4 = uStack_8c;
            if (0xfff < uVar5) {
              uVar4 = *(uint *)(uStack_8c - 4);
              uVar5 = uVar6 + 0x24;
              uVar1 = (undefined)uStack_8;
              if (0x1f < (uStack_8c - uVar4) - 4) goto LAB_008d51ff;
            }
            FUN_01674ea0(uVar4,uVar5);
          }
          uStack_8._0_1_ = 1;
          uVar6 = uStack_14;
          if (0xf < uStack_ac) {
            uVar4 = uStack_ac + 1;
            uVar6 = uStack_c0;
            if (0xfff < uVar4) {
              uVar6 = *(uint *)(uStack_c0 - 4);
              uVar4 = uStack_ac + 0x24;
              uVar1 = (undefined)uStack_8;
              if (0x1f < (uStack_c0 - uVar6) - 4) {
LAB_008d51ff:
                uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar6,uVar4);
            uVar6 = uStack_14;
          }
        }
        FUN_0167f070();
        cVar2 = FUN_005e0cd0(auStack_30);
      }
      *param_1 = uStack_20;
      param_1[1] = puVar7;
      param_1[2] = puStack_18;
    }
  }
  uStack_20 = 0;
  puStack_1c = (undefined4 *)0x0;
  puStack_18 = (undefined4 *)0x0;
  FUN_0167ec40();
  FUN_007c4590();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15210 ; VA 0x008d5210 ; FUN_008d5210 */

code * FUN_008d5210(undefined4 *param_1,int param_2,undefined4 param_3,code *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0208;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0088dc10(&uStack_28);
  if (param_2 == 1) {
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (DAT_01ee4204 != '\0') {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      FUN_01677650(DAT_01ee4204,"Parsing content: %s",param_1);
    }
    FUN_00f26000(param_3,uStack_28);
    uStack_8 = 0;
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  uStack_18 = in_stack_00000038;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  if (param_4 == (code *)0x0) {
    uVar4 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar4);
  }
  (**(code **)(((uint)param_4 & 0xfffffffe) + 4))
            (&stack0x00000018,param_2,uStack_28,piStack_24,in_stack_00000038,in_stack_0000003c);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_4 != (code *)0x0) && (((uint)param_4 & 1) == 0)) &&
     (param_4 = *(code **)((uint)param_4 & 0xfffffffe), param_4 != (code *)0x0)) {
    param_4 = (code *)(*param_4)(&stack0x00000018,&stack0x00000018,2);
  }
  piVar3 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000034 + 1;
    iVar2 = *piVar1;
    param_4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_4 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_4 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000003c + 1;
    iVar2 = *piVar1;
    param_4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_4 = (code *)(**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_4 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 15211 ; VA 0x008d5291 ; Catch@008d5291 */

undefined * Catch_008d5291(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  
  if (DAT_01d84e8e != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
    piVar2 = *(int **)(unaff_EBP + 8);
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_01677490(DAT_01d84e8e,"Content failed to parse for %s because %s",piVar2,uVar1,0);
  }
  *(undefined4 *)(unaff_EBP + 0xc) = 2;
  return &DAT_008d52d3;
}



/* FUNCTION 15212 ; VA 0x008d5420 ; FUN_008d5420 */

code * FUN_008d5420(undefined4 *param_1,int param_2,undefined4 param_3,code *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined **ppuVar4;
  code *pcVar5;
  undefined **ppuVar6;
  int *in_stack_00000034;
  undefined **in_stack_00000038;
  int *in_stack_0000003c;
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  undefined *puStack_58;
  undefined **ppuStack_54;
  undefined **ppuStack_50;
  int *piStack_4c;
  undefined auStack_3c [4];
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0250;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb8;
  piStack_4c = &uStack_24;
  uStack_8 = 2;
  ppuStack_50 = (undefined **)0x8d5451;
  ExceptionList = &pvStack_10;
  FUN_0088dc10();
  ppuStack_50 = &puStack_18;
  auStack_3c[0] = 0;
  ppuStack_54 = &boost::lock_error::vftable_meta_ptr;
  puStack_58 = &DAT_018be100;
  puStack_18 = (undefined *)0xb;
  uStack_5c = 0x8d546f;
  ppuVar4 = (undefined **)FUN_00563d40();
  ppuVar6 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar4;
  }
  puStack_38 = *ppuVar6;
  uStack_34 = 0;
  uStack_30 = 0x3f800000;
  uStack_2c = 0;
  uStack_28 = 0;
  if (param_2 != 1) {
    if (in_stack_0000003c != (int *)0x0) {
      LOCK();
      in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
      UNLOCK();
    }
    ppuStack_50 = in_stack_00000038;
    piStack_4c = in_stack_0000003c;
    puStack_18 = auStack_68;
    uStack_8._0_1_ = 7;
    FUN_0060e660(auStack_3c);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_008c6ed0(param_2,uStack_24,piStack_20);
    piStack_4c = (int *)0x8d55af;
    FUN_0056cfd0();
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_4c = (int *)0x8d55c5;
        (**(code **)*piStack_20)();
        LOCK();
        iVar2 = piStack_20[2] + -1;
        piStack_20[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_4c = (int *)0x8d55d5;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (((param_4 != (code *)0x0) && (((uint)param_4 & 1) == 0)) &&
       (param_4 = *(code **)((uint)param_4 & 0xfffffffe), param_4 != (code *)0x0)) {
      ppuStack_54 = (undefined **)&stack0x00000018;
      piStack_4c = (int *)0x2;
      puStack_58 = (undefined *)0x8d55f6;
      ppuStack_50 = ppuStack_54;
      param_4 = (code *)(*param_4)();
    }
    piVar3 = in_stack_00000034;
    if (in_stack_00000034 != (int *)0x0) {
      LOCK();
      piVar1 = in_stack_00000034 + 1;
      iVar2 = *piVar1;
      param_4 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_4c = (int *)0x8d5616;
        (**(code **)*in_stack_00000034)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        param_4 = (code *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          piStack_4c = (int *)0x8d5626;
          param_4 = (code *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = in_stack_0000003c;
    if (in_stack_0000003c != (int *)0x0) {
      LOCK();
      piVar1 = in_stack_0000003c + 1;
      iVar2 = *piVar1;
      param_4 = (code *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_4c = (int *)0x8d563c;
        param_4 = (code *)(**(code **)*in_stack_0000003c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_4c = (int *)0x8d564b;
          param_4 = (code *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_4;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (DAT_01ee4204 != 0) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    ppuStack_54 = (undefined **)(uint)DAT_01ee4204;
    ppuStack_50 = (undefined **)0x1928d28;
    puStack_58 = (undefined *)0x8d54d2;
    piStack_4c = param_1;
    FUN_01677650();
  }
  piStack_4c = (int *)auStack_3c;
  ppuStack_50 = (undefined **)uStack_24;
  ppuStack_54 = (undefined **)param_3;
  puStack_58 = (undefined *)0x8d54e4;
  thunk_FUN_00f26030();
  pcVar5 = (code *)FUN_008d552e();
  return pcVar5;
}



/* FUNCTION 15213 ; VA 0x008d54e9 ; Catch@008d54e9 */

undefined * Catch_008d54e9(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  
  if (DAT_01d84e8e != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
    piVar2 = *(int **)(unaff_EBP + 8);
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_01677490(DAT_01d84e8e,"Content failed to parse for %s because %s",piVar2,uVar1,0);
  }
  *(undefined4 *)(unaff_EBP + 0xc) = 2;
  return &DAT_008d552b;
}



/* FUNCTION 15214 ; VA 0x008d552e ; FUN_008d552e */

code * FUN_008d552e(void)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  code *pcVar6;
  int unaff_EBP;
  undefined4 unaff_ESI;
  undefined auStack_20 [16];
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  undefined4 uStack_4;
  
  *(undefined4 *)(unaff_EBP + -4) = 4;
  *(int **)(unaff_EBP + 0xc) = &iStack_8;
  if (*(int *)(unaff_EBP + 0x40) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_EBP + 0x40) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = *(int *)(unaff_EBP + 0x3c);
  uStack_4 = *(undefined4 *)(unaff_EBP + 0x40);
  *(undefined *)(unaff_EBP + -4) = 7;
  *(undefined **)(unaff_EBP + -0x14) = auStack_20;
  FUN_0060e660(unaff_EBP + -0x38);
  piVar1 = *(int **)(unaff_EBP + -0x1c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_008c6ed0(unaff_ESI,*(undefined4 *)(unaff_EBP + -0x20),piVar1);
  uStack_4 = 0x8d55af;
  FUN_0056cfd0();
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_4 = 0x8d55c5;
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_4 = 0x8d55d5;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  pcVar6 = *(code **)(unaff_EBP + 0x14);
  *(undefined *)(unaff_EBP + -4) = 8;
  if (pcVar6 != (code *)0x0) {
    if ((((uint)pcVar6 & 1) == 0) &&
       (pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe), pcVar6 != (code *)0x0)) {
      iStack_c = unaff_EBP + 0x1c;
      uStack_4 = 2;
      uStack_10 = 0x8d55f6;
      iStack_8 = iStack_c;
      pcVar6 = (code *)(*pcVar6)();
    }
    *(undefined4 *)(unaff_EBP + 0x14) = 0;
  }
  piVar1 = *(int **)(unaff_EBP + 0x38);
  if (piVar1 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piVar1 + 1);
    uVar4 = *puVar2;
    pcVar6 = (code *)*puVar2;
    *puVar2 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      uStack_4 = 0x8d5616;
      (**(code **)*piVar1)();
      LOCK();
      puVar2 = (uint *)(piVar1 + 2);
      uVar4 = *puVar2;
      pcVar6 = (code *)*puVar2;
      *puVar2 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        uStack_4 = 0x8d5626;
        pcVar6 = (code *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(unaff_EBP + 0x40);
  if (piVar1 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piVar1 + 1);
    uVar4 = *puVar2;
    pcVar6 = (code *)*puVar2;
    *puVar2 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      uStack_4 = 0x8d563c;
      pcVar6 = (code *)(**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uStack_4 = 0x8d564b;
        pcVar6 = (code *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return pcVar6;
}



/* FUNCTION 15215 ; VA 0x008d5660 ; FUN_008d5660 */

undefined4 FUN_008d5660(int param_1,uint *param_2,uint param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int extraout_ECX;
  undefined4 *extraout_EDX;
  uint uVar3;
  undefined8 uVar4;
  
  if (param_4[4] != param_3 * 2) {
    return 0xffffffff;
  }
  uVar3 = (uint)param_4[4] >> 1;
  if (uVar3 < param_3) {
    param_3 = uVar3;
  }
  uVar3 = 0;
  *param_2 = param_3;
  if (param_3 != 0) {
    do {
      uVar1 = param_4[5];
      if (0xf < uVar1) {
        param_4 = (undefined4 *)*param_4;
      }
      FUN_008ceeb0(*(undefined *)((int)param_4 + uVar3 * 2));
      puVar2 = extraout_EDX;
      if (0xf < uVar1) {
        puVar2 = (undefined4 *)*extraout_EDX;
      }
      uVar4 = FUN_008ceeb0(*(undefined *)((int)puVar2 + uVar3 * 2 + 1));
      param_4 = (undefined4 *)((ulonglong)uVar4 >> 0x20);
      if (extraout_ECX == -1) {
        return 0xffffffff;
      }
      if ((int)uVar4 == -1) {
        return 0xffffffff;
      }
      *(char *)(uVar3 + param_1) = (char)extraout_ECX * '\x10' + (char)uVar4;
      uVar3 = uVar3 + 1;
    } while (uVar3 < *param_2);
  }
  return 0;
}



/* FUNCTION 15216 ; VA 0x008d56f0 ; FUN_008d56f0 */

/* WARNING: Type propagation algorithm not settling */

code * FUN_008d56f0(undefined4 *param_1,int param_2,int *param_3,code *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  undefined **appuStack_e8 [15];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_9c;
  undefined **ppuStack_98;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c02ca;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff0c;
  uStack_18 = 0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_00563ec0(&puStack_20);
  if (param_2 == 1) {
    uStack_8._0_1_ = 4;
    if (DAT_01ee4204 != '\0') {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      FUN_01677650(DAT_01ee4204,"Got content as string: %s",param_1);
    }
    appuStack_e8[0] = &PTR_018be314;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_18 = 1;
    ppuStack_98 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_9c = 0x48;
    FUN_00554f20(appuStack_e8 + 1,0);
    uStack_8 = 7;
    *(undefined ***)(appuStack_e8[0][1] + (int)appuStack_e8) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)(appuStack_e8[0][1] + (int)&stack0xffffff14) = appuStack_e8[0][1] + -0x50;
    FUN_0054ee60();
    appuStack_e8[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_ac = 0;
    uStack_a8 = 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_0056f130(*(undefined4 *)(*(int *)(*param_3 + 4) + 0x38 + (int)param_3));
    puVar5 = (undefined4 *)FUN_0058c400(aiStack_50);
    if (puStack_20 != puVar5) {
      FUN_005507b0();
      uVar6 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *puStack_20 = *puVar5;
      puStack_20[1] = uVar6;
      puStack_20[2] = uVar2;
      puStack_20[3] = uVar3;
      *(undefined8 *)(puStack_20 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_3c) {
      uVar8 = uStack_3c + 1;
      iVar7 = aiStack_50[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_50[0] + -4);
        uVar8 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
    FUN_00570540();
    uStack_8 = 0;
  }
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    in_stack_0000003c[1] = in_stack_0000003c[1] + 1;
    UNLOCK();
  }
  uStack_18 = in_stack_00000038;
  uStack_2c = in_stack_00000038;
  piStack_28 = in_stack_0000003c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  piStack_30 = piStack_1c;
  uStack_8._0_1_ = 0xb;
  if (param_4 == (code *)0x0) {
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  uStack_2c = 0;
  piStack_28 = (int *)0x0;
  uStack_34 = 0;
  piStack_30 = (int *)0x0;
  (**(code **)(((uint)param_4 & 0xfffffffe) + 4))
            (&stack0x00000018,param_2,puStack_20,piStack_1c,in_stack_00000038,in_stack_0000003c);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar7 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (((param_4 != (code *)0x0) && (((uint)param_4 & 1) == 0)) &&
     (param_4 = *(code **)((uint)param_4 & 0xfffffffe), param_4 != (code *)0x0)) {
    param_4 = (code *)(*param_4)(&stack0x00000018,&stack0x00000018,2);
  }
  piVar4 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000034 + 1;
    iVar7 = *piVar1;
    param_4 = (code *)*piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      param_4 = (code *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        param_4 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = in_stack_0000003c;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000003c + 1;
    iVar7 = *piVar1;
    param_4 = (code *)*piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      param_4 = (code *)(**(code **)*in_stack_0000003c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        param_4 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 15217 ; VA 0x008d589a ; Catch@008d589a */

undefined * Catch_008d589a(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  int *piVar2;
  
  piVar2 = *(int **)(unaff_EBP + 8);
  FUN_008c8430(piVar2);
  if (DAT_01d62f88 == '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x34) + 4))();
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0086f2f0(3,"Content failed to load for %s because %s",piVar2,uVar1);
  }
  *(undefined4 *)(unaff_EBP + 0xc) = 2;
  return &DAT_008d58df;
}



/* FUNCTION 15218 ; VA 0x008d5a30 ; FUN_008d5a30 */

undefined * FUN_008d5a30(void)

{
  return &DAT_01d631a0;
}



/* FUNCTION 15219 ; VA 0x008d5a40 ; FUN_008d5a40 */

void FUN_008d5a40(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  uint in_stack_00000018;
  undefined4 *puStack_54;
  undefined4 uStack_50;
  uint *puStack_4c;
  undefined *puStack_48;
  char *pcStack_44;
  char *pcStack_40;
  undefined4 *puStack_3c;
  uint auStack_34 [2];
  char acStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c02f0;
  pvStack_10 = ExceptionList;
  puStack_3c = (undefined4 *)0x0;
  puStack_14 = (undefined *)&puStack_54;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  FUN_008bcbe0();
  puStack_3c = (undefined4 *)0x1;
  pcStack_40 = (char *)0x0;
  pcStack_44 = (char *)&DAT_01d62f20;
  puStack_48 = &DAT_01d63020;
  puStack_4c = auStack_34;
  iStack_8._0_1_ = 1;
  uStack_50 = 0;
  puStack_54 = (undefined4 *)0x4f000000;
  iVar1 = FUN_008d7910(&param_1,1);
  iStack_8._0_1_ = 2;
  if (((auStack_34[0] != 0) && ((auStack_34[0] & 1) == 0)) &&
     (*(code **)(auStack_34[0] & 0xfffffffe) != (code *)0x0)) {
    pcStack_44 = acStack_2c;
    puStack_3c = (undefined4 *)0x2;
    puStack_48 = (undefined *)0x8d5ad1;
    pcStack_40 = pcStack_44;
    (**(code **)(auStack_34[0] & 0xfffffffe))();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if ((iVar1 != 0) && (iVar1 != 1)) {
    if (DAT_01d62f90 != '\0') {
      puStack_14 = (undefined *)&uStack_50;
      puStack_54 = &param_1;
      FUN_0054ef60();
      puStack_54 = (undefined4 *)0x8d5b05;
      FUN_008c7030();
    }
    if (DAT_01d62f88 == '\0') {
      puStack_3c = &param_1;
      if (0xf < in_stack_00000018) {
        puStack_3c = param_1;
      }
      pcStack_40 = "ContentProvider:Preload() failed for %s";
      pcStack_44 = (char *)0x3;
      puStack_48 = (undefined *)0x8d5b26;
      FUN_0086f2f0();
    }
  }
  if (0xf < in_stack_00000018) {
    puStack_3c = (undefined4 *)(in_stack_00000018 + 1);
    puVar2 = param_1;
    if (0xfff < puStack_3c) {
      puVar2 = (undefined4 *)param_1[-1];
      puStack_3c = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_3c = (undefined4 *)&UNK_008d5b6f;
        FUN_017167a3();
      }
    }
    pcStack_44 = (char *)0x8d5b56;
    pcStack_40 = (char *)puVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15220 ; VA 0x008d5b70 ; FUN_008d5b70 */

void FUN_008d5b70(int *param_1,int *param_2)

{
  int *piVar1;
  undefined **ppuVar2;
  undefined *****pppppuVar3;
  undefined ***pppuVar4;
  int **ppiVar5;
  undefined4 **ppuVar6;
  undefined uVar7;
  char cVar8;
  undefined **ppuVar9;
  undefined *puVar10;
  undefined **ppuVar11;
  int iVar12;
  int *piVar13;
  undefined4 *puVar14;
  undefined *puVar15;
  undefined4 *puVar16;
  undefined *in_stack_0000002c;
  undefined4 *in_stack_00000034;
  undefined4 in_stack_00000038;
  int *in_stack_0000003c;
  int *in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 *in_stack_00000048;
  undefined4 *in_stack_0000004c;
  undefined ***in_stack_00000054;
  undefined *in_stack_00000058;
  undefined **in_stack_0000005c;
  undefined **in_stack_00000060;
  undefined ***in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined **ppuStack_444;
  undefined *puStack_440;
  undefined4 uStack_43c;
  undefined4 *puStack_438;
  undefined ****ppppuStack_434;
  undefined ***pppuStack_430;
  int *piStack_42c;
  undefined4 uStack_428;
  undefined4 *puStack_424;
  undefined ****ppppuStack_420;
  undefined **ppuStack_41c;
  undefined4 *puStack_418;
  undefined ****ppppuStack_414;
  undefined ***pppuStack_410;
  undefined *puStack_40c;
  undefined **ppuStack_408;
  undefined **ppuStack_404;
  undefined ***pppuStack_400;
  undefined4 uStack_3fc;
  undefined **ppuStack_3f8;
  undefined ****ppppuStack_3f4;
  undefined ****ppppuStack_3f0;
  undefined **appuStack_3e4 [28];
  undefined **appuStack_374 [28];
  undefined **appuStack_304 [28];
  undefined **appuStack_294 [28];
  undefined **appuStack_224 [28];
  undefined *puStack_1b4;
  int *piStack_1b0;
  undefined **ppuStack_1ac;
  undefined **ppuStack_1a8;
  int *piStack_1a4;
  int *piStack_1a0;
  undefined **ppuStack_19c;
  undefined **ppuStack_198;
  int iStack_194;
  int iStack_190;
  int iStack_18c;
  int iStack_188;
  undefined *puStack_180;
  int *piStack_17c;
  undefined **appuStack_178 [2];
  undefined *puStack_170;
  undefined4 *puStack_168;
  undefined4 uStack_164;
  int *piStack_160;
  undefined **ppuStack_15c;
  undefined4 uStack_158;
  undefined4 *puStack_154;
  undefined **ppuStack_150;
  undefined **ppuStack_14c;
  undefined4 *apuStack_148 [2];
  undefined ***pppuStack_140;
  undefined *puStack_13c;
  undefined **ppuStack_138;
  undefined **ppuStack_134;
  undefined ***pppuStack_130;
  undefined4 uStack_12c;
  undefined **ppuStack_128;
  undefined **ppuStack_124;
  undefined **ppuStack_110;
  undefined **ppuStack_10c;
  undefined **ppuStack_108;
  undefined **appuStack_104 [2];
  undefined *puStack_fc;
  undefined4 *puStack_f4;
  undefined4 uStack_f0;
  int *piStack_ec;
  int *piStack_e8;
  undefined4 uStack_e4;
  undefined4 *puStack_e0;
  undefined **ppuStack_dc;
  undefined **ppuStack_d8;
  undefined4 *puStack_d4;
  undefined ***pppuStack_cc;
  undefined *puStack_c8;
  undefined **ppuStack_c4;
  undefined **ppuStack_c0;
  undefined ***pppuStack_bc;
  undefined4 uStack_b8;
  undefined **ppuStack_b4;
  undefined **ppuStack_b0;
  undefined auStack_94 [4];
  undefined *puStack_90;
  undefined *puStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined **ppuStack_7c;
  undefined *puStack_78;
  undefined *apuStack_74 [5];
  code *pcStack_60;
  undefined **appuStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  undefined **ppuStack_44;
  int *piStack_40;
  undefined *puStack_3c;
  undefined ***pppuStack_38;
  undefined ***pppuStack_34;
  undefined **ppuStack_30;
  int *piStack_2c;
  undefined **ppuStack_28;
  undefined **ppuStack_24;
  undefined **ppuStack_20;
  undefined **ppuStack_1c;
  undefined **ppuStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0632;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  if ((param_1 == (int *)0x0) || (*param_1 == param_1[1])) {
    if (in_stack_0000002c == (undefined *)0x0) {
      ppppuStack_3f0 = (undefined ****)0x8d7130;
      ExceptionList = &pvStack_10;
      ppppuStack_3f0 = (undefined ****)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
      ppppuStack_3f4 = (undefined ****)&UNK_008d713a;
      FUN_0054e5e0();
    }
    ppppuStack_3f0 = (undefined ****)&stack0x00000034;
    ppppuStack_3f4 = (undefined ****)0x8d7077;
    ExceptionList = &pvStack_10;
    (**(code **)(((uint)in_stack_0000002c & 0xfffffffe) + 4))();
  }
  else {
    ppppuStack_3f0 = (undefined ****)&ppuStack_1c;
    auStack_94[0] = 0;
    ppppuStack_3f4 = (undefined ****)&boost::lock_error::vftable_meta_ptr;
    ppuStack_3f8 = (undefined **)&DAT_018be100;
    ppuStack_1c = (undefined **)0xb;
    uStack_3fc = 0x8d5bd4;
    ExceptionList = &pvStack_10;
    ppuVar9 = (undefined **)FUN_00563d40();
    ppuVar11 = ppuVar9 + -1;
    if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar11 = ppuVar9;
    }
    puStack_90 = *ppuVar11;
    puStack_8c = (undefined *)0x0;
    uStack_88 = 0x3f800000;
    uStack_84 = 0;
    iStack_80 = 0;
    ppuStack_1c = (undefined **)param_1[1];
    ppuVar11 = (undefined **)*param_1;
    uStack_8._0_1_ = 5;
    if (ppuVar11 != ppuStack_1c) {
      do {
        puVar15 = *ppuVar11;
        ppppuStack_3f0 = (undefined ****)0x8d5c27;
        puVar10 = (undefined *)FUN_0088cdc0();
        if (puVar15 == puVar10) {
          ppppuStack_3f0 = (undefined ****)&ppuStack_44;
          ppppuStack_3f4 = (undefined ****)0x8d5c36;
          ppppuStack_3f4 = (undefined ****)FUN_008c03c0();
          ppppuStack_3f0 = (undefined ****)auStack_94;
          uStack_8._0_1_ = 6;
          ppuStack_3f8 = (undefined **)0x8d5c47;
          FUN_008ce720();
          piVar13 = piStack_40;
          uStack_8._0_1_ = 5;
          if (piStack_40 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_40[1] + -1;
            piStack_40[1] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              ppppuStack_3f0 = (undefined ****)0x8d5c6d;
              (**(code **)*piStack_40)();
              LOCK();
              piVar1 = piVar13 + 2;
              iVar12 = *piVar1 + -1;
              *piVar1 = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                ppppuStack_3f0 = (undefined ****)0x8d5c82;
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
        }
        else {
          ppppuStack_3f0 = (undefined ****)appuStack_5c;
          ppppuStack_3f4 = (undefined ****)0x8d5c90;
          FUN_008c04f0();
          uStack_8._0_1_ = 7;
          if (iStack_4c != 0) {
            ppppuStack_3f0 = (undefined ****)appuStack_5c;
            ppppuStack_3f4 = (undefined ****)0x8d5ca6;
            FUN_0054ef60();
            pcStack_60 = FUN_008ccda0;
            ppppuStack_3f4 = (undefined ****)&puStack_78;
            uStack_8._0_1_ = 8;
            ppuStack_3f8 = &puStack_180;
            uStack_3fc = 0x8d5cc8;
            ppppuStack_3f0 = ppppuStack_3f4;
            FUN_008c0130();
            ppppuStack_3f0 = (undefined ****)0x8d5cd0;
            FUN_005507b0();
          }
          uStack_8._0_1_ = 5;
          if (0xf < uStack_48) {
            ppppuStack_3f0 = (undefined ****)(uStack_48 + 1);
            ppuVar9 = appuStack_5c[0];
            if (0xfff < ppppuStack_3f0) {
              ppuVar9 = (undefined **)appuStack_5c[0][-1];
              ppppuStack_3f0 = (undefined ****)(uStack_48 + 0x24);
              if ((undefined *)0x1f < (undefined *)((int)appuStack_5c[0] + (-4 - (int)ppuVar9)))
              goto LAB_008d710b;
            }
            ppuStack_3f8 = (undefined **)0x8d5d05;
            ppppuStack_3f4 = (undefined ****)ppuVar9;
            FUN_01674ea0();
          }
        }
        ppuVar11 = ppuVar11 + 0x34;
      } while (ppuVar11 != ppuStack_1c);
      if (puStack_8c != (undefined *)0x0) {
        ppppuStack_3f0 = (undefined ****)0x2c;
        ppppuStack_3f4 = (undefined ****)0x8d5d2b;
        ppuVar11 = (undefined **)FUN_01674e20();
        uStack_8._0_1_ = 10;
        ppuStack_30 = ppuVar11;
        if (ppuVar11 == (undefined **)0x0) {
          ppuVar11 = (undefined **)0x0;
          ppuStack_24 = (undefined **)0x0;
        }
        else {
          ppppuStack_3f0 = (undefined ****)&stack0x0000000c;
          ppuVar11[1] = (undefined *)0x1;
          ppuVar11[2] = (undefined *)0x1;
          *ppuVar11 = (undefined *)std::_Ref_count_obj<class_RBX::Lua::WeakFunctionRef>::vftable;
          ppppuStack_3f4 = (undefined ****)0x8d5d5e;
          ppuStack_24 = ppuVar11;
          FUN_00d88580();
        }
        ppuStack_19c = ppuVar11 + 3;
        ppppuStack_3f0 = (undefined ****)0x18;
        uStack_8._0_1_ = 0xb;
        ppppuStack_3f4 = (undefined ****)0x8d5d7f;
        ppuStack_198 = ppuVar11;
        piStack_2c = (int *)FUN_01674e20();
        puVar15 = puStack_8c;
        if (piStack_2c == (int *)0x0) {
          piStack_2c = (int *)0x0;
        }
        else {
          piStack_2c[1] = 1;
          piStack_2c[2] = 1;
          *piStack_2c = (int)std::
                             _Ref_count_obj<class_std::vector<struct_std::pair<class_RBX::ContentId,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__cdecl*)(void)>,class_std::allocator<struct_std::pair<class_RBX::ContentId,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__cdecl*)(void)>_>_>_>
                             ::vftable;
          piStack_2c[3] = 0;
          piStack_2c[4] = 0;
          piStack_2c[5] = 0;
        }
        piStack_1a4 = piStack_2c + 3;
        ppppuStack_3f0 = (undefined ****)0x14;
        uStack_8._0_1_ = 0xc;
        ppppuStack_3f4 = (undefined ****)0x8d5ddb;
        piStack_1a0 = piStack_2c;
        ppuStack_28 = (undefined **)FUN_01674e20();
        if (ppuStack_28 == (undefined **)0x0) {
          ppuStack_28 = (undefined **)0x0;
        }
        else {
          ppuStack_28[1] = (undefined *)0x1;
          ppuStack_28[2] = (undefined *)0x1;
          *ppuStack_28 = (undefined *)std::_Ref_count_obj<class_RBX::PreloadAsyncRequest>::vftable;
          ppuStack_28[3] = puVar15;
          ppuStack_28[4] = (undefined *)0x0;
        }
        ppuStack_1ac = ppuStack_28 + 3;
        uStack_8._0_1_ = 0xd;
        ppuVar9 = ppuStack_28;
        ppuStack_1a8 = ppuStack_28;
        if (puStack_8c == (undefined *)0x0) {
          puVar16 = (undefined4 *)0x0;
        }
        else {
          puVar16 = *(undefined4 **)(iStack_80 + (int)puStack_90 * 4);
        }
        for (; ppuStack_28 = ppuVar9, puVar16 != (undefined4 *)0x0; puVar16 = (undefined4 *)*puVar16
            ) {
          ppppuStack_3f0 = (undefined ****)(puVar16 + 2);
          ppppuStack_3f4 = (undefined ****)0x8d5e4c;
          FUN_0054ef60();
          ppuVar11 = ppuStack_20;
          ppuStack_1c = (undefined **)puVar16[8];
          uStack_8._0_1_ = 0xe;
          uVar7 = (undefined)uStack_8;
          uStack_8._0_1_ = 0xe;
          if ((ppuStack_1c == (undefined **)FUN_008ccd50) &&
             (uVar7 = (undefined)uStack_8, ppuStack_20 != (undefined **)0x0)) {
            ppuStack_18 = (undefined **)ppuStack_20[0xd];
            if (ppuStack_18 == (undefined **)0x0) {
              ppuStack_18 = ppuStack_20;
            }
            else if (ppuStack_18[0xd] != (undefined *)0x0) {
              ppppuStack_3f0 = (undefined ****)0x8d5e83;
              ppuStack_18 = (undefined **)FUN_005c8ac0();
            }
            uVar7 = (undefined)uStack_8;
            if (ppuStack_18 == (undefined **)0x0) goto LAB_008d632a;
            puVar15 = ppuStack_18[3];
            ppppuStack_3f0 = (undefined ****)0x8d5e9d;
            iVar12 = FUN_008a8c30();
            ppuVar9 = ppuStack_18;
            ppuVar11 = ppuStack_20;
            uVar7 = (undefined)uStack_8;
            if ((uint)*(ushort *)(iVar12 + 0x1da) <
                (uint)*(ushort *)(puVar15 + 0x1d8) - (uint)*(ushort *)(iVar12 + 0x1d8))
            goto LAB_008d632a;
            ppppuStack_3f0 = (undefined ****)0x8d5ec6;
            piVar13 = (int *)FUN_005c41d0();
            ppuStack_18 = (undefined **)*piVar13;
            if (ppuStack_18 == (undefined **)0x0) {
              ppppuStack_3f0 = (undefined ****)&ppuStack_44;
              ppppuStack_3f4 = (undefined ****)0x8d5edc;
              FUN_005c2e50();
              ppppuStack_3f0 = (undefined ****)ppuVar9;
              uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
              ppppuStack_3f4 = (undefined ****)0x8d5eec;
              FUN_008a5700();
              ppppuStack_3f0 = (undefined ****)&LAB_005c2490;
              ppppuStack_3f4 = (undefined ****)&DAT_01ea8c4c;
              ppuStack_3f8 = (undefined **)0x8d5efb;
              FUN_005789c0();
              ppppuStack_3f0 = (undefined ****)0x8d5f03;
              ppppuStack_3f0 = (undefined ****)FUN_005c3850();
              ppppuStack_3f4 = (undefined ****)0x8d5f0b;
              puVar14 = (undefined4 *)FUN_008aa140();
              if (piStack_40 != (int *)0x0) {
                LOCK();
                piStack_40[1] = piStack_40[1] + 1;
                UNLOCK();
              }
              *puVar14 = ppuStack_44;
              piVar13 = (int *)puVar14[1];
              puVar14[1] = piStack_40;
              if (piVar13 != (int *)0x0) {
                LOCK();
                iVar12 = piVar13[1] + -1;
                piVar13[1] = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  ppppuStack_3f0 = (undefined ****)0x8d5f3a;
                  (**(code **)*piVar13)();
                  LOCK();
                  iVar12 = piVar13[2] + -1;
                  piVar13[2] = iVar12;
                  UNLOCK();
                  if (iVar12 == 0) {
                    ppppuStack_3f0 = (undefined ****)0x8d5f4b;
                    (**(code **)(*piVar13 + 4))();
                  }
                }
              }
              piVar13 = piStack_40;
              ppuStack_18 = ppuStack_44;
              uStack_8._0_1_ = 0xe;
              if (piStack_40 != (int *)0x0) {
                LOCK();
                iVar12 = piStack_40[1] + -1;
                piStack_40[1] = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  ppppuStack_3f0 = (undefined ****)0x8d5f6c;
                  (**(code **)*piStack_40)();
                  LOCK();
                  piVar1 = piVar13 + 2;
                  iVar12 = *piVar1 + -1;
                  *piVar1 = iVar12;
                  UNLOCK();
                  if (iVar12 == 0) {
                    ppppuStack_3f0 = (undefined ****)0x8d5f7d;
                    (**(code **)(*piVar13 + 4))();
                  }
                }
              }
              ppuVar11 = ppuStack_20;
              uVar7 = (undefined)uStack_8;
              if (ppuStack_18 == (undefined **)0x0) goto LAB_008d632a;
            }
            ppppuStack_3f0 = (undefined ****)&ppuStack_108;
            ppppuStack_3f4 = (undefined ****)0x0;
            ppuStack_3f8 = (undefined **)0x8d5f94;
            ppuStack_3f8 = (undefined **)(*(code *)ppuStack_1c)();
            pppuStack_400 = appuStack_5c;
            uStack_3fc = 0x41a00000;
            ppuStack_404 = &puStack_1b4;
            ppuStack_408 = (undefined **)0x8d5fb0;
            FUN_009dd5a0();
            piVar13 = piStack_1b0;
            if (piStack_1b0 != (int *)0x0) {
              LOCK();
              iVar12 = piStack_1b0[1] + -1;
              piStack_1b0[1] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                ppppuStack_3f0 = (undefined ****)0x8d5fca;
                (**(code **)*piStack_1b0)();
                LOCK();
                piVar1 = piVar13 + 2;
                iVar12 = *piVar1 + -1;
                *piVar1 = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  ppppuStack_3f0 = (undefined ****)0x8d5fdb;
                  (**(code **)(*piVar13 + 4))();
                }
              }
            }
            ppuVar11 = ppuStack_108;
            if (ppuStack_108 == (undefined **)0x0) {
LAB_008d63f6:
              ppppuStack_3f0 = (undefined ****)(puVar16 + 2);
              ppuVar11 = (undefined **)piStack_2c[4];
              if ((undefined **)piStack_2c[5] == ppuVar11) {
                ppuStack_3f8 = (undefined **)0x8d6427;
                ppppuStack_3f4 = (undefined ****)ppuVar11;
                FUN_008bda90();
              }
              else {
                ppppuStack_3f4 = (undefined ****)0x8d640f;
                FUN_0054ef60();
                ppuVar11[6] = (undefined *)puVar16[8];
                piStack_2c[4] = piStack_2c[4] + 0x1c;
              }
            }
            else {
              ppppuStack_3f0 = (undefined ****)appuStack_5c;
              ppuStack_1c = (undefined **)&ppuStack_3f8;
              if (ppuStack_28 != (undefined **)0x0) {
                LOCK();
                ppuStack_28[1] = ppuStack_28[1] + 1;
                UNLOCK();
              }
              ppuStack_3f8 = ppuStack_28 + 3;
              ppppuStack_3f4 = (undefined ****)ppuStack_28;
              ppuStack_18 = (undefined **)&puStack_418;
              pppuStack_34 = (undefined ***)&puStack_418;
              uStack_8._0_1_ = 0x10;
              puStack_418 = (undefined4 *)0x0;
              pppuVar4 = &ppuStack_3f8;
              ppuVar6 = &puStack_418;
              if (in_stack_0000004c != (undefined4 *)0x0) {
                puStack_418 = in_stack_0000004c;
                if (((uint)in_stack_0000004c & 1) == 0) {
                  ppuStack_41c = (undefined **)0x0;
                  ppppuStack_420 = &pppuStack_410;
                  puStack_424 = &stack0x00000054;
                  uStack_428 = 0x8d605f;
                  (**(code **)((uint)in_stack_0000004c & 0xfffffffe))();
                  pppuVar4 = (undefined ***)ppuStack_1c;
                  ppuVar6 = (undefined4 **)ppuStack_18;
                }
                else {
                  pppuStack_410 = in_stack_00000054;
                  puStack_40c = in_stack_00000058;
                  ppuStack_408 = in_stack_0000005c;
                  ppuStack_404 = in_stack_00000060;
                  pppuStack_400 = in_stack_00000064;
                  uStack_3fc = in_stack_00000068;
                  pppuVar4 = &ppuStack_3f8;
                  ppuVar6 = &puStack_418;
                }
              }
              ppuStack_18 = (undefined **)ppuVar6;
              ppuStack_1c = (undefined **)pppuVar4;
              pppuStack_34 = (undefined ***)&ppppuStack_420;
              if (ppuStack_24 != (undefined **)0x0) {
                LOCK();
                ppuStack_24[1] = ppuStack_24[1] + 1;
                UNLOCK();
              }
              ppppuStack_420 = (undefined ****)(ppuStack_24 + 3);
              ppuStack_41c = ppuStack_24;
              puStack_3c = (undefined *)&puStack_440;
              uStack_8._0_1_ = 0x12;
              puStack_440 = (undefined *)0x0;
              ppuVar9 = &puStack_440;
              pppppuVar3 = &ppppuStack_420;
              if (in_stack_0000002c != (undefined *)0x0) {
                puStack_440 = in_stack_0000002c;
                if (((uint)in_stack_0000002c & 1) == 0) {
                  ppuStack_444 = (undefined **)0x0;
                  (**(code **)((uint)in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&puStack_438)
                  ;
                  ppuVar9 = (undefined **)puStack_3c;
                  pppppuVar3 = (undefined *****)pppuStack_34;
                }
                else {
                  puStack_438 = in_stack_00000034;
                  ppppuStack_434 = (undefined ****)in_stack_00000038;
                  pppuStack_430 = (undefined ***)in_stack_0000003c;
                  piStack_42c = in_stack_00000040;
                  uStack_428 = in_stack_00000044;
                  puStack_424 = in_stack_00000048;
                  ppuVar9 = &puStack_440;
                  pppppuVar3 = &ppppuStack_420;
                }
              }
LAB_008d60bf:
              pppuStack_34 = (undefined ***)pppppuVar3;
              puStack_3c = (undefined *)ppuVar9;
              uStack_8._0_1_ = 0xe;
              ppuStack_444 = ppuVar11;
              FUN_008d7140();
            }
            uStack_8._0_1_ = 0xd;
            ppuVar11 = ppuStack_24;
            if (0xf < uStack_48) {
              ppppuStack_3f0 = (undefined ****)(uStack_48 + 1);
              ppuVar11 = appuStack_5c[0];
              if (0xfff < ppppuStack_3f0) {
                ppuVar11 = (undefined **)appuStack_5c[0][-1];
                ppppuStack_3f0 = (undefined ****)(uStack_48 + 0x24);
                if ((undefined *)0x1f < (undefined *)((int)appuStack_5c[0] + (-4 - (int)ppuVar11)))
                {
LAB_008d710b:
                    /* WARNING: Subroutine does not return */
                  ppppuStack_3f0 = (undefined ****)0x8d7110;
                  FUN_017167a3();
                }
              }
              ppuStack_3f8 = (undefined **)0x8d6101;
              ppppuStack_3f4 = (undefined ****)ppuVar11;
              FUN_01674ea0();
              ppuVar11 = ppuStack_24;
            }
          }
          else {
LAB_008d632a:
            uStack_8._0_1_ = uVar7;
            if ((ppuStack_1c == (undefined **)FUN_008ccd80) && (ppuVar11 != (undefined **)0x0)) {
              ppuStack_18 = (undefined **)ppuVar11[0xd];
              if ((ppuStack_18 != (undefined **)0x0) &&
                 (ppuVar11 = ppuStack_18, ppuStack_18[0xd] != (undefined *)0x0)) {
                ppppuStack_3f0 = (undefined ****)0x8d6355;
                ppuVar11 = (undefined **)FUN_005c8ac0();
              }
              ppuStack_18 = ppuVar11;
              if (ppuStack_18 != (undefined **)0x0) {
                puVar15 = ppuStack_18[3];
                ppppuStack_3f0 = (undefined ****)0x8d636f;
                iVar12 = FUN_008a8c30();
                if ((uint)*(ushort *)(puVar15 + 0x1d8) - (uint)*(ushort *)(iVar12 + 0x1d8) <=
                    (uint)*(ushort *)(iVar12 + 0x1da)) {
                  ppppuStack_3f0 = (undefined ****)0x8d6396;
                  iVar12 = FUN_005c34e0();
                  if (iVar12 != 0) {
                    ppppuStack_3f0 = (undefined ****)&ppuStack_30;
                    ppppuStack_3f4 = (undefined ****)0x0;
                    ppuStack_3f8 = (undefined **)0x8d63a9;
                    ppuStack_3f8 = (undefined **)(*(code *)ppuStack_1c)();
                    uStack_3fc = 0x41c80000;
                    pppuStack_400 = appuStack_5c;
                    ppuStack_404 = &puStack_180;
                    ppuStack_408 = (undefined **)0x8d63c4;
                    FUN_009dd5a0();
                    piVar13 = piStack_17c;
                    if (piStack_17c != (int *)0x0) {
                      LOCK();
                      iVar12 = piStack_17c[1] + -1;
                      piStack_17c[1] = iVar12;
                      UNLOCK();
                      if (iVar12 == 0) {
                        ppppuStack_3f0 = (undefined ****)0x8d63de;
                        (**(code **)*piStack_17c)();
                        LOCK();
                        piVar1 = piVar13 + 2;
                        iVar12 = *piVar1 + -1;
                        *piVar1 = iVar12;
                        UNLOCK();
                        if (iVar12 == 0) {
                          ppppuStack_3f0 = (undefined ****)0x8d63ef;
                          (**(code **)(*piVar13 + 4))();
                        }
                      }
                    }
                    ppuVar11 = ppuStack_30;
                    if (ppuStack_30 == (undefined **)0x0) goto LAB_008d63f6;
                    ppppuStack_3f0 = (undefined ****)appuStack_5c;
                    puStack_3c = (undefined *)&ppuStack_3f8;
                    if (ppuStack_28 != (undefined **)0x0) {
                      LOCK();
                      ppuStack_28[1] = ppuStack_28[1] + 1;
                      UNLOCK();
                    }
                    ppuStack_3f8 = ppuStack_28 + 3;
                    ppppuStack_3f4 = (undefined ****)ppuStack_28;
                    pppuStack_34 = (undefined ***)&puStack_418;
                    uStack_8._0_1_ = 0x13;
                    ppuStack_41c = (undefined **)&stack0x0000004c;
                    ppppuStack_420 = (undefined ****)0x8d646d;
                    FUN_0054f510();
                    ppuStack_1c = (undefined **)&ppppuStack_420;
                    if (ppuStack_24 != (undefined **)0x0) {
                      LOCK();
                      ppuStack_24[1] = ppuStack_24[1] + 1;
                      UNLOCK();
                    }
                    ppppuStack_420 = (undefined ****)(ppuStack_24 + 3);
                    ppuStack_41c = ppuStack_24;
                    uStack_8._0_1_ = 0x15;
                    ppuStack_444 = &stack0x0000002c;
                    FUN_0054f510();
                    ppuVar9 = (undefined **)puStack_3c;
                    pppppuVar3 = (undefined *****)pppuStack_34;
                    goto LAB_008d60bf;
                  }
                }
              }
            }
            if (ppuStack_1c == (undefined **)FUN_008ccd30) {
              if (ppuStack_20 == (undefined **)0x0) {
LAB_008d6513:
                ppuStack_18 = (undefined **)0x0;
              }
              else {
                ppuStack_18 = (undefined **)ppuStack_20[0xd];
                if (ppuStack_18 == (undefined **)0x0) {
                  ppuStack_18 = ppuStack_20;
                }
                else if (ppuStack_18[0xd] != (undefined *)0x0) {
                  ppppuStack_3f0 = (undefined ****)0x8d64d8;
                  ppuStack_18 = (undefined **)FUN_005c8ac0();
                }
                if (ppuStack_18 == (undefined **)0x0) goto LAB_008d6513;
                puVar15 = ppuStack_18[3];
                ppppuStack_3f0 = (undefined ****)0x8d64ee;
                iVar12 = FUN_008a8c30();
                if ((uint)*(ushort *)(iVar12 + 0x1da) <
                    (uint)*(ushort *)(puVar15 + 0x1d8) - (uint)*(ushort *)(iVar12 + 0x1d8))
                goto LAB_008d6513;
                ppppuStack_3f0 = (undefined ****)0x8d6511;
                ppuStack_18 = (undefined **)FUN_008bfe60();
              }
              if (ppuStack_18 != (undefined **)0x0) {
                pppuStack_34 = appuStack_178;
                puStack_170 = (undefined *)0x0;
                puStack_3c = (undefined *)&puStack_40c;
                ppuStack_1c = &puStack_40c;
                appuStack_178[0] = ppuStack_20;
                ppuVar11 = &puStack_40c;
                ppuVar9 = &puStack_40c;
                if (in_stack_0000002c != (undefined *)0x0) {
                  puStack_170 = in_stack_0000002c;
                  if (((uint)in_stack_0000002c & 1) == 0) {
                    ppppuStack_414 = (undefined ****)&puStack_168;
                    pppuStack_410 = (undefined ***)0x0;
                    puStack_418 = &stack0x00000034;
                    ppuStack_41c = (undefined **)0x8d6584;
                    (**(code **)((uint)in_stack_0000002c & 0xfffffffe))();
                    ppuVar11 = (undefined **)puStack_3c;
                    ppuVar9 = ppuStack_1c;
                  }
                  else {
                    puStack_168 = in_stack_00000034;
                    uStack_164 = in_stack_00000038;
                    piStack_160 = in_stack_0000003c;
                    ppuStack_15c = (undefined **)in_stack_00000040;
                    uStack_158 = in_stack_00000044;
                    puStack_154 = in_stack_00000048;
                    ppuVar11 = &puStack_40c;
                    ppuVar9 = &puStack_40c;
                  }
                }
                ppuStack_1c = ppuVar9;
                puStack_3c = (undefined *)ppuVar11;
                ppuVar11 = ppuStack_24;
                if (ppuStack_24 != (undefined **)0x0) {
                  LOCK();
                  ppuStack_24[1] = ppuStack_24[1] + 1;
                  UNLOCK();
                }
                ppuStack_150 = ppuStack_24 + 3;
                ppuStack_14c = ppuStack_24;
                uStack_8._0_1_ = 0x17;
                apuStack_148[0] = (undefined4 *)0x0;
                if (in_stack_0000004c != (undefined4 *)0x0) {
                  apuStack_148[0] = in_stack_0000004c;
                  if (((uint)in_stack_0000004c & 1) == 0) {
                    ppppuStack_414 = &pppuStack_140;
                    pppuStack_410 = (undefined ***)0x0;
                    puStack_418 = &stack0x00000054;
                    ppuStack_41c = (undefined **)0x8d6602;
                    (**(code **)((uint)in_stack_0000004c & 0xfffffffe))();
                  }
                  else {
                    pppuStack_140 = in_stack_00000054;
                    puStack_13c = in_stack_00000058;
                    ppuStack_138 = in_stack_0000005c;
                    ppuStack_134 = in_stack_00000060;
                    pppuStack_130 = in_stack_00000064;
                    uStack_12c = in_stack_00000068;
                  }
                }
                if (ppuStack_28 != (undefined **)0x0) {
                  LOCK();
                  ppuStack_28[1] = ppuStack_28[1] + 1;
                  UNLOCK();
                }
                ppuStack_128 = ppuStack_28 + 3;
                ppuStack_124 = ppuStack_28;
                pppuStack_410 = appuStack_5c;
                uStack_8._0_1_ = 0x19;
                ppppuStack_414 = (undefined ****)0x8d6646;
                FUN_0054ef60();
                pppuStack_410 = appuStack_178;
                uStack_8._0_1_ = 0x1a;
                ppppuStack_414 = (undefined ****)0x8d665c;
                FUN_008c1030();
                uStack_8._0_1_ = 0x1b;
                *ppuStack_1c = (undefined *)0x0;
                pppuStack_410 = appuStack_3e4;
                ppppuStack_414 = (undefined ****)0x8d667b;
                FUN_008c1030();
                pppuStack_410 = appuStack_374;
                uStack_8._0_1_ = 0x1c;
                ppppuStack_414 = (undefined ****)0x8d6691;
                FUN_008c1030();
                pppuStack_410 = appuStack_304;
                uStack_8._0_1_ = 0x1d;
                ppppuStack_414 = (undefined ****)0x8d66a7;
                FUN_008c1030();
                pppuStack_410 = appuStack_224;
                uStack_8._0_1_ = 0x1e;
                ppppuStack_414 = (undefined ****)0x8d66b7;
                cVar8 = FUN_00585a40();
                if (cVar8 == '\0') {
                  pppuStack_410 = appuStack_224;
                  ppppuStack_414 = (undefined ****)0x8d66d0;
                  FUN_008c1030();
                  pppuStack_410 = (undefined ***)0x70;
                  uStack_8._0_1_ = 0x1f;
                  ppppuStack_414 = (undefined ****)0x8d66db;
                  iStack_188 = FUN_01674e20();
                  uStack_8._0_1_ = 0x20;
                  if (iStack_188 == 0) {
                    puVar15 = (undefined *)0x0;
                  }
                  else {
                    pppuStack_410 = appuStack_294;
                    ppppuStack_414 = (undefined ****)0x8d66fa;
                    puVar15 = (undefined *)FUN_008c1030();
                  }
                  ppuStack_1c[2] = puVar15;
                  pppuStack_410 = (undefined ***)0x8d670f;
                  FUN_008c3210();
                  pppuStack_410 = (undefined ***)0x8d671a;
                  FUN_008c3210();
                  cStack_11 = '\x01';
                }
                else {
                  pppuStack_410 = (undefined ***)0x8d672b;
                  FUN_008c3210();
                  cStack_11 = '\0';
                }
                pppuStack_410 = (undefined ***)0x8d673a;
                FUN_008c3210();
                ppuVar9 = &PTR_FUN_019298c4;
                if (cStack_11 == '\0') {
                  ppuVar9 = (undefined **)0x0;
                }
                *ppuStack_1c = (undefined *)ppuVar9;
                pppuStack_410 = (undefined ***)0x8d6757;
                FUN_008c3210();
                pppuStack_410 = (undefined ***)0x8d6762;
                FUN_008c3210();
                pppuStack_410 = (undefined ***)0x8d676d;
                FUN_008c3210();
                pppuStack_38 = appuStack_104;
                uStack_8._0_1_ = 0x21;
                pppuStack_34 = (undefined ***)&piStack_42c;
                ppuStack_1c = (undefined **)&piStack_42c;
                appuStack_104[0] = ppuStack_20;
                puStack_fc = (undefined *)0x0;
                pppuVar4 = (undefined ***)&piStack_42c;
                ppiVar5 = &piStack_42c;
                if (in_stack_0000002c != (undefined *)0x0) {
                  puStack_fc = in_stack_0000002c;
                  if (((uint)in_stack_0000002c & 1) == 0) {
                    ppppuStack_434 = (undefined ****)&puStack_f4;
                    pppuStack_430 = (undefined ***)0x0;
                    puStack_438 = &stack0x00000034;
                    uStack_43c = 0x8d67d5;
                    (**(code **)((uint)in_stack_0000002c & 0xfffffffe))();
                    pppuVar4 = pppuStack_34;
                    ppiVar5 = (int **)ppuStack_1c;
                  }
                  else {
                    puStack_f4 = in_stack_00000034;
                    uStack_f0 = in_stack_00000038;
                    piStack_ec = in_stack_0000003c;
                    piStack_e8 = in_stack_00000040;
                    uStack_e4 = in_stack_00000044;
                    puStack_e0 = in_stack_00000048;
                    pppuVar4 = (undefined ***)&piStack_42c;
                    ppiVar5 = &piStack_42c;
                  }
                }
                ppuStack_1c = (undefined **)ppiVar5;
                pppuStack_34 = pppuVar4;
                if (ppuVar11 != (undefined **)0x0) {
                  LOCK();
                  ppuVar11[1] = ppuVar11[1] + 1;
                  UNLOCK();
                }
                ppuStack_dc = ppuVar11 + 3;
                ppuStack_d8 = ppuVar11;
                uStack_8._0_1_ = 0x23;
                puStack_d4 = (undefined4 *)0x0;
                if (in_stack_0000004c != (undefined4 *)0x0) {
                  puStack_d4 = in_stack_0000004c;
                  if (((uint)in_stack_0000004c & 1) == 0) {
                    ppppuStack_434 = &pppuStack_cc;
                    pppuStack_430 = (undefined ***)0x0;
                    puStack_438 = &stack0x00000054;
                    uStack_43c = 0x8d6850;
                    (**(code **)((uint)in_stack_0000004c & 0xfffffffe))();
                  }
                  else {
                    pppuStack_cc = in_stack_00000054;
                    puStack_c8 = in_stack_00000058;
                    ppuStack_c4 = in_stack_0000005c;
                    ppuStack_c0 = in_stack_00000060;
                    pppuStack_bc = in_stack_00000064;
                    uStack_b8 = in_stack_00000068;
                  }
                }
                if (ppuStack_28 != (undefined **)0x0) {
                  LOCK();
                  ppuStack_28[1] = ppuStack_28[1] + 1;
                  UNLOCK();
                }
                ppuStack_b4 = ppuStack_28 + 3;
                ppuStack_b0 = ppuStack_28;
                pppuStack_430 = appuStack_5c;
                uStack_8._0_1_ = 0x25;
                ppppuStack_434 = (undefined ****)0x8d6894;
                FUN_0054ef60();
                pppuStack_430 = appuStack_104;
                uStack_8._0_1_ = 0x26;
                ppppuStack_434 = (undefined ****)0x8d68aa;
                FUN_008c1030();
                uStack_8._0_1_ = 0x27;
                *ppuStack_1c = (undefined *)0x0;
                pppuStack_430 = appuStack_294;
                ppppuStack_434 = (undefined ****)0x8d68c9;
                FUN_008c1030();
                pppuStack_430 = appuStack_304;
                uStack_8._0_1_ = 0x28;
                ppppuStack_434 = (undefined ****)0x8d68df;
                FUN_008c1030();
                pppuStack_430 = appuStack_374;
                uStack_8._0_1_ = 0x29;
                ppppuStack_434 = (undefined ****)0x8d68f5;
                FUN_008c1030();
                pppuStack_430 = appuStack_224;
                uStack_8._0_1_ = 0x2a;
                ppppuStack_434 = (undefined ****)0x8d6905;
                cVar8 = FUN_00585a40();
                if (cVar8 == '\0') {
                  pppuStack_430 = appuStack_224;
                  ppppuStack_434 = (undefined ****)0x8d691e;
                  FUN_008c1030();
                  pppuStack_430 = (undefined ***)0x70;
                  uStack_8._0_1_ = 0x2b;
                  ppppuStack_434 = (undefined ****)0x8d6929;
                  iStack_18c = FUN_01674e20();
                  uStack_8._0_1_ = 0x2c;
                  if (iStack_18c == 0) {
                    puVar15 = (undefined *)0x0;
                  }
                  else {
                    pppuStack_430 = appuStack_3e4;
                    ppppuStack_434 = (undefined ****)0x8d6948;
                    puVar15 = (undefined *)FUN_008c1030();
                  }
                  ppuStack_1c[2] = puVar15;
                  pppuStack_430 = (undefined ***)0x8d695d;
                  FUN_008c3210();
                  pppuStack_430 = (undefined ***)0x8d6968;
                  FUN_008c3210();
                  cStack_11 = '\x01';
                }
                else {
                  pppuStack_430 = (undefined ***)0x8d6979;
                  FUN_008c3210();
                  cStack_11 = '\0';
                }
                pppuStack_430 = (undefined ***)0x8d6988;
                FUN_008c3210();
                ppuVar9 = &PTR_FUN_019298bc;
                if (cStack_11 == '\0') {
                  ppuVar9 = (undefined **)0x0;
                }
                *ppuStack_1c = (undefined *)ppuVar9;
                pppuStack_430 = (undefined ***)0x8d69a5;
                FUN_008c3210();
                pppuStack_430 = (undefined ***)0x8d69b0;
                FUN_008c3210();
                pppuStack_430 = (undefined ***)0x8d69bb;
                FUN_008c3210();
                pppuStack_38 = &ppuStack_444;
                uStack_8._0_1_ = 0x2d;
                FUN_0054ef60(appuStack_5c);
                uStack_8._0_1_ = 0xe;
                FUN_00e5faf0();
                uStack_8._0_1_ = 0xd;
                ppppuStack_3f0 = (undefined ****)0x8d69e8;
                FUN_005507b0();
                goto LAB_008d6107;
              }
            }
            if (((DAT_01d62f80 == '\0') || (ppuStack_1c != (undefined **)FUN_008ccda0)) ||
               (*(char *)(ppuStack_20 + 0x2c) == '\0')) {
              pppuStack_38 = appuStack_104;
              appuStack_104[0] = ppuStack_20;
              ppppuStack_3f0 = (undefined ****)&stack0x0000002c;
              ppppuStack_3f4 = (undefined ****)0x8d6cf8;
              FUN_0054f510();
              ppuVar11 = ppuStack_24;
              if (ppuStack_24 != (undefined **)0x0) {
                LOCK();
                ppuStack_24[1] = ppuStack_24[1] + 1;
                UNLOCK();
              }
              ppuStack_dc = ppuStack_24 + 3;
              ppuStack_d8 = ppuStack_24;
              ppppuStack_3f0 = (undefined ****)&stack0x0000004c;
              uStack_8._0_1_ = 0x3d;
              ppppuStack_3f4 = (undefined ****)0x8d6d39;
              FUN_0054f510();
              if (ppuStack_28 != (undefined **)0x0) {
                LOCK();
                ppuStack_28[1] = ppuStack_28[1] + 1;
                UNLOCK();
              }
              ppuStack_b4 = ppuStack_28 + 3;
              ppuStack_b0 = ppuStack_28;
              ppppuStack_3f0 = (undefined ****)appuStack_5c;
              uStack_8._0_1_ = 0x3f;
              ppppuStack_3f4 = (undefined ****)0x8d6d7a;
              FUN_0054ef60();
              ppppuStack_3f0 = (undefined ****)appuStack_104;
              uStack_8._0_1_ = 0x40;
              ppppuStack_3f4 = (undefined ****)0x8d6d90;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_294;
              uStack_8._0_1_ = 0x41;
              ppuStack_7c = (undefined **)0x0;
              ppppuStack_3f4 = (undefined ****)0x8d6dad;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_304;
              uStack_8._0_1_ = 0x42;
              ppppuStack_3f4 = (undefined ****)0x8d6dc3;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_374;
              uStack_8._0_1_ = 0x43;
              ppppuStack_3f4 = (undefined ****)0x8d6dd9;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_224;
              uStack_8._0_1_ = 0x44;
              ppppuStack_3f4 = (undefined ****)0x8d6de9;
              cVar8 = FUN_00585a40();
              if (cVar8 == '\0') {
                ppppuStack_3f0 = (undefined ****)appuStack_224;
                ppppuStack_3f4 = (undefined ****)0x8d6e02;
                FUN_008c1030();
                ppppuStack_3f0 = (undefined ****)0x70;
                uStack_8._0_1_ = 0x45;
                ppppuStack_3f4 = (undefined ****)0x8d6e0d;
                iStack_194 = FUN_01674e20();
                uStack_8._0_1_ = 0x46;
                if (iStack_194 == 0) {
                  apuStack_74[0] = (undefined *)0x0;
                }
                else {
                  ppppuStack_3f0 = (undefined ****)appuStack_3e4;
                  ppppuStack_3f4 = (undefined ****)0x8d6e2c;
                  apuStack_74[0] = (undefined *)FUN_008c1030();
                }
                ppppuStack_3f0 = (undefined ****)0x8d6e3e;
                FUN_008c3210();
                ppppuStack_3f0 = (undefined ****)0x8d6e49;
                FUN_008c3210();
                cStack_11 = '\x01';
              }
              else {
                ppppuStack_3f0 = (undefined ****)0x8d6e5a;
                FUN_008c3210();
                cStack_11 = '\0';
              }
              ppppuStack_3f0 = (undefined ****)0x8d6e69;
              FUN_008c3210();
              ppuStack_7c = &PTR_FUN_019298d4;
              if (cStack_11 == '\0') {
                ppuStack_7c = (undefined **)0x0;
              }
              ppppuStack_3f0 = (undefined ****)0x8d6e84;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)0x8d6e8f;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)0x8d6e9a;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)0x1;
              ppppuStack_3f4 = (undefined ****)0x0;
              ppuStack_3f8 = (undefined **)&DAT_01d62f20;
              uStack_8._0_1_ = 0x47;
              uStack_3fc = 0x8d6eac;
              uStack_3fc = (*(code *)puVar16[8])();
              pppuStack_400 = &ppuStack_7c;
              ppuStack_404 = (undefined **)0x0;
              pppuStack_410 = appuStack_5c;
              ppuStack_408 = (undefined **)0x4f000000;
              puStack_40c = (undefined *)0x1;
              ppppuStack_414 = (undefined ****)0x8d6ec9;
              ppuStack_1c = (undefined **)FUN_008d7910();
              uStack_8._0_1_ = 0x48;
              if (((ppuStack_7c != (undefined **)0x0) && (((uint)ppuStack_7c & 1) == 0)) &&
                 (*(code **)((uint)ppuStack_7c & 0xfffffffe) != (code *)0x0)) {
                ppuStack_3f8 = apuStack_74;
                ppppuStack_3f0 = (undefined ****)0x2;
                uStack_3fc = 0x8d6eee;
                ppppuStack_3f4 = (undefined ****)ppuStack_3f8;
                (**(code **)((uint)ppuStack_7c & 0xfffffffe))();
              }
              if (ppuStack_1c != (undefined **)0x0) {
                ppppuStack_3f0 = (undefined ****)appuStack_5c;
                pppuStack_38 = &ppuStack_3f8;
                if (ppuStack_28 != (undefined **)0x0) {
                  LOCK();
                  ppuStack_28[1] = ppuStack_28[1] + 1;
                  UNLOCK();
                }
                ppuStack_3f8 = ppuStack_28 + 3;
                ppppuStack_3f4 = (undefined ****)ppuStack_28;
                puStack_3c = (undefined *)&puStack_418;
                uStack_8._0_1_ = 0x49;
                ppuStack_41c = (undefined **)&stack0x0000004c;
                ppppuStack_420 = (undefined ****)0x8d6f3c;
                FUN_0054f510();
                pppuStack_34 = (undefined ***)&ppppuStack_420;
                if (ppuVar11 != (undefined **)0x0) {
                  LOCK();
                  ppuVar11[1] = ppuVar11[1] + 1;
                  UNLOCK();
                }
                ppppuStack_420 = (undefined ****)(ppuVar11 + 3);
                ppuStack_41c = ppuVar11;
                uStack_8._0_1_ = 0x4b;
                ppuStack_444 = &stack0x0000002c;
                FUN_0054f510();
                ppuStack_444 = ppuStack_1c;
                uStack_8._0_1_ = 0xe;
                FUN_008d7140();
              }
              uStack_8._0_1_ = 0xd;
              ppppuStack_3f0 = (undefined ****)0x8d6f8e;
              FUN_005507b0();
            }
            else {
              appuStack_104[0] = ppuStack_20;
              pppuStack_38 = appuStack_104;
              puStack_fc = (undefined *)0x0;
              if (in_stack_0000002c != (undefined *)0x0) {
                puStack_fc = in_stack_0000002c;
                if (((uint)in_stack_0000002c & 1) == 0) {
                  ppppuStack_3f4 = (undefined ****)&puStack_f4;
                  ppppuStack_3f0 = (undefined ****)0x0;
                  ppuStack_3f8 = (undefined **)&stack0x00000034;
                  uStack_3fc = 0x8d6a71;
                  (**(code **)((uint)in_stack_0000002c & 0xfffffffe))();
                }
                else {
                  puStack_f4 = in_stack_00000034;
                  uStack_f0 = in_stack_00000038;
                  piStack_ec = in_stack_0000003c;
                  piStack_e8 = in_stack_00000040;
                  uStack_e4 = in_stack_00000044;
                  puStack_e0 = in_stack_00000048;
                }
              }
              ppuVar11 = ppuStack_24;
              if (ppuStack_24 != (undefined **)0x0) {
                LOCK();
                ppuStack_24[1] = ppuStack_24[1] + 1;
                UNLOCK();
              }
              ppuStack_dc = ppuStack_24 + 3;
              ppuStack_d8 = ppuStack_24;
              uStack_8._0_1_ = 0x2f;
              puStack_d4 = (undefined4 *)0x0;
              if (in_stack_0000004c != (undefined4 *)0x0) {
                puStack_d4 = in_stack_0000004c;
                if (((uint)in_stack_0000004c & 1) == 0) {
                  ppppuStack_3f4 = &pppuStack_cc;
                  ppppuStack_3f0 = (undefined ****)0x0;
                  ppuStack_3f8 = (undefined **)&stack0x00000054;
                  uStack_3fc = 0x8d6aef;
                  (**(code **)((uint)in_stack_0000004c & 0xfffffffe))();
                }
                else {
                  pppuStack_cc = in_stack_00000054;
                  puStack_c8 = in_stack_00000058;
                  ppuStack_c4 = in_stack_0000005c;
                  ppuStack_c0 = in_stack_00000060;
                  pppuStack_bc = in_stack_00000064;
                  uStack_b8 = in_stack_00000068;
                }
              }
              if (ppuStack_28 != (undefined **)0x0) {
                LOCK();
                ppuStack_28[1] = ppuStack_28[1] + 1;
                UNLOCK();
              }
              ppuStack_b4 = ppuStack_28 + 3;
              ppuStack_b0 = ppuStack_28;
              ppppuStack_3f0 = (undefined ****)appuStack_5c;
              uStack_8._0_1_ = 0x31;
              ppppuStack_3f4 = (undefined ****)0x8d6b33;
              FUN_0054ef60();
              ppppuStack_3f0 = (undefined ****)appuStack_104;
              uStack_8._0_1_ = 0x32;
              ppppuStack_3f4 = (undefined ****)0x8d6b49;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_294;
              uStack_8._0_1_ = 0x33;
              ppuStack_7c = (undefined **)0x0;
              ppppuStack_3f4 = (undefined ****)0x8d6b66;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_304;
              uStack_8._0_1_ = 0x34;
              ppppuStack_3f4 = (undefined ****)0x8d6b7c;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_374;
              uStack_8._0_1_ = 0x35;
              ppppuStack_3f4 = (undefined ****)0x8d6b92;
              FUN_008c1030();
              ppppuStack_3f0 = (undefined ****)appuStack_224;
              uStack_8._0_1_ = 0x36;
              ppppuStack_3f4 = (undefined ****)0x8d6ba2;
              cVar8 = FUN_00585a40();
              if (cVar8 == '\0') {
                ppppuStack_3f0 = (undefined ****)appuStack_224;
                ppppuStack_3f4 = (undefined ****)0x8d6bbb;
                FUN_008c1030();
                ppppuStack_3f0 = (undefined ****)0x70;
                uStack_8._0_1_ = 0x37;
                ppppuStack_3f4 = (undefined ****)0x8d6bc6;
                iStack_190 = FUN_01674e20();
                uStack_8._0_1_ = 0x38;
                if (iStack_190 == 0) {
                  apuStack_74[0] = (undefined *)0x0;
                }
                else {
                  ppppuStack_3f0 = (undefined ****)appuStack_3e4;
                  ppppuStack_3f4 = (undefined ****)0x8d6be5;
                  apuStack_74[0] = (undefined *)FUN_008c1030();
                }
                ppppuStack_3f0 = (undefined ****)0x8d6bf7;
                FUN_008c3210();
                ppppuStack_3f0 = (undefined ****)0x8d6c02;
                FUN_008c3210();
                cStack_11 = '\x01';
              }
              else {
                ppppuStack_3f0 = (undefined ****)0x8d6c13;
                FUN_008c3210();
                cStack_11 = '\0';
              }
              ppppuStack_3f0 = (undefined ****)0x8d6c22;
              FUN_008c3210();
              ppuStack_7c = &PTR_FUN_019298cc;
              if (cStack_11 == '\0') {
                ppuStack_7c = (undefined **)0x0;
              }
              ppppuStack_3f0 = (undefined ****)0x8d6c3d;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)0x8d6c48;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)0x8d6c53;
              FUN_008c3210();
              ppppuStack_3f0 = (undefined ****)appuStack_5c;
              uStack_8._0_1_ = 0x39;
              ppppuStack_3f4 = (undefined ****)0x8d6c66;
              FUN_0054ef60();
              ppppuStack_3f0 = (undefined ****)&ppuStack_7c;
              uStack_8._0_1_ = 0x3a;
              pppuStack_130 = (undefined ***)0x0;
              ppppuStack_3f4 = (undefined ****)0x8d6c83;
              FUN_0054f510();
              ppppuStack_3f0 = (undefined ****)apuStack_148;
              ppuStack_3f8 = ppuStack_20 + 0x1b;
              uStack_8 = CONCAT31(uStack_8._1_3_,0x3b);
              ppppuStack_3f4 = (undefined ****)ppuStack_20[0x1c];
              if ((undefined ****)ppuStack_20[0x1d] == ppppuStack_3f4) {
                ppuStack_3f8 = (undefined **)0x8d6cb6;
                FUN_008be4c0();
              }
              else {
                uStack_3fc = 0x8d6ca3;
                FUN_008bfd20();
                ppuStack_20[0x1c] = ppuStack_20[0x1c] + 0x40;
              }
              ppppuStack_3f0 = (undefined ****)0x8d6cc1;
              FUN_008c3d70();
              ppppuStack_3f0 = (undefined ****)0x8d6cc9;
              FUN_00550990();
              uStack_8._0_1_ = 0xd;
              ppppuStack_3f0 = (undefined ****)0x8d6cd5;
              FUN_005507b0();
            }
          }
LAB_008d6107:
          ppuVar9 = ppuStack_28;
        }
        if (piStack_2c[3] != piStack_2c[4]) {
          piStack_160 = (int *)0x0;
          ppuStack_15c = (undefined **)0x0;
          uStack_158 = 0;
          ppuStack_138 = (undefined **)0x0;
          ppuStack_134 = (undefined **)0x0;
          pppuStack_130 = (undefined ***)0x0;
          ppuStack_110 = (undefined **)0x0;
          ppuStack_10c = (undefined **)0x0;
          ppppuStack_3f0 = (undefined ****)&stack0x0000002c;
          uStack_8._0_1_ = 0x4c;
          ppppuStack_3f4 = (undefined ****)0x8d6180;
          FUN_0054f510();
          ppppuStack_3f0 = (undefined ****)&uStack_158;
          uStack_8._0_1_ = 0x4d;
          ppppuStack_3f4 = (undefined ****)0x8d6192;
          FUN_005e2c00();
          uStack_8._0_1_ = 0x4e;
          if (((ppuStack_7c != (undefined **)0x0) && (((uint)ppuStack_7c & 1) == 0)) &&
             (*(code **)((uint)ppuStack_7c & 0xfffffffe) != (code *)0x0)) {
            ppuStack_3f8 = apuStack_74;
            ppppuStack_3f0 = (undefined ****)0x2;
            uStack_3fc = 0x8d61b3;
            ppppuStack_3f4 = (undefined ****)ppuStack_3f8;
            (**(code **)((uint)ppuStack_7c & 0xfffffffe))();
          }
          ppuVar9 = ppuStack_134;
          uStack_8._0_1_ = 0x4c;
          if (ppuVar11 != (undefined **)0x0) {
            LOCK();
            ppuVar11[1] = ppuVar11[1] + 1;
            UNLOCK();
          }
          ppuStack_138 = ppuVar11 + 3;
          ppuVar2 = ppuVar11;
          if (ppuStack_134 != (undefined **)0x0) {
            LOCK();
            iVar12 = (int)ppuStack_134[1] + -1;
            ppuStack_134[1] = (undefined *)iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              puVar16 = (undefined4 *)*ppuStack_134;
              ppppuStack_3f0 = (undefined ****)0x8d61eb;
              ppuStack_134 = ppuVar11;
              (*(code *)*puVar16)();
              LOCK();
              piVar13 = (int *)(ppuVar9 + 2);
              iVar12 = *piVar13 + -1;
              *piVar13 = iVar12;
              UNLOCK();
              ppuVar2 = ppuStack_134;
              if (iVar12 == 0) {
                ppppuStack_3f0 = (undefined ****)0x8d61fc;
                (**(code **)((int)*ppuVar9 + 4))();
                ppuVar2 = ppuStack_134;
              }
            }
          }
          ppuStack_134 = ppuVar2;
          ppppuStack_3f0 = (undefined ****)&stack0x0000004c;
          ppppuStack_3f4 = (undefined ****)0x8d6208;
          FUN_0054f510();
          ppppuStack_3f0 = &pppuStack_130;
          uStack_8._0_1_ = 0x4f;
          ppppuStack_3f4 = (undefined ****)0x8d621a;
          FUN_008da730();
          uStack_8._0_1_ = 0x50;
          if (((ppuStack_7c != (undefined **)0x0) && (((uint)ppuStack_7c & 1) == 0)) &&
             (*(code **)((uint)ppuStack_7c & 0xfffffffe) != (code *)0x0)) {
            ppuStack_3f8 = apuStack_74;
            ppppuStack_3f0 = (undefined ****)0x2;
            uStack_3fc = 0x8d623b;
            ppppuStack_3f4 = (undefined ****)ppuStack_3f8;
            (**(code **)((uint)ppuStack_7c & 0xfffffffe))();
          }
          ppuVar9 = ppuStack_28;
          ppuVar2 = ppuStack_10c;
          uStack_8._0_1_ = 0x4c;
          if (ppuStack_28 != (undefined **)0x0) {
            LOCK();
            ppuStack_28[1] = ppuStack_28[1] + 1;
            UNLOCK();
          }
          ppuStack_110 = ppuStack_28 + 3;
          ppuStack_30 = ppuStack_10c;
          ppuStack_10c = ppuStack_28;
          if (ppuVar2 != (undefined **)0x0) {
            LOCK();
            puVar15 = ppuVar2[1] + -1;
            ppuVar2[1] = puVar15;
            UNLOCK();
            if (puVar15 == (undefined *)0x0) {
              ppppuStack_3f0 = (undefined ****)0x8d6277;
              (**(code **)*ppuVar2)();
              LOCK();
              puVar15 = ppuStack_30[2] + -1;
              ppuStack_30[2] = puVar15;
              UNLOCK();
              if (puVar15 == (undefined *)0x0) {
                ppppuStack_3f0 = (undefined ****)0x8d6289;
                (**(code **)(*ppuStack_30 + 4))();
              }
            }
          }
          ppuVar2 = ppuStack_15c;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
          }
          piStack_160 = piStack_2c + 3;
          ppuStack_30 = ppuStack_15c;
          ppuStack_15c = (undefined **)piStack_2c;
          if (ppuVar2 != (undefined **)0x0) {
            LOCK();
            puVar15 = ppuVar2[1] + -1;
            ppuVar2[1] = puVar15;
            UNLOCK();
            if (puVar15 == (undefined *)0x0) {
              ppppuStack_3f0 = (undefined ****)0x8d62be;
              (**(code **)*ppuVar2)();
              LOCK();
              puVar15 = ppuStack_30[2] + -1;
              ppuStack_30[2] = puVar15;
              UNLOCK();
              if (puVar15 == (undefined *)0x0) {
                ppppuStack_3f0 = (undefined ****)0x8d62d0;
                (**(code **)(*ppuStack_30 + 4))();
              }
            }
          }
          ppppuStack_3f4 = (undefined ****)ppuStack_20[0x3b];
          if ((undefined ****)ppuStack_20[0x3c] == ppppuStack_3f4) {
            ppppuStack_3f0 = (undefined ****)&piStack_160;
            ppuStack_3f8 = (undefined **)0x8d6fa6;
            FUN_008bde70();
            ppppuStack_3f0 = (undefined ****)0x8d6fb1;
            FUN_008c4380();
          }
          else {
            ppppuStack_3f0 = (undefined ****)&piStack_160;
            ppppuStack_3f4 = (undefined ****)0x8d62f1;
            FUN_008c2f20();
            ppuStack_20[0x3b] = ppuStack_20[0x3b] + 0x58;
            ppppuStack_3f0 = (undefined ****)0x8d6306;
            FUN_008c4380();
          }
        }
        if (ppuVar9 != (undefined **)0x0) {
          LOCK();
          puVar15 = ppuVar9[1] + -1;
          ppuVar9[1] = puVar15;
          UNLOCK();
          if (puVar15 == (undefined *)0x0) {
            ppppuStack_3f0 = (undefined ****)0x8d6fca;
            (**(code **)*ppuVar9)();
            LOCK();
            puVar15 = ppuVar9[2] + -1;
            ppuVar9[2] = puVar15;
            UNLOCK();
            if (puVar15 == (undefined *)0x0) {
              ppppuStack_3f0 = (undefined ****)0x8d6fdb;
              (**(code **)(*ppuVar9 + 4))();
            }
          }
        }
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar12 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            ppppuStack_3f0 = (undefined ****)0x8d6ff2;
            (**(code **)*piStack_2c)();
            LOCK();
            iVar12 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              ppppuStack_3f0 = (undefined ****)0x8d7003;
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
        if (ppuVar11 != (undefined **)0x0) {
          LOCK();
          puVar15 = ppuVar11[1] + -1;
          ppuVar11[1] = puVar15;
          UNLOCK();
          if (puVar15 == (undefined *)0x0) {
            ppppuStack_3f0 = (undefined ****)0x8d7016;
            (**(code **)*ppuVar11)();
            LOCK();
            puVar15 = ppuVar11[2] + -1;
            ppuVar11[2] = puVar15;
            UNLOCK();
            if (puVar15 == (undefined *)0x0) {
              ppppuStack_3f0 = (undefined ****)0x8d7026;
              (**(code **)(*ppuVar11 + 4))();
            }
          }
        }
        ppppuStack_3f0 = (undefined ****)0x8d7031;
        FUN_005d1280();
        goto LAB_008d707a;
      }
    }
    if (in_stack_0000002c == (undefined *)0x0) {
      ppppuStack_3f0 = (undefined ****)0x8d711b;
      ppppuStack_3f0 = (undefined ****)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
                    /* WARNING: Subroutine does not return */
      ppppuStack_3f4 = (undefined ****)0x8d7125;
      FUN_0054e5e0();
    }
    ppppuStack_3f0 = (undefined ****)&stack0x00000034;
    ppppuStack_3f4 = (undefined ****)0x8d704d;
    (**(code **)(((uint)in_stack_0000002c & 0xfffffffe) + 4))();
    ppppuStack_3f0 = (undefined ****)0x8d705b;
    FUN_005d1280();
  }
LAB_008d707a:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar12 = param_2[1] + -1;
    param_2[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      ppppuStack_3f0 = (undefined ****)0x8d7090;
      (**(code **)*param_2)();
      LOCK();
      piVar13 = param_2 + 2;
      iVar12 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        ppppuStack_3f0 = (undefined ****)0x8d709f;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ppppuStack_3f0 = (undefined ****)0x8d70a7;
  FUN_00d88a30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x51);
  if (in_stack_0000002c != (undefined *)0x0) {
    if ((((uint)in_stack_0000002c & 1) == 0) &&
       (*(code **)((uint)in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      ppuStack_3f8 = (undefined **)&stack0x00000034;
      ppppuStack_3f0 = (undefined ****)0x2;
      uStack_3fc = 0x8d70c8;
      ppppuStack_3f4 = (undefined ****)ppuStack_3f8;
      (**(code **)((uint)in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = (undefined *)0x0;
  }
  uStack_8 = 0x52;
  if (((in_stack_0000004c != (undefined4 *)0x0) && (((uint)in_stack_0000004c & 1) == 0)) &&
     (*(code **)((uint)in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
    ppuStack_3f8 = (undefined **)&stack0x00000054;
    ppppuStack_3f0 = (undefined ****)0x2;
    uStack_3fc = 0x8d70f6;
    ppppuStack_3f4 = (undefined ****)ppuStack_3f8;
    (**(code **)((uint)in_stack_0000004c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15221 ; VA 0x008d7140 ; FUN_008d7140 */

code * FUN_008d7140(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                   undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
                   undefined4 param_9,int *param_10,code *param_11)

{
  int *piVar1;
  uint uVar2;
  bool bVar3;
  int *piVar4;
  undefined4 *puVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined **ppuVar9;
  code *pcVar10;
  int *in_stack_00000050;
  int *in_stack_00000054;
  undefined3 uStack00000058;
  undefined uStack0000005b;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 *puStack_228;
  undefined4 auStack_224 [2];
  undefined4 uStack_21c;
  undefined4 *puStack_218;
  char *pcStack_214;
  undefined4 *puStack_210;
  undefined auStack_204 [80];
  undefined auStack_1b4 [80];
  undefined auStack_164 [80];
  undefined auStack_114 [80];
  undefined auStack_c4 [80];
  undefined auStack_74 [4];
  undefined4 uStack_70;
  int *piStack_6c;
  int iStack_50;
  undefined uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined *puStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c06cc;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_18 = &DAT_01ee017c;
  cStack_14 = '\0';
  puStack_210 = (undefined4 *)0x8d717c;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  puVar5 = _uStack00000058;
  uStack_8._0_1_ = 4;
  *in_stack_00000050 = *in_stack_00000050 + -1;
  if (param_1 != 1) {
    if (DAT_01d62f90 != '\0') {
      puStack_228 = _uStack00000058;
      uStack_22c = 0x8d71a5;
      _uStack00000058 = auStack_224;
      FUN_0054ef60();
      puStack_228 = (undefined4 *)0x8d71af;
      FUN_008c7030();
    }
    if (DAT_01d62f88 == '\0') {
      puStack_210 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puStack_210 = (undefined4 *)*puVar5;
      }
      pcStack_214 = "ContentProvider:PreloadAsync() failed for %s";
      puStack_218 = (undefined4 *)0x3;
      uStack_21c = 0x8d71cf;
      FUN_0086f2f0();
    }
    in_stack_00000050[1] = in_stack_00000050[1] + 1;
  }
  pcStack_214 = (char *)0x8d71de;
  iStack_20 = FUN_008f7870();
  if (iStack_20 == 0) {
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
  }
  else {
    puStack_210 = (undefined4 *)0x1;
    puStack_24 = auStack_74;
    _uStack00000058 = (undefined4 *)CONCAT13(*in_stack_00000050 == 0,uStack00000058);
    puStack_1c = &uStack_230;
    if (param_10 != (int *)0x0) {
      LOCK();
      param_10[1] = param_10[1] + 1;
      UNLOCK();
    }
    uStack_70 = param_9;
    piStack_6c = param_10;
    uStack_8._0_1_ = 6;
    FUN_0054ef60(puVar5);
    iStack_50 = param_1;
    uStack_4c = uStack0000005b;
    uStack_8._0_1_ = 7;
    uStack_44 = 0;
    if (param_2 != 0) {
      uStack_44 = param_2;
      if ((param_2 & 1) == 0) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_3c,0);
      }
      else {
        uStack_3c = param_4;
        uStack_38 = param_5;
        uStack_34 = param_6;
        uStack_30 = param_7;
        uStack_2c = param_8;
      }
    }
    uStack_8._0_1_ = 8;
    FUN_008c13b0(auStack_74);
    puVar5 = puStack_1c;
    uStack_8._0_1_ = 9;
    *puStack_1c = 0;
    FUN_008c13b0(auStack_204);
    uStack_8._0_1_ = 10;
    FUN_008c13b0(auStack_1b4);
    uStack_8._0_1_ = 0xb;
    FUN_008c13b0(auStack_164);
    uStack_8._0_1_ = 0xc;
    cVar6 = FUN_00585a40(auStack_c4);
    if (cVar6 == '\0') {
      FUN_008c13b0(auStack_c4);
      uStack_8._0_1_ = 0xd;
      iVar7 = FUN_01674e20(0x50);
      uStack_8._0_1_ = 0xe;
      if (iVar7 == 0) {
        uVar8 = 0;
      }
      else {
        uVar8 = FUN_008c13b0(auStack_114);
      }
      puVar5[2] = uVar8;
      FUN_008c35a0();
      FUN_008c35a0();
      bVar3 = true;
    }
    else {
      FUN_008c35a0();
      bVar3 = false;
    }
    FUN_008c35a0();
    ppuVar9 = &PTR_FUN_019298b4;
    if (!bVar3) {
      ppuVar9 = (undefined **)0x0;
    }
    *puVar5 = ppuVar9;
    FUN_008c35a0();
    FUN_008c35a0();
    uStack_8._0_1_ = 4;
    FUN_008c35a0();
    FUN_0090ca30();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  }
  if (cStack_14 != '\0') {
    LOCK();
    uVar2 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        puStack_210 = (undefined4 *)0x8d73df;
        puStack_210 = (undefined4 *)FUN_00554e40();
        pcStack_214 = (char *)0x8d73e6;
        SetEvent();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_218 = &param_4;
    puStack_210 = (undefined4 *)0x2;
    uStack_21c = 0x8d7407;
    pcStack_214 = (char *)puStack_218;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  piVar4 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar7 = param_10[1] + -1;
    param_10[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      puStack_210 = (undefined4 *)0x8d742a;
      (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        puStack_210 = (undefined4 *)0x8d743a;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  pcVar10 = param_11;
  if (param_11 != (code *)0x0) {
    if ((((uint)param_11 & 1) == 0) &&
       (pcVar10 = *(code **)((uint)param_11 & 0xfffffffe), pcVar10 != (code *)0x0)) {
      puStack_218 = (undefined4 *)&stack0x00000038;
      puStack_210 = (undefined4 *)0x2;
      uStack_21c = 0x8d745b;
      pcStack_214 = (char *)puStack_218;
      pcVar10 = (code *)(*pcVar10)();
    }
    param_11 = (code *)0x0;
  }
  piVar4 = in_stack_00000054;
  if (in_stack_00000054 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000054 + 1;
    iVar7 = *piVar1;
    pcVar10 = (code *)*piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      puStack_210 = (undefined4 *)0x8d747b;
      pcVar10 = (code *)(**(code **)*in_stack_00000054)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        puStack_210 = (undefined4 *)0x8d748a;
        pcVar10 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar10;
}



/* FUNCTION 15222 ; VA 0x008d74a0 ; FUN_008d74a0 */

undefined4 * FUN_008d74a0(undefined4 *param_1,uint *param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000024;
  undefined uStack00000028;
  char cStack0000002b;
  undefined auStack_1c4 [72];
  undefined auStack_17c [72];
  undefined auStack_134 [72];
  undefined auStack_ec [72];
  undefined auStack_a4 [72];
  undefined auStack_5c [8];
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0741;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_5c;
  uStack_8 = 0;
  uStack_54 = 0;
  uVar5 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    uStack_54 = uVar5;
    if ((uVar5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))(param_2 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = param_2[2];
      uStack_48 = param_2[3];
      uStack_44 = param_2[4];
      uStack_40 = param_2[5];
      uStack_3c = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_34 = param_3;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&param_4);
  uStack_18 = uStack00000028;
  uStack_8._0_1_ = 2;
  FUN_008c0ef0(auStack_5c);
  uStack_8._0_1_ = 3;
  *param_1 = 0;
  FUN_008c0ef0(auStack_1c4);
  uStack_8._0_1_ = 4;
  FUN_008c0ef0(auStack_17c);
  uStack_8._0_1_ = 5;
  FUN_008c0ef0(auStack_134);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_a4);
  if (cVar1 == '\0') {
    FUN_008c0ef0(auStack_a4);
    uStack_8._0_1_ = 7;
    _uStack00000028 = FUN_01674e20(0x48);
    uStack_8._0_1_ = 8;
    if (_uStack00000028 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008c0ef0(auStack_ec);
    }
    param_1[2] = uVar2;
    FUN_008c30d0();
    FUN_008c30d0();
    _uStack00000028 = CONCAT13(1,_uStack00000028);
  }
  else {
    FUN_008c30d0();
    _uStack00000028 = _uStack00000028 & 0xffffff;
  }
  FUN_008c30d0();
  ppuVar3 = &PTR_FUN_01929894;
  if (cStack0000002b == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_008c30d0();
  FUN_008c30d0();
  FUN_008c30d0();
  if (0xf < in_stack_00000024) {
    uVar5 = in_stack_00000024 + 1;
    iVar4 = param_4;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_4 + -4);
      uVar5 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15223 ; VA 0x008d7690 ; FUN_008d7690 */

undefined4 * FUN_008d7690(undefined4 *param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  bool bVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_234 [88];
  undefined auStack_1dc [88];
  undefined auStack_184 [88];
  undefined auStack_12c [88];
  undefined auStack_d4 [88];
  undefined4 uStack_7c;
  int *piStack_78;
  uint uStack_74;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c07c4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_005c9c10(auStack_1c);
  piVar8 = (int *)puVar4[1];
  uStack_24 = *puVar4;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar4[1];
    if (piVar8 != (int *)0x0) {
      piVar9 = piVar8 + 2;
      LOCK();
      *piVar9 = *piVar9 + 1;
      UNLOCK();
      goto LAB_008d76de;
    }
  }
  piVar9 = piVar8 + 2;
LAB_008d76de:
  uStack_8 = 0;
  piStack_20 = piVar8;
  uStack_14 = uStack_24;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = *piVar9;
      *piVar9 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = &uStack_7c;
  piVar9 = piVar8 + 2;
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar9 = *piVar9 + 1;
    UNLOCK();
  }
  uStack_7c = uStack_14;
  uStack_8._0_1_ = 1;
  uStack_74 = 0;
  uVar1 = *param_2;
  piStack_78 = piVar8;
  if (uVar1 != 0) {
    uStack_74 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_6c,0);
    }
    else {
      uStack_6c = param_2[2];
      uStack_68 = param_2[3];
      uStack_64 = param_2[4];
      uStack_60 = param_2[5];
      uStack_5c = *(undefined8 *)(param_2 + 6);
    }
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_3);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(param_4);
  uStack_8._0_1_ = 4;
  FUN_008c1220(&uStack_7c);
  uStack_8._0_1_ = 5;
  *param_1 = 0;
  FUN_008c1220(auStack_234);
  uStack_8._0_1_ = 6;
  FUN_008c1220(auStack_1dc);
  uStack_8._0_1_ = 7;
  FUN_008c1220(auStack_184);
  uStack_8._0_1_ = 8;
  cVar3 = FUN_00585a40(auStack_d4);
  if (cVar3 == '\0') {
    FUN_008c1220(auStack_d4);
    uStack_8._0_1_ = 9;
    iVar5 = FUN_01674e20(0x58);
    uStack_8._0_1_ = 10;
    if (iVar5 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_008c1220(auStack_12c);
    }
    param_1[2] = uVar6;
    FUN_008c3410();
    FUN_008c3410();
    bVar2 = true;
  }
  else {
    FUN_008c3410();
    bVar2 = false;
  }
  FUN_008c3410();
  ppuVar7 = &PTR_FUN_0192989c;
  if (!bVar2) {
    ppuVar7 = (undefined **)0x0;
  }
  *param_1 = ppuVar7;
  FUN_008c3410();
  FUN_008c3410();
  FUN_008c3410();
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = *piVar9;
    *piVar9 = *piVar9 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      (**(code **)(*piVar8 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15224 ; VA 0x008d7910 ; FUN_008d7910 */

TypeDescriptor * __thiscall
FUN_008d7910(uint param_1,TypeDescriptor *param_2,TypeDescriptor *param_3,TypeDescriptor *param_4,
            TypeDescriptor *param_5,TypeDescriptor *param_6,undefined4 param_7,undefined4 param_8,
            TypeDescriptor *param_9,TypeDescriptor *param_10)

{
  void *pvVar1;
  void *pvVar2;
  void *pvVar3;
  TypeDescriptor *pTVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  TypeDescriptor *pTVar8;
  int *piVar9;
  bool bVar10;
  TypeDescriptor TStack_2e0;
  TypeDescriptor aTStack_2d8 [9];
  void *pvStack_290;
  void *pvStack_28c;
  void *pvStack_288;
  TypeDescriptor *pTStack_284;
  TypeDescriptor TStack_280;
  TypeDescriptor *pTStack_278;
  TypeDescriptor *pTStack_274;
  TypeDescriptor *pTStack_270;
  undefined8 uStack_26c;
  TypeDescriptor *pTStack_264;
  TypeDescriptor *pTStack_260;
  undefined auStack_244 [200];
  undefined4 auStack_17c [30];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  TypeDescriptor aTStack_e4 [3];
  undefined auStack_cc [24];
  undefined auStack_b4 [24];
  undefined *apuStack_9c [2];
  TypeDescriptor TStack_94;
  int *piStack_8c;
  TypeDescriptor *pTStack_88;
  undefined8 uStack_84;
  char acStack_7c [4];
  TypeDescriptor TStack_78;
  int *piStack_70;
  TypeDescriptor *pTStack_6c;
  undefined8 uStack_68;
  TypeDescriptor *pTStack_60;
  uint uStack_5c;
  TypeDescriptor aTStack_58 [2];
  TypeDescriptor TStack_48;
  TypeDescriptor TStack_40;
  int *piStack_38;
  TypeDescriptor *pTStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  int iStack_20;
  undefined4 uStack_1c;
  TypeDescriptor TStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0931;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_5c = param_1;
  if ((DAT_01d62fe8 != '\0') && (ExceptionList = &pvStack_10, *(char *)(param_1 + 300) != '\0')) {
    puVar7 = (undefined4 *)param_2[2].pVFTable;
    uStack_26c._4_4_ = (TypeDescriptor *)&DAT_0000000b;
    if (puVar7 < &DAT_0000000b) {
      uStack_26c._4_4_ = (TypeDescriptor *)puVar7;
    }
    uStack_26c._0_4_ = param_2;
    if ((void *)0xf < param_2[2].spare) {
      uStack_26c._0_4_ = (TypeDescriptor *)param_2->pVFTable;
    }
    pTStack_260 = (TypeDescriptor *)0xb;
    pTStack_264 = (TypeDescriptor *)0x18fbdcc;
    pTStack_270 = (TypeDescriptor *)0x8d797a;
    ExceptionList = &pvStack_10;
    iVar6 = FUN_0055c2d0();
    if (iVar6 != 0) {
      uStack_26c._4_4_ = (TypeDescriptor *)&DAT_00000004;
      if (puVar7 < &DAT_00000004) {
        uStack_26c._4_4_ = (TypeDescriptor *)puVar7;
      }
      uStack_26c._0_4_ = param_2;
      if ((void *)0xf < param_2[2].spare) {
        uStack_26c._0_4_ = (TypeDescriptor *)param_2->pVFTable;
      }
      pTStack_260 = (TypeDescriptor *)0x4;
      pTStack_264 = (TypeDescriptor *)&DAT_018c71bc;
      pTStack_270 = (TypeDescriptor *)0x8d79a9;
      iVar6 = FUN_0055c2d0();
      if (iVar6 != 0) {
LAB_008d7b91:
        pTStack_260 = param_10;
        pTStack_264 = param_9;
        uStack_26c._4_4_ = (TypeDescriptor *)param_8;
        uStack_26c._0_4_ = (TypeDescriptor *)param_7;
        pTStack_270 = param_6;
        pTStack_274 = param_5;
        pTStack_278 = param_4;
        TStack_280.spare = param_3;
        TStack_280.pVFTable = param_2;
        pTStack_284 = (TypeDescriptor *)0x8d7bb9;
        pTVar8 = (TypeDescriptor *)FUN_008d0f80();
        ExceptionList = pvStack_10;
        return pTVar8;
      }
      pTStack_264 = param_2;
      if ((void *)0xf < param_2[2].spare) {
        pTStack_264 = (TypeDescriptor *)param_2->pVFTable;
      }
      uStack_26c._4_4_ = (TypeDescriptor *)auStack_17c;
      uStack_26c._0_4_ = (TypeDescriptor *)0x8d79d7;
      pTStack_260 = (TypeDescriptor *)puVar7;
      FUN_0151bda0();
      pTStack_260 = (TypeDescriptor *)0x19296a8;
      uStack_8 = 0;
      pTStack_264 = (TypeDescriptor *)0x8d79f1;
      cVar5 = FUN_0151c660();
      uStack_8 = 0xffffffff;
      if (cVar5 == '\0') {
        pTStack_260 = (TypeDescriptor *)0x8d7b91;
        FUN_0056d9d0();
        goto LAB_008d7b91;
      }
      pTStack_260 = (TypeDescriptor *)0x8d7a0b;
      FUN_0056d9d0();
    }
  }
  if (param_2[2].pVFTable == (void *)0x0) {
    ExceptionList = pvStack_10;
    return (TypeDescriptor *)0x2;
  }
  pTStack_260 = param_2;
  pTStack_264 = (TypeDescriptor *)0x8d7a1d;
  cVar5 = FUN_008cc060();
  if (cVar5 == '\0') {
    ExceptionList = pvStack_10;
    return (TypeDescriptor *)0x2;
  }
  uStack_26c._4_4_ = (TypeDescriptor *)&DAT_0000000d;
  if (param_2[2].pVFTable < (void *)0xd) {
    uStack_26c._4_4_ = (TypeDescriptor *)param_2[2].pVFTable;
  }
  uStack_26c._0_4_ = param_2;
  if ((void *)0xf < param_2[2].spare) {
    uStack_26c._0_4_ = (TypeDescriptor *)param_2->pVFTable;
  }
  pTStack_260 = (TypeDescriptor *)0xd;
  pTStack_264 = (TypeDescriptor *)0x18db18c;
  pTStack_270 = (TypeDescriptor *)0x8d7a49;
  iVar6 = FUN_0055c2d0();
  if (iVar6 == 0) {
LAB_008d7a5f:
    pTStack_278 = (TypeDescriptor *)&pTStack_274;
    TStack_280.spare = (void *)0x8d7a6a;
    FUN_009cc5b0();
    pTStack_278 = &TStack_78;
    TStack_280.spare = (TypeDescriptor *)0x8d7a73;
    FUN_008cba30();
    if ((char)uStack_68 != '\0') {
      pTStack_260 = (TypeDescriptor *)piStack_70;
      pTStack_264 = (TypeDescriptor *)0x8d7a8b;
      FUN_00637330();
      pTStack_260 = &TStack_78;
      uStack_8 = 1;
      pTStack_264 = &TStack_40;
      uStack_26c._4_4_ = (TypeDescriptor *)0x8d7a9f;
      FUN_008cb670();
      uStack_8._0_1_ = 2;
      if (iStack_30 != 0) {
        if (param_5 != (TypeDescriptor *)0x0) {
          pTStack_260 = &TStack_40;
          pTStack_264 = aTStack_58;
          uStack_26c._4_4_ = (TypeDescriptor *)0x8d7ac8;
          uStack_26c._0_4_ = (TypeDescriptor *)FUN_0151a8d0();
          uStack_8._0_1_ = 3;
          if (7 < *(uint *)((int)(TypeDescriptor *)uStack_26c + 0x14)) {
            uStack_26c._0_4_ = *(TypeDescriptor **)(TypeDescriptor *)uStack_26c;
          }
          pTStack_260 = (TypeDescriptor *)0x1;
          pTStack_264 = (TypeDescriptor *)0x40;
          uStack_26c._4_4_ = (TypeDescriptor *)0x21;
          pTStack_270 = (TypeDescriptor *)0x8d7ae9;
          FUN_0054ebd0();
          uStack_8._0_1_ = 5;
          pTStack_260 = (TypeDescriptor *)0x8d7af5;
          FUN_00550800();
          pTStack_260 = (TypeDescriptor *)0x1;
          pTStack_264 = (TypeDescriptor *)0x2;
          uStack_26c._4_4_ = (TypeDescriptor *)0x8d7b04;
          FUN_00565520();
          pTStack_260 = (TypeDescriptor *)auStack_244;
          uStack_8._0_1_ = 6;
          pTStack_264 = (TypeDescriptor *)0x8d7b1a;
          FUN_0056f130();
          pTStack_260 = aTStack_58;
          pTStack_264 = (TypeDescriptor *)0x8d7b29;
          puVar7 = (undefined4 *)FUN_0058c400();
          pTStack_260 = (TypeDescriptor *)0x24;
          uStack_8._0_1_ = 7;
          pTStack_264 = (TypeDescriptor *)0x8d7b36;
          param_5 = (TypeDescriptor *)FUN_01674e20();
          if (param_5 == (TypeDescriptor *)0x0) {
            TStack_18.spare = (TypeDescriptor *)0x0;
          }
          else {
            param_5->spare = (void *)0x1;
            param_5[1].pVFTable = (void *)0x1;
            param_5->pVFTable =
                 std::
                 _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>
                 ::vftable;
            param_5[3].spare = (void *)0x0;
            param_5[4].pVFTable = (void *)0x0;
            pvVar1 = (void *)puVar7[1];
            pvVar2 = (void *)puVar7[2];
            pvVar3 = (void *)puVar7[3];
            param_5[1].spare = (void *)*puVar7;
            param_5[2].pVFTable = pvVar1;
            param_5[2].spare = pvVar2;
            param_5[3].pVFTable = pvVar3;
            *(undefined8 *)&param_5[3].spare = *(undefined8 *)(puVar7 + 4);
            puVar7[4] = 0;
            puVar7[5] = 0xf;
            *(undefined *)puVar7 = 0;
            TStack_18.spare = param_5;
          }
          TStack_18.pVFTable = &((TypeDescriptor *)((int)TStack_18.spare + 8))->spare;
          pTStack_260 = (TypeDescriptor *)0x8d7bde;
          FUN_005507b0();
          TStack_48.pVFTable = (void *)0x0;
          uStack_26c._4_4_ = &TStack_48;
          TStack_48.spare = (void *)0x0;
          uStack_26c._0_4_ = (TypeDescriptor *)0x8d7bfa;
          FUN_00557f90();
          pTStack_270 = &TStack_18;
          pTStack_274 = (TypeDescriptor *)0x8d7c08;
          FUN_00557fc0();
          pTStack_270 = (TypeDescriptor *)0x8d7c10;
          pTStack_260 = (TypeDescriptor *)FUN_008c2680();
          pTStack_264 = (TypeDescriptor *)0x8d7c18;
          FUN_008c45b0();
          pTStack_260 = (TypeDescriptor *)0x8d7c20;
          FUN_0056b650();
          pTStack_260 = (TypeDescriptor *)0x8d7c28;
          FUN_00550b30();
          pTStack_260 = (TypeDescriptor *)0x8d7c30;
          FUN_00550b30();
          pTStack_260 = (TypeDescriptor *)0x8d7c3b;
          FUN_00570540();
          pTStack_260 = (TypeDescriptor *)0x8d7c46;
          FUN_00551650();
        }
        pTStack_260 = (TypeDescriptor *)0x8d7c4e;
        FUN_005507b0();
        pTStack_260 = (TypeDescriptor *)0x8d7c56;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return (TypeDescriptor *)0x1;
      }
      pTStack_260 = (TypeDescriptor *)0x8d7c75;
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      pTStack_260 = (TypeDescriptor *)0x8d7c84;
      FUN_005507b0();
    }
  }
  else {
    pTStack_260 = (TypeDescriptor *)0x8d7a57;
    cVar5 = FUN_00782370();
    if (cVar5 != '\0') goto LAB_008d7a5f;
  }
  if (DAT_01ee4204 != 0) {
    if (param_6->pVFTable == (void *)0x0) {
      pTStack_260 = (TypeDescriptor *)0x0;
    }
    else {
      TStack_40.pVFTable =
           &boost::
            function<void___cdecl(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_istream<char,struct_std::char_traits<char>_>_>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>)>
            ::RTTI_Type_Descriptor;
      TStack_40.spare = (void *)CONCAT22(TStack_40.spare._2_2_,1);
      uStack_26c._4_4_ = param_6 + 1;
      pTStack_260 = (TypeDescriptor *)0x3;
      pTStack_264 = &TStack_40;
      uStack_26c._0_4_ = (TypeDescriptor *)0x8d7cb7;
      (**(code **)((uint)param_6->pVFTable & 0xfffffffe))();
      pTStack_260 = (TypeDescriptor *)TStack_40.pVFTable;
    }
    uStack_26c = (double)(float)param_4;
    pTStack_274 = param_2;
    if ((void *)0xf < param_2[2].spare) {
      pTStack_274 = (TypeDescriptor *)param_2->pVFTable;
    }
    pTStack_264 = param_5;
    pTStack_270 = param_3;
    TStack_280.spare = (void *)(uint)DAT_01ee4204;
    pTStack_278 = (TypeDescriptor *)0x1928f90;
    TStack_280.pVFTable = (TypeDescriptor *)0x8d7cf6;
    FUN_01677520();
  }
  if (*(int *)(param_1 + 0xb4) != 0) {
    pTStack_264 = (TypeDescriptor *)0x8d7d0c;
    pTStack_260 = (TypeDescriptor *)param_1;
    iVar6 = FUN_008f7870();
    if (iVar6 != 0) {
      pTStack_260 = *(TypeDescriptor **)(iVar6 + 0x444);
      pTStack_264 = *(TypeDescriptor **)(iVar6 + 0x440);
      uStack_26c._0_4_ = (TypeDescriptor *)acStack_7c;
      uStack_26c._4_4_ = param_2;
      pTStack_270 = (TypeDescriptor *)0x8d7d36;
      (**(code **)**(undefined4 **)(param_1 + 0xb4))();
      uStack_8 = 8;
      if (acStack_7c[0] != '\0') {
        TStack_18.pVFTable = (void *)0x0;
        TStack_18.spare = (void *)0x0;
        param_4 = (TypeDescriptor *)&pTStack_264;
        uStack_26c._4_4_ = &TStack_18;
        uStack_26c._0_4_ = (TypeDescriptor *)0x8d7d66;
        FUN_00557f90();
        uStack_26c._4_4_ = (TypeDescriptor *)0x24;
        uStack_8._0_1_ = 10;
        uStack_26c._0_4_ = (TypeDescriptor *)0x8d7d71;
        TStack_48.spare = (void *)FUN_01674e20();
        uStack_8._0_1_ = 0xb;
        param_3 = (TypeDescriptor *)TStack_48.spare;
        if ((undefined4 *)TStack_48.spare == (undefined4 *)0x0) {
          TStack_48.spare = (undefined4 *)0x0;
        }
        else {
          uStack_26c._4_4_ = &TStack_78;
          *(undefined4 *)((int)TStack_48.spare + 4) = 1;
          *(undefined4 *)((int)TStack_48.spare + 8) = 1;
          *(undefined ***)TStack_48.spare =
               std::
               _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
               ::vftable;
          uStack_26c._0_4_ = (TypeDescriptor *)0x8d7da1;
          FUN_0054ef60();
        }
        TStack_48.pVFTable = (void *)((int)TStack_48.spare + 0xc);
        pTStack_270 = &TStack_48;
        pTStack_274 = (TypeDescriptor *)0x8d7dbc;
        FUN_00557f90();
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        pTStack_270 = (TypeDescriptor *)0x8d7dc8;
        pTStack_260 = (TypeDescriptor *)FUN_008c2680();
        pTStack_264 = (TypeDescriptor *)0x8d7dd1;
        FUN_008c45b0();
        pTStack_260 = (TypeDescriptor *)0x8d7dd9;
        FUN_0056b650();
        pTStack_260 = (TypeDescriptor *)0x8d7de1;
        FUN_00550b30();
        pTStack_260 = (TypeDescriptor *)0x8d7de9;
        FUN_00550b30();
        if ((acStack_7c[0] != '\0') && (0xf < uStack_68._4_4_)) {
          pTStack_260 = (TypeDescriptor *)(uStack_68._4_4_ + 1);
          pTVar8 = (TypeDescriptor *)TStack_78.pVFTable;
          if (0xfff < pTStack_260) {
            pTVar8 = (TypeDescriptor *)((TypeDescriptor *)((int)TStack_78.pVFTable + -8))->spare;
            pTStack_260 = (TypeDescriptor *)(uStack_68._4_4_ + 0x24);
            if (0x1f < (uint)((int)TStack_78.pVFTable + (-4 - (int)pTVar8))) {
                    /* WARNING: Subroutine does not return */
              pTStack_260 = (TypeDescriptor *)0x8d85ff;
              FUN_017167a3();
            }
          }
          uStack_26c._4_4_ = (TypeDescriptor *)0x8d7e20;
          pTStack_264 = pTVar8;
          FUN_01674ea0();
        }
        ExceptionList = pvStack_10;
        return (TypeDescriptor *)0x1;
      }
      uStack_8 = 0xffffffff;
      param_1 = uStack_5c;
    }
  }
  uStack_26c._4_4_ = (TypeDescriptor *)(void *)0xa;
  if (param_2[2].pVFTable < (void *)0xa) {
    uStack_26c._4_4_ = (TypeDescriptor *)param_2[2].pVFTable;
  }
  uStack_26c._0_4_ = param_2;
  if ((void *)0xf < param_2[2].spare) {
    uStack_26c._0_4_ = (TypeDescriptor *)param_2->pVFTable;
  }
  pTStack_260 = (TypeDescriptor *)0xa;
  pTStack_264 = (TypeDescriptor *)0x18fbda8;
  pTStack_270 = (TypeDescriptor *)0x8d7e68;
  iVar6 = FUN_0055c2d0();
  if (iVar6 == 0) {
    ExceptionList = pvStack_10;
    return (TypeDescriptor *)0x2;
  }
  pTStack_260 = param_2;
  pTStack_264 = (TypeDescriptor *)0x8d7e7f;
  FUN_0054ef60();
  pTStack_260 = (TypeDescriptor *)param_7;
  uStack_8 = 0xc;
  pTStack_264 = (TypeDescriptor *)0x8d7e94;
  FUN_0054ef60();
  pTStack_260 = (TypeDescriptor *)param_8;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  pTStack_264 = (TypeDescriptor *)0x8d7ea6;
  FUN_0054ef60();
  uStack_8 = 0xe;
  if (param_3 != (TypeDescriptor *)0x3) {
    pTStack_260 = (TypeDescriptor *)0x8d7ebe;
    cVar5 = FUN_007822a0();
    if (cVar5 != '\0') {
      pTStack_264 = &TStack_78;
      pTStack_260 = param_2;
      uStack_26c._4_4_ = (TypeDescriptor *)0x8d7ed0;
      uStack_26c._4_4_ = (TypeDescriptor *)FUN_008cb670();
      uStack_26c._0_4_ = &TStack_48;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      pTStack_270 = (TypeDescriptor *)0x8d7ede;
      pTStack_260 = (TypeDescriptor *)FUN_008c0970();
      pTStack_264 = (TypeDescriptor *)0x8d7eea;
      FUN_00557f90();
      pTStack_260 = (TypeDescriptor *)0x8d7ef2;
      FUN_00550b30();
      pTStack_260 = (TypeDescriptor *)0x8d7efa;
      FUN_005507b0();
      if (*(int *)(iStack_20 + 0x10) != 0) {
LAB_008d7f2d:
        if (param_5 != (TypeDescriptor *)0x0) {
          uStack_26c._4_4_ = (TypeDescriptor *)&iStack_20;
          uStack_26c._0_4_ = (TypeDescriptor *)0x8d7f42;
          FUN_00557fc0();
          uStack_26c._4_4_ = (TypeDescriptor *)0x8d7f4a;
          pTStack_260 = (TypeDescriptor *)FUN_008c2740();
          pTStack_264 = (TypeDescriptor *)0x8d7f52;
          FUN_008c45b0();
          pTStack_260 = (TypeDescriptor *)0x8d7f5a;
          FUN_0056b650();
        }
        pTStack_260 = (TypeDescriptor *)0x8d7f62;
        FUN_00550b30();
        pTStack_260 = (TypeDescriptor *)0x8d7f6d;
        FUN_00637950();
        ExceptionList = pvStack_10;
        return (TypeDescriptor *)0x1;
      }
      pTStack_260 = (TypeDescriptor *)0x8d7f0b;
      FUN_00550b30();
      goto LAB_008d7f0b;
    }
    pTStack_260 = (TypeDescriptor *)0x8d7f8b;
    cVar5 = FUN_00782370();
    if (cVar5 == '\0') {
      pTStack_264 = &TStack_78;
      pTStack_260 = param_2;
      uStack_26c._4_4_ = (TypeDescriptor *)0x8d7f99;
      uStack_26c._4_4_ = (TypeDescriptor *)FUN_008cbc30();
      uStack_26c._0_4_ = &TStack_48;
      uStack_8._0_1_ = 0x10;
      pTStack_270 = (TypeDescriptor *)0x8d7fa7;
      pTStack_260 = (TypeDescriptor *)FUN_008c0970();
      pTStack_264 = (TypeDescriptor *)0x8d7fb3;
      FUN_00557f90();
      pTStack_260 = (TypeDescriptor *)0x8d7fbb;
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      pTStack_260 = (TypeDescriptor *)0x8d7fc7;
      FUN_005507b0();
      if (*(int *)(iStack_20 + 0x10) != 0) goto LAB_008d7f2d;
      pTStack_260 = (TypeDescriptor *)0x8d7fdc;
      FUN_00550b30();
    }
  }
  pTStack_260 = (TypeDescriptor *)0x8d7fe3;
  cVar5 = FUN_00782390();
  if (cVar5 == '\0') {
    if (param_3 == (TypeDescriptor *)0x1) {
      pTStack_260 = (TypeDescriptor *)0x8d83c4;
      cVar5 = FUN_00782370();
      if (cVar5 == '\0') goto LAB_008d7f0b;
    }
    else {
      if (param_3 == (TypeDescriptor *)0x2) {
        iStack_20 = 0;
        uStack_1c = 0;
        TStack_48.pVFTable = (void *)0x0;
        TStack_48.spare = (void *)0x0;
        TStack_18.pVFTable = (void *)0x0;
        TStack_18.spare = (void *)0x0;
        uStack_104 = 0;
        uStack_100 = 0;
        uStack_fc = 0;
        uStack_f8 = 0;
        uStack_f4 = 0;
        uStack_f0 = 0;
        uStack_ec = 0;
        uStack_e8 = 0;
        TStack_78.pVFTable = &param_6;
        TStack_78.spare = &TStack_48;
        piStack_70 = &iStack_20;
        pTStack_6c = &TStack_18;
        iStack_30 = (int)&param_3 + 3;
        puStack_2c = &uStack_104;
        pTStack_260 = &TStack_78;
        uStack_68 = CONCAT44(puStack_2c,iStack_30);
        param_3 = (TypeDescriptor *)0x2;
        pTStack_264 = (TypeDescriptor *)0x8d8268;
        TStack_40.pVFTable = TStack_78.pVFTable;
        TStack_40.spare = TStack_78.spare;
        piStack_38 = piStack_70;
        pTStack_34 = pTStack_6c;
        cVar5 = FUN_00585a40();
        if (cVar5 == '\0') {
          TStack_94.pVFTable = TStack_78.pVFTable;
          TStack_94.spare = TStack_78.spare;
          piStack_8c = piStack_70;
          pTStack_88 = pTStack_6c;
          apuStack_9c[0] = &DAT_01929945;
          uStack_84 = uStack_68;
        }
        else {
          apuStack_9c[0] = (undefined *)0x0;
        }
        pTStack_260 = (TypeDescriptor *)0x0;
        pTStack_264 = (TypeDescriptor *)&DAT_018bc9b8;
        uStack_8._0_1_ = 0x26;
        iStack_30 = 0;
        puStack_2c = (undefined4 *)0xf;
        TStack_40.pVFTable = (void *)((uint)TStack_40.pVFTable & 0xffffff00);
        uStack_26c._4_4_ = (TypeDescriptor *)0x8d82c3;
        FUN_005542c0();
        pTStack_278 = (TypeDescriptor *)apuStack_9c;
        pTStack_260 = (TypeDescriptor *)0x0;
        pTStack_264 = (TypeDescriptor *)0x1;
        uStack_26c._4_4_ = param_10;
        uStack_8._0_1_ = 0x27;
        uStack_26c._0_4_ = (TypeDescriptor *)0x0;
        pTStack_270 = (TypeDescriptor *)0x4;
        pTStack_274 = (TypeDescriptor *)0x0;
        TStack_280.spare = param_4;
        TStack_280.pVFTable = &TStack_40;
        pTStack_284 = aTStack_e4;
        pvStack_288 = (void *)0x8d82f8;
        FUN_00d1b340();
        pTStack_260 = (TypeDescriptor *)0x8d8300;
        FUN_005507b0();
        uStack_8._0_1_ = 0x25;
        pTStack_260 = (TypeDescriptor *)0x8d830f;
        FUN_00550990();
        if (param_3._3_1_ == '\0') {
          pTStack_60 = &TStack_18;
          uStack_5c = uStack_5c & 0xffffff00;
          pTStack_260 = (TypeDescriptor *)0x8d8327;
          FUN_00587410();
          uStack_8._0_1_ = 0x28;
          while (param_3._3_1_ == '\0') {
            pTStack_260 = (TypeDescriptor *)&pTStack_60;
            pTStack_264 = (TypeDescriptor *)0x8d8340;
            FUN_0058ca00();
          }
          uStack_8._0_1_ = 0x25;
          pTStack_260 = (TypeDescriptor *)0x8d8352;
          FUN_00550b60();
        }
        if (iStack_20 != 0) {
          pTStack_260 = (TypeDescriptor *)0x8d8607;
          piVar9 = (int *)FUN_0054db20();
          pTStack_260 = (TypeDescriptor *)0x8d8610;
          pTStack_260 = (TypeDescriptor *)(**(code **)(*piVar9 + 4))();
          pTStack_264 = (TypeDescriptor *)&DAT_018bd25c;
                    /* WARNING: Subroutine does not return */
          uStack_26c._4_4_ = (TypeDescriptor *)&UNK_008d861b;
          FUN_016757c0();
        }
        if (param_5 != (TypeDescriptor *)0x0) {
          pTStack_260 = &TStack_48;
          pTStack_264 = (TypeDescriptor *)0x8d836e;
          FUN_0056ecd0();
        }
        pTVar8 = param_6;
        pTStack_260 = (TypeDescriptor *)0x8d837c;
        FUN_0056e710();
        pTStack_260 = (TypeDescriptor *)TStack_18.spare;
        LOCK();
        TStack_18.spare = (void *)0x0;
        UNLOCK();
        if (pTStack_260 != (TypeDescriptor *)0x0) {
          pTStack_264 = (TypeDescriptor *)0x8d838e;
          CloseHandle();
        }
        pTStack_260 = (TypeDescriptor *)0x8d8396;
        FUN_00550b30();
        pTStack_260 = (TypeDescriptor *)0x8d839e;
        FUN_00550b30();
        pTStack_260 = (TypeDescriptor *)0x8d83a9;
        FUN_00637950();
        ExceptionList = pvStack_10;
        return pTVar8;
      }
      if (param_3 != (TypeDescriptor *)0x3) goto LAB_008d7f0b;
    }
    if (DAT_01ee4204 != 0) {
      if ((void *)0xf < param_2[2].spare) {
        param_2 = (TypeDescriptor *)param_2->pVFTable;
      }
      uStack_26c._4_4_ = (TypeDescriptor *)(uint)DAT_01ee4204;
      pTStack_264 = (TypeDescriptor *)0x192903c;
      uStack_26c._0_4_ = (TypeDescriptor *)0x8d83ec;
      pTStack_260 = param_2;
      FUN_01677650();
    }
    if (*(int *)(param_1 + 0xf4) == 0) {
      bVar10 = DAT_01d63008 == '\0';
      pTStack_260 = (TypeDescriptor *)0x0;
      iStack_30 = 0;
      puStack_2c = (undefined4 *)0xf;
      TStack_40.pVFTable = (void *)((uint)TStack_40.pVFTable & 0xffffff00);
      pTStack_264 = (TypeDescriptor *)&DAT_018bc9b8;
      if (bVar10) {
        uStack_26c._4_4_ = (TypeDescriptor *)0x8d85a1;
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
      }
      else {
        uStack_26c._4_4_ = (TypeDescriptor *)0x8d8594;
        FUN_005542c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
      }
      pTStack_260 = (TypeDescriptor *)(uint)!bVar10;
      TStack_280.pVFTable = &TStack_40;
      pTStack_264 = (TypeDescriptor *)0x1;
      uStack_26c._4_4_ = param_10;
      uStack_26c._0_4_ = (TypeDescriptor *)0x0;
      pTStack_270 = (TypeDescriptor *)0x4;
      pTStack_274 = param_9;
      pTStack_278 = param_6;
      TStack_280.spare = param_4;
      pTStack_284 = aTStack_e4;
      pvStack_288 = (void *)0x8d85d3;
      FUN_00d1b340();
      pTStack_260 = (TypeDescriptor *)0x8d85db;
      FUN_005507b0();
      goto LAB_008d85db;
    }
    pTStack_260 = aTStack_e4;
    pTStack_264 = (TypeDescriptor *)0x8d840b;
    cVar5 = FUN_00d1c770();
    if (cVar5 != '\0') {
LAB_008d7f0b:
      pTStack_260 = (TypeDescriptor *)0x8d7f16;
      FUN_00637950();
      ExceptionList = pvStack_10;
      return (TypeDescriptor *)0x2;
    }
    pTStack_260 = (TypeDescriptor *)&iStack_20;
    pTStack_264 = (TypeDescriptor *)0x8d841f;
    pTStack_260 = (TypeDescriptor *)FUN_005c9c10();
    pTStack_264 = &TStack_18;
    uStack_26c._4_4_ = (TypeDescriptor *)0x8d8429;
    pTStack_260 = (TypeDescriptor *)FUN_007291f0();
    pTStack_264 = (TypeDescriptor *)0x8d8435;
    FUN_005587b0();
    uStack_8._0_1_ = 0x19;
    pTStack_260 = (TypeDescriptor *)0x8d8441;
    FUN_00550b30();
    pTStack_260 = (TypeDescriptor *)0x8d8449;
    FUN_00550b30();
    pTStack_260 = (TypeDescriptor *)0x0;
    param_5 = aTStack_2d8;
    param_3 = aTStack_2d8;
    TStack_2e0.spare = aTStack_e4;
    TStack_2e0.pVFTable = (void *)0x8d8464;
    FUN_0054ef60();
    TStack_2e0.spare = auStack_cc;
    uStack_8._0_1_ = 0x1a;
    TStack_2e0.pVFTable = (void *)0x8d8477;
    FUN_0054ef60();
    TStack_2e0.spare = auStack_b4;
    uStack_8._0_1_ = 0x1b;
    TStack_2e0.pVFTable = (TypeDescriptor *)0x8d848a;
    FUN_0054ef60();
    if (TStack_48.spare != (void *)0x0) {
      LOCK();
      *(int *)((int)TStack_48.spare + 8) = *(int *)((int)TStack_48.spare + 8) + 1;
      UNLOCK();
    }
    pvStack_290 = TStack_48.pVFTable;
    pvStack_28c = TStack_48.spare;
    pvStack_288 = (void *)0x0;
    uStack_8._0_1_ = 0x1d;
    pvVar1 = param_6->pVFTable;
    if (pvVar1 != (void *)0x0) {
      pvStack_288 = pvVar1;
      if (((uint)pvVar1 & 1) == 0) {
        TStack_2e0.pVFTable = &TStack_280;
        TStack_2e0.spare = (void *)0x0;
        (**(code **)((uint)pvVar1 & 0xfffffffe))(param_6 + 1);
      }
      else {
        TStack_280.pVFTable = param_6[1].pVFTable;
        TStack_280.spare = param_6[1].spare;
        pTStack_278 = (TypeDescriptor *)param_6[2].pVFTable;
        pTStack_274 = (TypeDescriptor *)param_6[2].spare;
        pTStack_270 = (TypeDescriptor *)param_6[3].pVFTable;
        uStack_26c._0_4_ = (TypeDescriptor *)param_6[3].spare;
      }
    }
    uStack_26c._4_4_ = param_9;
    pTStack_264 = (TypeDescriptor *)CONCAT31(pTStack_264._1_3_,param_10._0_1_);
    uStack_8._0_1_ = 0x19;
    TStack_2e0.spare = (void *)0x8d850b;
    FUN_008bce40();
    pTStack_260 = (TypeDescriptor *)apuStack_9c;
    uStack_26c._4_4_ = aTStack_e4;
    pTStack_264 = param_4;
    uStack_8._0_1_ = 0x1e;
    uStack_26c._0_4_ = (TypeDescriptor *)0x8d8533;
    FUN_00f4e670();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
  }
  else {
    if (param_3 != (TypeDescriptor *)0x1) {
      pTStack_260 = param_2;
      pTStack_264 = (TypeDescriptor *)0x8d7ff7;
      FUN_008c8430();
      if (DAT_01d62f88 == '\0') {
        if ((void *)0xf < param_2[2].spare) {
          param_2 = (TypeDescriptor *)param_2->pVFTable;
        }
        pTStack_264 = (TypeDescriptor *)0x1928ff0;
        uStack_26c._4_4_ = (TypeDescriptor *)0x3;
        uStack_26c._0_4_ = (TypeDescriptor *)0x8d8018;
        pTStack_260 = param_2;
        FUN_0086f2f0();
      }
      pTStack_260 = (TypeDescriptor *)0x8d8026;
      FUN_00637950();
      ExceptionList = pvStack_10;
      return (TypeDescriptor *)0x2;
    }
    pTStack_260 = aTStack_e4;
    pTStack_264 = (TypeDescriptor *)0x8d804c;
    cVar5 = FUN_00d1c770();
    if (cVar5 != '\0') goto LAB_008d7f0b;
    pTStack_260 = (TypeDescriptor *)&iStack_20;
    pTStack_264 = (TypeDescriptor *)0x8d8060;
    pTStack_260 = (TypeDescriptor *)FUN_005c9c10();
    pTStack_264 = &TStack_18;
    uStack_26c._4_4_ = (TypeDescriptor *)0x8d806a;
    pTStack_260 = (TypeDescriptor *)FUN_007291f0();
    pTStack_264 = (TypeDescriptor *)0x8d8076;
    FUN_005587b0();
    uStack_8._0_1_ = 0x11;
    pTStack_260 = (TypeDescriptor *)0x8d8082;
    FUN_00550b30();
    pTStack_260 = (TypeDescriptor *)0x8d808a;
    FUN_00550b30();
    pTStack_260 = (TypeDescriptor *)0x0;
    param_5 = &TStack_2e0;
    param_3 = &TStack_2e0;
    FUN_0054ef60(aTStack_e4);
    uStack_8._0_1_ = 0x12;
    FUN_0054ef60(auStack_cc);
    uStack_8._0_1_ = 0x13;
    FUN_0054ef60(auStack_b4);
    pTVar8 = param_5;
    param_5[9].pVFTable = param_4;
    pTVar8[9].spare = (void *)0x0;
    pTVar8[10].pVFTable = (void *)0x0;
    if (TStack_48.spare != (void *)0x0) {
      LOCK();
      *(int *)((int)TStack_48.spare + 8) = *(int *)((int)TStack_48.spare + 8) + 1;
      UNLOCK();
    }
    pTVar8[9].spare = TStack_48.pVFTable;
    pTVar8[10].pVFTable = TStack_48.spare;
    pTVar4 = param_6;
    pTVar8[0xb].pVFTable = (void *)0x0;
    uStack_8._0_1_ = 0x15;
    pvVar1 = pTVar4->pVFTable;
    if (pvVar1 != (void *)0x0) {
      pTVar8[0xb].pVFTable = pvVar1;
      if (((uint)pvVar1 & 1) == 0) {
        (**(code **)((uint)pvVar1 & 0xfffffffe))(pTVar4 + 1,param_5 + 0xc,0);
        pTVar8 = param_5;
      }
      else {
        pvVar1 = pTVar4[1].spare;
        pvVar2 = pTVar4[2].pVFTable;
        pvVar3 = pTVar4[2].spare;
        pTVar8[0xc].pVFTable = pTVar4[1].pVFTable;
        pTVar8[0xc].spare = pvVar1;
        pTVar8[0xd].pVFTable = pvVar2;
        pTVar8[0xd].spare = pvVar3;
        pTVar8[0xe] = pTVar4[3];
      }
    }
    pTVar8[0xf].pVFTable = param_9;
    *(undefined *)&pTVar8[0xf].spare = param_10._0_1_;
    uStack_8._0_1_ = 0x11;
    FUN_008bc840();
    uStack_26c._4_4_ = &TStack_78;
    pTStack_260 = (TypeDescriptor *)0xffffffff;
    pTStack_264 = (TypeDescriptor *)0xb;
    uStack_8._0_1_ = 0x16;
    uStack_26c._0_4_ = (TypeDescriptor *)0x8d8180;
    pTStack_264 = (TypeDescriptor *)FUN_0058c540();
    pTStack_260 = (TypeDescriptor *)apuStack_9c;
    uStack_8._0_1_ = 0x17;
    uStack_26c._4_4_ = (TypeDescriptor *)0x8d8193;
    FUN_00f48670();
    pTStack_260 = (TypeDescriptor *)0x8d819b;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  }
  if (((apuStack_9c[0] != (undefined *)0x0) && (((uint)apuStack_9c[0] & 1) == 0)) &&
     (*(code **)((uint)apuStack_9c[0] & 0xfffffffe) != (code *)0x0)) {
    uStack_26c._4_4_ = &TStack_94;
    pTStack_260 = (TypeDescriptor *)0x2;
    uStack_26c._0_4_ = (TypeDescriptor *)0x8d855a;
    pTStack_264 = uStack_26c._4_4_;
    (**(code **)((uint)apuStack_9c[0] & 0xfffffffe))();
  }
  pTStack_260 = (TypeDescriptor *)0x8d8565;
  FUN_0056c200();
LAB_008d85db:
  pTStack_260 = (TypeDescriptor *)0x8d85e6;
  FUN_00637950();
  ExceptionList = pvStack_10;
  return (TypeDescriptor *)0x0;
}



/* FUNCTION 15225 ; VA 0x008d8620 ; FUN_008d8620 */

undefined __thiscall FUN_008d8620(undefined *param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  uint *puVar5;
  int **ppiVar6;
  char cVar7;
  undefined *puVar8;
  int iVar9;
  int *piVar10;
  undefined4 *puVar11;
  int iVar12;
  uint auStack_94 [2];
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int *piStack_78;
  int *piStack_74;
  int *piStack_70;
  uint auStack_6c [2];
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined *puStack_48;
  undefined **ppuStack_44;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined *puStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  piVar3 = param_2;
  puStack_c = &LAB_017c09b0;
  pvStack_10 = ExceptionList;
  iStack_38 = 0;
  iStack_34 = 0;
  iStack_30 = 0;
  uStack_8 = 0;
  iVar12 = *(int *)*param_2;
  ppuStack_44 = (undefined **)((((int *)*param_2)[1] - iVar12) / 0x1c);
  puStack_14 = param_1;
  if (ppuStack_44 == (undefined **)0x0) {
    param_2 = (int *)*param_2;
    ExceptionList = &pvStack_10;
  }
  else {
    if (0x9249249 < ppuStack_44) {
                    /* WARNING: Subroutine does not return */
      ppuStack_44 = (undefined **)&UNK_008d8c21;
      ExceptionList = &pvStack_10;
      FUN_00577c30();
    }
    puStack_48 = (undefined *)0x8d8694;
    ExceptionList = &pvStack_10;
    FUN_008c7ac0();
    param_2 = (int *)*param_2;
    iVar12 = *param_2;
  }
  iStack_1c = param_2[1];
  param_2 = (int *)iVar12;
  if (iVar12 != iStack_1c) {
    do {
      if (*(code **)((int)param_2 + 0x18) == FUN_008ccd50) {
        if (puStack_14 != (undefined *)0x0) {
          puStack_18 = *(undefined **)(puStack_14 + 0x34);
          puVar8 = puStack_14;
          if ((puStack_18 != (undefined *)0x0) &&
             (puVar8 = puStack_18, *(int *)(puStack_18 + 0x34) != 0)) {
            ppuStack_44 = (undefined **)0x8d86df;
            puVar8 = (undefined *)FUN_005c8ac0();
          }
          puStack_18 = puVar8;
          if (puVar8 != (undefined *)0x0) {
            iVar12 = *(int *)(puVar8 + 0xc);
            ppuStack_44 = (undefined **)0x8d86f7;
            iVar9 = FUN_008a8c30();
            puVar8 = puStack_18;
            if ((uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
                (uint)*(ushort *)(iVar9 + 0x1da)) {
              ppuStack_44 = (undefined **)0x8d8722;
              piVar10 = (int *)FUN_005c41d0();
              puStack_18 = (undefined *)*piVar10;
              if (puStack_18 == (undefined *)0x0) {
                ppuStack_44 = &puStack_2c;
                puStack_48 = (undefined *)0x8d8738;
                FUN_005c2e50();
                ppuStack_44 = (undefined **)puVar8;
                uStack_8 = CONCAT31(uStack_8._1_3_,1);
                puStack_48 = (undefined *)0x8d8748;
                FUN_008a5700();
                ppuStack_44 = (undefined **)&LAB_005c2490;
                puStack_48 = &DAT_01ea8c4c;
                iStack_4c = 0x8d8757;
                FUN_005789c0();
                ppuStack_44 = (undefined **)0x8d875f;
                ppuStack_44 = (undefined **)FUN_005c3850();
                puStack_48 = (undefined *)0x8d8767;
                puVar11 = (undefined4 *)FUN_008aa140();
                if (piStack_28 != (int *)0x0) {
                  LOCK();
                  piStack_28[1] = piStack_28[1] + 1;
                  UNLOCK();
                }
                *puVar11 = puStack_2c;
                piVar10 = (int *)puVar11[1];
                puVar11[1] = piStack_28;
                if (piVar10 != (int *)0x0) {
                  LOCK();
                  iVar12 = piVar10[1] + -1;
                  piVar10[1] = iVar12;
                  UNLOCK();
                  if (iVar12 == 0) {
                    ppuStack_44 = (undefined **)0x8d8796;
                    (**(code **)*piVar10)();
                    LOCK();
                    iVar12 = piVar10[2] + -1;
                    piVar10[2] = iVar12;
                    UNLOCK();
                    if (iVar12 == 0) {
                      ppuStack_44 = (undefined **)0x8d87a7;
                      (**(code **)(*piVar10 + 4))();
                    }
                  }
                }
                piVar10 = piStack_28;
                puStack_18 = puStack_2c;
                uStack_8 = uStack_8 & 0xffffff00;
                if (piStack_28 != (int *)0x0) {
                  LOCK();
                  iVar12 = piStack_28[1] + -1;
                  piStack_28[1] = iVar12;
                  UNLOCK();
                  if (iVar12 == 0) {
                    ppuStack_44 = (undefined **)0x8d87c8;
                    (**(code **)*piStack_28)();
                    LOCK();
                    piVar1 = piVar10 + 2;
                    iVar12 = *piVar1 + -1;
                    *piVar1 = iVar12;
                    UNLOCK();
                    if (iVar12 == 0) {
                      ppuStack_44 = (undefined **)0x8d87d9;
                      (**(code **)(*piVar10 + 4))();
                    }
                  }
                }
                if (puStack_18 == (undefined *)0x0) goto LAB_008d8ba1;
              }
              ppuStack_44 = (undefined **)param_2;
              puStack_48 = (undefined *)0x8d87ef;
              cVar7 = FUN_009dc670();
              ppuStack_44 = (undefined **)param_2;
              if (cVar7 == '\0') {
                puStack_48 = (undefined *)0x8d890d;
                cVar7 = FUN_009dc7e0();
                ppuStack_44 = (undefined **)param_2;
                if (cVar7 == '\0') {
                  if (iStack_30 == iStack_34) {
LAB_008d89b2:
                    puStack_48 = (undefined *)iStack_34;
                    iStack_4c = 0x8d89bb;
                    ppuStack_44 = (undefined **)param_2;
                    FUN_008bda90();
                  }
                  else {
LAB_008d8b86:
                    ppuStack_44 = (undefined **)param_2;
                    puStack_48 = (undefined *)0x8d8b8d;
                    FUN_0054ef60();
                    *(undefined4 *)(iStack_34 + 0x18) = *(undefined4 *)((int)param_2 + 0x18);
                    iStack_34 = iStack_34 + 0x1c;
                  }
                }
                else {
                  if (piVar3[0x15] != 0) {
                    LOCK();
                    piVar10 = (int *)(piVar3[0x15] + 4);
                    *piVar10 = *piVar10 + 1;
                    UNLOCK();
                  }
                  iStack_4c = piVar3[0x14];
                  puStack_48 = (undefined *)piVar3[0x15];
                  puStack_24 = (undefined *)auStack_6c;
                  uStack_8._0_1_ = 5;
                  piStack_70 = piVar3 + 0xc;
                  piStack_74 = (int *)0x8d8956;
                  FUN_0054f510();
                  puStack_20 = (undefined *)&piStack_74;
                  if (piVar3[0xb] != 0) {
                    LOCK();
                    piVar10 = (int *)(piVar3[0xb] + 4);
                    *piVar10 = *piVar10 + 1;
                    UNLOCK();
                  }
                  piStack_74 = (int *)piVar3[10];
                  piStack_70 = (int *)piVar3[0xb];
                  uStack_8._0_1_ = 7;
                  FUN_0054f510(piVar3 + 2);
                  uStack_8 = (uint)uStack_8._1_3_ << 8;
                  FUN_008d7140(2);
                }
              }
              else {
                if (piVar3[0x15] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0x15] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                iStack_4c = piVar3[0x14];
                puStack_48 = (undefined *)piVar3[0x15];
                puStack_18 = (undefined *)auStack_6c;
                puStack_20 = (undefined *)auStack_6c;
                uStack_8._0_1_ = 2;
                auStack_6c[0] = 0;
                uVar2 = piVar3[0xc];
                puVar5 = auStack_6c;
                if (uVar2 != 0) {
                  auStack_6c[0] = uVar2;
                  if ((uVar2 & 1) == 0) {
                    piStack_74 = &iStack_64;
                    piStack_70 = (int *)0x0;
                    piStack_78 = piVar3 + 0xe;
                    iStack_7c = 0x8d886b;
                    (**(code **)(uVar2 & 0xfffffffe))();
                    puVar5 = (uint *)puStack_18;
                  }
                  else {
                    iStack_64 = piVar3[0xe];
                    iStack_60 = piVar3[0xf];
                    iStack_5c = piVar3[0x10];
                    iStack_58 = piVar3[0x11];
                    iStack_54 = piVar3[0x12];
                    iStack_50 = piVar3[0x13];
                    puVar5 = auStack_6c;
                  }
                }
                puStack_18 = (undefined *)puVar5;
                puStack_20 = (undefined *)&piStack_74;
                if (piVar3[0xb] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0xb] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                piStack_74 = (int *)piVar3[10];
                piStack_70 = (int *)piVar3[0xb];
                puStack_24 = (undefined *)auStack_94;
                uStack_8._0_1_ = 4;
                auStack_94[0] = 0;
                uVar2 = piVar3[2];
                puVar5 = auStack_94;
                ppiVar6 = &piStack_74;
                if (uVar2 != 0) {
                  auStack_94[0] = uVar2;
                  if ((uVar2 & 1) != 0) {
                    iStack_8c = piVar3[4];
                    iStack_88 = piVar3[5];
                    iStack_84 = piVar3[6];
                    iStack_80 = piVar3[7];
                    iStack_7c = piVar3[8];
                    piStack_78 = (int *)piVar3[9];
                    uStack_8 = (uint)uStack_8._1_3_ << 8;
                    puStack_24 = (undefined *)auStack_94;
                    puStack_20 = (undefined *)&piStack_74;
                    FUN_008d7140(1);
                    goto LAB_008d8ba1;
                  }
                  (**(code **)(uVar2 & 0xfffffffe))(piVar3 + 4,&iStack_8c,0);
                  puVar5 = (uint *)puStack_24;
                  ppiVar6 = (int **)puStack_20;
                }
                puStack_20 = (undefined *)ppiVar6;
                puStack_24 = (undefined *)puVar5;
                uStack_8 = (uint)uStack_8._1_3_ << 8;
                FUN_008d7140(1);
              }
            }
          }
        }
      }
      else if ((*(code **)((int)param_2 + 0x18) == FUN_008ccd80) && (puStack_14 != (undefined *)0x0)
              ) {
        puStack_18 = *(undefined **)(puStack_14 + 0x34);
        puVar8 = puStack_14;
        if ((puStack_18 != (undefined *)0x0) &&
           (puVar8 = puStack_18, *(int *)(puStack_18 + 0x34) != 0)) {
          ppuStack_44 = (undefined **)0x8d89ec;
          puVar8 = (undefined *)FUN_005c8ac0();
        }
        puStack_18 = puVar8;
        if (puVar8 != (undefined *)0x0) {
          iVar12 = *(int *)(puVar8 + 0xc);
          ppuStack_44 = (undefined **)0x8d8a04;
          iVar9 = FUN_008a8c30();
          if ((uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
              (uint)*(ushort *)(iVar9 + 0x1da)) {
            ppuStack_44 = (undefined **)0x8d8a2d;
            puStack_18 = (undefined *)FUN_005c34e0();
            if (puStack_18 != (undefined *)0x0) {
              ppuStack_44 = (undefined **)param_2;
              puStack_48 = (undefined *)0x8d8a43;
              cVar7 = FUN_009dc670();
              ppuStack_44 = (undefined **)param_2;
              if (cVar7 == '\0') {
                puStack_48 = (undefined *)0x8d8ae4;
                cVar7 = FUN_009dc7e0();
                ppuStack_44 = (undefined **)param_2;
                if (cVar7 == '\0') {
                  if (iStack_30 == iStack_34) goto LAB_008d89b2;
                  goto LAB_008d8b86;
                }
                if (piVar3[0x15] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0x15] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                iStack_4c = piVar3[0x14];
                puStack_48 = (undefined *)piVar3[0x15];
                puStack_24 = (undefined *)auStack_6c;
                uStack_8._0_1_ = 0xb;
                piStack_70 = piVar3 + 0xc;
                piStack_74 = (int *)0x8d8b2d;
                FUN_0054f510();
                puStack_20 = (undefined *)&piStack_74;
                if (piVar3[0xb] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0xb] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                piStack_74 = (int *)piVar3[10];
                piStack_70 = (int *)piVar3[0xb];
                uStack_8._0_1_ = 0xd;
                FUN_0054f510(piVar3 + 2);
                uStack_8 = (uint)uStack_8._1_3_ << 8;
                FUN_008d7140(2);
              }
              else {
                if (piVar3[0x15] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0x15] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                iStack_4c = piVar3[0x14];
                puStack_48 = (undefined *)piVar3[0x15];
                puStack_24 = (undefined *)auStack_6c;
                uStack_8._0_1_ = 8;
                piStack_70 = piVar3 + 0xc;
                piStack_74 = (int *)0x8d8a8c;
                FUN_0054f510();
                puStack_20 = (undefined *)&piStack_74;
                if (piVar3[0xb] != 0) {
                  LOCK();
                  piVar10 = (int *)(piVar3[0xb] + 4);
                  *piVar10 = *piVar10 + 1;
                  UNLOCK();
                }
                piStack_74 = (int *)piVar3[10];
                piStack_70 = (int *)piVar3[0xb];
                uStack_8._0_1_ = 10;
                FUN_0054f510(piVar3 + 2);
                uStack_8 = (uint)uStack_8._1_3_ << 8;
                FUN_008d7140(1);
              }
            }
          }
        }
      }
LAB_008d8ba1:
      param_2 = (int *)((int)param_2 + 0x1c);
    } while (param_2 != (int *)iStack_1c);
  }
  iVar12 = iStack_34 - iStack_38 >> 0x1f;
  if ((iStack_34 - iStack_38) / 0x1c + iVar12 == iVar12) {
    param_2._3_1_ = 1;
  }
  else {
    piVar3 = (int *)*piVar3;
    if (piVar3 != &iStack_38) {
      iVar12 = *piVar3;
      *piVar3 = iStack_38;
      iVar9 = piVar3[1];
      piVar3[1] = iStack_34;
      iVar4 = piVar3[2];
      piVar3[2] = iStack_30;
      iStack_38 = iVar12;
      iStack_34 = iVar9;
      iStack_30 = iVar4;
    }
    param_2._3_1_ = 0;
  }
  ppuStack_44 = (undefined **)0x8d8c07;
  FUN_006b35b0();
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 15226 ; VA 0x008d8c30 ; FUN_008d8c30 */

undefined4 ***** FUN_008d8c30(undefined4 *****param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *****pppppuVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  uint uVar9;
  undefined4 *****pppppuVar10;
  undefined auStack_520 [1200];
  int aiStack_70 [5];
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [4];
  int iStack_4c;
  undefined4 ****appppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  undefined4 ****ppppuStack_30;
  undefined4 ***pppuStack_2c;
  undefined4 ***pppuStack_28;
  undefined4 ***pppuStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 ****ppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c0a25;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = (undefined4 ****)0x0;
  param_1[5] = (undefined4 ****)0xf;
  *(char *)param_1 = '\0';
  iStack_8 = 0;
  uStack_18 = 1;
  FUN_01530880();
  iStack_8 = 1;
  FUN_00f453a0(param_2);
  FUN_01531240(aiStack_70);
  uStack_18 = 3;
  iStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_70);
  iStack_8._0_1_ = 3;
  FUN_009cbbb0(&ppppuStack_30);
  iStack_8._0_1_ = 2;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (param_1 == &ppppuStack_30) {
    if (0xf < uStack_1c) {
      uVar9 = uStack_1c + 1;
      ppppuVar7 = ppppuStack_30;
      if (0xfff < uVar9) {
        ppppuVar7 = (undefined4 ****)ppppuStack_30[-1];
        uVar9 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)ppppuStack_30 + (-4 - (int)ppppuVar7))) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar7,uVar9);
    }
  }
  else {
    FUN_005507b0();
    *param_1 = ppppuStack_30;
    param_1[1] = (undefined4 ****)pppuStack_2c;
    param_1[2] = (undefined4 ****)pppuStack_28;
    param_1[3] = (undefined4 ****)pppuStack_24;
    *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_1c,uStack_20);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
  iStack_8._0_1_ = 1;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_5c) {
    uVar9 = uStack_5c + 1;
    iVar8 = aiStack_70[0];
    if (0xfff < uVar9) {
      iVar8 = *(int *)(aiStack_70[0] + -4);
      uVar9 = uStack_5c + 0x24;
      if (0x1f < (aiStack_70[0] - iVar8) - 4U) {
        iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00550be0();
  FUN_008ce340(appppuStack_48,1);
  iStack_8 = 4;
  ppppuStack_14 = param_1;
  if ((undefined4 ****)0xf < param_1[5]) {
    ppppuStack_14 = *param_1;
  }
  if (*(char *)ppppuStack_14 != '\0') {
    iStack_4c = FUN_01687bc0();
    uVar3 = FUN_01686580();
    FUN_01685950(ppppuStack_14,0,appppuStack_48,uVar3);
    if (iStack_4c != 0) {
      FUN_01687c10(iStack_4c);
    }
  }
  uStack_58 = 0;
  uStack_54 = FUN_01685730();
  piVar4 = (int *)FUN_0168e1c0(auStack_50,appppuStack_48,&uStack_58);
  if ((*piVar4 == 0) || (*piVar4 == 1)) {
    iStack_8._0_1_ = 5;
    uStack_20 = 0;
    uStack_1c = 0xf;
    ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
    uStack_18 = 7;
    if (iStack_38 != 0) {
      pppppuVar5 = appppuStack_48;
      if (7 < uStack_34) {
        pppppuVar5 = (undefined4 *****)appppuStack_48[0];
      }
      pppppuVar10 = appppuStack_48;
      if (7 < uStack_34) {
        pppppuVar10 = (undefined4 *****)appppuStack_48[0];
      }
      uVar3 = FUN_01686580();
      FUN_01685a20(pppppuVar10,(int)pppppuVar5 + iStack_38 * 2,&ppppuStack_30,uVar3);
    }
    pppppuVar5 = &ppppuStack_30;
    if (0xf < uStack_1c) {
      pppppuVar5 = (undefined4 *****)ppppuStack_30;
    }
    FUN_00565320(pppppuVar5,0x22,0x40,1);
    uStack_18 = 3;
    iStack_8 = CONCAT31(iStack_8._1_3_,7);
    if (0xf < uStack_1c) {
      uVar9 = uStack_1c + 1;
      pppppuVar5 = (undefined4 *****)ppppuStack_30;
      if (0xfff < uVar9) {
        pppppuVar5 = (undefined4 *****)ppppuStack_30[-1];
        uVar9 = uStack_1c + 0x24;
        if (0x1f < (uint)((int)ppppuStack_30 + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar9);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    uVar3 = 4;
    ppppuStack_30 = (undefined4 ****)((uint)ppppuStack_30 & 0xffffff00);
    if (*(int *)((int)param_2 + *(int *)(*param_2 + 4) + 0x38) != 0) {
      uVar3 = 0;
    }
    FUN_00554460(uVar3,0);
    FUN_005956d0(0,0,0);
    do {
      do {
        FUN_005af630(auStack_520,0x400,0);
        FUN_005af750(auStack_520,param_2[2],param_2[3]);
      } while (0 < param_2[3]);
    } while ((-1 < param_2[3]) && (param_2[2] != 0));
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    FUN_00570460();
  }
  if ((DAT_01d63018 != '\0') && (param_3 != (undefined4 *)0x0)) {
    puVar6 = (undefined4 *)FUN_005569d0(aiStack_70);
    iStack_8 = CONCAT31(iStack_8._1_3_,8);
    if (param_3 != puVar6) {
      puVar1 = puVar6 + 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_005542c0(puVar6,*puVar1);
    }
    FUN_005507b0();
  }
  if (7 < uStack_34) {
    uVar9 = uStack_34 * 2 + 2;
    pppppuVar5 = (undefined4 *****)appppuStack_48[0];
    if (0xfff < uVar9) {
      pppppuVar5 = (undefined4 *****)appppuStack_48[0][-1];
      uVar9 = uStack_34 * 2 + 0x25;
      if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar9);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15227 ; VA 0x008d8fe0 ; FUN_008d8fe0 */

void __thiscall FUN_008d8fe0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (((DAT_01d62fd8 != '\0') && (ExceptionList = &pvStack_10, DAT_01d62fc0 != '\0')) &&
     (ExceptionList = &pvStack_10, (undefined4 **)(param_1 + 0x80) != &param_2)) {
    puVar1 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar1 = param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,in_stack_00000014);
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    puVar1 = param_2;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_2[-1];
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15228 ; VA 0x008d9080 ; FUN_008d9080 */

void FUN_008d9080(int param_1)

{
  int iVar1;
  uint in_stack_00000018;
  undefined auStack_30 [12];
  undefined4 uStack_24;
  int iStack_20;
  undefined *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d5a0a8 != '\0') {
    iStack_20 = 0x8d90b2;
    ExceptionList = &pvStack_10;
    iVar1 = FUN_005eef10();
    if (iVar1 != 0) {
      puStack_1c = (undefined *)0x8d90c0;
      iVar1 = FUN_00688090();
      if (iVar1 != 0) {
        FUN_00630580(auStack_30,&param_1);
        FUN_008d8fe0();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    puStack_1c = (undefined *)(in_stack_00000018 + 1);
    iVar1 = param_1;
    if (0xfff < puStack_1c) {
      iVar1 = *(int *)(param_1 + -4);
      puStack_1c = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_1c = &UNK_008d9122;
        FUN_017167a3();
      }
    }
    uStack_24 = 0x8d9109;
    iStack_20 = iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15229 ; VA 0x008d9130 ; FUN_008d9130 */

void FUN_008d9130(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0a40;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d62fd8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_008c4650(&param_1);
    if ((undefined4 **)(iVar1 + 0x18) != &stack0x0000001c) {
      puVar2 = &stack0x0000001c;
      if (0xf < in_stack_00000030) {
        puVar2 = in_stack_0000001c;
      }
      FUN_005542c0(puVar2,in_stack_0000002c);
    }
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    uVar4 = in_stack_00000030 + 1;
    puVar2 = in_stack_0000001c;
    if (0xfff < uVar4) {
      puVar2 = (undefined4 *)in_stack_0000001c[-1];
      uVar4 = in_stack_00000030 + 0x24;
      if (0x1f < (uint)((int)in_stack_0000001c + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15230 ; VA 0x008d9210 ; FUN_008d9210 */

void FUN_008d9210(uint param_1)

{
  int iVar1;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0a68;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d5a0a8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_005eef10();
    if (iVar1 != 0) {
      iVar1 = FUN_00688090();
      if (iVar1 != 0) {
        FUN_00630580();
        uStack_8._0_1_ = 2;
        FUN_0054ef60(&param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_008d9130();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    if (0xfff < in_stack_00000018 + 1) {
      if (0x1f < (param_1 - *(int *)(param_1 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    if (0xfff < in_stack_00000030 + 1) {
      if (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15231 ; VA 0x008d9320 ; FUN_008d9320 */

void FUN_008d9320(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  return;
}



/* FUNCTION 15232 ; VA 0x008d9340 ; FUN_008d9340 */

/* WARNING: Type propagation algorithm not settling */

int * FUN_008d9340(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_1a4 [164];
  int iStack_100;
  undefined **appuStack_fc [15];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b0;
  undefined **ppuStack_ac;
  undefined auStack_64 [24];
  undefined auStack_4c [8];
  uint auStack_44 [2];
  undefined auStack_3c [24];
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0aed;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  if (DAT_01d62f48 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_008d9600(param_1,param_2,param_3,param_4,&DAT_01d62f20,param_5);
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  iStack_20 = 0;
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  auStack_44[0] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  iVar2 = FUN_008d7910(auStack_64,1,param_3,&iStack_20,auStack_44,param_4,&DAT_01d62f20,0,param_5);
  uStack_8._0_1_ = 3;
  if (((auStack_44[0] != 0) && ((auStack_44[0] & 1) == 0)) &&
     (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_44[0] & 0xfffffffe))(auStack_3c,auStack_3c,2);
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (iVar2 == 1) {
    if (iStack_20 == 0) {
      uVar3 = FUN_01675290(DAT_01f6dd5c);
      uStack_8._0_1_ = 4;
      puVar4 = (undefined4 *)FUN_0151a8d0(auStack_3c,uStack_18);
      uStack_8._0_1_ = 5;
      if (7 < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0054ebd0(puVar4,0x21,0x40,1);
      FUN_00550800();
      appuStack_fc[0] = &PTR_018be314;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      uStack_24 = 2;
      ppuStack_ac = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
      uStack_b0 = 0x48;
      FUN_00554f20(appuStack_fc + 1,0);
      uStack_8 = 10;
      *(undefined ***)(appuStack_fc[0][1] + (int)appuStack_fc) =
           std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>
           ::vftable;
      *(undefined **)((int)&iStack_100 + (int)appuStack_fc[0][1]) = appuStack_fc[0][1] + -0x50;
      FUN_0054ee60();
      appuStack_fc[1] =
           std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      uStack_c0 = 0;
      uStack_bc = 4;
      uStack_8._0_1_ = 0xb;
      FUN_0056f130(auStack_1a4);
      uVar5 = FUN_0058c400(auStack_3c);
      uStack_8._0_1_ = 0xc;
      uVar5 = FUN_008c0970(auStack_4c,uVar5);
      FUN_005587e0(uVar5);
      FUN_00550b30();
      FUN_005507b0();
      FUN_00570540();
      FUN_00551650();
      uStack_8._0_1_ = 0xd;
      FUN_01675290(uVar3);
      uVar1 = (undefined)uStack_8;
    }
    uStack_8._0_1_ = uVar1;
    *param_1 = 0;
    param_1[1] = 0;
    if (iStack_1c != 0) {
      LOCK();
      *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
      UNLOCK();
    }
    *param_1 = iStack_20;
    param_1[1] = iStack_1c;
  }
  else {
    *param_1 = 0;
    param_1[1] = 0;
    uStack_8._0_1_ = uVar1;
  }
  FUN_0056b650();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15233 ; VA 0x008d9600 ; FUN_008d9600 */

/* WARNING: Type propagation algorithm not settling */

int * FUN_008d9600(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_1a4 [164];
  int iStack_100;
  undefined **appuStack_fc [15];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b0;
  undefined **ppuStack_ac;
  undefined auStack_64 [24];
  undefined auStack_4c [8];
  uint auStack_44 [2];
  undefined auStack_3c [24];
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0aed;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  if (DAT_01d62f48 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_2);
    iStack_20 = 0;
    iStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    auStack_44[0] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    iVar2 = FUN_008d7910(auStack_64,1,param_3,&iStack_20,auStack_44,param_4,param_5,0,param_6);
    uStack_8._0_1_ = 3;
    if (((auStack_44[0] != 0) && ((auStack_44[0] & 1) == 0)) &&
       (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_44[0] & 0xfffffffe))(auStack_3c,auStack_3c,2);
    }
    uStack_8._0_1_ = 1;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (iVar2 == 1) {
      if (iStack_20 == 0) {
        uVar3 = FUN_01675290(DAT_01f6dd5c);
        uStack_8._0_1_ = 4;
        puVar4 = (undefined4 *)FUN_0151a8d0(auStack_3c,uStack_18);
        uStack_8._0_1_ = 5;
        if (7 < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_0054ebd0(puVar4,0x21,0x40,1);
        FUN_00550800();
        appuStack_fc[0] = &PTR_018be314;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        uStack_24 = 2;
        ppuStack_ac = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
        uStack_b0 = 0x48;
        FUN_00554f20(appuStack_fc + 1,0);
        uStack_8 = 10;
        *(undefined ***)(appuStack_fc[0][1] + (int)appuStack_fc) =
             std::
             basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        *(undefined **)((int)&iStack_100 + (int)appuStack_fc[0][1]) = appuStack_fc[0][1] + -0x50;
        FUN_0054ee60();
        appuStack_fc[1] =
             std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        uStack_c0 = 0;
        uStack_bc = 4;
        uStack_8._0_1_ = 0xb;
        FUN_0056f130(auStack_1a4);
        uVar5 = FUN_0058c400(auStack_3c);
        uStack_8._0_1_ = 0xc;
        uVar5 = FUN_008c0970(auStack_4c,uVar5);
        FUN_005587e0(uVar5);
        FUN_00550b30();
        FUN_005507b0();
        FUN_00570540();
        FUN_00551650();
        uStack_8._0_1_ = 0xd;
        FUN_01675290(uVar3);
        uVar1 = (undefined)uStack_8;
      }
      uStack_8._0_1_ = uVar1;
      *param_1 = 0;
      param_1[1] = 0;
      if (iStack_1c != 0) {
        LOCK();
        *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
        UNLOCK();
      }
      *param_1 = iStack_20;
      param_1[1] = iStack_1c;
    }
    else {
      *param_1 = 0;
      param_1[1] = 0;
    }
    FUN_0056b650();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 15234 ; VA 0x008d98b0 ; FUN_008d98b0 */

void FUN_008d98b0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uStack_5c;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c0b28;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_3c;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_3c = param_1;
  piStack_38 = param_2;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60();
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piStack_38[2] = piStack_38[2] + 1;
    UNLOCK();
  }
  uStack_8 = 3;
  FUN_0054ef60(auStack_34);
  uStack_8 = 2;
  FUN_008bcfd0();
  FUN_005d11a0();
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_01534720();
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  _uStack_8 = CONCAT31(uStack_7,5);
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15235 ; VA 0x008d9a00 ; FUN_008d9a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_008d9a00(char *param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined4 *****pppppuVar8;
  char *pcVar9;
  uint uVar10;
  int iVar11;
  undefined auStack_c0 [24];
  undefined2 auStack_a8 [8];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined auStack_90 [24];
  undefined4 ****appppuStack_78 [4];
  int iStack_68;
  uint uStack_64;
  undefined2 auStack_60 [8];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  int iStack_44;
  undefined4 ****ppppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****ppppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0c13;
  pvStack_10 = ExceptionList;
  iStack_44 = 0;
  if (DAT_01ee01a2 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8d != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677650(DAT_01d84e8d,"setAssetFolder %s",param_1);
    }
    iStack_18 = 0;
    uStack_14 = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    pcVar9 = param_1;
    do {
      cVar2 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_1,(int)pcVar9 - (int)(param_1 + 1));
    uStack_8 = 0;
    uVar4 = FUN_008da620(auStack_60,&ppppuStack_28);
    uStack_8._0_1_ = 1;
    FUN_0168e430(auStack_90,uVar4,0);
    FUN_00550800();
    uStack_8._0_1_ = 4;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      ppppuVar7 = ppppuStack_28;
      if (0xfff < uVar10) {
        ppppuVar7 = (undefined4 ****)ppppuStack_28[-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)ppppuVar7))) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar7,uVar10);
    }
    piVar5 = (int *)FUN_0168e1c0(auStack_48,auStack_90,0);
    iStack_44 = piVar5[1];
    if ((*piVar5 == 0) || (*piVar5 == 1)) {
      FUN_005569d0(auStack_c0);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("The path \'%s\' does not exist",uVar4);
    }
    piVar5 = (int *)FUN_0168e1c0(auStack_48,auStack_90,0);
    iStack_44 = piVar5[1];
    if (*piVar5 != 3) {
      FUN_005569d0(auStack_c0);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("\'%s\' is not a directory",uVar4);
    }
    FUN_008c8270(auStack_90);
    uStack_98 = 0;
    uStack_94 = 7;
    auStack_a8[0] = 0;
    uStack_8._0_1_ = 7;
    iStack_68 = 0;
    uStack_64 = 0xf;
    appppuStack_78[0] = (undefined4 ****)((uint)appppuStack_78[0] & 0xffffff00);
    FUN_005542c0("../PlatformContent/pc/",0x16);
    uStack_8._0_1_ = 8;
    if (iStack_68 != 0) {
      pppppuVar8 = appppuStack_78;
      if (0xf < uStack_64) {
        pppppuVar8 = (undefined4 *****)appppuStack_78[0];
      }
      iVar11 = (int)pppppuVar8 + iStack_68;
      pppppuVar8 = appppuStack_78;
      if (0xf < uStack_64) {
        pppppuVar8 = (undefined4 *****)appppuStack_78[0];
      }
      uVar4 = FUN_01686580();
      FUN_01685950(pppppuVar8,iVar11,auStack_a8,uVar4);
    }
    uStack_8._0_1_ = 7;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_64) {
      uVar10 = uStack_64 + 1;
      pppppuVar8 = (undefined4 *****)appppuStack_78[0];
      if (0xfff < uVar10) {
        pppppuVar8 = (undefined4 *****)appppuStack_78[0][-1];
        uVar10 = uStack_64 + 0x24;
        if (0x1f < (uint)((int)appppuStack_78[0] + (-4 - (int)pppppuVar8))) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar8,uVar10);
    }
    iStack_68 = 0;
    uStack_64 = 0xf;
    appppuStack_78[0] = (undefined4 ****)((uint)appppuStack_78[0] & 0xffffff00);
    uStack_8._0_1_ = 9;
    FUN_0151a940(&ppppuStack_28,auStack_90);
    FUN_005507b0();
    DAT_01d63188 = ppppuStack_28;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    uRam01d6318c = uStack_24;
    uRam01d63190 = uStack_20;
    uRam01d63194 = uStack_1c;
    _DAT_01d63198 = CONCAT44(uStack_14,iStack_18);
    iStack_18 = 0;
    uStack_14 = 0xf;
    FUN_005507b0();
    puVar6 = (undefined4 *)FUN_005569d0(auStack_60);
    uStack_8._0_1_ = 0xb;
    iStack_18 = 0;
    uStack_14 = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    iStack_44 = 7;
    FUN_0058a190(DAT_01d63198 + puVar6[4]);
    ppppuVar7 = &DAT_01d63188;
    if (0xf < DAT_01d6319c) {
      ppppuVar7 = DAT_01d63188;
    }
    FUN_00554150(ppppuVar7,DAT_01d63198);
    puVar1 = puVar6 + 4;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_00554150(puVar6,*puVar1);
    FUN_005507b0();
    _DAT_01d631a0 = ppppuStack_28;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    uRam01d631a4 = uStack_24;
    uRam01d631a8 = uStack_20;
    uRam01d631ac = uStack_1c;
    _DAT_01d631b0 = CONCAT44(uStack_14,iStack_18);
    iStack_18 = 0;
    uStack_14 = 0xf;
    FUN_005507b0();
    uStack_8._0_1_ = 9;
    FUN_005507b0();
    FUN_0168bf40(auStack_60,0);
    uStack_8._0_1_ = 0xc;
    FUN_0168b4a0(&ppppuStack_40,auStack_90,auStack_60,0);
    pppppuVar8 = &ppppuStack_40;
    if (7 < uStack_2c) {
      pppppuVar8 = (undefined4 *****)ppppuStack_40;
    }
    uStack_8._0_1_ = 0xd;
    FUN_0058ed10(pppppuVar8,uStack_30);
    FUN_00550800();
    uStack_8._0_1_ = 9;
    FUN_00550800();
    FUN_0168bf40(auStack_60,0);
    uStack_8._0_1_ = 0xe;
    uVar4 = FUN_005514a0(&ppppuStack_28,auStack_90,auStack_a8);
    uStack_8._0_1_ = 0xf;
    FUN_0168b4a0(&ppppuStack_40,uVar4,auStack_60,0);
    pppppuVar8 = &ppppuStack_40;
    if (7 < uStack_2c) {
      pppppuVar8 = (undefined4 *****)ppppuStack_40;
    }
    uStack_8._0_1_ = 0x10;
    FUN_0058ed10(pppppuVar8,uStack_30);
    FUN_00550800();
    FUN_00550800();
    FUN_00550800();
    uStack_50 = 0;
    uStack_4c = 7;
    auStack_60[0] = 0;
    uStack_8._0_1_ = 0x11;
    iStack_18 = 0;
    uStack_14 = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    FUN_005542c0("../ExtraContent/",0x10);
    uStack_8._0_1_ = 0x12;
    if (iStack_18 != 0) {
      pppppuVar8 = &ppppuStack_28;
      if (0xf < uStack_14) {
        pppppuVar8 = (undefined4 *****)ppppuStack_28;
      }
      iVar11 = (int)pppppuVar8 + iStack_18;
      pppppuVar8 = &ppppuStack_28;
      if (0xf < uStack_14) {
        pppppuVar8 = (undefined4 *****)ppppuStack_28;
      }
      uVar4 = FUN_01686580();
      FUN_01685950(pppppuVar8,iVar11,auStack_60,uVar4);
    }
    uStack_8._0_1_ = 0x11;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      pppppuVar8 = (undefined4 *****)ppppuStack_28;
      if (0xfff < uVar10) {
        pppppuVar8 = (undefined4 *****)ppppuStack_28[-1];
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)pppppuVar8))) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar8,uVar10);
    }
    iStack_18 = 0;
    uStack_14 = 0xf;
    ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
    uStack_8._0_1_ = 0x13;
    uVar4 = FUN_005514a0(auStack_c0,auStack_90,auStack_60);
    uStack_8._0_1_ = 0x14;
    piVar5 = (int *)FUN_0168e1c0(auStack_48,uVar4,0);
    if ((*piVar5 == 0) || (*piVar5 == 1)) {
      uStack_30 = 0;
      uStack_2c = 7;
      ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffff0000);
      uStack_8._0_1_ = 0x17;
      FUN_0058ed10(&ppppuStack_40,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      FUN_00550800();
      FUN_005542c0(&DAT_018bc9b8,0);
    }
    else {
      FUN_0168bf40(&ppppuStack_28,0);
      uStack_8._0_1_ = 0x15;
      FUN_0168b4a0(&ppppuStack_40,uVar4,&ppppuStack_28,0);
      pppppuVar8 = &ppppuStack_40;
      if (7 < uStack_2c) {
        pppppuVar8 = (undefined4 *****)ppppuStack_40;
      }
      uStack_8._0_1_ = 0x16;
      FUN_0058ed10(pppppuVar8,uStack_30);
      FUN_00550800();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
      FUN_00550800();
      FUN_0151a940(&ppppuStack_40,&DAT_01d63158);
      FUN_005507b0();
      DAT_01d631b8 = (undefined4 *****)ppppuStack_40;
      uRam01d631bc = uStack_3c;
      uRam01d631c0 = uStack_38;
      uRam01d631c4 = uStack_34;
      _DAT_01d631c8 = CONCAT44(uStack_2c,uStack_30);
    }
    if (DAT_01d84e8d != '\0') {
      pppppuVar8 = &DAT_01d631b8;
      if (0xf < DAT_01d631cc) {
        pppppuVar8 = DAT_01d631b8;
      }
      FUN_01677650(DAT_01d84e8d,"setExtraAssetFolder %s",pppppuVar8);
    }
    FUN_00550800();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_00550800();
    FUN_0151a940(&ppppuStack_40,&DAT_01d63158);
    FUN_005507b0();
    DAT_01d631b8 = (undefined4 *****)ppppuStack_40;
    ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
    uRam01d631bc = uStack_3c;
    uRam01d631c0 = uStack_38;
    uRam01d631c4 = uStack_34;
    _DAT_01d631c8 = CONCAT44(uStack_2c,uStack_30);
    uStack_30 = 0;
    uStack_2c = 0xf;
    FUN_005507b0();
    DAT_01ee01a2 = '\x01';
    FUN_00550800();
    FUN_00550800();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15236 ; VA 0x008da0d0 ; FUN_008da0d0 */

void __thiscall FUN_008da0d0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  char *pcVar8;
  int *piVar9;
  char *pcVar10;
  undefined4 ****ppppuVar11;
  uint uVar12;
  uint uVar13;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017c0c30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (in_stack_00000014 != 0) {
    puVar3 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar3 = param_2;
    }
    ExceptionList = &pvStack_10;
    if (*(char *)(in_stack_00000014 + -1 + (int)puVar3) != '/') {
      ExceptionList = &pvStack_10;
      FUN_005558a0(0x2f);
    }
  }
  uVar12 = in_stack_00000018;
  iVar7 = in_stack_00000014;
  puVar3 = param_2;
  piVar9 = (int *)(iStack_14 + 0xb8);
  puVar4 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar4 = param_2;
  }
  if (0xf < *(uint *)(iStack_14 + 0xcc)) {
    piVar9 = (int *)*piVar9;
  }
  cVar2 = FUN_0055c360(piVar9,*(undefined4 *)(iStack_14 + 200),puVar4,in_stack_00000014);
  if (cVar2 == '\0') {
    iStack_1c = iVar7;
    if ((undefined4 **)(iStack_14 + 0xb8) != &param_2) {
      puVar4 = &param_2;
      if (0xf < uVar12) {
        puVar4 = puVar3;
      }
      FUN_005542c0(puVar4,iVar7);
      iStack_1c = in_stack_00000014;
      puVar3 = param_2;
      uVar12 = in_stack_00000018;
    }
    puStack_20 = &param_2;
    if (DAT_01d62f70 == '\0') {
      if (0xf < uVar12) {
        puStack_20 = puVar3;
      }
      cVar2 = FUN_00631690("https://",8);
      pcVar10 = "https://www.roblox.com/";
      if (cVar2 == '\0') {
        pcVar10 = "http://www.roblox.com/";
      }
      pcVar8 = pcVar10;
      do {
        cVar2 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar2 != '\0');
      iVar7 = iStack_14 + 0xd0;
      if (0xf < *(uint *)(iStack_14 + 0xe4)) {
        iVar7 = *(int *)(iStack_14 + 0xd0);
      }
      cVar2 = FUN_0055c360(iVar7,*(undefined4 *)(iStack_14 + 0xe0),pcVar10,
                           (int)pcVar8 - (int)(pcVar10 + 1));
      if (cVar2 == '\0') {
        FUN_005542c0(pcVar10,(int)pcVar8 - (int)(pcVar10 + 1));
      }
    }
    else {
      if (0xf < uVar12) {
        puStack_20 = puVar3;
      }
      cVar2 = FUN_00631690("https://",8);
      uStack_28 = 0;
      uStack_24 = 0xf;
      pcVar10 = "https://www.roblox.com/";
      apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
      if (cVar2 == '\0') {
        pcVar10 = "http://www.roblox.com/";
      }
      pcVar8 = pcVar10;
      do {
        cVar2 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar2 != '\0');
      FUN_005542c0(pcVar10,(int)pcVar8 - (int)(pcVar10 + 1));
      uVar12 = uStack_24;
      uVar1 = uStack_28;
      ppppuVar11 = (undefined4 ****)(iStack_14 + 0xd0);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      ppppuVar6 = apppuStack_38;
      if (0xf < uStack_24) {
        ppppuVar6 = (undefined4 ****)apppuStack_38[0];
      }
      ppppuVar5 = ppppuVar11;
      if (0xf < *(uint *)(iStack_14 + 0xe4)) {
        ppppuVar5 = (undefined4 ****)*ppppuVar11;
      }
      cVar2 = FUN_0055c360(ppppuVar5,*(undefined4 *)(iStack_14 + 0xe0),ppppuVar6,uStack_28);
      if ((cVar2 == '\0') && (ppppuVar11 != apppuStack_38)) {
        ppppuVar6 = apppuStack_38;
        if (0xf < uVar12) {
          ppppuVar6 = (undefined4 ****)apppuStack_38[0];
        }
        FUN_005542c0(ppppuVar6,uVar1);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_005507b0();
    }
    FUN_008a4940(&DAT_0211bd28);
    puVar3 = param_2;
    uVar12 = in_stack_00000018;
  }
  if (0xf < uVar12) {
    uVar13 = uVar12 + 1;
    puVar4 = puVar3;
    if (0xfff < uVar13) {
      puVar4 = (undefined4 *)puVar3[-1];
      uVar13 = uVar12 + 0x24;
      if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15237 ; VA 0x008da320 ; FUN_008da320 */

void __thiscall FUN_008da320(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_20 [8];
  int *piStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)*param_1;
  if ((piVar2 == (int *)0x0) ||
     ((*(char *)(param_1 + 1) != '\0' &&
      ((*(char *)(piVar2 + 0x1d) != '\0' ||
       ((*(char *)(param_1 + 1) != '\0' && (*(char *)(piVar2 + 0x1d) != '\0')))))))) {
    ExceptionList = &pvStack_10;
    uVar5 = FUN_005deb10(auStack_20,4);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar5);
  }
  piStack_18 = piVar2 + 7;
  cStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016dee6d(piStack_18);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  cStack_14 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)piVar2 + 0x7d) != '\0') {
    uVar5 = FUN_005deb10(auStack_20,3);
                    /* WARNING: Subroutine does not return */
    FUN_016dfe59(uVar5);
  }
  piVar2[2] = *param_2;
  iVar4 = param_2[2];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[2];
  }
  piVar2[3] = param_2[1];
  piVar3 = (int *)piVar2[4];
  piVar2[4] = iVar4;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  (**(code **)(*piVar2 + 0x14))(&piStack_18,0);
  uStack_8 = 1;
  if ((cStack_14 != '\0') && (iVar4 = FUN_016deec8(piStack_18), iVar4 != 0)) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15238 ; VA 0x008da460 ; FUN_008da460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008da460(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0c56;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee046c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee046c);
    if (DAT_01ee046c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AssetFetchStatus");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0408 =
           RBX::Reflection::EnumDesc<enum_RBX::ContentProvider::AssetFetchStatus>::vftable;
      FUN_009caf20(&DAT_01d632d8,2);
      FUN_016f3654(&LAB_01882460);
      FUN_016f37bf(&DAT_01ee046c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0408;
}



/* FUNCTION 15239 ; VA 0x008da510 ; FUN_008da510 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008da510(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee048c) {
    FUN_016f3809(&DAT_01ee048c);
    if (DAT_01ee048c == -1) {
      _DAT_01ee0480 = FUN_005c65e0;
      _DAT_01ee0484 = FUN_005c65e0;
      _DAT_01ee0488 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee048c);
    }
  }
  return &DAT_01ee0480;
}



/* FUNCTION 15240 ; VA 0x008da580 ; FUN_008da580 */

undefined4 FUN_008da580(void)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  undefined auStack_24 [24];
  undefined8 uStack_c;
  
  FUN_005956d0(0,0,2);
  puVar3 = (uint *)FUN_005957d0(auStack_24);
  uVar1 = puVar3[2];
  uVar2 = *puVar3;
  iVar4 = puVar3[3] + puVar3[1] + (uint)CARRY4(uVar1,*puVar3);
  FUN_005956d0(0,0,0);
  if ((0 < iVar4) || ((-1 < iVar4 && (7 < uVar1 + uVar2)))) {
    uStack_c = 0;
    FUN_005af630(&uStack_c,8,0);
    FUN_005956d0(0,0,0);
    if (((int)uStack_c == DAT_01ee0190) && (uStack_c._4_4_ == DAT_01ee0194)) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 15241 ; VA 0x008da620 ; FUN_008da620 */

undefined4 FUN_008da620(undefined4 param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0c70;
  pvStack_10 = ExceptionList;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    param_2 = *(char **)param_2;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  uStack_8 = 0;
  uVar2 = FUN_0151a8d0(auStack_40,auStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054f050(uVar2);
  if (7 < uStack_2c) {
    uVar4 = uStack_2c * 2 + 2;
    uVar5 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c * 2 + 0x25;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 7;
  auStack_40[0] = auStack_40[0] & 0xffff0000;
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15242 ; VA 0x008da730 ; FUN_008da730 */

void __thiscall FUN_008da730(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0c88;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15243 ; VA 0x008da7c0 ; FUN_008da7c0 */

void __thiscall FUN_008da7c0(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0ca8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15244 ; VA 0x008da850 ; FUN_008da850 */

void __thiscall FUN_008da850(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  float10 fVar4;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0cd3;
  pvStack_10 = ExceptionList;
  if ((param_2[4] != 0) && (ExceptionList = &pvStack_10, iVar2 = FUN_009cc8a0(param_2), iVar2 != 0))
  {
    for (iVar3 = *param_1; iVar3 != param_1[1]; iVar3 = iVar3 + 0x60) {
      if (*(int *)(iVar3 + 0x38) == iVar2) {
        ExceptionList = pvStack_10;
        return;
      }
    }
    fVar4 = (float10)FUN_01683110();
    uStack_5c = 0xf;
    uStack_78 = 0;
    dStack_18 = (double)fVar4;
    uStack_74 = 0;
    uStack_60 = 0;
    auStack_70[0] = 0;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = 0;
    iStack_40 = 0;
    uStack_38 = 0.0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_20 = 0;
    uStack_28 = 0;
    uStack_8 = 0;
    if ((undefined4 *)auStack_70 != param_2) {
      puVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_005542c0(param_2,*puVar1);
    }
    puVar1 = (undefined4 *)param_1[1];
    uStack_38 = dStack_18;
    uStack_74 = param_3;
    iStack_40 = iVar2;
    if ((undefined4 *)param_1[2] == puVar1) {
      FUN_008bdc00(puVar1,&uStack_78);
    }
    else {
      *puVar1 = uStack_78;
      puVar1[1] = param_3;
      FUN_0054ef60(auStack_70);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054ef60(auStack_58);
      puVar1[0xe] = iStack_40;
      puVar1[0x10] = (undefined4)uStack_38;
      puVar1[0x11] = uStack_38._4_4_;
      puVar1[0x12] = uStack_30;
      puVar1[0x13] = uStack_2c;
      puVar1[0x16] = uStack_20;
      *(undefined8 *)(puVar1 + 0x14) = uStack_28;
      param_1[1] = param_1[1] + 0x60;
    }
    FUN_00651cc0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15245 ; VA 0x008da9d0 ; FUN_008da9d0 */

void __thiscall FUN_008da9d0(int param_1,int param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((DAT_01d62fd8 != '\0') && (ExceptionList = &pvStack_10, *(int *)(param_1 + 0xa0) != 0)) {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_009cc8a0(&param_2);
    uVar5 = uVar2 % *(uint *)(param_1 + 0x9c);
    piVar6 = *(int **)(uVar5 * 4 + *(int *)(param_1 + 0xac));
    if ((piVar6 != (int *)0x0) && (iVar4 = *piVar6, iVar4 != 0)) {
      while (*(uint *)(iVar4 + 4) % *(uint *)(param_1 + 0x9c) == uVar5) {
        if ((*(uint *)(iVar4 + 4) == uVar2) &&
           (cVar1 = FUN_009cbaa0(&param_2,iVar4 + 8), cVar1 != '\0')) {
          FUN_008ca4e0(piVar6,*(undefined4 *)*piVar6);
          if (*piVar6 != 0) {
            uVar2 = *(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 0x9c);
            if (uVar5 == uVar2) break;
            *(int **)(*(int *)(param_1 + 0xac) + uVar2 * 4) = piVar6;
          }
          puVar3 = (undefined4 *)(*(int *)(param_1 + 0xac) + uVar5 * 4);
          if ((int *)*puVar3 == piVar6) {
            *puVar3 = 0;
          }
          break;
        }
        piVar6 = (int *)*piVar6;
        iVar4 = *piVar6;
        if (iVar4 == 0) break;
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar4 = param_2;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15246 ; VA 0x008dab00 ; FUN_008dab00 */

void __thiscall FUN_008dab00(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  char ****ppppcVar2;
  char ****ppppcVar3;
  uint uVar4;
  undefined auStack_88 [72];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  char ***apppcStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d0e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  cVar1 = FUN_008cc060(apppcStack_28);
  if ((cVar1 != '\0') && (iStack_18 != 0)) {
    ppppcVar3 = apppcStack_28;
    if (0xf < uStack_14) {
      ppppcVar3 = (char ****)apppcStack_28[0];
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    ppppcVar2 = ppppcVar3;
    do {
      cVar1 = *(char *)ppppcVar2;
      ppppcVar2 = (char ****)((int)ppppcVar2 + 1);
    } while (cVar1 != '\0');
    FUN_005542c0(ppppcVar3,(int)ppppcVar2 - (int)((int)ppppcVar3 + 1));
    uStack_8._0_1_ = 1;
    FUN_0054ef60(auStack_40);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(param_3);
    uStack_8._0_1_ = 3;
    FUN_0054ef60(&DAT_01d62f20);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005507b0();
    if (*(int *)(param_1 + 0xf4) != 0) {
      FUN_00f4f950(auStack_88,param_4);
    }
    FUN_00d1e530(auStack_88,param_4);
    FUN_00637950();
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    ppppcVar3 = (char ****)apppcStack_28[0];
    if (0xfff < uVar4) {
      ppppcVar3 = (char ****)apppcStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_28[0] + (-4 - (int)ppppcVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15247 ; VA 0x008dac50 ; FUN_008dac50 */

undefined FUN_008dac50(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined uVar2;
  char ****ppppcVar3;
  char ****ppppcVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_a0 [72];
  char ***apppcStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d59;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  uStack_8 = 0;
  cVar1 = FUN_008cc060(apppcStack_58);
  if (cVar1 == '\0') {
    uVar2 = 0;
  }
  else {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 1;
    ppppcVar4 = apppcStack_58;
    if (0xf < uStack_44) {
      ppppcVar4 = (char ****)apppcStack_58[0];
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ppppcVar3 = ppppcVar4;
    do {
      cVar1 = *(char *)ppppcVar3;
      ppppcVar3 = (char ****)((int)ppppcVar3 + 1);
    } while (cVar1 != '\0');
    FUN_005542c0(ppppcVar4,(int)ppppcVar3 - (int)((int)ppppcVar4 + 1));
    uStack_8._0_1_ = 2;
    FUN_0054ef60(auStack_28);
    uStack_8._0_1_ = 3;
    FUN_0054ef60(auStack_40);
    uStack_8._0_1_ = 4;
    FUN_0054ef60(&DAT_01d62f20);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uVar2 = FUN_00d1e530(auStack_a0,param_2);
    FUN_00637950();
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    if (0xf < uStack_2c) {
      uVar5 = uStack_2c + 1;
      uVar6 = auStack_40[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_40[0] - 4);
        uVar5 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
  }
  if (0xf < uStack_44) {
    uVar6 = uStack_44 + 1;
    ppppcVar4 = (char ****)apppcStack_58[0];
    if (0xfff < uVar6) {
      ppppcVar4 = (char ****)apppcStack_58[0][-1];
      uVar6 = uStack_44 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_58[0] + (-4 - (int)ppppcVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 15248 ; VA 0x008dae20 ; FUN_008dae20 */

int * __thiscall
FUN_008dae20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::DataModel::*)(void)const_>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15249 ; VA 0x008daf20 ; FUN_008daf20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_008daf20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0dbf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0b6c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0b6c);
    if (DAT_01ee0b6c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee0b48 = RBX::Reflection::RefType<class_RBX::Workspace*>::vftable;
      FUN_016f3654(&LAB_018832b0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee0b6c);
    }
  }
  uVar2 = FUN_008dcf60();
  FUN_009ca670(uVar2,&DAT_01ee0b48,param_2,param_3,param_7,param_8,param_9,param_10,param_11,
               param_11,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::DataModel,class_RBX::Workspace>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::RefPropDescriptor<class_RBX::DataModel,class_RBX::Workspace>
                      ::vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DataModel,class_RBX::Workspace*>::
              GetImpl<class_RBX::Workspace*_(__thiscall_RBX::DataModel::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}


