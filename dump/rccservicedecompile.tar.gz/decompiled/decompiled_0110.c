/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 27500 ; VA 0x00c19020 ; FUN_00c19020 */

void __thiscall FUN_00c19020(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180632f;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x238);
  if (iVar1 == 0) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedc78)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eedc78), DAT_01eedc78 == -1)) {
      DAT_01eedc6c._0_4_ = 0;
      DAT_01eedc6c._4_4_ = -0.5;
      DAT_01eedc74 = 0.5;
      FUN_016f37bf(&DAT_01eedc78);
    }
    if (((*param_3 == (int)DAT_01eedc6c) &&
        ((NAN((float)param_3[1]) || NAN(DAT_01eedc6c._4_4_)) !=
         ((float)param_3[1] == DAT_01eedc6c._4_4_))) &&
       ((NAN((float)param_3[2]) || NAN(DAT_01eedc74)) != ((float)param_3[2] == DAT_01eedc74))) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar1 = FUN_01674e20(0x48);
    uStack_8 = 0;
    if (iVar1 == 0) {
      iVar1 = 0;
    }
    else {
      iVar2 = 6;
      do {
        FUN_00b011f0();
        iVar2 = iVar2 + -1;
      } while (iVar2 != 0);
    }
    *(int *)(param_1 + 0x238) = iVar1;
  }
  *(undefined8 *)(iVar1 + param_2 * 0xc) = *(undefined8 *)param_3;
  *(int *)(iVar1 + 8 + param_2 * 0xc) = param_3[2];
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27501 ; VA 0x00c19160 ; FUN_00c19160 */

void __thiscall FUN_00c19160(int param_1,int param_2,undefined param_3)

{
  *(undefined *)(param_2 + 0x22f + param_1) = param_3;
  return;
}



/* FUNCTION 27502 ; VA 0x00c19180 ; FUN_00c19180 */

void __thiscall FUN_00c19180(int param_1,undefined8 *param_2)

{
  uint uVar1;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uVar1 = -(uint)(param_1 != 0) & param_1 + 0x50U;
  FUN_00fa07b0();
  uStack_4c = *(undefined4 *)(uVar1 + 0xb4);
  uStack_48 = *(undefined4 *)(uVar1 + 0xb8);
  uStack_44 = *(undefined4 *)(uVar1 + 0xbc);
  uStack_40 = *(undefined4 *)(uVar1 + 0xc0);
  uStack_3c = *(undefined4 *)(uVar1 + 0xc4);
  uStack_38 = *(undefined4 *)(uVar1 + 200);
  uStack_34 = *(undefined4 *)(uVar1 + 0xcc);
  uStack_30 = *(undefined4 *)(uVar1 + 0xd0);
  uStack_14 = *(undefined4 *)(param_2 + 1);
  uStack_8 = *(undefined4 *)((int)param_2 + 0x14);
  uStack_2c = *(undefined4 *)(uVar1 + 0xd4);
  uStack_28 = *(undefined4 *)(uVar1 + 0xd8);
  uStack_24 = *(undefined4 *)(uVar1 + 0xdc);
  uStack_20 = *(undefined4 *)(uVar1 + 0xe0);
  uStack_1c = *param_2;
  uStack_10 = *(undefined8 *)((int)param_2 + 0xc);
  FUN_00c18610(&uStack_4c);
  return;
}



/* FUNCTION 27503 ; VA 0x00c19200 ; FUN_00c19200 */

void __thiscall FUN_00c19200(int param_1,uint param_2)

{
  int ***pppiVar1;
  int ****ppppiVar2;
  int ****ppppiVar3;
  float fVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  int *****pppppiVar11;
  int *****pppppiVar12;
  int iVar13;
  undefined4 uStack_64;
  undefined4 uStack_5c;
  int iStack_58;
  int ****ppppiStack_3c;
  int ***pppiStack_38;
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int ****ppppiStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806358;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff90;
  iVar13 = param_1 + -0xc;
  if (param_1 == 0) {
    iVar13 = -0xc;
  }
  piVar5 = (int *)(param_1 + -8);
  if (param_1 == 0) {
    piVar5 = (int *)&DAT_00000004;
  }
  if (*piVar5 == 0) {
    pppppiVar12 = (int *****)0x0;
  }
  else {
    pppppiVar12 = (int *****)(*piVar5 + 0x20);
  }
  ExceptionList = &pvStack_10;
  ppppiStack_28 = (int ****)pppppiVar12;
  iStack_1c = param_1;
  FUN_00c12ef0((int)&param_2 + 3,&ppppiStack_3c,param_2);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (param_1 == 0) {
    iVar13 = 0;
  }
  iStack_34 = *(int *)(iVar13 + 0x28);
  if (iStack_34 != 0) {
    iVar6 = FUN_00577ed0(iStack_34);
    uStack_30 = *(uint *)(iVar13 + 0x28);
    uStack_8._0_1_ = 1;
    if (uStack_30 == 0) {
      uStack_18 = 0;
      iStack_20 = 0;
    }
    else {
      uVar10 = uStack_30 * 4;
      if (uStack_30 < 0x40000000) {
        if (uVar10 < 0x1000) {
          if (uVar10 == 0) {
            iStack_20 = *(int *)(iVar13 + 0x28);
            uStack_18 = 0;
          }
          else {
            uStack_18 = FUN_01674e20(uVar10);
            iStack_20 = *(int *)(iVar13 + 0x28);
          }
          goto LAB_00c192ff;
        }
      }
      else {
        uVar10 = 0xffffffff;
      }
      uVar7 = uVar10 + 0x23;
      if (uVar7 <= uVar10) {
        uVar7 = 0xffffffff;
      }
      iVar8 = FUN_01674e20(uVar7);
      if (iVar8 == 0) goto LAB_00c1959b;
      uStack_18 = iVar8 + 0x23U & 0xffffffe0;
      *(int *)(uStack_18 - 4) = iVar8;
      iStack_20 = *(int *)(iVar13 + 0x28);
    }
LAB_00c192ff:
    iVar13 = 0;
    param_2 = param_2 & 0xffffff;
    uStack_8._0_1_ = 3;
    while (iStack_24 = iVar13, iVar13 != iStack_20) {
      pppppiVar11 = (int *****)*pppppiVar12;
      uStack_2c = FUN_01078e00(-(uint)(pppppiVar11 != (int *****)0x0) & (uint)(pppppiVar11 + -8));
      *(undefined4 *)(iVar6 + iVar13 * 4) = uStack_2c;
      *(int ******)(uStack_18 + iVar13 * 4) = pppppiVar11;
      ppppiVar2 = *pppppiVar12;
      ppppiVar3 = (int ****)(*ppppiVar2)[1];
      if (ppppiVar3 != ppppiVar2) {
        *ppppiVar3 = (int ***)0x0;
        (*ppppiVar2)[1] = (int **)ppppiVar2[1];
        *pppppiVar12 = (int ****)*ppppiVar2;
      }
      else {
        (*ppppiVar2)[1] = (int **)ppppiVar2[1];
        *pppppiVar12 = (int ****)*ppppiVar2;
      }
      param_2 = CONCAT13(ppppiVar3 == ppppiVar2,(undefined3)param_2);
      iVar8 = FUN_008a4250(uStack_2c,uStack_64);
      pppiVar1 = (int ***)(iStack_58 + iVar8 * 4);
      if (*pppiVar1 == (int **)0x0) {
        iVar13 = iVar13 + 1;
        *pppppiVar11 = ppppiStack_3c;
        pppppiVar11[1] = (int ****)ppppiStack_3c[1];
        (*pppppiVar11)[1] = pppiVar1;
        *pppiVar1 = (int **)pppppiVar11;
        ppppiStack_3c = (int ****)pppppiVar11;
      }
      else {
        iVar13 = iVar13 + 1;
        *pppppiVar11 = (int ****)**pppiVar1;
        pppppiVar11[1] = (int ****)*pppiVar1;
        *pppiVar1 = (int **)pppppiVar11;
        *pppppiVar11[1] = (int ***)pppppiVar11;
      }
    }
    if (uStack_30 != 0) {
      uVar10 = uStack_30 * 4;
      uVar7 = uStack_18;
      if (0xfff < uVar10) {
        uVar7 = *(uint *)(uStack_18 - 4);
        uVar10 = uVar10 + 0x23;
        if (0x1f < (uStack_18 - uVar7) - 4) goto LAB_00c1959b;
      }
      FUN_01674ea0(uVar7,uVar10);
    }
    param_1 = iStack_1c;
    if (iStack_34 != 0) {
      uVar10 = iStack_34 * 4;
      iVar13 = iVar6;
      if (0xfff < uVar10) {
        iVar13 = *(int *)(iVar6 + -4);
        uVar10 = uVar10 + 0x23;
        if (0x1f < (iVar6 - iVar13) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar13,uVar10);
      param_1 = iStack_1c;
    }
  }
  fVar4 = DAT_018c0d80;
  pppppiVar11 = pppppiVar12;
  if ((int *****)ppppiStack_3c != &ppppiStack_3c) {
    pppppiVar11 = (int *****)ppppiStack_3c;
  }
  *pppppiVar12 = (int ****)pppppiVar11;
  pppppiVar12[1] = (int ****)pppiStack_38;
  **pppiStack_38 = (int *)pppppiVar12;
  *(*pppppiVar12)[1] = (int **)pppppiVar12;
  *(undefined4 *)(param_1 + 4) = uStack_64;
  iVar13 = *(int *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 0xc) = uStack_5c;
  iVar6 = *(int *)(param_1 + 0x10);
  *(int *)(param_1 + 0x10) = iStack_58;
  iVar8 = *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4);
  *(undefined4 *)(param_1 + 0x18) = 0xffffffff;
  if ((float)((double)iVar8 + (double)(&DAT_018c0d90)[-(iVar8 >> 0x1f)]) *
      *(float *)(param_1 + 0x14) < fVar4) {
    uVar9 = FUN_016f3cd0();
    *(undefined4 *)(param_1 + 0x18) = uVar9;
  }
  if (iVar13 != 0) {
    uVar10 = iVar13 * 4;
    iVar13 = iVar6;
    if (0xfff < uVar10) {
      iVar13 = *(int *)(iVar6 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar6 - iVar13) - 4U) {
LAB_00c1959b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar13,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27504 ; VA 0x00c193c6 ; Catch_All@00c193c6 */

void Catch_All_00c193c6(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int unaff_EBP;
  int iVar8;
  
  iVar8 = *(int *)(unaff_EBP + -0x20);
  if (iVar8 != 0) {
    iVar5 = *(int *)(unaff_EBP + -0x18);
    uVar4 = FUN_008a4250(*(undefined4 *)(*(int *)(unaff_EBP + -0x3c) + -4 + iVar8 * 4),
                         *(undefined4 *)(iVar5 + 4));
    *(uint *)(unaff_EBP + -0x14) = uVar4;
    if (*(char *)(unaff_EBP + 0xb) == '\0') {
      *(uint *)(unaff_EBP + -0x14) = ~uVar4;
    }
    piVar1 = *(int **)(unaff_EBP + -0x24);
    iVar7 = *(int *)(unaff_EBP + -0x3c) - *(int *)(unaff_EBP + -0x48);
    *(int *)(unaff_EBP + -0x28) = iVar7;
    iVar6 = *(int *)(unaff_EBP + -0x48) + iVar8 * 4;
    do {
      uVar2 = *(undefined4 *)(iVar5 + 4);
      iVar8 = iVar8 + -1;
      *(int *)(unaff_EBP + 8) = iVar6 + -4;
      iVar5 = FUN_008a4250(*(undefined4 *)(iVar7 + iVar6 + -4),uVar2);
      piVar3 = (int *)**(undefined4 **)(unaff_EBP + 8);
      if (iVar5 == *(int *)(unaff_EBP + -0x14)) {
        *piVar3 = *piVar1;
        piVar3[1] = *(int *)(*piVar1 + 4);
        *(int **)(*piVar3 + 4) = piVar3;
        *piVar1 = (int)piVar3;
      }
      else {
        FUN_008a37e0(piVar3,*(int *)(*(int *)(unaff_EBP + -0x18) + 0x10) + iVar5 * 4,piVar1);
      }
      iVar6 = *(int *)(unaff_EBP + 8);
      iVar7 = *(int *)(unaff_EBP + -0x28);
      *(int *)(unaff_EBP + -0x14) = iVar5;
      iVar5 = *(int *)(unaff_EBP + -0x18);
    } while (iVar8 != 0);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27505 ; VA 0x00c195b0 ; FUN_00c195b0 */

void __thiscall FUN_00c195b0(int param_1,char param_2)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  
  if (DAT_01d6866c == '\0') {
    if (param_2 != '\0') {
      FUN_00c3e280();
    }
  }
  else {
    FUN_00c3e3a0();
  }
  if (DAT_01d6f4f8 == '\0') {
    iVar5 = 0;
    if (0 < (int)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) & 0xfffffff8U)) {
      do {
        FUN_00ff5c60();
        iVar5 = iVar5 + 1;
      } while (iVar5 < *(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3);
    }
    if (*(int *)(param_1 + 0x1a8) != 0) {
      FUN_00ca1730(param_1);
      iVar5 = FUN_00ca1550();
      if (param_1 == iVar5) {
        puVar2 = (uint *)FUN_00ca1510();
        uVar6 = 0;
        piVar3 = (int *)*puVar2;
        uVar4 = (uint)((int)puVar2[1] + (3 - (int)piVar3)) >> 2;
        if ((int *)puVar2[1] < piVar3) {
          uVar4 = 0;
        }
        if (uVar4 != 0) {
          do {
            piVar1 = (int *)*piVar3;
            iVar5 = (**(code **)(*piVar1 + 0x10))();
            if (iVar5 - 7U < 0x13) {
              FUN_00bc1c10(piVar1[0xb],0);
              FUN_00bc1c10(piVar1[0xc],0);
            }
            uVar6 = uVar6 + 1;
            piVar3 = piVar3 + 1;
          } while (uVar6 != uVar4);
        }
      }
    }
  }
  return;
}



/* FUNCTION 27506 ; VA 0x00c196c0 ; FUN_00c196c0 */

void FUN_00c196c0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_00ca1550();
  FUN_00c19ac0(param_2);
  iVar1 = *(int *)(iVar1 + 0x14);
  iVar2 = 0;
  if (0 < iVar1) {
    do {
      FUN_00c19ac0(param_2);
      iVar2 = iVar2 + 1;
    } while (iVar2 < iVar1);
  }
  return;
}



/* FUNCTION 27507 ; VA 0x00c19710 ; FUN_00c19710 */

void __thiscall FUN_00c19710(undefined4 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  
  if ((((param_2 != 0) && (iVar2 = FUN_00ca1730(param_1), iVar2 != 0)) &&
      (cVar1 = FUN_00ca0df0(param_2,param_3), cVar1 != '\0')) &&
     ((*(int *)(iVar2 + 0x40) != 0 && (*(int *)(iVar2 + 0x40) != 6)))) {
    FUN_00ca1550();
    FUN_00c19c40(param_3,param_2);
  }
  return;
}



/* FUNCTION 27508 ; VA 0x00c19760 ; FUN_00c19760 */

void __fastcall FUN_00c19760(int param_1)

{
  if ((*(char *)(param_1 + 0x222) == '\0') && (*(char *)(param_1 + 0x223) == '\0')) {
    FUN_00bc1c10(param_1,0);
  }
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00f3cfa0(param_1);
  }
  if ((*(int *)(param_1 + 0x1a8) != 0) && (*(int *)(*(int *)(param_1 + 0x1a8) + 0x110) != 0)) {
    if (*(int *)(param_1 + 0x1a0) != 0) {
      FUN_00bbbc20(param_1,0,*(undefined4 *)(*(int *)(param_1 + 0x1a0) + 4));
      return;
    }
    FUN_00bbbcb0(param_1,0);
  }
  return;
}



/* FUNCTION 27509 ; VA 0x00c197d0 ; FUN_00c197d0 */

void __fastcall FUN_00c197d0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x1ac) + 0x10);
  if (iVar1 != 0) {
    FUN_00fa05c0(iVar1);
  }
  return;
}



/* FUNCTION 27510 ; VA 0x00c197f0 ; FUN_00c197f0 */

void __thiscall FUN_00c197f0(int param_1,undefined4 param_2,float *param_3,int param_4)

{
  int iVar1;
  undefined uVar2;
  float *pfVar3;
  int iVar4;
  undefined4 uVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  int iStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_8 = (float)DAT_01d68adc / DAT_018ce320;
  iStack_10 = param_1;
  pfVar3 = (float *)(**(code **)(**(int **)(*(int *)(param_1 + 0xc) + 0x1ac) + 0x14))(&fStack_1c);
  iVar1 = *(int *)(param_1 + 0xc);
  iVar4 = iVar1 + 0x50;
  fStack_c = *pfVar3 * DAT_018ce2f4 + fStack_8;
  fVar8 = (float)((uint)(*pfVar3 * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fStack_30 = pfVar3[1] * DAT_018ce2f4 + fStack_8;
  fStack_2c = pfVar3[2] * DAT_018ce2f4 + fStack_8;
  fStack_3c = (float)((uint)(pfVar3[1] * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fStack_8 = (float)((uint)(pfVar3[2] * DAT_018ce2f4) ^ DAT_018c4ea0) - fStack_8;
  fVar7 = (fStack_30 - fStack_3c) * DAT_018daf54;
  fStack_34 = (fStack_c - fVar8) * DAT_018daf54;
  fStack_3c = fStack_3c - fVar7;
  fVar6 = (fStack_2c - fStack_8) * DAT_018daf54;
  fStack_30 = fStack_30 + fVar7;
  fStack_40 = fVar8 - fStack_34;
  fStack_38 = fStack_8 - fVar6;
  fStack_2c = fStack_2c + fVar6;
  fStack_34 = fStack_c + fStack_34;
  fStack_8 = fVar8;
  if (DAT_01d69148 == '\0') {
    if (iVar1 == 0) {
      iVar4 = 0;
    }
    FUN_00fa07b0();
    pfVar3 = (float *)FUN_00c9eef0(&fStack_58,iVar4 + 0xb4,param_2);
    fVar6 = pfVar3[1];
    fVar7 = pfVar3[2];
    fVar8 = pfVar3[3];
    *param_3 = *pfVar3;
    param_3[1] = fVar6;
    param_3[2] = fVar7;
    param_3[3] = fVar8;
    *(undefined8 *)(param_3 + 4) = *(undefined8 *)(pfVar3 + 4);
  }
  else {
    FUN_00fa0810();
    iVar4 = iVar1 + 0x104;
    if (iVar1 == 0) {
      iVar4 = 0xb4;
    }
    FUN_00c9eef0(&fStack_28,iVar4,param_2);
    iVar4 = iVar1 + 0x14c;
    if (iVar1 == 0) {
      iVar4 = 0xfc;
    }
    FUN_00c9eef0(&fStack_58,iVar4,param_2);
    *param_3 = fStack_28;
    param_3[1] = fStack_24;
    param_3[2] = fStack_20;
    param_3[3] = fStack_1c;
    *(ulonglong *)(param_3 + 4) = CONCAT44(fStack_14,uStack_18);
    fVar6 = param_3[2];
    if (fStack_50 <= param_3[2]) {
      fVar6 = fStack_50;
    }
    fVar7 = param_3[1];
    if (fStack_54 <= param_3[1]) {
      fVar7 = fStack_54;
    }
    fVar8 = *param_3;
    if (fStack_58 <= *param_3) {
      fVar8 = fStack_58;
    }
    *(ulonglong *)param_3 = CONCAT44(fVar7,fVar8);
    param_3[2] = fVar6;
    fStack_14 = param_3[5];
    if (param_3[5] <= fStack_44) {
      fStack_14 = fStack_44;
    }
    fVar6 = param_3[4];
    if (param_3[4] <= fStack_48) {
      fVar6 = fStack_48;
    }
    fVar7 = param_3[3];
    if (param_3[3] <= fStack_4c) {
      fVar7 = fStack_4c;
    }
    *(ulonglong *)(param_3 + 3) = CONCAT44(fVar6,fVar7);
    param_3[5] = fStack_14;
  }
  iVar4 = iStack_10;
  if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
    uVar2 = (**(code **)(**(int **)(*(int *)(iStack_10 + 0xc) + 0x1b0) + 4))();
  }
  else {
    uVar2 = *(undefined *)(*(int *)(iStack_10 + 0xc) + 0x224);
  }
  *(undefined *)(param_4 + 1) = uVar2;
  if ((*(char *)(*(int *)(iVar4 + 0xc) + 0x222) == '\0') &&
     (*(char *)(*(int *)(iVar4 + 0xc) + 0x225) != '\0')) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
  }
  *(undefined *)(param_4 + 2) = uVar2;
  uVar5 = FUN_00bbd8a0(CONCAT31((int3)((uint)*(int *)(iVar4 + 0xc) >> 8),
                                *(undefined *)(*(int *)(iVar4 + 0xc) + 0x22a)));
  *(undefined4 *)(param_4 + 4) = uVar5;
  if (DAT_01d69068 != '\0') {
    *(undefined *)(param_4 + 3) = *(undefined *)(*(int *)(iVar4 + 0xc) + 0x226);
  }
  return;
}



/* FUNCTION 27511 ; VA 0x00c19ac0 ; FUN_00c19ac0 */

/* WARNING: Removing unreachable block (ram,0x00c19bec) */
/* WARNING: Removing unreachable block (ram,0x00c19bc5) */
/* WARNING: Removing unreachable block (ram,0x00c19bfe) */
/* WARNING: Removing unreachable block (ram,0x00c19c2b) */
/* WARNING: Removing unreachable block (ram,0x00c19c0e) */

void __fastcall FUN_00c19ac0(int param_1)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uStack00000004;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806378;
  if (*(int *)(param_1 + 0x1c4) - (int)*(int **)(param_1 + 0x1c0) >> 3 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = **(int **)(param_1 + 0x1c0);
  }
  piVar6 = (int *)0x0;
  piStack_28 = (int *)0x0;
  uStack_8 = 0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  for (; iVar4 != 0; iVar4 = *(int *)(*(int *)(param_1 + 0x1c0) + (iVar4 + 1U) * 8)) {
    iVar1 = *(int *)(iVar4 + 4);
    if (param_1 == iVar1) {
      iVar1 = *(int *)(iVar4 + 8);
    }
    uStack00000004 = iVar4;
    iVar1 = FUN_00ca1730(iVar1);
    if ((iVar1 != 0) && ((*(int *)(iVar1 + 0x40) == 0 || (*(int *)(iVar1 + 0x40) == 6)))) {
      if (piVar6 == (int *)0x0) {
        FUN_006030d0(0,&stack0x00000004);
        iVar4 = uStack00000004;
        piVar6 = piStack_28;
      }
      else {
        *piVar6 = iVar4;
        piStack_28 = piVar6 + 1;
        piVar6 = piStack_28;
      }
    }
    if (param_1 == *(int *)(iVar4 + 4)) {
      iVar4 = *(int *)(iVar4 + 0x10);
    }
    else {
      iVar4 = *(int *)(iVar4 + 0x14);
    }
    if ((uint)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3) <= iVar4 + 1U) break;
  }
  puVar3 = (undefined4 *)0x0;
  uVar5 = 0;
  uVar2 = (int)piVar6 + 3U >> 2;
  uStack00000004 = uVar2;
  if (uVar2 != 0) {
    do {
      FUN_00ce0280(*puVar3,0);
      uVar5 = uVar5 + 1;
      puVar3 = puVar3 + 1;
    } while (uVar5 != uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27512 ; VA 0x00c19c40 ; FUN_00c19c40 */

void __thiscall FUN_00c19c40(int param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  int iVar5;
  int iVar6;
  
  iVar2 = *(int *)(param_3 + 0x6ac);
  if (*(int *)(param_1 + 0x1c4) - (int)*(int **)(param_1 + 0x1c0) >> 3 != 0) {
    for (iVar6 = **(int **)(param_1 + 0x1c0); iVar6 != 0;
        iVar6 = *(int *)(*(int *)(param_1 + 0x1c0) + (iVar6 + 1U) * 8)) {
      if ((*(int *)(iVar6 + 0x20) != -1) && (*(int *)(iVar6 + 0x1c) == -1)) {
        FUN_00ce9040(iVar6,0);
      }
      iVar5 = *(int *)(iVar6 + 4);
      if (param_1 == iVar5) {
        iVar5 = *(int *)(iVar6 + 8);
      }
      cVar1 = *(char *)(iVar6 + 0xd);
      if ((*(char *)(iVar2 + 0x2c) == '\0') ||
         ((*(int *)(iVar6 + 0x1c) != -1 && (*(int *)(iVar6 + 0x20) != -1)))) {
        bVar4 = false;
      }
      else {
        bVar4 = true;
      }
      if ((((cVar1 != '\0') || (bVar4)) && (0 < param_2)) &&
         ((iVar5 = FUN_00ca1730(iVar5), iVar5 != 0 && (iVar3 = *(int *)(iVar5 + 0x40), iVar3 != 3)))
         ) {
        if (cVar1 == '\0') {
          if (((bVar4) && (iVar3 != 1)) && (iVar3 != 2)) {
            FUN_009dffa0(iVar5);
          }
        }
        else {
          FUN_00bc2ac0(iVar5,param_2);
        }
      }
      if (param_1 == *(int *)(iVar6 + 4)) {
        iVar6 = *(int *)(iVar6 + 0x10);
      }
      else {
        iVar6 = *(int *)(iVar6 + 0x14);
      }
      if ((uint)(*(int *)(param_1 + 0x1c4) - *(int *)(param_1 + 0x1c0) >> 3) <= iVar6 + 1U) break;
    }
  }
  iVar2 = *(int *)(param_1 + 0x14);
  iVar6 = 0;
  if (0 < iVar2) {
    do {
      FUN_00c19c40(param_2,param_3);
      iVar6 = iVar6 + 1;
    } while (iVar6 < iVar2);
  }
  return;
}



/* FUNCTION 27513 ; VA 0x00c19d80 ; FUN_00c19d80 */

void __fastcall FUN_00c19d80(int param_1)

{
  undefined4 uVar1;
  float10 fVar2;
  undefined auStack_38 [36];
  undefined auStack_14 [12];
  float fStack_8;
  
  fVar2 = (float10)(**(code **)(**(int **)(param_1 + 0x1ac) + 100))();
  fStack_8 = (float)fVar2;
  fVar2 = (float10)FUN_00f9dd40(param_1);
  fStack_8 = (float)(fVar2 * (float10)fStack_8);
  FUN_00fa0110(fStack_8);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x60))(auStack_38,fStack_8);
  FUN_00fa0380(uVar1);
  uVar1 = (**(code **)(**(int **)(param_1 + 0x1ac) + 0x5c))(auStack_14);
  FUN_00fa0050(uVar1);
  *(undefined *)(param_1 + 0x229) = 1;
  return;
}



/* FUNCTION 27514 ; VA 0x00c19e00 ; FUN_00c19e00 */

undefined8 * FUN_00c19e00(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e20) {
    FUN_016f3809(&DAT_01ef8e20);
    if (DAT_01ef8e20 == -1) {
      DAT_01ef8e14._4_4_ = 0;
      DAT_01ef8e08._0_4_ = 0;
      DAT_01ef8e08._4_4_ = 0;
      DAT_01ef8e10 = 0;
      DAT_01ef8e14._0_4_ = 0;
      DAT_01ef8e1c = 0;
      FUN_016f37bf(&DAT_01ef8e20);
    }
  }
  return &DAT_01ef8e08;
}



/* FUNCTION 27515 ; VA 0x00c19e70 ; FUN_00c19e70 */

void __fastcall FUN_00c19e70(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00ca1730(param_1);
  if ((iVar1 != 0) && (iVar1 = FUN_00ca1550(), iVar1 != param_1)) {
    return;
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef8e20) &&
     (FUN_016f3809(&DAT_01ef8e20), DAT_01ef8e20 == -1)) {
    DAT_01ef8e14._4_4_ = 0;
    DAT_01ef8e08._0_4_ = 0;
    DAT_01ef8e08._4_4_ = 0;
    DAT_01ef8e10 = 0;
    DAT_01ef8e14._0_4_ = 0;
    DAT_01ef8e1c = 0;
    FUN_016f37bf(&DAT_01ef8e20);
  }
  FUN_00fa0570(&DAT_01ef8e08,param_1 + 0x30);
  return;
}



/* FUNCTION 27516 ; VA 0x00c19f10 ; FUN_00c19f10 */

undefined4 * __fastcall FUN_00c19f10(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806398;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IPipelined::vftable;
  param_1[1] = 0;
  uStack_8 = 0;
  FUN_01078820();
  *param_1 = RBX::Mechanism::vftable;
  param_1[2] = RBX::Mechanism::vftable;
  param_1[0xb] = 0xffffffff;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27517 ; VA 0x00c19f72 ; FUN_00c19f72 */

void FUN_00c19f72(void)

{
  FUN_00c19f80();
  return;
}



/* FUNCTION 27518 ; VA 0x00c19f80 ; FUN_00c19f80 */

undefined4 * __thiscall FUN_00c19f80(undefined4 *param_1,byte param_2)

{
  param_1[2] = RBX::Mechanism::vftable;
  *param_1 = RBX::Mechanism::vftable;
  FUN_01078870();
  *param_1 = RBX::IPipelined::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 27519 ; VA 0x00c19fc0 ; FUN_00c19fc0 */

uint FUN_00c19fc0(uint param_1)

{
  char cVar1;
  
  while( true ) {
    if ((-(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) - 8U) == 0) {
      return param_1;
    }
    cVar1 = FUN_00ca0f40();
    if (cVar1 != '\0') break;
    param_1 = -(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) - 8U;
  }
  return param_1;
}



/* FUNCTION 27520 ; VA 0x00c1a000 ; FUN_00c1a000 */

uint FUN_00c1a000(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00ca1730(param_1);
  if (iVar1 != 0) {
    return -(uint)(*(int *)(iVar1 + 0x28) != 0) & *(int *)(iVar1 + 0x28) - 8U;
  }
  return 0;
}



/* FUNCTION 27521 ; VA 0x00c1a030 ; FUN_00c1a030 */

undefined4 FUN_00c1a030(void)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  
  uVar2 = FUN_00c155c0();
  if ((uVar2 != 0) && (cVar1 = FUN_00ca0f40(), cVar1 == '\0')) {
    while (((-(uint)(*(int *)(uVar2 + 0xc) != 0) & *(int *)(uVar2 + 0xc) - 8U) != 0 &&
           (cVar1 = FUN_00ca0f40(), cVar1 == '\0'))) {
      uVar2 = -(uint)(*(int *)(uVar2 + 0xc) != 0) & *(int *)(uVar2 + 0xc) - 8U;
    }
    uVar3 = FUN_00ca1550();
    return uVar3;
  }
  return 0;
}



/* FUNCTION 27522 ; VA 0x00c1a090 ; FUN_00c1a090 */

uint __fastcall FUN_00c1a090(int param_1)

{
  int *piVar1;
  
  piVar1 = (int *)(*(int *)(param_1 + 0x24) + 0x1c);
  if (*(int *)(param_1 + 0x24) == 0) {
    piVar1 = (int *)0x24;
  }
  return -(uint)(*(int *)(*piVar1 + 0x1c) != 0) & *(int *)(*piVar1 + 0x1c) - 8U;
}



/* FUNCTION 27523 ; VA 0x00c1a0b0 ; FUN_00c1a0b0 */

uint FUN_00c1a0b0(uint param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  
  if (*(int *)(param_1 + 0x3c) == 0xb) {
    return 0;
  }
  do {
    uVar3 = param_1;
    iVar1 = *(int *)(uVar3 + 0xc);
    param_1 = -(uint)(iVar1 != 0) & iVar1 - 8U;
    if (param_1 == 0) {
      return uVar3;
    }
    piVar2 = (int *)(iVar1 + 0x34);
    if (iVar1 == 0) {
      piVar2 = (int *)0x3c;
    }
  } while (*piVar2 != 0xb);
  return uVar3;
}



/* FUNCTION 27524 ; VA 0x00c1a0f0 ; FUN_00c1a0f0 */

uint __fastcall FUN_00c1a0f0(int param_1)

{
  return -(uint)(*(int *)(param_1 + 0x24) != 0) & *(int *)(param_1 + 0x24) - 8U;
}



/* FUNCTION 27525 ; VA 0x00c1a100 ; FUN_00c1a100 */

undefined4 FUN_00c1a100(void)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  
  uVar2 = FUN_00c155c0();
  if ((uVar2 != 0) && (cVar1 = FUN_00ca0f40(), cVar1 == '\0')) {
    while (((-(uint)(*(int *)(uVar2 + 0xc) != 0) & *(int *)(uVar2 + 0xc) - 8U) != 0 &&
           (cVar1 = FUN_00ca0f40(), cVar1 == '\0'))) {
      uVar2 = -(uint)(*(int *)(uVar2 + 0xc) != 0) & *(int *)(uVar2 + 0xc) - 8U;
    }
    uVar3 = FUN_00ca1550();
    return uVar3;
  }
  return 0;
}



/* FUNCTION 27526 ; VA 0x00c1a160 ; FUN_00c1a160 */

uint FUN_00c1a160(uint param_1)

{
  int iVar1;
  int *piVar2;
  
  if ((param_1 != 0) && (*(int *)(param_1 + 0x20) != 0)) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x18);
    param_1 = iVar1 - 8;
    if ((param_1 & -(uint)(iVar1 != 0)) != 0) {
      piVar2 = (int *)(iVar1 + 0x18);
      if (iVar1 == 0) {
        piVar2 = (int *)&DAT_00000020;
      }
      param_1 = *piVar2 - 8;
      if ((param_1 & -(uint)(*piVar2 != 0)) != 0) {
        return CONCAT31((int3)(param_1 >> 8),1);
      }
    }
  }
  return param_1 & 0xffffff00;
}



/* FUNCTION 27527 ; VA 0x00c1a1b0 ; FUN_00c1a1b0 */

undefined4 FUN_00c1a1b0(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_00ca0f40();
  if (cVar1 != '\0') {
    return 0;
  }
  if (((-(uint)(*(int *)(param_1 + 0xc) != 0) & *(int *)(param_1 + 0xc) - 8U) != 0) &&
     (cVar1 = FUN_00ca0f40(), cVar1 == '\0')) {
    return 0;
  }
  return 1;
}



/* FUNCTION 27528 ; VA 0x00c1a1f0 ; FUN_00c1a1f0 */

undefined4 * __thiscall FUN_00c1a1f0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01806412;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 8) = *(int *)(param_3 + 8) + 1;
    UNLOCK();
  }
  uStack_94 = param_2;
  iStack_90 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  puStack_14 = &uStack_74;
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 8) = *(int *)(iStack_90 + 8) + 1;
    UNLOCK();
  }
  uStack_74 = uStack_94;
  iStack_70 = iStack_90;
  uStack_8 = 3;
  FUN_0054ef60(auStack_8c);
  puStack_14 = &uStack_34;
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 8) = *(int *)(iStack_70 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8 = 5;
  FUN_0054ef60(auStack_6c);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_34);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_54;
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    iStack_50 = iStack_30;
    uStack_8 = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8 = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_50 != 0) {
        LOCK();
        *(int *)(iStack_50 + 8) = *(int *)(iStack_50 + 8) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_54;
      puVar3[1] = iStack_50;
      uStack_8 = 10;
      FUN_0054ef60(auStack_4c);
    }
    param_1[2] = puVar3;
    FUN_005d11a0();
    FUN_005d11a0();
    bVar1 = true;
  }
  else {
    FUN_005d11a0();
    bVar1 = false;
  }
  FUN_005d11a0();
  ppuVar4 = &PTR_FUN_0196603c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005d11a0();
  FUN_005d11a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27529 ; VA 0x00c1a400 ; FUN_00c1a400 */

undefined4 * __fastcall FUN_00c1a400(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  undefined auStack_74 [24];
  undefined auStack_5c [24];
  undefined auStack_44 [24];
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806498;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_104;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x0000001c);
  puStack_14 = auStack_d4;
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  FUN_0054ef60(auStack_104);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_ec);
  puStack_14 = auStack_a4;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_d4);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_bc);
  puStack_14 = auStack_44;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_a4);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(auStack_8c);
  uStack_8._0_1_ = 8;
  cVar2 = FUN_00585a40(auStack_44);
  if (cVar2 == '\0') {
    puStack_14 = auStack_74;
    FUN_0054ef60(auStack_44);
    uStack_8._0_1_ = 9;
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 10;
    puVar3 = (undefined *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 0xb;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_74);
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_5c);
    }
    param_1[2] = puVar3;
    FUN_005509f0();
    FUN_005509f0();
    bVar1 = true;
  }
  else {
    FUN_005509f0();
    bVar1 = false;
  }
  FUN_005509f0();
  ppuVar4 = &PTR_FUN_0196605c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_005509f0();
  FUN_005509f0();
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27530 ; VA 0x00c1a5e0 ; FUN_00c1a5e0 */

undefined4 * __thiscall FUN_00c1a5e0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  int in_stack_00000020;
  undefined4 in_stack_00000024;
  int in_stack_00000028;
  undefined auStack_b4 [40];
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  int iStack_40;
  undefined auStack_3c [24];
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018064ed;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_0054ef60(&stack0x00000004);
  if (in_stack_00000020 != 0) {
    LOCK();
    *(int *)(in_stack_00000020 + 4) = *(int *)(in_stack_00000020 + 4) + 1;
    UNLOCK();
  }
  iStack_70 = in_stack_00000020;
  uStack_74 = in_stack_0000001c;
  if (in_stack_00000028 != 0) {
    LOCK();
    *(int *)(in_stack_00000028 + 4) = *(int *)(in_stack_00000028 + 4) + 1;
    UNLOCK();
  }
  uStack_6c = in_stack_00000024;
  iStack_68 = in_stack_00000028;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(auStack_8c);
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 4) = *(int *)(iStack_70 + 4) + 1;
    UNLOCK();
  }
  iStack_48 = iStack_70;
  uStack_4c = uStack_74;
  if (iStack_68 != 0) {
    LOCK();
    *(int *)(iStack_68 + 4) = *(int *)(iStack_68 + 4) + 1;
    UNLOCK();
  }
  uStack_44 = uStack_6c;
  iStack_40 = iStack_68;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(auStack_64);
  if (iStack_48 != 0) {
    LOCK();
    *(int *)(iStack_48 + 4) = *(int *)(iStack_48 + 4) + 1;
    UNLOCK();
  }
  iStack_20 = iStack_48;
  uStack_24 = uStack_4c;
  if (iStack_40 != 0) {
    LOCK();
    *(int *)(iStack_40 + 4) = *(int *)(iStack_40 + 4) + 1;
    UNLOCK();
  }
  uStack_1c = uStack_44;
  iStack_18 = iStack_40;
  uStack_8._0_1_ = 3;
  cVar2 = FUN_00585a40(auStack_3c);
  if (cVar2 == '\0') {
    FUN_00c1c5a0(auStack_3c);
    uStack_8._0_1_ = 4;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 5;
    if (iStack_14 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_00c1c5a0(auStack_b4);
    }
    param_1[2] = uVar3;
    FUN_009468e0();
    FUN_009468e0();
    bVar1 = true;
  }
  else {
    FUN_009468e0();
    bVar1 = false;
  }
  FUN_009468e0();
  ppuVar4 = &PTR_FUN_01966054;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_009468e0();
  FUN_009468e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27531 ; VA 0x00c1a790 ; FUN_00c1a790 */

undefined4 * __thiscall FUN_00c1a790(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806518;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xc1a7c5;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xc1a7db;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_01966064;
  cVar1 = FUN_00c1b910();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xc1a8b2;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1a836;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xc1a8b7;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1a866;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00c1a8bc;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1a896;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27532 ; VA 0x00c1a8c0 ; FUN_00c1a8c0 */

undefined4 * __thiscall
FUN_00c1a8c0(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  bool bVar1;
  char cVar2;
  undefined **ppuVar3;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  iStack_10 = param_3;
  if (param_5 != 0) {
    LOCK();
    *(int *)(param_5 + 4) = *(int *)(param_5 + 4) + 1;
    UNLOCK();
  }
  uStack_c = param_4;
  iStack_8 = param_5;
  cVar2 = FUN_00585a40(&uStack_14);
  if (cVar2 == '\0') {
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (iStack_10 != 0) {
      LOCK();
      *(int *)(iStack_10 + 4) = *(int *)(iStack_10 + 4) + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = iStack_10;
    param_1[4] = 0;
    param_1[5] = 0;
    if (iStack_8 != 0) {
      LOCK();
      *(int *)(iStack_8 + 4) = *(int *)(iStack_8 + 4) + 1;
      UNLOCK();
    }
    param_1[5] = iStack_8;
    param_1[4] = uStack_c;
    FUN_0056b650();
    bVar1 = true;
  }
  else {
    bVar1 = false;
  }
  FUN_0056b650();
  FUN_0056b650();
  ppuVar3 = &PTR_FUN_01966034;
  if (!bVar1) {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_0056b650();
  FUN_0056b650();
  return param_1;
}



/* FUNCTION 27533 ; VA 0x00c1aa00 ; FUN_00c1aa00 */

undefined4 * __thiscall FUN_00c1aa00(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined in_stack_00000034;
  undefined auStack_118 [24];
  undefined auStack_100 [24];
  undefined uStack_e8;
  undefined auStack_e4 [24];
  undefined auStack_cc [24];
  undefined uStack_b4;
  undefined auStack_b0 [24];
  undefined auStack_98 [24];
  undefined uStack_80;
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined uStack_4c;
  undefined auStack_48 [24];
  undefined auStack_30 [24];
  undefined uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018065a8;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_118;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_8._0_1_ = 1;
  FUN_0054f050(&stack0x0000001c);
  uStack_e8 = in_stack_00000034;
  puStack_14 = auStack_e4;
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  FUN_0054ef60(auStack_118);
  uStack_8._0_1_ = 3;
  FUN_0054f050(auStack_100);
  uStack_b4 = uStack_e8;
  puStack_14 = auStack_b0;
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_e4);
  uStack_8._0_1_ = 5;
  FUN_0054f050(auStack_cc);
  uStack_80 = uStack_b4;
  puStack_14 = auStack_48;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_b0);
  uStack_8._0_1_ = 7;
  FUN_0054f050(auStack_98);
  uStack_18 = uStack_80;
  uStack_8._0_1_ = 8;
  cVar2 = FUN_00585a40(auStack_48);
  if (cVar2 == '\0') {
    puStack_14 = auStack_7c;
    FUN_0054ef60(auStack_48);
    uStack_8._0_1_ = 9;
    FUN_0054f050(auStack_30);
    uStack_4c = uStack_18;
    uStack_8._0_1_ = 10;
    puVar3 = (undefined *)FUN_01674e20(0x34);
    uStack_8._0_1_ = 0xb;
    puStack_14 = puVar3;
    if (puVar3 == (undefined *)0x0) {
      puVar3 = (undefined *)0x0;
    }
    else {
      FUN_0054ef60(auStack_7c);
      uStack_8._0_1_ = 0xc;
      FUN_0054f050(auStack_64);
      puVar3[0x30] = uStack_4c;
    }
    param_1[2] = puVar3;
    FUN_00c1cbe0();
    FUN_00c1cbe0();
    bVar1 = true;
  }
  else {
    FUN_00c1cbe0();
    bVar1 = false;
  }
  FUN_00c1cbe0();
  ppuVar4 = &PTR_FUN_0196604c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00c1cbe0();
  FUN_00c1cbe0();
  FUN_00c1cbe0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27534 ; VA 0x00c1ac10 ; FUN_00c1ac10 */

undefined4 * __thiscall
FUN_00c1ac10(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01966010;
  cVar3 = FUN_00a9fa00(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 27535 ; VA 0x00c1ad00 ; FUN_00c1ad00 */

undefined4 * __thiscall FUN_00c1ad00(undefined4 *param_1,undefined4 param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_94;
  int iStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  int iStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01806622;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  uStack_94 = param_2;
  iStack_90 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x0000000c);
  puStack_14 = &uStack_74;
  if (iStack_90 != 0) {
    LOCK();
    *(int *)(iStack_90 + 4) = *(int *)(iStack_90 + 4) + 1;
    UNLOCK();
  }
  uStack_74 = uStack_94;
  iStack_70 = iStack_90;
  uStack_8 = 3;
  FUN_0054ef60(auStack_8c);
  puStack_14 = &uStack_34;
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 4) = *(int *)(iStack_70 + 4) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8 = 5;
  FUN_0054ef60(auStack_6c);
  uStack_8 = 6;
  cVar2 = FUN_00585a40(&uStack_34);
  if (cVar2 == '\0') {
    puStack_14 = &uStack_54;
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
      UNLOCK();
    }
    uStack_54 = uStack_34;
    iStack_50 = iStack_30;
    uStack_8 = 7;
    FUN_0054ef60(auStack_2c);
    uStack_8 = 8;
    puVar3 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8 = 9;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = 0;
      puVar3[1] = 0;
      if (iStack_50 != 0) {
        LOCK();
        *(int *)(iStack_50 + 4) = *(int *)(iStack_50 + 4) + 1;
        UNLOCK();
      }
      *puVar3 = uStack_54;
      puVar3[1] = iStack_50;
      uStack_8 = 10;
      FUN_0054ef60(auStack_4c);
    }
    param_1[2] = puVar3;
    FUN_006511a0();
    FUN_006511a0();
    bVar1 = true;
  }
  else {
    FUN_006511a0();
    bVar1 = false;
  }
  FUN_006511a0();
  ppuVar4 = &PTR_FUN_0196602c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_006511a0();
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27536 ; VA 0x00c1af10 ; FUN_00c1af10 */

undefined4 * __thiscall FUN_00c1af10(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000018;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806648;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  iStack_54 = 0xc1af45;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  piStack_50 = aiStack_44;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_54 = 0xc1af5b;
  FUN_0054ef60();
  piStack_50 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = (undefined4 *)auStack_68;
  FUN_0054ef60(aiStack_2c);
  ppuVar3 = &PTR_FUN_01966044;
  cVar1 = FUN_00c1ba80();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    piStack_50 = (int *)(uStack_18 + 1);
    iVar2 = aiStack_2c[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      piStack_50 = (int *)(uStack_18 + 0x24);
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xc1b032;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1afb6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_30) {
    piStack_50 = (int *)(uStack_30 + 1);
    iVar2 = aiStack_44[0];
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      piStack_50 = (int *)(uStack_30 + 0x24);
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)0xc1b037;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1afe6;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000018) {
    piStack_50 = (int *)(in_stack_00000018 + 1);
    iVar2 = param_2;
    if (0xfff < piStack_50) {
      iVar2 = *(int *)(param_2 + -4);
      piStack_50 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00c1b03c;
        FUN_017167a3();
      }
    }
    uStack_58 = 0xc1b016;
    iStack_54 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27537 ; VA 0x00c1b040 ; FUN_00c1b040 */

undefined4 * __thiscall FUN_00c1b040(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined **ppuVar4;
  undefined4 in_stack_0000001c;
  int in_stack_00000020;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  int iStack_78;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  int iStack_38;
  undefined auStack_34 [24];
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180669a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_0054ef60(&stack0x00000004);
  if (in_stack_00000020 != 0) {
    LOCK();
    *(int *)(in_stack_00000020 + 4) = *(int *)(in_stack_00000020 + 4) + 1;
    UNLOCK();
  }
  uStack_7c = in_stack_0000001c;
  iStack_78 = in_stack_00000020;
  uStack_8._0_1_ = 1;
  FUN_0054ef60(auStack_94);
  if (iStack_78 != 0) {
    LOCK();
    *(int *)(iStack_78 + 4) = *(int *)(iStack_78 + 4) + 1;
    UNLOCK();
  }
  uStack_5c = uStack_7c;
  iStack_58 = iStack_78;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(auStack_74);
  if (iStack_58 != 0) {
    LOCK();
    *(int *)(iStack_58 + 4) = *(int *)(iStack_58 + 4) + 1;
    UNLOCK();
  }
  uStack_1c = uStack_5c;
  iStack_18 = iStack_58;
  uStack_8._0_1_ = 3;
  cVar2 = FUN_00585a40(auStack_34);
  if (cVar2 == '\0') {
    FUN_0054ef60(auStack_34);
    if (iStack_18 != 0) {
      LOCK();
      *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
      UNLOCK();
    }
    uStack_3c = uStack_1c;
    iStack_38 = iStack_18;
    uStack_8._0_1_ = 4;
    iVar3 = FUN_01674e20(0x20);
    uStack_8._0_1_ = 5;
    iStack_14 = iVar3;
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      FUN_0054ef60(auStack_54);
      *(undefined4 *)(iVar3 + 0x18) = 0;
      *(undefined4 *)(iVar3 + 0x1c) = 0;
      if (iStack_38 != 0) {
        LOCK();
        *(int *)(iStack_38 + 4) = *(int *)(iStack_38 + 4) + 1;
        UNLOCK();
      }
      *(undefined4 *)(iVar3 + 0x18) = uStack_3c;
      *(int *)(iVar3 + 0x1c) = iStack_38;
    }
    param_1[2] = iVar3;
    FUN_0056cac0();
    FUN_0056cac0();
    bVar1 = true;
  }
  else {
    FUN_0056cac0();
    bVar1 = false;
  }
  FUN_0056cac0();
  ppuVar4 = &PTR_FUN_0196606c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_0056cac0();
  FUN_0056cac0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27538 ; VA 0x00c1b1e0 ; FUN_00c1b1e0 */

int * __thiscall
FUN_00c1b1e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018066d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c1b320();
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<float,1>::
              BoundPropGetSet<class_RBX::Soundscape::SoundService>::vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = param_5;
    puVar5[5] = param_6;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27539 ; VA 0x00c1b2d0 ; FUN_00c1b2d0 */

int * __thiscall FUN_00c1b2d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c28900();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 27540 ; VA 0x00c1b320 ; FUN_00c1b320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c1b320(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806700;
  pvStack_10 = ExceptionList;
  if (DAT_01ef98f8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9b10) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef9b10);
      if (DAT_01ef9b10 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SoundService",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef9b08 = RBX::Creator<class_RBX::Soundscape::SoundService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef9900,&DAT_01ef9b08);
        FUN_016f3654(FUN_018938b0);
        FUN_016f37bf(&DAT_01ef9b10);
      }
    }
    DAT_01ef98f8 = &DAT_01ef9900;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef98f8;
}



/* FUNCTION 27541 ; VA 0x00c1b420 ; FUN_00c1b420 */

void FUN_00c1b420(void)

{
  int iVar1;
  
  if (DAT_01ef9b14 == 0) {
    iVar1 = FUN_00c1b320();
    DAT_01ef9b14 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27542 ; VA 0x00c1b440 ; FUN_00c1b440 */

int __thiscall FUN_00c1b440(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  
  iVar8 = *param_1;
  iVar9 = param_2 - iVar8 >> 3;
  iVar4 = param_1[1] - iVar8 >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar6 = param_1[2] - iVar8 >> 3;
  uVar10 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar10 = (uVar6 >> 1) + uVar6, uVar10 < uVar1)) {
    uVar10 = uVar1;
  }
  puVar5 = (undefined4 *)FUN_00578020(uVar10);
  puVar3 = puVar5 + iVar9 * 2;
  *puVar3 = 0;
  puVar3[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 8);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar3 = *param_3;
  puVar3[1] = param_3[1];
  iVar8 = param_1[1];
  iVar4 = *param_1;
  puVar7 = puVar5;
  if (param_2 != iVar8) {
    FUN_006cfaf0(*param_1,param_2,puVar5,param_1);
    iVar8 = param_1[1];
    puVar7 = puVar3 + 2;
    iVar4 = param_2;
  }
  FUN_006cfaf0(iVar4,iVar8,puVar7,param_1);
  FUN_00777d00(puVar5,uVar1,uVar10);
  return *param_1 + iVar9 * 8;
}



/* FUNCTION 27543 ; VA 0x00c1b530 ; FUN_00c1b530 */

void __thiscall FUN_00c1b530(int *param_1,int *param_2,uint *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar4 = (undefined4 *)*param_1;
  puVar1 = (undefined4 *)puVar4[1];
  puVar5 = puVar4;
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    puVar2 = puVar1;
    do {
      if ((uint)puVar2[4] < *param_3) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        if ((*(char *)((int)puVar4 + 0xd) != '\0') && (*param_3 < (uint)puVar2[4])) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined4 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
  }
  if (*(char *)((int)puVar4 + 0xd) == '\0') {
    puVar1 = (undefined4 *)*puVar4;
  }
  if (*(char *)((int)puVar1 + 0xd) == '\0') {
    do {
      if (*param_3 < (uint)puVar1[4]) {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      else {
        puVar2 = (undefined4 *)puVar1[2];
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  *param_2 = (int)puVar5;
  param_2[1] = (int)puVar4;
  return;
}



/* FUNCTION 27544 ; VA 0x00c1b5b0 ; FUN_00c1b5b0 */

int __thiscall FUN_00c1b5b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806710;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<struct_RBX::Soundscape::NonBlockingFmodSoundLoader>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 4) == 0 || (*(int *)(*(int *)(param_2 + 4) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)param_2 = param_2;
    piVar3 = *(int **)(param_2 + 4);
    *(int **)(param_2 + 4) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27545 ; VA 0x00c1b683 ; Catch_All@00c1b683 */

void Catch_All_00c1b683(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00c1e4d0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27546 ; VA 0x00c1b6a0 ; FUN_00c1b6a0 */

int __thiscall FUN_00c1b6a0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806720;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Soundscape::SoundJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27547 ; VA 0x00c1b774 ; Catch_All@00c1b774 */

void Catch_All_00c1b774(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27548 ; VA 0x00c1b790 ; FUN_00c1b790 */

int __thiscall FUN_00c1b790(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806730;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Soundscape::SoundServiceStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27549 ; VA 0x00c1b862 ; Catch_All@00c1b862 */

void Catch_All_00c1b862(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27550 ; VA 0x00c1b880 ; FUN_00c1b880 */

void __thiscall FUN_00c1b880(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806740;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_resource<class_FMOD::System*,struct_FMODSystemRelease>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27551 ; VA 0x00c1b8ec ; Catch_All@00c1b8ec */

void Catch_All_00c1b8ec(void)

{
  int unaff_EBP;
  
  FUN_00c1e270(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27552 ; VA 0x00c1b910 ; FUN_00c1b910 */

undefined FUN_00c1b910(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806768;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 27553 ; VA 0x00c1ba80 ; FUN_00c1ba80 */

undefined FUN_00c1ba80(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined uVar5;
  uint in_stack_00000018;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806798;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_2c);
  if (cVar1 == '\0') {
    FUN_0054ef60(auStack_2c);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(aiStack_44);
    if (0xf < uStack_30) {
      uVar3 = uStack_30 + 1;
      iVar2 = aiStack_44[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_44[0] + -4);
        uVar3 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 1;
  }
  else {
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uVar5 = 0;
  }
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_18 = 0xf;
  uStack_1c = 0;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 27554 ; VA 0x00c1bbf0 ; FUN_00c1bbf0 */

void FUN_00c1bbf0(int *param_1)

{
  void **ppvVar1;
  int iVar2;
  int iStack_68;
  int iStack_64;
  char cStack_60;
  int iStack_5c;
  char acStack_58 [72];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e2778;
  pvStack_10 = ExceptionList;
  iStack_68 = -0x3ea8cf1e;
  iStack_64 = 0x7f0725e3;
  cStack_60 = '\0';
  iStack_5c = 0;
  acStack_58[0] = '\0';
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (*param_1 != -0x3ea8cf1e) {
    do {
      LOCK();
      iVar2 = *param_1;
      if (iVar2 == 0) {
        *param_1 = iStack_64;
        iVar2 = 0;
      }
      UNLOCK();
      if (iVar2 == 0) {
        if (iStack_5c == 0) {
          if (acStack_58[0] == '\0') {
            FUN_005881c0(acStack_58,param_1);
          }
          iVar2 = OpenEventA(0x100002,0,acStack_58);
          if ((iStack_5c != 0) && (iStack_5c != -1)) {
            CloseHandle(iStack_5c);
          }
          iStack_5c = iVar2;
          if (iVar2 != 0) goto LAB_00c1bd02;
        }
        else {
LAB_00c1bd02:
          ResetEvent(iStack_5c);
        }
        FUN_011ae050(0x804,2,FUN_00c21900,0);
        FUN_011add40(0,0,FUN_00c21ee0,FUN_00c21f40,FUN_00c21ec0,0xffffffff);
        FUN_0057b500(param_1,&iStack_68);
        ppvVar1 = (void **)ExceptionList;
        break;
      }
      if (cStack_60 == '\0') {
        LOCK();
        param_1[1] = param_1[1] + 1;
        UNLOCK();
        cStack_60 = '\x01';
        ppvVar1 = (void **)ExceptionList;
        if (*param_1 == iStack_68) break;
        if (iStack_5c != 0) goto LAB_00c1bca8;
        if (acStack_58[0] == '\0') {
          FUN_005881c0(acStack_58,param_1);
        }
        iVar2 = CreateEventA(0,1,0,acStack_58);
        if ((iStack_5c != 0) && (iStack_5c != -1)) {
          CloseHandle(iStack_5c);
        }
      }
      else {
LAB_00c1bca8:
        WaitForSingleObjectEx(iStack_5c,0xffffffff,0);
        iVar2 = iStack_5c;
      }
      iStack_5c = iVar2;
      ppvVar1 = (void **)ExceptionList;
    } while (*param_1 != iStack_68);
  }
  ExceptionList = ppvVar1;
  if ((iStack_5c != 0) && (iStack_5c != -1)) {
    CloseHandle(iStack_5c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27555 ; VA 0x00c1bd70 ; FUN_00c1bd70 */

undefined4 * FUN_00c1bd70(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806809;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009fb200();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0xb0);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar1 = *param_2;
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar4 = RBX::Described<class_RBX::Stats::Item,class_RBX::Instance>::vftable;
    uVar5 = FUN_009fb200();
    puVar4[3] = uVar5;
    *(undefined8 *)(puVar4 + 0x16) = 0;
    puVar4[0x1c] = 0;
    puVar4[0x1d] = 0xf;
    *(undefined *)(puVar4 + 0x18) = 0;
    *puVar4 = RBX::Soundscape::SoundServiceStatsItem::vftable;
    puVar4[0x1e] = uVar1;
    puVar4[0x1f] = 0;
    puVar4[0x20] = 0;
    puVar4[0x29] = 0;
    puVar4[0x2a] = 0;
    uStack_8._0_1_ = 5;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Sound",5);
    uStack_8._0_1_ = 6;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 5;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c1b790(puVar4,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 10;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27556 ; VA 0x00c1bf10 ; FUN_00c1bf10 */

void FUN_00c1bf10(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_005e6280();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 27557 ; VA 0x00c1bf70 ; FUN_00c1bf70 */

void __thiscall FUN_00c1bf70(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_00c1b440(puVar2,param_2);
  return;
}



/* FUNCTION 27558 ; VA 0x00c1bfc0 ; FUN_00c1bfc0 */

int FUN_00c1bfc0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00add460();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 27559 ; VA 0x00c1c000 ; thunk_FUN_00ae1680 */

undefined * thunk_FUN_00ae1680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ead4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eebd74);
    if (DAT_01eebd74 == -1) {
      uStack_8 = 0;
      FUN_00fe8ba0();
      FUN_016f3654(&LAB_0188b810);
      FUN_016f37bf(&DAT_01eebd74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eebd10;
}



/* FUNCTION 27560 ; VA 0x00c1c010 ; FUN_00c1c010 */

undefined4 * FUN_00c1c010(void)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x40);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::thread_data<class_<lambda_38470608b436a2437fa63f29d2ff569d>_>::vftable;
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 27561 ; VA 0x00c1c072 ; Catch_All@00c1c072 */

void Catch_All_00c1c072(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27562 ; VA 0x00c1c0a0 ; FUN_00c1c0a0 */

undefined4 * FUN_00c1c0a0(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180685b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x88);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::thread_data<class_<lambda_b96566f913c227a1a004992e22af1fb9>_>::vftable;
    uStack_8._0_1_ = 2;
    puVar3[0x10] = *param_1;
    puVar3[0x12] = 0;
    FUN_005880d0(param_1 + 2);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar3[0x1a] = 0;
    FUN_005880d0(param_1 + 10);
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 27563 ; VA 0x00c1c141 ; Catch_All@00c1c141 */

void Catch_All_00c1c141(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27564 ; VA 0x00c1c170 ; FUN_00c1c170 */

undefined4 * FUN_00c1c170(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180688b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x88);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::thread_data<class_<lambda_f3e4f0f3bf79b9e52bf64c75a2bd3764>_>::vftable;
    uStack_8._0_1_ = 2;
    puVar3[0x10] = *param_1;
    puVar3[0x12] = 0;
    FUN_005880d0(param_1 + 2);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar3[0x1a] = 0;
    FUN_005880d0(param_1 + 10);
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 27565 ; VA 0x00c1c211 ; Catch_All@00c1c211 */

void Catch_All_00c1c211(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 27566 ; VA 0x00c1c240 ; FUN_00c1c240 */

int * FUN_00c1c240(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018068af;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_8 = 0;
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::Soundscape::FMODPlaybackChannelGroup>::vftable;
    FUN_0107fb80(*param_2);
  }
  piVar1 = piVar3 + 3;
  *param_1 = (int)piVar1;
  param_1[1] = (int)piVar3;
  if ((piVar1 != (int *)0x0) && ((piVar3[4] == 0 || (*(int *)(piVar3[4] + 4) == 0)))) {
    piVar4 = piVar3;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *piVar1 = (int)piVar1;
    piVar1 = (int *)piVar3[4];
    piVar3[4] = (int)piVar4;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[1] + -1;
      piVar4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27567 ; VA 0x00c1c320 ; FUN_00c1c320 */

int __thiscall FUN_00c1c320(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_00c1b880(param_2,param_3);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar4 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 27568 ; VA 0x00c1c390 ; thunk_FUN_00c287a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c287a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807736;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9b94) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef9b94);
    if (DAT_01ef9b94 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ListenerType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef9b30 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ListenerType>::vftable;
      FUN_009caf20(&DAT_01d68590,4);
      FUN_016f3654(&LAB_01893870);
      FUN_016f37bf(&DAT_01ef9b94);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef9b30;
}



/* FUNCTION 27569 ; VA 0x00c1c3a0 ; FUN_00c1c3a0 */

undefined4 FUN_00c1c3a0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00c1c51d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00c1c51d;
  }
  iVar2 = FUN_00c287a0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00c1c4c8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00c287a0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00c1b2d0(&param_3);
      iVar4 = FUN_00c287a0();
      iStack_ec = iVar4;
      iVar5 = FUN_00c287a0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00c1c4c8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00c287a0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 27570 ; VA 0x00c1c5a0 ; FUN_00c1c5a0 */

int __thiscall FUN_00c1c5a0(int param_1,int param_2)

{
  int *piVar1;
  
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (*(int *)(param_2 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (*(int *)(param_2 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  return param_1;
}



/* FUNCTION 27571 ; VA 0x00c1c610 ; FUN_00c1c610 */

undefined4 * __thiscall FUN_00c1c610(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018068c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_8 = 0;
  param_1[2] = param_3;
  param_1[3] = 0;
  FUN_0054ef60(param_2);
  FUN_016dee4c(param_1 + 10,2);
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27572 ; VA 0x00c1c690 ; FUN_00c1c690 */

undefined4 * __fastcall FUN_00c1c690(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806a6c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Soundscape::SoundService,class_RBX::ServiceInstance>
             ::vftable;
  uVar3 = FUN_00c1b320();
  param_1[3] = uVar3;
  *param_1 = RBX::Soundscape::SoundService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  *(undefined *)(param_1 + 0x19) = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0x3f800000;
  param_1[0x1e] = 0x40551eb8;
  param_1[0x1f] = 0x3f800000;
  *(undefined *)(param_1 + 0x20) = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0x3f800000;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0x3f800000;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0x3f800000;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  puVar1 = param_1 + 0x34;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  *(undefined *)(param_1 + 0x33) = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  puStack_18 = puVar1;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  FUN_016dee4c(param_1 + 0x3c,2);
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  *(undefined8 *)(param_1 + 0x54) = 0;
  *(undefined *)(param_1 + 0x56) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x57] = uVar3;
  param_1[0x58] = 0;
  param_1[0x59] = 0x3f800000;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  *(undefined *)(param_1 + 0x5c) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x5d] = uVar3;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0x3f800000;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  puVar1 = param_1 + 0x62;
  uStack_8._0_1_ = 0xe;
  *puVar1 = 0;
  param_1[99] = 0;
  puStack_18 = puVar1;
  uVar3 = FUN_00601dc0();
  *puVar1 = uVar3;
  *(undefined *)(param_1 + 100) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x65] = uVar3;
  param_1[0x66] = 0;
  param_1[0x67] = 0x3f800000;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  *(undefined *)(param_1 + 0x6a) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x6b] = uVar3;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0x3f800000;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  *(undefined *)(param_1 + 0x73) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0x74] = uVar3;
  param_1[0x75] = 0;
  param_1[0x76] = 0x3f800000;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  FUN_016dee4c(param_1 + 0x7c,2);
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0x1000000;
  *(undefined2 *)(param_1 + 0x8e) = 0;
  FUN_016dee4c(param_1 + 0x8f,2);
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  param_1[0xa2] = 0;
  param_1[0xa3] = 0;
  *(undefined *)(param_1 + 0xa4) = 0;
  param_1[0xa5] = 0;
  uStack_8._0_1_ = 0x1c;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("SoundService",0xc);
  uStack_8._0_1_ = 0x1d;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uVar3 = FUN_01674e20(1);
  iVar2 = param_1[0xa5];
  param_1[0xa5] = uVar3;
  if (iVar2 != 0) {
    FUN_01674ea0(iVar2,1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27573 ; VA 0x00c1cbe0 ; FUN_00c1cbe0 */

void __fastcall FUN_00c1cbe0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  if (7 < (uint)param_1[0xb]) {
    iVar3 = param_1[6];
    iVar1 = param_1[0xb] * 2;
    uVar4 = iVar1 + 2;
    iVar2 = iVar3;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar3 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar3 - iVar2) - 4U) goto LAB_00c1cc6f;
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 7;
  *(undefined2 *)(param_1 + 6) = 0;
  uVar4 = param_1[5];
  if (0xf < uVar4) {
    iVar1 = *param_1;
    uVar5 = uVar4 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar5 = uVar4 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) {
LAB_00c1cc6f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 27574 ; VA 0x00c1cc80 ; FUN_00c1cc80 */

void __fastcall FUN_00c1cc80(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Soundscape::SoundService>::vftable;
  uVar1 = FUN_00c1b320(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27575 ; VA 0x00c1ccc0 ; FUN_00c1ccc0 */

void __fastcall FUN_00c1ccc0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00c1bf10(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 27576 ; VA 0x00c1ccf0 ; FUN_00c1ccf0 */

void __fastcall FUN_00c1ccf0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00c20df0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27577 ; VA 0x00c1cd40 ; FUN_00c1cd40 */

void __fastcall FUN_00c1cd40(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00c209e0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 27578 ; VA 0x00c1cdc0 ; FUN_00c1cdc0 */

void __fastcall FUN_00c1cdc0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00c209e0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 27579 ; VA 0x00c1cdd0 ; FUN_00c1cdd0 */

void __fastcall FUN_00c1cdd0(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00e39150();
  piVar2 = *(int **)(param_1 + 0x5c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016dedfb(param_1 + 0x28);
  uVar3 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x10);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27580 ; VA 0x00c1cea0 ; FUN_00c1cea0 */

int __fastcall FUN_00c1cea0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ef8f4b != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ef8f4b,"~NonBlockingFmodSoundLoader %p",param_1);
  }
  iVar4 = FUN_005e6280();
  uVar2 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x3c);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00c1cfe0;
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  piVar3 = *(int **)(param_1 + 0x38);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar2) {
    iVar4 = *(int *)(param_1 + 0x18);
    uVar6 = uVar2 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00c1cfe0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  piVar3 = *(int **)(param_1 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27581 ; VA 0x00c1cff0 ; FUN_00c1cff0 */

void __fastcall FUN_00c1cff0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Soundscape::SoundService::vftable;
  puStack_14 = param_1;
  if (param_1[0xa5] != 0) {
    FUN_01674ea0(param_1[0xa5],1);
  }
  piVar2 = (int *)param_1[0xa3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00641040();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x9e];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[0x9b];
  uStack_8 = 0xffffffff;
  if (iVar3 != 0) {
    uVar5 = (param_1[0x9d] - iVar3 >> 2) * 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00c1d388;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x9b] = 0;
    param_1[0x9c] = 0;
    param_1[0x9d] = 0;
  }
  FUN_016dedfb(param_1 + 0x8f);
  iVar3 = param_1[0x88];
  if (iVar3 != 0) {
    uVar5 = (param_1[0x8a] - iVar3 >> 2) * 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00c1d388;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x88] = 0;
    param_1[0x89] = 0;
    param_1[0x8a] = 0;
  }
  FUN_016dedfb(param_1 + 0x7c);
  FUN_00577ac0();
  FUN_00640d60();
  FUN_00577ac0();
  FUN_00c1cd40();
  FUN_008c3e10();
  uStack_8 = 1;
  FUN_00c20df0(&puStack_14,*(undefined4 *)param_1[0x62],(undefined4 *)param_1[0x62]);
  FUN_01674ea0(param_1[0x62],0x18);
  FUN_00ac8870();
  FUN_00ac8870();
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[0x53];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  piVar2 = (int *)param_1[0x52];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x50];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00577ac0();
  FUN_00577ac0();
  FUN_016dedfb(param_1 + 0x3c);
  piVar2 = (int *)param_1[0x3a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00651780();
  piVar2 = (int *)param_1[0x2f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_1[0x16];
  if (iVar3 != 0) {
    uVar5 = param_1[0x18] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00c1d388:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x16] = 0;
    param_1[0x17] = 0;
    param_1[0x18] = 0;
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27582 ; VA 0x00c1d390 ; FUN_00c1d390 */

void __fastcall FUN_00c1d390(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00c1d3b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 27583 ; VA 0x00c1d3c0 ; FUN_00c1d3c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_00c1d3c0(byte *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806a88;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar2,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uStack_8 = 0;
  FUN_00619db0();
  _DAT_0000000c = 0;
  _DAT_00000010 = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar5 = uVar3 + 1;
  _DAT_00000008 = uVar2;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005d6bb0(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    param_2 = (uint *)0x1;
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar5) {
      uVar7 = 1;
    }
    iVar6 = FUN_005d6bb0(uVar7 + *(int *)(param_1 + 8));
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar9;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar9;
          puVar9 = puVar4;
        }
        else {
          *puVar9 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar2 % *(uint *)(param_1 + 4)) * 4);
  _DAT_00000004 = uVar2;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *piVar1 = (int)piVar8;
    _DAT_00000000 = *piVar8;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (uint *)&DAT_00000008;
}



/* FUNCTION 27584 ; VA 0x00c1d560 ; FUN_00c1d560 */

int * __thiscall FUN_00c1d560(byte *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01806ab0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_18,iVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar4 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  *piStack_1c = 0;
  piVar4[3] = 0;
  piVar4[4] = 0;
  piVar4[5] = 0;
  piVar4[6] = 0;
  piVar4[7] = 0;
  piVar4[8] = 0;
  piVar4[9] = 0;
  piStack_24 = piVar4;
  FUN_0054ef60(aiStack_40);
  piVar1 = piVar4 + 8;
  if (piVar1 != (int *)0x0) {
    piVar1[0] = 0;
    piVar1[1] = 0;
  }
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar7 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar7) {
      uVar6 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar6 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar3 = (undefined4 *)*puVar8;
      while (piVar4 = piStack_24, puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar3[1] % *param_2) * 4) == 0) {
          *piVar1 = (int)puVar8;
          puVar8 = puVar3;
        }
        else {
          *puVar8 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        param_1 = pbStack_14;
        puVar3 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar4[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar4 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar4 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar1 = (int)piVar4;
    *piStack_24 = *piVar4;
  }
  else {
    *piStack_24 = *(int *)*piVar1;
    piVar4 = (int *)*piVar1;
  }
  *piVar4 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 27585 ; VA 0x00c1d7a0 ; FUN_00c1d7a0 */

int * __thiscall FUN_00c1d7a0(byte *param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01806ad0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_14,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar3 = (int *)FUN_01674e20(0x38);
  piStack_18 = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_20 = piVar3;
  FUN_0170d1f0(piStack_18,0,0x30);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  piVar3[0xc] = 0;
  piVar3[0xd] = 0xf;
  *(undefined *)(piVar3 + 8) = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar7 = uStack_28 + 1;
    iVar4 = aiStack_3c[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_3c[0] + -4);
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = 1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar5 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (puVar2 != (undefined4 *)0x0) {
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar6 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar8 = piVar6;
    *piVar3 = *piVar6;
  }
  else {
    *piVar3 = *piVar6;
    piVar6 = (int *)*puVar8;
  }
  *piVar6 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 27586 ; VA 0x00c1d9d0 ; FUN_00c1d9d0 */

int * __thiscall FUN_00c1d9d0(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01806af0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 27587 ; VA 0x00c1dc10 ; FUN_00c1dc10 */

int * __thiscall FUN_00c1dc10(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01806b10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005d6bb0(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005d6bb0(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 27588 ; VA 0x00c1de50 ; FUN_00c1de50 */

int * __thiscall FUN_00c1de50(byte *param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01806b30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_14,iVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  FUN_00c1fc60();
  piVar4 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar4[8] = 0;
  piVar4[9] = 0;
  piVar4[10] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = 1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar9;
      while (puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar9;
          puVar9 = puVar3;
        }
        else {
          *puVar9 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar4[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *piVar1 = (int)piVar7;
    *piVar4 = *piVar7;
  }
  else {
    *piVar4 = *piVar7;
    piVar7 = (int *)*piVar1;
  }
  *piVar7 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 27589 ; VA 0x00c1e060 ; FUN_00c1e060 */

void FUN_00c1e060(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806b40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0153dc80("sounds",DAT_01d682b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27590 ; VA 0x00c1e0ac ; Catch@00c1e0ac */

undefined4 Catch_00c1e0ac(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d84e8d != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
    FUN_01677650(DAT_01d84e8d,"Error while cleaning sound cache: %s",uVar1);
  }
  return 0xc1e09b;
}



/* FUNCTION 27591 ; VA 0x00c1e0e0 ; FUN_00c1e0e0 */

void __fastcall FUN_00c1e0e0(int param_1)

{
  uint uVar1;
  undefined8 uVar2;
  uint uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806b78;
  pvStack_10 = ExceptionList;
  uStack_58 = 0;
  uVar1 = *(uint *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_58 = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,&uStack_50,0);
    }
    else {
      uStack_50 = *(undefined4 *)(param_1 + 0x30);
      uStack_4c = *(undefined4 *)(param_1 + 0x34);
      uStack_48 = *(undefined4 *)(param_1 + 0x38);
      uStack_44 = *(undefined4 *)(param_1 + 0x3c);
      uStack_40 = *(undefined8 *)(param_1 + 0x40);
      ExceptionList = &pvStack_10;
    }
  }
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  uStack_78 = 0;
  if (uVar1 != 0) {
    uStack_78 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,&uStack_70,0);
    }
    else {
      uStack_70 = *(undefined4 *)(param_1 + 0x10);
      uStack_6c = *(undefined4 *)(param_1 + 0x14);
      uStack_68 = *(undefined4 *)(param_1 + 0x18);
      uStack_64 = *(undefined4 *)(param_1 + 0x1c);
      uStack_60 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  uStack_8 = 2;
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uVar1 = uStack_38;
  uStack_8._0_1_ = 3;
  if (uStack_58 == 0) {
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  uStack_38 = uStack_38 & 0xffffff00;
  uVar2 = CONCAT44(uStack_24,uStack_28);
  uStack_28 = 0;
  uStack_24 = 0xf;
  (**(code **)((uStack_58 & 0xfffffffe) + 4))(&uStack_50,uVar1,uStack_34,uStack_30,uStack_2c,uVar2);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_78 != 0) && ((uStack_78 & 1) == 0)) &&
     (*(code **)(uStack_78 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_78 & 0xfffffffe))(&uStack_70,&uStack_70,2);
  }
  uStack_8 = 6;
  if (((uStack_58 != 0) && ((uStack_58 & 1) == 0)) &&
     (*(code **)(uStack_58 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_58 & 0xfffffffe))(&uStack_50,&uStack_50,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27592 ; VA 0x00c1e270 ; FUN_00c1e270 */

void __thiscall FUN_00c1e270(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ef8f49 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ef8f49,"Releasing FMOD.",0,param_1);
  }
  if (DAT_01d683c8 != '\0') {
    FUN_00c27ea0(1);
  }
  iVar1 = FUN_016dee6d(&DAT_01ef90a0,&DAT_01ef90a0);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  uVar4 = 0;
  pcVar3 = "release";
  uStack_8 = 0;
  uVar2 = FUN_011aef40(param_2);
  FUN_00c1f3a0(uVar2,pcVar3,uVar4,param_2);
  uStack_8 = 1;
  iVar1 = FUN_016deec8(&DAT_01ef90a0);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27593 ; VA 0x00c1e330 ; FUN_00c1e330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c1e330(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ListenerType>::vftable;
  _DAT_01ef9b20 = _DAT_01ef9b20 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27594 ; VA 0x00c1e360 ; FUN_00c1e360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c1e360(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ReverbType>::vftable;
  _DAT_01ef9b18 = _DAT_01ef9b18 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27595 ; VA 0x00c1e390 ; FUN_00c1e390 */

undefined4 * __thiscall FUN_00c1e390(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Soundscape::ReverbType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 27596 ; VA 0x00c1e3c0 ; FUN_00c1e3c0 */

undefined4 __thiscall FUN_00c1e3c0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  return param_1;
}



/* FUNCTION 27597 ; VA 0x00c1e3f0 ; FUN_00c1e3f0 */

undefined4 __thiscall FUN_00c1e3f0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x6c);
  }
  return param_1;
}



/* FUNCTION 27598 ; VA 0x00c1e410 ; FUN_00c1e410 */

undefined4 __thiscall FUN_00c1e410(undefined4 param_1,byte param_2)

{
  FUN_0096ca80();
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 27599 ; VA 0x00c1e440 ; FUN_00c1e440 */

undefined4 * __thiscall FUN_00c1e440(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Soundscape::DetachedSoundPlayback::vftable;
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Soundscape::PlaybackChannelOwner::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 27600 ; VA 0x00c1e4a0 ; FUN_00c1e4a0 */

undefined4 * __thiscall FUN_00c1e4a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Soundscape::ReverbType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 27601 ; VA 0x00c1e4d0 ; FUN_00c1e4d0 */

undefined4 __thiscall FUN_00c1e4d0(undefined4 param_1,byte param_2)

{
  FUN_00c1cea0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 27602 ; VA 0x00c1e500 ; FUN_00c1e500 */

undefined4 __thiscall FUN_00c1e500(undefined4 param_1,byte param_2)

{
  FUN_00c1cff0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x298);
  }
  return param_1;
}



/* FUNCTION 27603 ; VA 0x00c1e530 ; FUN_00c1e530 */

int __thiscall FUN_00c1e530(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0xa8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x60);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  return param_1;
}



/* FUNCTION 27604 ; VA 0x00c1e5d0 ; FUN_00c1e5d0 */

char * FUN_00c1e5d0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return "No errors.";
  case 1:
    return 
    "Tried to call a function on a data type that does not allow this type of functionality (ie calling Sound::lock on a streaming sound)."
    ;
  case 2:
    return "Error trying to allocate a channel.";
  case 3:
    return "The specified channel has been reused to play another sound.";
  case 4:
    return "DMA Failure.  See debug output for more information.";
  case 5:
    return 
    "DSP connection error.  Connection possibly caused a cyclic dependency or connected dsps with incompatible buffer counts."
    ;
  case 6:
    return 
    "DSP return code from a DSP process query callback.  Tells mixer not to call the process callback and therefore not consume CPU.  Use this to optimize the DSP graph."
    ;
  case 7:
    return 
    "DSP Format error.  A DSP unit may have attempted to connect to this network with the wrong format, or a matrix may have been set with the wrong size if the target unit has a specified channel map."
    ;
  case 8:
    return 
    "DSP is already in the mixer\'s DSP network. It must be removed before being reinserted or released."
    ;
  case 9:
    return "DSP connection error.  Couldn\'t find the DSP unit specified.";
  case 10:
    return 
    "DSP operation error.  Cannot perform operation on this DSP as it is reserved by the system.";
  case 0xb:
    return 
    "DSP return code from a DSP process query callback.  Tells mixer silence would be produced from read, so go idle and not consume CPU.  Use this to optimize the DSP graph."
    ;
  case 0xc:
    return "DSP operation cannot be performed on a DSP of this type.";
  case 0xd:
    return "Error loading file.";
  case 0xe:
    return 
    "Couldn\'t perform seek operation.  This is a limitation of the medium (ie netstreams) or the file format."
    ;
  case 0xf:
    return "Media was ejected while reading.";
  case 0x10:
    return "End of file unexpectedly reached while trying to read essential data (truncated?).";
  case 0x11:
    return "End of current chunk reached while trying to read data.";
  case 0x12:
    return "File not found.";
  case 0x13:
    return "Unsupported file or audio format.";
  case 0x14:
    return 
    "There is a version mismatch between the FMOD header and either the FMOD Studio library or the FMOD Low Level library."
    ;
  case 0x15:
    return "A HTTP error occurred. This is a catch-all for HTTP errors not listed elsewhere.";
  case 0x16:
    return "The specified resource requires authentication or is forbidden.";
  case 0x17:
    return "Proxy authentication is required to access the specified resource.";
  case 0x18:
    return "A HTTP server error occurred.";
  case 0x19:
    return "The HTTP request timed out.";
  case 0x1a:
    return "FMOD was not initialized correctly to support this function.";
  case 0x1b:
    return "Cannot call this command after System::init.";
  case 0x1c:
    return "An error occurred that wasn\'t supposed to.  Contact support.";
  case 0x1d:
    return "Value passed in was a NaN, Inf or denormalized float.";
  case 0x1e:
    return "An invalid object handle was used.";
  case 0x1f:
    return "An invalid parameter was passed to this function.";
  case 0x20:
    return "An invalid seek position was passed to this function.";
  case 0x21:
    return "An invalid speaker was passed to this function based on the current speaker mode.";
  case 0x22:
    return "The syncpoint did not come from this sound handle.";
  case 0x23:
    return "Tried to call a function on a thread that is not supported.";
  case 0x24:
    return "The vectors passed in are not unit length, or perpendicular.";
  case 0x25:
    return "Reached maximum audible playback count for this sound\'s soundgroup.";
  case 0x26:
    return "Not enough memory or resources.";
  case 0x27:
    return 
    "Can\'t use FMOD_OPENMEMORY_POINT on non PCM source data, or non mp3/xma/adpcm data if FMOD_CREATECOMPRESSEDSAMPLE was used."
    ;
  case 0x28:
    return "Tried to call a command on a 2d sound when the command was meant for 3d sound.";
  case 0x29:
    return "Tried to use a feature that requires hardware support.";
  case 0x2a:
    return "Couldn\'t connect to the specified host.";
  case 0x2b:
    return 
    "A socket error occurred.  This is a catch-all for socket-related errors not listed elsewhere.";
  case 0x2c:
    return "The specified URL couldn\'t be resolved.";
  case 0x2d:
    return "Operation on a non-blocking socket could not complete immediately.";
  case 0x2e:
    return "Operation could not be performed because specified sound/DSP connection is not ready.";
  case 0x2f:
    return 
    "Error initializing output device, but more specifically, the output device is already in use and cannot be reused."
    ;
  case 0x30:
    return "Error creating hardware sound buffer.";
  case 0x31:
    return 
    "A call to a standard soundcard driver failed, which could possibly mean a bug in the driver or resources were missing or exhausted."
    ;
  case 0x32:
    return "Soundcard does not support the specified format.";
  case 0x33:
    return "Error initializing output device.";
  case 0x34:
    return 
    "The output device has no drivers installed.  If pre-init, FMOD_OUTPUT_NOSOUND is selected as the output mode.  If post-init, the function just fails."
    ;
  case 0x35:
    return "An unspecified error has been returned from a plugin.";
  case 0x36:
    return "A requested output, dsp unit type or codec was not available.";
  case 0x37:
    return 
    "A resource that the plugin requires cannot be found. (ie the DLS file for MIDI playback)";
  case 0x38:
    return "A plugin was built with an unsupported SDK version.";
  case 0x39:
    return "An error occurred trying to initialize the recording device.";
  case 0x3a:
    return 
    "Reverb properties cannot be set on this channel because a parent channelgroup owns the reverb connection."
    ;
  case 0x3b:
    return 
    "Specified instance in FMOD_REVERB_PROPERTIES couldn\'t be set. Most likely because it is an invalid instance number or the reverb doesn\'t exist."
    ;
  case 0x3c:
    return 
    "The error occurred because the sound referenced contains subsounds when it shouldn\'t have, or it doesn\'t contain subsounds when it should have.  The operation may also not be able to be performed on a parent sound."
    ;
  case 0x3d:
    return 
    "This subsound is already being used by another sound, you cannot have more than one parent to a sound.  Null out the other parent\'s entry first."
    ;
  case 0x3e:
    return 
    "Shared subsounds cannot be replaced or moved from their parent stream, such as when the parent stream is an FSB file."
    ;
  case 0x3f:
    return "The specified tag could not be found or there are no tags.";
  case 0x40:
    return 
    "The sound created exceeds the allowable input channel count.  This can be increased using the \'maxinputchannels\' parameter in System::setSoftwareFormat."
    ;
  case 0x41:
    return "The retrieved string is too long to fit in the supplied buffer and has been truncated.";
  case 0x42:
    return "Something in FMOD hasn\'t been implemented when it should be! contact support!";
  case 0x43:
    return "This command failed because System::init or System::setDriver was not called.";
  case 0x44:
    return 
    "A command issued was not supported by this object.  Possibly a plugin without certain callbacks specified."
    ;
  case 0x45:
    return "The version number of this file format is not supported.";
  case 0x46:
    return "The specified bank has already been loaded.";
  case 0x47:
    return "The live update connection failed due to the game already being connected.";
  case 0x48:
    return "The live update connection failed due to the game data being out of sync with the tool."
    ;
  case 0x49:
    return "The live update connection timed out.";
  case 0x4a:
    return "The requested event, parameter, bus or vca could not be found.";
  case 0x4b:
    return "The Studio::System object is not yet initialized.";
  case 0x4c:
    return "The specified resource is not loaded, so it can\'t be unloaded.";
  case 0x4d:
    return "An invalid string was passed to this function.";
  case 0x4e:
    return "The specified resource is already locked.";
  case 0x4f:
    return "The specified resource is not locked, so it can\'t be unlocked.";
  case 0x50:
    return "The specified recording driver has been disconnected.";
  case 0x51:
    return "The length provided exceeds the allowable limit.";
  default:
    return "Unknown error.";
  }
}



/* FUNCTION 27605 ; VA 0x00c1e980 ; FUN_00c1e980 */

void FUN_00c1e980(int param_1,undefined4 *param_2)

{
  bool bVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  uint in_stack_0000001c;
  undefined auStack_464 [1080];
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_1;
  puStack_c = &LAB_01806e10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) goto LAB_00c1ebb8;
  param_1 = 0;
  uStack_14 = 0;
  bVar2 = false;
  bVar1 = false;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_011aea70(iVar4,&param_1);
  if (iVar3 == 0) {
    if (DAT_01d684b0 != '\0') {
      if (param_1 < 1) goto LAB_00c1ebb8;
      goto LAB_00c1e9e7;
    }
LAB_00c1e9ef:
    bVar1 = bVar2;
    iVar3 = FUN_011ae6e0(iVar4,&uStack_14);
    if (iVar3 != 0) {
      bVar1 = true;
    }
  }
  else {
    bVar2 = true;
    bVar1 = true;
LAB_00c1e9e7:
    if ((DAT_01d684b0 == '\0') || (!bVar1)) goto LAB_00c1e9ef;
  }
  if ((DAT_01d684b0 == '\0') || (!bVar1)) {
    iVar4 = FUN_011ae7a0(iVar4,uStack_14,auStack_464,0x400,0,0,0,0);
    if (iVar4 == 0) {
      if (!bVar1) {
        puVar6 = &param_2;
        if (0xf < in_stack_0000001c) {
          puVar6 = param_2;
        }
        uVar5 = FUN_01675640(auStack_2c,"FMODReportDeviceInfo-%s-Success",puVar6);
        uStack_8._0_1_ = 2;
        FUN_008783f0(uVar5,1,0);
        uStack_8._0_1_ = 0;
        FUN_005507b0();
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 3;
        puVar6 = (undefined4 *)FUN_01675640(auStack_2c,&DAT_018bed68,param_1);
        uStack_8._0_1_ = 4;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_0151f850("numDrivers",puVar6);
        uStack_8._0_1_ = 3;
        FUN_005507b0();
        puVar6 = (undefined4 *)FUN_01675640(auStack_2c,&DAT_018bed68,uStack_14);
        uStack_8._0_1_ = 5;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_0151f850("driverIndex",puVar6);
        uStack_8._0_1_ = 3;
        FUN_005507b0();
        puVar6 = (undefined4 *)FUN_01675640(auStack_2c,&DAT_018bd25c,auStack_464);
        uStack_8._0_1_ = 6;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_0151f850("driverName",puVar6);
        uStack_8._0_1_ = 3;
        FUN_005507b0();
        uVar5 = DAT_01ef8f58;
        puVar6 = &param_2;
        if (0xf < in_stack_0000001c) {
          puVar6 = param_2;
        }
        uVar7 = FUN_01675640(auStack_2c,"FMODReportDeviceInfo-%s",puVar6);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        FUN_01520d20(uVar7,uVar5,0);
        FUN_005507b0();
        FUN_0151f7f0();
        goto LAB_00c1ebb8;
      }
    }
    else {
      auStack_464[0] = 0;
    }
  }
  puVar6 = &param_2;
  if (0xf < in_stack_0000001c) {
    puVar6 = param_2;
  }
  uVar5 = FUN_01675640(auStack_2c,"FMODReportDeviceInfo-%s-Error",puVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008783f0(uVar5,1,0);
  FUN_005507b0();
LAB_00c1ebb8:
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    puVar6 = param_2;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27606 ; VA 0x00c1ec00 ; FUN_00c1ec00 */

void __fastcall FUN_00c1ec00(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00c1cea0();
    FUN_01674ea0(iVar1,100);
  }
  return;
}



/* FUNCTION 27607 ; VA 0x00c1ec20 ; FUN_00c1ec20 */

void __fastcall FUN_00c1ec20(int param_1)

{
  FUN_016dedfb(param_1 + 0x38);
  return;
}



/* FUNCTION 27608 ; VA 0x00c1ec30 ; FUN_00c1ec30 */

void FUN_00c1ec30(void)

{
  FUN_00fe8cf0();
  return;
}



/* FUNCTION 27609 ; VA 0x00c1ec40 ; FUN_00c1ec40 */

void FUN_00c1ec40(void)

{
  FUN_0107fc90();
  return;
}



/* FUNCTION 27610 ; VA 0x00c1ec50 ; FUN_00c1ec50 */

void FUN_00c1ec50(void)

{
  FUN_0107f5d0();
  return;
}



/* FUNCTION 27611 ; VA 0x00c1ec60 ; FUN_00c1ec60 */

void FUN_00c1ec60(void)

{
  FUN_00c1cdd0();
  return;
}



/* FUNCTION 27612 ; VA 0x00c1ec70 ; FUN_00c1ec70 */

void __fastcall FUN_00c1ec70(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c1e270(*(undefined4 *)(param_1 + 0xc));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27613 ; VA 0x00c1eca0 ; thunk_FUN_00c28850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c28850(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807756;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9bfc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef9bfc);
    if (DAT_01ef9bfc == -1) {
      uStack_8 = 0;
      FUN_009ca470("ReverbType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef9b98 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ReverbType>::vftable;
      FUN_009caf20(&DAT_01d684d0,0x18);
      FUN_016f3654(&LAB_01893890);
      FUN_016f37bf(&DAT_01ef9bfc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef9b98;
}



/* FUNCTION 27614 ; VA 0x00c1ecb0 ; FUN_00c1ecb0 */

int __thiscall FUN_00c1ecb0(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1dfe4c8);
  if (iVar1 == 0) {
    return param_1 + 0xc;
  }
  return 0;
}



/* FUNCTION 27615 ; VA 0x00c1ece0 ; FUN_00c1ece0 */

void __fastcall FUN_00c1ece0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined8 *puVar6;
  undefined4 uVar7;
  float10 fVar8;
  undefined4 *puVar9;
  undefined auStack_68 [20];
  undefined4 uStack_54;
  double dStack_50;
  int *piStack_48;
  int *piStack_44;
  undefined8 uStack_40;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01806e52;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iStack_30 = param_1;
  uVar4 = FUN_01675290(DAT_01ef904c);
  uStack_14 = 0;
  uStack_34 = uVar4;
  if ((*(char *)(param_1 + 0x236) != '\0') && (*(char *)(param_1 + 0x237) != '\0')) {
    piVar5 = (int *)FUN_01674e20(0xb0);
    uStack_14 = CONCAT31(uStack_14._1_3_,2);
    piStack_24 = piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
      piStack_28 = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::_Ref_count_obj<class_RBX::Soundscape::FMODPlaybackChannel>::vftable;
      piStack_28 = piVar5;
      FUN_00fe8c00();
    }
    piStack_48 = piVar5 + 4;
    piStack_44 = piVar5;
    if ((piStack_48 != (int *)0x0) && ((piVar5[5] == 0 || (*(int *)(piVar5[5] + 4) == 0)))) {
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
      *piStack_48 = (int)piStack_48;
      piVar1 = (int *)piVar5[5];
      piVar5[5] = (int)piVar5;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    uStack_14._0_1_ = 3;
    fVar8 = (float10)FUN_00adf600();
    uStack_40 = (double)fVar8;
    FUN_00fe9d60(uStack_40);
    uStack_54 = 0;
    uStack_40 = 0.0;
    puVar6 = (undefined8 *)FUN_00adf5e0(auStack_68);
    dStack_50 = (double)*puVar6;
    uVar7 = *(undefined4 *)(puVar6 + 1);
    uVar3 = FUN_0085e810();
    piStack_24 = (int *)CONCAT31(piStack_24._1_3_,uVar3);
    FUN_00fe9780(piStack_24,dStack_50,uVar7,SUB84(uStack_40,0),SUB84(uStack_40,0),uStack_54);
    fVar8 = (float10)FUN_00adf7f0();
    dStack_50 = (double)fVar8;
    FUN_00fe9e70(dStack_50);
    fVar8 = (float10)FUN_00adf3d0();
    dStack_50 = (double)fVar8;
    FUN_00fe9c30(dStack_50);
    fVar8 = (float10)FUN_00adf3b0();
    dStack_50 = (double)fVar8;
    FUN_00fe9bc0(dStack_50);
    if (*(int *)(iStack_30 + 0x140) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(iStack_30 + 0x140) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_00fe9890(*(undefined4 *)(iStack_30 + 0x13c),*(undefined4 *)(iStack_30 + 0x140));
    piStack_24 = (int *)FUN_01674e20(0x1c);
    piVar5 = piStack_28;
    if (piStack_24 == (int *)0x0) {
      piStack_24 = (int *)0x0;
    }
    else {
      piStack_24[1] = 1;
      piStack_24[2] = 1;
      *piStack_24 = (int)std::_Ref_count_obj<class_RBX::Soundscape::DetachedSoundPlayback>::vftable;
      piStack_24[3] = (int)RBX::Soundscape::DetachedSoundPlayback::vftable;
      piStack_24[4] = 0;
      piStack_24[5] = 0;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
      }
      piStack_24[5] = (int)piStack_28;
      piStack_24[4] = (int)(piStack_28 + 4);
      *(undefined2 *)(piStack_24 + 6) = 0;
    }
    uStack_40 = (double)CONCAT44(piStack_24,piStack_24 + 3);
    uStack_14 = CONCAT31(uStack_14._1_3_,4);
    FUN_00fe9af0(0);
    FUN_00fe9c90(1,iStack_30);
    puVar9 = *(undefined4 **)(iStack_30 + 0x130);
    if (*(undefined4 **)(iStack_30 + 0x134) == puVar9) {
      FUN_005c1970(puVar9,&uStack_40);
      piStack_24 = uStack_40._4_4_;
    }
    else {
      *puVar9 = 0;
      puVar9[1] = 0;
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
      *puVar9 = (undefined4)uStack_40;
      puVar9[1] = piStack_24;
      *(int *)(iStack_30 + 0x130) = *(int *)(iStack_30 + 0x130) + 8;
      piVar5 = piStack_28;
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    uStack_2c = (undefined4)uStack_40;
    puVar9 = &uStack_2c;
    uStack_14 = CONCAT31(uStack_14._1_3_,5);
    piStack_28 = piStack_24;
    uVar7 = FUN_00adf5d0(puVar9);
    FUN_00c24fa0(uVar7,puVar9);
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[1] + -1;
      piStack_28[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar2 = piStack_28[2] + -1;
        piStack_28[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_24[2] + -1;
        piStack_24[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[1] + -1;
      piVar5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  uStack_14 = 6;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 27616 ; VA 0x00c1f0c0 ; FUN_00c1f0c0 */

void FUN_00c1f0c0(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d7930;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef9461);
  auStack_6c[0] = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_5 + 2;
      uStack_7c = 0xc1f137;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_5[2];
      uStack_60 = param_5[3];
      uStack_5c = param_5[4];
      uStack_58 = param_5[5];
      uStack_54 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2);
    }
    else {
      uStack_a8 = param_4[2];
      uStack_a4 = param_4[3];
      uStack_a0 = param_4[4];
      uStack_9c = param_4[5];
      uStack_98 = *(undefined8 *)(param_4 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xc1f219;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_90 = 0xc1f233;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27617 ; VA 0x00c1f250 ; FUN_00c1f250 */

void FUN_00c1f250(int param_1,char *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 ****ppppuVar3;
  char *pcVar4;
  uint uVar5;
  undefined4 ***apppuStack_40 [5];
  uint uStack_2c;
  undefined4 ***apppuStack_28 [3];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return;
  }
  ExceptionList = &pvStack_10;
  if (DAT_01ef8f4c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016773b0(DAT_01ef8f4c,"Result %d operation %s fmodParent %p fmodObject %p",param_1,param_2,
                 param_3,param_4,0);
  }
  uVar2 = FUN_00c1e5d0(param_1);
  FUN_01675640(apppuStack_40,"FMOD %d: %s during %s",param_1,uVar2,param_2);
  ppppuVar3 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar3 = (undefined4 ****)apppuStack_40[0];
  }
  iStack_8 = 0;
  FUN_0086edd0(2,ppppuVar3,6);
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
  iStack_8._0_1_ = 1;
  if (DAT_01ef8f48 != '\0') {
    ppppuVar3 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_01677520(DAT_01ef8f48,"FMOD object: %p, parent: %p, fmodOperation: %s, error: %s",param_4,
                 param_3,ppppuVar3,uVar2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  FUN_005500e0(apppuStack_40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 27618 ; VA 0x00c1f3a0 ; FUN_00c1f3a0 */

void FUN_00c1f3a0(int param_1,char *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 ***pppuVar4;
  char *pcVar5;
  undefined auStack_228 [512];
  undefined4 **appuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    if (DAT_01ef8f4c != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016773b0(DAT_01ef8f4c,"Result %d operation %s fmodParent %p fmodObject %p",param_1,param_2
                   ,param_3,param_4,0);
    }
    iVar2 = FUN_00912810();
    if ((*(char *)(iVar2 + 0x59) != '\0') || (DAT_01ef8f48 != '\0')) {
      uVar3 = FUN_00c1e5d0(param_1,0x200);
      FUN_0171dd10(auStack_228,uVar3);
      iVar2 = FUN_00912810();
      if (*(char *)(iVar2 + 0x59) != '\0') {
        FUN_0086f2f0(2,"FMOD %d: %s during %s",param_1,auStack_228,param_2);
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      appuStack_28[0] = (undefined4 **)((uint)appuStack_28[0] & 0xffffff00);
      pcVar5 = param_2;
      do {
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(param_2,(int)pcVar5 - (int)(param_2 + 1));
      uStack_8 = 0;
      if (DAT_01ef8f48 != '\0') {
        pppuVar4 = appuStack_28;
        if (0xf < uStack_14) {
          pppuVar4 = (undefined4 ***)appuStack_28[0];
        }
        FUN_01677520(DAT_01ef8f48,"FMOD object: %p, parent: %p, fmodOperation: %s, error: %s",
                     param_4,param_3,pppuVar4,auStack_228);
      }
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27619 ; VA 0x00c1f4d0 ; FUN_00c1f4d0 */

void __fastcall FUN_00c1f4d0(int param_1)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uStack_74;
  undefined auStack_70 [48];
  ushort uStack_40;
  undefined auStack_14 [8];
  int iStack_c;
  undefined uStack_5;
  
  iStack_c = param_1;
  FUN_0170d1f0(auStack_70,0,0x5c);
  uStack_74 = 0x60;
  FUN_011ae400(*(undefined4 *)(param_1 + 0x68),&uStack_74);
  uVar3 = 0x2430;
  uStack_40 = 0x2430;
  if (DAT_01ef945c != 0) {
    do {
      if ((*(uint *)(DAT_01ef9450 + (uVar3 - 0x2430 >> 5) * 4) &
          1 << ((byte)(uVar3 - 0x2430) & 0x1f)) == 0) break;
      uStack_40 = (short)uVar3 + 1;
      uVar3 = (uint)uStack_40;
    } while (uVar3 - 0x2430 < DAT_01ef945c);
  }
  uVar3 = uVar3 - 0x2430;
  if (uVar3 < DAT_01ef945c) {
    puVar2 = (uint *)(DAT_01ef9450 + (uVar3 >> 5) * 4);
    *puVar2 = *puVar2 | 1 << (uVar3 & 0x1f);
  }
  else {
    uStack_5 = 1;
    if (((int)DAT_01ef945c < 0) && (DAT_01ef945c != 0)) {
      iVar1 = -((~DAT_01ef945c >> 5) * 4 + 4);
    }
    else {
      iVar1 = (DAT_01ef945c >> 5) * 4;
    }
    FUN_00656a20(auStack_14,DAT_01ef9450 + iVar1,DAT_01ef945c & 0x1f,1,&uStack_5);
  }
  FUN_011af310(*(undefined4 *)(iStack_c + 0x68),&uStack_74);
  return;
}



/* FUNCTION 27620 ; VA 0x00c1f5d0 ; FUN_00c1f5d0 */

undefined4 * __thiscall FUN_00c1f5d0(uint param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined4 *puStack_14;
  undefined4 *puStack_10;
  int iStack_c;
  uint uStack_8;
  
  piVar6 = param_2;
  uStack_8 = param_1;
  if (*(char *)(*param_2 + 0x30) == '\0') {
    iVar8 = *param_2 + 0x18;
    iVar7 = param_1 + 0x171 + (uint)*(byte *)(param_1 + 0x170);
    uVar4 = FUN_009cc8a0(iVar8);
    puVar3 = (undefined4 *)FUN_00607080(&uStack_8,uVar4,iVar8,-(uint)(iVar7 != 0) & iVar7 + 1U);
    if ((uStack_8 != 0) && (*(int *)(param_1 + 0x178) != 0)) {
      iStack_c = *param_2 + 0x18;
      uStack_8 = FUN_009cc8a0(iStack_c);
      param_2 = (int *)(uStack_8 % *(uint *)(param_1 + 0x174));
      puVar3 = (undefined4 *)((int)param_2 * 4);
      piVar6 = *(int **)((int)puVar3 + *(int *)(param_1 + 0x184));
      if ((piVar6 != (int *)0x0) && (iVar7 = *piVar6, puStack_10 = puVar3, iVar7 != 0)) {
        while( true ) {
          uVar1 = *(uint *)(iVar7 + 4);
          puVar3 = (undefined4 *)(uVar1 / *(uint *)(param_1 + 0x174));
          if ((int *)(uVar1 % *(uint *)(param_1 + 0x174)) != param_2) break;
          if ((uVar1 == uStack_8) &&
             (puVar3 = (undefined4 *)FUN_009cbaa0(iStack_c,iVar7 + 8), (char)puVar3 != '\0')) {
            FUN_00ad3a40(piVar6,*(undefined4 *)*piVar6);
            if (*piVar6 != 0) {
              uVar1 = *(uint *)(*piVar6 + 4);
              uVar5 = uVar1 % *(uint *)(param_1 + 0x174);
              if (param_2 == (int *)uVar5) {
                return (undefined4 *)(uVar1 / *(uint *)(param_1 + 0x174));
              }
              *(int **)(*(int *)(param_1 + 0x184) + uVar5 * 4) = piVar6;
            }
            puStack_10 = (undefined4 *)(*(int *)(param_1 + 0x184) + (int)puStack_10);
            if ((int *)*puStack_10 != piVar6) {
              return puStack_10;
            }
            *puStack_10 = 0;
            return puStack_10;
          }
          piVar6 = (int *)*piVar6;
          iVar7 = *piVar6;
          if (iVar7 == 0) {
            return puVar3;
          }
        }
      }
    }
  }
  else {
    FUN_00c1b530(&puStack_14,param_2);
    puVar2 = puStack_10;
    iVar7 = 0;
    param_2 = puStack_14;
    puVar3 = puStack_14;
    if (puStack_14 != puStack_10) {
      do {
        iVar7 = iVar7 + 1;
        puVar3 = (undefined4 *)FUN_00551320();
      } while (param_2 != puVar2);
      if (iVar7 != 0) {
        FUN_00c1b530(&puStack_14,piVar6);
        param_2 = puStack_14;
        while (param_2 != puStack_10) {
          FUN_00551320();
        }
        puVar3 = (undefined4 *)FUN_00c20df0(&param_2,puStack_14,puStack_10);
        return puVar3;
      }
    }
  }
  return puVar3;
}



/* FUNCTION 27621 ; VA 0x00c1f770 ; FUN_00c1f770 */

void __fastcall FUN_00c1f770(int param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  puVar8 = (undefined4 *)(param_1 + 300);
  ExceptionList = &pvStack_10;
  FUN_005596d0(*puVar8,*(undefined4 *)(param_1 + 0x130),puVar8);
  *(undefined4 *)(param_1 + 0x130) = *puVar8;
  piVar2 = *(int **)(param_1 + 0x1c4);
  for (piVar7 = *(int **)(param_1 + 0x1c0); piVar7 != piVar2; piVar7 = piVar7 + 2) {
    FUN_00c20fa0(*piVar7 + 0x10);
    FUN_00e39150();
  }
  puVar8 = (undefined4 *)(param_1 + 0x1c0);
  if (*(int *)(param_1 + 0x160) != 0) {
    FUN_00ad3a40(*(int *)(param_1 + 0x16c) + *(int *)(param_1 + 0x15c) * 4,0);
    puVar5 = *(undefined4 **)(param_1 + 0x16c);
    puVar6 = puVar5 + *(int *)(param_1 + 0x15c);
    for (; puVar5 != puVar6; puVar5 = puVar5 + 1) {
      *puVar5 = 0;
    }
  }
  FUN_005596d0(*puVar8,*(undefined4 *)(param_1 + 0x1c4),puVar8);
  *(undefined4 *)(param_1 + 0x1c4) = *puVar8;
  if (*(int *)(param_1 + 0x178) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x184) + *(int *)(param_1 + 0x174) * 4);
  }
  for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
    if (DAT_01d68460 != '\0') {
      FUN_00c27790(puVar8 + 8);
    }
    if (*(int *)(puVar8[8] + 0x60) != 0) {
      FUN_011b02e0(*(int *)(puVar8[8] + 0x60));
    }
  }
  if (*(int *)(param_1 + 0x178) != 0) {
    FUN_00ad3a40(*(int *)(param_1 + 0x184) + *(int *)(param_1 + 0x174) * 4,0);
    puVar6 = *(undefined4 **)(param_1 + 0x184);
    puVar8 = puVar6 + *(int *)(param_1 + 0x174);
    for (; puVar6 != puVar8; puVar6 = puVar6 + 1) {
      *puVar6 = 0;
    }
  }
  puVar8 = *(undefined4 **)(param_1 + 0x188);
  puVar6 = (undefined4 *)*puVar8;
  while (puVar6 != puVar8) {
    if (DAT_01d68460 != '\0') {
      FUN_00c27790(puVar6 + 4);
    }
    iVar3 = *(int *)(puVar6[4] + 0x60);
    if (iVar3 != 0) {
      FUN_011b02e0(iVar3);
    }
    puVar5 = (undefined4 *)puVar6[2];
    if (*(char *)((int)puVar5 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar5 + 0xd);
      puVar6 = puVar5;
      puVar5 = (undefined4 *)*puVar5;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar5 + 0xd);
        puVar6 = puVar5;
        puVar5 = (undefined4 *)*puVar5;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar6[1] + 0xd);
      puVar4 = (undefined4 *)puVar6[1];
      puVar5 = puVar6;
      while ((puVar6 = puVar4, cVar1 == '\0' && (puVar5 == (undefined4 *)puVar6[2]))) {
        cVar1 = *(char *)((int)puVar6[1] + 0xd);
        puVar4 = (undefined4 *)puVar6[1];
        puVar5 = puVar6;
      }
    }
  }
  iVar3 = *(int *)(param_1 + 0x188);
  piVar2 = (int *)(param_1 + 0x188);
  uStack_8 = 0;
  FUN_00777e50(*(undefined4 *)(iVar3 + 4));
  *(int *)(*piVar2 + 4) = iVar3;
  *(int *)*piVar2 = iVar3;
  *(int *)(*piVar2 + 8) = iVar3;
  *(undefined4 *)(param_1 + 0x18c) = 0;
  if (*(int *)(param_1 + 0x1b0) != 0) {
    FUN_00c209e0(*(int *)(param_1 + 0x1bc) + *(int *)(param_1 + 0x1ac) * 4,0);
    puVar6 = *(undefined4 **)(param_1 + 0x1bc);
    puVar8 = puVar6 + *(int *)(param_1 + 0x1ac);
    for (; puVar6 != puVar8; puVar6 = puVar6 + 1) {
      *puVar6 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27622 ; VA 0x00c1f9d0 ; FUN_00c1f9d0 */

void __fastcall FUN_00c1f9d0(int param_1)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 uStack_84;
  undefined auStack_80 [48];
  ushort uStack_50;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806e70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (DAT_01ef8f4b != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ef8f4b,"SoundService::closeFmod(%p)",param_1);
  }
  if (DAT_01ef8f49 != '\0') {
    FUN_016774b0(DAT_01ef8f49,"Closing Fmod.",0);
  }
  *(undefined *)(param_1 + 0x235) = 0;
  *(undefined *)(param_1 + 100) = 1;
  FUN_00650440(param_1 + 0x58);
  uVar8 = 0;
  uStack_8 = 0;
  uVar6 = (uint)((int)puStack_20 + (3 - (int)puStack_24)) >> 2;
  if (puStack_20 < puStack_24) {
    uVar6 = 0;
  }
  puVar7 = puStack_24;
  if (uVar6 != 0) {
    do {
      (**(code **)(*(int *)*puVar7 + 0x10))();
      uVar8 = uVar8 + 1;
      puVar7 = puVar7 + 1;
      param_1 = iStack_18;
    } while (uVar8 != uVar6);
  }
  *(undefined *)(param_1 + 100) = 0;
  FUN_01679490();
  FUN_00c275c0();
  FUN_00c1f770();
  *(undefined4 *)(param_1 + 0x13c) = 0;
  piVar3 = *(int **)(param_1 + 0x140);
  *(undefined4 *)(param_1 + 0x140) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x138) = 0;
  if (*(int *)(param_1 + 0x68) != 0) {
    if ((DAT_01d80f04 != '\0') && (DAT_01d684a8 != '\0')) {
      FUN_0153c530(param_1,FUN_00c267c0);
    }
    if ((DAT_01d68430 == '\0') && (iVar4 = FUN_00912810(), *(char *)(iVar4 + 0x5a) != '\0')) {
      FUN_0170d1f0(auStack_80,0,0x5c);
      uStack_84 = 0x60;
      FUN_011ae400(*(undefined4 *)(param_1 + 0x68),&uStack_84);
      puVar2 = (uint *)(DAT_01ef9450 + (uStack_50 - 0x2430 >> 5) * 4);
      *puVar2 = *puVar2 & ~(1 << ((byte)(uStack_50 - 0x2430) & 0x1f));
    }
    *(undefined4 *)(param_1 + 0x68) = 0;
    piVar3 = *(int **)(param_1 + 0x6c);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  iVar4 = param_1 + 0x1f0;
  *(undefined *)(param_1 + 0x236) = 0;
  iStack_18 = iVar4;
  iVar5 = FUN_016dee6d(iVar4);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_8._0_1_ = 1;
  if (*(int *)(param_1 + 0x220) != *(int *)(param_1 + 0x224)) {
    *(int *)(param_1 + 0x224) = *(int *)(param_1 + 0x220);
  }
  if (DAT_01ef8f49 != '\0') {
    FUN_016774b0(DAT_01ef8f49,"Fmod Closed.",0);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = FUN_016deec8(iVar4);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  if (puStack_24 != (undefined4 *)0x0) {
    uVar6 = iStack_1c - (int)puStack_24 & 0xfffffffc;
    puVar7 = puStack_24;
    if (0xfff < uVar6) {
      puVar7 = (undefined4 *)puStack_24[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)puStack_24 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar7,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27623 ; VA 0x00c1fc60 ; FUN_00c1fc60 */

void __fastcall FUN_00c1fc60(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x2c);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00c1bf10(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 27624 ; VA 0x00c1fcc0 ; FUN_00c1fcc0 */

undefined4 FUN_00c1fcc0(ulonglong *param_1,float *param_2)

{
  float fVar1;
  char cVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined8 uStack_10;
  float fStack_8;
  
  uStack_10 = *param_1;
  fStack_8 = *(float *)(param_1 + 1);
  cVar2 = FUN_00c942f0((float)uStack_10);
  if (cVar2 != '\0') {
    uStack_10 = uStack_10 & 0xffffffff00000000;
  }
  cVar2 = FUN_00c942f0(uStack_10._4_4_);
  if (cVar2 != '\0') {
    uStack_10 = uStack_10 & 0xffffffff;
  }
  cVar2 = FUN_00c942f0(fStack_8);
  if (cVar2 != '\0') {
    fStack_8 = 0.0;
  }
  cVar2 = FUN_00c943f0(&uStack_10);
  fVar5 = DAT_01955580;
  if (cVar2 != '\0') {
    return 0;
  }
  fVar1 = DAT_01966074;
  if (DAT_01966074 <= (float)uStack_10) {
    fVar1 = (float)uStack_10;
  }
  fVar3 = DAT_01955580;
  if (fVar1 <= DAT_01955580) {
    fVar3 = fVar1;
  }
  fVar1 = DAT_01966074;
  if (DAT_01966074 <= uStack_10._4_4_) {
    fVar1 = uStack_10._4_4_;
  }
  fVar4 = DAT_01966074;
  if (DAT_01966074 <= fStack_8) {
    fVar4 = fStack_8;
  }
  *param_2 = fVar3;
  fVar3 = fVar5;
  if (fVar1 <= fVar5) {
    fVar3 = fVar1;
  }
  if (fVar4 <= fVar5) {
    fVar5 = fVar4;
  }
  param_2[1] = fVar3;
  param_2[2] = fVar5;
  return 1;
}



/* FUNCTION 27625 ; VA 0x00c1fda0 ; FUN_00c1fda0 */

void FUN_00c1fda0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c287a0();
    *param_2 = uVar3;
    iVar4 = FUN_00c28900();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 27626 ; VA 0x00c1fe00 ; FUN_00c1fe00 */

void FUN_00c1fe00(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c28850();
    *param_2 = uVar3;
    iVar4 = FUN_00c28970();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 27627 ; VA 0x00c1fe60 ; FUN_00c1fe60 */

void FUN_00c1fe60(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c287a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27628 ; VA 0x00c1fea0 ; FUN_00c1fea0 */

void FUN_00c1fea0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c28850();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27629 ; VA 0x00c1fee0 ; FUN_00c1fee0 */

undefined4 * FUN_00c1fee0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006740c0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 27630 ; VA 0x00c1ff50 ; FUN_00c1ff50 */

int * FUN_00c1ff50(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806ec2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c1bd70(param_1,&param_2);
  iVar2 = *param_1;
  uStack_8 = 0;
  uStack_14 = 1;
  iVar7 = *(int *)((int)param_2 + 0x28c);
  if (iVar7 != 0) {
    LOCK();
    *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
    UNLOCK();
    iVar7 = *(int *)((int)param_2 + 0x28c);
  }
  *(undefined4 *)(iVar2 + 0xa4) = *(undefined4 *)((int)param_2 + 0x288);
  piVar3 = *(int **)(iVar2 + 0xa8);
  *(int *)(iVar2 + 0xa8) = iVar7;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feef0(auStack_28,&DAT_01963654,*param_1 + 0x90);
  uStack_8 = 1;
  FUN_009feef0(auStack_20,&DAT_01963658,*param_1 + 0x94);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feef0(auStack_20,"Stream",*param_1 + 0x98);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feef0(auStack_20,"Geometry",*param_1 + 0x9c);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feef0(auStack_20,"Update",*param_1 + 0xa0);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  iStack_18 = *param_1;
  param_2 = (int *)(iStack_18 + 0x8c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar6 = (undefined4 *)FUN_00670d90(auStack_38,&param_2);
  piVar3 = piStack_34;
  uStack_14 = 3;
  param_2 = (int *)*puVar6;
  piStack_2c = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piStack_30 = param_2;
  piStack_1c = piStack_2c;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  pcVar4 = *(code **)(*param_2 + 0x38);
  FUN_005542c0("ChannelsPlaying",0xf);
  uStack_8._0_1_ = 3;
  (*pcVar4)(auStack_50);
  uStack_8._0_1_ = 2;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_3c) {
    uVar9 = uStack_3c + 1;
    uVar8 = auStack_50[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_50[0] - 4);
      uVar9 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_008a65e0(iStack_18,0);
  piVar3 = piStack_1c;
  uStack_14 = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feda0(auStack_38,"Current",*param_1 + 0x7c);
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_009feda0(auStack_38,&DAT_018f7780,*param_1 + 0x80);
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_38,"# Sounds",*param_1 + 0x84);
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_006756e0(auStack_38,"# Unused",*param_1 + 0x88);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar3 = piStack_24 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27631 ; VA 0x00c20370 ; FUN_00c20370 */

int * __thiscall FUN_00c20370(int param_1,int *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  uint uVar3;
  char *pcVar4;
  int iVar5;
  uint in_stack_0000001c;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [8];
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806ef0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d68380 != '\0') {
    iVar5 = 0;
    iStack_1c = 0;
    pcVar4 = "success";
    iStack_24 = 0;
    iStack_20 = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    if (*(int *)(param_1 + 0x68) == 0) {
      pcVar4 = "null_system";
      ExceptionList = &pvStack_10;
    }
    else {
      puVar2 = &param_3;
      if (0xf < in_stack_0000001c) {
        puVar2 = param_3;
      }
      ExceptionList = &pvStack_10;
      iStack_1c = FUN_011ae100(*(int *)(param_1 + 0x68),puVar2,&iStack_14);
      if (iStack_1c == 0) {
        if (*(int *)(param_1 + 0x138) != 0) {
          FUN_011b1880(*(int *)(param_1 + 0x138),iStack_14,1,0);
        }
        uVar1 = FUN_00c1c240(auStack_2c,&iStack_14);
        FUN_005587e0(uVar1);
        FUN_00550b30();
        iVar5 = iStack_24;
        if ((iStack_24 != 0) && (DAT_01d68388 == '\0')) goto LAB_00c204b2;
      }
      else {
        pcVar4 = "fmod_error";
      }
    }
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8._0_1_ = 2;
    FUN_0151f850("Which",pcVar4);
    FUN_0151f9c0("Result",iStack_1c);
    uVar1 = DAT_01ef8f50;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = 0;
    FUN_005542c0("CreateChannelGroup",0x12);
    uStack_8._0_1_ = 3;
    FUN_01520d20(auStack_44,uVar1,0);
    FUN_005507b0();
    FUN_0151f7f0();
LAB_00c204b2:
    *param_2 = iVar5;
    param_2[1] = iStack_20;
    if (in_stack_0000001c < 0x10) {
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar3 = in_stack_0000001c + 1;
    puVar2 = param_3;
    if (0xfff < uVar3) {
      puVar2 = (undefined4 *)param_3[-1];
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x68) != 0) {
    puVar2 = &param_3;
    if (0xf < in_stack_0000001c) {
      puVar2 = param_3;
    }
    ExceptionList = &pvStack_10;
    iVar5 = FUN_011ae100(*(int *)(param_1 + 0x68),puVar2,&iStack_1c);
    if (iVar5 == 0) {
      if (*(int *)(param_1 + 0x138) != 0) {
        FUN_011b1880(*(int *)(param_1 + 0x138),iStack_1c,1,0);
      }
      FUN_00c1c240(&iStack_18,&iStack_1c);
      iVar5 = iStack_18;
      iStack_18 = 0;
      *param_2 = iVar5;
      param_2[1] = iStack_14;
      iStack_14 = 0;
      FUN_00550b30();
      goto LAB_00c20588;
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
LAB_00c20588:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27632 ; VA 0x00c205b0 ; FUN_00c205b0 */

void __thiscall FUN_00c205b0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  char *pcVar6;
  undefined4 uVar7;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806f17;
  pvStack_10 = ExceptionList;
  if ((param_3 != 0) && (*(int *)(param_1 + 0x68) != 0)) {
    uVar7 = 0;
    pcVar6 = "createDSPByType";
    param_3 = 0;
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    uVar4 = FUN_011ae1f0(*(int *)(param_1 + 0x68),iVar3,&param_3);
    FUN_00c1f3a0(uVar4,pcVar6,uVar7,param_1);
    piVar5 = (int *)FUN_01674e20(0x20);
    uStack_8 = 0;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::_Ref_count_obj<class_RBX::Soundscape::FMODPlaybackDSP>::vftable;
      piStack_18 = piVar5;
      FUN_0107f5a0(param_3);
    }
    piVar1 = piVar5 + 3;
    piStack_1c = piVar1;
    piStack_18 = piVar5;
    if ((piVar1 != (int *)0x0) && ((piVar5[4] == 0 || (*(int *)(piVar5[4] + 4) == 0)))) {
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
      *piVar1 = (int)piVar1;
      piVar2 = (int *)piVar5[4];
      piVar5[4] = (int)piVar5;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar2 = piVar5 + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    uStack_8 = 1;
    piVar2 = *(int **)(iStack_14 + 0x1e8);
    if (*(int **)(iStack_14 + 0x1ec) == piVar2) {
      FUN_005c1970(piVar2,&piStack_1c);
    }
    else {
      *piVar2 = 0;
      piVar2[1] = 0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      *piVar2 = (int)piVar1;
      piVar2[1] = (int)piVar5;
      *(int *)(iStack_14 + 0x1e8) = *(int *)(iStack_14 + 0x1e8) + 8;
      piStack_18 = piVar5;
      piStack_1c = piVar1;
    }
    *param_2 = (int)piStack_1c;
    param_2[1] = (int)piStack_18;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return;
}



/* FUNCTION 27633 ; VA 0x00c20730 ; FUN_00c20730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c20730(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_1bc = FUN_00c287a0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_00c28900();
    puStack_18 = &uStack_1bc;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_00c287a0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088cbe0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8)
       && (FUN_016f3809(&DAT_01ead3c8), DAT_01ead3c8 == -1)) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
    puStack_e8 = &DAT_01ead3bc;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27634 ; VA 0x00c209e0 ; FUN_00c209e0 */

int __thiscall FUN_00c209e0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00c1bf10(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x2c);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 27635 ; VA 0x00c20a40 ; FUN_00c20a40 */

void FUN_00c20a40(uint param_1,undefined *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0x18);
  FUN_0090c170();
  if (param_2 == &DAT_0213ba40) {
    iVar2 = FUN_0090c170();
    param_2 = *(undefined **)(iVar2 + 0xe4);
    iVar2 = *(int *)(iVar1 + 0x138);
    if (iVar2 != 0) {
      param_1 = param_1 & 0xffffff;
      FUN_011b08a0(iVar2,(int)&param_1 + 3);
      if (param_1._3_1_ == '\0') {
        FUN_011b1200(*(undefined4 *)(iVar1 + 0x138),param_2);
      }
    }
  }
  return;
}



/* FUNCTION 27636 ; VA 0x00c20ab0 ; FUN_00c20ab0 */

int FUN_00c20ab0(undefined4 param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806f40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if ((((iStack_18 != 0) && (param_3 != '\0')) && (*(int *)(iStack_18 + 0xe4) != 0)) &&
     ((*(int *)(iStack_18 + 0x288) != 0 && (DAT_01d68480 != '\0')))) {
    iVar3 = *(int *)(iStack_18 + 0x288) + 0x2c;
    iVar2 = FUN_016dee6d(iVar3);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    uStack_8._0_1_ = 1;
    FUN_0151f9c0("stats/snd/playing",*(undefined4 *)(*(int *)(iStack_18 + 0x288) + 0x14));
    FUN_0151fa60("stats/snd/numSounds",*(undefined4 *)(*(int *)(iStack_18 + 0x288) + 0xc));
    FUN_0151fa60("stats/snd/numUnusedSounds",*(undefined4 *)(*(int *)(iStack_18 + 0x288) + 0x10));
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar2 = FUN_016deec8(iVar3);
    if (iVar2 != 0) {
      iVar2 = FUN_016df3c9(iVar2);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 27637 ; VA 0x00c20be0 ; FUN_00c20be0 */

undefined __fastcall FUN_00c20be0(int param_1)

{
  if ((*(char *)(param_1 + 0x236) != '\0') && (*(char *)(param_1 + 0x237) != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 27638 ; VA 0x00c20c00 ; FUN_00c20c00 */

void __thiscall
FUN_00c20c00(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_80;
  undefined4 uStack_60;
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  uint auStack_38 [2];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01806fa1;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  auStack_58[0] = 0;
  ExceptionList = &pvStack_10;
  uStack_60 = param_1;
  if (param_2 != 0) {
    auStack_58[0] = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_50,0);
    }
    else {
      uStack_50 = param_4;
      uStack_4c = param_5;
      uStack_48 = param_6;
      uStack_44 = param_7;
      uStack_40 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  auStack_38[0] = 0;
  if (param_9 != 0) {
    auStack_38[0] = param_9;
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_30,0);
    }
    else {
      uStack_30 = param_11;
      uStack_2c = param_12;
      uStack_28 = param_13;
      uStack_24 = param_14;
      uStack_20 = param_15;
    }
  }
  auStack_a8[0] = uStack_60;
  uStack_8._0_1_ = 3;
  uStack_a0 = 0;
  FUN_005880d0(auStack_58);
  uStack_8._0_1_ = 4;
  uStack_80 = 0;
  FUN_005880d0(auStack_38);
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined4 *)FUN_00c1c170(auStack_a8);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0096ca80();
  cVar3 = FUN_0168a8f0();
  if (cVar3 == '\0') {
    uVar4 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar4);
  }
  uStack_8._0_1_ = 9;
  FUN_016899e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_016899e0();
  puVar2 = puStack_14;
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    iVar1 = puStack_14[1] + -1;
    puStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*puStack_14)(0);
      uVar4 = GetProcessHeap(0,puVar2);
      HeapFree(uVar4);
    }
  }
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 0xc;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27639 ; VA 0x00c20df0 ; FUN_00c20df0 */

void __thiscall FUN_00c20df0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar3 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00777e50(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar3, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar4 = FUN_00553830(param_3);
    piVar1 = *(int **)(iVar4 + 0x14);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar4,0x18);
    ppvVar3 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27640 ; VA 0x00c20ee0 ; FUN_00c20ee0 */

undefined4 __thiscall FUN_00c20ee0(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar6 = *param_2;
  uVar5 = uVar6 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar5 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    for (piVar2 = (int *)*piVar1;
        (piVar2 != (int *)0x0 && ((uint)piVar2[1] % *(uint *)(param_1 + 4) == uVar5));
        piVar2 = (int *)*piVar2) {
      if ((piVar2[1] == uVar6) && (uVar6 == piVar2[2])) {
        uVar3 = FUN_007c62b0(piVar1,*piVar2);
        if (*piVar1 != 0) {
          uVar6 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
          if (uVar5 == uVar6) {
            return uVar3;
          }
          *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4) = piVar1;
        }
        puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
        if ((int *)*puVar4 == piVar1) {
          *puVar4 = 0;
        }
        return uVar3;
      }
      piVar1 = piVar2;
    }
  }
  return 0;
}



/* FUNCTION 27641 ; VA 0x00c20fa0 ; FUN_00c20fa0 */

undefined4 __thiscall FUN_00c20fa0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar4 = FUN_009cc8a0(param_2);
  uVar7 = uVar4 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar7 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    iVar2 = *piVar1;
    while( true ) {
      if ((iVar2 == 0) || (*(uint *)(iVar2 + 4) % *(uint *)(param_1 + 4) != uVar7)) {
        return 0;
      }
      if ((*(uint *)(iVar2 + 4) == uVar4) &&
         (cVar3 = FUN_009cbaa0(param_2,iVar2 + 8), cVar3 != '\0')) break;
      piVar1 = (int *)*piVar1;
      iVar2 = *piVar1;
    }
    uVar5 = FUN_00ad3a40(piVar1,*(undefined4 *)*piVar1);
    if (*piVar1 != 0) {
      uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar7 == uVar4) {
        return uVar5;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
    }
    puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if ((int *)*puVar6 == piVar1) {
      *puVar6 = 0;
    }
    return uVar5;
  }
  return 0;
}



/* FUNCTION 27642 ; VA 0x00c21070 ; FUN_00c21070 */

undefined4 __thiscall FUN_00c21070(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar4 = FUN_009cc8a0(param_2);
  uVar7 = uVar4 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar7 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    iVar2 = *piVar1;
    while( true ) {
      if ((iVar2 == 0) || (*(uint *)(iVar2 + 4) % *(uint *)(param_1 + 4) != uVar7)) {
        return 0;
      }
      if ((*(uint *)(iVar2 + 4) == uVar4) &&
         (cVar3 = FUN_009cbaa0(param_2,iVar2 + 8), cVar3 != '\0')) break;
      piVar1 = (int *)*piVar1;
      iVar2 = *piVar1;
    }
    uVar5 = FUN_00c209e0(piVar1,*(undefined4 *)*piVar1);
    if (*piVar1 != 0) {
      uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar7 == uVar4) {
        return uVar5;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
    }
    puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if ((int *)*puVar6 == piVar1) {
      *puVar6 = 0;
    }
    return uVar5;
  }
  return 0;
}



/* FUNCTION 27643 ; VA 0x00c21140 ; FUN_00c21140 */

void __thiscall FUN_00c21140(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00c1f0c0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27644 ; VA 0x00c211e0 ; FUN_00c211e0 */

undefined4 FUN_00c211e0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed9c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_01256300(param_2);
  iVar5 = iVar5 - param_3;
  puStack_18 = (undefined4 *)FUN_009d0b50(auStack_20,uVar3,param_3,2,iVar5,iStack_14 + 0x44);
  uStack_8 = 0;
  if (0 < iVar5) {
    uVar6 = FUN_00c287a0();
    cVar4 = FUN_009d1e20(uVar6,uVar3,param_3 + 1,&param_2);
    uVar6 = param_2;
    if (cVar4 != '\0') goto LAB_00c21270;
  }
  uVar6 = FUN_00c1c3a0(uVar3,param_3,1,iVar5,iStack_14 + 0x40);
LAB_00c21270:
  pcVar2 = *(code **)(iStack_14 + 0x38);
  param_3 = *(int *)(iStack_14 + 0x3c) + param_1;
  if (puStack_18[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_18[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(uVar6,*puStack_18,puStack_18[1]);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27645 ; VA 0x00c212f0 ; FUN_00c212f0 */

undefined4 FUN_00c212f0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01806fc7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf2ac)
       && (FUN_016f3809(&DAT_01edf2ac), DAT_01edf2ac == -1)) {
      uStack_8 = 0;
      FUN_00e359d0();
      FUN_016f3654(&LAB_01880c70);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf2ac);
    }
    cVar2 = FUN_009d1e20(&DAT_01edf248,param_2,iVar1 + 1,&param_3);
    iVar5 = param_3;
    if (cVar2 != '\0') goto LAB_00c21414;
  }
  if (0 < iVar3) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_f0,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00e35840();
      iVar5 = *piVar4;
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00c21414;
    }
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(auStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  iVar5 = **(int **)(iStack_14 + 0x40);
LAB_00c21414:
  (**(code **)(iStack_14 + 0x38))(iVar5);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27646 ; VA 0x00c214b0 ; FUN_00c214b0 */

void __thiscall FUN_00c214b0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d05b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 27647 ; VA 0x00c21500 ; FUN_00c21500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00c21500(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  undefined auStack_98 [96];
  undefined4 uStack_38;
  int iStack_34;
  uint uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807013;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ef904c);
  uStack_8 = 0;
  uStack_38 = uVar2;
  if (param_1 == 0) {
    if (DAT_01ef8f4b != '\0') {
      FUN_016774b0(DAT_01ef8f4b,"NBFSL::fmodCallback received null sound",0);
    }
  }
  else {
    iStack_18 = 0;
    if ((param_2 == 0) &&
       ((iVar3 = FUN_011adea0(param_1,&iStack_18,0,0,0), iVar3 != 0 || (iStack_18 != 0)))) {
      if (DAT_01ef8f4b != '\0') {
        FUN_01677490(DAT_01ef8f4b,
                     "NBFSL::fmodCallback bad open state sound=%p openState=%d, openStateResult=%d",
                     param_1,iStack_18,iVar3);
      }
    }
    else {
      iVar3 = FUN_011adf00(param_1,&uStack_24);
      if (iVar3 == 0) {
        iStack_2c = 0;
        piStack_28 = (int *)0x0;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        piStack_1c = (int *)&DAT_01ef9058;
        iVar3 = FUN_016dee6d(&DAT_01ef9058);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        FUN_00606ea0(&piStack_14,uStack_24,&uStack_24,
                     -(uint)(DAT_01ef9088 != 0xfe106f77) & DAT_01ef9088 + 0x1ef908a);
        if (piStack_14 == (int *)0x0) {
          if (DAT_01ef8f4b != '\0') {
            FUN_016774b0(DAT_01ef8f4b,"NBFSL::fmodCallback loader already used, returning. sound=%p"
                         ,param_1);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          iVar3 = FUN_016deec8(&DAT_01ef9058);
          if (iVar3 != 0) {
            FUN_016df3c9(iVar3);
          }
        }
        else {
          FUN_0056ecd0(piStack_14 + 3);
          piStack_1c = (int *)*piStack_14;
          uVar4 = (uint)piStack_14[1] % DAT_01ef908c;
          piVar1 = *(int **)(DAT_01ef909c + uVar4 * 4);
          for (piVar6 = (int *)*piVar1; uStack_30 = uVar4, piVar6 != piStack_14;
              piVar6 = (int *)*piVar6) {
            piVar1 = piVar6;
          }
          do {
            piStack_14 = piVar1;
            *piStack_14 = *piVar6;
            piVar1 = (int *)piVar6[4];
            if (piVar1 != (int *)0x0) {
              LOCK();
              iVar3 = piVar1[1] + -1;
              piVar1[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piVar1)();
                LOCK();
                iVar3 = piVar1[2] + -1;
                piVar1[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar1 + 4))();
                }
              }
            }
            FUN_01674ea0(piVar6,0x14);
            _DAT_01ef9090 = _DAT_01ef9090 + -1;
            uVar5 = uVar4;
            if (*piStack_14 == 0) {
LAB_00c21734:
              if (*(int **)(DAT_01ef909c + uVar4 * 4) == piStack_14) {
                *(undefined4 *)(DAT_01ef909c + uVar4 * 4) = 0;
              }
            }
            else {
              uVar5 = *(uint *)(*piStack_14 + 4) % DAT_01ef908c;
              if (uVar4 != uVar5) {
                *(int **)(DAT_01ef909c + uVar5 * 4) = piStack_14;
                goto LAB_00c21734;
              }
            }
            piVar6 = (int *)*piStack_14;
            uVar4 = uVar5;
            piVar1 = piStack_14;
          } while (piVar6 != piStack_1c);
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          iVar3 = FUN_016deec8(&DAT_01ef9058);
          uVar2 = uStack_38;
          if (iVar3 != 0) {
            FUN_016df3c9(iVar3);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          if (DAT_01d684b8 != '\0') {
            piStack_14 = (int *)0x0;
            param_2 = FUN_011ade80(param_1,0,0,&piStack_14,0);
            if ((param_2 == 0) && (DAT_01d6834c < (int)piStack_14)) {
              param_2 = 0x40;
            }
          }
          iVar3 = iStack_2c;
          if (DAT_01ef8f4b != '\0') {
            FUN_016773b0(DAT_01ef8f4b,
                         "NBFSL::fmodCallback returning to dm sound=%p result=%d openState=%d loader=%p"
                         ,param_1,param_2,iStack_18,iStack_2c,0);
          }
          FUN_00587490(&iStack_20);
          piVar1 = piStack_28;
          uStack_8._0_1_ = 9;
          if (iStack_20 != 0) {
            if (DAT_01d68468 != '\0') {
              FUN_00587490(&iStack_34);
              uStack_8._0_1_ = 10;
              if (((iStack_34 != 0) && (FUN_00c27790(&iStack_2c), DAT_01d684b8 != '\0')) &&
                 (param_2 == 0x40)) {
                FUN_00c1c610(iVar3 + 0x18,param_1);
                uStack_8._0_1_ = 0xb;
                FUN_00c279c0(auStack_98);
                FUN_00c1cdd0();
              }
              uStack_8._0_1_ = 9;
              FUN_00550b30();
            }
            if (piVar1 != (int *)0x0) {
              LOCK();
              piVar1[1] = piVar1[1] + 1;
              UNLOCK();
            }
            FUN_00c1ac10(iVar3,piVar1,param_2,0);
            FUN_0090ca30();
          }
          FUN_00550b30();
          if (piVar1 != (int *)0x0) {
            LOCK();
            iVar3 = piVar1[1] + -1;
            piVar1[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piVar1)();
              LOCK();
              piVar6 = piVar1 + 2;
              iVar3 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar3 == 1) {
                (**(code **)(*piVar1 + 4))();
              }
            }
          }
        }
      }
      else if (DAT_01ef8f4b != '\0') {
        FUN_01677490(DAT_01ef8f4b,
                     "NBFSL::fmodCallback Unable to get loader sound=%p getUserDataResult=%d",
                     param_1,iVar3,0);
      }
    }
  }
  uStack_8 = 0xc;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27648 ; VA 0x00c21900 ; FUN_00c21900 */

undefined4 FUN_00c21900(void)

{
  undefined4 in_stack_00000014;
  
  if (DAT_01ef8f4b != '\0') {
    FUN_01677650(DAT_01ef8f4b,"FMOD: %s",in_stack_00000014);
  }
  return 0;
}



/* FUNCTION 27649 ; VA 0x00c21930 ; FUN_00c21930 */

void FUN_00c21930(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  double *pdVar8;
  int *piVar9;
  float10 fVar10;
  undefined auStack_80 [24];
  int aiStack_68 [5];
  uint uStack_54;
  undefined4 ***pppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **ppuStack_48;
  undefined4 **ppuStack_44;
  undefined8 uStack_40;
  undefined8 uStack_38;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  double *pdStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180706f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_01675290(DAT_01ef904c);
  uStack_8 = 0;
  if (*param_1 != 0) {
    FUN_00c1f5d0(param_1);
    if (param_2 == 0) {
      iVar4 = *param_1;
      pdStack_18 = (double *)(iVar4 + 0x18);
      piVar3 = (int *)FUN_01674e20(0x6c);
      piStack_20 = piVar3;
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        piStack_28 = piVar3 + 3;
        piVar3[1] = 1;
        piVar3[2] = 1;
        *piVar3 = (int)std::_Ref_count_obj<class_RBX::Soundscape::FMODSound>::vftable;
        iVar4 = *(int *)(iVar4 + 0x60);
        *piStack_28 = 0;
        piVar3[4] = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        piVar3[5] = iVar4;
        piVar3[6] = 0;
        FUN_0054ef60(pdStack_18);
        FUN_016dee4c(piVar3 + 0xd,2);
        piVar3[0x19] = 0;
        piVar3[0x1a] = 0;
      }
      piStack_30 = piVar3 + 3;
      piStack_2c = piVar3;
      if ((piStack_30 != (int *)0x0) && ((piVar3[4] == 0 || (*(int *)(piVar3[4] + 4) == 0)))) {
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[1] = piVar3[1] + 1;
          UNLOCK();
          if (piVar3 != (int *)0x0) {
            LOCK();
            piVar3[2] = piVar3[2] + 1;
            UNLOCK();
          }
        }
        *piStack_30 = (int)piStack_30;
        piVar9 = (int *)piVar3[4];
        piVar3[4] = (int)piVar3;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar4 = piVar9[2] + -1;
          piVar9[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
      }
      piVar3 = piStack_30 + 10;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_28 = piVar3;
      iVar4 = FUN_016dee6d(piVar3);
      if (iVar4 != 0) {
        FUN_016df3c9(iVar4);
      }
      uStack_8._0_1_ = 5;
      fVar10 = (float10)FUN_0107ff70(piStack_30[2]);
      uStack_38 = (double)fVar10;
      FUN_0054ef60(piStack_30 + 4);
      iVar4 = iStack_14;
      uStack_8._0_1_ = 6;
      iVar5 = FUN_00c1d560(aiStack_68);
      uStack_8._0_1_ = 5;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 5;
      *(double *)(iVar5 + 0x18) = uStack_38;
      if (0xf < uStack_54) {
        uVar7 = uStack_54 + 1;
        iVar5 = aiStack_68[0];
        if (0xfff < uVar7) {
          iVar5 = *(int *)(aiStack_68[0] + -4);
          uVar7 = uStack_54 + 0x24;
          if (0x1f < (aiStack_68[0] - iVar5) - 4U) {
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar7);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      iVar5 = FUN_016deec8(piVar3);
      if (iVar5 != 0) {
        FUN_016df3c9(iVar5);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if ((*(char *)(iVar4 + 0x236) != '\0') && (*(char *)(iVar4 + 0x237) != '\0')) {
        puVar1 = *(undefined4 **)(iVar4 + 0x1c4);
        if (*(undefined4 **)(iVar4 + 0x1c8) == puVar1) {
          FUN_005c1970(puVar1,&piStack_30);
        }
        else {
          *puVar1 = 0;
          puVar1[1] = 0;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
          }
          *puVar1 = piStack_30;
          puVar1[1] = piStack_2c;
          *(int *)(iVar4 + 0x1c4) = *(int *)(iVar4 + 0x1c4) + 8;
        }
        if (*(char *)(*param_1 + 0x30) == '\0') {
          iVar4 = FUN_00c1dc10(*param_1 + 0x18);
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
          }
          *(int **)(iVar4 + 0x18) = piStack_30;
          piVar3 = *(int **)(iVar4 + 0x1c);
          *(int **)(iVar4 + 0x1c) = piStack_2c;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
      }
      pdVar8 = *(double **)(*param_1 + 0x54);
      pdStack_18 = *(double **)(*param_1 + 0x58);
      if (pdVar8 != pdStack_18) {
        do {
          iVar4 = *(int *)((int)pdVar8 + 4);
          piStack_24 = (int *)0x0;
          piStack_20 = (int *)0x0;
          if (iVar4 != 0) {
            piVar3 = (int *)(iVar4 + 4);
            iVar4 = *(int *)(iVar4 + 4);
            while (iVar4 != 0) {
              LOCK();
              iVar5 = *piVar3;
              if (iVar4 == iVar5) {
                *piVar3 = iVar4 + 1;
                iVar5 = iVar4;
              }
              UNLOCK();
              if (iVar5 == iVar4) {
                piStack_24 = *(int **)pdVar8;
                piStack_20 = *(int **)((int)pdVar8 + 4);
                break;
              }
              iVar4 = *piVar3;
            }
          }
          piVar3 = piStack_20;
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          if (piStack_24 != (int *)0x0) {
            (**(code **)(*piStack_24 + 4))(iStack_14,*param_1 + 0x18,&piStack_30);
          }
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          pdVar8 = pdVar8 + 1;
        } while (pdVar8 != pdStack_18);
      }
      piVar3 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar9 = piVar3 + 2;
          iVar4 = *piVar9;
          *piVar9 = *piVar9 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else {
      uStack_40 = 0xf00000000;
      pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      if (param_2 == 0x12) {
        FUN_005542c0("file not found",0xe);
      }
      else if (param_2 == 0x13) {
        FUN_005542c0("unsupported file format",0x17);
      }
      else {
        ppppuVar6 = (undefined4 ****)FUN_01675640(auStack_80,"error code %d",param_2);
        if (&pppuStack_50 != ppppuVar6) {
          FUN_005507b0();
          pppuStack_50 = *ppppuVar6;
          ppuStack_4c = ppppuVar6[1];
          ppuStack_48 = ppppuVar6[2];
          ppuStack_44 = ppppuVar6[3];
          uStack_40 = *(undefined8 *)(ppppuVar6 + 4);
          ppppuVar6[4] = (undefined4 ***)0x0;
          ppppuVar6[5] = (undefined4 ***)0xf;
          *(undefined *)ppppuVar6 = 0;
        }
        FUN_005507b0();
      }
      pdVar8 = *(double **)(*param_1 + 0x54);
      pdStack_18 = *(double **)(*param_1 + 0x58);
      if (pdVar8 != pdStack_18) {
        do {
          iVar4 = *(int *)((int)pdVar8 + 4);
          uStack_38 = 0.0;
          piVar3 = (int *)0x0;
          piVar9 = (int *)0x0;
          if (iVar4 != 0) {
            piVar3 = (int *)(iVar4 + 4);
            iVar4 = *(int *)(iVar4 + 4);
            while (iVar4 != 0) {
              LOCK();
              iVar5 = *piVar3;
              if (iVar4 == iVar5) {
                *piVar3 = iVar4 + 1;
                iVar5 = iVar4;
              }
              UNLOCK();
              if (iVar5 == iVar4) {
                piVar3 = *(int **)pdVar8;
                piVar9 = *(int **)((int)pdVar8 + 4);
                uStack_38 = *pdVar8;
                goto LAB_00c21dcd;
              }
              iVar4 = *piVar3;
            }
            uStack_38._0_4_ = (int *)0x0;
            uStack_38._4_4_ = (int *)0x0;
            piVar3 = (int *)uStack_38;
            piVar9 = uStack_38._4_4_;
          }
LAB_00c21dcd:
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          if (piVar3 != (int *)0x0) {
            ppppuVar6 = &pppuStack_50;
            if (0xf < uStack_40._4_4_) {
              ppppuVar6 = (undefined4 ****)pppuStack_50;
            }
            (**(code **)(*piVar3 + 8))(*param_1 + 0x18,ppppuVar6);
          }
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar4 = piVar9[1] + -1;
            piVar9[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar4 = piVar9[2] + -1;
              piVar9[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          pdVar8 = pdVar8 + 1;
        } while (pdVar8 != pdStack_18);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_40._4_4_) {
        uVar7 = uStack_40._4_4_ + 1;
        ppppuVar6 = (undefined4 ****)pppuStack_50;
        if (0xfff < uVar7) {
          ppppuVar6 = (undefined4 ****)pppuStack_50[-1];
          uVar7 = uStack_40._4_4_ + 0x24;
          if (0x1f < (uint)((int)pppuStack_50 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar6,uVar7);
      }
      uStack_40 = 0xf00000000;
      pppuStack_50 = (undefined4 ***)((uint)pppuStack_50 & 0xffffff00);
    }
  }
  uStack_8 = 0xb;
  FUN_01675290(uStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27650 ; VA 0x00c21ec0 ; FUN_00c21ec0 */

void FUN_00c21ec0(undefined4 param_1)

{
  FUN_01674ea0(param_1);
  return;
}



/* FUNCTION 27651 ; VA 0x00c21ee0 ; FUN_00c21ee0 */

undefined4 FUN_00c21ee0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ef9050);
  uStack_8 = 0;
  uVar2 = FUN_01674f30(param_1);
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 27652 ; VA 0x00c21f40 ; FUN_00c21f40 */

undefined4 FUN_00c21f40(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ef9050);
  uStack_8 = 0;
  uVar2 = FUN_01675190(param_1,param_2);
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 27653 ; VA 0x00c21fb0 ; FUN_00c21fb0 */

undefined4 FUN_00c21fb0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar1 = param_1;
  if (param_1 != 0) {
    iStack_8 = 0;
    param_1 = FUN_011b0060(param_1,&iStack_8);
    iVar2 = param_2;
    if (param_1 == 0) {
      if (iStack_8 == param_2) {
        return 1;
      }
      if (DAT_01d68470 != '\0') {
        FUN_011afd30(iVar1,&param_1);
        iVar4 = 0;
        if (0 < param_1) {
          do {
            uStack_c = 0;
            FUN_011aff40(iVar1,iVar4,&uStack_c);
            cVar3 = FUN_00c21fb0(uStack_c,iVar2);
            if (cVar3 != '\0') {
              return 1;
            }
            iVar4 = iVar4 + 1;
          } while (iVar4 < param_1);
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 27654 ; VA 0x00c22040 ; FUN_00c22040 */

undefined4 FUN_00c22040(undefined4 param_1,uint param_2,int *param_3,int param_4,int param_5)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined *puVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  char *pcVar9;
  undefined auStack_210 [256];
  undefined auStack_110 [256];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar8 = param_5;
  piVar3 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807088;
  pvStack_10 = ExceptionList;
  if (param_2 < 0x81) {
    if (param_2 == 0x80) {
      iVar8 = *param_3;
      if (iVar8 == 0x1e) {
        return 0;
      }
      if ((DAT_01d68478 != '\0') && (iVar8 == 3)) {
        return 0;
      }
      if (DAT_01ef8f4b == '\0') {
        return 0;
      }
      puVar4 = &DAT_018d743c;
      if ((undefined *)param_3[3] != (undefined *)0x0) {
        puVar4 = (undefined *)param_3[3];
      }
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01ef8f4b,"FMOD API error, FMOD_RESULT:%d, functionname:%s",iVar8,puVar4);
      ExceptionList = pvStack_10;
      return 0;
    }
    switch(param_2) {
    case 1:
      ExceptionList = &pvStack_10;
      if (DAT_01ef8f4b != '\0') {
        ExceptionList = &pvStack_10;
        FUN_01677520(DAT_01ef8f4b,"FMOD DEVICELISTCHANGED");
      }
      if (DAT_01d683c0 == '\0') {
        ExceptionList = pvStack_10;
        return 0;
      }
      FUN_011adfc0(param_1,0);
      ExceptionList = pvStack_10;
      return 0;
    case 2:
      if (DAT_01ef8f4b == '\0') {
        return 0;
      }
      pcVar9 = "FMOD DEVICELOST";
      break;
    default:
switchD_00c22089_caseD_3:
      if (DAT_01ef8f4b == '\0') {
        return 0;
      }
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01ef8f4b,"FMOD unknown callback type:%d",param_2);
      ExceptionList = pvStack_10;
      return 0;
    case 4:
      if (DAT_01ef8f4b == '\0') {
        return 0;
      }
      pcVar9 = "FMOD MEMORYALLOCATIONFAILED";
      break;
    case 8:
      if (DAT_01ef8f4b == '\0') {
        return 0;
      }
      pcVar9 = "FMOD THREADCREATED";
      break;
    case 0x10:
      ExceptionList = &pvStack_10;
      if (param_3 != (int *)0x0) {
        ExceptionList = &pvStack_10;
        FUN_011b1e90(param_3,auStack_210,0,0,0,0);
      }
      iVar8 = param_4;
      if (param_4 != 0) {
        FUN_011b1e90(param_4,auStack_110,0,0,0,0);
      }
      if (DAT_01ef8f4b == '\0') {
        ExceptionList = pvStack_10;
        return 0;
      }
      puVar4 = auStack_110;
      if (iVar8 == 0) {
        puVar4 = &DAT_018ccd30;
      }
      puVar5 = auStack_210;
      if (piVar3 == (int *)0x0) {
        puVar5 = &DAT_018ccd30;
      }
      FUN_01677520(DAT_01ef8f4b,"FMOD BADDSPCONNECTION, src:%s dst:%s",puVar5,puVar4);
      ExceptionList = pvStack_10;
      return 0;
    case 0x20:
    case 0x40:
      goto switchD_00c22089_caseD_20;
    }
  }
  else if (param_2 < 0x801) {
    if (param_2 == 0x800) {
      return 0;
    }
    if (param_2 == 0x100) {
      return 0;
    }
    if (param_2 != 0x200) {
      if (param_2 == 0x400) {
        return 0;
      }
      goto switchD_00c22089_caseD_3;
    }
    if (DAT_01ef8f4b == '\0') {
      return 0;
    }
    pcVar9 = "FMOD THREADDESTROYED";
  }
  else {
    if (param_2 != 0x1000) {
      if (param_2 != 0x10000000) goto switchD_00c22089_caseD_3;
      if (param_5 == 0) {
        return 0;
      }
      iVar1 = param_5 + 0x1f0;
      ExceptionList = &pvStack_10;
      iVar6 = FUN_016dee6d(iVar1);
      if (iVar6 != 0) {
        FUN_016df3c9(iVar6);
      }
      uStack_8 = 0;
      if (DAT_01d68450 != '\0') {
        puVar2 = *(undefined4 **)(iVar8 + 0x224);
        puVar7 = *(undefined4 **)(iVar8 + 0x220);
        if (puVar7 != puVar2) {
          do {
            if ((int *)*puVar7 == piVar3) break;
            puVar7 = puVar7 + 1;
          } while (puVar7 != puVar2);
          if (puVar7 != puVar2) {
            uStack_8 = 1;
            goto LAB_00c222e8;
          }
        }
      }
      puVar2 = *(undefined4 **)(iVar8 + 0x224);
      if (*(undefined4 **)(iVar8 + 0x228) == puVar2) {
        FUN_006030d0(puVar2,&param_3);
      }
      else {
        *puVar2 = piVar3;
        *(int *)(iVar8 + 0x224) = *(int *)(iVar8 + 0x224) + 4;
      }
      uStack_8 = 2;
LAB_00c222e8:
      iVar8 = FUN_016deec8(iVar1);
      if (iVar8 == 0) {
        ExceptionList = pvStack_10;
        return 0;
      }
      FUN_016df3c9(iVar8);
      ExceptionList = pvStack_10;
      return 0;
    }
    if (DAT_01ef8f4b == '\0') {
      return 0;
    }
    pcVar9 = "FMOD RECORDLISTCHANGED";
  }
  ExceptionList = &pvStack_10;
  FUN_01677520(DAT_01ef8f4b,pcVar9);
switchD_00c22089_caseD_20:
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 27655 ; VA 0x00c22390 ; FUN_00c22390 */

int * FUN_00c22390(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                  undefined4 param_6,int *param_7,undefined4 *param_8,int *param_9,
                  undefined4 param_10,int *param_11)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 auStack_ac [13];
  code *pcStack_78;
  int iStack_68;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018070d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ef904c);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(100);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    piStack_14 = puVar3;
    FUN_0170d1f0(puVar3,0,100);
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[10] = 0;
    puVar3[0xb] = 0xf;
    *(undefined *)(puVar3 + 6) = 0;
    puVar3[0xd] = 0;
    puVar3[0xe] = 0;
    puVar3[0x13] = 0;
    puVar3[0x14] = 0xf;
    *(undefined *)(puVar3 + 0xf) = 0;
    puVar3[0x15] = 0;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
  }
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_00c1b5b0(puVar3,param_8);
  iVar6 = iStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iStack_18 + 0x10) = param_2;
  piVar5 = *(int **)(iStack_18 + 0x14);
  *(int **)(iStack_18 + 0x14) = param_3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[2] + -1;
    piVar5[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar6 + 8) = param_6;
  piVar5 = *(int **)(iVar6 + 0xc);
  *(int **)(iVar6 + 0xc) = param_7;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[2] + -1;
    piVar5[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  if ((undefined4 *)(iVar6 + 0x18) != param_8) {
    puVar3 = param_8;
    if (0xf < (uint)param_8[5]) {
      puVar3 = (undefined4 *)*param_8;
    }
    FUN_005542c0(puVar3,param_8[4]);
  }
  *(undefined *)(iVar6 + 0x30) = 1;
  if ((undefined4 *)(iVar6 + 0x3c) != param_9) {
    puVar3 = param_9;
    if (0xf < (uint)param_9[5]) {
      puVar3 = (undefined4 *)*param_9;
    }
    FUN_005542c0(puVar3,param_9[4]);
  }
  puVar3 = *(undefined4 **)(iVar6 + 0x58);
  if (*(undefined4 **)(iVar6 + 0x5c) == puVar3) {
    FUN_00c1b440(puVar3,&param_10);
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    if (param_11 != (int *)0x0) {
      LOCK();
      param_11[2] = param_11[2] + 1;
      UNLOCK();
    }
    *puVar3 = param_10;
    puVar3[1] = param_11;
    *(int *)(iVar6 + 0x58) = *(int *)(iVar6 + 0x58) + 8;
  }
  *(undefined4 *)(iVar6 + 0x60) = 0;
  param_9 = (int *)&DAT_01ef9058;
  iVar4 = FUN_016dee6d(&DAT_01ef9058);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  param_8 = (undefined4 *)DAT_01ef9464;
  DAT_01ef9464 = DAT_01ef9464 + 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar4 = FUN_00c1d3c0(&param_8);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
  }
  *(int *)(iVar4 + 4) = iVar6;
  param_9 = *(int **)(iVar4 + 8);
  *(int **)(iVar4 + 8) = piStack_14;
  if (param_9 != (int *)0x0) {
    LOCK();
    iVar4 = param_9[1] + -1;
    param_9[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_9)();
      LOCK();
      iVar4 = param_9[2] + -1;
      param_9[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_9 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar4 = FUN_016deec8(&DAT_01ef9058);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0170d1f0(auStack_ac,0,0x90);
  iStack_68 = (int)param_8;
  piVar5 = (int *)(iVar6 + 0x3c);
  auStack_ac[0] = 0x90;
  pcStack_78 = FUN_00c21500;
  if (0xf < *(uint *)(iVar6 + 0x50)) {
    piVar5 = (int *)*piVar5;
  }
  param_9 = (int *)FUN_011ae2e0(param_4,piVar5,0x8014090,auStack_ac,iVar6 + 0x60);
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"NonBlockingFmodSoundLoader created fromDiskData sound=%p loader=%p",
                 *(undefined4 *)(iVar6 + 0x60),iVar6,0);
  }
  if (param_9 == (int *)0x0) {
    *param_1 = iVar6;
    param_1[1] = (int)piStack_14;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
  }
  else {
    iVar6 = FUN_016dee6d(&DAT_01ef9058);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
    FUN_00c20ee0(&param_8);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    iVar6 = FUN_016deec8(&DAT_01ef9058);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
    piVar5 = piStack_14;
    *param_1 = 0;
    param_1[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
  }
  FUN_01675290(uVar2);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar6 = param_3[2] + -1;
    param_3[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar6 = param_5[1] + -1;
    param_5[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar6 = param_5[2] + -1;
      param_5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar6 = param_7[2] + -1;
    param_7[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_11 != (int *)0x0) {
    LOCK();
    piVar5 = param_11 + 2;
    iVar6 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*param_11 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27656 ; VA 0x00c227a0 ; FUN_00c227a0 */

int * FUN_00c227a0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                  undefined4 param_6,int *param_7,undefined4 *param_8,undefined4 param_9,
                  int *param_10,undefined4 *param_11)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  code *pcStack_78;
  int iStack_68;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807128;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01ef904c);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(100);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    piStack_14 = puVar4;
    FUN_0170d1f0(puVar4,0,100);
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puVar4[5] = 0;
    puVar4[10] = 0;
    puVar4[0xb] = 0xf;
    *(undefined *)(puVar4 + 6) = 0;
    puVar4[0xd] = 0;
    puVar4[0xe] = 0;
    puVar4[0x13] = 0;
    puVar4[0x14] = 0xf;
    *(undefined *)(puVar4 + 0xf) = 0;
    puVar4[0x15] = 0;
    puVar4[0x16] = 0;
    puVar4[0x17] = 0;
  }
  iStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_00c1b5b0(puVar4,param_11);
  iVar7 = iStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iStack_18 + 0x10) = param_2;
  piVar6 = *(int **)(iStack_18 + 0x14);
  *(int **)(iStack_18 + 0x14) = param_3;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[2] + -1;
    piVar6[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar6 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[2] = param_7[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar7 + 8) = param_6;
  piVar6 = *(int **)(iVar7 + 0xc);
  *(int **)(iVar7 + 0xc) = param_7;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[2] + -1;
    piVar6[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar6 + 4))();
    }
  }
  if ((undefined4 *)(iVar7 + 0x18) != param_8) {
    puVar4 = param_8 + 4;
    if (0xf < (uint)param_8[5]) {
      param_8 = (undefined4 *)*param_8;
    }
    FUN_005542c0(param_8,*puVar4);
  }
  *(undefined *)(iVar7 + 0x30) = 0;
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar7 + 0x34) = param_9;
  piVar6 = *(int **)(iVar7 + 0x38);
  *(int **)(iVar7 + 0x38) = param_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar5 = piVar6[2] + -1;
      piVar6[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  puVar4 = (undefined4 *)(iVar7 + 0x54);
  *(undefined4 *)(iVar7 + 0x60) = 0;
  if (puVar4 != param_11) {
    uVar2 = *puVar4;
    *puVar4 = *param_11;
    *param_11 = uVar2;
    uVar2 = *(undefined4 *)(iVar7 + 0x58);
    *(undefined4 *)(iVar7 + 0x58) = param_11[1];
    param_11[1] = uVar2;
    uVar2 = *(undefined4 *)(iVar7 + 0x5c);
    *(undefined4 *)(iVar7 + 0x5c) = param_11[2];
    param_11[2] = uVar2;
  }
  iVar5 = FUN_016dee6d(&DAT_01ef9058);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  param_11 = (undefined4 *)DAT_01ef9464;
  DAT_01ef9464 = DAT_01ef9464 + 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_00c1d3c0(&param_11);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
  }
  *(int *)(iVar5 + 4) = iVar7;
  piVar6 = *(int **)(iVar5 + 8);
  *(int **)(iVar5 + 8) = piStack_14;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar5 = piVar6[2] + -1;
      piVar6[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_016deec8(&DAT_01ef9058);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0170d1f0(&uStack_ac,0,0x90);
  uStack_ac = 0x90;
  pcStack_78 = FUN_00c21500;
  iStack_68 = (int)param_11;
  uStack_a8 = *(undefined4 *)(*(int *)(iVar7 + 0x34) + 0x10);
  piVar6 = *(int **)(iVar7 + 0x34);
  if (0xf < (uint)piVar6[5]) {
    piVar6 = (int *)*piVar6;
  }
  iVar5 = FUN_011ae2e0(param_4,piVar6,0x8014910,&uStack_ac,iVar7 + 0x60);
  if (DAT_01ef8f4b != '\0') {
    FUN_01677490(DAT_01ef8f4b,"NonBlockingFmodSoundLoader created fromMemoryData sound=%p loader=%p"
                 ,*(undefined4 *)(iVar7 + 0x60),iVar7,0);
  }
  if (iVar5 == 0) {
    *param_1 = iVar7;
    param_1[1] = (int)piStack_14;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
  }
  else {
    iVar7 = FUN_016dee6d(&DAT_01ef9058);
    if (iVar7 != 0) {
      FUN_016df3c9(iVar7);
    }
    FUN_00c20ee0(&param_11);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    iVar7 = FUN_016deec8(&DAT_01ef9058);
    if (iVar7 != 0) {
      FUN_016df3c9(iVar7);
    }
    piVar6 = piStack_14;
    *param_1 = 0;
    param_1[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_14[1] + -1;
      piStack_14[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar7 = *piVar1 + -1;
        *piVar1 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
  }
  FUN_01675290(uVar3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar7 = param_3[2] + -1;
    param_3[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar7 = param_5[1] + -1;
    param_5[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar7 = param_5[2] + -1;
      param_5[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar7 = param_7[2] + -1;
    param_7[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*param_7 + 4))();
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar7 = param_10[1] + -1;
    param_10[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar6 = param_10 + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27657 ; VA 0x00c22be0 ; FUN_00c22be0 */

uint __fastcall FUN_00c22be0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint uVar7;
  uint *puVar8;
  
  puVar6 = *(uint **)(param_1 + 0x1c0);
  uVar4 = *(int *)(param_1 + 0x1c4) - (int)puVar6 >> 3;
  uVar7 = 0;
  if (uVar4 != 0) {
    do {
      if (*(int *)(puVar6[uVar7 * 2] + 0xc) < 1) {
        FUN_00c20fa0(puVar6[uVar7 * 2] + 0x10);
        FUN_00e39150();
      }
      uVar7 = uVar7 + 1;
      puVar6 = *(uint **)(param_1 + 0x1c0);
      uVar4 = *(int *)(param_1 + 0x1c4) - (int)puVar6 >> 3;
    } while (uVar7 < uVar4);
  }
  puVar8 = *(uint **)(param_1 + 0x1c4);
  if (puVar6 != puVar8) {
    do {
      uVar4 = *puVar6;
      if (*(int *)(uVar4 + 0xc) < 1) break;
      puVar6 = puVar6 + 2;
    } while (puVar6 != puVar8);
    puVar5 = puVar6;
    if (puVar6 != puVar8) {
      while (puVar5 = puVar5 + 2, puVar5 != puVar8) {
        uVar7 = *puVar5;
        if (0 < *(int *)(uVar7 + 0xc)) {
          uVar4 = puVar5[1];
          *puVar5 = 0;
          puVar5[1] = 0;
          *puVar6 = uVar7;
          piVar2 = (int *)puVar6[1];
          puVar6[1] = uVar4;
          if (piVar2 != (int *)0x0) {
            LOCK();
            puVar1 = (uint *)(piVar2 + 1);
            uVar7 = *puVar1;
            uVar4 = *puVar1;
            *puVar1 = uVar7 - 1;
            UNLOCK();
            if (uVar7 - 1 == 0) {
              (**(code **)*piVar2)();
              LOCK();
              puVar1 = (uint *)(piVar2 + 2);
              uVar7 = *puVar1;
              uVar4 = *puVar1;
              *puVar1 = uVar7 - 1;
              UNLOCK();
              if (uVar7 - 1 == 0) {
                uVar4 = (**(code **)(*piVar2 + 4))();
              }
            }
          }
          puVar6 = puVar6 + 2;
        }
      }
      if (puVar6 != puVar8) {
        puVar5 = *(uint **)(param_1 + 0x1c4);
        if (puVar8 != puVar5) {
          do {
            uVar4 = *puVar8;
            uVar7 = puVar8[1];
            *puVar8 = 0;
            puVar8[1] = 0;
            *puVar6 = uVar4;
            piVar2 = (int *)puVar6[1];
            puVar6[1] = uVar7;
            if (piVar2 != (int *)0x0) {
              LOCK();
              iVar3 = piVar2[1] + -1;
              piVar2[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piVar2)();
                LOCK();
                iVar3 = piVar2[2] + -1;
                piVar2[2] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
            puVar8 = puVar8 + 2;
            puVar6 = puVar6 + 2;
          } while (puVar8 != puVar5);
          puVar5 = *(uint **)(param_1 + 0x1c4);
        }
        uVar4 = FUN_005596d0(puVar6,puVar5,param_1 + 0x1c0);
        *(uint **)(param_1 + 0x1c4) = puVar6;
      }
    }
  }
  return uVar4;
}



/* FUNCTION 27658 ; VA 0x00c22d40 ; FUN_00c22d40 */

void __thiscall FUN_00c22d40(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 200);
  *param_2 = *(undefined8 *)(param_1 + 0xc0);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 27659 ; VA 0x00c22d60 ; FUN_00c22d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c22d60(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = _DAT_00000000;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180715f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_01674e20(0xc);
  uStack_8 = 0;
  if (iVar7 == 0) {
    iVar7 = 0;
  }
  else {
    FUN_00569550(2,&uStack_11);
  }
  uStack_8 = 0xffffffff;
  FUN_0055ba30(iVar7,param_2);
  uStack_8 = 1;
  uVar8 = FUN_00c287a0();
  *_DAT_00000000 = uVar8;
  iVar9 = FUN_00c28900();
  iVar7 = puVar6[1];
  if (iVar7 == iVar9) {
    puVar6[2] = *(undefined4 *)(param_1 + 0x84);
  }
  else {
    if (iVar7 != 0) {
      (**(code **)(iVar7 + 8))(puVar6 + 2);
      puVar6[1] = 0;
    }
    puVar6[2] = *(undefined4 *)(param_1 + 0x84);
    puVar6[1] = iVar9;
  }
  puVar6 = _DAT_00000000;
  iVar7 = *(int *)(param_1 + 0x84);
  if (iVar7 == 1) {
    uVar8 = FUN_00b00260();
    iVar7 = _tls_index;
    _DAT_00000000[0x34] = uVar8;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar7 * 4) + 0x34) < DAT_01ead3d8) &&
       (FUN_016f3809(&DAT_01ead3d8), DAT_01ead3d8 == -1)) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
    puVar2 = (undefined *)puVar6[0x35];
    if (puVar2 == &DAT_01ead3cc) {
      uVar8 = *(undefined4 *)(param_1 + 0x8c);
      uVar4 = *(undefined4 *)(param_1 + 0x90);
      uVar5 = *(undefined4 *)(param_1 + 0x94);
      puVar6[0x36] = *(undefined4 *)(param_1 + 0x88);
      puVar6[0x37] = uVar8;
      puVar6[0x38] = uVar4;
      puVar6[0x39] = uVar5;
      uVar8 = *(undefined4 *)(param_1 + 0x9c);
      uVar4 = *(undefined4 *)(param_1 + 0xa0);
      uVar5 = *(undefined4 *)(param_1 + 0xa4);
      puVar6[0x3a] = *(undefined4 *)(param_1 + 0x98);
      puVar6[0x3b] = uVar8;
      puVar6[0x3c] = uVar4;
      puVar6[0x3d] = uVar5;
      uVar8 = *(undefined4 *)(param_1 + 0xac);
      uVar4 = *(undefined4 *)(param_1 + 0xb0);
      uVar5 = *(undefined4 *)(param_1 + 0xb4);
      puVar6[0x3e] = *(undefined4 *)(param_1 + 0xa8);
      puVar6[0x3f] = uVar8;
      puVar6[0x40] = uVar4;
      puVar6[0x41] = uVar5;
    }
    else {
      if (puVar2 != (undefined *)0x0) {
        (**(code **)(puVar2 + 8))(puVar6 + 0x36);
        puVar6[0x35] = 0;
      }
      uVar8 = *(undefined4 *)(param_1 + 0x8c);
      uVar4 = *(undefined4 *)(param_1 + 0x90);
      uVar5 = *(undefined4 *)(param_1 + 0x94);
      puVar6[0x36] = *(undefined4 *)(param_1 + 0x88);
      puVar6[0x37] = uVar8;
      puVar6[0x38] = uVar4;
      puVar6[0x39] = uVar5;
      uVar8 = *(undefined4 *)(param_1 + 0x9c);
      uVar4 = *(undefined4 *)(param_1 + 0xa0);
      uVar5 = *(undefined4 *)(param_1 + 0xa4);
      puVar6[0x3a] = *(undefined4 *)(param_1 + 0x98);
      puVar6[0x3b] = uVar8;
      puVar6[0x3c] = uVar4;
      puVar6[0x3d] = uVar5;
      uVar8 = *(undefined4 *)(param_1 + 0xac);
      uVar4 = *(undefined4 *)(param_1 + 0xb0);
      uVar5 = *(undefined4 *)(param_1 + 0xb4);
      puVar6[0x3e] = *(undefined4 *)(param_1 + 0xa8);
      puVar6[0x3f] = uVar8;
      puVar6[0x40] = uVar4;
      puVar6[0x41] = uVar5;
      puVar6[0x35] = &DAT_01ead3cc;
    }
  }
  else if ((iVar7 == 2) || (iVar7 == 3)) {
    uStack_8._0_1_ = 2;
    iStack_18 = FUN_0170d75d(*(undefined4 *)(param_1 + 0xb8),0,
                             &RBX::IHasLocation::RTTI_Type_Descriptor,
                             &RBX::Instance::RTTI_Type_Descriptor,0);
    if (iStack_18 == 0) {
      iVar7 = 0;
      iStack_18 = 0;
    }
    else {
      iVar7 = *(int *)(param_1 + 0xbc);
      if (iVar7 != 0) {
        LOCK();
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
        UNLOCK();
        iVar7 = *(int *)(param_1 + 0xbc);
      }
    }
    puVar6 = _DAT_00000000;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uVar8 = FUN_0088cdc0();
    _DAT_00000000[0x34] = uVar8;
    iVar10 = FUN_006309e0();
    iVar9 = puVar6[0x35];
    if (iVar9 == iVar10) {
      puVar6[0x36] = iStack_18;
      piVar3 = (int *)puVar6[0x37];
      puVar6[0x37] = iVar7;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar7 = piVar3[1] + -1;
        piVar3[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar7 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else {
      if (iVar9 != 0) {
        (**(code **)(iVar9 + 8))(puVar6 + 0x36);
      }
      puVar6[0x36] = iStack_18;
      puVar6[0x37] = iVar7;
      puVar6[0x35] = iVar10;
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27660 ; VA 0x00c23020 ; FUN_00c23020 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c23020(int param_1,int param_2,double *param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  uint uVar2;
  int *piVar3;
  float *pfVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fStack_38;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  
  if (*(char *)(param_1 + 0xcc) != '\0') {
    uVar7 = *(uint *)(param_1 + 0xd8);
    fStack_c = (float)((DAT_018c0d60 / *param_3) * _DAT_0194be00);
    uStack_14 = CONCAT44((*(float *)(param_2 + 0x28) - *(float *)(param_1 + 0xc4)) * fStack_c,
                         (*(float *)(param_2 + 0x24) - *(float *)(param_1 + 0xc0)) * fStack_c);
    fStack_c = (*(float *)(param_2 + 0x2c) - *(float *)(param_1 + 200)) * fStack_c;
    if (uVar7 <= *(int *)(param_1 + 0xe0) + 1U) {
      FUN_00716150(1);
      uVar7 = *(uint *)(param_1 + 0xd8);
    }
    *(uint *)(param_1 + 0xdc) = *(uint *)(param_1 + 0xdc) & uVar7 - 1;
    iVar6 = *(int *)(param_1 + 0xd4);
    uVar7 = *(int *)(param_1 + 0xe0) + *(int *)(param_1 + 0xdc) & *(int *)(param_1 + 0xd8) - 1U;
    if (*(int *)(iVar6 + uVar7 * 4) == 0) {
      uVar5 = FUN_01674e20(0xc);
      *(undefined4 *)(*(int *)(param_1 + 0xd4) + uVar7 * 4) = uVar5;
      iVar6 = *(int *)(param_1 + 0xd4);
    }
    puVar1 = *(undefined8 **)(iVar6 + uVar7 * 4);
    *puVar1 = uStack_14;
    *(float *)(puVar1 + 1) = fStack_c;
    iVar6 = *(int *)(param_1 + 0xe0);
    *(int *)(param_1 + 0xe0) = iVar6 + 1;
    if (5 < *(uint *)(param_1 + 0xe0)) {
      *(int *)(param_1 + 0xe0) = iVar6;
      if (iVar6 == 0) {
        *(undefined4 *)(param_1 + 0xdc) = 0;
      }
      else {
        *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + 1;
      }
    }
    uVar8 = *(uint *)(param_1 + 0xdc);
    fVar10 = 0.0;
    uVar2 = *(uint *)(param_1 + 0xe0);
    fVar11 = 0.0;
    fVar12 = 0.0;
    piVar3 = *(int **)(param_1 + 0xd0);
    uStack_14 = 0;
    uVar7 = uVar8 + uVar2;
    fStack_c = 0.0;
    fStack_20 = 0.0;
    fStack_1c = 0.0;
    fStack_18 = 0.0;
    fStack_38 = DAT_018f7864;
    for (; uVar8 != uVar7; uVar8 = uVar8 + 1) {
      if (piVar3 == (int *)0x0) {
        iVar6 = 0;
      }
      else {
        iVar6 = *piVar3;
      }
      pfVar4 = *(float **)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & uVar8) * 4);
      fVar11 = pfVar4[1] + fVar11;
      fVar10 = fVar10 + *pfVar4;
      fVar12 = pfVar4[2] + fVar12;
      if (piVar3 == (int *)0x0) {
        iVar6 = 0;
      }
      else {
        iVar6 = *piVar3;
      }
      pfVar4 = *(float **)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & uVar8) * 4);
      dVar9 = (double)(*pfVar4 * *pfVar4 + pfVar4[1] * pfVar4[1] + pfVar4[2] * pfVar4[2]);
      fStack_20 = fVar10;
      fStack_1c = fVar11;
      fStack_18 = fVar12;
      FUN_017267a0();
      if (fStack_38 < (float)dVar9) {
        if (piVar3 == (int *)0x0) {
          iVar6 = 0;
        }
        else {
          iVar6 = *piVar3;
        }
        puVar1 = *(undefined8 **)(*(int *)(iVar6 + 4) + (*(int *)(iVar6 + 8) - 1U & uVar8) * 4);
        uStack_14 = *puVar1;
        fStack_c = *(float *)(puVar1 + 1);
        fStack_38 = (float)dVar9;
      }
    }
    if (1 < uVar2) {
      fStack_18 = DAT_018ce2f8 /
                  (float)((double)(int)(uVar2 - 1) +
                         (double)(&DAT_018c0d90)[-((int)(uVar2 - 1) >> 0x1f)]);
      fStack_20 = (fVar10 - (float)uStack_14) * fStack_18;
      fStack_1c = (fVar11 - uStack_14._4_4_) * fStack_18;
      fStack_18 = (fVar12 - fStack_c) * fStack_18;
    }
    FUN_00c1fcc0(&fStack_20,param_4);
  }
  *(undefined8 *)(param_1 + 0xc0) = *(undefined8 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 200) = *(undefined4 *)(param_2 + 0x2c);
  *(undefined *)(param_1 + 0xcc) = 1;
  return;
}



/* FUNCTION 27661 ; VA 0x00c23310 ; FUN_00c23310 */

float10 __fastcall FUN_00c23310(int param_1)

{
  return (float10)*(float *)(param_1 + 0xe4);
}



/* FUNCTION 27662 ; VA 0x00c23320 ; FUN_00c23320 */

void __thiscall
FUN_00c23320(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_80;
  undefined4 uStack_60;
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  uint auStack_38 [2];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018071c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  auStack_58[0] = 0;
  ExceptionList = &pvStack_10;
  uStack_60 = param_1;
  if (param_2 != 0) {
    auStack_58[0] = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_50,0);
    }
    else {
      uStack_50 = param_4;
      uStack_4c = param_5;
      uStack_48 = param_6;
      uStack_44 = param_7;
      uStack_40 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  auStack_38[0] = 0;
  if (param_9 != 0) {
    auStack_38[0] = param_9;
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_30,0);
    }
    else {
      uStack_30 = param_11;
      uStack_2c = param_12;
      uStack_28 = param_13;
      uStack_24 = param_14;
      uStack_20 = param_15;
    }
  }
  auStack_a8[0] = uStack_60;
  uStack_8._0_1_ = 3;
  uStack_a0 = 0;
  FUN_005880d0(auStack_58);
  uStack_8._0_1_ = 4;
  uStack_80 = 0;
  FUN_005880d0(auStack_38);
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined4 *)FUN_00c1c0a0(auStack_a8);
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0096ca80();
  cVar3 = FUN_0168a8f0();
  if (cVar3 == '\0') {
    uVar4 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar4);
  }
  uStack_8._0_1_ = 9;
  FUN_016899e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_016899e0();
  puVar2 = puStack_14;
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    iVar1 = puStack_14[1] + -1;
    puStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*puStack_14)(0);
      uVar4 = GetProcessHeap(0,puVar2);
      HeapFree(uVar4);
    }
  }
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 0xc;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27663 ; VA 0x00c23510 ; FUN_00c23510 */

undefined __fastcall FUN_00c23510(int param_1)

{
  return *(undefined *)(param_1 + 0x80);
}



/* FUNCTION 27664 ; VA 0x00c23520 ; FUN_00c23520 */

float10 __thiscall FUN_00c23520(int param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  uint in_stack_00000018;
  double dStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018071d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar3 = param_1 + 0x1cd + (uint)*(byte *)(param_1 + 0x1cc);
  dStack_1c = 0.0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009cc8a0(&param_2);
  FUN_00607080(&iStack_14,uVar1,&param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (iStack_14 != 0) {
    dStack_1c = *(double *)(iStack_14 + 0x20);
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar3 = param_2;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return (float10)dStack_1c;
}



/* FUNCTION 27665 ; VA 0x00c235e0 ; FUN_00c235e0 */

void __thiscall FUN_00c235e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  char ****ppppcVar3;
  int iVar4;
  undefined4 uVar5;
  char *****pppppcVar6;
  char *****pppppcVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  bool bVar11;
  int iStack_124;
  float afStack_120 [50];
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  char ****ppppcStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  float fStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807213;
  pvStack_10 = ExceptionList;
  piVar10 = *(int **)(param_1 + 0x1c0);
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_00888650(&uStack_28);
  bVar11 = piVar10 == *(int **)(param_1 + 0x1c4);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  do {
    if (bVar11) {
      *param_2 = uStack_28;
      param_2[1] = uStack_24;
      ExceptionList = pvStack_10;
      return;
    }
    iVar4 = *piVar10;
    puStack_1c = (undefined4 *)(iVar4 + 0x10);
    fStack_14 = *(float *)(iVar4 + 0x20);
    fStack_30 = 0.0;
    uStack_2c = 0;
    if (0xf < *(uint *)(iVar4 + 0x24)) {
      puStack_1c = (undefined4 *)*puStack_1c;
    }
    if ((uint)fStack_14 < 0x10) {
      pppppcVar6 = (char *****)*puStack_1c;
      uStack_3c = puStack_1c[1];
      uStack_38 = puStack_1c[2];
      uStack_34 = puStack_1c[3];
      uStack_18 = 0xf;
      ppppcStack_40 = (char ****)pppppcVar6;
    }
    else {
      uStack_18 = (uint)fStack_14 | 0xf;
      if (0x7fffffff < uStack_18) {
        uStack_18 = 0x7fffffff;
      }
      uVar9 = uStack_18 + 1;
      if (uVar9 < 0x1000) {
        if (uVar9 == 0) {
          pppppcVar6 = (char *****)0x0;
        }
        else {
          pppppcVar6 = (char *****)FUN_01674e20(uVar9);
        }
      }
      else {
        uVar8 = uStack_18 + 0x24;
        if (uVar8 <= uVar9) {
          uVar8 = 0xffffffff;
        }
        ppppcVar3 = (char ****)FUN_01674e20(uVar8);
        if (ppppcVar3 == (char ****)0x0) goto LAB_00c238f8;
        pppppcVar6 = (char *****)((int)ppppcVar3 + 0x23U & 0xffffffe0);
        pppppcVar6[-1] = ppppcVar3;
      }
      ppppcStack_40 = (char ****)pppppcVar6;
      FUN_0170c6f0(pppppcVar6,puStack_1c,(int)fStack_14 + 1);
    }
    uStack_8._0_1_ = 1;
    fStack_30 = fStack_14;
    uStack_2c = uStack_18;
    iVar4 = FUN_00e38e00();
    fStack_14 = (float)iVar4 / DAT_018d0938;
    uVar5 = FUN_0088c960();
    iStack_124 = 0;
    afStack_120[0] = fStack_14;
    iStack_124 = FUN_00630820();
    uStack_8._0_1_ = 2;
    pppppcVar7 = &ppppcStack_40;
    if (0xf < uStack_18) {
      pppppcVar7 = pppppcVar6;
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    pppppcVar6 = pppppcVar7;
    do {
      cVar2 = *(char *)pppppcVar6;
      pppppcVar6 = (char *****)((int)pppppcVar6 + 1);
    } while (cVar2 != '\0');
    FUN_005542c0(pppppcVar7,(int)pppppcVar6 - (int)((int)pppppcVar7 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar4 = FUN_005c4c00(auStack_58);
    piVar1 = (int *)(iVar4 + 0x1c);
    *(undefined4 *)(iVar4 + 0x18) = uVar5;
    if (&iStack_124 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(iVar4 + 0x20);
        *piVar1 = 0;
      }
      if (iStack_124 != 0) {
        (**(code **)(iStack_124 + 4))(afStack_120,iVar4 + 0x20);
        *piVar1 = iStack_124;
        if (iStack_124 != 0) {
          (**(code **)(iStack_124 + 8))(afStack_120);
          iStack_124 = 0;
        }
      }
    }
    FUN_00888530();
    if (iStack_124 != 0) {
      (**(code **)(iStack_124 + 8))(afStack_120);
      iStack_124 = 0;
    }
    uStack_8._0_1_ = 2;
    if (0xf < uStack_44) {
      uVar8 = uStack_44 + 1;
      uVar9 = auStack_58[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_58[0] - 4);
        uVar8 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar9) - 4) goto LAB_00c238f8;
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    if (iStack_124 != 0) {
      (**(code **)(iStack_124 + 8))(afStack_120);
    }
    uStack_8._0_1_ = 0;
    if (0xf < uStack_2c) {
      uVar9 = uStack_2c + 1;
      pppppcVar6 = (char *****)ppppcStack_40;
      if (0xfff < uVar9) {
        pppppcVar6 = (char *****)ppppcStack_40[-1];
        uVar9 = uStack_2c + 0x24;
        if ((char *)0x1f < (char *)((int)ppppcStack_40 + (-4 - (int)pppppcVar6))) {
LAB_00c238f8:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppcVar6,uVar9);
    }
    piVar10 = piVar10 + 2;
    bVar11 = piVar10 == *(int **)(iStack_20 + 0x1c4);
  } while( true );
}



/* FUNCTION 27666 ; VA 0x00c23900 ; FUN_00c23900 */

int __fastcall FUN_00c23900(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iStack_c;
  int iStack_8;
  
  iVar4 = 0;
  iVar2 = FUN_011aeb30(*(undefined4 *)(param_1 + 0x68),&iStack_c,&iStack_8);
  if ((iVar2 == 0) && (iStack_8 == 8)) {
    if (*(int *)(param_1 + 0x160) == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3 = *(undefined4 **)(*(int *)(param_1 + 0x16c) + *(int *)(param_1 + 0x15c) * 4);
    }
    for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
      cVar1 = FUN_00e38f20();
      if (cVar1 == '\0') {
        iVar2 = FUN_00e38e00();
        if (0 < iVar2 - iStack_c) {
          iVar4 = iVar4 + (iVar2 - iStack_c);
        }
      }
    }
    return iVar4;
  }
  return 0;
}



/* FUNCTION 27667 ; VA 0x00c23990 ; FUN_00c23990 */

void __thiscall FUN_00c23990(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c28850();
  *param_3 = uVar3;
  iVar4 = FUN_00c28970();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 27668 ; VA 0x00c239f0 ; FUN_00c239f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c239f0(uint param_1)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  void *pvVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  uint uVar10;
  uint in_stack_00000024;
  undefined4 ***apppuStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807260;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_44 = 0;
  uStack_40 = 0xf;
  apppuStack_54[0] = (undefined4 ***)((uint)apppuStack_54[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 2;
  FUN_00888650(&uStack_24);
  uStack_8._0_1_ = 3;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018c3d40,6);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar5 = FUN_005c4c00(auStack_3c);
  uVar6 = FUN_0088c8c0();
  *(undefined4 *)(iVar5 + 0x18) = uVar6;
  iVar7 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar5 + 0x1c);
  if (iVar2 == iVar7) {
    *(undefined4 *)(iVar5 + 0x20) = 2;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar5 + 0x20);
    }
    *(undefined4 *)(iVar5 + 0x20) = 2;
    *(int *)(iVar5 + 0x1c) = iVar7;
  }
  uStack_8._0_1_ = 3;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0(&DAT_0194b318,8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar5 = FUN_005c4c00(auStack_3c);
  uVar6 = FUN_0088cb40();
  pvVar4 = ThreadLocalStoragePointer;
  iVar2 = _tls_index;
  *(undefined4 *)(iVar5 + 0x18) = uVar6;
  if ((*(int *)(*(int *)((int)pvVar4 + iVar2 * 4) + 0x34) < DAT_01ea8c48) &&
     (FUN_016f3809(&DAT_01ea8c48), DAT_01ea8c48 == -1)) {
    _DAT_01ea8c3c = FUN_005c65f0;
    _DAT_01ea8c40 = FUN_005c93a0;
    DAT_01ea8c44 = FUN_005c77b0;
    FUN_016f37bf(&DAT_01ea8c48);
  }
  puVar3 = *(undefined **)(iVar5 + 0x1c);
  if (puVar3 == &DAT_01ea8c3c) {
    if ((undefined4 ****)(iVar5 + 0x20) != apppuStack_54) {
      ppppuVar8 = apppuStack_54;
      if (0xf < uStack_40) {
        ppppuVar8 = (undefined4 ****)apppuStack_54[0];
      }
      FUN_005542c0(ppppuVar8,uStack_44);
    }
  }
  else {
    if (puVar3 != (undefined *)0x0) {
      (**(code **)(puVar3 + 8))(iVar5 + 0x20);
      *(undefined4 *)(iVar5 + 0x1c) = 0;
    }
    FUN_0054ef60(apppuStack_54);
    *(undefined **)(iVar5 + 0x1c) = &DAT_01ea8c3c;
  }
  uStack_8._0_1_ = 3;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  uStack_1c = uStack_24;
  piStack_18 = piStack_20;
  uStack_8._0_1_ = 6;
  if (param_1 == 0) {
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c,uStack_24,piStack_20);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_40) {
    uVar10 = uStack_40 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_54[0];
    if (0xfff < uVar10) {
      ppppuVar8 = (undefined4 ****)apppuStack_54[0][-1];
      uVar10 = uStack_40 + 0x24;
      if (0x1f < (uint)((int)apppuStack_54[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar10);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  uStack_8 = 9;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27669 ; VA 0x00c24150 ; FUN_00c24150 */

void FUN_00c24150(int *param_1)

{
  int iVar1;
  undefined uVar2;
  uint uVar3;
  undefined auStack_98 [48];
  undefined uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_4c;
  int iStack_48;
  uint uStack_44;
  uint *puStack_40;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01807280;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_20 = 0;
  uStack_1c = 7;
  auStack_30[0] = auStack_30[0] & 0xffff0000;
  iStack_8 = 0;
  iStack_48 = *(undefined4 *)(iVar1 + 0x18);
  uStack_44 = *(int *)(iStack_48 + 0x10);
  if (0xf < *(uint *)(iStack_48 + 0x14)) {
    iStack_48 = *(int *)iStack_48;
  }
  puStack_40 = auStack_30;
  uStack_4c = 0xc241a6;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00fea6b0();
  uStack_14 = *(undefined4 *)(iVar1 + 0x20);
  puStack_40 = (uint *)0x1;
  uStack_64 = 0;
  puStack_18 = auStack_98;
  FUN_0054ef60(iVar1);
  iStack_8._0_1_ = 1;
  FUN_0054f050(auStack_30);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_68 = uVar2;
  FUN_00c1aa00();
  uStack_64 = 0xc241f2;
  FUN_0090ca30();
  if (7 < uStack_1c) {
    puStack_40 = (uint *)(uStack_1c * 2 + 2);
    uVar3 = auStack_30[0];
    if (0xfff < puStack_40) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      puStack_40 = (uint *)(uStack_1c * 2 + 0x25);
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_40 = (uint *)&UNK_00c2423e;
        FUN_017167a3();
      }
    }
    iStack_48 = 0xc24225;
    uStack_44 = uVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27670 ; VA 0x00c24240 ; FUN_00c24240 */

void FUN_00c24240(undefined4 param_1)

{
  FUN_00e39520(param_1);
  return;
}



/* FUNCTION 27671 ; VA 0x00c24260 ; FUN_00c24260 */

void FUN_00c24260(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *param_1;
  iVar2 = FUN_0068f660();
  if (iVar2 != 0) {
    FUN_00c29560(iVar1,iVar1 + 0x18);
  }
  return;
}



/* FUNCTION 27672 ; VA 0x00c24290 ; FUN_00c24290 */

void FUN_00c24290(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0068f660();
  if (iVar1 != 0) {
    FUN_00c26330(param_1);
  }
  return;
}



/* FUNCTION 27673 ; VA 0x00c242b0 ; FUN_00c242b0 */

void FUN_00c242b0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0068f660();
  if (iVar2 != 0) {
    if (*(char *)(iVar1 + 0x30) != '\0') {
      uVar3 = FUN_005569d0(auStack_28);
      uStack_8 = 0;
      FUN_00c29560(iVar1,uVar3);
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00c26330(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27674 ; VA 0x00c24340 ; FUN_00c24340 */

void FUN_00c24340(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_0068f660();
  if (iVar1 != 0) {
    FUN_00c21930(param_1,*(undefined4 *)(param_1 + 8));
  }
  return;
}



/* FUNCTION 27675 ; VA 0x00c24370 ; FUN_00c24370 */

void FUN_00c24370(int *param_1)

{
  int iVar1;
  int *piVar2;
  
  param_1 = (int *)*param_1;
  iVar1 = FUN_0068f660();
  if (iVar1 != 0) {
    piVar2 = param_1 + 2;
    iVar1 = FUN_00c1d7a0(*param_1 + 0x10);
    if ((int *)(iVar1 + 0x18) != piVar2) {
      if (0xf < (uint)param_1[7]) {
        piVar2 = (int *)*piVar2;
      }
      FUN_005542c0(piVar2,param_1[6]);
    }
    FUN_00c20fa0(*param_1 + 0x10);
  }
  return;
}



/* FUNCTION 27676 ; VA 0x00c243e0 ; FUN_00c243e0 */

void FUN_00c243e0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *param_1;
  iVar2 = FUN_0068f660();
  if (iVar2 != 0) {
    FUN_00c292a0(iVar1,iVar1 + 0x18);
  }
  return;
}



/* FUNCTION 27677 ; VA 0x00c24410 ; FUN_00c24410 */

int FUN_00c24410(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puVar3 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c289e0(*puVar3,puVar3[1],puVar3 + 2,param_2,param_3,param_4,param_5,param_6,param_7,
                       param_8);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27678 ; VA 0x00c24570 ; FUN_00c24570 */

uint FUN_00c24570(void)

{
  int iVar1;
  
  iVar1 = FUN_00c1b320();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 27679 ; VA 0x00c24590 ; FUN_00c24590 */

uint FUN_00c24590(void)

{
  int iVar1;
  
  iVar1 = FUN_00c1b320();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 27680 ; VA 0x00c245b0 ; FUN_00c245b0 */

void __fastcall FUN_00c245b0(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined *in_stack_fffffe48;
  undefined auStack_194 [256];
  undefined4 uStack_94;
  undefined auStack_90 [40];
  float fStack_68;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 *puStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  char cStack_15;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018072b9;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d683c8 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00c27ea0(4);
  }
  iVar3 = FUN_016dee6d(&DAT_01ef90a0);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  iVar3 = FUN_011adf20(&uStack_1c);
  uStack_8 = 0;
  iVar4 = FUN_016deec8(&DAT_01ef90a0);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = 0xffffffff;
  if ((iVar3 == 0) && (FUN_00c1c320(uStack_1c,uStack_2c), *(int *)(param_1 + 0x68) != 0)) {
    iStack_28 = iVar3;
    iVar3 = FUN_011aec20(uStack_1c,&iStack_28);
    iVar4 = FUN_011b2920();
    if (((iVar3 != 0) || ((iStack_28 != 0x20008 || (iVar4 != 0x20008)))) && (DAT_01d84e8e != '\0'))
    {
      FUN_01677520(DAT_01d84e8e,"fmod version mismatch. runtime version:%u, headers version:%u",
                   iStack_28,0x20008);
    }
    FUN_011af860(*(undefined4 *)(param_1 + 0x68),param_1);
    FUN_011af3d0(*(undefined4 *)(param_1 + 0x68),FUN_00c22040,DAT_01d68358);
    if (DAT_01d683b8 == '\0') {
      cStack_15 = '\x01';
    }
    else {
      iVar3 = FUN_0090c170();
      cStack_15 = *(char *)(iVar3 + 0x13e);
    }
    puStack_20 = *(undefined **)(param_1 + 0x68);
    uStack_14 = 0;
    iVar3 = FUN_011aea70(puStack_20,&uStack_14);
    if ((iVar3 == 0) && (uStack_14 != 0)) {
      iVar3 = 0;
      if (0 < (int)uStack_14) {
        do {
          in_stack_fffffe48 = auStack_194;
          iVar4 = FUN_011ae7a0(puStack_20,iVar3,in_stack_fffffe48,0x100,0,0,0,0);
          if (((iVar4 == 0) && (cStack_15 != '\0')) &&
             ((iVar4 = FUN_0170de40(auStack_194,"Rift Audio"), iVar4 != 0 ||
              (iVar4 = FUN_0170de40(auStack_194,"HTC-VIVE"), iVar4 != 0)))) {
            if (-1 < iVar3) goto LAB_00c24778;
            goto LAB_00c247ab;
          }
          iVar3 = iVar3 + 1;
        } while (iVar3 < (int)uStack_14);
      }
      iVar3 = 0;
LAB_00c24778:
      FUN_011af4c0(*(undefined4 *)(param_1 + 0x68),iVar3);
      in_stack_fffffe48 = &DAT_01f6e8dc;
      FUN_011ae7a0(*(undefined4 *)(param_1 + 0x68),iVar3,&DAT_01f6e8dc,0x80,0,&DAT_01f6e95c,
                   &DAT_01f6e960,&DAT_01f6e964);
      DAT_01f6e968 = iVar3;
    }
LAB_00c247ab:
    uVar6 = 0;
    uStack_14 = 0;
    if ((DAT_01d68430 == '\0') && (iVar3 = FUN_00912810(), *(char *)(iVar3 + 0x5a) != '\0')) {
      uVar6 = 0x10000;
      uStack_14 = 0x10000;
      FUN_00c1f4d0();
    }
    if (DAT_01d68488 != '\0') {
      uStack_14 = uVar6 | 0x20000;
      FUN_0170d1f0(auStack_90,0,0x5c);
      uStack_94 = 0x60;
      iVar3 = FUN_011ae400(*(undefined4 *)(param_1 + 0x68),&uStack_94);
      if (iVar3 == 0) {
        fStack_68 = (float)DAT_01d6831c / (float)DAT_01d68324;
        FUN_011af310(*(undefined4 *)(param_1 + 0x68),&uStack_94);
      }
    }
    FUN_011af730(*(undefined4 *)(param_1 + 0x68),48000,0,0);
    uVar5 = uStack_1c;
    uVar6 = (uint)in_stack_fffffe48 & 0xffffff00;
    FUN_005542c0("ClientLoad",10);
    FUN_00c1e980(uVar5,uVar6);
    if (DAT_01d683c8 != '\0') {
      FUN_00c27ea0(5);
    }
    puStack_20 = &DAT_01ef90a0;
    iVar3 = FUN_016dee6d(&DAT_01ef90a0);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uVar6 = uStack_14;
    uVar5 = DAT_01d68250;
    uStack_8 = 1;
    *(undefined4 *)(param_1 + 0x70) = DAT_01d68250;
    iVar3 = FUN_011aece0(*(undefined4 *)(param_1 + 0x68),uVar5,uStack_14,0);
    if (iVar3 != 0) {
      FUN_011af580(*(undefined4 *)(param_1 + 0x68),2);
      FUN_011aece0(*(undefined4 *)(param_1 + 0x68),*(undefined4 *)(param_1 + 0x70),uVar6,0);
    }
    uStack_8 = 2;
    iVar3 = FUN_016deec8(&DAT_01ef90a0);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8 = 0xffffffff;
    FUN_011ae100(*(undefined4 *)(param_1 + 0x68),0,param_1 + 0x138);
    if ((DAT_01d68478 != '\0') &&
       (iVar3 = FUN_011ae9b0(*(undefined4 *)(param_1 + 0x68),&uStack_14), iVar3 == 0)) {
      FUN_011b1af0(uStack_14,DAT_01d68310);
      FUN_011b1bb0(uStack_14,2);
    }
    uVar5 = FUN_00c1c240(auStack_34,param_1 + 0x138);
    FUN_005587e0(uVar5);
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_30[1] + -1;
      piStack_30[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar3 = piStack_30[2] + -1;
        piStack_30[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    uVar5 = *(undefined4 *)(param_1 + 0x138);
    iVar3 = FUN_0090c170();
    FUN_011b1200(uVar5,*(undefined4 *)(iVar3 + 0xe4));
    iVar3 = FUN_0090c170();
    uStack_14 = iVar3 + 0x4c;
    uStack_8 = 3;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 4;
    puStack_20 = (undefined *)uVar5;
    piStack_30 = (int *)FUN_01674e20(0x1c);
    if (piStack_30 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *piStack_30 = 0;
      piStack_30[1] = 1;
      piStack_30[2] = (int)FUN_00c20a40;
      piStack_30[3] = (int)_guard_check_icall;
      piStack_30[4] = 0;
      piStack_30[5] = uStack_14;
      piStack_30[6] = param_1;
      puVar7 = piStack_30;
    }
    FUN_016797d0(puVar7);
    if (puVar7 != (undefined4 *)0x0) {
      LOCK();
      puVar7[1] = puVar7[1] + 1;
      UNLOCK();
    }
    uStack_2c = 1;
    uStack_8._0_1_ = 5;
    puStack_24 = puVar7;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    cVar2 = FUN_01679300(&puStack_24);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_24);
    }
    uStack_8 = 0xffffffff;
    if (puStack_24 != (undefined4 *)0x0) {
      piVar1 = puStack_24 + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(puStack_24);
      }
    }
    FUN_00c29f20();
    if (*(int *)(param_1 + 0xec) != 0) {
      FUN_00c2a130();
    }
    *(undefined *)(param_1 + 0x236) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27681 ; VA 0x00c24af0 ; FUN_00c24af0 */

int __fastcall FUN_00c24af0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined uVar9;
  undefined4 uVar10;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807308;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x236) = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  iStack_1c = param_1;
  FUN_005542c0("RCCLoadFMOD-Init",0x10);
  uStack_8 = 0;
  FUN_008783f0(auStack_38,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar7 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  iStack_14 = 0;
  if (DAT_01d683c8 != '\0') {
    FUN_00c27ea0(2);
  }
  iVar4 = FUN_016dee6d(&DAT_01ef90a0);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iVar4 = FUN_011adf20(&iStack_14);
  uStack_8 = 1;
  iVar5 = FUN_016deec8(&DAT_01ef90a0);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_8 = 0xffffffff;
  if ((iVar4 == 0) && (iStack_14 != 0)) {
    puVar1 = (undefined4 *)(param_1 + 0x68);
    FUN_00c1c320(iStack_14,iStack_1c);
    iStack_18 = iVar4;
    iVar4 = FUN_011aec20(iStack_14,&iStack_18);
    if (((iVar4 != 0) || (iStack_18 != 0x20008)) && (DAT_01d84e8e != '\0')) {
      FUN_01677520(DAT_01d84e8e,"fmod version mismatch. runtime version:%u, headers version:%u",
                   iStack_18,0x20008);
    }
    FUN_011af860(*puVar1,param_1);
    FUN_011af3d0(*puVar1,FUN_00c22040,DAT_01d68358);
    iVar4 = 0;
    if (0 < DAT_01d6828c) {
      puStack_20 = &DAT_01ef90a0;
      iVar5 = param_1;
      do {
        if (iVar4 < 2) {
          uVar10 = 2;
        }
        else if (iVar4 < 3) {
          uVar10 = 4;
        }
        else {
          uVar10 = 0;
        }
        FUN_011af580(*puVar1,uVar10);
        if ((DAT_01d68430 == '\0') && (iVar6 = FUN_00912810(), *(char *)(iVar6 + 0x5a) != '\0')) {
          FUN_00c1f4d0();
        }
        if (DAT_01d683c8 != '\0') {
          FUN_00c27ea0(3);
        }
        iVar6 = FUN_016dee6d(&DAT_01ef90a0);
        if (iVar6 != 0) {
          FUN_016df3c9(iVar6);
        }
        uVar10 = *puVar1;
        uStack_8 = 3;
        *(undefined4 *)(iVar5 + 0x70) = 8;
        iVar5 = FUN_011aece0(uVar10,8,0,0);
        uStack_8 = 4;
        iVar6 = FUN_016deec8(&DAT_01ef90a0);
        if (iVar6 != 0) {
          FUN_016df3c9(iVar6);
        }
        uStack_8 = 0xffffffff;
        if (iVar5 == 0) {
          uStack_28 = 0;
          uStack_24 = 0xf;
          auStack_38[0] = auStack_38[0] & 0xffffff00;
          if (iVar4 < 2) {
            FUN_005542c0("RCCLoadFMOD-NoSound",0x13);
            uStack_8 = 5;
          }
          else if (iVar4 < 3) {
            FUN_005542c0("RCCLoadFMOD-NoSoundNRT",0x16);
            uStack_8 = 6;
          }
          else {
            FUN_005542c0("RCCLoadFMOD-AutoDetect",0x16);
            uStack_8 = 7;
          }
          FUN_008783f0(auStack_38,1,0);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          iVar4 = iStack_14;
          uVar9 = 0;
          FUN_005542c0("RCCLoad",7);
          iVar4 = FUN_00c1e980(iVar4,uVar9);
          ExceptionList = pvStack_10;
          return iVar4;
        }
        iVar4 = iVar4 + 1;
        iVar5 = iStack_1c;
      } while (iVar4 < DAT_01d6828c);
    }
    FUN_0086edd0(3,
                 "ERROR: FMOD could not initialize on the server. Sounds may not work properly for this game."
                 ,6);
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("RCCLoadFMOD-FMODInitFailure",0x1b);
    uStack_8 = 8;
    FUN_008783f0(auStack_38,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar7 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    iVar4 = iStack_14;
    uVar9 = 0;
    FUN_005542c0("RCCLoadFailure",0xe);
    iVar4 = FUN_00c1e980(iVar4,uVar9);
    *puVar1 = 0;
    piVar3 = *(int **)(param_1 + 0x6c);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar2 = piVar3 + 1;
      iVar5 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar2 = piVar3 + 2;
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
          ExceptionList = pvStack_10;
          return iVar4;
        }
      }
    }
  }
  else {
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("RCCLoadFMOD-FailSysCreate",0x19);
    uStack_8 = 2;
    iVar4 = FUN_008783f0(auStack_38,1,0);
    if (0xf < uStack_24) {
      uVar8 = uStack_24 + 1;
      uVar7 = auStack_38[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        uVar8 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar4 = FUN_01674ea0(uVar7,uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27682 ; VA 0x00c24fa0 ; FUN_00c24fa0 */

void __thiscall FUN_00c24fa0(int *param_1,int *param_2,int *param_3)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iStack_9c;
  int iStack_98;
  int *piStack_94;
  undefined4 uStack_90;
  uint *puStack_8c;
  int **ppiStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  uint auStack_6c [2];
  int aiStack_64 [6];
  int iStack_4c;
  int iStack_48;
  undefined auStack_44 [24];
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807350;
  pvStack_10 = ExceptionList;
  piStack_7c = (int *)DAT_01ef904c;
  piStack_80 = (int *)0xc24fce;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  uVar1 = FUN_01675290();
  uStack_8 = 0;
  uStack_24 = uVar1;
  if ((*param_3 != 0) && (param_1 != (int *)0x0)) {
    piStack_14 = (int *)param_1[0xd];
    piVar2 = param_1;
    if ((piStack_14 != (int *)0x0) && (piVar2 = piStack_14, piStack_14[0xd] != 0)) {
      piStack_7c = (int *)0xc25007;
      piVar2 = (int *)FUN_005c8ac0();
    }
    piStack_14 = piVar2;
    if (piStack_14 != (int *)0x0) {
      iVar4 = piStack_14[3];
      piStack_7c = (int *)0xc25021;
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        piStack_7c = (int *)&LAB_005c2460;
        piStack_80 = (int *)&DAT_01ea8c5c;
        piStack_84 = (int *)0xc2504f;
        FUN_005789c0();
        piStack_7c = (int *)0xc25057;
        piStack_7c = (int *)FUN_005c36d0();
        piStack_80 = (int *)0xc25062;
        piStack_14 = (int *)FUN_008aa140();
        if (*piStack_14 == 0) {
          piStack_7c = (int *)0xc25073;
          piStack_7c = (int *)FUN_008bd920();
          piStack_80 = (int *)auStack_2c;
          piStack_84 = (int *)0xc2507f;
          piVar2 = (int *)FUN_008a9ba0();
          iVar4 = *piVar2;
          iVar3 = piVar2[1];
          *piVar2 = 0;
          piVar2[1] = 0;
          *piStack_14 = iVar4;
          piVar2 = (int *)piStack_14[1];
          piStack_14[1] = iVar3;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar4 = piVar2[1] + -1;
            piVar2[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              piStack_7c = (int *)0xc250b0;
              (**(code **)*piVar2)();
              LOCK();
              iVar4 = piVar2[2] + -1;
              piVar2[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                piStack_7c = (int *)0xc250c3;
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          if (piStack_28 != (int *)0x0) {
            LOCK();
            iVar4 = piStack_28[1] + -1;
            piStack_28[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              piStack_7c = (int *)0xc250da;
              (**(code **)*piStack_28)();
              LOCK();
              piVar2 = piStack_28 + 2;
              iVar4 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                piStack_7c = (int *)0xc250ec;
                (**(code **)(*piStack_28 + 4))();
              }
            }
          }
        }
        iStack_20 = *piStack_14;
        if (iStack_20 != 0) {
          piStack_80 = (int *)0xc25102;
          piStack_7c = param_1;
          iVar4 = FUN_008f7870();
          if (iVar4 != 0) {
            piStack_7c = param_2;
            iVar4 = (int)param_1 + *(byte *)(param_1 + 0x56) + 0x159;
            piStack_80 = (int *)0xc25124;
            piStack_84 = (int *)FUN_009cc8a0();
            piVar2 = param_2;
            piStack_7c = (int *)(-(uint)(iVar4 != 0) & iVar4 + 1U);
            piStack_80 = param_2;
            ppiStack_88 = &piStack_14;
            puStack_8c = (uint *)0xc25145;
            FUN_00607080();
            piVar5 = piStack_1c;
            if (piStack_14 == (int *)0x0) {
              piStack_7c = param_2;
              iVar4 = (int)piStack_1c + *(byte *)(piStack_1c + 0x5c) + 0x171;
              piStack_80 = (int *)0xc2517b;
              piStack_84 = (int *)FUN_009cc8a0();
              piStack_7c = (int *)(-(uint)(iVar4 != 0) & iVar4 + 1U);
              piStack_80 = param_2;
              ppiStack_88 = &piStack_14;
              puStack_8c = (uint *)0xc2519b;
              FUN_00607080();
              if (piStack_14 == (int *)0x0) {
                piStack_7c = param_2;
                iVar4 = (int)piVar5 + *(byte *)(piVar5 + 100) + 0x191;
                piStack_80 = (int *)0xc251cc;
                piStack_84 = (int *)FUN_009cc8a0();
                piVar2 = param_2;
                piStack_7c = (int *)(-(uint)(iVar4 != 0) & iVar4 + 1U);
                piStack_80 = param_2;
                ppiStack_88 = &piStack_14;
                puStack_8c = (uint *)0xc251ed;
                FUN_00607080();
                if (piStack_14 == (int *)0x0) {
                  piStack_7c = param_2;
                  iVar4 = (int)piVar5 + *(byte *)(piVar5 + 0x6a) + 0x1a9;
                  piStack_80 = (int *)0xc25220;
                  piStack_84 = (int *)FUN_009cc8a0();
                  piVar2 = param_2;
                  piStack_7c = (int *)(-(uint)(iVar4 != 0) & iVar4 + 1U);
                  piStack_80 = param_2;
                  ppiStack_88 = &param_2;
                  puStack_8c = (uint *)0xc25241;
                  FUN_00607080();
                  if (param_2 == (int *)0x0) {
                    if ((DAT_01d68390 != '\0') || (DAT_01d68398 != '\0')) {
                      piStack_7c = piVar2;
                      piStack_80 = (int *)0xc25272;
                      FUN_00c27c40();
                    }
                    piStack_7c = piVar2;
                    piStack_80 = (int *)0xc2527e;
                    FUN_00c1de50();
                    piStack_7c = param_3;
                    piStack_80 = (int *)0xc2528a;
                    FUN_00c1bf70();
                    piStack_7c = piVar5;
                    piStack_80 = (int *)0xc25290;
                    piStack_80 = (int *)FUN_008f7870();
                    piStack_84 = (int *)auStack_18;
                    ppiStack_88 = (int **)0xc2529a;
                    piVar5 = (int *)FUN_005e5de0();
                    param_2 = &iStack_4c;
                    iStack_4c = *piVar5;
                    iStack_48 = piVar5[1];
                    *piVar5 = 0;
                    piVar5[1] = 0;
                    piStack_7c = piVar2;
                    uStack_8._0_1_ = 9;
                    piStack_80 = (int *)0xc252d6;
                    FUN_0054ef60();
                    piStack_7c = (int *)0x0;
                    param_2 = &iStack_9c;
                    if (iStack_48 != 0) {
                      LOCK();
                      *(int *)(iStack_48 + 8) = *(int *)(iStack_48 + 8) + 1;
                      UNLOCK();
                    }
                    iStack_9c = iStack_4c;
                    iStack_98 = iStack_48;
                    uStack_8._0_1_ = 0xb;
                    FUN_0054ef60(auStack_44);
                    uStack_8._0_1_ = 10;
                    FUN_00c1a1f0();
                    piStack_7c = (int *)0xc25327;
                    FUN_005d11a0();
                    piStack_7c = (int *)0x1;
                    piStack_80 = (int *)0x0;
                    piStack_84 = &DAT_01d62f20;
                    uStack_8._0_1_ = 0xc;
                    ppiStack_88 = (int **)0xc25339;
                    ppiStack_88 = (int **)FUN_008ccd90();
                    puStack_8c = auStack_6c;
                    uStack_90 = 0x42a00000;
                    piStack_94 = piVar2;
                    iStack_98 = 0xc2534f;
                    FUN_008cd330();
                    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
                    if (auStack_6c[0] != 0) {
                      if (((auStack_6c[0] & 1) == 0) &&
                         (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
                        piStack_84 = aiStack_64;
                        piStack_7c = (int *)0x2;
                        ppiStack_88 = (int **)0xc25370;
                        piStack_80 = piStack_84;
                        (**(code **)(auStack_6c[0] & 0xfffffffe))();
                      }
                      auStack_6c[0] = 0;
                    }
                    piStack_7c = (int *)0xc25382;
                    FUN_0056c200();
                  }
                  else {
                    piStack_7c = param_3;
                    piStack_80 = (int *)0xc25253;
                    FUN_00c1bf70();
                  }
                }
                else {
                  piStack_80 = piStack_14 + 8;
                  piStack_7c = param_3;
                  piStack_84 = piVar2;
                  ppiStack_88 = (int **)0xc25204;
                  FUN_00c253b0();
                }
              }
              else {
                piStack_7c = param_3;
                piStack_80 = (int *)0xc251b0;
                FUN_00c1bf70();
              }
            }
            else {
              piStack_7c = piStack_14 + 8;
              piStack_80 = piVar2;
              piStack_84 = piStack_1c;
              ppiStack_88 = (int **)0xc2515f;
              (**(code **)(*(int *)*param_3 + 4))();
            }
          }
        }
      }
    }
  }
  uStack_8 = 0xe;
  piStack_80 = (int *)0xc2538f;
  piStack_7c = (int *)uVar1;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27683 ; VA 0x00c253b0 ; FUN_00c253b0 */

int __thiscall FUN_00c253b0(int param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uStack_58;
  int iStack_54;
  undefined auStack_50 [4];
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  char *pcStack_3c;
  undefined auStack_2c [4];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807388;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)&piStack_40;
  ExceptionList = &pvStack_10;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piStack_40 = (int *)*param_4;
  pcStack_3c = (char *)param_4[1];
  uStack_44 = param_3;
  uStack_8 = 0;
  piStack_48 = param_2;
  uStack_58 = 0xc25418;
  iStack_54 = param_1;
  uStack_58 = FUN_008f7870();
  FUN_005e5de0(auStack_50);
  puStack_18 = (undefined *)&uStack_58;
  if (*(int *)(param_1 + 0x6c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x6c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_58 = *(undefined4 *)(param_1 + 0x68);
  iStack_54 = *(undefined4 *)(param_1 + 0x6c);
  uStack_8._0_1_ = 2;
  puVar3 = (undefined4 *)FUN_0060dcd0(auStack_2c,param_1);
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  FUN_00c22390(&iStack_24,*puVar3,puVar3[1]);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_28[1] + -1;
    piStack_28[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      pcStack_3c = (char *)0xc254af;
      (**(code **)*piStack_28)();
      LOCK();
      iVar4 = piStack_28[2] + -1;
      piStack_28[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        pcStack_3c = (char *)0xc254bf;
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (iStack_24 == 0) {
    pcStack_3c = "Unable to start loading sound in to fmod";
    piStack_40 = param_2;
    uStack_44 = 0xc254f1;
    iVar4 = (**(code **)(*(int *)*param_4 + 8))();
  }
  else {
    pcStack_3c = (char *)param_4;
    piStack_40 = &iStack_24;
    uStack_44 = 0;
    piStack_48 = &iStack_1c;
    uStack_4c = 0xc254dd;
    iVar4 = FUN_00774a90();
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pcStack_3c = (char *)0xc25507;
      iVar4 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcStack_3c = (char *)0xc25516;
        iVar4 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 27684 ; VA 0x00c25530 ; FUN_00c25530 */

void FUN_00c25530(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c287a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27685 ; VA 0x00c25570 ; FUN_00c25570 */

void FUN_00c25570(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c28850();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27686 ; VA 0x00c255b0 ; FUN_00c255b0 */

void FUN_00c255b0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018073b7;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dfe420);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_0fc3f939b443872a6ba5005968484ed2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27687 ; VA 0x00c25720 ; FUN_00c25720 */

void FUN_00c25720(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018073e7;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0054ef60(iVar2 + 0x18);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005509f0();
        FUN_01674ea0(iVar2,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfe340);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_700e143057beebbc462fe99ccf070747>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27688 ; VA 0x00c25880 ; FUN_00c25880 */

void FUN_00c25880(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00c1c5a0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_009468e0();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfe378);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_76020235abc30c4fef1257f19aabbbdf>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27689 ; VA 0x00c259d0 ; FUN_00c259d0 */

void FUN_00c259d0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfe308);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_978bb20d38c3b2032456de99c0bfc493>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27690 ; VA 0x00c25aa0 ; FUN_00c25aa0 */

void FUN_00c25aa0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[3] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      if (param_3 != 1) {
        return;
      }
      FUN_0056b650();
      return;
    }
    if (param_3 == 2) {
      FUN_0056b650();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dfe458);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_9c3f42c61bf532c8b7cc3a8538e22f68>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27691 ; VA 0x00c25b60 ; FUN_00c25b60 */

void FUN_00c25b60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807417;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x34);
      uStack_8 = 0;
      if (iVar1 != 0) {
        FUN_0054ef60(iVar2);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0054f050(iVar2 + 0x18);
        *(undefined *)(iVar1 + 0x30) = *(undefined *)(iVar2 + 0x30);
        *param_2 = iVar1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00c1cbe0();
        FUN_01674ea0(iVar2,0x34);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfe3b0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_be65555de6c1496654f55b59312bea50>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27692 ; VA 0x00c25cc0 ; FUN_00c25cc0 */

int * FUN_00c25cc0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c25da1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c25d16. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dfe4e8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_c16784236eed4848b1ee21d42a5fa80c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 27693 ; VA 0x00c25dc0 ; FUN_00c25dc0 */

void FUN_00c25dc0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807447;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_006511a0();
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dfe490);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_c5bd41bc64d783301f4a93d5e097a254>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27694 ; VA 0x00c25f30 ; FUN_00c25f30 */

void FUN_00c25f30(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_0054ef60(param_1);
      if (param_3 == 1) {
        uVar1 = param_1[5];
        if (0xf < uVar1) {
          iVar2 = *param_1;
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        param_1[4] = 0;
        param_1[5] = 0xf;
        *(undefined *)param_1 = 0;
      }
      return;
    }
    if (param_3 == 2) {
      FUN_00571be0(0);
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dfe3e8);
      piVar4 = (int *)0x0;
      if (iVar2 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_d25b0b49ee1b65008dd24ab7724f31ac>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 27695 ; VA 0x00c26000 ; FUN_00c26000 */

void FUN_00c26000(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180746f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar2 != 0) {
        FUN_0054ef60(iVar3);
        *(undefined4 *)(iVar2 + 0x18) = 0;
        *(undefined4 *)(iVar2 + 0x1c) = 0;
        if (*(int *)(iVar3 + 0x1c) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(iVar3 + 0x1c) + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *(undefined4 *)(iVar2 + 0x18) = *(undefined4 *)(iVar3 + 0x18);
        *(undefined4 *)(iVar2 + 0x1c) = *(undefined4 *)(iVar3 + 0x1c);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0056cac0();
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dfe2d0);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_e509507a5a6e1cf18a8ebe1490b7c5cc>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 27696 ; VA 0x00c26170 ; FUN_00c26170 */

int __thiscall FUN_00c26170(int param_1,int param_2,int *param_3,char param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807490;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar7 = FUN_016dee6d(param_1 + 0xf0);
  if (iVar7 != 0) {
    FUN_016df3c9(iVar7);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_2 == 0) {
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
  }
  else {
    iVar7 = *(int *)(param_2 + 0x124);
    cVar6 = FUN_00adf810();
    if (param_4 == '\0') {
      if (cVar6 != '\0') {
        *(int *)(*(int *)(*(int *)(param_1 + 0x124) + -8) + 0x124) = iVar7;
        *(undefined4 *)(param_2 + 0x124) = 0xffffffff;
        iVar3 = *(int *)(param_1 + 0x124);
        puVar2 = (undefined4 *)(*(int *)(param_1 + 0x120) + iVar7 * 8);
        uVar5 = *puVar2;
        *puVar2 = *(undefined4 *)(iVar3 + -8);
        *(undefined4 *)(iVar3 + -8) = uVar5;
        uVar5 = puVar2[1];
        puVar2[1] = *(undefined4 *)(iVar3 + -4);
        *(undefined4 *)(iVar3 + -4) = uVar5;
        piVar4 = *(int **)(*(int *)(param_1 + 0x124) + -4);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar7 = piVar4[1] + -1;
          piVar4[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar7 = piVar4[2] + -1;
            piVar4[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        *(int *)(param_1 + 0x124) = *(int *)(param_1 + 0x124) + -8;
      }
    }
    else if (cVar6 == '\0') {
      *(int *)(param_2 + 0x124) = *(int *)(param_1 + 0x124) - *(int *)(param_1 + 0x120) >> 3;
      piVar4 = *(int **)(param_1 + 0x124);
      if (*(int **)(param_1 + 0x128) == piVar4) {
        FUN_00ba09b0(piVar4,&param_2);
      }
      else {
        *piVar4 = 0;
        piVar4[1] = 0;
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        *piVar4 = param_2;
        piVar4[1] = (int)param_3;
        *(int *)(param_1 + 0x124) = *(int *)(param_1 + 0x124) + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  iVar7 = FUN_016deec8(param_1 + 0xf0);
  if (iVar7 != 0) {
    iVar7 = FUN_016df3c9(iVar7);
  }
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar3 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 27697 ; VA 0x00c26330 ; FUN_00c26330 */

void FUN_00c26330(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018074b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ef904c);
  uStack_8 = 0;
  iVar3 = FUN_00c1de50(param_1);
  puVar6 = *(undefined4 **)(iVar3 + 0x18);
  puVar1 = *(undefined4 **)(iVar3 + 0x1c);
  *(undefined4 *)(iVar3 + 0x18) = 0;
  *(undefined4 *)(iVar3 + 0x1c) = 0;
  *(undefined4 *)(iVar3 + 0x20) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00c21070(param_1);
  do {
    if (puVar6 == puVar1) {
      FUN_005e6280();
      uStack_8 = 3;
      FUN_01675290(uVar2);
      ExceptionList = pvStack_10;
      return;
    }
    iVar3 = puVar6[1];
    piVar5 = (int *)0x0;
    piVar7 = (int *)0x0;
    if (iVar3 != 0) {
      piVar5 = (int *)(iVar3 + 4);
      iVar3 = *(int *)(iVar3 + 4);
      while (iVar3 != 0) {
        LOCK();
        iVar4 = *piVar5;
        if (iVar3 == iVar4) {
          *piVar5 = iVar3 + 1;
          iVar4 = iVar3;
        }
        UNLOCK();
        if (iVar4 == iVar3) {
          piVar5 = (int *)*puVar6;
          piVar7 = (int *)puVar6[1];
          goto LAB_00c263f9;
        }
        iVar3 = *piVar5;
      }
      piVar5 = (int *)0x0;
      piVar7 = (int *)0x0;
    }
LAB_00c263f9:
    uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 8))(param_1,"Unable to download sound data");
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar3 = piVar7[1] + -1;
      piVar7[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar3 = piVar7[2] + -1;
        piVar7[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    puVar6 = puVar6 + 2;
  } while( true );
}



/* FUNCTION 27698 ; VA 0x00c26480 ; FUN_00c26480 */

int __thiscall FUN_00c26480(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int *piStack_4c;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined *puStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018074d8;
  pvStack_10 = ExceptionList;
  piStack_4c = &iStack_18;
  piStack_50 = &iStack_1c;
  uStack_54 = *(undefined4 *)(param_1 + 0x68);
  uStack_58 = 0xc264b0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_011aeb30();
  if ((iVar3 == 0) && (iStack_18 == 8)) {
    piStack_50 = &uStack_2c;
    uVar4 = 0;
    uStack_14 = 0;
    uStack_54 = 0xc264d1;
    piStack_4c = (int *)param_1;
    iVar3 = FUN_0060dcd0();
    uStack_8 = 0;
    piVar7 = piStack_28;
    if (*(int *)(param_1 + 0x160) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 0x16c);
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x15c) * 4);
    }
    while ((puVar6 != (undefined4 *)0x0 && (uVar4 < param_2))) {
      piStack_4c = (int *)0xc26511;
      iVar3 = FUN_00e38f20();
      if ((char)iVar3 == '\0') {
        piStack_4c = (int *)0xc26521;
        iVar3 = FUN_00e38e00();
        piVar1 = piStack_28;
        iVar5 = iVar3 - iStack_1c;
        uVar4 = uStack_14;
        if (0 < iVar5) {
          puStack_20 = auStack_68;
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
          }
          iVar3 = puVar6[9];
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
            UNLOCK();
            iVar3 = puVar6[9];
          }
          uVar2 = puVar6[8];
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
          }
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
            UNLOCK();
          }
          FUN_00c1a8c0(uStack_2c,piStack_28,uVar2,iVar3,0);
          FUN_0056b650();
          iVar3 = FUN_0151ddd0();
          uVar4 = uStack_14 + iVar5;
          piVar7 = piVar1;
          uStack_14 = uVar4;
        }
      }
      puVar6 = (undefined4 *)*puVar6;
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar1 = piVar7 + 1;
      iVar5 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piStack_4c = (int *)0xc265dd;
        iVar3 = (**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          piStack_4c = (int *)0xc265ec;
          iVar3 = (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 27699 ; VA 0x00c26600 ; FUN_00c26600 */

void __thiscall FUN_00c26600(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (DAT_01ef8f4b != '\0') {
    FUN_016774b0(DAT_01ef8f4b,"SoundService::muteAllChannels(%p)",param_1);
  }
  iVar1 = *(int *)(param_1 + 0x138);
  if (iVar1 != 0) {
    uVar2 = FUN_011b1080(iVar1,param_2);
    FUN_00c1f250(uVar2,"setMute",param_1,iVar1);
    FUN_00c2a130();
  }
  return;
}



/* FUNCTION 27700 ; VA 0x00c26660 ; FUN_00c26660 */

void FUN_00c26660(undefined4 *param_1)

{
  int iVar1;
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807508;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008f7870();
  if (iVar1 != 0) {
    puStack_14 = &uStack_34;
    iStack_30 = param_1[1];
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
      UNLOCK();
      iStack_30 = param_1[1];
    }
    uStack_34 = *param_1;
    uStack_8 = 0;
    FUN_0054ef60();
    if (iStack_30 != 0) {
      LOCK();
      *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    FUN_0054ef60(auStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00c1ad00();
    uStack_8 = 0xffffffff;
    FUN_006511a0();
    FUN_0090ca30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27701 ; VA 0x00c267c0 ; FUN_00c267c0 */

void FUN_00c267c0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  
  switch(param_2) {
  case 1:
    uVar1 = FUN_00c23900();
    FUN_00c26480(uVar1 >> 2);
    return;
  case 2:
    uVar1 = FUN_00c23900();
    FUN_00c26480(uVar1 >> 1);
    return;
  case 3:
    iVar2 = FUN_00c23900();
    FUN_00c26480((uint)(iVar2 * 3) >> 2);
    return;
  case 4:
    uVar3 = FUN_00c23900();
    FUN_00c26480(uVar3);
  }
  return;
}



/* FUNCTION 27702 ; VA 0x00c26840 ; FUN_00c26840 */

void __thiscall FUN_00c26840(char *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *******pppppppuVar8;
  undefined4 *******pppppppuVar9;
  undefined4 ******ppppppuVar10;
  undefined4 *puVar11;
  char *pcStack_ac;
  undefined4 ******ppppppuStack_a8;
  undefined4 ******ppppppuStack_a4;
  undefined4 *****apppppuStack_80 [5];
  uint uStack_6c;
  undefined4 ******appppppuStack_68 [5];
  uint uStack_54;
  undefined4 ******appppppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined uStack_25;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180759e;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ef8f4b != '\0') {
    ppppppuStack_a4 = (undefined4 ******)param_3;
    ppppppuStack_a8 = (undefined4 ******)param_2;
    ExceptionList = &pvStack_10;
    pcStack_ac = param_1;
    FUN_01677490(DAT_01ef8f4b,"SoundService::onServiceProvider(%p, %p, %p)");
  }
  piVar5 = *(int **)(param_1 + 0x148);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0x148);
  }
  uStack_30 = *(undefined4 *)(param_1 + 0x144);
  uStack_8 = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
  }
  piStack_2c = piVar5;
  FUN_0151dac0(uStack_30,piVar5,1,0);
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar7 = piVar5[1] + -1;
    piVar5[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      ppppppuStack_a4 = (undefined4 ******)0xc26905;
      (**(code **)*piVar5)();
      LOCK();
      iVar7 = piVar5[2] + -1;
      piVar5[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        ppppppuStack_a4 = (undefined4 ******)0xc26915;
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  param_1[0x144] = '\0';
  param_1[0x145] = '\0';
  param_1[0x146] = '\0';
  param_1[0x147] = '\0';
  piVar5 = *(int **)(param_1 + 0x148);
  param_1[0x148] = '\0';
  param_1[0x149] = '\0';
  param_1[0x14a] = '\0';
  param_1[0x14b] = '\0';
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar7 = piVar5[1] + -1;
    piVar5[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      ppppppuStack_a4 = (undefined4 ******)0xc26942;
      (**(code **)*piVar5)();
      LOCK();
      iVar7 = piVar5[2] + -1;
      piVar5[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        ppppppuStack_a4 = (undefined4 ******)0xc26952;
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (param_1[0x239] == '\0') {
    ppppppuStack_a4 = (undefined4 ******)&uStack_25;
    param_1[0x239] = '\x01';
    ppppppuStack_a8 = (undefined4 ******)0xc2696f;
    puStack_14 = (undefined4 *)FUN_00c1c010();
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    uStack_24 = 1;
    uStack_8 = 1;
    ppppppuStack_a4 = (undefined4 ******)0xc26990;
    cVar3 = FUN_0168a8f0();
    if (cVar3 == '\0') {
      ppppppuStack_a4 = (undefined4 ******)0xc27012;
      ppppppuStack_a4 = (undefined4 ******)FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      ppppppuStack_a8 = (undefined4 ******)0xc2701c;
      FUN_0054e630();
    }
    uStack_8 = 3;
    ppppppuStack_a4 = (undefined4 ******)0xc269a7;
    FUN_016899e0();
    uStack_8 = 4;
    ppppppuStack_a4 = (undefined4 ******)0xc269b6;
    FUN_016899e0();
    puVar6 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      iVar7 = puStack_14[1] + -1;
      puStack_14[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        ppppppuStack_a4 = (undefined4 ******)0x0;
        ppppppuStack_a8 = (undefined4 ******)0xc269ce;
        (**(code **)*puStack_14)();
        ppppppuStack_a8 = (undefined4 ******)puVar6;
        pcStack_ac = (char *)0x0;
        uVar4 = GetProcessHeap();
        HeapFree(uVar4);
      }
    }
    uStack_8._0_1_ = 0xff;
    uStack_8._1_3_ = 0xffffff;
  }
  if (*(int *)(param_1 + 0xe4) != 0) {
    ppppppuStack_a4 = (undefined4 ******)0x0;
    ppppppuStack_a8 = (undefined4 ******)0x0;
    pcStack_ac = (char *)0xc269f8;
    FUN_008a65e0();
    param_1[0xe4] = '\0';
    param_1[0xe5] = '\0';
    param_1[0xe6] = '\0';
    param_1[0xe7] = '\0';
    piVar5 = *(int **)(param_1 + 0xe8);
    param_1[0xe8] = '\0';
    param_1[0xe9] = '\0';
    param_1[0xea] = '\0';
    param_1[0xeb] = '\0';
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar7 = piVar5[1] + -1;
      piVar5[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        ppppppuStack_a4 = (undefined4 ******)0xc26a25;
        (**(code **)*piVar5)();
        LOCK();
        iVar7 = piVar5[2] + -1;
        piVar5[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppppppuStack_a4 = (undefined4 ******)0xc26a35;
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if (param_2 != (undefined4 *)0x0) {
    ppppppuStack_a4 = (undefined4 ******)0xc26a46;
    FUN_01679490();
    ppppppuStack_a4 = (undefined4 ******)0xc26a4d;
    FUN_00c1f9d0();
  }
  if (*(int *)(param_1 + 0x198) == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = *(undefined4 **)(*(int *)(param_1 + 0x1a4) + *(int *)(param_1 + 0x194) * 4);
  }
  do {
    if (puVar6 == (undefined4 *)0x0) {
      if (*(int *)(param_1 + 0x198) != 0) {
        ppppppuStack_a4 = (undefined4 ******)0x0;
        ppppppuStack_a8 =
             (undefined4 ******)(*(int *)(param_1 + 0x1a4) + *(int *)(param_1 + 0x194) * 4);
        pcStack_ac = (char *)0xc26c33;
        FUN_008ca4e0();
        puVar11 = *(undefined4 **)(param_1 + 0x1a4);
        puVar6 = puVar11 + *(int *)(param_1 + 0x194);
        for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
          *puVar11 = 0;
        }
      }
      iVar7 = (int)param_3;
      ppppppuStack_a4 = (undefined4 ******)param_3;
      ppppppuStack_a8 = (undefined4 ******)param_2;
      pcStack_ac = (char *)0xc26c5b;
      FUN_008a4210();
      if (iVar7 != 0) {
        if ((param_1[0x234] != '\0') && (param_1[0x235] == '\0')) {
          ppppppuStack_a4 = (undefined4 ******)0xc26c7c;
          FUN_00c27030();
        }
        ppppppuStack_a4 = (undefined4 ******)0x130;
        ppppppuStack_a8 = (undefined4 ******)0xc26c86;
        puVar6 = (undefined4 *)FUN_01674e20();
        uStack_8 = 9;
        param_2 = puVar6;
        if (puVar6 == (undefined4 *)0x0) {
          ppppppuStack_a8 = (undefined4 ******)0x0;
        }
        else {
          ppppppuStack_a8 = (undefined4 ******)0xc26c9f;
          ppppppuStack_a4 = (undefined4 ******)param_1;
          iVar7 = FUN_008f7870();
          if (iVar7 == 0) {
            iVar7 = 0;
          }
          else {
            iVar7 = iVar7 + 0x10;
          }
          ppppppuStack_a4 = (undefined4 ******)0x4;
          FUN_00944080(&pcStack_ac,iVar7);
          FUN_00a360a0("Sound",1,0);
          *puVar6 = RBX::Soundscape::SoundJob::vftable;
          puVar6[0x4a] = param_1;
          ppppppuStack_a8 = (undefined4 ******)puVar6;
        }
        ppppppuStack_a4 = (undefined4 ******)param_2;
        uStack_8 = 0xffffffff;
        iStack_20 = 0;
        piStack_1c = (int *)0x0;
        pcStack_ac = (char *)0xc26cff;
        FUN_00c1b6a0();
        *(int *)(param_1 + 0x144) = iStack_20;
        piVar5 = *(int **)(param_1 + 0x148);
        *(int **)(param_1 + 0x148) = piStack_1c;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar7 = piVar5[1] + -1;
          piVar5[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppppppuStack_a4 = (undefined4 ******)0xc26d2a;
            (**(code **)*piVar5)();
            LOCK();
            iVar7 = piVar5[2] + -1;
            piVar5[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26d3a;
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (*(int *)(param_1 + 0x148) != 0) {
          LOCK();
          piVar5 = (int *)(*(int *)(param_1 + 0x148) + 4);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
        }
        ppppppuStack_a8 = *(undefined4 *******)(param_1 + 0x144);
        ppppppuStack_a4 = *(undefined4 *******)(param_1 + 0x148);
        pcStack_ac = (char *)0xc26d70;
        FUN_0151d950();
        if (DAT_01d68480 != '\0') {
          ppppppuStack_a8 = (undefined4 ******)&uStack_30;
          pcStack_ac = (char *)0xc26d8a;
          ppppppuStack_a4 = (undefined4 ******)param_1;
          FUN_0060e0c0();
          uStack_8 = 10;
          ppppppuStack_a4 = (undefined4 ******)0xc26d99;
          puStack_14 = (undefined4 *)FUN_0153c830();
          piVar5 = piStack_2c;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[2] = piStack_2c[2] + 1;
            UNLOCK();
          }
          uStack_38 = uStack_30;
          piStack_34 = piStack_2c;
          ppppppuStack_a4 = (undefined4 ******)DAT_02110da8;
          uStack_8._0_1_ = 0xc;
          ppppppuStack_a8 = (undefined4 ******)0xc26dbf;
          uVar4 = FUN_01675290();
          ppppppuStack_a8 = (undefined4 ******)0x20;
          uStack_8._0_1_ = 0xd;
          pcStack_ac = (char *)0xc26dcf;
          piStack_1c = (int *)uVar4;
          puStack_18 = (undefined4 *)FUN_01674e20();
          if (puStack_18 == (undefined4 *)0x0) {
            puStack_18 = (undefined4 *)0x0;
          }
          else {
            *puStack_18 = 0;
            puStack_18[1] = 1;
            puStack_18[2] = FUN_00c20ab0;
            puStack_18[3] = FUN_005d3660;
            puStack_18[4] = 0;
            puStack_18[5] = puStack_14;
            puStack_18[6] = 0;
            puStack_18[7] = 0;
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[2] = piVar5[2] + 1;
              UNLOCK();
            }
            puStack_18[6] = uStack_30;
            puStack_18[7] = piVar5;
          }
          ppppppuStack_a8 = (undefined4 ******)0xc26e2d;
          ppppppuStack_a4 = (undefined4 ******)puStack_18;
          FUN_016797d0();
          param_2 = puStack_18;
          if (puStack_18 != (undefined4 *)0x0) {
            LOCK();
            puStack_18[1] = puStack_18[1] + 1;
            UNLOCK();
          }
          uStack_24 = uStack_24 | 8;
          uStack_8._0_1_ = 0xe;
          ppppppuStack_a8 = (undefined4 ******)0xc26e51;
          ppppppuStack_a4 = (undefined4 ******)uVar4;
          FUN_01675290();
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          ppppppuStack_a4 = (undefined4 ******)&param_2;
          ppppppuStack_a8 = (undefined4 ******)0xc26e67;
          cVar3 = FUN_01679300();
          if (cVar3 != '\0') {
            ppppppuStack_a4 = (undefined4 ******)0xc26e76;
            FUN_01679490();
            ppppppuStack_a4 = (undefined4 ******)&param_2;
            ppppppuStack_a8 = (undefined4 ******)0xc26e85;
            FUN_016791c0();
          }
          if (param_2 != (undefined4 *)0x0) {
            piVar1 = param_2 + 1;
            LOCK();
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              ppppppuStack_a4 = (undefined4 ******)param_2;
              ppppppuStack_a8 = (undefined4 ******)0xc26ea5;
              FUN_01674ea0();
            }
          }
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar7 = piVar5[2] + -1;
            piVar5[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26ebc;
              (**(code **)(*piVar5 + 4))();
            }
          }
          uStack_8 = 0xffffffff;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar7 = piVar5[2] + -1;
            piVar5[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26ed7;
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        ppppppuStack_a4 = (undefined4 ******)0xc26edf;
        param_2 = (undefined4 *)FUN_006fb410();
        if (param_2 != (undefined4 *)0x0) {
          ppppppuStack_a4 = (undefined4 ******)0x68;
          ppppppuStack_a8 = (undefined4 ******)0xc26ef1;
          puVar6 = (undefined4 *)FUN_01674e20();
          param_3 = puVar6;
          if (puVar6 == (undefined4 *)0x0) {
            puVar6 = (undefined4 *)0x0;
          }
          else {
            ppppppuStack_a4 = (undefined4 ******)0x5c;
            pcStack_ac = (char *)(puVar6 + 3);
            puVar6[1] = 1;
            ppppppuStack_a8 = (undefined4 ******)0x0;
            puVar6[2] = 1;
            *puVar6 = std::_Ref_count_obj<struct_RBX::Soundscape::SoundServiceStats>::vftable;
            FUN_0170d1f0();
            FUN_016dee4c(puVar6 + 0xe,2);
          }
          *(undefined4 **)(param_1 + 0x288) = puVar6 + 3;
          piVar5 = *(int **)(param_1 + 0x28c);
          *(undefined4 **)(param_1 + 0x28c) = puVar6;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar7 = piVar5[1] + -1;
            piVar5[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26f5b;
              (**(code **)*piVar5)();
              LOCK();
              iVar7 = piVar5[2] + -1;
              piVar5[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                ppppppuStack_a4 = (undefined4 ******)0xc26f6b;
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          ppppppuStack_a8 = (undefined4 ******)&uStack_38;
          pcStack_ac = (char *)0xc26f75;
          ppppppuStack_a4 = (undefined4 ******)param_1;
          puVar6 = (undefined4 *)FUN_00c1ff50();
          uVar4 = *puVar6;
          uVar2 = puVar6[1];
          *puVar6 = 0;
          puVar6[1] = 0;
          *(undefined4 *)(param_1 + 0xe4) = uVar4;
          piVar5 = *(int **)(param_1 + 0xe8);
          *(undefined4 *)(param_1 + 0xe8) = uVar2;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar7 = piVar5[1] + -1;
            piVar5[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26faf;
              (**(code **)*piVar5)();
              LOCK();
              iVar7 = piVar5[2] + -1;
              piVar5[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                ppppppuStack_a4 = (undefined4 ******)0xc26fbf;
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          piVar5 = piStack_34;
          if (piStack_34 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_34[1] + -1;
            piStack_34[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppppuStack_a4 = (undefined4 ******)0xc26fd5;
              (**(code **)*piStack_34)();
              LOCK();
              piVar1 = piVar5 + 2;
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                ppppppuStack_a4 = (undefined4 ******)0xc26fe4;
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          ppppppuStack_a4 = (undefined4 ******)0x0;
          ppppppuStack_a8 = (undefined4 ******)param_2;
          pcStack_ac = (char *)0xc26ff4;
          FUN_008a65e0();
        }
      }
      ExceptionList = pvStack_10;
      return;
    }
    pppppppuVar9 = (undefined4 *******)(puVar6 + 2);
    ppppppuStack_a4 = (undefined4 ******)(puVar6 + 8);
    ppppppuStack_a8 = appppppuStack_50;
    pcStack_ac = (char *)0xc26a81;
    ppppppuStack_a4 = (undefined4 ******)FUN_0151a8d0();
    uStack_8 = 5;
    ppppppuStack_a8 = (undefined4 *******)0xc26a94;
    FUN_0054f050();
    uStack_8._0_1_ = 7;
    if (7 < uStack_3c) {
      ppppppuStack_a4 = (undefined4 ******)(uStack_3c * 2 + 2);
      pppppppuVar8 = (undefined4 *******)appppppuStack_50[0];
      if (0xfff < ppppppuStack_a4) {
        pppppppuVar8 = (undefined4 *******)appppppuStack_50[0][-1];
        ppppppuStack_a4 = (undefined4 ******)(uStack_3c * 2 + 0x25);
        if (0x1f < (uint)((int)appppppuStack_50[0] + (-4 - (int)pppppppuVar8))) goto LAB_00c2701c;
      }
      pcStack_ac = (char *)0xc26acf;
      ppppppuStack_a8 = pppppppuVar8;
      FUN_01674ea0();
    }
    uStack_40 = 0;
    uStack_3c = 7;
    appppppuStack_50[0] = (undefined4 ******)((uint)appppppuStack_50[0] & 0xffff0000);
    iStack_20 = 0;
    ppppppuStack_a4 = (undefined4 ******)0xc26aee;
    piStack_1c = (int *)FUN_01685730();
    ppppppuStack_a4 = (undefined4 ******)&iStack_20;
    ppppppuStack_a8 = apppppuStack_80;
    pcStack_ac = (char *)&uStack_38;
    piVar5 = (int *)FUN_0168e1c0();
    piStack_2c = (int *)piVar5[1];
    if (((*piVar5 != 0) && (*piVar5 != 1)) && (iStack_20 == 0)) {
      ppppppuStack_a4 = (undefined4 ******)&iStack_20;
      ppppppuStack_a8 = apppppuStack_80;
      pcStack_ac = (char *)0xc26b35;
      FUN_0168da40();
      if ((iStack_20 != 0) && (DAT_01d84e8d != '\0')) {
        ppppppuStack_a4 = (undefined4 ******)iStack_20;
        ppppppuStack_a8 = appppppuStack_68;
        pcStack_ac = (char *)0xc26b59;
        (**(code **)(*piStack_1c + 8))();
        uStack_24 = uStack_24 | 2;
        uStack_8._0_1_ = 8;
        ppppppuStack_a4 = appppppuStack_68;
        if (0xf < uStack_54) {
          ppppppuStack_a4 = appppppuStack_68[0];
        }
        if (0xf < (uint)puVar6[7]) {
          pppppppuVar9 = (undefined4 *******)*pppppppuVar9;
        }
        pcStack_ac = "Failed to remove stream cache file for sound id %s: %s";
        ppppppuStack_a8 = pppppppuVar9;
        FUN_01677520(DAT_01d84e8d);
        uStack_8._0_1_ = 7;
        if (0xf < uStack_54) {
          ppppppuStack_a4 = (undefined4 ******)(uStack_54 + 1);
          pppppppuVar9 = (undefined4 *******)appppppuStack_68[0];
          if (0xfff < ppppppuStack_a4) {
            pppppppuVar9 = (undefined4 *******)appppppuStack_68[0][-1];
            ppppppuStack_a4 = (undefined4 ******)(uStack_54 + 0x24);
            if (0x1f < (uint)((int)appppppuStack_68[0] + (-4 - (int)pppppppuVar9)))
            goto LAB_00c2701c;
          }
          pcStack_ac = (char *)0xc26bc0;
          ppppppuStack_a8 = pppppppuVar9;
          FUN_01674ea0();
        }
      }
    }
    uStack_8._0_1_ = 0xff;
    uStack_8._1_3_ = 0xffffff;
    if (7 < uStack_6c) {
      ppppppuStack_a4 = (undefined4 ******)(uStack_6c * 2 + 2);
      ppppppuVar10 = (undefined4 ******)apppppuStack_80[0];
      if (0xfff < ppppppuStack_a4) {
        ppppppuVar10 = (undefined4 ******)apppppuStack_80[0][-1];
        ppppppuStack_a4 = (undefined4 ******)(uStack_6c * 2 + 0x25);
        if (0x1f < (uint)((int)apppppuStack_80[0] + (-4 - (int)ppppppuVar10))) {
LAB_00c2701c:
                    /* WARNING: Subroutine does not return */
          ppppppuStack_a4 = (undefined4 ******)&UNK_00c27021;
          FUN_017167a3();
        }
      }
      pcStack_ac = (char *)0xc26c01;
      ppppppuStack_a8 = ppppppuVar10;
      FUN_01674ea0();
    }
    puVar6 = (undefined4 *)*puVar6;
  } while( true );
}



/* FUNCTION 27703 ; VA 0x00c27030 ; FUN_00c27030 */

void __fastcall FUN_00c27030(int param_1)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  undefined4 uStack_8c;
  undefined auStack_88 [44];
  undefined4 uStack_5c;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int iStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018075c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (DAT_01ef8f4b != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ef8f4b,"SoundService::openFmod(%p)",param_1);
  }
  FUN_00c1bbf0(&DAT_01ef98e8,&uStack_11);
  iVar7 = DAT_01ea8528;
  if (DAT_01ea8528 == 0) {
    piVar3 = (int *)FUN_00910d90();
    cStack_18 = '\0';
    iVar7 = *piVar3;
    puStack_1c = (uint *)(iVar7 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ea8528 == 0) {
      FUN_0055e190(&puStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar7,0);
      piVar3 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_24[1] + -1;
        piStack_24[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar7 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    iVar7 = DAT_01ea8528;
    uStack_8 = 2;
    if (cStack_18 != '\0') {
      LOCK();
      uVar5 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar5 & 0x40000000) == 0) && (-0x80000000 < (int)uVar5)) {
        LOCK();
        uVar5 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar5 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
    uStack_8 = 0xffffffff;
  }
  cVar2 = *(char *)(iVar7 + 0xa8);
  FUN_011b27e0(0,DAT_01d683d8);
  FUN_011b27e0(1,DAT_01d683e0);
  FUN_011b27e0(2,DAT_01d683e8);
  FUN_011b27e0(3,DAT_01d683f0);
  FUN_011b27e0(4,DAT_01d683f8);
  FUN_011b27e0(5,DAT_01d68400);
  FUN_011b27e0(6,DAT_01d68408);
  FUN_011b27e0(7,DAT_01d68410);
  FUN_011b27e0(8,DAT_01d68418);
  FUN_011b27e0(10,DAT_01d68420);
  FUN_011b27e0(0xb,DAT_01d68428);
  FUN_011b27e0(0xd,DAT_01d68438);
  FUN_011b27e0(0xc,DAT_01d68448);
  FUN_011b27e0(0xf,DAT_01d684c0);
  if (cVar2 == '\0') {
    FUN_00c24af0();
  }
  else {
    FUN_00c245b0();
  }
  iVar7 = *(int *)(param_1 + 0x68);
  *(undefined *)(param_1 + 0x235) = 1;
  if (iVar7 != 0) {
    FUN_0170d1f0(auStack_88,0,0x5c);
    uStack_8c = 0x60;
    FUN_011ae400(iVar7,&uStack_8c);
    uStack_5c = 500;
    FUN_011af310(*(undefined4 *)(param_1 + 0x68),&uStack_8c);
    if ((DAT_01d80f04 != '\0') && (DAT_01d684a8 != '\0')) {
      FUN_0153c480(param_1,FUN_00c267c0);
    }
  }
  *(undefined *)(param_1 + 100) = 1;
  FUN_00650440(param_1 + 0x58);
  uVar8 = 0;
  uStack_8 = 3;
  uVar5 = (uint)((int)puStack_28 + (3 - (int)puStack_2c)) >> 2;
  if (puStack_28 < puStack_2c) {
    uVar5 = 0;
  }
  puVar6 = puStack_2c;
  if (uVar5 != 0) {
    do {
      (**(code **)(*(int *)*puVar6 + 0xc))();
      uVar8 = uVar8 + 1;
      puVar6 = puVar6 + 1;
      param_1 = iStack_20;
    } while (uVar8 != uVar5);
  }
  *(undefined *)(param_1 + 100) = 0;
  if (puStack_2c != (undefined4 *)0x0) {
    uVar5 = (int)piStack_24 - (int)puStack_2c & 0xfffffffc;
    puVar6 = puStack_2c;
    if (0xfff < uVar5) {
      puVar6 = (undefined4 *)puStack_2c[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)puStack_2c + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27704 ; VA 0x00c27340 ; FUN_00c27340 */

int __thiscall FUN_00c27340(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018075f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
    FUN_016756b0(auStack_1c,"SoundService:PlayLocalSound SoundService is not initialized.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  if ((*(int *)(iVar2 + 0x4a0) != 1) && (*(int *)(iVar2 + 0x4a0) != 3)) {
    FUN_016756b0(auStack_1c,"SoundService:PlayLocalSound only works on a client.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00add460();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      uVar4 = FUN_0060dcd0(auStack_18,param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iVar2 = FUN_00c1ece0(uVar4);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar3 = *piVar1;
        iVar2 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar3 = *piVar1;
          iVar2 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            iVar2 = (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar1 = param_3 + 1;
        iVar3 = *piVar1;
        iVar2 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar2 = (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            iVar2 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar2;
    }
  }
  FUN_016756b0(auStack_1c,"SoundService:PlayLocalSound expects a Sound object.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 27705 ; VA 0x00c274c0 ; FUN_00c274c0 */

void __thiscall FUN_00c274c0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  
  *(undefined *)(param_1 + 100) = 1;
  puVar1 = *(undefined4 **)(param_1 + 0x5c);
  if (*(undefined4 **)(param_1 + 0x60) == puVar1) {
    FUN_00595d30(puVar1,&param_2);
  }
  else {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + 4;
  }
  if (*(char *)(param_1 + 0x235) != '\0') {
    (**(code **)(*param_2 + 0xc))();
  }
  *(undefined *)(param_1 + 100) = 0;
  return;
}



/* FUNCTION 27706 ; VA 0x00c27510 ; FUN_00c27510 */

void __thiscall FUN_00c27510(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(param_1 + 0x23c);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  piVar1 = *(int **)(param_1 + 0x270);
  piVar3 = *(int **)(param_1 + 0x26c);
  if (piVar3 != piVar1) {
    do {
      if (*piVar3 == param_2) break;
      piVar3 = piVar3 + 1;
    } while (piVar3 != piVar1);
    if (piVar3 != piVar1) {
      FUN_0170cc70(piVar3,piVar3 + 1,(int)piVar1 - (int)(piVar3 + 1));
      *(int *)(param_1 + 0x270) = *(int *)(param_1 + 0x270) + -4;
    }
  }
  uStack_8 = 0;
  iVar2 = FUN_016deec8(param_1 + 0x23c);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27707 ; VA 0x00c275c0 ; FUN_00c275c0 */

void __fastcall FUN_00c275c0(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807610;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016dee6d(param_1 + 0x1f0);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iVar4 = *(int *)(param_1 + 0x220);
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x224) - iVar4 >> 2 != 0) {
    uVar8 = 0;
    do {
      piVar6 = *(int **)(param_1 + 0x1c0);
      uVar1 = *(undefined4 *)(uVar8 * 4 + iVar4);
      piVar2 = *(int **)(param_1 + 0x1c4);
      if (piVar6 == piVar2) {
LAB_00c2771f:
        uVar8 = uVar8 + 1;
      }
      else {
        do {
          iVar7 = *piVar6 + 0x28;
          iVar4 = FUN_016dee6d(iVar7);
          if (iVar4 != 0) {
            FUN_016df3c9(iVar4);
          }
          uStack_8._0_1_ = 1;
          cVar3 = FUN_00c21fb0(*(undefined4 *)(*piVar6 + 8),uVar1);
          if (cVar3 != '\0') {
            FUN_00c279c0(*piVar6);
            if (DAT_01d68458 != '\0') {
              iVar4 = *(int *)(param_1 + 0x224);
              puVar5 = (undefined4 *)(*(int *)(param_1 + 0x220) + uVar8 * 4);
              uVar1 = *puVar5;
              *puVar5 = *(undefined4 *)(iVar4 + -4);
              *(undefined4 *)(iVar4 + -4) = uVar1;
              *(int *)(param_1 + 0x224) = *(int *)(param_1 + 0x224) + -4;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            iVar4 = FUN_016deec8(iVar7);
            if (iVar4 != 0) {
              FUN_016df3c9(iVar4);
            }
            uStack_8 = uStack_8 & 0xffffff00;
            if (DAT_01d68458 != '\0') goto LAB_00c27725;
            goto LAB_00c2771f;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          iVar4 = FUN_016deec8(iVar7);
          if (iVar4 != 0) {
            FUN_016df3c9(iVar4);
          }
          piVar6 = piVar6 + 2;
          uStack_8 = uStack_8 & 0xffffff00;
        } while (piVar6 != piVar2);
        uVar8 = uVar8 + 1;
      }
LAB_00c27725:
      iVar4 = *(int *)(param_1 + 0x220);
    } while (uVar8 < (uint)(*(int *)(param_1 + 0x224) - iVar4 >> 2));
  }
  if (DAT_01d68458 == '\0') {
    *(int *)(param_1 + 0x224) = iVar4;
  }
  uStack_8 = 4;
  iVar4 = FUN_016deec8(param_1 + 0x1f0);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27708 ; VA 0x00c27790 ; FUN_00c27790 */

void __thiscall FUN_00c27790(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  undefined4 uStack_64;
  uint uStack_60;
  undefined auStack_5c [48];
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807638;
  pvStack_10 = ExceptionList;
  iVar8 = param_1 + 0x1f0;
  ExceptionList = &pvStack_10;
  iStack_24 = iVar8;
  iStack_18 = param_1;
  iVar6 = FUN_016dee6d(iVar8);
  if (iVar6 != 0) {
    FUN_016df3c9(iVar6);
  }
  iVar6 = *(int *)(param_1 + 0x220);
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = *(undefined4 *)(*param_2 + 0x60);
  if (*(int *)(param_1 + 0x224) - iVar6 >> 2 != 0) {
    do {
      iVar2 = uStack_20 * 4;
      cStack_11 = '\0';
      cVar5 = FUN_00c21fb0(uStack_1c,*(undefined4 *)(iVar2 + iVar6));
      if (cVar5 != '\0') {
        uStack_84 = 0;
        piStack_80 = (int *)0x0;
        uStack_7c = uStack_1c;
        uStack_8._0_1_ = 1;
        uStack_78 = 0;
        FUN_0054ef60(*param_2 + 0x18);
        FUN_016dee4c(auStack_5c,2);
        uStack_2c = 0;
        piStack_28 = (int *)0x0;
        uStack_8._0_1_ = 2;
        FUN_00c279c0(&uStack_84);
        iVar6 = *(int *)(param_1 + 0x224);
        cStack_11 = '\x01';
        uVar3 = *(undefined4 *)(*(int *)(iStack_18 + 0x220) + iVar2);
        *(undefined4 *)(*(int *)(iStack_18 + 0x220) + iVar2) = *(undefined4 *)(iVar6 + -4);
        *(undefined4 *)(iVar6 + -4) = uVar3;
        *(int *)(iStack_18 + 0x224) = *(int *)(iStack_18 + 0x224) + -4;
        if (DAT_01d68450 != '\0') {
          FUN_00c1cdd0();
          break;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_00e39150();
        piVar4 = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_28[1] + -1;
          piStack_28[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar6 = *piVar1 + -1;
            *piVar1 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_016dedfb(auStack_5c);
        if (0xf < uStack_60) {
          uVar9 = uStack_60 + 1;
          uVar7 = uStack_74;
          if (0xfff < uVar9) {
            uVar7 = *(uint *)(uStack_74 - 4);
            uVar9 = uStack_60 + 0x24;
            if (0x1f < (uStack_74 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,uVar9);
        }
        uStack_64 = 0;
        uStack_60 = 0xf;
        uStack_74 = uStack_74 & 0xffffff00;
        if (piStack_80 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_80[2] + -1;
          piStack_80[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_80 + 4))();
          }
        }
        uStack_8 = uStack_8 & 0xffffff00;
        param_1 = iStack_18;
      }
      uVar7 = uStack_20 + 1;
      if (cStack_11 != '\0') {
        uVar7 = uStack_20;
      }
      iVar6 = *(int *)(param_1 + 0x220);
      uStack_20 = uVar7;
    } while (uVar7 < (uint)(*(int *)(param_1 + 0x224) - iVar6 >> 2));
  }
  uStack_8 = 4;
  iVar8 = FUN_016deec8(iVar8);
  if (iVar8 != 0) {
    FUN_016df3c9(iVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27709 ; VA 0x00c279c0 ; FUN_00c279c0 */

void FUN_00c279c0(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180766b;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FMODParseError",0xe);
  uStack_8 = 0;
  FUN_008783f0(auStack_38,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar3 = uStack_24 + 1;
    uVar2 = auStack_38[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_38[0] - 4);
      uVar3 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_14 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_011afab0(*(undefined4 *)(param_1 + 8),&uStack_14,&uStack_20,&uStack_1c,&uStack_18);
  FUN_0151f6f0(0xffffffff,0,0);
  puVar4 = (undefined4 *)(param_1 + 0x10);
  uStack_8 = 1;
  if (0xf < *(uint *)(param_1 + 0x24)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151f850("assetId",puVar4);
  FUN_0151f9c0("fmodSoundType",uStack_14);
  uVar1 = DAT_01ef8f5c;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("FMODParseErrorInfo",0x12);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01520d20(auStack_50,uVar1,0);
  if (0xf < uStack_3c) {
    uVar3 = uStack_3c + 1;
    uVar2 = auStack_50[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_50[0] - 4);
      uVar3 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27710 ; VA 0x00c27b60 ; FUN_00c27b60 */

void FUN_00c27b60(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0151f850("assetId",param_1);
  uVar1 = DAT_01ef8f54;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("SoundAssetsOfInterest",0x15);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27711 ; VA 0x00c27c40 ; FUN_00c27c40 */

void FUN_00c27c40(byte *param_1)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  byte *pbVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  byte ****ppppbVar8;
  uint uVar9;
  bool bVar10;
  byte ***apppbStack_2c [4];
  uint uStack_1c;
  uint uStack_18;
  byte ***pppbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807690;
  pvStack_10 = ExceptionList;
  if (DAT_01d68390 == '\0') {
    if (DAT_01d68398 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_00c27b60(param_1);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    uVar9 = 0;
    ExceptionList = &pvStack_10;
    if (DAT_01d683b0 != 0) {
      do {
        uVar7 = DAT_01d683b0;
        pppbStack_14 = (byte ***)&DAT_01d683a0;
        if (0xf < DAT_01d683b4) {
          pppbStack_14 = (byte ***)DAT_01d683a0;
        }
        if ((uVar9 < DAT_01d683b0) &&
           (iVar3 = FUN_0170db20((int)pppbStack_14 + uVar9,0x2c,DAT_01d683b0 - uVar9), iVar3 != 0))
        {
          iVar3 = iVar3 - (int)pppbStack_14;
        }
        else {
          iVar3 = -1;
        }
        uStack_1c = 0;
        uStack_18 = 0xf;
        apppbStack_2c[0] = (byte ***)((uint)apppbStack_2c[0] & 0xffffff00);
        if (iVar3 == -1) {
          if (uVar9 <= uVar7) {
            iVar3 = -1;
            if (uVar7 - uVar9 != -1) {
              iVar3 = uVar7 - uVar9;
            }
            puVar5 = &DAT_01d683a0;
            if (0xf < DAT_01d683b4) {
              puVar5 = DAT_01d683a0;
            }
            FUN_005542c0((int)puVar5 + uVar9,iVar3);
            uStack_8 = 0;
            cVar2 = FUN_00558b30(param_1,apppbStack_2c);
            if (cVar2 != '\0') {
              FUN_00c27b60(param_1);
            }
            FUN_005507b0();
            ExceptionList = pvStack_10;
            return;
          }
LAB_00c27e98:
          FUN_00554050();
          pcVar1 = (code *)swi(3);
          (*pcVar1)();
          return;
        }
        if (uVar7 < uVar9) goto LAB_00c27e98;
        uVar6 = iVar3 - uVar9;
        if (uVar7 - uVar9 < iVar3 - uVar9) {
          uVar6 = uVar7 - uVar9;
        }
        puVar5 = &DAT_01d683a0;
        if (0xf < DAT_01d683b4) {
          puVar5 = DAT_01d683a0;
        }
        FUN_005542c0((int)puVar5 + uVar9,uVar6);
        ppppbVar8 = apppbStack_2c;
        if (0xf < uStack_18) {
          ppppbVar8 = (byte ****)apppbStack_2c[0];
        }
        pppbStack_14 = apppbStack_2c[0];
        uVar9 = *(uint *)(param_1 + 0x10);
        uStack_8 = 1;
        pbVar4 = param_1;
        if (0xf < *(uint *)(param_1 + 0x14)) {
          pbVar4 = *(byte **)param_1;
        }
        if (uVar9 == uStack_1c) {
          while (uVar7 = uVar9 - 4, 3 < uVar9) {
            if (*(byte ****)pbVar4 != *ppppbVar8) goto LAB_00c27d56;
            pbVar4 = pbVar4 + 4;
            ppppbVar8 = ppppbVar8 + 1;
            uVar9 = uVar7;
          }
          if (uVar7 == 0xfffffffc) {
LAB_00c27d8a:
            uVar9 = 0;
          }
          else {
LAB_00c27d56:
            bVar10 = *pbVar4 < *(byte *)ppppbVar8;
            if ((*pbVar4 == *(byte *)ppppbVar8) &&
               ((uVar7 == 0xfffffffd ||
                ((bVar10 = pbVar4[1] < *(byte *)((int)ppppbVar8 + 1),
                 pbVar4[1] == *(byte *)((int)ppppbVar8 + 1) &&
                 ((uVar7 == 0xfffffffe ||
                  ((bVar10 = pbVar4[2] < *(byte *)((int)ppppbVar8 + 2),
                   pbVar4[2] == *(byte *)((int)ppppbVar8 + 2) &&
                   ((uVar7 == 0xffffffff ||
                    (bVar10 = pbVar4[3] < *(byte *)((int)ppppbVar8 + 3),
                    pbVar4[3] == *(byte *)((int)ppppbVar8 + 3))))))))))))) goto LAB_00c27d8a;
            uVar9 = -(uint)bVar10 | 1;
          }
          if (uVar9 == 0) {
            FUN_00c27b60(param_1);
          }
        }
        uVar9 = iVar3 + 1;
        uStack_8 = 0xffffffff;
        if (0xf < uStack_18) {
          uVar7 = uStack_18 + 1;
          ppppbVar8 = (byte ****)pppbStack_14;
          if (0xfff < uVar7) {
            ppppbVar8 = (byte ****)pppbStack_14[-1];
            uVar7 = uStack_18 + 0x24;
            if ((byte *)0x1f < (byte *)((int)pppbStack_14 + (-4 - (int)ppppbVar8))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppbVar8,uVar7);
        }
      } while (uVar9 < DAT_01d683b0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27712 ; VA 0x00c27ea0 ; FUN_00c27ea0 */

void FUN_00c27ea0(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018076d0;
  pvStack_10 = ExceptionList;
  if (DAT_01d683c8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_016dee92(&DAT_01ef90a0);
    if ((iVar2 != 0) && (iVar2 != 3)) {
      FUN_016df3c9(iVar2);
    }
    bVar5 = iVar2 != 0;
    if (((DAT_01d683d0 == '\0') || (!bVar5)) && (iVar2 = FUN_016deec8(&DAT_01ef90a0), iVar2 != 0)) {
      FUN_016df3c9(iVar2);
    }
    iVar2 = DAT_01d633dc;
    iVar3 = GetCurrentThreadId();
    if ((bVar5) || (iVar2 != iVar3)) {
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      puVar4 = (undefined4 *)FUN_01675640(auStack_28,&DAT_018bed68,iVar2);
      uStack_8._0_1_ = 1;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("mainThreadId",puVar4);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      puVar4 = (undefined4 *)FUN_01675640(auStack_28,&DAT_018bed68,iVar3);
      uStack_8._0_1_ = 2;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("currentThreadId",puVar4);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      puVar4 = (undefined4 *)FUN_01675640(auStack_28,&DAT_018bed68,bVar5);
      uStack_8._0_1_ = 3;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("isLocked",puVar4);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      puVar4 = (undefined4 *)FUN_01675640(auStack_28,&DAT_018bed68,param_1);
      uStack_8._0_1_ = 4;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0151f850("callsiteId",puVar4);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
      uVar1 = DAT_01ef8f60;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("FMODInitThreading",0x11);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_01520d20(auStack_28,uVar1,0);
      FUN_005507b0();
      FUN_0151f7f0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27713 ; VA 0x00c28090 ; FUN_00c28090 */

undefined __thiscall FUN_00c28090(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(param_1 + 0x23c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  piVar1 = *(int **)(param_1 + 0x26c);
  piVar2 = *(int **)(param_1 + 0x270);
  uStack_8 = 0;
  piVar4 = piVar1;
  if (piVar1 == piVar2) {
LAB_00c28104:
    if (DAT_01d6d070 <= (uint)((int)piVar2 - (int)piVar1 >> 2)) {
      uVar5 = 0;
      goto LAB_00c28132;
    }
    if (*(int **)(param_1 + 0x274) == piVar2) {
      FUN_006030d0(piVar2,&param_2);
    }
    else {
      *piVar2 = param_2;
      *(int *)(param_1 + 0x270) = *(int *)(param_1 + 0x270) + 4;
    }
  }
  else {
    do {
      if (*piVar4 == param_2) break;
      piVar4 = piVar4 + 1;
    } while (piVar4 != piVar2);
    if (piVar4 == piVar2) goto LAB_00c28104;
  }
  uVar5 = 1;
LAB_00c28132:
  uStack_8 = 1;
  iVar3 = FUN_016deec8(param_1 + 0x23c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 27714 ; VA 0x00c28170 ; FUN_00c28170 */

void FUN_00c28170(void)

{
  FUN_00c1e060();
  return;
}



/* FUNCTION 27715 ; VA 0x00c28180 ; FUN_00c28180 */

void FUN_00c28180(void)

{
  FUN_00c1e0e0();
  return;
}



/* FUNCTION 27716 ; VA 0x00c28190 ; FUN_00c28190 */

void __fastcall FUN_00c28190(int param_1)

{
  uint uVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uVar1 = *(uint *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_40 = uVar1;
    if ((uVar1 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = param_1 + 0x70;
      uStack_50 = 0xc281f9;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(param_1 + 0x70);
      uStack_34 = *(undefined4 *)(param_1 + 0x74);
      uStack_30 = *(undefined4 *)(param_1 + 0x78);
      uStack_2c = *(undefined4 *)(param_1 + 0x7c);
      uStack_28 = *(undefined8 *)(param_1 + 0x80);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar1 = *(uint *)(param_1 + 0x48);
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(param_1 + 0x50);
      uStack_54 = *(undefined4 *)(param_1 + 0x54);
      uStack_50 = *(undefined4 *)(param_1 + 0x58);
      iStack_4c = *(int *)(param_1 + 0x5c);
      uStack_48 = *(ulonglong *)(param_1 + 0x60);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00c239f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27717 ; VA 0x00c28270 ; FUN_00c28270 */

void __fastcall FUN_00c28270(int param_1)

{
  int iVar1;
  float fVar2;
  int iStack_10;
  int iStack_c;
  float fStack_8;
  
  if (*(int *)(param_1 + 0x68) != 0) {
    fVar2 = (float)DAT_01d68338;
    fStack_8 = 0.0;
    iStack_c = FUN_011ae4c0(*(int *)(param_1 + 0x68),0,0,0,0,&fStack_8);
    if ((iStack_c == 0) && (DAT_018daf54 <= fStack_8)) {
      iVar1 = FUN_011ae9b0(*(undefined4 *)(param_1 + 0x68),&iStack_c);
      if ((iVar1 == 0) && (iStack_c != 0)) {
        iStack_10 = 0;
        iVar1 = FUN_011b1a30(iStack_c,&iStack_10);
        if (iVar1 == 0) {
          iVar1 = (int)(((float)iStack_10 * fVar2) / fStack_8);
          if (DAT_01d68310 < iVar1) {
            iVar1 = DAT_01d68310;
          }
          if (iVar1 != iStack_10) {
            FUN_011b1af0(iStack_c,iVar1);
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 27718 ; VA 0x00c28330 ; FUN_00c28330 */

void __thiscall FUN_00c28330(int param_1,int *param_2)

{
  if (DAT_01ef8f4b != '\0') {
    FUN_016774b0(DAT_01ef8f4b,"SoundService::setAmbientReverb(%p)",param_1);
  }
  if (*param_2 != *(int *)(param_1 + 0xec)) {
    *(int *)(param_1 + 0xec) = *param_2;
    FUN_008a4940(&DAT_01ef9178);
    FUN_00c2a130();
  }
  return;
}



/* FUNCTION 27719 ; VA 0x00c28380 ; FUN_00c28380 */

void __thiscall FUN_00c28380(int param_1,char param_2)

{
  *(char *)(param_1 + 0x234) = param_2;
  if (param_2 == '\0') {
    if (*(char *)(param_1 + 0x235) != '\0') {
      FUN_00c1f9d0();
    }
  }
  else if (*(char *)(param_1 + 0x235) == '\0') {
    FUN_00c27030();
    return;
  }
  return;
}



/* FUNCTION 27720 ; VA 0x00c283b0 ; FUN_00c283b0 */

int __thiscall FUN_00c283b0(int param_1,int param_2,int *param_3,int *param_4)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_40 [12];
  int *apiStack_34 [3];
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807708;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_14 = param_1;
  if (((param_3 == (int *)0x0) ||
      (iVar5 = param_3[1] - *param_3 >> 0x1f, (param_3[1] - *param_3) / 0xd0 + iVar5 == iVar5)) &&
     (param_2 != 0)) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(apiStack_34,"SoundService:SetListener called with an incorrect argument.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(apiStack_34,&DAT_01c17198);
  }
  if (param_2 == 1) {
    ExceptionList = &pvStack_10;
    FUN_006d07c0(param_3);
    uStack_8._0_1_ = 1;
    iVar5 = *piStack_28;
    iVar3 = FUN_00b00260();
    if (iVar5 != iVar3) {
      FUN_016756b0(apiStack_34,
                   "SoundService:SetListener value given is not a valid CFrame when given Enum.ListenerType.CFrame"
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(apiStack_34,&DAT_01c17198);
    }
    iVar5 = *piStack_28;
    iVar3 = FUN_00b00260();
    if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = piStack_28 + 2;
    if (piStack_28[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar5 = piVar4[1];
    iVar3 = piVar4[2];
    iVar1 = piVar4[3];
    *(int *)(iStack_14 + 0x88) = *piVar4;
    *(int *)(iStack_14 + 0x8c) = iVar5;
    *(int *)(iStack_14 + 0x90) = iVar3;
    *(int *)(iStack_14 + 0x94) = iVar1;
    iVar5 = piVar4[5];
    iVar3 = piVar4[6];
    iVar1 = piVar4[7];
    *(int *)(iStack_14 + 0x98) = piVar4[4];
    *(int *)(iStack_14 + 0x9c) = iVar5;
    *(int *)(iStack_14 + 0xa0) = iVar3;
    *(int *)(iStack_14 + 0xa4) = iVar1;
    iVar5 = piVar4[9];
    iVar3 = piVar4[10];
    iVar1 = piVar4[0xb];
    *(int *)(iStack_14 + 0xa8) = piVar4[8];
    *(int *)(iStack_14 + 0xac) = iVar5;
    *(int *)(iStack_14 + 0xb0) = iVar3;
    *(int *)(iStack_14 + 0xb4) = iVar1;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  else {
    if ((param_2 != 2) && (ExceptionList = &pvStack_10, param_2 != 3)) goto LAB_00c2857f;
    ExceptionList = &pvStack_10;
    FUN_006d07c0(param_3);
    uStack_8._0_1_ = 4;
    iVar5 = *apiStack_34[0];
    iVar3 = FUN_0088cdc0();
    if (iVar5 != iVar3) {
      FUN_016756b0(auStack_40,"SoundService:SetListener value given is not a valid instance");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
    iVar5 = *apiStack_34[0];
    iVar3 = FUN_0088cdc0();
    if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = apiStack_34[0] + 2;
    if (apiStack_34[0][1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar5 = piVar4[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = piVar4[1];
    }
    iStack_24 = *piVar4;
    uStack_8._0_1_ = 6;
    iStack_20 = iVar5;
    iStack_1c = FUN_0170d75d(iStack_24,0,&RBX::Instance::RTTI_Type_Descriptor,
                             &RBX::IHasLocation::RTTI_Type_Descriptor,0);
    if (iStack_1c == 0) {
      iStack_1c = 0;
      iVar5 = 0;
    }
    else if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 7;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    iStack_18 = iVar5;
    if (iStack_1c == 0) {
      uStack_8._0_1_ = uVar2;
      FUN_016756b0(auStack_40,"SoundService:SetListener value given does not have a location");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
    }
    *(int *)(iStack_14 + 0xb8) = iStack_1c;
    piVar4 = *(int **)(iStack_14 + 0xbc);
    *(int *)(iStack_14 + 0xbc) = iVar5;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    FUN_00550b30();
    FUN_00550b30();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
  }
  FUN_00577b20();
LAB_00c2857f:
  *(int *)(iStack_14 + 0x84) = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar4 = param_4 + 1;
    iVar5 = *piVar4;
    param_2 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      param_2 = (**(code **)*param_4)();
      LOCK();
      piVar4 = param_4 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        param_2 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 27721 ; VA 0x00c28650 ; FUN_00c28650 */

void __thiscall FUN_00c28650(uint param_1,undefined4 param_2)

{
  undefined4 uStack_8;
  
  if (*(int *)(param_1 + 0x138) != 0) {
    uStack_8 = param_1 & 0xffffff;
    FUN_011b08a0(*(int *)(param_1 + 0x138),(int)&uStack_8 + 3);
    if (uStack_8._3_1_ == '\0') {
      FUN_011b1200(*(undefined4 *)(param_1 + 0x138),param_2);
    }
  }
  return;
}



/* FUNCTION 27722 ; VA 0x00c286a0 ; FUN_00c286a0 */

void __thiscall FUN_00c286a0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x80) != param_2) {
    *(char *)(param_1 + 0x80) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 27723 ; VA 0x00c286d0 ; FUN_00c286d0 */

void __thiscall FUN_00c286d0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_0086f2f0(3,"Failed to load SoundId %s: %s",param_2,param_3);
  *(undefined *)(param_1 + 0xc) = 1;
  return;
}



/* FUNCTION 27724 ; VA 0x00c28700 ; FUN_00c28700 */

void __thiscall FUN_00c28700(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00fe99b0(param_2,*param_4,param_4[1]);
  *(undefined *)(param_1 + 0xd) = 1;
  return;
}



/* FUNCTION 27725 ; VA 0x00c28750 ; FUN_00c28750 */

void __thiscall FUN_00c28750(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c28850();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 27726 ; VA 0x00c287a0 ; FUN_00c287a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c287a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807736;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9b94) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef9b94);
    if (DAT_01ef9b94 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ListenerType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef9b30 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ListenerType>::vftable;
      FUN_009caf20(&DAT_01d68590,4);
      FUN_016f3654(&LAB_01893870);
      FUN_016f37bf(&DAT_01ef9b94);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef9b30;
}



/* FUNCTION 27727 ; VA 0x00c28850 ; FUN_00c28850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c28850(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807756;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9bfc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef9bfc);
    if (DAT_01ef9bfc == -1) {
      uStack_8 = 0;
      FUN_009ca470("ReverbType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef9b98 = RBX::Reflection::EnumDesc<enum_RBX::Soundscape::ReverbType>::vftable;
      FUN_009caf20(&DAT_01d684d0,0x18);
      FUN_016f3654(&LAB_01893890);
      FUN_016f37bf(&DAT_01ef9bfc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef9b98;
}



/* FUNCTION 27728 ; VA 0x00c28900 ; FUN_00c28900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c28900(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9c1c) {
    FUN_016f3809(&DAT_01ef9c1c);
    if (DAT_01ef9c1c == -1) {
      _DAT_01ef9c10 = FUN_005c65e0;
      _DAT_01ef9c14 = FUN_005c65e0;
      _DAT_01ef9c18 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef9c1c);
    }
  }
  return &DAT_01ef9c10;
}



/* FUNCTION 27729 ; VA 0x00c28970 ; FUN_00c28970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c28970(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9c0c) {
    FUN_016f3809(&DAT_01ef9c0c);
    if (DAT_01ef9c0c == -1) {
      _DAT_01ef9c00 = FUN_005c65e0;
      _DAT_01ef9c04 = FUN_005c65e0;
      _DAT_01ef9c08 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef9c0c);
    }
  }
  return &DAT_01ef9c00;
}



/* FUNCTION 27730 ; VA 0x00c289e0 ; FUN_00c289e0 */

/* WARNING: Type propagation algorithm not settling */

int FUN_00c289e0(undefined4 param_1,int *param_2,int param_3,int param_4,int *param_5,int *param_6,
                int *******param_7,int *param_8,undefined4 param_9,int *param_10)

{
  int iVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *******pppppppiVar8;
  int *******pppppppiVar9;
  uint uVar10;
  undefined auStack_1c4 [4];
  undefined4 uStack_1c0;
  undefined *puStack_1bc;
  undefined *puStack_1b8;
  int iStack_1b4;
  int iStack_1b0;
  int aiStack_1ac [5];
  undefined4 uStack_198;
  int iStack_194;
  int iStack_190;
  undefined auStack_18c [8];
  undefined4 uStack_184;
  int *piStack_180;
  int *******pppppppiStack_17c;
  int *******pppppppiStack_178;
  int *******pppppppiStack_174;
  int *******pppppppiStack_170;
  undefined2 auStack_164 [8];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 *******apppppppuStack_14c [4];
  undefined4 uStack_13c;
  uint uStack_138;
  int iStack_134;
  undefined **appuStack_130 [2];
  int aiStack_128 [2];
  int *piStack_120;
  int *piStack_11c;
  int aiStack_118 [2];
  int *piStack_110;
  uint *puStack_10c;
  int aiStack_108 [2];
  int *piStack_100;
  int *piStack_fc;
  int iStack_f8;
  uint uStack_f4;
  uint uStack_f0;
  undefined4 uStack_e4;
  undefined **ppuStack_e0;
  uint uStack_98;
  undefined4 uStack_88;
  uint uStack_84;
  undefined2 auStack_80 [8];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  int aiStack_58 [2];
  int *******pppppppiStack_50;
  int *piStack_4c;
  int *******pppppppiStack_48;
  int *piStack_44;
  int *******pppppppiStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  int *******pppppppiStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined *puStack_1c;
  char cStack_15;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180784a;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)0x0;
  pppppppiStack_170 = (int *******)DAT_01ef904c;
  uStack_8 = 3;
  pppppppiStack_174 = (int *******)0xc28a19;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_01675290();
  pppppppiStack_170 = (int *******)&pppppppiStack_28;
  pppppppiStack_174 = (int *******)0xc28a30;
  iStack_134 = iVar5;
  FUN_00587490();
  uStack_8._0_1_ = 5;
  if (pppppppiStack_28 == (int *******)0x0) {
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_24[1] + -1;
      piStack_24[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppppppiStack_170 = (int *******)0xc28a51;
        (**(code **)*piStack_24)();
        LOCK();
        iVar1 = piStack_24[2] + -1;
        piStack_24[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pppppppiStack_170 = (int *******)0xc28a62;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    goto LAB_00c291df;
  }
  if ((param_7 == (int *******)0x0) && (param_5 != (int *)0x0)) {
    appuStack_130[0] = &PTR_018be314;
    pppppppiStack_170 = param_7;
    pppppppiStack_174 = (int *******)(appuStack_130 + 1);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_1c = (undefined *)0x1;
    ppuStack_e0 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_e4 = 0x48;
    pppppppiStack_178 = (int *******)0xc28abb;
    FUN_00554f20();
    pppppppiStack_170 = (int *******)0x8;
    uStack_8 = 9;
    *(undefined ***)((int)appuStack_130 + (int)appuStack_130[0][1]) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_134 + (int)appuStack_130[0][1]) = appuStack_130[0][1] + -0x50;
    appuStack_130[1] = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    pppppppiStack_174 = (int *******)0xc28afa;
    piStack_14 = (int *)FUN_01674e20();
    if (piStack_14 == (int *)0x0) {
      iStack_f8 = 0;
    }
    else {
      pppppppiStack_170 = (int *******)0x1;
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      pppppppiStack_174 = (int *******)0xc28b0f;
      uVar6 = FUN_016de181();
      *(undefined4 *)((int)piStack_14 + 4) = uVar6;
      iStack_f8 = (int)piStack_14;
    }
    piStack_120 = aiStack_128;
    piStack_11c = aiStack_128 + 1;
    piStack_110 = aiStack_118;
    puStack_10c = (uint *)(aiStack_118 + 1);
    piStack_100 = aiStack_108;
    piStack_fc = aiStack_108 + 1;
    aiStack_128[1] = 0;
    aiStack_118[1] = 0;
    aiStack_108[1] = 0;
    aiStack_128[0] = 0;
    aiStack_118[0] = 0;
    aiStack_108[0] = 0;
    appuStack_130[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_f4 = 0;
    uStack_f0 = 4;
    uStack_8._0_1_ = 0xb;
    pppppppiStack_170 = *(int ********)(*(int *)(*param_5 + 4) + 0x38 + (int)param_5);
    pppppppiStack_174 = (int *******)0xc28bdf;
    FUN_0056f130();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    iStack_30 = 0;
    uStack_2c = 0xf;
    pppppppiStack_40 = (int *******)((uint)pppppppiStack_40 & 0xffffff00);
    puStack_1c = (undefined *)0x9;
    if (((uStack_f0 & 2) == 0) && (uVar10 = *puStack_10c, uVar10 != 0)) {
      if (uVar10 < uStack_f4) {
        uVar10 = uStack_f4;
      }
      pppppppiStack_174 = (int *******)*piStack_11c;
      pppppppiStack_170 = (int *******)(uVar10 - (int)pppppppiStack_174);
LAB_00c28c4f:
      pppppppiStack_178 = (int *******)0xc28c59;
      FUN_005542c0();
    }
    else if (((uStack_f0 & 4) == 0) && (*piStack_110 != 0)) {
      pppppppiStack_174 = (int *******)*piStack_120;
      pppppppiStack_170 = (int *******)((*piStack_110 - (int)pppppppiStack_174) + *piStack_100);
      goto LAB_00c28c4f;
    }
    pppppppiStack_170 = (int *******)0x24;
    uStack_8 = 0xd;
    pppppppiStack_174 = (int *******)0xc28c67;
    piVar7 = (int *)FUN_01674e20();
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)0x0;
    }
    else {
      piVar7[1] = 1;
      piVar7[2] = 1;
      *piVar7 = (int)std::
                     _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>
                     ::vftable;
      piVar7[7] = 0;
      piVar7[8] = 0;
      piVar7[3] = (int)pppppppiStack_40;
      piVar7[4] = iStack_3c;
      piVar7[5] = iStack_38;
      piVar7[6] = iStack_34;
      pppppppiStack_40 = (int *******)((uint)pppppppiStack_40 & 0xffffff00);
      *(ulonglong *)(piVar7 + 7) = CONCAT44(uStack_2c,iStack_30);
      iStack_30 = 0;
      uStack_2c = 0xf;
    }
    param_7 = (int *******)(piVar7 + 3);
    uStack_20 = 0;
    puStack_1c = (undefined *)0x0;
    piStack_14 = param_8;
    if (param_8 != (int *)0x0) {
      LOCK();
      iVar1 = param_8[1] + -1;
      param_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppppppiStack_170 = (int *******)0xc28ced;
        (**(code **)*param_8)();
        LOCK();
        iVar1 = piStack_14[2] + -1;
        piStack_14[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pppppppiStack_170 = (int *******)0xc28cfe;
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    pppppppiStack_170 = (int *******)0xc28d06;
    FUN_00550b30();
    pppppppiStack_170 = (int *******)0xc28d0e;
    FUN_005507b0();
    uStack_8._0_1_ = 5;
    pppppppiStack_170 = (int *******)0xc28d1d;
    FUN_00570540();
    param_8 = piVar7;
  }
  if ((param_4 == 1) && (param_7 != (int *******)0x0)) {
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    pppppppiStack_174 = param_7;
    pppppppiStack_170 = (int *******)param_8;
    pppppppiStack_178 = (int *******)0xc28d5f;
    cVar4 = FUN_00e38f90();
    if (cVar4 != '\0') goto LAB_00c2918b;
    if (DAT_01d6e7ec < (int)param_7[4]) {
LAB_00c28da6:
      if ((DAT_01d68490 == '\0') || (DAT_01d68498 == '\0')) {
        uStack_70 = 0;
        uStack_6c = 7;
        auStack_80[0] = 0;
        uStack_8._0_1_ = 0xf;
        cStack_15 = '\0';
        if (DAT_01d68490 == '\0') {
          pppppppiStack_170 = (int *******)0x19633fc;
          pppppppiStack_178 = (int *******)aiStack_58;
          pppppppiStack_174 = (int *******)0x1;
          pppppppiStack_17c = (int *******)0xc28f51;
          FUN_0153e080();
          iStack_30 = 0;
          uStack_2c = 0xf;
          pppppppiStack_40 = (int *******)((uint)pppppppiStack_40 & 0xffffff00);
          pppppppiStack_17c = (int *******)&pppppppiStack_40;
          uStack_8._0_1_ = 0x11;
          piStack_180 = (int *)0xc28f70;
          FUN_01531ce0();
          uStack_154 = 0;
          uStack_150 = 7;
          auStack_164[0] = 0;
          uStack_8._0_1_ = 0x12;
          if (iStack_30 != 0) {
            pppppppiVar8 = (int *******)&pppppppiStack_40;
            if (0xf < uStack_2c) {
              pppppppiVar8 = pppppppiStack_40;
            }
            piStack_14 = (int *)((int)pppppppiVar8 + iStack_30);
            pppppppiVar8 = (int *******)&pppppppiStack_40;
            if (0xf < uStack_2c) {
              pppppppiVar8 = pppppppiStack_40;
            }
            pppppppiStack_170 = (int *******)0xc28fbb;
            pppppppiStack_170 = (int *******)FUN_01686580();
            pppppppiStack_174 = (int *******)auStack_164;
            pppppppiStack_178 = (int *******)piStack_14;
            piStack_180 = (int *)0xc28fcc;
            pppppppiStack_17c = pppppppiVar8;
            FUN_01685950();
          }
          pppppppiStack_170 = (int *******)aiStack_58;
          uStack_8._0_1_ = 0x13;
          pppppppiStack_174 = (int *******)0xc28fe2;
          FUN_0054f050();
          pppppppiStack_170 = (int *******)auStack_164;
          uStack_8._0_1_ = 0x14;
          pppppppiStack_174 = (int *******)0xc28ff8;
          pppppppiStack_170 = (int *******)FUN_01686150();
          pppppppiStack_174 = (int *******)0xc29004;
          FUN_0054f050();
          uStack_8._0_1_ = 0x13;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 0x13;
          if (7 < uStack_84) {
            pppppppiStack_170 = (int *******)(uStack_84 * 2 + 2);
            uVar10 = uStack_98;
            if (0xfff < pppppppiStack_170) {
              uVar10 = *(uint *)(uStack_98 - 4);
              pppppppiStack_170 = (int *******)(uStack_84 * 2 + 0x25);
              if (0x1f < (uStack_98 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
                pppppppiStack_170 = (int *******)&UNK_00c29283;
                uStack_8._0_1_ = uVar3;
                FUN_017167a3();
              }
            }
            pppppppiStack_178 = (int *******)0xc29042;
            pppppppiStack_174 = (int *******)uVar10;
            FUN_01674ea0();
          }
          uStack_88 = 0;
          uStack_84 = 7;
          uStack_98 = uStack_98 & 0xffff0000;
          pppppppiStack_170 = (int *******)uStack_13c;
          pppppppiStack_174 = (int *******)apppppppuStack_14c;
          if (7 < uStack_138) {
            pppppppiStack_174 = apppppppuStack_14c[0];
          }
          uStack_8._0_1_ = 0x15;
          pppppppiStack_178 = (int *******)0xc29086;
          FUN_0058ed10();
          pppppppiStack_170 = (int *******)0xc29091;
          FUN_00550800();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
          pppppppiStack_170 = (int *******)0xc290a0;
          FUN_00550800();
          pppppppiStack_170 = (int *******)auStack_80;
          pppppppiStack_174 = (int *******)0xc290a9;
          pppppppiStack_170 = (int *******)FUN_0153ad70();
          piStack_14 = (int *)pppppppiStack_170;
          if (pppppppiStack_170 != (int *******)0x0) {
            pppppppiVar8 = (int *******)param_7[4];
            if ((int ******)0xf < param_7[5]) {
              param_7 = (int *******)*param_7;
            }
            pppppppiStack_178 = (int *******)0x1;
            piStack_180 = (int *)0xc290cb;
            pppppppiStack_17c = param_7;
            pppppppiStack_174 = pppppppiVar8;
            pppppppiVar9 = (int *******)FUN_01719056();
            piStack_180 = piStack_14;
            cStack_15 = pppppppiVar9 == pppppppiVar8;
            uStack_184 = 0xc290d9;
            FUN_01718190();
          }
          pppppppiStack_170 = (int *******)0xc290e4;
          FUN_005507b0();
          uStack_8._0_1_ = 0xf;
          pppppppiStack_170 = (int *******)0xc290f0;
          FUN_00550800();
          cVar4 = cStack_15;
        }
        else {
          pppppppiStack_174 = (int *******)param_7[4];
          if ((int ******)0xf < param_7[5]) {
            param_7 = (int *******)*param_7;
          }
          pppppppiStack_170 = (int *******)auStack_80;
          pppppppiStack_17c = (int *******)0xc28f39;
          pppppppiStack_178 = param_7;
          cVar4 = FUN_00fea6b0();
        }
        if (cVar4 == '\0') {
          pppppppiStack_170 = (int *******)0x1;
          iStack_194 = 0;
          piStack_14 = aiStack_1ac;
          iStack_1b0 = param_3;
          iStack_1b4 = 0xc29172;
          FUN_0054ef60();
          iStack_1b0 = 0xc29179;
          FUN_00c1a790();
          iStack_194 = 0xc29181;
          FUN_0090ca30();
          pppppppiStack_170 = (int *******)0xc29189;
          FUN_00550800();
        }
        else {
          pppppppiStack_170 = (int *******)aiStack_58;
          pppppppiStack_174 = (int *******)0xc29103;
          FUN_005569d0();
          pppppppiStack_170 = (int *******)0x1;
          piStack_14 = &iStack_190;
          uStack_8._0_1_ = 0x16;
          iStack_194 = 0;
          puStack_1c = auStack_1c4;
          FUN_0054ef60(param_3);
          uStack_8._0_1_ = 0x17;
          FUN_0054ef60(aiStack_58);
          uStack_8._0_1_ = 0x16;
          FUN_00c1a400();
          iStack_194 = 0xc29147;
          FUN_0090ca30();
          pppppppiStack_170 = (int *******)0xc2914f;
          FUN_005507b0();
          pppppppiStack_170 = (int *******)0xc29157;
          FUN_00550800();
        }
      }
      else {
        puStack_1c = auStack_18c;
        iStack_190 = param_3;
        iStack_194 = 0xc28dd1;
        FUN_0054ef60();
        if (param_8 != (int *)0x0) {
          LOCK();
          param_8[1] = param_8[1] + 1;
          UNLOCK();
        }
        piStack_4c = param_8;
        pppppppiStack_50 = param_7;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        pppppppiStack_48 = pppppppiStack_28;
        piStack_44 = piStack_24;
        iStack_190 = 0;
        piStack_14 = (int *)&puStack_1b8;
        uStack_8._0_1_ = 0xe;
        puStack_1bc = auStack_68;
        uStack_1c0 = 0xc28e13;
        FUN_0054ef60();
        piVar2 = piStack_14;
        piVar7 = piStack_4c;
        piStack_14[6] = 0;
        piVar2[7] = 0;
        pppppppiVar8 = pppppppiStack_50;
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
        }
        piVar2[7] = (int)piVar7;
        piVar7 = piStack_44;
        piVar2[6] = (int)pppppppiVar8;
        piVar2[8] = 0;
        piVar2[9] = 0;
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
        }
        piVar2[8] = (int)pppppppiStack_48;
        piVar2[9] = (int)piVar7;
        puStack_1bc = (undefined *)0xc28e62;
        FUN_00c1a5e0();
        uStack_8._0_1_ = 5;
        iStack_190 = 0xc28e6e;
        FUN_009468e0();
        iStack_190 = 0xc28e73;
        FUN_0151ddd0();
      }
    }
    else {
      if ((DAT_01d68440 != '\0') && (DAT_01d80f04 != '\0')) {
        pppppppiStack_170 = (int *******)0xc28d97;
        uVar6 = FUN_0153c330();
        switch(uVar6) {
        case 0:
        case 1:
        case 2:
          break;
        default:
          goto LAB_00c28da6;
        }
      }
      pppppppiStack_170 = (int *******)0x1;
      puStack_1c = (undefined *)&iStack_190;
      iStack_194 = param_3;
      uStack_198 = 0xc28e8e;
      FUN_0054ef60();
      if (param_8 != (int *)0x0) {
        LOCK();
        param_8[1] = param_8[1] + 1;
        UNLOCK();
      }
      pppppppiStack_48 = param_7;
      piStack_44 = param_8;
      iStack_194 = 0;
      piStack_14 = &iStack_1b4;
      uStack_8._0_1_ = 0x18;
      puStack_1b8 = auStack_60;
      puStack_1bc = (undefined *)0xc28ebe;
      FUN_0054ef60();
      piVar2 = piStack_14;
      piVar7 = piStack_44;
      piStack_14[6] = 0;
      piVar2[7] = 0;
      pppppppiVar8 = pppppppiStack_48;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      piVar2[7] = (int)piVar7;
      piVar2[6] = (int)pppppppiVar8;
      puStack_1b8 = (undefined *)0xc28eeb;
      FUN_00c1b040();
      uStack_8._0_1_ = 5;
      iStack_194 = 0xc28ef7;
      FUN_0056cac0();
      iStack_194 = 0xc28eff;
      FUN_0090ca30();
    }
  }
  else {
LAB_00c2918b:
    pppppppiStack_170 = (int *******)0x1;
    iStack_194 = 0;
    piStack_14 = aiStack_1ac;
    iStack_1b0 = param_3;
    iStack_1b4 = 0xc291a4;
    FUN_0054ef60();
    iStack_1b0 = 0xc291ab;
    FUN_00c1af10();
    iStack_194 = 0xc291b3;
    FUN_0090ca30();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_24[1] + -1;
    piStack_24[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      pppppppiStack_170 = (int *******)0xc291ca;
      (**(code **)*piStack_24)();
      LOCK();
      iVar1 = piStack_24[2] + -1;
      piStack_24[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        pppppppiStack_170 = (int *******)0xc291db;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
LAB_00c291df:
  pppppppiStack_174 = (int *******)0xc291e5;
  pppppppiStack_170 = (int *******)iVar5;
  iVar5 = FUN_01675290();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar7 = param_2 + 2;
    iVar1 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pppppppiStack_170 = (int *******)0xc291fd;
      iVar5 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar7 = param_6 + 1;
    iVar1 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pppppppiStack_170 = (int *******)0xc29213;
      (**(code **)*param_6)();
      LOCK();
      piVar7 = param_6 + 2;
      iVar1 = *piVar7;
      iVar5 = *piVar7;
      *piVar7 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pppppppiStack_170 = (int *******)0xc29223;
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar7 = param_8 + 1;
    iVar1 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pppppppiStack_170 = (int *******)0xc29239;
      (**(code **)*param_8)();
      LOCK();
      piVar7 = param_8 + 2;
      iVar1 = *piVar7;
      iVar5 = *piVar7;
      *piVar7 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pppppppiStack_170 = (int *******)0xc29249;
        iVar5 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    piVar7 = param_10 + 1;
    iVar1 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      pppppppiStack_170 = (int *******)0xc2925f;
      iVar5 = (**(code **)*param_10)();
      LOCK();
      piVar7 = param_10 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        pppppppiStack_170 = (int *******)0xc2926e;
        iVar5 = (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 27731 ; VA 0x00c292a0 ; FUN_00c292a0 */

void __thiscall FUN_00c292a0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iStack_6c;
  int iStack_68;
  undefined auStack_64 [8];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 **ppuStack_50;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018078a0;
  pvStack_10 = ExceptionList;
  ppuStack_50 = (undefined4 **)DAT_01ef904c;
  uStack_54 = 0xc292ce;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar2 = FUN_01675290();
  ppuStack_50 = (undefined4 **)param_2;
  uStack_8 = 0;
  uStack_54 = 0xc292eb;
  uStack_18 = uVar2;
  iVar3 = FUN_00c1de50();
  puStack_40 = *(undefined4 **)(iVar3 + 0x18);
  puStack_3c = *(undefined4 **)(iVar3 + 0x1c);
  uStack_38 = *(undefined4 *)(iVar3 + 0x20);
  *(undefined4 *)(iVar3 + 0x18) = 0;
  *(undefined4 *)(iVar3 + 0x1c) = 0;
  *(undefined4 *)(iVar3 + 0x20) = 0;
  ppuStack_50 = (undefined4 **)param_2;
  uStack_8._0_1_ = 1;
  uStack_54 = 0xc29325;
  FUN_00c21070();
  ppuStack_50 = &puStack_40;
  puStack_1c = (undefined *)&uStack_58;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_58 = *param_3;
  uStack_54 = param_3[1];
  uStack_5c = param_2;
  uStack_8._0_1_ = 2;
  iStack_6c = 0xc2936b;
  iStack_68 = param_1;
  iStack_6c = FUN_008f7870();
  FUN_005e5de0(auStack_64);
  piStack_20 = &iStack_6c;
  if (*(int *)(param_1 + 0x6c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x6c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_6c = *(int *)(param_1 + 0x68);
  iStack_68 = *(undefined4 *)(param_1 + 0x6c);
  uStack_8._0_1_ = 4;
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_34,param_1);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 6;
  FUN_00c227a0(&iStack_2c,*puVar4,puVar4[1]);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_30[1] + -1;
    piStack_30[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_50 = (undefined4 **)0xc29402;
      (**(code **)*piStack_30)();
      LOCK();
      iVar3 = piStack_30[2] + -1;
      piStack_30[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        ppuStack_50 = (undefined4 **)0xc29412;
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (iStack_2c == 0) {
    puVar4 = puStack_40;
    if (puStack_40 != puStack_3c) {
      do {
        iVar3 = puVar4[1];
        piStack_24 = (int *)0x0;
        piStack_20 = (int *)0x0;
        if (iVar3 != 0) {
          piVar1 = (int *)(iVar3 + 4);
          iVar3 = *(int *)(iVar3 + 4);
          while (iVar3 != 0) {
            LOCK();
            iVar5 = *piVar1;
            if (iVar3 == iVar5) {
              *piVar1 = iVar3 + 1;
              iVar5 = iVar3;
            }
            UNLOCK();
            if (iVar5 == iVar3) {
              piStack_24 = (int *)*puVar4;
              piStack_20 = (int *)puVar4[1];
              break;
            }
            iVar3 = *piVar1;
          }
        }
        piVar1 = piStack_20;
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        if (piStack_24 != (int *)0x0) {
          ppuStack_50 = (undefined4 **)0x1963404;
          uStack_54 = param_2;
          uStack_58 = 0xc294d2;
          (**(code **)(*piStack_24 + 8))();
        }
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar3 = piVar1[1] + -1;
          piVar1[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppuStack_50 = (undefined4 **)0xc294e5;
            (**(code **)*piVar1)();
            LOCK();
            iVar3 = piVar1[2] + -1;
            piVar1[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              ppuStack_50 = (undefined4 **)0xc294f5;
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        puVar4 = puVar4 + 2;
        uVar2 = uStack_18;
      } while (puVar4 != puStack_3c);
    }
  }
  else {
    ppuStack_50 = (undefined4 **)param_2;
    uStack_54 = 0xc29429;
    iVar3 = FUN_00c1d9d0();
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    *(int *)(iVar3 + 0x18) = iStack_2c;
    piVar1 = *(int **)(iVar3 + 0x1c);
    *(int **)(iVar3 + 0x1c) = piStack_28;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        ppuStack_50 = (undefined4 **)0xc29460;
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppuStack_50 = (undefined4 **)0xc29474;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppuStack_50 = (undefined4 **)0xc29516;
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppuStack_50 = (undefined4 **)0xc29525;
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ppuStack_50 = (undefined4 **)0xc2952d;
  FUN_005e6280();
  uStack_8 = 10;
  uStack_54 = 0xc2953a;
  ppuStack_50 = (undefined4 **)uVar2;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27732 ; VA 0x00c29560 ; FUN_00c29560 */

void FUN_00c29560(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018078c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ef904c);
  uStack_8 = 0;
  uStack_1c = uVar2;
  iVar3 = FUN_00c1de50(param_1);
  piVar6 = *(int **)(iVar3 + 0x18);
  piStack_18 = *(int **)(iVar3 + 0x1c);
  *(undefined4 *)(iVar3 + 0x18) = 0;
  *(undefined4 *)(iVar3 + 0x1c) = 0;
  *(undefined4 *)(iVar3 + 0x20) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00c21070(param_1);
  iVar3 = FUN_00c1d7a0(param_1);
  if ((undefined4 *)(iVar3 + 0x18) != param_2) {
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar4,param_2[4]);
  }
  if (piVar6 != piStack_18) {
    do {
      iVar3 = piVar6[1];
      iStack_24 = 0;
      piStack_20 = (int *)0x0;
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        iVar3 = *(int *)(iVar3 + 4);
        while (iVar3 != 0) {
          LOCK();
          iVar5 = *piVar1;
          if (iVar3 == iVar5) {
            *piVar1 = iVar3 + 1;
            iVar5 = iVar3;
          }
          UNLOCK();
          if (iVar5 == iVar3) {
            iStack_24 = *piVar6;
            piStack_20 = (int *)piVar6[1];
            break;
          }
          iVar3 = *piVar1;
        }
      }
      piVar1 = piStack_20;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_24 != 0) {
        FUN_00c253b0(param_1,param_2,&iStack_24);
      }
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar6 = piVar6 + 2;
      uVar2 = uStack_1c;
    } while (piVar6 != piStack_18);
  }
  FUN_005e6280();
  uStack_8 = 3;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27733 ; VA 0x00c296f0 ; FUN_00c296f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c296f0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  float fVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piVar11;
  undefined auStack_b8 [48];
  undefined auStack_88 [12];
  undefined auStack_7c [12];
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  undefined4 uStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018078e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  if ((*(char *)((int)param_1 + 0x236) == '\0') ||
     (ExceptionList = &pvStack_10, *(char *)((int)param_1 + 0x237) == '\0')) goto LAB_00c29b98;
  piStack_14 = (int *)param_1[0xd];
  ExceptionList = &pvStack_10;
  piVar4 = param_1;
  if ((piStack_14 != (int *)0x0) &&
     (ExceptionList = &pvStack_10, piVar4 = piStack_14, piStack_14[0xd] != 0)) {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_005c8ac0();
  }
  piStack_14 = piVar4;
  if ((piStack_14 == (int *)0x0) ||
     (iVar7 = piStack_14[3], iVar5 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) goto LAB_00c299e1;
  FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
  uVar6 = FUN_00560f40();
  piStack_14 = (int *)FUN_008aa140(uVar6);
  if (*piStack_14 == 0) {
    uVar6 = FUN_008aa950();
    piVar4 = (int *)FUN_008a9ba0(&uStack_20,uVar6);
    iVar7 = *piVar4;
    iVar5 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piStack_14 = iVar7;
    piVar4 = (int *)piStack_14[1];
    piStack_14[1] = iVar5;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar7 = piVar4[1] + -1;
      piVar4[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar7 = piVar4[2] + -1;
        piVar4[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar11 = piVar4 + 2;
        iVar7 = *piVar11 + -1;
        *piVar11 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  if ((*piStack_14 == 0) || (iVar7 = (**(code **)(*(int *)(*piStack_14 + 0x144) + 4))(), iVar7 == 0)
     ) goto LAB_00c299e1;
  FUN_00d226b0(&iStack_70);
  switch(param_1[0x21]) {
  case 0:
    piVar4 = (int *)FUN_00d226b0(auStack_b8);
    goto LAB_00c298da;
  case 1:
    iStack_70 = param_1[0x22];
    iStack_6c = param_1[0x23];
    iStack_68 = param_1[0x24];
    iStack_64 = param_1[0x25];
    iStack_60 = param_1[0x26];
    iStack_5c = param_1[0x27];
    iStack_58 = param_1[0x28];
    iStack_54 = param_1[0x29];
    iStack_50 = param_1[0x2a];
    iVar7 = param_1[0x2b];
    iVar5 = param_1[0x2c];
    iStack_44 = param_1[0x2d];
    goto LAB_00c298ed;
  case 2:
    iVar7 = (*(code *)**(undefined4 **)param_1[0x2e])(auStack_b8);
    uStack_4c = *(undefined8 *)(iVar7 + 0x24);
    iStack_44 = *(int *)(iVar7 + 0x2c);
    break;
  case 3:
    piVar4 = (int *)(*(code *)**(undefined4 **)param_1[0x2e])(auStack_b8);
LAB_00c298da:
    iStack_70 = *piVar4;
    iStack_6c = piVar4[1];
    iStack_68 = piVar4[2];
    iStack_64 = piVar4[3];
    iStack_60 = piVar4[4];
    iStack_5c = piVar4[5];
    iStack_58 = piVar4[6];
    iStack_54 = piVar4[7];
    iStack_50 = piVar4[8];
    iVar7 = piVar4[9];
    iVar5 = piVar4[10];
    iStack_44 = piVar4[0xb];
LAB_00c298ed:
    uStack_4c = CONCAT44(iVar5,iVar7);
  }
  cVar3 = FUN_00c1fcc0(&uStack_4c,&fStack_34);
  if (cVar3 != '\0') {
    puVar8 = (undefined4 *)FUN_011612d0(auStack_7c,2);
    uStack_24 = *puVar8;
    uStack_20 = puVar8[1];
    piStack_1c = (int *)puVar8[2];
    cVar3 = FUN_00c1fcc0(&uStack_24,auStack_88);
    if (cVar3 != '\0') {
      FUN_011612d0(&uStack_24,1);
      cVar3 = FUN_00c1fcc0(&uStack_24,auStack_7c);
      if (cVar3 != '\0') {
        piStack_1c = (int *)0x0;
        uStack_20 = 0;
        uStack_24 = 0;
        FUN_00c23020(&iStack_70,param_2,&uStack_24);
        iVar7 = FUN_011af000(param_1[0x1a],0,&fStack_34,&uStack_24,auStack_88,auStack_7c);
        if (iVar7 != 0) {
          FUN_00c1f3a0(iVar7,"set3DListenerAttributes",param_1,param_1[0x1a]);
        }
      }
    }
  }
LAB_00c299e1:
  if (param_1[0x39] != 0) {
    piVar4 = (int *)(param_1[0xa2] + 0x2c);
    piStack_1c = piVar4;
    iVar7 = FUN_016dee6d(piVar4);
    if (iVar7 != 0) {
      FUN_016df3c9(iVar7);
    }
    uStack_8 = 0;
    iVar7 = FUN_011adc40(&uStack_40,&puStack_18,1);
    if (iVar7 == 0) {
      *(undefined4 *)(param_1[0xa2] + 4) = uStack_40;
      *(undefined4 **)(param_1[0xa2] + 8) = puStack_18;
    }
    iVar7 = param_1[0x1a];
    uVar6 = FUN_011aec20(iVar7,&piStack_14);
    param_1 = piStack_28;
    FUN_00c1f250(uVar6,"getVersion",piStack_28,iVar7);
    *(int **)param_1[0xa2] = piStack_14;
    iVar7 = param_1[0xa2];
    *(undefined4 *)(iVar7 + 0x10) = 0;
    *(undefined4 *)(iVar7 + 0xc) = 0;
    piVar11 = (int *)param_1[0x71];
    piVar10 = (int *)param_1[0x70];
    if (piVar10 != piVar11) {
      do {
        if (*(int *)(*piVar10 + 0xc) < 1) {
          *(int *)(iVar7 + 0x10) = *(int *)(iVar7 + 0x10) + 1;
        }
        piVar10 = piVar10 + 2;
      } while (piVar10 != piVar11);
      piVar11 = (int *)piStack_28[0x71];
      param_1 = piStack_28;
    }
    *(int *)(iVar7 + 0xc) = (int)piVar11 - param_1[0x70] >> 3;
    piStack_14 = (int *)(param_1[0xa2] + 0x14);
    if (DAT_01ef8f4b != '\0') {
      FUN_016774b0(DAT_01ef8f4b,"SoundService::getChannelsPlaying(%p)",param_1);
    }
    *piStack_14 = 0;
    piVar11 = (int *)param_1[0x1a];
    if (piVar11 != (int *)0x0) {
      piVar10 = piStack_14;
      piStack_14 = piVar11;
      uVar6 = FUN_011ae620(piVar11,piVar10,0);
      FUN_00c1f3a0(uVar6,"getChannelIsPlaying",param_1,piStack_14);
      piVar11 = (int *)param_1[0x1a];
    }
    piStack_14 = (int *)param_1[0xa2];
    if (piVar11 == (int *)0x0) {
      piStack_14[7] = 0;
      piStack_14[8] = 0;
      piStack_14[9] = 0;
      piStack_14[10] = 0;
      piStack_14[6] = 0;
    }
    else {
      FUN_011ae4c0(piVar11,&fStack_38,&fStack_34,&fStack_30,&fStack_2c,&fStack_3c);
      fVar2 = _DAT_01966080;
      fStack_38 = fStack_38 * _UNK_01966084;
      fStack_34 = fStack_34 * _UNK_01966088;
      fStack_30 = fStack_30 * _UNK_0196608c;
      piStack_14[6] = (int)(fStack_3c * _DAT_01966080);
      piStack_14[7] = (int)fStack_38;
      piStack_14[8] = (int)fStack_34;
      piStack_14[9] = (int)fStack_30;
      piStack_14[10] = (int)(fStack_2c * fVar2);
    }
    uStack_8 = 1;
    iVar7 = FUN_016deec8(piVar4);
    if (iVar7 != 0) {
      FUN_016df3c9(iVar7);
    }
    uStack_8 = 0xffffffff;
  }
LAB_00c29b98:
  FUN_00c22be0();
  FUN_00c2a1f0(param_2);
  FUN_00c2a460(param_2);
  piVar4 = (int *)(param_1[0x4c] - param_1[0x4b] >> 3);
  while (piVar11 = piVar4, piVar4 = (int *)((int)piVar11 + -1), piStack_14 = piVar4,
        -1 < (int)piVar4) {
    puStack_18 = *(undefined4 **)(param_1[0x4b] + (int)piVar4 * 8);
    if (*(char *)((int)puStack_18 + 0xd) != '\0') {
      FUN_00fea2e0(param_2,param_1);
      cVar3 = *(char *)(puStack_18[1] + 0x6c);
      *(undefined *)(puStack_18[1] + 0x6c) = 0;
      if (cVar3 != '\0') {
        *(undefined *)(puStack_18 + 3) = 1;
      }
    }
    if (*(char *)(*(int *)(param_1[0x4b] + (int)piVar4 * 8) + 0xc) != '\0') {
      puVar9 = (undefined4 *)param_1[0x4c];
      puVar8 = (undefined4 *)(param_1[0x4b] + (int)piVar11 * 8);
      puStack_18 = puVar9;
      if (puVar8 != puVar9) {
        do {
          uVar6 = *puVar8;
          uVar1 = puVar8[1];
          *puVar8 = 0;
          puVar8[1] = 0;
          puVar8[-2] = uVar6;
          piVar4 = (int *)puVar8[-1];
          puVar8[-1] = uVar1;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar7 = piVar4[1] + -1;
            piVar4[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar4)();
              LOCK();
              iVar7 = piVar4[2] + -1;
              piVar4[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          puVar8 = puVar8 + 2;
        } while (puVar8 != puStack_18);
        puVar9 = (undefined4 *)piStack_28[0x4c];
        param_1 = piStack_28;
      }
      piVar4 = (int *)puVar9[-1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar7 = piVar4[1] + -1;
        piVar4[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar7 = piVar4[2] + -1;
          piVar4[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      param_1[0x4c] = param_1[0x4c] + -8;
      piVar4 = piStack_14;
    }
  }
  if (((*(char *)((int)param_1 + 0x236) != '\0') && (*(char *)((int)param_1 + 0x237) != '\0')) &&
     (iVar7 = FUN_011af8e0(param_1[0x1a]), iVar7 != 0)) {
    FUN_00c1f3a0(iVar7,"update",param_1,param_1[0x1a]);
  }
  FUN_00c275c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27734 ; VA 0x00c29d20 ; FUN_00c29d20 */

undefined4 __thiscall FUN_00c29d20(int param_1,int param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807910;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ef904c);
  uStack_8 = 0;
  FUN_008e9840(*(undefined4 *)(param_1 + 0x128));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00c296f0(param_2 + 8);
  FUN_008eb130();
  uStack_8 = 2;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 27735 ; VA 0x00c29db0 ; FUN_00c29db0 */

void __thiscall FUN_00c29db0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  
  *(undefined *)(param_1 + 100) = 1;
  piVar1 = *(int **)(param_1 + 0x5c);
  piVar2 = *(int **)(param_1 + 0x58);
  if (piVar2 != piVar1) {
    while ((int *)*piVar2 != param_2) {
      piVar2 = piVar2 + 1;
      if (piVar2 == piVar1) {
        *(undefined *)(param_1 + 100) = 0;
        return;
      }
    }
    if (piVar2 != piVar1) {
      if (*(char *)(param_1 + 0x235) != '\0') {
        (**(code **)(*param_2 + 0x10))();
      }
      FUN_0170cc70(piVar2,piVar2 + 1,*(int *)(param_1 + 0x5c) - (int)(piVar2 + 1));
      *(int *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + -4;
    }
  }
  *(undefined *)(param_1 + 100) = 0;
  return;
}



/* FUNCTION 27736 ; VA 0x00c29e10 ; FUN_00c29e10 */

void __thiscall FUN_00c29e10(int param_1,int param_2,int *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  iVar5 = *(int *)(param_1 + 0x1e8) - *(int *)(param_1 + 0x1e4) >> 3;
  while (iVar4 = iVar5, iVar5 = iVar4 + -1, -1 < iVar5) {
    if (*(int *)(*(int *)(param_1 + 0x1e4) + iVar5 * 8) == param_2) {
      puVar6 = *(undefined4 **)(param_1 + 0x1e8);
      puVar7 = (undefined4 *)(*(int *)(param_1 + 0x1e4) + iVar4 * 8);
      if (puVar7 != puVar6) {
        do {
          uVar1 = *puVar7;
          uVar2 = puVar7[1];
          *puVar7 = 0;
          puVar7[1] = 0;
          puVar7[-2] = uVar1;
          piVar3 = (int *)puVar7[-1];
          puVar7[-1] = uVar2;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          puVar7 = puVar7 + 2;
        } while (puVar7 != puVar6);
        puVar6 = *(undefined4 **)(param_1 + 0x1e8);
      }
      piVar3 = (int *)puVar6[-1];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      *(int *)(param_1 + 0x1e8) = *(int *)(param_1 + 0x1e8) + -8;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 27737 ; VA 0x00c29f20 ; FUN_00c29f20 */

void __fastcall FUN_00c29f20(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (DAT_01ef8f4b != '\0') {
    FUN_016774b0(DAT_01ef8f4b,"SoundService::update3DSettings(%p)",param_1);
  }
  iVar1 = *(int *)(param_1 + 0x68);
  if (iVar1 != 0) {
    uVar2 = FUN_011af1a0(iVar1,*(undefined4 *)(param_1 + 0x74),*(undefined4 *)(param_1 + 0x78),
                         *(undefined4 *)(param_1 + 0x7c));
    FUN_00c1f3a0(uVar2,"set3DSettings",param_1,iVar1);
  }
  return;
}



/* FUNCTION 27738 ; VA 0x00c29f90 ; FUN_00c29f90 */

void __fastcall FUN_00c29f90(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  int iVar7;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807930;
  pvStack_10 = ExceptionList;
  if ((*(char *)(*(int *)(param_1 + 0x78) + 0x236) == '\0') ||
     (*(char *)(*(int *)(param_1 + 0x78) + 0x237) == '\0')) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    ExceptionList = &pvStack_10;
    FUN_005542c0("-disabled-",10);
    uStack_8 = 2;
    *(undefined8 *)(param_1 + 0x58) = 0;
    if ((undefined4 ****)(param_1 + 0x60) != apppuStack_2c) {
      ppppuVar5 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_005542c0(ppppuVar5,uStack_1c);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
      if (0xfff < uVar6) {
        ppppuVar5 = (undefined4 ****)apppuStack_2c[0][-1];
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar6);
    }
  }
  else {
    iVar7 = *(int *)(param_1 + 0xa4) + 0x2c;
    ExceptionList = &pvStack_10;
    iStack_14 = iVar7;
    iVar4 = FUN_016dee6d(iVar7);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
    uStack_8 = 0;
    iVar4 = **(int **)(param_1 + 0xa4);
    FUN_009ffd50(param_1,(double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)],"fmod %08x",iVar4
                );
    iVar4 = *(int *)(param_1 + 0xa4);
    *(undefined4 *)(param_1 + 0x7c) = *(undefined4 *)(iVar4 + 4);
    *(undefined4 *)(param_1 + 0x80) = *(undefined4 *)(iVar4 + 8);
    *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(iVar4 + 0xc);
    *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)(iVar4 + 0x10);
    *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(iVar4 + 0x14);
    uVar1 = *(undefined4 *)(iVar4 + 0x1c);
    uVar2 = *(undefined4 *)(iVar4 + 0x20);
    uVar3 = *(undefined4 *)(iVar4 + 0x24);
    *(undefined4 *)(param_1 + 0x90) = *(undefined4 *)(iVar4 + 0x18);
    *(undefined4 *)(param_1 + 0x94) = uVar1;
    *(undefined4 *)(param_1 + 0x98) = uVar2;
    *(undefined4 *)(param_1 + 0x9c) = uVar3;
    *(undefined4 *)(param_1 + 0xa0) = *(undefined4 *)(iVar4 + 0x28);
    uStack_8 = 1;
    iVar4 = FUN_016deec8(iVar7);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27739 ; VA 0x00c2a130 ; FUN_00c2a130 */

void __fastcall FUN_00c2a130(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined *puVar5;
  int iStack_c;
  char cStack_5;
  
  if (DAT_01ef8f4b != '\0') {
    FUN_016774b0(DAT_01ef8f4b,"SoundService::updateAmbientReverb(%p)",param_1);
  }
  if (*(int *)(param_1 + 0x68) != 0) {
    FUN_005789c0(&DAT_01ef98f0,&LAB_00c23d50);
    if (*(int *)(param_1 + 0x138) == 0) {
      cVar2 = '\0';
    }
    else {
      cStack_5 = '\0';
      iStack_c = 0;
      iVar3 = FUN_011b0ae0(*(int *)(param_1 + 0x138),&iStack_c);
      cVar2 = cStack_5;
      if ((iVar3 == 0) && (iStack_c != 0)) {
        FUN_011b08a0(*(undefined4 *)(param_1 + 0x138),&cStack_5);
        cVar2 = cStack_5;
      }
    }
    uVar1 = *(undefined4 *)(param_1 + 0x68);
    if (cVar2 == '\0') {
      puVar5 = &DAT_01ef9468 + *(int *)(param_1 + 0xec) * 0x30;
    }
    else {
      puVar5 = &DAT_01ef9468;
    }
    uVar4 = FUN_011af640(uVar1,0,puVar5);
    FUN_00c1f3a0(uVar4,"setReverbProperties",param_1,uVar1);
  }
  return;
}



/* FUNCTION 27740 ; VA 0x00c2a1f0 ; FUN_00c2a1f0 */

void __thiscall FUN_00c2a1f0(int param_1,double *param_2)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  float fVar5;
  double dVar6;
  float fStack_c;
  undefined *puStack_8;
  
  if ((*(int *)(param_1 + 0x138) != 0) && (iVar1 = *(int *)(param_1 + 0x230), iVar1 != 0)) {
    if (iVar1 == 2) {
      puStack_8 = &DAT_bf800000;
      FUN_011b0b60(*(int *)(param_1 + 0x138),&puStack_8);
    }
    else {
      iVar2 = FUN_0090c170();
      puStack_8 = *(undefined **)(iVar2 + 0xe4);
    }
    if (0.0 < *(float *)(param_1 + 0x22c)) {
      fVar5 = DAT_018ce2f8;
      if (iVar1 == 2) {
        fVar5 = DAT_018f7864;
      }
      dVar6 = (double)*(float *)(param_1 + 0x22c);
      param_2 = (double *)
                (float)((((dVar6 / (*param_2 * DAT_018c0d70)) * (double)(float)puStack_8) / dVar6) *
                       (double)fVar5);
    }
    else {
      param_2 = (double *)DAT_018ce2f8;
      if (iVar1 == 2) {
        param_2 = (double *)DAT_018f7864;
      }
      fStack_c = DAT_018f7864;
      if (*(int *)(param_1 + 0x138) != 0) {
        FUN_011b0b60(*(int *)(param_1 + 0x138),&fStack_c);
      }
      param_2 = (double *)((float)param_2 * fStack_c);
    }
    if (iVar1 != 2) {
      FUN_00c26600(0);
    }
    iVar2 = *(int *)(param_1 + 0x138);
    fStack_c = DAT_018f7864;
    if (iVar1 == 2) {
      if (iVar2 != 0) {
        FUN_011b0b60(iVar2,&fStack_c);
      }
      bVar4 = fStack_c == DAT_018ce2f0;
      bVar3 = fStack_c < DAT_018ce2f0;
    }
    else {
      if (iVar2 != 0) {
        FUN_011b0b60(iVar2,&fStack_c);
      }
      bVar4 = (float)puStack_8 == fStack_c;
      bVar3 = (float)puStack_8 < fStack_c;
    }
    if (!bVar3 && !bVar4) {
      fStack_c = DAT_018f7864;
      if (*(int *)(param_1 + 0x138) != 0) {
        FUN_011b0b60(*(int *)(param_1 + 0x138),&fStack_c);
      }
      fVar5 = fStack_c + (float)param_2;
      if (DAT_018daf54 <
          (float)(double)CONCAT44((uint)((ulonglong)(double)fVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)fVar5,0) & (uint)DAT_018c0da0)) {
        if (DAT_018fde78 <= fVar5) {
          fVar5 = DAT_018ce2f8;
        }
      }
      else {
        fVar5 = 0.0;
      }
      FUN_00c28650(fVar5);
    }
    param_2 = (double *)&DAT_bf800000;
    if ((*(int *)(param_1 + 0x138) == 0) ||
       (FUN_011b0b60(*(int *)(param_1 + 0x138),&param_2), (float)param_2 <= 0.0)) {
      if (iVar1 == 2) {
        FUN_00c26600(1);
        *(undefined4 *)(param_1 + 0x230) = 0;
        return;
      }
    }
    else if (iVar1 == 2) {
      return;
    }
    param_2 = (double *)DAT_018f7864;
    if (*(int *)(param_1 + 0x138) != 0) {
      FUN_011b0b60(*(int *)(param_1 + 0x138),&param_2);
    }
    if ((float)puStack_8 <= (float)param_2) {
      FUN_00c28650(puStack_8);
      *(undefined4 *)(param_1 + 0x230) = 0;
    }
  }
  return;
}



/* FUNCTION 27741 ; VA 0x00c2a460 ; FUN_00c2a460 */

void __thiscall FUN_00c2a460(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (DAT_01ef8f4a != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ef8f4a,"Number of channels = %d",
                 *(int *)(param_1 + 0x124) - *(int *)(param_1 + 0x120) >> 3);
  }
  if ((DAT_01d668ec != '\0') || (cVar1 = FUN_00fea670(param_1), cVar1 != '\0')) {
    iVar5 = 0;
    iStack_2c = 0;
    iStack_28 = 0;
    iStack_24 = 0;
    iVar3 = param_1 + 0xf0;
    uStack_8 = 0;
    iStack_20 = iVar3;
    iVar2 = FUN_016dee6d(iVar3);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    uStack_8._0_1_ = 1;
    iVar2 = 0;
    if (&iStack_2c != (int *)(param_1 + 0x120)) {
      iStack_14 = *(int *)(param_1 + 0x124);
      iStack_18 = *(int *)(param_1 + 0x120);
      uVar4 = iStack_14 - iStack_18 >> 3;
      if (uVar4 == 0) {
        iVar2 = 0;
        FUN_00602d30(iStack_18,iStack_14,0);
        FUN_005596d0(0,0,&iStack_2c);
        iStack_28 = iVar2;
      }
      else {
        if (0x1fffffff < uVar4) {
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        iStack_2c = 0;
        iStack_28 = 0;
        iStack_24 = 0;
        uVar4 = -(uint)(uVar4 != 0) & uVar4;
        if (uVar4 != 0) {
          if (0x1fffffff < uVar4) {
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          iStack_28 = FUN_00578020(uVar4);
          iStack_24 = iStack_28 + uVar4 * 8;
        }
        iStack_2c = iStack_28;
        iVar2 = FUN_0055c480(iStack_18,iStack_14,iStack_28);
        iVar5 = iStack_2c;
        iStack_28 = iVar2;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar3 = FUN_016deec8(iVar3);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (iVar5 != iVar2) {
      iVar3 = iStack_1c + 0xc0;
      do {
        FUN_00ae1a30(param_2,iVar3);
        iVar5 = iVar5 + 8;
      } while (iVar5 != iVar2);
    }
    FUN_00577ac0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27742 ; VA 0x00c2a600 ; FUN_00c2a600 */

undefined4 * __thiscall
FUN_00c2a600(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807978;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xc2a66d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xc2a6b9);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0196694c;
  cStack_11 = FUN_00c2a8f0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xc2a743);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xc2a77e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xc2a7ac);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27743 ; VA 0x00c2a7d0 ; FUN_00c2a7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c2a7d0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018079b0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef9c24 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef9e38) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef9e38);
      if (DAT_01ef9e38 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SocialService",1,uStack_20,0,0,1,0,0);
        _DAT_01ef9e30 = RBX::Creator<class_RBX::SocialService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef9c28,&DAT_01ef9e30);
        FUN_016f3654(FUN_01893a70);
        FUN_016f37bf(&DAT_01ef9e38);
      }
    }
    DAT_01ef9c24 = &DAT_01ef9c28;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef9c24;
}



/* FUNCTION 27744 ; VA 0x00c2a8d0 ; FUN_00c2a8d0 */

void FUN_00c2a8d0(void)

{
  int iVar1;
  
  if (DAT_01ef9e3c == 0) {
    iVar1 = FUN_00c2a7d0();
    DAT_01ef9e3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 27745 ; VA 0x00c2a8f0 ; FUN_00c2a8f0 */

undefined FUN_00c2a8f0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018079df;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 27746 ; VA 0x00c2aa50 ; FUN_00c2aa50 */

/* WARNING: Restarted to delay deadcode elimination for space: ram */

void FUN_00c2aa50(uint param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined in_stack_00000024;
  undefined4 uStack_298;
  code **ppcStack_294;
  undefined auStack_290 [184];
  undefined4 uStack_1d8;
  undefined *puStack_1d4;
  undefined *puStack_1d0;
  int *piStack_1cc;
  undefined auStack_1b8 [212];
  undefined4 uStack_e4;
  code **ppcStack_e0;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01807a24;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_1cc = (int *)0xc2aa7c;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088daf0();
  auStack_1b8[0] = in_stack_00000024;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8) {
    piStack_1cc = &DAT_01ea8bf8;
    puStack_1d0 = (undefined *)0xc2ac32;
    FUN_016f3809();
    if (DAT_01ea8bf8 == -1) {
      piStack_1cc = &DAT_01ea8bf8;
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      puStack_1d0 = (undefined *)0xc2ac6a;
      FUN_016f37bf();
    }
  }
  piStack_1cc = (int *)auStack_dc;
  puStack_1d0 = auStack_1b8;
  uStack_8._0_1_ = 1;
  ppcStack_e0 = (code **)0x0;
  puStack_1d4 = (undefined *)0xc2aaee;
  uStack_e4 = uVar2;
  (*DAT_01ea8bec)();
  ppcStack_e0 = &DAT_01ea8bec;
  uStack_8._0_1_ = 2;
  if (param_1 == 0) {
    piStack_1cc = (int *)0xc2ac7d;
    piStack_1cc = (int *)FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    puStack_1d0 = &UNK_00c2ac87;
    FUN_0054e5e0();
  }
  puStack_14 = (undefined *)&uStack_298;
  pcVar1 = *(code **)((param_1 & 0xfffffffe) + 4);
  uStack_298 = uStack_e4;
  ppcStack_294 = (code **)0x0;
  (*DAT_01ea8bf0)(auStack_dc,auStack_290);
  ppcStack_294 = ppcStack_e0;
  if (ppcStack_e0 != (code **)0x0) {
    (*ppcStack_e0[2])(auStack_dc);
    ppcStack_e0 = (code **)0x0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_e4 = FUN_00888530();
  if (ppcStack_e0 != (code **)0x0) {
    (*ppcStack_e0[2])(auStack_dc);
    ppcStack_e0 = (code **)0x0;
  }
  uStack_8._0_1_ = 2;
  (*pcVar1)(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  if (ppcStack_e0 != (code **)0x0) {
    piStack_1cc = (int *)auStack_dc;
    puStack_1d0 = (undefined *)0xc2abd1;
    (*ppcStack_e0[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  piStack_1cc = (int *)auStack_1b8;
  puStack_1d0 = (undefined *)0xc2abee;
  (*DAT_01ea8bf4)();
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_1d4 = &stack0x0000000c;
    piStack_1cc = (int *)0x2;
    uStack_1d8 = 0xc2ac15;
    puStack_1d0 = puStack_1d4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 27747 ; VA 0x00c2ac90 ; FUN_00c2ac90 */

undefined4 * __thiscall FUN_00c2ac90(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807a3b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27748 ; VA 0x00c2ad60 ; FUN_00c2ad60 */

undefined4 * __fastcall FUN_00c2ad60(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01807a7e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::SocialService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00c2a7d0();
  param_1[3] = uVar1;
  *param_1 = RBX::SocialService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("SocialService",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 27749 ; VA 0x00c2ae50 ; FUN_00c2ae50 */

void __fastcall FUN_00c2ae50(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_009cb8b0();
  return;
}


