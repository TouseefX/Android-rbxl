/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 8000 ; VA 0x0067ccb0 ; FUN_0067ccb0 */

void FUN_0067ccb0(undefined4 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0067ccbf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*param_1)();
  return;
}



/* FUNCTION 8001 ; VA 0x0067ccd0 ; FUN_0067ccd0 */

int FUN_0067ccd0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    *(undefined4 *)(iStack_18 + 0x3d68) = 2;
    iVar3 = FUN_0067fc40(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 8002 ; VA 0x0067cd60 ; FUN_0067cd60 */

void FUN_0067cd60(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)*param_1;
  (*(code *)*puVar1)(puVar1 + 2,puVar1[4],puVar1[5],puVar1[6],puVar1[7]);
  return;
}



/* FUNCTION 8003 ; VA 0x0067cd90 ; FUN_0067cd90 */

void FUN_0067cd90(undefined4 *param_1)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  code *pcVar4;
  
  uVar3 = param_1[4];
  uVar2 = *(undefined *)(param_1 + 3);
  pcVar4 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(param_1[1],param_1[2],uVar2,uVar3);
  return;
}



/* FUNCTION 8004 ; VA 0x0067cdd0 ; FUN_0067cdd0 */

int FUN_0067cdd0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined2 uVar8;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a1e08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    uVar3 = *(undefined4 *)(param_1 + 8);
    uVar4 = *(undefined4 *)(param_1 + 0x10);
    FUN_005f70a0();
    FUN_005f7140();
    uVar6 = DAT_01d5ae88;
    uVar7 = DAT_01d5ae8c;
    uVar8 = DAT_01d5ae90;
    FUN_005f7170(iStack_1c + 0x74);
    iVar5 = FUN_00681340(uVar3,uVar4,3,0,uVar6,uVar7,uVar8);
    *(undefined *)(iStack_1c + 0x3844) = 0;
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 8005 ; VA 0x0067cea0 ; FUN_0067cea0 */

void FUN_0067cea0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  FUN_0054ef60(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[1],puVar2[2]);
  return;
}



/* FUNCTION 8006 ; VA 0x0067cef0 ; FUN_0067cef0 */

undefined4 __fastcall FUN_0067cef0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x3c1c) >> 8),
                  *(int *)(*(int *)(param_1 + 0x3c1c) + 0x124) == 2);
}



/* FUNCTION 8007 ; VA 0x0067cf10 ; FUN_0067cf10 */

undefined4 __fastcall FUN_0067cf10(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x3c1c) >> 8),
                  *(int *)(*(int *)(param_1 + 0x3c1c) + 0x124) == 1);
}



/* FUNCTION 8008 ; VA 0x0067cf30 ; FUN_0067cf30 */

bool __thiscall FUN_0067cf30(int *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int *piStack_8;
  
  piStack_8 = param_1;
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 == '\0') {
    if ((param_1[0xf03] == 0) && (iVar2 = (**(code **)(*param_1 + 0x278))(param_2), iVar2 == 1)) {
      return false;
    }
    if (param_1[0x685] == 0) {
      if ((param_1[0xee4] != 0) && (cVar1 = FUN_006902e0(param_2,&piStack_8), cVar1 != '\0')) {
        return piStack_8 == (int *)0x0;
      }
    }
    else {
      iVar2 = FUN_00690300(param_2);
      if (iVar2 == 1) {
        return false;
      }
    }
  }
  return true;
}



/* FUNCTION 8009 ; VA 0x0067cfc0 ; FUN_0067cfc0 */

undefined4 __fastcall FUN_0067cfc0(int *param_1)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 != '\0') {
    return 1;
  }
  return 0;
}



/* FUNCTION 8010 ; VA 0x0067cff0 ; FUN_0067cff0 */

bool __thiscall FUN_0067cff0(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = param_2;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00913630();
    if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da)) && (*(int *)(param_1 + 0x3c0c) != iVar4)) {
      return false;
    }
  }
  if (*(int *)(param_1 + 0x1a14) != 0) {
    iVar4 = FUN_00690650(iVar4,param_3);
    return iVar4 == 0;
  }
  if (*(int *)(param_1 + 0x3b90) != 0) {
    cVar2 = FUN_00573f40(iVar4,param_3,&param_2);
    if (cVar2 != '\0') {
      return param_2 == 0;
    }
  }
  return true;
}



/* FUNCTION 8011 ; VA 0x0067d090 ; FUN_0067d090 */

bool __thiscall FUN_0067d090(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined auStack_18 [4];
  int iStack_14;
  int *piStack_10;
  int iStack_c;
  int iStack_8;
  
  uVar2 = param_2;
  if ((param_2 != 0) &&
     (iVar5 = *(int *)(param_2 + 0xc), iVar4 = FUN_00913630(),
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    return false;
  }
  cVar3 = (**(code **)(*param_1 + 0x11c))();
  if (cVar3 == '\0') {
    cVar3 = FUN_006452c0(uVar2);
    if (cVar3 == '\0') {
      return false;
    }
    if ((uVar2 != 0) &&
       (iVar5 = *(int *)(uVar2 + 0xc), iVar4 = FUN_00c37c00(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      return false;
    }
    iVar5 = param_1[0xf03];
    iVar4 = FUN_00676bf0(uVar2);
    if (iVar5 == 0) {
      if ((iVar4 == 0) && (iVar5 = (**(code **)(*param_1 + 0x27c))(uVar2), iVar5 == 1)) {
        return false;
      }
    }
    else if (iVar4 != 0) {
      FUN_00550130("remotePlayer already exists");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_18,&DAT_01c17198);
    }
    if (param_1[0x685] != 0) {
      iStack_8 = 0;
      param_2 = param_2 & 0xffffff;
      iVar5 = FUN_00690930(uVar2,param_3,param_4,(int)&param_2 + 3,&iStack_8);
      if (((iVar5 == 0) && (param_2._3_1_ != '\0')) && (iStack_8 != 0)) {
        iVar4 = *(int *)(uVar2 + 0xc);
        iVar6 = FUN_00c39bb0();
        uVar7 = 0;
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          uVar7 = uVar2;
        }
        FUN_0060e0c0(&iStack_14,uVar7);
        if (piStack_10 != (int *)0x0) {
          LOCK();
          piStack_10[2] = piStack_10[2] + 1;
          UNLOCK();
        }
        *(int *)(iStack_8 + 0x164) = iStack_14;
        piVar1 = *(int **)(iStack_8 + 0x168);
        *(int **)(iStack_8 + 0x168) = piStack_10;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar4 = piVar1[2] + -1;
          piVar1[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        if (piStack_10 != (int *)0x0) {
          LOCK();
          piVar1 = piStack_10 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_10 + 4))();
          }
        }
      }
      return iVar5 != 1;
    }
    if ((param_1[0xee4] != 0) && (cVar3 = FUN_00690910(uVar2,param_3,&iStack_c), cVar3 != '\0')) {
      return iStack_c == 0;
    }
  }
  return true;
}



/* FUNCTION 8012 ; VA 0x0067d290 ; FUN_0067d290 */

undefined4 __thiscall FUN_0067d290(int *param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  if ((param_2 == 0) ||
     (iVar3 = *(int *)(param_2 + 0xc), iVar2 = FUN_00913630(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    if ((DAT_01d5af38 == '\0') || (param_3 != (undefined4 *)&DAT_0212c10c)) {
      cVar1 = (**(code **)(*param_1 + 0x11c))();
      if (cVar1 != '\0') {
        return 1;
      }
      if ((param_1[0xf03] == 0) &&
         (iVar3 = (**(code **)(*param_1 + 0x280))(param_2,param_3), iVar3 == 1)) {
        return 0;
      }
      if (((param_3 != &DAT_01ef0a50) && (param_3 != &DAT_01ef0a88)) && (param_3 != &DAT_01ee5728))
      {
        uVar4 = FUN_00620f80(param_2,param_3);
        return uVar4;
      }
    }
    return 0;
  }
  if (DAT_01d5aeb8 != '\0') {
    return 0;
  }
  if (param_3 == (undefined4 *)&DAT_0211e4e4) {
    return 0;
  }
  if (param_3 == (undefined4 *)&DAT_0211e51c) {
    return 0;
  }
  if (param_3 != (undefined4 *)&DAT_0211a3a0) {
    return 1;
  }
  return 0;
}



/* FUNCTION 8013 ; VA 0x0067d360 ; FUN_0067d360 */

undefined4 __thiscall FUN_0067d360(int *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (((cVar1 == '\0') && (param_1[0x685] != 0)) && (iVar2 = FUN_00554b50(), iVar2 != 0)) {
    return 0;
  }
  if ((param_1[0xf03] == 0) && (iVar2 = (**(code **)(*param_1 + 0x270))(param_2), iVar2 == 1)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 8014 ; VA 0x0067d3b0 ; FUN_0067d3b0 */

int FUN_0067d3b0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  uint3 uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00913630();
  uVar3 = (uint3)(byte)(*(ushort *)(iVar2 + 0x1da) >> 8);
  if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da)) && (param_2 == &DAT_0211f6c8)) {
    return (uint)uVar3 << 8;
  }
  return CONCAT31(uVar3,1);
}



/* FUNCTION 8015 ; VA 0x0067d3f0 ; FUN_0067d3f0 */

undefined __thiscall FUN_0067d3f0(int *param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_3 == (undefined4 *)&DAT_02135700) && (param_2 != 0)) {
    return *(undefined *)(param_2 + 0x3f0);
  }
  if ((param_3 == &DAT_01ee5728) && (param_2 != 0)) {
    iVar3 = *(int *)(param_2 + 0xc);
    iVar1 = FUN_009ec190();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      return *(undefined *)(param_2 + 0xee);
    }
  }
  iVar3 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00913630();
  iVar1 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar1 = param_2;
  }
  if ((iVar1 != 0) &&
     ((((param_3 == (undefined4 *)&DAT_0211e5fc || (param_3 == (undefined4 *)&DAT_0211e634)) ||
       (param_3 == &DAT_0211e968)) ||
      ((param_3 == (undefined4 *)&DAT_0211e9a0 || (param_3 == (undefined4 *)&DAT_0211ed90)))))) {
    iVar3 = (**(code **)(*param_1 + 0xb4))();
    return param_2 != iVar3;
  }
  return false;
}



/* FUNCTION 8016 ; VA 0x0067d4d0 ; FUN_0067d4d0 */

undefined4 __thiscall FUN_0067d4d0(int param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if ((param_3 == &DAT_01eed858) && (param_2 != 0)) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      FUN_00b07ca0(&param_3);
      param_2 = 3;
      cVar2 = FUN_005e0cd0(&param_2);
      if (cVar2 != '\0') {
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01eadcf4) {
          FUN_016f3809(&DAT_01eadcf4);
          if (DAT_01eadcf4 == -1) {
            DAT_01eadcf0 = 0xffffffff;
            FUN_016f37bf(&DAT_01eadcf4);
          }
        }
        param_2 = DAT_01eadcf0;
        cVar2 = FUN_005e0cd0(&param_2);
        if (cVar2 != '\0') {
          param_2 = 1;
          cVar2 = FUN_005e0cd0(&param_2);
          if (cVar2 != '\0') {
            param_2 = 2;
            cVar2 = FUN_005e0cd0(&param_2);
            if (cVar2 != '\0') {
              cVar2 = FUN_005e0cd0(param_1 + 0x94);
              if (cVar2 != '\0') {
                return 1;
              }
            }
          }
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 8017 ; VA 0x0067d600 ; FUN_0067d600 */

/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined FUN_0067d600(char *param_1,int param_2,char *param_3)

{
  undefined4 ******ppppppuVar1;
  undefined4 ******ppppppuVar2;
  undefined4 *****pppppuVar3;
  char *pcVar4;
  char cVar5;
  undefined4 *******pppppppuVar6;
  undefined4 *******pppppppuVar7;
  undefined4 *******pppppppuVar8;
  undefined uVar9;
  char *pcVar10;
  undefined4 ******ppppppuStack_60;
  undefined4 ******ppppppuStack_5c;
  char *pcStack_58;
  undefined4 ******ppppppuStack_54;
  undefined4 *****pppppuStack_44;
  undefined4 *****pppppuStack_40;
  undefined4 uStack_3c;
  undefined4 ******appppppuStack_38 [2];
  char *pcStack_30;
  undefined4 ******appppppuStack_2c [2];
  char *pcStack_24;
  undefined4 ******appppppuStack_20 [2];
  char *pcStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a49d0;
  pvStack_10 = ExceptionList;
  if (((*(int *)(param_1 + 0x10) == 0) || (*(int *)(param_2 + 0x10) == 0)) ||
     (*(int *)(param_3 + 0x10) == 0)) {
    return 0;
  }
  pppppuStack_44 = (undefined4 ******)0x0;
  pppppuStack_40 = (undefined4 ******)0x0;
  uStack_3c = 0;
  uStack_8 = 0;
  if (0xf < *(uint *)(param_3 + 0x14)) {
    param_3 = *(char **)param_3;
  }
  pcVar10 = param_3;
  do {
    cVar5 = *pcVar10;
    pcVar10 = pcVar10 + 1;
  } while (cVar5 != '\0');
  pcVar10 = pcVar10 + -(int)(param_3 + 1);
  appppppuStack_20[0] = (undefined4 *******)0x0;
  pcStack_18 = pcVar10;
  if (&DAT_00000008 < pcVar10) {
    pcStack_58 = (char *)0x67d693;
    ExceptionList = &pvStack_10;
    ppppppuStack_54 = (undefined4 ******)pcVar10;
    pppppppuVar7 = (undefined4 *******)FUN_01674e20();
    appppppuStack_20[0] = pppppppuVar7;
  }
  else {
    pppppppuVar7 = appppppuStack_20;
    ExceptionList = &pvStack_10;
  }
  ppppppuStack_60 = (undefined4 ******)0x67d6a4;
  ppppppuStack_5c = pppppppuVar7;
  pcStack_58 = param_3;
  ppppppuStack_54 = (undefined4 ******)pcVar10;
  FUN_0170cc70();
  ppppppuStack_60 = pppppppuVar7;
  FUN_0063e660(pppppppuVar7,pcStack_18 + (int)pppppppuVar7,
               (int)(pcStack_18 + (int)pppppppuVar7) - (int)pppppppuVar7);
  pcVar10 = pcStack_18;
  pppppppuVar7 = &ppppppuStack_60;
  uStack_8._0_1_ = 1;
  pcStack_30 = pcStack_18;
  appppppuStack_38[0] = (undefined4 *******)0x0;
  if (&DAT_00000008 < pcStack_18) {
    pppppppuVar6 = (undefined4 *******)FUN_01674e20(pcStack_18);
    pppppppuVar8 = (undefined4 *******)appppppuStack_20[0];
    appppppuStack_38[0] = pppppppuVar6;
  }
  else {
    pppppppuVar6 = appppppuStack_38;
    pppppppuVar8 = appppppuStack_20;
  }
  FUN_0170c6f0(pppppppuVar6,pppppppuVar8,pcVar10);
  pcVar10 = pcStack_30;
  uStack_8._0_1_ = 2;
  pcStack_24 = pcStack_30;
  appppppuStack_2c[0] = (undefined4 *******)0x0;
  if (&DAT_00000008 < pcStack_30) {
    pppppppuVar6 = (undefined4 *******)FUN_01674e20(pcStack_30);
    pppppppuVar8 = (undefined4 *******)appppppuStack_38[0];
    appppppuStack_2c[0] = pppppppuVar6;
  }
  else {
    pppppppuVar6 = appppppuStack_2c;
    pppppppuVar8 = appppppuStack_38;
  }
  FUN_0170c6f0(pppppppuVar6,pppppppuVar8,pcVar10);
  pcVar4 = pcStack_24;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  pcStack_58 = pcStack_24;
  ppppppuStack_60 = (undefined4 ******)0x0;
  if (&DAT_00000008 < pcStack_24) {
    pppppppuVar7 = (undefined4 *******)FUN_01674e20(pcStack_24);
    pppppppuVar6 = (undefined4 *******)appppppuStack_2c[0];
    ppppppuStack_60 = pppppppuVar7;
  }
  else {
    pppppppuVar6 = appppppuStack_2c;
  }
  FUN_0170c6f0(pppppppuVar7,pppppppuVar6,pcStack_58);
  ppppppuStack_54 = (undefined4 ******)0x1;
  if ((&DAT_00000008 < pcVar4) &&
     ((undefined4 *******)appppppuStack_2c[0] != (undefined4 *******)0x0)) {
    FUN_01674ea0(appppppuStack_2c[0]);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((&DAT_00000008 < pcVar10) &&
     ((undefined4 *******)appppppuStack_38[0] != (undefined4 *******)0x0)) {
    FUN_01674ea0(appppppuStack_38[0]);
  }
  FUN_0064f4f0(&pppppuStack_44,param_2);
  ppppppuVar1 = (undefined4 ******)pppppuStack_44;
  ppppppuVar2 = (undefined4 ******)pppppuStack_40;
  if ((&DAT_00000008 < pcStack_18) &&
     ((undefined4 *******)appppppuStack_20[0] != (undefined4 *******)0x0)) {
    ppppppuStack_54 = appppppuStack_20[0];
    pcStack_58 = (char *)0x67d7cd;
    FUN_01674ea0();
    ppppppuVar1 = (undefined4 ******)pppppuStack_44;
    ppppppuVar2 = (undefined4 ******)pppppuStack_40;
  }
  do {
    pppppuVar3 = pppppuStack_40;
    if (ppppppuVar1 == (undefined4 ******)pppppuStack_40) {
      uVar9 = 0;
      pppppuStack_40 = ppppppuVar2;
LAB_0067d811:
      ppppppuStack_54 = (undefined4 ******)0x67d819;
      FUN_00577a40();
      ExceptionList = pvStack_10;
      return uVar9;
    }
    pcStack_58 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcStack_58 = *(char **)param_1;
    }
    ppppppuStack_60 = ppppppuVar1;
    if ((undefined4 *****)0xf < ppppppuVar1[5]) {
      ppppppuStack_60 = (undefined4 ******)*ppppppuVar1;
    }
    ppppppuStack_54 = *(undefined4 *******)(param_1 + 0x10);
    ppppppuStack_5c = (undefined4 ******)ppppppuVar1[4];
    pppppuStack_40 = ppppppuVar2;
    cVar5 = FUN_0055c360();
    if (cVar5 != '\0') {
      uVar9 = 1;
      goto LAB_0067d811;
    }
    ppppppuVar1 = ppppppuVar1 + 6;
    ppppppuVar2 = (undefined4 ******)pppppuStack_40;
    pppppuStack_40 = pppppuVar3;
  } while( true );
}



/* FUNCTION 8018 ; VA 0x0067d850 ; FUN_0067d850 */

int __fastcall FUN_0067d850(int param_1)

{
  uint3 uVar1;
  
  uVar1 = (uint3)((uint)*(int *)(param_1 + 0x3c1c) >> 8);
  if ((*(char *)(*(int *)(param_1 + 0x3c1c) + 0x3a5) == '\0') &&
     (*(char *)(param_1 + 0x3c29) != '\0')) {
    return CONCAT31(uVar1,1);
  }
  return (uint)uVar1 << 8;
}



/* FUNCTION 8019 ; VA 0x0067d870 ; FUN_0067d870 */

void __fastcall FUN_0067d870(int param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a49f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_009805c0();
  if ((cVar1 != '\0') && (*(int *)(param_1 + 0x3c0c) != 0)) {
    uStack_8 = 1;
    FUN_0054ef60(param_1 + 0x3c60);
    uStack_8 = 0xffffffff;
    FUN_0092ab80(1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8020 ; VA 0x0067d900 ; FUN_0067d900 */

/* WARNING: Removing unreachable block (ram,0x0067daa8) */
/* WARNING: Removing unreachable block (ram,0x0067dab0) */
/* WARNING: Removing unreachable block (ram,0x0067dac0) */
/* WARNING: Removing unreachable block (ram,0x0067dac7) */
/* WARNING: Removing unreachable block (ram,0x0067dad9) */
/* WARNING: Removing unreachable block (ram,0x0067dad2) */
/* WARNING: Removing unreachable block (ram,0x0067dade) */
/* WARNING: Removing unreachable block (ram,0x0067daf0) */
/* WARNING: Removing unreachable block (ram,0x0067d948) */

undefined * __thiscall
FUN_0067d900(int *param_1,int param_2,int *param_3,undefined *param_4,undefined *param_5)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  undefined *puVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a4a20;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_4 = 0;
  *param_5 = 0;
  puVar4 = param_5;
  piStack_14 = param_1;
  if (param_2 != 0) {
    lVar7 = FUN_00928340();
    puVar4 = (undefined *)lVar7;
    if (0 < lVar7) {
      if (DAT_01d5aee0 == '\0') {
        uStack_8._0_1_ = 1;
        (**(code **)(*(int *)param_1[0xf07] + 0x40))(&piStack_28);
        uStack_8._0_1_ = 2;
        if ((piStack_28 != (int *)0x0) && (iVar6 = *piStack_28, iVar6 != piStack_28[1])) {
          do {
            FUN_00676c60(&piStack_20,iVar6);
            piVar1 = piStack_20;
            uStack_8._0_1_ = 3;
            if ((piStack_20 != (int *)0x0) &&
               ((iVar5 = (**(code **)(*piStack_20 + 0xb8))(), piVar1 != piStack_14 && (iVar5 != 0)))
               ) {
              uVar8 = FUN_00928340();
              uStack_18 = (undefined4)((ulonglong)uVar8 >> 0x20);
              lVar7 = FUN_00928340();
              if (lVar7 == CONCAT44(uStack_18,(int)uVar8)) {
                FUN_005c93e0(&piStack_20);
              }
            }
            piVar1 = piStack_1c;
            uStack_8._0_1_ = 2;
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar5 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)*piStack_1c)();
                LOCK();
                piVar2 = piVar1 + 2;
                iVar5 = *piVar2 + -1;
                *piVar2 = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)(*piVar1 + 4))();
                }
              }
            }
            iVar6 = iVar6 + 8;
          } while (iVar6 != piStack_28[1]);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_24[1] + -1;
          piStack_24[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar6 = piStack_24[2] + -1;
            piStack_24[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
        puVar4 = (undefined *)FUN_00577ac0();
      }
      else {
        pcVar3 = *(code **)(*param_1 + 0xe8);
        uVar8 = FUN_00928340();
        puVar4 = (undefined *)(*pcVar3)(uVar8,param_4,param_5);
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar6 = *piVar1;
    puVar4 = (undefined *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puVar4 = (undefined *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puVar4 = (undefined *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 8021 ; VA 0x0067db10 ; FUN_0067db10 */

/* WARNING: Removing unreachable block (ram,0x0067dd20) */
/* WARNING: Removing unreachable block (ram,0x0067dd30) */
/* WARNING: Removing unreachable block (ram,0x0067dd37) */
/* WARNING: Removing unreachable block (ram,0x0067dd49) */
/* WARNING: Removing unreachable block (ram,0x0067dd42) */
/* WARNING: Removing unreachable block (ram,0x0067dd4e) */

void __thiscall FUN_0067db10(int *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  longlong lVar8;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a4a48;
  pvStack_10 = ExceptionList;
  bVar2 = false;
  bVar1 = false;
  piStack_1c = (int *)0x0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  (**(code **)(*(int *)param_1[0xf07] + 0x40))(&piStack_40);
  iStack_8._0_1_ = 1;
  if ((piStack_40 != (int *)0x0) && (piVar7 = (int *)*piStack_40, piVar7 != (int *)piStack_40[1])) {
    do {
      if ((*piVar7 == 0) ||
         (iVar4 = *(int *)(*piVar7 + 0xc), iVar3 = FUN_005ee350(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
        bVar1 = true;
        piStack_24 = (int *)0x0;
        puVar5 = &uStack_28;
        piStack_1c = (int *)0x0;
      }
      else {
        piStack_2c = (int *)piVar7[1];
        piStack_1c = (int *)*piVar7;
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[1] = piStack_2c[1] + 1;
          UNLOCK();
          piStack_2c = (int *)piVar7[1];
        }
        bVar2 = true;
        puVar5 = &uStack_30;
      }
      piVar6 = (int *)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      piStack_38 = piStack_1c;
      piStack_34 = piVar6;
      piStack_14 = piStack_1c;
      if ((bVar1) && (bVar1 = false, piStack_24 != (int *)0x0)) {
        LOCK();
        iVar4 = piStack_24[1] + -1;
        piStack_24[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_24)();
          piStack_14 = piStack_1c;
          LOCK();
          iVar4 = piStack_24[2] + -1;
          piStack_24[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_24 + 4))();
            piStack_14 = piStack_1c;
          }
        }
      }
      piStack_1c = piStack_14;
      if ((bVar2) && (bVar2 = false, piStack_2c != (int *)0x0)) {
        LOCK();
        iVar4 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_18 = piStack_14;
          (**(code **)*piStack_2c)();
          piStack_18 = piStack_14;
          LOCK();
          iVar4 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
      iStack_8._0_1_ = 2;
      piStack_18 = piStack_14;
      if ((((piStack_1c != (int *)0x0) &&
           (iVar4 = (**(code **)(*piStack_1c + 0xb8))(), piStack_18 != piStack_20)) && (iVar4 != 0))
         && (lVar8 = FUN_00928340(), lVar8 == CONCAT44(param_3,param_2))) {
        FUN_005c93e0(&piStack_38);
        piVar6 = piStack_34;
      }
      iStack_8._0_1_ = 1;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar4 = piVar6[1] + -1;
        piVar6[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar4 = piVar6[2] + -1;
          piVar6[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar7 = piVar7 + 2;
    } while (piVar7 != (int *)piStack_40[1]);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar7 = piStack_3c + 2;
      iVar4 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8022 ; VA 0x0067dd80 ; FUN_0067dd80 */

int * FUN_0067dd80(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = (int *)FUN_006775b0(param_1);
      if (param_3 == 1) {
        piVar2 = *(int **)(param_1 + 0xc);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 1;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(param_1 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0067de24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_00679550(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar3 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d98c20);
      iVar4 = 0;
      if (piVar3 == (int *)0x0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return piVar3;
    }
  }
  *param_2 = (int)&<lambda_c3a78bbcbb07d8039fd2c7e78c5383a2>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 8023 ; VA 0x0067de40 ; FUN_0067de40 */

int * FUN_0067de40(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067def7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067de7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d98be8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_cf474b650956101c6696afc538652f6d>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 8024 ; VA 0x0067df10 ; FUN_0067df10 */

void FUN_0067df10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d98cbc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<int_const&,int_const&_(__cdecl*)(int_const*),class_boost::_bi::list1<class_boost::_bi::value<int_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 8025 ; VA 0x0067df80 ; FUN_0067df80 */

void FUN_0067df80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d98c5c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<unsigned_int_const&,unsigned_int_const&_(__cdecl*)(unsigned_int_const*),class_boost::_bi::list1<class_boost::_bi::value<unsigned_int_const*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 8026 ; VA 0x0067dff0 ; FUN_0067dff0 */

void FUN_0067dff0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x20);
      if (iVar2 != 0) {
        iVar3 = FUN_00677610(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9893c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Network::ServerReplicator>_const&,__int64,__int64),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Network::ServerReplicator>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 8027 ; VA 0x0067e0d0 ; FUN_0067e0d0 */

int * FUN_0067e0d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067e182. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067e10e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d987cc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>),class_boost::_bi::list1<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 8028 ; VA 0x0067e1a0 ; FUN_0067e1a0 */

void FUN_0067e1a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_006776e0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar2,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1d98aac);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Network::ServerReplicator>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Network::ServerReplicator>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 8029 ; VA 0x0067e2f0 ; FUN_0067e2f0 */

int * FUN_0067e2f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      *(undefined *)(param_2 + 3) = *(undefined *)(param_1 + 3);
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067e3ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0067e32e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d98864);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Network::ServerReplicator>,bool,int),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Network::ServerReplicator>_>,class_boost::_bi::value<bool>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 8030 ; VA 0x0067e3d0 ; FUN_0067e3d0 */

void FUN_0067e3d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d98a0c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<bool,class_boost::_mfi::mf0<bool,class_RBX::Network::Replicator>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::Network::ServerReplicator*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 8031 ; VA 0x0067e440 ; FUN_0067e440 */

void __thiscall FUN_0067e440(int param_1,int param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  uint uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_18 = param_3;
  if (param_2 == 0) {
    uStack_c = 0xffffffff;
    iStack_8 = 0;
  }
  else {
    uStack_c = *(undefined4 *)(param_2 + 0x18);
    iStack_8 = *(int *)(param_2 + 0x1c);
  }
  uStack_14 = uStack_c;
  iStack_10 = iStack_8;
  iVar1 = param_1 + 9 + (uint)*(byte *)(param_1 + 8);
  FUN_009c91c0(&param_3,&uStack_14);
  FUN_00676f40(&param_3,(param_3 >> 2) + 0x9e3779b9 + param_3 * 0x40 + iStack_10 ^ param_3,
               &uStack_18,-(uint)(iVar1 != 0) & iVar1 + 1U);
  if (param_3 != 0) {
    *(undefined4 *)(param_3 + 0x2c) = param_4;
  }
  return;
}



/* FUNCTION 8032 ; VA 0x0067e4f0 ; FUN_0067e4f0 */

undefined4 __thiscall FUN_0067e4f0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  uint uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_18 = param_3;
  if (param_2 == 0) {
    uStack_c = 0xffffffff;
    iStack_8 = 0;
  }
  else {
    uStack_c = *(undefined4 *)(param_2 + 0x18);
    iStack_8 = *(int *)(param_2 + 0x1c);
  }
  uStack_14 = uStack_c;
  iStack_10 = iStack_8;
  iVar1 = param_1 + 9 + (uint)*(byte *)(param_1 + 8);
  FUN_009c91c0(&param_3,&uStack_14);
  FUN_00676f40(&param_3,(param_3 >> 2) + 0x9e3779b9 + param_3 * 0x40 + iStack_10 ^ param_3,
               &uStack_18,-(uint)(iVar1 != 0) & iVar1 + 1U);
  if ((param_3 != 0) && (*(int *)(param_3 + 0x2c) != *(int *)(param_3 + 0x18))) {
    *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
    return 1;
  }
  return 0;
}



/* FUNCTION 8033 ; VA 0x0067e5b0 ; FUN_0067e5b0 */

void __fastcall FUN_0067e5b0(int param_1)

{
  *(undefined *)(param_1 + 0x3c28) = 0;
  return;
}



/* FUNCTION 8034 ; VA 0x0067e5c0 ; FUN_0067e5c0 */

void __thiscall FUN_0067e5c0(int *param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  double *pdVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_d0;
  uint *puStack_cc;
  undefined auStack_c8 [12];
  undefined4 uStack_bc;
  undefined4 *puStack_b8;
  int *piStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_9c;
  char *pcStack_98;
  undefined8 uStack_94;
  undefined4 uStack_7c;
  int iStack_78;
  undefined auStack_74 [24];
  code *pcStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  undefined auStack_50 [24];
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4af8;
  pvStack_10 = ExceptionList;
  if (param_2 != 0xd) {
    if (param_2 == 0xe) {
      *(undefined *)(param_1 + 0x7b2) = 0;
      return;
    }
    if ((param_2 == 0xf) && (param_1[0x779] != 0)) {
      uStack_94 = (double)CONCAT44(0x67ea24,(undefined4)uStack_94);
      ExceptionList = &pvStack_10;
      FUN_006e6a10();
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_94 = (double)CONCAT44(&iStack_18,0x67e5f5);
  ExceptionList = &pvStack_10;
  pdVar3 = (double *)FUN_016830f0();
  uStack_94 = *pdVar3 - *(double *)(param_1 + 0xef0);
  pcStack_98 = "TopRepContSent";
  uStack_9c = 0x67e617;
  FUN_0151fb00();
  *(undefined *)((int)param_1 + 0x3c29) = 1;
  uStack_94 = (double)CONCAT44(0x67e62a,(undefined4)uStack_94);
  cVar2 = (**(code **)(*param_1 + 0x11c))();
  if (cVar2 == '\0') {
    uStack_94 = 8.48831958047151e-313;
    iVar4 = FUN_01674e20();
    uStack_8 = 0;
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uStack_94 = (double)CONCAT44(1,param_1);
      pcStack_98 = (char *)0x67e657;
      uVar5 = FUN_00703e40();
    }
    uStack_8 = 0xffffffff;
    uStack_94 = (double)CONCAT44(iVar4,uVar5);
    iStack_18 = 0;
    puStack_14 = (undefined4 *)0x0;
    pcStack_98 = (char *)0x67e67c;
    FUN_0066e1c0();
    param_1[0xe16] = iStack_18;
    piVar1 = (int *)param_1[0xe17];
    param_1[0xe17] = (int)puStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_94 = (double)CONCAT44(0x67e6a7,(undefined4)uStack_94);
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_94 = (double)CONCAT44(0x67e6b7,(undefined4)uStack_94);
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    uStack_94 = 3.73474623441703e-312;
    iVar4 = FUN_01674e20();
    uStack_8 = 1;
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uStack_94 = (double)CONCAT44(param_1,0x67e6da);
      uVar5 = FUN_0071ef50();
    }
    uStack_8 = 0xffffffff;
    uStack_94 = (double)CONCAT44(iVar4,uVar5);
    iStack_18 = 0;
    puStack_14 = (undefined4 *)0x0;
    pcStack_98 = (char *)0x67e6ff;
    FUN_0066e250();
    param_1[0xe12] = iStack_18;
    piVar1 = (int *)param_1[0xe13];
    param_1[0xe13] = (int)puStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_94 = (double)CONCAT44(0x67e72a,(undefined4)uStack_94);
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_94 = (double)CONCAT44(0x67e73a,(undefined4)uStack_94);
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    uStack_94 = 2.03714960227722e-312;
    iVar4 = FUN_01674e20();
    uStack_8 = 2;
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uStack_94 = (double)CONCAT44(param_1,0x67e75a);
      uVar5 = FUN_00721e30();
    }
    uStack_8 = 0xffffffff;
    uStack_94 = (double)CONCAT44(iVar4,uVar5);
    iStack_18 = 0;
    puStack_14 = (undefined4 *)0x0;
    pcStack_98 = (char *)0x67e77f;
    FUN_0066e2e0();
    param_1[0xe14] = iStack_18;
    piVar1 = (int *)param_1[0xe15];
    param_1[0xe15] = (int)puStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_94 = (double)CONCAT44(0x67e7aa,(undefined4)uStack_94);
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_94 = (double)CONCAT44(0x67e7ba,(undefined4)uStack_94);
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (param_1[0x779] != 0) {
    *(undefined *)(param_1[0x779] + 0x1d4) = 1;
  }
  if (param_1[0xf03] != 0) {
    uStack_94 = (double)CONCAT44(param_1,0x67e7de);
    FUN_008f7870();
    piStack_b4 = param_1 + 0xf18;
    uStack_94 = (double)CONCAT44(1,(undefined4)uStack_94);
    puStack_b8 = (undefined4 *)0x67e7fa;
    FUN_0054ef60();
    puStack_b8 = &uStack_20;
    uStack_8 = 3;
    uStack_bc = 0x67e80b;
    piStack_b4 = param_1;
    FUN_0060e0c0();
    puStack_14 = (undefined4 *)auStack_c8;
    uStack_8 = 5;
    puStack_cc = auStack_38;
    uStack_d0 = 0x67e823;
    FUN_0054ef60();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    uStack_d0 = uStack_20;
    puStack_cc = (uint *)piStack_1c;
    puVar6 = (undefined4 *)FUN_00677760();
    puStack_14 = &uStack_7c;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_7c = *puVar6;
    iStack_78 = puVar6[1];
    piStack_b4 = puVar6 + 2;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_b8 = (undefined4 *)0x67e896;
    FUN_0054ef60();
    piStack_b4 = (int *)0x67e89e;
    FUN_005d11a0();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_b4 = (int *)0x67e8b2;
        (**(code **)(*piStack_1c + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      piStack_b4 = (int *)(uStack_24 + 1);
      uVar7 = auStack_38[0];
      if (0xfff < piStack_b4) {
        uVar7 = *(uint *)(auStack_38[0] - 4);
        piStack_b4 = (int *)(uStack_24 + 0x24);
        if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          piStack_b4 = (int *)&UNK_0067ea3c;
          FUN_017167a3();
        }
      }
      uStack_bc = 0x67e8ea;
      puStack_b8 = (undefined4 *)uVar7;
      FUN_01674ea0();
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    pcStack_5c = FUN_0067cb60;
    puStack_14 = &uStack_58;
    if (iStack_78 != 0) {
      LOCK();
      *(int *)(iStack_78 + 8) = *(int *)(iStack_78 + 8) + 1;
      UNLOCK();
    }
    uStack_58 = uStack_7c;
    iStack_54 = iStack_78;
    piStack_b4 = (int *)auStack_74;
    uStack_8._0_1_ = 9;
    uStack_8._1_3_ = 0;
    puStack_b8 = (undefined4 *)0x67e947;
    FUN_0054ef60();
    uStack_b0 = 0;
    puStack_14 = &uStack_d0;
    if (iStack_54 != 0) {
      LOCK();
      *(int *)(iStack_54 + 8) = *(int *)(iStack_54 + 8) + 1;
      UNLOCK();
    }
    uStack_d0 = uStack_58;
    puStack_cc = (uint *)iStack_54;
    uStack_8._0_1_ = 0xb;
    FUN_0054ef60(auStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_006706e0();
    piStack_b4 = (int *)0x67e9a6;
    FUN_005d11a0();
    uStack_8 = 0xffffffff;
    piStack_b4 = (int *)0x67e9b5;
    FUN_005d11a0();
    piStack_b4 = (int *)0x67e9bd;
    FUN_0090ca30();
  }
  uStack_94 = (double)CONCAT44(0x67e9c7,(undefined4)uStack_94);
  (**(code **)(*param_1 + 0x288))();
  uStack_94 = (double)CONCAT44(0x67e9d3,(undefined4)uStack_94);
  cVar2 = (**(code **)(*param_1 + 0x124))();
  *(bool *)(param_1 + 0xe00) = cVar2 == '\0';
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8035 ; VA 0x0067ea40 ; FUN_0067ea40 */

void __thiscall FUN_0067ea40(int *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  double *pdVar8;
  undefined8 uVar9;
  undefined auStack_1c [4];
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4b50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[0x779] != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x779] = 0;
    piVar5 = (int *)param_1[0x77a];
    param_1[0x77a] = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar7 = piVar5[1] + -1;
      piVar5[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar7 = piVar5[2] + -1;
        piVar5[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_1[0xf03] != 0) {
      FUN_00934890(0,0);
    }
  }
  if (param_1[0xeeb] != 0) {
    if (param_1[0xeec] != 0) {
      LOCK();
      piVar5 = (int *)(param_1[0xeec] + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_00628870(param_1[0xeeb],param_1[0xeec]);
    param_1[0xeeb] = 0;
    piVar5 = (int *)param_1[0xeec];
    param_1[0xeec] = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar7 = piVar5[1] + -1;
      piVar5[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar7 = piVar5[2] + -1;
        piVar5[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if (param_3 != 0) {
    param_1[0xf09] = 0;
    piStack_14 = (int *)FUN_00562f00();
    if (piStack_14 == (int *)0x0) {
      FUN_00550130();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    cVar3 = (**(code **)(*param_1 + 0x11c))();
    if ((cVar3 == '\0') && (*(char *)(piStack_14 + 0xc0) != '\0')) {
      *(undefined *)(param_1 + 0xdfe) = 1;
      if ((param_1[0xe02] & 0x2000000U) == 0) {
        param_1[0x640] = 4;
      }
      piStack_14 = (int *)FUN_01674e20();
      uStack_8 = 0;
      if (piStack_14 == (int *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_006e2000();
      }
      uStack_8 = 0xffffffff;
      iStack_18 = 0;
      piStack_14 = (int *)0x0;
      FUN_0064db80(uVar4,param_3);
      piVar6 = piStack_14;
      param_1[0x779] = iStack_18;
      piVar5 = (int *)param_1[0x77a];
      iStack_18 = 0;
      piStack_14 = (int *)0x0;
      param_1[0x77a] = (int)piVar6;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar7 = piVar5[1] + -1;
        piVar5[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar7 = piVar5[2] + -1;
          piVar5[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      FUN_00550b30();
      piVar5 = (int *)FUN_01674e20();
      if (piVar5 == (int *)0x0) {
        piVar5 = (int *)0x0;
        piStack_14 = (int *)0x0;
      }
      else {
        *piVar5 = 0;
        uStack_8 = 2;
        piStack_14 = piVar5;
        piStack_14 = (int *)FUN_01674e20();
        if (piStack_14 == (int *)0x0) {
          piVar6 = (int *)0x0;
        }
        else {
          *piStack_14 = 0;
          piStack_14[1] = 0;
          piStack_14[2] = 0;
          piStack_14[3] = 0x4c;
          piStack_14[4] = 0x20;
          piStack_14[5] = 0x20;
          piStack_14[6] = 0;
          piVar6 = piStack_14;
        }
        iVar7 = *piVar5;
        *piVar5 = (int)piVar6;
        if (iVar7 != 0) {
          FUN_00615040();
        }
      }
      piVar6 = (int *)param_1[0x65b];
      uStack_8 = 0xffffffff;
      param_1[0x65b] = (int)piVar5;
      if (piVar6 != (int *)0x0) {
        if (*piVar6 != 0) {
          FUN_00615040();
        }
        FUN_01674ea0(piVar6,4);
      }
    }
    iVar7 = FUN_01674e20();
    uStack_8 = 3;
    if (iVar7 == 0) {
      iVar7 = 0;
    }
    else {
      iVar7 = param_1[0xf07];
      if (*(int *)(iVar7 + 0xf4) != 0) {
        LOCK();
        piVar5 = (int *)(*(int *)(iVar7 + 0xf4) + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      uVar4 = *(undefined4 *)(iVar7 + 0xf0);
      uVar1 = *(undefined4 *)(iVar7 + 0xf4);
      if (*(int *)(iVar7 + 0xec) != 0) {
        LOCK();
        piVar5 = (int *)(*(int *)(iVar7 + 0xec) + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      iVar7 = FUN_0068fb60(param_1,*(undefined4 *)(iVar7 + 0xe8),*(undefined4 *)(iVar7 + 0xec),uVar4
                           ,uVar1);
    }
    iVar2 = param_1[0x685];
    uStack_8 = 0xffffffff;
    param_1[0x685] = iVar7;
    if (iVar2 != 0) {
      FUN_006157e0();
    }
    iVar7 = FUN_008f7870();
    if (iVar7 != 0) {
      FUN_0090afc0();
      iVar7 = FUN_008f87a0();
      param_1[0x16] = iVar7;
    }
  }
  FUN_006229b0(param_2,param_3);
  if ((param_3 == 0) && (param_1[0xf03] != 0)) {
    uVar4 = FUN_0060dcd0(&iStack_18,param_1);
    uStack_8 = 4;
    uVar9 = FUN_00928340();
    FUN_0064b490(uVar9,uVar4);
    piVar5 = piStack_14;
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_14[1] + -1;
      piStack_14[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar7 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  pdVar8 = (double *)FUN_016830f0();
  FUN_0151fb00("ReplicatorAdded",*pdVar8 - *(double *)(param_1 + 0xef0));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8036 ; VA 0x0067eea0 ; FUN_0067eea0 */

int * FUN_0067eea0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  undefined uVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  int **ppiVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4bba;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00700dd0(param_1,param_2);
  if (iVar3 != 0) {
    piVar6 = (int *)FUN_00587490(auStack_20);
    uStack_8 = 0;
    if ((*piVar6 == 0) ||
       (iVar3 = *(int *)(*piVar6 + 0xc), iVar7 = FUN_005ee350(),
       (uint)*(ushort *)(iVar7 + 0x1da) <
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
      piStack_34 = (int *)0x0;
      ppiVar10 = &piStack_38;
      param_2 = (int *)0x0;
      uVar11 = 2;
    }
    else {
      piStack_28 = (int *)piVar6[1];
      param_2 = (int *)*piVar6;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
        piStack_28 = (int *)piVar6[1];
      }
      ppiVar10 = &piStack_2c;
      uVar11 = 1;
    }
    piStack_3c = ppiVar10[1];
    uVar12 = uVar11 | 4;
    piStack_30 = piStack_3c;
    *ppiVar10 = (int *)0x0;
    ppiVar10[1] = (int *)0x0;
    piVar2 = piStack_34;
    piVar6 = piStack_3c;
    piStack_40 = param_2;
    uStack_14 = uVar12;
    if (((uVar11 & 2) != 0) &&
       (uVar12 = uVar11 & 0xfffffffd | 4, uStack_14 = uVar12, piStack_34 != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_34 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_28;
    if (((uVar12 & 1) != 0) &&
       (uVar12 = uVar12 & 0xfffffffe, uStack_14 = uVar12, piStack_28 != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_28 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_1c;
    uStack_8._0_1_ = 2;
    uStack_24 = uVar12;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      FUN_009ff040(&piStack_38,"PropSync");
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uVar8 = FUN_009ff040(&piStack_2c,"ItemCount");
      FUN_005587e0(uVar8);
      piVar6 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[1] + -1;
        piStack_28[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piStack_1c = piStack_38;
      param_1 = param_2 + 0xed2;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puVar9 = (undefined4 *)FUN_00670ee0(&piStack_50,&param_1);
      uStack_14 = uVar12 | 8;
      param_1 = (int *)*puVar9;
      piStack_44 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      piStack_48 = param_1;
      piStack_28 = piStack_44;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          iVar3 = piStack_4c[2] + -1;
          piStack_4c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_4c + 4))();
          }
        }
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      pcVar4 = *(code **)(*param_1 + 0x38);
      FUN_005542c0("RejectionCount",0xe);
      uStack_8._0_1_ = 5;
      (*pcVar4)(auStack_68);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (0xf < uStack_54) {
        uVar12 = uStack_54 + 1;
        uVar11 = auStack_68[0];
        if (0xfff < uVar12) {
          uVar11 = *(uint *)(auStack_68[0] - 4);
          uVar12 = uStack_54 + 0x24;
          if (0x1f < (auStack_68[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar12);
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      FUN_008a65e0(piStack_1c,0);
      uVar11 = uStack_24;
      piVar6 = piStack_28;
      uStack_14 = uStack_24;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[1] + -1;
        piStack_28[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_2 = param_2 + 0xeed;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      puVar9 = (undefined4 *)FUN_00670d90(&piStack_48,&param_2);
      piVar2 = piStack_44;
      uStack_14 = uVar11 | 0x10;
      param_2 = (int *)*puVar9;
      piVar6 = (int *)puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      piStack_50 = param_2;
      piStack_4c = piVar6;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_44[1] + -1;
        piStack_44[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      pcVar4 = *(code **)(*param_2 + 0x38);
      FUN_005542c0("Num Parts Owned",0xf);
      uStack_8._0_1_ = 7;
      (*pcVar4)(auStack_68);
      uStack_8._0_1_ = 6;
      uVar5 = (undefined)uStack_8;
      uStack_8._0_1_ = 6;
      if (0xf < uStack_54) {
        uVar12 = uStack_54 + 1;
        uVar11 = auStack_68[0];
        if (0xfff < uVar12) {
          uVar11 = *(uint *)(auStack_68[0] - 4);
          uVar12 = uStack_54 + 0x24;
          if (0x1f < (auStack_68[0] - uVar11) - 4) {
            uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar12);
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      FUN_008a65e0(uStack_18,0);
      uStack_8._0_1_ = 3;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar3 = piVar6[2] + -1;
          piVar6[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(&piStack_50,"Send Stream Data");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(&piStack_50,"Avg Packet Size");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(&piStack_50,"Avg Instance per step");
      FUN_005587e0(uVar8);
      piVar6 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uVar8 = FUN_009ff040(&piStack_50,"Client instance quota");
      piVar6 = (int *)FUN_005587e0(uVar8);
      piVar2 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        piVar1 = piStack_4c + 1;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar6 = (int *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_34 + 1;
        iVar3 = *piVar1;
        piVar6 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piStack_34)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          piVar6 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar6 = (int *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    piVar2 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_30 + 1;
      iVar3 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar6 = (int *)(**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar6 = (int *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 8037 ; VA 0x0067f430 ; FUN_0067f430 */

void __fastcall FUN_0067f430(int param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1ec8) == '\0') {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(DAT_01eadc98);
    uStack_8 = 0;
    FUN_00625d80();
    uStack_8 = 1;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8038 ; VA 0x0067f4a0 ; FUN_0067f4a0 */

undefined __thiscall FUN_0067f4a0(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  double *pdVar8;
  int *piVar9;
  undefined8 uVar10;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4be8;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  ExceptionList = &pvStack_10;
  if ((*param_2 == 0) ||
     (iVar6 = *(int *)(*param_2 + 0xc), ExceptionList = &pvStack_10, iVar4 = FUN_00913630(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    piStack_18 = (int *)0x0;
    puVar5 = &uStack_1c;
    param_2 = (int *)0x0;
    piVar9 = (int *)&DAT_00000006;
  }
  else {
    piStack_20 = (int *)param_2[1];
    iVar6 = *param_2;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
      piStack_20 = (int *)param_2[1];
    }
    piVar9 = (int *)&DAT_00000005;
    puVar5 = &uStack_24;
    param_2 = (int *)iVar6;
  }
  piVar1 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  if ((((uint)piVar9 & 2) != 0) &&
     (piStack_14 = (int *)((uint)piVar9 & 0xfffffffd), piVar9 = piStack_14, piStack_18 != (int *)0x0
     )) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar6 = piStack_18[2] + -1;
      piStack_18[2] = iVar6;
      UNLOCK();
      piVar9 = piStack_14;
      if (iVar6 == 0) {
        (**(code **)(*piStack_18 + 4))();
        piVar9 = piStack_14;
      }
    }
  }
  if ((((uint)piVar9 & 1) != 0) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar6 = piStack_20[2] + -1;
      piStack_20[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (param_2 == (int *)0x0) {
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar6 = piVar1[1] + -1;
      piVar1[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar9 = piVar1 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  if (param_1[0xf03] == 0) {
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    param_1[0xf03] = (int)param_2;
    piStack_14 = (int *)param_1[0xf04];
    param_1[0xf04] = (int)piVar1;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar6 = piStack_14[2] + -1;
        piStack_14[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    piStack_14 = (int *)param_1[0xf07];
    puVar5 = (undefined4 *)FUN_0060dcd0(&uStack_24,param_1);
    if (puVar5[1] != 0) {
      LOCK();
      piVar9 = (int *)(puVar5[1] + 8);
      *piVar9 = *piVar9 + 1;
      UNLOCK();
    }
    uStack_1c = *puVar5;
    piStack_18 = (int *)puVar5[1];
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar10 = FUN_00928340();
    FUN_00646cb0(uVar10,&uStack_1c);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_18[2] + -1;
      piStack_18[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    piStack_14 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_14[2] + -1;
        piStack_14[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    FUN_00934430(param_1 + 0x1d,param_1[0xec0]);
    if (param_1[0xf05] != 0) {
      FUN_008a65e0(param_1[0xf03],0);
    }
    if (param_1[0x779] != 0) {
      if (param_1[0x77a] != 0) {
        LOCK();
        piVar9 = (int *)(param_1[0x77a] + 4);
        *piVar9 = *piVar9 + 1;
        UNLOCK();
      }
      FUN_00934890(-(uint)(param_1[0x779] != 0) & param_1[0x779] + 0x130U,param_1[0x77a]);
      iVar6 = FUN_005c3ac0();
      if (iVar6 == 0) goto LAB_0067f85a;
      if (*(int *)(iVar6 + 0x30c) == 2) {
        FUN_00933a00();
      }
    }
    if (((DAT_01d6420c == '\0') && (cVar2 = (**(code **)(*param_1 + 0x11c))(), cVar2 == '\0')) &&
       (cVar2 = FUN_0091dda0(), cVar2 != '\0')) {
      uVar7 = FUN_005c8880();
      FUN_009223e0(uVar7,param_1 + 0xf18);
    }
    uVar10 = FUN_00928340();
    FUN_015220d0(uVar10);
    pdVar8 = (double *)FUN_016830f0();
    FUN_0151fb00("ReceivedPlayer",*pdVar8 - *(double *)(param_1 + 0xef0));
    if (*(char *)((int)param_1 + 0x3c2a) == '\0') {
      (**(code **)(*param_1 + 0x284))();
    }
    uVar3 = FUN_00644850();
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar6 = piVar1[1] + -1;
      piVar1[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar9 = piVar1 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return uVar3;
  }
LAB_0067f85a:
  FUN_00550130();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 8039 ; VA 0x0067f880 ; FUN_0067f880 */

void __thiscall FUN_0067f880(int param_1,int param_2)

{
  float fVar1;
  double dVar2;
  uint uVar3;
  int iVar5;
  short sVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  undefined8 uVar10;
  double dStack_c;
  uint uVar4;
  
  uVar10 = FUN_006a6900();
  uVar3 = *(uint *)(param_1 + 0x1070);
  uVar4 = *(uint *)(param_1 + 0x1070);
  iVar5 = *(int *)(param_1 + 0x1074);
  FUN_00624590(param_2);
  if (((int)((ulonglong)uVar10 >> 0x20) - iVar5 != (uint)((uint)uVar10 < uVar3)) ||
     (300 < (uint)uVar10 - uVar4)) {
    fVar1 = *(float *)(param_2 + 0x20);
    dStack_c = (double)fVar1;
    sVar6 = FUN_017265ed(&dStack_c);
    if (sVar6 < 1) {
      dVar2 = *(double *)(param_1 + 0x3c80);
      dVar9 = DAT_018c0d60 - dVar2;
      dVar7 = (double)fVar1;
      dVar8 = dVar7;
      if (*(char *)(param_1 + 0x3ca0) == '\0') {
        dVar8 = *(double *)(param_1 + 0x3c90) * dVar9 + dVar7 * dVar2;
      }
      *(undefined *)(param_1 + 0x3ca0) = 0;
      *(double *)(param_1 + 0x3c90) = dVar8;
      *(float *)(param_1 + 0x3c88) = fVar1;
      *(double *)(param_1 + 0x3c98) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar2 + *(double *)(param_1 + 0x3c98) * dVar9;
    }
    fVar1 = *(float *)(param_2 + 0x24);
    dStack_c = (double)fVar1;
    sVar6 = FUN_017265ed(&dStack_c);
    if (sVar6 < 1) {
      dVar2 = *(double *)(param_1 + 0x3ca8);
      dVar9 = DAT_018c0d60 - dVar2;
      dVar7 = (double)fVar1;
      dVar8 = dVar7;
      if (*(char *)(param_1 + 0x3cc8) == '\0') {
        dVar8 = *(double *)(param_1 + 0x3cb8) * dVar9 + dVar7 * dVar2;
      }
      *(undefined *)(param_1 + 0x3cc8) = 0;
      *(double *)(param_1 + 0x3cb8) = dVar8;
      *(float *)(param_1 + 0x3cb0) = fVar1;
      *(double *)(param_1 + 0x3cc0) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar2 + *(double *)(param_1 + 0x3cc0) * dVar9;
    }
    fVar1 = *(float *)(param_2 + 0x28);
    dStack_c = (double)fVar1;
    sVar6 = FUN_017265ed(&dStack_c);
    if (sVar6 < 1) {
      dVar2 = *(double *)(param_1 + 0x3cd0);
      dVar9 = DAT_018c0d60 - dVar2;
      dVar7 = (double)fVar1;
      dVar8 = dVar7;
      if (*(char *)(param_1 + 0x3cf0) == '\0') {
        dVar8 = *(double *)(param_1 + 0x3ce0) * dVar9 + dVar7 * dVar2;
      }
      *(undefined *)(param_1 + 0x3cf0) = 0;
      *(double *)(param_1 + 0x3ce0) = dVar8;
      *(float *)(param_1 + 0x3cd8) = fVar1;
      *(double *)(param_1 + 0x3ce8) =
           (dVar7 - dVar8) * (dVar7 - dVar8) * dVar2 + *(double *)(param_1 + 0x3ce8) * dVar9;
    }
    fVar1 = *(float *)(param_2 + 0x20);
    if (((NAN(fVar1) || NAN(DAT_018c0ff0)) != (fVar1 == DAT_018c0ff0)) ||
       ((NAN(fVar1) || NAN(DAT_018ce2f0)) != (fVar1 == DAT_018ce2f0))) {
      *(undefined *)(param_1 + 0x3c33) = 1;
    }
  }
  return;
}



/* FUNCTION 8040 ; VA 0x0067fad0 ; FUN_0067fad0 */

void __thiscall FUN_0067fad0(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 ***pppuVar4;
  undefined8 uVar5;
  undefined auStack_48 [24];
  undefined4 **appuStack_30 [5];
  uint uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4c18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(*param_1 + 0xb4))();
  if (iVar2 != 0) {
    if (DAT_01d5af18 == '\0') {
      iStack_18 = param_1[0xf07];
      puVar3 = (undefined4 *)FUN_00927520(auStack_48);
      uStack_8 = 2;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      uVar5 = FUN_00928340();
      if (*(int *)(iVar2 + 0x378) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(iVar2 + 0x378) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00644e80(param_2,*(undefined4 *)(iVar2 + 0x374),*(undefined4 *)(iVar2 + 0x378),uVar5,
                   &DAT_018bc9b8,puVar3,param_1 + 0x1d);
    }
    else {
      FUN_0054ef60(*(undefined4 *)(iVar2 + 0x28));
      iStack_18 = param_1[0xf07];
      uStack_8 = 0;
      puStack_14 = (undefined4 *)FUN_00927520(auStack_48);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (0xf < (uint)puStack_14[5]) {
        puStack_14 = (undefined4 *)*puStack_14;
      }
      pppuVar4 = appuStack_30;
      if (0xf < uStack_1c) {
        pppuVar4 = (undefined4 ***)appuStack_30[0];
      }
      uVar5 = FUN_00928340();
      if (*(int *)(iVar2 + 0x378) != 0) {
        LOCK();
        piVar1 = (int *)(*(int *)(iVar2 + 0x378) + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_00644e80(param_2,*(undefined4 *)(iVar2 + 0x374),*(undefined4 *)(iVar2 + 0x378),uVar5,
                   pppuVar4,puStack_14,param_1 + 0x1d);
      FUN_005507b0();
    }
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8041 ; VA 0x0067fc40 ; FUN_0067fc40 */

void __thiscall FUN_0067fc40(int param_1,int param_2,int param_3)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  char cVar4;
  int iVar5;
  undefined *puStack_a4;
  undefined *puStack_a0;
  undefined *puStack_9c;
  undefined *puStack_98;
  undefined *puStack_94;
  undefined8 uStack_90;
  undefined **ppuStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  undefined ***pppuStack_58;
  undefined auStack_54 [24];
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [8];
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4c8a;
  pvStack_10 = ExceptionList;
  bVar2 = false;
  bVar1 = false;
  iStack_14 = 0;
  if (DAT_01d5af08 == '\0') {
    return;
  }
  if (*(int *)(param_1 + 0x3d68) == 1) {
    return;
  }
  if (*(int *)(param_1 + 0x3c0c) == 0) {
    return;
  }
  if (*(char *)(param_1 + 0x3844) != '\0') {
    return;
  }
  uStack_90._0_4_ = (undefined *)0x67fc9c;
  ExceptionList = &pvStack_10;
  uStack_90._4_4_ = (undefined ***)param_1;
  iStack_1c = FUN_008f7870();
  if (iStack_1c == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = *(int *)(param_1 + 0x3d68);
  if (iVar5 == 0) {
    if (DAT_01d5af00 == 0) {
LAB_0067fd2d:
      bVar3 = false;
    }
    else {
      uStack_90._4_4_ = (undefined ***)0x1;
      uStack_90._0_4_ = &DAT_018bf378;
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      puStack_94 = (undefined *)0x67fcdf;
      FUN_005542c0();
      uStack_8 = 0;
      iStack_14 = 1;
      uStack_90._4_4_ = (undefined ***)0x67fcf4;
      uStack_90 = FUN_00928340();
      puStack_98 = auStack_54;
      puStack_94 = &DAT_018bed48;
      puStack_9c = (undefined *)0x67fd04;
      puStack_a4 = (undefined *)FUN_01675640();
      puStack_9c = auStack_3c;
      uStack_8 = 1;
      puStack_a0 = &DAT_01d5aef0;
      bVar2 = true;
      bVar1 = true;
      iStack_14 = 3;
      cVar4 = FUN_0067d600();
      bVar3 = true;
      if (cVar4 == '\0') goto LAB_0067fd2d;
    }
    if (bVar1) {
      uStack_90._4_4_ = (undefined ***)0x67fd41;
      FUN_005507b0();
    }
    uStack_8 = 0xffffffff;
    if (bVar2) {
      uStack_90._4_4_ = (undefined ***)0x67fd55;
      FUN_005507b0();
    }
    if (bVar3) {
      *(undefined4 *)(param_1 + 0x3d68) = 2;
      goto LAB_0067fdfe;
    }
    uStack_90._0_4_ = auStack_24;
    puStack_94 = (undefined *)0x67fd74;
    uStack_90._4_4_ = (undefined ***)param_1;
    uStack_90._4_4_ = (undefined ***)FUN_0060dcd0();
    uStack_90._0_4_ = (undefined *)0x67fd80;
    FUN_005587b0();
    uStack_8 = 2;
    uStack_90._4_4_ = (undefined ***)0x67fd8f;
    FUN_00550b30();
    if (iStack_14 != 0) {
      LOCK();
      *(int *)(iStack_14 + 8) = *(int *)(iStack_14 + 8) + 1;
      UNLOCK();
    }
    uStack_78 = uStack_18;
    iStack_6c = param_3;
    uStack_90._4_4_ = &ppuStack_7c;
    ppuStack_7c = std::
                  _Func_impl_no_alloc<class_<lambda_8efa8613e04d74ea603fc25b2f37ee41>,void,enum_RBX::Player::CanManageStatus>
                  ::vftable;
    iStack_74 = iStack_14;
    iStack_70 = param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_90._0_4_ = (undefined *)0x67fdc9;
    pppuStack_58 = uStack_90._4_4_;
    FUN_0091e690();
    if (pppuStack_58 != (undefined ***)0x0) {
      uStack_90._4_4_ =
           (undefined ***)CONCAT31((int3)((uint)&ppuStack_7c >> 8),pppuStack_58 != &ppuStack_7c);
      uStack_90._0_4_ = (undefined *)0x67fde0;
      (*(code *)(*pppuStack_58)[4])();
    }
    uStack_8 = 0xffffffff;
    uStack_90._4_4_ = (undefined ***)0x67fdef;
    FUN_0056c200();
    iVar5 = *(int *)(param_1 + 0x3d68);
  }
  if (iVar5 != 2) {
    ExceptionList = pvStack_10;
    return;
  }
LAB_0067fdfe:
  if ((DAT_01d5ae38 < param_2) || (param_2 < 1)) {
    param_2 = DAT_01d5ae38;
  }
  if ((DAT_01d5ae40 < param_3) || (param_3 < 1)) {
    param_3 = DAT_01d5ae40;
  }
  *(undefined *)(param_1 + 0x3844) = 1;
  uStack_90._4_4_ = (undefined ***)0x67fe2b;
  FUN_0152de00();
  uStack_90._0_4_ = (undefined *)0x2;
  puStack_a4 = (undefined *)&puStack_9c;
  puStack_a0 = (undefined *)param_1;
  puStack_94 = (undefined *)param_2;
  uStack_90._4_4_ = (undefined ***)param_3;
  FUN_0060e0c0();
  uStack_8 = 4;
  FUN_005e5de0(&puStack_a4,iStack_1c);
  uStack_8 = 0xffffffff;
  uStack_90._4_4_ = (undefined ***)FUN_006709d0(&iStack_74,FUN_0067feb0);
  uStack_8 = 5;
  uStack_90._0_4_ = (undefined *)0x67fe7b;
  FUN_0066dc80();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_90._4_4_ = (undefined ***)0x67fe87;
  FUN_006782e0();
  uStack_90._4_4_ = (undefined ***)0x67fe8f;
  FUN_016899e0();
  uStack_90._4_4_ = (undefined ***)0x67fe97;
  FUN_0056ebb0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8042 ; VA 0x0067feb0 ; FUN_0067feb0 */

uint FUN_0067feb0(int param_1,int *param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                 undefined4 param_6,int *param_7)

{
  uint *puVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  longlong lVar9;
  undefined8 uVar10;
  int aiStack_16c [3];
  undefined4 uStack_160;
  undefined *puStack_15c;
  undefined8 uStack_158;
  undefined8 uStack_150;
  undefined auStack_13c [40];
  undefined auStack_114 [16];
  undefined4 uStack_104;
  int iStack_100;
  undefined **appuStack_fc [2];
  undefined8 uStack_f4;
  undefined *****apppppuStack_ec [6];
  undefined *****pppppuStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 *puStack_c8;
  undefined4 *puStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 *puStack_b8;
  undefined4 *puStack_b4;
  int iStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_98;
  undefined **ppuStack_94;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined auStack_24 [4];
  undefined8 uStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4d3e;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_8 = 1;
  uStack_150._4_4_ = (undefined8 *)0x0;
  uStack_150._0_4_ = (char *)0xf4240;
  if ((int)param_7 < 0) {
    uVar6 = (int)param_7 >> 0x1f;
    uVar8 = (uint)param_7 ^ uVar6;
    uStack_158 = 0;
    puStack_15c = (undefined *)0x67ff45;
    ExceptionList = &pvStack_10;
    uVar10 = FUN_016f39b0();
    lVar9 = (longlong)(int)(uVar8 - uVar6) * 1000000;
    iVar2 = (int)lVar9;
    uVar6 = -iVar2;
    uStack_158 = CONCAT44((-(int)((ulonglong)uVar10 >> 0x20) -
                          ((int)((ulonglong)lVar9 >> 0x20) + (uint)(iVar2 != 0))) -
                          (uint)(uVar6 < (uint)uVar10),uVar6 - (uint)uVar10);
  }
  else {
    uStack_158 = 0;
    puStack_15c = (undefined *)0x67ff0e;
    ExceptionList = &pvStack_10;
    lVar9 = FUN_016f39b0();
    uStack_158 = (longlong)(int)param_7 * 1000000 + lVar9;
  }
  uStack_150._4_4_ = (undefined8 *)0x0;
  uStack_150._0_4_ = (char *)0x3e8;
  puStack_15c = (undefined *)0x67ff6f;
  lVar9 = FUN_016f3900();
  if (((int)((ulonglong)lVar9 >> 0x20) < 1) && (lVar9 < 0)) {
    uStack_20 = 0;
    lVar9 = 0;
  }
  aiStack_16c[0] = (int)((ulonglong)lVar9 >> 0x20);
  FUN_005ef740((int)lVar9);
  aiStack_16c[0] = -1;
  FUN_01689e80();
  uStack_150._4_4_ = &uStack_20;
  uStack_150._0_4_ = (char *)0x67ffa9;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  uVar6 = (uint)uStack_20;
  uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c);
  if (((uint)uStack_20 != 0) &&
     (uVar6 = (uint)*(byte *)((uint)uStack_20 + 0x3844),
     uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c),
     *(byte *)((uint)uStack_20 + 0x3844) != 0)) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eadd00) {
      uStack_150._4_4_ = (undefined8 *)&DAT_01eadd00;
      uStack_150._0_4_ = (char *)0x6804c1;
      FUN_016f3809();
      if (DAT_01eadd00 == -1) {
        uStack_150._4_4_ = (undefined8 *)0xffffffff;
        uStack_150._0_4_ = "profilerDump";
        uStack_8._0_1_ = 3;
        uStack_158._4_4_ = &DAT_018c5904;
        uStack_158._0_4_ = 0x6804e6;
        uVar10 = FUN_0152dab0();
        DAT_01eadcfc = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eadcf8 = (undefined4)uVar10;
        uStack_158 = CONCAT44(uStack_158._4_4_,&DAT_01eadd00);
        uStack_8._0_1_ = 2;
        puStack_15c = (undefined *)0x6804ff;
        FUN_016f37bf();
      }
    }
    uStack_150._4_4_ = (undefined8 *)DAT_01eadcfc;
    uStack_150._0_4_ = (char *)DAT_01eadcf8;
    uStack_34 = DAT_01eadcf8;
    uStack_30 = DAT_01eadcfc;
    uStack_158 = CONCAT44(0x680001,(undefined4)uStack_158);
    uStack_2c = FUN_0152d930();
    appuStack_fc[0] = &PTR_018bf148;
    apppppuStack_ec[0] = (undefined *****)&DAT_018bf150;
    uStack_150._4_4_ = (undefined8 *)0x0;
    uStack_150._0_4_ = (char *)(apppppuStack_ec + 2);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_40 = 1;
    ppuStack_94 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_98 = 0x50;
    uStack_f4 = 0;
    uStack_158 = CONCAT44(0x68005c,(undefined4)uStack_158);
    FUN_00554f20();
    *(undefined ***)((int)apppppuStack_ec + (int)apppppuStack_ec[0][1]) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined *****)((int)apppppuStack_ec + (int)(apppppuStack_ec[0][1] + -1)) =
         apppppuStack_ec[0][1] + -2;
    *(undefined ***)((int)appuStack_fc + (int)appuStack_fc[0][1]) =
         std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)&iStack_100 + (int)appuStack_fc[0][1]) = appuStack_fc[0][1] + -0x20;
    uStack_150._4_4_ = (undefined8 *)0x8;
    uStack_8 = 10;
    *(undefined ***)((int)appuStack_fc + (int)appuStack_fc[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_100 + (int)appuStack_fc[0][1]) = appuStack_fc[0][1] + -0x68;
    apppppuStack_ec[2] =
         (undefined *****)std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    uStack_150._0_4_ = (char *)0x6800e9;
    iStack_b0 = FUN_01674e20();
    if (iStack_b0 == 0) {
      iStack_b0 = 0;
    }
    else {
      uStack_150._4_4_ = (undefined8 *)0x1;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      uStack_150._0_4_ = (char *)0x6800fd;
      uVar3 = FUN_016de181();
      *(undefined4 *)(iStack_b0 + 4) = uVar3;
    }
    apppppuStack_ec[5] = (undefined *****)(apppppuStack_ec + 3);
    pppppuStack_d4 = (undefined *****)(apppppuStack_ec + 4);
    puStack_c8 = &uStack_d0;
    puStack_c4 = &uStack_cc;
    puStack_b8 = &uStack_c0;
    puStack_b4 = &uStack_bc;
    apppppuStack_ec[4] = (undefined *****)0x0;
    uStack_cc = 0;
    uStack_bc = 0;
    apppppuStack_ec[3] = (undefined *****)0x0;
    uStack_d0 = 0;
    uStack_c0 = 0;
    apppppuStack_ec[2] =
         (undefined *****)
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_ac = 0;
    uStack_a8 = 0;
    uStack_150._4_4_ = (undefined8 *)param_5;
    uStack_150._0_4_ = (char *)appuStack_fc;
    uStack_8._0_1_ = 0xc;
    uStack_158 = CONCAT44(0x6801c2,(undefined4)uStack_158);
    FUN_0152d8a0();
    uStack_150._4_4_ = (undefined8 *)0x6801ca;
    FUN_0152dea0();
    uStack_150._4_4_ = (undefined8 *)auStack_114;
    uStack_150._0_4_ = (char *)0x6801dc;
    FUN_0058c420();
    uStack_150._4_4_ = (undefined8 *)0x34;
    uStack_8._0_1_ = 0xd;
    uStack_150._0_4_ = (char *)0x6801e7;
    piVar4 = (int *)FUN_01674e20();
    uStack_8._0_1_ = 0xe;
    param_7 = piVar4;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4[1] = 1;
      piVar4[2] = 1;
      *piVar4 = (int)std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
      uStack_150._4_4_ = (undefined8 *)0x680213;
      FUN_006ab530();
    }
    uStack_8._0_1_ = 0xf;
    uStack_150._4_4_ = (undefined8 *)0x68022f;
    piStack_3c = piVar4 + 3;
    piStack_38 = piVar4;
    FUN_006ab530();
    uStack_150._4_4_ = (undefined8 *)0x1;
    uStack_150._0_4_ = (char *)&param_7;
    uStack_8._0_1_ = 0x10;
    param_7 = (int *)CONCAT31(param_7._1_3_,0x9a);
    uStack_158 = CONCAT44(0x680244,(undefined4)uStack_158);
    FUN_006ad5e0();
    uStack_150._4_4_ = (undefined8 *)0x4;
    uStack_150._0_4_ = auStack_48;
    uStack_44 = 1;
    uStack_158 = CONCAT44(&uStack_44,0x68025a);
    FUN_006a5c10();
    uStack_150._0_4_ = auStack_48;
    uStack_150._4_4_ = (undefined8 *)0x4;
    uStack_158 = CONCAT44(0x68026a,(undefined4)uStack_158);
    FUN_006ad5e0();
    uStack_4c = uStack_104;
    uStack_150._0_4_ = auStack_24;
    uStack_150._4_4_ = (undefined8 *)0x4;
    uStack_158 = CONCAT44(&uStack_4c,0x680282);
    FUN_006a5c10();
    uStack_150._0_4_ = auStack_24;
    uStack_150._4_4_ = (undefined8 *)0x4;
    uStack_158 = CONCAT44(0x680292,(undefined4)uStack_158);
    FUN_006ad5e0();
    uStack_150._4_4_ = (undefined8 *)auStack_13c;
    uStack_150._0_4_ = auStack_114;
    uStack_158 = CONCAT44(0x6802a5,(undefined4)uStack_158);
    FUN_006ad360();
    puStack_15c = auStack_13c;
    uStack_158 = (ulonglong)CONCAT14(DAT_01d5be5c,piVar4 + 3);
    uStack_160 = 0x6802ba;
    FUN_00619a10();
    iStack_18 = 0;
    piStack_14 = (int *)0x0;
    if (param_2 != (int *)0x0) {
      piVar7 = param_2 + 1;
      iVar2 = param_2[1];
      while (iVar2 != 0) {
        LOCK();
        iVar5 = *piVar7;
        if (iVar2 == iVar5) {
          *piVar7 = iVar2 + 1;
          iVar5 = iVar2;
        }
        UNLOCK();
        if (iVar5 == iVar2) {
          iStack_18 = param_1;
          piStack_14 = param_2;
          break;
        }
        iVar2 = *piVar7;
      }
    }
    uStack_8._0_1_ = 0x11;
    if (iStack_18 != 0) {
      uStack_150._4_4_ = (undefined8 *)0x1;
      param_7 = aiStack_16c;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[2] = param_4[2] + 1;
        UNLOCK();
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[2] = param_4[2] + 1;
        UNLOCK();
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      FUN_0066db60(param_3,param_4,piStack_3c,piVar4,param_6,0);
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar2 = param_4[2] + -1;
        param_4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
      FUN_0090ca30();
      uStack_150._4_4_ = (undefined8 *)0x680469;
      FUN_00550b30();
      uStack_150._4_4_ = (undefined8 *)0x680474;
      FUN_00613200();
      uStack_150._4_4_ = (undefined8 *)0x68047c;
      FUN_00550b30();
      uStack_150._4_4_ = (undefined8 *)0x680487;
      FUN_005507b0();
      uStack_150._4_4_ = (undefined8 *)0x680492;
      FUN_005705c0();
      uStack_8._0_1_ = 0x13;
      uStack_158 = CONCAT44(uStack_30,uStack_34);
      puStack_15c = (undefined *)0x6804a7;
      uStack_150 = uStack_2c;
      FUN_0152dda0();
      uStack_150._4_4_ = (undefined8 *)0x6804b2;
      uVar6 = FUN_00550b30();
      goto LAB_00680375;
    }
    uStack_150._4_4_ = (undefined8 *)0x68030e;
    FUN_00550b30();
    uStack_150._4_4_ = (undefined8 *)0x680319;
    FUN_00613200();
    uStack_150._4_4_ = (undefined8 *)0x680321;
    FUN_00550b30();
    uStack_150._4_4_ = (undefined8 *)0x68032c;
    FUN_005507b0();
    uStack_150._4_4_ = (undefined8 *)0x680337;
    FUN_005705c0();
    uStack_8._0_1_ = 0x12;
    uStack_158 = CONCAT44(uStack_30,uStack_34);
    puStack_15c = (undefined *)0x68034c;
    uStack_150 = uStack_2c;
    uVar6 = FUN_0152dda0();
  }
  piVar4 = uStack_20._4_4_;
  if (uStack_20._4_4_ != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(uStack_20._4_4_ + 1);
    uVar8 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uStack_150._4_4_ = (undefined8 *)0x680365;
      (**(code **)*uStack_20._4_4_)();
      LOCK();
      puVar1 = (uint *)(piVar4 + 2);
      uVar8 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar8 - 1;
      UNLOCK();
      if (uVar8 - 1 == 0) {
        uStack_150._4_4_ = (undefined8 *)0x680375;
        uVar6 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
LAB_00680375:
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_2 + 2);
    uVar8 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uStack_150._4_4_ = (undefined8 *)0x68038a;
      uVar6 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar4 = param_4 + 2;
    iVar2 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      uStack_150._4_4_ = (undefined8 *)0x68039e;
      uVar6 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 8043 ; VA 0x00680510 ; FUN_00680510 */

void __thiscall FUN_00680510(int param_1,undefined4 param_2)

{
  uint *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e768;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01682800(&uStack_20);
  puVar1 = (uint *)(param_1 + 0x34);
  do {
    LOCK();
    uVar5 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar5 & 1) != 0);
  } while (uStack_8 != 0);
  if (*(int *)(param_1 + 0x30) == 0) {
    *(ulonglong *)(param_1 + 0x38) = CONCAT44(uStack_1c,uStack_20);
  }
  uVar5 = *(uint *)(param_1 + 0x28);
  puStack_18 = puVar1;
  if (uVar5 <= *(int *)(param_1 + 0x30) + 1U) {
    FUN_00617300(1);
    uVar5 = *(uint *)(param_1 + 0x28);
  }
  *(uint *)(param_1 + 0x2c) = *(uint *)(param_1 + 0x2c) & uVar5 - 1;
  uVar5 = *(int *)(param_1 + 0x30) + *(int *)(param_1 + 0x2c) & *(int *)(param_1 + 0x28) - 1U;
  iVar4 = *(int *)(param_1 + 0x24);
  if (*(int *)(iVar4 + uVar5 * 4) == 0) {
    uVar3 = FUN_01674e20(0x10);
    *(undefined4 *)(*(int *)(param_1 + 0x24) + uVar5 * 4) = uVar3;
    iVar4 = *(int *)(iStack_14 + 0x24);
  }
  puVar2 = *(undefined4 **)(iVar4 + uVar5 * 4);
  *puVar2 = param_2;
  puVar2[1] = uStack_24;
  puVar2[2] = uStack_20;
  puVar2[3] = uStack_1c;
  *(int *)(param_1 + 0x30) = *(int *)(param_1 + 0x30) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8044 ; VA 0x006805f0 ; FUN_006805f0 */

void __thiscall FUN_006805f0(int param_1,undefined8 *param_2)

{
  uint *puVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4d58;
  pvStack_10 = ExceptionList;
  uVar2 = *param_2;
  uVar3 = *(undefined4 *)(param_2 + 1);
  ExceptionList = &pvStack_10;
  FUN_01682800(&uStack_1c);
  puVar1 = (uint *)(param_1 + 0x14);
  do {
    LOCK();
    uVar7 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar7 & 1) != 0);
  } while (uStack_8 != 0);
  if (*(int *)(param_1 + 0x10) == 0) {
    *(undefined8 *)(param_1 + 0x18) = uStack_1c;
  }
  uVar7 = *(uint *)(param_1 + 8);
  puStack_14 = puVar1;
  if (uVar7 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_006174f0(1);
    uVar7 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar7 - 1;
  uVar7 = *(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U;
  iVar6 = *(int *)(param_1 + 4);
  if (*(int *)(iVar6 + uVar7 * 4) == 0) {
    uVar5 = FUN_01674e20(0x18);
    *(undefined4 *)(*(int *)(param_1 + 4) + uVar7 * 4) = uVar5;
    iVar6 = *(int *)(param_1 + 4);
  }
  puVar4 = *(undefined4 **)(iVar6 + uVar7 * 4);
  uStack_2c = (undefined4)uVar2;
  uStack_28 = (undefined4)((ulonglong)uVar2 >> 0x20);
  *puVar4 = uStack_2c;
  puVar4[1] = uStack_28;
  puVar4[2] = uVar3;
  puVar4[3] = uStack_20;
  *(undefined8 *)(puVar4 + 4) = uStack_1c;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8045 ; VA 0x006806d0 ; FUN_006806d0 */

void __thiscall
FUN_006806d0(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4d7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x40);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_006b1a30(param_1);
    *puVar1 = RBX::Network::Replicator::StreamJob::StreamDataInfoItem::vftable;
    *(undefined8 *)(puVar1 + 0xc) = param_2;
    puVar1[0xe] = param_3;
    puVar1[0xf] = param_4;
  }
  uStack_8 = 0xffffffff;
  FUN_006b1f50(puVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8046 ; VA 0x00680760 ; FUN_00680760 */

void __thiscall FUN_00680760(int *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  
  if ((param_1[0xe02] & 2U) != 0) {
    cVar1 = (**(code **)(*param_1 + 0x11c))();
    if (cVar1 != '\0') {
      cVar1 = FUN_006abd90();
      *(char *)(param_3 + 1) = cVar1;
      if (cVar1 != '\0') {
        FUN_006ab8a0(param_3 + 4,param_2);
      }
    }
  }
  return;
}



/* FUNCTION 8047 ; VA 0x006807b0 ; FUN_006807b0 */

undefined4 __thiscall FUN_006807b0(int *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  byte bVar2;
  char cVar3;
  undefined2 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  undefined8 uVar10;
  undefined auStack_78 [36];
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined uStack_20;
  char cStack_1f;
  int *piStack_1c;
  undefined auStack_18 [4];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4da0;
  pvStack_10 = ExceptionList;
  piStack_1c = param_1;
  switch(param_3) {
  case 8:
    ExceptionList = &pvStack_10;
    FUN_00680d20(param_2);
    ExceptionList = pvStack_10;
    return 1;
  case 9:
    ExceptionList = &pvStack_10;
    cVar3 = FUN_006abe40();
    if (cVar3 == '\0') {
      uStack_3c = FUN_006ace40();
      uStack_38 = FUN_006ace40();
      uStack_34 = FUN_006ace40();
      uStack_30 = FUN_006ace40();
      uStack_2c = FUN_006ace40();
      (**(code **)(*param_1 + 600))(&uStack_3c);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (cVar3 == '\x02') {
      (**(code **)(*param_1 + 0x25c))(uVar6);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (cVar3 == '\x06') {
      (**(code **)(*param_1 + 0x260))(uVar6);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (cVar3 == '\b') {
      (**(code **)(*param_1 + 0x264))(uVar6);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (cVar3 == '\f') {
      (**(code **)(*param_1 + 0x268))(uVar6);
    }
    break;
  case 10:
    ExceptionList = &pvStack_10;
    FUN_006b8fd0(auStack_18,param_2);
    cVar3 = FUN_006abe60(&param_2,2);
    if (cVar3 == '\0') {
      FUN_0054eff0("readFast past end for uint16_t");
      uStack_8 = 0;
      FUN_005f8ef0(auStack_54);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_78,&DAT_01c27108);
    }
    param_2 = (uint)(ushort)((ushort)param_2 << 8 | (ushort)param_2 >> 8);
    (**(code **)(*param_1 + 0x138))(uVar6,&uStack_20);
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    uStack_8 = 1;
    cVar3 = FUN_00621ac0(auStack_18,&iStack_28);
    if (((cVar3 != '\0') && (cStack_1f != '\0')) && (iStack_28 != 0)) {
      FUN_0067e440(iStack_28,param_2 & 0xffff,piStack_1c);
    }
    piVar9 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar7 = piVar9 + 2;
        iVar5 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar9 + 4))();
          ExceptionList = pvStack_10;
          return 1;
        }
      }
    }
    break;
  default:
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00627050(param_2,param_3);
    ExceptionList = pvStack_10;
    return uVar6;
  case 0xc:
    ExceptionList = &pvStack_10;
    uVar6 = FUN_006ac4d0();
    uVar4 = FUN_006ac450();
    if (param_1[0x779] != 0) {
      FUN_006e8c10(uVar6,uVar4);
      ExceptionList = pvStack_10;
      return 1;
    }
    break;
  case 0xe:
    ExceptionList = &pvStack_10;
    if (param_1[0x779] != 0) {
      ExceptionList = &pvStack_10;
      FUN_006e7230(param_2);
      ExceptionList = pvStack_10;
      return 1;
    }
    goto LAB_006809b0;
  case 0xf:
    ExceptionList = &pvStack_10;
    if (param_1[0x779] != 0) {
      ExceptionList = &pvStack_10;
      FUN_006e7190(param_2);
      ExceptionList = pvStack_10;
      return 1;
    }
    goto LAB_006809b0;
  case 0x12:
    param_3 = param_3 & 0xffffff;
    ExceptionList = &pvStack_10;
    bVar2 = FUN_006abe40();
    if (bVar2 == 0xff) {
      param_3 = CONCAT13(1,(undefined3)param_3);
      bVar2 = FUN_006abe40();
    }
    piVar9 = param_1 + 0xf46;
    uStack_14 = (uint)bVar2;
    FUN_005f86c0(uStack_14,piVar9);
    piStack_24 = param_1 + 0xf45;
    iVar5 = FUN_006ace40();
    uVar1 = uStack_14;
    uVar8 = 0;
    param_1[0xf45] = iVar5;
    piVar7 = param_1 + 0xf45;
    if (uStack_14 != 0) {
      do {
        uVar6 = FUN_006ace40();
        *(undefined4 *)(*piVar9 + uVar8 * 4) = uVar6;
        uVar8 = uVar8 + 1;
        piVar7 = piStack_24;
        param_1 = piStack_1c;
      } while (uVar8 < uVar1);
    }
    if (param_3._3_1_ == '\0') {
      iVar5 = 3;
      piVar9 = param_1 + 0xf4a;
      do {
        uVar10 = FUN_006ace60();
        *(undefined8 *)piVar9 = uVar10;
        iVar5 = iVar5 + -1;
        piVar9 = piVar9 + 2;
      } while (iVar5 != 0);
      piVar9 = param_1 + 0xf45;
      (**(code **)(*param_1 + 0x240))(piVar9);
      (**(code **)(*param_1 + 0x244))(piVar9);
      (**(code **)(*param_1 + 0x248))(param_1 + 0xf4a,*piVar9);
      (**(code **)(*param_1 + 0x24c))(piVar9,param_1 + 0xf4a);
      ExceptionList = pvStack_10;
      return 1;
    }
    (**(code **)(*param_1 + 0x250))(piVar7);
    (**(code **)(*param_1 + 0x254))(param_1 + 0xf45);
    ExceptionList = pvStack_10;
    return 1;
  case 0x19:
    if (param_1[0x779] != 0) {
      ExceptionList = &pvStack_10;
      FUN_006e71c0(param_2);
      ExceptionList = pvStack_10;
      return 1;
    }
    ExceptionList = &pvStack_10;
    if (DAT_01ee420a != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01ee420a,
                   "Disconnecting because got prefetch request but not streaming enabled.",0);
    }
LAB_006809b0:
    FUN_0062b370(0x106);
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8048 ; VA 0x00680c70 ; FUN_00680c70 */

void FUN_00680c70(int param_1)

{
  int iVar1;
  undefined auStack_10 [12];
  
  iVar1 = *(int *)(param_1 + 0x10);
  while( true ) {
    if (iVar1 == *(int *)(param_1 + 0x14)) {
      FUN_00627150(param_1);
      return;
    }
    if (*(char *)(iVar1 + 0x48) == '\0') break;
    iVar1 = iVar1 + 0x58;
  }
  FUN_016756b0(auStack_10,"Malformed Join");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 8049 ; VA 0x00680cc0 ; FUN_00680cc0 */

int __thiscall FUN_00680cc0(int *param_1,undefined8 *param_2)

{
  int iVar1;
  int iVar2;
  undefined auStack_34 [36];
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  iVar1 = (**(code **)(*param_1 + 0xb4))();
  if (iVar1 != 0) {
    FUN_0060efa0();
    iVar2 = FUN_00927e40(auStack_34);
    if (iVar2 != 0) {
      *param_2 = uStack_10;
      *(undefined4 *)(param_2 + 1) = uStack_8;
      *(undefined4 *)((int)param_2 + 0xc) = *(undefined4 *)(iVar1 + 0x188);
      return iVar2;
    }
  }
  return 0;
}



/* FUNCTION 8050 ; VA 0x00680d20 ; FUN_00680d20 */

int __thiscall FUN_00680d20(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  double *pdVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined auStack_94 [24];
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  int iStack_4c;
  uint uStack_38;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4ddb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pdVar4 = (double *)FUN_016830f0();
  FUN_0151fb00("CharacterRequestReceived",*pdVar4 - *(double *)(param_1 + 0x3bc0));
  FUN_006ace40();
  FUN_006acbd0();
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = 1;
  uStack_20 = 0xffffffff;
  uStack_1c = 0;
  iVar5 = FUN_006b9040(param_2,&uStack_18,&uStack_20);
  piVar3 = piStack_14;
  if ((char)iVar5 == '\0') {
    if (DAT_01d84e8e != '\0') {
      FUN_016774b0(DAT_01d84e8e,"RequestCharacter - could not resolve RemotePlayer",0);
    }
    FUN_006b1620(auStack_64,param_1 + 0x74,1,0x7c);
    uStack_8._0_1_ = 2;
    uVar6 = FUN_005543f0();
    FUN_009c93d0(auStack_7c,4);
    uStack_8._0_1_ = 3;
    uVar7 = FUN_005543f0();
    FUN_01675640(auStack_94,"Couldn\'t resolve remotePlayer %s from %s",uVar7,uVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_005500e0();
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    iVar5 = iStack_4c;
    if (0xfff < uVar8) {
      iVar5 = *(int *)(iStack_4c + -4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (iStack_4c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 8051 ; VA 0x00680ec0 ; FUN_00680ec0 */

void __thiscall FUN_00680ec0(undefined4 param_1,int param_2)

{
  if ((*(int *)(param_2 + 0x1c) != 0) && (*(int *)(param_2 + 0x14) != 0)) {
    FUN_006d5370(param_2 + 0x14,*(int *)(param_2 + 0x1c),param_2 + 0x20,param_1);
    return;
  }
  FUN_0062b370();
  return;
}



/* FUNCTION 8052 ; VA 0x00680f00 ; FUN_00680f00 */

void __fastcall FUN_00680f00(int param_1)

{
  if ((DAT_01d5b9c0 != '\0') && (*(int *)(param_1 + 0x1de4) != 0)) {
    FUN_006e6400();
    return;
  }
  return;
}



/* FUNCTION 8053 ; VA 0x00680f20 ; FUN_00680f20 */

void __thiscall FUN_00680f20(int param_1,undefined4 param_2)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  bool bVar7;
  double in_XMM0_Qa;
  double dVar8;
  undefined auStack_94 [56];
  uint uStack_5c;
  int iStack_58;
  uint uStack_44;
  int iStack_40;
  double dStack_3c;
  double dStack_34;
  double dStack_2c;
  double dStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4df8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x3d4c) = 1;
  if (*(int *)(param_1 + 0x6c) != 0) {
    iVar3 = FUN_0054db20();
    if (iVar3 != 0) {
      piVar4 = (int *)FUN_0054db20();
      cVar2 = (**(code **)(*piVar4 + 300))(param_1 + 0x74,auStack_94,param_2);
      if (cVar2 != '\0') {
        iStack_1c = 0;
        uStack_18 = 0;
        iStack_14 = 0;
        uStack_8 = 0;
        FUN_016f4020();
        dStack_2c = in_XMM0_Qa;
        FUN_016f4020();
        dStack_3c = in_XMM0_Qa;
        FUN_016f4020();
        dVar8 = 0.0;
        dStack_34 = 0.0;
        if ((NAN(dStack_2c) == (dStack_2c == 0.0)) && (NAN(in_XMM0_Qa) == (in_XMM0_Qa == 0.0))) {
          dStack_24 = in_XMM0_Qa;
          FUN_016f4020();
          dVar8 = dVar8 / dStack_24;
          uVar5 = (uint)(uStack_5c < uStack_44);
          uVar1 = iStack_58 - iStack_40;
          bVar7 = (int)(uVar1 - uVar5) < 0;
          dStack_24 = dVar8;
          if ((!bVar7) &&
             (((uVar1 != uVar5 && (SBORROW4(iStack_58,iStack_40) != SBORROW4(uVar1,uVar5)) == bVar7
               || (uStack_5c != uStack_44)) && (uStack_5c != 0 || iStack_58 != 0)))) {
            FUN_016f3900();
            FUN_016f4020();
            dStack_34 = dVar8;
          }
          iVar3 = FUN_008f7870(param_1);
          piVar4 = *(int **)(iVar3 + 0x43c);
          iVar3 = piVar4[1] - (int)piVar4;
          iVar6 = *piVar4 - (int)piVar4;
          FUN_0067af90(&iStack_1c,"GameLoadDataStatistics_RakNetSent",dStack_2c,iVar6,iVar3,param_2)
          ;
          FUN_0067af90(&iStack_1c,"GameLoadDataStatistics_SocketSentTotal",dStack_3c,iVar6,iVar3,
                       param_2);
          FUN_0067af90(&iStack_1c,"GameLoadDataStatistics_ResentRatio",dStack_24,iVar6,iVar3,param_2
                      );
          FUN_0067af90(&iStack_1c,"GameLoadDataStatistics_TimeoutResentRatio",dStack_34,iVar6,iVar3,
                       param_2);
          FUN_00874d70(&iStack_1c,0);
          if (iStack_1c != 0) {
            FUN_00559500(iStack_1c,uStack_18,&iStack_1c);
            uVar5 = iStack_14 - iStack_1c & 0xffffffe0;
            iVar3 = iStack_1c;
            if (0xfff < uVar5) {
              iVar3 = *(int *)(iStack_1c + -4);
              uVar5 = uVar5 + 0x23;
              if (0x1f < (iStack_1c - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar3,uVar5);
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8054 ; VA 0x00681170 ; FUN_00681170 */

int __fastcall FUN_00681170(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 auStack_4c [5];
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a608;
  pvStack_10 = ExceptionList;
  uStack_2c = *(undefined4 *)(param_1 + 0x3c1c);
  uStack_30 = 0x681199;
  ExceptionList = &pvStack_10;
  uStack_30 = FUN_008f7870();
  piStack_34 = &iStack_1c;
  uStack_38 = 0x6811a3;
  iVar4 = FUN_005c4330();
  uStack_8 = 0;
  if (iStack_1c != 0) {
    uStack_2c = 1;
    puStack_14 = auStack_4c;
    iVar4 = iStack_1c;
    puVar3 = auStack_4c;
    if (piStack_18 != (int *)0x0) {
      piVar1 = piStack_18 + 2;
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      puVar3 = auStack_4c;
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
        puVar3 = puStack_14;
      }
      puStack_14 = puVar3;
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      iVar4 = iStack_1c;
      puVar3 = puStack_14;
    }
    puStack_14 = puVar3;
    *puStack_14 = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    FUN_006705d0(FUN_00616a40,iVar4,piStack_18);
    if (piStack_18 != (int *)0x0) {
      piVar1 = piStack_18 + 2;
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    iVar4 = FUN_0090ca30();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_2c = 0x681295;
      iVar4 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = 0x6812a4;
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 8055 ; VA 0x006812c0 ; FUN_006812c0 */

void FUN_006812c0(void)

{
  FUN_006b88d0();
  return;
}



/* FUNCTION 8056 ; VA 0x006812d0 ; FUN_006812d0 */

void __fastcall FUN_006812d0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  uVar2 = *(undefined4 *)(param_1 + 0x58);
  pcVar3 = *(code **)(param_1 + 0x3c);
  uVar4 = *(undefined4 *)(param_1 + 0x54);
  uVar5 = *(undefined4 *)(param_1 + 0x50);
  if (*(int *)(param_1 + 0x4c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x4c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = *(undefined4 *)(param_1 + 0x48);
  uVar7 = *(undefined4 *)(param_1 + 0x4c);
  if (*(int *)(param_1 + 0x44) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x44) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(*(undefined4 *)(param_1 + 0x40),*(undefined4 *)(param_1 + 0x44),uVar6,uVar7,uVar5,uVar4,
            uVar2);
  return;
}



/* FUNCTION 8057 ; VA 0x00681340 ; FUN_00681340 */

undefined4 __thiscall
FUN_00681340(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined2 param_8)

{
  code *pcVar1;
  int *piVar2;
  undefined4 in_stack_00000044;
  
  if (*(int *)(param_1 + 0x6c) != 0) {
    piVar2 = (int *)FUN_0054db20();
    if (piVar2 != (int *)0x0) {
      pcVar1 = *(code **)(*piVar2 + 0x4c);
      FUN_005f70a0();
      FUN_005f7140();
      FUN_005f7170(&stack0x00000024);
      (*pcVar1)(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8058 ; VA 0x006813c0 ; FUN_006813c0 */

void __thiscall FUN_006813c0(int *param_1,undefined4 param_2,char param_3)

{
  byte *pbVar1;
  undefined uVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  byte *pbVar12;
  byte *pbVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 *puVar16;
  undefined auStack_58 [12];
  undefined auStack_4c [12];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int aiStack_38 [2];
  undefined4 uStack_30;
  int *piStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  byte *pbStack_20;
  byte *pbStack_1c;
  int iStack_18;
  byte abStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a4e3b;
  pvStack_10 = ExceptionList;
  pbStack_20 = (byte *)0x0;
  pbStack_1c = (byte *)0x0;
  iStack_18 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(*param_1 + 0x11c))();
  uVar4 = FUN_00672fb0(param_1);
  uVar14 = 0x681424;
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,uVar2);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_005c2c60();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00674180();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00674d10();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  piVar11 = (int *)param_1[0xd];
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01d5af30 != '\0');
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00674620();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,uStack_24,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_006743d0();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0063f510();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0055e000();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00562f00();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00671b50();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_0055e560();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01d5af28 != '\0');
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00674ac0();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,uStack_24,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00634b40();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_006715f0();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_005f4cd0();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00671840();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00672050();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_005f4830();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00673410();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00673660();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00674f60();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00671e00();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00672860();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_006710f0();
  }
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  piVar11 = (int *)param_1[0xd];
  piVar5 = param_1;
  if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
    piVar5 = (int *)FUN_005c8ac0();
  }
  if ((piVar5 == (int *)0x0) ||
     (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
     (uint)*(ushort *)(iVar6 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00673f30();
  }
  uVar15 = 0x681d70;
  FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  if (DAT_01d680f0 != '\0') {
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_006731c0();
    }
    uVar15 = 0x681ddb;
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  }
  if (DAT_01d63584 != '\0') {
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00672ab0();
    }
    uVar15 = 0x681e46;
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  }
  if (DAT_01d68228 != '\0') {
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00672d00();
    }
    uVar15 = 0x681eb1;
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
  }
  cVar3 = (**(code **)(*param_1 + 0x11c))();
  if (cVar3 != '\0') {
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_006738b0();
    }
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00673ce0();
    }
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,1);
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0055e310();
    }
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,1);
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_005c2a10();
    }
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
    piVar11 = (int *)param_1[0xd];
    piVar5 = param_1;
    if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
      piVar5 = (int *)FUN_005c8ac0();
    }
    if ((piVar5 == (int *)0x0) ||
       (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00671340();
    }
    uVar15 = 0x6820af;
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,1);
    if (DAT_01d656d0 != '\0') {
      piVar11 = (int *)param_1[0xd];
      piVar5 = param_1;
      if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
        piVar5 = (int *)FUN_005c8ac0();
      }
      if ((piVar5 == (int *)0x0) ||
         (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_00675400();
      }
      uVar15 = 0x68211a;
      FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
    }
    if (DAT_01d656f0 != '\0') {
      piVar11 = (int *)param_1[0xd];
      piVar5 = param_1;
      if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
        piVar5 = (int *)FUN_005c8ac0();
      }
      if ((piVar5 == (int *)0x0) ||
         (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_00674870();
      }
      uVar15 = 0x682185;
      FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
    }
    if (DAT_01d635f4 != '\0') {
      piVar11 = (int *)param_1[0xd];
      piVar5 = param_1;
      if ((piVar11 != (int *)0x0) && (piVar5 = piVar11, piVar11[0xd] != 0)) {
        piVar5 = (int *)FUN_005c8ac0();
      }
      if ((piVar5 == (int *)0x0) ||
         (iVar7 = piVar5[3], iVar6 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_006751b0();
      }
      uVar15 = 0x6821f0;
      FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,0,0);
    }
  }
  if ((DAT_01d665a8 != '\0') && (cVar3 = (**(code **)(*param_1 + 0x120))(), cVar3 == '\0')) {
    iVar7 = FUN_005c8880(param_1);
    if (iVar7 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_006725b0();
    }
    uVar15 = 0x682238;
    FUN_0067c050(param_1[0x67d],&pbStack_20,uVar4,1,0);
  }
  pbVar13 = pbStack_1c;
  pbVar12 = pbStack_20;
  uVar8 = ((int)pbStack_1c - (int)pbStack_20) / 0xc;
  if (DAT_01d59eec <= uVar8) {
    if (DAT_01eace68 != 0) {
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8._0_1_ = 1;
      uVar4 = FUN_006838d0();
      FUN_0151f9c0("Count",uVar4);
      FUN_0151f850(&DAT_018bf030,"TopReplicationContainer (write)");
      iVar7 = DAT_01eace68;
      FUN_0054eff0("ReplicatorTopContainerCountLimit");
      iStack_8._0_1_ = 2;
      FUN_01520d20(auStack_58,iVar7,0);
      FUN_005507b0();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_0151f7f0();
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Too many top replication containers");
  }
  FUN_006ad4e0(uVar8,param_2);
  if (pbVar12 != pbVar13) {
    pbVar13 = pbVar12 + 9;
    do {
      FUN_00628420(*(undefined4 *)(pbVar13 + -5));
      uStack_40 = *(undefined4 *)(*(int *)(pbVar13 + -5) + 0x18);
      uStack_3c = *(undefined4 *)(*(int *)(pbVar13 + -5) + 0x1c);
      FUN_006b92d0(param_2,&uStack_40);
      uStack_28 = (uint)*(ushort *)(pbVar13 + -9);
      FUN_006a5c10(&uStack_28,&uStack_24,2);
      FUN_006ad5e0(&uStack_24,2);
      abStack_14[0] = pbVar13[-1];
      FUN_006ad5e0(abStack_14,1);
      abStack_14[0] = *pbVar13;
      FUN_006ad5e0(abStack_14,1);
      piVar11 = (int *)0x0;
      uStack_30 = 0;
      piStack_2c = (int *)0x0;
      iStack_8._0_1_ = 3;
      cVar3 = FUN_0061f540();
      if ((((cVar3 != '\0') && (param_3 == '\0')) && (pbVar13[-1] == 0)) && (*pbVar13 != 0)) {
        iVar7 = FUN_006193b0(*(undefined2 *)(pbVar13 + -9));
        if (iVar7 == 0) {
          FUN_016756b0(auStack_4c,
                       "Top replication container definition included invalid class network id");
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_4c,&DAT_01c17198);
        }
        FUN_008a98b0(aiStack_38,param_1,*(undefined4 *)(*(int *)(iVar7 + 8) + 4));
        iStack_8._0_1_ = 4;
        if (aiStack_38[0] != 0) {
          uVar8 = (uint)DAT_01d5b840;
          uVar9 = (uint)*pbVar13;
          uVar10 = (uint)pbVar13[-1];
          puVar16 = &uStack_30;
          uVar4 = 0;
          FUN_00557fc0(aiStack_38);
          FUN_00617d00(iVar7,uVar14,uVar15,uVar10,uVar9,uVar4,puVar16,uVar8);
        }
        iStack_8._0_1_ = 3;
        FUN_00550b30();
        piVar11 = piStack_2c;
      }
      if (((DAT_01d5a098 != '\0') && (param_3 != '\0')) && ((pbVar13[-1] == 0 && (*pbVar13 != 0))))
      {
        FUN_006d9060();
        FUN_006c9050(*(undefined4 *)(pbVar13 + -5));
        piVar11 = piStack_2c;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar7 = piVar11[1] + -1;
        piVar11[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar7 = piVar11[2] + -1;
          piVar11[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      pbVar1 = pbVar13 + 3;
      pbVar12 = pbStack_20;
      pbVar13 = pbVar13 + 0xc;
    } while (pbVar1 != pbStack_1c);
  }
  if (pbVar12 != (byte *)0x0) {
    FUN_0061a4e0(pbVar12,(iStack_18 - (int)pbVar12) / 0xc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8059 ; VA 0x00682500 ; FUN_00682500 */

uint __thiscall FUN_00682500(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  bool bVar9;
  
  iVar7 = *(int *)(param_1 + 0x3b94);
  iVar4 = *(int *)(iVar7 + 0x50);
  uVar1 = *(uint *)(param_2 + 0xc);
  if ((iVar4 != *(int *)(iVar7 + 0x54)) && (uVar1 != *(uint *)(iVar7 + 0x60))) {
    uVar3 = (uVar1 >> 3) + uVar1;
    uVar8 = (*(int *)(iVar7 + 0x54) - iVar4 >> 2) - 1;
    uVar6 = 0;
    do {
      uVar3 = uVar3 & uVar8;
      uVar2 = *(uint *)(iVar4 + uVar3 * 4);
      if (uVar2 == uVar1) goto LAB_006825a7;
      if (uVar2 == *(uint *)(iVar7 + 0x60)) break;
      uVar3 = uVar3 + 1 + uVar6;
      uVar6 = uVar6 + 1;
    } while (uVar6 <= uVar8);
  }
  iVar4 = FUN_00aff8c0();
  uVar3 = (uint)*(ushort *)(iVar4 + 0x1da);
  iVar7 = 0;
  if ((uint)*(ushort *)(uVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <= uVar3) {
    iVar7 = param_2;
  }
  if (iVar7 == 0) {
    iVar7 = *(int *)(param_2 + 0xc);
    iVar5 = FUN_00add460();
    uVar3 = (uint)*(ushort *)(iVar5 + 0x1da);
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= uVar3) {
      iVar4 = param_2;
    }
    if (iVar4 == 0) {
      iVar7 = *(int *)(param_2 + 0xc);
      iVar5 = FUN_00913630();
      uVar3 = (uint)*(ushort *)(iVar5 + 0x1da);
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= uVar3) {
        iVar4 = param_2;
      }
      if (iVar4 == 0) {
        iVar7 = *(int *)(param_2 + 0xc);
        iVar4 = FUN_00c31b40();
        uVar3 = (uint)*(ushort *)(iVar4 + 0x1da);
        if (uVar3 < (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))
        goto LAB_0068262d;
      }
    }
  }
  else if ((*(byte *)(iVar7 + 0xb4) & 2) == 0) {
    if (DAT_01d6866c == '\0') {
      bVar9 = *(int *)(iVar7 + 0x70) == 0;
    }
    else {
      bVar9 = *(int *)(iVar7 + 0x6c) == -1;
    }
    uVar3 = (uint)CONCAT11((char)(*(ushort *)(iVar4 + 0x1da) >> 8),bVar9);
    if (bVar9 != false) {
LAB_0068262d:
      return CONCAT31((int3)(uVar3 >> 8),1);
    }
  }
LAB_006825a7:
  return uVar3 & 0xffffff00;
}



/* FUNCTION 8060 ; VA 0x00682640 ; FUN_00682640 */

int * FUN_00682640(int *param_1,undefined4 param_2)

{
  char acStack_20 [4];
  undefined4 uStack_1c;
  char acStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4e58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00644bc0(acStack_20,param_2);
  uStack_8 = 0;
  if (acStack_20[0] != '\0') {
    FUN_00644e20(acStack_18,uStack_1c);
    *param_1 = iStack_14;
    LOCK();
    *(int *)(iStack_14 + 0x28) = *(int *)(iStack_14 + 0x28) + 1;
    UNLOCK();
    if (acStack_18[0] != '\0') {
      FUN_0056cd30();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00a33c70();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8061 ; VA 0x006826e0 ; FUN_006826e0 */

int __thiscall FUN_006826e0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_0062d220(param_2);
  if (iVar1 == 0) {
    return 0;
  }
  if ((*(char *)(*(int *)(param_1 + 0x3c1c) + 0x3a5) != '\0') &&
     (*(char *)(param_1 + 0x18fc) == '\0')) {
    while ((*(int *)(param_1 + 0x18f0) != 0 && (*(int *)(*(int *)(param_1 + 0x18f0) + 0x20) == 2)))
    {
      iVar2 = FUN_0062d220(param_2);
      if (iVar2 == 0) {
        return iVar1;
      }
      iVar1 = iVar1 + iVar2;
      if (*(char *)(param_1 + 0x18fc) != '\0') {
        return iVar1;
      }
    }
  }
  return iVar1;
}



/* FUNCTION 8062 ; VA 0x00682750 ; FUN_00682750 */

undefined4 __thiscall FUN_00682750(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (DAT_01d59fc0 != '\0') {
    uVar2 = FUN_0062e250(param_2);
    return uVar2;
  }
  cVar1 = FUN_0062e250(param_2);
  if (cVar1 != '\0') {
    if (*(char *)(*(int *)(param_1 + 0x3c1c) + 0x3a5) == '\0') {
      if ((*(char *)(param_1 + 0x3c29) == '\0') && (iVar3 = 0, DAT_01d651d3 != 0)) {
        do {
          uVar2 = FUN_0061e980();
          cVar1 = FUN_0062e250(uVar2);
          if (cVar1 == '\0') {
            return 0;
          }
          iVar3 = iVar3 + 1;
        } while (iVar3 < (int)(uint)DAT_01d651d3);
      }
    }
    else {
      while (*(char *)(param_1 + 0x3c29) == '\0') {
        uVar2 = FUN_0061e980();
        cVar1 = FUN_0062e250(uVar2);
        if (cVar1 == '\0') {
          return 1;
        }
      }
    }
    return 1;
  }
  return 0;
}



/* FUNCTION 8063 ; VA 0x00682800 ; FUN_00682800 */

void __fastcall FUN_00682800(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *unaff_FS_OFFSET;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  uint uStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_10 = *unaff_FS_OFFSET;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  *unaff_FS_OFFSET = &uStack_10;
  if (*(int *)(param_1 + 0x1a18) != 0) {
    cVar2 = FUN_00afc8c0();
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    if (cVar2 != '\0') goto LAB_0068283a;
  }
  uStack_14 = uStack_14 & 0xffffff00;
LAB_0068283a:
  FUN_0151fcf0("HasTerrain",uStack_14);
  iVar3 = FUN_0061f4a0();
  FUN_0151fc50("BytesSent",*(undefined4 *)(iVar3 + 0x60),*(undefined4 *)(iVar3 + 100));
  uVar1 = DAT_01ead4a0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ServerJoin",10);
  uStack_8 = 0;
  FUN_01520d20(auStack_2c,uVar1,0);
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  *unaff_FS_OFFSET = uStack_10;
  return;
}



/* FUNCTION 8064 ; VA 0x006828f0 ; FUN_006828f0 */

void __thiscall FUN_006828f0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined2 uVar3;
  undefined auStack_3c [40];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4e78;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x3c0c) != 0) {
    ExceptionList = &pvStack_10;
    FUN_006ab530();
    uStack_8 = 0;
    auStack_14[0] = 0x98;
    FUN_006ad5e0(auStack_14,1);
    FUN_006ae570(param_2);
    FUN_005f70a0();
    FUN_005f7140();
    uVar1 = DAT_01d5ae88;
    uVar2 = DAT_01d5ae8c;
    uVar3 = DAT_01d5ae90;
    FUN_005f7170(param_1 + 0x74);
    FUN_00681340(auStack_3c,0,3,0,uVar1,uVar2,uVar3);
    FUN_00613200();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8065 ; VA 0x006829b0 ; FUN_006829b0 */

void __fastcall FUN_006829b0(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  puVar4 = (undefined4 *)FUN_006448b0(auStack_10);
  uVar1 = *puVar4;
  uVar5 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 *)(param_1 + 0x3b94) = uVar1;
  piVar2 = *(int **)(param_1 + 0x3b98);
  *(undefined4 *)(param_1 + 0x3b98) = uVar5;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_c[1] + -1;
    piStack_c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar2 = piStack_c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  uVar1 = *(undefined4 *)(param_1 + 0x3b94);
  FUN_005f70a0();
  FUN_005f7140();
  uVar5 = DAT_01d5ae88;
  uVar6 = DAT_01d5ae8c;
  uVar7 = DAT_01d5ae90;
  FUN_005f7170(iStack_8 + 0x74);
  FUN_00681340(uVar1,2,3,0,uVar5,uVar6,uVar7);
  return;
}



/* FUNCTION 8066 ; VA 0x00682aa0 ; FUN_00682aa0 */

void __thiscall FUN_00682aa0(int *param_1,code *param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  double *pdVar10;
  char *pcVar11;
  uint uVar12;
  undefined4 *puVar13;
  float fVar14;
  undefined8 uVar15;
  undefined4 uVar16;
  undefined2 uVar17;
  undefined4 auStack_cc [3];
  undefined4 uStack_c0;
  code *pcStack_bc;
  double *pdStack_b8;
  undefined8 uStack_b4;
  double dStack_a4;
  char *pcStack_9c;
  int *piStack_98;
  undefined8 uStack_94;
  char cStack_8c;
  int iStack_84;
  int *piStack_80;
  undefined auStack_7c [24];
  code *pcStack_64;
  char *pcStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  code *pcStack_48;
  int iStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [4];
  int iStack_34;
  int *piStack_30;
  code *pcStack_2c;
  undefined auStack_28 [4];
  code *pcStack_24;
  int *piStack_20;
  int *piStack_1c;
  char cStack_15;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f2c;
  pvStack_10 = ExceptionList;
  uStack_4c = 0;
  pcStack_24 = *(code **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  if (*(int *)((int)pcStack_24 + 0x34) < DAT_01eadd10) {
    uStack_b4._4_4_ = (char *)&DAT_01eadd10;
    uStack_b4._0_4_ = (char *)0x6833d5;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eadd10 == -1) {
      uStack_b4._4_4_ = (char *)0xffffffff;
      uStack_b4._0_4_ = "Server Join Snapshot";
      pdStack_b8 = (double *)&DAT_018c5904;
      uStack_8 = 0;
      cStack_15 = DAT_01d7ad48;
      pcStack_bc = (code *)0x683405;
      uStack_b4 = FUN_0152dab0();
      piStack_1c = (int *)((ulonglong)uStack_b4 >> 0x20);
      pcVar11 = (char *)uStack_b4;
      if ((cStack_15 != '\0') && (DAT_01d7ad40 != '\0')) {
        pdStack_b8 = (double *)0x683425;
        FUN_01532a30();
      }
      uStack_b4._4_4_ = (char *)&DAT_01eadd10;
      uStack_8 = 0xffffffff;
      uStack_b4._0_4_ = (char *)0x683449;
      DAT_01eadd08 = pcVar11;
      DAT_01eadd0c = piStack_1c;
      FUN_016f37bf();
    }
  }
  cStack_15 = DAT_01d7ad48;
  uStack_b4._4_4_ = (char *)DAT_01eadd0c;
  uStack_b4._0_4_ = DAT_01eadd08;
  pcStack_54 = DAT_01eadd08;
  pcStack_9c = DAT_01eadd08;
  piStack_50 = DAT_01eadd0c;
  piStack_98 = DAT_01eadd0c;
  pdStack_b8 = (double *)0x682b1b;
  uStack_94 = FUN_01532c80();
  cStack_8c = cStack_15;
  pdStack_b8 = &dStack_a4;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  pcStack_bc = (code *)0x682b43;
  FUN_016827e0();
  if (DAT_01ee420a != 0) {
    uStack_b4._4_4_ = (char *)0x0;
    pdStack_b8 = (double *)(uint)DAT_01ee420a;
    uStack_b4._0_4_ = "ServerReplicator:sendTop - begin";
    pcStack_bc = (code *)0x682b5f;
    FUN_016774b0();
  }
  if (param_2 == (code *)0x0) {
    uStack_b4._4_4_ = "ServerReplicator unable to find rawPeer.";
  }
  else {
    uStack_b4._4_4_ = (char *)0x682b74;
    FUN_006ab530();
    uStack_b4._4_4_ = (char *)0x1;
    uStack_b4._0_4_ = auStack_14;
    uStack_8._0_1_ = 2;
    auStack_14[0] = 0x81;
    pdStack_b8 = (double *)0x682b8a;
    FUN_006ad5e0();
    auStack_14[0] = param_1[0x779] != 0;
    uStack_b4._0_4_ = auStack_14;
    uStack_b4._4_4_ = (char *)0x1;
    pdStack_b8 = (double *)0x682ba3;
    FUN_006ad5e0();
    uStack_b4._0_4_ = (char *)0x682ba9;
    uStack_b4._4_4_ = (char *)param_1;
    iVar4 = FUN_005c3ac0();
    if (iVar4 != 0) {
      uStack_b4._4_4_ = (char *)0x682bc8;
      cVar3 = (**(code **)(*param_1 + 0x11c))();
      auStack_14[0] = cVar3 == '\0';
      uStack_b4._4_4_ = (char *)0x1;
      uStack_b4._0_4_ = auStack_14;
      pdStack_b8 = (double *)0x682bdc;
      FUN_006ad5e0();
      if ((param_1[0xe02] & 0x10000000U) == 0) {
        auStack_14[0] = *(undefined *)(iVar4 + 0x328);
      }
      else {
        piStack_1c = (int *)param_1[0xd];
        piVar7 = param_1;
        if ((piStack_1c != (int *)0x0) && (piVar7 = piStack_1c, piStack_1c[0xd] != 0)) {
          uStack_b4._4_4_ = (char *)0x682c0d;
          piVar7 = (int *)FUN_005c8ac0();
        }
        piStack_1c = piVar7;
        if (piStack_1c != (int *)0x0) {
          iVar4 = piStack_1c[3];
          uStack_b4._4_4_ = (char *)0x682c23;
          iVar8 = FUN_008a8c30();
          if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
              (uint)*(ushort *)(iVar8 + 0x1da)) {
            uStack_b4._4_4_ = (char *)0x682c46;
            FUN_00672300();
          }
        }
        uStack_b4._4_4_ = (char *)0x682c53;
        auStack_14[0] = FUN_007cfe50();
        uStack_b4._4_4_ = (char *)0x1;
        uStack_b4._0_4_ = auStack_14;
        pdStack_b8 = (double *)0x682c64;
        FUN_006ad5e0();
        uStack_b4._4_4_ = (char *)0x682c6b;
        auStack_14[0] = FUN_00838a70();
        uStack_b4._4_4_ = (char *)0x1;
        uStack_b4._0_4_ = auStack_14;
        pdStack_b8 = (double *)0x682c7c;
        FUN_006ad5e0();
        uStack_b4._4_4_ = (char *)0x682c83;
        auStack_14[0] = FUN_00bfe4e0();
      }
      uStack_b4._4_4_ = (char *)0x1;
      uStack_b4._0_4_ = auStack_14;
      pdStack_b8 = (double *)0x682c94;
      FUN_006ad5e0();
      uStack_b4._4_4_ = (char *)0x1;
      auStack_14[0] = *(undefined *)(param_1[0x770] + 0xa1);
      uStack_b4._0_4_ = auStack_14;
      pdStack_b8 = (double *)0x682cb1;
      FUN_006ad5e0();
      if (DAT_01ee420a != 0) {
        uStack_b4._4_4_ = (char *)param_1[0xec0];
        pdStack_b8 = (double *)(uint)DAT_01ee420a;
        uStack_b4._0_4_ = "Sending peer id = %u";
        pcStack_bc = (code *)0x682cce;
        FUN_016774b0();
      }
      uStack_b4._4_4_ = auStack_7c;
      uStack_b4._0_4_ = (char *)param_1[0xec0];
      pdStack_b8 = (double *)0x682ce0;
      FUN_006ad4e0();
      uStack_b4._4_4_ = (char *)0x682cef;
      cVar3 = (**(code **)(*param_1 + 0x124))();
      if (cVar3 == '\0') {
        uStack_b4._4_4_ = (char *)0x682cf8;
        cVar3 = FUN_00554b40();
        if ((cVar3 != '\0') && ((param_1[0xe02] & 0x80U) == 0)) {
          uStack_b4._0_4_ = (char *)0x682d12;
          uStack_b4._4_4_ = (char *)param_1;
          iVar4 = FUN_008f7870();
          uVar12 = **(int **)(iVar4 + 0x43c) - (int)*(int **)(iVar4 + 0x43c);
          if (DAT_01d5b288 == '\0') {
            uStack_b4._4_4_ = (char *)0x682d34;
            uVar5 = FUN_009edf00();
          }
          else {
            uVar5 = 1;
          }
          uStack_b4._4_4_ = (char *)(uVar12 ^ uVar5);
          uStack_b4._0_4_ = (char *)0x682d41;
          FUN_006323c0();
          if (DAT_01d5b288 == '\0') {
            uStack_b4._4_4_ = (char *)0x682d5d;
            uVar5 = (**(code **)(*param_1 + 0x26c))();
          }
          else {
            uVar5 = 1;
          }
          uStack_b4._4_4_ = (char *)(uVar12 ^ uVar5);
          uStack_b4._0_4_ = (char *)0x682d68;
          FUN_006323c0();
        }
      }
      iVar4 = *(int *)(param_1[0x76d] + 8);
      piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,iVar4 == 0);
      pcStack_2c = pcStack_64;
      uStack_b4._4_4_ = (char *)piStack_1c;
      uStack_b4._0_4_ = auStack_7c;
      pdStack_b8 = (double *)0x682d8b;
      FUN_006813c0();
      uVar12 = param_1[0xe02];
      if (((uVar12 & 0x20000) == 0) || (piStack_30 = (int *)param_1[0xe03], iVar4 == 0)) {
        uStack_b4._4_4_ = (char *)pcStack_2c;
        uStack_b4._0_4_ = (char *)0x682db5;
        FUN_006ab690();
        uStack_b4._4_4_ = auStack_7c;
        uStack_b4._0_4_ = (char *)0x682dc0;
        FUN_0062bef0();
        piStack_30 = (int *)param_1[0xe03];
        uVar12 = param_1[0xe02];
      }
      if ((uVar12 & 0x20000) != 0) {
        if (*(int *)((int)pcStack_24 + 0x34) < DAT_01eadd20) {
          uStack_b4._4_4_ = (char *)&DAT_01eadd20;
          uStack_b4._0_4_ = (char *)0x683476;
          FUN_016f3809();
          if (DAT_01eadd20 == -1) {
            uStack_b4._4_4_ = (char *)0xffffffff;
            uStack_b4._0_4_ = "SerializingJoinInstances";
            pdStack_b8 = (double *)&DAT_018c5904;
            uStack_8._0_1_ = 3;
            pcStack_bc = (code *)0x68349b;
            uVar15 = FUN_0152dab0();
            DAT_01eadd1c = (int)((ulonglong)uVar15 >> 0x20);
            DAT_01eadd18 = (code *)uVar15;
            pcStack_bc = (code *)&DAT_01eadd20;
            uStack_8._0_1_ = 2;
            uStack_c0 = 0x6834b4;
            FUN_016f37bf();
          }
        }
        uStack_b4._4_4_ = (char *)DAT_01eadd1c;
        uStack_b4._0_4_ = (char *)DAT_01eadd18;
        pcStack_2c = DAT_01eadd18;
        pcStack_48 = DAT_01eadd18;
        pcStack_24 = (code *)DAT_01eadd1c;
        iStack_44 = DAT_01eadd1c;
        pdStack_b8 = (double *)0x682e10;
        uStack_40 = FUN_0152d930();
        uStack_8._0_1_ = 4;
        if (DAT_01ee420a != 0) {
          uStack_b4._4_4_ = (char *)0x0;
          pdStack_b8 = (double *)(uint)DAT_01ee420a;
          uStack_b4._0_4_ = "Serializing Instances and preparing blobs for JoinDataItemV2";
          pcStack_bc = (code *)0x682e37;
          FUN_016774b0();
        }
        uStack_b4._4_4_ = (char *)0xc8;
        uStack_b4._0_4_ = (char *)0x682e44;
        piStack_30 = (int *)FUN_01674e20();
        uStack_8._0_1_ = 5;
        if (piStack_30 == (int *)0x0) {
          uVar6 = 0;
        }
        else {
          uStack_b4._0_4_ = (char *)0x682e5a;
          uStack_b4._4_4_ = (char *)param_1;
          uVar6 = FUN_006f8a10();
        }
        uStack_b4._4_4_ = (char *)piStack_1c;
        uStack_8._0_1_ = 4;
        uStack_b4._0_4_ = (char *)0x682e72;
        uStack_b4._0_4_ = (char *)FUN_006d9060();
        pcStack_bc = (code *)0x682e7b;
        pdStack_b8 = (double *)param_1;
        FUN_006fa7f0();
        uStack_b4._0_4_ = (char *)0x682e87;
        uStack_b4._4_4_ = (char *)uVar6;
        FUN_006b1f50();
        uStack_8._0_1_ = 6;
        pdStack_b8 = (double *)pcStack_24;
        pcStack_bc = pcStack_2c;
        uStack_c0 = 0x682e9c;
        uStack_b4 = uStack_40;
        FUN_0152dda0();
        uStack_8._0_1_ = 2;
      }
      if (DAT_01d5b840 != '\0') {
        *(int *)(param_1[0x76d] + 0x218) = *(int *)(param_1[0x76d] + 0x218) + 1;
        *(undefined *)(param_1 + 0xe25) = 1;
      }
      if (DAT_01d5b880 != '\0') {
        *(int *)(param_1[0x76d] + 0x21c) = *(int *)(param_1[0x76d] + 0x21c) + 1;
      }
      uStack_b4._4_4_ = (char *)0x58;
      uStack_b4._0_4_ = (char *)0x682edb;
      piStack_30 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 7;
      if (piStack_30 == (int *)0x0) {
        uStack_b4._4_4_ = (char *)0x0;
      }
      else {
        piStack_1c = auStack_cc;
        pcStack_48 = FUN_00620ef0;
        iStack_44 = 0;
        uStack_40._0_4_ = param_1;
        cVar3 = FUN_00585a40(&pcStack_48);
        piVar9 = piStack_1c;
        uVar6 = uStack_40._4_4_;
        piVar7 = (int *)uStack_40;
        iVar4 = iStack_44;
        if (cVar3 == '\0') {
          piStack_1c[2] = (int)pcStack_48;
          piVar9[3] = iVar4;
          piVar9[4] = (int)piVar7;
          piVar9[5] = uVar6;
          uVar6 = 0xd;
          *piVar9 = (int)&DAT_018d62b1;
          uStack_b4._4_4_ = (char *)FUN_00703220(param_1,uVar6);
        }
        else {
          uVar6 = 0xd;
          *piStack_1c = 0;
          uStack_b4._4_4_ = (char *)FUN_00703220(param_1,uVar6);
        }
      }
      uStack_8._0_1_ = 2;
      uStack_b4._0_4_ = (char *)0x682f5f;
      FUN_006b1f50();
      iVar4 = *(int *)(param_1[0x76d] + 0x1fc);
      param_1[0xe04] = *(int *)(param_1[0x76d] + 0x1f8);
      param_1[0xe05] = iVar4;
      piVar7 = (int *)param_1[0xf17];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = (int *)param_1[0xf17];
      }
      iStack_34 = param_1[0xf16];
      uStack_b4._4_4_ = (char *)&iStack_34;
      uStack_8._0_1_ = 8;
      uStack_b4._0_4_ = (char *)0x682fac;
      piStack_30 = piVar7;
      FUN_0067f4a0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar4 = piVar7[1] + -1;
        piVar7[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_b4._4_4_ = (char *)0x682fc4;
          (**(code **)*piVar7)();
          LOCK();
          iVar4 = piVar7[2] + -1;
          piVar7[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            uStack_b4._4_4_ = (char *)0x682fd5;
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (param_1[0xf17] != 0) {
        LOCK();
        piVar7 = (int *)(param_1[0xf17] + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      uStack_b4._0_4_ = (char *)param_1[0xf16];
      uStack_b4._4_4_ = (char *)param_1[0xf17];
      pdStack_b8 = (double *)0x68300d;
      FUN_0067b3f0();
      puVar13 = *(undefined4 **)(param_1[0xf16] + 0x2c);
      if (puVar13 != (undefined4 *)0x0) {
        puVar2 = (undefined4 *)puVar13[1];
        param_1 = piStack_20;
        for (puVar13 = (undefined4 *)*puVar13; piStack_20 = param_1, puVar13 != puVar2;
            puVar13 = puVar13 + 2) {
          pcStack_2c = (code *)*puVar13;
          if (pcStack_2c != (code *)0x0) {
            pcStack_24 = *(code **)(pcStack_2c + 0xc);
            uStack_b4._4_4_ = (char *)0x683037;
            iVar4 = FUN_00b56e90();
            if ((uint)*(ushort *)((int)pcStack_24 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
                (uint)*(ushort *)(iVar4 + 0x1da)) {
              param_1 = piStack_20;
              if (pcStack_2c != (code *)0x0) {
                uStack_b4._4_4_ = (char *)pcStack_2c;
                uStack_b4._0_4_ = auStack_28;
                pdStack_b8 = (double *)0x68308b;
                piVar7 = (int *)FUN_0060dcd0();
                param_1 = piStack_20;
                uStack_8._0_1_ = 9;
                uStack_b4._0_4_ = (char *)*piVar7;
                uStack_b4._4_4_ = (char *)piVar7[1];
                *piVar7 = 0;
                piVar7[1] = 0;
                pdStack_b8 = (double *)0x6830c1;
                FUN_0067b3f0();
                uStack_8 = CONCAT31(uStack_8._1_3_,2);
                uStack_b4._4_4_ = (char *)0x6830cd;
                FUN_00550b30();
              }
              break;
            }
          }
          param_1 = piStack_20;
        }
      }
      piStack_1c = (int *)param_1[0xd];
      piVar7 = param_1;
      if ((piStack_1c != (int *)0x0) && (piVar7 = piStack_1c, piStack_1c[0xd] != 0)) {
        uStack_b4._4_4_ = (char *)0x683075;
        piVar7 = (int *)FUN_005c8ac0();
      }
      piStack_1c = piVar7;
      if (piStack_1c != (int *)0x0) {
        iVar4 = piStack_1c[3];
        uStack_b4._4_4_ = (char *)0x6830e4;
        iVar8 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
            (uint)*(ushort *)(iVar8 + 0x1da)) {
          uStack_b4._4_4_ = (char *)0x683107;
          piVar7 = (int *)FUN_00677290();
          if (*piVar7 != 0) {
            uStack_b4._4_4_ = (char *)&pcStack_48;
            pcStack_48 = FUN_0067b3f0;
            iStack_44 = 0;
            uStack_b4._0_4_ = (char *)0x683127;
            uStack_40._0_4_ = param_1;
            FUN_00677470();
            uStack_b4._4_4_ = (char *)0x58;
            uStack_b4._0_4_ = (char *)0x68312e;
            piStack_30 = (int *)FUN_01674e20();
            uStack_8._0_1_ = 10;
            if (piStack_30 == (int *)0x0) {
              uStack_b4._4_4_ = (char *)0x0;
            }
            else {
              auStack_cc[0] = 0;
              uStack_b4._4_4_ = (char *)FUN_00703220(param_1,0xc);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            uStack_b4._0_4_ = (char *)0x683165;
            FUN_006b1f50();
          }
        }
      }
      uStack_b4._4_4_ = (char *)0x0;
      uStack_b4._0_4_ = (char *)0x0;
      pcStack_24 = *(code **)(*(int *)param_2 + 0x4c);
      FUN_005f70a0();
      FUN_005f7140();
      uVar6 = DAT_01d5ae88;
      uVar16 = DAT_01d5ae8c;
      uVar17 = DAT_01d5ae90;
      FUN_005f7170(piStack_20 + 0x1d);
      (*pcStack_24)(auStack_7c,2,3,0,uVar6,uVar16,uVar17);
      piVar7 = piStack_20;
      *(undefined *)(piStack_20 + 0xf0b) = 1;
      FUN_0062e8b0(&iStack_84);
      uStack_8._0_1_ = 0xb;
      uVar15 = uStack_40;
      if (iStack_84 != 0) {
        iVar4 = *(int *)(iStack_84 + 0xc);
        iVar8 = FUN_005eded0();
        uVar15 = uStack_40;
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
            (uint)*(ushort *)(iVar8 + 0x1da)) {
          piStack_1c = (int *)(iStack_84 + 0x58);
          pcStack_48 = FUN_0067d870;
          iStack_44 = 0;
          uStack_40._0_4_ = piVar7;
          uStack_8._0_1_ = 0xc;
          piVar9 = (int *)FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 0xd;
          piStack_30 = piVar9;
          param_2 = (code *)FUN_01674e20(0x28);
          if (param_2 == (code *)0x0) {
            param_2 = (code *)0x0;
          }
          else {
            *(undefined4 *)param_2 = 0;
            *(undefined4 *)(param_2 + 4) = 1;
            *(code **)(param_2 + 8) = FUN_0067baa0;
            *(code **)(param_2 + 0xc) = _guard_check_icall;
            *(undefined4 *)(param_2 + 0x10) = 0;
            *(int **)(param_2 + 0x14) = piStack_1c;
            *(code **)(param_2 + 0x18) = pcStack_48;
            *(int *)(param_2 + 0x1c) = iStack_44;
            *(int **)(param_2 + 0x20) = (int *)uStack_40;
            *(undefined4 *)(param_2 + 0x24) = uStack_40._4_4_;
          }
          FUN_016797d0(param_2);
          pcStack_24 = param_2;
          if (param_2 != (code *)0x0) {
            LOCK();
            *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 1;
            UNLOCK();
          }
          uStack_4c = 1;
          uStack_8._0_1_ = 0xe;
          FUN_01675290(piVar9);
          uStack_8._0_1_ = 0xb;
          uVar15 = CONCAT44(uStack_40._4_4_,(int *)uStack_40);
          if (param_2 != (code *)0x0) {
            pcVar1 = param_2 + 4;
            LOCK();
            iVar4 = *(int *)pcVar1;
            *(int *)pcVar1 = *(int *)pcVar1 + -1;
            UNLOCK();
            uVar15 = CONCAT44(uStack_40._4_4_,(int *)uStack_40);
            if (iVar4 == 1) {
              FUN_01674ea0(param_2);
              uVar15 = CONCAT44(uStack_40._4_4_,(int *)uStack_40);
            }
          }
        }
      }
      uStack_40 = uVar15;
      pdVar10 = (double *)FUN_016827e0(&iStack_34);
      fVar14 = (float)((*pdVar10 - dStack_a4) * DAT_018c0d70);
      piVar7[0xe06] = (int)fVar14;
      if (DAT_01ee4213 != '\0') {
        FUN_016774d0(DAT_01ee4213,"Server Join snapshot timer: %f",fVar14,0,0,0);
      }
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_80[1] + -1;
        piStack_80[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          piVar7 = piStack_80 + 2;
          iVar4 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_80 + 4))();
          }
        }
      }
      FUN_00613200();
      piVar7 = piStack_50;
      pcVar11 = pcStack_54;
      uStack_8 = 0xf;
      FUN_0152dda0(pcStack_54,piStack_50,uStack_94);
      if ((cStack_15 != '\0') && (DAT_01d7ad40 != '\0')) {
        FUN_01532d10(pcVar11,piVar7,uStack_94);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uStack_b4._4_4_ = "ServerReplicator unable to find workspace.";
  }
  uStack_b4._0_4_ = (char *)0x68345e;
  FUN_00550130();
  uStack_b4._4_4_ = &DAT_01c17198;
  uStack_b4._0_4_ = auStack_38;
                    /* WARNING: Subroutine does not return */
  pdStack_b8 = (double *)0x68346c;
  FUN_0170c2a8();
}



/* FUNCTION 8067 ; VA 0x006834c0 ; FUN_006834c0 */

void __thiscall FUN_006834c0(int param_1,undefined4 param_2,int param_3,uint param_4,uint param_5)

{
  int iVar1;
  char cVar2;
  undefined uVar3;
  double *pdVar4;
  ulonglong uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [8];
  undefined8 uStack_c;
  
  cVar2 = FUN_00683840(param_3,param_4,param_5);
  if (cVar2 != '\0') {
    param_5 = param_4 & 0xffff;
    uStack_38 = 0;
    uStack_30 = 0;
    uStack_28 = uStack_28 & 0xffffff00;
    uStack_24 = 0xffffffff;
    if (param_3 == 0) {
      uStack_c = 0xffffffff;
    }
    else {
      uStack_c = *(undefined8 *)(param_3 + 0x18);
    }
    uStack_1c = (int)uStack_c;
    uStack_60 = CONCAT44((int)uStack_c,param_4) & 0xffffffff0000ffff;
    uStack_58 = uStack_c._4_4_;
    uStack_50 = 0;
    uStack_4c = uStack_34;
    uStack_48 = 0;
    uStack_44 = 0;
    uStack_40 = CONCAT44(0xffffffff,uStack_28);
    uStack_20 = param_5;
    FUN_006769c0(&uStack_c,&uStack_60,&uStack_60);
    iVar1 = (int)uStack_c;
    *(undefined *)((int)uStack_c + 0x28) = 1;
    if (uStack_c._4_1_ == '\0') {
      if (*(int *)((int)uStack_c + 0x18) != 0) {
        uVar3 = 0;
        goto LAB_006835e3;
      }
    }
    else {
      pdVar4 = (double *)FUN_01682800(auStack_14);
      *(double *)(iVar1 + 0x20) = *pdVar4 + *(double *)(param_1 + 0x3b08);
      uStack_20 = param_5;
      if (param_3 == 0) {
        uStack_c = 0xffffffff;
      }
      else {
        uStack_c = *(undefined8 *)(param_3 + 0x18);
      }
      uStack_1c = (int)uStack_c;
      uStack_18 = uStack_c._4_4_;
      FUN_006805f0(&uStack_20);
    }
  }
  uVar3 = 1;
LAB_006835e3:
  param_5 = CONCAT31(param_5._1_3_,uVar3);
  FUN_006ad5e0(&param_5,1);
  return;
}



/* FUNCTION 8068 ; VA 0x00683610 ; FUN_00683610 */

void FUN_00683610(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f50;
  pvStack_10 = ExceptionList;
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_0071e070(auStack_14,puVar3);
  puVar2 = param_2;
  uStack_8 = 0;
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  FUN_0071e070(&param_1,puVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_006ae210(auStack_14);
  FUN_006ae210(&param_1);
  FUN_01678450(puVar1,puVar2);
  FUN_0071e0a0();
  FUN_0071e0a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8069 ; VA 0x006836b0 ; FUN_006836b0 */

void FUN_006836b0(undefined4 param_1)

{
  uint uStack_c;
  undefined auStack_8 [4];
  
  uStack_c = FUN_01677950();
  uStack_c = uStack_c & 0xffff;
  FUN_006a5c10(&uStack_c,auStack_8,2);
  FUN_006ad5e0(auStack_8,2);
  FUN_01677790(FUN_00683610,param_1,4);
  return;
}



/* FUNCTION 8070 ; VA 0x00683700 ; FUN_00683700 */

bool __thiscall FUN_00683700(int *param_1,undefined4 param_2)

{
  float fVar1;
  uint uVar2;
  int *piVar3;
  double *pdVar4;
  int iVar5;
  float10 extraout_ST0;
  undefined auStack_10 [10];
  char cStack_6;
  char cStack_5;
  
  cStack_5 = '\0';
  cStack_6 = '\0';
  uVar2 = FUN_006266b0(param_2,&cStack_5,&cStack_6);
  if ((cStack_6 != '\0') || (cStack_5 != '\0')) {
    if (NAN((float)param_1[0x672]) == ((float)param_1[0x672] == 0.0)) {
      if (NAN((float)param_1[0x671]) == ((float)param_1[0x671] == 0.0)) {
        FUN_0061f160();
        fVar1 = (float)(extraout_ST0 + (float10)DAT_018ce2f8);
        if (fVar1 < (float)param_1[0x671] || fVar1 == (float)param_1[0x671]) {
          param_1[0x670] = (int)fVar1;
          piVar3 = (int *)FUN_016830f0(auStack_10);
          param_1[0x66e] = *piVar3;
          param_1[0x66f] = piVar3[1];
        }
      }
    }
  }
  if (uVar2 != 0) {
    FUN_0062b030(uVar2);
  }
  if ((cStack_5 == '\0') && (cStack_6 == '\0')) {
    return false;
  }
  pdVar4 = (double *)FUN_016830f0(auStack_10);
  if (((double)DAT_01d5ae30 / DAT_018c0d70 < *pdVar4 - *(double *)(param_1 + 0xef2)) &&
     (0 < DAT_01d5ae30)) {
    iVar5 = (**(code **)(*param_1 + 0xb8))();
    if (iVar5 != 0) {
      piVar3 = *(int **)(iVar5 + 0x28);
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_0086f2f0(2,"Player \"%s\" appears to be spamming remote events.",piVar3);
    }
    piVar3 = (int *)FUN_016830f0(auStack_10);
    param_1[0xef2] = *piVar3;
    param_1[0xef3] = piVar3[1];
  }
  return (param_1[0x67c] & uVar2) != 0;
}



/* FUNCTION 8071 ; VA 0x00683840 ; FUN_00683840 */

undefined4 __thiscall FUN_00683840(int *param_1,int param_2,short param_3,int param_4)

{
  char cVar1;
  int iVar2;
  short *psVar3;
  bool bVar4;
  
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (((cVar1 == '\0') && (param_4 != 0)) && (param_1[0x685] != 0)) {
    if (*(char *)(param_1 + 0xeea) == '\0') {
      iVar2 = FUN_006914b0(param_4);
      bVar4 = iVar2 != 0;
    }
    else {
      iVar2 = FUN_00690040(param_2,param_4);
      bVar4 = iVar2 == 0;
    }
    if (!bVar4) {
      param_4 = *(undefined4 *)(param_2 + 0xc);
      psVar3 = (short *)FUN_0061dc20(&param_4);
      if ((psVar3 == (short *)0x0) || (*psVar3 != param_3)) {
        return 0;
      }
    }
  }
  return 1;
}



/* FUNCTION 8072 ; VA 0x006838d0 ; FUN_006838d0 */

int __fastcall FUN_006838d0(int *param_1)

{
  return (param_1[1] - *param_1) / 0xc;
}



/* FUNCTION 8073 ; VA 0x006838f0 ; FUN_006838f0 */

undefined4 __thiscall FUN_006838f0(int param_1,int param_2)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00a36320(*(undefined8 *)(param_2 + 8),DAT_018c0d60,0x3f800000,0x3f800000);
  if (DAT_018c0d60 <= (double)fVar1) {
    FUN_0062eb00(*(undefined4 *)(param_1 + 0x130));
  }
  return 1;
}



/* FUNCTION 8074 ; VA 0x00683960 ; FUN_00683960 */

void __thiscall FUN_00683960(int param_1,undefined8 param_2)

{
  if ((*(uint *)(param_1 + 0x3808) & 2) != 0) {
    *(undefined4 *)(param_1 + 0x3b08) = (undefined4)param_2;
    *(undefined4 *)(param_1 + 0x3b0c) = param_2._4_4_;
    *(undefined4 *)(param_1 + 0x3b50) = (undefined4)param_2;
    *(undefined4 *)(param_1 + 0x3b54) = param_2._4_4_;
    return;
  }
  *(undefined8 *)(param_1 + 0x3b08) = param_2;
  return;
}



/* FUNCTION 8075 ; VA 0x006839b0 ; FUN_006839b0 */

int FUN_006839b0(undefined4 param_1,int *param_2,char param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a4f82;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 1;
  if (iStack_20 != 0) {
    if (param_3 == '\0') {
      if (*(int *)(iStack_20 + 0x3bb0) != 0) {
        LOCK();
        piVar3 = (int *)(*(int *)(iStack_20 + 0x3bb0) + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      iVar4 = FUN_00628870(*(undefined4 *)(iStack_20 + 0x3bac),*(undefined4 *)(iStack_20 + 0x3bb0));
      *(undefined4 *)(iStack_20 + 0x3bac) = 0;
      piVar3 = *(int **)(iStack_20 + 0x3bb0);
      *(undefined4 *)(iStack_20 + 0x3bb0) = 0;
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar4 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else if (*(int *)(iStack_20 + 0x3bac) == 0) {
      puVar5 = (undefined4 *)FUN_01674e20(0x138);
      uStack_8._0_1_ = 2;
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        puStack_14 = puVar5;
        FUN_00610b20("Replicator StatsSender",iStack_20,4,0xb);
        *puVar5 = RBX::Network::Replicator::SendStatsJob::vftable;
        puVar5[0x4c] = param_4;
      }
      uStack_8._0_1_ = 1;
      uStack_18 = 0;
      puStack_14 = (undefined4 *)0x0;
      FUN_0066e370(puVar5,param_2);
      puVar5 = puStack_14;
      *(undefined4 *)(iStack_20 + 0x3bac) = uStack_18;
      piVar3 = *(int **)(iStack_20 + 0x3bb0);
      uStack_18 = 0;
      puStack_14 = (undefined4 *)0x0;
      *(undefined4 **)(iStack_20 + 0x3bb0) = puVar5;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_00550b30();
      if (*(int *)(iStack_20 + 0x3bb0) != 0) {
        LOCK();
        piVar3 = (int *)(*(int *)(iStack_20 + 0x3bb0) + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      iVar4 = FUN_0151d950(*(undefined4 *)(iStack_20 + 0x3bac),*(undefined4 *)(iStack_20 + 0x3bb0));
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar3 = piStack_1c + 1;
    iVar2 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar3 = piStack_1c + 2;
      iVar2 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar2 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 8076 ; VA 0x00683bc0 ; FUN_00683bc0 */

void __fastcall FUN_00683bc0(int param_1)

{
  undefined4 uVar1;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f98;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    uStack_14 = (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80);
    FUN_009fdde0(&uStack_14);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 8077 ; VA 0x00683c30 ; FUN_00683c30 */

void __fastcall FUN_00683c30(int param_1)

{
  undefined4 uVar1;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f98;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x78) != 0) {
    ExceptionList = &pvStack_10;
    uStack_14 = (**(code **)((*(uint *)(param_1 + 0x78) & 0xfffffffe) + 4))(param_1 + 0x80);
    FUN_009fde10(&uStack_14);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 8078 ; VA 0x00683ca0 ; FUN_00683ca0 */

void __fastcall FUN_00683ca0(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined auStack_24 [8];
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4fb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00701a80();
  if ((((*(int *)(param_1 + 0x1f0) != 0) && (*(int *)(param_1 + 0x1f8) != 0)) &&
      (*(int *)(param_1 + 0x200) != 0)) &&
     ((*(int *)(param_1 + 0x208) != 0 && (*(int *)(param_1 + 0x210) != 0)))) {
    piVar2 = (int *)FUN_00587490(auStack_24);
    iStack_18 = piVar2[1];
    iVar1 = *piVar2;
    if (iStack_18 != 0) {
      LOCK();
      *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
      UNLOCK();
      iStack_18 = piVar2[1];
    }
    uStack_8 = 0;
    iStack_1c = iVar1;
    FUN_00550b30();
    if (iVar1 != 0) {
      iStack_14 = *(int *)(iVar1 + 0x3b18);
      FUN_009fde10(&iStack_14);
      if (*(int *)(iVar1 + 0x1de4) != 0) {
        FUN_009ffc10(*(int *)(iVar1 + 0x1de4) + 0x2b8);
        iStack_14 = (int)*(double *)(*(int *)(iVar1 + 0x1de4) + 0x330);
        FUN_009fdde0(&iStack_14);
        iStack_14 = (int)*(double *)(*(int *)(iVar1 + 0x1de4) + 0x308);
        FUN_009fdde0(&iStack_14);
        iStack_14 = *(int *)(*(int *)(iVar1 + 0x1de4) + 0x160);
        FUN_009fdde0(&iStack_14);
      }
    }
    FUN_00550b30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8079 ; VA 0x00683df0 ; FUN_00683df0 */

void __fastcall FUN_00683df0(int param_1)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  undefined8 uStack_c;
  
  uStack_c = 0;
  sVar2 = FUN_017265ed(&uStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x3c80);
    dVar3 = DAT_018c0d60 - dVar1;
    if (*(char *)(param_1 + 0x3ca0) == '\0') {
      dVar4 = *(double *)(param_1 + 0x3c90) * dVar3 + dVar1 * 0.0;
    }
    else {
      dVar4 = 0.0;
    }
    *(undefined4 *)(param_1 + 0x3c88) = 0;
    *(double *)(param_1 + 0x3c90) = dVar4;
    *(undefined *)(param_1 + 0x3ca0) = 0;
    *(double *)(param_1 + 0x3c98) =
         (0.0 - dVar4) * (0.0 - dVar4) * dVar1 + dVar3 * *(double *)(param_1 + 0x3c98);
  }
  uStack_c = 0;
  sVar2 = FUN_017265ed(&uStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x3ca8);
    dVar3 = DAT_018c0d60 - dVar1;
    if (*(char *)(param_1 + 0x3cc8) == '\0') {
      dVar4 = *(double *)(param_1 + 0x3cb8) * dVar3 + dVar1 * 0.0;
    }
    else {
      dVar4 = 0.0;
    }
    *(undefined4 *)(param_1 + 0x3cb0) = 0;
    *(double *)(param_1 + 0x3cb8) = dVar4;
    *(undefined *)(param_1 + 0x3cc8) = 0;
    *(double *)(param_1 + 0x3cc0) =
         (0.0 - dVar4) * (0.0 - dVar4) * dVar1 + *(double *)(param_1 + 0x3cc0) * dVar3;
  }
  uStack_c = 0;
  sVar2 = FUN_017265ed(&uStack_c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x3cd0);
    dVar3 = DAT_018c0d60 - dVar1;
    if (*(char *)(param_1 + 0x3cf0) == '\0') {
      dVar4 = *(double *)(param_1 + 0x3ce0) * dVar3 + dVar1 * 0.0;
    }
    else {
      dVar4 = 0.0;
    }
    *(undefined4 *)(param_1 + 0x3cd8) = 0;
    *(double *)(param_1 + 0x3ce0) = dVar4;
    *(undefined *)(param_1 + 0x3cf0) = 0;
    *(double *)(param_1 + 0x3ce8) =
         (0.0 - dVar4) * (0.0 - dVar4) * dVar1 + dVar3 * *(double *)(param_1 + 0x3ce8);
  }
  *(int *)(param_1 + 0x3cf8) = *(int *)(param_1 + 0x3cf8) + 1;
  return;
}



/* FUNCTION 8080 ; VA 0x00683fc0 ; FUN_00683fc0 */

void __thiscall FUN_00683fc0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  char cVar2;
  double *pdVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 auStack_48 [2];
  undefined8 uStack_40;
  undefined uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4fd8;
  pvStack_10 = ExceptionList;
  if ((param_1[0xe02] & 2U) != 0) {
    ExceptionList = &pvStack_10;
    cVar2 = (**(code **)(*param_1 + 0x11c))();
    if (cVar2 != '\0') {
      FUN_0054ef60(param_4);
      uStack_68 = uStack_30;
      uStack_64 = uStack_2c;
      uStack_60 = uStack_28;
      uStack_5c = uStack_24;
      uStack_54 = uStack_1c;
      if (param_3 == 0) {
        uStack_18 = 2.12199579047121e-314;
      }
      else {
        uStack_18 = *(double *)(param_3 + 0x18);
      }
      uStack_20 = 0;
      uStack_50 = (int)uStack_18;
      uStack_4c = uStack_18._4_4_;
      uStack_1c = 0xf;
      uStack_30 = uStack_30 & 0xffffff00;
      uStack_8 = 0;
      auStack_48[0] = 0;
      uStack_38 = 0;
      uStack_34 = 0xffffffff;
      uStack_40 = 0;
      FUN_00676780(&uStack_18,&uStack_68,&uStack_68,auStack_48);
      iVar1 = (int)uStack_18;
      *(undefined *)((int)uStack_18 + 0x38) = 1;
      if (uStack_18._4_1_ == '\0') {
        iVar1 = *(int *)((int)uStack_18 + 0x28);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_54) {
          uVar5 = uStack_54 + 1;
          uVar4 = uStack_68;
          if (0xfff < uVar5) {
            uVar4 = *(uint *)(uStack_68 - 4);
            uVar5 = uStack_54 + 0x24;
            if (0x1f < (uStack_68 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar5);
        }
        bVar6 = iVar1 == 0;
      }
      else {
        pdVar3 = (double *)FUN_01682800(&uStack_18);
        uStack_18 = *pdVar3 + *(double *)(param_1 + 0xed4);
        *(double *)(iVar1 + 0x30) = uStack_18;
        FUN_00680510(iVar1 + 8);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_54) {
          uVar5 = uStack_54 + 1;
          uVar4 = uStack_68;
          if (0xfff < uVar5) {
            uVar4 = *(uint *)(uStack_68 - 4);
            uVar5 = uStack_54 + 0x24;
            if (0x1f < (uStack_68 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar5);
        }
        bVar6 = true;
      }
      param_4 = CONCAT31(param_4._1_3_,bVar6);
      FUN_006ad5e0(&param_4,1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8081 ; VA 0x00684190 ; FUN_00684190 */

void FUN_00684190(char *param_1)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  
  if ((param_1 != (char *)0x0) && (*param_1 != '\0')) {
    pcVar2 = param_1;
    do {
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    iVar3 = (int)pcVar2 - (int)(param_1 + 1);
    if (param_1[iVar3 + -1] == '\\') {
      param_1[iVar3 + -1] = '/';
      return;
    }
    if (param_1[iVar3 + -1] != '/') {
      (param_1 + iVar3)[0] = '/';
      (param_1 + iVar3)[1] = '\0';
    }
  }
  return;
}



/* FUNCTION 8082 ; VA 0x006841d0 ; FUN_006841d0 */

undefined4 FUN_006841d0(char *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  char *pcVar5;
  char *pcVar6;
  
  if ((param_1 == (char *)0x0) || (*param_1 == '\0')) {
    return 0;
  }
  pcVar5 = param_1;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  pcVar2 = (char *)FUN_01674f30(pcVar5 + (1 - (int)(param_1 + 1)));
  pcVar5 = param_1;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
    pcVar5[(int)(pcVar2 + (-1 - (int)param_1))] = cVar1;
  } while (cVar1 != '\0');
  if (*pcVar2 != '\0') {
    cVar1 = pcVar2[1];
    pcVar5 = pcVar2;
    while (cVar1 != '\0') {
      pcVar6 = pcVar5 + 1;
      if ((cVar1 == '/') || (cVar1 == '\\')) {
        *pcVar6 = '\0';
        iVar3 = FUN_017268fd(pcVar2);
        if ((iVar3 < 0) &&
           ((piVar4 = (int *)FUN_0171689d(), *piVar4 != 0x11 &&
            (piVar4 = (int *)FUN_0171689d(), *piVar4 != 0xd)))) goto LAB_006842bf;
        *pcVar6 = '/';
      }
      cVar1 = pcVar5[2];
      pcVar5 = pcVar6;
    }
  }
  if (param_2 == 0) {
    iVar3 = FUN_017268fd(pcVar2);
    if ((iVar3 < 0) && (piVar4 = (int *)FUN_0171689d(), *piVar4 != 0x11)) goto LAB_006842bf;
  }
  else {
    iVar3 = FUN_01722015(param_1,&DAT_018d6530);
    if (iVar3 == 0) {
LAB_006842bf:
      FUN_01674ea0(pcVar2);
      return 0;
    }
    FUN_01719056(param_2,1,param_3,iVar3);
    FUN_01718190(iVar3);
  }
  FUN_01674ea0(pcVar2);
  return 1;
}



/* FUNCTION 8083 ; VA 0x006842e0 ; FUN_006842e0 */

int * __thiscall
FUN_006842e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005edfb0();
  FUN_00684820(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::NetworkSettings>::
              vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8084 ; VA 0x006843b0 ; FUN_006843b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006843b0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead278) {
    FUN_016f3809(&DAT_01ead278);
    if (DAT_01ead278 == -1) {
      _DAT_01ead26c = FUN_005c65e0;
      _DAT_01ead270 = FUN_005c65e0;
      DAT_01ead274 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead278);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01ead26c) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01ead26c;
  return param_1;
}



/* FUNCTION 8085 ; VA 0x00684460 ; FUN_00684460 */

byte FUN_00684460(undefined4 param_1,undefined4 param_2)

{
  byte bVar1;
  
  bVar1 = FUN_00558b30(param_1,param_2);
  return bVar1 ^ 1;
}



/* FUNCTION 8086 ; VA 0x00684480 ; FUN_00684480 */

float10 __fastcall FUN_00684480(int *param_1)

{
  int iVar1;
  int iVar2;
  float *pfVar3;
  undefined4 *puVar4;
  undefined auStack_dc [200];
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c960();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_dc);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    pfVar3 = (float *)FUN_008894a0();
    fStack_14 = *pfVar3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_dc);
    }
    ExceptionList = pvStack_10;
    return (float10)fStack_14;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    pfVar3 = (float *)(param_1 + 2);
    if (param_1[1] == 0) {
      pfVar3 = (float *)0x0;
    }
    ExceptionList = pvStack_10;
    return (float10)*pfVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 8087 ; VA 0x00684570 ; FUN_00684570 */

float10 __fastcall FUN_00684570(int *param_1)

{
  int iVar1;
  int iVar2;
  double *pdVar3;
  undefined4 *puVar4;
  undefined auStack_e0 [200];
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a501b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088ca00();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_e0);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    pdVar3 = (double *)FUN_008896a0();
    dStack_18 = *pdVar3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e0);
    }
    ExceptionList = pvStack_10;
    return (float10)dStack_18;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088ca00();
  if (iVar1 == iVar2) {
    pdVar3 = (double *)(param_1 + 2);
    if (param_1[1] == 0) {
      pdVar3 = (double *)0x0;
    }
    ExceptionList = pvStack_10;
    return (float10)*pdVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 8088 ; VA 0x00684660 ; FUN_00684660 */

undefined4 * __fastcall FUN_00684660(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("PacketPriority");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_PacketPriority>::vftable;
  FUN_009caf20(&DAT_01d5af78,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8089 ; VA 0x006846c0 ; FUN_006846c0 */

/* WARNING: Removing unreachable block (ram,0x00684753) */

int * __thiscall
FUN_006846c0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a506b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088c960();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8090 ; VA 0x00684770 ; FUN_00684770 */

/* WARNING: Removing unreachable block (ram,0x00684803) */

int * __thiscall
FUN_00684770(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a509b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088ca00();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8091 ; VA 0x00684820 ; FUN_00684820 */

/* WARNING: Removing unreachable block (ram,0x006848b3) */

int * __thiscall
FUN_00684820(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a50cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088daf0();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8092 ; VA 0x006848d0 ; FUN_006848d0 */

undefined4 * __fastcall FUN_006848d0(undefined4 *param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5137;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0x54);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::NetworkSettings,class_RBX::GlobalAdvancedSettings::Item>::
             vftable;
  uVar3 = FUN_005edfb0();
  param_1[3] = uVar3;
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 1;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::NetworkSettings>::vftable;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("NetworkSettings",0xf);
  uStack_8._0_1_ = 2;
  FUN_008a6520(auStack_44);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    uVar5 = auStack_44[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_44[0] - 4);
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  if (DAT_01ea94c4 == (undefined4 *)0x0) {
    DAT_01ea94c4 = param_1;
    *param_1 = RBX::NetworkSettings::vftable;
    param_1[0x16] = 0;
    *(undefined *)(param_1 + 0x17) = 0;
    *(undefined8 *)(param_1 + 0x18) = 0;
    *(undefined2 *)(param_1 + 0x1a) = 0;
    *(undefined *)((int)param_1 + 0x6a) = 0;
    param_1[0x1f] = 0;
    param_1[0x20] = 0xf;
    uStack_8 = 3;
    *(undefined *)(param_1 + 0x1b) = 0;
    FUN_005542c0(&DAT_018c92b8,9);
    param_1[0x21] = 0x94eb;
    param_1[0x26] = 0;
    param_1[0x27] = 0xf;
    uStack_8._0_1_ = 4;
    *(undefined *)(param_1 + 0x22) = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    *(undefined *)(param_1 + 0x2a) = 0;
    uStack_8._0_1_ = 5;
    *(undefined8 *)(param_1 + 0x28) = 0;
    param_1[0x2f] = 0;
    param_1[0x30] = 0xf;
    *(undefined *)(param_1 + 0x2b) = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    puVar2 = PTR_DAT_01d5af70;
    uStack_8._0_1_ = 6;
    param_1[0x31] = 0;
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    pcVar4 = puVar2;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(puVar2,(int)pcVar4 - (int)(puVar2 + 1));
    uStack_8._0_1_ = 7;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar4 = PTR_DAT_01d5af70;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(PTR_DAT_01d5af70,(int)pcVar4 - (int)(PTR_DAT_01d5af70 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_008a6520(auStack_44);
    if (0xf < uStack_30) {
      uVar6 = uStack_30 + 1;
      uVar5 = auStack_44[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_44[0] - 4);
        uVar6 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = uStack_2c;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_2c - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (uStack_2c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_20,"singleton %s already exists","NetworkSettings");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 8093 ; VA 0x00684ba0 ; thunk_FUN_0089b230 */

void __fastcall thunk_FUN_0089b230(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Instance::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  if ((undefined4 *)param_1[0x11] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x11])(1);
  }
  piVar1 = (int *)param_1[0xc];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 0;
  LOCK();
  piVar1 = (int *)(param_1[10] + 0x18);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1) {
    FUN_008a3020();
    uVar3 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar4 = FUN_0089d8f0(param_1 + 10);
    if (cVar4 != '\0') {
      FUN_0089fdd0(param_1[10]);
    }
    LeaveCriticalSection(uVar3);
  }
  LOCK();
  DAT_01ea851c = DAT_01ea851c + -1;
  UNLOCK();
  FUN_0089ac10();
  FUN_00892570();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8094 ; VA 0x00684bb0 ; FUN_00684bb0 */

void __fastcall FUN_00684bb0(undefined4 *param_1)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::NetworkSettings>::vftable;
  DAT_01ea94c4 = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 8095 ; VA 0x00684bd0 ; FUN_00684bd0 */

undefined4 * __thiscall FUN_00684bd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<double>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 8096 ; VA 0x00684c00 ; FUN_00684c00 */

undefined4 * __thiscall FUN_00684c00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<bool>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 8097 ; VA 0x00684c30 ; FUN_00684c30 */

undefined4 * __thiscall FUN_00684c30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<float>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 8098 ; VA 0x00684c60 ; FUN_00684c60 */

undefined4 * __thiscall FUN_00684c60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 8099 ; VA 0x00684c90 ; FUN_00684c90 */

undefined4 * __thiscall FUN_00684c90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::NetworkSettings>::vftable;
  DAT_01ea94c4 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 8100 ; VA 0x00684cd0 ; FUN_00684cd0 */

undefined4 * __thiscall FUN_00684cd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<float>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8101 ; VA 0x00684d00 ; FUN_00684d00 */

undefined4 * __thiscall FUN_00684d00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<double>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8102 ; VA 0x00684d30 ; FUN_00684d30 */

undefined4 * __thiscall FUN_00684d30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8103 ; VA 0x00684d60 ; FUN_00684d60 */

undefined4 * __thiscall FUN_00684d60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<bool>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8104 ; VA 0x00684d90 ; FUN_00684d90 */

undefined4 * __thiscall FUN_00684d90(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::NetworkSettings::vftable;
  uVar1 = param_1[0x30];
  if (0xf < uVar1) {
    iVar2 = param_1[0x2b];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00684ec0;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x2f] = 0;
  param_1[0x30] = 0xf;
  *(undefined *)(param_1 + 0x2b) = 0;
  uVar1 = param_1[0x27];
  if (0xf < uVar1) {
    iVar2 = param_1[0x22];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00684ec0;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x26] = 0;
  param_1[0x27] = 0xf;
  *(undefined *)(param_1 + 0x22) = 0;
  uVar1 = param_1[0x20];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1b];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00684ec0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1f] = 0;
  param_1[0x20] = 0xf;
  *(undefined *)(param_1 + 0x1b) = 0;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::NetworkSettings>::vftable;
  DAT_01ea94c4 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  return param_1;
}



/* FUNCTION 8105 ; VA 0x00684ed0 ; FUN_00684ed0 */

bool FUN_00684ed0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::GlobalAdvancedSettings::Item::RTTI_Type_Descriptor,0);
  return iVar1 != 0;
}



/* FUNCTION 8106 ; VA 0x00684f00 ; FUN_00684f00 */

void __thiscall FUN_00684f00(int param_1,float param_2,undefined4 param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  param_2 = (float)fVar1;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&param_2);
  return;
}



/* FUNCTION 8107 ; VA 0x00684f40 ; FUN_00684f40 */

void __thiscall FUN_00684f40(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  double dStack_10;
  code *pcStack_8;
  
  pcStack_8 = *(code **)(**(int **)(param_1 + 0x34) + 0xc);
  fVar1 = (float10)(*pcStack_8)(param_2);
  dStack_10 = (double)fVar1;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&dStack_10);
  return;
}



/* FUNCTION 8108 ; VA 0x00684f80 ; FUN_00684f80 */

void __thiscall FUN_00684f80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8109 ; VA 0x00685010 ; FUN_00685010 */

void __thiscall FUN_00685010(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  param_2 = CONCAT13(uVar1,(undefined3)param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,(int)&param_2 + 3);
  return;
}



/* FUNCTION 8110 ; VA 0x00685040 ; FUN_00685040 */

int __thiscall FUN_00685040(int param_1,int param_2,int param_3)

{
  double *pdVar1;
  double dVar2;
  uint3 uVar3;
  
  dVar2 = *(double *)(*(int *)(param_1 + 8) + param_2);
  pdVar1 = (double *)(*(int *)(param_1 + 8) + param_3);
  uVar3 = CONCAT21((short)((uint)param_3 >> 0x10),
                   (dVar2 == *pdVar1) << 6 | (NAN(dVar2) || NAN(*pdVar1)) << 2 | 2U |
                   dVar2 < *pdVar1);
  if ((NAN(dVar2) || NAN(*pdVar1)) != (dVar2 == *pdVar1)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 8111 ; VA 0x00685070 ; FUN_00685070 */

bool __thiscall FUN_00685070(int param_1,int param_2,int param_3)

{
  return *(char *)(*(int *)(param_1 + 8) + param_2) == *(char *)(*(int *)(param_1 + 8) + param_3);
}



/* FUNCTION 8112 ; VA 0x00685090 ; FUN_00685090 */

int __fastcall FUN_00685090(int param_1)

{
  float fVar1;
  float fVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar1 = (float)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  fVar2 = (float)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (fVar1 == fVar2) << 6 | (NAN(fVar1) || NAN(fVar2)) << 2 | 2U | fVar1 < fVar2);
  if ((NAN(fVar1) || NAN(fVar2)) != (fVar1 == fVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 8113 ; VA 0x006850e0 ; FUN_006850e0 */

undefined __fastcall FUN_006850e0(int param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 8))(auStack_28);
  uVar1 = FUN_00558b30(uVar3,uVar2);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar6 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar6 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 8114 ; VA 0x006851d0 ; FUN_006851d0 */

bool __fastcall FUN_006851d0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(param_1 + 8))();
  iVar2 = (**(code **)(param_1 + 8))();
  return iVar2 == iVar1;
}



/* FUNCTION 8115 ; VA 0x00685200 ; FUN_00685200 */

bool __fastcall FUN_00685200(int param_1)

{
  char cVar1;
  char cVar2;
  
  cVar1 = (**(code **)(param_1 + 8))();
  cVar2 = (**(code **)(param_1 + 8))();
  return cVar2 == cVar1;
}



/* FUNCTION 8116 ; VA 0x00685230 ; thunk_FUN_005ee4b0 */

void thunk_FUN_005ee4b0(void)

{
  int iVar1;
  
  if (DAT_01ea9b24 == 0) {
    iVar1 = FUN_005edfb0();
    DAT_01ea9b24 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 8117 ; VA 0x00685240 ; FUN_00685240 */

undefined __fastcall FUN_00685240(int param_1)

{
  return *(undefined *)(param_1 + 0xa8);
}



/* FUNCTION 8118 ; VA 0x00685260 ; FUN_00685260 */

float10 __fastcall FUN_00685260(undefined4 param_1)

{
  double in_XMM0_Qa;
  
  FUN_015228f0(param_1);
  FUN_016f3fe0();
  return (float10)((float)in_XMM0_Qa * DAT_018d6c1c * DAT_018d6c1c);
}



/* FUNCTION 8119 ; VA 0x006852a0 ; FUN_006852a0 */

undefined4 __thiscall FUN_006852a0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0xac);
  return param_2;
}



/* FUNCTION 8120 ; VA 0x006852e0 ; FUN_006852e0 */

float10 __thiscall FUN_006852e0(int param_1,int param_2)

{
  return (float10)*(double *)(param_2 + *(int *)(param_1 + 8));
}



/* FUNCTION 8121 ; VA 0x006852f0 ; FUN_006852f0 */

undefined __thiscall FUN_006852f0(int param_1,int param_2)

{
  return *(undefined *)(param_2 + *(int *)(param_1 + 8));
}



/* FUNCTION 8122 ; VA 0x00685300 ; FUN_00685300 */

void __fastcall FUN_00685300(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 8123 ; VA 0x00685320 ; FUN_00685320 */

undefined4 * __thiscall FUN_00685320(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_1c);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_2;
}



/* FUNCTION 8124 ; VA 0x006853b0 ; FUN_006853b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006853b0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  undefined4 uVar3;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  uVar3 = FUN_0088c960();
  iVar2 = _tls_index;
  *param_3 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead278) {
    FUN_016f3809(&DAT_01ead278);
    if (DAT_01ead278 == -1) {
      _DAT_01ead26c = FUN_005c65e0;
      _DAT_01ead270 = FUN_005c65e0;
      DAT_01ead274 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead278);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead26c) {
    param_3[2] = (float)fVar4;
    return;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
  }
  param_3[2] = (float)fVar4;
  param_3[1] = &DAT_01ead26c;
  return;
}



/* FUNCTION 8125 ; VA 0x00685480 ; FUN_00685480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00685480(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  int iVar2;
  undefined4 uVar3;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  uVar3 = FUN_0088ca00();
  iVar2 = _tls_index;
  *param_3 = uVar3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead488) {
    FUN_016f3809(&DAT_01ead488);
    if (DAT_01ead488 == -1) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead47c) {
    *(double *)(param_3 + 2) = (double)fVar4;
    return;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_3 + 2);
  }
  *(double *)(param_3 + 2) = (double)fVar4;
  param_3[1] = &DAT_01ead47c;
  return;
}



/* FUNCTION 8126 ; VA 0x00685550 ; FUN_00685550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00685550(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar5 = FUN_0088cb40();
  iVar6 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) < DAT_01ea8c48) {
    FUN_016f3809(&DAT_01ea8c48);
    if (DAT_01ea8c48 == -1) {
      _DAT_01ea8c3c = FUN_005c65f0;
      _DAT_01ea8c40 = FUN_005c93a0;
      DAT_01ea8c44 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ea8c48);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ea8c3c) {
    if (param_3 + 2 != puVar4) {
      FUN_005507b0();
      uVar5 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      param_3[2] = *puVar4;
      param_3[3] = uVar5;
      param_3[4] = uVar2;
      param_3[5] = uVar3;
      *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[6] = 0;
    param_3[7] = 0;
    uVar5 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    param_3[2] = *puVar4;
    param_3[3] = uVar5;
    param_3[4] = uVar2;
    param_3[5] = uVar3;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    param_3[1] = &DAT_01ea8c3c;
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    iVar6 = aiStack_28[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_28[0] + -4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8127 ; VA 0x006856d0 ; FUN_006856d0 */

void __thiscall FUN_006856d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 uVar4;
  
  uVar3 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  uVar4 = FUN_0088daf0();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  puVar2 = (undefined4 *)param_3[1];
  if ((code **)puVar2 == &DAT_01ea8bec) {
    *(undefined *)(param_3 + 2) = uVar3;
    return;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_3 + 2);
  }
  *(undefined *)(param_3 + 2) = uVar3;
  param_3[1] = &DAT_01ea8bec;
  return;
}



/* FUNCTION 8128 ; VA 0x00685790 ; FUN_00685790 */

undefined * FUN_00685790(undefined *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  FUN_005542c0("Please use iOS or Android to use this feature.",0x2e);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8129 ; VA 0x00685820 ; FUN_00685820 */

undefined4 FUN_00685820(undefined4 *param_1)

{
  if ((DAT_01d5af68 != '\0') && ((param_1 == &DAT_021196d4 || (param_1 == &DAT_0211970c)))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 8130 ; VA 0x00685850 ; FUN_00685850 */

void __thiscall FUN_00685850(int param_1,char param_2)

{
  if ((DAT_01d7a1ac != '\0') && (param_2 != *(char *)(param_1 + 0xa8))) {
    *(char *)(param_1 + 0xa8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 8131 ; VA 0x00685880 ; FUN_00685880 */

void __thiscall FUN_00685880(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 0;
  if (-1 < param_2) {
    iVar1 = param_2;
  }
  if (iVar1 != *(int *)(param_1 + 0xc4)) {
    *(int *)(param_1 + 0xc4) = iVar1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 8132 ; VA 0x006858b0 ; FUN_006858b0 */

void __thiscall FUN_006858b0(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d7a1ac != '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00558b30(&param_2,(undefined4 *)(param_1 + 0xac));
    if (cVar1 == '\0') {
      if ((undefined4 **)(param_1 + 0xac) != &param_2) {
        puVar2 = &param_2;
        if (0xf < in_stack_00000018) {
          puVar2 = param_2;
        }
        FUN_005542c0(puVar2,in_stack_00000014);
      }
      FUN_008a4940(&DAT_0211970c);
    }
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    puVar2 = param_2;
    if (0xfff < uVar3) {
      puVar2 = (undefined4 *)param_2[-1];
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8133 ; VA 0x00685970 ; FUN_00685970 */

void FUN_00685970(void)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = PTR_DAT_01d5af70;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d5af70,(int)pcVar3 - (int)(PTR_DAT_01d5af70 + 1));
  uStack_8 = 0;
  FUN_008a6520(auStack_28);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8134 ; VA 0x00685a30 ; FUN_00685a30 */

void FUN_00685a30(char param_1)

{
  if (param_1 != DAT_01edfb01) {
    DAT_01edfb01 = param_1;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 8135 ; VA 0x00685a60 ; FUN_00685a60 */

void FUN_00685a60(char param_1)

{
  if (param_1 != DAT_01edfb02) {
    DAT_01edfb02 = param_1;
  }
  return;
}



/* FUNCTION 8136 ; VA 0x00685a90 ; FUN_00685a90 */

void __thiscall FUN_00685a90(int param_1,int param_2,double *param_3)

{
  double dVar1;
  double dVar2;
  
  dVar1 = *param_3;
  dVar2 = *(double *)(*(int *)(param_1 + 8) + param_2);
  if ((NAN(dVar2) || NAN(dVar1)) == (dVar2 == dVar1)) {
    *(double *)(*(int *)(param_1 + 8) + param_2) = dVar1;
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 8137 ; VA 0x00685ae0 ; FUN_00685ae0 */

void __thiscall FUN_00685ae0(int param_1,int param_2,char *param_3)

{
  if (*(char *)(*(int *)(param_1 + 8) + param_2) != *param_3) {
    *(char *)(*(int *)(param_1 + 8) + param_2) = *param_3;
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 8138 ; VA 0x00685b20 ; FUN_00685b20 */

void FUN_00685b20(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("can\'t set value");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 8139 ; VA 0x00685b50 ; FUN_00685b50 */

void __thiscall FUN_00685b50(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  
  pcVar1 = *(code **)(param_1 + 0x10);
  FUN_0054ef60(param_3);
  (*pcVar1)();
  return;
}



/* FUNCTION 8140 ; VA 0x00685b80 ; FUN_00685b80 */

void __thiscall FUN_00685b80(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 8141 ; VA 0x00685ba0 ; FUN_00685ba0 */

void __thiscall FUN_00685ba0(int param_1,undefined4 param_2,undefined *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 8142 ; VA 0x00685bc0 ; FUN_00685bc0 */

void __thiscall FUN_00685bc0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_e0 [200];
  code *pcStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a501b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_18 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c960();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088c960();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iStack_14 = *piVar3;
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_e0);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_008894a0();
    iStack_14 = *piVar3;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e0);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_18)(param_2,&iStack_14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8143 ; VA 0x00685cd0 ; FUN_00685cd0 */

void __thiscall FUN_00685cd0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined auStack_ec [200];
  undefined8 uStack_24;
  undefined8 uStack_1c;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a524b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088ca00();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088ca00();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_24 = *(undefined8 *)piVar3;
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_ec);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    puVar5 = (undefined8 *)FUN_008896a0();
    uStack_1c = *puVar5;
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_ec);
    }
    uStack_8 = 0xffffffff;
    uStack_24 = uStack_1c;
  }
  (*pcStack_14)(param_2,&uStack_24);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8144 ; VA 0x00685de0 ; FUN_00685de0 */

void __thiscall FUN_00685de0(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00563690(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8145 ; VA 0x00685e70 ; FUN_00685e70 */

void __thiscall FUN_00685e70(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined *puVar6;
  undefined uVar7;
  undefined auStack_e0 [200];
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a501b;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 0x34);
  pcStack_18 = *(code **)(*piStack_14 + 0x10);
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar1 == iVar3) {
    iVar1 = *piVar2;
    iVar3 = FUN_0088daf0();
    if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = piVar2 + 2;
    if (piVar2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    uVar7 = *(undefined *)piVar4;
  }
  else {
    puVar5 = (undefined4 *)piVar2[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(piVar2 + 2,auStack_e0);
      puVar5 = (undefined4 *)piVar2[1];
    }
    uStack_8 = 0;
    puVar6 = (undefined *)FUN_0088bcc0();
    uVar7 = *puVar6;
    uStack_8 = 1;
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)puVar5[2])(auStack_e0);
    }
    uStack_8 = 0xffffffff;
  }
  param_3 = (int *)CONCAT13(uVar7,param_3._0_3_);
  (*pcStack_18)(param_2,(int)&param_3 + 3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8146 ; VA 0x00685f70 ; FUN_00685f70 */

void __thiscall FUN_00685f70(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_38 [24];
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5279;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0090de90();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      FUN_008a2380(auStack_38);
      uStack_8 = 0;
      uStack_14 = 1;
      uVar3 = FUN_005543f0();
      (**(code **)(*param_1 + 0x10))(uVar3);
      uVar3 = FUN_005543f0();
      FUN_016756b0(auStack_20,"Invalid parent for Service. %s cannot be parented to %s .",uVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8147 ; VA 0x00686030 ; FUN_00686030 */

undefined4 * __fastcall FUN_00686030(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = RBX::Security::SessionCrypto::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  *(undefined *)(param_1 + 10) = 0;
  param_1[6] = DAT_018d6c38;
  uVar1 = DAT_018d6c3c;
  param_1[7] = DAT_018d6c3c;
  FUN_006860e0(param_1[6],uVar1);
  return param_1;
}



/* FUNCTION 8148 ; VA 0x00686090 ; FUN_00686090 */

void __fastcall FUN_00686090(int param_1)

{
  FUN_0154e020(param_1 + 0x20,0x20);
  FUN_0154e020(param_1 + 0x40,0x20);
  FUN_0154e020(param_1 + 0x60,0x20);
  FUN_0154e020(param_1 + 0x80,0x20);
  FUN_0154e020(param_1 + 0xa0,0x20);
  return;
}



/* FUNCTION 8149 ; VA 0x006860e0 ; FUN_006860e0 */

undefined8 __thiscall FUN_006860e0(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  do {
    iVar2 = *(int *)param_1;
    LOCK();
    lVar1 = *param_1;
    if (*param_1 == lVar1) {
      *param_1 = CONCAT44(param_3,param_2);
      iVar3 = iVar2;
      iVar4 = *(int *)((int)param_1 + 4);
    }
    else {
      iVar3 = (int)lVar1;
      iVar4 = (int)((ulonglong)lVar1 >> 0x20);
    }
    UNLOCK();
  } while ((iVar2 != iVar3) || (*(int *)((int)param_1 + 4) != iVar4));
  return CONCAT44(param_3,param_2);
}



/* FUNCTION 8150 ; VA 0x00686130 ; FUN_00686130 */

char * __thiscall FUN_00686130(char *param_1,char *param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  pcVar1 = param_1 + 4;
  if (*param_1 != '\0') {
    if (pcVar1 != param_2) {
      FUN_005507b0();
      uVar2 = *(undefined4 *)(param_2 + 4);
      uVar3 = *(undefined4 *)(param_2 + 8);
      uVar4 = *(undefined4 *)(param_2 + 0xc);
      *(undefined4 *)pcVar1 = *(undefined4 *)param_2;
      *(undefined4 *)(param_1 + 8) = uVar2;
      *(undefined4 *)(param_1 + 0xc) = uVar3;
      *(undefined4 *)(param_1 + 0x10) = uVar4;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x10);
      param_2[0x10] = '\0';
      param_2[0x11] = '\0';
      param_2[0x12] = '\0';
      param_2[0x13] = '\0';
      param_2[0x14] = '\x0f';
      param_2[0x15] = '\0';
      param_2[0x16] = '\0';
      param_2[0x17] = '\0';
      *param_2 = '\0';
    }
    return param_1;
  }
  param_1[0x14] = '\0';
  param_1[0x15] = '\0';
  param_1[0x16] = '\0';
  param_1[0x17] = '\0';
  param_1[0x18] = '\0';
  param_1[0x19] = '\0';
  param_1[0x1a] = '\0';
  param_1[0x1b] = '\0';
  uVar2 = *(undefined4 *)(param_2 + 4);
  uVar3 = *(undefined4 *)(param_2 + 8);
  uVar4 = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)pcVar1 = *(undefined4 *)param_2;
  *(undefined4 *)(param_1 + 8) = uVar2;
  *(undefined4 *)(param_1 + 0xc) = uVar3;
  *(undefined4 *)(param_1 + 0x10) = uVar4;
  *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x10);
  param_2[0x10] = '\0';
  param_2[0x11] = '\0';
  param_2[0x12] = '\0';
  param_2[0x13] = '\0';
  param_2[0x14] = '\x0f';
  param_2[0x15] = '\0';
  param_2[0x16] = '\0';
  param_2[0x17] = '\0';
  *param_2 = '\0';
  *param_1 = '\x01';
  return param_1;
}



/* FUNCTION 8151 ; VA 0x006861c0 ; FUN_006861c0 */

void FUN_006861c0(int param_1)

{
  if (param_1 != 0) {
    FUN_0154e020(param_1 + 0x20,0x20);
    FUN_0154e020(param_1 + 0x40,0x20);
    FUN_0154e020(param_1 + 0x60,0x20);
    FUN_0154e020(param_1 + 0x80,0x20);
    FUN_0154e020(param_1 + 0xa0,0x20);
    FUN_01674ea0(param_1,0xe0);
  }
  return;
}



/* FUNCTION 8152 ; VA 0x00686220 ; FUN_00686220 */

undefined4 * __thiscall FUN_00686220(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Security::SessionCrypto::vftable;
  if (param_1[8] != 0) {
    FUN_006861c0(param_1[8]);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 8153 ; VA 0x00686260 ; FUN_00686260 */

longlong FUN_00686260(uint *param_1,uint param_2,int param_3)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  longlong lVar4;
  uint uVar5;
  uint uVar6;
  
  do {
    uVar2 = *param_1;
    uVar3 = param_1[1];
    lVar4 = *(longlong *)param_1;
    LOCK();
    lVar1 = *(longlong *)param_1;
    if (*(longlong *)param_1 == lVar1) {
      *(longlong *)param_1 = CONCAT44(uVar3 + param_3 + (uint)CARRY4(uVar2,param_2),uVar2 + param_2)
      ;
      uVar5 = uVar2;
      uVar6 = uVar3;
    }
    else {
      uVar5 = (uint)lVar1;
      uVar6 = (uint)((ulonglong)lVar1 >> 0x20);
    }
    UNLOCK();
  } while ((uVar2 != uVar5) || (uVar3 != uVar6));
  return lVar4;
}



/* FUNCTION 8154 ; VA 0x006862a0 ; FUN_006862a0 */

longlong FUN_006862a0(uint *param_1,uint param_2,uint param_3)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  longlong lVar4;
  uint uVar5;
  uint uVar6;
  
  do {
    uVar2 = *param_1;
    uVar3 = param_1[1];
    lVar4 = *(longlong *)param_1;
    LOCK();
    lVar1 = *(longlong *)param_1;
    if (*(longlong *)param_1 == lVar1) {
      *(longlong *)param_1 = CONCAT44(uVar3 | param_3,uVar2 | param_2);
      uVar5 = uVar2;
      uVar6 = uVar3;
    }
    else {
      uVar5 = (uint)lVar1;
      uVar6 = (uint)((ulonglong)lVar1 >> 0x20);
    }
    UNLOCK();
  } while ((uVar2 != uVar5) || (uVar3 != uVar6));
  return lVar4;
}



/* FUNCTION 8155 ; VA 0x006862e0 ; FUN_006862e0 */

bool __thiscall FUN_006862e0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  puVar1 = param_3 + 4;
  puVar3 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar3 = (undefined4 *)*param_3;
  }
  if ((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) {
    if (param_2[4] != 0x1c) {
      return false;
    }
    param_3 = (undefined4 *)((uint)param_3 & 0xffffff);
    iVar2 = 0x29;
    if (*(char *)(param_1 + 0x24) == '\0') {
      iVar2 = 0x49;
    }
    param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
    iVar2 = FUN_0154d9e0((int)&param_3 + 3,0,(int)&param_2 + 3,0,0,puVar4 + 3,puVar3,*puVar1,0,
                         puVar4,iVar2 + param_1);
    return iVar2 == 0;
  }
  return false;
}



/* FUNCTION 8156 ; VA 0x00686380 ; FUN_00686380 */

uint __thiscall
FUN_00686380(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  uint in_EAX;
  int iVar1;
  undefined4 uStack_8;
  
  if (((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) &&
     (param_3 == 0x1c)) {
    iVar1 = 0x29;
    uStack_8 = (uint)((uint3)param_1 & 0xffff);
    if (*(char *)(param_1 + 0x24) == '\0') {
      iVar1 = 0x49;
    }
    in_EAX = FUN_0154d9e0((int)&uStack_8 + 2,0,(int)&uStack_8 + 3,0,0,param_2 + 0xc,param_4,param_5,
                          0,param_2,iVar1 + param_1);
    if (in_EAX == 0) {
      return 1;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8157 ; VA 0x006863f0 ; FUN_006863f0 */

uint __thiscall FUN_006863f0(int param_1,undefined4 param_2,int param_3)

{
  uint in_EAX;
  int iVar1;
  
  if ((((*(char *)(param_1 + 0x27) == '\0') && (param_3 == 0x20)) &&
      (*(char *)(param_1 + 0x24) == '\0')) && (iVar1 = *(int *)(param_1 + 0x20), iVar1 != 0)) {
    iVar1 = FUN_0154dcb0(param_1 + 0x49,param_1 + 0x29,iVar1,iVar1 + 0x20,param_2);
    if (iVar1 == 0) {
      *(undefined *)(param_1 + 0x26) = 1;
      return 1;
    }
    in_EAX = *(uint *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = 0;
    if (in_EAX != 0) {
      in_EAX = FUN_006861c0(in_EAX);
    }
    *(undefined2 *)(param_1 + 0x25) = 0;
    *(undefined *)(param_1 + 0x27) = 1;
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8158 ; VA 0x00686470 ; FUN_00686470 */

uint __thiscall FUN_00686470(int param_1,undefined4 param_2,uint param_3,int param_4,uint param_5)

{
  uint in_EAX;
  int iVar1;
  
  if ((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) {
    in_EAX = param_5 - 0x1c;
    if ((param_3 == in_EAX) && (0x1b < param_5)) {
      iVar1 = 0x29;
      if (*(char *)(param_1 + 0x24) == '\0') {
        iVar1 = 0x49;
      }
      in_EAX = FUN_0154d9e0(param_2,0,param_4,param_3,0,param_4 + param_3 + 0xc,0,0,0,
                            param_4 + param_3,iVar1 + param_1);
      if (in_EAX == 0) {
        return 1;
      }
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8159 ; VA 0x006864f0 ; FUN_006864f0 */

uint __thiscall FUN_006864f0(int param_1,int param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  undefined auStack_18 [12];
  uint uStack_c;
  undefined4 uStack_8;
  
  if (((0x11 < param_3) && (iVar3 = param_3 - 0x12, *(char *)(param_1 + 0x27) == '\0')) &&
     (*(char *)(param_1 + 0x26) != '\0')) {
    uStack_c = (uint)*(ushort *)(iVar3 + param_2);
    FUN_00686c40(uStack_c,auStack_18);
    uStack_8 = 0x49;
    pcVar4 = FUN_0154d9e0;
    if ((*(byte *)(param_1 + 0x28) & 2) != 0) {
      pcVar4 = (code *)&LAB_0154b7a0;
    }
    iVar1 = 0x29;
    if (*(char *)(param_1 + 0x24) == '\0') {
      iVar1 = 0x49;
    }
    param_3 = (*pcVar4)(param_2,0,param_2,iVar3,0,param_2 + 2 + iVar3,0,0,0,auStack_18,
                        iVar1 + param_1);
    if (param_3 == 0) {
      uStack_c = uStack_c & 0xffff;
      iVar3 = uStack_c - *(ushort *)(param_1 + 0x18);
      if (iVar3 < -0x8000) {
        uVar2 = *(uint *)(param_1 + 0x18);
        *(uint *)(param_1 + 0x18) = uVar2 + 0x10000 & 0xffff0000 | uStack_c;
        *(uint *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + (uint)(0xfffeffff < uVar2);
        return CONCAT31((int3)(uStack_c >> 8),1);
      }
      uVar2 = (uint)*(ushort *)(param_1 + 0x18);
      if (0 < iVar3) {
        *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_1 + 0x1c);
        *(uint *)(param_1 + 0x18) = *(uint *)(param_1 + 0x18) & 0xffff0000 | uStack_c;
        uVar2 = uStack_c;
      }
      return CONCAT31((int3)(uVar2 >> 8),1);
    }
  }
  return param_3 & 0xffffff00;
}



/* FUNCTION 8160 ; VA 0x006865f0 ; FUN_006865f0 */

/* WARNING: Removing unreachable block (ram,0x006866d4) */
/* WARNING: Removing unreachable block (ram,0x00686711) */
/* WARNING: Removing unreachable block (ram,0x00686719) */
/* WARNING: Removing unreachable block (ram,0x00686727) */
/* WARNING: Removing unreachable block (ram,0x0068675a) */
/* WARNING: Removing unreachable block (ram,0x00686737) */

undefined * FUN_006865f0(undefined *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *****pppppuVar2;
  uint uVar3;
  uint uVar4;
  undefined4 ****appppuStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5298;
  pvStack_10 = ExceptionList;
  uVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (0x1b < uVar1) {
    uStack_8 = 0;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_00686130(auStack_2c);
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    FUN_0058a370(uVar1 - 0x1c,0);
    pppppuVar2 = appppuStack_44;
    if (0xf < uStack_30) {
      pppppuVar2 = (undefined4 *****)appppuStack_44[0];
    }
    FUN_00686470(pppppuVar2,uVar1 - 0x1c,param_2,uVar1);
    *param_1 = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 8161 ; VA 0x00686760 ; FUN_00686760 */

undefined4 __thiscall FUN_00686760(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  uVar3 = (**(code **)(*param_2 + 8))();
  if (param_3 + 0x1cU <= uVar3) {
    FUN_006a5790();
    iVar4 = (**(code **)(*param_2 + 4))();
    iVar5 = (**(code **)(*param_2 + 4))();
    if ((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x25) != '\0')) {
      iVar6 = 0x80;
      if (*(char *)(param_1 + 0x24) == '\0') {
        iVar6 = 0xa0;
      }
      iVar2 = *(int *)(param_1 + 0x20);
      FUN_0170c6f0(iVar4,iVar5,param_3);
      iVar1 = iVar5 + (uVar3 - 0x1c);
      iVar4 = FUN_0154d9e0(iVar4 + param_3,0,iVar5 + param_3,(uVar3 - 0x1c) - param_3,0,iVar1 + 0xc,
                           iVar5,param_3,0,iVar1,iVar6 + iVar2);
      if (iVar4 == 0) {
        FUN_006a5c40(uVar3 * 8 + -0xe0,0);
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 8162 ; VA 0x00686830 ; FUN_00686830 */

uint FUN_00686830(int *param_1,int param_2,uint param_3)

{
  int iVar1;
  longlong lVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  uint uVar7;
  int iVar8;
  longlong lStack_1c;
  int iStack_c;
  uint uStack_8;
  
  param_3 = param_3 & 0xffff;
  iVar4 = (**(code **)(*param_1 + 8))();
  iVar4 = iVar4 - param_3;
  FUN_006a5790();
  FUN_006a5860(param_3 + 0x1c + iVar4);
  iVar5 = (**(code **)(*param_1 + 4))();
  iVar5 = param_3 + iVar5;
  uVar7 = uStack_8;
  if ((*(char *)(uStack_8 + 0x27) == '\0') && (*(char *)(uStack_8 + 0x25) != '\0')) {
    iVar8 = 0xa0;
    if (*(char *)(uStack_8 + 0x24) == '\0') {
      iVar8 = 0x80;
    }
    iVar1 = *(int *)(uStack_8 + 0x20);
    FUN_0170c6f0(iVar5,iVar5,param_2);
    uVar3 = DAT_018d6c30;
    lVar2 = DAT_018d6c28;
    plVar6 = (longlong *)(iVar4 + iVar5);
    lStack_1c = FUN_00686260(uStack_8 + 8,1,0);
    lStack_1c = lStack_1c + lVar2;
    *plVar6 = lStack_1c;
    *(undefined4 *)(plVar6 + 1) = uVar3;
    uVar7 = FUN_0154db60(iVar5 + param_2,(int)plVar6 + 0xc,&iStack_c,iVar5 + param_2,iVar4 - param_2
                         ,0,iVar5,param_2,0,0,plVar6,iVar8 + iVar1);
    if (((uVar7 == 0) && (iStack_c == 0x10)) && (uStack_8 == 0)) {
      return 1;
    }
  }
  return uVar7 & 0xffffff00;
}



/* FUNCTION 8163 ; VA 0x00686940 ; FUN_00686940 */

uint __thiscall FUN_00686940(int param_1,int param_2,uint param_3,undefined4 param_4,int param_5)

{
  uint in_EAX;
  undefined4 uVar1;
  int iVar2;
  undefined auStack_14 [8];
  undefined4 uStack_c;
  char cStack_5;
  
  if ((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) {
    cStack_5 = *(char *)(param_1 + 0x24);
    in_EAX = param_5 + 0x1c;
    if (param_3 == in_EAX) {
      uVar1 = FUN_006873b0(param_2 + param_5);
      uStack_c = 0x29;
      iVar2 = 0x49;
      if (cStack_5 == '\0') {
        iVar2 = 0x29;
      }
      in_EAX = FUN_0154db60(param_2,param_5 + 0xc + param_2,auStack_14,param_4,param_5,0,0,0,0,0,
                            uVar1,iVar2 + param_1);
      if (in_EAX == 0) {
        return 1;
      }
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8164 ; VA 0x006869d0 ; FUN_006869d0 */

bool __thiscall FUN_006869d0(int param_1,int param_2,uint param_3)

{
  undefined4 uVar1;
  int iVar2;
  code *pcVar3;
  undefined auStack_1c [8];
  int iStack_14;
  undefined4 uStack_10;
  int iStack_c;
  char cStack_5;
  
  if (((0x11 < param_3) && (*(char *)(param_1 + 0x27) == '\0')) &&
     (*(char *)(param_1 + 0x26) != '\0')) {
    cStack_5 = *(char *)(param_1 + 0x24);
    iStack_c = param_3 - 0x12;
    iStack_14 = param_2;
    uVar1 = FUN_00687400(iStack_c + param_2);
    pcVar3 = FUN_0154db60;
    if ((*(byte *)(param_1 + 0x28) & 2) != 0) {
      pcVar3 = (code *)&LAB_0154c8b0;
    }
    uStack_10 = 0x29;
    iVar2 = 0x49;
    if (cStack_5 == '\0') {
      iVar2 = 0x29;
    }
    iVar2 = (*pcVar3)(param_2,iStack_c + 2 + param_2,auStack_1c,iStack_14,iStack_c,0,0,0,0,0,uVar1,
                      iVar2 + param_1);
    return iVar2 == 0;
  }
  return false;
}



/* FUNCTION 8165 ; VA 0x00686a90 ; FUN_00686a90 */

/* WARNING: Removing unreachable block (ram,0x00686b52) */
/* WARNING: Removing unreachable block (ram,0x00686b8f) */
/* WARNING: Removing unreachable block (ram,0x00686b97) */
/* WARNING: Removing unreachable block (ram,0x00686ba5) */
/* WARNING: Removing unreachable block (ram,0x00686bd8) */
/* WARNING: Removing unreachable block (ram,0x00686bb5) */

undefined * FUN_00686a90(undefined *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  uint uVar4;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5298;
  pvStack_10 = ExceptionList;
  iVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00686130(auStack_2c);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0058a370(iVar1 + 0x1c,0);
  ppppuVar2 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar2 = (undefined4 ****)apppuStack_44[0];
  }
  FUN_00686940(ppppuVar2,uStack_34,param_2,iVar1);
  *param_1 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8166 ; VA 0x00686be0 ; FUN_00686be0 */

byte __fastcall FUN_00686be0(int param_1)

{
  byte bVar1;
  
  bVar1 = *(byte *)(param_1 + 0x28);
  if (bVar1 == 0) {
    return bVar1;
  }
  return (byte)~bVar1 >> 7;
}



/* FUNCTION 8167 ; VA 0x00686bf0 ; FUN_00686bf0 */

void __thiscall FUN_00686bf0(int param_1,int *param_2)

{
  if ((*(char *)(param_1 + 0x27) == '\0') && (*(int *)(param_1 + 0x20) != 0)) {
    *param_2 = *(int *)(param_1 + 0x20);
    param_2[1] = 0x20;
    return;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return;
}



/* FUNCTION 8168 ; VA 0x00686c30 ; FUN_00686c30 */

undefined __fastcall FUN_00686c30(int param_1)

{
  return *(undefined *)(param_1 + 0x28);
}



/* FUNCTION 8169 ; VA 0x00686c40 ; FUN_00686c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_00686c40(int param_1,ushort param_2,uint *param_3)

{
  ushort uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  
  uVar1 = *(ushort *)(param_1 + 0x18);
  uVar5 = *(uint *)(param_1 + 0x1c);
  iVar3 = (uint)param_2 - (uint)uVar1;
  uVar4 = *(uint *)(param_1 + 0x18) & 0xffff0000 | (uint)param_2;
  if (iVar3 < -0x8000) {
    bVar6 = 0xfffeffff < uVar4;
    uVar4 = uVar4 + 0x10000;
    uVar5 = uVar5 + bVar6;
  }
  else if (0x8000 < iVar3) {
    bVar6 = 0xffff < uVar4;
    uVar4 = uVar4 - 0x10000;
    uVar5 = (uVar5 - 1) + (uint)bVar6;
  }
  *(undefined8 *)param_3 = _DAT_018d6c38;
  uVar2 = DAT_018d6c40;
  param_3[2] = DAT_018d6c40;
  param_3[1] = uVar5;
  *param_3 = uVar4;
  return CONCAT31((int3)(CONCAT22((short)(uVar2 >> 0x10),param_2) >> 8),param_2 != uVar1);
}



/* FUNCTION 8170 ; VA 0x00686cc0 ; FUN_00686cc0 */

uint FUN_00686cc0(void)

{
  uint in_EAX;
  
  if (DAT_01d5afb0 == '\0') {
    in_EAX = FUN_0154d8e0();
    if (in_EAX == 1) {
      return 1;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8171 ; VA 0x00686ce0 ; FUN_00686ce0 */

uint __thiscall
FUN_00686ce0(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  uint in_EAX;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_6;
  undefined uStack_5;
  
  if (((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) &&
     (cVar1 = *(char *)(param_1 + 0x24), param_3 == 0x1c)) {
    uStack_5 = 0;
    uStack_6 = 0;
    uStack_10 = 0x10;
    uStack_c = 0;
    uVar2 = FUN_006873b0(param_2);
    iVar3 = 0x49;
    if (cVar1 == '\0') {
      iVar3 = 0x29;
    }
    in_EAX = FUN_0154db60(&uStack_6,param_2 + 0xc,&uStack_10,&uStack_5,0,0,param_4,param_5,0,0,uVar2
                          ,iVar3 + param_1);
    if (in_EAX == 0) {
      return 1;
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8172 ; VA 0x00686d80 ; FUN_00686d80 */

/* WARNING: Removing unreachable block (ram,0x00686e3d) */
/* WARNING: Removing unreachable block (ram,0x00686e7d) */
/* WARNING: Removing unreachable block (ram,0x00686e85) */
/* WARNING: Removing unreachable block (ram,0x00686e93) */
/* WARNING: Removing unreachable block (ram,0x00686ec5) */
/* WARNING: Removing unreachable block (ram,0x00686ea3) */

undefined * FUN_00686d80(undefined *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  undefined4 ***pppuVar4;
  uint uVar5;
  undefined4 **appuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a52b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00686130(auStack_28);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar5);
  }
  FUN_0058a370(0x1c,0);
  pppuVar4 = appuStack_40;
  if (0xf < uStack_2c) {
    pppuVar4 = (undefined4 ***)appuStack_40[0];
  }
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_00686ce0(pppuVar4,uStack_30,param_2,*puVar1);
  if (cVar2 == '\0') {
    *param_1 = 0;
  }
  else {
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8173 ; VA 0x00686ed0 ; FUN_00686ed0 */

/* WARNING: Removing unreachable block (ram,0x00686f83) */
/* WARNING: Removing unreachable block (ram,0x00686fc3) */
/* WARNING: Removing unreachable block (ram,0x00686fcb) */
/* WARNING: Removing unreachable block (ram,0x00686fd9) */
/* WARNING: Removing unreachable block (ram,0x0068700b) */
/* WARNING: Removing unreachable block (ram,0x00686fe9) */

undefined * FUN_00686ed0(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 ***pppuVar2;
  uint uVar3;
  uint uVar4;
  undefined4 **appuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a52b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00686130(auStack_28);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0058a370(0x1c,0);
  pppuVar2 = appuStack_40;
  if (0xf < uStack_2c) {
    pppuVar2 = (undefined4 ***)appuStack_40[0];
  }
  cVar1 = FUN_00686ce0(pppuVar2,uStack_30,param_2,param_3);
  if (cVar1 == '\0') {
    *param_1 = 0;
  }
  else {
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8174 ; VA 0x00687020 ; FUN_00687020 */

uint __thiscall FUN_00687020(int param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  
  *(undefined *)(param_1 + 0x24) = 0;
  cVar1 = FUN_006870c0();
  if ((cVar1 == '\0') || (param_3 != 0x20)) {
    uVar3 = *(uint *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  else {
    FUN_0170c6f0(*(int *)(param_1 + 0x20) + 0x40,param_2,0x20);
    iVar2 = *(int *)(param_1 + 0x20);
    iVar2 = FUN_0154dcb0(iVar2 + 0xa0,iVar2 + 0x80,iVar2,iVar2 + 0x20,param_2);
    if (iVar2 == 0) {
      *(undefined *)(param_1 + 0x25) = 1;
      return 1;
    }
    uVar3 = *(uint *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  if (uVar3 != 0) {
    uVar3 = FUN_006861c0(uVar3);
  }
  *(undefined2 *)(param_1 + 0x25) = 0;
  *(undefined *)(param_1 + 0x27) = 1;
  return uVar3 & 0xffffff00;
}



/* FUNCTION 8175 ; VA 0x006870c0 ; FUN_006870c0 */

bool __fastcall FUN_006870c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  *(undefined2 *)(param_1 + 0x25) = 0;
  piVar1 = (int *)(param_1 + 0x20);
  *(undefined *)(param_1 + 0x27) = 0;
  iVar3 = FUN_01674e20(0xe0);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    FUN_0154e020(iVar3,0x20);
    FUN_0154e020(iVar3 + 0x20,0x20);
    FUN_0154e020(iVar3 + 0x40,0x20);
    FUN_0154e020(iVar3 + 0x60,0x20);
    FUN_0154e020(iVar3 + 0x80,0x20);
    FUN_0154e020(iVar3 + 0xa0,0x20);
  }
  iVar2 = *piVar1;
  *piVar1 = iVar3;
  if (iVar2 != 0) {
    FUN_006861c0(iVar2);
    iVar3 = *piVar1;
  }
  iVar3 = FUN_0154ddd0(iVar3,iVar3 + 0x20);
  return iVar3 == 0;
}



/* FUNCTION 8176 ; VA 0x00687160 ; FUN_00687160 */

undefined4 __thiscall
FUN_00687160(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  char cVar2;
  
  *(undefined *)(param_1 + 0x24) = 1;
  cVar2 = FUN_006870c0();
  if (((cVar2 != '\0') && (param_3 == 0x20)) && (param_5 == 0x20)) {
    FUN_0170c6f0(*(int *)(param_1 + 0x20) + 0x40,param_2,0x20);
    FUN_0170c6f0(*(int *)(param_1 + 0x20) + 0x60,param_4,0x20);
    return 1;
  }
  iVar1 = *(int *)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (iVar1 != 0) {
    FUN_006861c0(iVar1);
  }
  *(undefined2 *)(param_1 + 0x25) = 0;
  *(undefined *)(param_1 + 0x27) = 1;
  return 0;
}



/* FUNCTION 8177 ; VA 0x006871e0 ; FUN_006871e0 */

byte FUN_006871e0(byte param_1)

{
  return param_1 >> 1 & 1;
}



/* FUNCTION 8178 ; VA 0x006871f0 ; FUN_006871f0 */

undefined __fastcall FUN_006871f0(int param_1)

{
  if ((*(char *)(param_1 + 0x27) == '\0') && (*(char *)(param_1 + 0x26) != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 8179 ; VA 0x00687210 ; FUN_00687210 */

byte FUN_00687210(byte param_1)

{
  return param_1 >> 7;
}



/* FUNCTION 8180 ; VA 0x00687220 ; FUN_00687220 */

void __thiscall FUN_00687220(int param_1,char param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (iVar1 != 0) {
    FUN_006861c0(iVar1);
  }
  *(undefined *)(param_1 + 0x25) = 0;
  if (param_2 != '\0') {
    *(undefined2 *)(param_1 + 0x26) = 0x100;
  }
  return;
}



/* FUNCTION 8181 ; VA 0x00687260 ; FUN_00687260 */

undefined4 __thiscall FUN_00687260(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if ((((*(char *)(param_1 + 0x27) == '\0') && (param_3 == 0x20)) &&
      (*(char *)(param_1 + 0x24) != '\0')) && (iVar4 = *(int *)(param_1 + 0x20), iVar4 != 0)) {
    iVar4 = FUN_0154ddf0(iVar4 + 0x80,iVar4 + 0xa0,iVar4 + 0x40,iVar4 + 0x60,param_2);
    if (iVar4 == 0) {
      *(undefined *)(param_1 + 0x25) = 1;
      iVar4 = *(int *)(param_1 + 0x20);
      uVar1 = param_2[1];
      uVar2 = param_2[2];
      uVar3 = param_2[3];
      *(undefined4 *)(iVar4 + 0xc0) = *param_2;
      *(undefined4 *)(iVar4 + 0xc4) = uVar1;
      *(undefined4 *)(iVar4 + 200) = uVar2;
      *(undefined4 *)(iVar4 + 0xcc) = uVar3;
      uVar1 = param_2[5];
      uVar2 = param_2[6];
      uVar3 = param_2[7];
      *(undefined4 *)(iVar4 + 0xd0) = param_2[4];
      *(undefined4 *)(iVar4 + 0xd4) = uVar1;
      *(undefined4 *)(iVar4 + 0xd8) = uVar2;
      *(undefined4 *)(iVar4 + 0xdc) = uVar3;
      return 1;
    }
    iVar4 = *(int *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = 0;
    if (iVar4 != 0) {
      FUN_006861c0(iVar4);
    }
    *(undefined2 *)(param_1 + 0x25) = 0;
    *(undefined *)(param_1 + 0x27) = 1;
  }
  return 0;
}



/* FUNCTION 8182 ; VA 0x00687300 ; FUN_00687300 */

uint __fastcall FUN_00687300(int param_1)

{
  uint in_EAX;
  int iVar1;
  
  if (((*(char *)(param_1 + 0x27) == '\0') && (iVar1 = *(int *)(param_1 + 0x20), iVar1 != 0)) &&
     (*(char *)(param_1 + 0x24) != '\0')) {
    iVar1 = FUN_0154ddf0(param_1 + 0x29,param_1 + 0x49,iVar1,iVar1 + 0x20,iVar1 + 0xc0);
    if (iVar1 == 0) {
      *(undefined *)(param_1 + 0x26) = 1;
      return 1;
    }
    in_EAX = *(uint *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = 0;
    if (in_EAX != 0) {
      in_EAX = FUN_006861c0(in_EAX);
    }
    *(undefined2 *)(param_1 + 0x25) = 0;
    *(undefined *)(param_1 + 0x27) = 1;
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 8183 ; VA 0x00687370 ; FUN_00687370 */

void __thiscall FUN_00687370(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x28) = param_2;
  return;
}



/* FUNCTION 8184 ; VA 0x00687380 ; FUN_00687380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00687380(undefined4 *param_1,int param_2)

{
  if (param_2 == 0x20) {
    _DAT_01eadee8 = *param_1;
    uRam01eadeec = param_1[1];
    uRam01eadef0 = param_1[2];
    uRam01eadef4 = param_1[3];
    _DAT_01eadef8 = param_1[4];
    uRam01eadefc = param_1[5];
    uRam01eadf00 = param_1[6];
    uRam01eadf04 = param_1[7];
  }
  return;
}



/* FUNCTION 8185 ; VA 0x006873b0 ; FUN_006873b0 */

void __thiscall FUN_006873b0(int param_1,longlong *param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong lStack_10;
  
  uVar2 = DAT_018d6c30;
  lVar1 = DAT_018d6c28;
  lStack_10 = FUN_00686260(param_1 + 8,1,0);
  lStack_10 = lStack_10 + lVar1;
  *param_2 = lStack_10;
  *(undefined4 *)(param_2 + 1) = uVar2;
  return;
}



/* FUNCTION 8186 ; VA 0x00687400 ; FUN_00687400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall FUN_00687400(int param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  
  *param_2 = _DAT_018d6c38;
  *(undefined4 *)(param_2 + 1) = DAT_018d6c40;
  uVar1 = FUN_00686260(param_1 + 0x10,1,0);
  *param_2 = uVar1;
  return param_2;
}



/* FUNCTION 8187 ; VA 0x00687440 ; FUN_00687440 */

undefined4 * __thiscall FUN_00687440(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_008881d0();
  *param_1 = uVar3;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  iVar2 = _tls_index;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  param_1[1] = &DAT_01ea8a90;
  return param_1;
}



/* FUNCTION 8188 ; VA 0x006874f0 ; FUN_006874f0 */

undefined4 * __thiscall FUN_006874f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0088cdc0();
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  uVar2 = FUN_006309e0();
  param_1[1] = uVar2;
  return param_1;
}



/* FUNCTION 8189 ; VA 0x00687540 ; FUN_00687540 */

undefined4 * __thiscall FUN_00687540(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  uVar2 = FUN_006309e0();
  *param_1 = uVar2;
  return param_1;
}



/* FUNCTION 8190 ; VA 0x00687590 ; FUN_00687590 */

void FUN_00687590(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar2 = param_1 + 3;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      if (*piVar2 != 0) {
        (**(code **)(*piVar2 + 8))(piVar2 + 1);
      }
      piVar1 = piVar2 + 0x33;
      piVar2 = piVar2 + 0x36;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8191 ; VA 0x00687600 ; FUN_00687600 */

undefined4 * __thiscall
FUN_00687600(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a52d0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_005f8250(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_005f8250(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      piVar2 = (int *)FUN_00551320();
      if ((*piVar2 == *param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_005f8250(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_005f8250(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_005f85b0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8192 ; VA 0x006877ed ; Catch_All@006877ed */

void Catch_All_006877ed(void)

{
  int unaff_EBP;
  
  FUN_005f0c20(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8193 ; VA 0x00687810 ; FUN_00687810 */

void __thiscall FUN_00687810(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a52e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined *)(((int)param_3 - (int)param_2) / 0xd8);
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar1 != (undefined *)0x0) {
    if (&DAT_012f684b < puVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = (int)puVar1 * 0xd8;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar2 = uVar5 + 0x23;
      if (uVar2 <= uVar5) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar5;
    puVar6 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; param_2 != param_3; param_2 = param_2 + 0x36) {
      *puVar6 = *param_2;
      puVar6[1] = param_2[1];
      puVar6[2] = param_2[2];
      puVar6[3] = 0;
      puVar4 = (undefined4 *)param_2[3];
      if (puVar4 != (undefined4 *)0x0) {
        (*(code *)*puVar4)(param_2 + 4,puVar6 + 4);
        puVar4 = (undefined4 *)param_2[3];
      }
      puVar6[3] = puVar4;
      puVar6 = puVar6 + 0x36;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00687590(puVar6,puVar6,param_1);
    param_1[1] = (uint)puVar6;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8194 ; VA 0x00687960 ; Catch_All@00687960 */

void Catch_All_00687960(void)

{
  FUN_0068a760();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8195 ; VA 0x00687980 ; FUN_00687980 */

void __thiscall FUN_00687980(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5308;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_005759f0(((int)param_3 - (int)param_2) / 0xd0);
  if (cVar1 != '\0') {
    puVar3 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; param_2 != param_3; param_2 = param_2 + 0x34) {
      *puVar3 = *param_2;
      puVar3[1] = 0;
      puVar2 = (undefined4 *)param_2[1];
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)*puVar2)(param_2 + 2,puVar3 + 2);
        puVar2 = (undefined4 *)param_2[1];
      }
      puVar3[1] = puVar2;
      puVar3 = puVar3 + 0x34;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00559720(puVar3,puVar3,param_1);
    param_1[1] = puVar3;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8196 ; VA 0x00687a42 ; Catch_All@00687a42 */

void Catch_All_00687a42(void)

{
  FUN_00577b20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8197 ; VA 0x00687a60 ; FUN_00687a60 */

int __thiscall FUN_00687a60(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Network::ClientReplicator*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8198 ; VA 0x00687b32 ; Catch_All@00687b32 */

void Catch_All_00687b32(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8199 ; VA 0x00687b50 ; FUN_00687b50 */

void __thiscall
FUN_00687b50(undefined4 *param_1,int param_2,undefined4 param_3,int param_4,undefined4 param_5)

{
  bool bVar1;
  char cVar2;
  undefined **ppuVar3;
  int iVar4;
  uint uVar5;
  int aiStack_44 [2];
  int iStack_3c;
  undefined4 uStack_38;
  int aiStack_34 [2];
  int iStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006400f0(&param_2);
  uStack_38 = param_5;
  uStack_8._0_1_ = 1;
  FUN_006400f0(aiStack_44);
  uStack_18 = uStack_38;
  uStack_8._0_1_ = 2;
  cVar2 = FUN_00585a40(auStack_24);
  if (cVar2 == '\0') {
    FUN_006400f0(auStack_24);
    uStack_28 = uStack_18;
    uStack_8._0_1_ = 3;
    FUN_006400f0(aiStack_34);
    param_1[5] = uStack_28;
    if (aiStack_34[0] != 0) {
      uVar5 = iStack_2c - aiStack_34[0];
      iVar4 = aiStack_34[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_34[0] + -4);
        uVar5 = uVar5 + 0x23;
        if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    FUN_0056d2d0();
    bVar1 = true;
  }
  else {
    FUN_0056d2d0();
    bVar1 = false;
  }
  if (aiStack_44[0] != 0) {
    uVar5 = iStack_3c - aiStack_44[0];
    iVar4 = aiStack_44[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_44[0] + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (aiStack_44[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ppuVar3 = &PTR_FUN_018d7a24;
  if (!bVar1) {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (param_2 != 0) {
    uVar5 = param_4 - param_2;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8200 ; VA 0x00687cc0 ; FUN_00687cc0 */

undefined4 * __thiscall FUN_00687cc0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_0068ad10;
    puVar2[3] = _guard_check_icall;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    puVar2[6] = *param_3;
  }
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8201 ; VA 0x00687d80 ; FUN_00687d80 */

undefined4 * FUN_00687d80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5393;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar10 = FUN_005edd10();
  uVar11 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar10 + 0x1dc) != (undefined4 *)0x0) {
    uVar11 = **(undefined4 **)(iVar10 + 0x1dc);
  }
  uVar11 = FUN_01675290(uVar11);
  uStack_8 = 1;
  iVar10 = FUN_01674e20(0x3ce8);
  uStack_8._0_1_ = 2;
  if (iVar10 == 0) {
    uVar12 = 0;
  }
  else {
    uVar12 = *param_2;
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    uVar5 = param_2[4];
    uVar6 = param_2[5];
    uVar7 = param_2[6];
    uVar8 = param_2[7];
    uVar9 = param_2[8];
    if (param_2[10] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[10] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar12 = FUN_006ec390(uVar12,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,param_2[9],
                          param_2[10]);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00687a60(uVar12,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8202 ; VA 0x00687eb0 ; FUN_00687eb0 */

void __thiscall FUN_00687eb0(int param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a53a8;
  pvStack_10 = ExceptionList;
  uVar8 = *param_3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar9 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar9;
    }
    if (piVar5 == (int *)0x0) goto LAB_00687f3d;
    do {
      if (uVar8 == piVar5[1]) {
        if (uVar8 == piVar5[2]) break;
      }
      else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar7) goto LAB_00687f3d;
      piVar5 = (int *)*piVar5;
    } while (piVar5 != (int *)0x0);
  }
  if (piVar5 != (int *)0x0) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_00687f3d:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(0xc);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  piVar5[2] = *param_4;
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar6 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar6 = 1;
    }
    iVar4 = FUN_005c9310(uVar6 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (puVar2 != (undefined4 *)0x0) {
        uVar7 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar7 * 4) == 0) {
          *piVar3 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar9 = piVar3;
    *piVar5 = *piVar3;
    *piVar3 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar3;
    *(int **)*puVar9 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8203 ; VA 0x00688090 ; FUN_00688090 */

int __fastcall FUN_00688090(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_005edd10(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 8204 ; VA 0x006880f0 ; FUN_006880f0 */

/* WARNING: Removing unreachable block (ram,0x00688278) */
/* WARNING: Removing unreachable block (ram,0x00688236) */
/* WARNING: Removing unreachable block (ram,0x00688244) */
/* WARNING: Removing unreachable block (ram,0x006882d0) */
/* WARNING: Removing unreachable block (ram,0x00688254) */
/* WARNING: Removing unreachable block (ram,0x00688286) */
/* WARNING: Removing unreachable block (ram,0x006882d5) */
/* WARNING: Removing unreachable block (ram,0x00688296) */

void __thiscall FUN_006880f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a53d8;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  iVar5 = *(int *)(iVar1 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088c8c0();
  if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined4 *)(iVar1 + 0xd8);
  if (*(int *)(iVar1 + 0xd4) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  uVar2 = *puVar4;
  iVar1 = *param_3;
  iVar5 = *(int *)(iVar1 + 0x1a0);
  iVar3 = FUN_0088cb40();
  if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  iVar5 = iVar1 + 0x1a8;
  if (*(int *)(iVar1 + 0x1a4) == 0) {
    iVar5 = 0;
  }
  FUN_0054ef60(iVar5);
  uStack_8 = 0;
  param_3 = (int *)*param_3;
  iVar1 = *param_3;
  iVar5 = FUN_0088cb40();
  if (iVar1 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar6 = param_3 + 2;
  if (param_3[1] == 0) {
    piVar6 = (int *)0x0;
  }
  FUN_0054ef60(piVar6);
  uStack_8 = 2;
  (**(code **)(param_1 + 0x38))(1);
  FUN_00688bd0(uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20),uVar2,uStack_48
               ,uStack_44,uStack_40,uStack_3c,CONCAT44(uStack_34,uStack_38));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8205 ; VA 0x006882e0 ; FUN_006882e0 */

/* WARNING: Removing unreachable block (ram,0x006883f0) */
/* WARNING: Removing unreachable block (ram,0x006883fe) */
/* WARNING: Removing unreachable block (ram,0x0068843e) */
/* WARNING: Removing unreachable block (ram,0x0068840e) */

void __thiscall FUN_006882e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5408;
  pvStack_10 = ExceptionList;
  iVar6 = *param_3;
  iVar1 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cdc0();
  if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  iVar6 = puVar4[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar4[1];
  }
  uVar2 = *puVar4;
  uStack_8 = 0;
  param_3 = (int *)*param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0088cb40();
  if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar5 = param_3 + 2;
  if (param_3[1] == 0) {
    piVar5 = (int *)0x0;
  }
  FUN_0054ef60(piVar5);
  uStack_8 = 2;
  (**(code **)(param_1 + 0x38))(1);
  FUN_00688d70(uStack_38,uStack_34,uStack_30,uStack_2c,CONCAT44(uStack_24,uStack_28),uVar2,iVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8206 ; VA 0x00688450 ; FUN_00688450 */

undefined4 * __fastcall FUN_00688450(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a54fe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006c43c0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Network::Client,class_RBX::Network::Peer>::vftable;
  param_1[0x15] =
       RBX::DescribedCreatable<class_RBX::Network::Client,class_RBX::Network::Peer>::vftable;
  uVar2 = FUN_005edc10();
  param_1[3] = uVar2;
  *(undefined *)(param_1 + 0x40) = 1;
  *param_1 = RBX::Network::Client::vftable;
  param_1[0x15] = RBX::Network::Client::vftable;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  FUN_005f7140();
  param_1[0x4c] = 0xffffffff;
  param_1[0x4d] = 0xffffffff;
  param_1[0x52] = 0;
  param_1[0x53] = 0xf;
  *(undefined *)(param_1 + 0x4e) = 0;
  uStack_8._0_1_ = 5;
  iVar6 = DAT_01ea94c4;
  if (DAT_01ea94c4 == 0) {
    piVar3 = (int *)FUN_00910d90();
    cStack_18 = '\0';
    iVar6 = *piVar3;
    puStack_1c = (uint *)(iVar6 + 0x94);
    FUN_00587410();
    uStack_8._0_1_ = 6;
    if (DAT_01ea94c4 == 0) {
      FUN_005eeb00(auStack_24);
      uStack_8._0_1_ = 7;
      FUN_008a65e0(iVar6,0);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[1] + -1;
        piStack_20[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar3 = piStack_20 + 2;
          iVar6 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    iVar6 = DAT_01ea94c4;
    uStack_8._0_1_ = 8;
    if (cStack_18 != '\0') {
      LOCK();
      uVar4 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
        LOCK();
        uVar4 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar4 >> 0x1e & 1) == 0) {
          uVar2 = FUN_00554e40();
          SetEvent(uVar2);
        }
      }
    }
  }
  uStack_8._0_1_ = 5;
  param_1[0x54] = iVar6;
  param_1[0x55] = 0xffffffff;
  param_1[0x56] = 0xffffffff;
  param_1[0x57] = 0;
  *(undefined *)(param_1 + 0x58) = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0xf;
  *(undefined *)(param_1 + 0x59) = 0;
  FUN_005542c0("Unknown",7);
  param_1[0x5f] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uStack_8._0_1_ = 10;
  FUN_016830f0(param_1 + 0x66);
  param_1[0x6c] = 0;
  param_1[0x6d] = 0xf;
  *(undefined *)(param_1 + 0x68) = 0;
  uStack_8._0_1_ = 0xb;
  FUN_006d0970(0,0);
  uStack_8._0_1_ = 0xc;
  FUN_008866d0();
  param_1[0x10c] = 0;
  param_1[0x10d] = 0;
  param_1[0x10e] = 0;
  param_1[0x10f] = 0;
  param_1[0x110] = 0;
  param_1[0x111] = 0;
  param_1[0x112] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  *(undefined *)(param_1 + 0x113) = 0;
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,1);
  if (cVar1 == '\0') {
    FUN_01255600(1,"create a NetworkClient");
  }
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("NetworkClient",0xd);
  uStack_8._0_1_ = 0x12;
  FUN_008a6520(auStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (0xf < uStack_28) {
    uVar5 = uStack_28 + 1;
    uVar4 = auStack_3c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_3c[0] - 4);
      uVar5 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"NetworkClient:Create",0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8207 ; VA 0x006887a0 ; thunk_FUN_009cba00 */

void __fastcall thunk_FUN_009cba00(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::EventDescriptor::vftable;
  FUN_00888910();
  FUN_008925b0();
  return;
}



/* FUNCTION 8208 ; VA 0x006887b0 ; FUN_006887b0 */

void __fastcall FUN_006887b0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00687590(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8209 ; VA 0x006887f0 ; FUN_006887f0 */

void __fastcall FUN_006887f0(undefined4 *param_1)

{
  FUN_0068a870();
  FUN_01674ea0(*param_1,0x14);
  return;
}



/* FUNCTION 8210 ; VA 0x00688810 ; FUN_00688810 */

void __fastcall FUN_00688810(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0xc);
  }
  return;
}



/* FUNCTION 8211 ; VA 0x00688830 ; FUN_00688830 */

void FUN_00688830(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0068a760();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8212 ; VA 0x00688860 ; FUN_00688860 */

void __fastcall FUN_00688860(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::Client::vftable;
  param_1[0x15] = RBX::Network::Client::vftable;
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"NetworkClient:Remove",0);
  }
  FUN_00637860();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0056e380();
  FUN_0056e380();
  FUN_006d21e0();
  uVar2 = param_1[0x6d];
  if (0xf < uVar2) {
    iVar3 = param_1[0x68];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00688aff;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x6c] = 0;
  param_1[0x6d] = 0xf;
  *(undefined *)(param_1 + 0x68) = 0;
  uVar2 = param_1[0x65];
  if (0xf < uVar2) {
    iVar3 = param_1[0x60];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00688aff;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[100] = 0;
  param_1[0x65] = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uVar2 = param_1[0x5e];
  if (0xf < uVar2) {
    iVar3 = param_1[0x59];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00688aff;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x5d] = 0;
  param_1[0x5e] = 0xf;
  *(undefined *)(param_1 + 0x59) = 0;
  uVar2 = param_1[0x53];
  if (0xf < uVar2) {
    iVar3 = param_1[0x4e];
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00688aff:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x52] = 0;
  param_1[0x53] = 0xf;
  *(undefined *)(param_1 + 0x4e) = 0;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = param_1[0x41];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_006c4520();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8213 ; VA 0x00688b10 ; FUN_00688b10 */

void __fastcall FUN_00688b10(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 0xc) + 8))(param_1 + 0x10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8214 ; VA 0x00688b50 ; FUN_00688b50 */

uint * __thiscall FUN_00688b50(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint *puStack_8;
  
  puVar4 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar4[1];
    do {
      if ((uint)puVar1[4] < *param_2) {
        puVar2 = (undefined4 *)puVar1[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    if ((puVar4 != (undefined4 *)*param_1) && ((uint)puVar4[4] <= *param_2)) {
      return puVar4 + 5;
    }
  }
  puStack_8 = param_2;
  iVar3 = FUN_005f81a0(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_00687600(&param_2,puVar4,iVar3 + 0x10,iVar3);
  return param_2 + 5;
}



/* FUNCTION 8215 ; VA 0x00688bd0 ; FUN_00688bd0 */

/* WARNING: Removing unreachable block (ram,0x00688cba) */
/* WARNING: Removing unreachable block (ram,0x00688cca) */
/* WARNING: Removing unreachable block (ram,0x00688cd0) */

void __thiscall FUN_00688bd0(int *param_1,int param_2)

{
  uint in_stack_00000018;
  int in_stack_00000020;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5538;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000034) {
    if ((0xfff < in_stack_00000034 + 1) &&
       (0x1f < (in_stack_00000020 - *(int *)(in_stack_00000020 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8216 ; VA 0x00688d3f ; Catch@00688d3f */

undefined * Catch_00688d3f(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00688d50;
}



/* FUNCTION 8217 ; VA 0x00688d70 ; FUN_00688d70 */

/* WARNING: Removing unreachable block (ram,0x00688e0e) */
/* WARNING: Removing unreachable block (ram,0x00688e1e) */
/* WARNING: Removing unreachable block (ram,0x00688e24) */

void * __thiscall FUN_00688d70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000018;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a5578;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (0xf < in_stack_00000018) {
      if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      ExceptionList = &pvStack_10;
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = in_stack_00000020 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_00000020 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 8218 ; VA 0x00688eb0 ; Catch@00688eb0 */

undefined * Catch_00688eb0(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00688ec1;
}



/* FUNCTION 8219 ; VA 0x00688ed9 ; FUN_00688ed9 */

void FUN_00688ed9(void)

{
  FUN_00688f90();
  return;
}



/* FUNCTION 8220 ; VA 0x00688ef0 ; FUN_00688ef0 */

int * __thiscall FUN_00688ef0(int *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 8221 ; VA 0x00688f60 ; FUN_00688f60 */

undefined4 __thiscall FUN_00688f60(undefined4 param_1,byte param_2)

{
  FUN_009cba00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 8222 ; VA 0x00688f90 ; FUN_00688f90 */

undefined4 __thiscall FUN_00688f90(undefined4 param_1,byte param_2)

{
  FUN_00688860();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x450);
  }
  return param_1;
}



/* FUNCTION 8223 ; VA 0x00688fc0 ; FUN_00688fc0 */

void __thiscall FUN_00688fc0(int param_1,undefined4 *param_2)

{
  undefined4 ****ppppuVar1;
  undefined4 *****pppppuVar2;
  undefined4 ****ppppuVar3;
  undefined4 ***pppuVar4;
  undefined4 *****pppppuVar5;
  undefined uVar6;
  char cVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  uint *puVar11;
  undefined4 *******pppppppuVar12;
  undefined4 ******ppppppuVar13;
  undefined4 ***pppuVar14;
  undefined auStack_1dc [12];
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined *puStack_1c8;
  undefined4 ******ppppppuStack_1c4;
  undefined4 *****pppppuStack_1c0;
  undefined4 *****pppppuStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 *****pppppuStack_1ac;
  undefined4 *puStack_1a8;
  undefined4 uStack_1a4;
  int iStack_1a0;
  undefined4 ****ppppuStack_19c;
  undefined *puStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 *****pppppuStack_15c;
  undefined4 *puStack_158;
  undefined *puStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  int iStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined2 uStack_13c;
  undefined4 uStack_11c;
  int iStack_118;
  undefined *puStack_114;
  undefined *puStack_110;
  undefined auStack_d4 [12];
  undefined4 *****pppppuStack_c8;
  int iStack_c0;
  undefined4 auStack_ac [9];
  undefined4 uStack_88;
  undefined4 ***pppuStack_84;
  undefined8 uStack_7c;
  undefined auStack_70 [8];
  undefined4 ******appppppuStack_68 [3];
  code *pcStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 *****pppppuStack_50;
  undefined4 ***pppuStack_4c;
  code *pcStack_48;
  undefined4 *****pppppuStack_44;
  undefined4 ****ppppuStack_40;
  undefined auStack_3c [4];
  int iStack_38;
  int iStack_34;
  undefined4 *****pppppuStack_30;
  undefined auStack_2c [4];
  undefined4 *****pppppuStack_28;
  undefined4 ****ppppuStack_24;
  undefined4 *****pppppuStack_20;
  undefined4 *****pppppuStack_1c;
  undefined4 ****ppppuStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a5691;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffef4;
  pppppuStack_50 = (undefined4 *****)0x0;
  pppuStack_4c = (undefined4 ***)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  puStack_110 = (undefined *)0x68900d;
  ExceptionList = &pvStack_10;
  iStack_34 = param_1;
  FUN_006ab530();
  puStack_110 = (undefined *)0x1;
  puStack_114 = auStack_2c;
  _uStack_8 = CONCAT31(uStack_7,2);
  auStack_2c[0] = 0x92;
  iStack_118 = 0x689026;
  FUN_006ad5e0();
  iStack_118 = *DAT_01eeb54c - (int)DAT_01eeb54c;
  puStack_114 = (undefined *)(DAT_01eeb54c[1] - (int)DAT_01eeb54c);
  puStack_110 = auStack_d4;
  uStack_11c = 0x689042;
  FUN_006ad310();
  puStack_110 = (undefined *)0x689050;
  ppppuStack_18 = (undefined4 ****)FUN_0054db20();
  puStack_110 = (undefined *)0x0;
  puStack_114 = (undefined *)0x0;
  pppppuStack_30 = (undefined4 *****)(*ppppuStack_18)[0x13];
  iStack_148 = 0x68906b;
  FUN_005f70a0();
  iStack_148 = 0x689073;
  FUN_005f7140();
  uStack_144 = DAT_01d5b000;
  uStack_140 = DAT_01d5b004;
  uStack_13c = DAT_01d5b008;
  iStack_148 = param_1 + 0x110;
  uStack_14c = 0x68909b;
  FUN_005f7170();
  puStack_154 = auStack_d4;
  iStack_148 = 0;
  uStack_14c = 3;
  uStack_150 = 2;
  puStack_158 = (undefined4 *)0x6890ae;
  (*(code *)pppppuStack_30)();
  puStack_158 = (undefined4 *)0x6890b5;
  FUN_0068e270();
  puStack_158 = (undefined4 *)0x6890bc;
  FUN_0068e0f0();
  iVar9 = *(int *)(param_1 + 0x34);
  iVar8 = param_1;
  if ((iVar9 != 0) && (iVar8 = iVar9, *(int *)(iVar9 + 0x34) != 0)) {
    puStack_158 = (undefined4 *)0x6890cf;
    iVar8 = FUN_005c8ac0();
  }
  if (iVar8 != 0) {
    ppppuStack_18 = *(undefined4 *****)(iVar8 + 0xc);
    puStack_158 = (undefined4 *)0x6890e8;
    iVar9 = FUN_008a8c30();
    if ((uint)*(ushort *)(ppppuStack_18 + 0x76) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) {
      puStack_158 = (undefined4 *)&LAB_0055d5d0;
      pppppuStack_15c = (undefined4 *****)&DAT_01ea8ad8;
      uStack_160 = 0x689119;
      FUN_005789c0();
      puStack_158 = (undefined4 *)0x689121;
      puStack_158 = (undefined4 *)FUN_00560f40();
      pppppuStack_15c = (undefined4 ******)0x689129;
      pppppuStack_20 = (undefined4 *****)FUN_008aa140();
      if (*pppppuStack_20 == (undefined4 ****)0x0) {
        puStack_158 = (undefined4 *)0x68913a;
        puStack_158 = (undefined4 *)FUN_008aa950();
        pppppuStack_15c = &pppppuStack_28;
        uStack_160 = 0x689146;
        piVar10 = (int *)FUN_008a9ba0();
        iVar9 = *piVar10;
        iVar8 = piVar10[1];
        *piVar10 = 0;
        piVar10[1] = 0;
        *pppppuStack_20 = (undefined4 ****)iVar9;
        ppppuStack_18 = pppppuStack_20[1];
        pppppuStack_20[1] = (undefined4 ****)iVar8;
        if (ppppuStack_18 != (undefined4 ****)0x0) {
          LOCK();
          pppuVar14 = (undefined4 ***)((int)ppppuStack_18[1] + -1);
          ppppuStack_18[1] = pppuVar14;
          UNLOCK();
          if (pppuVar14 == (undefined4 ***)0x0) {
            puStack_158 = (undefined4 *)0x68917a;
            (*(code *)**ppppuStack_18)();
            LOCK();
            pppuVar14 = (undefined4 ***)((int)ppppuStack_18[2] + -1);
            ppppuStack_18[2] = pppuVar14;
            UNLOCK();
            if (pppuVar14 == (undefined4 ***)0x0) {
              puStack_158 = (undefined4 *)0x68918b;
              (*(code *)(*ppppuStack_18)[1])();
            }
          }
        }
        ppppuStack_18 = ppppuStack_24;
        if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
          LOCK();
          ppppuVar3 = (undefined4 ****)((int)ppppuStack_24[1] + -1);
          ppppuStack_24[1] = ppppuVar3;
          UNLOCK();
          if (ppppuVar3 == (undefined4 ****)0x0) {
            puStack_158 = (undefined4 *)0x6891a2;
            (*(code *)**ppppuStack_24)();
            LOCK();
            ppppuVar3 = (undefined4 ****)((int)ppppuStack_18[2] + -1);
            ppppuStack_18[2] = ppppuVar3;
            UNLOCK();
            if (ppppuVar3 == (undefined4 ****)0x0) {
              puStack_158 = (undefined4 *)0x6891b3;
              (*(code *)(*ppppuStack_18)[1])();
            }
          }
        }
      }
    }
  }
  puStack_158 = (undefined4 *)0x6891cb;
  FUN_008b01d0();
  auStack_ac[0] = 0xffffffff;
  puStack_158 = (undefined4 *)0x6891e0;
  FUN_005f7140();
  uStack_88 = 0;
  pppuStack_84 = (undefined4 ****)0x0;
  puStack_158 = param_2;
  _uStack_8 = CONCAT31(uStack_7,3);
  pppppuStack_15c = (undefined4 *****)0x689203;
  FUN_005f7170();
  pppuVar14 = *(undefined4 ****)(param_1 + 0xcc);
  if (pppuVar14 != (undefined4 ***)0x0) {
    LOCK();
    ((int *)pppuVar14)[1] = ((int *)pppuVar14)[1] + 1;
    UNLOCK();
    pppuVar14 = *(undefined4 ****)(param_1 + 0xcc);
  }
  uStack_88 = *(undefined4 *)(param_1 + 200);
  ppppuStack_18 = (undefined4 ****)pppuStack_84;
  if ((undefined4 ****)pppuStack_84 != (undefined4 ****)0x0) {
    LOCK();
    pppuVar4 = (undefined4 ***)((int)pppuStack_84[1] + -1);
    pppuStack_84[1] = pppuVar4;
    UNLOCK();
    if (pppuVar4 == (undefined4 ***)0x0) {
      pppuVar4 = (undefined4 ***)*pppuStack_84;
      puStack_158 = (undefined4 *)0x68923d;
      pppuStack_84 = pppuVar14;
      (*(code *)*pppuVar4)();
      LOCK();
      pppuVar4 = (undefined4 ***)((int)ppppuStack_18[2] + -1);
      ppppuStack_18[2] = pppuVar4;
      UNLOCK();
      pppuVar14 = pppuStack_84;
      if (pppuVar4 == (undefined4 ***)0x0) {
        puStack_158 = (undefined4 *)0x68924e;
        (*(code *)(*ppppuStack_18)[1])();
        pppuVar14 = pppuStack_84;
      }
    }
  }
  pppuStack_84 = pppuVar14;
  auStack_ac[0] = 1;
  puStack_158 = (undefined4 *)0x689263;
  piVar10 = (int *)FUN_0054db20();
  uStack_174 = *param_2;
  uStack_170 = param_2[1];
  uStack_16c = param_2[2];
  uStack_168 = param_2[3];
  uStack_164 = param_2[4];
  uStack_160 = param_2[5];
  pppppuStack_15c = (undefined4 *****)param_2[6];
  puStack_158 = (undefined4 *)param_2[7];
  uStack_178 = 0x689285;
  uStack_7c = (**(code **)(*piVar10 + 0x150))();
  iVar9 = iStack_34;
  ppppuStack_18 = (undefined4 ****)(iStack_34 + 0x1b8);
  uStack_178 = 0x6892a2;
  piVar10 = (int *)FUN_0054db20();
  uStack_194 = *(undefined4 *)(iVar9 + 0x110);
  uStack_190 = *(undefined4 *)(iVar9 + 0x114);
  uStack_18c = *(undefined4 *)(iVar9 + 0x118);
  uStack_188 = *(undefined4 *)(iVar9 + 0x11c);
  uStack_184 = *(undefined4 *)(iVar9 + 0x120);
  uStack_180 = *(undefined4 *)(iVar9 + 0x124);
  uStack_17c = *(undefined4 *)(iVar9 + 0x128);
  uStack_178 = *(undefined4 *)(iVar9 + 300);
  puStack_198 = auStack_70;
  ppppuStack_19c = (undefined4 ****)0x6892cc;
  uStack_1a4 = (**(code **)(*piVar10 + 0xb4))();
  ppppuStack_19c = &ppppuStack_18;
  iStack_1a0 = iVar9 + 0x150;
  puStack_1a8 = auStack_ac;
  pppppuStack_1ac = &pppppuStack_28;
  uStack_1b0 = 0x6892e8;
  piVar10 = (int *)FUN_00687d80();
  pppuStack_4c = (undefined4 ***)piVar10[1];
  pppppuStack_50 = (undefined4 *****)*piVar10;
  *piVar10 = 0;
  piVar10[1] = 0;
  pppppuStack_1c = (undefined4 *****)ppppuStack_24;
  pppppuStack_30 = pppppuStack_50;
  ppppuStack_18 = (undefined4 ****)pppuStack_4c;
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    LOCK();
    ppppuVar3 = (undefined4 ****)((int)ppppuStack_24[1] + -1);
    ppppuStack_24[1] = ppppuVar3;
    UNLOCK();
    if (ppppuVar3 == (undefined4 ****)0x0) {
      ppppuStack_19c = (undefined4 ****)0x689320;
      (*(code *)**ppppuStack_24)();
      LOCK();
      ppppuVar3 = (undefined4 ****)((int)pppppuStack_1c[2] + -1);
      pppppuStack_1c[2] = ppppuVar3;
      UNLOCK();
      if (ppppuVar3 == (undefined4 ****)0x0) {
        ppppuStack_19c = (undefined4 ****)0x689331;
        (*(code *)(*pppppuStack_1c)[1])();
      }
    }
  }
  ppppuStack_19c = (undefined4 ****)0x68933c;
  piVar10 = (int *)FUN_0054db20();
  uStack_1b8 = *param_2;
  uStack_1b4 = param_2[1];
  uStack_1b0 = param_2[2];
  pppppuStack_1ac = (undefined4 *****)param_2[3];
  puStack_1a8 = (undefined4 *)param_2[4];
  uStack_1a4 = param_2[5];
  iStack_1a0 = param_2[6];
  ppppuStack_19c = (undefined4 ****)param_2[7];
  pppppuStack_1bc = &pppppuStack_28;
  pppppuStack_1c0 = (undefined4 *****)0x689362;
  (**(code **)(*piVar10 + 0x158))();
  iVar9 = iStack_34;
  uStack_8 = 4;
  if ((undefined4 ******)pppppuStack_28 != (undefined4 ******)0x0) {
    if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
      LOCK();
      ppppuStack_24[1] = (undefined4 ****)((int)ppppuStack_24[1] + 1);
      UNLOCK();
    }
    ppppppuStack_1c4 = (undefined4 ******)pppppuStack_28;
    pppppuStack_1c0 = (undefined4 *****)ppppuStack_24;
    puStack_1c8 = (undefined *)0x68939f;
    FUN_006307a0();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  pppppuStack_1c = (undefined4 *****)ppppuStack_24;
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    LOCK();
    ppppuVar3 = (undefined4 ****)((int)ppppuStack_24[1] + -1);
    ppppuStack_24[1] = ppppuVar3;
    UNLOCK();
    if (ppppuVar3 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x6893ba;
      (*(code *)**ppppuStack_24)();
      LOCK();
      ppppuVar3 = (undefined4 ****)((int)pppppuStack_1c[2] + -1);
      pppppuStack_1c[2] = ppppuVar3;
      UNLOCK();
      if (ppppuVar3 == (undefined4 ****)0x0) {
        pppppuStack_1c0 = (undefined4 *****)0x6893cb;
        (*(code *)(*pppppuStack_1c)[1])();
      }
    }
  }
  pppppuVar2 = *(undefined4 ******)(iVar9 + 0x130);
  pppppuStack_1c0 = (undefined4 *****)iVar9;
  pppppuStack_30[0xebb] = *(undefined4 ******)(iVar9 + 0x134);
  pppppuStack_30[0xeba] = pppppuVar2;
  ppppppuStack_1c4 = (undefined4 ******)0x6893ee;
  FUN_008a5700();
  pppppuStack_1c0 = (undefined4 *****)iVar9;
  ppppppuStack_1c4 = (undefined4 ******)0x6893f4;
  pppppuStack_1c0 = (undefined4 *****)FUN_008f7870();
  ppppppuStack_1c4 = &pppppuStack_28;
  puStack_1c8 = (undefined *)0x689401;
  FUN_005e5de0();
  ppppuVar3 = ppppuStack_24;
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    LOCK();
    ppppuStack_24[2] = (undefined4 ****)((int)ppppuStack_24[2] + 1);
    UNLOCK();
  }
  pppppuStack_1c = pppppuStack_28;
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    pppppuVar2 = (undefined4 *****)(ppppuStack_24 + 2);
    LOCK();
    *pppppuVar2 = (undefined4 ****)((int)*pppppuVar2 + 1);
    UNLOCK();
    LOCK();
    *pppppuVar2 = (undefined4 ****)((int)*pppppuVar2 + 1);
    UNLOCK();
    LOCK();
    *pppppuVar2 = (undefined4 ****)((int)*pppppuVar2 + 1);
    UNLOCK();
    LOCK();
    ppppuVar1 = *pppppuVar2;
    *pppppuVar2 = (undefined4 ****)((int)ppppuVar1 + -1);
    UNLOCK();
    if ((undefined4 ****)((int)ppppuVar1 + -1) == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x689437;
      (*(code *)(*ppppuStack_24)[1])();
    }
    LOCK();
    ppppuVar1 = (undefined4 ****)((int)ppppuVar3[2] + -1);
    ppppuVar3[2] = ppppuVar1;
    UNLOCK();
    if (ppppuVar1 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x689449;
      (*(code *)(*ppppuVar3)[1])();
    }
  }
  pcStack_5c = FUN_0068c680;
  if ((undefined4 *****)ppppuVar3 != (undefined4 *****)0x0) {
    pppppuVar2 = (undefined4 *****)(ppppuVar3 + 2);
    LOCK();
    *pppppuVar2 = (undefined4 ****)((int)*pppppuVar2 + 1);
    UNLOCK();
    LOCK();
    ppppuVar1 = *pppppuVar2;
    *pppppuVar2 = (undefined4 ****)((int)ppppuVar1 + -1);
    UNLOCK();
    if ((undefined4 ****)((int)ppppuVar1 + -1) == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x689469;
      (*(code *)(*ppppuVar3)[1])();
    }
    LOCK();
    ppppuVar1 = (undefined4 ****)((int)ppppuVar3[2] + -1);
    ppppuVar3[2] = ppppuVar1;
    UNLOCK();
    if (ppppuVar1 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x68947b;
      (*(code *)(*ppppuVar3)[1])();
    }
  }
  pcStack_48 = FUN_0068c680;
  pppppuStack_44 = pppppuStack_1c;
  ppppuStack_40 = ppppuVar3;
  uStack_58 = 0;
  uStack_54 = 0;
  pppppuStack_1c0 = (undefined4 *****)&pcStack_48;
  uStack_8 = 7;
  ppppppuStack_1c4 = (undefined4 ******)0x6894a6;
  pppppuStack_20 = (undefined4 *****)FUN_005ef280();
  if ((undefined4 ******)pppppuStack_20 != (undefined4 ******)0x0) {
    LOCK();
    ((undefined4 ******)pppppuStack_20)[1] =
         (undefined4 *****)((int)((undefined4 ******)pppppuStack_20)[1] + 1);
    UNLOCK();
  }
  uStack_8 = 9;
  if ((undefined4 *****)ppppuStack_40 != (undefined4 *****)0x0) {
    LOCK();
    ppppuVar3 = (undefined4 ****)((int)ppppuStack_40[2] + -1);
    ppppuStack_40[2] = ppppuVar3;
    UNLOCK();
    if (ppppuVar3 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x6894cd;
      (*(code *)(*ppppuStack_40)[1])();
    }
  }
  pppppuStack_1c0 = (undefined4 *****)0x6894d5;
  cVar7 = FUN_0168a8f0();
  if (cVar7 == '\0') {
    pppppuStack_1c0 = (undefined4 *****)0x6897ce;
    pppppuStack_1c0 = (undefined4 *****)FUN_005503c0();
    _uStack_8 = CONCAT31(uStack_7,10);
                    /* WARNING: Subroutine does not return */
    ppppppuStack_1c4 = (undefined4 ******)0x6897d8;
    FUN_0054e630();
  }
  _uStack_8 = CONCAT31(uStack_7,0xc);
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    LOCK();
    ppppuStack_24[2] = (undefined4 ****)((int)ppppuStack_24[2] + 1);
    UNLOCK();
  }
  ppppppuStack_1c4 = (undefined4 ******)pppppuStack_28;
  pppppuStack_1c0 = (undefined4 *****)ppppuStack_24;
  puStack_1c8 = (undefined *)0x68950e;
  FUN_005f3a10();
  pppppuStack_1c0 = &pppppuStack_44;
  ppppppuStack_1c4 = (undefined4 ******)0x68951d;
  puVar11 = (uint *)FUN_00587490();
  ppppuVar3 = ppppuStack_40;
  pppppuStack_1c = (undefined4 *****)*puVar11;
  if ((undefined4 *****)ppppuStack_40 != (undefined4 *****)0x0) {
    LOCK();
    ppppuVar1 = (undefined4 ****)((int)ppppuStack_40[1] + -1);
    ppppuStack_40[1] = ppppuVar1;
    UNLOCK();
    if (ppppuVar1 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x689538;
      (*(code *)**ppppuStack_40)();
      LOCK();
      pppppuVar2 = (undefined4 *****)(ppppuVar3 + 2);
      ppppuVar1 = (undefined4 ****)((int)*pppppuVar2 + -1);
      *pppppuVar2 = ppppuVar1;
      UNLOCK();
      if (ppppuVar1 == (undefined4 ****)0x0) {
        pppppuStack_1c0 = (undefined4 *****)0x689548;
        (*(code *)(*ppppuVar3)[1])();
      }
    }
  }
  if (pppppuStack_1c == (undefined4 *****)0x0) {
    pppppuStack_1c0 = (undefined4 *****)iStack_34;
    ppppppuStack_1c4 = (undefined4 ******)0x689556;
    iStack_38 = FUN_008f7870();
    pppppuStack_1c = (undefined4 *****)0x8000;
    pppppuVar2 = (undefined4 *****)(iStack_38 + 0x1e0);
    ppppppuStack_1c4 = (undefined4 ******)0x689572;
    pppppuStack_1c0 = pppppuVar2;
    ppppuStack_40 = pppppuVar2;
    pppppuStack_1c0 = (undefined4 *****)FUN_016dee6d();
    if (pppppuStack_1c0 != (undefined4 *****)0x0) {
      ppppppuStack_1c4 = (undefined4 ******)0x68957f;
      FUN_016df3c9();
    }
    ppppppuStack_1c4 = &pppppuStack_1c;
    puStack_1c8 = auStack_3c;
    uStack_8 = 0xd;
    uStack_1cc = 0x68959d;
    pppppuStack_1c0 = ppppppuStack_1c4;
    FUN_00687eb0();
    DAT_01ee04b4 = DAT_01ee04b4 | (uint)pppppuStack_1c;
    _uStack_8 = CONCAT31(uStack_7,0xe);
    ppppppuStack_1c4 = (undefined4 ******)0x6895b0;
    pppppuStack_1c0 = pppppuVar2;
    pppppuStack_1c0 = (undefined4 *****)FUN_016deec8();
    if (pppppuStack_1c0 != (undefined4 *****)0x0) {
      ppppppuStack_1c4 = (undefined4 ******)0x6895bd;
      FUN_016df3c9();
    }
  }
  _uStack_8 = CONCAT31(uStack_7,0xf);
  pppppuStack_1c0 = (undefined4 *****)0x6895cc;
  FUN_016899e0();
  pppppuVar2 = pppppuStack_20;
  if ((undefined4 ******)pppppuStack_20 != (undefined4 ******)0x0) {
    LOCK();
    pppppuVar5 = (undefined4 *****)((int)pppppuStack_20[1] + -1);
    pppppuStack_20[1] = pppppuVar5;
    UNLOCK();
    if (pppppuVar5 == (undefined4 *****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x0;
      ppppppuStack_1c4 = (undefined4 ******)0x6895e4;
      (*(code *)**pppppuStack_20)();
      ppppppuStack_1c4 = (undefined4 ******)pppppuVar2;
      puStack_1c8 = (undefined *)0x0;
      uStack_1cc = 0x6895ed;
      uStack_1cc = GetProcessHeap();
      uStack_1d0 = 0x6895f4;
      HeapFree();
    }
  }
  uStack_8 = 3;
  if ((undefined4 *****)ppppuStack_24 != (undefined4 *****)0x0) {
    LOCK();
    ppppuVar3 = (undefined4 ****)((int)ppppuStack_24[2] + -1);
    ppppuStack_24[2] = ppppuVar3;
    UNLOCK();
    if (ppppuVar3 == (undefined4 ****)0x0) {
      pppppuStack_1c0 = (undefined4 *****)0x68960d;
      (*(code *)(*ppppuStack_24)[1])();
    }
  }
  pppppuStack_1c0 = (undefined4 *****)iStack_34;
  ppppppuStack_1c4 = (undefined4 ******)0x689616;
  iStack_38 = FUN_008f7870();
  uStack_58 = 0;
  uStack_54 = 0xf;
  appppppuStack_68[0] = (undefined4 ******)((uint)appppppuStack_68[0] & 0xffffff00);
  pppppuStack_1c0 = (undefined4 *****)0x13;
  ppppppuStack_1c4 = (undefined4 ******)0x18d77c8;
  puStack_1c8 = (undefined *)0x68963d;
  FUN_005542c0();
  uStack_8 = 0x10;
  if ((undefined4 *******)(iStack_38 + 0x4ac) != appppppuStack_68) {
    pppppuStack_1c0 = (undefined4 *****)uStack_58;
    ppppppuStack_1c4 = appppppuStack_68;
    if (0xf < uStack_54) {
      ppppppuStack_1c4 = appppppuStack_68[0];
    }
    puStack_1c8 = (undefined *)0x689662;
    FUN_005542c0();
  }
  uStack_8 = 3;
  uVar6 = uStack_8;
  uStack_8 = 3;
  if (0xf < uStack_54) {
    pppppuStack_1c0 = (undefined4 *****)(uStack_54 + 1);
    pppppppuVar12 = (undefined4 *******)appppppuStack_68[0];
    if (0xfff < pppppuStack_1c0) {
      pppppppuVar12 = (undefined4 *******)appppppuStack_68[0][-1];
      pppppuStack_1c0 = (undefined4 *****)(uStack_54 + 0x24);
      if (0x1f < (uint)((int)appppppuStack_68[0] + (-4 - (int)pppppppuVar12))) {
                    /* WARNING: Subroutine does not return */
        pppppuStack_1c0 = (undefined4 *****)0x6897dd;
        uStack_8 = uVar6;
        FUN_017167a3();
      }
    }
    puStack_1c8 = (undefined *)0x689697;
    ppppppuStack_1c4 = pppppppuVar12;
    FUN_01674ea0();
  }
  ppppuStack_40 = &ppppppuStack_1c4;
  if (ppppuStack_18 != (undefined4 ****)0x0) {
    LOCK();
    ppppuStack_18[1] = (undefined4 ***)((int)ppppuStack_18[1] + 1);
    UNLOCK();
  }
  ppppppuStack_1c4 = (undefined4 ******)pppppuStack_30;
  pppppuStack_1c0 = (undefined4 *****)ppppuStack_18;
  uStack_8 = 0x11;
  FUN_006b1620(auStack_1dc,param_2,1,0x7c);
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_00688d70();
  pppuVar14 = pppuStack_84;
  if (pppuStack_84 != (undefined4 ***)0x0) {
    LOCK();
    iVar9 = (int)pppuStack_84[1] + -1;
    pppuStack_84[1] = (undefined4 **)iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      pppppuStack_1c0 = (undefined4 *****)0x689700;
      (*(code *)**pppuStack_84)();
      LOCK();
      piVar10 = (int *)(pppuVar14 + 2);
      iVar9 = *piVar10 + -1;
      *piVar10 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        pppppuStack_1c0 = (undefined4 *****)0x689710;
        (**(code **)((int)*pppuVar14 + 4))();
      }
    }
  }
  if ((undefined4 ******)pppppuStack_c8 != (undefined4 ******)0x0) {
    pppppuStack_1c0 = (undefined4 *****)(iStack_c0 - (int)pppppuStack_c8);
    ppppppuVar13 = (undefined4 ******)pppppuStack_c8;
    if ((undefined4 ****)0xfff < pppppuStack_1c0) {
      ppppppuVar13 = (undefined4 ******)pppppuStack_c8[-1];
      pppppuStack_1c0 = (undefined4 *****)((int)pppppuStack_1c0 + 0x23);
      if (0x1f < (uint)((int)pppppuStack_c8 + (-4 - (int)ppppppuVar13))) {
                    /* WARNING: Subroutine does not return */
        pppppuStack_1c0 = (undefined4 *****)&UNK_006897e2;
        FUN_017167a3();
      }
    }
    puStack_1c8 = (undefined *)0x689747;
    ppppppuStack_1c4 = ppppppuVar13;
    FUN_01674ea0();
  }
  FUN_0068978e();
  return;
}



/* FUNCTION 8224 ; VA 0x0068974f ; Catch@0068974f */

undefined * Catch_0068974f(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x70) + 4))();
  FUN_0086f2f0(3,"Error in ID_CONNECTION_REQUEST_ACCEPTED: %s",uVar1);
  if (*(int *)(unaff_EBP + -0x4c) != 0) {
    *(undefined *)(*(int *)(unaff_EBP + -0x4c) + 0x22) = 0;
    FUN_008a65e0(0,0);
  }
  return &DAT_00689788;
}



/* FUNCTION 8225 ; VA 0x0068978e ; FUN_0068978e */

void FUN_0068978e(void)

{
  int *piVar1;
  int iVar2;
  int unaff_EBP;
  int *unaff_ESI;
  int unaff_EDI;
  
  if (unaff_ESI != (int *)0x0) {
    LOCK();
    iVar2 = unaff_ESI[1] + unaff_EDI;
    unaff_ESI[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*unaff_ESI)();
      LOCK();
      piVar1 = unaff_ESI + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + unaff_EDI;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*unaff_ESI + 4))();
      }
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 8226 ; VA 0x006897f0 ; FUN_006897f0 */

void FUN_006897f0(void)

{
  undefined auStack_408 [1028];
  
  if (DAT_01d5b038 != '\0') {
    FUN_005f7b20(1,auStack_408,0x401,0x7c);
    FUN_0068ee80(auStack_408,4,&DAT_018bc9b8);
  }
  return;
}



/* FUNCTION 8227 ; VA 0x00689840 ; FUN_00689840 */

void __thiscall FUN_00689840(int param_1,undefined *param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  char *pcVar3;
  undefined uVar4;
  undefined auStack_4a0 [12];
  undefined4 uStack_494;
  char *pcStack_490;
  undefined4 uStack_48c;
  undefined auStack_488 [16];
  undefined4 uStack_478;
  undefined *puStack_474;
  undefined auStack_470 [4];
  undefined4 uStack_46c;
  char *pcStack_468;
  undefined *puStack_464;
  undefined **ppuStack_460;
  char **ppcStack_45c;
  undefined auStack_450 [1032];
  undefined *puStack_48;
  undefined auStack_44 [4];
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  char *apcStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a56c8;
  pvStack_10 = ExceptionList;
  puStack_464 = auStack_450;
  ppcStack_45c = (char **)0x7c;
  ppuStack_460 = (undefined **)0x401;
  pcStack_468 = (char *)0x1;
  uStack_46c = 0x68987a;
  ExceptionList = &pvStack_10;
  FUN_005f7b20();
  if (DAT_01d5b038 == '\0') {
    ppcStack_45c = (char **)0x1;
    ppuStack_460 = (undefined **)0x18d7664;
    puStack_464 = (undefined *)0x689894;
    FUN_0068cab0();
  }
  if (DAT_01d5ba64 != '\0') {
    ppcStack_45c = &param_2;
    auStack_44[0] = 0;
    ppuStack_460 = &boost::lock_error::vftable_meta_ptr;
    puStack_464 = &DAT_018be100;
    param_2 = (undefined *)0xb;
    pcStack_468 = (char *)0x6898c4;
    ppuVar1 = (undefined **)FUN_00563d40();
    ppuVar2 = ppuVar1 + -1;
    if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar2 = ppuVar1;
    }
    puStack_40 = *ppuVar2;
    uStack_3c = 0;
    uStack_38 = 0x3f800000;
    uStack_34 = 0;
    uStack_30 = 0;
    ppcStack_45c = (char **)0x15;
    ppuStack_460 = (undefined **)0x18d767c;
    iStack_8 = 0;
    uStack_1c = 0;
    uStack_18 = 0xf;
    apcStack_2c[0] = (char *)((uint)apcStack_2c[0] & 0xffffff00);
    puStack_464 = (undefined *)0x68991b;
    FUN_005542c0();
    ppcStack_45c = apcStack_2c;
    iStack_8._0_1_ = 1;
    ppuStack_460 = (undefined **)0x68992b;
    FUN_005d15d0();
    ppcStack_45c = (char **)0xe;
    ppuStack_460 = (undefined **)0x18d7694;
    puStack_464 = (undefined *)0x68993a;
    FUN_005542c0();
    iStack_8._0_1_ = 0;
    uVar4 = (undefined)iStack_8;
    iStack_8._0_1_ = 0;
    if (0xf < uStack_18) {
      ppcStack_45c = (char **)(uStack_18 + 1);
      pcVar3 = apcStack_2c[0];
      if (0xfff < ppcStack_45c) {
        pcVar3 = *(char **)(apcStack_2c[0] + -4);
        ppcStack_45c = (char **)(uStack_18 + 0x24);
        if ((char *)0x1f < apcStack_2c[0] + (-4 - (int)pcVar3)) {
                    /* WARNING: Subroutine does not return */
          ppcStack_45c = (char **)&UNK_00689b39;
          iStack_8._0_1_ = uVar4;
          FUN_017167a3();
        }
      }
      puStack_464 = (undefined *)0x68996f;
      ppuStack_460 = (undefined **)pcVar3;
      FUN_01674ea0();
    }
    param_2 = auStack_470;
    puStack_14 = auStack_470;
    uStack_1c = 0;
    puStack_474 = auStack_44;
    uStack_18 = 0xf;
    apcStack_2c[0] = (char *)((uint)apcStack_2c[0] & 0xffffff00);
    uStack_478 = 0x689998;
    FUN_0060e660();
    puStack_14 = auStack_488;
    iStack_8._0_1_ = 2;
    uStack_48c = 0xf;
    uStack_478 = 0;
    puStack_474 = (undefined *)0xf;
    pcStack_490 = "GameJoinFailure";
    auStack_488[0] = 0;
    uStack_494 = 0x6899c1;
    FUN_005542c0();
    puStack_48 = auStack_4a0;
    iStack_8._0_1_ = 3;
    pcStack_490 = (char *)0x0;
    uStack_48c = 0xf;
    auStack_4a0[0] = 0;
    FUN_005542c0("report",6);
    iStack_8._0_1_ = 4;
    uVar4 = 0;
    FUN_005542c0("client",6);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_0087a540(uVar4);
    iStack_8 = 0xffffffff;
    ppcStack_45c = (char **)0x689a2b;
    FUN_0056cfd0();
  }
  if (*(char *)(param_1 + 0x108) == '\0') {
    if (*(char *)(param_1 + 0x109) != '\0') {
      if (DAT_01d5b038 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      ppcStack_45c = (char **)0x3;
      ppuStack_460 = (undefined **)auStack_450;
      puStack_464 = (undefined *)0x1;
      pcStack_468 = "ConnectFailed_Timeout_SecondReplyOnly";
      uStack_46c = 0x689a9a;
      FUN_0068b590();
      ExceptionList = pvStack_10;
      return;
    }
    if (DAT_01d5b038 != '\0') {
      ppcStack_45c = (char **)0x3;
      ppuStack_460 = (undefined **)auStack_450;
      puStack_464 = (undefined *)0x1;
      pcStack_468 = "ConnectFailed_Timeout_NoReplies";
      uStack_46c = 0x689a5d;
      FUN_0068b590();
      ExceptionList = pvStack_10;
      return;
    }
    ppuStack_460 = (undefined **)0x18d76b4;
  }
  else if (*(char *)(param_1 + 0x109) == '\0') {
    if (DAT_01d5b038 != '\0') {
      ppcStack_45c = (char **)0x3;
      ppuStack_460 = (undefined **)auStack_450;
      puStack_464 = (undefined *)0x1;
      pcStack_468 = "ConnectFailed_Timeout_FirstReplyOnly";
      uStack_46c = 0x689ad0;
      FUN_0068b590();
      ExceptionList = pvStack_10;
      return;
    }
    ppuStack_460 = (undefined **)0x18d76d4;
  }
  else {
    if (DAT_01d5b038 != '\0') {
      ppcStack_45c = (char **)0x3;
      ppuStack_460 = (undefined **)auStack_450;
      puStack_464 = (undefined *)0x1;
      pcStack_468 = "ConnectFailed_Timeout_FirstAndSecondReplied";
      uStack_46c = 0x689b04;
      FUN_0068b590();
      ExceptionList = pvStack_10;
      return;
    }
    ppuStack_460 = (undefined **)0x18d76fc;
  }
  ppcStack_45c = (char **)0x1;
  puStack_464 = (undefined *)0x689b22;
  FUN_0068cab0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8228 ; VA 0x00689b40 ; FUN_00689b40 */

void FUN_00689b40(int param_1,undefined4 param_2)

{
  byte bVar1;
  undefined uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  undefined auStack_484 [20];
  undefined4 uStack_470;
  undefined4 ***pppuStack_46c;
  undefined4 uStack_464;
  undefined4 **ppuStack_460;
  char *pcStack_45c;
  undefined4 ***pppuStack_458;
  undefined4 ***pppuStack_454;
  char acStack_444 [1028];
  undefined4 *apuStack_40 [5];
  uint uStack_2c;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5708;
  pvStack_10 = ExceptionList;
  pppuStack_454 = (undefined4 ***)(uint)**(byte **)(param_1 + 0x38);
  pppuStack_458 = apppuStack_28;
  pcStack_45c = (char *)0x689b76;
  ExceptionList = &pvStack_10;
  FUN_0068c740();
  iStack_8 = 0;
  pppuStack_454 = (undefined4 ***)0x7c;
  if (DAT_01d5b038 == '\0') {
    ppuStack_460 = apuStack_40;
    pppuStack_458 = (undefined4 ***)0x1;
    pcStack_45c = (char *)param_1;
    ppppuVar5 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_464 = 0x689ca3;
    pppuStack_458 = (undefined4 ***)FUN_006b1620();
    iStack_8._0_1_ = 3;
    if (0xf < pppuStack_458[5]) {
      pppuStack_458 = (undefined4 ***)*pppuStack_458;
    }
    pcStack_45c = "Failed to connect to %s. %s\n";
    ppuStack_460 = (undefined4 **)0x4;
    uStack_464 = 0x689cc0;
    pppuStack_454 = ppppuVar5;
    FUN_0086f2f0();
    iStack_8._0_1_ = 0;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 0;
    if (0xf < uStack_2c) {
      pppuStack_454 = (undefined4 ***)(uStack_2c + 1);
      puVar4 = apuStack_40[0];
      if ((undefined4 ****)0xfff < pppuStack_454) {
        puVar4 = (undefined4 *)apuStack_40[0][-1];
        pppuStack_454 = (undefined4 ***)(uStack_2c + 0x24);
        if (0x1f < (uint)((int)apuStack_40[0] + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_454 = (undefined4 ***)0x689d81;
          iStack_8._0_1_ = uVar2;
          FUN_017167a3();
        }
      }
      pcStack_45c = (char *)0x689cf8;
      pppuStack_458 = (undefined4 ***)puVar4;
      FUN_01674ea0();
    }
    bVar1 = **(byte **)(param_1 + 0x38);
    pppuStack_46c = apppuStack_28;
    uStack_470 = 0x689d12;
    FUN_0054ef60();
    iStack_8._0_1_ = 4;
  }
  else {
    pppuStack_458 = (undefined4 ***)0x401;
    pcStack_45c = acStack_444;
    ppuStack_460 = (undefined4 **)0x1;
    uStack_464 = 0x689ba4;
    FUN_005f7b20();
    switch(param_2) {
    case 0:
      pppuStack_454 = (undefined4 ***)0x18d74f8;
      break;
    case 1:
      pppuStack_454 = (undefined4 ***)0x18d7518;
      break;
    case 2:
      pppuStack_454 = (undefined4 ***)0x18d7530;
      break;
    case 3:
      pppuStack_454 = (undefined4 ***)0x18d7550;
      break;
    case 4:
      pppuStack_454 = (undefined4 ***)0x18d7570;
      break;
    case 5:
      pppuStack_454 = (undefined4 ***)0x18d7588;
      break;
    case 6:
      pppuStack_454 = (undefined4 ***)0x18d75a0;
      break;
    case 7:
      pppuStack_454 = (undefined4 ***)0x18d75bc;
      break;
    case 8:
      pppuStack_454 = (undefined4 ***)0x18d75d8;
      break;
    case 9:
      pppuStack_454 = (undefined4 ***)0x18d75fc;
      break;
    case 10:
      pppuStack_454 = (undefined4 ***)0x18d761c;
      break;
    default:
      pppuStack_454 = (undefined4 ***)0x18d7634;
    }
    pppuStack_458 = (undefined4 ***)0x3;
    pcStack_45c = acStack_444;
    ppuStack_460 = (undefined4 **)0x689c17;
    FUN_0068ee80();
    pppuStack_454 = (undefined4 ***)0x689c1f;
    cVar3 = FUN_0068bd00();
    if (cVar3 == '\0') goto LAB_00689d39;
    ppuStack_460 = apuStack_40;
    pppuStack_454 = (undefined4 ***)0x7c;
    pppuStack_458 = (undefined4 ***)0x1;
    pcStack_45c = (char *)param_1;
    ppppuVar5 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_464 = 0x689c40;
    pppuStack_458 = (undefined4 ***)FUN_006b1620();
    iStack_8._0_1_ = 1;
    if (0xf < pppuStack_458[5]) {
      pppuStack_458 = (undefined4 ***)*pppuStack_458;
    }
    pcStack_45c = "Failed to connect to %s. %s\n";
    ppuStack_460 = (undefined4 **)0x4;
    uStack_464 = 0x689c5d;
    pppuStack_454 = ppppuVar5;
    FUN_0086f2f0();
    iStack_8._0_1_ = 0;
    pppuStack_454 = (undefined4 ****)0x689c6c;
    FUN_005507b0();
    bVar1 = **(byte **)(param_1 + 0x38);
    pppuStack_46c = apppuStack_28;
    uStack_470 = 0x689c83;
    FUN_0054ef60();
    iStack_8._0_1_ = 2;
  }
  pppuStack_46c = (undefined4 ***)(uint)bVar1;
  FUN_006b1620(auStack_484,param_1,1,0x7c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00688bd0();
LAB_00689d39:
  if (0xf < uStack_14) {
    pppuStack_454 = (undefined4 ***)(uStack_14 + 1);
    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < pppuStack_454) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0][-1];
      pppuStack_454 = (undefined4 ***)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_454 = (undefined4 ***)&UNK_00689d86;
        FUN_017167a3();
      }
    }
    pcStack_45c = (char *)0x689d66;
    pppuStack_458 = ppppuVar5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8229 ; VA 0x00689dc0 ; FUN_00689dc0 */

void FUN_00689dc0(void)

{
  undefined auStack_408 [1028];
  
  if (DAT_01d5b038 != '\0') {
    FUN_005f7b20(1,auStack_408,0x401,0x7c);
    FUN_0068b590("ConnectFailed_InternalRakNet",1,auStack_408,3);
    return;
  }
  FUN_0068cab0("ConnectFailed_InternalRakNet",1);
  return;
}



/* FUNCTION 8230 ; VA 0x00689e30 ; FUN_00689e30 */

void FUN_00689e30(void)

{
  undefined auStack_408 [1028];
  
  if (DAT_01d5b038 != '\0') {
    FUN_005f7b20(1,auStack_408,0x401,0x7c);
    FUN_0068ee80(auStack_408,2,&DAT_018bc9b8);
  }
  return;
}



/* FUNCTION 8231 ; VA 0x00689e80 ; FUN_00689e80 */

/* WARNING: Removing unreachable block (ram,0x00689fc1) */

undefined4 __thiscall FUN_00689e80(int param_1,int param_2)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  double *pdVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined uVar7;
  uint uStack_4b8;
  undefined *puStack_4b4;
  int iStack_4b0;
  undefined4 uStack_4ac;
  char *pcStack_4a8;
  undefined4 uStack_4a4;
  undefined auStack_4a0 [4];
  undefined4 uStack_49c;
  undefined4 uStack_498;
  undefined *puStack_494;
  undefined *puStack_490;
  undefined *puStack_48c;
  char acStack_488 [4];
  undefined4 uStack_484;
  char *pcStack_480;
  char *pcStack_47c;
  char *pcStack_478;
  undefined4 *puStack_474;
  char acStack_464 [1028];
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [24];
  undefined *puStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  char *pcStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5768;
  pvStack_10 = ExceptionList;
  puStack_474 = (undefined4 *)DAT_01eadc98;
  pcStack_478 = (char *)0x689eae;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290();
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  uStack_8 = 2;
  uStack_2c = uVar2;
  switch(**(char **)(param_2 + 0x38)) {
  case '\x10':
    if (DAT_01eadf38 != 0) {
      puStack_474 = (undefined4 *)0x0;
      pcStack_47c = (char *)(uint)DAT_01eadf38;
      pcStack_478 = "Client received ID_CONNECTION_REQUEST_ACCEPTED successfully";
      pcStack_480 = (char *)0x689f13;
      FUN_016774b0();
    }
    if (DAT_01d5b038 == '\0') {
      iStack_1c = param_1 + -0x54;
      puStack_474 = (undefined4 *)0x0;
      pcStack_478 = "RakNetPasswordAccepted";
      pcStack_47c = (char *)0x689f69;
      FUN_0068cab0();
    }
    else {
      puStack_474 = (undefined4 *)0x7c;
      pcStack_478 = (char *)0x401;
      pcStack_47c = acStack_464;
      pcStack_480 = (char *)0x1;
      uStack_484 = 0x689f36;
      FUN_005f7b20();
      puStack_474 = (undefined4 *)0x2;
      pcStack_478 = acStack_464;
      iStack_1c = param_1 + -0x54;
      pcStack_47c = (char *)0x0;
      pcStack_480 = "RakNetPasswordAccepted";
      uStack_484 = 0x689f53;
      FUN_0068b590();
    }
    *(undefined4 *)(param_1 + 0x128) = 2;
    if (DAT_01d5ba64 != '\0') {
      iVar3 = *(int *)(param_1 + 0xe0);
      if ((-1 < iVar3) && ((0 < iVar3 || (*(char **)(param_1 + 0xdc) != (char *)0x0)))) {
        puStack_474 = (undefined4 *)0x0;
        pcStack_478 = (char *)0x3e8;
        uStack_484 = 0x689fac;
        pcStack_480 = *(char **)(param_1 + 0xdc);
        pcStack_47c = (char *)iVar3;
        lVar6 = FUN_016f4270();
        pcStack_18 = (char *)lVar6;
        if (lVar6 < DAT_01eaf360) {
          pcStack_18 = acStack_488;
          puStack_48c = &uStack_11;
          puStack_490 = &uStack_11;
          puStack_494 = &uStack_11;
          uStack_498 = 0xb;
          uStack_49c = 0x689fe5;
          FUN_005d0b40();
          puStack_30 = auStack_4a0;
          uStack_8._0_1_ = 3;
          uStack_4a4 = 0x18;
          puStack_490 = (undefined *)0x0;
          puStack_48c = (undefined *)0xf;
          pcStack_4a8 = "GameServerConnectSuccess";
          auStack_4a0[0] = 0;
          uStack_4ac = 0x68a00e;
          FUN_005542c0();
          puStack_20 = (undefined *)&uStack_4b8;
          uStack_8._0_1_ = 4;
          pcStack_4a8 = (char *)0x0;
          uStack_4a4 = 0xf;
          uStack_4b8 = uStack_4b8 & 0xffffff00;
          FUN_005542c0("report",6);
          uStack_8._0_1_ = 5;
          uVar7 = 0;
          FUN_005542c0("client",6);
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_0087a540(uVar7);
        }
      }
    }
    pcStack_478 = (char *)0x68a06f;
    puStack_474 = (undefined4 *)(param_1 + -0x54);
    iVar3 = FUN_008f7870();
    pcStack_478 = auStack_28;
    pcStack_47c = (char *)0x68a07e;
    pdVar4 = (double *)FUN_016830f0();
    pcStack_47c = (char *)(param_1 - 0x54);
    pcStack_18 = (char *)(float)(*pdVar4 - *(double *)(iVar3 + 0x300));
    pcStack_480 = (char *)0x68a098;
    iVar3 = FUN_008f7870();
    *(char **)(iVar3 + 0x30c) = pcStack_18;
    if (DAT_01d84e8d != 0) {
      puStack_474 = (undefined4 *)0x7c;
      pcStack_478 = (char *)0x1;
      pcStack_480 = auStack_48;
      pcStack_47c = (char *)param_2;
      uStack_484 = 0x68a0c2;
      puStack_474 = (undefined4 *)FUN_006b1620();
      uStack_8._0_1_ = 6;
      if (0xf < (uint)puStack_474[5]) {
        puStack_474 = (undefined4 *)*puStack_474;
      }
      pcStack_47c = (char *)(uint)DAT_01d84e8d;
      pcStack_478 = "Connection accepted from %s";
      pcStack_480 = (char *)0x68a0e4;
      FUN_01677520();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puStack_474 = (undefined4 *)0x68a0f3;
      FUN_005507b0();
    }
    puStack_474 = (undefined4 *)param_2;
    pcStack_478 = (char *)0x68a0ff;
    FUN_005f7170();
    puStack_474 = (undefined4 *)0x68a107;
    FUN_0068eb20();
    puStack_474 = (undefined4 *)param_2;
    pcStack_478 = (char *)0x68a110;
    FUN_00688fc0();
    break;
  case '\x15':
  case '\x16':
    puStack_474 = (undefined4 *)&DAT_01eadf40;
    pcStack_478 = (char *)0x68a28c;
    FUN_005f7170();
    break;
  case '\x18':
    if (DAT_01d5b038 == '\0') {
      puStack_474 = (undefined4 *)0x1;
      pcStack_478 = "RakNetPasswordRejected";
      pcStack_47c = (char *)0x68a15e;
      FUN_0068cab0();
    }
    else {
      puStack_474 = (undefined4 *)0x7c;
      pcStack_478 = (char *)0x401;
      pcStack_47c = acStack_464;
      pcStack_480 = (char *)0x1;
      uStack_484 = 0x68a135;
      FUN_005f7b20();
      puStack_474 = (undefined4 *)0x3;
      pcStack_478 = acStack_464;
      pcStack_47c = (char *)0x1;
      pcStack_480 = "RakNetPasswordRejected";
      uStack_484 = 0x68a14d;
      FUN_0068b590();
    }
    puStack_474 = (undefined4 *)0x7c;
    pcStack_478 = (char *)0x1;
    pcStack_480 = auStack_48;
    pcStack_47c = (char *)param_2;
    uStack_484 = 0x68a16c;
    puStack_474 = (undefined4 *)FUN_006b1620();
    uStack_8._0_1_ = 8;
    if (0xf < (uint)puStack_474[5]) {
      puStack_474 = (undefined4 *)*puStack_474;
    }
    pcStack_478 = "Invalid password from %s";
    pcStack_47c = (char *)0x4;
    pcStack_480 = (char *)0x68a188;
    FUN_0086f2f0();
    uStack_8._0_1_ = 2;
    puStack_474 = (undefined4 *)0x68a197;
    FUN_005507b0();
    puStack_24 = acStack_488;
    puStack_490 = acStack_488;
    bVar1 = **(byte **)(param_2 + 0x38);
    puStack_494 = (undefined *)0x68a1ac;
    puStack_48c = (undefined *)(uint)bVar1;
    FUN_0068c740();
    puStack_4b4 = (undefined *)&uStack_4a4;
    uStack_8._0_1_ = 9;
    pcStack_4a8 = (char *)0x7c;
    uStack_4ac = 1;
    iStack_4b0 = param_2;
    uStack_4b8 = 0x68a1c7;
    puStack_48c = (undefined *)(uint)bVar1;
    FUN_006b1620();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    pcStack_4a8 = (char *)0x68a1d9;
    FUN_00688bd0();
    uVar5 = 0;
    goto LAB_0068a29c;
  case -0x6c:
  case -0x6b:
    pcStack_18 = "HashRejected";
    if (**(char **)(param_2 + 0x38) != -0x6c) {
      pcStack_18 = "SecurityKeyRejected";
    }
    if (DAT_01d5b038 == '\0') {
      puStack_474 = (undefined4 *)0x1;
      pcStack_47c = (char *)0x68a236;
      pcStack_478 = pcStack_18;
      FUN_0068cab0();
    }
    else {
      puStack_474 = (undefined4 *)0x7c;
      pcStack_478 = (char *)0x401;
      pcStack_47c = acStack_464;
      pcStack_480 = (char *)0x1;
      uStack_484 = 0x68a213;
      FUN_005f7b20();
      puStack_474 = (undefined4 *)0x3;
      pcStack_478 = acStack_464;
      pcStack_47c = (char *)0x1;
      pcStack_480 = pcStack_18;
      uStack_484 = 0x68a229;
      FUN_0068b590();
    }
    puStack_24 = acStack_488;
    puStack_490 = acStack_488;
    bVar1 = **(byte **)(param_2 + 0x38);
    puStack_494 = (undefined *)0x68a24b;
    puStack_48c = (undefined *)(uint)bVar1;
    FUN_0068c740();
    puStack_4b4 = (undefined *)&uStack_4a4;
    uStack_8._0_1_ = 0xb;
    pcStack_4a8 = (char *)0x7c;
    uStack_4ac = 1;
    iStack_4b0 = param_2;
    uStack_4b8 = 0x68a266;
    puStack_48c = (undefined *)(uint)bVar1;
    FUN_006b1620();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    pcStack_4a8 = (char *)0x68a278;
    FUN_00688bd0();
    uVar5 = 0;
    goto LAB_0068a29c;
  case -100:
    puStack_474 = (undefined4 *)param_2;
    pcStack_478 = (char *)0x68a297;
    FUN_0068b870();
  }
  uVar5 = 1;
LAB_0068a29c:
  uStack_8 = 0xf;
  pcStack_478 = (char *)0x68a2a9;
  puStack_474 = (undefined4 *)uVar2;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 8232 ; VA 0x0068a370 ; FUN_0068a370 */

void __fastcall FUN_0068a370(int param_1)

{
  *(undefined *)(param_1 + 0x108) = 1;
  return;
}



/* FUNCTION 8233 ; VA 0x0068a380 ; FUN_0068a380 */

void __fastcall FUN_0068a380(int param_1)

{
  *(undefined *)(param_1 + 0x109) = 1;
  return;
}



/* FUNCTION 8234 ; VA 0x0068a390 ; FUN_0068a390 */

void __fastcall FUN_0068a390(int param_1)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  undefined auStack_42c [1028];
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("LostReliableConnection",0x16);
  uStack_8 = 0;
  if (DAT_01d5b038 == '\0') {
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0068de80(ppppuVar2,1);
  }
  else {
    FUN_005f7b20(1,auStack_42c,0x401,0x7c);
    switch(*(undefined4 *)(param_1 + 0x128)) {
    case 0:
      pcVar4 = "_NotStartedYet";
      break;
    case 1:
      pcVar4 = "_BeforeConnected";
      break;
    case 2:
      pcVar4 = "_BeforeLoadFinished";
      break;
    case 3:
      pcVar4 = "_AfterLoadFinished";
      break;
    default:
      pcVar4 = "";
    }
    pcVar3 = pcVar4;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_00554150(pcVar4,(int)pcVar3 - (int)(pcVar4 + 1));
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0068b590(ppppuVar2,1,auStack_42c,3);
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8235 ; VA 0x0068a4e0 ; FUN_0068a4e0 */

void __fastcall FUN_0068a4e0(int param_1)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  undefined auStack_42c [1028];
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("RemoteActiveDisconnect",0x16);
  uStack_8 = 0;
  if (DAT_01d5b038 == '\0') {
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0068de80(ppppuVar2,1);
  }
  else {
    FUN_005f7b20(1,auStack_42c,0x401,0x7c);
    switch(*(undefined4 *)(param_1 + 0x128)) {
    case 0:
      pcVar4 = "_NotStartedYet";
      break;
    case 1:
      pcVar4 = "_BeforeConnected";
      break;
    case 2:
      pcVar4 = "_BeforeLoadFinished";
      break;
    case 3:
      pcVar4 = "_AfterLoadFinished";
      break;
    default:
      pcVar4 = "";
    }
    pcVar3 = pcVar4;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_00554150(pcVar4,(int)pcVar3 - (int)(pcVar4 + 1));
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0068b590(ppppuVar2,1,auStack_42c,3);
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8236 ; VA 0x0068a630 ; FUN_0068a630 */

void FUN_0068a630(void)

{
  undefined auStack_408 [1028];
  
  if (DAT_01d5b038 != '\0') {
    FUN_005f7b20(1,auStack_408,0x401,0x7c);
    FUN_0068b590("TimeoutRakNetPassword",1,auStack_408,3);
    return;
  }
  FUN_0068cab0("TimeoutRakNetPassword",1);
  return;
}



/* FUNCTION 8237 ; VA 0x0068a6a0 ; FUN_0068a6a0 */

void FUN_0068a6a0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x14);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 8238 ; VA 0x0068a6d0 ; FUN_0068a6d0 */

void __thiscall FUN_0068a6d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00687590(param_2,param_3,param_1);
  return;
}



/* FUNCTION 8239 ; VA 0x0068a6f0 ; FUN_0068a6f0 */

void FUN_0068a6f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  FUN_01674ea0(param_1,0x14);
  return;
}



/* FUNCTION 8240 ; VA 0x0068a760 ; FUN_0068a760 */

void __fastcall FUN_0068a760(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00687590(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xd8) * 0xd8;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 8241 ; VA 0x0068a7e0 ; FUN_0068a7e0 */

undefined FUN_0068a7e0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if ((iVar2 != 0) && (*(int *)(iVar2 + 0x4a0) == 1)) {
    iVar2 = FUN_0055e560();
    if (param_1 == *(int *)(iVar2 + 0xf4)) {
      uVar3 = 1;
      goto LAB_0068a833;
    }
  }
  uVar3 = 0;
LAB_0068a833:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 8242 ; VA 0x0068a870 ; FUN_0068a870 */

void __fastcall FUN_0068a870(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_1;
  piVar5 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar5 != (int *)*param_1) {
    do {
      iVar2 = piVar5[2];
      piVar1 = (int *)*piVar5;
      if (iVar2 != 0) {
        uVar4 = piVar5[4] - iVar2;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[2] = 0;
        piVar5[3] = 0;
        piVar5[4] = 0;
      }
      FUN_01674ea0(piVar5,0x14);
      piVar5 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 8243 ; VA 0x0068a900 ; FUN_0068a900 */

bool FUN_0068a900(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      iVar2 = FUN_005eee40();
      return iVar2 != 0;
    }
  }
  return false;
}



/* FUNCTION 8244 ; VA 0x0068a970 ; FUN_0068a970 */

void FUN_0068a970(undefined4 param_1)

{
  undefined4 in_stack_00000014;
  
  FUN_006ad360(param_1,in_stack_00000014);
  return;
}



/* FUNCTION 8245 ; VA 0x0068a990 ; FUN_0068a990 */

undefined4 * __thiscall
FUN_0068a990(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a57b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0068ada0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8246 ; VA 0x0068ab40 ; FUN_0068ab40 */

undefined4 * __thiscall
FUN_0068ab40(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a57f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0068afb0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8247 ; VA 0x0068acf0 ; FUN_0068acf0 */

void __fastcall FUN_0068acf0(int param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(param_1 + 0x38))(0);
  if (iVar1 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 8248 ; VA 0x0068ad10 ; FUN_0068ad10 */

int FUN_0068ad10(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar3 = *(code **)(param_1 + 0x18);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 8249 ; VA 0x0068ada0 ; FUN_0068ada0 */

void FUN_0068ada0(int param_1,uint param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined auStack_290 [208];
  undefined4 uStack_1c0;
  undefined4 *puStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a584f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar2;
  FUN_005c13e0(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_1c0 = FUN_0088c8c0();
  uStack_1b8 = in_stack_00000020;
  puStack_1bc = (undefined4 *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c18) {
    FUN_016f3809(&DAT_01ea8c18);
    if (DAT_01ea8c18 == -1) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
  }
  puStack_1bc = &DAT_01ea8c0c;
  uStack_8._0_1_ = 4;
  FUN_005c13e0(&stack0x00000024);
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_290,&uStack_20,pcVar1);
  uStack_8._0_1_ = 6;
  (*pcVar1)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(auStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_01675290(uVar2);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    uVar5 = param_2;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(param_2 - 4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    uVar5 = in_stack_00000038 + 1;
    iVar3 = in_stack_00000024;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(in_stack_00000024 + -4);
      uVar5 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}


