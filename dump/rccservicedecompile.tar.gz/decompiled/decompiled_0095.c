/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 23750 ; VA 0x00b33440 ; FUN_00b33440 */

undefined4 * FUN_00b33440(undefined4 *param_1,undefined4 param_2)

{
  int aiStack_b8 [24];
  undefined **appuStack_58 [18];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f163b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00565000(param_2,1,1);
  uStack_8 = 0;
  FUN_00a8d320(param_1);
  FUN_00a8d320(param_1 + 1);
  *(undefined ***)((int)aiStack_b8 + *(int *)(aiStack_b8[0] + 4)) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)((int)aiStack_b8 + *(int *)(aiStack_b8[0] + 4) + -4) = *(int *)(aiStack_b8[0] + 4) + -0x60
  ;
  FUN_0056b950();
  *(undefined ***)((int)aiStack_b8 + *(int *)(aiStack_b8[0] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_b8 + *(int *)(aiStack_b8[0] + 4) + -4) = *(int *)(aiStack_b8[0] + 4) + -0x18
  ;
  uStack_8 = 1;
  appuStack_58[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_58);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23751 ; VA 0x00b33530 ; FUN_00b33530 */

undefined4 __thiscall FUN_00b33530(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_3);
  FUN_00b33640(param_2,auStack_c);
  return param_2;
}



/* FUNCTION 23752 ; VA 0x00b33560 ; FUN_00b33560 */

void __thiscall FUN_00b33560(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087d060(auStack_30);
  uVar1 = FUN_00b33440(auStack_18,auStack_30);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar1);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23753 ; VA 0x00b33610 ; FUN_00b33610 */

undefined4 __thiscall FUN_00b33610(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  FUN_00b33440(auStack_c,param_3);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_c);
  return 1;
}



/* FUNCTION 23754 ; VA 0x00b33640 ; FUN_00b33640 */

/* WARNING: Type propagation algorithm not settling */

undefined * FUN_00b33640(undefined *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined **appuStack_ac [4];
  int *piStack_9c;
  int *piStack_98;
  int *piStack_8c;
  uint *puStack_88;
  int *piStack_7c;
  uint uStack_70;
  uint uStack_6c;
  undefined4 uStack_60;
  undefined **appuStack_5c [18];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1698;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_5c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(&stack0xffffff50 + (int)appuStack_ac[0][1]) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  uVar1 = FUN_00a8e3b0(*param_2,&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[1],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_14 = 0x12;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (((uStack_6c & 2) == 0) && (uVar3 = *puStack_88, uVar3 != 0)) {
    if (uVar3 < uStack_70) {
      uVar3 = uStack_70;
    }
    iVar2 = *piStack_98;
    iVar4 = uVar3 - iVar2;
  }
  else {
    if (((uStack_6c & 4) != 0) || (*piStack_8c == 0)) goto LAB_00b337aa;
    iVar2 = *piStack_9c;
    iVar4 = (*piStack_8c - iVar2) + *piStack_7c;
  }
  FUN_005542c0(iVar2,iVar4);
LAB_00b337aa:
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(&stack0xffffff50 + (int)appuStack_ac[0][1]) = appuStack_ac[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(&stack0xffffff50 + (int)appuStack_ac[0][1]) = appuStack_ac[0][1] + -8;
  uStack_8 = 5;
  appuStack_5c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23755 ; VA 0x00b33830 ; FUN_00b33830 */

void __thiscall FUN_00b33830(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f16cf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_2);
  FUN_00b33640(aiStack_48,auStack_18);
  uStack_8 = 0;
  FUN_0054ef60(aiStack_48);
  uStack_8._0_1_ = 1;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(aiStack_30);
  }
  *(undefined4 *)(param_3 + 0x18) = uVar2;
  *(undefined4 *)(param_3 + 0x14) = 2;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar1 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  if (0xf < uStack_34) {
    uVar3 = uStack_34 + 1;
    iVar1 = aiStack_48[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_48[0] + -4);
      uVar3 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23756 ; VA 0x00b33940 ; FUN_00b33940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b33940(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f16ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee624) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee624);
    if (DAT_01eee624 == -1) {
      uStack_8 = 0;
      FUN_00888860("Region3int16",0x18,0,0,0);
      _DAT_01eee600 = RBX::Reflection::TType<class_RBX::Region3int16>::vftable;
      FUN_016f3654(&LAB_0188dac0);
      FUN_016f37bf(&DAT_01eee624);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee600;
}



/* FUNCTION 23757 ; VA 0x00b339e0 ; FUN_00b339e0 */

int * __thiscall FUN_00b339e0(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1708;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar6 = FUN_0078a0b0();
  *param_1 = iVar6;
  uStack_8 = 1;
  uVar7 = FUN_00b35490(*(undefined4 *)(*param_2 + 4),iVar6,param_2);
  *(undefined4 *)(*param_1 + 4) = uVar7;
  piVar2 = (int *)*param_1;
  param_1[1] = param_2[1];
  piVar3 = (int *)piVar2[1];
  if (*(char *)((int)piVar3 + 0xd) == '\0') {
    cVar1 = *(char *)(*piVar3 + 0xd);
    piVar5 = (int *)*piVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*piVar5 + 0xd);
      piVar3 = piVar5;
      piVar5 = (int *)*piVar5;
    }
    *piVar2 = (int)piVar3;
    iVar6 = *(int *)(*param_1 + 4);
    iVar4 = *(int *)(iVar6 + 8);
    cVar1 = *(char *)(iVar4 + 0xd);
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*(int *)(iVar4 + 8) + 0xd);
      iVar6 = iVar4;
      iVar4 = *(int *)(iVar4 + 8);
    }
    *(int *)(*param_1 + 8) = iVar6;
  }
  else {
    *piVar2 = (int)piVar2;
    *(int *)(*param_1 + 8) = *param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23758 ; VA 0x00b33a9e ; Catch_All@00b33a9e */

void Catch_All_00b33a9e(void)

{
  FUN_00b3fcb0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23759 ; VA 0x00b33ab0 ; FUN_00b33ab0 */

undefined4 * __thiscall FUN_00b33ab0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1720;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<class_boost::date_time::day_calc_dst_rule<struct_boost::local_time::nth_kday_rule_spec>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23760 ; VA 0x00b33b25 ; Catch_All@00b33b25 */

void Catch_All_00b33b25(void)

{
  int unaff_EBP;
  
  FUN_0054dc80(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23761 ; VA 0x00b33b40 ; FUN_00b33b40 */

undefined4 * __thiscall FUN_00b33b40(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_00b33be0(param_2);
  uVar2 = param_1[1];
  param_1[1] = *puVar4;
  *puVar4 = uVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  _guard_check_icall(param_1,param_2,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23762 ; VA 0x00b33be0 ; FUN_00b33be0 */

undefined4 * __thiscall FUN_00b33be0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1730;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<class_boost::date_time::day_calc_dst_rule<struct_boost::local_time::partial_date_rule_spec>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23763 ; VA 0x00b33c55 ; Catch_All@00b33c55 */

void Catch_All_00b33c55(void)

{
  int unaff_EBP;
  
  FUN_0054dc80(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23764 ; VA 0x00b33c70 ; FUN_00b33c70 */

undefined4 * __thiscall FUN_00b33c70(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1740;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::sp_counted_impl_p<class_boost::local_time::posix_time_zone_base<char>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23765 ; VA 0x00b33ce5 ; Catch_All@00b33ce5 */

void Catch_All_00b33ce5(void)

{
  int unaff_EBP;
  
  FUN_0054dc80(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23766 ; VA 0x00b33d00 ; FUN_00b33d00 */

int __thiscall FUN_00b33d00(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  
  uVar3 = FUN_016de2ed(*(undefined4 *)(param_2 + 4));
  *(undefined4 *)(param_1 + 4) = uVar3;
  if (param_3 != 0) {
    if (DAT_01eee670 == 0) {
      FUN_016dda75(0);
      if (DAT_01eee670 == 0) {
        DAT_01eee670 = DAT_021130c8 + 1;
        DAT_021130c8 = DAT_01eee670;
      }
      FUN_016ddacd();
    }
    FUN_016e06b5(uVar3,param_3,DAT_01eee670);
    *(undefined4 *)(*(int *)(param_1 + 4) + 0x10) = 0;
    iVar1 = *(int *)(param_1 + 4);
    puVar2 = *(undefined **)(iVar1 + 0x18);
    if (puVar2 != &DAT_018c0df0) {
      if (puVar2 != (undefined *)0x0) {
        FUN_017168b0(puVar2);
      }
      *(undefined4 *)(iVar1 + 0x18) = 0;
      pcVar5 = "*";
      do {
        pcVar6 = pcVar5;
        pcVar5 = pcVar6 + 1;
      } while (*pcVar5 != '\0');
      pcVar6 = pcVar6 + -0x18c0dee;
      iVar4 = FUN_0171e1f2(pcVar6);
      *(int *)(iVar1 + 0x18) = iVar4;
      if (iVar4 != 0) {
        FUN_0170c6f0(iVar4,&DAT_018c0df0,pcVar6);
      }
    }
  }
  return param_1;
}



/* FUNCTION 23767 ; VA 0x00b33de0 ; FUN_00b33de0 */

int __thiscall FUN_00b33de0(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  
  uVar3 = FUN_016de2ed(*(undefined4 *)(param_2 + 4));
  *(undefined4 *)(param_1 + 4) = uVar3;
  if (param_3 != 0) {
    if (DAT_01eee668 == 0) {
      FUN_016dda75(0);
      if (DAT_01eee668 == 0) {
        DAT_01eee668 = DAT_021130c8 + 1;
        DAT_021130c8 = DAT_01eee668;
      }
      FUN_016ddacd();
    }
    FUN_016e06b5(uVar3,param_3,DAT_01eee668);
    *(undefined4 *)(*(int *)(param_1 + 4) + 0x10) = 0;
    iVar1 = *(int *)(param_1 + 4);
    puVar2 = *(undefined **)(iVar1 + 0x18);
    if (puVar2 != &DAT_018c0df0) {
      if (puVar2 != (undefined *)0x0) {
        FUN_017168b0(puVar2);
      }
      *(undefined4 *)(iVar1 + 0x18) = 0;
      pcVar5 = "*";
      do {
        pcVar6 = pcVar5;
        pcVar5 = pcVar6 + 1;
      } while (*pcVar5 != '\0');
      pcVar6 = pcVar6 + -0x18c0dee;
      iVar4 = FUN_0171e1f2(pcVar6);
      *(int *)(iVar1 + 0x18) = iVar4;
      if (iVar4 != 0) {
        FUN_0170c6f0(iVar4,&DAT_018c0df0,pcVar6);
      }
    }
  }
  return param_1;
}



/* FUNCTION 23768 ; VA 0x00b33ec0 ; FUN_00b33ec0 */

int * FUN_00b33ec0(int *param_1)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  char *pcVar8;
  int iVar9;
  undefined4 *puStack_e4;
  int iStack_e0;
  undefined4 *puStack_dc;
  undefined4 *puStack_d8;
  int **ppiStack_d4;
  undefined4 uStack_d0;
  undefined auStack_c0 [24];
  undefined auStack_a8 [12];
  int *piStack_9c;
  char cStack_98;
  undefined auStack_94 [16];
  int iStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  uint uStack_78;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  int *piStack_60;
  int iStack_5c;
  undefined uStack_58;
  undefined uStack_57;
  undefined4 uStack_54;
  undefined2 uStack_50;
  uint uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1811;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff34;
  piStack_18 = (int *)0x0;
  uStack_78 = *(uint *)(*(int *)(*param_1 + 4) + 0x14 + (int)param_1);
  iVar9 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_8 = 0;
  piStack_9c = param_1;
  ExceptionList = &pvStack_10;
  iStack_7c = iVar9;
  uStack_4c = uStack_78;
  iStack_48 = iVar9;
  puVar4 = &stack0xffffff34;
  if (*(int **)(iVar9 + 0x38) != (int *)0x0) {
    uStack_d0 = 0xb33f1e;
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(iVar9 + 0x38) + 4))();
    puVar4 = puStack_14;
  }
  puStack_14 = puVar4;
  uStack_d0 = 0;
  uStack_8._0_1_ = 1;
  ppiStack_d4 = (int **)0xb33f2b;
  cStack_98 = FUN_00593b40();
  if (cStack_98 == '\0') {
    uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
    piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar6 != (int *)0x0) {
      ppiStack_d4 = (int **)0xb344ce;
      (**(code **)(*piVar6 + 8))();
    }
    *(uint *)(iVar9 + 0x14) = uStack_4c & 0xffff;
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = 0;
  ppiStack_d4 = (int **)0x0;
  uStack_8._0_1_ = 4;
  uStack_28 = 0xfffffffe;
  piStack_24 = (int *)0x7fffffff;
  puStack_d8 = (undefined4 *)0xb33f6a;
  puStack_d8 = (undefined4 *)FUN_0056a9c0();
  ppiStack_d4 = (int **)&uStack_28;
  puStack_dc = (undefined4 *)0xb33f77;
  FUN_005672c0();
  iStack_5c = *(int *)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  uStack_58 = iStack_5c == 0;
  uStack_57 = 0;
  uStack_54 = 0;
  uStack_50 = 1;
  piVar6 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 5;
  ppiStack_d4 = (int **)0xb33fb2;
  piStack_18 = piVar6;
  (**(code **)(*piVar6 + 4))();
  ppiStack_d4 = (int **)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puStack_d8 = (undefined4 *)0xb33fc0;
  FUN_016dda75();
  uStack_2c = DAT_01eee668;
  if (DAT_01eee668 == 0) {
    ppiStack_d4 = (int **)DAT_01eee668;
    puStack_d8 = (undefined4 *)0xb33fd6;
    FUN_016dda75();
    if (DAT_01eee668 == 0) {
      DAT_01eee668 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee668;
    }
    ppiStack_d4 = (int **)0xb33ff7;
    FUN_016ddacd();
  }
  uStack_2c = DAT_01eee668;
  if (DAT_01eee668 < (uint)piVar6[3]) {
    iVar9 = *(int *)(piVar6[2] + DAT_01eee668 * 4);
    if (iVar9 == 0) goto LAB_00b34013;
  }
  else {
    iVar9 = 0;
LAB_00b34013:
    if (*(char *)(piStack_18 + 5) != '\0') {
      ppiStack_d4 = (int **)0xb34021;
      iVar9 = FUN_016de17b();
      if (uStack_2c < *(uint *)(iVar9 + 0xc)) {
        iVar9 = *(int *)(*(int *)(iVar9 + 8) + uStack_2c * 4);
      }
      else {
        iVar9 = 0;
      }
    }
  }
  ppiStack_d4 = (int **)0xb3403b;
  FUN_016ddacd();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  ppiStack_d4 = (int **)0xb34049;
  puVar5 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    ppiStack_d4 = (int **)0x1;
    puStack_d8 = (undefined4 *)0xb34055;
    (**(code **)*puVar5)();
  }
  uStack_8._0_1_ = 4;
  if (iVar9 == 0) {
    ppiStack_d4 = (int **)0xf0;
    puStack_d8 = (undefined4 *)0xb34169;
    puVar5 = (undefined4 *)FUN_01674e20();
    uStack_8._0_1_ = 0xd;
    puStack_30 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      uStack_64 = 0;
      piStack_60 = (int *)&DAT_0000000f;
      auStack_74[0] = 0;
      piStack_1c = (int *)(PTR_DAT_01d66f6c + 1);
      pcVar8 = PTR_DAT_01d66f6c;
      do {
        cVar1 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar1 != '\0');
      ppiStack_d4 = (int **)((int)pcVar8 - (int)piStack_1c);
      puStack_d8 = (undefined4 *)PTR_DAT_01d66f6c;
      puStack_dc = (undefined4 *)0xb341b4;
      FUN_005542c0();
      ppiStack_d4 = (int **)0x0;
      puStack_d8 = (undefined4 *)auStack_74;
      uStack_8._0_1_ = 0xe;
      puStack_dc = (undefined4 *)0xb341c5;
      FUN_00b3a9d0();
      uStack_8._0_1_ = 0x10;
      ppiStack_d4 = (int **)0xb341d1;
      FUN_005507b0();
      *puVar5 = boost::date_time::
                time_input_facet<class_boost::posix_time::ptime,char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                ::vftable;
      puStack_d8 = (undefined4 *)PTR_DAT_01d66f70;
      piStack_24 = (int *)PTR_DAT_01d66f70;
      puVar5[0x3a] = 0;
      puVar5[0x3b] = 0xf;
      piStack_1c = (int *)((int)puStack_d8 + 1);
      *(undefined *)(puVar5 + 0x36) = 0;
      pcVar8 = (char *)puStack_d8;
      do {
        cVar1 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar1 != '\0');
      ppiStack_d4 = (int **)((int)pcVar8 - (int)piStack_1c);
      puStack_dc = (undefined4 *)0xb34213;
      FUN_005542c0();
    }
    piStack_24 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 0x11;
    ppiStack_d4 = (int **)0xb34232;
    piStack_1c = piStack_24;
    (**(code **)(*piStack_24 + 4))();
    piStack_18 = (int *)0xa;
    puStack_d8 = &uStack_28;
    uStack_8._0_1_ = 0x12;
    puStack_dc = (undefined4 *)0xb3424a;
    ppiStack_d4 = (int **)puVar5;
    FUN_00b33de0();
    uStack_8._0_1_ = 0x15;
    if (piStack_1c != (int *)0x0) {
      ppiStack_d4 = (int **)0xb3425c;
      puVar5 = (undefined4 *)(**(code **)(*piStack_1c + 8))();
      if (puVar5 != (undefined4 *)0x0) {
        ppiStack_d4 = (int **)0x1;
        puStack_d8 = (undefined4 *)0xb34268;
        (**(code **)*puVar5)();
      }
    }
    uStack_8._0_1_ = 0x14;
    ppiStack_d4 = (int **)auStack_3c;
    puStack_d8 = (undefined4 *)auStack_20;
    puStack_dc = (undefined4 *)0xb34280;
    FUN_00b460e0();
    uStack_8._0_1_ = 0x16;
    if (piStack_1c != (int *)0x0) {
      ppiStack_d4 = (int **)0xb34292;
      puVar5 = (undefined4 *)(**(code **)(*piStack_1c + 8))();
      if (puVar5 != (undefined4 *)0x0) {
        ppiStack_d4 = (int **)0x1;
        puStack_d8 = (undefined4 *)0xb3429e;
        (**(code **)*puVar5)();
      }
    }
    puStack_d8 = (undefined4 *)auStack_94;
    ppiStack_d4 = (int **)0x1;
    puStack_dc = &uStack_44;
    uStack_8._0_1_ = 0x14;
    iStack_e0 = *(int *)(*param_1 + 4) + (int)param_1;
    puStack_e4 = &uStack_54;
    FUN_00b43800(&uStack_64,&iStack_5c);
    uStack_8._0_1_ = 0x17;
    if (piStack_38 == (int *)0x0) goto LAB_00b342e8;
  }
  else {
    piStack_60 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 8;
    ppiStack_d4 = (int **)0xb3407c;
    piStack_38 = piStack_60;
    (**(code **)(*piStack_60 + 4))();
    piStack_18 = (int *)0x6;
    ppiStack_d4 = (int **)0x0;
    uStack_8._0_1_ = 9;
    puStack_d8 = (undefined4 *)0xb34091;
    FUN_016dda75();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    piStack_24 = DAT_01eee67c;
    if (DAT_01eee668 == 0) {
      ppiStack_d4 = (int **)DAT_01eee668;
      puStack_d8 = (undefined4 *)0xb340b0;
      FUN_016dda75();
      if (DAT_01eee668 == 0) {
        DAT_01eee668 = DAT_021130c8 + 1;
        DAT_021130c8 = DAT_01eee668;
      }
      ppiStack_d4 = (int **)0xb340d0;
      FUN_016ddacd();
    }
    uVar3 = DAT_01eee668;
    if (DAT_01eee668 < (uint)piStack_38[3]) {
      uStack_2c = *(uint *)(piStack_38[2] + DAT_01eee668 * 4);
      if (uStack_2c == 0) goto LAB_00b34133;
    }
    else {
      uStack_2c = 0;
LAB_00b34133:
      if (*(char *)(piStack_38 + 5) == '\0') {
LAB_00b3414c:
        if (uStack_2c != 0) goto LAB_00b340ee;
      }
      else {
        ppiStack_d4 = (int **)0xb3413e;
        iVar9 = FUN_016de17b();
        if (uVar3 < *(uint *)(iVar9 + 0xc)) {
          uStack_2c = *(uint *)(*(int *)(iVar9 + 8) + uVar3 * 4);
          goto LAB_00b3414c;
        }
      }
      if (piStack_24 == (int *)0x0) {
        ppiStack_d4 = (int **)0xb344f5;
        FUN_0054fc60();
        ppiStack_d4 = (int **)&DAT_01c24924;
        puStack_d8 = (undefined4 *)auStack_a8;
                    /* WARNING: Subroutine does not return */
        puStack_dc = (undefined4 *)0xb34506;
        FUN_0170c2a8();
      }
    }
LAB_00b340ee:
    uStack_8._0_1_ = 9;
    ppiStack_d4 = (int **)0xb340fa;
    FUN_016ddacd();
    puStack_d8 = (undefined4 *)auStack_94;
    ppiStack_d4 = (int **)0x1;
    puStack_dc = &uStack_44;
    iStack_e0 = *(int *)(*param_1 + 4) + (int)param_1;
    puStack_e4 = &uStack_54;
    FUN_00b43800(&uStack_28,&iStack_5c);
    uStack_8._0_1_ = 0xc;
  }
  ppiStack_d4 = (int **)0xb342dc;
  puVar5 = (undefined4 *)(**(code **)(*piStack_38 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    ppiStack_d4 = (int **)0x1;
    puStack_d8 = (undefined4 *)0xb342e8;
    (**(code **)*puVar5)();
  }
LAB_00b342e8:
  uStack_8._0_1_ = 4;
  if (iStack_84 != 0) {
    ppiStack_d4 = (int **)0x90;
    puStack_d8 = (undefined4 *)0xb3435b;
    piStack_1c = (int *)FUN_01674e20();
    uStack_8._0_1_ = 0x1a;
    if (piStack_1c == (int *)0x0) {
      ppiStack_d4 = (int **)0x0;
    }
    else {
      ppiStack_d4 = (int **)auStack_94;
      puStack_d8 = (undefined4 *)auStack_c0;
      puStack_dc = (undefined4 *)0xb3437e;
      ppiStack_d4 = (int **)FUN_00b35f60();
      piStack_18 = (int *)((uint)piStack_18 | 1);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
      puStack_d8 = (undefined4 *)0xb34391;
      ppiStack_d4 = (int **)FUN_00b3b770();
    }
    puStack_30 = (undefined4 *)0x0;
    uStack_8 = 0x1d;
    puStack_d8 = (undefined4 *)0xb343b2;
    piStack_38 = (int *)ppiStack_d4;
    uStack_34 = ppiStack_d4;
    piVar7 = (int *)FUN_00b33c70();
    piVar6 = piStack_1c;
    iVar9 = *piVar7;
    *piVar7 = (int)puStack_30;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    puStack_30 = (undefined4 *)iVar9;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        ppiStack_d4 = (int **)0xb343da;
        (**(code **)(*piStack_1c + 4))();
        LOCK();
        piVar7 = piVar6 + 2;
        iVar9 = *piVar7 + -1;
        *piVar7 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          ppiStack_d4 = (int **)0xb343eb;
          (**(code **)(*piVar6 + 8))();
        }
      }
    }
    ppiStack_d4 = (int **)piStack_38;
    puStack_d8 = piStack_38;
    puStack_dc = &uStack_34;
    iStack_e0 = 0xb343f9;
    _guard_check_icall();
    uStack_8 = 0x20;
    if (((uint)piStack_18 & 1) != 0) {
      ppiStack_d4 = (int **)0xb34414;
      FUN_005507b0();
    }
    ppiStack_d4 = &piStack_1c;
    puStack_d8 = (undefined4 *)0xb34420;
    puVar5 = (undefined4 *)FUN_00b41a70();
    ppiStack_d4 = (int **)0x0;
    uVar2 = *puVar5;
    puStack_dc = (undefined4 *)uStack_34;
    puStack_d8 = puStack_30;
    if (puStack_30 != (undefined4 *)0x0) {
      LOCK();
      *(int *)((int)puStack_30 + 4) = *(int *)((int)puStack_30 + 4) + 1;
      UNLOCK();
    }
    FUN_00b4a230(&puStack_e4);
    ppiStack_d4 = (int **)FUN_00b3b010(uVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
    puStack_d8 = (undefined4 *)0xb3445e;
    FUN_00b3dbb0();
    ppiStack_d4 = (int **)0xb34466;
    FUN_00b3d840();
    ppiStack_d4 = (int **)0xb3446e;
    FUN_00550ad0();
    ppiStack_d4 = (int **)0xb34479;
    FUN_005507b0();
    piVar6 = (int *)FUN_00b344ae();
    return piVar6;
  }
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_8._0_1_ = 0x18;
  puStack_dc = (undefined4 *)uStack_40;
  puStack_d8 = (undefined4 *)0x0;
  iStack_e0 = uStack_44;
  ppiStack_d4 = (int **)0x0;
  puStack_e4 = (undefined4 *)0xb34324;
  ppiStack_d4 = (int **)FUN_00b3b2c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  puStack_d8 = (undefined4 *)0xb34331;
  FUN_00b3dbb0();
  ppiStack_d4 = (int **)0xb34339;
  FUN_00b3d840();
  ppiStack_d4 = (int **)0xb34341;
  FUN_00550ad0();
  ppiStack_d4 = (int **)0xb3434c;
  FUN_005507b0();
  piVar6 = (int *)FUN_00b344ae();
  return piVar6;
}



/* FUNCTION 23769 ; VA 0x00b3447b ; Catch_All@00b3447b */

void Catch_All_00b3447b(void)

{
  int unaff_EBP;
  
  *(BADSPACEBASE **)(unaff_EBP + -0x10) = register0x00000010;
  if ((*(byte *)((int)*(int **)(unaff_EBP + 8) + *(int *)(**(int **)(unaff_EBP + 8) + 4) + 0x10) & 2
      ) == 0) {
    FUN_00b3449a();
    return;
  }
  *(undefined *)(unaff_EBP + -4) = 0x23;
  FUN_005565b0(2,0);
  *(undefined4 *)(unaff_EBP + -4) = 0x22;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23770 ; VA 0x00b34494 ; Catch@00b34494 */

undefined4 Catch_00b34494(void)

{
  return 0xb3450f;
}



/* FUNCTION 23771 ; VA 0x00b3449a ; FUN_00b3449a */

undefined * FUN_00b3449a(void)

{
  FUN_005565b0();
  return &DAT_00b344a5;
}



/* FUNCTION 23772 ; VA 0x00b344ae ; FUN_00b344ae */

void FUN_00b344ae(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int unaff_EBP;
  int *unaff_EDI;
  
  iVar1 = *(int *)(unaff_EBP + -0x44);
  *(undefined4 *)(unaff_EBP + -4) = 2;
  iVar2 = *unaff_EDI;
  *(undefined *)(unaff_EBP + -4) = 0x25;
  piVar3 = *(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)unaff_EDI);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 8))();
  }
  *(uint *)(iVar1 + 0x14) = *(uint *)(unaff_EBP + -0x48) & 0xffff;
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 23773 ; VA 0x00b34520 ; FUN_00b34520 */

int * FUN_00b34520(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  char *pcVar6;
  char *pcVar7;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  uint uStack_44;
  undefined auStack_40 [4];
  uint uStack_3c;
  undefined auStack_34 [4];
  int *piStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017f185a;
  pvStack_10 = ExceptionList;
  iStack_48 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_44 = *(uint *)(iStack_48 + 0x14);
  uStack_1c = *(undefined4 *)(iStack_48 + 0x38);
  uStack_3c = uStack_3c & 0xffffff00;
  piVar1 = *(int **)(*(int *)(iStack_48 + 0x30) + 4);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uStack_2c = uStack_44;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_016dda75(0);
  if (DAT_01eee66c == 0) {
    FUN_016dda75(0);
    if (DAT_01eee66c == 0) {
      DAT_01eee66c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee66c;
    }
    FUN_016ddacd();
  }
  uVar3 = DAT_01eee66c;
  if (DAT_01eee66c < (uint)piVar1[3]) {
    iVar4 = *(int *)(piVar1[2] + DAT_01eee66c * 4);
    if (iVar4 == 0) goto LAB_00b345d2;
  }
  else {
    iVar4 = 0;
LAB_00b345d2:
    if (*(char *)(piStack_14 + 5) != '\0') {
      iVar4 = FUN_016de17b();
      if (uVar3 < *(uint *)(iVar4 + 0xc)) {
        iVar4 = *(int *)(*(int *)(iVar4 + 8) + uVar3 * 4);
      }
      else {
        iVar4 = 0;
      }
    }
  }
  FUN_016ddacd();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar5 = (undefined4 *)(**(code **)(*piStack_14 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    (**(code **)*puVar5)(1);
  }
  uVar3 = uStack_8;
  uStack_8 = uStack_8 & 0xffffff00;
  if (iVar4 == 0) {
    piStack_24 = (int *)FUN_01674e20(0xfc);
    uStack_8._0_1_ = 9;
    if (piStack_24 == (int *)0x0) {
      piStack_14 = (int *)0x0;
    }
    else {
      piStack_14 = (int *)FUN_00b39b00(0);
    }
    piVar1 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 10;
    piStack_4c = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    piStack_30 = (int *)FUN_016de2ed(piVar1);
    piStack_20 = piStack_30;
    if (piStack_14 != (int *)0x0) {
      if (DAT_01eee66c == 0) {
        FUN_016dda75(0);
        if (DAT_01eee66c == 0) {
          DAT_01eee66c = DAT_021130c8 + 1;
          DAT_021130c8 = DAT_01eee66c;
        }
        FUN_016ddacd();
      }
      FUN_016e06b5(piStack_20,piStack_14,DAT_01eee66c);
      piStack_30[4] = 0;
      piStack_18 = piStack_30;
      puVar2 = (undefined *)piStack_30[6];
      if (puVar2 != &DAT_018c0df0) {
        if (puVar2 != (undefined *)0x0) {
          FUN_017168b0(puVar2);
        }
        piStack_18[6] = 0;
        pcVar6 = "*";
        do {
          pcVar7 = pcVar6;
          pcVar6 = pcVar7 + 1;
        } while (*pcVar6 != '\0');
        pcVar7 = pcVar7 + -0x18c0dee;
        iVar4 = FUN_0171e1f2(pcVar7);
        piStack_18[6] = iVar4;
        if (iVar4 != 0) {
          FUN_0170c6f0(iVar4,&DAT_018c0df0,pcVar7);
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar5 != (undefined4 *)0x0) {
      (**(code **)*puVar5)(1);
    }
    uStack_8._0_1_ = 0xd;
    FUN_00b460e0(auStack_28,auStack_34);
    uStack_8._0_1_ = 0xf;
    if ((piStack_24 != (int *)0x0) &&
       (puVar5 = (undefined4 *)(**(code **)(*piStack_24 + 8))(), puVar5 != (undefined4 *)0x0)) {
      (**(code **)*puVar5)(1);
    }
    uStack_8._0_1_ = 0xd;
    iVar4 = *(int *)(*param_1 + 4) + (int)param_1;
    FUN_00b48630(auStack_50,uStack_3c,uStack_1c,iVar4,
                 CONCAT31((int3)((uint)*(int *)(*param_1 + 4) >> 8),*(undefined *)(iVar4 + 0x40)),
                 param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    if ((piStack_30 != (int *)0x0) &&
       (puVar5 = (undefined4 *)(**(code **)(*piStack_30 + 8))(), puVar5 != (undefined4 *)0x0)) {
      (**(code **)*puVar5)(1);
    }
    goto LAB_00b346ec;
  }
  piVar1 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._1_3_ = SUB43(uVar3,1);
  uStack_8._0_1_ = 4;
  piStack_30 = piVar1;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8._0_1_ = 5;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  piStack_18 = (int *)DAT_01eee684;
  if (DAT_01eee66c == 0) {
    FUN_016dda75(0);
    if (DAT_01eee66c == 0) {
      DAT_01eee66c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee66c;
    }
    FUN_016ddacd();
  }
  uVar3 = DAT_01eee66c;
  if (DAT_01eee66c < (uint)piVar1[3]) {
    iVar4 = *(int *)(piVar1[2] + DAT_01eee66c * 4);
    if (iVar4 == 0) goto LAB_00b3470c;
  }
  else {
    iVar4 = 0;
LAB_00b3470c:
    if (*(char *)(piStack_14 + 5) == '\0') {
LAB_00b34725:
      if (iVar4 != 0) goto LAB_00b3469f;
    }
    else {
      iVar4 = FUN_016de17b();
      if (uVar3 < *(uint *)(iVar4 + 0xc)) {
        iVar4 = *(int *)(*(int *)(iVar4 + 8) + uVar3 * 4);
        goto LAB_00b34725;
      }
    }
    if (piStack_18 == (int *)0x0) {
      FUN_0054fc60();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c24924);
    }
  }
LAB_00b3469f:
  uStack_8._0_1_ = 5;
  FUN_016ddacd();
  iVar4 = *(int *)(*param_1 + 4) + (int)param_1;
  FUN_00b48630(auStack_50,uStack_3c,uStack_1c,iVar4,
               CONCAT31((int3)((uint)*(int *)(*param_1 + 4) >> 8),*(undefined *)(iVar4 + 0x40)),
               param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar5 = (undefined4 *)(**(code **)(*piStack_14 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    (**(code **)*puVar5)(1);
  }
LAB_00b346ec:
  *(uint *)(iStack_48 + 0x14) = uStack_2c & 0xffff;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23774 ; VA 0x00b34910 ; FUN_00b34910 */

int * FUN_00b34910(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_38 [4];
  int *piStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  uint uStack_20;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar2 = param_1;
  puStack_c = &LAB_017f18a2;
  pvStack_10 = ExceptionList;
  iStack_30 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_2c = *(uint *)(iStack_30 + 0x14);
  uStack_14 = *(undefined4 *)(iStack_30 + 0x38);
  uStack_20 = uStack_20 & 0xffffff00;
  piVar1 = *(int **)(*(int *)(iStack_30 + 0x30) + 4);
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  piStack_24 = piVar1;
  uStack_18 = uStack_2c;
  (**(code **)(*piVar1 + 4))();
  cVar3 = FUN_00b38720(auStack_28);
  uStack_8 = 2;
  if ((piVar1 != (int *)0x0) &&
     (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
    (**(code **)*puVar4)(1);
  }
  uStack_8 = 0;
  if (cVar3 == '\0') {
    iVar5 = FUN_01674e20(0x114);
    uStack_8 = 6;
    if (iVar5 == 0) {
      param_1 = (int *)0x0;
    }
    else {
      param_1 = (int *)FUN_00b3c250(0);
    }
    piVar1 = *(int **)(*(int *)(*(int *)(*piVar2 + 4) + 0x30 + (int)piVar2) + 4);
    uStack_8 = 7;
    piStack_34 = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 8;
    FUN_00b33d00(auStack_38,param_1);
    uStack_8 = 0xb;
    if ((piVar1 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = 10;
    FUN_00b460e0(auStack_38,auStack_28);
    uStack_8 = 0xc;
    if ((piStack_34 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_34 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = 10;
    iVar5 = *(int *)(*piVar2 + 4) + (int)piVar2;
    FUN_00b486f0(auStack_38,uStack_20,uStack_14,iVar5,
                 CONCAT31((int3)((uint)*(int *)(*piVar2 + 4) >> 8),*(undefined *)(iVar5 + 0x40)),
                 param_2);
    _uStack_8 = CONCAT31(uStack_7,0xd);
    if ((piStack_24 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_24 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
  }
  else {
    piVar1 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8 = 3;
    piStack_24 = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 4;
    FUN_00b390a0(auStack_28);
    iVar5 = *(int *)(*param_1 + 4) + (int)param_1;
    FUN_00b486f0(auStack_38,uStack_20,uStack_14,iVar5,
                 CONCAT31((int3)((uint)*(int *)(*param_1 + 4) >> 8),*(undefined *)(iVar5 + 0x40)),
                 param_2);
    _uStack_8 = CONCAT31(uStack_7,5);
    if ((piVar1 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
  }
  *(uint *)(iStack_30 + 0x14) = uStack_18 & 0xffff;
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 23775 ; VA 0x00b34b30 ; FUN_00b34b30 */

int * FUN_00b34b30(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_38 [4];
  int *piStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  uint uStack_20;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar2 = param_1;
  puStack_c = &LAB_017f18a2;
  pvStack_10 = ExceptionList;
  iStack_30 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_2c = *(uint *)(iStack_30 + 0x14);
  uStack_14 = *(undefined4 *)(iStack_30 + 0x38);
  uStack_20 = uStack_20 & 0xffffff00;
  piVar1 = *(int **)(*(int *)(iStack_30 + 0x30) + 4);
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  piStack_24 = piVar1;
  uStack_18 = uStack_2c;
  (**(code **)(*piVar1 + 4))();
  cVar3 = FUN_00b38720(auStack_28);
  uStack_8 = 2;
  if ((piVar1 != (int *)0x0) &&
     (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
    (**(code **)*puVar4)(1);
  }
  uStack_8 = 0;
  if (cVar3 == '\0') {
    iVar5 = FUN_01674e20(0x114);
    uStack_8 = 6;
    if (iVar5 == 0) {
      param_1 = (int *)0x0;
    }
    else {
      param_1 = (int *)FUN_00b3c250(0);
    }
    piVar1 = *(int **)(*(int *)(*(int *)(*piVar2 + 4) + 0x30 + (int)piVar2) + 4);
    uStack_8 = 7;
    piStack_34 = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 8;
    FUN_00b33d00(auStack_38,param_1);
    uStack_8 = 0xb;
    if ((piVar1 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = 10;
    FUN_00b460e0(auStack_38,auStack_28);
    uStack_8 = 0xc;
    if ((piStack_34 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_34 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = 10;
    iVar5 = *(int *)(*piVar2 + 4) + (int)piVar2;
    FUN_00b49210(auStack_38,uStack_20,uStack_14,iVar5,
                 CONCAT31((int3)((uint)*(int *)(*piVar2 + 4) >> 8),*(undefined *)(iVar5 + 0x40)),
                 param_2);
    _uStack_8 = CONCAT31(uStack_7,0xd);
    if ((piStack_24 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_24 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
  }
  else {
    piVar1 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8 = 3;
    piStack_24 = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 4;
    FUN_00b390a0(auStack_28);
    iVar5 = *(int *)(*param_1 + 4) + (int)param_1;
    FUN_00b49210(auStack_38,uStack_20,uStack_14,iVar5,
                 CONCAT31((int3)((uint)*(int *)(*param_1 + 4) >> 8),*(undefined *)(iVar5 + 0x40)),
                 param_2);
    _uStack_8 = CONCAT31(uStack_7,5);
    if ((piVar1 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
  }
  *(uint *)(iStack_30 + 0x14) = uStack_18 & 0xffff;
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 23776 ; VA 0x00b34d50 ; FUN_00b34d50 */

int FUN_00b34d50(int param_1,int param_2)

{
  undefined uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f18d9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 1;
  FUN_0054ef60(param_2 + 0x18);
  *(undefined *)(param_1 + 0x30) = *(undefined *)(param_2 + 0x30);
  *(undefined *)(param_1 + 0x31) = *(undefined *)(param_2 + 0x31);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_2 + 0x34);
  *(undefined *)(param_1 + 0x38) = *(undefined *)(param_2 + 0x38);
  *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_2 + 0x3c);
  *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_2 + 0x40);
  *(undefined *)(param_1 + 0x44) = *(undefined *)(param_2 + 0x44);
  uStack_8 = 2;
  FUN_0054ef60(param_2 + 0x48);
  uStack_8 = 0;
  uVar1 = FUN_005904a0(param_2 + 0x3c,*(undefined4 *)(param_2 + 0x40),param_2 + 0x48);
  *(undefined *)(param_2 + 0x44) = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23777 ; VA 0x00b34e20 ; FUN_00b34e20 */

void __thiscall FUN_00b34e20(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  if ((((uVar1 != 0) || (uVar2 != 0x80000000)) && ((uVar1 != 0xffffffff || (uVar2 != 0x7fffffff))))
     && ((uVar1 != 0xfffffffe || (uVar2 != 0x7fffffff)))) {
    uVar4 = *param_3;
    uVar5 = param_3[1];
    if (((uVar4 != 0) || (uVar5 != 0x80000000)) &&
       (((uVar4 != 0xffffffff || (uVar5 != 0x7fffffff)) &&
        ((uVar4 != 0xfffffffe || (uVar5 != 0x7fffffff)))))) goto LAB_00b34f6a;
  }
  if ((uVar1 == 0xfffffffe) && (uVar2 == 0x7fffffff)) {
LAB_00b34f05:
    *param_2 = 0xfffffffe;
    param_2[1] = 0x7fffffff;
    return;
  }
  uVar4 = *param_3;
  uVar5 = param_3[1];
  if ((uVar4 == 0xfffffffe) && (uVar5 == 0x7fffffff)) goto LAB_00b34f05;
  if ((uVar1 == 0xffffffff) && (uVar2 == 0x7fffffff)) {
    if ((uVar4 == 0) && (uVar5 == 0x80000000)) goto LAB_00b34f05;
  }
  else if ((uVar1 == 0) && (uVar2 == 0x80000000)) {
    if ((uVar4 == 0xffffffff) && (uVar5 == 0x7fffffff)) goto LAB_00b34f05;
    goto LAB_00b34ed3;
  }
  if ((uVar1 != 0xffffffff) || (uVar2 != 0x7fffffff)) {
    if ((uVar4 == 0xffffffff) && (uVar5 == 0x7fffffff)) {
      param_2[1] = 0x7fffffff;
      *param_2 = 0xffffffff;
      return;
    }
    cVar3 = FUN_00586330(uVar4,uVar5);
    if (cVar3 != '\0') {
      *param_2 = 0;
      param_2[1] = 0x80000000;
      return;
    }
LAB_00b34f6a:
    param_2[1] = uVar2 + uVar5 + (uint)CARRY4(uVar1,uVar4);
    *param_2 = uVar1 + uVar4;
    return;
  }
LAB_00b34ed3:
  *param_2 = uVar1;
  param_2[1] = param_1[1];
  return;
}



/* FUNCTION 23778 ; VA 0x00b34f80 ; FUN_00b34f80 */

void __thiscall FUN_00b34f80(undefined4 *param_1,undefined4 *param_2,char *param_3,char *param_4)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  
  if (param_3 != param_4) {
    pcVar1 = (char *)param_1[1];
    do {
      pcVar2 = (char *)*param_1;
      pcVar3 = param_3;
      if ((char *)*param_1 == pcVar1) break;
      for (; pcVar3 != param_4; pcVar3 = pcVar3 + 1) {
        if (pcVar2 == pcVar1) goto LAB_00b34fdd;
        if (*pcVar3 != *pcVar2) break;
        pcVar2 = pcVar2 + 1;
      }
      if (pcVar2 == pcVar1) {
LAB_00b34fdd:
        *param_2 = param_3;
        param_2[1] = pcVar3;
        return;
      }
      param_3 = param_3 + 1;
    } while (param_3 != param_4);
  }
  *param_2 = param_4;
  param_2[1] = param_4;
  return;
}



/* FUNCTION 23779 ; VA 0x00b34ff0 ; FUN_00b34ff0 */

int FUN_00b34ff0(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f18f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0078a0d0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  FUN_0054ef60(param_1 + 1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_1 + 7);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 23780 ; VA 0x00b35069 ; Catch_All@00b35069 */

void Catch_All_00b35069(void)

{
  int unaff_EBP;
  
  FUN_0078a1d0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23781 ; VA 0x00b35080 ; FUN_00b35080 */

int FUN_00b35080(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1910;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d10(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined4 *)(iVar1 + 0x20) = *(undefined4 *)(param_3 + 0x18);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 23782 ; VA 0x00b350e2 ; Catch_All@00b350e2 */

void Catch_All_00b350e2(void)

{
  int unaff_EBP;
  
  FUN_00781060(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23783 ; VA 0x00b35100 ; FUN_00b35100 */

undefined4 FUN_00b35100(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1928;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00970740(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_3 + 0x18);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23784 ; VA 0x00b35171 ; Catch_All@00b35171 */

void Catch_All_00b35171(void)

{
  int unaff_EBP;
  
  FUN_00875970(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23785 ; VA 0x00b35190 ; FUN_00b35190 */

int FUN_00b35190(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1940;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575ba0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(param_1);
  *(undefined4 *)(iVar1 + 0x28) = *(undefined4 *)(param_1 + 0x18);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 23786 ; VA 0x00b351f2 ; Catch_All@00b351f2 */

void Catch_All_00b351f2(void)

{
  int unaff_EBP;
  
  FUN_00576e10(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23787 ; VA 0x00b35210 ; FUN_00b35210 */

int FUN_00b35210(undefined *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009707a0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  uVar2 = FUN_00575ab0();
  *(undefined4 *)(iVar1 + 0x14) = uVar2;
  *(undefined4 *)(iVar1 + 0x14) = *(undefined4 *)(param_1 + 4);
  *(undefined4 *)(param_1 + 4) = uVar2;
  uVar2 = *(undefined4 *)(iVar1 + 0x18);
  *(undefined4 *)(iVar1 + 0x18) = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 8) = uVar2;
  *(undefined2 *)(iVar1 + 0x1c) = *(undefined2 *)(param_1 + 0xc);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 23788 ; VA 0x00b3529e ; Catch_All@00b3529e */

void Catch_All_00b3529e(void)

{
  int unaff_EBP;
  
  FUN_00970b90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23789 ; VA 0x00b352c0 ; FUN_00b352c0 */

void __thiscall FUN_00b352c0(uint *param_1,undefined *param_2,undefined4 param_3,undefined *param_4)

{
  uint uVar1;
  undefined uVar2;
  int *piVar3;
  uint *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1960;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  while( true ) {
    while( true ) {
      if (param_2 == param_4) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar2 = *param_2;
      piVar3 = (int *)FUN_0054e7d0(param_3);
      uVar2 = (**(code **)(*piVar3 + 0x10))(uVar2);
      uVar1 = param_1[5];
      uVar7 = param_1[4];
      if (uVar1 <= uVar7) break;
      param_1[4] = uVar7 + 1;
      puVar4 = param_1;
      if (0xf < uVar1) {
        puVar4 = (uint *)*param_1;
      }
      *(undefined *)((int)puVar4 + uVar7) = uVar2;
      *(undefined *)((int)puVar4 + uVar7 + 1) = 0;
      param_2 = param_2 + 1;
    }
    if (uVar7 == 0x7fffffff) break;
    uVar8 = uVar7 + 1 | 0xf;
    if (uVar8 < 0x80000000) {
      if (0x7fffffff - (uVar1 >> 1) < uVar1) {
        uVar8 = 0x7fffffff;
      }
      else {
        uVar9 = (uVar1 >> 1) + uVar1;
        if (uVar8 < uVar9) {
          uVar8 = uVar9;
        }
      }
    }
    else {
      uVar8 = 0x7fffffff;
    }
    uVar9 = uVar8 + 1;
    if (uVar9 < 0x1000) {
      if (uVar9 == 0) {
        uVar9 = 0;
      }
      else {
        uVar9 = FUN_01674e20(uVar9);
      }
    }
    else {
      uVar5 = uVar8 + 0x24;
      if (uVar5 <= uVar9) {
        uVar5 = 0xffffffff;
      }
      iVar6 = FUN_01674e20(uVar5);
      if (iVar6 == 0) goto LAB_00b35478;
      uVar9 = iVar6 + 0x23U & 0xffffffe0;
      *(int *)(uVar9 - 4) = iVar6;
    }
    param_1[4] = uVar7 + 1;
    param_1[5] = uVar8;
    if (uVar1 < 0x10) {
      FUN_0170c6f0(uVar9,param_1,uVar7);
      *(undefined *)(uVar9 + uVar7) = uVar2;
      *(undefined *)(uVar9 + 1 + uVar7) = 0;
      param_2 = param_2 + 1;
      *param_1 = uVar9;
    }
    else {
      uVar8 = *param_1;
      FUN_0170c6f0(uVar9,uVar8,uVar7);
      uVar5 = uVar1 + 1;
      *(undefined *)(uVar9 + uVar7) = uVar2;
      *(undefined *)(uVar9 + 1 + uVar7) = 0;
      uVar7 = uVar8;
      if (0xfff < uVar5) {
        uVar7 = *(uint *)(uVar8 - 4);
        uVar5 = uVar1 + 0x24;
        if (0x1f < (uVar8 - uVar7) - 4) goto LAB_00b35478;
      }
      FUN_01674ea0(uVar7,uVar5);
      param_2 = param_2 + 1;
      *param_1 = uVar9;
    }
  }
  FUN_00554040();
LAB_00b35478:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 23790 ; VA 0x00b3547d ; Catch_All@00b3547d */

void Catch_All_00b3547d(void)

{
  FUN_005507b0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23791 ; VA 0x00b35490 ; FUN_00b35490 */

undefined4 * __thiscall
FUN_00b35490(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1970;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00b34ff0(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00b35490(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00b35490(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 23792 ; VA 0x00b35524 ; Catch_All@00b35524 */

void Catch_All_00b35524(void)

{
  int unaff_EBP;
  
  FUN_00b3fbb0(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23793 ; VA 0x00b35540 ; FUN_00b35540 */

void FUN_00b35540(undefined4 param_1,undefined4 param_2)

{
  FUN_01674ea0(param_2,0x24);
  return;
}



/* FUNCTION 23794 ; VA 0x00b35560 ; FUN_00b35560 */

void __thiscall FUN_00b35560(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1980;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00780650(param_4);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_00a1aac0(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_00b35560(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23795 ; VA 0x00b35768 ; Catch_All@00b35768 */

void Catch_All_00b35768(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a134d0(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23796 ; VA 0x00b35790 ; FUN_00b35790 */

void __thiscall
FUN_00b35790(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0x7fffffd < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00b35210(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00b357e8;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00b357e8;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00b357e8:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00b35841:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00b35841;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 23797 ; VA 0x00b358f0 ; FUN_00b358f0 */

undefined4 * __thiscall
FUN_00b358f0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1990;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00559fe0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    puVar4 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar4 = (undefined4 *)*param_4;
    }
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(piVar3,param_3[8],puVar4,param_4[4]);
    if (iVar2 < 0) {
      FUN_00559fe0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00b3e2a0(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_00559fe0(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00b3e2a0(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00b3e2a0(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00b3e2a0(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar3 = piStack_18;
      if ((piStack_18 == (int *)*param_1) ||
         (cVar1 = FUN_00b3e2a0(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00559fe0(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00559fe0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined4 *)FUN_00b35b50(auStack_20,0,param_4,param_5);
  *param_2 = *puVar4;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23798 ; VA 0x00b35b33 ; Catch_All@00b35b33 */

void Catch_All_00b35b33(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23799 ; VA 0x00b35b50 ; FUN_00b35b50 */

void __thiscall
FUN_00b35b50(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  byte bVar3;
  byte extraout_var;
  int *piVar4;
  byte extraout_var_00;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_4;
  puStack_c = &LAB_017f19a0;
  piVar6 = (int *)*param_1;
  bVar3 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar6[1] + 0xd);
  piVar4 = piVar6;
  piVar2 = (int *)piVar6[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar4 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_0055c2d0(piVar4,piVar2[8],puVar8,puVar5[4]);
      bVar3 = extraout_var_00 >> 7;
    }
    else {
      if (0xf < (uint)piVar2[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      FUN_0055c2d0(puVar8,puVar5[4],piVar4,piVar2[8]);
      bVar3 = extraout_var >> 7 ^ 1;
    }
    if (bVar3 == 0) {
      piVar9 = (int *)piVar2[2];
    }
    else {
      piVar9 = (int *)*piVar2;
    }
    piVar4 = piVar2;
    piVar2 = piVar9;
    cVar1 = *(char *)((int)piVar9 + 0xd);
  }
  param_3 = piVar4;
  if (bVar3 != 0) {
    if (piVar4 == (int *)*piVar6) {
      puVar5 = (undefined4 *)FUN_00559fe0(&param_3,1,piVar4,puVar5,param_5);
      *param_2 = *puVar5;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar6 = param_3 + 4;
  if (0xf < (uint)param_3[9]) {
    piVar6 = (int *)*piVar6;
  }
  puVar8 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar8 = (undefined4 *)*puVar5;
  }
  iVar7 = FUN_0055c2d0(puVar8,puVar5[4],piVar6,param_3[8]);
  if (iVar7 < 0) {
    puVar5 = (undefined4 *)FUN_00559fe0(&param_3,bVar3,piVar4,puVar5,param_5);
    *param_2 = *puVar5;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00576370(param_5);
  *param_2 = piVar2;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23800 ; VA 0x00b35cce ; Catch_All@00b35cce */

void Catch_All_00b35cce(void)

{
  int unaff_EBP;
  
  FUN_00576370(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23801 ; VA 0x00b35cf0 ; FUN_00b35cf0 */

void __thiscall
FUN_00b35cf0(int *param_1,undefined4 *param_2,char param_3,char *param_4,undefined4 param_5)

{
  bool bVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f19b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar1 = true;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar3[1];
    do {
      puVar3 = puVar2;
      if (param_3 == '\0') {
        bVar1 = *param_4 < *(char *)(puVar3 + 4);
      }
      else {
        bVar1 = *param_4 <= *(char *)(puVar3 + 4);
      }
      if (bVar1 == false) {
        puVar2 = (undefined4 *)puVar3[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar3;
      }
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_00b35790(&param_3,bVar1,puVar3,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23802 ; VA 0x00b35d8a ; Catch_All@00b35d8a */

void Catch_All_00b35d8a(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23803 ; VA 0x00b35da0 ; FUN_00b35da0 */

int * FUN_00b35da0(int *param_1,int *param_2,undefined4 param_3,undefined4 *param_4,
                  undefined4 param_5)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  char cVar6;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined2 uStack_78;
  short sStack_76;
  undefined auStack_74 [24];
  undefined auStack_5c [24];
  undefined auStack_44 [44];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = param_5;
  puStack_c = &LAB_017f19eb;
  pvStack_10 = ExceptionList;
  uStack_80 = 0;
  uStack_78 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  sStack_76 = -1;
  uStack_8 = 0;
  cVar6 = (char)param_5;
  if ((cVar6 == '-') || (ExceptionList = &pvStack_10, cVar6 == '+')) {
    ExceptionList = &pvStack_10;
    if (*(char *)(param_2 + 1) == '\0') {
      piVar1 = (int *)*param_2;
      ExceptionList = &pvStack_10;
      if (piVar1 == (int *)0x0) {
LAB_00b35e2d:
        *param_2 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          ExceptionList = &pvStack_10;
          uVar2 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar2 = (uint)**(byte **)piVar1[7];
          ExceptionList = &pvStack_10;
        }
        if (uVar2 == 0xffffffff) goto LAB_00b35e2d;
        *(char *)((int)param_2 + 5) = (char)uVar2;
      }
      *(undefined *)(param_2 + 1) = 1;
    }
    if (*(char *)((int)param_2 + 5) != cVar6) {
      FUN_005558a0(uVar3);
    }
  }
  param_5 = 0;
  FUN_00b46fa0(param_2,param_3,auStack_90,&param_5);
  if (sStack_76 != -1) {
    FUN_0061f5c0(&uStack_18,(int)sStack_76);
    *param_4 = uStack_18;
    param_4[1] = uStack_14;
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    if (0xf < uStack_7c) {
      uVar5 = uStack_7c + 1;
      uVar2 = auStack_90[0];
      if (0xfff < uVar5) {
        uVar2 = *(uint *)(auStack_90[0] - 4);
        uVar5 = uStack_7c + 0x24;
        if (0x1f < (auStack_90[0] - uVar2) - 4) goto LAB_00b35f49;
      }
      FUN_01674ea0(uVar2,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00b35f60(auStack_44,auStack_90);
  uStack_8._0_1_ = 1;
  uVar3 = FUN_00555250(&uStack_18,1);
  uVar4 = FUN_00558df0(auStack_5c,"Parse failed. No match found for \'",auStack_44);
  uStack_8._0_1_ = 2;
  uVar4 = FUN_00558c80(auStack_74,uVar4,&DAT_01952878);
  uStack_8._0_1_ = 3;
  uVar3 = FUN_00b3cdd0(uVar4,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_007ceab0(uVar3);
LAB_00b35f49:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 23804 ; VA 0x00b35f50 ; thunk_FUN_00b38310 */

/* WARNING: Removing unreachable block (ram,0x00b383f1) */
/* WARNING: Removing unreachable block (ram,0x00b383b7) */
/* WARNING: Removing unreachable block (ram,0x00b38404) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall thunk_FUN_00b38310(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  double dVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined auStack_b0 [36];
  undefined auStack_8c [36];
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_1c;
  undefined8 uStack_18;
  
  iVar6 = *param_1;
  uStack_18._4_4_ = param_1;
  iVar2 = FUN_00b38680();
  if (iVar6 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      return piVar3;
    }
  }
  iVar6 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar6 != iVar2) {
    thunk_FUN_00b38680();
    uVar5 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar5);
  }
  FUN_0060f000();
  iVar6 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar6 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (0xf < (uint)piVar3[5]) {
      piVar3 = (int *)*piVar3;
    }
    lVar9 = FUN_01717857(piVar3);
    uStack_4c = (undefined4)((ulonglong)lVar9 >> 0x20);
    uStack_44 = (undefined4)lVar9;
    if (0xf6d3d9496bff < lVar9 + 0x105c07299000U) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error interpreting timestampMillis as a precise point in time. Fields out of range. UnixTimestampMillis should be between %lld and %lld."
                   ,0xf8d67000,0xffffefa3,0xd21fdbff,58999);
    }
    uVar10 = FUN_016f3900(lVar9,1000,0);
    iStack_1c = (int)(uVar10 >> 0x20);
    uStack_3c = (undefined4)uVar10;
    if (0x3f3016db7f < uVar10 + 0x430229a00) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error interpreting timestamp as a precise point in time. Fields out of range. UnixTimestamp should be between %lld and %lld."
                   ,0xcfdd6600,0xfffffffb,0xfff4417f,0x3a);
    }
    if (uVar10 < 0x7933fff80) {
      FUN_00b45090(auStack_b0,auStack_8c,uVar10);
      puVar4 = (undefined4 *)FUN_00b48520(auStack_58,auStack_8c);
      uVar5 = *puVar4;
      uVar7 = puVar4[1];
      puVar4 = (undefined4 *)FUN_00b48520(auStack_60,auStack_b0);
      uStack_18._0_4_ = *puVar4;
      piStack_34 = (int *)puVar4[1];
      param_1 = uStack_18._4_4_;
      uStack_30 = uVar5;
      uStack_2c = uVar7;
      uStack_24 = (undefined4)uStack_18;
    }
    else {
      FUN_00b44e20(&uStack_18,uVar10);
      puVar4 = (undefined4 *)FUN_00b4b490(auStack_68,(undefined4)uStack_18,uStack_18._4_4_);
      uStack_30 = *puVar4;
      uStack_2c = puVar4[1];
      piStack_34 = uStack_18._4_4_;
    }
    uStack_18 = (double)CONCAT44(piStack_34,(undefined4)uStack_18);
    uStack_38 = (undefined4)uStack_18;
    FUN_00b4a230(&iStack_28);
    dVar8 = DAT_018d8a10;
    FUN_01726ab0();
    uStack_18 = dVar8;
    FUN_016f39b0(uStack_3c,iStack_1c,1000,0);
    FUN_016f4020();
    uVar5 = FUN_005ef640(0,0,0,(int)(uStack_18 * dVar8),(int)(uStack_18 * dVar8) >> 0x1f);
    piVar3 = (int *)FUN_00b3e000(auStack_48,uVar5);
    iStack_28 = *piVar3;
    uStack_18._4_4_ = (int *)piVar3[1];
    piVar3 = (int *)FUN_00b3e000(auStack_40,uVar5);
    iStack_1c = piVar3[1];
    iVar6 = *piVar3;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2f8)
       && (FUN_016f3809(&DAT_01ead2f8), DAT_01ead2f8 == -1)) {
      _DAT_01ead2ec = FUN_00619f20;
      _DAT_01ead2f0 = FUN_00619f20;
      _DAT_01ead2f4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead2f8);
    }
    puVar1 = (undefined *)param_1[1];
    if (puVar1 == &DAT_01ead2ec) {
      param_1[4] = iStack_28;
      param_1[2] = iVar6;
      param_1[3] = iStack_1c;
      param_1[5] = (int)uStack_18._4_4_;
    }
    else {
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(param_1 + 2);
      }
      param_1[4] = iStack_28;
      param_1[2] = iVar6;
      param_1[3] = iStack_1c;
      param_1[5] = (int)uStack_18._4_4_;
      param_1[1] = (int)&DAT_01ead2ec;
    }
    iVar6 = FUN_00b38680();
    *param_1 = iVar6;
    iVar2 = FUN_00b38680();
    if (iVar6 == iVar2) {
      piVar3 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar3 = (int *)0x0;
      }
      return piVar3;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23805 ; VA 0x00b35f60 ; FUN_00b35f60 */

undefined4 * FUN_00b35f60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_8 = 0;
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
  }
  piVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar4 = param_1;
  puVar2 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar2 = (undefined4 *)*param_1;
    puVar4 = (undefined4 *)*param_1;
  }
  FUN_00591430((int)puVar2 - (int)puVar4,0,param_2,(int)puVar3 + (*piVar1 - (int)param_2));
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23806 ; VA 0x00b36000 ; FUN_00b36000 */

undefined4 * FUN_00b36000(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1a2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01952784;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::ambiguous_result::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23807 ; VA 0x00b360e0 ; FUN_00b360e0 */

undefined4 * FUN_00b360e0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1a6c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01952870;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_adjustment::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23808 ; VA 0x00b361c0 ; FUN_00b361c0 */

undefined4 * FUN_00b361c0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1aac;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01951d88;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_year::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23809 ; VA 0x00b362a0 ; FUN_00b362a0 */

undefined4 * FUN_00b362a0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1aec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01952830;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_offset::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23810 ; VA 0x00b36380 ; FUN_00b36380 */

undefined4 * FUN_00b36380(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1b2c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01951dc8;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_weekday::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23811 ; VA 0x00b36460 ; FUN_00b36460 */

undefined4 * FUN_00b36460(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1b6c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_019527c4;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::time_label_invalid::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23812 ; VA 0x00b36540 ; FUN_00b36540 */

undefined4 * FUN_00b36540(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1bac;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_019527f0;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23813 ; VA 0x00b36620 ; FUN_00b36620 */

undefined4 * FUN_00b36620(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1bc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23814 ; VA 0x00b366c0 ; FUN_00b366c0 */

undefined4 * FUN_00b366c0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  return param_1;
}



/* FUNCTION 23815 ; VA 0x00b36720 ; FUN_00b36720 */

undefined4 * FUN_00b36720(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::bad_adjustment>::vftable;
  return param_1;
}



/* FUNCTION 23816 ; VA 0x00b36780 ; FUN_00b36780 */

undefined4 * FUN_00b36780(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::gregorian::bad_day_of_year>::vftable;
  return param_1;
}



/* FUNCTION 23817 ; VA 0x00b367e0 ; FUN_00b367e0 */

undefined4 * FUN_00b367e0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
               vftable;
  return param_1;
}



/* FUNCTION 23818 ; VA 0x00b36840 ; FUN_00b36840 */

undefined4 * FUN_00b36840(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
               vftable;
  return param_1;
}



/* FUNCTION 23819 ; VA 0x00b368a0 ; FUN_00b368a0 */

undefined4 * FUN_00b368a0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  return param_1;
}



/* FUNCTION 23820 ; VA 0x00b36900 ; FUN_00b36900 */

undefined4 * FUN_00b36900(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  return param_1;
}



/* FUNCTION 23821 ; VA 0x00b36960 ; FUN_00b36960 */

void FUN_00b36960(undefined4 *param_1,undefined4 *param_2)

{
  char *pcVar1;
  char *pcVar2;
  int *piVar3;
  char *pcVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_c [8];
  
  pcVar1 = (char *)*param_2;
  pcVar2 = pcVar1;
  do {
    pcVar4 = pcVar2;
    pcVar2 = pcVar4 + 1;
  } while (*pcVar4 != '\0');
  puVar5 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar5 = (undefined4 *)*param_1;
  }
  puVar6 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar6 = (undefined4 *)*param_1;
  }
  piVar3 = (int *)FUN_00632f40(auStack_c,puVar6,param_1[4] + (int)puVar5);
  if (*piVar3 != piVar3[1]) {
    FUN_00b36d80(param_1,CONCAT44(pcVar4,pcVar1));
  }
  return;
}



/* FUNCTION 23822 ; VA 0x00b36a00 ; FUN_00b36a00 */

void FUN_00b36a00(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined auStack_c [8];
  
  puVar5 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar5 = (undefined4 *)*param_2;
  }
  iVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  puVar4 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  piVar2 = (int *)FUN_00b34f80(auStack_c,puVar4,param_1[4] + (int)puVar3);
  if (*piVar2 != piVar2[1]) {
    FUN_00b36f90(param_1,CONCAT44(iVar1 + (int)puVar5,param_2));
  }
  return;
}



/* FUNCTION 23823 ; VA 0x00b36aa0 ; FUN_00b36aa0 */

void FUN_00b36aa0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  
  puVar2 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar2 = (undefined4 *)*param_1;
  }
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  piVar1 = (int *)FUN_00632f40(auStack_20,puVar3,param_1[4] + (int)puVar2);
  uStack_18 = param_3;
  if (*piVar1 != piVar1[1]) {
    FUN_00b36b40(param_1,param_2,param_3,param_4,param_5,*piVar1,piVar1[1],param_4,param_5);
  }
  return;
}



/* FUNCTION 23824 ; VA 0x00b36b40 ; FUN_00b36b40 */

void FUN_00b36b40(char *param_1,char *param_2,char *param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,char *param_7,char *param_8,undefined4 param_9,
                 undefined4 param_10)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  undefined4 uVar5;
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined auStack_30 [12];
  char *pcStack_24;
  char *pcStack_20;
  undefined4 uStack_1c;
  char *pcStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1be8;
  pvStack_10 = ExceptionList;
  uStack_1c = param_10;
  piStack_44 = (int *)0x0;
  uStack_40 = 0;
  uStack_3c = 0;
  iStack_38 = 0;
  iStack_34 = 0;
  ExceptionList = &pvStack_10;
  piStack_44 = (int *)FUN_01674e20(8);
  *piStack_44 = 0;
  piStack_44[1] = 0;
  *piStack_44 = (int)&piStack_44;
  uStack_8 = 0;
  pcStack_18 = param_1;
  pcVar3 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcStack_18 = *(char **)param_1;
    pcVar3 = *(char **)param_1;
  }
  if (param_7 == param_8) {
LAB_00b36cb6:
    pcVar2 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar2 = *(char **)param_1;
    }
    FUN_00632fb0(&pcStack_24,&piStack_44,param_1,pcStack_18,pcVar3,pcVar2 + *(int *)(param_1 + 0x10)
                );
    if (iStack_34 == 0) {
      pcVar3 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pcVar3 = *(char **)param_1;
      }
      FUN_00635720(&pcStack_24,param_1,pcStack_24,pcVar3 + *(int *)(param_1 + 0x10));
    }
    else {
      pcVar3 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pcVar3 = *(char **)param_1;
      }
      FUN_00636710(param_1,pcVar3 + *(int *)(param_1 + 0x10),piStack_44,0,iStack_38,piStack_44,0,
                   iStack_38 + iStack_34);
    }
    FUN_00611300();
    ExceptionList = pvStack_10;
    return;
  }
  do {
    FUN_00632fb0(&pcStack_24,&piStack_44,param_1,pcStack_18,pcVar3,param_7);
    pcStack_18 = pcStack_24;
    uVar5 = 0;
    if ((piStack_44 != (int *)0x0) && ((undefined4 *)*piStack_44 != (undefined4 *)0x0)) {
      uVar5 = *(undefined4 *)*piStack_44;
    }
    pcStack_20 = param_8;
    FUN_00b387e0(auStack_30,uVar5,0,iStack_34 + iStack_38,param_9,uStack_1c);
    pcVar2 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar2 = *(char **)param_1;
    }
    pcVar2 = pcVar2 + *(int *)(param_1 + 0x10);
    for (pcVar4 = param_8; param_8 = pcVar2, param_7 = pcVar2, pcVar3 = pcStack_20, pcVar4 != pcVar2
        ; pcVar4 = pcVar4 + 1) {
      pcVar1 = param_2;
      param_8 = pcVar4;
      if (param_2 == param_3) goto LAB_00b36cb6;
      for (; param_7 = pcVar4, param_8 != pcVar2; param_8 = param_8 + 1) {
        if (pcVar1 == param_3) goto LAB_00b36c93;
        if (*param_8 != *pcVar1) break;
        pcVar1 = pcVar1 + 1;
      }
      if (pcVar1 == param_3) break;
    }
LAB_00b36c93:
    if (param_7 == param_8) goto LAB_00b36cb6;
    uStack_1c = param_6;
    param_9 = param_5;
  } while( true );
}



/* FUNCTION 23825 ; VA 0x00b36d80 ; FUN_00b36d80 */

void FUN_00b36d80(char *param_1,char *param_2,char *param_3,undefined4 param_4,undefined4 param_5,
                 char *param_6,char *param_7)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  undefined4 uVar5;
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  char *pcStack_20;
  char *pcStack_1c;
  char *pcStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1be8;
  pvStack_10 = ExceptionList;
  piStack_44 = (int *)0x0;
  uStack_40 = 0;
  uStack_3c = 0;
  iStack_38 = 0;
  iStack_34 = 0;
  ExceptionList = &pvStack_10;
  piStack_44 = (int *)FUN_01674e20(8);
  *piStack_44 = 0;
  piStack_44[1] = 0;
  *piStack_44 = (int)&piStack_44;
  uStack_8 = 0;
  pcStack_18 = param_1;
  pcVar3 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcStack_18 = *(char **)param_1;
    pcVar3 = *(char **)param_1;
  }
  if (param_6 != param_7) {
    do {
      FUN_00632fb0(&pcStack_20,&piStack_44,param_1,pcStack_18,pcVar3,param_6);
      pcStack_18 = pcStack_20;
      uVar5 = 0;
      if ((piStack_44 != (int *)0x0) && ((undefined4 *)*piStack_44 != (undefined4 *)0x0)) {
        uVar5 = *(undefined4 *)*piStack_44;
      }
      pcStack_1c = param_7;
      FUN_00b387e0(auStack_30,uVar5,0,iStack_34 + iStack_38,0,0);
      pcVar2 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pcVar2 = *(char **)param_1;
      }
      pcVar2 = pcVar2 + *(int *)(param_1 + 0x10);
      for (pcVar4 = param_7; param_7 = pcVar2, param_6 = pcVar2, pcVar3 = pcStack_1c,
          pcVar4 != pcVar2; pcVar4 = pcVar4 + 1) {
        param_7 = pcVar4;
        pcVar1 = param_2;
        if (param_2 == param_3) goto LAB_00b36ed6;
        for (; param_6 = pcVar4, param_7 != pcVar2; param_7 = param_7 + 1) {
          if (pcVar1 == param_3) goto LAB_00b36ec0;
          if (*param_7 != *pcVar1) break;
          pcVar1 = pcVar1 + 1;
        }
        if (pcVar1 == param_3) break;
      }
LAB_00b36ec0:
    } while (param_6 != param_7);
  }
LAB_00b36ed6:
  pcVar2 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar2 = *(char **)param_1;
  }
  FUN_00632fb0(&pcStack_20,&piStack_44,param_1,pcStack_18,pcVar3,pcVar2 + *(int *)(param_1 + 0x10));
  if (iStack_34 == 0) {
    pcVar3 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar3 = *(char **)param_1;
    }
    FUN_00635720(auStack_24,param_1,pcStack_20,pcVar3 + *(int *)(param_1 + 0x10));
  }
  else {
    pcVar3 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar3 = *(char **)param_1;
    }
    FUN_00636710(param_1,pcVar3 + *(int *)(param_1 + 0x10),piStack_44,0,iStack_38,piStack_44,0,
                 iStack_38 + iStack_34);
  }
  FUN_00611300();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23826 ; VA 0x00b36f90 ; FUN_00b36f90 */

void FUN_00b36f90(char *param_1,char *param_2,char *param_3,undefined4 param_4,undefined4 param_5,
                 char *param_6,char *param_7)

{
  char *pcVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  undefined4 uVar5;
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  char *pcStack_20;
  char *pcStack_1c;
  char *pcStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1be8;
  pvStack_10 = ExceptionList;
  piStack_44 = (int *)0x0;
  uStack_40 = 0;
  uStack_3c = 0;
  iStack_38 = 0;
  iStack_34 = 0;
  ExceptionList = &pvStack_10;
  piStack_44 = (int *)FUN_01674e20(8);
  *piStack_44 = 0;
  piStack_44[1] = 0;
  *piStack_44 = (int)&piStack_44;
  uStack_8 = 0;
  pcStack_18 = param_1;
  pcVar3 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcStack_18 = *(char **)param_1;
    pcVar3 = *(char **)param_1;
  }
  if (param_6 != param_7) {
    do {
      FUN_00632fb0(&pcStack_20,&piStack_44,param_1,pcStack_18,pcVar3,param_6);
      pcStack_18 = pcStack_20;
      uVar5 = 0;
      if ((piStack_44 != (int *)0x0) && ((undefined4 *)*piStack_44 != (undefined4 *)0x0)) {
        uVar5 = *(undefined4 *)*piStack_44;
      }
      pcStack_1c = param_7;
      FUN_00b387e0(auStack_30,uVar5,0,iStack_34 + iStack_38,0,0);
      pcVar2 = param_1;
      if (0xf < *(uint *)(param_1 + 0x14)) {
        pcVar2 = *(char **)param_1;
      }
      pcVar2 = pcVar2 + *(int *)(param_1 + 0x10);
      for (pcVar4 = param_7; param_7 = pcVar2, param_6 = pcVar2, pcVar3 = pcStack_1c,
          pcVar4 != pcVar2; pcVar4 = pcVar4 + 1) {
        param_7 = pcVar4;
        pcVar1 = param_2;
        if (param_2 == param_3) goto LAB_00b370e6;
        for (; param_6 = pcVar4, param_7 != pcVar2; param_7 = param_7 + 1) {
          if (pcVar1 == param_3) goto LAB_00b370d0;
          if (*param_7 != *pcVar1) break;
          pcVar1 = pcVar1 + 1;
        }
        if (pcVar1 == param_3) break;
      }
LAB_00b370d0:
    } while (param_6 != param_7);
  }
LAB_00b370e6:
  pcVar2 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar2 = *(char **)param_1;
  }
  FUN_00632fb0(&pcStack_20,&piStack_44,param_1,pcStack_18,pcVar3,pcVar2 + *(int *)(param_1 + 0x10));
  if (iStack_34 == 0) {
    pcVar3 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar3 = *(char **)param_1;
    }
    FUN_00635720(auStack_24,param_1,pcStack_20,pcVar3 + *(int *)(param_1 + 0x10));
  }
  else {
    pcVar3 = param_1;
    if (0xf < *(uint *)(param_1 + 0x14)) {
      pcVar3 = *(char **)param_1;
    }
    FUN_00636710(param_1,pcVar3 + *(int *)(param_1 + 0x10),piStack_44,0,iStack_38,piStack_44,0,
                 iStack_38 + iStack_34);
  }
  FUN_00611300();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23827 ; VA 0x00b371a0 ; FUN_00b371a0 */

uint FUN_00b371a0(int *param_1,undefined4 param_2,int param_3,uint param_4,byte *param_5)

{
  int *piVar1;
  byte *pbVar2;
  void **ppvVar3;
  char cVar4;
  byte bVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1c00;
  pvStack_10 = ExceptionList;
  uVar8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_4 != 0) {
    do {
      cVar4 = FUN_00a8d280(param_1,param_2);
      ppvVar3 = (void **)ExceptionList;
      if (cVar4 != '\0') break;
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b37218:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b37218;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      iVar7 = FUN_0171db62((int)*(char *)((int)param_1 + 5));
      if (iVar7 == 0) {
        if (*(char *)(param_1 + 1) == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b37263:
            *param_1 = 0;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar6 = (**(code **)(*piVar1 + 0x18))();
            }
            else {
              uVar6 = (uint)**(byte **)piVar1[7];
            }
            if (uVar6 == 0xffffffff) goto LAB_00b37263;
            *(char *)((int)param_1 + 5) = (char)uVar6;
          }
          *(undefined *)(param_1 + 1) = 1;
        }
        ppvVar3 = (void **)ExceptionList;
        if (*(byte *)((int)param_1 + 5) != *param_5) break;
      }
      cVar4 = *(char *)(param_1 + 1);
      if (cVar4 == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b372ad:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b372ad;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
        cVar4 = '\x01';
      }
      bVar5 = *(byte *)((int)param_1 + 5);
      if (bVar5 == *param_5) {
        FUN_005558a0(0x30);
      }
      else {
        if (cVar4 == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b37305:
            *param_1 = 0;
            uVar6 = (uint)bVar5;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar6 = (**(code **)(*piVar1 + 0x18))();
              bVar5 = *(byte *)((int)param_1 + 5);
            }
            else {
              uVar6 = (uint)**(byte **)piVar1[7];
            }
            if (uVar6 == 0xffffffff) goto LAB_00b37305;
            *(char *)((int)param_1 + 5) = (char)uVar6;
          }
          *(undefined *)(param_1 + 1) = 1;
          bVar5 = (byte)uVar6;
        }
        FUN_005558a0(bVar5);
      }
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b37353:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b37353;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b37396:
        *param_1 = 0;
        *(undefined *)(param_1 + 1) = 1;
      }
      else {
        if (*(int *)piVar1[7] == 0) {
LAB_00b37386:
          uVar6 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar7 = *(int *)piVar1[0xb];
          if (iVar7 < 1) goto LAB_00b37386;
          *(int *)piVar1[0xb] = iVar7 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar6 = (uint)*pbVar2;
        }
        if (uVar6 == 0xffffffff) goto LAB_00b37396;
        *(undefined *)(param_1 + 1) = 0;
      }
      uVar8 = uVar8 + 1;
      ppvVar3 = (void **)ExceptionList;
    } while (uVar8 < param_4);
  }
  ExceptionList = ppvVar3;
  if (param_4 <= *(uint *)(param_3 + 0x10)) {
    uStack_8 = 0;
    uVar8 = FUN_00b38bb0(param_3);
    ExceptionList = pvStack_10;
    return uVar8 & 0xffff;
  }
  ExceptionList = pvStack_10;
  return 0xffffffff;
}



/* FUNCTION 23828 ; VA 0x00b373f4 ; Catch@00b373f4 */

undefined * Catch_00b373f4(void)

{
  return &LAB_00b373fa;
}



/* FUNCTION 23829 ; VA 0x00b37410 ; FUN_00b37410 */

undefined2 FUN_00b37410(int *param_1,undefined4 param_2,int param_3,uint param_4,byte *param_5)

{
  int *piVar1;
  byte *pbVar2;
  void **ppvVar3;
  char cVar4;
  byte bVar5;
  undefined2 uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1c10;
  pvStack_10 = ExceptionList;
  uVar9 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_4 != 0) {
    do {
      cVar4 = FUN_00a8d280(param_1,param_2);
      ppvVar3 = (void **)ExceptionList;
      if (cVar4 != '\0') break;
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b37488:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b37488;
          *(char *)((int)param_1 + 5) = (char)uVar7;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      iVar8 = FUN_0171db62((int)*(char *)((int)param_1 + 5));
      if (iVar8 == 0) {
        if (*(char *)(param_1 + 1) == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b374d3:
            *param_1 = 0;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar7 = (**(code **)(*piVar1 + 0x18))();
            }
            else {
              uVar7 = (uint)**(byte **)piVar1[7];
            }
            if (uVar7 == 0xffffffff) goto LAB_00b374d3;
            *(char *)((int)param_1 + 5) = (char)uVar7;
          }
          *(undefined *)(param_1 + 1) = 1;
        }
        ppvVar3 = (void **)ExceptionList;
        if (*(byte *)((int)param_1 + 5) != *param_5) break;
      }
      cVar4 = *(char *)(param_1 + 1);
      if (cVar4 == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b3751d:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b3751d;
          *(char *)((int)param_1 + 5) = (char)uVar7;
        }
        *(undefined *)(param_1 + 1) = 1;
        cVar4 = '\x01';
      }
      bVar5 = *(byte *)((int)param_1 + 5);
      if (bVar5 == *param_5) {
        FUN_005558a0(0x30);
      }
      else {
        if (cVar4 == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b37575:
            *param_1 = 0;
            uVar7 = (uint)bVar5;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar7 = (**(code **)(*piVar1 + 0x18))();
              bVar5 = *(byte *)((int)param_1 + 5);
            }
            else {
              uVar7 = (uint)**(byte **)piVar1[7];
            }
            if (uVar7 == 0xffffffff) goto LAB_00b37575;
            *(char *)((int)param_1 + 5) = (char)uVar7;
          }
          *(undefined *)(param_1 + 1) = 1;
          bVar5 = (byte)uVar7;
        }
        FUN_005558a0(bVar5);
      }
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b375c3:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b375c3;
          *(char *)((int)param_1 + 5) = (char)uVar7;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b37606:
        *param_1 = 0;
        *(undefined *)(param_1 + 1) = 1;
      }
      else {
        if (*(int *)piVar1[7] == 0) {
LAB_00b375f6:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b375f6;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 == 0xffffffff) goto LAB_00b37606;
        *(undefined *)(param_1 + 1) = 0;
      }
      uVar9 = uVar9 + 1;
      ppvVar3 = (void **)ExceptionList;
    } while (uVar9 < param_4);
  }
  ExceptionList = ppvVar3;
  if (param_4 <= *(uint *)(param_3 + 0x10)) {
    uStack_8 = 0;
    uVar6 = FUN_009d6080(param_3);
    ExceptionList = pvStack_10;
    return uVar6;
  }
  ExceptionList = pvStack_10;
  return 0xffff;
}



/* FUNCTION 23830 ; VA 0x00b37666 ; Catch@00b37666 */

undefined * Catch_00b37666(void)

{
  return &LAB_00b3766c;
}



/* FUNCTION 23831 ; VA 0x00b37680 ; FUN_00b37680 */

undefined4 FUN_00b37680(int *param_1,undefined4 param_2,int param_3,uint param_4,byte *param_5)

{
  int *piVar1;
  byte *pbVar2;
  void **ppvVar3;
  char cVar4;
  byte bVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1c20;
  pvStack_10 = ExceptionList;
  uVar9 = 0;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_4 != 0) {
    do {
      cVar4 = FUN_00a8d280(param_1,param_2);
      ppvVar3 = (void **)ExceptionList;
      if (cVar4 != '\0') break;
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b376f8:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b376f8;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      iVar7 = FUN_0171db62((int)*(char *)((int)param_1 + 5));
      if (iVar7 == 0) {
        if (*(char *)(param_1 + 1) == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b37743:
            *param_1 = 0;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar6 = (**(code **)(*piVar1 + 0x18))();
            }
            else {
              uVar6 = (uint)**(byte **)piVar1[7];
            }
            if (uVar6 == 0xffffffff) goto LAB_00b37743;
            *(char *)((int)param_1 + 5) = (char)uVar6;
          }
          *(undefined *)(param_1 + 1) = 1;
        }
        ppvVar3 = (void **)ExceptionList;
        if (*(byte *)((int)param_1 + 5) != *param_5) break;
      }
      cVar4 = *(char *)(param_1 + 1);
      if (cVar4 == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b3778d:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b3778d;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
        cVar4 = '\x01';
      }
      bVar5 = *(byte *)((int)param_1 + 5);
      if (bVar5 == *param_5) {
        FUN_005558a0(0x30);
      }
      else {
        if (cVar4 == '\0') {
          piVar1 = (int *)*param_1;
          if (piVar1 == (int *)0x0) {
LAB_00b377e5:
            *param_1 = 0;
            uVar6 = (uint)bVar5;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar6 = (**(code **)(*piVar1 + 0x18))();
              bVar5 = *(byte *)((int)param_1 + 5);
            }
            else {
              uVar6 = (uint)**(byte **)piVar1[7];
            }
            if (uVar6 == 0xffffffff) goto LAB_00b377e5;
            *(char *)((int)param_1 + 5) = (char)uVar6;
          }
          *(undefined *)(param_1 + 1) = 1;
          bVar5 = (byte)uVar6;
        }
        FUN_005558a0(bVar5);
      }
      if (*(char *)(param_1 + 1) == '\0') {
        piVar1 = (int *)*param_1;
        if (piVar1 == (int *)0x0) {
LAB_00b37833:
          *param_1 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar6 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar6 = (uint)**(byte **)piVar1[7];
          }
          if (uVar6 == 0xffffffff) goto LAB_00b37833;
          *(char *)((int)param_1 + 5) = (char)uVar6;
        }
        *(undefined *)(param_1 + 1) = 1;
      }
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b37876:
        *param_1 = 0;
        *(undefined *)(param_1 + 1) = 1;
      }
      else {
        if (*(int *)piVar1[7] == 0) {
LAB_00b37866:
          uVar6 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar7 = *(int *)piVar1[0xb];
          if (iVar7 < 1) goto LAB_00b37866;
          *(int *)piVar1[0xb] = iVar7 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar6 = (uint)*pbVar2;
        }
        if (uVar6 == 0xffffffff) goto LAB_00b37876;
        *(undefined *)(param_1 + 1) = 0;
      }
      uVar9 = uVar9 + 1;
      ppvVar3 = (void **)ExceptionList;
    } while (uVar9 < param_4);
  }
  ExceptionList = ppvVar3;
  if (param_4 <= *(uint *)(param_3 + 0x10)) {
    uStack_8 = 0;
    uVar8 = FUN_009d6100(param_3);
    ExceptionList = pvStack_10;
    return uVar8;
  }
  ExceptionList = pvStack_10;
  return 0xffffffff;
}



/* FUNCTION 23832 ; VA 0x00b378d1 ; Catch@00b378d1 */

undefined * Catch_00b378d1(void)

{
  return &LAB_00b378d7;
}



/* FUNCTION 23833 ; VA 0x00b378f0 ; FUN_00b378f0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * FUN_00b378f0(undefined4 *param_1,int param_2,char param_3)

{
  char cVar1;
  uint *puVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  undefined4 *puVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *******pppppppuVar10;
  uint uVar11;
  int iVar12;
  undefined auStack_12c [8];
  undefined8 uStack_124;
  undefined8 uStack_11c;
  int iStack_114;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined **appuStack_100 [14];
  int aiStack_c8 [2];
  undefined4 auStack_c0 [3];
  undefined4 uStack_b4;
  undefined **appuStack_b0 [18];
  uint uStack_68;
  int *piStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined4 *******apppppppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 *******pppppppuStack_28;
  int iStack_24;
  char acStack_1c [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1caa;
  pvStack_10 = ExceptionList;
  uStack_18 = (int *)CONCAT13(uStack_18._3_1_,0x6225);
  acStack_1c[0] = '%';
  acStack_1c[1] = 'B';
  acStack_1c[2] = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar11 = 1;
  uStack_8 = 0;
  pcVar7 = (char *)&uStack_18;
  uStack_14 = 1;
  iStack_34 = 0;
  uStack_30 = 0xf;
  apppppppuStack_44[0] = (undefined4 *******)((uint)apppppppuStack_44[0] & 0xffffff00);
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(&uStack_18,(int)pcVar7 - ((int)&uStack_18 + 1));
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (param_3 == '\0') {
    pcVar7 = acStack_1c;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(acStack_1c,(int)pcVar7 - (int)(acStack_1c + 1));
  }
  pppppppuStack_28 = apppppppuStack_44;
  if (0xf < uStack_30) {
    pppppppuStack_28 = apppppppuStack_44[0];
  }
  iStack_24 = iStack_34 + (int)pppppppuStack_28;
  uStack_124 = 0;
  uStack_11c = 0;
  uStack_110 = 0;
  uStack_108 = 0;
  _param_3 = 0;
  do {
    appuStack_100[0] = &PTR_018be314;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = uVar11 | 2;
    appuStack_b0[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_b4 = 0x48;
    iStack_114 = _param_3;
    FUN_00554f20(appuStack_100 + 1,0);
    uStack_8 = 4;
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -0x50
    ;
    FUN_0054ee60();
    appuStack_100[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    aiStack_c8[1] = 0;
    auStack_c0[0] = 4;
    uStack_8._0_1_ = 5;
    uStack_68 = uStack_68 & 0xffffff00;
    uStack_2c = *(undefined4 *)((int)aiStack_c8 + (int)appuStack_100[0][1]);
    FUN_016dda75(0);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_18 = DAT_01eee678;
    if (DAT_01eee674 == 0) {
      FUN_016dda75(0);
      if (DAT_01eee674 == 0) {
        DAT_01eee674 = DAT_021130c8 + 1;
        DAT_021130c8 = DAT_01eee674;
      }
      FUN_016ddacd();
    }
    uVar11 = DAT_01eee674;
    iVar3 = *(int *)(param_2 + 4);
    if ((*(uint *)(iVar3 + 0xc) <= DAT_01eee674) ||
       (*(int *)(*(int *)(iVar3 + 8) + DAT_01eee674 * 4) == 0)) {
      iVar12 = 0;
      if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00b37b36:
        if (iVar12 != 0) goto LAB_00b37bed;
      }
      else {
        iVar3 = FUN_016de17b();
        if (uVar11 < *(uint *)(iVar3 + 0xc)) {
          iVar12 = *(int *)(*(int *)(iVar3 + 8) + uVar11 * 4);
          goto LAB_00b37b36;
        }
      }
      if (uStack_18 == (int *)0x0) {
        piVar4 = (int *)FUN_01674e20(0xc);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        piStack_60 = piVar4;
        if (piVar4 == (int *)0x0) {
          piVar4 = (int *)0x0;
        }
        else {
          iVar3 = *(int *)(param_2 + 4);
          if (iVar3 == 0) {
            puVar5 = &DAT_018bc9b8;
          }
          else {
            puVar5 = *(undefined1 **)(iVar3 + 0x18);
            if (puVar5 == (undefined1 *)0x0) {
              puVar5 = (undefined1 *)(iVar3 + 0x1c);
            }
          }
          FUN_0054f870(puVar5);
          uStack_14 = uStack_14 | 8;
          piVar4[1] = 0;
          *piVar4 = (int)std::
                         time_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                         ::vftable;
          piVar4[2] = 0;
          iVar3 = thunk_FUN_0173056b();
          piVar4[2] = iVar3;
          FUN_017168b0(0);
        }
        if ((uStack_14 & 8) != 0) {
          uStack_14 = uStack_14 & 0xfffffff7;
          FUN_00550e70();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        uStack_18 = piVar4;
        FUN_016de14f(piVar4);
        (**(code **)(*piVar4 + 4))();
        DAT_01eee678 = piVar4;
      }
    }
LAB_00b37bed:
    uStack_8._0_1_ = 5;
    FUN_016ddacd();
    FUN_00b499b0(auStack_12c,uStack_68,uStack_2c,appuStack_100[0][1] + (int)appuStack_100,
                 *(undefined *)((int)auStack_c0 + (int)appuStack_100[0][1]),&uStack_124,
                 pppppppuStack_28,iStack_24);
    FUN_0058c420(&uStack_5c);
    uVar11 = uStack_14 | 0x10;
    uStack_8._0_1_ = 9;
    puVar2 = (uint *)param_1[1];
    uStack_14 = uVar11;
    if ((uint *)param_1[2] == puVar2) {
      FUN_0058d0a0(puVar2,&uStack_5c);
    }
    else {
      puVar2[4] = 0;
      puVar2[5] = 0;
      *puVar2 = uStack_5c;
      puVar2[1] = uStack_58;
      puVar2[2] = uStack_54;
      puVar2[3] = uStack_50;
      puVar2[4] = uStack_4c;
      puVar2[5] = uStack_48;
      param_1[1] = param_1[1] + 0x18;
      uStack_4c = 0;
      uStack_48 = 0xf;
      uStack_5c = uStack_5c & 0xffffff00;
    }
    uStack_8._0_1_ = 5;
    if (0xf < uStack_48) {
      uVar9 = uStack_48 + 1;
      uVar8 = uStack_5c;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_5c - 4);
        uVar9 = uStack_48 + 0x24;
        if (0x1f < (uStack_5c - uVar8) - 4) goto LAB_00b37ded;
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -0x50
    ;
    appuStack_100[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    FUN_00577980();
    iVar3 = aiStack_c8[0];
    appuStack_100[1] = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    if (aiStack_c8[0] != 0) {
      uStack_8._0_1_ = 10;
      if ((*(int **)(aiStack_c8[0] + 4) != (int *)0x0) &&
         (puVar6 = (undefined4 *)(**(code **)(**(int **)(aiStack_c8[0] + 4) + 8))(),
         puVar6 != (undefined4 *)0x0)) {
        (**(code **)*puVar6)(1);
      }
      FUN_01674ea0(iVar3,8);
    }
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -8;
    uStack_8._0_1_ = 0xb;
    appuStack_b0[0] = std::ios_base::vftable;
    FUN_016de551(appuStack_b0);
    _param_3 = _param_3 + 1;
    uStack_8._0_1_ = 1;
  } while (_param_3 < 0xc);
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    pppppppuVar10 = apppppppuStack_44[0];
    if (0xfff < uVar11) {
      pppppppuVar10 = (undefined4 *******)apppppppuStack_44[0][-1];
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_44[0] + (-4 - (int)pppppppuVar10))) {
LAB_00b37ded:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar10,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23834 ; VA 0x00b37e00 ; FUN_00b37e00 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * FUN_00b37e00(undefined4 *param_1,int param_2,char param_3)

{
  char cVar1;
  uint *puVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  undefined4 *puVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *******pppppppuVar10;
  uint uVar11;
  int iVar12;
  undefined auStack_12c [8];
  undefined8 uStack_124;
  undefined8 uStack_11c;
  undefined8 uStack_114;
  int iStack_10c;
  undefined8 uStack_108;
  undefined **appuStack_100 [14];
  int aiStack_c8 [2];
  undefined4 auStack_c0 [3];
  undefined4 uStack_b4;
  undefined **appuStack_b0 [18];
  uint uStack_68;
  int *piStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined4 *******apppppppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 *******pppppppuStack_28;
  int iStack_24;
  char acStack_1c [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1caa;
  pvStack_10 = ExceptionList;
  uStack_18 = (int *)CONCAT13(uStack_18._3_1_,0x6125);
  acStack_1c[0] = '%';
  acStack_1c[1] = 'A';
  acStack_1c[2] = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar11 = 1;
  uStack_8 = 0;
  pcVar7 = (char *)&uStack_18;
  uStack_14 = 1;
  iStack_34 = 0;
  uStack_30 = 0xf;
  apppppppuStack_44[0] = (undefined4 *******)((uint)apppppppuStack_44[0] & 0xffffff00);
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(&uStack_18,(int)pcVar7 - ((int)&uStack_18 + 1));
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (param_3 == '\0') {
    pcVar7 = acStack_1c;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(acStack_1c,(int)pcVar7 - (int)(acStack_1c + 1));
  }
  pppppppuStack_28 = apppppppuStack_44;
  if (0xf < uStack_30) {
    pppppppuStack_28 = apppppppuStack_44[0];
  }
  iStack_24 = iStack_34 + (int)pppppppuStack_28;
  uStack_124 = 0;
  uStack_11c = 0;
  uStack_114 = 0;
  uStack_108 = 0;
  _param_3 = 0;
  do {
    appuStack_100[0] = &PTR_018be314;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = uVar11 | 2;
    appuStack_b0[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    uStack_b4 = 0x48;
    iStack_10c = _param_3;
    FUN_00554f20(appuStack_100 + 1,0);
    uStack_8 = 4;
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -0x50
    ;
    FUN_0054ee60();
    appuStack_100[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    aiStack_c8[1] = 0;
    auStack_c0[0] = 4;
    uStack_8._0_1_ = 5;
    uStack_68 = uStack_68 & 0xffffff00;
    uStack_2c = *(undefined4 *)((int)aiStack_c8 + (int)appuStack_100[0][1]);
    FUN_016dda75(0);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    uStack_18 = DAT_01eee678;
    if (DAT_01eee674 == 0) {
      FUN_016dda75(0);
      if (DAT_01eee674 == 0) {
        DAT_01eee674 = DAT_021130c8 + 1;
        DAT_021130c8 = DAT_01eee674;
      }
      FUN_016ddacd();
    }
    uVar11 = DAT_01eee674;
    iVar3 = *(int *)(param_2 + 4);
    if ((*(uint *)(iVar3 + 0xc) <= DAT_01eee674) ||
       (*(int *)(*(int *)(iVar3 + 8) + DAT_01eee674 * 4) == 0)) {
      iVar12 = 0;
      if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00b38046:
        if (iVar12 != 0) goto LAB_00b380fd;
      }
      else {
        iVar3 = FUN_016de17b();
        if (uVar11 < *(uint *)(iVar3 + 0xc)) {
          iVar12 = *(int *)(*(int *)(iVar3 + 8) + uVar11 * 4);
          goto LAB_00b38046;
        }
      }
      if (uStack_18 == (int *)0x0) {
        piVar4 = (int *)FUN_01674e20(0xc);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        piStack_60 = piVar4;
        if (piVar4 == (int *)0x0) {
          piVar4 = (int *)0x0;
        }
        else {
          iVar3 = *(int *)(param_2 + 4);
          if (iVar3 == 0) {
            puVar5 = &DAT_018bc9b8;
          }
          else {
            puVar5 = *(undefined1 **)(iVar3 + 0x18);
            if (puVar5 == (undefined1 *)0x0) {
              puVar5 = (undefined1 *)(iVar3 + 0x1c);
            }
          }
          FUN_0054f870(puVar5);
          uStack_14 = uStack_14 | 8;
          piVar4[1] = 0;
          *piVar4 = (int)std::
                         time_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                         ::vftable;
          piVar4[2] = 0;
          iVar3 = thunk_FUN_0173056b();
          piVar4[2] = iVar3;
          FUN_017168b0(0);
        }
        if ((uStack_14 & 8) != 0) {
          uStack_14 = uStack_14 & 0xfffffff7;
          FUN_00550e70();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        uStack_18 = piVar4;
        FUN_016de14f(piVar4);
        (**(code **)(*piVar4 + 4))();
        DAT_01eee678 = piVar4;
      }
    }
LAB_00b380fd:
    uStack_8._0_1_ = 5;
    FUN_016ddacd();
    FUN_00b499b0(auStack_12c,uStack_68,uStack_2c,appuStack_100[0][1] + (int)appuStack_100,
                 *(undefined *)((int)auStack_c0 + (int)appuStack_100[0][1]),&uStack_124,
                 pppppppuStack_28,iStack_24);
    FUN_0058c420(&uStack_5c);
    uVar11 = uStack_14 | 0x10;
    uStack_8._0_1_ = 9;
    puVar2 = (uint *)param_1[1];
    uStack_14 = uVar11;
    if ((uint *)param_1[2] == puVar2) {
      FUN_0058d0a0(puVar2,&uStack_5c);
    }
    else {
      puVar2[4] = 0;
      puVar2[5] = 0;
      *puVar2 = uStack_5c;
      puVar2[1] = uStack_58;
      puVar2[2] = uStack_54;
      puVar2[3] = uStack_50;
      puVar2[4] = uStack_4c;
      puVar2[5] = uStack_48;
      param_1[1] = param_1[1] + 0x18;
      uStack_4c = 0;
      uStack_48 = 0xf;
      uStack_5c = uStack_5c & 0xffffff00;
    }
    uStack_8._0_1_ = 5;
    if (0xf < uStack_48) {
      uVar9 = uStack_48 + 1;
      uVar8 = uStack_5c;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_5c - 4);
        uVar9 = uStack_48 + 0x24;
        if (0x1f < (uStack_5c - uVar8) - 4) goto LAB_00b382fd;
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -0x50
    ;
    appuStack_100[1] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    FUN_00577980();
    iVar3 = aiStack_c8[0];
    appuStack_100[1] = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    if (aiStack_c8[0] != 0) {
      uStack_8._0_1_ = 10;
      if ((*(int **)(aiStack_c8[0] + 4) != (int *)0x0) &&
         (puVar6 = (undefined4 *)(**(code **)(**(int **)(aiStack_c8[0] + 4) + 8))(),
         puVar6 != (undefined4 *)0x0)) {
        (**(code **)*puVar6)(1);
      }
      FUN_01674ea0(iVar3,8);
    }
    *(undefined ***)(appuStack_100[0][1] + (int)appuStack_100) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)&uStack_108 + (int)(appuStack_100[0][1] + 4)) = appuStack_100[0][1] + -8;
    uStack_8._0_1_ = 0xb;
    appuStack_b0[0] = std::ios_base::vftable;
    FUN_016de551(appuStack_b0);
    _param_3 = _param_3 + 1;
    uStack_8._0_1_ = 1;
  } while (_param_3 < 7);
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    pppppppuVar10 = apppppppuStack_44[0];
    if (0xfff < uVar11) {
      pppppppuVar10 = (undefined4 *******)apppppppuStack_44[0][-1];
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppppppuStack_44[0] + (-4 - (int)pppppppuVar10))) {
LAB_00b382fd:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar10,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23835 ; VA 0x00b38310 ; FUN_00b38310 */

/* WARNING: Removing unreachable block (ram,0x00b383f1) */
/* WARNING: Removing unreachable block (ram,0x00b383b7) */
/* WARNING: Removing unreachable block (ram,0x00b38404) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00b38310(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  double dVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined auStack_b0 [36];
  undefined auStack_8c [36];
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_1c;
  undefined8 uStack_18;
  
  iVar6 = *param_1;
  uStack_18._4_4_ = param_1;
  iVar2 = FUN_00b38680();
  if (iVar6 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      return piVar3;
    }
  }
  iVar6 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar6 != iVar2) {
    thunk_FUN_00b38680();
    uVar5 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar5);
  }
  FUN_0060f000();
  iVar6 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar6 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (0xf < (uint)piVar3[5]) {
      piVar3 = (int *)*piVar3;
    }
    lVar9 = FUN_01717857(piVar3);
    uStack_4c = (undefined4)((ulonglong)lVar9 >> 0x20);
    uStack_44 = (undefined4)lVar9;
    if (0xf6d3d9496bff < lVar9 + 0x105c07299000U) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error interpreting timestampMillis as a precise point in time. Fields out of range. UnixTimestampMillis should be between %lld and %lld."
                   ,0xf8d67000,0xffffefa3,0xd21fdbff,58999);
    }
    uVar10 = FUN_016f3900(lVar9,1000,0);
    iStack_1c = (int)(uVar10 >> 0x20);
    uStack_3c = (undefined4)uVar10;
    if (0x3f3016db7f < uVar10 + 0x430229a00) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error interpreting timestamp as a precise point in time. Fields out of range. UnixTimestamp should be between %lld and %lld."
                   ,0xcfdd6600,0xfffffffb,0xfff4417f,0x3a);
    }
    if (uVar10 < 0x7933fff80) {
      FUN_00b45090(auStack_b0,auStack_8c,uVar10);
      puVar4 = (undefined4 *)FUN_00b48520(auStack_58,auStack_8c);
      uVar5 = *puVar4;
      uVar7 = puVar4[1];
      puVar4 = (undefined4 *)FUN_00b48520(auStack_60,auStack_b0);
      uStack_18._0_4_ = *puVar4;
      piStack_34 = (int *)puVar4[1];
      param_1 = uStack_18._4_4_;
      uStack_30 = uVar5;
      uStack_2c = uVar7;
      uStack_24 = (undefined4)uStack_18;
    }
    else {
      FUN_00b44e20(&uStack_18,uVar10);
      puVar4 = (undefined4 *)FUN_00b4b490(auStack_68,(undefined4)uStack_18,uStack_18._4_4_);
      uStack_30 = *puVar4;
      uStack_2c = puVar4[1];
      piStack_34 = uStack_18._4_4_;
    }
    uStack_18 = (double)CONCAT44(piStack_34,(undefined4)uStack_18);
    uStack_38 = (undefined4)uStack_18;
    FUN_00b4a230(&iStack_28);
    dVar8 = DAT_018d8a10;
    FUN_01726ab0();
    uStack_18 = dVar8;
    FUN_016f39b0(uStack_3c,iStack_1c,1000,0);
    FUN_016f4020();
    uVar5 = FUN_005ef640(0,0,0,(int)(uStack_18 * dVar8),(int)(uStack_18 * dVar8) >> 0x1f);
    piVar3 = (int *)FUN_00b3e000(auStack_48,uVar5);
    iStack_28 = *piVar3;
    uStack_18._4_4_ = (int *)piVar3[1];
    piVar3 = (int *)FUN_00b3e000(auStack_40,uVar5);
    iStack_1c = piVar3[1];
    iVar6 = *piVar3;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead2f8)
       && (FUN_016f3809(&DAT_01ead2f8), DAT_01ead2f8 == -1)) {
      _DAT_01ead2ec = FUN_00619f20;
      _DAT_01ead2f0 = FUN_00619f20;
      _DAT_01ead2f4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead2f8);
    }
    puVar1 = (undefined *)param_1[1];
    if (puVar1 == &DAT_01ead2ec) {
      param_1[4] = iStack_28;
      param_1[2] = iVar6;
      param_1[3] = iStack_1c;
      param_1[5] = (int)uStack_18._4_4_;
    }
    else {
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(param_1 + 2);
      }
      param_1[4] = iStack_28;
      param_1[2] = iVar6;
      param_1[3] = iStack_1c;
      param_1[5] = (int)uStack_18._4_4_;
      param_1[1] = (int)&DAT_01ead2ec;
    }
    iVar6 = FUN_00b38680();
    *param_1 = iVar6;
    iVar2 = FUN_00b38680();
    if (iVar6 == iVar2) {
      piVar3 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar3 = (int *)0x0;
      }
      return piVar3;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23836 ; VA 0x00b38680 ; FUN_00b38680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b38680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1ccc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee664) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eee664);
    if (DAT_01eee664 == -1) {
      uStack_8 = 0;
      FUN_00888860("DateTime",0x3c,0,0,0);
      _DAT_01eee640 = RBX::Reflection::TType<class_RBX::DateTime>::vftable;
      FUN_016f3654(&LAB_0188db50);
      FUN_016f37bf(&DAT_01eee664);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eee640;
}



/* FUNCTION 23837 ; VA 0x00b38720 ; FUN_00b38720 */

bool FUN_00b38720(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  if (DAT_01eee670 == 0) {
    FUN_016dda75(0);
    if (DAT_01eee670 == 0) {
      DAT_01eee670 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee670;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01eee670;
  iVar2 = *(int *)(param_1 + 4);
  if ((*(uint *)(iVar2 + 0xc) <= DAT_01eee670) ||
     (bVar4 = *(int *)(*(int *)(iVar2 + 8) + DAT_01eee670 * 4) == 0, bVar4)) {
    iVar3 = 0;
    if (*(char *)(iVar2 + 0x14) != '\0') {
      iVar2 = FUN_016de17b();
      if (uVar1 < *(uint *)(iVar2 + 0xc)) {
        iVar3 = *(int *)(*(int *)(iVar2 + 8) + uVar1 * 4);
      }
      else {
        iVar3 = 0;
      }
    }
    bVar4 = iVar3 == 0;
  }
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return !bVar4;
}



/* FUNCTION 23838 ; VA 0x00b387e0 ; FUN_00b387e0 */

void __thiscall
FUN_00b387e0(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined *param_6,undefined *param_7)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  undefined auStack_30 [12];
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1ce0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc4;
  uStack_20 = param_5 - param_1[3];
  uVar8 = param_1[4];
  if (param_6 != param_7) {
    piStack_1c = param_1;
    uStack_18 = uVar8;
    if (uVar8 >> 1 < uStack_20) {
      uStack_8 = 2;
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffc4;
      for (; iVar4 = param_1[3], param_6 != param_7; param_6 = param_6 + 1) {
        if (((iVar4 + uVar8 & 0xf) == 0) && ((uint)param_1[2] <= uVar8 + 0x10 >> 4)) {
          FUN_00638430(1);
        }
        uStack_24 = param_1[2] * 0x10 - 1U & param_1[3];
        param_1[3] = uStack_24;
        uStack_24 = param_1[4] + uStack_24;
        iVar4 = (uStack_24 >> 4 & param_1[2] - 1U) * 4;
        iVar10 = param_1[1];
        if (*(int *)(iVar4 + iVar10) == 0) {
          uVar1 = FUN_01674e20(0x10);
          *(undefined4 *)(iVar4 + param_1[1]) = uVar1;
          iVar10 = param_1[1];
        }
        *(undefined *)((uStack_24 & 0xf) + *(int *)(iVar4 + iVar10)) = *param_6;
        param_1[4] = param_1[4] + 1;
        uVar8 = param_1[4];
      }
      piVar6 = (int *)*param_1;
      iVar5 = iVar4 + uVar8;
      iVar10 = *param_1;
      piVar7 = (int *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      iVar2 = iVar4 + uStack_18;
      uVar1 = 0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        uVar1 = *(undefined4 *)*piVar7;
      }
      puVar3 = (undefined4 *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        puVar3 = *(undefined4 **)*piVar6;
      }
      iVar4 = uStack_20 + iVar4;
      iVar9 = 0;
      if ((puVar3 != (undefined4 *)0x0) && ((int *)*puVar3 != (int *)0x0)) {
        iVar9 = *(int *)*puVar3;
      }
    }
    else {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      for (; param_6 != param_7; param_6 = param_6 + 1) {
        if (((*(byte *)(param_1 + 3) & 0xf) == 0) && ((uint)param_1[2] <= uVar8 + 0x10 >> 4)) {
          FUN_00638430(1);
        }
        uVar8 = param_1[2] * 0x10 - 1U & param_1[3];
        param_1[3] = uVar8;
        if (uVar8 == 0) {
          uVar8 = param_1[2] << 4;
        }
        uVar8 = uVar8 - 1;
        uStack_24 = (uVar8 >> 4 & param_1[2] - 1U) * 4;
        iVar4 = param_1[1];
        if (*(int *)(iVar4 + uStack_24) == 0) {
          uVar1 = FUN_01674e20(0x10);
          *(undefined4 *)(uStack_24 + param_1[1]) = uVar1;
          iVar4 = param_1[1];
        }
        *(undefined *)((uVar8 & 0xf) + *(int *)(uStack_24 + iVar4)) = *param_6;
        param_1[3] = uVar8;
        param_1[4] = param_1[4] + 1;
        uVar8 = param_1[4];
      }
      iVar2 = uVar8 - uStack_18;
      piVar7 = (int *)0x0;
      piVar6 = (int *)*param_1;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      puVar3 = (undefined4 *)0x0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        puVar3 = *(undefined4 **)*piVar7;
      }
      if (puVar3 == (undefined4 *)0x0) {
        uVar1 = 0;
      }
      else {
        uVar1 = *puVar3;
      }
      if (piVar6 == (int *)0x0) {
        iVar4 = 0;
      }
      else {
        iVar4 = *piVar6;
      }
      FUN_006337c0(iVar4,param_1[3],uVar1,iVar2 + param_1[3]);
      piVar6 = (int *)*param_1;
      puVar3 = (undefined4 *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        puVar3 = *(undefined4 **)*piVar6;
      }
      iVar2 = iVar2 + param_1[3];
      iVar5 = iVar2 + uStack_20;
      iVar10 = 0;
      if ((puVar3 != (undefined4 *)0x0) && ((int *)*puVar3 != (int *)0x0)) {
        iVar10 = *(int *)*puVar3;
      }
      piVar7 = (int *)0x0;
      if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
        piVar7 = *(int **)*piVar6;
      }
      uVar1 = 0;
      if ((piVar7 != (int *)0x0) && ((undefined4 *)*piVar7 != (undefined4 *)0x0)) {
        uVar1 = *(undefined4 *)*piVar7;
      }
      iVar4 = piStack_1c[3];
      iVar9 = *piStack_1c;
    }
    param_1 = piStack_1c;
    FUN_00636d10(auStack_30,iVar9,0,iVar4,uVar1,0,iVar2,iVar10,0,iVar5);
  }
  piVar6 = (int *)0x0;
  iVar4 = param_1[3];
  if (((int *)*param_1 != (int *)0x0) &&
     (puVar3 = *(undefined4 **)*param_1, puVar3 != (undefined4 *)0x0)) {
    piVar6 = (int *)*puVar3;
  }
  *param_2 = 0;
  param_2[1] = 0;
  if ((piVar6 != (int *)0x0) && ((undefined4 *)*piVar6 != (undefined4 *)0x0)) {
    *param_2 = *(undefined4 *)*piVar6;
  }
  param_2[2] = iVar4 + uStack_20;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23839 ; VA 0x00b388d5 ; Catch_All@00b388d5 */

void Catch_All_00b388d5(void)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int unaff_EBP;
  
  iVar2 = *(int *)(unaff_EBP + -0x18);
  uVar3 = *(uint *)(unaff_EBP + -0x14);
  uVar1 = *(uint *)(iVar2 + 0x10);
  while (uVar3 < uVar1) {
    FUN_0063c960();
    uVar1 = *(uint *)(iVar2 + 0x10);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23840 ; VA 0x00b38a7d ; Catch_All@00b38a7d */

void Catch_All_00b38a7d(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int unaff_EBP;
  
  iVar3 = *(int *)(unaff_EBP + -0x18);
  uVar4 = *(uint *)(unaff_EBP + -0x14);
  uVar2 = *(uint *)(iVar3 + 0x10);
  while (uVar4 < uVar2) {
    piVar1 = (int *)(iVar3 + 0x10);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(iVar3 + 0xc) = 0;
    }
    uVar2 = *(uint *)(iVar3 + 0x10);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 23841 ; VA 0x00b38bb0 ; FUN_00b38bb0 */

int FUN_00b38bb0(char *param_1)

{
  char cVar1;
  code *pcVar2;
  bool bVar3;
  undefined4 uVar4;
  ushort uVar6;
  int iVar5;
  char *pcVar7;
  
  pcVar7 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar7 = *(char **)param_1;
  }
  if (pcVar7 != pcVar7 + *(int *)(param_1 + 0x10)) {
    cVar1 = *pcVar7;
    uVar4 = FUN_009d7350();
    uVar6 = (ushort)((uint)uVar4 >> 0x10);
    if (cVar1 == '-') {
      if ((char)uVar4 == '\0') {
        bVar3 = false;
      }
      else {
        uVar6 = 0;
        bVar3 = true;
      }
    }
    else if ((char)uVar4 == '\0') {
      bVar3 = false;
    }
    else {
      uVar6 = 0;
      bVar3 = true;
    }
    if (bVar3) {
      return (uint)uVar6 << 0x10;
    }
  }
  FUN_00b38d60();
  pcVar2 = (code *)swi(3);
  iVar5 = (*pcVar2)();
  return iVar5;
}



/* FUNCTION 23842 ; VA 0x00b38c50 ; FUN_00b38c50 */

void FUN_00b38c50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  pcVar2 = (char *)*param_2;
  do {
    pcVar3 = pcVar2;
    pcVar2 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_00b36aa0(param_1,CONCAT44(pcVar3,(char *)*param_2));
  return;
}



/* FUNCTION 23843 ; VA 0x00b38cc0 ; FUN_00b38cc0 */

void FUN_00b38cc0(undefined4 param_1,undefined4 *param_2)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = (char *)*param_2;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_00635b90(param_1,CONCAT44(pcVar2,(char *)*param_2));
  return;
}



/* FUNCTION 23844 ; VA 0x00b38d30 ; FUN_00b38d30 */

void FUN_00b38d30(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 0x18) = *param_2;
  return;
}



/* FUNCTION 23845 ; VA 0x00b38d40 ; FUN_00b38d40 */

void FUN_00b38d40(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 0x14) = *param_2;
  return;
}



/* FUNCTION 23846 ; VA 0x00b38d50 ; FUN_00b38d50 */

void FUN_00b38d50(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 0x1c) = *param_2;
  return;
}



/* FUNCTION 23847 ; VA 0x00b38d60 ; FUN_00b38d60 */

void FUN_00b38d60(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d6228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00637490(&std::
                        basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        ::RTTI_Type_Descriptor,&TypeDescriptor_01de4dd0);
  uStack_8 = 0;
  FUN_00636dc0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 23848 ; VA 0x00b38da0 ; FUN_00b38da0 */

void FUN_00b38da0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1cf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b36620(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b36540(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b884);
}



/* FUNCTION 23849 ; VA 0x00b38df0 ; FUN_00b38df0 */

void FUN_00b38df0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b366c0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b36000(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b77c);
}



/* FUNCTION 23850 ; VA 0x00b38e40 ; FUN_00b38e40 */

void FUN_00b38e40(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b36720(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b360e0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b974);
}



/* FUNCTION 23851 ; VA 0x00b38e90 ; FUN_00b38e90 */

void FUN_00b38e90(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1d58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b36780(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b361c0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b66c);
}



/* FUNCTION 23852 ; VA 0x00b38ee0 ; FUN_00b38ee0 */

void FUN_00b38ee0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1d78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b367e0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b362a0(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b8ec);
}



/* FUNCTION 23853 ; VA 0x00b38f30 ; FUN_00b38f30 */

void FUN_00b38f30(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1d98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b36840(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b36380(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b6f4);
}



/* FUNCTION 23854 ; VA 0x00b38f80 ; FUN_00b38f80 */

void FUN_00b38f80(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1db8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b368a0(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b36460(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b800);
}



/* FUNCTION 23855 ; VA 0x00b38fd0 ; FUN_00b38fd0 */

void FUN_00b38fd0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1cf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b36900(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00b36540(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c9b884);
}



/* FUNCTION 23856 ; VA 0x00b39020 ; FUN_00b39020 */

void FUN_00b39020(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_3c [44];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1dd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0054d840(param_4);
  uVar3 = FUN_0054d840(param_3);
  uVar4 = FUN_0054d840(param_2);
  uVar5 = FUN_00b36900(auStack_3c,param_1);
  uStack_8 = 0;
  uVar4 = FUN_00b38d40(uVar5,uVar4);
  uVar3 = FUN_00b38d30(uVar4,uVar3);
  uVar2 = FUN_00b38d50(uVar3,uVar2);
  FUN_00b38da0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 23857 ; VA 0x00b390a0 ; FUN_00b390a0 */

int FUN_00b390a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined auStack_24 [20];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1df8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  iVar2 = DAT_01eee680;
  uStack_8 = 0;
  if (DAT_01eee670 == 0) {
    FUN_016dda75(0);
    if (DAT_01eee670 == 0) {
      DAT_01eee670 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee670;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01eee670;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01eee670 < *(uint *)(iVar3 + 0xc)) {
    iVar4 = *(int *)(*(int *)(iVar3 + 8) + DAT_01eee670 * 4);
    if (iVar4 != 0) goto LAB_00b39123;
  }
  else {
    iVar4 = 0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00b39156:
    if (iVar4 != 0) goto LAB_00b39123;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      iVar4 = *(int *)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_00b39156;
    }
  }
  iVar4 = iVar2;
  if (iVar2 == 0) {
    FUN_0054fc60();
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c24924);
  }
LAB_00b39123:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23858 ; VA 0x00b39180 ; FUN_00b39180 */

int * FUN_00b39180(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1e2f;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01eee678;
  uStack_8 = 0;
  if (DAT_01eee674 == 0) {
    FUN_016dda75(0);
    if (DAT_01eee674 == 0) {
      DAT_01eee674 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eee674;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01eee674;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01eee674 < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01eee674 * 4);
    if (piVar4 != (int *)0x0) goto LAB_00b392cd;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00b39223:
    if (piVar4 != (int *)0x0) goto LAB_00b392cd;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_00b39223;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)FUN_01674e20(0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        puVar5 = &DAT_018bc9b8;
      }
      else {
        puVar5 = *(undefined1 **)(iVar3 + 0x18);
        if (puVar5 == (undefined1 *)0x0) {
          puVar5 = (undefined1 *)(iVar3 + 0x1c);
        }
      }
      FUN_0054f870(puVar5);
      piVar4[1] = 0;
      bVar6 = true;
      *piVar4 = (int)std::
                     time_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                     ::vftable;
      piVar4[2] = 0;
      iVar3 = thunk_FUN_0173056b();
      piVar4[2] = iVar3;
      FUN_017168b0(0);
    }
    if (bVar6) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016de14f(piVar4);
    (**(code **)(*piVar4 + 4))();
    DAT_01eee678 = piVar4;
  }
LAB_00b392cd:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 23859 ; VA 0x00b392f0 ; FUN_00b392f0 */

undefined4 FUN_00b392f0(int *param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined2 uVar6;
  undefined2 extraout_var;
  undefined2 uVar7;
  uint uVar8;
  uint auStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_14 = 0xf;
  iStack_18 = 0;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00a8d280(param_1,param_2);
  cVar3 = (char)iVar4;
  for (uVar8 = 0; (cVar3 == '\0' && (uVar8 < param_3)); uVar8 = uVar8 + 1) {
    if (*(char *)(param_1 + 1) == '\0') {
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b3937a:
        *param_1 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar5 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar5 = (uint)**(byte **)piVar1[7];
        }
        if (uVar5 == 0xffffffff) goto LAB_00b3937a;
        *(char *)((int)param_1 + 5) = (char)uVar5;
      }
      *(undefined *)(param_1 + 1) = 1;
    }
    iVar4 = FUN_0171db62((int)*(char *)((int)param_1 + 5));
    if (iVar4 == 0) break;
    if (*(char *)(param_1 + 1) == '\0') {
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b393ca:
        *param_1 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar5 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar5 = (uint)**(byte **)piVar1[7];
        }
        if (uVar5 == 0xffffffff) goto LAB_00b393ca;
        *(char *)((int)param_1 + 5) = (char)uVar5;
      }
      *(undefined *)(param_1 + 1) = 1;
    }
    FUN_005558a0(*(undefined *)((int)param_1 + 5));
    piVar1 = (int *)*param_1;
    if (piVar1 == (int *)0x0) {
LAB_00b3941a:
      *param_1 = 0;
      *(undefined *)(param_1 + 1) = 1;
    }
    else {
      if (*(int *)piVar1[7] == 0) {
LAB_00b3940a:
        uVar5 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar4 = *(int *)piVar1[0xb];
        if (iVar4 < 1) goto LAB_00b3940a;
        *(int *)piVar1[0xb] = iVar4 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar5 = (uint)*pbVar2;
      }
      if (uVar5 == 0xffffffff) goto LAB_00b3941a;
      *(undefined *)(param_1 + 1) = 0;
    }
    iVar4 = FUN_00a8d280(param_1,param_2);
    cVar3 = (char)iVar4;
  }
  uVar7 = 0xffff;
  if (iStack_18 != 0) {
    iVar4 = FUN_00b38bb0(auStack_28);
    uVar7 = (undefined2)iVar4;
  }
  uVar6 = (undefined2)((uint)iVar4 >> 0x10);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar5);
    uVar6 = extraout_var;
  }
  ExceptionList = pvStack_10;
  return CONCAT22(uVar6,uVar7);
}



/* FUNCTION 23860 ; VA 0x00b394a0 ; FUN_00b394a0 */

undefined4 * __thiscall FUN_00b394a0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1e64;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01952784;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::ambiguous_result::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23861 ; VA 0x00b39580 ; FUN_00b39580 */

undefined4 * __thiscall FUN_00b39580(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1e94;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01952870;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_adjustment::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23862 ; VA 0x00b39660 ; FUN_00b39660 */

undefined4 * __thiscall FUN_00b39660(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1ec4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01951d88;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_year::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23863 ; VA 0x00b39740 ; FUN_00b39740 */

undefined4 * __thiscall FUN_00b39740(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1ef4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01952830;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_offset::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23864 ; VA 0x00b39820 ; FUN_00b39820 */

undefined4 * __thiscall FUN_00b39820(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1f24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01951dc8;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_weekday::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23865 ; VA 0x00b39900 ; FUN_00b39900 */

undefined4 * __thiscall FUN_00b39900(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f1f54;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_019527c4;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::time_label_invalid::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23866 ; VA 0x00b399e0 ; FUN_00b399e0 */

undefined4 * __thiscall FUN_00b399e0(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793fe4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_019527f0;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
       ::vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23867 ; VA 0x00b39ac0 ; FUN_00b39ac0 */

ushort * __thiscall FUN_00b39ac0(ushort *param_1,uint param_2)

{
  code *pcVar1;
  ushort *puVar2;
  uint extraout_EDX;
  
  *param_1 = 1;
  if ((param_2 & 0xffff) + 1 < 2) {
    FUN_00b471d0(1,param_2,0);
    param_2 = extraout_EDX;
  }
  else if ((ushort)param_2 < 0x16f) {
    *param_1 = (ushort)param_2;
    return param_1;
  }
  FUN_00b471d0(1,param_2,1);
  pcVar1 = (code *)swi(3);
  puVar2 = (ushort *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 23868 ; VA 0x00b39b00 ; FUN_00b39b00 */

undefined4 * __thiscall FUN_00b39b00(undefined4 *param_1,undefined4 param_2)

{
  char *pcVar1;
  char *pcVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f1fc3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = param_2;
  *param_1 = boost::date_time::
             date_facet<class_boost::gregorian::date,char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
             ::vftable;
  param_1[6] = 0;
  param_1[7] = 0xf;
  uStack_8 = 0;
  *(undefined *)(param_1 + 2) = 0;
  pcVar1 = "%Y-%b-%d";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522f0,pcVar2 + -0x19522f0);
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  uStack_8._0_1_ = 1;
  *(undefined *)(param_1 + 8) = 0;
  pcVar1 = "%b";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522d8,pcVar2 + -0x19522d8);
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  uStack_8._0_1_ = 2;
  *(undefined *)(param_1 + 0xe) = 0;
  pcVar1 = "%a";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522d0,pcVar2 + -0x19522d0);
  param_1[0x14] = 1;
  param_1[0x19] = 0;
  param_1[0x1a] = 0xf;
  uStack_8._0_1_ = 3;
  *(undefined *)(param_1 + 0x15) = 0;
  pcVar1 = "/";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_01952340,pcVar2 + -0x1952340);
  param_1[0x1f] = 0;
  param_1[0x20] = 0xf;
  uStack_8._0_1_ = 4;
  *(undefined *)(param_1 + 0x1b) = 0;
  pcVar1 = "[";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_01952344,pcVar2 + -0x1952344);
  param_1[0x25] = 0;
  param_1[0x26] = 0xf;
  uStack_8._0_1_ = 5;
  *(undefined *)(param_1 + 0x21) = 0;
  pcVar1 = ")";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_01952348,pcVar2 + -0x1952348);
  param_1[0x2b] = 0;
  param_1[0x2c] = 0xf;
  uStack_8._0_1_ = 6;
  *(undefined *)(param_1 + 0x27) = 0;
  pcVar1 = "]";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0195234c,pcVar2 + -0x195234c);
  uStack_8._0_1_ = 7;
  FUN_00b39f50();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_00b3bcb0();
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23869 ; VA 0x00b39d60 ; FUN_00b39d60 */

undefined4 * __thiscall FUN_00b39d60(undefined4 *param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 *in_stack_00000084;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f2054;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = in_stack_00000084;
  *param_1 = boost::date_time::
             date_facet<class_boost::gregorian::date,char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
             ::vftable;
  param_1[6] = 0;
  param_1[7] = 0xf;
  uStack_8 = 3;
  uStack_7 = 0;
  *(undefined *)(param_1 + 2) = 0;
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  uStack_8 = 4;
  *(undefined *)(param_1 + 8) = 0;
  pcVar3 = "%b";
  do {
    pcVar2 = pcVar3;
    pcVar3 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522d8,pcVar2 + -0x19522d8);
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  uStack_8 = 5;
  *(undefined *)(param_1 + 0xe) = 0;
  pcVar3 = "%a";
  do {
    pcVar2 = pcVar3;
    pcVar3 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522d0,pcVar2 + -0x19522d0);
  in_stack_00000084 = param_1 + 0x14;
  *in_stack_00000084 = param_3;
  uStack_8 = 6;
  FUN_0054ef60(&stack0x0000000c);
  uStack_8 = 7;
  FUN_0054ef60(&stack0x00000024);
  uStack_8 = 8;
  FUN_0054ef60(&stack0x0000003c);
  uStack_8 = 9;
  FUN_0054ef60(&stack0x00000054);
  uStack_8 = 10;
  FUN_00637260(&stack0x00000078);
  _uStack_8 = CONCAT31(uStack_7,0xb);
  FUN_00637260(&stack0x0000006c);
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  FUN_00b3d950();
  FUN_00577a40();
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23870 ; VA 0x00b39f50 ; FUN_00b39f50 */

undefined4 * __fastcall FUN_00b39f50(undefined4 *param_1)

{
  uint *puVar1;
  undefined uVar2;
  char *pcVar3;
  uint uVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f20b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  puStack_14 = param_1;
  FUN_00b3fc00(9);
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "first";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_019522fc,pcVar5 + -0x19522fc);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 1;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "second";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_01952304,pcVar5 + -0x1952304);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 2;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "third";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_0195230c,pcVar5 + -0x195230c);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 3;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "fourth";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_01952314,pcVar5 + -0x1952314);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 4;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "fifth";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_0195231c,pcVar5 + -0x195231c);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 5;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "last";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_01952324,pcVar5 + -0x1952324);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 6;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "before";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_0195232c,pcVar5 + -0x195232c);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 7;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
    uVar7 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar7 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar7) {
    uVar6 = uVar7 + 1;
    uVar4 = uStack_2c;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar7 + 0x24;
      if (0x1f < (uStack_2c - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "after";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_01952334,pcVar5 + -0x1952334);
  uVar7 = uStack_2c;
  puVar1 = (uint *)param_1[1];
  uStack_8._0_1_ = 8;
  if ((uint *)param_1[2] == puVar1) {
    FUN_0058d0a0(puVar1,&uStack_2c);
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar1 = uVar7;
    puVar1[1] = uStack_28;
    puVar1[2] = uStack_24;
    puVar1[3] = uStack_20;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uStack_1c = 0;
    uStack_18 = 0xf;
  }
  uStack_8._0_1_ = 0;
  FUN_005507b0();
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar3 = "of";
  do {
    pcVar5 = pcVar3;
    pcVar3 = pcVar5 + 1;
  } while (*pcVar5 != '\0');
  FUN_005542c0(&DAT_0195233c,pcVar5 + -0x195233c);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00590440(&uStack_2c);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23871 ; VA 0x00b3a500 ; FUN_00b3a500 */

undefined4 * __fastcall FUN_00b3a500(undefined4 *param_1)

{
  char *pcVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2122;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uVar2 = FUN_00575ab0();
  *param_1 = uVar2;
  *(undefined2 *)(param_1 + 2) = 0xffff;
  uStack_8 = 0;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  pcVar1 = "of";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952134,pcVar3 + -0x1952134);
  uStack_8._0_1_ = 1;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  pcVar1 = "after";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_0195212c,pcVar3 + -0x195212c);
  uStack_8._0_1_ = 2;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  pcVar1 = "before";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952124,pcVar3 + -0x1952124);
  uStack_8._0_1_ = 3;
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  pcVar1 = "last";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_0195211c,pcVar3 + -0x195211c);
  uStack_8._0_1_ = 4;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  pcVar1 = "fifth";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952114,pcVar3 + -0x1952114);
  uStack_8._0_1_ = 5;
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  pcVar1 = "fourth";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_0195210c,pcVar3 + -0x195210c);
  uStack_8._0_1_ = 6;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar1 = "third";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952104,pcVar3 + -0x1952104);
  uStack_8._0_1_ = 7;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar1 = "second";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_019520fc,pcVar3 + -0x19520fc);
  uStack_8._0_1_ = 8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar1 = "first";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_019520f4,pcVar3 + -0x19520f4);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00b424a0(auStack_28,auStack_40,auStack_58,auStack_70,auStack_88,auStack_a0,auStack_b8,
               auStack_d0,auStack_e8);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    uVar4 = auStack_40[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_40[0] - 4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_44) {
    uVar5 = uStack_44 + 1;
    uVar4 = auStack_58[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_58[0] - 4);
      uVar5 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_5c) {
    uVar5 = uStack_5c + 1;
    uVar4 = auStack_70[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_70[0] - 4);
      uVar5 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_74) {
    uVar5 = uStack_74 + 1;
    uVar4 = auStack_88[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_88[0] - 4);
      uVar5 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_8c) {
    uVar5 = uStack_8c + 1;
    uVar4 = auStack_a0[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_a0[0] - 4);
      uVar5 = uStack_8c + 0x24;
      if (0x1f < (auStack_a0[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_a4) {
    uVar5 = uStack_a4 + 1;
    uVar4 = auStack_b8[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_b8[0] - 4);
      uVar5 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_bc) {
    uVar5 = uStack_bc + 1;
    uVar4 = auStack_d0[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_d0[0] - 4);
      uVar5 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_d4) {
    uVar5 = uStack_d4 + 1;
    uVar4 = auStack_e8[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_e8[0] - 4);
      uVar5 = uStack_d4 + 0x24;
      if (0x1f < (auStack_e8[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23872 ; VA 0x00b3a9d0 ; FUN_00b3a9d0 */

undefined4 * __thiscall FUN_00b3a9d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char *pcVar1;
  undefined4 uVar2;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined1 *puStack_28;
  char *pcStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f21b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = param_3;
  pcStack_24 = (char *)param_2;
  uStack_8 = 0;
  *param_1 = boost::date_time::
             date_input_facet<class_boost::gregorian::date,char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
             ::vftable;
  puStack_28 = (undefined1 *)0xb3aa14;
  FUN_0054ef60();
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  uStack_8._0_1_ = 1;
  *(undefined *)(param_1 + 8) = 0;
  pcVar1 = "%b";
  do {
    pcStack_24 = pcVar1;
    pcVar1 = pcStack_24 + 1;
  } while (*pcStack_24 != '\0');
  pcStack_24 = pcStack_24 + -0x19520d8;
  puStack_28 = &DAT_019520d8;
  puStack_2c = (undefined *)0xb3aa49;
  FUN_005542c0();
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  uStack_8._0_1_ = 2;
  *(undefined *)(param_1 + 0xe) = 0;
  pcVar1 = "%a";
  do {
    pcStack_24 = pcVar1;
    pcVar1 = pcStack_24 + 1;
  } while (*pcStack_24 != '\0');
  pcStack_24 = pcStack_24 + -0x19520d4;
  puStack_28 = &DAT_019520d4;
  puStack_2c = (undefined *)0xb3aa84;
  FUN_005542c0();
  param_1[0x18] = 0;
  param_1[0x19] = 0xf;
  uStack_8._0_1_ = 3;
  *(undefined *)(param_1 + 0x14) = 0;
  pcVar1 = "%Y";
  do {
    pcStack_24 = pcVar1;
    pcVar1 = pcStack_24 + 1;
  } while (*pcStack_24 != '\0');
  pcStack_24 = pcStack_24 + -0x19520dc;
  puStack_28 = &DAT_019520dc;
  puStack_2c = (undefined *)0xb3aab8;
  FUN_005542c0();
  uStack_8._0_1_ = 4;
  pcStack_24 = (char *)0xb3aac7;
  uVar2 = FUN_016de368();
  puStack_28 = (undefined1 *)0xb3aad3;
  pcStack_24 = (char *)(param_1 + 2);
  FUN_0054ef60();
  pcStack_24 = (char *)0x1;
  uStack_8._0_1_ = 5;
  FUN_00b378f0(&puStack_30,uVar2,1);
  FUN_00b3c0c0();
  pcStack_24 = (char *)0x1;
  uStack_8._0_1_ = 6;
  FUN_00b378f0(&puStack_30,uVar2,0);
  FUN_00b3c0c0();
  pcStack_24 = (char *)0x0;
  uStack_8._0_1_ = 7;
  FUN_00b37e00(&puStack_30,uVar2,1);
  FUN_00b3c0c0();
  pcStack_24 = (char *)0x0;
  uStack_8._0_1_ = 8;
  FUN_00b37e00(&puStack_30,uVar2,0);
  FUN_00b3c0c0();
  uStack_8._0_1_ = 9;
  pcStack_24 = (char *)0xb3ab61;
  FUN_00b3a500();
  pcStack_24 = "]";
  puStack_28 = &DAT_01952140;
  puStack_2c = &DAT_0195213c;
  puStack_30 = &DAT_01952138;
  uStack_8._0_1_ = 10;
  FUN_00b3b480(1);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  pcStack_24 = (char *)0xb3ab95;
  FUN_00b3bdc0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23873 ; VA 0x00b3abb0 ; FUN_00b3abb0 */

undefined4 * __thiscall FUN_00b3abb0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f21c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::ambiguous_result::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23874 ; VA 0x00b3ac50 ; FUN_00b3ac50 */

undefined4 * __thiscall FUN_00b3ac50(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f21e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_adjustment::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::bad_adjustment>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23875 ; VA 0x00b3acf0 ; FUN_00b3acf0 */

undefined4 * __thiscall FUN_00b3acf0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2208;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_year::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>
             ::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::gregorian::bad_day_of_year>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23876 ; VA 0x00b3ad90 ; FUN_00b3ad90 */

undefined4 * __thiscall FUN_00b3ad90(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_offset::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23877 ; VA 0x00b3ae30 ; FUN_00b3ae30 */

undefined4 * __thiscall FUN_00b3ae30(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_weekday::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
             vftable;
  param_1[3] = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
               vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23878 ; VA 0x00b3aed0 ; FUN_00b3aed0 */

undefined4 * __thiscall FUN_00b3aed0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2268;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::time_label_invalid::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  param_1[3] = boost::exception_detail::
               error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23879 ; VA 0x00b3af70 ; FUN_00b3af70 */

undefined4 * __thiscall FUN_00b3af70(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794238;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23880 ; VA 0x00b3b010 ; FUN_00b3b010 */

undefined4 * __thiscall
FUN_00b3b010(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6,int param_7)

{
  int *piVar1;
  code *pcVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined auStack_dc [152];
  undefined auStack_44 [24];
  undefined4 *puStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f22c9;
  pvStack_10 = ExceptionList;
  uStack_24 = param_3;
  uStack_20 = param_4;
  iStack_28 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_2c = param_1;
  FUN_005672c0(&iStack_28,&uStack_24);
  *param_1 = uStack_18;
  param_1[1] = uStack_14;
  param_1[2] = param_5;
  param_1[3] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00b40ce0(param_2,param_3,param_4,param_5,param_6);
  if (iVar4 == 2) {
    if (param_7 == 0) {
      FUN_00565520(2,1);
      uStack_8._0_1_ = 2;
      uVar5 = FUN_00558890(auStack_dc,"time given: ",&param_2,0x20,&param_3);
      uVar5 = FUN_00b34520(uVar5);
      uVar5 = FUN_005ed940(uVar5);
      FUN_00b34b30(uVar5);
      uVar5 = FUN_0058c400(auStack_44);
      uStack_8._0_1_ = 3;
      uVar5 = FUN_00b3c840(uVar5);
      uStack_8._0_1_ = 4;
      FUN_00b38df0(uVar5);
LAB_00b3b247:
      FUN_00565520(2,1);
      uStack_8._0_1_ = 5;
      uVar5 = FUN_00558890(auStack_dc,"time given: ",&param_2,0x20,&param_3);
      uVar5 = FUN_00b34520(uVar5);
      uVar5 = FUN_005ed940(uVar5);
      FUN_00b34b30(uVar5);
      uVar5 = FUN_0058c400(auStack_44);
      uStack_8._0_1_ = 6;
      uVar5 = FUN_00b3cee0(uVar5);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_00b38f80(uVar5);
      pcVar2 = (code *)swi(3);
      puVar7 = (undefined4 *)(*pcVar2)();
      return puVar7;
    }
  }
  else {
    if (iVar4 != 3) {
      uStack_18 = param_3;
      uStack_14 = param_4;
      param_7 = param_2;
      if (iVar4 != 1) {
        FUN_005672c0(&param_7,&uStack_18);
      }
      else {
        FUN_005672c0(&param_7,&uStack_18);
      }
      if (param_6 != (int *)0x0) {
        LOCK();
        param_6[1] = param_6[1] + 1;
        UNLOCK();
      }
      FUN_00b417a0(&uStack_18,uStack_24,uStack_20,param_5,param_6,iVar4 == 1);
      uVar5 = FUN_00b4a230(&uStack_24);
      uVar6 = FUN_00b41a70(&param_7);
      FUN_005672c0(uVar6,uVar5);
      *param_1 = uStack_18;
      uVar5 = uStack_14;
      goto LAB_00b3b18e;
    }
    if (param_7 == 0) goto LAB_00b3b247;
  }
  uStack_18 = 0xfffffffe;
  uStack_14 = 0x7fffffff;
  uVar5 = FUN_0056a9c0(0);
  FUN_005672c0(uVar5,&uStack_18);
  *param_1 = uStack_24;
  uVar5 = uStack_20;
LAB_00b3b18e:
  piVar3 = param_6;
  param_1[1] = uVar5;
  uStack_8 = 8;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar4 = param_6[1] + -1;
    param_6[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*param_6 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23881 ; VA 0x00b3b2c0 ; FUN_00b3b2c0 */

undefined4 * __thiscall
FUN_00b3b2c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar3 = ExceptionList;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 8))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvVar3;
  return param_1;
}



/* FUNCTION 23882 ; VA 0x00b3b360 ; FUN_00b3b360 */

undefined4 * __thiscall FUN_00b3b360(undefined4 *param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined auStack_24 [2];
  undefined2 uStack_22;
  undefined2 uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f22e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
  param_1[1] = 0x10001;
  uStack_8 = 0;
  puStack_1c = param_1;
  FUN_0056a920(2000,1,1);
  iStack_18 = 1;
  cVar1 = FUN_00b3e1d0(&iStack_18);
  if (cVar1 == '\0') goto LAB_00b3b43c;
  iStack_18 = 0x16e;
  cVar1 = FUN_00b3e1d0(&iStack_18);
  if (cVar1 == '\0') {
    if ((param_2 != -0x80000000) && (param_2 != 0x7fffffff)) goto LAB_00b3b400;
LAB_00b3b407:
    if (((param_2 != 0x7ffffffe) && (param_2 != -0x80000000)) && (param_2 != 0x7fffffff))
    goto LAB_00b3b41e;
  }
  else {
    param_2 = 0x16e;
LAB_00b3b400:
    if (param_2 == 0x7ffffffe) goto LAB_00b3b407;
LAB_00b3b41e:
    param_2 = param_2 + -1;
  }
  iStack_18 = param_2;
  puVar2 = (undefined4 *)FUN_00b3e0c0(auStack_24,&iStack_18);
  uStack_14 = *puVar2;
LAB_00b3b43c:
  FUN_00b43600(auStack_24,uStack_14);
  *(undefined2 *)(param_1 + 1) = uStack_20;
  FUN_00b43600(auStack_24,uStack_14);
  *(undefined2 *)((int)param_1 + 6) = uStack_22;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23883 ; VA 0x00b3b480 ; FUN_00b3b480 */

undefined4 * __thiscall
FUN_00b3b480(undefined4 *param_1,undefined4 param_2,char *param_3,char *param_4,char *param_5,
            char *param_6)

{
  char cVar1;
  uint *puVar2;
  undefined uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2328;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  param_1[3] = param_2;
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar4 = param_3;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  puStack_14 = param_1;
  FUN_005542c0(param_3,(int)pcVar4 - (int)(param_3 + 1));
  uVar5 = uStack_2c;
  puVar2 = (uint *)param_1[1];
  uStack_8._0_1_ = 1;
  if ((uint *)param_1[2] == puVar2) {
    FUN_0058d0a0(puVar2,&uStack_2c);
    uVar5 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar2 = uVar5;
    puVar2[1] = uStack_28;
    puVar2[2] = uStack_24;
    puVar2[3] = uStack_20;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar5 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar5) {
    uVar6 = uVar5 + 1;
    uVar7 = uStack_2c;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar5 + 0x24;
      if (0x1f < (uStack_2c - uVar7) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar4 = param_4;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_4,(int)pcVar4 - (int)(param_4 + 1));
  uVar5 = uStack_2c;
  puVar2 = (uint *)param_1[1];
  uStack_8._0_1_ = 2;
  if ((uint *)param_1[2] == puVar2) {
    FUN_0058d0a0(puVar2,&uStack_2c);
    uVar5 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar2 = uVar5;
    puVar2[1] = uStack_28;
    puVar2[2] = uStack_24;
    puVar2[3] = uStack_20;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar5 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar5) {
    uVar6 = uVar5 + 1;
    uVar7 = uStack_2c;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar5 + 0x24;
      if (0x1f < (uStack_2c - uVar7) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar4 = param_5;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_5,(int)pcVar4 - (int)(param_5 + 1));
  uVar5 = uStack_2c;
  puVar2 = (uint *)param_1[1];
  uStack_8._0_1_ = 3;
  if ((uint *)param_1[2] == puVar2) {
    FUN_0058d0a0(puVar2,&uStack_2c);
    uVar5 = uStack_18;
  }
  else {
    uStack_2c = uStack_2c & 0xffffff00;
    *puVar2 = uVar5;
    puVar2[1] = uStack_28;
    puVar2[2] = uStack_24;
    puVar2[3] = uStack_20;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    uVar5 = 0xf;
  }
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uVar5) {
    uVar6 = uVar5 + 1;
    uVar7 = uStack_2c;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_2c - 4);
      uVar6 = uVar5 + 0x24;
      if (0x1f < (uStack_2c - uVar7) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  pcVar4 = param_6;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_6,(int)pcVar4 - (int)(param_6 + 1));
  puVar2 = (uint *)param_1[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if ((uint *)param_1[2] != puVar2) {
    *puVar2 = uStack_2c;
    puVar2[1] = uStack_28;
    puVar2[2] = uStack_24;
    puVar2[3] = uStack_20;
    *(ulonglong *)(puVar2 + 4) = CONCAT44(uStack_18,uStack_1c);
    param_1[1] = param_1[1] + 0x18;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_0058d0a0(puVar2,&uStack_2c);
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    uVar5 = uStack_2c;
    if (0xfff < uVar7) {
      uVar5 = *(uint *)(uStack_2c - 4);
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23884 ; VA 0x00b3b770 ; FUN_00b3b770 */

undefined4 * __fastcall FUN_00b3b770(undefined4 *param_1)

{
  char cVar1;
  code *pcVar2;
  undefined8 uVar3;
  undefined uVar4;
  undefined4 *puVar5;
  char *pcVar6;
  undefined4 **ppuVar7;
  bool bVar8;
  int iStack_158;
  int iStack_154;
  char cStack_150;
  int iStack_c8;
  int iStack_c4;
  char cStack_c0;
  undefined auStack_50 [24];
  undefined auStack_38 [24];
  undefined uStack_20;
  undefined uStack_1f;
  undefined4 uStack_1c;
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2429;
  pvStack_10 = ExceptionList;
  puStack_14 = param_1 + 1;
  ExceptionList = &pvStack_10;
  *param_1 = boost::local_time::posix_time_zone_base<char>::vftable;
  pcVar6 = "std_name";
  param_1[5] = 0;
  param_1[6] = 0xf;
  uStack_8 = 0;
  *(undefined *)puStack_14 = 0;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  pcVar6 = "std_abbrev";
  param_1[0xb] = 0;
  param_1[0xc] = 0xf;
  uStack_8._0_1_ = 1;
  *(undefined *)(param_1 + 7) = 0;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  pcVar6 = "no-dst";
  param_1[0x11] = 0;
  param_1[0x12] = 0xf;
  uStack_8._0_1_ = 2;
  *(undefined *)(param_1 + 0xd) = 0;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  pcVar6 = "no-dst";
  param_1[0x17] = 0;
  param_1[0x18] = 0xf;
  uStack_8._0_1_ = 3;
  *(undefined *)(param_1 + 0x13) = 0;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  *(undefined *)(param_1 + 0x19) = 0;
  uVar3 = FUN_016f39b0();
  *(undefined8 *)(param_1 + 0x1a) = uVar3;
  *(undefined8 *)(param_1 + 0x1c) = uVar3;
  *(undefined8 *)(param_1 + 0x1e) = uVar3;
  *(undefined8 *)(param_1 + 0x20) = uVar3;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  puStack_14 = (undefined4 *)CONCAT22(puStack_14._2_2_,0x2c);
  ppuVar7 = &puStack_14;
  uStack_8._0_1_ = 6;
  do {
    cVar1 = *(char *)ppuVar7;
    ppuVar7 = (undefined4 **)((int)ppuVar7 + 1);
  } while (cVar1 != '\0');
  FUN_005542c0();
  uStack_8._0_1_ = 8;
  FUN_0054ef60();
  uStack_8._0_1_ = 9;
  FUN_0054ef60();
  uStack_20 = 0;
  uStack_1f = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8._0_1_ = 10;
  FUN_0054ef60(auStack_50);
  uStack_8._0_1_ = 0xb;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 10;
  FUN_00590840();
  uStack_8._0_1_ = 0xc;
  FUN_0054ef60(auStack_50);
  uStack_8._0_1_ = 0xd;
  FUN_0054ef60(auStack_38);
  uStack_8._0_1_ = 0xc;
  FUN_00590840();
  uStack_8._0_1_ = 0xe;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if ((cStack_150 == '\0') || (cStack_c0 == '\0')) {
    bVar8 = cStack_150 == cStack_c0;
  }
  else if ((iStack_158 == iStack_c8) && (iStack_154 == iStack_c4)) {
    bVar8 = true;
  }
  else {
    bVar8 = false;
  }
  if (bVar8) {
    uStack_8._0_1_ = uVar4;
    FUN_00b3ce50();
    uStack_8._0_1_ = 0xf;
    FUN_00b39020();
  }
  else {
    FUN_00b34d50();
    uStack_8._0_1_ = 0x10;
    FUN_00b40440();
    uStack_8._0_1_ = 0xe;
    FUN_00590940();
    if (*(char *)(param_1 + 0x19) == '\0') {
LAB_00b3bbf7:
      FUN_00590940();
      FUN_00590940();
      FUN_005509f0();
      FUN_005509f0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    if ((cStack_150 == '\0') || (cStack_c0 == '\0')) {
      bVar8 = cStack_150 == cStack_c0;
    }
    else if ((iStack_158 == iStack_c8) && (iStack_154 == iStack_c4)) {
      bVar8 = true;
    }
    else {
      bVar8 = false;
    }
    if (!bVar8) {
      FUN_00b34d50();
      uStack_8._0_1_ = 0x12;
      FUN_0054ef60();
      uStack_8._0_1_ = 0x14;
      FUN_00590940();
      if ((cStack_150 == '\0') || (cStack_c0 == '\0')) {
        bVar8 = cStack_150 == cStack_c0;
      }
      else if ((iStack_158 == iStack_c8) && (iStack_154 == iStack_c4)) {
        bVar8 = true;
      }
      else {
        bVar8 = false;
      }
      if (!bVar8) {
        FUN_0054ef60();
        uStack_8._0_1_ = 0x16;
        FUN_00b3fd60();
        FUN_005507b0();
        FUN_005507b0();
        goto LAB_00b3bbf7;
      }
      goto LAB_00b3bc81;
    }
  }
  FUN_00b3ce50();
  uStack_8._0_1_ = 0x11;
  FUN_00b39020();
LAB_00b3bc81:
  FUN_00b3ce50();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  FUN_00b39020();
  pcVar2 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar2)();
  return puVar5;
}



/* FUNCTION 23885 ; VA 0x00b3bcb0 ; FUN_00b3bcb0 */

undefined4 * __fastcall FUN_00b3bcb0(undefined4 *param_1)

{
  char cVar1;
  uint *puVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  char *pcVar7;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f2450;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  iStack_8 = 0;
  pcVar7 = "not-a-date-time";
  puStack_14 = param_1;
  do {
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    pcVar3 = pcVar7;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar7,(int)pcVar3 - (int)(pcVar7 + 1));
    uVar4 = uStack_2c;
    puVar2 = (uint *)param_1[1];
    iStack_8._0_1_ = 1;
    if ((uint *)param_1[2] == puVar2) {
      FUN_0058d0a0(puVar2,&uStack_2c);
      uVar4 = uStack_18;
    }
    else {
      uStack_2c = uStack_2c & 0xffffff00;
      *puVar2 = uVar4;
      puVar2[1] = uStack_28;
      puVar2[2] = uStack_24;
      puVar2[3] = uStack_20;
      puVar2[4] = uStack_1c;
      puVar2[5] = uStack_18;
      param_1[1] = param_1[1] + 0x18;
      uVar4 = 0xf;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uVar4) {
      uVar6 = uVar4 + 1;
      uVar5 = uStack_2c;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_2c - 4);
        uVar6 = uVar4 + 0x24;
        if (0x1f < (uStack_2c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    pcVar7 = pcVar7 + 0x11;
  } while (pcVar7 != "");
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23886 ; VA 0x00b3bdc0 ; FUN_00b3bdc0 */

undefined4 * __fastcall FUN_00b3bdc0(undefined4 *param_1)

{
  char *pcVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2493;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_14 = param_1;
  uVar2 = FUN_00575ab0();
  *param_1 = uVar2;
  *(undefined2 *)(param_1 + 2) = 0xffff;
  uStack_8 = 0;
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  pcVar1 = "maximum-date-time";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952184,pcVar3 + -0x1952184);
  uStack_8._0_1_ = 1;
  uStack_68 = 0;
  uStack_64 = 0xf;
  auStack_78[0] = auStack_78[0] & 0xffffff00;
  pcVar1 = "minimum-date-time";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952170,pcVar3 + -0x1952170);
  uStack_8._0_1_ = 2;
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  pcVar1 = "+infinity";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952164,pcVar3 + -0x1952164);
  uStack_8._0_1_ = 3;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  pcVar1 = "-infinity";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952158,pcVar3 + -0x1952158);
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcVar1 = "not-a-date-time";
  do {
    pcVar3 = pcVar1;
    pcVar1 = pcVar3 + 1;
  } while (*pcVar3 != '\0');
  FUN_005542c0(&DAT_01952148,pcVar3 + -0x1952148);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00b4a0a0(auStack_30,auStack_48,auStack_60,auStack_78,auStack_90);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_4c) {
    uVar5 = uStack_4c + 1;
    uVar4 = auStack_60[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_60[0] - 4);
      uVar5 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_64) {
    uVar5 = uStack_64 + 1;
    uVar4 = auStack_78[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_78[0] - 4);
      uVar5 = uStack_64 + 0x24;
      if (0x1f < (auStack_78[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (0xf < uStack_7c) {
    uVar5 = uStack_7c + 1;
    uVar4 = auStack_90[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_90[0] - 4);
      uVar5 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23887 ; VA 0x00b3c070 ; FUN_00b3c070 */

undefined4 * __thiscall FUN_00b3c070(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = FUN_00575ab0();
  *param_1 = uVar1;
  *param_1 = *param_2;
  *param_2 = uVar1;
  uVar1 = param_1[1];
  param_1[1] = param_2[1];
  param_2[1] = uVar1;
  *(undefined2 *)(param_1 + 2) = *(undefined2 *)(param_2 + 2);
  return param_1;
}



/* FUNCTION 23888 ; VA 0x00b3c0c0 ; FUN_00b3c0c0 */

undefined4 * __thiscall
FUN_00b3c0c0(undefined4 *param_1,int param_2,int param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f24c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_18 = param_1;
  uVar3 = FUN_00575ab0();
  *param_1 = uVar3;
  uStack_8._0_1_ = 1;
  iVar2 = param_3 - param_2 >> 0x1f;
  uStack_14 = 0;
  if ((param_3 - param_2) / 0x18 + iVar2 != iVar2) {
    do {
      uStack_8._0_1_ = 2;
      piStack_1c = (int *)FUN_016de181(1);
      uStack_8._0_1_ = 3;
      piVar4 = (int *)(param_2 + (uStack_14 & 0xffff) * 0x18);
      piVar7 = piVar4;
      if (0xf < *(uint *)(param_2 + 0x14 + (uStack_14 & 0xffff) * 0x18)) {
        piVar7 = (int *)*piVar4;
      }
      piVar1 = piVar4 + 4;
      if (0xf < (uint)piVar4[5]) {
        piVar4 = (int *)*piVar4;
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = auStack_38[0] & 0xffffff00;
      FUN_00b352c0(piVar4,auStack_20,*piVar1 + (int)piVar7,auStack_20,param_5);
      uStack_8._0_1_ = 6;
      if ((piStack_1c != (int *)0x0) &&
         (puVar5 = (undefined4 *)(**(code **)(*piStack_1c + 8))(), puVar5 != (undefined4 *)0x0)) {
        (**(code **)*puVar5)(1);
      }
      uStack_8._0_1_ = 5;
      FUN_00b46290(auStack_38,uStack_14 + param_5);
      uStack_14 = uStack_14 + 1;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_24) {
        uVar8 = uStack_24 + 1;
        uVar6 = auStack_38[0];
        if (0xfff < uVar8) {
          uVar6 = *(uint *)(auStack_38[0] - 4);
          uVar8 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar8);
      }
      param_1 = puStack_18;
    } while ((uStack_14 & 0xffff) != (param_3 - param_2) / 0x18);
  }
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23889 ; VA 0x00b3c250 ; FUN_00b3c250 */

/* WARNING: Removing unreachable block (ram,0x00b3c442) */
/* WARNING: Removing unreachable block (ram,0x00b3c450) */
/* WARNING: Removing unreachable block (ram,0x00b3c47f) */
/* WARNING: Removing unreachable block (ram,0x00b3c460) */

undefined4 * __fastcall FUN_00b3c250(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined *puVar5;
  undefined4 *puVar6;
  char *pcVar7;
  char *pcVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = PTR_s__Y__b__d__H__M__S_F__z_01d66fb8;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2511;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00b39f50();
  uStack_8 = 0;
  FUN_00b3bcb0();
  uStack_8._0_1_ = 1;
  pcVar8 = "/";
  do {
    pcVar7 = pcVar8;
    pcVar8 = pcVar7 + 1;
  } while (*pcVar7 != '\0');
  FUN_005542c0(&DAT_01952340,pcVar7 + -0x1952340);
  uStack_8._0_1_ = 2;
  pcVar8 = "[";
  do {
    pcVar7 = pcVar8;
    pcVar8 = pcVar7 + 1;
  } while (*pcVar7 != '\0');
  FUN_005542c0(&DAT_01952344,pcVar7 + -0x1952344);
  uStack_8._0_1_ = 3;
  pcVar8 = ")";
  do {
    pcVar7 = pcVar8;
    pcVar8 = pcVar7 + 1;
  } while (*pcVar7 != '\0');
  FUN_005542c0(&DAT_01952348,pcVar7 + -0x1952348);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  pcVar8 = "]";
  do {
    pcVar7 = pcVar8;
    pcVar8 = pcVar7 + 1;
  } while (*pcVar7 != '\0');
  FUN_005542c0(&DAT_0195234c,pcVar7 + -0x195234c);
  uStack_8 = 0xffffffff;
  FUN_00b39d60(puVar5);
  *param_1 = boost::date_time::
             time_facet<class_boost::posix_time::ptime,char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
             ::vftable;
  pcVar8 = PTR_DAT_01d66fbc;
  uStack_8 = 5;
  pcVar7 = PTR_DAT_01d66fa4;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  do {
    cVar1 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar1 != '\0');
  puVar6 = (undefined4 *)FUN_00554150();
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  uVar2 = puVar6[1];
  uVar3 = puVar6[2];
  uVar4 = puVar6[3];
  param_1[0x3f] = *puVar6;
  param_1[0x40] = uVar2;
  param_1[0x41] = uVar3;
  param_1[0x42] = uVar4;
  *(undefined8 *)(param_1 + 0x43) = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23890 ; VA 0x00b3c490 ; FUN_00b3c490 */

/* WARNING: Removing unreachable block (ram,0x00b3c5ff) */
/* WARNING: Removing unreachable block (ram,0x00b3c60d) */
/* WARNING: Removing unreachable block (ram,0x00b3c64b) */
/* WARNING: Removing unreachable block (ram,0x00b3c61d) */

undefined4 * __thiscall FUN_00b3c490(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  char *pcVar6;
  undefined4 *in_stack_0000006c;
  char *in_stack_0000007c;
  undefined4 auStack_bc [23];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_54;
  undefined *puStack_50;
  undefined auStack_4c [4];
  undefined4 uStack_48;
  char *pcStack_44;
  int iStack_40;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2574;
  pvStack_10 = ExceptionList;
  iStack_40 = (int)in_stack_0000007c;
  puStack_50 = &stack0x00000070;
  uStack_8 = 1;
  in_stack_0000007c = auStack_4c;
  uStack_54 = 0xb3c4d6;
  ExceptionList = &pvStack_10;
  FUN_00637260();
  uStack_8._0_1_ = 2;
  uStack_5c = in_stack_0000006c;
  uStack_60 = 0xb3c4ed;
  FUN_00637260();
  in_stack_0000006c = auStack_bc;
  uStack_8._0_1_ = 3;
  auStack_bc[0] = param_3;
  FUN_0054ef60(&stack0x0000000c);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&stack0x00000024);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&stack0x0000003c);
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&stack0x00000054);
  uStack_8._0_1_ = 1;
  FUN_00b39d60(param_2);
  *param_1 = boost::date_time::
             time_facet<class_boost::posix_time::ptime,char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
             ::vftable;
  uStack_8._0_1_ = 7;
  in_stack_0000007c = PTR_DAT_01d66fbc;
  pcVar6 = PTR_DAT_01d66fa4;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  iStack_40 = (int)pcVar6 - (int)(PTR_DAT_01d66fa4 + 1);
  pcStack_44 = PTR_DAT_01d66fa4;
  uStack_48 = 0xb3c593;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  pcVar6 = in_stack_0000007c;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  iStack_40 = (int)pcVar6 - (int)(in_stack_0000007c + 1);
  pcStack_44 = in_stack_0000007c;
  uStack_48 = 0xb3c5c8;
  in_stack_0000006c = param_1 + 0x3f;
  puVar5 = (undefined4 *)FUN_00554150();
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  uVar2 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  param_1[0x3f] = *puVar5;
  param_1[0x40] = uVar2;
  param_1[0x41] = uVar3;
  param_1[0x42] = uVar4;
  *(undefined8 *)(param_1 + 0x43) = *(undefined8 *)(puVar5 + 4);
  puVar5[4] = 0;
  puVar5[5] = 0xf;
  *(undefined *)puVar5 = 0;
  iStack_40 = 0xb3c62f;
  FUN_00b3d950();
  iStack_40 = 0xb3c637;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23891 ; VA 0x00b3c660 ; FUN_00b3c660 */

undefined4 * __thiscall FUN_00b3c660(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  param_1[1] = param_3;
  *param_1 = std::
             time_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>::
             vftable;
  param_1[2] = 0;
  uVar1 = thunk_FUN_0173056b();
  param_1[2] = uVar1;
  FUN_017168b0(0);
  return param_1;
}



/* FUNCTION 23892 ; VA 0x00b3c6a0 ; FUN_00b3c6a0 */

undefined4 * __thiscall
FUN_00b3c6a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  return param_1;
}



/* FUNCTION 23893 ; VA 0x00b3c6c0 ; FUN_00b3c6c0 */

int __thiscall FUN_00b3c6c0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f25f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00637260(param_2);
  uStack_8 = 0;
  FUN_00637260(iVar1 + 0xc);
  uStack_8._0_1_ = 1;
  FUN_00637260(iVar1 + 0x18);
  uStack_8._0_1_ = 2;
  FUN_00637260(iVar1 + 0x24);
  uStack_8._0_1_ = 3;
  FUN_00637260(iVar1 + 0x30);
  uStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(iVar1 + 0x3c);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  uVar2 = FUN_00970740(0,0);
  *(undefined4 *)(param_1 + 0x40) = uVar2;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  uStack_8._0_1_ = 6;
  FUN_00b3fa60(iVar1 + 0x3c);
  uStack_8._0_1_ = 7;
  FUN_00b339e0(iVar1 + 0x5c,(int)&param_2 + 3);
  param_2 = (undefined4 *)(param_1 + 100);
  uStack_8._0_1_ = 8;
  *param_2 = *(undefined4 *)(iVar1 + 100);
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  uVar2 = FUN_00616d10(0,0);
  *(undefined4 *)(param_1 + 0x68) = uVar2;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_00b3f960(iVar1 + 100);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23894 ; VA 0x00b3c800 ; FUN_00b3c800 */

undefined4 * __thiscall FUN_00b3c800(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::ambiguous_result::vftable;
  return param_1;
}



/* FUNCTION 23895 ; VA 0x00b3c840 ; FUN_00b3c840 */

undefined4 * __thiscall FUN_00b3c840(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2619;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 0x28);
  FUN_00554150("Daylight Savings Results are ambiguous: ",0x28);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_18 = apppuStack_30;
  if (0xf < uStack_1c) {
    pppuStack_18 = apppuStack_30[0];
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_0170c226(&pppuStack_18,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  *param_1 = boost::local_time::ambiguous_result::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23896 ; VA 0x00b3c950 ; FUN_00b3c950 */

undefined4 * __thiscall FUN_00b3c950(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_adjustment::vftable;
  return param_1;
}



/* FUNCTION 23897 ; VA 0x00b3c990 ; FUN_00b3c990 */

undefined4 * __thiscall FUN_00b3c990(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2619;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 0x19);
  FUN_00554150("Adjustment out of range: ",0x19);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_18 = apppuStack_30;
  if (0xf < uStack_1c) {
    pppuStack_18 = apppuStack_30[0];
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_0170c226(&pppuStack_18,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  *param_1 = boost::local_time::bad_adjustment::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23898 ; VA 0x00b3caa0 ; FUN_00b3caa0 */

undefined4 * __thiscall FUN_00b3caa0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_day_of_year::vftable;
  return param_1;
}



/* FUNCTION 23899 ; VA 0x00b3cae0 ; FUN_00b3cae0 */

undefined4 * __fastcall FUN_00b3cae0(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [4];
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0xf;
  apppuStack_24[0] = (undefined4 ***)((uint)apppuStack_24[0] & 0xffffff00);
  puStack_8 = param_1;
  FUN_005542c0("Day of year value is out of range 1..366",0x28);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = boost::gregorian::bad_day_of_year::vftable;
  return param_1;
}



/* FUNCTION 23900 ; VA 0x00b3cb90 ; FUN_00b3cb90 */

undefined4 * __thiscall FUN_00b3cb90(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::bad_offset::vftable;
  return param_1;
}



/* FUNCTION 23901 ; VA 0x00b3cbd0 ; FUN_00b3cbd0 */

undefined4 * __thiscall FUN_00b3cbd0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2619;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 0x15);
  FUN_00554150("Offset out of range: ",0x15);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_18 = apppuStack_30;
  if (0xf < uStack_1c) {
    pppuStack_18 = apppuStack_30[0];
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_0170c226(&pppuStack_18,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  *param_1 = boost::local_time::bad_offset::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23902 ; VA 0x00b3cce0 ; FUN_00b3cce0 */

undefined4 * __thiscall FUN_00b3cce0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::gregorian::bad_weekday::vftable;
  return param_1;
}



/* FUNCTION 23903 ; VA 0x00b3cd20 ; FUN_00b3cd20 */

undefined4 * __fastcall FUN_00b3cd20(undefined4 *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_24 [4];
  undefined4 uStack_14;
  uint uStack_10;
  undefined4 ***pppuStack_c;
  undefined4 *puStack_8;
  
  uStack_14 = 0;
  uStack_10 = 0xf;
  apppuStack_24[0] = (undefined4 ***)((uint)apppuStack_24[0] & 0xffffff00);
  puStack_8 = param_1;
  FUN_005542c0("Weekday is out of range 0..6",0x1c);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_c = apppuStack_24;
  if (0xf < uStack_10) {
    pppuStack_c = apppuStack_24[0];
  }
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  FUN_0170c226(&pppuStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  if (0xf < uStack_10) {
    uVar2 = uStack_10 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_24[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_24[0][-1];
      uVar2 = uStack_10 + 0x24;
      if (0x1f < (uint)((int)apppuStack_24[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  *param_1 = boost::gregorian::bad_weekday::vftable;
  return param_1;
}



/* FUNCTION 23904 ; VA 0x00b3cdd0 ; FUN_00b3cdd0 */

undefined4 * __thiscall FUN_00b3cdd0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_0054f9c0(*param_3,param_3[1],param_2);
  *param_1 = std::ios_base::failure::vftable;
  return param_1;
}



/* FUNCTION 23905 ; VA 0x00b3ce00 ; FUN_00b3ce00 */

undefined4 * __thiscall FUN_00b3ce00(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  puStack_c = param_2;
  FUN_0170c226(&puStack_c,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  return param_1;
}



/* FUNCTION 23906 ; VA 0x00b3ce50 ; FUN_00b3ce50 */

undefined4 * __thiscall FUN_00b3ce50(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::invalid_argument::vftable;
  return param_1;
}



/* FUNCTION 23907 ; VA 0x00b3cea0 ; FUN_00b3cea0 */

undefined4 * __thiscall FUN_00b3cea0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::local_time::time_label_invalid::vftable;
  return param_1;
}



/* FUNCTION 23908 ; VA 0x00b3cee0 ; FUN_00b3cee0 */

undefined4 * __thiscall FUN_00b3cee0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2619;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 0x1d);
  FUN_00554150("Time label given is invalid: ",0x1d);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  pppuStack_18 = apppuStack_30;
  if (0xf < uStack_1c) {
    pppuStack_18 = apppuStack_30[0];
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  FUN_0170c226(&pppuStack_18,param_1 + 1);
  *param_1 = std::logic_error::vftable;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  *param_1 = boost::local_time::time_label_invalid::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23909 ; VA 0x00b3cff0 ; FUN_00b3cff0 */

void __fastcall FUN_00b3cff0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a15350();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x24);
  return;
}



/* FUNCTION 23910 ; VA 0x00b3d060 ; FUN_00b3d060 */

void __fastcall FUN_00b3d060(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23911 ; VA 0x00b3d0c0 ; FUN_00b3d0c0 */

void __fastcall FUN_00b3d0c0(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x20);
  return;
}



/* FUNCTION 23912 ; VA 0x00b3d0d0 ; FUN_00b3d0d0 */

void __fastcall FUN_00b3d0d0(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x44);
  return;
}



/* FUNCTION 23913 ; VA 0x00b3d0e0 ; FUN_00b3d0e0 */

void __fastcall FUN_00b3d0e0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00b3d950();
  uVar1 = param_1[0x13];
  if (0xf < uVar1) {
    iVar2 = param_1[0xe];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b3d1ff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar1 = param_1[0xd];
  if (0xf < uVar1) {
    iVar2 = param_1[8];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b3d1ff;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b3d1ff:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  *param_1 = std::_Facet_base::vftable;
  return;
}



/* FUNCTION 23914 ; VA 0x00b3d210 ; FUN_00b3d210 */

void __fastcall FUN_00b3d210(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar2 = param_1[0x33];
  piVar1 = param_1 + 0x33;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fb60(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  param_1[0x34] = 0;
  FUN_01674ea0(*piVar1,0x20);
  FUN_00577a40();
  iVar2 = param_1[0x2c];
  piVar1 = param_1 + 0x2c;
  uStack_8 = 1;
  FUN_00b3fb60(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  param_1[0x2d] = 0;
  FUN_01674ea0(*piVar1,0x20);
  FUN_00b3d700();
  uVar3 = param_1[0x19];
  if (0xf < uVar3) {
    iVar2 = param_1[0x14];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00b3d3e3;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x18] = 0;
  param_1[0x19] = 0xf;
  *(undefined *)(param_1 + 0x14) = 0;
  uVar3 = param_1[0x13];
  if (0xf < uVar3) {
    iVar2 = param_1[0xe];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00b3d3e3;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x12] = 0;
  param_1[0x13] = 0xf;
  *(undefined *)(param_1 + 0xe) = 0;
  uVar3 = param_1[0xd];
  if (0xf < uVar3) {
    iVar2 = param_1[8];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00b3d3e3;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0xc] = 0;
  param_1[0xd] = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  uVar3 = param_1[7];
  if (0xf < uVar3) {
    iVar2 = param_1[2];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00b3d3e3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  *param_1 = std::_Facet_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23915 ; VA 0x00b3d3f0 ; FUN_00b3d3f0 */

void __fastcall FUN_00b3d3f0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23916 ; VA 0x00b3d460 ; FUN_00b3d460 */

void __fastcall FUN_00b3d460(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23917 ; VA 0x00b3d4d0 ; FUN_00b3d4d0 */

void __fastcall FUN_00b3d4d0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23918 ; VA 0x00b3d540 ; FUN_00b3d540 */

void __fastcall FUN_00b3d540(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23919 ; VA 0x00b3d5b0 ; FUN_00b3d5b0 */

void __fastcall FUN_00b3d5b0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23920 ; VA 0x00b3d620 ; FUN_00b3d620 */

void __fastcall FUN_00b3d620(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23921 ; VA 0x00b3d690 ; FUN_00b3d690 */

void __fastcall FUN_00b3d690(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23922 ; VA 0x00b3d700 ; FUN_00b3d700 */

void __fastcall FUN_00b3d700(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x3c);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x3c) + 4) = iVar1;
  **(int **)(param_1 + 0x3c) = iVar1;
  *(int *)(*(int *)(param_1 + 0x3c) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x40) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x3c),0x20);
  iVar1 = *(int *)(param_1 + 0x30);
  uStack_8 = 1;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x30) + 4) = iVar1;
  **(int **)(param_1 + 0x30) = iVar1;
  *(int *)(*(int *)(param_1 + 0x30) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x34) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x30),0x20);
  iVar1 = *(int *)(param_1 + 0x24);
  uStack_8 = 2;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x24) + 4) = iVar1;
  **(int **)(param_1 + 0x24) = iVar1;
  *(int *)(*(int *)(param_1 + 0x24) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x28) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x24),0x20);
  iVar1 = *(int *)(param_1 + 0x18);
  uStack_8 = 3;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x18) + 4) = iVar1;
  **(int **)(param_1 + 0x18) = iVar1;
  *(int *)(*(int *)(param_1 + 0x18) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x18),0x20);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23923 ; VA 0x00b3d820 ; FUN_00b3d820 */

void __fastcall FUN_00b3d820(undefined4 *param_1)

{
  FUN_00a15350();
  FUN_01674ea0(*param_1,0x24);
  return;
}



/* FUNCTION 23924 ; VA 0x00b3d840 ; FUN_00b3d840 */

void * __fastcall FUN_00b3d840(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0xc);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 23925 ; VA 0x00b3d8a0 ; FUN_00b3d8a0 */

void __fastcall FUN_00b3d8a0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fbb0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x44);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23926 ; VA 0x00b3d900 ; FUN_00b3d900 */

void __fastcall FUN_00b3d900(undefined4 *param_1)

{
  *param_1 = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  return;
}



/* FUNCTION 23927 ; VA 0x00b3d910 ; FUN_00b3d910 */

void FUN_00b3d910(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fc50();
  FUN_00b3d0c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23928 ; VA 0x00b3d950 ; FUN_00b3d950 */

void __fastcall FUN_00b3d950(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x60);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x4c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b3da65;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0xf;
  *(undefined *)(param_1 + 0x4c) = 0;
  uVar1 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x34);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b3da65;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  uVar1 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x1c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b3da65;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  uVar1 = *(uint *)(param_1 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b3da65:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 23929 ; VA 0x00b3da70 ; FUN_00b3da70 */

void __fastcall FUN_00b3da70(undefined4 *param_1)

{
  *param_1 = boost::date_time::time_zone_base<class_boost::posix_time::ptime,char>::vftable;
  return;
}



/* FUNCTION 23930 ; VA 0x00b3da80 ; thunk_FUN_00b3cff0 */

void __fastcall thunk_FUN_00b3cff0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a15350();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x24);
  return;
}



/* FUNCTION 23931 ; VA 0x00b3da90 ; FUN_00b3da90 */

void __fastcall FUN_00b3da90(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00b3cff0();
  iVar1 = *(int *)(param_1 + 0x5c);
  uStack_8 = 0;
  FUN_00b3fbb0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x5c) + 4) = iVar1;
  **(int **)(param_1 + 0x5c) = iVar1;
  *(int *)(*(int *)(param_1 + 0x5c) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x60) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x5c),0x44);
  FUN_00a3bd10();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23932 ; VA 0x00b3db30 ; FUN_00b3db30 */

void __fastcall FUN_00b3db30(int *param_1)

{
  *(uint *)(*param_1 + 0x14) = (uint)*(ushort *)(param_1 + 1);
  return;
}



/* FUNCTION 23933 ; VA 0x00b3db40 ; FUN_00b3db40 */

int * __thiscall FUN_00b3db40(int *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  
  pcVar3 = (char *)*param_1;
  if (pcVar3 != param_2) {
    if (pcVar3 != (char *)0x0) {
      FUN_017168b0(pcVar3);
    }
    *param_1 = 0;
    if (param_2 != (char *)0x0) {
      cVar1 = *param_2;
      pcVar3 = param_2;
      while (cVar1 != '\0') {
        pcVar3 = pcVar3 + 1;
        cVar1 = *pcVar3;
      }
      iVar2 = FUN_0171e1f2(pcVar3 + (1 - (int)param_2));
      *param_1 = iVar2;
      if (iVar2 != 0) {
        FUN_0170c6f0(iVar2,param_2,pcVar3 + (1 - (int)param_2));
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 23934 ; VA 0x00b3dbb0 ; FUN_00b3dbb0 */

undefined4 * __thiscall FUN_00b3dbb0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  iVar2 = param_2[3];
  uVar3 = param_2[2];
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  param_1[2] = uVar3;
  piVar4 = (int *)param_1[3];
  param_1[3] = iVar2;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23935 ; VA 0x00b3dc40 ; FUN_00b3dc40 */

int * __thiscall FUN_00b3dc40(int *param_1,undefined2 param_2)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint auStack_38 [2];
  int *piStack_30;
  undefined uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2648;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar7 = *param_1;
  uStack_28 = 0;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  piStack_20 = param_1;
  puVar2 = &stack0xffffffbc;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  iVar1 = *(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1);
  uStack_2c = iVar1 == 0;
  uStack_8 = 1;
  if (iVar1 == 0) {
    piStack_24 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_18 = piStack_24;
    (**(code **)(*piStack_24 + 4))();
    uStack_8._0_1_ = 3;
    piStack_18 = (int *)FUN_00564aa0(auStack_1c);
    uStack_8._0_1_ = 4;
    if ((piStack_24 != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_24 + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    piStack_24 = (int *)CONCAT31(piStack_24._1_3_,
                                 *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uVar8 = auStack_38[0];
    (**(code **)(*piStack_18 + 0x20))
              (auStack_38,auStack_38[0],*(undefined4 *)(iVar7 + 0x38),iVar7,piStack_24,param_2);
    piVar5 = (int *)FUN_00b3dd70(uVar8);
    return piVar5;
  }
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar8;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23936 ; VA 0x00b3dd51 ; Catch_All@00b3dd51 */

undefined * Catch_All_00b3dd51(void)

{
  FUN_005565b0(4,1);
  return &DAT_00b3dd6a;
}



/* FUNCTION 23937 ; VA 0x00b3dd70 ; FUN_00b3dd70 */

void FUN_00b3dd70(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 23938 ; VA 0x00b3dde0 ; FUN_00b3dde0 */

undefined4 __fastcall FUN_00b3dde0(undefined4 param_1)

{
  FUN_00551320();
  return param_1;
}



/* FUNCTION 23939 ; VA 0x00b3ddf0 ; FUN_00b3ddf0 */

int * __thiscall FUN_00b3ddf0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  bool bVar2;
  int iVar3;
  
  iVar1 = *param_3;
  if (((iVar1 == -0x80000000) || (iVar1 == 0x7fffffff)) || (iVar1 == 0x7ffffffe)) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  iVar3 = *param_1;
  if (bVar2) {
    if ((iVar3 != 0) && (iVar3 != -1)) {
      if (iVar3 == -2) goto LAB_00b3ded6;
      if (((iVar1 != -0x80000000) && (iVar1 != 0x7fffffff)) && (iVar1 != 0x7ffffffe))
      goto LAB_00b3deef;
    }
    if ((iVar3 == -2) || (iVar1 == 0x7ffffffe)) {
LAB_00b3ded6:
      *param_2 = -2;
      return param_2;
    }
    if (iVar3 == -1) {
      if (iVar1 != 0x7fffffff) {
        *param_2 = -1;
        return param_2;
      }
      goto LAB_00b3ded6;
    }
    if (iVar3 == 0) {
      if (iVar1 == -0x80000000) {
        *param_2 = -2;
        return param_2;
      }
      goto LAB_00b3def1;
    }
    if (iVar3 == -1) goto LAB_00b3def1;
    if (iVar1 == 0x7fffffff) {
      *param_2 = 0;
      return param_2;
    }
    if (iVar1 == -0x80000000) {
      *param_2 = -1;
      return param_2;
    }
  }
  else if (((iVar3 == 0) || (iVar3 == -1)) || (iVar3 == -2)) {
    if (iVar3 == -2) goto LAB_00b3ded6;
    if ((iVar3 == 0) || (iVar3 == -1)) goto LAB_00b3def1;
  }
LAB_00b3deef:
  iVar3 = iVar3 - iVar1;
LAB_00b3def1:
  *param_2 = iVar3;
  return param_2;
}



/* FUNCTION 23940 ; VA 0x00b3df00 ; FUN_00b3df00 */

void __thiscall FUN_00b3df00(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *param_1;
  if (((iVar2 == -2) || (iVar2 == 0)) || (iVar2 == -1)) {
    iVar1 = *param_3;
  }
  else {
    iVar1 = *param_3;
    if (((iVar1 != -2) && (iVar1 != 0)) && (iVar1 != -1)) {
      *param_2 = iVar2 - iVar1;
      return;
    }
  }
  if ((iVar2 == 0) || (iVar2 == -1)) {
LAB_00b3df4f:
    if ((iVar2 != -2) && (iVar1 != -2)) {
      if (iVar2 != -1) {
        if (iVar2 == 0) {
          if (iVar1 == 0) goto LAB_00b3df62;
LAB_00b3df85:
          if (iVar2 == -2) goto LAB_00b3df62;
          if (iVar2 == 0) {
LAB_00b3df9a:
            iVar2 = 1;
            goto LAB_00b3df64;
          }
          if (iVar2 != -1) {
            *param_2 = 0x7ffffffe;
            return;
          }
        }
        else {
          if (iVar2 == -1) goto LAB_00b3df85;
          if (iVar1 == -1) goto LAB_00b3df9a;
          if (iVar1 != 0) goto LAB_00b3df83;
        }
        iVar2 = 2;
        goto LAB_00b3df64;
      }
      if (iVar1 != -1) goto LAB_00b3df85;
    }
  }
  else if (iVar2 != -2) {
    if (((iVar1 == 0) || (iVar1 == -1)) || (iVar1 == -2)) goto LAB_00b3df4f;
LAB_00b3df83:
    iVar2 = iVar2 - iVar1;
    goto LAB_00b3df85;
  }
LAB_00b3df62:
  iVar2 = 0;
LAB_00b3df64:
                    /* WARNING: Could not recover jumptable at 0x00b3df64. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(&DAT_00b3dfe4)[iVar2])();
  return;
}



/* FUNCTION 23941 ; VA 0x00b3e000 ; FUN_00b3e000 */

void __thiscall FUN_00b3e000(uint *param_1,int *param_2,uint *param_3)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_1c [8];
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uStack_10 = param_1[1];
  uStack_14 = *param_1;
  uStack_c = *param_3;
  uVar1 = param_3[1];
  if ((((uStack_14 != 0) || (uStack_10 != 0x80000000)) &&
      ((uStack_14 != 0xffffffff || (uStack_10 != 0x7fffffff)))) &&
     ((((uStack_14 != 0xfffffffe || (uStack_10 != 0x7fffffff)) &&
       ((uStack_c != 0 || (uVar1 != 0x80000000)))) &&
      (((uStack_c != 0xffffffff || (uVar1 != 0x7fffffff)) &&
       ((uStack_c != 0xfffffffe || (uVar1 != 0x7fffffff)))))))) {
    param_2[1] = uVar1 + param_1[1] + (uint)CARRY4(uStack_c,uStack_14);
    *param_2 = uStack_c + uStack_14;
    return;
  }
  uStack_8 = param_3[1];
  piVar3 = (int *)FUN_00b34e20(auStack_1c,&uStack_c);
  iVar2 = piVar3[1];
  *param_2 = *piVar3;
  param_2[1] = iVar2;
  return;
}



/* FUNCTION 23942 ; VA 0x00b3e0c0 ; FUN_00b3e0c0 */

int * __thiscall FUN_00b3e0c0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  bool bVar2;
  int iVar3;
  
  iVar1 = *param_3;
  if (((iVar1 == -0x80000000) || (iVar1 == 0x7fffffff)) || (iVar1 == 0x7ffffffe)) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  iVar3 = *param_1;
  if (bVar2) {
    if ((iVar3 != 0) && (iVar3 != -1)) {
      if (iVar3 == -2) goto LAB_00b3e1a6;
      if (((iVar1 != -0x80000000) && (iVar1 != 0x7fffffff)) && (iVar1 != 0x7ffffffe))
      goto LAB_00b3e1bf;
    }
    if ((iVar3 == -2) || (iVar1 == 0x7ffffffe)) {
LAB_00b3e1a6:
      *param_2 = -2;
      return param_2;
    }
    if (iVar3 == -1) {
      if (iVar1 != -0x80000000) {
        *param_2 = -1;
        return param_2;
      }
      goto LAB_00b3e1a6;
    }
    if (iVar3 == 0) {
      if (iVar1 == 0x7fffffff) {
        *param_2 = -2;
        return param_2;
      }
      goto LAB_00b3e1c1;
    }
    if (iVar3 == -1) goto LAB_00b3e1c1;
    if (iVar1 == 0x7fffffff) {
      *param_2 = -1;
      return param_2;
    }
    if (iVar1 == -0x80000000) {
      *param_2 = 0;
      return param_2;
    }
  }
  else if (((iVar3 == 0) || (iVar3 == -1)) || (iVar3 == -2)) {
    if (iVar3 == -2) goto LAB_00b3e1a6;
    if ((iVar3 == 0) || (iVar3 == -1)) goto LAB_00b3e1c1;
  }
LAB_00b3e1bf:
  iVar3 = iVar3 + iVar1;
LAB_00b3e1c1:
  *param_2 = iVar3;
  return param_2;
}



/* FUNCTION 23943 ; VA 0x00b3e1d0 ; FUN_00b3e1d0 */

uint __thiscall FUN_00b3e1d0(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  uint3 uVar3;
  
  iVar1 = *param_1;
  if (((iVar1 == -0x80000000) || (iVar1 == 0x7fffffff)) || (iVar1 == 0x7ffffffe)) {
    uVar2 = *param_2;
LAB_00b3e20b:
    uVar3 = (uint3)(uVar2 >> 8);
    if (iVar1 == 0x7ffffffe) {
      if (uVar2 == 0x7ffffffe) {
        return (uint)uVar3 << 8;
      }
LAB_00b3e287:
      return (uint)uVar3 << 8;
    }
    if (uVar2 == 0x7ffffffe) goto LAB_00b3e287;
    if ((iVar1 == -0x80000000) && (uVar2 != 0x80000000)) goto LAB_00b3e231;
    if (uVar2 == 0x7fffffff) {
      if (iVar1 != 0x7fffffff) goto LAB_00b3e231;
    }
    else if (iVar1 == 0x7fffffff) goto LAB_00b3e266;
    if ((uVar2 == 0x80000000) && (iVar1 != -0x80000000)) {
LAB_00b3e266:
      return CONCAT31(uVar3,1);
    }
  }
  else {
    uVar2 = *param_2;
    if (((uVar2 == 0x80000000) || (uVar2 == 0x7fffffff)) || (uVar2 == 0x7ffffffe))
    goto LAB_00b3e20b;
  }
  if ((int)uVar2 <= iVar1) {
    return CONCAT31((int3)(uVar2 >> 8),(int)uVar2 < iVar1);
  }
LAB_00b3e231:
  return uVar2 & 0xffffff00;
}



/* FUNCTION 23944 ; VA 0x00b3e2a0 ; FUN_00b3e2a0 */

uint FUN_00b3e2a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  puVar2 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  uVar3 = FUN_0055c2d0(param_2,*puVar2,param_1,*puVar1);
  return uVar3 >> 0x1f;
}



/* FUNCTION 23945 ; VA 0x00b3e2e0 ; FUN_00b3e2e0 */

void __thiscall FUN_00b3e2e0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined auStack_8 [4];
  
  FUN_00b4a230(auStack_20);
  puVar1 = (undefined4 *)FUN_00602640(&uStack_18,param_3);
  uStack_10 = *puVar1;
  uStack_c = puVar1[1];
  uVar2 = FUN_00b41a70(auStack_8);
  FUN_005672c0(uVar2,&uStack_10);
  *param_1 = uStack_18;
  param_1[1] = uStack_14;
  *param_2 = uStack_18;
  param_2[1] = uStack_14;
  return;
}



/* FUNCTION 23946 ; VA 0x00b3e340 ; FUN_00b3e340 */

void __fastcall FUN_00b3e340(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23947 ; VA 0x00b3e3e0 ; FUN_00b3e3e0 */

void __fastcall FUN_00b3e3e0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23948 ; VA 0x00b3e480 ; FUN_00b3e480 */

void __fastcall FUN_00b3e480(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23949 ; VA 0x00b3e520 ; FUN_00b3e520 */

void __fastcall FUN_00b3e520(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23950 ; VA 0x00b3e5c0 ; FUN_00b3e5c0 */

void __fastcall FUN_00b3e5c0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23951 ; VA 0x00b3e660 ; FUN_00b3e660 */

void __fastcall FUN_00b3e660(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23952 ; VA 0x00b3e700 ; FUN_00b3e700 */

void __fastcall FUN_00b3e700(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23953 ; VA 0x00b3e798 ; FUN_00b3e798 */

void FUN_00b3e798(void)

{
  FUN_00b3e860();
  return;
}



/* FUNCTION 23954 ; VA 0x00b3e7a3 ; FUN_00b3e7a3 */

void FUN_00b3e7a3(void)

{
  FUN_00b3e860();
  return;
}



/* FUNCTION 23955 ; VA 0x00b3e7ab ; FUN_00b3e7ab */

void FUN_00b3e7ab(void)

{
  FUN_00b3e890();
  return;
}



/* FUNCTION 23956 ; VA 0x00b3e7b6 ; FUN_00b3e7b6 */

void FUN_00b3e7b6(void)

{
  FUN_00b3e890();
  return;
}



/* FUNCTION 23957 ; VA 0x00b3e7be ; FUN_00b3e7be */

void FUN_00b3e7be(void)

{
  FUN_00b3e8c0();
  return;
}



/* FUNCTION 23958 ; VA 0x00b3e7c9 ; FUN_00b3e7c9 */

void FUN_00b3e7c9(void)

{
  FUN_00b3e8c0();
  return;
}



/* FUNCTION 23959 ; VA 0x00b3e7d1 ; FUN_00b3e7d1 */

void FUN_00b3e7d1(void)

{
  FUN_00b3e8f0();
  return;
}



/* FUNCTION 23960 ; VA 0x00b3e7dc ; FUN_00b3e7dc */

void FUN_00b3e7dc(void)

{
  FUN_00b3e8f0();
  return;
}



/* FUNCTION 23961 ; VA 0x00b3e7e4 ; FUN_00b3e7e4 */

void FUN_00b3e7e4(void)

{
  FUN_00b3e920();
  return;
}



/* FUNCTION 23962 ; VA 0x00b3e7ef ; FUN_00b3e7ef */

void FUN_00b3e7ef(void)

{
  FUN_00b3e920();
  return;
}



/* FUNCTION 23963 ; VA 0x00b3e7f7 ; FUN_00b3e7f7 */

void FUN_00b3e7f7(void)

{
  FUN_00b3e950();
  return;
}



/* FUNCTION 23964 ; VA 0x00b3e802 ; FUN_00b3e802 */

void FUN_00b3e802(void)

{
  FUN_00b3e950();
  return;
}



/* FUNCTION 23965 ; VA 0x00b3e80a ; FUN_00b3e80a */

void FUN_00b3e80a(void)

{
  FUN_00b3e980();
  return;
}



/* FUNCTION 23966 ; VA 0x00b3e815 ; FUN_00b3e815 */

void FUN_00b3e815(void)

{
  FUN_00b3e980();
  return;
}



/* FUNCTION 23967 ; VA 0x00b3e81d ; FUN_00b3e81d */

void FUN_00b3e81d(void)

{
  FUN_00b3eac0();
  return;
}



/* FUNCTION 23968 ; VA 0x00b3e825 ; FUN_00b3e825 */

void FUN_00b3e825(void)

{
  FUN_00b3eb40();
  return;
}



/* FUNCTION 23969 ; VA 0x00b3e82d ; FUN_00b3e82d */

void FUN_00b3e82d(void)

{
  FUN_00b3ebc0();
  return;
}



/* FUNCTION 23970 ; VA 0x00b3e835 ; FUN_00b3e835 */

void FUN_00b3e835(void)

{
  FUN_00b3ec40();
  return;
}



/* FUNCTION 23971 ; VA 0x00b3e83d ; FUN_00b3e83d */

void FUN_00b3e83d(void)

{
  FUN_00b3ecc0();
  return;
}



/* FUNCTION 23972 ; VA 0x00b3e845 ; FUN_00b3e845 */

void FUN_00b3e845(void)

{
  FUN_00b3ed40();
  return;
}



/* FUNCTION 23973 ; VA 0x00b3e84d ; FUN_00b3e84d */

void FUN_00b3e84d(void)

{
  FUN_00b3edc0();
  return;
}



/* FUNCTION 23974 ; VA 0x00b3e860 ; FUN_00b3e860 */

undefined4 __thiscall FUN_00b3e860(undefined4 param_1,byte param_2)

{
  FUN_00b3e340();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23975 ; VA 0x00b3e890 ; FUN_00b3e890 */

undefined4 __thiscall FUN_00b3e890(undefined4 param_1,byte param_2)

{
  FUN_00b3e3e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23976 ; VA 0x00b3e8c0 ; FUN_00b3e8c0 */

undefined4 __thiscall FUN_00b3e8c0(undefined4 param_1,byte param_2)

{
  FUN_00b3e480();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23977 ; VA 0x00b3e8f0 ; FUN_00b3e8f0 */

undefined4 __thiscall FUN_00b3e8f0(undefined4 param_1,byte param_2)

{
  FUN_00b3e520();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23978 ; VA 0x00b3e920 ; FUN_00b3e920 */

undefined4 __thiscall FUN_00b3e920(undefined4 param_1,byte param_2)

{
  FUN_00b3e5c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23979 ; VA 0x00b3e950 ; FUN_00b3e950 */

undefined4 __thiscall FUN_00b3e950(undefined4 param_1,byte param_2)

{
  FUN_00b3e660();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23980 ; VA 0x00b3e980 ; FUN_00b3e980 */

undefined4 __thiscall FUN_00b3e980(undefined4 param_1,byte param_2)

{
  FUN_00b3e700();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 23981 ; VA 0x00b3e9b0 ; FUN_00b3e9b0 */

undefined4 __thiscall FUN_00b3e9b0(undefined4 param_1,byte param_2)

{
  FUN_00b3d0e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xfc);
  }
  return param_1;
}



/* FUNCTION 23982 ; VA 0x00b3e9e0 ; FUN_00b3e9e0 */

undefined4 __thiscall FUN_00b3e9e0(undefined4 param_1,byte param_2)

{
  FUN_00b3d210();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 23983 ; VA 0x00b3ea10 ; FUN_00b3ea10 */

undefined4 * __thiscall FUN_00b3ea10(undefined4 *param_1,byte param_2)

{
  param_1[5] = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  param_1[1] = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  *param_1 = boost::date_time::dst_day_calc_rule<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 23984 ; VA 0x00b3ea50 ; FUN_00b3ea50 */

undefined4 * __thiscall FUN_00b3ea50(undefined4 *param_1,byte param_2)

{
  param_1[3] = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  param_1[1] = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  *param_1 = boost::date_time::dst_day_calc_rule<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 23985 ; VA 0x00b3ea90 ; FUN_00b3ea90 */

undefined4 * __thiscall FUN_00b3ea90(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::date_time::dst_day_calc_rule<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23986 ; VA 0x00b3eac0 ; FUN_00b3eac0 */

undefined4 * __thiscall FUN_00b3eac0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::ambiguous_result>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23987 ; VA 0x00b3eb40 ; FUN_00b3eb40 */

undefined4 * __thiscall FUN_00b3eb40(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23988 ; VA 0x00b3ebc0 ; FUN_00b3ebc0 */

undefined4 * __thiscall FUN_00b3ebc0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>
             ::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23989 ; VA 0x00b3ec40 ; FUN_00b3ec40 */

undefined4 * __thiscall FUN_00b3ec40(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23990 ; VA 0x00b3ecc0 ; FUN_00b3ecc0 */

undefined4 * __thiscall FUN_00b3ecc0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>::
             vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23991 ; VA 0x00b3ed40 ; FUN_00b3ed40 */

undefined4 * __thiscall FUN_00b3ed40(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             error_info_injector<struct_boost::local_time::time_label_invalid>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23992 ; VA 0x00b3edc0 ; FUN_00b3edc0 */

undefined4 * __thiscall FUN_00b3edc0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::invalid_argument>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23993 ; VA 0x00b3ee40 ; FUN_00b3ee40 */

undefined4 * __thiscall FUN_00b3ee40(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 23994 ; VA 0x00b3ee70 ; FUN_00b3ee70 */

undefined4 * __thiscall FUN_00b3ee70(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 23995 ; VA 0x00b3eea0 ; FUN_00b3eea0 */

undefined4 * __thiscall FUN_00b3eea0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::local_time::posix_time_zone_base<char>::vftable;
  piVar2 = (int *)param_1[0x23];
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 8))();
      }
    }
  }
  FUN_006375f0();
  *param_1 = boost::date_time::time_zone_base<class_boost::posix_time::ptime,char>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x90);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23996 ; VA 0x00b3ef30 ; FUN_00b3ef30 */

int __thiscall FUN_00b3ef30(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x110);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xfc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0xf;
  *(undefined *)(param_1 + 0xfc) = 0;
  FUN_00b3d0e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x114);
  }
  return param_1;
}



/* FUNCTION 23997 ; VA 0x00b3efb0 ; FUN_00b3efb0 */

int __thiscall FUN_00b3efb0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0xec);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xd8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0xf;
  *(undefined *)(param_1 + 0xd8) = 0;
  FUN_00b3d210();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf0);
  }
  return param_1;
}



/* FUNCTION 23998 ; VA 0x00b3f030 ; FUN_00b3f030 */

undefined4 * __thiscall FUN_00b3f030(undefined4 *param_1,byte param_2)

{
  *param_1 = std::
             time_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>::
             vftable;
  FUN_017168b0(param_1[2]);
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 23999 ; VA 0x00b3f070 ; FUN_00b3f070 */

undefined4 * __thiscall FUN_00b3f070(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::date_time::time_zone_base<class_boost::posix_time::ptime,char>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}


