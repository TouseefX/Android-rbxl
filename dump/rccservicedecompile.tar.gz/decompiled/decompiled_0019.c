/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 4750 ; VA 0x005aabb0 ; FUN_005aabb0 */

undefined4
FUN_005aabb0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x17);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4751 ; VA 0x005aac00 ; FUN_005aac00 */

undefined4
FUN_005aac00(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x16);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4752 ; VA 0x005aac50 ; FUN_005aac50 */

undefined4
FUN_005aac50(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x18);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4753 ; VA 0x005aaca0 ; FUN_005aaca0 */

undefined4
FUN_005aaca0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x19);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4754 ; VA 0x005aacf0 ; FUN_005aacf0 */

undefined4
FUN_005aacf0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xc);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4755 ; VA 0x005aad40 ; FUN_005aad40 */

undefined4
FUN_005aad40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xb);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4756 ; VA 0x005aad90 ; FUN_005aad90 */

undefined4
FUN_005aad90(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,9);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4757 ; VA 0x005aade0 ; FUN_005aade0 */

undefined4
FUN_005aade0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xd);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4758 ; VA 0x005aae30 ; FUN_005aae30 */

undefined4
FUN_005aae30(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,10);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4759 ; VA 0x005aae80 ; FUN_005aae80 */

undefined4
FUN_005aae80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,8);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4760 ; VA 0x005aaed0 ; FUN_005aaed0 */

undefined4
FUN_005aaed0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x33);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005ab2d0(param_1,param_2,iVar1,*param_4,param_5);
  return uVar2;
}



/* FUNCTION 4761 ; VA 0x005aaf20 ; FUN_005aaf20 */

undefined4
FUN_005aaf20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  
  puVar1 = param_4;
  param_4 = (undefined4 *)FUN_005b10f0(param_1,*param_4);
  uVar2 = FUN_005b44d0(param_1,param_3,puVar1,0xac,param_5);
  iVar3 = FUN_005b3c80(param_1,param_2,uVar2);
  if (iVar3 == 0) {
    iVar3 = FUN_005b8840(param_1,"SOAP-ENV:Value",0xffffffff,&param_4,&DAT_018bc9b8,5);
    if (iVar3 == 0) {
      iVar3 = FUN_005b3f00(param_1,"SOAP-ENV:Subcode",0xffffffff,puVar1[1],0,0,&DAT_018bc9b8,0xac);
      if (iVar3 < 0) {
        iVar3 = *(int *)(param_1 + 0x1615c);
      }
      else {
        iVar3 = FUN_005aaf20(param_1,"SOAP-ENV:Subcode",iVar3,puVar1[1],&DAT_018bc9b8);
      }
      if (iVar3 == 0) {
        uVar2 = FUN_005b3e10(param_1,param_2);
        return uVar2;
      }
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4762 ; VA 0x005aafe0 ; FUN_005aafe0 */

undefined4
FUN_005aafe0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,0xae,param_5);
  iVar2 = FUN_005b3c80(param_1,param_2,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ae400(param_1,param_4[1],"fault",0xffffffff,*param_4);
    if (iVar2 == 0) {
      FUN_005b86c0(param_1,&DAT_018c22a8,param_4 + 2,0);
      uVar1 = FUN_005b3e10(param_1,param_2);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4763 ; VA 0x005ab060 ; FUN_005ab060 */

undefined4
FUN_005ab060(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  
  puVar1 = param_4;
  param_4 = (undefined4 *)FUN_005b10f0(param_1,*param_4);
  uVar2 = FUN_005b44d0(param_1,param_3,puVar1,0xb2,param_5);
  iVar3 = FUN_005b3c80(param_1,param_2,uVar2);
  if (iVar3 == 0) {
    iVar3 = FUN_005b8840(param_1,"faultcode",0xffffffff,&param_4,&DAT_018bc9b8,5);
    if (iVar3 == 0) {
      iVar3 = FUN_005b8840(param_1,"faultstring",0xffffffff,puVar1 + 1,&DAT_018bc9b8,4);
      if (iVar3 == 0) {
        iVar3 = FUN_005b8840(param_1,"faultactor",0xffffffff,puVar1 + 2,&DAT_018bc9b8,4);
        if (iVar3 == 0) {
          iVar3 = FUN_005aa110(param_1,"detail",0xffffffff,puVar1 + 3,&DAT_018bc9b8);
          if (iVar3 == 0) {
            iVar3 = FUN_005aa0c0(param_1,"SOAP-ENV:Code",0xffffffff,puVar1 + 4,&DAT_018bc9b8);
            if (iVar3 == 0) {
              iVar3 = FUN_005aa160(param_1,"SOAP-ENV:Reason",0xffffffff,puVar1 + 5,&DAT_018bc9b8);
              if (iVar3 == 0) {
                iVar3 = FUN_005b8840(param_1,"SOAP-ENV:Node",0xffffffff,puVar1 + 6,&DAT_018bc9b8,4);
                if (iVar3 == 0) {
                  iVar3 = FUN_005b8840(param_1,"SOAP-ENV:Role",0xffffffff,puVar1 + 7,&DAT_018bc9b8,4
                                      );
                  if (iVar3 == 0) {
                    iVar3 = FUN_005aa110(param_1,"SOAP-ENV:Detail",0xffffffff,puVar1 + 8,
                                         &DAT_018bc9b8);
                    if (iVar3 == 0) {
                      uVar2 = FUN_005b3e10(param_1,param_2);
                      return uVar2;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4764 ; VA 0x005ab1e0 ; FUN_005ab1e0 */

undefined4
FUN_005ab1e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,0xb1,param_5);
  iVar2 = FUN_005b3c80(param_1,param_2,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b8840(param_1,"SOAP-ENV:Text",0xffffffff,param_4,&DAT_018bc9b8,4);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_1,param_2);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4765 ; VA 0x005ab250 ; FUN_005ab250 */

undefined4
FUN_005ab250(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,0x32,param_5);
  iVar2 = FUN_005b3c80(param_1,param_2,uVar1);
  if (iVar2 == 0) {
    uVar1 = *param_4;
    iVar2 = FUN_005b3050(&DAT_018c16b4,uVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b7f00(param_1,uVar1);
    }
    iVar2 = FUN_005bbfb0(param_1,iVar2);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_1,param_2);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4766 ; VA 0x005ab2d0 ; FUN_005ab2d0 */

undefined4
FUN_005ab2d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  if (((*(uint *)(param_1 + 8) & 0x800000) != 0) && (param_4[4] == 0)) {
    uVar1 = FUN_005b4030(param_1,param_2,param_3,param_5);
    return uVar1;
  }
  uVar1 = FUN_005b44d0(param_1,param_3,param_4,0x33,param_5);
  iVar2 = FUN_005b3c80(param_1,param_2,uVar1);
  if (iVar2 == 0) {
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    iVar2 = FUN_005bd9a0(param_1,param_4,0);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3e10(param_1,param_2);
      if (iVar2 == 0) {
        return 0;
      }
    }
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4767 ; VA 0x005ab360 ; FUN_005ab360 */

undefined4 FUN_005ab360(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_4;
  if (puVar2 != (undefined4 *)param_4[1]) {
    do {
      iVar1 = FUN_005b3f00(param_1,param_2,param_3,*puVar2,0,0,&DAT_018bc9b8,9);
      if (iVar1 < 0) {
        iVar1 = *(int *)(param_1 + 0x1615c);
      }
      else {
        iVar1 = (**(code **)(*(int *)*puVar2 + 0x10))(param_1,param_2,iVar1,&DAT_018bc9b8);
      }
      if (iVar1 != 0) {
        return *(undefined4 *)(param_1 + 0x1615c);
      }
      puVar2 = puVar2 + 1;
    } while (puVar2 != (undefined4 *)param_4[1]);
  }
  return 0;
}



/* FUNCTION 4768 ; VA 0x005ab3d0 ; FUN_005ab3d0 */

undefined4 FUN_005ab3d0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_4;
  if (puVar2 != (undefined4 *)param_4[1]) {
    do {
      iVar1 = FUN_005b3f00(param_1,param_2,param_3,*puVar2,0,0,&DAT_018bc9b8,0xd);
      if (iVar1 < 0) {
        iVar1 = *(int *)(param_1 + 0x1615c);
      }
      else {
        iVar1 = (**(code **)(*(int *)*puVar2 + 0x10))(param_1,param_2,iVar1,&DAT_018bc9b8);
      }
      if (iVar1 != 0) {
        return *(undefined4 *)(param_1 + 0x1615c);
      }
      puVar2 = puVar2 + 1;
    } while (puVar2 != (undefined4 *)param_4[1]);
  }
  return 0;
}



/* FUNCTION 4769 ; VA 0x005ab440 ; FUN_005ab440 */

undefined4 __thiscall FUN_005ab440(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x20);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4770 ; VA 0x005ab490 ; FUN_005ab490 */

undefined4 __thiscall FUN_005ab490(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x22);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4771 ; VA 0x005ab4e0 ; FUN_005ab4e0 */

undefined4 __thiscall FUN_005ab4e0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x23);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4772 ; VA 0x005ab530 ; FUN_005ab530 */

undefined4 __thiscall FUN_005ab530(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x21);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4773 ; VA 0x005ab580 ; FUN_005ab580 */

undefined4 __thiscall FUN_005ab580(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2c);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4774 ; VA 0x005ab5d0 ; FUN_005ab5d0 */

undefined4 __thiscall FUN_005ab5d0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2d);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4775 ; VA 0x005ab620 ; FUN_005ab620 */

undefined4 __thiscall FUN_005ab620(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2a);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4776 ; VA 0x005ab670 ; FUN_005ab670 */

undefined4 __thiscall FUN_005ab670(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2b);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4777 ; VA 0x005ab6c0 ; FUN_005ab6c0 */

undefined4 __thiscall FUN_005ab6c0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1e);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4778 ; VA 0x005ab710 ; FUN_005ab710 */

undefined4 __thiscall FUN_005ab710(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1f);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4779 ; VA 0x005ab760 ; FUN_005ab760 */

undefined4 __thiscall FUN_005ab760(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2e);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4780 ; VA 0x005ab7b0 ; FUN_005ab7b0 */

undefined4 __thiscall FUN_005ab7b0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x30);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4781 ; VA 0x005ab800 ; FUN_005ab800 */

undefined4 __thiscall FUN_005ab800(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x31);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4782 ; VA 0x005ab850 ; FUN_005ab850 */

undefined4 __thiscall FUN_005ab850(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x2f);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4783 ; VA 0x005ab8a0 ; FUN_005ab8a0 */

undefined4 __thiscall FUN_005ab8a0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1a);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4784 ; VA 0x005ab8f0 ; FUN_005ab8f0 */

undefined4 __thiscall FUN_005ab8f0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1c);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4785 ; VA 0x005ab940 ; FUN_005ab940 */

undefined4 __thiscall FUN_005ab940(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1d);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4786 ; VA 0x005ab990 ; FUN_005ab990 */

undefined4 __thiscall FUN_005ab990(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x1b);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4787 ; VA 0x005ab9e0 ; FUN_005ab9e0 */

undefined4 __thiscall FUN_005ab9e0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x26);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4788 ; VA 0x005aba30 ; FUN_005aba30 */

undefined4 __thiscall FUN_005aba30(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x28);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4789 ; VA 0x005aba80 ; FUN_005aba80 */

undefined4 __thiscall FUN_005aba80(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x29);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4790 ; VA 0x005abad0 ; FUN_005abad0 */

undefined4 __thiscall FUN_005abad0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x27);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4791 ; VA 0x005abb20 ; FUN_005abb20 */

undefined4 __thiscall FUN_005abb20(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x24);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4792 ; VA 0x005abb70 ; FUN_005abb70 */

undefined4 __thiscall FUN_005abb70(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x25);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4793 ; VA 0x005abbc0 ; FUN_005abbc0 */

undefined4 __thiscall FUN_005abbc0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x12);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4794 ; VA 0x005abc10 ; FUN_005abc10 */

undefined4 __thiscall FUN_005abc10(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x13);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4795 ; VA 0x005abc60 ; FUN_005abc60 */

undefined4 __thiscall FUN_005abc60(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x10);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4796 ; VA 0x005abcb0 ; FUN_005abcb0 */

undefined4 __thiscall FUN_005abcb0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x11);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4797 ; VA 0x005abd00 ; FUN_005abd00 */

undefined4 __thiscall FUN_005abd00(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0xe);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4798 ; VA 0x005abd50 ; FUN_005abd50 */

undefined4 __thiscall FUN_005abd50(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0xf);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4799 ; VA 0x005abda0 ; FUN_005abda0 */

undefined4 __thiscall FUN_005abda0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x14);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4800 ; VA 0x005abdf0 ; FUN_005abdf0 */

undefined4 __thiscall FUN_005abdf0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x15);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4801 ; VA 0x005abe40 ; FUN_005abe40 */

undefined4 __thiscall FUN_005abe40(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x17);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4802 ; VA 0x005abe90 ; FUN_005abe90 */

undefined4 __thiscall FUN_005abe90(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x16);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4803 ; VA 0x005abee0 ; FUN_005abee0 */

undefined4 __thiscall FUN_005abee0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x18);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4804 ; VA 0x005abf30 ; FUN_005abf30 */

undefined4 __thiscall FUN_005abf30(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0x19);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4805 ; VA 0x005abf80 ; FUN_005abf80 */

undefined4 __thiscall FUN_005abf80(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0xc);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4806 ; VA 0x005abfd0 ; FUN_005abfd0 */

undefined4 __thiscall FUN_005abfd0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0xb);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4807 ; VA 0x005ac020 ; FUN_005ac020 */

undefined4 __thiscall FUN_005ac020(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,9);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4808 ; VA 0x005ac070 ; FUN_005ac070 */

undefined4 __thiscall FUN_005ac070(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,0xd);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4809 ; VA 0x005ac0c0 ; FUN_005ac0c0 */

undefined4 __thiscall FUN_005ac0c0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,10);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4810 ; VA 0x005ac110 ; FUN_005ac110 */

undefined4 __thiscall FUN_005ac110(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b43f0(param_2,param_1,0,0,param_3,8);
  iVar2 = (**(code **)(*param_1 + 0x10))(param_2,param_3,uVar1,param_4);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_2);
  return uVar1;
}



/* FUNCTION 4811 ; VA 0x005ac160 ; FUN_005ac160 */

undefined4 FUN_005ac160(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  
  if (((*(short *)(param_1 + 6) == 1) && (*(int *)(param_1 + 0x28) != 0)) &&
     ((*(uint *)(param_1 + 8) & 0x18000) == 0)) {
    puVar2 = (undefined4 *)(param_1 + 0x1fa4);
    iVar4 = 0;
    do {
      for (puVar1 = (undefined4 *)*puVar2; puVar1 != (undefined4 *)0x0;
          puVar1 = (undefined4 *)*puVar1) {
        if (((*(char *)(puVar1 + 5) == '\x02') || (*(char *)((int)puVar1 + 0x15) == '\x02')) &&
           (iVar3 = FUN_005ae400(param_1,puVar1[1],&DAT_018c1fd8,puVar1[4],puVar1[3]), iVar3 != 0))
        {
          return *(undefined4 *)(param_1 + 0x1615c);
        }
      }
      iVar4 = iVar4 + 1;
      puVar2 = puVar2 + 1;
    } while (iVar4 < 0x400);
  }
  return 0;
}



/* FUNCTION 4812 ; VA 0x005ac1f0 ; FUN_005ac1f0 */

void __thiscall FUN_005ac1f0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),9);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 4) + 8))(param_2);
  }
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 8),10);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 8) + 8))(param_2);
  }
  return;
}



/* FUNCTION 4813 ; VA 0x005ac240 ; FUN_005ac240 */

void __thiscall FUN_005ac240(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),0xb);
  if (iVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005ac261. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 4) + 8))();
    return;
  }
  return;
}



/* FUNCTION 4814 ; VA 0x005ac270 ; FUN_005ac270 */

void __thiscall FUN_005ac270(int param_1,undefined4 param_2)

{
  FUN_005ac970(param_2,param_1 + 4);
  return;
}



/* FUNCTION 4815 ; VA 0x005ac290 ; FUN_005ac290 */

void __thiscall FUN_005ac290(int param_1,undefined4 param_2)

{
  FUN_005b44a0(param_2,param_1 + 4,0x33);
  return;
}



/* FUNCTION 4816 ; VA 0x005ac2b0 ; FUN_005ac2b0 */

void __thiscall FUN_005ac2b0(int param_1,undefined4 param_2)

{
  FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 8),0x33);
  return;
}



/* FUNCTION 4817 ; VA 0x005ac2d0 ; FUN_005ac2d0 */

void __thiscall FUN_005ac2d0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_005b44a0(param_2,param_1 + 4,0x33);
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 0x1c),10);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 0x1c) + 8))(param_2);
  }
  return;
}



/* FUNCTION 4818 ; VA 0x005ac310 ; FUN_005ac310 */

void __thiscall FUN_005ac310(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),0xc);
  if (iVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005ac331. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 4) + 8))();
    return;
  }
  return;
}



/* FUNCTION 4819 ; VA 0x005ac340 ; FUN_005ac340 */

void __thiscall FUN_005ac340(int param_1,undefined4 param_2)

{
  FUN_005ac930(param_2,param_1 + 4);
  return;
}



/* FUNCTION 4820 ; VA 0x005ac360 ; FUN_005ac360 */

void __thiscall FUN_005ac360(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),8);
  if (iVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005ac381. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 4) + 8))();
    return;
  }
  return;
}



/* FUNCTION 4821 ; VA 0x005ac390 ; FUN_005ac390 */

void __thiscall FUN_005ac390(int param_1,undefined4 param_2)

{
  FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),0x33);
  return;
}



/* FUNCTION 4822 ; VA 0x005ac3b0 ; FUN_005ac3b0 */

void __thiscall FUN_005ac3b0(int param_1,undefined4 param_2)

{
  FUN_005b44a0(param_2,param_1 + 8,0x33);
  return;
}



/* FUNCTION 4823 ; VA 0x005ac3d0 ; FUN_005ac3d0 */

void __thiscall FUN_005ac3d0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 8),0x33);
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 0xc),0xb);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 8))(param_2);
  }
  return;
}



/* FUNCTION 4824 ; VA 0x005ac410 ; FUN_005ac410 */

void __thiscall FUN_005ac410(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 4),0x33);
  FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 8),0x33);
  iVar1 = FUN_005bb2a0(param_2,*(undefined4 *)(param_1 + 0xc),0xb);
  if (iVar1 == 0) {
    (**(code **)(**(int **)(param_1 + 0xc) + 8))(param_2);
  }
  return;
}



/* FUNCTION 4825 ; VA 0x005ac460 ; FUN_005ac460 */

void FUN_005ac460(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_005bb2a0(param_1,*param_2,0xac);
  while (iVar2 == 0) {
    puVar1 = (undefined4 *)*param_2;
    FUN_005bb2a0(param_1,*puVar1,4);
    param_2 = puVar1 + 1;
    iVar2 = FUN_005bb2a0(param_1,*param_2,0xac);
  }
  return;
}



/* FUNCTION 4826 ; VA 0x005ac4b0 ; FUN_005ac4b0 */

void FUN_005ac4b0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x20);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4827 ; VA 0x005ac4e0 ; FUN_005ac4e0 */

void FUN_005ac4e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x22);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4828 ; VA 0x005ac510 ; FUN_005ac510 */

void FUN_005ac510(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x2c);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4829 ; VA 0x005ac540 ; FUN_005ac540 */

void FUN_005ac540(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x2a);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4830 ; VA 0x005ac570 ; FUN_005ac570 */

void FUN_005ac570(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x1e);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4831 ; VA 0x005ac5a0 ; FUN_005ac5a0 */

void FUN_005ac5a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x2e);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4832 ; VA 0x005ac5d0 ; FUN_005ac5d0 */

void FUN_005ac5d0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x30);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4833 ; VA 0x005ac600 ; FUN_005ac600 */

void FUN_005ac600(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x1a);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4834 ; VA 0x005ac630 ; FUN_005ac630 */

void FUN_005ac630(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x1c);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4835 ; VA 0x005ac660 ; FUN_005ac660 */

void FUN_005ac660(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x26);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4836 ; VA 0x005ac690 ; FUN_005ac690 */

void FUN_005ac690(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x28);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4837 ; VA 0x005ac6c0 ; FUN_005ac6c0 */

void FUN_005ac6c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x24);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4838 ; VA 0x005ac6f0 ; FUN_005ac6f0 */

void FUN_005ac6f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x12);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4839 ; VA 0x005ac720 ; FUN_005ac720 */

void FUN_005ac720(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x10);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4840 ; VA 0x005ac750 ; FUN_005ac750 */

void FUN_005ac750(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0xe);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4841 ; VA 0x005ac780 ; FUN_005ac780 */

void FUN_005ac780(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x14);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4842 ; VA 0x005ac7b0 ; FUN_005ac7b0 */

void FUN_005ac7b0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x15);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4843 ; VA 0x005ac7e0 ; FUN_005ac7e0 */

void FUN_005ac7e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0x18);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4844 ; VA 0x005ac810 ; FUN_005ac810 */

void FUN_005ac810(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0xc);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4845 ; VA 0x005ac840 ; FUN_005ac840 */

void FUN_005ac840(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0xb);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4846 ; VA 0x005ac870 ; FUN_005ac870 */

void FUN_005ac870(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,9);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4847 ; VA 0x005ac8a0 ; FUN_005ac8a0 */

void FUN_005ac8a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,0xd);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4848 ; VA 0x005ac8d0 ; FUN_005ac8d0 */

void FUN_005ac8d0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,10);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4849 ; VA 0x005ac900 ; FUN_005ac900 */

void FUN_005ac900(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_005bb2a0(param_1,*param_2,8);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
  }
  return;
}



/* FUNCTION 4850 ; VA 0x005ac930 ; FUN_005ac930 */

void FUN_005ac930(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_2;
  if (puVar2 != (undefined4 *)param_2[1]) {
    do {
      iVar1 = FUN_005bb2a0(param_1,*puVar2,9);
      if (iVar1 == 0) {
        (**(code **)(*(int *)*puVar2 + 8))(param_1);
      }
      puVar2 = puVar2 + 1;
    } while (puVar2 != (undefined4 *)param_2[1]);
  }
  return;
}



/* FUNCTION 4851 ; VA 0x005ac970 ; FUN_005ac970 */

void FUN_005ac970(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)*param_2;
  if (puVar2 != (undefined4 *)param_2[1]) {
    do {
      iVar1 = FUN_005bb2a0(param_1,*puVar2,0xd);
      if (iVar1 == 0) {
        (**(code **)(*(int *)*puVar2 + 8))(param_1);
      }
      puVar2 = puVar2 + 1;
    } while (puVar2 != (undefined4 *)param_2[1]);
  }
  return;
}



/* FUNCTION 4852 ; VA 0x005ac9b0 ; FUN_005ac9b0 */

undefined4 FUN_005ac9b0(void)

{
  return 0x22;
}



/* FUNCTION 4853 ; VA 0x005ac9c0 ; FUN_005ac9c0 */

undefined4 FUN_005ac9c0(void)

{
  return 0x23;
}



/* FUNCTION 4854 ; VA 0x005ac9d0 ; FUN_005ac9d0 */

undefined4 FUN_005ac9d0(void)

{
  return 0x2c;
}



/* FUNCTION 4855 ; VA 0x005ac9e0 ; FUN_005ac9e0 */

undefined4 FUN_005ac9e0(void)

{
  return 0x2d;
}



/* FUNCTION 4856 ; VA 0x005ac9f0 ; FUN_005ac9f0 */

undefined4 FUN_005ac9f0(void)

{
  return 0x2a;
}



/* FUNCTION 4857 ; VA 0x005aca00 ; FUN_005aca00 */

undefined4 FUN_005aca00(void)

{
  return 0x2b;
}



/* FUNCTION 4858 ; VA 0x005aca10 ; FUN_005aca10 */

undefined4 FUN_005aca10(void)

{
  return 0x1e;
}



/* FUNCTION 4859 ; VA 0x005aca20 ; FUN_005aca20 */

undefined4 FUN_005aca20(void)

{
  return 0x1f;
}



/* FUNCTION 4860 ; VA 0x005aca30 ; FUN_005aca30 */

undefined4 FUN_005aca30(void)

{
  return 0x2e;
}



/* FUNCTION 4861 ; VA 0x005aca40 ; FUN_005aca40 */

undefined4 FUN_005aca40(void)

{
  return 0x30;
}



/* FUNCTION 4862 ; VA 0x005aca50 ; FUN_005aca50 */

undefined4 FUN_005aca50(void)

{
  return 0x31;
}



/* FUNCTION 4863 ; VA 0x005aca60 ; FUN_005aca60 */

undefined4 FUN_005aca60(void)

{
  return 0x2f;
}



/* FUNCTION 4864 ; VA 0x005aca70 ; FUN_005aca70 */

undefined4 FUN_005aca70(void)

{
  return 0x1a;
}



/* FUNCTION 4865 ; VA 0x005aca80 ; FUN_005aca80 */

undefined4 FUN_005aca80(void)

{
  return 0x1c;
}



/* FUNCTION 4866 ; VA 0x005aca90 ; FUN_005aca90 */

undefined4 FUN_005aca90(void)

{
  return 0x1d;
}



/* FUNCTION 4867 ; VA 0x005acaa0 ; FUN_005acaa0 */

undefined4 FUN_005acaa0(void)

{
  return 0x1b;
}



/* FUNCTION 4868 ; VA 0x005acab0 ; FUN_005acab0 */

undefined4 FUN_005acab0(void)

{
  return 0x26;
}



/* FUNCTION 4869 ; VA 0x005acac0 ; FUN_005acac0 */

undefined4 FUN_005acac0(void)

{
  return 0x28;
}



/* FUNCTION 4870 ; VA 0x005acad0 ; FUN_005acad0 */

undefined4 FUN_005acad0(void)

{
  return 0x29;
}



/* FUNCTION 4871 ; VA 0x005acae0 ; FUN_005acae0 */

undefined4 FUN_005acae0(void)

{
  return 0x27;
}



/* FUNCTION 4872 ; VA 0x005acaf0 ; FUN_005acaf0 */

undefined4 FUN_005acaf0(void)

{
  return 0x24;
}



/* FUNCTION 4873 ; VA 0x005acb00 ; FUN_005acb00 */

undefined4 FUN_005acb00(void)

{
  return 0x25;
}



/* FUNCTION 4874 ; VA 0x005acb10 ; FUN_005acb10 */

undefined4 FUN_005acb10(void)

{
  return 0x12;
}



/* FUNCTION 4875 ; VA 0x005acb20 ; FUN_005acb20 */

undefined4 FUN_005acb20(void)

{
  return 0x13;
}



/* FUNCTION 4876 ; VA 0x005acb30 ; FUN_005acb30 */

undefined4 FUN_005acb30(void)

{
  return 0x10;
}



/* FUNCTION 4877 ; VA 0x005acb40 ; FUN_005acb40 */

undefined4 FUN_005acb40(void)

{
  return 0x11;
}



/* FUNCTION 4878 ; VA 0x005acb50 ; FUN_005acb50 */

undefined4 FUN_005acb50(void)

{
  return 0xe;
}



/* FUNCTION 4879 ; VA 0x005acb60 ; FUN_005acb60 */

undefined4 FUN_005acb60(void)

{
  return 0xf;
}



/* FUNCTION 4880 ; VA 0x005acb70 ; FUN_005acb70 */

undefined4 FUN_005acb70(void)

{
  return 0x15;
}



/* FUNCTION 4881 ; VA 0x005acb80 ; FUN_005acb80 */

undefined4 FUN_005acb80(void)

{
  return 0x17;
}



/* FUNCTION 4882 ; VA 0x005acb90 ; FUN_005acb90 */

undefined4 FUN_005acb90(void)

{
  return 0x18;
}



/* FUNCTION 4883 ; VA 0x005acba0 ; FUN_005acba0 */

undefined4 FUN_005acba0(void)

{
  return 0x19;
}



/* FUNCTION 4884 ; VA 0x005acbb0 ; FUN_005acbb0 */

undefined4 FUN_005acbb0(void)

{
  return 0xc;
}



/* FUNCTION 4885 ; VA 0x005acbc0 ; FUN_005acbc0 */

undefined4 FUN_005acbc0(void)

{
  return 0xb;
}



/* FUNCTION 4886 ; VA 0x005acbd0 ; FUN_005acbd0 */

undefined4 FUN_005acbd0(void)

{
  return 0xd;
}



/* FUNCTION 4887 ; VA 0x005acbe0 ; FUN_005acbe0 */

undefined4 FUN_005acbe0(void)

{
  return 8;
}



/* FUNCTION 4888 ; VA 0x005acbf0 ; FUN_005acbf0 */

void FUN_005acbf0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  short sVar5;
  
  if (*(int *)(param_1 + 0x2fb0) == 0) {
    puVar1 = (undefined4 *)FUN_005b7ec0(param_1,0,0xb2,0xffffffff,FUN_00598780);
    puVar2 = puVar1;
    if (puVar1 != (undefined4 *)0x0) {
      puVar2 = (undefined4 *)FUN_01674e20(0x24);
      puVar1[1] = puVar2;
    }
    *(undefined4 **)(param_1 + 0x2fb0) = puVar2;
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
  }
  sVar5 = *(short *)(param_1 + 6);
  if (sVar5 == 2) {
    if (*(int *)(*(int *)(param_1 + 0x2fb0) + 0x10) != 0) goto LAB_005accda;
    iVar3 = FUN_005b7ec0(param_1,0,0xac,0xffffffff,FUN_00598780);
    iVar4 = iVar3;
    if (iVar3 != 0) {
      iVar4 = FUN_01674e20(8);
      *(int *)(iVar3 + 4) = iVar4;
    }
    *(int *)(*(int *)(param_1 + 0x2fb0) + 0x10) = iVar4;
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x2fb0) + 0x10);
    *puVar2 = 0;
    puVar2[1] = 0;
    sVar5 = *(short *)(param_1 + 6);
  }
  if (sVar5 != 2) {
    return;
  }
LAB_005accda:
  if (*(int *)(*(int *)(param_1 + 0x2fb0) + 0x14) == 0) {
    iVar3 = FUN_005b7ec0(param_1,0,0xb1,0xffffffff,FUN_00598780);
    iVar4 = iVar3;
    if (iVar3 != 0) {
      iVar4 = FUN_01674e20(4);
      *(int *)(iVar3 + 4) = iVar4;
    }
    *(int *)(*(int *)(param_1 + 0x2fb0) + 0x14) = iVar4;
    **(undefined4 **)(*(int *)(param_1 + 0x2fb0) + 0x14) = 0;
  }
  return;
}



/* FUNCTION 4889 ; VA 0x005acd30 ; FUN_005acd30 */

int FUN_005acd30(int param_1)

{
  int iVar1;
  
  FUN_005acbf0(param_1);
  iVar1 = *(int *)(param_1 + 0x2fb0);
  if (*(short *)(param_1 + 6) == 2) {
    iVar1 = *(int *)(iVar1 + 0x10);
  }
  return iVar1;
}



/* FUNCTION 4890 ; VA 0x005acd60 ; FUN_005acd60 */

int FUN_005acd60(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  FUN_005acbf0(param_1);
  iVar4 = *(int *)(param_1 + 0x2fb0);
  if (*(short *)(param_1 + 6) == 1) {
    if (*(int *)(iVar4 + 0xc) == 0) {
      uVar2 = FUN_005b7fc0(param_1,0xc);
      *(undefined4 *)(*(int *)(param_1 + 0x2fb0) + 0xc) = uVar2;
      puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x2fb0) + 0xc);
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      iVar4 = *(int *)(param_1 + 0x2fb0);
    }
    return *(int *)(iVar4 + 0xc) + 8;
  }
  if (*(int *)(iVar4 + 0x20) == 0) {
    iVar3 = FUN_005b7ec0(param_1,0,0xae,0xffffffff,FUN_00598780);
    iVar4 = iVar3;
    if (iVar3 != 0) {
      iVar4 = FUN_01674e20(0xc);
      *(int *)(iVar3 + 4) = iVar4;
    }
    *(int *)(*(int *)(param_1 + 0x2fb0) + 0x20) = iVar4;
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x2fb0) + 0x20);
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    iVar4 = *(int *)(param_1 + 0x2fb0);
  }
  return *(int *)(iVar4 + 0x20) + 8;
}



/* FUNCTION 4891 ; VA 0x005ace30 ; FUN_005ace30 */

int FUN_005ace30(int param_1)

{
  FUN_005acbf0(param_1);
  if (*(short *)(param_1 + 6) == 2) {
    return *(int *)(*(int *)(param_1 + 0x2fb0) + 0x14);
  }
  return *(int *)(param_1 + 0x2fb0) + 4;
}



/* FUNCTION 4892 ; VA 0x005ace60 ; FUN_005ace60 */

int FUN_005ace60(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  FUN_005acbf0(param_1);
  iVar2 = *(int *)(param_1 + 0x2fb0);
  if (*(short *)(param_1 + 6) == 2) {
    if (*(int *)(*(int *)(iVar2 + 0x10) + 4) == 0) {
      iVar2 = FUN_005b7ec0(param_1,0,0xac,0xffffffff,FUN_00598780);
      if (iVar2 == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_01674e20(8);
        *(undefined4 *)(iVar2 + 4) = uVar3;
      }
      *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x2fb0) + 0x10) + 4) = uVar3;
      puVar1 = *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x2fb0) + 0x10) + 4);
      *puVar1 = 0;
      puVar1[1] = 0;
      iVar2 = *(int *)(param_1 + 0x2fb0);
    }
    return *(int *)(*(int *)(iVar2 + 0x10) + 4);
  }
  return iVar2;
}



/* FUNCTION 4893 ; VA 0x005acf00 ; FUN_005acf00 */

undefined4 FUN_005acf00(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  iVar1 = FUN_005b8900(param_1);
  if (iVar1 != 0) {
    return 0;
  }
  if (*(char *)(param_1 + 0x13cb4) != '\0') {
    iVar1 = FUN_005b7f90(param_1,param_1 + 0x13cb4);
    *param_2 = iVar1;
    if (iVar1 != 0) goto LAB_005acf4e;
  }
  iVar1 = FUN_005b7f90(param_1,param_1 + 0x140b4);
  *param_2 = iVar1;
LAB_005acf4e:
  switch(*param_2) {
  case 1:
    uVar3 = FUN_005b7550(param_1,0,0,"xsd:int",1);
    return uVar3;
  case 3:
    uVar3 = FUN_005b7270(param_1,0,0,"xsd:byte",3);
    return uVar3;
  case 4:
    puVar4 = (undefined4 *)FUN_005b7b00(param_1,0,0,"xsd:string",4,1,0xffffffff,0xffffffff);
    if (puVar4 == (undefined4 *)0x0) {
      return 0;
    }
    return *puVar4;
  case 8:
    uVar3 = FUN_005a26a0(param_1,0,0,"ns1:Status");
    return uVar3;
  case 9:
    uVar3 = FUN_005a1ef0(param_1,0,0,"ns1:Job");
    return uVar3;
  case 10:
    uVar3 = FUN_005a2490(param_1,0,0,"ns1:ScriptExecution");
    return uVar3;
  case 0xb:
    uVar3 = FUN_005a1da0(param_1,0,0,"ns1:ArrayOfLuaValue");
    return uVar3;
  case 0xc:
    uVar3 = FUN_005a1c50(param_1,0,0,"ns1:ArrayOfJob");
    return uVar3;
  case 0xd:
    uVar3 = FUN_005a2280(param_1,0,0,"ns1:LuaValue");
    return uVar3;
  case 0x32:
    uVar3 = FUN_005a2170(param_1,0,0,"ns1:LuaType");
    return uVar3;
  case 0x33:
    uVar3 = FUN_005a2880(param_1,0,0,"xsd:string");
    return uVar3;
  case 0x34:
    uVar3 = FUN_0059cd50(param_1,0,0,"xsd:string");
    return uVar3;
  case 0x36:
    uVar3 = FUN_005b73b0(param_1,0,0,"xsd:double",0x36);
    return uVar3;
  case 0x37:
    uVar3 = FUN_0059c8f0(param_1,0,0,"ns1:ArrayOfLuaValue");
    return uVar3;
  case 0x38:
    uVar3 = FUN_0059ca90(param_1,0,0,"ns1:LuaValue");
    return uVar3;
  case 0x3a:
    uVar3 = FUN_0059c9c0(param_1,0,0,"ns1:Job");
    return uVar3;
  case 0x3c:
    uVar3 = FUN_0059cc30(param_1,0,0,"ns1:Status");
    return uVar3;
  case 0x3d:
    uVar3 = FUN_0059cb60(param_1,0,0,"ns1:ScriptExecution");
    return uVar3;
  case 0x3e:
    uVar3 = FUN_0059c820(param_1,0,0,"ns1:ArrayOfJob");
    return uVar3;
  case 0x3f:
    uVar3 = FUN_0059bfd0(param_1,0,0,"ns1:HelloWorld");
    return uVar3;
  case 0x40:
    uVar3 = FUN_0059c0e0(param_1,0,0,"ns1:HelloWorldResponse");
    return uVar3;
  case 0x43:
    uVar3 = FUN_0059bdf0(param_1,0,0,"ns1:GetVersion");
    return uVar3;
  case 0x44:
    uVar3 = FUN_0059bf00(param_1,0,0,"ns1:GetVersionResponse");
    return uVar3;
  case 0x47:
    uVar3 = FUN_0059bbc0(param_1,0,0,"ns1:GetStatus");
    return uVar3;
  case 0x48:
    uVar3 = FUN_0059bcd0(param_1,0,0,"ns1:GetStatusResponse");
    return uVar3;
  case 0x4b:
    uVar3 = FUN_0059c200(param_1,0,0,"ns1:OpenJob");
    return uVar3;
  case 0x4c:
    uVar3 = FUN_0059c560(param_1,0,0,"ns1:OpenJobResponse");
    return uVar3;
  case 0x4f:
    uVar3 = FUN_0059c320(param_1,0,0,"ns1:OpenJobEx");
    return uVar3;
  case 0x50:
    uVar3 = FUN_0059c440(param_1,0,0,"ns1:OpenJobExResponse");
    return uVar3;
  case 0x53:
    uVar3 = FUN_0059c630(param_1,0,0,"ns1:RenewLease");
    return uVar3;
  case 0x54:
    uVar3 = FUN_0059c700(param_1,0,0,"ns1:RenewLeaseResponse");
    return uVar3;
  case 0x57:
    uVar3 = FUN_0059b230(param_1,0,0,"ns1:Execute");
    return uVar3;
  case 0x58:
    uVar3 = FUN_0059b4f0(param_1,0,0,"ns1:ExecuteResponse");
    return uVar3;
  case 0x5b:
    uVar3 = FUN_0059b300(param_1,0,0,"ns1:ExecuteEx");
    return uVar3;
  case 0x5c:
    uVar3 = FUN_0059b3d0(param_1,0,0,"ns1:ExecuteExResponse");
    return uVar3;
  case 0x5f:
    uVar3 = FUN_0059ac20(param_1,0,0,"ns1:CloseJob");
    return uVar3;
  case 0x60:
    uVar3 = FUN_0059acf0(param_1,0,0,"ns1:CloseJobResponse");
    return uVar3;
  case 99:
    uVar3 = FUN_0059a390(param_1,0,0,"ns1:BatchJob");
    return uVar3;
  case 100:
    uVar3 = FUN_0059a6f0(param_1,0,0,"ns1:BatchJobResponse");
    return uVar3;
  case 0x67:
    uVar3 = FUN_0059a4b0(param_1,0,0,"ns1:BatchJobEx");
    return uVar3;
  case 0x68:
    uVar3 = FUN_0059a5d0(param_1,0,0,"ns1:BatchJobExResponse");
    return uVar3;
  case 0x6b:
    uVar3 = FUN_0059b9d0(param_1,0,0,"ns1:GetExpiration");
    return uVar3;
  case 0x6c:
    uVar3 = FUN_0059baa0(param_1,0,0,"ns1:GetExpirationResponse");
    return uVar3;
  case 0x6f:
    uVar3 = FUN_0059b5c0(param_1,0,0,"ns1:GetAllJobs");
    return uVar3;
  case 0x70:
    uVar3 = FUN_0059b900(param_1,0,0,"ns1:GetAllJobsResponse");
    return uVar3;
  case 0x73:
    uVar3 = FUN_0059b6d0(param_1,0,0,"ns1:GetAllJobsEx");
    return uVar3;
  case 0x74:
    uVar3 = FUN_0059b7e0(param_1,0,0,"ns1:GetAllJobsExResponse");
    return uVar3;
  case 0x77:
    uVar3 = FUN_0059a9f0(param_1,0,0,"ns1:CloseExpiredJobs");
    return uVar3;
  case 0x78:
    uVar3 = FUN_0059ab00(param_1,0,0,"ns1:CloseExpiredJobsResponse");
    return uVar3;
  case 0x7b:
    uVar3 = FUN_0059a7c0(param_1,0,0,"ns1:CloseAllJobs");
    return uVar3;
  case 0x7c:
    uVar3 = FUN_0059a8d0(param_1,0,0,"ns1:CloseAllJobsResponse");
    return uVar3;
  case 0x7f:
    uVar3 = FUN_0059ae00(param_1,0,0,"ns1:Diag");
    return uVar3;
  case 0x80:
    uVar3 = FUN_0059b160(param_1,0,0,"ns1:DiagResponse");
    return uVar3;
  case 0x83:
    uVar3 = FUN_0059af20(param_1,0,0,"ns1:DiagEx");
    return uVar3;
  case 0x84:
    uVar3 = FUN_0059b040(param_1,0,0,"ns1:DiagExResponse");
    return uVar3;
  }
  iVar1 = 0x138b4;
  if (*(char *)(param_1 + 0x144b4) != '\0') {
    iVar1 = 0x144b4;
  }
  iVar1 = iVar1 + param_1;
  iVar2 = FUN_005b8220(param_1,iVar1,"xsd:string");
  if (iVar2 == 0) {
    *param_2 = 0x33;
    uVar3 = FUN_005a2880(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:LuaValue");
  if (iVar2 == 0) {
    *param_2 = 0xd;
    uVar3 = FUN_005a2280(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ArrayOfJob");
  if (iVar2 == 0) {
    *param_2 = 0xc;
    uVar3 = FUN_005a1c50(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ArrayOfLuaValue");
  if (iVar2 == 0) {
    *param_2 = 0xb;
    uVar3 = FUN_005a1da0(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ScriptExecution");
  if (iVar2 == 0) {
    *param_2 = 10;
    uVar3 = FUN_005a2490(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Job");
  if (iVar2 == 0) {
    *param_2 = 9;
    uVar3 = FUN_005a1ef0(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Status");
  if (iVar2 == 0) {
    *param_2 = 8;
    uVar3 = FUN_005a26a0(param_1,0,0,0);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"xsd:byte");
  if (iVar2 == 0) {
    *param_2 = 3;
    uVar3 = FUN_005b7270(param_1,0,0,0,3);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"xsd:int");
  if (iVar2 == 0) {
    *param_2 = 1;
    uVar3 = FUN_005b7550(param_1,0,0,0,1);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"xsd:double");
  if (iVar2 == 0) {
    *param_2 = 0x36;
    uVar3 = FUN_005b73b0(param_1,0,0,0,0x36);
    return uVar3;
  }
  iVar2 = FUN_005b8220(param_1,iVar1,"ns1:LuaType");
  if (iVar2 == 0) {
    *param_2 = 0x32;
    uVar3 = FUN_005a2170(param_1,0,0,0);
    return uVar3;
  }
  iVar1 = FUN_005b8220(param_1,iVar1,"xsd:string");
  if (iVar1 == 0) {
    uVar5 = 1;
    *param_2 = 4;
    uVar3 = 4;
  }
  else {
    iVar1 = param_1 + 0x138b4;
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:DiagExResponse");
    if (iVar2 == 0) {
      *param_2 = 0x31;
      uVar3 = FUN_0059f7a0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:DiagEx");
    if (iVar2 == 0) {
      *param_2 = 0x30;
      uVar3 = FUN_0059f5c0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:DiagResponse");
    if (iVar2 == 0) {
      *param_2 = 0x2f;
      uVar3 = FUN_0059f940(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Diag");
    if (iVar2 == 0) {
      *param_2 = 0x2e;
      uVar3 = FUN_0059f3e0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseAllJobsResponse");
    if (iVar2 == 0) {
      *param_2 = 0x2d;
      uVar3 = FUN_0059eca0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseAllJobs");
    if (iVar2 == 0) {
      *param_2 = 0x2c;
      uVar3 = FUN_0059eb70(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseExpiredJobsResponse");
    if (iVar2 == 0) {
      *param_2 = 0x2b;
      uVar3 = FUN_0059ef70(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseExpiredJobs");
    if (iVar2 == 0) {
      *param_2 = 0x2a;
      uVar3 = FUN_0059ee40(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobsExResponse");
    if (iVar2 == 0) {
      *param_2 = 0x29;
      uVar3 = FUN_005a03a0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobsEx");
    if (iVar2 == 0) {
      *param_2 = 0x28;
      uVar3 = FUN_005a0270(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobsResponse");
    if (iVar2 == 0) {
      *param_2 = 0x27;
      uVar3 = FUN_005a0540(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetAllJobs");
    if (iVar2 == 0) {
      *param_2 = 0x26;
      uVar3 = FUN_005a0140(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetExpirationResponse");
    if (iVar2 == 0) {
      *param_2 = 0x25;
      uVar3 = FUN_005a0840(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetExpiration");
    if (iVar2 == 0) {
      *param_2 = 0x24;
      uVar3 = FUN_005a06a0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJobExResponse");
    if (iVar2 == 0) {
      *param_2 = 0x23;
      uVar3 = FUN_0059e870(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJobEx");
    if (iVar2 == 0) {
      *param_2 = 0x22;
      uVar3 = FUN_0059e6a0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJobResponse");
    if (iVar2 == 0) {
      *param_2 = 0x21;
      uVar3 = FUN_0059ea10(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:BatchJob");
    if (iVar2 == 0) {
      *param_2 = 0x20;
      uVar3 = FUN_0059e4d0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseJobResponse");
    if (iVar2 == 0) {
      *param_2 = 0x1f;
      uVar3 = FUN_0059f2b0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:CloseJob");
    if (iVar2 == 0) {
      *param_2 = 0x1e;
      uVar3 = FUN_0059f110(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ExecuteExResponse");
    if (iVar2 == 0) {
      *param_2 = 0x1d;
      uVar3 = FUN_0059fe40(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ExecuteEx");
    if (iVar2 == 0) {
      *param_2 = 0x1c;
      uVar3 = FUN_0059fc70(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:ExecuteResponse");
    if (iVar2 == 0) {
      *param_2 = 0x1b;
      uVar3 = FUN_0059ffe0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:Execute");
    if (iVar2 == 0) {
      *param_2 = 0x1a;
      uVar3 = FUN_0059faa0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:RenewLeaseResponse");
    if (iVar2 == 0) {
      *param_2 = 0x19;
      uVar3 = FUN_005a1ab0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:RenewLease");
    if (iVar2 == 0) {
      *param_2 = 0x18;
      uVar3 = FUN_005a18d0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJobExResponse");
    if (iVar2 == 0) {
      *param_2 = 0x17;
      uVar3 = FUN_005a15d0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJobResponse");
    if (iVar2 == 0) {
      *param_2 = 0x16;
      uVar3 = FUN_005a1770(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJobEx");
    if (iVar2 == 0) {
      *param_2 = 0x15;
      uVar3 = FUN_005a1400(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:OpenJob");
    if (iVar2 == 0) {
      *param_2 = 0x14;
      uVar3 = FUN_005a1230(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetStatusResponse");
    if (iVar2 == 0) {
      *param_2 = 0x13;
      uVar3 = FUN_005a0b10(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetStatus");
    if (iVar2 == 0) {
      *param_2 = 0x12;
      uVar3 = FUN_005a09e0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetVersionResponse");
    if (iVar2 == 0) {
      *param_2 = 0x11;
      uVar3 = FUN_005a0de0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:GetVersion");
    if (iVar2 == 0) {
      *param_2 = 0x10;
      uVar3 = FUN_005a0cb0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:HelloWorldResponse");
    if (iVar2 == 0) {
      *param_2 = 0xf;
      uVar3 = FUN_005a10b0(param_1,0,0,0);
      return uVar3;
    }
    iVar2 = FUN_005b8220(param_1,iVar1,"ns1:HelloWorld");
    if (iVar2 == 0) {
      *param_2 = 0xe;
      uVar3 = FUN_005a0f80(param_1,0,0,0);
      return uVar3;
    }
    iVar1 = FUN_005b8220(param_1,iVar1,"xsd:QName");
    if (iVar1 != 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      return 0;
    }
    uVar5 = 2;
    *param_2 = 5;
    uVar3 = 5;
  }
  puVar4 = (undefined4 *)FUN_005b7b00(param_1,0,0,0,uVar3,uVar5,0xffffffff,0xffffffff);
  if (puVar4 == (undefined4 *)0x0) {
    return 0;
  }
  return *puVar4;
}



/* FUNCTION 4894 ; VA 0x005ade00 ; FUN_005ade00 */

bool FUN_005ade00(int param_1)

{
  int iVar1;
  
  *(undefined2 *)(param_1 + 0x15508) = 3;
  iVar1 = FUN_0059ce00(param_1,"SOAP-ENV:Header",0,0);
  *(int *)(param_1 + 0x2fac) = iVar1;
  *(undefined2 *)(param_1 + 0x15508) = 4;
  return iVar1 == 0;
}



/* FUNCTION 4895 ; VA 0x005ade50 ; FUN_005ade50 */

void FUN_005ade50(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  switch(param_3) {
  case 4:
  case 5:
    FUN_005bb2a0();
    return;
  case 6:
  case 7:
  case 0x32:
  case 0x33:
  case 0x35:
  case 0x36:
  case 0x39:
  case 0x3b:
  case 0x41:
  case 0x45:
  case 0x49:
  case 0x4d:
  case 0x51:
  case 0x55:
  case 0x59:
  case 0x5d:
  case 0x61:
  case 0x65:
  case 0x69:
  case 0x6d:
  case 0x71:
  case 0x75:
  case 0x79:
  case 0x7d:
  case 0x81:
  case 0x85:
  case 0x87:
  case 0x89:
  case 0x8b:
  case 0x8d:
  case 0x8f:
  case 0x91:
  case 0x93:
  case 0x95:
  case 0x97:
  case 0x99:
  case 0x9b:
  case 0x9d:
  case 0x9f:
  case 0xa1:
  case 0xa3:
  case 0xa5:
  case 0xa7:
  case 0xa9:
    goto switchD_005ade66_caseD_2;
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
  case 0x30:
  case 0x31:
    (**(code **)(*param_2 + 8))(param_1);
    return;
  case 0x34:
    FUN_005bb2a0(param_1,*param_2,0x33);
    return;
  case 0x37:
    FUN_005ac840(param_1,param_2);
    return;
  case 0x38:
    FUN_005ac8a0(param_1,param_2);
    return;
  case 0x3a:
    FUN_005ac870(param_1,param_2);
    return;
  case 0x3c:
    FUN_005ac900(param_1,param_2);
    return;
  case 0x3d:
    FUN_005ac8d0(param_1,param_2);
    return;
  case 0x3e:
    FUN_005ac810(param_1,param_2);
    return;
  case 0x3f:
    FUN_005ac750(param_1,param_2);
    return;
  case 0x40:
    uVar2 = 0xf;
    break;
  case 0x42:
  case 0x88:
    uVar2 = 0xe;
    break;
  case 0x43:
    FUN_005ac720(param_1,param_2);
    return;
  case 0x44:
    uVar2 = 0x11;
    break;
  case 0x46:
  case 0x8a:
    uVar2 = 0x10;
    break;
  case 0x47:
    FUN_005ac6f0(param_1,param_2);
    return;
  case 0x48:
    uVar2 = 0x13;
    break;
  case 0x4a:
  case 0x8c:
    uVar2 = 0x12;
    break;
  case 0x4b:
    FUN_005ac780(param_1,param_2);
    return;
  case 0x4c:
    uVar2 = 0x16;
    break;
  case 0x4e:
  case 0x8e:
    uVar2 = 0x14;
    break;
  case 0x4f:
    FUN_005ac7b0(param_1,param_2);
    return;
  case 0x50:
    uVar2 = 0x17;
    break;
  case 0x52:
  case 0x90:
    uVar2 = 0x15;
    break;
  case 0x53:
    FUN_005ac7e0(param_1,param_2);
    return;
  case 0x54:
    uVar2 = 0x19;
    break;
  case 0x56:
  case 0x92:
    uVar2 = 0x18;
    break;
  case 0x57:
    FUN_005ac600(param_1,param_2);
    return;
  case 0x58:
    uVar2 = 0x1b;
    break;
  case 0x5a:
  case 0x94:
    uVar2 = 0x1a;
    break;
  case 0x5b:
    FUN_005ac630(param_1,param_2);
    return;
  case 0x5c:
    uVar2 = 0x1d;
    break;
  case 0x5e:
  case 0x96:
    uVar2 = 0x1c;
    break;
  case 0x5f:
    FUN_005ac570(param_1,param_2);
    return;
  case 0x60:
    uVar2 = 0x1f;
    break;
  case 0x62:
  case 0x98:
    uVar2 = 0x1e;
    break;
  case 99:
    FUN_005ac4b0(param_1,param_2);
    return;
  case 100:
    uVar2 = 0x21;
    break;
  case 0x66:
  case 0x9a:
    uVar2 = 0x20;
    break;
  case 0x67:
    FUN_005ac4e0(param_1,param_2);
    return;
  case 0x68:
    uVar2 = 0x23;
    break;
  case 0x6a:
  case 0x9c:
    uVar2 = 0x22;
    break;
  case 0x6b:
    FUN_005ac6c0(param_1,param_2);
    return;
  case 0x6c:
    uVar2 = 0x25;
    break;
  case 0x6e:
  case 0x9e:
    uVar2 = 0x24;
    break;
  case 0x6f:
    FUN_005ac660(param_1,param_2);
    return;
  case 0x70:
    uVar2 = 0x27;
    break;
  case 0x72:
  case 0xa0:
    uVar2 = 0x26;
    break;
  case 0x73:
    FUN_005ac690(param_1,param_2);
    return;
  case 0x74:
    uVar2 = 0x29;
    break;
  case 0x76:
  case 0xa2:
    uVar2 = 0x28;
    break;
  case 0x77:
    FUN_005ac540(param_1,param_2);
    return;
  case 0x78:
    uVar2 = 0x2b;
    break;
  case 0x7a:
  case 0xa4:
    uVar2 = 0x2a;
    break;
  case 0x7b:
    FUN_005ac510(param_1,param_2);
    return;
  case 0x7c:
    uVar2 = 0x2d;
    break;
  case 0x7e:
  case 0xa6:
    uVar2 = 0x2c;
    break;
  case 0x7f:
    FUN_005ac5a0(param_1,param_2);
    return;
  case 0x80:
    uVar2 = 0x2f;
    break;
  case 0x82:
  case 0xa8:
    uVar2 = 0x2e;
    break;
  case 0x83:
    FUN_005ac5d0(param_1,param_2);
    goto switchD_005ade66_caseD_2;
  case 0x84:
    uVar2 = 0x31;
    break;
  case 0x86:
  case 0xaa:
    uVar2 = 0x30;
    break;
  default:
    goto switchD_005ade66_caseD_a7;
  }
  iVar1 = FUN_005bb2a0(param_1,*param_2,uVar2);
  if (iVar1 == 0) {
    (**(code **)(*(int *)*param_2 + 8))(param_1);
    return;
  }
switchD_005ade66_caseD_2:
switchD_005ade66_caseD_a7:
  return;
}



/* FUNCTION 4896 ; VA 0x005ae400 ; FUN_005ae400 */

undefined4
FUN_005ae400(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  
  switch(param_5) {
  case 1:
    uVar1 = FUN_005b8630(param_1,param_3,param_4,param_2,"xsd:int",1);
    return uVar1;
  default:
    return 0;
  case 3:
    uVar1 = FUN_005b84a0(param_1,param_3,param_4,param_2,"xsd:byte",3);
    return uVar1;
  case 4:
    uVar1 = FUN_005b8840(param_1,param_3,param_4,&param_2,"xsd:string",4);
    return uVar1;
  case 5:
    uVar1 = FUN_005b8840(param_1,"xsd:QName",param_4,&param_2,0,4);
    return uVar1;
  case 8:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:Status");
    return uVar1;
  case 9:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:Job");
    return uVar1;
  case 10:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:ScriptExecution");
    return uVar1;
  case 0xb:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:ArrayOfLuaValue");
    return uVar1;
  case 0xc:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:ArrayOfJob");
    return uVar1;
  case 0xd:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,param_3,param_4,"ns1:LuaValue");
    return uVar1;
  case 0xe:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:HelloWorld",param_4,0);
    return uVar1;
  case 0xf:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:HelloWorldResponse",param_4,0);
    return uVar1;
  case 0x10:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetVersion",param_4,0);
    return uVar1;
  case 0x11:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetVersionResponse",param_4,0);
    return uVar1;
  case 0x12:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetStatus",param_4,0);
    return uVar1;
  case 0x13:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetStatusResponse",param_4,0);
    return uVar1;
  case 0x14:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:OpenJob",param_4,0);
    return uVar1;
  case 0x15:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:OpenJobEx",param_4,0);
    return uVar1;
  case 0x16:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:OpenJobResponse",param_4,0);
    return uVar1;
  case 0x17:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:OpenJobExResponse",param_4,0);
    return uVar1;
  case 0x18:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:RenewLease",param_4,0);
    return uVar1;
  case 0x19:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:RenewLeaseResponse",param_4,0);
    return uVar1;
  case 0x1a:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:Execute",param_4,0);
    return uVar1;
  case 0x1b:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:ExecuteResponse",param_4,0);
    return uVar1;
  case 0x1c:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:ExecuteEx",param_4,0);
    return uVar1;
  case 0x1d:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:ExecuteExResponse",param_4,0);
    return uVar1;
  case 0x1e:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseJob",param_4,0);
    return uVar1;
  case 0x1f:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseJobResponse",param_4,0);
    return uVar1;
  case 0x20:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:BatchJob",param_4,0);
    return uVar1;
  case 0x21:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:BatchJobResponse",param_4,0);
    return uVar1;
  case 0x22:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:BatchJobEx",param_4,0);
    return uVar1;
  case 0x23:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:BatchJobExResponse",param_4,0);
    return uVar1;
  case 0x24:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetExpiration",param_4,0);
    return uVar1;
  case 0x25:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetExpirationResponse",param_4,0);
    return uVar1;
  case 0x26:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetAllJobs",param_4,0);
    return uVar1;
  case 0x27:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetAllJobsResponse",param_4,0);
    return uVar1;
  case 0x28:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetAllJobsEx",param_4,0);
    return uVar1;
  case 0x29:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:GetAllJobsExResponse",param_4,0);
    return uVar1;
  case 0x2a:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseExpiredJobs",param_4,0);
    return uVar1;
  case 0x2b:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseExpiredJobsResponse",param_4,0);
    return uVar1;
  case 0x2c:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseAllJobs",param_4,0);
    return uVar1;
  case 0x2d:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:CloseAllJobsResponse",param_4,0);
    return uVar1;
  case 0x2e:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:Diag",param_4,0);
    return uVar1;
  case 0x2f:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:DiagResponse",param_4,0);
    return uVar1;
  case 0x30:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:DiagEx",param_4,0);
    return uVar1;
  case 0x31:
    uVar1 = (**(code **)(*param_2 + 0x10))(param_1,"ns1:DiagExResponse",param_4,0);
    return uVar1;
  case 0x32:
    uVar1 = FUN_005ab250(param_1,param_3,param_4,param_2,"ns1:LuaType");
    return uVar1;
  case 0x33:
    uVar1 = FUN_005ab2d0(param_1,param_3,param_4,param_2,"xsd:string");
    return uVar1;
  case 0x34:
    uVar1 = FUN_005aaed0(param_1,param_3,param_4,param_2,"xsd:string");
    return uVar1;
  case 0x36:
    uVar1 = FUN_005b8530(param_1,param_3,param_4,param_2,"xsd:double",0x36);
    return uVar1;
  case 0x37:
    uVar1 = FUN_005aad40(param_1,param_3,param_4,param_2,"ns1:ArrayOfLuaValue");
    return uVar1;
  case 0x38:
    uVar1 = FUN_005aade0(param_1,param_3,param_4,param_2,"ns1:LuaValue");
    return uVar1;
  case 0x3a:
    uVar1 = FUN_005aad90(param_1,param_3,param_4,param_2,"ns1:Job");
    return uVar1;
  case 0x3c:
    uVar1 = FUN_005aae80(param_1,param_3,param_4,param_2,"ns1:Status");
    return uVar1;
  case 0x3d:
    uVar1 = FUN_005aae30(param_1,param_3,param_4,param_2,"ns1:ScriptExecution");
    return uVar1;
  case 0x3e:
    uVar1 = FUN_005aacf0(param_1,param_3,param_4,param_2,"ns1:ArrayOfJob");
    return uVar1;
  case 0x3f:
    uVar1 = FUN_005aaa70(param_1,param_3,param_4,param_2,"ns1:HelloWorld");
    return uVar1;
  case 0x40:
    uVar1 = FUN_005aaac0(param_1,param_3,param_4,param_2,"ns1:HelloWorldResponse");
    return uVar1;
  case 0x43:
    uVar1 = FUN_005aa9d0(param_1,param_3,param_4,param_2,"ns1:GetVersion");
    return uVar1;
  case 0x44:
    uVar1 = FUN_005aaa20(param_1,param_3,param_4,param_2,"ns1:GetVersionResponse");
    return uVar1;
  case 0x47:
    uVar1 = FUN_005aa930(param_1,param_3,param_4,param_2,"ns1:GetStatus");
    return uVar1;
  case 0x48:
    uVar1 = FUN_005aa980(param_1,param_3,param_4,param_2,"ns1:GetStatusResponse");
    return uVar1;
  case 0x4b:
    uVar1 = FUN_005aab10(param_1,param_3,param_4,param_2,"ns1:OpenJob");
    return uVar1;
  case 0x4c:
    uVar1 = FUN_005aac00(param_1,param_3,param_4,param_2,"ns1:OpenJobResponse");
    return uVar1;
  case 0x4f:
    uVar1 = FUN_005aab60(param_1,param_3,param_4,param_2,"ns1:OpenJobEx");
    return uVar1;
  case 0x50:
    uVar1 = FUN_005aabb0(param_1,param_3,param_4,param_2,"ns1:OpenJobExResponse");
    return uVar1;
  case 0x53:
    uVar1 = FUN_005aac50(param_1,param_3,param_4,param_2,"ns1:RenewLease");
    return uVar1;
  case 0x54:
    uVar1 = FUN_005aaca0(param_1,param_3,param_4,param_2,"ns1:RenewLeaseResponse");
    return uVar1;
  case 0x57:
    uVar1 = FUN_005aa610(param_1,param_3,param_4,param_2,"ns1:Execute");
    return uVar1;
  case 0x58:
    uVar1 = FUN_005aa700(param_1,param_3,param_4,param_2,"ns1:ExecuteResponse");
    return uVar1;
  case 0x5b:
    uVar1 = FUN_005aa660(param_1,param_3,param_4,param_2,"ns1:ExecuteEx");
    return uVar1;
  case 0x5c:
    uVar1 = FUN_005aa6b0(param_1,param_3,param_4,param_2,"ns1:ExecuteExResponse");
    return uVar1;
  case 0x5f:
    uVar1 = FUN_005aa430(param_1,param_3,param_4,param_2,"ns1:CloseJob");
    return uVar1;
  case 0x60:
    uVar1 = FUN_005aa480(param_1,param_3,param_4,param_2,"ns1:CloseJobResponse");
    return uVar1;
  case 99:
    uVar1 = FUN_005aa1b0(param_1,param_3,param_4,param_2,"ns1:BatchJob");
    return uVar1;
  case 100:
    uVar1 = FUN_005aa2a0(param_1,param_3,param_4,param_2,"ns1:BatchJobResponse");
    return uVar1;
  case 0x67:
    uVar1 = FUN_005aa200(param_1,param_3,param_4,param_2,"ns1:BatchJobEx");
    return uVar1;
  case 0x68:
    uVar1 = FUN_005aa250(param_1,param_3,param_4,param_2,"ns1:BatchJobExResponse");
    return uVar1;
  case 0x6b:
    uVar1 = FUN_005aa890(param_1,param_3,param_4,param_2,"ns1:GetExpiration");
    return uVar1;
  case 0x6c:
    uVar1 = FUN_005aa8e0(param_1,param_3,param_4,param_2,"ns1:GetExpirationResponse");
    return uVar1;
  case 0x6f:
    uVar1 = FUN_005aa750(param_1,param_3,param_4,param_2,"ns1:GetAllJobs");
    return uVar1;
  case 0x70:
    uVar1 = FUN_005aa840(param_1,param_3,param_4,param_2,"ns1:GetAllJobsResponse");
    return uVar1;
  case 0x73:
    uVar1 = FUN_005aa7a0(param_1,param_3,param_4,param_2,"ns1:GetAllJobsEx");
    return uVar1;
  case 0x74:
    uVar1 = FUN_005aa7f0(param_1,param_3,param_4,param_2,"ns1:GetAllJobsExResponse");
    return uVar1;
  case 0x77:
    uVar1 = FUN_005aa390(param_1,param_3,param_4,param_2,"ns1:CloseExpiredJobs");
    return uVar1;
  case 0x78:
    uVar1 = FUN_005aa3e0(param_1,param_3,param_4,param_2,"ns1:CloseExpiredJobsResponse");
    return uVar1;
  case 0x7b:
    uVar1 = FUN_005aa2f0(param_1,param_3,param_4,param_2,"ns1:CloseAllJobs");
    return uVar1;
  case 0x7c:
    uVar1 = FUN_005aa340(param_1,param_3,param_4,param_2,"ns1:CloseAllJobsResponse");
    return uVar1;
  case 0x7f:
    uVar1 = FUN_005aa4d0(param_1,param_3,param_4,param_2,"ns1:Diag");
    return uVar1;
  case 0x80:
    uVar1 = FUN_005aa5c0(param_1,param_3,param_4,param_2,"ns1:DiagResponse");
    return uVar1;
  case 0x83:
    uVar1 = FUN_005aa520(param_1,param_3,param_4,param_2,"ns1:DiagEx");
    return uVar1;
  case 0x84:
    uVar1 = FUN_005aa570(param_1,param_3,param_4,param_2,"ns1:DiagExResponse");
    return uVar1;
  }
}



/* FUNCTION 4897 ; VA 0x005aef40 ; FUN_005aef40 */

undefined4 FUN_005aef40(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x2fb0);
  if (iVar2 == 0) {
    return 0;
  }
  uVar1 = FUN_005b43f0(param_1,iVar2,0,0,"SOAP-ENV:Fault",0xb2);
  iVar2 = FUN_005ab060(param_1,"SOAP-ENV:Fault",uVar1,iVar2,0);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar1 = FUN_005ac160(param_1);
  return uVar1;
}



/* FUNCTION 4898 ; VA 0x005aefa0 ; FUN_005aefa0 */

undefined4 FUN_005aefa0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x2fac) != 0) {
    *(undefined2 *)(param_1 + 0x15508) = 3;
    uVar1 = FUN_005b44d0(param_1,0,*(int *)(param_1 + 0x2fac),0xab,0);
    iVar2 = FUN_005b3c80(param_1,"SOAP-ENV:Header",uVar1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3e10(param_1,"SOAP-ENV:Header");
    }
    else {
      iVar2 = *(int *)(param_1 + 0x1615c);
    }
    if (iVar2 != 0) {
      return *(undefined4 *)(param_1 + 0x1615c);
    }
    *(undefined2 *)(param_1 + 0x15508) = 4;
  }
  return 0;
}



/* FUNCTION 4899 ; VA 0x005af020 ; FUN_005af020 */

void FUN_005af020(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  FUN_005acbf0(param_1);
  puVar1 = *(undefined4 **)(param_1 + 0x2fb0);
  if (puVar1 != (undefined4 *)0x0) {
    FUN_005bb2a0(param_1,*puVar1,4);
    FUN_005bb2a0(param_1,puVar1[1],4);
    FUN_005bb2a0(param_1,puVar1[2],4);
    iVar2 = FUN_005bb2a0(param_1,puVar1[3],0xae);
    if (iVar2 == 0) {
      FUN_005ade50(param_1,((undefined4 *)puVar1[3])[1],*(undefined4 *)puVar1[3]);
    }
    FUN_005ac460(param_1,puVar1 + 4);
    iVar2 = FUN_005bb2a0(param_1,puVar1[5],0xb1);
    if (iVar2 == 0) {
      FUN_005bb2a0(param_1,*(undefined4 *)puVar1[5],4);
    }
    FUN_005bb2a0(param_1,puVar1[6],4);
    FUN_005bb2a0(param_1,puVar1[7],4);
    iVar2 = FUN_005bb2a0(param_1,puVar1[8],0xae);
    if (iVar2 == 0) {
      FUN_005ade50(param_1,((undefined4 *)puVar1[8])[1],*(undefined4 *)puVar1[8]);
    }
  }
  return;
}



/* FUNCTION 4900 ; VA 0x005af100 ; FUN_005af100 */

undefined4 * __fastcall FUN_005af100(undefined4 *param_1)

{
  *param_1 = soap::vftable;
  FUN_0170d1f0(param_1 + 0x586d,0,0x1018);
  FUN_005b76c0(param_1);
  return param_1;
}



/* FUNCTION 4901 ; VA 0x005af130 ; FUN_005af130 */

void __fastcall FUN_005af130(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  *param_1 = soap::vftable;
  FUN_005b3540(param_1,0);
  if ((*(short *)(param_1 + 1) == 1) || (*(short *)(param_1 + 1) == 2)) {
    FUN_005b52e0(param_1);
    if ((*(short *)(param_1 + 1) == 1) || (*(short *)(param_1 + 1) == 2)) {
      puVar1 = (undefined4 *)param_1[0x19];
      while (puVar1 != (undefined4 *)0x0) {
        if (*(short *)((int)puVar1 + -2) != -0x3f22) {
          param_1[0x5857] = 0x15;
          goto LAB_005af216;
        }
        param_1[0x19] = *puVar1;
        FUN_017168b0((int)puVar1 - puVar1[1]);
        puVar1 = (undefined4 *)param_1[0x19];
      }
      param_1[4] = param_1[4] & 0xfffffeff;
      param_1[0x5846] = 0;
      param_1[0xbec] = 0;
      param_1[0xbeb] = 0;
      param_1[0xbf0] = 0;
      param_1[0xbf1] = 0;
      param_1[0x5847] = 0;
      param_1[9] = 0;
      param_1[0x586a] = 0;
      param_1[0x586b] = 0;
      param_1[0x5867] = 0;
      param_1[0x5868] = 0;
    }
LAB_005af216:
    iVar2 = param_1[0x18];
    while (iVar2 != 0) {
      iVar2 = *(int *)param_1[0x18];
      FUN_017168b0((int *)param_1[0x18]);
      param_1[0x18] = iVar2;
    }
    FUN_005b2e00(param_1);
  }
  FUN_005b35d0(param_1);
  return;
}



/* FUNCTION 4902 ; VA 0x005af260 ; FUN_005af260 */

int * __thiscall FUN_005af260(int *param_1,undefined4 param_2)

{
  undefined *puVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ef7;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  iVar3 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  puVar1 = &stack0xffffff7c;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar3 = *param_1;
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar3 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar3 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) != 0) {
    uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
    uVar6 = uVar8 | 4;
    if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
      uVar6 = uVar8;
    }
    FUN_00554460(uVar6,0);
    uStack_8 = 10;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 8))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  piVar5 = *(int **)(*(int *)(*(int *)(iVar3 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_18 = piVar5;
  (**(code **)(*piVar5 + 4))();
  uStack_8._0_1_ = 3;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_28 = DAT_01ea8a14;
  uStack_1c = DAT_01e90d00;
  if (DAT_01e90d00 == 0) {
    FUN_016dda75(0);
    if (DAT_01e90d00 == 0) {
      DAT_01e90d00 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01e90d00;
    }
    FUN_016ddacd();
  }
  uStack_1c = DAT_01e90d00;
  if (DAT_01e90d00 < (uint)piVar5[3]) {
    piVar5 = *(int **)(piVar5[2] + DAT_01e90d00 * 4);
    if (piVar5 != (int *)0x0) goto LAB_005af3fb;
  }
  else {
    piVar5 = (int *)0x0;
  }
  if (*(char *)(piStack_18 + 5) == '\0') {
LAB_005af389:
    if (piVar5 != (int *)0x0) goto LAB_005af3fb;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uStack_1c < *(uint *)(iVar3 + 0xc)) {
      piVar5 = *(int **)(*(int *)(iVar3 + 8) + uStack_1c * 4);
      goto LAB_005af389;
    }
  }
  piVar5 = piStack_28;
  if (piStack_28 == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20(8);
    uStack_8._0_1_ = 5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar7 = (int *)piStack_18[6];
      if (piVar7 == (int *)0x0) {
        piVar7 = piStack_18 + 7;
      }
      piStack_28 = piVar5;
      FUN_0054f870(piVar7);
      piVar5[1] = 0;
      *piVar5 = (int)std::
                     num_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                     ::vftable;
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    piStack_28 = piVar5;
    FUN_016de14f(piVar5);
    (**(code **)(*piVar5 + 4))();
    DAT_01ea8a14 = piVar5;
  }
LAB_005af3fb:
  FUN_016ddacd();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar4 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
  if (puVar4 != (undefined4 *)0x0) {
    (**(code **)*puVar4)(1);
  }
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar3 = *(int *)(*param_1 + 4) + (int)param_1;
  piStack_28 = (int *)CONCAT31(piStack_28._1_3_,*(undefined *)(iVar3 + 0x40));
  uVar8 = uStack_20;
  (**(code **)(*piVar5 + 0x24))
            (auStack_2c,uStack_20,*(undefined4 *)(iVar3 + 0x38),iVar3,piStack_28,param_2);
  piVar5 = (int *)FUN_005af47c(uVar8);
  return piVar5;
}



/* FUNCTION 4903 ; VA 0x005af45d ; Catch_All@005af45d */

undefined * Catch_All_005af45d(void)

{
  FUN_005565b0(4,1);
  return &DAT_005af476;
}



/* FUNCTION 4904 ; VA 0x005af47c ; FUN_005af47c */

void FUN_005af47c(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 10;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 0xb;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4905 ; VA 0x005af4f0 ; FUN_005af4f0 */

undefined4 * __thiscall FUN_005af4f0(undefined4 *param_1,byte param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  *param_1 = soap::vftable;
  FUN_005b3540(param_1,0);
  if ((*(short *)(param_1 + 1) == 1) || (*(short *)(param_1 + 1) == 2)) {
    FUN_005b52e0(param_1);
    if ((*(short *)(param_1 + 1) == 1) || (*(short *)(param_1 + 1) == 2)) {
      puVar1 = (undefined4 *)param_1[0x19];
      while (puVar1 != (undefined4 *)0x0) {
        if (*(short *)((int)puVar1 + -2) != -0x3f22) {
          param_1[0x5857] = 0x15;
          goto LAB_005af5d9;
        }
        param_1[0x19] = *puVar1;
        FUN_017168b0((int)puVar1 - puVar1[1]);
        puVar1 = (undefined4 *)param_1[0x19];
      }
      param_1[4] = param_1[4] & 0xfffffeff;
      param_1[0x5846] = 0;
      param_1[0xbec] = 0;
      param_1[0xbeb] = 0;
      param_1[0xbf0] = 0;
      param_1[0xbf1] = 0;
      param_1[0x5847] = 0;
      param_1[9] = 0;
      param_1[0x586a] = 0;
      param_1[0x586b] = 0;
      param_1[0x5867] = 0;
      param_1[0x5868] = 0;
    }
LAB_005af5d9:
    iVar2 = param_1[0x18];
    while (iVar2 != 0) {
      iVar2 = *(int *)param_1[0x18];
      FUN_017168b0((int *)param_1[0x18]);
      param_1[0x18] = iVar2;
    }
    FUN_005b2e00(param_1);
  }
  FUN_005b35d0(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x17658);
  }
  return param_1;
}



/* FUNCTION 4906 ; VA 0x005af630 ; FUN_005af630 */

int * __thiscall FUN_005af630(int *param_1,undefined4 param_2,int param_3,int param_4)

{
  uint *puVar1;
  uint uVar2;
  char cVar3;
  int *piVar4;
  uint uVar5;
  longlong lVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797f20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = 0;
  param_1[3] = 0;
  piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 4))();
  }
  uStack_8 = 0;
  cVar3 = FUN_00593b40(1);
  if (((cVar3 != '\0') && (-1 < param_4)) && ((0 < param_4 || (param_3 != 0)))) {
    uStack_8 = 2;
    lVar6 = (**(code **)(**(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1) + 0x20))
                      (param_2,param_3,param_4);
    puVar1 = (uint *)(param_1 + 2);
    uVar2 = *puVar1;
    *puVar1 = *puVar1 + (uint)lVar6;
    param_1[3] = param_1[3] + (int)((ulonglong)lVar6 >> 0x20) + (uint)CARRY4(uVar2,(uint)lVar6);
    if (lVar6 != CONCAT44(param_4,param_3)) {
      piVar4 = (int *)FUN_005af6f2();
      return piVar4;
    }
  }
  uStack_8 = 1;
  uVar2 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar5 = uVar2 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar5 = uVar2;
  }
  FUN_00554460(uVar5,0);
  uStack_8 = 4;
  piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4907 ; VA 0x005af6d3 ; Catch_All@005af6d3 */

undefined * Catch_All_005af6d3(void)

{
  FUN_005565b0(4,1);
  return &DAT_005af6ec;
}



/* FUNCTION 4908 ; VA 0x005af6f2 ; FUN_005af6f2 */

void FUN_005af6f2(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar4 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar3 = uVar4 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar3 = uVar4;
  }
  FUN_00554460(uVar3,0);
  iVar1 = *unaff_ESI;
  *(undefined4 *)(unaff_EBP + -4) = 4;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4909 ; VA 0x005af750 ; FUN_005af750 */

int * __thiscall FUN_005af750(int *param_1,undefined4 param_2,int param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  longlong lVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797f40;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  iVar2 = *param_1;
  piVar3 = *(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar3 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar3 + 4))();
    iVar2 = *param_1;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar2 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar3 = *(int **)(*(int *)(iVar2 + 4) + 0x3c + (int)param_1), piVar3 != (int *)0x0)) &&
     (piVar3 != param_1)) {
    FUN_00581480();
    iVar2 = *param_1;
  }
  if (*(int *)(*(int *)(iVar2 + 4) + 0xc + (int)param_1) == 0) {
    if ((-1 < param_4) && ((0 < param_4 || (param_3 != 0)))) {
      uStack_8 = 2;
      lVar6 = (**(code **)(**(int **)(*(int *)(iVar2 + 4) + 0x38 + (int)param_1) + 0x24))
                        (param_2,param_3,param_4);
      if (lVar6 != CONCAT44(param_4,param_3)) {
        piVar3 = (int *)FUN_005af82a();
        return piVar3;
      }
    }
  }
  else {
    uVar5 = 4;
  }
  uStack_8 = 1;
  uVar5 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uVar5;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  uStack_8 = 4;
  cVar1 = thunk_FUN_0170e3b7();
  if (cVar1 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piVar3 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4910 ; VA 0x005af80b ; Catch_All@005af80b */

undefined * Catch_All_005af80b(void)

{
  FUN_005565b0(4,1);
  return &DAT_005af824;
}



/* FUNCTION 4911 ; VA 0x005af82a ; FUN_005af82a */

void FUN_005af82a(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 5;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4912 ; VA 0x005af8a0 ; FUN_005af8a0 */

undefined * FUN_005af8a0(void)

{
  return &DAT_01ea8b80;
}



/* FUNCTION 4913 ; VA 0x005af8b0 ; FUN_005af8b0 */

int FUN_005af8b0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint *puVar1;
  int iVar2;
  
  puVar1 = (uint *)FUN_005574c0(param_1,param_2,param_3,0,&stack0x00000010);
  iVar2 = FUN_0171d0ba(*puVar1 | 1,puVar1[1]);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  return iVar2;
}



/* FUNCTION 4914 ; VA 0x005af8f0 ; FUN_005af8f0 */

undefined4 FUN_005af8f0(int param_1,byte *param_2)

{
  byte bVar1;
  undefined4 *puVar2;
  byte *pbVar3;
  uint uVar4;
  byte *pbVar5;
  bool bVar6;
  
  puVar2 = *(undefined4 **)(param_1 + 0x2fbc);
  while( true ) {
    if (puVar2 == (undefined4 *)0x0) {
      return 0;
    }
    pbVar3 = (byte *)puVar2[1];
    pbVar5 = param_2;
    if (pbVar3 == param_2) break;
    do {
      bVar1 = *pbVar3;
      bVar6 = bVar1 < *pbVar5;
      if (bVar1 != *pbVar5) {
LAB_005af930:
        uVar4 = -(uint)bVar6 | 1;
        goto LAB_005af935;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar3[1];
      bVar6 = bVar1 < pbVar5[1];
      if (bVar1 != pbVar5[1]) goto LAB_005af930;
      pbVar3 = pbVar3 + 2;
      pbVar5 = pbVar5 + 2;
    } while (bVar1 != 0);
    uVar4 = 0;
LAB_005af935:
    if (uVar4 == 0) break;
    puVar2 = (undefined4 *)*puVar2;
  }
  return puVar2[2];
}



/* FUNCTION 4915 ; VA 0x005af950 ; FUN_005af950 */

void FUN_005af950(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_005574c0(param_1,param_2,0,&stack0x0000000c);
  FUN_0171cf89(*puVar1,puVar1[1]);
  return;
}



/* FUNCTION 4916 ; VA 0x005af980 ; FUN_005af980 */

int FUN_005af980(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uStack_118;
  int iStack_114;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar3 = param_1;
  iVar6 = 100;
  piVar1 = *(int **)(param_1 + 0x3080);
  *(undefined4 *)(param_1 + 0x16164) = 0;
  if (piVar1 == (int *)0x0) {
    if (*(int *)(param_1 + 0x3078) != -1) {
      do {
        if (*(int *)(iVar3 + 0x30) != 0) {
          while( true ) {
            iStack_14 = *(int *)(iVar3 + 0x30);
            if (iStack_14 < 1) {
              iVar4 = (int)((ulonglong)((longlong)iStack_14 * -0x431bde83) >> 0x20);
              iStack_10 = -iStack_14;
              iStack_14 = (iVar4 >> 0x12) - (iVar4 >> 0x1f);
              iStack_10 = iStack_10 % 1000000;
            }
            else {
              iStack_10 = 0;
            }
            iStack_114 = *(int *)(iVar3 + 0x3078);
            uStack_118 = 1;
            iVar4 = Ordinal_18(iStack_114 + 1,&uStack_118,0,&uStack_118,&iStack_14);
            if (0 < iVar4) break;
            if (iVar4 == 0) goto LAB_005afb75;
            iVar4 = Ordinal_111();
            if ((iVar4 != 0x2714) && (iVar4 != 0x2733)) {
              *(int *)(iVar3 + 0x16164) = iVar4;
              return 0;
            }
          }
        }
        if ((*(byte *)(iVar3 + 0x10) & 4) == 0) {
          iVar4 = Ordinal_16(*(undefined4 *)(iVar3 + 0x3078),param_2,param_3,
                             *(undefined4 *)(iVar3 + 0x40));
        }
        else {
          param_1 = 0x10;
          *(undefined4 *)(iVar3 + 0x171e4) = 0;
          *(undefined4 *)(iVar3 + 0x171e8) = 0;
          *(undefined4 *)(iVar3 + 0x171ec) = 0;
          *(undefined4 *)(iVar3 + 0x171f0) = 0;
          iVar4 = Ordinal_17(*(undefined4 *)(iVar3 + 0x3078),param_2,param_3,
                             *(undefined4 *)(iVar3 + 0x40),(undefined4 *)(iVar3 + 0x171e4),&param_1)
          ;
          *(int *)(iVar3 + 0x171f4) = param_1;
          uVar5 = Ordinal_14(*(undefined4 *)(iVar3 + 0x171e8));
          *(undefined4 *)(iVar3 + 0x16124) = uVar5;
        }
        if (-1 < iVar4) {
          return iVar4;
        }
        iVar4 = Ordinal_111();
        if ((iVar4 != 0x2714) && (iVar4 != 0x2733)) goto LAB_005afbad;
        iStack_c = *(int *)(iVar3 + 0x30);
        if (iStack_c < 1) {
          if (-1 < iStack_c) {
            iStack_c = 5;
            goto LAB_005afb35;
          }
          iVar4 = (int)((ulonglong)((longlong)iStack_c * -0x431bde83) >> 0x20);
          iStack_8 = -iStack_c;
          iStack_c = (iVar4 >> 0x12) - (iVar4 >> 0x1f);
          iStack_8 = iStack_8 % 1000000;
        }
        else {
LAB_005afb35:
          iStack_8 = 0;
        }
        iStack_114 = *(int *)(iVar3 + 0x3078);
        uStack_118 = 1;
        iVar4 = Ordinal_18(iStack_114 + 1,&uStack_118,0,&uStack_118,&iStack_c);
        if (iVar4 == 0) {
          if (*(int *)(iVar3 + 0x30) != 0) {
LAB_005afb75:
            *(undefined4 *)(iVar3 + 0x16164) = 0;
            return 0;
          }
        }
        else if (((iVar4 < 0) && (iVar4 = Ordinal_111(), iVar4 != 0x2714)) && (iVar4 != 0x2733))
        goto LAB_005afbad;
        bVar2 = 0 < iVar6;
        iVar6 = iVar6 + -1;
      } while (bVar2);
      iVar4 = Ordinal_111();
LAB_005afbad:
      *(int *)(iVar3 + 0x16164) = iVar4;
      return 0;
    }
    iVar6 = FUN_017328fe(*(undefined4 *)(param_1 + 0x3088),param_2,param_3);
    if (-1 < iVar6) {
      return iVar6;
    }
    uVar5 = GetLastError();
    *(undefined4 *)(iVar3 + 0x16164) = uVar5;
  }
  else if (*(int *)(*(int *)(*piVar1 + 4) + 0xc + (int)piVar1) == 0) {
    iVar3 = FUN_005af630(param_2,param_3,0);
    return *(int *)(iVar3 + 8);
  }
  return 0;
}



/* FUNCTION 4917 ; VA 0x005afc00 ; FUN_005afc00 */

undefined4 FUN_005afc00(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  bool bVar8;
  undefined4 uStack_228;
  int iStack_224;
  undefined4 uStack_124;
  int iStack_120;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar3 = param_1;
  if (*(int *)(param_1 + 0x307c) == 0) {
    iStack_8 = param_3;
    if (param_3 != 0) {
      param_1 = param_2;
      do {
        iVar5 = iStack_8;
        if (*(int *)(iVar3 + 0x3078) == -1) {
          iVar4 = FUN_0173353f(*(undefined4 *)(iVar3 + 0x3084),param_1,iStack_8);
          if (iVar4 < 1) {
            iVar4 = GetLastError();
            if (((iVar4 != 0) && (iVar4 != 0x2714)) && (iVar4 != 0x2733)) goto LAB_005afcf5;
            goto LAB_005afee3;
          }
        }
        else {
          if (*(int *)(iVar3 + 0x34) != 0) {
            while( true ) {
              iStack_18 = *(int *)(iVar3 + 0x34);
              if (iStack_18 < 1) {
                iVar4 = (int)((ulonglong)((longlong)iStack_18 * -0x431bde83) >> 0x20);
                iStack_14 = -iStack_18;
                iStack_18 = (iVar4 >> 0x12) - (iVar4 >> 0x1f);
                iStack_14 = iStack_14 % 1000000;
              }
              else {
                iStack_14 = 0;
              }
              iStack_120 = *(int *)(iVar3 + 0x3078);
              uStack_124 = 1;
              iVar4 = Ordinal_18(iStack_120 + 1,0,&uStack_124,&uStack_124,&iStack_18);
              if (0 < iVar4) break;
              if (iVar4 == 0) goto LAB_005aff00;
              iVar4 = Ordinal_111();
              if ((iVar4 != 0x2714) && (iVar4 != 0x2733)) goto LAB_005afcf5;
            }
          }
          uVar1 = *(undefined4 *)(iVar3 + 0x40);
          uVar2 = *(undefined4 *)(iVar3 + 0x3078);
          if ((*(byte *)(iVar3 + 0x10) & 4) == 0) {
            iVar4 = Ordinal_19(uVar2,param_1,iVar5,uVar1);
LAB_005afdfb:
            bVar8 = iVar4 < 0;
          }
          else {
            if (*(int *)(iVar3 + 0x171f4) == 0) {
              iVar4 = Ordinal_19(uVar2,param_1,iVar5,uVar1);
            }
            else {
              iVar4 = Ordinal_20(uVar2,param_1,iVar5,uVar1,iVar3 + 0x171e4,*(int *)(iVar3 + 0x171f4)
                                );
            }
            bVar8 = iVar4 < 0;
            if (bVar8) {
              uVar6 = *(uint *)(iVar3 + 0x44);
              iVar5 = FUN_0171d737();
              uVar6 = (uVar6 & 0x20 | 0x10) >> 4;
              iVar7 = iVar5 % 0xc9 + 0x32;
              do {
                iStack_1c = iVar7 * 1000;
                uStack_20 = 0;
                iStack_224 = *(int *)(iVar3 + 0x3078);
                uStack_228 = 1;
                Ordinal_18(iStack_224 + 1,0,0,&uStack_228,&uStack_20);
                if (*(int *)(iVar3 + 0x171f4) == 0) {
                  iVar4 = Ordinal_19(*(undefined4 *)(iVar3 + 0x3078),param_1,iStack_8,
                                     *(undefined4 *)(iVar3 + 0x40));
                }
                else {
                  iVar4 = Ordinal_20(*(undefined4 *)(iVar3 + 0x3078),param_1,iStack_8,
                                     *(undefined4 *)(iVar3 + 0x40),iVar3 + 0x171e4,
                                     *(int *)(iVar3 + 0x171f4));
                }
                iVar7 = iVar7 * 2;
                if (500 < iVar7) {
                  iVar7 = 500;
                }
                iVar5 = iStack_8;
              } while ((iVar4 < 0) && (uVar6 = uVar6 - 1, 0 < (int)uVar6));
              goto LAB_005afdfb;
            }
          }
          if (iVar4 == 0 || bVar8) {
            iVar4 = Ordinal_111();
            if (iVar4 == 0x2733) {
              iStack_10 = *(int *)(iVar3 + 0x34);
              if (iStack_10 < 1) {
                if (iStack_10 < 0) {
                  iVar4 = (int)((ulonglong)((longlong)iStack_10 * -0x431bde83) >> 0x20);
                  iStack_c = -iStack_10;
                  iStack_10 = (iVar4 >> 0x12) - (iVar4 >> 0x1f);
                  iStack_c = iStack_c % 1000000;
                }
                else {
                  iStack_10 = 0;
                  iStack_c = 10000;
                }
              }
              else {
                iStack_c = 0;
              }
              iStack_120 = *(int *)(iVar3 + 0x3078);
              uStack_124 = 1;
              iVar4 = Ordinal_18(iStack_120 + 1,0,&uStack_124,&uStack_124,&iStack_10);
              if (iVar4 < 0) {
                iVar4 = Ordinal_111();
                goto LAB_005afea3;
              }
            }
            else if (iVar4 != 0) {
LAB_005afea3:
              if (iVar4 != 0x2714) {
LAB_005afcf5:
                *(int *)(iVar3 + 0x16164) = iVar4;
                return 0xffffffff;
              }
            }
LAB_005afee3:
            iVar4 = 0;
          }
        }
        iStack_8 = iVar5 - iVar4;
        param_1 = param_1 + iVar4;
        if (iStack_8 == 0) {
          return 0;
        }
      } while( true );
    }
  }
  else {
    FUN_005af750(param_2,param_3,0);
    if (*(int *)(*(int *)(**(int **)(param_1 + 0x307c) + 4) + 0xc + (int)*(int **)(param_1 + 0x307c)
                ) != 0) {
LAB_005aff00:
      *(undefined4 *)(iVar3 + 0x16164) = 0;
      return 0xffffffff;
    }
  }
  return 0;
}



/* FUNCTION 4918 ; VA 0x005aff20 ; FUN_005aff20 */

undefined1 * FUN_005aff20(undefined4 param_1,int param_2)

{
  int *piVar1;
  undefined1 *puVar2;
  
  piVar1 = (int *)&DAT_018c27a8;
  if (param_2 != 200) {
    do {
      if (piVar1[1] == 0) break;
      piVar1 = piVar1 + 2;
    } while (*piVar1 != param_2);
  }
  puVar2 = &DAT_018c2414;
  if ((undefined1 *)piVar1[1] != (undefined1 *)0x0) {
    puVar2 = (undefined1 *)piVar1[1];
  }
  return puVar2;
}



/* FUNCTION 4919 ; VA 0x005aff50 ; FUN_005aff50 */

uint FUN_005aff50(char *param_1)

{
  char cVar1;
  char *pcVar2;
  ushort uVar3;
  int iVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  char *pcVar10;
  ushort uVar11;
  uint uVar12;
  char *pcVar13;
  int iVar14;
  char acStack_2010 [8172];
  undefined4 uStack_24;
  char *pcStack_20;
  char *pcStack_1c;
  char *pcStack_18;
  char *pcStack_14;
  uint uVar15;
  
  FUN_016f40d0();
  pcVar2 = param_1;
  pcStack_14 = (char *)0x400;
  pcStack_18 = param_1 + 0x130b4;
  uVar15 = 0;
  pcStack_1c = param_1;
  param_1[0x15518] = '\0';
  pcVar2[0x30a4] = '\0';
  pcVar2[0x30a5] = '\0';
  pcVar2[0x30a6] = '\0';
  pcVar2[0x30a7] = '\0';
  pcVar2[0x2fc0] = '\0';
  pcVar2[0x2fc1] = '\0';
  pcVar2[0x2fc2] = '\0';
  pcVar2[0x2fc3] = '\0';
  pcVar2[0x2fc4] = '\0';
  pcVar2[0x2fc5] = '\0';
  pcVar2[0x2fc6] = '\0';
  pcVar2[0x2fc7] = '\0';
  pcVar2[0x16118] = '\0';
  pcVar2[0x16119] = '\0';
  pcVar2[0x1611a] = '\0';
  pcVar2[0x1611b] = '\0';
  pcVar2[0x1611c] = '\0';
  pcVar2[0x1611d] = '\0';
  pcVar2[0x1611e] = '\0';
  pcVar2[0x1611f] = '\0';
  pcVar2[0x16154] = '\0';
  pcVar2[0x16155] = '\0';
  pcVar2[0x16156] = '\0';
  pcVar2[0x16157] = '\0';
  pcVar2[0x24] = '\0';
  pcVar2[0x25] = '\0';
  pcVar2[0x26] = '\0';
  pcVar2[0x27] = '\0';
  pcVar2[0x16158] = '\0';
  pcVar2[0x16159] = '\0';
  pcVar2[0x1615a] = '\0';
  pcVar2[0x1615b] = '\0';
  pcStack_20 = (char *)0x5affad;
  iVar4 = FUN_005b6770();
  do {
    if (iVar4 != 0) {
      if (*(int *)(pcVar2 + 0x1615c) != -1) {
        pcVar2[0x1615c] = -0x62;
        pcVar2[0x1615d] = '\x01';
        pcVar2[0x1615e] = '\0';
        pcVar2[0x1615f] = '\0';
        return 0x19e;
      }
      return 0xffffffff;
    }
    pcStack_14 = (char *)0x2000;
    pcStack_18 = acStack_2010;
    pcStack_1c = pcVar2;
    pcStack_20 = (char *)0x5affd2;
    iVar4 = FUN_005b6770();
    while (iVar4 == 0) {
      if (acStack_2010[0] == '\0') goto LAB_005b00d9;
      pcStack_18 = acStack_2010;
      pcStack_14 = (char *)0x3a;
      pcStack_1c = (char *)0x5afffb;
      param_1 = (char *)FUN_0170dbd0();
      if (param_1 != (char *)0x0) {
        *param_1 = '\0';
        do {
          pcVar5 = param_1;
          param_1 = pcVar5 + 1;
          if (*param_1 == '\0') break;
        } while (*param_1 < '!');
        pcVar10 = param_1;
        if (*param_1 == '\"') {
          param_1 = pcVar5 + 2;
          pcVar10 = param_1;
        }
        do {
          pcVar5 = pcVar10;
          pcVar10 = pcVar5 + 1;
        } while (*pcVar5 != '\0');
        do {
          pcVar10 = pcVar5;
          pcVar5 = pcVar10 + -1;
          if (pcVar5 <= param_1) break;
        } while (*pcVar5 < '!');
        if ((param_1 <= pcVar5) && (*pcVar5 == '\"')) {
          pcVar5 = pcVar10 + -2;
        }
        pcVar5[1] = '\0';
        pcStack_18 = acStack_2010;
        pcStack_1c = pcVar2;
        pcStack_20 = (char *)0x5b006d;
        pcStack_14 = param_1;
        uVar6 = (**(code **)(pcVar2 + 0x2fec))();
        *(uint *)(pcVar2 + 0x1615c) = uVar6;
        if (uVar6 != 0) {
          if ((int)uVar6 < 1000) {
            return uVar6;
          }
          uVar15 = uVar6 & 0xffff;
          pcVar2[0x1615c] = '\0';
          pcVar2[0x1615d] = '\0';
          pcVar2[0x1615e] = '\0';
          pcVar2[0x1615f] = '\0';
        }
      }
      pcStack_14 = (char *)0x2000;
      pcStack_18 = acStack_2010;
      pcStack_1c = pcVar2;
      pcStack_20 = (char *)0x5b00a7;
      iVar4 = FUN_005b6770();
    }
    if (*(uint *)(pcVar2 + 0x1615c) != 0xffffffff) {
      return *(uint *)(pcVar2 + 0x1615c);
    }
    pcVar2[0x1615c] = '\0';
    pcVar2[0x1615d] = '\0';
    pcVar2[0x1615e] = '\0';
    pcVar2[0x1615f] = '\0';
LAB_005b00d9:
    pcVar5 = pcVar2 + 0x130b4;
    pcStack_14 = (char *)0x20;
    pcStack_1c = (char *)0x5b00e1;
    pcStack_18 = pcVar5;
    param_1 = (char *)FUN_0170dbd0();
    if (param_1 == (char *)0x0) {
LAB_005b0140:
      uVar6 = 0;
LAB_005b0145:
      pcStack_14 = "HTTP/";
      pcStack_1c = (char *)0x5b0150;
      pcStack_18 = pcVar5;
      param_1 = (char *)FUN_0170de40();
      uVar11 = (ushort)uVar6;
      if ((param_1 != (char *)0x0) && (*(char *)((int)param_1 + 7) != '1')) {
        if (*(short *)(pcVar2 + 0x1612c) == 1) {
          pcVar2[0x1612c] = '\0';
          pcVar2[0x1612d] = '\0';
        }
        if ((uVar11 == 0) && (((byte)*(uint *)(pcVar2 + 0x10) & 3) == 3)) {
          *(uint *)(pcVar2 + 0xc) = *(uint *)(pcVar2 + 0xc) | 3;
          *(uint *)(pcVar2 + 0x10) = *(uint *)(pcVar2 + 0x10) & 0xfffffffe | 2;
        }
      }
      if (*(short *)(pcVar2 + 0x1612c) < 0) {
        pcVar2[0x1612c] = '\x01';
        pcVar2[0x1612d] = '\0';
      }
      if (uVar11 != 0) goto LAB_005b0399;
      if (param_1 != (char *)0x0) {
        iVar14 = 5;
        pcStack_1c = pcVar2 + 0x130b4;
        pcStack_14 = (char *)0x5;
        pcStack_18 = "POST ";
        pcStack_20 = (char *)0x5b01d1;
        iVar4 = FUN_01723e00();
        if (iVar4 == 0) {
          uVar3 = 1;
        }
        else {
          iVar14 = 4;
          pcStack_1c = pcVar2 + 0x130b4;
          pcStack_14 = (char *)0x4;
          pcStack_18 = "GET ";
          pcStack_20 = (char *)0x5b01f7;
          iVar4 = FUN_01723e00();
          if (iVar4 == 0) {
            uVar3 = 2;
          }
          else {
            pcStack_14 = (char *)0x4;
            pcStack_1c = pcVar2 + 0x130b4;
            pcStack_18 = "PUT ";
            pcStack_20 = (char *)0x5b0216;
            iVar4 = FUN_01723e00();
            if (iVar4 == 0) {
              uVar3 = 3;
            }
            else {
              iVar14 = 7;
              pcStack_1c = pcVar2 + 0x130b4;
              pcStack_14 = (char *)0x7;
              pcStack_18 = "DELETE ";
              pcStack_20 = (char *)0x5b023b;
              iVar4 = FUN_01723e00();
              if (iVar4 == 0) {
                uVar3 = 4;
              }
              else {
                iVar14 = 5;
                pcStack_1c = pcVar2 + 0x130b4;
                pcStack_14 = (char *)0x5;
                pcStack_18 = "HEAD ";
                pcStack_20 = (char *)0x5b025e;
                iVar4 = FUN_01723e00();
                uVar3 = 0;
                if (iVar4 == 0) {
                  uVar3 = 5;
                }
              }
            }
          }
        }
        if ((param_1 != (char *)0x0) && (uVar3 != 0)) {
          pcVar5 = pcVar2 + 0x15518;
          do {
            cVar1 = *pcVar5;
            pcVar5 = pcVar5 + 1;
          } while (cVar1 != '\0');
          uVar7 = (int)pcVar5 - (int)(pcVar2 + 0x15519);
          uVar12 = (int)param_1 + -0x130b5 + ((uVar7 - iVar14) - (int)pcVar2);
          uVar9 = uVar12;
          if (uVar7 <= uVar12) {
            uVar9 = uVar7;
          }
          if (0x3ff < uVar12) {
            uVar12 = 0x3ff;
          }
          pcStack_1c = pcVar2 + 0x15918;
          pcStack_18 = pcVar2 + iVar14 + 0x130b4;
          pcStack_20 = (char *)0x5b02d4;
          pcStack_14 = (char *)(uVar12 - uVar9);
          FUN_0171dd10();
          pcVar5 = pcVar2 + 0x15918;
          pcVar2[(uVar12 - uVar9) + 0x15918] = '\0';
          pcVar10 = pcVar5;
          do {
            cVar1 = *pcVar10;
            pcVar10 = pcVar10 + 1;
          } while (cVar1 != '\0');
          pcVar8 = pcVar2 + 0x15517;
          do {
            pcVar13 = pcVar8 + 1;
            pcVar8 = pcVar8 + 1;
          } while (*pcVar13 != '\0');
          pcVar13 = pcVar5;
          for (uVar9 = (uint)((int)pcVar10 - (int)pcVar5) >> 2; uVar9 != 0; uVar9 = uVar9 - 1) {
            *(undefined4 *)pcVar8 = *(undefined4 *)pcVar13;
            pcVar13 = pcVar13 + 4;
            pcVar8 = pcVar8 + 4;
          }
          for (uVar9 = (int)pcVar10 - (int)pcVar5 & 3; uVar9 != 0; uVar9 = uVar9 - 1) {
            *pcVar8 = *pcVar13;
            pcVar13 = pcVar13 + 1;
            pcVar8 = pcVar8 + 1;
          }
          if (1 < uVar3) {
            switch(uVar3) {
            case 2:
              pcStack_14 = pcVar2;
              pcStack_18 = (char *)0x5b0332;
              uVar15 = (**(code **)(pcVar2 + 0x2fcc))();
              break;
            case 3:
              pcStack_14 = pcVar2;
              pcStack_18 = (char *)0x5b0340;
              uVar15 = (**(code **)(pcVar2 + 0x2fd0))();
              break;
            case 4:
              pcStack_14 = pcVar2;
              pcStack_18 = (char *)0x5b034e;
              uVar15 = (**(code **)(pcVar2 + 0x2fd4))();
              break;
            case 5:
              pcStack_14 = pcVar2;
              pcStack_18 = (char *)0x5b035c;
              uVar15 = (**(code **)(pcVar2 + 0x2fd8))();
              break;
            default:
              uVar15 = 0x13;
            }
            *(uint *)(pcVar2 + 0x1615c) = uVar15;
            if (uVar15 != 0) {
              return uVar15;
            }
            pcVar2[0x1615c] = -0x18;
            pcVar2[0x1615d] = '\x03';
            pcVar2[0x1615e] = '\0';
            pcVar2[0x1615f] = '\0';
            return 1000;
          }
          if ((short)uVar15 != 0) {
LAB_005b0429:
            *(uint *)(pcVar2 + 0x1615c) = uVar15;
            return uVar15;
          }
LAB_005b0399:
          *(uint *)(pcVar2 + 0x16158) = uVar6;
          if ((((uVar11 != 0) && (uVar11 != 200)) &&
              ((((uVar11 < 0xc9 || (299 < uVar11)) && ((uVar11 != 400 && (uVar11 != 500)))) ||
               ((*(int *)(pcVar2 + 0x30a4) == 0 && (((byte)*(undefined4 *)(pcVar2 + 0xc) & 3) != 3))
               )))) && (((uVar11 != 400 && (uVar11 != 500)) ||
                        ((*(int *)(pcVar2 + 0x24) == 0 && (*(short *)(pcVar2 + 0x1612c) != 0)))))) {
            pcStack_18 = pcVar2 + 0x130b4;
            pcStack_1c = "HTTP Error";
            pcStack_20 = pcVar2;
            uStack_24 = 0x5b0417;
            pcStack_14 = (char *)uVar6;
            uVar15 = FUN_005bcf60();
            return uVar15;
          }
          return 0;
        }
      }
      if ((short)uVar15 != 0) goto LAB_005b0429;
      if (param_1 != (char *)0x0) {
        pcVar2[0x1615c] = -0x6b;
        pcVar2[0x1615d] = '\x01';
        pcVar2[0x1615e] = '\0';
        pcVar2[0x1615f] = '\0';
        return 0x195;
      }
      goto LAB_005b0399;
    }
    pcStack_14 = (char *)0xa;
    pcStack_18 = (char *)&param_1;
    pcStack_20 = (char *)0x5b00f7;
    pcStack_1c = param_1;
    uVar6 = FUN_0171d7dd();
    uVar6 = uVar6 & 0xffff;
    if ((*param_1 < '\0') || (' ' < *param_1)) goto LAB_005b0140;
    if (uVar6 != 100) goto LAB_005b0145;
    pcStack_14 = (char *)0x400;
    pcStack_1c = pcVar2;
    pcStack_20 = (char *)0x5b011e;
    pcStack_18 = pcVar5;
    iVar4 = FUN_005b6770();
  } while( true );
}



/* FUNCTION 4920 ; VA 0x005b0490 ; FUN_005b0490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_005b0490(int param_1,undefined4 param_2,char *param_3)

{
  int iVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined *puVar4;
  char *pcVar5;
  uint uVar6;
  int iStack_8;
  
  iVar1 = FUN_005bdc80(param_2,&DAT_018c39a4);
  if (iVar1 == 0) {
    *(undefined4 *)(param_1 + 0x15518) = DAT_018c39ac;
    *(undefined4 *)(param_1 + 0x1551c) = _DAT_018c39b0;
    FUN_01723cc0((undefined4 *)(param_1 + 0x15518),param_3,0x3f8);
    *(undefined *)(param_1 + 0x15917) = 0;
    return 0;
  }
  iVar1 = FUN_005bdc80(param_2,"Content-Type");
  if (iVar1 == 0) {
    uVar2 = FUN_005bd1b0(param_1,param_3);
    *(undefined4 *)(param_1 + 0x24) = uVar2;
    iVar1 = FUN_005b58c0(param_1,param_3,"application/dime");
    if (iVar1 == 0) {
      iVar1 = FUN_005b58c0(param_1,param_3,"multipart/related");
      if ((iVar1 != 0) || (iVar1 = FUN_005b58c0(param_1,param_3,"multipart/form-data"), iVar1 != 0))
      {
        uVar2 = FUN_005b58c0(param_1,param_3,"boundary");
        uVar2 = FUN_005bd1b0(param_1,uVar2);
        *(undefined4 *)(param_1 + 0x1619c) = uVar2;
        uVar2 = FUN_005b58c0(param_1,param_3,"start");
        uVar2 = FUN_005bd1b0(param_1,uVar2);
        *(undefined4 *)(param_1 + 0x161a0) = uVar2;
        *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x100;
      }
    }
    else {
      *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x80;
    }
    param_3 = (char *)FUN_005b58c0(param_1,param_3,"action");
    if (param_3 != (char *)0x0) {
      if (*param_3 == '\"') {
        pcVar3 = (char *)FUN_005bd1b0(param_1,param_3 + 1);
        *(char **)(param_1 + 0x16118) = pcVar3;
        do {
          pcVar5 = pcVar3;
          pcVar3 = pcVar5 + 1;
        } while (*pcVar5 != '\0');
        pcVar5[-1] = '\0';
        return 0;
      }
LAB_005b0885:
      uVar2 = FUN_005bd1b0(param_1,param_3);
      *(undefined4 *)(param_1 + 0x16118) = uVar2;
      return 0;
    }
  }
  else {
    iVar1 = FUN_005bdc80(param_2,"Content-Length");
    if (iVar1 == 0) {
      uVar2 = FUN_0171d7dd(param_3,0,10);
      *(undefined4 *)(param_1 + 0x30a4) = uVar2;
      return 0;
    }
    iVar1 = FUN_005bdc80(param_2,"Content-Encoding");
    if (iVar1 == 0) {
      iVar1 = FUN_005bdc80(param_3,"deflate");
      if ((iVar1 == 0) || (iVar1 = FUN_005bdc80(param_3,&DAT_018c3a24), iVar1 == 0)) {
        return 0x1f;
      }
    }
    else {
      iVar1 = FUN_005bdc80(param_2,"Transfer-Encoding");
      if (iVar1 == 0) {
        uVar6 = *(uint *)(param_1 + 8) & 0xfffffffc;
        *(uint *)(param_1 + 8) = uVar6;
        iVar1 = FUN_005bdc80(param_3,"chunked");
        if (iVar1 == 0) {
          *(uint *)(param_1 + 8) = uVar6 | 3;
          return 0;
        }
      }
      else {
        iVar1 = FUN_005bdc80(param_2,"Connection");
        if (iVar1 == 0) {
          iVar1 = FUN_005bdc80(param_3,"keep-alive");
          if (iVar1 == 0) {
            *(short *)(param_1 + 0x1612c) = -*(short *)(param_1 + 0x1612c);
            return 0;
          }
          iVar1 = FUN_005bdc80(param_3,"close");
          if (iVar1 == 0) {
            *(undefined2 *)(param_1 + 0x1612c) = 0;
            return 0;
          }
        }
        else {
          iVar1 = FUN_005bdc80(param_2,"Authorization");
          if (iVar1 == 0) {
            iVar1 = FUN_005bdc80(param_3,"Basic *");
            if (iVar1 == 0) {
              iVar1 = param_1 + 0x134b4;
              FUN_005b1c50(param_1,param_3 + 6,iVar1,0x3ff,&iStack_8);
              *(undefined *)(iStack_8 + 0x134b4 + param_1) = 0;
              puVar4 = (undefined *)FUN_0170dbd0(iVar1,0x3a);
              if (puVar4 != (undefined *)0x0) {
                *puVar4 = 0;
                uVar2 = FUN_005bd1b0(param_1,iVar1);
                *(undefined4 *)(param_1 + 0x2fc0) = uVar2;
                uVar2 = FUN_005bd1b0(param_1,puVar4 + 1);
                *(undefined4 *)(param_1 + 0x2fc4) = uVar2;
              }
            }
          }
          else {
            iVar1 = FUN_005bdc80(param_2,"WWW-Authenticate");
            if (iVar1 == 0) {
              uVar2 = FUN_005b58c0(param_1,param_3 + 6,"realm");
              uVar2 = FUN_005bd1b0(param_1,uVar2);
              *(undefined4 *)(param_1 + 0x1611c) = uVar2;
              return 0;
            }
            iVar1 = FUN_005bdc80(param_2,"Expect");
            if (iVar1 == 0) {
              iVar1 = FUN_005bdc80(param_3,"100-continue");
              if (iVar1 == 0) {
                iVar1 = (**(code **)(param_1 + 0x2fe0))(param_1,"HTTP/1.1 100 Continue",0);
                *(int *)(param_1 + 0x1615c) = iVar1;
                if (iVar1 != 0) {
                  return iVar1;
                }
                iVar1 = (**(code **)(param_1 + 0x2fe0))(param_1,0,0);
                *(int *)(param_1 + 0x1615c) = iVar1;
                if (iVar1 != 0) {
                  return iVar1;
                }
              }
            }
            else {
              iVar1 = FUN_005bdc80(param_2,"SOAPAction");
              if (iVar1 == 0) {
                if (*param_3 == '\"') {
                  pcVar3 = (char *)FUN_005bd1b0(param_1,param_3 + 1);
                  *(char **)(param_1 + 0x16118) = pcVar3;
                  do {
                    pcVar5 = pcVar3;
                    pcVar3 = pcVar5 + 1;
                  } while (*pcVar5 != '\0');
                  pcVar5[-1] = '\0';
                  return 0;
                }
                goto LAB_005b0885;
              }
              iVar1 = FUN_005bdc80(param_2,&DAT_018c3ad8);
              if (iVar1 == 0) {
                FUN_0171dd10(param_1 + 0x15518,param_3,0x400);
                *(undefined *)(param_1 + 0x15917) = 0;
                return 0;
              }
              iVar1 = FUN_005bdc80(param_2,"X-Forwarded-For");
              if (iVar1 == 0) {
                uVar2 = FUN_005bd1b0(param_1,param_3);
                *(undefined4 *)(param_1 + 0x16154) = uVar2;
                return 0;
              }
              iVar1 = FUN_005bdc80(param_2,"Roblox-Id");
              if (iVar1 == 0) {
                return 0x2b;
              }
            }
          }
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 4921 ; VA 0x005b0930 ; FUN_005b0930 */

int FUN_005b0930(int param_1,char *param_2,char *param_3,int param_4,char *param_5,char *param_6,
                undefined4 param_7)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  undefined1 *puVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  
  puVar4 = &DAT_018c3c98;
  if (*(int *)(param_1 + 0x16158) == 0x7d1) {
    puVar4 = &DAT_018c3c94;
  }
  if ((param_2 == (char *)0x0) ||
     (((iVar5 = FUN_005bdc80(param_2,"http:*"), iVar5 != 0 &&
       (iVar5 = FUN_005bdc80(param_2,"https:*"), iVar5 != 0)) &&
      (iVar5 = FUN_01723e00(param_2,"httpg:",6), iVar5 != 0)))) {
    return 0;
  }
  pcVar6 = param_2;
  do {
    cVar3 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar3 != '\0');
  pcVar8 = *(char **)(param_1 + 0x20);
  pcVar1 = pcVar8 + 1;
  do {
    cVar3 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar3 != '\0');
  if (pcVar6 + (int)(pcVar8 + (-(int)pcVar1 - (int)(param_2 + 1))) < (char *)0x3b1) {
    if ((*(int *)(param_1 + 0x16144) == 0) || (iVar5 = FUN_005bdc80(param_2,"https:*"), iVar5 == 0))
    {
      pcVar6 = "%s /%s HTTP/%s";
      param_2 = param_5 + 1;
      if (*param_5 != '/') {
        param_2 = param_5;
      }
    }
    else {
      pcVar6 = "%s %s HTTP/%s";
    }
    pcVar1 = (char *)(param_1 + 0x134b4);
    FUN_005bde90(pcVar1,pcVar6,puVar4,param_2,*(undefined4 *)(param_1 + 0x20));
    iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,pcVar1,0);
    if (iVar5 != 0) {
      return iVar5;
    }
    pcVar6 = pcVar1;
    if (param_4 == 0x50) {
      do {
        cVar3 = *param_3;
        param_3 = param_3 + 1;
        *pcVar6 = cVar3;
        pcVar6 = pcVar6 + 1;
      } while (cVar3 != '\0');
    }
    else {
      FUN_005bde90(pcVar1,"%s:%d",param_3,param_4);
    }
    iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,&DAT_018c39a4,pcVar1);
    if (iVar5 != 0) {
      return iVar5;
    }
    iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,"User-Agent","gSOAP/2.7");
    if (iVar5 != 0) {
      return iVar5;
    }
    iVar5 = FUN_005ba390(param_1,0,param_7);
    if (iVar5 != 0) {
      return iVar5;
    }
    pcVar6 = *(char **)(param_1 + 0x2fc0);
    if ((pcVar6 != (char *)0x0) && (pcVar8 = *(char **)(param_1 + 0x2fc4), pcVar8 != (char *)0x0)) {
      pcVar7 = pcVar6;
      do {
        cVar3 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar3 != '\0');
      pcVar2 = pcVar8 + 1;
      do {
        cVar3 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar3 != '\0');
      if (pcVar7 + (int)(pcVar8 + (-(int)pcVar2 - (int)(pcVar6 + 1))) < (char *)0x2f9) {
        FUN_005bde90(param_1 + 0x135ba,"%s:%s",pcVar6,*(undefined4 *)(param_1 + 0x2fc4));
        *(undefined4 *)pcVar1 = DAT_018c3cf8;
        *(undefined2 *)(param_1 + 0x134b8) = DAT_018c3cfc;
        *(undefined *)(param_1 + 0x134ba) = DAT_018c3cfe;
        pcVar6 = (char *)(param_1 + 0x135ba);
        do {
          cVar3 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar3 != '\0');
        FUN_005bbaa0(param_1,(char *)(param_1 + 0x135ba),param_1 + 0x134ba,
                     (int)pcVar6 - (param_1 + 0x135bb));
        iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,"Authorization",pcVar1);
        if (iVar5 != 0) {
          return iVar5;
        }
      }
    }
    pcVar6 = *(char **)(param_1 + 0x1614c);
    if ((pcVar6 != (char *)0x0) && (pcVar8 = *(char **)(param_1 + 0x16150), pcVar8 != (char *)0x0))
    {
      pcVar7 = pcVar6;
      do {
        cVar3 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar3 != '\0');
      pcVar2 = pcVar8 + 1;
      do {
        cVar3 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar3 != '\0');
      if (pcVar7 + (int)(pcVar8 + (-(int)pcVar2 - (int)(pcVar6 + 1))) < (char *)0x2f9) {
        FUN_005bde90(param_1 + 0x135ba,"%s:%s",pcVar6,*(undefined4 *)(param_1 + 0x16150));
        *(undefined4 *)pcVar1 = DAT_018c3cf8;
        *(undefined2 *)(param_1 + 0x134b8) = DAT_018c3cfc;
        *(undefined *)(param_1 + 0x134ba) = DAT_018c3cfe;
        pcVar6 = (char *)(param_1 + 0x135ba);
        do {
          cVar3 = *pcVar6;
          pcVar6 = pcVar6 + 1;
        } while (cVar3 != '\0');
        FUN_005bbaa0(param_1,(char *)(param_1 + 0x135ba),param_1 + 0x134ba,
                     (int)pcVar6 - (param_1 + 0x135bb));
        iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,"Proxy-Authorization",pcVar1);
        if (iVar5 != 0) {
          return iVar5;
        }
      }
    }
    if (*(int *)(param_1 + 0x16158) == 0x7d1) goto LAB_005b0c91;
    if (*(short *)(param_1 + 6) != 1) {
      if ((param_6 == (char *)0x0) || (*param_6 == '\0')) goto LAB_005b0c91;
      pcVar6 = param_6;
      do {
        cVar3 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar3 != '\0');
      if (0x3fd < (uint)((int)pcVar6 - (int)(param_6 + 1))) goto LAB_005b0c91;
    }
    pcVar6 = "";
    if (param_6 != (char *)0x0) {
      pcVar6 = param_6;
    }
    FUN_005bde90(pcVar1,&DAT_018c3d14,pcVar6);
    iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,"SOAPAction",pcVar1);
    if (iVar5 == 0) {
LAB_005b0c91:
      iVar5 = (**(code **)(param_1 + 0x2fe0))(param_1,0,0);
      return iVar5;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    iVar5 = 0x14;
  }
  return iVar5;
}



/* FUNCTION 4922 ; VA 0x005b0cb0 ; FUN_005b0cb0 */

undefined4 FUN_005b0cb0(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_2 != 0) {
    iVar1 = FUN_005b0fa0(param_1,param_2);
    if (iVar1 == 0) {
      if (param_3 == 0) goto LAB_005b0cff;
      iVar1 = FUN_005bc2c0(param_1,&DAT_018bcaac,2);
      if (iVar1 == 0) {
        iVar1 = FUN_005b0fa0(param_1,param_3);
        if (iVar1 == 0) goto LAB_005b0cff;
      }
    }
    return *(undefined4 *)(param_1 + 0x1615c);
  }
LAB_005b0cff:
  uVar2 = FUN_005bc2c0(param_1,&DAT_018c38c4,2);
  return uVar2;
}



/* FUNCTION 4923 ; VA 0x005b0d20 ; FUN_005b0d20 */

int FUN_005b0d20(int param_1,int param_2,int param_3)

{
  char cVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  uint uVar7;
  char *pcVar8;
  byte *pbVar9;
  char *pcVar10;
  bool bVar11;
  undefined8 uVar12;
  
  pcVar10 = *(char **)(param_1 + 0x20);
  pcVar8 = pcVar10;
  do {
    cVar1 = *pcVar8;
    pcVar8 = pcVar8 + 1;
  } while (cVar1 != '\0');
  if (4 < (uint)((int)pcVar8 - (int)(pcVar10 + 1))) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return 0x14;
  }
  if (((param_2 == 0) || (param_2 == 0x3ea)) || (param_2 == 0x3eb)) {
    if ((param_3 != 0) ||
       (pcVar8 = "202 ACCEPTED", ((byte)*(undefined4 *)(param_1 + 0x10) & 3) == 3)) {
      pcVar8 = "200 OK";
    }
    if ((*(int *)(param_1 + 0x3074) != -1) || (*(int *)(param_1 + 0x3078) != -1)) {
      FUN_005bde90(param_1 + 0x134b4,"HTTP/%s %s",pcVar10,pcVar8);
      iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,param_1 + 0x134b4,0);
      if (iVar4 != 0) {
        return iVar4;
      }
      goto LAB_005b0f55;
    }
  }
  else {
    if (param_2 - 200U < 400) {
      uVar12 = FUN_005aff20(param_1,param_2);
      iVar4 = param_1 + 0x134b4;
      FUN_005bde90(iVar4,"HTTP/%s %d %s",(int)((ulonglong)uVar12 >> 0x20),param_2,(int)uVar12);
      iVar3 = (**(code **)(param_1 + 0x2fe0))(param_1,iVar4,0);
      if (iVar3 != 0) {
        return iVar3;
      }
      if (param_2 == 0x191) {
        pcVar10 = *(char **)(param_1 + 0x1611c);
        if (pcVar10 != (char *)0x0) {
          pcVar8 = pcVar10;
          do {
            cVar1 = *pcVar8;
            pcVar8 = pcVar8 + 1;
          } while (cVar1 != '\0');
          if (0x3f1 < (uint)((int)pcVar8 - (int)(pcVar10 + 1))) {
            pcVar10 = "gSOAP Web Service";
          }
        }
        FUN_005bde90(iVar4,"Basic realm=\"%s\"",pcVar10);
        iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"WWW-Authenticate",iVar4);
        if (iVar4 != 0) {
          return iVar4;
        }
      }
      else if ((((300 < param_2) && (param_2 < 0x130)) || (param_2 == 0x133)) &&
              (iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,&DAT_018c3ad8,param_1 + 0x15518),
              iVar4 != 0)) {
        return iVar4;
      }
      goto LAB_005b0f55;
    }
    puVar5 = (undefined4 *)FUN_005acd30(param_1);
    pbVar6 = (byte *)*puVar5;
    if (*(short *)(param_1 + 6) == 2) {
      if (pbVar6 != (byte *)0x0) {
        pbVar9 = &DAT_018c3d80;
        do {
          bVar2 = *pbVar6;
          bVar11 = bVar2 < *pbVar9;
          if (bVar2 != *pbVar9) {
LAB_005b0e93:
            uVar7 = -(uint)bVar11 | 1;
            goto LAB_005b0e98;
          }
          if (bVar2 == 0) break;
          bVar2 = pbVar6[1];
          bVar11 = bVar2 < pbVar9[1];
          if (bVar2 != pbVar9[1]) goto LAB_005b0e93;
          pbVar6 = pbVar6 + 2;
          pbVar9 = pbVar9 + 2;
        } while (bVar2 != 0);
        uVar7 = 0;
LAB_005b0e98:
        if (uVar7 != 0) goto LAB_005b0ea3;
      }
      pcVar8 = "400 Bad Request";
    }
    else {
LAB_005b0ea3:
      pcVar8 = "500 Internal Server Error";
    }
    if ((*(int *)(param_1 + 0x3074) != -1) || (*(int *)(param_1 + 0x3078) != -1)) {
      FUN_005bde90(param_1 + 0x134b4,"HTTP/%s %s",*(undefined4 *)(param_1 + 0x20),pcVar8);
      iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,param_1 + 0x134b4,0);
      if (iVar4 != 0) {
        return iVar4;
      }
      goto LAB_005b0f55;
    }
  }
  iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,&DAT_018c3d40,pcVar8);
  if (iVar4 != 0) {
    return iVar4;
  }
LAB_005b0f55:
  iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,"Server","gSOAP/2.7");
  if ((iVar4 == 0) && (iVar4 = FUN_005ba390(param_1,param_2,param_3), iVar4 == 0)) {
    iVar4 = (**(code **)(param_1 + 0x2fe0))(param_1,0,0);
  }
  return iVar4;
}



/* FUNCTION 4924 ; VA 0x005b0fa0 ; FUN_005b0fa0 */

undefined4 FUN_005b0fa0(int param_1,char *param_2)

{
  uint uVar1;
  char *pcVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  uint uStack_8;
  
  do {
    pcVar3 = (char *)FUN_0170dbd0(param_2,10);
    pcVar2 = param_2;
    if (pcVar3 == (char *)0x0) {
      do {
        pcVar3 = pcVar2;
        pcVar2 = pcVar3 + 1;
      } while (*pcVar3 != '\0');
    }
    uVar5 = (int)pcVar3 - (int)param_2;
    if (uVar5 != 0) {
      uVar1 = *(uint *)(param_1 + 8);
      if ((uVar1 & 8) == 0) {
        if ((uVar1 & 3) == 0) {
          iVar4 = FUN_005b5160(param_1,param_2,uVar5);
          goto LAB_005b10be;
        }
        iVar4 = *(int *)(param_1 + 0x308c);
        uStack_8 = 0x10000 - iVar4;
        if (uStack_8 <= uVar5) {
          do {
            FUN_0170c6f0(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1,param_2,uStack_8);
            *(undefined4 *)(param_1 + 0x308c) = 0;
            iVar4 = FUN_005b5160(param_1,param_1 + 0x30b4,0x10000);
            if (iVar4 != 0) {
              iVar4 = *(int *)(param_1 + 0x1615c);
              goto LAB_005b10be;
            }
            uVar5 = uVar5 - uStack_8;
            param_2 = param_2 + uStack_8;
            uStack_8 = 0x10000;
          } while (0xffff < uVar5);
          iVar4 = *(int *)(param_1 + 0x308c);
        }
        FUN_0170c6f0(param_1 + 0x30b4 + iVar4,param_2,uVar5);
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + uVar5;
      }
      else {
        *(int *)(param_1 + 0x30a0) = *(int *)(param_1 + 0x30a0) + uVar5;
        if ((*(code **)(param_1 + 0x3038) != (code *)0x0) && (((byte)uVar1 & 3) != 2)) {
          iVar4 = (**(code **)(param_1 + 0x3038))(param_1,param_2,uVar5);
          *(int *)(param_1 + 0x1615c) = iVar4;
LAB_005b10be:
          if (iVar4 != 0) {
            return *(undefined4 *)(param_1 + 0x1615c);
          }
        }
      }
    }
    param_2 = pcVar3 + 1;
    if (*pcVar3 == '\0') {
      return 0;
    }
  } while( true );
}



/* FUNCTION 4925 ; VA 0x005b10f0 ; FUN_005b10f0 */

int FUN_005b10f0(int param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  int iVar7;
  int *piVar8;
  
  if (param_2 == (char *)0x0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0x30b0) = 0;
  while (cVar3 = *param_2, cVar3 != '\0') {
    do {
      pcVar5 = param_2;
      if ((cVar3 < '\0') || (' ' < cVar3)) break;
      cVar3 = param_2[1];
      param_2 = param_2 + 1;
      pcVar5 = param_2;
    } while (cVar3 != '\0');
    if (cVar3 == '\0') break;
    pcVar6 = pcVar5 + 1;
    iVar7 = 1;
    cVar3 = pcVar5[1];
    while ((cVar3 != '\0' && ((cVar3 < '\0' || (' ' < cVar3))))) {
      iVar1 = iVar7 + 1;
      iVar7 = iVar7 + 1;
      cVar3 = pcVar5[iVar1];
    }
    if (*pcVar5 == '\"') {
      iVar1 = FUN_0170dbd0(pcVar6,0x22);
      if (iVar1 != 0) {
        piVar8 = *(int **)(param_1 + 0x54);
        if (piVar8 != (int *)0x0) {
          iVar2 = *piVar8;
joined_r0x005b11bc:
          if (iVar2 != 0) {
            if (((piVar8[1] == 0) || (iVar2 = FUN_005bdc80(pcVar6,piVar8[1]), iVar2 != 0)) &&
               ((piVar8[2] == 0 || (iVar2 = FUN_005bdc80(pcVar6,piVar8[2]), iVar2 != 0))))
            goto LAB_005b11ea;
            pcVar4 = (char *)*piVar8;
            if (pcVar4 != (char *)0x0) {
              pcVar5 = pcVar4;
              do {
                cVar3 = *pcVar5;
                pcVar5 = pcVar5 + 1;
              } while (cVar3 != '\0');
              iVar2 = (int)pcVar5 - (int)(pcVar4 + 1);
              goto LAB_005b12aa;
            }
          }
        }
        param_2 = (char *)0x0;
        if (pcVar6 != (char *)0x0) {
          pcVar4 = pcVar6;
          do {
            cVar3 = *pcVar4;
            pcVar4 = pcVar4 + 1;
          } while (cVar3 != '\0');
          param_2 = (char *)FUN_005b7fc0(param_1,pcVar4 + (1 - (int)(pcVar5 + 2)));
          if (param_2 != (char *)0x0) {
            pcVar5 = pcVar6;
            do {
              cVar3 = *pcVar5;
              pcVar5 = pcVar5 + 1;
              pcVar5[((int)param_2 - (int)pcVar6) + -1] = cVar3;
            } while (cVar3 != '\0');
          }
        }
        *(undefined *)(((int)param_2 - (int)pcVar6) + iVar1) = 0;
        iVar2 = *(int *)(param_1 + 0x2fb4);
        *(int *)(param_1 + 0x2fb4) = iVar2 + 1;
        FUN_005bde90(param_1 + 0x134b4,"xmlns:_%d",iVar2);
        FUN_005bc430(param_1,param_1 + 0x134b4,param_2);
        pcVar4 = (char *)(param_1 + 0x134ba);
        pcVar5 = pcVar4;
        do {
          cVar3 = *pcVar5;
          pcVar5 = pcVar5 + 1;
        } while (cVar3 != '\0');
        iVar2 = (int)pcVar5 - (param_1 + 0x134bb);
LAB_005b12aa:
        FUN_005b19f0(param_1,pcVar4,iVar2);
        FUN_005b19f0(param_1,iVar1 + 1,pcVar6 + (iVar7 - iVar1) + -1);
      }
    }
    else {
      FUN_005b19f0(param_1,pcVar5,iVar7);
      pcVar6 = pcVar5;
      if (((*(uint *)(param_1 + 8) & 0x4000) != 0) &&
         (iVar1 = FUN_0170dbd0(pcVar5,0x3a), iVar1 != 0)) {
        FUN_005bdd60(param_1,pcVar5,iVar1 - (int)pcVar5);
      }
    }
    param_2 = pcVar6 + iVar7;
    if (*param_2 != '\0') {
      FUN_005b19f0(param_1,&DAT_018c0cc8,1);
    }
  }
  FUN_005b19f0(param_1,&DAT_018c2414,1);
  pcVar5 = *(char **)(param_1 + 0x30a8);
  iVar7 = 0;
  if (pcVar5 != (char *)0x0) {
    pcVar6 = pcVar5;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    iVar7 = FUN_005b7fc0(param_1,pcVar6 + (1 - (int)(pcVar5 + 1)));
    if (iVar7 != 0) {
      iVar1 = iVar7 - (int)pcVar5;
      do {
        cVar3 = *pcVar5;
        pcVar5 = pcVar5 + 1;
        pcVar5[iVar1 + -1] = cVar3;
      } while (cVar3 != '\0');
    }
  }
  return iVar7;
LAB_005b11ea:
  piVar8 = piVar8 + 4;
  iVar2 = *piVar8;
  goto joined_r0x005b11bc;
}



/* FUNCTION 4926 ; VA 0x005b1350 ; FUN_005b1350 */

undefined4 FUN_005b1350(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  char *pcVar7;
  undefined4 uStack_11c;
  int iStack_118;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_1;
  uStack_14 = 0x10;
  uStack_18 = 0x10000;
  uStack_8 = 1;
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  if ((*(byte *)(param_1 + 0x10) & 4) != 0) {
    *(undefined4 *)(param_1 + 0x3078) = *(undefined4 *)(param_1 + 0x3074);
    return *(undefined4 *)(param_1 + 0x3074);
  }
  puVar4 = (undefined4 *)(param_1 + 0x171e4);
  *puVar4 = 0;
  *(undefined4 *)(param_1 + 0x171e8) = 0;
  *(undefined4 *)(param_1 + 0x171ec) = 0;
  *(undefined4 *)(param_1 + 0x171f0) = 0;
  *(undefined4 *)(param_1 + 0x3078) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x16160) = 0;
  *(undefined2 *)(param_1 + 0x1612c) = 0;
  if (*(int *)(param_1 + 0x3074) == -1) {
    *(undefined4 *)(param_1 + 0x16164) = 0;
    uVar5 = FUN_005be760(param_1);
    pcVar7 = "SOAP-ENV:Receiver";
    if (*(short *)(iVar2 + 6) != 2) {
      pcVar7 = "SOAP-ENV:Server";
    }
    puVar4 = (undefined4 *)FUN_005acd30(iVar2);
    *puVar4 = pcVar7;
    puVar4 = (undefined4 *)FUN_005ace30(iVar2);
    *puVar4 = uVar5;
    puVar4 = (undefined4 *)FUN_005acd60(iVar2);
    if (puVar4 != (undefined4 *)0x0) {
      *puVar4 = "no master socket in soap_accept()";
    }
LAB_005b19d8:
    *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
    return 0xffffffff;
  }
  do {
    if (((*(int *)(iVar2 + 0x3c) != 0) || (*(int *)(iVar2 + 0x34) != 0)) ||
       (*(int *)(iVar2 + 0x30) != 0)) {
LAB_005b13e6:
      iStack_10 = *(int *)(iVar2 + 0x3c);
      if (iStack_10 < 1) {
        if (-1 < iStack_10) {
          iStack_10 = 0x3c;
          goto LAB_005b1420;
        }
        iVar3 = (int)((ulonglong)((longlong)iStack_10 * -0x431bde83) >> 0x20);
        iStack_c = -iStack_10;
        iStack_10 = (iVar3 >> 0x12) - (iVar3 >> 0x1f);
        iStack_c = iStack_c % 1000000;
      }
      else {
LAB_005b1420:
        iStack_c = 0;
      }
      iStack_118 = *(int *)(iVar2 + 0x3074);
      uStack_11c = 1;
      iVar3 = Ordinal_18(iStack_118 + 1,&uStack_11c,&uStack_11c,&uStack_11c,&iStack_10);
      if (iVar3 < 1) {
        if (iVar3 == 0) {
          if (*(int *)(iVar2 + 0x3c) != 0) {
            pcVar7 = "SOAP-ENV:Receiver";
            *(undefined4 *)(iVar2 + 0x16164) = 0;
            if (*(short *)(iVar2 + 6) != 2) {
              pcVar7 = "SOAP-ENV:Server";
            }
            puVar4 = (undefined4 *)FUN_005acd30(iVar2);
            *puVar4 = pcVar7;
            puVar4 = (undefined4 *)FUN_005ace30(iVar2);
            *puVar4 = "Timeout";
            puVar4 = (undefined4 *)FUN_005acd60(iVar2);
            if (puVar4 != (undefined4 *)0x0) {
              *puVar4 = "accept failed in soap_accept()";
              *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
              return 0xffffffff;
            }
            goto LAB_005b19d8;
          }
        }
        else if ((iVar3 < 0) && (iVar3 = Ordinal_111(), iVar3 != 0x2714)) {
          iVar1 = *(int *)(iVar2 + 0x1615c);
          *(int *)(iVar2 + 0x16164) = iVar3;
          if (((iVar1 == -1) || ((iVar1 == 0x1c || (iVar1 == 0x1e)))) ||
             (*(short *)(iVar2 + 0x1612c) == 0)) {
            if (*(code **)(iVar2 + 0x3010) == (code *)0x0) {
LAB_005b1511:
              *(undefined2 *)(iVar2 + 0x1612c) = 0;
              goto LAB_005b151a;
            }
            iVar3 = (**(code **)(iVar2 + 0x3010))(iVar2);
            *(int *)(iVar2 + 0x1615c) = iVar3;
            if (iVar3 == 0) goto LAB_005b1511;
          }
          else {
LAB_005b151a:
            *(int *)(iVar2 + 0x1615c) = iVar1;
          }
          uVar5 = FUN_005be760(iVar2);
          pcVar7 = "SOAP-ENV:Sender";
          if (*(short *)(iVar2 + 6) != 2) {
            pcVar7 = "SOAP-ENV:Client";
          }
          puVar4 = (undefined4 *)FUN_005acd30(iVar2);
          *puVar4 = pcVar7;
          puVar4 = (undefined4 *)FUN_005ace30(iVar2);
          *puVar4 = uVar5;
          puVar4 = (undefined4 *)FUN_005acd60(iVar2);
          if (puVar4 != (undefined4 *)0x0) {
            *puVar4 = "accept failed in soap_accept()";
            *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
            return 0xffffffff;
          }
          goto LAB_005b19d8;
        }
        goto LAB_005b13e6;
      }
    }
    if (((*(int *)(iVar2 + 0x3c) != 0) || (*(int *)(iVar2 + 0x34) != 0)) ||
       (param_1 = 0, *(int *)(iVar2 + 0x30) != 0)) {
      param_1 = 1;
    }
    Ordinal_10(*(undefined4 *)(iVar2 + 0x3074),0x8004667e,&param_1);
    iVar3 = (**(code **)(iVar2 + 0x300c))(iVar2,*(undefined4 *)(iVar2 + 0x3074),puVar4,&uStack_14);
    *(int *)(iVar2 + 0x3078) = iVar3;
    *(undefined4 *)(iVar2 + 0x171f4) = uStack_14;
    if (iVar3 != -1) {
      uVar5 = Ordinal_14(*(undefined4 *)(iVar2 + 0x171e8));
      *(undefined4 *)(iVar2 + 0x16124) = uVar5;
      uVar6 = Ordinal_15(*(undefined2 *)(iVar2 + 0x171e6));
      *(uint *)(iVar2 + 0x16128) = uVar6 & 0xffff;
      iVar3 = *(int *)(iVar2 + 0x4c);
      if (iVar3 == 0x80) {
        param_1 = 1;
        iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),0xffff,0x80,&param_1,4);
        if (iVar3 != 0) {
          uVar5 = Ordinal_111();
          *(undefined4 *)(iVar2 + 0x16164) = uVar5;
          uVar5 = FUN_005be760(iVar2);
          pcVar7 = "SOAP-ENV:Receiver";
          if (*(short *)(iVar2 + 6) != 2) {
            pcVar7 = "SOAP-ENV:Server";
          }
          puVar4 = (undefined4 *)FUN_005acd30(iVar2);
          *puVar4 = pcVar7;
          puVar4 = (undefined4 *)FUN_005ace30(iVar2);
          *puVar4 = uVar5;
          puVar4 = (undefined4 *)FUN_005acd60(iVar2);
          if (puVar4 != (undefined4 *)0x0) {
            *puVar4 = "setsockopt SO_LINGER failed in soap_accept()";
          }
          goto LAB_005b183a;
        }
      }
      else if ((iVar3 != 0) &&
              (iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),0xffff,iVar3,&uStack_8,4),
              iVar3 != 0)) {
        uVar5 = Ordinal_111();
        *(undefined4 *)(iVar2 + 0x16164) = uVar5;
        uVar5 = FUN_005be760(iVar2);
        pcVar7 = "SOAP-ENV:Receiver";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar7 = "SOAP-ENV:Server";
        }
        puVar4 = (undefined4 *)FUN_005acd30(iVar2);
        *puVar4 = pcVar7;
        puVar4 = (undefined4 *)FUN_005ace30(iVar2);
        *puVar4 = uVar5;
        puVar4 = (undefined4 *)FUN_005acd60(iVar2);
        if (puVar4 != (undefined4 *)0x0) {
          *puVar4 = "setsockopt failed in soap_accept()";
        }
        goto LAB_005b183a;
      }
      if ((((*(uint *)(iVar2 + 0xc) | *(uint *)(iVar2 + 0x10)) & 0x10) == 0) ||
         (iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),0xffff,8,&uStack_8,4), iVar3 == 0)) {
        iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),0xffff,0x1001,&uStack_18,4);
        if (iVar3 == 0) {
          iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),0xffff,0x1002,&uStack_18,4);
          if (iVar3 == 0) {
            if (((*(byte *)(iVar2 + 0x10) & 4) != 0) ||
               (iVar3 = Ordinal_21(*(undefined4 *)(iVar2 + 0x3078),6,1,&uStack_8,4), iVar3 == 0)) {
              *(ushort *)(iVar2 + 0x1612c) =
                   ((ushort)(*(uint *)(iVar2 + 0xc) >> 4) | (ushort)(*(uint *)(iVar2 + 0x10) >> 4))
                   & 1;
              return *(undefined4 *)(iVar2 + 0x3078);
            }
            uVar5 = Ordinal_111();
            *(undefined4 *)(iVar2 + 0x16164) = uVar5;
            uVar5 = FUN_005be760(iVar2);
            pcVar7 = "SOAP-ENV:Receiver";
            if (*(short *)(iVar2 + 6) != 2) {
              pcVar7 = "SOAP-ENV:Server";
            }
            puVar4 = (undefined4 *)FUN_005acd30(iVar2);
            *puVar4 = pcVar7;
            puVar4 = (undefined4 *)FUN_005ace30(iVar2);
            *puVar4 = uVar5;
            puVar4 = (undefined4 *)FUN_005acd60(iVar2);
            if (puVar4 != (undefined4 *)0x0) {
              *puVar4 = "setsockopt TCP_NODELAY failed in soap_accept()";
            }
          }
          else {
            uVar5 = Ordinal_111();
            *(undefined4 *)(iVar2 + 0x16164) = uVar5;
            uVar5 = FUN_005be760(iVar2);
            pcVar7 = "SOAP-ENV:Receiver";
            if (*(short *)(iVar2 + 6) != 2) {
              pcVar7 = "SOAP-ENV:Server";
            }
            puVar4 = (undefined4 *)FUN_005acd30(iVar2);
            *puVar4 = pcVar7;
            puVar4 = (undefined4 *)FUN_005ace30(iVar2);
            *puVar4 = uVar5;
            puVar4 = (undefined4 *)FUN_005acd60(iVar2);
            if (puVar4 != (undefined4 *)0x0) {
              *puVar4 = "setsockopt SO_RCVBUF failed in soap_accept()";
            }
          }
          goto LAB_005b1953;
        }
        uVar5 = Ordinal_111();
        *(undefined4 *)(iVar2 + 0x16164) = uVar5;
        uVar5 = FUN_005be760(iVar2);
        pcVar7 = "SOAP-ENV:Receiver";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar7 = "SOAP-ENV:Server";
        }
        puVar4 = (undefined4 *)FUN_005acd30(iVar2);
        *puVar4 = pcVar7;
        puVar4 = (undefined4 *)FUN_005ace30(iVar2);
        *puVar4 = uVar5;
        puVar4 = (undefined4 *)FUN_005acd60(iVar2);
        if (puVar4 != (undefined4 *)0x0) {
          *puVar4 = "setsockopt SO_SNDBUF failed in soap_accept()";
        }
      }
      else {
        uVar5 = Ordinal_111();
        *(undefined4 *)(iVar2 + 0x16164) = uVar5;
        uVar5 = FUN_005be760(iVar2);
        pcVar7 = "SOAP-ENV:Receiver";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar7 = "SOAP-ENV:Server";
        }
        puVar4 = (undefined4 *)FUN_005acd30(iVar2);
        *puVar4 = pcVar7;
        puVar4 = (undefined4 *)FUN_005ace30(iVar2);
        *puVar4 = uVar5;
        puVar4 = (undefined4 *)FUN_005acd60(iVar2);
        if (puVar4 != (undefined4 *)0x0) {
          *puVar4 = "setsockopt SO_KEEPALIVE failed in soap_accept()";
        }
      }
LAB_005b183a:
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      if (*(code **)(iVar2 + 0x3010) != (code *)0x0) {
        iVar3 = (**(code **)(iVar2 + 0x3010))(iVar2);
        *(int *)(iVar2 + 0x1615c) = iVar3;
        if (iVar3 != 0) {
          return 0xffffffff;
        }
      }
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      *(undefined2 *)(iVar2 + 0x1612c) = 0;
      return 0xffffffff;
    }
    iVar3 = Ordinal_111();
    if (((iVar3 != 0) && (iVar3 != 0x2714)) && (iVar3 != 0x2733)) {
      *(int *)(iVar2 + 0x16164) = iVar3;
      uVar5 = FUN_005be760(iVar2);
      pcVar7 = "SOAP-ENV:Receiver";
      if (*(short *)(iVar2 + 6) != 2) {
        pcVar7 = "SOAP-ENV:Server";
      }
      puVar4 = (undefined4 *)FUN_005acd30(iVar2);
      *puVar4 = pcVar7;
      puVar4 = (undefined4 *)FUN_005ace30(iVar2);
      *puVar4 = uVar5;
      puVar4 = (undefined4 *)FUN_005acd60(iVar2);
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = "accept failed in soap_accept()";
      }
LAB_005b1953:
      *(undefined4 *)(iVar2 + 0x1615c) = 0x1c;
      FUN_005b2e00(iVar2);
      return 0xffffffff;
    }
  } while( true );
}



/* FUNCTION 4927 ; VA 0x005b19f0 ; FUN_005b19f0 */

undefined4 FUN_005b19f0(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  uVar3 = *(uint *)(param_1 + 0x30ac);
  uVar4 = *(int *)(param_1 + 0x30b0) + param_3;
  if (uVar3 <= uVar4) {
    iVar1 = *(int *)(param_1 + 0x30a8);
    if (uVar3 == 0) {
      *(undefined4 *)(param_1 + 0x30ac) = 0x100;
      uVar3 = 0x100;
    }
    if (uVar3 <= uVar4) {
      do {
        uVar3 = uVar3 * 2;
      } while (uVar3 <= uVar4);
      *(uint *)(param_1 + 0x30ac) = uVar3;
    }
    iVar2 = FUN_0171e1f2(uVar3);
    *(int *)(param_1 + 0x30a8) = iVar2;
    if (iVar2 == 0) {
      if (iVar1 != 0) {
        FUN_017168b0(iVar1);
      }
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0x14;
    }
    if (iVar1 != 0) {
      FUN_0170c6f0(iVar2,iVar1,*(undefined4 *)(param_1 + 0x30b0));
      FUN_017168b0(iVar1);
    }
  }
  if (param_2 != 0) {
    FUN_0170c6f0(*(int *)(param_1 + 0x30a8) + *(int *)(param_1 + 0x30b0),param_2,param_3);
    *(int *)(param_1 + 0x30b0) = *(int *)(param_1 + 0x30b0) + param_3;
  }
  return 0;
}



/* FUNCTION 4928 ; VA 0x005b1ac0 ; FUN_005b1ac0 */

undefined4
FUN_005b1ac0(int param_1,int param_2,uint *param_3,int param_4,int param_5,undefined4 *param_6)

{
  uint uVar1;
  undefined4 *puVar2;
  uint *puVar3;
  int iVar4;
  uint *puVar5;
  
  *param_6 = 0;
  if ((param_2 != 0) && (uVar1 = *param_3, uVar1 != 0)) {
    for (puVar2 = *(undefined4 **)(param_1 + 0x1fa4 + (uVar1 >> 3 & 0x3ff) * 4);
        puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2) {
      if (((puVar2[3] == param_5) && (puVar5 = (uint *)puVar2[2], puVar5 != (uint *)0x0)) &&
         (*puVar5 == uVar1)) {
        iVar4 = 0;
        puVar3 = param_3;
        if (0 < param_4) {
          do {
            puVar5 = puVar5 + 1;
            if (*puVar5 != puVar3[1]) break;
            iVar4 = iVar4 + 1;
            puVar3 = puVar3 + 1;
          } while (iVar4 < param_4);
        }
        if (iVar4 == param_4) {
          *param_6 = puVar2;
          return puVar2[4];
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 4929 ; VA 0x005b1b60 ; FUN_005b1b60 */

undefined4 FUN_005b1b60(int param_1,char *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  
  if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
    iVar2 = FUN_005bc2c0(param_1,&DAT_018c0cc8,1);
    if (iVar2 != 0) goto LAB_005b1bb4;
    if (param_2 != (char *)0x0) {
      pcVar3 = param_2;
      do {
        cVar1 = *pcVar3;
        pcVar3 = pcVar3 + 1;
      } while (cVar1 != '\0');
      iVar2 = FUN_005bc2c0(param_1,param_2,(int)pcVar3 - (int)(param_2 + 1));
      if (iVar2 != 0) goto LAB_005b1bb4;
    }
    if (param_3 == 0) {
      return 0;
    }
    iVar2 = FUN_005bc2c0(param_1,&DAT_018c35d4,2);
    if ((iVar2 != 0) || (iVar2 = FUN_005bd9a0(param_1,param_3,1), iVar2 != 0)) goto LAB_005b1bb4;
    iVar2 = FUN_005bc2c0(param_1,&DAT_018c35d8,1);
  }
  else {
    iVar2 = FUN_01723e00(param_2,"xmlns:",6);
    if (iVar2 == 0) {
      FUN_005b9d40(param_1,param_2 + 6,param_3,0);
      return 0;
    }
    iVar2 = FUN_005bc430(param_1,param_2,param_3);
  }
  if (iVar2 == 0) {
    return 0;
  }
LAB_005b1bb4:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4930 ; VA 0x005b1c50 ; FUN_005b1c50 */

undefined * FUN_005b1c50(int param_1,char *param_2,undefined *param_3,uint param_4,int *param_5)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined *puVar7;
  uint uStack_8;
  
  if ((param_2 == (char *)0x0) || (*param_2 == '\0')) {
    if (param_5 != (int *)0x0) {
      *param_5 = 0;
    }
    puVar7 = &DAT_018c2414;
    if (*(int *)(param_1 + 0x1615c) != 0) {
      puVar7 = (undefined1 *)0x0;
    }
    return puVar7;
  }
  if (param_3 == (undefined *)0x0) {
    pcVar3 = param_2;
    do {
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    uStack_8 = ((uint)(pcVar3 + (3 - (int)(param_2 + 1))) >> 2) * 3;
    param_3 = (undefined *)FUN_005b7fc0(param_1,uStack_8);
    if (param_3 == (undefined *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return (undefined *)0x0;
    }
  }
  else {
    uStack_8 = param_4;
  }
  pcVar3 = param_2;
  puVar7 = param_3;
  if (param_5 != (int *)0x0) {
    *param_5 = 0;
  }
  do {
    param_2 = (char *)0x0;
    do {
      uVar5 = 0;
      iVar6 = 0;
      do {
        uVar2 = (uint)*pcVar3;
        pcVar3 = pcVar3 + 1;
        if ((uVar2 == 0x3d) || (uVar2 == 0)) {
          iVar4 = (int)param_2 * 3;
          if (iVar6 == 2) {
            iVar4 = iVar4 + 1;
            *puVar7 = (char)(uVar5 >> 4);
          }
          else if (iVar6 == 3) {
            iVar4 = iVar4 + 2;
            *puVar7 = (char)(uVar5 >> 10);
            puVar7[1] = (char)(uVar5 >> 2);
          }
          if (param_5 == (int *)0x0) {
            return param_3;
          }
          *param_5 = *param_5 + iVar4;
          return param_3;
        }
        if (uVar2 - 0x2b < 0x50) {
          if (0x3f < "defghijklmnopqrstuvwxyz0123456789+/"[uVar2]) {
LAB_005b1d79:
            *(undefined4 *)(param_1 + 0x1615c) = 4;
            return (undefined *)0x0;
          }
          uVar5 = uVar5 * 0x40 + (int)"defghijklmnopqrstuvwxyz0123456789+/"[uVar2];
          iVar6 = iVar6 + 1;
        }
        else if (0x20 < uVar2) goto LAB_005b1d79;
      } while (iVar6 < 4);
      *puVar7 = (char)(uVar5 >> 0x10);
      puVar7[1] = (char)(uVar5 >> 8);
      puVar7[2] = (char)uVar5;
      puVar7 = puVar7 + 3;
      if (uStack_8 < 3) {
        if (param_5 == (int *)0x0) {
          return param_3;
        }
        *param_5 = *param_5 + (int)param_2;
        return param_3;
      }
      uStack_8 = uStack_8 - 3;
      param_2 = (char *)((int)param_2 + 1);
    } while ((int)param_2 < 0x100);
    if (param_5 != (int *)0x0) {
      *param_5 = *param_5 + 0x300;
    }
  } while( true );
}



/* FUNCTION 4931 ; VA 0x005b1df0 ; FUN_005b1df0 */

void FUN_005b1df0(int param_1)

{
  if (*(short *)(param_1 + 0x1612c) == 0) {
    *(undefined4 *)(param_1 + 0x3090) = 0;
    *(undefined4 *)(param_1 + 0x308c) = 0;
  }
  *(undefined4 *)(param_1 + 0x15506) = 0x90000;
  *(ushort *)(param_1 + 0x1612c) =
       ((ushort)(*(uint *)(param_1 + 0x10) >> 4) | (ushort)(*(uint *)(param_1 + 0xc) >> 4)) & 1;
  *(undefined4 *)(param_1 + 0x15502) = 0;
  *(undefined2 *)(param_1 + 0x154b6) = 0;
  *(undefined2 *)(param_1 + 0x15500) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x1550a) = 0;
  *(undefined4 *)(param_1 + 0x30a0) = 0;
  *(undefined4 *)(param_1 + 0x30a4) = 0;
  *(undefined2 *)(param_1 + 0x3098) = 0;
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  *(undefined4 *)(param_1 + 0x3094) = 0;
  *(undefined4 *)(param_1 + 0x2fb4) = 0;
  *(undefined4 *)(param_1 + 0x309c) = 0;
  *(undefined *)(param_1 + 0x15518) = 0;
  *(undefined4 *)(param_1 + 0x16174) = 0;
  *(undefined4 *)(param_1 + 0x16178) = 0;
  FUN_005b52e0();
  return;
}



/* FUNCTION 4932 ; VA 0x005b1ea0 ; FUN_005b1ea0 */

undefined4 FUN_005b1ea0(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  
  if (((*(byte *)(param_1 + 8) & 0x80) == 0) &&
     (uVar2 = *(uint *)(param_1 + 0x10), -1 < (char)uVar2)) {
    *(uint *)(param_1 + 8) = uVar2;
    if (((uVar2 & 3) == 2) ||
       (((uVar2 & 0x40) != 0 || (uVar2 & 3) == 3 && (*(int *)(param_1 + 0x3038) == 0)))) {
      uVar2 = uVar2 & 0xfffffff7;
    }
    else {
      uVar2 = uVar2 | 8;
    }
  }
  else {
    uVar2 = *(uint *)(param_1 + 0x10) | 0x88;
  }
  if ((*(int *)(param_1 + 0x28) == 0) && ((uVar2 & 0x10000) == 0)) {
    uVar2 = uVar2 | 0x8000;
  }
  uVar3 = uVar2 | 0x100;
  if ((uVar2 & 0x280) != 0x280) {
    uVar3 = uVar2 & 0xfffffdff;
  }
  *(uint *)(param_1 + 8) = uVar3;
  if ((uVar3 & 0x100) != 0) {
    FUN_005bbe70(param_1);
  }
  *(undefined4 *)(param_1 + 0x16190) = *(undefined4 *)(param_1 + 0x16198);
  *(undefined4 *)(param_1 + 0x30a0) = 0;
  *(undefined4 *)(param_1 + 0x15504) = 0;
  *(undefined2 *)(param_1 + 0x154b6) = 0;
  *(undefined4 *)(param_1 + 0x15500) = 0;
  *(undefined2 *)(param_1 + 0x15508) = 0;
  *(undefined4 *)(param_1 + 0x2fb4) = 0;
  FUN_005b2e60(param_1);
  FUN_005bcec0(param_1);
  *(undefined4 *)(param_1 + 0x1616c) = 0;
  *(undefined4 *)(param_1 + 0x16170) = 0;
  if ((*(code **)(param_1 + 0x3034) != (code *)0x0) &&
     (((byte)*(undefined4 *)(param_1 + 8) & 3) != 2)) {
    uVar1 = (**(code **)(param_1 + 0x3034))(param_1);
    *(undefined4 *)(param_1 + 0x1615c) = uVar1;
    return uVar1;
  }
  return 0;
}



/* FUNCTION 4933 ; VA 0x005b1fc0 ; FUN_005b1fc0 */

int FUN_005b1fc0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  FUN_005b52e0(param_1);
  FUN_005bcec0(param_1);
  *(undefined2 *)(param_1 + 6) = 0;
  FUN_005b5270(param_1);
  uVar2 = *(uint *)(param_1 + 0xc);
  if (((byte)uVar2 & 3) == 3) {
    *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 3;
  }
  *(uint *)(param_1 + 0xc) = uVar2 & 0xfffffffc;
  *(uint *)(param_1 + 8) = uVar2 & 0xfffffffc;
  if (*(short *)(param_1 + 0x1612c) == 0) {
    *(undefined4 *)(param_1 + 0x3090) = 0;
    *(undefined4 *)(param_1 + 0x308c) = 0;
  }
  if ((uVar2 & 0x10) == 0) {
    *(undefined2 *)(param_1 + 0x1612c) = 0;
  }
  *(undefined4 *)(param_1 + 0x3094) = 0;
  *(undefined4 *)(param_1 + 0x1550a) = 0;
  *(undefined4 *)(param_1 + 0x309c) = 0;
  *(undefined2 *)(param_1 + 0x15508) = 0;
  *(undefined4 *)(param_1 + 0x30a0) = 0;
  *(undefined4 *)(param_1 + 0x30a4) = 0;
  *(undefined2 *)(param_1 + 0x3098) = 0;
  *(undefined *)(param_1 + 0x15518) = 0;
  *(undefined4 *)(param_1 + 0x16118) = 0;
  *(undefined4 *)(param_1 + 0x2fac) = 0;
  *(undefined4 *)(param_1 + 0x2fb0) = 0;
  *(undefined4 *)(param_1 + 0x16158) = 0;
  *(undefined4 *)(param_1 + 0x16168) = 0;
  *(undefined4 *)(param_1 + 0x16174) = 0;
  *(undefined4 *)(param_1 + 0x16178) = 0;
  *(undefined4 *)(param_1 + 0x16190) = 0;
  *(undefined4 *)(param_1 + 0x16194) = 0;
  *(undefined4 *)(param_1 + 0x16198) = 0;
  *(undefined4 *)(param_1 + 0x161a4) = 0;
  *(undefined4 *)(param_1 + 0x161a8) = 0;
  *(undefined4 *)(param_1 + 0x161ac) = 0;
  *(undefined4 *)(param_1 + 0x1619c) = 0;
  *(undefined4 *)(param_1 + 0x161a0) = 0;
  *(undefined4 *)(param_1 + 0x161b0) = 0;
  if (*(int *)(param_1 + 0x3078) == -1) {
    FUN_01724f84(*(undefined4 *)(param_1 + 0x3088),0x8000);
  }
  if (*(code **)(param_1 + 0x3034) != (code *)0x0) {
    (**(code **)(param_1 + 0x3034))(param_1);
  }
  uVar2 = FUN_005b5fd0(param_1);
  if ((uVar2 == 0x2d) &&
     (((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090) ||
       (iVar3 = FUN_005bac80(param_1), iVar3 == 0)) &&
      (*(char *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1) == '-')))) {
    *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x100;
  }
  else {
    if ((uVar2 & 0xfffc) == 0xc) {
      if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
         (iVar3 = FUN_005bac80(param_1), iVar3 == 0)) {
        uVar4 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
      }
      else {
        uVar4 = 0xffffffff;
      }
      if ((uVar4 & 0xfff0) != 0x20) goto joined_r0x005b21ec;
      *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x80;
    }
    else {
joined_r0x005b21ec:
      while ((-1 < (int)uVar2 && ((int)uVar2 < 0x21))) {
        uVar2 = *(uint *)(param_1 + 0x3094);
        if (uVar2 == 0) {
          if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
             (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) goto LAB_005b224d;
          uVar2 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else if (uVar2 != 0xffffffff) {
          *(undefined4 *)(param_1 + 0x3094) = 0;
        }
      }
    }
    if (uVar2 == 0xffffffff) {
LAB_005b224d:
      *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
      return -1;
    }
  }
  *(uint *)(param_1 + 0x3094) = uVar2;
  if (((uVar2 != 0x3c) && (uVar2 != 0xef)) && ((*(uint *)(param_1 + 8) & 0x580) == 0)) {
    *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) & 0xfffffffc;
    iVar3 = (**(code **)(param_1 + 0x2fe8))(param_1);
    *(int *)(param_1 + 0x1615c) = iVar3;
    if ((iVar3 != 0) && (iVar3 < 1000)) {
      *(undefined2 *)(param_1 + 0x1612c) = 0;
      return iVar3;
    }
    if (iVar3 == 1000) {
      return 1000;
    }
    if (((byte)*(undefined4 *)(param_1 + 8) & 3) == 3) {
      *(undefined4 *)(param_1 + 0x15514) = *(undefined4 *)(param_1 + 0x3090);
      *(undefined4 *)(param_1 + 0x3090) = *(undefined4 *)(param_1 + 0x308c);
      *(undefined4 *)(param_1 + 0x15510) = 0;
    }
    else if (*(code **)(param_1 + 0x303c) != (code *)0x0) {
      iVar3 = *(int *)(param_1 + 0x308c);
      if (*(int *)(param_1 + 0x3090) != iVar3) {
        (**(code **)(param_1 + 0x303c))
                  (param_1,param_1 + 0x30b4 + iVar3,*(int *)(param_1 + 0x3090) - iVar3);
      }
    }
    if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
       (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
      iVar3 = *(int *)(param_1 + 0x16158);
      if (iVar3 == 200) {
        *(undefined4 *)(param_1 + 0x1615c) = 0xe;
        return 0xe;
      }
      *(int *)(param_1 + 0x1615c) = iVar3;
      return iVar3;
    }
    iVar3 = *(int *)(param_1 + 0x1615c);
    if (iVar3 != 0) {
      if (iVar3 != 0x3e9) {
        return iVar3;
      }
      if (*(code **)(param_1 + 0x2fdc) == (code *)0x0) {
        return 0x3e9;
      }
      iVar3 = (**(code **)(param_1 + 0x2fdc))(param_1);
      *(int *)(param_1 + 0x1615c) = iVar3;
      if (iVar3 != 0) {
        return iVar3;
      }
      *(undefined4 *)(param_1 + 0x1615c) = 1000;
      return 1000;
    }
  }
  if ((*(uint *)(param_1 + 8) & 0x100) != 0) {
    iVar3 = FUN_005b68d0(param_1);
    if (iVar3 != 0) goto LAB_005b2368;
    iVar3 = *(int *)(param_1 + 0x161a0);
    while (((iVar3 != 0 && (iVar3 = *(int *)(*(int *)(param_1 + 0x161ac) + 0xc), iVar3 != 0)) &&
           (iVar3 = FUN_005b8070(param_1,*(undefined4 *)(param_1 + 0x161a0),iVar3), iVar3 != 0))) {
      iVar3 = FUN_005b5940(param_1,0);
    }
    iVar3 = FUN_005b58c0(param_1,*(undefined4 *)(*(int *)(param_1 + 0x161a8) + 0x10),
                         "application/dime");
    if (iVar3 != 0) {
      *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x80;
    }
  }
  if ((*(byte *)(param_1 + 8) & 0x80) != 0) {
    iVar3 = FUN_005b65b0(param_1);
    if (iVar3 != 0) {
LAB_005b2368:
      return *(int *)(param_1 + 0x1615c);
    }
    if ((*(byte *)(param_1 + 0x1617c) & 1) != 0) {
      iVar3 = *(int *)(param_1 + 0x3090);
      iVar1 = *(int *)(param_1 + 0x308c);
      uVar2 = *(uint *)(param_1 + 0x16170);
      *(uint *)(param_1 + 0x16174) = uVar2;
      if ((uint)(iVar3 - iVar1) < uVar2) {
        *(uint *)(param_1 + 0x16174) = (uVar2 - iVar3) + iVar1;
      }
      else {
        *(int *)(param_1 + 0x16178) = iVar3;
        *(uint *)(param_1 + 0x3090) = uVar2 + iVar1;
      }
    }
    *(int *)(param_1 + 0x30a0) = *(int *)(param_1 + 0x3090) - *(int *)(param_1 + 0x308c);
  }
  return 0;
}



/* FUNCTION 4934 ; VA 0x005b2450 ; FUN_005b2450 */

undefined4 FUN_005b2450(int param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  uVar1 = *(uint *)(param_1 + 8) & 0x88 | *(uint *)(param_1 + 0x10);
  if ((*(uint *)(param_1 + 0x10) & 4) != 0) {
    uVar1 = uVar1 | 0x40;
    *(uint *)(param_1 + 8) = uVar1;
    if (0x10000 < *(uint *)(param_1 + 0x30a0)) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x1b;
      return 0x1b;
    }
  }
  if (((uVar1 & 3) == 0) && (*(int *)(param_1 + 0x3078) != -1)) {
    if ((*(int *)(param_1 + 0x30a0) == 0) && ((uVar1 & 0x48) == 0)) {
      uVar1 = uVar1 | 2;
    }
    else {
      uVar1 = uVar1 | 1;
    }
  }
  *(uint *)(param_1 + 8) = uVar1 & 0xfffffff7;
  if (((byte)uVar1 & 3) == 2) {
    puVar2 = (undefined4 *)FUN_0171e1f2(0xc);
    if (puVar2 != (undefined4 *)0x0) {
      *puVar2 = *(undefined4 *)(param_1 + 0x5c);
      puVar2[1] = 0;
      puVar2[2] = 0;
      *(undefined4 **)(param_1 + 0x5c) = puVar2;
    }
  }
  uVar1 = *(uint *)(param_1 + 8);
  if ((uVar1 & 0x10) == 0) {
    *(undefined2 *)(param_1 + 0x1612c) = 0;
  }
  if ((*(int *)(param_1 + 0x28) == 0) && ((uVar1 & 0x10000) == 0)) {
    uVar1 = uVar1 | 0x8000;
  }
  if ((uVar1 & 0x280) == 0x280) {
    uVar1 = uVar1 & 0xffffff7f | 0x100;
  }
  else {
    uVar1 = uVar1 & 0xfffffdff;
  }
  *(uint *)(param_1 + 8) = uVar1;
  if ((uVar1 & 0x100) != 0) {
    FUN_005bbe70(param_1);
  }
  if (*(int *)(param_1 + 0x3078) == -1) {
    FUN_01724f84(*(undefined4 *)(param_1 + 0x3084),0x8000);
  }
  if ((*(byte *)(param_1 + 8) & 3) != 0) {
    *(undefined4 *)(param_1 + 0x308c) = 0;
    *(undefined4 *)(param_1 + 0x3090) = 0;
  }
  *(undefined4 *)(param_1 + 0x15510) = 0;
  *(undefined4 *)(param_1 + 0x15504) = 0;
  *(undefined2 *)(param_1 + 0x154b6) = 0;
  *(undefined4 *)(param_1 + 0x15500) = 0;
  *(undefined4 *)(param_1 + 0x2fb4) = 0;
  *(undefined4 *)(param_1 + 0x309c) = 0;
  FUN_005b2e60(param_1);
  FUN_005bcec0(param_1);
  *(undefined2 *)(param_1 + 0x15508) = 0;
  if ((*(code **)(param_1 + 0x3034) != (code *)0x0) &&
     (((byte)*(undefined4 *)(param_1 + 8) & 3) == 2)) {
    (**(code **)(param_1 + 0x3034))(param_1);
  }
  return 0;
}



/* FUNCTION 4935 ; VA 0x005b25e0 ; FUN_005b25e0 */

undefined4 FUN_005b25e0(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  char *pcVar5;
  bool bVar6;
  undefined auStack_19c [400];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0x10000;
  uStack_8 = 1;
  if (*(int *)(param_1 + 0x3074) != -1) {
    (**(code **)(param_1 + 0x3000))(param_1,*(int *)(param_1 + 0x3074));
    *(undefined4 *)(param_1 + 0x3074) = 0xffffffff;
  }
  bVar6 = DAT_01ea8b8c == 0;
  *(undefined4 *)(param_1 + 0x3078) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x16160) = 1;
  if (bVar6) {
    iVar2 = Ordinal_115(0x101,auStack_19c);
    if (iVar2 != 0) {
      uVar3 = FUN_005be760(param_1);
      pcVar5 = "SOAP-ENV:Receiver";
      if (*(short *)(param_1 + 6) != 2) {
        pcVar5 = "SOAP-ENV:Server";
      }
      puVar4 = (undefined4 *)FUN_005acd30(param_1);
      *puVar4 = pcVar5;
      puVar4 = (undefined4 *)FUN_005ace30(param_1);
      *puVar4 = uVar3;
      puVar4 = (undefined4 *)FUN_005acd60(param_1);
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = "TCP init failed in soap_bind()";
        *(undefined4 *)(param_1 + 0x1615c) = 0x1c;
        return 0xffffffff;
      }
      goto LAB_005b26d7;
    }
    DAT_01ea8b8c = 1;
  }
  iVar2 = Ordinal_23(2,((*(byte *)(param_1 + 0x10) & 4) != 0) + '\x01',0);
  *(int *)(param_1 + 0x3074) = iVar2;
  *(undefined4 *)(param_1 + 0x16160) = 0;
  if (iVar2 == -1) {
    uVar3 = Ordinal_111();
    *(undefined4 *)(param_1 + 0x16164) = uVar3;
    uVar3 = FUN_005be760(param_1);
    pcVar5 = "SOAP-ENV:Receiver";
    if (*(short *)(param_1 + 6) != 2) {
      pcVar5 = "SOAP-ENV:Server";
    }
    puVar4 = (undefined4 *)FUN_005acd30(param_1);
    *puVar4 = pcVar5;
    puVar4 = (undefined4 *)FUN_005ace30(param_1);
    *puVar4 = uVar3;
    puVar4 = (undefined4 *)FUN_005acd60(param_1);
    if (puVar4 != (undefined4 *)0x0) {
      *puVar4 = "socket failed in soap_bind()";
    }
LAB_005b26d7:
    *(undefined4 *)(param_1 + 0x1615c) = 0x1c;
    return 0xffffffff;
  }
  if ((*(byte *)(param_1 + 0x10) & 4) != 0) {
    *(int *)(param_1 + 0x3078) = iVar2;
  }
  if (*(int *)(param_1 + 0x48) == 0) {
LAB_005b2794:
    if (((*(uint *)(param_1 + 0xc) | *(uint *)(param_1 + 0x10)) & 0x10) != 0) {
      iVar2 = Ordinal_21(*(undefined4 *)(param_1 + 0x3074),0xffff,8,&uStack_8,4);
      if (iVar2 != 0) {
        uVar3 = Ordinal_111();
        pcVar5 = "setsockopt SO_KEEPALIVE failed in soap_bind()";
        goto LAB_005b2771;
      }
    }
    iVar2 = Ordinal_21(*(undefined4 *)(param_1 + 0x3074),0xffff,0x1001,&uStack_c,4);
    if (iVar2 == 0) {
      iVar2 = Ordinal_21(*(undefined4 *)(param_1 + 0x3074),0xffff,0x1002,&uStack_c,4);
      if (iVar2 == 0) {
        if ((*(byte *)(param_1 + 0x10) & 4) == 0) {
          iVar2 = Ordinal_21(*(undefined4 *)(param_1 + 0x3074),6,1,&uStack_8,4);
          if (iVar2 != 0) {
            uVar3 = Ordinal_111();
            pcVar5 = "setsockopt TCP_NODELAY failed in soap_bind()";
            goto LAB_005b2771;
          }
        }
        puVar4 = (undefined4 *)(param_1 + 0x171e4);
        *(undefined4 *)(param_1 + 0x171f4) = 0x10;
        *puVar4 = 0;
        *(undefined4 *)(param_1 + 0x171e8) = 0;
        *(undefined4 *)(param_1 + 0x171ec) = 0;
        *(undefined4 *)(param_1 + 0x171f0) = 0;
        *(undefined2 *)puVar4 = 2;
        *(undefined4 *)(param_1 + 0x16160) = 2;
        if (param_2 == 0) {
          uVar3 = Ordinal_8(0);
          *(undefined4 *)(param_1 + 0x171e8) = uVar3;
        }
        else {
          iVar2 = (**(code **)(param_1 + 0x2ff4))(param_1,param_2,(undefined4 *)(param_1 + 0x171e8))
          ;
          if (iVar2 != 0) {
            pcVar5 = "get host by name failed in soap_bind()";
            goto LAB_005b2777;
          }
        }
        uVar1 = Ordinal_9(param_3);
        *(undefined2 *)(param_1 + 0x171e6) = uVar1;
        *(undefined4 *)(param_1 + 0x16160) = 0;
        iVar2 = Ordinal_2(*(undefined4 *)(param_1 + 0x3074),puVar4,
                          *(undefined4 *)(param_1 + 0x171f4));
        if (iVar2 == 0) {
          if ((*(byte *)(param_1 + 0x10) & 4) == 0) {
            iVar2 = Ordinal_13(*(undefined4 *)(param_1 + 0x3074),param_4);
            if (iVar2 != 0) {
              uVar3 = Ordinal_111();
              *(undefined4 *)(param_1 + 0x16164) = uVar3;
              FUN_005b2e00(param_1);
              pcVar5 = "listen failed in soap_bind()";
              goto LAB_005b2777;
            }
          }
          return *(undefined4 *)(param_1 + 0x3074);
        }
        uVar3 = Ordinal_111();
        *(undefined4 *)(param_1 + 0x16164) = uVar3;
        FUN_005b2e00(param_1);
        pcVar5 = "bind failed in soap_bind()";
        goto LAB_005b2777;
      }
      uVar3 = Ordinal_111();
      pcVar5 = "setsockopt SO_RCVBUF failed in soap_bind()";
    }
    else {
      uVar3 = Ordinal_111();
      pcVar5 = "setsockopt SO_SNDBUF failed in soap_bind()";
    }
  }
  else {
    iVar2 = Ordinal_21(iVar2,0xffff,*(int *)(param_1 + 0x48),&uStack_8,4);
    if (iVar2 == 0) goto LAB_005b2794;
    uVar3 = Ordinal_111();
    pcVar5 = "setsockopt failed in soap_bind()";
  }
LAB_005b2771:
  *(undefined4 *)(param_1 + 0x16164) = uVar3;
LAB_005b2777:
  uVar3 = FUN_005be760(param_1,pcVar5,0x1c);
  FUN_005bcf60(param_1,uVar3);
  return 0xffffffff;
}



/* FUNCTION 4936 ; VA 0x005b2950 ; FUN_005b2950 */

undefined4 FUN_005b2950(int param_1)

{
  int iVar1;
  
  *(undefined2 *)(param_1 + 0x15508) = 6;
  iVar1 = FUN_005b8900(param_1);
  if (iVar1 == 0) {
    if (*(short *)(param_1 + 0x154b4) != 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      goto LAB_005b2983;
    }
    iVar1 = FUN_005b8220(param_1,param_1 + 0x138b4,"SOAP-ENV:Body");
    *(int *)(param_1 + 0x1615c) = iVar1;
    if (iVar1 != 0) goto LAB_005b2983;
    *(undefined2 *)(param_1 + 0x1550c) = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) && ((*(uint *)(param_1 + 8) & 0x1000) != 0)) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x17;
      return *(undefined4 *)(param_1 + 0x1615c);
    }
    iVar1 = 0;
    if (*(short *)(param_1 + 0x309a) != 0) {
      *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + 1;
    }
  }
  else {
    iVar1 = *(int *)(param_1 + 0x1615c);
    if (iVar1 == 6) goto LAB_005b2983;
  }
  if (iVar1 == 0) {
    if (*(short *)(param_1 + 0x309a) == 0) {
      *(undefined2 *)(param_1 + 0x15508) = 5;
    }
    return 0;
  }
LAB_005b2983:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4937 ; VA 0x005b2a20 ; FUN_005b2a20 */

undefined4 FUN_005b2a20(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  *(undefined2 *)(param_1 + 0x15508) = 6;
  if (*(short *)(param_1 + 6) == 1) {
    *(undefined2 *)(param_1 + 0x15500) = 1;
  }
  if ((*(uint *)(param_1 + 8) & 0x80000) != 0) {
    iVar1 = FUN_005bc430(param_1,&DAT_018c363c,&DAT_018c3bf4);
    if (iVar1 != 0) goto LAB_005b2a66;
  }
  iVar1 = FUN_005b37c0(param_1,"SOAP-ENV:Body",0,0);
  if (iVar1 == 0) {
    uVar2 = FUN_005b4210(param_1,0);
    return uVar2;
  }
LAB_005b2a66:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4938 ; VA 0x005b2aa0 ; FUN_005b2aa0 */

undefined4 FUN_005b2aa0(int param_1)

{
  undefined4 uVar1;
  
  if (*(short *)(param_1 + 0x15508) == 5) {
    return 0;
  }
  *(undefined2 *)(param_1 + 0x15508) = 7;
  uVar1 = FUN_005b3cc0(param_1,"SOAP-ENV:Body");
  return uVar1;
}



/* FUNCTION 4939 ; VA 0x005b2ad0 ; FUN_005b2ad0 */

undefined4 FUN_005b2ad0(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_005b3e10(param_1,"SOAP-ENV:Body");
  if (iVar1 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  *(undefined2 *)(param_1 + 0x15508) = 7;
  return 0;
}



/* FUNCTION 4940 ; VA 0x005b2b10 ; FUN_005b2b10 */

undefined4 FUN_005b2b10(int param_1)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  byte *pbVar5;
  int iVar6;
  byte *pbVar7;
  bool bVar8;
  byte abStack_c [8];
  
  iVar6 = 0;
  pbVar7 = abStack_c;
  uVar3 = *(uint *)(param_1 + 0x308c);
  do {
    if (*(uint *)(param_1 + 0x3090) <= uVar3) {
      iVar2 = FUN_005bac80(param_1);
      if (iVar2 != 0) break;
    }
    bVar1 = *(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    uVar3 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar3;
    if (bVar1 == 0x3b) break;
    *pbVar7 = bVar1;
    iVar6 = iVar6 + 1;
    pbVar7 = pbVar7 + 1;
  } while (iVar6 < 7);
  *pbVar7 = 0;
  if (abStack_c[0] == 0x23) {
    if ((abStack_c[1] != 'x') && (abStack_c[1] != 'X')) {
      uVar4 = FUN_01717832(abStack_c + 1);
      return uVar4;
    }
    uVar4 = FUN_0171d785(abStack_c + 2,0,0x10);
    return uVar4;
  }
  pbVar5 = &DAT_018c2f3c;
  pbVar7 = abStack_c;
  do {
    bVar1 = *pbVar7;
    bVar8 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b2bc1:
      uVar3 = -(uint)bVar8 | 1;
      goto LAB_005b2bc6;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar7[1];
    bVar8 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b2bc1;
    pbVar7 = pbVar7 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_005b2bc6:
  if (uVar3 == 0) {
    return 0x3c;
  }
  pbVar5 = &DAT_018c2f40;
  pbVar7 = abStack_c;
  do {
    bVar1 = *pbVar7;
    bVar8 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b2c00:
      uVar3 = -(uint)bVar8 | 1;
      goto LAB_005b2c05;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar7[1];
    bVar8 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b2c00;
    pbVar7 = pbVar7 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_005b2c05:
  if (uVar3 == 0) {
    return 0x3e;
  }
  pbVar5 = &DAT_018c2f44;
  pbVar7 = abStack_c;
  do {
    bVar1 = *pbVar7;
    bVar8 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b2c40:
      uVar3 = -(uint)bVar8 | 1;
      goto LAB_005b2c45;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar7[1];
    bVar8 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b2c40;
    pbVar7 = pbVar7 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_005b2c45:
  if (uVar3 == 0) {
    return 0x26;
  }
  pbVar5 = &DAT_018c2f48;
  pbVar7 = abStack_c;
  do {
    bVar1 = *pbVar7;
    bVar8 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b2c80:
      uVar3 = -(uint)bVar8 | 1;
      goto LAB_005b2c85;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar7[1];
    bVar8 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b2c80;
    pbVar7 = pbVar7 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_005b2c85:
  if (uVar3 == 0) {
    return 0x22;
  }
  pbVar5 = &DAT_018c2f50;
  pbVar7 = abStack_c;
  do {
    bVar1 = *pbVar7;
    bVar8 = bVar1 < *pbVar5;
    if (bVar1 != *pbVar5) {
LAB_005b2cc0:
      uVar3 = -(uint)bVar8 | 1;
      goto LAB_005b2cc5;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar7[1];
    bVar8 = bVar1 < pbVar5[1];
    if (bVar1 != pbVar5[1]) goto LAB_005b2cc0;
    pbVar7 = pbVar7 + 2;
    pbVar5 = pbVar5 + 2;
  } while (bVar1 != 0);
  uVar3 = 0;
LAB_005b2cc5:
  if (uVar3 == 0) {
    return 0x27;
  }
  uVar4 = FUN_005b2f40(&DAT_018c24a0,abStack_c,0x7f);
  return uVar4;
}



/* FUNCTION 4941 ; VA 0x005b2cf0 ; FUN_005b2cf0 */

void FUN_005b2cf0(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  
  if ((((*(short *)(param_1 + 6) == 2) && (*(int *)(param_1 + 0x28) != 0)) &&
      (iVar2 = FUN_005b3b70(param_1,":result",1,0), iVar2 == 0)) &&
     (piVar3 = (int *)FUN_005b7fc0(param_1,4), piVar3 != (int *)0x0)) {
    if (*(short *)(param_1 + 0x309a) == 0) {
      if (*(short *)(param_1 + 0x15504) == 0) {
        iVar2 = FUN_005b7fc0(param_1,1);
        if (iVar2 != 0) {
          pcVar4 = "";
          do {
            cVar1 = *pcVar4;
            pcVar4 = pcVar4 + 1;
            pcVar4[iVar2 + -0x18c2415] = cVar1;
          } while (cVar1 != '\0');
        }
        *piVar3 = iVar2;
      }
      else {
        *piVar3 = 0;
      }
    }
    else {
      iVar2 = FUN_005bd410(param_1,2,0xffffffff,0xffffffff);
      *piVar3 = iVar2;
      if (iVar2 == 0) {
        return;
      }
      iVar2 = FUN_005b6e40(param_1,param_1 + 0x13cb4,iVar2,0,4,0,0,0,0);
      if (iVar2 == 0) {
        return;
      }
    }
    if (*(char *)(param_1 + 0x140b4) != '\0') {
      FUN_005b70d0(param_1,param_1 + 0x140b4,piVar3,0,4,0);
    }
    if (*(short *)(param_1 + 0x309a) != 0) {
      FUN_005b3cc0(param_1,":result");
    }
  }
  return;
}



/* FUNCTION 4942 ; VA 0x005b2e00 ; FUN_005b2e00 */

int FUN_005b2e00(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0x1615c);
  if ((((iVar1 == -1) || (iVar1 == 0x1c)) || (iVar1 == 0x1e)) ||
     (*(short *)(param_1 + 0x1612c) == 0)) {
    if (*(code **)(param_1 + 0x3010) != (code *)0x0) {
      iVar2 = (**(code **)(param_1 + 0x3010))(param_1);
      *(int *)(param_1 + 0x1615c) = iVar2;
      if (iVar2 != 0) {
        return iVar2;
      }
    }
    *(undefined2 *)(param_1 + 0x1612c) = 0;
  }
  *(int *)(param_1 + 0x1615c) = iVar1;
  return iVar1;
}



/* FUNCTION 4943 ; VA 0x005b2e60 ; FUN_005b2e60 */

void FUN_005b2e60(int param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar2 = *(int **)(param_1 + 0x154fc);
  if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
    for (; piVar2 != (int *)0x0; piVar2 = (int *)*piVar2) {
      *(undefined2 *)(piVar2 + 4) = 0;
    }
  }
  else if (piVar2 != (int *)0x0) {
    do {
      piVar1 = (int *)*piVar2;
      if (piVar2[1] != 0) {
        FUN_017168b0(piVar2[1]);
        piVar2 = *(int **)(param_1 + 0x154fc);
      }
      FUN_017168b0(piVar2);
      *(int **)(param_1 + 0x154fc) = piVar1;
      piVar2 = piVar1;
    } while (piVar1 != (int *)0x0);
    return;
  }
  return;
}



/* FUNCTION 4944 ; VA 0x005b2ed0 ; FUN_005b2ed0 */

int FUN_005b2ed0(int param_1,byte *param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  byte *pbVar3;
  uint uVar4;
  byte *pbVar5;
  bool bVar6;
  
  if ((param_1 != 0) && (param_2 != (byte *)0x0)) {
    pbVar3 = *(byte **)(param_1 + 4);
    while (pbVar5 = param_2, pbVar3 != (byte *)0x0) {
      do {
        bVar2 = *pbVar5;
        bVar6 = bVar2 < *pbVar3;
        if (bVar2 != *pbVar3) {
LAB_005b2f12:
          uVar4 = -(uint)bVar6 | 1;
          goto LAB_005b2f17;
        }
        if (bVar2 == 0) break;
        bVar2 = pbVar5[1];
        bVar6 = bVar2 < pbVar3[1];
        if (bVar2 != pbVar3[1]) goto LAB_005b2f12;
        pbVar3 = pbVar3 + 2;
        pbVar5 = pbVar5 + 2;
      } while (bVar2 != 0);
      uVar4 = 0;
LAB_005b2f17:
      if (uVar4 == 0) {
        return param_1;
      }
      puVar1 = (undefined4 *)(param_1 + 0xc);
      param_1 = param_1 + 8;
      pbVar3 = (byte *)*puVar1;
    }
  }
  return 0;
}



/* FUNCTION 4945 ; VA 0x005b2f40 ; FUN_005b2f40 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_005b2f40(undefined4 *param_1,char *param_2,undefined4 param_3)

{
  char *pcVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  
  if ((param_1 != (undefined4 *)0x0) && (pcVar8 = (char *)param_1[1], pcVar8 != (char *)0x0)) {
    cVar2 = *param_2;
    pcVar7 = param_2;
    cVar3 = cVar2;
joined_r0x005b2f6e:
    do {
      iVar5 = (int)cVar3;
      pcVar9 = pcVar8;
      if (iVar5 == 0) {
LAB_005b300d:
        if (((*pcVar9 == '*') && (pcVar9[1] == '\0')) || (*pcVar9 == '\0')) {
LAB_005b3038:
          return *param_1;
        }
      }
      else {
        iVar4 = (int)*pcVar8;
        if (iVar5 == 0x22) goto LAB_005b300d;
        if ((*pcVar8 == '-') || (iVar5 == iVar4)) {
LAB_005b2fa9:
          pcVar9 = pcVar7 + 1;
          pcVar8 = pcVar8 + 1;
          pcVar7 = pcVar7 + 1;
          cVar3 = *pcVar9;
          goto joined_r0x005b2f6e;
        }
        iVar6 = iVar4 + 0x20;
        if (0x19 < iVar4 - 0x41U) {
          iVar6 = iVar4;
        }
        iVar4 = iVar5 + 0x20;
        if (0x19 < iVar5 - 0x41U) {
          iVar4 = iVar5;
        }
        if (iVar4 == iVar6) goto LAB_005b2fa9;
        if (iVar6 == 0x2a) {
          pcVar9 = pcVar8 + 1;
          iVar5 = (int)pcVar8[1];
          if (pcVar8[1] == '\0') goto LAB_005b3038;
          cVar3 = *pcVar7;
          iVar4 = iVar5 + 0x20;
          if (0x19 < iVar5 - 0x41U) {
            iVar4 = iVar5;
          }
          while ((iVar5 = (int)cVar3, iVar5 != 0 && (iVar5 != 0x22))) {
            iVar6 = iVar5 + 0x20;
            if (0x19 < iVar5 - 0x41U) {
              iVar6 = iVar5;
            }
            if ((iVar6 == iVar4) && (iVar5 = FUN_005bdc80(pcVar7 + 1,pcVar8 + 2), iVar5 == 0))
            goto LAB_005b3038;
            pcVar1 = pcVar7 + 1;
            pcVar7 = pcVar7 + 1;
            cVar3 = *pcVar1;
          }
          goto LAB_005b300d;
        }
      }
      pcVar8 = (char *)param_1[3];
      pcVar7 = param_2;
      cVar3 = cVar2;
      param_1 = param_1 + 2;
    } while (pcVar8 != (char *)0x0);
  }
  return param_3;
}



/* FUNCTION 4946 ; VA 0x005b3050 ; FUN_005b3050 */

int * FUN_005b3050(int *param_1,int param_2)

{
  int iVar1;
  
  if (param_1 != (int *)0x0) {
    iVar1 = *param_1;
    while ((iVar1 != param_2 && (param_1[1] != 0))) {
      param_1 = param_1 + 2;
      iVar1 = *param_1;
    }
    return (int *)param_1[1];
  }
  return param_1;
}



/* FUNCTION 4947 ; VA 0x005b3080 ; FUN_005b3080 */

int FUN_005b3080(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  
  if ((param_2 == 0) || ((*(short *)(param_2 + 4) != 1 && (*(short *)(param_2 + 4) != 2)))) {
    return 0;
  }
  if (param_1 != 0) {
    FUN_0170c6f0(param_1,param_2,0x17658);
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    *(undefined2 *)(param_1 + 4) = 2;
    *(undefined4 *)(param_1 + 0x2fc0) = 0;
    *(undefined4 *)(param_1 + 0x2fc4) = 0;
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
    *(undefined4 *)(param_1 + 0x60) = 0;
    *(undefined4 *)(param_1 + 100) = 0;
    *(undefined4 *)(param_1 + 0x154fc) = 0;
    *(undefined4 *)(param_1 + 0x30a8) = 0;
    *(undefined4 *)(param_1 + 0x30ac) = 0;
    *(undefined4 *)(param_1 + 0x30b0) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
    puVar6 = (undefined4 *)(param_1 + 0x68);
    for (iVar5 = 1999; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar6 = 0;
      puVar6 = puVar6 + 1;
    }
    *(undefined4 *)(param_1 + 0x2fa4) = 0;
    *(undefined2 *)(param_1 + 0x2fa8) = 0;
    puVar6 = (undefined4 *)(param_1 + 0x1fa4);
    for (iVar5 = 0x400; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar6 = 0;
      puVar6 = puVar6 + 1;
    }
    *(undefined4 *)(param_1 + 0x2fac) = 0;
    *(undefined4 *)(param_1 + 0x2fb0) = 0;
    *(undefined4 *)(param_1 + 0x16118) = 0;
    *(undefined4 *)(param_1 + 0x171d4) = 0;
    *(undefined4 *)(param_1 + 0x2fbc) = 0;
    for (puVar6 = *(undefined4 **)(param_2 + 0x2fbc); puVar6 != (undefined4 *)0x0;
        puVar6 = (undefined4 *)*puVar6) {
      puVar4 = (undefined4 *)FUN_0171e1f2(0x14);
      if (puVar4 == (undefined4 *)0x0) {
        return 0;
      }
      uVar1 = puVar6[1];
      uVar2 = puVar6[2];
      uVar3 = puVar6[3];
      *puVar4 = *puVar6;
      puVar4[1] = uVar1;
      puVar4[2] = uVar2;
      puVar4[3] = uVar3;
      puVar4[4] = puVar6[4];
      if (((code *)puVar6[3] != (code *)0x0) &&
         (iVar5 = (*(code *)puVar6[3])(param_1,puVar4,puVar6), iVar5 != 0)) {
        FUN_017168b0(puVar4);
        return 0;
      }
      *puVar4 = *(undefined4 *)(param_1 + 0x2fbc);
      *(undefined4 **)(param_1 + 0x2fbc) = puVar4;
    }
  }
  return param_1;
}



/* FUNCTION 4948 ; VA 0x005b31e0 ; FUN_005b31e0 */

void FUN_005b31e0(int param_1,undefined4 param_2,int param_3,int param_4,int param_5)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uStack_8;
  
  iVar3 = 0;
  pcVar4 = (char *)0x0;
  uStack_8 = 0;
  if (param_3 != 0) {
    iVar3 = FUN_005bd1b0(param_1,param_3);
  }
  if (param_4 != 0) {
    uStack_8 = FUN_005bd1b0(param_1,param_4);
  }
  if (param_5 != 0) {
    pcVar4 = (char *)FUN_005bd1b0(param_1,param_5);
  }
  puVar1 = (undefined4 *)FUN_005acd30(param_1);
  *puVar1 = param_2;
  if (iVar3 != 0) {
    piVar2 = (int *)FUN_005ace60(param_1);
    *piVar2 = iVar3;
  }
  puVar1 = (undefined4 *)FUN_005ace30(param_1);
  *puVar1 = uStack_8;
  if ((pcVar4 != (char *)0x0) && (*pcVar4 != '\0')) {
    puVar1 = (undefined4 *)FUN_005acd60(param_1);
    if (puVar1 != (undefined4 *)0x0) {
      *puVar1 = pcVar4;
    }
  }
  *(undefined4 *)(param_1 + 0x1615c) = 0xc;
  return;
}



/* FUNCTION 4949 ; VA 0x005b3280 ; FUN_005b3280 */

char * FUN_005b3280(int param_1)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  int *piVar10;
  
  pcVar9 = *(char **)(param_1 + 0x30a0);
  if ((*(uint *)(param_1 + 8) & 0x280) == 0x80) {
    for (puVar4 = *(undefined4 **)(param_1 + 0x16194); puVar4 != (undefined4 *)0x0;
        puVar4 = (undefined4 *)*puVar4) {
      pcVar7 = (char *)puVar4[3];
      pcVar9 = pcVar9 + (puVar4[2] + 3 & 0xfffffffc) + 0xc;
      if (pcVar7 != (char *)0x0) {
        pcVar1 = pcVar7 + 1;
        do {
          cVar3 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar9 + ((uint)(pcVar7 + (3 - (int)pcVar1)) & 0xfffffffc);
      }
      pcVar7 = (char *)puVar4[4];
      if (pcVar7 != (char *)0x0) {
        pcVar1 = pcVar7 + 1;
        do {
          cVar3 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar9 + ((uint)(pcVar7 + (3 - (int)pcVar1)) & 0xfffffffc);
      }
      iVar5 = puVar4[5];
      if (iVar5 != 0) {
        pcVar9 = pcVar9 + (CONCAT11(*(undefined *)(iVar5 + 2),*(undefined *)(iVar5 + 3)) + 7 &
                          0xfffffffc);
      }
    }
  }
  if (((*(uint *)(param_1 + 8) & 0x100) == 0) ||
     (pcVar7 = *(char **)(param_1 + 0x1619c), pcVar7 == (char *)0x0)) {
    return pcVar9;
  }
  pcVar1 = pcVar7 + 1;
  do {
    cVar3 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar3 != '\0');
  piVar10 = *(int **)(param_1 + 0x161a8);
  if (piVar10 != (int *)0x0) {
    do {
      pcVar8 = (char *)piVar10[4];
      pcVar9 = pcVar7 + (int)(pcVar9 + (6 - (int)pcVar1));
      if (pcVar8 != (char *)0x0) {
        pcVar2 = pcVar8 + 1;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar8 + (int)(pcVar9 + (0x10 - (int)pcVar2));
      }
      piVar6 = (int *)&DAT_018c28e0;
      if (piVar10[6] != 1) {
        do {
          if (piVar6[1] == 0) break;
          piVar6 = piVar6 + 2;
        } while (*piVar6 != piVar10[6]);
      }
      pcVar8 = (char *)piVar6[1];
      if (pcVar8 != (char *)0x0) {
        pcVar2 = pcVar8 + 1;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar8 + (int)(pcVar9 + (0x1d - (int)pcVar2));
      }
      pcVar8 = (char *)piVar10[3];
      if (pcVar8 != (char *)0x0) {
        pcVar2 = pcVar8 + 1;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar8 + (int)(pcVar9 + (0xe - (int)pcVar2));
      }
      pcVar8 = (char *)piVar10[7];
      if (pcVar8 != (char *)0x0) {
        pcVar2 = pcVar8 + 1;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar8 + (int)(pcVar9 + (0x14 - (int)pcVar2));
      }
      pcVar8 = (char *)piVar10[8];
      if (pcVar8 != (char *)0x0) {
        pcVar2 = pcVar8 + 1;
        do {
          cVar3 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar3 != '\0');
        pcVar9 = pcVar8 + (int)(pcVar9 + (0x17 - (int)pcVar2));
      }
      pcVar9 = pcVar9 + piVar10[2] + 2;
      piVar10 = (int *)*piVar10;
    } while (piVar10 != (int *)0x0);
  }
  return pcVar7 + (int)(pcVar9 + (6 - (int)pcVar1));
}



/* FUNCTION 4950 ; VA 0x005b3420 ; FUN_005b3420 */

byte * FUN_005b3420(byte *param_1,int param_2,byte *param_3,undefined4 param_4)

{
  int iVar1;
  byte bVar2;
  byte *pbVar3;
  
  bVar2 = *param_3;
  while ((bVar2 != 0 &&
         (((bVar2 == 0x20 || (bVar2 == 9)) ||
          (iVar1 = FUN_0170dbd0(param_4,(int)(char)bVar2), iVar1 != 0))))) {
    bVar2 = param_3[1];
    param_3 = param_3 + 1;
  }
  bVar2 = *param_3;
  if (bVar2 == 0x22) {
    bVar2 = param_3[1];
    param_3 = param_3 + 1;
    while (((bVar2 != 0 && (bVar2 != 0x22)) && (param_2 = param_2 + -1, param_2 != 0))) {
      param_3 = param_3 + 1;
      *param_1 = bVar2;
      param_1 = param_1 + 1;
      bVar2 = *param_3;
    }
  }
  else {
    while ((((bVar2 != 0 && (((char)bVar2 < '\0' || (' ' < (char)bVar2)))) &&
            (iVar1 = FUN_0170dbd0(param_4,(int)(char)bVar2), iVar1 == 0)) &&
           (param_2 = param_2 + -1, param_2 != 0))) {
      bVar2 = *param_3;
      pbVar3 = param_3 + 1;
      if (bVar2 == 0x25) {
        bVar2 = *pbVar3;
        if ('@' < (char)bVar2) {
          bVar2 = (bVar2 & 7) + 9;
        }
        if ((char)param_3[2] < 'A') {
          pbVar3 = param_3 + 3;
          bVar2 = bVar2 * '\x10' + (param_3[2] - 0x30);
        }
        else {
          pbVar3 = param_3 + 3;
          bVar2 = bVar2 * '\x10' + (param_3[2] & 7) + 9;
        }
      }
      *param_1 = bVar2;
      bVar2 = *pbVar3;
      param_1 = param_1 + 1;
      param_3 = pbVar3;
    }
  }
  *param_1 = 0;
  bVar2 = *param_3;
  while ((bVar2 != 0 && (iVar1 = FUN_0170dbd0(param_4,(int)(char)bVar2), iVar1 == 0))) {
    bVar2 = param_3[1];
    param_3 = param_3 + 1;
  }
  return param_3;
}



/* FUNCTION 4951 ; VA 0x005b3540 ; FUN_005b3540 */

void FUN_005b3540(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  if ((param_1 != 0) && ((*(short *)(param_1 + 4) == 1 || (*(short *)(param_1 + 4) == 2)))) {
    piVar3 = (int *)(param_1 + 0x60);
    if (*(int **)(param_1 + 0x60) != (int *)0x0) {
      piVar1 = *(int **)(param_1 + 0x60);
      if (param_2 == 0) {
        do {
          piVar1 = (int *)*piVar3;
          *piVar3 = *piVar1;
          (*(code *)piVar1[4])(piVar1);
          FUN_017168b0(piVar1);
        } while (*piVar3 != 0);
      }
      else {
        do {
          piVar2 = piVar1;
          piVar1 = (int *)*piVar2;
          if (param_2 == piVar2[1]) {
            *piVar3 = (int)piVar1;
            (*(code *)piVar2[4])(piVar2);
            FUN_017168b0(piVar2);
            return;
          }
          piVar3 = piVar2;
        } while (piVar1 != (int *)0x0);
      }
    }
    *(undefined4 *)(param_1 + 0x2fb0) = 0;
    *(undefined4 *)(param_1 + 0x2fac) = 0;
  }
  return;
}



/* FUNCTION 4952 ; VA 0x005b35d0 ; FUN_005b35d0 */

void FUN_005b35d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if ((param_1 != 0) && ((*(short *)(param_1 + 4) == 1 || (*(short *)(param_1 + 4) == 2)))) {
    FUN_005b52e0(param_1);
    iVar2 = *(int *)(param_1 + 0x60);
    while (iVar2 != 0) {
      iVar2 = **(int **)(param_1 + 0x60);
      FUN_017168b0(*(int **)(param_1 + 0x60));
      *(int *)(param_1 + 0x60) = iVar2;
    }
    *(undefined2 *)(param_1 + 0x1612c) = 0;
    FUN_005b2e00(param_1);
    puVar3 = *(undefined4 **)(param_1 + 0x2fbc);
    while (puVar3 != (undefined4 *)0x0) {
      puVar1 = (undefined4 *)*puVar3;
      if ((puVar3[3] != 0) || (*(short *)(param_1 + 4) == 1)) {
        (*(code *)puVar3[4])(param_1,puVar3);
        puVar3 = *(undefined4 **)(param_1 + 0x2fbc);
      }
      FUN_017168b0(puVar3);
      *(undefined4 **)(param_1 + 0x2fbc) = puVar1;
      puVar3 = puVar1;
    }
    *(code **)(param_1 + 0x302c) = FUN_005af8f0;
    *(undefined4 *)(param_1 + 0x3030) = 0;
    *(code **)(param_1 + 0x2fc8) = FUN_005b0930;
    *(code **)(param_1 + 0x2fcc) = FUN_005acb60;
    *(code **)(param_1 + 0x2fd0) = FUN_005acb30;
    *(code **)(param_1 + 0x2fd4) = FUN_005acb40;
    *(code **)(param_1 + 0x2fd8) = FUN_005acb10;
    *(undefined4 *)(param_1 + 0x2fdc) = 0;
    *(code **)(param_1 + 0x2fe0) = FUN_005b0cb0;
    *(code **)(param_1 + 0x2fe4) = FUN_005b0d20;
    *(code **)(param_1 + 0x2fe8) = FUN_005aff50;
    *(code **)(param_1 + 0x2fec) = FUN_005b0490;
    *(undefined4 *)(param_1 + 0x2ff0) = 0;
    *(code **)(param_1 + 0x2ff4) = FUN_005be7e0;
    *(code **)(param_1 + 0x300c) = FUN_005bdf00;
    *(code **)(param_1 + 0x3008) = FUN_005bdf30;
    *(code **)(param_1 + 0x3010) = FUN_005be710;
    *(code **)(param_1 + 0x3000) = FUN_005bdf20;
    *(code **)(param_1 + 0x3004) = FUN_005be840;
    *(code **)(param_1 + 0x3014) = FUN_005afc00;
    *(code **)(param_1 + 0x3018) = FUN_005af980;
    *(code **)(param_1 + 0x301c) = FUN_005b9850;
    *(undefined4 *)(param_1 + 0x3034) = 0;
    *(undefined4 *)(param_1 + 0x3038) = 0;
    *(undefined4 *)(param_1 + 0x303c) = 0;
    *(undefined4 *)(param_1 + 0x3040) = 0;
    *(undefined4 *)(param_1 + 0x3020) = 0;
    *(undefined4 *)(param_1 + 0x3024) = 0;
    *(undefined4 *)(param_1 + 0x3028) = 0;
    if ((*(short *)(param_1 + 4) == 1) && (*(int *)(param_1 + 0x3074) != -1)) {
      FUN_005bdf20(param_1,*(int *)(param_1 + 0x3074));
      *(undefined4 *)(param_1 + 0x3074) = 0xffffffff;
    }
  }
  return;
}



/* FUNCTION 4953 ; VA 0x005b37c0 ; FUN_005b37c0 */

undefined4 FUN_005b37c0(int param_1,char *param_2,int param_3,char *param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined1 *puVar5;
  uint uVar6;
  char *pcVar7;
  char *pcVar8;
  undefined4 *puVar9;
  undefined2 *puVar10;
  
  iVar2 = param_1;
  uVar6 = *(int *)(param_1 + 0x309c) + 1;
  *(uint *)(param_1 + 0x309c) = uVar6;
  if (*(short *)(param_1 + 0x15506) == 0) {
    if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
      pcVar8 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
      if (*(char **)(param_1 + 0x16120) != (char *)0x0) {
        pcVar8 = *(char **)(param_1 + 0x16120);
      }
      pcVar7 = pcVar8;
      do {
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      iVar3 = FUN_005bc2c0(param_1,pcVar8,(int)pcVar7 - (int)(pcVar8 + 1));
      if (iVar3 != 0) goto LAB_005b381e;
    }
  }
  else if ((*(uint *)(param_1 + 8) & 0x2000) != 0) {
    if (*(short *)(param_1 + 0x15506) == 1) {
      uVar4 = 10;
      if (uVar6 < 0xb) {
        uVar4 = uVar6;
      }
      iVar3 = FUN_005bc2c0(param_1,"\n\t\t\t\t\t\t\t\t\t",uVar4);
      if (iVar3 != 0) goto LAB_005b381e;
    }
    *(undefined2 *)(param_1 + 0x309a) = 1;
  }
  iVar3 = FUN_005bc2c0(param_1,&DAT_018c3500,1);
  if (iVar3 == 0) {
    if (param_2 != (char *)0x0) {
      pcVar8 = param_2;
      do {
        cVar1 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar1 != '\0');
      iVar3 = FUN_005bc2c0(param_1,param_2,(int)pcVar8 - (int)(param_2 + 1));
      if (iVar3 != 0) goto LAB_005b381e;
    }
    if (*(short *)(param_1 + 0x15506) == 0) {
      for (puVar9 = *(undefined4 **)(param_1 + 0x54);
          (puVar9 != (undefined4 *)0x0 && (pcVar8 = (char *)*puVar9, pcVar8 != (char *)0x0));
          puVar9 = puVar9 + 4) {
        if ((*pcVar8 != '\0') && ((puVar9[3] != 0 || (puVar9[1] != 0)))) {
          FUN_005bde90(param_1 + 0x134b4,"xmlns:%s",pcVar8);
          iVar3 = puVar9[3];
          if (iVar3 == 0) {
            iVar3 = puVar9[1];
          }
          iVar3 = FUN_005b1b60(param_1,param_1 + 0x134b4,iVar3);
          if (iVar3 != 0) goto LAB_005b381e;
        }
      }
    }
    *(undefined2 *)(param_1 + 0x15506) = 1;
    if (((*(uint *)(param_1 + 8) & 0x4000) != 0) && (iVar3 = FUN_0170dbd0(param_2,0x3a), iVar3 != 0)
       ) {
      FUN_005bdd60(param_1,param_2,iVar3 - (int)param_2);
    }
    if (0 < param_3) {
      FUN_005bde90(param_1 + 0x134b4,&DAT_018c3510,param_3);
      iVar3 = FUN_005b1b60(param_1,&DAT_018c1fd8,param_1 + 0x134b4);
      if (iVar3 != 0) goto LAB_005b381e;
    }
    if (((param_4 != (char *)0x0) && (*param_4 != '\0')) &&
       (((*(uint *)(param_1 + 8) & 0x80000) == 0 || (*(short *)(param_1 + 0x15508) == 6)))) {
      iVar3 = FUN_005b1b60(param_1,"xsi:type",param_4);
      if (iVar3 != 0) goto LAB_005b381e;
      if (((*(uint *)(param_1 + 8) & 0x4000) != 0) &&
         (iVar3 = FUN_0170dbd0(param_4,0x3a), iVar3 != 0)) {
        FUN_005bdd60(param_1,param_4,iVar3 - (int)param_4);
      }
    }
    if ((*(short *)(param_1 + 0x15504) != 0) && (0 < *(short *)(param_1 + 0x154b6))) {
      pcVar8 = (char *)(param_1 + 0x134b4);
      FUN_005bde90(pcVar8,&DAT_018c2f8c,*(undefined4 *)(param_1 + 0x154b8));
      param_1 = 1;
      if (1 < *(short *)(iVar2 + 0x154b6)) {
        puVar9 = (undefined4 *)(iVar2 + 0x154bc);
        do {
          pcVar7 = pcVar8;
          do {
            cVar1 = *pcVar7;
            pcVar7 = pcVar7 + 1;
          } while (cVar1 != '\0');
          FUN_005bde90(pcVar8 + ((int)pcVar7 - (iVar2 + 0x134b5)),&DAT_018c2f88,*puVar9);
          param_1 = param_1 + 1;
          puVar9 = puVar9 + 1;
        } while (param_1 < *(short *)(iVar2 + 0x154b6));
      }
      puVar10 = (undefined2 *)(iVar2 + 0x134b3);
      do {
        pcVar7 = (char *)((int)puVar10 + 1);
        puVar10 = (undefined2 *)((int)puVar10 + 1);
      } while (*pcVar7 != '\0');
      *puVar10 = DAT_018bfd94;
      iVar3 = FUN_005b1b60(iVar2,"SOAP-ENC:position",pcVar8);
      if (iVar3 != 0) goto LAB_005b381e;
    }
    if (*(short *)(iVar2 + 0x15502) != 0) {
      pcVar8 = *(char **)(iVar2 + 0x2c);
      if ((pcVar8 != (char *)0x0) && (*pcVar8 != '\0')) {
        pcVar7 = "SOAP-ENV:role";
        if (*(short *)(iVar2 + 6) != 2) {
          pcVar7 = "SOAP-ENV:actor";
        }
        iVar3 = FUN_005b1b60(iVar2,pcVar7,pcVar8);
        if (iVar3 != 0) goto LAB_005b381e;
      }
      puVar5 = &DAT_018bdf50;
      if (*(short *)(iVar2 + 6) != 2) {
        puVar5 = &DAT_018c3554;
      }
      iVar3 = FUN_005b1b60(iVar2,"SOAP-ENV:mustUnderstand",puVar5);
      if (iVar3 != 0) goto LAB_005b381e;
      *(undefined2 *)(iVar2 + 0x15502) = 0;
    }
    if (*(short *)(iVar2 + 0x15500) != 0) {
      pcVar8 = *(char **)(iVar2 + 0x28);
      if ((pcVar8 != (char *)0x0) && (iVar3 = *(int *)(iVar2 + 0x54), iVar3 != 0)) {
        if (*pcVar8 == '\0') {
          pcVar8 = *(char **)(iVar3 + 0x1c);
          if (pcVar8 == (char *)0x0) {
            pcVar8 = *(char **)(iVar3 + 0x14);
          }
          *(char **)(iVar2 + 0x28) = pcVar8;
        }
        iVar3 = FUN_005b1b60(iVar2,"SOAP-ENV:encodingStyle",pcVar8);
        if (iVar3 != 0) goto LAB_005b381e;
      }
      *(undefined2 *)(iVar2 + 0x15500) = 0;
    }
    *(undefined2 *)(iVar2 + 0x15504) = 0;
    *(undefined2 *)(iVar2 + 0x154b6) = 0;
    if ((*(short *)(iVar2 + 0x15508) == 10) && ((*(uint *)(iVar2 + 8) & 0x4000) != 0)) {
      *(undefined2 *)(iVar2 + 0x15508) = 0xb;
    }
    return 0;
  }
LAB_005b381e:
  return *(undefined4 *)(iVar2 + 0x1615c);
}



/* FUNCTION 4954 ; VA 0x005b3b70 ; FUN_005b3b70 */

int FUN_005b3b70(int param_1,char *param_2,int param_3,int param_4)

{
  int iVar1;
  
  iVar1 = FUN_005b8900(param_1);
  if (iVar1 == 0) {
    if (*(short *)(param_1 + 0x154b4) != 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      return 3;
    }
    if ((param_2 == (char *)0x0) || (*param_2 != '-')) {
      iVar1 = FUN_005b8220(param_1,param_1 + 0x138b4,param_2);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 0) {
        *(undefined2 *)(param_1 + 0x1550c) = 0;
        if (((param_4 != 0) && (*(char *)(param_1 + 0x144b4) != '\0')) &&
           (iVar1 = FUN_005b8220(param_1,param_1 + 0x144b4,param_4), iVar1 != 0)) {
          *(undefined4 *)(param_1 + 0x1615c) = 4;
          return 4;
        }
        if (((param_3 == 0) && (*(short *)(param_1 + 0x15504) != 0)) &&
           ((*(uint *)(param_1 + 8) & 0x1000) != 0)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x17;
          return 0x17;
        }
        if (*(short *)(param_1 + 0x309a) != 0) {
          *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + 1;
        }
      }
      return *(int *)(param_1 + 0x1615c);
    }
  }
  else {
    if (*(int *)(param_1 + 0x1615c) != 6) {
      return *(int *)(param_1 + 0x1615c);
    }
    if (param_2 == (char *)0x0) {
      return 6;
    }
    if (*param_2 != '-') {
      return 6;
    }
    *(undefined4 *)(param_1 + 0x1615c) = 0;
  }
  return 0;
}



/* FUNCTION 4955 ; VA 0x005b3c80 ; FUN_005b3c80 */

undefined4 FUN_005b3c80(int param_1,char *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*param_2 == '-') {
    return 0;
  }
  iVar1 = FUN_005b37c0(param_1,param_2,param_3,param_4);
  if (iVar1 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005b4210(param_1,0);
  return uVar2;
}



/* FUNCTION 4956 ; VA 0x005b3cc0 ; FUN_005b3cc0 */

undefined4 FUN_005b3cc0(int param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  
  uVar3 = 0;
  if ((param_2 != (char *)0x0) && (*param_2 == '-')) {
    return 0;
  }
  if (*(int *)(param_1 + 0x1615c) == 6) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
  }
  if (*(short *)(param_1 + 0x1550c) != 0) {
    *(undefined2 *)(param_1 + 0x1550c) = 0;
    uVar3 = (uint)(*(char *)(param_1 + 0x138b4) != '\0');
  }
  do {
    iVar1 = FUN_005b5480(param_1);
    uVar4 = uVar3;
    while (iVar1 != -3) {
      if (iVar1 == -1) goto LAB_005b3d8e;
      if (iVar1 == -2) {
        uVar4 = uVar4 + 1;
      }
      else if (iVar1 == 0x2f) {
        iVar1 = FUN_005b5480(param_1);
        if (iVar1 == -4) {
          uVar4 = uVar4 - 1;
        }
        else {
          *(int *)(param_1 + 0x3094) = iVar1;
        }
      }
      iVar1 = FUN_005b5480(param_1);
    }
    uVar3 = uVar4 - 1;
  } while (uVar4 != 0);
  puVar5 = (undefined *)(param_1 + 0x138b4);
  iVar1 = 0x400;
  iVar2 = FUN_005b5480(param_1);
  while (0x20 < iVar2) {
    iVar1 = iVar1 + -1;
    if (0 < iVar1) {
      *puVar5 = (char)iVar2;
      puVar5 = puVar5 + 1;
    }
    iVar2 = FUN_005b5480(param_1);
  }
  *puVar5 = 0;
  if (iVar2 == -1) {
LAB_005b3d8e:
    *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
    return 0xffffffff;
  }
  while ((-1 < iVar2 && (iVar2 < 0x21))) {
    iVar2 = FUN_005b5480(param_1);
  }
  if (iVar2 == -4) {
    if ((param_2 != (char *)0x0) && ((*(uint *)(param_1 + 8) & 0x1000) != 0)) {
      FUN_005b9a10(param_1);
      iVar1 = FUN_005b8220(param_1,param_1 + 0x138b4,param_2);
      if (iVar1 != 0) goto LAB_005b3df3;
    }
    *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + -1;
    return 0;
  }
LAB_005b3df3:
  *(undefined4 *)(param_1 + 0x1615c) = 5;
  return 5;
}



/* FUNCTION 4957 ; VA 0x005b3e10 ; FUN_005b3e10 */

undefined4 FUN_005b3e10(int param_1,char *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  char *pcVar7;
  
  if (*param_2 == '-') {
    return 0;
  }
  uVar4 = *(uint *)(param_1 + 8);
  if ((uVar4 & 0x4000) != 0) {
    puVar3 = *(undefined4 **)(param_1 + 0x58);
    while ((puVar3 != (undefined4 *)0x0 && (*(uint *)(param_1 + 0x309c) <= (uint)puVar3[1]))) {
      puVar2 = (undefined4 *)*puVar3;
      FUN_017168b0(puVar3);
      puVar3 = puVar2;
    }
    uVar4 = *(uint *)(param_1 + 8);
    *(undefined4 **)(param_1 + 0x58) = puVar3;
  }
  if ((uVar4 & 0x2000) != 0) {
    if (*(short *)(param_1 + 0x309a) == 0) {
      uVar4 = 10;
      if (*(uint *)(param_1 + 0x309c) < 0xb) {
        uVar4 = *(uint *)(param_1 + 0x309c);
      }
      iVar5 = FUN_005bc2c0(param_1,"\n\t\t\t\t\t\t\t\t\t",uVar4);
      if (iVar5 != 0) goto LAB_005b3ef2;
    }
    *(undefined2 *)(param_1 + 0x309a) = 0;
  }
  iVar5 = FUN_005bc2c0(param_1,&DAT_018c35e0,2);
  if (iVar5 == 0) {
    pcVar7 = param_2;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iVar5 = FUN_005bc2c0(param_1,param_2,(int)pcVar7 - (int)(param_2 + 1));
    if (iVar5 == 0) {
      *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + -1;
      uVar6 = FUN_005bc2c0(param_1,&DAT_018c34a0,1);
      return uVar6;
    }
  }
LAB_005b3ef2:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4958 ; VA 0x005b3f00 ; FUN_005b3f00 */

int FUN_005b3f00(int param_1,undefined4 param_2,int param_3,int param_4,int *param_5,
                undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  short sVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  
  if ((param_4 == 0) || ((param_5 != (int *)0x0 && (*param_5 == 0)))) {
    FUN_005b4030(param_1,param_2,param_3,param_7);
    return -1;
  }
  if ((*(uint *)(param_1 + 8) & 0x8000) != 0) {
    return 0;
  }
  if (param_3 < 0) {
    if (param_5 == (int *)0x0) {
      param_3 = FUN_005b9800(param_1,param_4,param_8,&param_4);
    }
    else {
      param_3 = FUN_005b1ac0(param_1,param_4,param_5,param_6,param_8,&param_4);
    }
    iVar3 = param_4;
    if (param_3 != 0) {
      iVar2 = FUN_005b7c70(param_1,param_4);
      if (iVar2 != 0) {
        sVar1 = *(short *)(param_1 + 6);
        FUN_005bde90(param_1 + 0x140b4,&DAT_018c35f4,param_3);
        iVar3 = FUN_005b37c0(param_1,param_2,0,0);
        if (iVar3 == 0) {
          pcVar4 = "href";
          if (sVar1 == 2) {
            pcVar4 = "SOAP-ENC:ref";
          }
          iVar3 = FUN_005b1b60(param_1,pcVar4,(sVar1 == 2) + 0x140b4 + param_1);
          if (iVar3 == 0) {
            FUN_005b4210(param_1,param_2);
          }
        }
        return -1;
      }
      iVar2 = FUN_005b7ce0(param_1,iVar3);
      if (iVar2 != 0) {
        return 0;
      }
      FUN_005bc880(param_1,iVar3);
    }
  }
  return param_3;
}



/* FUNCTION 4959 ; VA 0x005b4030 ; FUN_005b4030 */

int FUN_005b4030(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  
  for (puVar1 = *(undefined4 **)(param_1 + 0x154fc); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)*puVar1) {
    if (*(short *)(puVar1 + 4) != 0) goto LAB_005b4087;
  }
  if ((((*(short *)(param_1 + 6) != 2) || (*(short *)(param_1 + 0x154b6) < 1)) && (param_3 < 1)) &&
     ((*(uint *)(param_1 + 8) & 0x20000) == 0)) {
    *(undefined4 *)(param_1 + 0x15502) = 0x10000;
    *(undefined2 *)(param_1 + 0x154b6) = 0;
    return 0;
  }
LAB_005b4087:
  iVar2 = FUN_005b37c0(param_1,param_2,param_3,param_4);
  if (iVar2 != 0) {
    return *(int *)(param_1 + 0x1615c);
  }
  if (puVar1 != (undefined4 *)0x0) goto LAB_005b4174;
  if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
    iVar2 = FUN_005bc2c0(param_1,&DAT_018c0cc8,1);
    if (((iVar2 == 0) && (iVar2 = FUN_005bc2c0(param_1,&DAT_018c35fc,7), iVar2 == 0)) &&
       ((iVar2 = FUN_005bc2c0(param_1,&DAT_018c35d4,2), iVar2 == 0 &&
        (iVar2 = FUN_005bd9a0(param_1,&DAT_018bdf50,1), iVar2 == 0)))) {
      iVar2 = FUN_005bc2c0(param_1,&DAT_018c35d8,1);
      goto LAB_005b4161;
    }
  }
  else {
    iVar2 = FUN_01723e00(&DAT_018c35fc,"xmlns:",6);
    if (iVar2 == 0) {
      FUN_005b9d40(param_1,&DAT_018c3602,&DAT_018bdf50,0);
      iVar2 = FUN_005b4210(param_1,param_2);
      return iVar2;
    }
    iVar2 = FUN_005bc430(param_1,&DAT_018c35fc,&DAT_018bdf50);
LAB_005b4161:
    if (iVar2 == 0) goto LAB_005b4174;
  }
  if (*(int *)(param_1 + 0x1615c) != 0) {
    return *(int *)(param_1 + 0x1615c);
  }
LAB_005b4174:
  iVar2 = FUN_005b4210(param_1,param_2);
  return iVar2;
}



/* FUNCTION 4960 ; VA 0x005b4190 ; FUN_005b4190 */

undefined4 FUN_005b4190(int param_1,undefined4 param_2)

{
  int iVar1;
  
  if ((*(short *)(param_1 + 6) != 2) || (*(int *)(param_1 + 0x28) == 0)) {
    return 0;
  }
  iVar1 = FUN_005b37c0(param_1,"SOAP-RPC:result",0,0);
  if (((iVar1 == 0) &&
      (((iVar1 = FUN_005b1b60(param_1,"xmlns:SOAP-RPC","http://www.w3.org/2003/05/soap-rpc"),
        iVar1 == 0 && (iVar1 = FUN_005b4210(param_1,0), iVar1 == 0)) &&
       (iVar1 = FUN_005bd9a0(param_1,param_2,0), iVar1 == 0)))) &&
     (iVar1 = FUN_005b3e10(param_1,"SOAP-RPC:result"), iVar1 == 0)) {
    return 0;
  }
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4961 ; VA 0x005b4210 ; FUN_005b4210 */

undefined4 FUN_005b4210(int param_1,int param_2)

{
  char *pcVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  char *pcVar7;
  
  if ((*(uint *)(param_1 + 8) & 0x4000) != 0) {
    for (puVar3 = *(undefined4 **)(param_1 + 0x154fc); puVar3 != (undefined4 *)0x0;
        puVar3 = (undefined4 *)*puVar3) {
      if (((*(short *)(puVar3 + 4) != 0) && (iVar5 = (int)puVar3 + 0x12, iVar5 != 0)) &&
         (iVar4 = FUN_0170dbd0(iVar5,0x3a), iVar4 != 0)) {
        FUN_005bdd60(param_1,iVar5,(iVar4 - (int)puVar3) + -0x12);
      }
    }
    for (puVar3 = *(undefined4 **)(param_1 + 0x58); puVar3 != (undefined4 *)0x0;
        puVar3 = (undefined4 *)*puVar3) {
      if ((*(short *)(puVar3 + 2) == 1) && (puVar3[3] != 0)) {
        FUN_005bde90(param_1 + 0x134b4,"xmlns:%s",puVar3 + 4);
        FUN_005bc430(param_1,param_1 + 0x134b4,puVar3[3]);
        *(undefined2 *)(puVar3 + 2) = 2;
      }
    }
  }
  for (puVar3 = *(undefined4 **)(param_1 + 0x154fc); puVar3 != (undefined4 *)0x0;
      puVar3 = (undefined4 *)*puVar3) {
    if (*(short *)(puVar3 + 4) != 0) {
      iVar5 = FUN_005bc2c0(param_1,&DAT_018c0cc8,1);
      if (iVar5 != 0) goto LAB_005b4395;
      pcVar1 = (char *)((int)puVar3 + 0x12);
      if (pcVar1 != (char *)0x0) {
        pcVar7 = pcVar1;
        do {
          cVar2 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar2 != '\0');
        iVar5 = FUN_005bc2c0(param_1,pcVar1,(int)pcVar7 - ((int)puVar3 + 0x13));
        if (iVar5 != 0) goto LAB_005b4395;
      }
      if (((*(short *)(puVar3 + 4) == 2) && (puVar3[1] != 0)) &&
         ((iVar5 = FUN_005bc2c0(param_1,&DAT_018c35d4,2), iVar5 != 0 ||
          ((iVar5 = FUN_005bd9a0(param_1,puVar3[1],1), iVar5 != 0 ||
           (iVar5 = FUN_005bc2c0(param_1,&DAT_018c35d8,1), iVar5 != 0)))))) goto LAB_005b4395;
      *(undefined2 *)(puVar3 + 4) = 0;
    }
  }
  if (param_2 == 0) {
    uVar6 = FUN_005bc2c0(param_1,&DAT_018c34a0,1);
    return uVar6;
  }
  if ((*(uint *)(param_1 + 8) & 0x4000) == 0) {
    *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + -1;
    iVar5 = FUN_005bc2c0(param_1,&DAT_018c35dc,2);
    if (iVar5 != 0) {
      return *(undefined4 *)(param_1 + 0x1615c);
    }
  }
  else {
    iVar5 = FUN_005bc2c0(param_1,&DAT_018c34a0,1);
    if ((iVar5 != 0) || (iVar5 = FUN_005b3e10(param_1,param_2), iVar5 != 0)) {
LAB_005b4395:
      return *(undefined4 *)(param_1 + 0x1615c);
    }
  }
  return 0;
}



/* FUNCTION 4962 ; VA 0x005b43f0 ; FUN_005b43f0 */

int FUN_005b43f0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar2 = param_1;
  if (*(short *)(param_1 + 6) != 1) {
    *(undefined2 *)(param_1 + 0x15500) = 1;
  }
  if (param_3 == 0) {
    iVar4 = FUN_005b9800(param_1,param_2,param_6,&param_1);
  }
  else {
    iVar4 = FUN_005b1ac0(param_1,param_2,param_3,param_4,param_6,&param_1);
  }
  iVar3 = param_1;
  if (iVar4 != 0) {
    iVar5 = FUN_005b7c70(iVar2,param_1);
    if ((iVar5 != 0) || (*(short *)(iVar2 + 0x15508) == 3)) {
      return 0;
    }
    if (iVar3 != 0) {
      uVar6 = *(uint *)(iVar2 + 8) & 8;
      if (uVar6 == 0) {
        cVar1 = *(char *)(iVar3 + 0x15);
      }
      else {
        cVar1 = *(char *)(iVar3 + 0x14);
      }
      if (cVar1 == '\0') {
        return 0;
      }
      if (uVar6 == 0) {
        *(undefined *)(iVar3 + 0x15) = 1;
        return iVar4;
      }
      *(undefined *)(iVar3 + 0x14) = 1;
    }
  }
  return iVar4;
}



/* FUNCTION 4963 ; VA 0x005b44a0 ; FUN_005b44a0 */

void FUN_005b44a0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iStack_8;
  
  iVar1 = FUN_005b9800(param_1,param_2,param_3,&iStack_8);
  if (iVar1 != 0) {
    *(undefined2 *)(iStack_8 + 0x14) = 0x101;
  }
  return;
}



/* FUNCTION 4964 ; VA 0x005b44d0 ; FUN_005b44d0 */

int FUN_005b44d0(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  int iStack_8;
  
  iStack_8 = 0;
  uVar1 = *(uint *)(param_1 + 8);
  if ((uVar1 & 0x8000) != 0) {
    return param_2;
  }
  if ((((*(short *)(param_1 + 6) == 1) && (*(int *)(param_1 + 0x28) != 0)) &&
      ((uVar1 & 0x10000) == 0)) && (*(short *)(param_1 + 0x15508) != 3)) {
    if (-1 < param_2) {
      return param_2;
    }
    iVar2 = FUN_005b9800(param_1,param_3,param_4,&iStack_8);
    if (iVar2 != 0) {
      if ((uVar1 & 8) != 0) {
        *(undefined *)(iStack_8 + 0x14) = 2;
        return -1;
      }
      *(undefined *)(iStack_8 + 0x15) = 2;
    }
    return -1;
  }
  if (param_2 < 0) {
    param_2 = FUN_005b9800(param_1,param_3,param_4,&iStack_8);
  }
  else {
    if (param_2 == 0) {
      return 0;
    }
    iVar2 = FUN_005b9800(param_1,param_3,param_4,&iStack_8);
    if (iVar2 == 0) {
      return 0;
    }
  }
  if ((param_2 != 0) && (iStack_8 != 0)) {
    if ((uVar1 & 8) != 0) {
      *(undefined *)(iStack_8 + 0x14) = 1;
      return param_2;
    }
    *(undefined *)(iStack_8 + 0x15) = 1;
  }
  return param_2;
}



/* FUNCTION 4965 ; VA 0x005b454f ; FUN_005b454f */

int __fastcall FUN_005b454f(int param_1)

{
  int iVar1;
  uint unaff_EBX;
  int unaff_EBP;
  
  if (param_1 < 0) {
    param_1 = FUN_005b9800();
  }
  else {
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = FUN_005b9800();
    if (iVar1 == 0) {
      return 0;
    }
  }
  if ((param_1 != 0) && (iVar1 = *(int *)(unaff_EBP + -4), iVar1 != 0)) {
    if ((unaff_EBX & 8) != 0) {
      *(undefined *)(iVar1 + 0x14) = 1;
      return param_1;
    }
    *(undefined *)(iVar1 + 0x15) = 1;
  }
  return param_1;
}



/* FUNCTION 4966 ; VA 0x005b45c0 ; FUN_005b45c0 */

void FUN_005b45c0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  if ((param_1 != 0) && ((*(short *)(param_1 + 4) == 1 || (*(short *)(param_1 + 4) == 2)))) {
    FUN_005b52e0(param_1);
    if ((*(short *)(param_1 + 4) == 1) || (*(short *)(param_1 + 4) == 2)) {
      puVar1 = *(undefined4 **)(param_1 + 100);
      while (puVar1 != (undefined4 *)0x0) {
        if (*(short *)((int)puVar1 + -2) != -0x3f22) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x15;
          goto LAB_005b46a4;
        }
        *(undefined4 *)(param_1 + 100) = *puVar1;
        FUN_017168b0((int)puVar1 - puVar1[1]);
        puVar1 = *(undefined4 **)(param_1 + 100);
      }
      *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfffffeff;
      *(undefined4 *)(param_1 + 0x16118) = 0;
      *(undefined4 *)(param_1 + 0x2fb0) = 0;
      *(undefined4 *)(param_1 + 0x2fac) = 0;
      *(undefined4 *)(param_1 + 0x2fc0) = 0;
      *(undefined4 *)(param_1 + 0x2fc4) = 0;
      *(undefined4 *)(param_1 + 0x1611c) = 0;
      *(undefined4 *)(param_1 + 0x24) = 0;
      *(undefined4 *)(param_1 + 0x161a8) = 0;
      *(undefined4 *)(param_1 + 0x161ac) = 0;
      *(undefined4 *)(param_1 + 0x1619c) = 0;
      *(undefined4 *)(param_1 + 0x161a0) = 0;
    }
LAB_005b46a4:
    iVar2 = *(int *)(param_1 + 0x60);
    while (iVar2 != 0) {
      iVar2 = **(int **)(param_1 + 0x60);
      FUN_017168b0(*(int **)(param_1 + 0x60));
      *(int *)(param_1 + 0x60) = iVar2;
    }
    FUN_005b2e00(param_1);
  }
  return;
}



/* FUNCTION 4967 ; VA 0x005b46e0 ; FUN_005b46e0 */

void FUN_005b46e0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar1 = *(undefined4 **)(param_1 + 0x5c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar3 = (undefined4 *)puVar1[1];
    while (puVar3 != (undefined4 *)0x0) {
      puVar2 = (undefined4 *)*puVar3;
      FUN_017168b0(puVar3);
      puVar3 = puVar2;
    }
    *(undefined4 *)(param_1 + 0x5c) = *puVar1;
    FUN_017168b0(puVar1);
  }
  return;
}



/* FUNCTION 4968 ; VA 0x005b4720 ; FUN_005b4720 */

undefined4 FUN_005b4720(int param_1)

{
  undefined4 uVar1;
  
  if (*(code **)(param_1 + 0x3040) != (code *)0x0) {
    uVar1 = (**(code **)(param_1 + 0x3040))(param_1);
    *(undefined4 *)(param_1 + 0x1615c) = uVar1;
    return uVar1;
  }
  return 0;
}



/* FUNCTION 4969 ; VA 0x005b4750 ; FUN_005b4750 */

int FUN_005b4750(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  
  *(undefined2 *)(param_1 + 0x15508) = 9;
  if (((*(byte *)(param_1 + 8) & 0x80) == 0) || (iVar2 = FUN_005b6030(param_1), iVar2 == 0)) {
    *(undefined4 *)(param_1 + 0x16190) = *(undefined4 *)(param_1 + 0x16194);
    *(undefined4 *)(param_1 + 0x16194) = 0;
    *(undefined4 *)(param_1 + 0x16198) = 0;
    if ((*(uint *)(param_1 + 8) & 0x100) != 0) {
      if ((*(uint *)(param_1 + 8) & 0x10000000) != 0) {
        FUN_005bb320(param_1);
        return 0;
      }
      do {
        iVar2 = FUN_005b5940(param_1,0);
      } while (iVar2 != 0);
      if (*(int *)(param_1 + 0x1615c) != 0) {
        return *(int *)(param_1 + 0x1615c);
      }
    }
    puVar1 = *(undefined4 **)(param_1 + 0x161a8);
    *(undefined4 **)(param_1 + 0x161a4) = puVar1;
    *(undefined4 *)(param_1 + 0x161a8) = 0;
    *(undefined4 *)(param_1 + 0x161ac) = 0;
    *(undefined4 *)(param_1 + 0x1619c) = 0;
    if (*(int *)(param_1 + 0x161b0) != 0) {
      for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
        FUN_005bb5d0(param_1,puVar1);
      }
    }
    if (((byte)*(undefined4 *)(param_1 + 8) & 3) == 3) {
      do {
        uVar3 = *(uint *)(param_1 + 0x3094);
        if (uVar3 == 0) {
          if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
             (iVar2 = FUN_005bac80(param_1), iVar2 != 0)) break;
          uVar3 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else {
          if (uVar3 == 0xffffffff) break;
          *(undefined4 *)(param_1 + 0x3094) = 0;
        }
      } while (uVar3 != 0xffffffff);
    }
    if (*(code **)(param_1 + 0x2ffc) != (code *)0x0) {
      iVar2 = (**(code **)(param_1 + 0x2ffc))(param_1);
      *(int *)(param_1 + 0x1615c) = iVar2;
      if (iVar2 != 0) {
        return iVar2;
      }
    }
    iVar2 = FUN_005bb320(param_1);
    if (iVar2 == 0) {
      if (*(int *)(param_1 + 0x161b0) == 0) {
        FUN_005b52e0(param_1);
        return 0;
      }
      if ((*(uint *)(param_1 + 8) & 0x200) == 0) {
        *(undefined4 *)(param_1 + 0x1615c) = 0x21;
        return 0x21;
      }
      *(undefined4 *)(param_1 + 0x1615c) = 0x25;
      return 0x25;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x16194) = 0;
    *(undefined4 *)(param_1 + 0x16198) = 0;
  }
  return *(int *)(param_1 + 0x1615c);
}



/* FUNCTION 4970 ; VA 0x005b4900 ; FUN_005b4900 */

int FUN_005b4900(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (*(int *)(param_1 + 0x16190) != 0) {
    **(undefined4 **)(param_1 + 0x16198) = *(undefined4 *)(param_1 + 0x16194);
    *(undefined4 *)(param_1 + 0x16194) = **(undefined4 **)(param_1 + 0x16190);
    **(undefined4 **)(param_1 + 0x16190) = 0;
    *(undefined4 *)(param_1 + 0x16198) = *(undefined4 *)(param_1 + 0x16190);
  }
  iVar2 = FUN_005b9f10(param_1);
  if ((iVar2 != 0) || (iVar2 = FUN_005ba690(param_1), iVar2 != 0)) goto LAB_005b4a92;
  *(undefined4 *)(param_1 + 0x161a4) = 0;
  *(undefined4 *)(param_1 + 0x161a8) = 0;
  *(undefined4 *)(param_1 + 0x161ac) = 0;
  *(undefined4 *)(param_1 + 0x16190) = 0;
  *(undefined4 *)(param_1 + 0x16194) = 0;
  *(undefined4 *)(param_1 + 0x16198) = 0;
  if ((*(byte *)(param_1 + 8) & 3) == 0) goto LAB_005b4abd;
  iVar2 = FUN_005b5120(param_1);
  if (iVar2 != 0) goto LAB_005b4a92;
  uVar1 = *(uint *)(param_1 + 8);
  if ((uVar1 & 3) != 2) {
    if ((uVar1 & 3) == 3) {
      iVar2 = (**(code **)(param_1 + 0x3014))(param_1,"\r\n0\r\n\r\n",7);
      *(int *)(param_1 + 0x1615c) = iVar2;
      if (iVar2 != 0) {
        return iVar2;
      }
    }
    goto LAB_005b4abd;
  }
  if ((uVar1 & 0x40) == 0) {
    iVar2 = *(int *)(param_1 + 0x16158);
    *(uint *)(param_1 + 8) = uVar1 - 1;
    if (iVar2 < 2000) {
      if (iVar2 != 1000) {
        uVar3 = (**(code **)(param_1 + 0x2fe4))
                          (param_1,iVar2,*(undefined4 *)(*(int *)(param_1 + 0x5c) + 8));
        goto LAB_005b4a1d;
      }
    }
    else {
      uVar3 = (**(code **)(param_1 + 0x2fc8))
                        (param_1,param_1 + 0x15518,param_1 + 0x15d18,
                         *(undefined4 *)(param_1 + 0x16128),param_1 + 0x15918,
                         *(undefined4 *)(param_1 + 0x16118),
                         *(undefined4 *)(*(int *)(param_1 + 0x5c) + 8));
LAB_005b4a1d:
      *(undefined4 *)(param_1 + 0x1615c) = uVar3;
    }
    if ((*(int *)(param_1 + 0x1615c) != 0) || (iVar2 = FUN_005b5120(param_1), iVar2 != 0)) {
LAB_005b4a92:
      return *(int *)(param_1 + 0x1615c);
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  }
  iVar2 = FUN_005b50f0(param_1);
  while (iVar2 != 0) {
    iVar2 = (**(code **)(param_1 + 0x3014))
                      (param_1,iVar2,*(undefined4 *)(*(int *)(*(int *)(param_1 + 0x5c) + 4) + 4));
    *(int *)(param_1 + 0x1615c) = iVar2;
    if (iVar2 != 0) {
      FUN_005b46e0(param_1);
      goto LAB_005b4a92;
    }
    iVar2 = FUN_005b8460();
  }
  FUN_005b46e0(param_1);
LAB_005b4abd:
  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) & 0xfff7ffff;
  *(undefined2 *)(param_1 + 0x15508) = 9;
  *(undefined4 *)(param_1 + 0x30a0) = 0;
  return 0;
}



/* FUNCTION 4971 ; VA 0x005b4ae0 ; FUN_005b4ae0 */

undefined4 * FUN_005b4ae0(int param_1,char *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  char *pcVar4;
  
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  puVar2 = (undefined4 *)FUN_0171e1f2(pcVar4 + (0x24 - (int)(param_2 + 1)));
  if (puVar2 != (undefined4 *)0x0) {
    iVar3 = FUN_005b6df0(param_2);
    pcVar4 = param_2;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
      pcVar4[(int)puVar2 + (0x1f - (int)param_2)] = cVar1;
    } while (cVar1 != '\0');
    param_1 = param_1 + iVar3 * 4;
    *puVar2 = *(undefined4 *)(param_1 + 0x68);
    *(undefined4 **)(param_1 + 0x68) = puVar2;
    return puVar2;
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4972 ; VA 0x005b4b50 ; FUN_005b4b50 */

int FUN_005b4b50(int param_1)

{
  byte bVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  char *pcVar5;
  byte *pbVar6;
  undefined4 uVar7;
  byte *pbVar8;
  uint uVar9;
  byte *pbVar10;
  char *pcVar11;
  bool bVar12;
  
  *(undefined2 *)(param_1 + 0x15508) = 2;
  iVar4 = FUN_005b8900(param_1);
  if (iVar4 == 0) {
    if (*(short *)(param_1 + 0x154b4) == 0) {
      iVar4 = FUN_005b8220(param_1,param_1 + 0x138b4,"SOAP-ENV:Envelope");
      *(int *)(param_1 + 0x1615c) = iVar4;
      if (iVar4 == 0) {
        *(undefined2 *)(param_1 + 0x1550c) = 0;
        if ((*(short *)(param_1 + 0x15504) == 0) || ((*(uint *)(param_1 + 8) & 0x1000) == 0)) {
          iVar4 = 0;
          if (*(short *)(param_1 + 0x309a) != 0) {
            *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + 1;
          }
          goto LAB_005b4c40;
        }
        *(undefined4 *)(param_1 + 0x1615c) = 0x17;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
    }
  }
  else {
    iVar4 = *(int *)(param_1 + 0x1615c);
    if (iVar4 != 6) {
LAB_005b4c40:
      if (iVar4 == 0) {
        iVar4 = *(int *)(param_1 + 0x54);
        if (iVar4 != 0) {
          pbVar6 = *(byte **)(iVar4 + 0xc);
          if (pbVar6 == (byte *)0x0) {
            pbVar6 = *(byte **)(iVar4 + 4);
          }
          pbVar10 = &DAT_018c22f8;
          pbVar8 = pbVar6;
          do {
            bVar1 = *pbVar8;
            bVar12 = bVar1 < *pbVar10;
            if (bVar1 != *pbVar10) {
LAB_005b4c85:
              uVar9 = -(uint)bVar12 | 1;
              goto LAB_005b4c8a;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar8[1];
            bVar12 = bVar1 < pbVar10[1];
            if (bVar1 != pbVar10[1]) goto LAB_005b4c85;
            pbVar8 = pbVar8 + 2;
            pbVar10 = pbVar10 + 2;
          } while (bVar1 != 0);
          uVar9 = 0;
LAB_005b4c8a:
          if (uVar9 == 0) {
            *(undefined2 *)(param_1 + 6) = 1;
            if (*(int *)(iVar4 + 0x1c) != 0) {
              FUN_017168b0(*(int *)(iVar4 + 0x1c));
            }
            pcVar5 = (char *)FUN_0171e1f2(0x2a);
            *(char **)(iVar4 + 0x1c) = pcVar5;
            if (pcVar5 != (char *)0x0) {
              pcVar11 = "http://schemas.xmlsoap.org/soap/encoding/";
              do {
                cVar2 = *pcVar11;
                pcVar11 = pcVar11 + 1;
                *pcVar5 = cVar2;
                pcVar5 = pcVar5 + 1;
              } while (cVar2 != '\0');
              return 0;
            }
          }
          else {
            pbVar8 = &DAT_018c2350;
            do {
              bVar1 = *pbVar6;
              bVar12 = bVar1 < *pbVar8;
              if (bVar1 != *pbVar8) {
LAB_005b4d00:
                uVar9 = -(uint)bVar12 | 1;
                goto LAB_005b4d05;
              }
              if (bVar1 == 0) break;
              bVar1 = pbVar6[1];
              bVar12 = bVar1 < pbVar8[1];
              if (bVar1 != pbVar8[1]) goto LAB_005b4d00;
              pbVar6 = pbVar6 + 2;
              pbVar8 = pbVar8 + 2;
            } while (bVar1 != 0);
            uVar9 = 0;
LAB_005b4d05:
            if (uVar9 == 0) {
              *(undefined2 *)(param_1 + 6) = 2;
              if (*(int *)(iVar4 + 0x1c) != 0) {
                FUN_017168b0(*(int *)(iVar4 + 0x1c));
              }
              pcVar5 = (char *)FUN_0171e1f2(0x28);
              *(char **)(iVar4 + 0x1c) = pcVar5;
              if (pcVar5 != (char *)0x0) {
                pcVar11 = "http://www.w3.org/2003/05/soap-encoding";
                do {
                  cVar2 = *pcVar11;
                  pcVar11 = pcVar11 + 1;
                  *pcVar5 = cVar2;
                  pcVar5 = pcVar5 + 1;
                } while (cVar2 != '\0');
              }
            }
          }
        }
        return 0;
      }
    }
  }
  if (*(int *)(param_1 + 0x1615c) != 3) goto LAB_005b4bb9;
  iVar4 = FUN_005b8900(param_1);
  if (iVar4 == 0) {
    if (*(short *)(param_1 + 0x154b4) != 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      goto LAB_005b4bb9;
    }
    iVar4 = FUN_005b8220(param_1,param_1 + 0x138b4,&DAT_018c3bec);
    *(int *)(param_1 + 0x1615c) = iVar4;
    if (iVar4 != 0) goto LAB_005b4bb9;
    *(undefined2 *)(param_1 + 0x1550c) = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) && ((*(uint *)(param_1 + 8) & 0x1000) != 0)) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x17;
      goto LAB_005b4bb9;
    }
    iVar4 = 0;
    if (*(short *)(param_1 + 0x309a) != 0) {
      *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + 1;
    }
  }
  else {
    iVar4 = *(int *)(param_1 + 0x1615c);
    if (iVar4 == 6) goto LAB_005b4bb9;
  }
  if (iVar4 == 0) {
    uVar3 = *(undefined4 *)(param_1 + 0x3018);
    *(code **)(param_1 + 0x3018) = FUN_00554ed0;
    if ((*(short *)(param_1 + 0x1550c) == 0) &&
       (*(undefined2 *)(param_1 + 0x1550c) = 1, *(short *)(param_1 + 0x309a) != 0)) {
      *(int *)(param_1 + 0x309c) = *(int *)(param_1 + 0x309c) + -1;
    }
    uVar7 = FUN_005bd410(param_1,1,0xffffffff,0xffffffff);
    *(undefined4 *)(param_1 + 0x3018) = uVar3;
    iVar4 = FUN_005bcf60(param_1,"HTTP Error",uVar7,0x1d);
    return iVar4;
  }
LAB_005b4bb9:
  iVar4 = *(int *)(param_1 + 0x1615c);
  if (iVar4 == 3) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x27;
    iVar4 = 0x27;
  }
  return iVar4;
}



/* FUNCTION 4973 ; VA 0x005b4e30 ; FUN_005b4e30 */

undefined4 FUN_005b4e30(int param_1)

{
  char *pcVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  
  uVar3 = *(uint *)(param_1 + 8);
  if ((((uVar3 & 0x100) != 0) && (pcVar7 = *(char **)(param_1 + 0x1619c), pcVar7 != (char *)0x0)) &&
     (pcVar6 = *(char **)(param_1 + 0x161a0), pcVar6 != (char *)0x0)) {
    pcVar8 = pcVar7;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    pcVar1 = pcVar6 + 1;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    if (pcVar8 + (int)(pcVar6 + (-(int)pcVar1 - (int)(pcVar7 + 1))) < (char *)0x3b0) {
      if ((uVar3 & 0x280) == 0x80) {
        pcVar6 = "application/dime";
      }
      else if (*(short *)(param_1 + 6) == 2) {
        pcVar6 = "application/soap+xml; charset=utf-8";
        if ((uVar3 & 0x200) != 0) {
          pcVar6 = "application/xop+xml; charset=utf-8; type=\"application/soap+xml\"";
        }
      }
      else {
        pcVar6 = "text/xml; charset=utf-8";
      }
      pcVar8 = (char *)(param_1 + 0x134b4);
      FUN_005bde90(pcVar8,
                   "--%s\r\nContent-Type: %s\r\nContent-Transfer-Encoding: binary\r\nContent-ID: %s\r\n\r\n"
                   ,pcVar7,pcVar6,*(undefined4 *)(param_1 + 0x161a0));
      pcVar7 = pcVar8;
      do {
        cVar2 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar2 != '\0');
      iVar4 = FUN_005bc2c0(param_1,pcVar8,(int)pcVar7 - (param_1 + 0x134b5));
      if (iVar4 != 0) goto LAB_005b4f08;
    }
  }
  if ((*(uint *)(param_1 + 8) & 8) == 0) {
    if (((char)*(uint *)(param_1 + 8) < '\0') && (iVar4 = FUN_005ba200(param_1), iVar4 != 0))
    goto LAB_005b4f08;
  }
  else {
    *(undefined4 *)(param_1 + 0x16170) = *(undefined4 *)(param_1 + 0x30a0);
  }
  *(undefined2 *)(param_1 + 0x15508) = 2;
  iVar4 = FUN_005b37c0(param_1,"SOAP-ENV:Envelope",0,0);
  if (iVar4 == 0) {
    uVar5 = FUN_005b4210(param_1,0);
    return uVar5;
  }
LAB_005b4f08:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4974 ; VA 0x005b4f70 ; FUN_005b4f70 */

void FUN_005b4f70(int param_1)

{
  *(undefined2 *)(param_1 + 0x15508) = 8;
  FUN_005b3cc0(param_1,"SOAP-ENV:Envelope");
  return;
}



/* FUNCTION 4975 ; VA 0x005b4fa0 ; FUN_005b4fa0 */

undefined4 FUN_005b4fa0(int param_1)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  uint uVar6;
  uint uVar7;
  char *pcVar8;
  
  iVar3 = FUN_005b3e10(param_1,"SOAP-ENV:Envelope");
  if (iVar3 != 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar7 = *(uint *)(param_1 + 8);
  if ((uVar7 & 0x288) == 0x88) {
    pcVar8 = (char *)(param_1 + 0x13cb4);
    *(int *)(param_1 + 0x16170) = *(int *)(param_1 + 0x30a0) - *(int *)(param_1 + 0x16170);
    FUN_005bde90(pcVar8,*(undefined4 *)(param_1 + 0x1c),0);
    iVar3 = *(int *)(param_1 + 0x54);
    *(char **)(param_1 + 0x16184) = pcVar8;
    if (iVar3 != 0) {
      if (*(int *)(iVar3 + 0xc) == 0) {
        *(undefined4 *)(param_1 + 0x16188) = *(undefined4 *)(iVar3 + 4);
      }
      else {
        *(int *)(param_1 + 0x16188) = *(int *)(iVar3 + 0xc);
      }
    }
    *(undefined4 *)(param_1 + 0x1618c) = 0;
    *(undefined *)(param_1 + 0x1617c) = 0x24;
    if (*(int *)(param_1 + 0x16194) == 0) {
      *(undefined *)(param_1 + 0x1617c) = 0x26;
    }
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    pcVar5 = *(char **)(param_1 + 0x16188);
    if (pcVar5 == (char *)0x0) {
      uVar6 = 0;
    }
    else {
      pcVar1 = pcVar5 + 1;
      do {
        cVar2 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar2 != '\0');
      uVar6 = (uint)(pcVar5 + (3 - (int)pcVar1)) & 0xfffffffc;
    }
    uVar7 = *(uint *)(param_1 + 8);
    *(int *)(param_1 + 0x30a0) =
         *(int *)(param_1 + 0x30a0) +
         ((uint)(pcVar8 + (3 - (param_1 + 0x13cb5))) & 0xfffffffc) + uVar6 + 0xc;
  }
  if ((uVar7 & 0x280) == 0x80) {
    uVar4 = FUN_005bc2c0(param_1,&DAT_018c2414,-*(int *)(param_1 + 0x16170) & 3);
    return uVar4;
  }
  *(undefined2 *)(param_1 + 0x15508) = 8;
  return 0;
}



/* FUNCTION 4976 ; VA 0x005b50d0 ; FUN_005b50d0 */

void FUN_005b50d0(void)

{
  undefined4 in_stack_00000010;
  undefined4 in_stack_00000018;
  undefined4 in_stack_0000001c;
  
  FUN_0170c6f0(in_stack_00000010,in_stack_00000018,in_stack_0000001c);
  return;
}



/* FUNCTION 4977 ; VA 0x005b50f0 ; FUN_005b50f0 */

int * FUN_005b50f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x5c) + 4);
  if (piVar1 == (int *)0x0) {
    return (int *)0x0;
  }
  piVar3 = (int *)0x0;
  do {
    piVar2 = piVar1;
    piVar1 = (int *)*piVar2;
    *piVar2 = (int)piVar3;
    piVar3 = piVar2;
  } while (piVar1 != (int *)0x0);
  *(int **)(*(int *)(param_1 + 0x5c) + 4) = piVar2;
  return piVar2 + 2;
}



/* FUNCTION 4978 ; VA 0x005b5120 ; FUN_005b5120 */

undefined4 FUN_005b5120(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x308c);
  if (iVar1 != 0) {
    *(undefined4 *)(param_1 + 0x308c) = 0;
    uVar2 = FUN_005b5160(param_1,param_1 + 0x30b4,iVar1);
    return uVar2;
  }
  return 0;
}



/* FUNCTION 4979 ; VA 0x005b5160 ; FUN_005b5160 */

int FUN_005b5160(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  char *pcVar6;
  char acStack_14 [16];
  
  uVar3 = *(uint *)(param_1 + 8) & 3;
  if (uVar3 == 2) {
    puVar4 = (undefined4 *)FUN_0171e1f2(param_3 + 8);
    if (puVar4 != (undefined4 *)0x0) {
      *puVar4 = *(undefined4 *)(*(int *)(param_1 + 0x5c) + 4);
      puVar4[1] = param_3;
      *(undefined4 **)(*(int *)(param_1 + 0x5c) + 4) = puVar4;
      piVar1 = (int *)(*(int *)(param_1 + 0x5c) + 8);
      *piVar1 = *piVar1 + param_3;
      if (puVar4 + 2 != (undefined4 *)0x0) {
        FUN_0170c6f0(puVar4 + 2,param_2,param_3);
        if (*(code **)(param_1 + 0x3038) == (code *)0x0) {
          return 0;
        }
        iVar5 = (**(code **)(param_1 + 0x3038))(param_1,param_2,param_3);
        *(int *)(param_1 + 0x1615c) = iVar5;
        return iVar5;
      }
    }
    *(undefined4 *)(param_1 + 0x1615c) = 0x14;
    return 0x14;
  }
  if (uVar3 == 3) {
    iVar5 = 2;
    if (*(int *)(param_1 + 0x15510) != 0) {
      iVar5 = 0;
    }
    FUN_005bde90(acStack_14,"\r\n%lX\r\n" + iVar5,param_3);
    pcVar6 = acStack_14;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iVar5 = (**(code **)(param_1 + 0x3014))(param_1,acStack_14,(int)pcVar6 - (int)(acStack_14 + 1));
    *(int *)(param_1 + 0x1615c) = iVar5;
    if (iVar5 != 0) {
      return iVar5;
    }
    *(int *)(param_1 + 0x15510) = *(int *)(param_1 + 0x15510) + param_3;
  }
  iVar5 = (**(code **)(param_1 + 0x3014))(param_1,param_2,param_3);
  *(int *)(param_1 + 0x1615c) = iVar5;
  return iVar5;
}



/* FUNCTION 4980 ; VA 0x005b5270 ; FUN_005b5270 */

void FUN_005b5270(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iStack_8;
  
  puVar4 = (undefined4 *)(param_1 + 0x68);
  iStack_8 = 1999;
  do {
    puVar3 = (undefined4 *)*puVar4;
    while (puVar3 != (undefined4 *)0x0) {
      puVar2 = (undefined4 *)puVar3[5];
      while (puVar2 != (undefined4 *)0x0) {
        puVar1 = (undefined4 *)*puVar2;
        FUN_017168b0(puVar2);
        puVar2 = puVar1;
      }
      puVar2 = (undefined4 *)*puVar3;
      FUN_017168b0(puVar3);
      puVar3 = puVar2;
    }
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
    iStack_8 = iStack_8 + -1;
  } while (iStack_8 != 0);
  return;
}



/* FUNCTION 4981 ; VA 0x005b52e0 ; FUN_005b52e0 */

void FUN_005b52e0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  
  puVar7 = *(undefined4 **)(param_1 + 0x58);
  while (puVar7 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar7;
    FUN_017168b0(puVar7);
    puVar7 = puVar1;
  }
  puVar7 = *(undefined4 **)(param_1 + 0x5c);
  *(undefined4 *)(param_1 + 0x58) = 0;
  while (puVar7 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar7[1];
    while (puVar1 != (undefined4 *)0x0) {
      puVar2 = (undefined4 *)*puVar1;
      FUN_017168b0(puVar1);
      puVar1 = puVar2;
    }
    *(undefined4 *)(param_1 + 0x5c) = *puVar7;
    FUN_017168b0(puVar7);
    puVar7 = *(undefined4 **)(param_1 + 0x5c);
  }
  puVar7 = *(undefined4 **)(param_1 + 0x154fc);
  while (puVar7 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar7;
    if (puVar7[1] != 0) {
      FUN_017168b0(puVar7[1]);
    }
    FUN_017168b0(puVar7);
    puVar7 = puVar1;
  }
  *(undefined4 *)(param_1 + 0x154fc) = 0;
  if (*(int *)(param_1 + 0x30a8) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0x30a8));
  }
  piVar6 = *(int **)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x30a8) = 0;
  *(undefined4 *)(param_1 + 0x30ac) = 0;
  *(undefined4 *)(param_1 + 0x30b0) = 0;
  if (piVar6 != (int *)0x0) {
    if (*piVar6 != 0) {
      puVar4 = *(undefined1 **)(param_1 + 0x28);
      do {
        puVar3 = (undefined1 *)piVar6[3];
        if (puVar3 != (undefined1 *)0x0) {
          if (puVar4 == puVar3) {
            *(undefined1 **)(param_1 + 0x28) = &DAT_018c2414;
            puVar3 = (undefined1 *)piVar6[3];
          }
          FUN_017168b0(puVar3);
          piVar6[3] = 0;
        }
        puVar4 = *(undefined1 **)(param_1 + 0x28);
        if (puVar4 == (undefined1 *)piVar6[1]) {
          *(undefined1 **)(param_1 + 0x28) = &DAT_018c2414;
          puVar4 = &DAT_018c2414;
        }
        piVar6 = piVar6 + 4;
      } while (*piVar6 != 0);
      piVar6 = *(int **)(param_1 + 0x54);
    }
    FUN_017168b0(piVar6);
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  iVar5 = *(int *)(param_1 + 0x161b0);
  while (iVar5 != 0) {
    iVar5 = **(int **)(param_1 + 0x161b0);
    FUN_017168b0(*(int **)(param_1 + 0x161b0));
    *(int *)(param_1 + 0x161b0) = iVar5;
  }
  puVar7 = *(undefined4 **)(param_1 + 0x2fa4);
  while (puVar7 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar7;
    FUN_017168b0(puVar7);
    puVar7 = puVar1;
  }
  *(undefined4 *)(param_1 + 0x2fa4) = 0;
  *(undefined2 *)(param_1 + 0x2fa8) = 0;
  puVar7 = (undefined4 *)(param_1 + 0x1fa4);
  for (iVar5 = 0x400; iVar5 != 0; iVar5 = iVar5 + -1) {
    *puVar7 = 0;
    puVar7 = puVar7 + 1;
  }
  FUN_005b5270(param_1);
  return;
}



/* FUNCTION 4982 ; VA 0x005b5480 ; FUN_005b5480 */

uint FUN_005b5480(int param_1)

{
  char cVar1;
  byte bVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  
  uVar4 = *(uint *)(param_1 + 0x3094);
  if (uVar4 == 0) {
    if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
       (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
      return 0xffffffff;
    }
    uVar4 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
  }
  else {
    if (uVar4 == 0xffffffff) {
      return 0xffffffff;
    }
    *(undefined4 *)(param_1 + 0x3094) = 0;
  }
  if (uVar4 == 0xffffffff) {
    return 0xffffffff;
  }
LAB_005b54f0:
  if (*(short *)(param_1 + 0x3098) != 0) {
    if (uVar4 != 0x5d) {
      return uVar4;
    }
    if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
       (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
      uVar4 = *(uint *)(param_1 + 0x308c);
LAB_005b57f5:
      *(uint *)(param_1 + 0x308c) = uVar4 - 1;
      return 0x5d;
    }
    cVar1 = *(char *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
    uVar4 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar4;
    if (cVar1 != ']') goto LAB_005b57f5;
    if (((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) ||
       (uVar4 = *(uint *)(param_1 + 0x308c), *(char *)(uVar4 + 0x30b4 + param_1) != '>')) {
      *(undefined4 *)(param_1 + 0x3094) = 0x5d;
      return 0x5d;
    }
    *(undefined2 *)(param_1 + 0x3098) = 0;
    if (uVar4 < *(uint *)(param_1 + 0x3090)) {
LAB_005b5594:
      uVar4 = uVar4 + 1;
      *(uint *)(param_1 + 0x308c) = uVar4;
    }
    else {
      iVar3 = FUN_005bac80(param_1);
      uVar4 = *(uint *)(param_1 + 0x308c);
      if (iVar3 == 0) goto LAB_005b5594;
    }
    if ((uVar4 < *(uint *)(param_1 + 0x3090)) || (iVar3 = FUN_005bac80(param_1), iVar3 == 0)) {
      uVar4 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
    }
    else {
      uVar4 = 0xffffffff;
    }
  }
  switch(uVar4) {
  case 0x22:
    return 0xfffffffb;
  default:
    return uVar4;
  case 0x26:
    uVar4 = FUN_005b2b10(param_1);
    return uVar4 | 0x80000000;
  case 0x27:
    return 0xfffffffa;
  case 0x3c:
    uVar4 = *(uint *)(param_1 + 0x308c);
    break;
  case 0x3e:
    return 0xfffffffc;
  }
  do {
    if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
      uVar4 = *(uint *)(param_1 + 0x308c);
      goto LAB_005b5820;
    }
    uVar6 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    uVar4 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar4;
  } while (uVar6 < 0x21);
  if (((uVar6 != 0x21) && (uVar6 != 0x3f)) && (uVar6 != 0x25)) {
    if (uVar6 == 0x2f) {
      return 0xfffffffd;
    }
LAB_005b5820:
    *(uint *)(param_1 + 0x308c) = uVar4 - 1;
    return 0xfffffffe;
  }
  iVar3 = 1;
  if (uVar6 != 0x21) {
    if (uVar6 == 0x3f) {
      uVar6 = FUN_005b5d90(param_1);
    }
LAB_005b5767:
    if (uVar6 == 0xffffffff) {
      return 0xffffffff;
    }
    do {
      if (uVar6 == 0x3c) {
        iVar3 = iVar3 + 1;
      }
      else if ((uVar6 == 0x3e) && (iVar3 = iVar3 + -1, iVar3 < 1)) goto LAB_005b57b8;
      if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
         (iVar5 = FUN_005bac80(param_1), iVar5 != 0)) {
        return 0xffffffff;
      }
      uVar6 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
    } while( true );
  }
  if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar5 = FUN_005bac80(param_1), iVar5 != 0)) {
    return 0xffffffff;
  }
  uVar6 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
  uVar4 = *(int *)(param_1 + 0x308c) + 1;
  *(uint *)(param_1 + 0x308c) = uVar4;
  if (uVar6 != 0x5b) {
    if (uVar6 == 0x2d) {
      if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar5 = FUN_005bac80(param_1), iVar5 != 0)) {
        return 0xffffffff;
      }
      uVar6 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
      uVar4 = *(int *)(param_1 + 0x308c) + 1;
      *(uint *)(param_1 + 0x308c) = uVar4;
      if (uVar6 == 0x2d) {
        do {
          do {
            if ((*(uint *)(param_1 + 0x3090) <= uVar4) &&
               (iVar5 = FUN_005bac80(param_1), iVar5 != 0)) {
              return 0xffffffff;
            }
            cVar1 = *(char *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
            uVar4 = *(int *)(param_1 + 0x308c) + 1;
            *(uint *)(param_1 + 0x308c) = uVar4;
          } while (cVar1 != '-');
          if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar5 = FUN_005bac80(param_1), iVar5 != 0))
          {
            return 0xffffffff;
          }
          cVar1 = *(char *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
          uVar4 = *(int *)(param_1 + 0x308c) + 1;
          *(uint *)(param_1 + 0x308c) = uVar4;
        } while (cVar1 != '-');
        uVar6 = 0x2d;
      }
    }
    goto LAB_005b5767;
  }
  do {
    if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
      return 0xffffffff;
    }
    cVar1 = *(char *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
    uVar4 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar4;
  } while (cVar1 != '[');
  *(undefined2 *)(param_1 + 0x3098) = 1;
  goto LAB_005b57be;
LAB_005b57b8:
  uVar4 = *(uint *)(param_1 + 0x308c);
LAB_005b57be:
  if ((*(uint *)(param_1 + 0x3090) <= uVar4) && (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
    return 0xffffffff;
  }
  bVar2 = *(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
  *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
  uVar4 = (uint)bVar2;
  goto LAB_005b54f0;
}



/* FUNCTION 4983 ; VA 0x005b58c0 ; FUN_005b58c0 */

undefined * FUN_005b58c0(int param_1,char *param_2,undefined4 param_3)

{
  short sVar1;
  undefined *puVar2;
  
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    puVar2 = (undefined *)(param_1 + 0x134b4);
    do {
      param_2 = (char *)FUN_005b3420(puVar2,0x400,param_2,&DAT_018c3b00);
      sVar1 = FUN_005bdc80(puVar2,param_3);
      if (*param_2 == '=') {
        param_2 = (char *)FUN_005b3420(puVar2,0x400,param_2 + 1,&DAT_018c3b04);
      }
      else {
        *puVar2 = 0;
      }
      if (sVar1 == 0) {
        return puVar2;
      }
    } while (*param_2 != '\0');
  }
  return (undefined *)0x0;
}



/* FUNCTION 4984 ; VA 0x005b5940 ; FUN_005b5940 */

int FUN_005b5940(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  char *pcVar5;
  undefined4 uVar6;
  int iVar7;
  char cVar8;
  uint uVar9;
  char *pcVar10;
  bool bVar11;
  uint uStack_14;
  char *pcStack_10;
  uint uStack_c;
  char *pcStack_8;
  
  iVar7 = param_1;
  uVar9 = 0;
  pcVar10 = (char *)0x0;
  pcStack_10 = (char *)0x0;
  uStack_14 = 0;
  if ((*(uint *)(param_1 + 8) & 0x100) == 0) {
    return 0;
  }
  iVar2 = *(int *)(param_1 + 0x161ac);
  if (iVar2 == 0) {
    iVar2 = FUN_005b68d0(param_1);
    if (iVar2 != 0) {
      return 0;
    }
    iVar2 = *(int *)(param_1 + 0x161ac);
  }
  else if ((iVar2 != *(int *)(param_1 + 0x161a8)) && (*(code **)(param_1 + 0x3060) != (code *)0x0))
  {
    iVar3 = (**(code **)(param_1 + 0x3060))
                      (param_1,param_2,*(undefined4 *)(iVar2 + 0xc),*(undefined4 *)(iVar2 + 0x10),
                       *(undefined4 *)(iVar2 + 0x20),*(undefined4 *)(iVar2 + 0x18));
    *(int *)(iVar2 + 4) = iVar3;
    if ((iVar3 == 0) && (*(int *)(param_1 + 0x1615c) != 0)) {
      return 0;
    }
  }
  param_1 = iVar2;
  if (*(int *)(param_1 + 4) == 0) {
    puVar4 = (undefined4 *)FUN_0171e1f2(0xc);
    if (puVar4 == (undefined4 *)0x0) {
LAB_005b5d71:
      *(undefined4 *)(iVar7 + 0x1615c) = 0x14;
      return 0;
    }
    *puVar4 = *(undefined4 *)(iVar7 + 0x5c);
    puVar4[1] = 0;
    puVar4[2] = 0;
    *(undefined4 **)(iVar7 + 0x5c) = puVar4;
  }
  do {
    do {
      if (*(int *)(param_1 + 4) == 0) {
        puVar4 = (undefined4 *)FUN_0171e1f2(0x408);
        if (puVar4 == (undefined4 *)0x0) goto LAB_005b5d71;
        *puVar4 = *(undefined4 *)(*(int *)(iVar7 + 0x5c) + 4);
        puVar4[1] = 0x400;
        *(undefined4 **)(*(int *)(iVar7 + 0x5c) + 4) = puVar4;
        piVar1 = (int *)(*(int *)(iVar7 + 0x5c) + 8);
        *piVar1 = *piVar1 + 0x400;
        pcStack_8 = (char *)(puVar4 + 2);
        if (pcStack_8 == (char *)0x0) goto LAB_005b5d71;
      }
      else {
        pcStack_8 = (char *)(iVar7 + 0x134b4);
      }
      uStack_c = 0;
      do {
        if (pcVar10 == (char *)0x0) {
          if ((short)uStack_14 == 0) {
            if ((*(uint *)(iVar7 + 0x3090) <= *(uint *)(iVar7 + 0x308c)) &&
               (iVar2 = FUN_005bac80(iVar7), iVar2 != 0)) goto LAB_005b5d5e;
            uVar9 = (uint)*(byte *)(*(int *)(iVar7 + 0x308c) + 0x30b4 + iVar7);
            *(int *)(iVar7 + 0x308c) = *(int *)(iVar7 + 0x308c) + 1;
            if (uVar9 == 0xd) goto LAB_005b5aa7;
          }
          else {
LAB_005b5aa7:
            pcStack_10 = (char *)(iVar7 + 0x130b4);
            FUN_0170d1f0(iVar7 + 0x130b8,0,0x3fc);
            builtin_strncpy(pcStack_10,"\n--",4);
            pcVar5 = pcStack_10;
            if (*(int *)(iVar7 + 0x1619c) != 0) {
              FUN_01723cc0(pcStack_10,*(int *)(iVar7 + 0x1619c),0x3fc);
            }
            do {
              pcVar10 = pcVar5;
              uVar9 = *(uint *)(iVar7 + 0x3094);
              if (uVar9 == 0) {
                if ((*(uint *)(iVar7 + 0x308c) < *(uint *)(iVar7 + 0x3090)) ||
                   (iVar2 = FUN_005bac80(iVar7), iVar2 == 0)) {
                  uVar9 = (uint)*(byte *)(*(int *)(iVar7 + 0x308c) + 0x30b4 + iVar7);
                  *(int *)(iVar7 + 0x308c) = *(int *)(iVar7 + 0x308c) + 1;
                }
                else {
                  uVar9 = 0xffffffff;
                }
              }
              else if (uVar9 != 0xffffffff) {
                *(undefined4 *)(iVar7 + 0x3094) = 0;
              }
              pcVar5 = pcVar10 + 1;
            } while (uVar9 == (int)*pcVar10);
            if (uVar9 == 0xffffffff) {
LAB_005b5d5e:
              *(undefined4 *)(iVar7 + 0x1615c) = 0xffffffff;
              return 0;
            }
            if (*pcVar10 == '\0') goto LAB_005b5bd3;
            *pcVar10 = (char)uVar9;
            bVar11 = uVar9 == 0xd;
            uVar9 = 0xd;
            uStack_14 = (uint)bVar11;
            pcVar10 = pcVar10 + (-iVar7 - uStack_14) + -0x130b3;
          }
          cVar8 = (char)uVar9;
        }
        else {
          cVar8 = *pcStack_10;
          pcStack_10 = pcStack_10 + 1;
          pcVar10 = pcVar10 + -1;
        }
        pcVar5 = pcStack_8 + 1;
        *pcStack_8 = cVar8;
        uStack_c = uStack_c + 1;
        pcStack_8 = pcVar5;
      } while (uStack_c < 0x400);
    } while ((*(int *)(param_1 + 4) == 0) || (*(code **)(iVar7 + 0x3070) == (code *)0x0));
    iVar2 = (**(code **)(iVar7 + 0x3070))(iVar7,*(int *)(param_1 + 4),iVar7 + 0x134b4,uStack_c);
    *(int *)(iVar7 + 0x1615c) = iVar2;
  } while (iVar2 == 0);
LAB_005b5bd3:
  *pcStack_8 = '\0';
  if (*(int *)(param_1 + 4) == 0) {
    iVar2 = *(int *)(iVar7 + 0x5c);
    if (*(int *)(iVar2 + 4) != 0) {
      *(int *)(iVar2 + 8) =
           *(int *)(iVar2 + 8) + ((uStack_c + 1) - *(int *)(*(int *)(iVar2 + 4) + 4));
      *(uint *)(*(int *)(*(int *)(iVar7 + 0x5c) + 4) + 4) = uStack_c + 1;
      iVar2 = *(int *)(iVar7 + 0x5c);
    }
    *(int *)(param_1 + 8) = *(int *)(iVar2 + 8) + -1;
    uVar6 = FUN_005bbc60(iVar7,0,0);
    *(undefined4 *)(param_1 + 4) = uVar6;
  }
  else {
    if ((*(int *)(iVar7 + 0x1615c) == 0) && (*(code **)(iVar7 + 0x3070) != (code *)0x0)) {
      uVar6 = (**(code **)(iVar7 + 0x3070))(iVar7,*(int *)(param_1 + 4),iVar7 + 0x134b4,uStack_c);
      *(undefined4 *)(iVar7 + 0x1615c) = uVar6;
    }
    if (*(code **)(iVar7 + 0x3068) != (code *)0x0) {
      (**(code **)(iVar7 + 0x3068))(iVar7,*(undefined4 *)(param_1 + 4));
    }
    if (*(int *)(iVar7 + 0x1615c) != 0) {
      return 0;
    }
  }
  FUN_005bb5d0(iVar7,param_1);
  if (uVar9 != 0x2d) goto joined_r0x005b5cbf;
  iVar2 = FUN_005b5fd0(iVar7);
  if (iVar2 == 0x2d) {
    *(uint *)(iVar7 + 8) = *(uint *)(iVar7 + 8) & 0xfffffeff;
    if (((*(uint *)(iVar7 + 8) & 0x10000000) != 0) && (iVar7 = FUN_005b4750(iVar7), iVar7 != 0)) {
      return 0;
    }
  }
  else {
LAB_005b5cc1:
    do {
      if ((uVar9 == 0xffffffff) || (0x20 < uVar9)) {
        if (uVar9 != 0xd) goto LAB_005b5d4b;
        break;
      }
      uVar9 = *(uint *)(iVar7 + 0x3094);
      if (uVar9 == 0) {
        if ((*(uint *)(iVar7 + 0x3090) <= *(uint *)(iVar7 + 0x308c)) &&
           (iVar2 = FUN_005bac80(iVar7), iVar2 != 0)) {
          uVar9 = 0xffffffff;
          goto LAB_005b5cc1;
        }
        uVar9 = (uint)*(byte *)(*(int *)(iVar7 + 0x308c) + 0x30b4 + iVar7);
        *(int *)(iVar7 + 0x308c) = *(int *)(iVar7 + 0x308c) + 1;
      }
      else if (uVar9 != 0xffffffff) {
        *(undefined4 *)(iVar7 + 0x3094) = 0;
      }
joined_r0x005b5cbf:
    } while (uVar9 != 0xd);
    iVar2 = FUN_005b5fd0(iVar7);
    if (iVar2 != 10) {
LAB_005b5d4b:
      *(undefined4 *)(iVar7 + 0x1615c) = 0x24;
      return 0;
    }
    iVar7 = FUN_005b68d0(iVar7);
    if (iVar7 != 0) {
      return 0;
    }
  }
  return param_1;
}



/* FUNCTION 4985 ; VA 0x005b5d90 ; FUN_005b5d90 */

undefined4 FUN_005b5d90(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_48 [64];
  undefined *puStack_8;
  
  puStack_8 = auStack_48;
  iVar4 = 0x40;
  uVar1 = FUN_005b5fd0(param_1);
LAB_005b5db2:
  while( true ) {
    if ((uVar1 == 0xffffffff) || (uVar1 == 0x3f)) goto LAB_005b5e24;
    iVar4 = iVar4 + -1;
    if (0 < iVar4) {
      if (uVar1 < 0x21) {
        uVar1 = 0x20;
      }
      *puStack_8 = (char)uVar1;
      puStack_8 = puStack_8 + 1;
    }
    uVar1 = *(uint *)(param_1 + 0x3094);
    if (uVar1 == 0) break;
    if (uVar1 == 0xffffffff) goto LAB_005b5e24;
    *(undefined4 *)(param_1 + 0x3094) = 0;
  }
  if (*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) {
    iVar2 = FUN_005bac80(param_1);
    if (iVar2 != 0) {
      uVar1 = 0xffffffff;
LAB_005b5e24:
      *puStack_8 = 0;
      iVar4 = FUN_01723e00(auStack_48,&DAT_018c2f58,4);
      if (iVar4 == 0) {
        iVar4 = FUN_0170de40(auStack_48," encoding=");
        if ((iVar4 != 0) && (*(char *)(iVar4 + 10) != '\0')) {
          iVar4 = iVar4 + 0xb;
          iVar2 = FUN_005bdc80(iVar4,"iso-8859-1*");
          if (iVar2 != 0) {
            iVar2 = FUN_005bdc80(iVar4,"latin1*");
            if (iVar2 != 0) {
              iVar4 = FUN_005bdc80(iVar4,"utf-8*");
              if (iVar4 == 0) {
                *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) & 0xffffffdf;
              }
              goto LAB_005b5e9f;
            }
          }
          *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) | 0x20;
        }
      }
LAB_005b5e9f:
      if (uVar1 != 0xffffffff) {
        uVar3 = FUN_005b5fd0(param_1);
        return uVar3;
      }
      return 0xffffffff;
    }
  }
  uVar1 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
  *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
  goto LAB_005b5db2;
}



/* FUNCTION 4986 ; VA 0x005b5ec0 ; FUN_005b5ec0 */

undefined4 FUN_005b5ec0(int param_1,undefined *param_2,uint param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  if (param_3 != 0) {
    do {
      iVar1 = FUN_005b5480(param_1);
      switch(iVar1) {
      case 9:
      case 10:
      case 0xd:
      case 0x20:
      case 0x2f:
        if (param_4 == 0x20) goto LAB_005b5f4d;
      default:
        if (iVar1 == -1) {
          *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
          return 0xffffffff;
        }
        *param_2 = (char)iVar1;
        break;
      case -6:
        if (iVar1 == param_4) goto LAB_005b5f53;
        *param_2 = 0x27;
        break;
      case -5:
        if (iVar1 == param_4) goto LAB_005b5f53;
        *param_2 = 0x22;
        break;
      case -4:
        if (param_4 == 0x20) {
LAB_005b5f4d:
          *(int *)(param_1 + 0x3094) = iVar1;
LAB_005b5f53:
          *param_2 = 0;
          return 0;
        }
        *param_2 = 0x3e;
        break;
      case -3:
        *param_2 = 0x3c;
        *(undefined4 *)(param_1 + 0x3094) = 0x2f;
        break;
      case -2:
        *param_2 = 0x3c;
      }
      uVar2 = uVar2 + 1;
      param_2 = param_2 + 1;
    } while (uVar2 < param_3);
  }
  *(undefined4 *)(param_1 + 0x1615c) = 0x14;
  return 0x14;
}



/* FUNCTION 4987 ; VA 0x005b5fd0 ; FUN_005b5fd0 */

uint FUN_005b5fd0(int param_1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = *(uint *)(param_1 + 0x3094);
  if (uVar2 == 0) {
    if (*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) {
      iVar1 = FUN_005bac80(param_1);
      if (iVar1 != 0) {
        return 0xffffffff;
      }
    }
    uVar2 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
    *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
  }
  else if (uVar2 != 0xffffffff) {
    *(undefined4 *)(param_1 + 0x3094) = 0;
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 4988 ; VA 0x005b6030 ; FUN_005b6030 */

int FUN_005b6030(int param_1)

{
  int *piVar1;
  undefined uVar2;
  byte bVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  
  bVar3 = *(byte *)(param_1 + 0x1617c);
  while ((bVar3 & 1) != 0) {
    iVar6 = FUN_005b65b0(param_1);
    if (iVar6 != 0) goto LAB_005b6216;
    iVar6 = FUN_005b8370(param_1,*(undefined4 *)(param_1 + 0x16170));
    if (iVar6 != 0) goto LAB_005b64c5;
    bVar3 = *(byte *)(param_1 + 0x1617c);
  }
  iVar6 = FUN_005b8370(param_1,(*(int *)(param_1 + 0x16170) + 3U & 0xfffffffc) -
                               (((*(int *)(param_1 + 0x30a0) -
                                 (uint)(*(int *)(param_1 + 0x3094) != 0)) -
                                *(int *)(param_1 + 0x3090)) + *(int *)(param_1 + 0x308c)));
  if (iVar6 == 0) {
    iVar6 = FUN_005b65b0(param_1);
    while (iVar6 == 0) {
      if (*(code **)(param_1 + 0x3048) == (code *)0x0) {
LAB_005b6104:
        if ((*(byte *)(param_1 + 0x1617c) & 1) == 0) {
          uVar10 = FUN_005b64e0(param_1,*(undefined4 *)(param_1 + 0x16170));
          *(undefined4 *)(param_1 + 0x16180) = uVar10;
        }
        else {
          uVar10 = *(undefined4 *)(param_1 + 0x16184);
          uVar4 = *(undefined4 *)(param_1 + 0x16188);
          uVar5 = *(undefined4 *)(param_1 + 0x1618c);
          puVar7 = (undefined4 *)FUN_0171e1f2(0xc);
          if (puVar7 == (undefined4 *)0x0) {
            return 0x14;
          }
          *puVar7 = *(undefined4 *)(param_1 + 0x5c);
          puVar7[1] = 0;
          puVar7[2] = 0;
          *(undefined4 **)(param_1 + 0x5c) = puVar7;
          while( true ) {
            iVar6 = *(int *)(param_1 + 0x16170);
            puVar7 = (undefined4 *)FUN_0171e1f2(iVar6 + 8);
            if (puVar7 == (undefined4 *)0x0) goto LAB_005b64af;
            *puVar7 = *(undefined4 *)(*(int *)(param_1 + 0x5c) + 4);
            puVar7[1] = iVar6;
            *(undefined4 **)(*(int *)(param_1 + 0x5c) + 4) = puVar7;
            piVar1 = (int *)(*(int *)(param_1 + 0x5c) + 8);
            *piVar1 = *piVar1 + iVar6;
            puVar7 = puVar7 + 2;
            if (puVar7 == (undefined4 *)0x0) goto LAB_005b64af;
            for (iVar6 = *(int *)(param_1 + 0x16170); iVar6 != 0; iVar6 = iVar6 + -1) {
              if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
                 (iVar8 = FUN_005bac80(param_1), iVar8 != 0)) goto LAB_005b64c5;
              uVar2 = *(undefined *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
              *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
              *(undefined *)puVar7 = uVar2;
              puVar7 = (undefined4 *)((int)puVar7 + 1);
            }
            iVar6 = FUN_005b8370(param_1,-*(int *)(param_1 + 0x16170) & 3);
            if (iVar6 != 0) goto LAB_005b64c5;
            if ((*(byte *)(param_1 + 0x1617c) & 1) == 0) break;
            iVar6 = FUN_005b65b0(param_1);
            if (iVar6 != 0) goto LAB_005b6216;
          }
          iVar6 = *(int *)(*(int *)(param_1 + 0x5c) + 8);
          *(int *)(*(int *)(param_1 + 0x5c) + 8) = iVar6 + 1;
          *(int *)(param_1 + 0x16170) = iVar6;
          iVar6 = FUN_005bbc60(param_1,0,0);
          *(int *)(param_1 + 0x16180) = iVar6;
          if (iVar6 == 0) {
LAB_005b6216:
            return *(int *)(param_1 + 0x1615c);
          }
          *(undefined *)(iVar6 + *(int *)(param_1 + 0x16170)) = 0;
          *(undefined4 *)(param_1 + 0x16184) = uVar10;
          *(undefined4 *)(param_1 + 0x16188) = uVar4;
          *(undefined4 *)(param_1 + 0x1618c) = uVar5;
        }
      }
      else {
        iVar6 = (**(code **)(param_1 + 0x3048))
                          (param_1,*(undefined4 *)(param_1 + 0x16184),
                           *(undefined4 *)(param_1 + 0x16188),*(undefined4 *)(param_1 + 0x1618c));
        *(int *)(param_1 + 0x16180) = iVar6;
        if (iVar6 == 0) {
          if (*(int *)(param_1 + 0x1615c) != 0) {
            return *(int *)(param_1 + 0x1615c);
          }
          goto LAB_005b6104;
        }
        uVar10 = *(undefined4 *)(param_1 + 0x16184);
        uVar4 = *(undefined4 *)(param_1 + 0x16188);
        uVar5 = *(undefined4 *)(param_1 + 0x1618c);
LAB_005b6240:
        uVar11 = *(uint *)(param_1 + 0x16170);
        while( true ) {
          uVar9 = *(int *)(param_1 + 0x3090) - *(int *)(param_1 + 0x308c);
          uVar12 = uVar11;
          if (uVar9 <= uVar11) {
            uVar12 = uVar9;
          }
          iVar6 = (**(code **)(param_1 + 0x3058))
                            (param_1,*(undefined4 *)(param_1 + 0x16180),
                             *(int *)(param_1 + 0x308c) + 0x30b4 + param_1,uVar12);
          *(int *)(param_1 + 0x1615c) = iVar6;
          if (iVar6 != 0) goto LAB_005b62ec;
          uVar11 = uVar11 - uVar12;
          if (uVar11 == 0) break;
          iVar6 = FUN_005bac80(param_1);
          if (iVar6 != 0) goto LAB_005b629c;
        }
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + uVar12;
LAB_005b62ec:
        iVar6 = FUN_005b8370(param_1,-*(int *)(param_1 + 0x16170) & 3);
        if (iVar6 == 0) {
          if (((*(byte *)(param_1 + 0x1617c) & 1) == 0) ||
             (iVar6 = FUN_005b65b0(param_1), iVar6 != 0)) goto LAB_005b62a6;
          goto LAB_005b6240;
        }
LAB_005b629c:
        *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
LAB_005b62a6:
        if (*(code **)(param_1 + 0x3050) != (code *)0x0) {
          (**(code **)(param_1 + 0x3050))(param_1,*(undefined4 *)(param_1 + 0x16180));
        }
        *(undefined4 *)(param_1 + 0x16184) = uVar10;
        *(undefined4 *)(param_1 + 0x16188) = uVar4;
        *(undefined4 *)(param_1 + 0x16170) = 0;
        *(undefined4 *)(param_1 + 0x1618c) = uVar5;
      }
      uVar10 = *(undefined4 *)(param_1 + 0x16170);
      uVar4 = *(undefined4 *)(param_1 + 0x16180);
      if (*(code **)(param_1 + 0x3030) == (code *)0x0) {
        puVar7 = (undefined4 *)FUN_0171e1f2(0x30);
        if (puVar7 == (undefined4 *)0x0) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x14;
          goto LAB_005b64af;
        }
        *(undefined2 *)((int)puVar7 + 0x26) = 0xc0de;
        puVar7[10] = *(undefined4 *)(param_1 + 100);
        puVar7[0xb] = 0x28;
        *(undefined4 **)(param_1 + 100) = puVar7 + 10;
      }
      else {
        puVar7 = (undefined4 *)(**(code **)(param_1 + 0x3030))(param_1,0x24);
      }
      *(undefined2 *)(param_1 + 0x1550a) = 1;
      if (puVar7 == (undefined4 *)0x0) {
LAB_005b64af:
        *(undefined4 *)(param_1 + 0x1615c) = 0x14;
        return 0x14;
      }
      *puVar7 = 0;
      puVar7[1] = uVar4;
      puVar7[2] = uVar10;
      puVar7[3] = 0;
      puVar7[4] = 0;
      puVar7[5] = 0;
      puVar7[6] = 0;
      puVar7[7] = 0;
      puVar7[8] = 0;
      if (*(int *)(param_1 + 0x16194) == 0) {
        *(undefined4 **)(param_1 + 0x16194) = puVar7;
      }
      if (*(undefined4 **)(param_1 + 0x16198) != (undefined4 *)0x0) {
        **(undefined4 **)(param_1 + 0x16198) = puVar7;
      }
      *(undefined4 **)(param_1 + 0x16198) = puVar7;
      if (puVar7 == (undefined4 *)0x0) goto LAB_005b64af;
      puVar7[3] = *(undefined4 *)(param_1 + 0x16184);
      puVar7[4] = *(undefined4 *)(param_1 + 0x16188);
      puVar7[5] = *(undefined4 *)(param_1 + 0x1618c);
      if (*(int *)(param_1 + 0x1615c) != 0) {
        return *(int *)(param_1 + 0x1615c);
      }
      FUN_005bb5d0(param_1,puVar7);
      iVar6 = FUN_005b65b0(param_1);
    }
    iVar6 = *(int *)(param_1 + 0x1615c);
    if (iVar6 == 0x23) {
      *(undefined4 *)(param_1 + 0x1615c) = 0;
      return 0;
    }
  }
  else {
LAB_005b64c5:
    *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
    iVar6 = -1;
  }
  return iVar6;
}



/* FUNCTION 4989 ; VA 0x005b64e0 ; FUN_005b64e0 */

undefined * FUN_005b64e0(int param_1,int param_2)

{
  undefined uVar1;
  undefined *puVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  
  iVar4 = param_2;
  puVar2 = (undefined *)0x0;
  if (param_2 != 0) {
    puVar2 = (undefined *)FUN_005b7fc0(param_1,param_2 + 1);
    if (puVar2 == (undefined *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return (undefined *)0x0;
    }
    puVar5 = puVar2;
    if (param_2 != 0) {
      do {
        if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
           (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
          return (undefined *)0x0;
        }
        uVar1 = *(undefined *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        *puVar5 = uVar1;
        puVar5 = puVar5 + 1;
        param_2 = param_2 + -1;
      } while (param_2 != 0);
    }
    *puVar5 = 0;
    iVar4 = FUN_005b8370(param_1,-iVar4 & 3);
    *(int *)(param_1 + 0x1615c) = iVar4;
    if (iVar4 != 0) {
      return (undefined *)0x0;
    }
  }
  return puVar2;
}



/* FUNCTION 4990 ; VA 0x005b65b0 ; FUN_005b65b0 */

int FUN_005b65b0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  byte *pbVar4;
  byte abStack_10 [4];
  undefined uStack_c;
  undefined uStack_b;
  undefined uStack_a;
  undefined uStack_9;
  undefined uStack_8;
  undefined uStack_7;
  undefined uStack_6;
  undefined uStack_5;
  
  if ((*(byte *)(param_1 + 8) & 0x80) == 0) {
    *(undefined4 *)(param_1 + 0x1615c) = 0x23;
    return 0x23;
  }
  if ((*(int *)(param_1 + 0x16178) == 0) && (*(int *)(param_1 + 0x16174) == 0)) {
    pbVar4 = abStack_10;
    iVar3 = 0xc;
    do {
      iVar1 = FUN_005b5fd0(param_1);
      if (iVar1 == -1) goto LAB_005b673f;
      *pbVar4 = (byte)iVar1;
      iVar3 = iVar3 + -1;
      pbVar4 = pbVar4 + 1;
    } while (0 < iVar3);
    if ((abStack_10[0] & 0xf8) != 8) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x22;
      return 0x22;
    }
    *(byte *)(param_1 + 0x1617c) = abStack_10[1] & 0xf0 | abStack_10[0] & 7;
    *(uint *)(param_1 + 0x16170) = CONCAT31(CONCAT21(CONCAT11(uStack_8,uStack_7),uStack_6),uStack_5)
    ;
    iVar3 = FUN_005b64e0(param_1,CONCAT11(abStack_10[2],abStack_10[3]));
    *(int *)(param_1 + 0x1618c) = iVar3;
    if ((iVar3 == 0) && (*(int *)(param_1 + 0x1615c) != 0)) {
      return *(int *)(param_1 + 0x1615c);
    }
    iVar3 = FUN_005b64e0(param_1,CONCAT11(uStack_c,uStack_b));
    *(int *)(param_1 + 0x16184) = iVar3;
    if ((iVar3 == 0) && (*(int *)(param_1 + 0x1615c) != 0)) {
      return *(int *)(param_1 + 0x1615c);
    }
    iVar3 = FUN_005b64e0(param_1,CONCAT11(uStack_a,uStack_9));
    *(int *)(param_1 + 0x16188) = iVar3;
    if ((iVar3 == 0) && (*(int *)(param_1 + 0x1615c) != 0)) {
      return *(int *)(param_1 + 0x1615c);
    }
    if ((*(byte *)(param_1 + 0x1617c) & 2) != 0) {
      *(uint *)(param_1 + 8) = *(uint *)(param_1 + 8) & 0xffffff7f;
      return 0;
    }
  }
  else {
    iVar3 = FUN_005b8370(param_1,*(int *)(param_1 + 0x16170) -
                                 (((*(int *)(param_1 + 0x30a0) -
                                   (uint)(*(int *)(param_1 + 0x3094) != 0)) -
                                  *(int *)(param_1 + 0x3090)) + *(int *)(param_1 + 0x308c)));
    if (iVar3 != 0) {
LAB_005b673f:
      *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
      return -1;
    }
    uVar2 = FUN_005b5fd0(param_1);
    *(undefined4 *)(param_1 + 0x3094) = uVar2;
  }
  return 0;
}



/* FUNCTION 4991 ; VA 0x005b6770 ; FUN_005b6770 */

undefined4 FUN_005b6770(int param_1,undefined *param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  uVar2 = 0;
  iVar4 = param_3;
joined_r0x005b6784:
  do {
    iVar1 = iVar4 + -1;
    if (iVar1 < 1) {
LAB_005b67ec:
      if (uVar2 != 10) {
        uVar2 = *(uint *)(param_1 + 0x3094);
        if (uVar2 == 0) {
          if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
             (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) goto LAB_005b684a;
          uVar2 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else if (uVar2 != 0xffffffff) {
          *(undefined4 *)(param_1 + 0x3094) = 0;
        }
        if (uVar2 != 10) {
          iVar4 = iVar1;
          if (uVar2 == 0xffffffff) {
LAB_005b684a:
            *(undefined4 *)(param_1 + 0x1615c) = 0xffffffff;
            return 0xffffffff;
          }
          goto joined_r0x005b6784;
        }
      }
    }
    else {
      uVar2 = *(uint *)(param_1 + 0x3094);
      if (uVar2 == 0) {
        if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
           (iVar3 = FUN_005bac80(param_1), iVar3 != 0)) goto LAB_005b684a;
        uVar2 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
        *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
      }
      else if (uVar2 != 0xffffffff) {
        *(undefined4 *)(param_1 + 0x3094) = 0;
      }
      if (uVar2 == 0xd) goto LAB_005b67ec;
      if (uVar2 != 10) {
        if (uVar2 == 0xffffffff) goto LAB_005b684a;
        *param_2 = (char)uVar2;
        param_2 = param_2 + 1;
        iVar4 = iVar1;
        goto joined_r0x005b6784;
      }
    }
    *param_2 = 0;
    if (((iVar4 == param_3) ||
        ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c) &&
         (iVar4 = FUN_005bac80(param_1), iVar4 != 0)))) ||
       ((uVar2 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c)), iVar4 = iVar1,
        uVar2 != 0x20 && (uVar2 != 9)))) {
      if (iVar1 < 0) {
        *(undefined4 *)(param_1 + 0x1615c) = 0x16;
        return 0x16;
      }
      return 0;
    }
  } while( true );
}



/* FUNCTION 4992 ; VA 0x005b68d0 ; FUN_005b68d0 */

undefined4 FUN_005b68d0(int param_1)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  char *pcVar6;
  byte *pbVar7;
  uint uVar8;
  undefined *puVar9;
  int iVar10;
  undefined4 uVar11;
  byte *pbVar12;
  bool bVar13;
  
  pcVar2 = (char *)(param_1 + 0x130b4);
  iVar5 = FUN_005b6770(param_1,pcVar2,0x400);
  if (iVar5 == 0) {
    while (*pcVar2 == '\0') {
      iVar5 = FUN_005b6770(param_1,pcVar2,0x400);
      if (iVar5 != 0) {
        return *(undefined4 *)(param_1 + 0x1615c);
      }
    }
    if ((*pcVar2 == '-') && (pcVar1 = pcVar2, *(char *)(param_1 + 0x130b5) == '-')) {
      do {
        pcVar6 = pcVar1;
        pcVar1 = pcVar6 + 1;
      } while (*pcVar6 != '\0');
      pcVar6 = pcVar6 + -1;
      cVar3 = *pcVar6;
      while ((-1 < cVar3 && (cVar3 < '!'))) {
        pcVar1 = pcVar6 + -1;
        pcVar6 = pcVar6 + -1;
        cVar3 = *pcVar1;
      }
      pcVar6[1] = '\0';
      pbVar7 = (byte *)(param_1 + 0x130b6);
      pbVar12 = *(byte **)(param_1 + 0x1619c);
      if (pbVar12 == (byte *)0x0) {
        uVar11 = FUN_005bd1b0(param_1,pbVar7);
        *(undefined4 *)(param_1 + 0x1619c) = uVar11;
      }
      else {
        do {
          bVar4 = *pbVar7;
          bVar13 = bVar4 < *pbVar12;
          if (bVar4 != *pbVar12) {
LAB_005b6990:
            uVar8 = -(uint)bVar13 | 1;
            goto LAB_005b6995;
          }
          if (bVar4 == 0) break;
          bVar4 = pbVar7[1];
          bVar13 = bVar4 < pbVar12[1];
          if (bVar4 != pbVar12[1]) goto LAB_005b6990;
          pbVar7 = pbVar7 + 2;
          pbVar12 = pbVar12 + 2;
        } while (bVar4 != 0);
        uVar8 = 0;
LAB_005b6995:
        if (uVar8 != 0) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x24;
          return 0x24;
        }
      }
      iVar5 = FUN_005b6770(param_1,pcVar2,0x400);
      if (iVar5 != 0) goto LAB_005b69cf;
    }
    iVar5 = FUN_005b83f0(param_1,param_1 + 0x161a8,(int *)(param_1 + 0x161ac),0,0);
    if (iVar5 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0x14;
    }
    *(undefined4 *)(iVar5 + 0xc) = 0;
    *(undefined4 *)(iVar5 + 0x10) = 0;
    *(undefined4 *)(iVar5 + 0x18) = 0;
    *(undefined4 *)(iVar5 + 0x1c) = 0;
    *(undefined4 *)(iVar5 + 0x20) = 0;
    cVar3 = *pcVar2;
    iVar5 = *(int *)(param_1 + 0x161ac);
    do {
      if (cVar3 == '\0') {
        return 0;
      }
      puVar9 = (undefined *)FUN_0170dbd0(pcVar2,0x3a);
      if (puVar9 != (undefined *)0x0) {
        *puVar9 = 0;
        do {
          pcVar1 = puVar9 + 1;
          puVar9 = puVar9 + 1;
          if (*pcVar1 == '\0') break;
        } while (*pcVar1 < '!');
        iVar10 = FUN_005bdc80(pcVar2,"Content-ID");
        if (iVar10 == 0) {
          uVar11 = FUN_005bd1b0(param_1,puVar9);
          *(undefined4 *)(iVar5 + 0xc) = uVar11;
        }
        else {
          iVar10 = FUN_005bdc80(pcVar2,"Content-Location");
          if (iVar10 == 0) {
            uVar11 = FUN_005bd1b0(param_1,puVar9);
            *(undefined4 *)(iVar5 + 0x1c) = uVar11;
          }
          else {
            iVar10 = FUN_005bdc80(pcVar2,"Content-Disposition");
            if (iVar10 == 0) {
              uVar11 = FUN_005b58c0(param_1,puVar9,&DAT_018c387c);
              uVar11 = FUN_005bd1b0(param_1,uVar11);
              *(undefined4 *)(iVar5 + 0xc) = uVar11;
            }
            else {
              iVar10 = FUN_005bdc80(pcVar2,"Content-Type");
              if (iVar10 == 0) {
                uVar11 = FUN_005bd1b0(param_1,puVar9);
                *(undefined4 *)(iVar5 + 0x10) = uVar11;
              }
              else {
                iVar10 = FUN_005bdc80(pcVar2,"Content-Description");
                if (iVar10 == 0) {
                  uVar11 = FUN_005bd1b0(param_1,puVar9);
                  *(undefined4 *)(iVar5 + 0x20) = uVar11;
                }
                else {
                  iVar10 = FUN_005bdc80(pcVar2,"Content-Transfer-Encoding");
                  if (iVar10 == 0) {
                    uVar11 = FUN_005b2f40(&DAT_018c28e0,puVar9,0);
                    *(undefined4 *)(iVar5 + 0x18) = uVar11;
                  }
                }
              }
            }
          }
        }
      }
      iVar10 = FUN_005b6770(param_1,pcVar2,0x400);
      if (iVar10 != 0) {
        return *(undefined4 *)(param_1 + 0x1615c);
      }
      cVar3 = *pcVar2;
    } while( true );
  }
LAB_005b69cf:
  return *(undefined4 *)(param_1 + 0x1615c);
}



/* FUNCTION 4993 ; VA 0x005b6b90 ; FUN_005b6b90 */

uint FUN_005b6b90(int param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar1 = *(uint *)(param_1 + 0x3094);
  if (0xff < (int)uVar1) {
    *(undefined4 *)(param_1 + 0x3094) = 0;
    return uVar1;
  }
  while( true ) {
    uVar1 = FUN_005b5480(param_1);
    if ((int)uVar1 < 0x80) {
      return uVar1;
    }
    if ((*(byte *)(param_1 + 8) & 0x20) != 0) {
      return uVar1;
    }
    if ((*(uint *)(param_1 + 0x3090) <= *(uint *)(param_1 + 0x308c)) &&
       (iVar2 = FUN_005bac80(param_1), iVar2 != 0)) break;
    uVar4 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
    uVar3 = *(int *)(param_1 + 0x308c) + 1;
    *(uint *)(param_1 + 0x308c) = uVar3;
    if (uVar4 < 0x80) goto LAB_005b6c8c;
    uVar4 = uVar4 & 0x3f;
    if ((int)uVar1 < 0xe0) {
      return (uVar1 & 0x1f) << 6 | uVar4;
    }
    if ((uVar3 < *(uint *)(param_1 + 0x3090)) || (iVar2 = FUN_005bac80(param_1), iVar2 == 0)) {
      uVar3 = (uint)*(byte *)(param_1 + 0x30b4 + *(int *)(param_1 + 0x308c));
      *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
    }
    else {
      uVar3 = 0xffffffff;
    }
    uVar3 = uVar3 & 0x3f;
    if (uVar1 != 0xef) {
      if (0xef < (int)uVar1) {
        if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
           (iVar2 = FUN_005bac80(param_1), iVar2 == 0)) {
          uVar5 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else {
          uVar5 = 0xffffffff;
        }
        uVar5 = uVar5 & 0x3f;
        if ((int)uVar1 < 0xf8) {
          return ((uVar4 | (uVar1 & 7) << 6) << 6 | uVar3) << 6 | uVar5;
        }
        if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
           (iVar2 = FUN_005bac80(param_1), iVar2 == 0)) {
          uVar6 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else {
          uVar6 = 0xffffffff;
        }
        if ((int)uVar1 < 0xfc) {
          return (((uVar4 | (uVar1 & 3) << 6) << 6 | uVar3) << 6 | uVar5) << 6 | uVar6 & 0x3f;
        }
        if ((*(uint *)(param_1 + 0x308c) < *(uint *)(param_1 + 0x3090)) ||
           (iVar2 = FUN_005bac80(param_1), iVar2 == 0)) {
          uVar7 = (uint)*(byte *)(*(int *)(param_1 + 0x308c) + 0x30b4 + param_1);
          *(int *)(param_1 + 0x308c) = *(int *)(param_1 + 0x308c) + 1;
        }
        else {
          uVar7 = 0xffffffff;
        }
        return ((((uVar4 | (uVar1 & 1) << 6) << 6 | uVar3) << 6 | uVar5) << 6 | uVar6 & 0x3f) << 6 |
               uVar7 & 0x3f;
      }
LAB_005b6ca7:
      return (uVar4 | (uVar1 & 0xf) << 6) << 6 | uVar3;
    }
    if (uVar4 != 0x3b) goto LAB_005b6ca7;
    if (uVar3 != 0x3f) {
      return uVar3 | 0xfec0;
    }
  }
  uVar3 = *(uint *)(param_1 + 0x308c);
LAB_005b6c8c:
  *(uint *)(param_1 + 0x308c) = uVar3 - 1;
  return uVar1;
}



/* FUNCTION 4994 ; VA 0x005b6bb6 ; FUN_005b6bb6 */

uint FUN_005b6bb6(void)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int unaff_EBP;
  int unaff_EDI;
  
  while( true ) {
    uVar1 = FUN_005b5480();
    if ((int)uVar1 < 0x80) {
      return uVar1;
    }
    if ((*(byte *)(unaff_EDI + 8) & 0x20) != 0) {
      return uVar1;
    }
    if ((*(uint *)(unaff_EDI + 0x3090) <= *(uint *)(unaff_EDI + 0x308c)) &&
       (iVar2 = FUN_005bac80(), iVar2 != 0)) break;
    uVar4 = (uint)*(byte *)(unaff_EDI + 0x30b4 + *(int *)(unaff_EDI + 0x308c));
    uVar3 = *(int *)(unaff_EDI + 0x308c) + 1;
    *(uint *)(unaff_EDI + 0x308c) = uVar3;
    if (uVar4 < 0x80) goto LAB_005b6c8c;
    uVar4 = uVar4 & 0x3f;
    *(uint *)(unaff_EBP + 8) = uVar4;
    if ((int)uVar1 < 0xe0) {
      return (uVar1 & 0x1f) << 6 | uVar4;
    }
    if ((uVar3 < *(uint *)(unaff_EDI + 0x3090)) || (iVar2 = FUN_005bac80(), iVar2 == 0)) {
      uVar3 = (uint)*(byte *)(unaff_EDI + 0x30b4 + *(int *)(unaff_EDI + 0x308c));
      *(int *)(unaff_EDI + 0x308c) = *(int *)(unaff_EDI + 0x308c) + 1;
    }
    else {
      uVar3 = 0xffffffff;
    }
    uVar3 = uVar3 & 0x3f;
    if (uVar1 != 0xef) {
      if (0xef < (int)uVar1) {
        if ((*(uint *)(unaff_EDI + 0x308c) < *(uint *)(unaff_EDI + 0x3090)) ||
           (iVar2 = FUN_005bac80(), iVar2 == 0)) {
          uVar4 = (uint)*(byte *)(*(int *)(unaff_EDI + 0x308c) + 0x30b4 + unaff_EDI);
          *(int *)(unaff_EDI + 0x308c) = *(int *)(unaff_EDI + 0x308c) + 1;
        }
        else {
          uVar4 = 0xffffffff;
        }
        *(uint *)(unaff_EBP + -4) = uVar4 & 0x3f;
        if ((int)uVar1 < 0xf8) {
          return ((*(uint *)(unaff_EBP + 8) | (uVar1 & 7) << 6) << 6 | uVar3) << 6 | uVar4 & 0x3f;
        }
        if ((*(uint *)(unaff_EDI + 0x308c) < *(uint *)(unaff_EDI + 0x3090)) ||
           (iVar2 = FUN_005bac80(), iVar2 == 0)) {
          uVar4 = (uint)*(byte *)(*(int *)(unaff_EDI + 0x308c) + 0x30b4 + unaff_EDI);
          *(int *)(unaff_EDI + 0x308c) = *(int *)(unaff_EDI + 0x308c) + 1;
        }
        else {
          uVar4 = 0xffffffff;
        }
        *(uint *)(unaff_EBP + -8) = uVar4 & 0x3f;
        if (0xfb < (int)uVar1) {
          if ((*(uint *)(unaff_EDI + 0x308c) < *(uint *)(unaff_EDI + 0x3090)) ||
             (iVar2 = FUN_005bac80(), iVar2 == 0)) {
            uVar4 = (uint)*(byte *)(*(int *)(unaff_EDI + 0x308c) + 0x30b4 + unaff_EDI);
            *(int *)(unaff_EDI + 0x308c) = *(int *)(unaff_EDI + 0x308c) + 1;
          }
          else {
            uVar4 = 0xffffffff;
          }
          return ((((*(uint *)(unaff_EBP + 8) | (uVar1 & 1) << 6) << 6 | uVar3) << 6 |
                  *(uint *)(unaff_EBP + -4)) << 6 | *(uint *)(unaff_EBP + -8)) << 6 | uVar4 & 0x3f;
        }
        return (((*(uint *)(unaff_EBP + 8) | (uVar1 & 3) << 6) << 6 | uVar3) << 6 |
               *(uint *)(unaff_EBP + -4)) << 6 | uVar4 & 0x3f;
      }
      uVar4 = *(uint *)(unaff_EBP + 8);
LAB_005b6ca7:
      return (uVar4 | (uVar1 & 0xf) << 6) << 6 | uVar3;
    }
    uVar4 = *(uint *)(unaff_EBP + 8);
    if (uVar4 != 0x3b) goto LAB_005b6ca7;
    if (uVar3 != 0x3f) {
      return uVar3 | 0xfec0;
    }
  }
  uVar3 = *(uint *)(unaff_EDI + 0x308c);
LAB_005b6c8c:
  *(uint *)(unaff_EDI + 0x308c) = uVar3 - 1;
  return uVar1;
}



/* FUNCTION 4995 ; VA 0x005b6df0 ; FUN_005b6df0 */

uint FUN_005b6df0(char *param_1)

{
  char cVar1;
  uint uVar2;
  
  uVar2 = 0;
  cVar1 = *param_1;
  while (cVar1 != '\0') {
    param_1 = param_1 + 1;
    uVar2 = uVar2 * 0x1003f + (int)cVar1;
    cVar1 = *param_1;
  }
  return uVar2 % 1999;
}



/* FUNCTION 4996 ; VA 0x005b6e40 ; FUN_005b6e40 */

int FUN_005b6e40(int param_1,char *param_2,int param_3,int param_4,int param_5,int param_6,
                undefined4 param_7,undefined4 param_8,code *param_9)

{
  char cVar1;
  int iVar2;
  
  *(undefined2 *)(param_1 + 0x1550a) = 0;
  if (param_3 == 0) {
    if (param_9 == (code *)0x0) {
      param_3 = FUN_005b7fc0(param_1,param_5);
    }
    else {
      param_3 = (*param_9)(param_1,param_4,param_7,param_8,&param_5);
    }
    if (param_3 != 0) {
      *(undefined2 *)(param_1 + 0x1550a) = 1;
    }
  }
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    iVar2 = FUN_005b7f30(param_1,param_2);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4ae0(param_1,param_2);
      *(int *)(iVar2 + 4) = param_4;
      *(undefined4 *)(iVar2 + 0xc) = 0;
      *(undefined4 *)(iVar2 + 0x10) = 0;
      *(undefined4 *)(iVar2 + 0x14) = 0;
      *(int *)(iVar2 + 8) = param_5;
      *(int *)(iVar2 + 0x1c) = param_6;
      *(int *)(iVar2 + 0x18) = param_3;
      return param_3;
    }
    if (((*(int *)(iVar2 + 4) != param_4) ||
        ((*(int *)(iVar2 + 0x1c) == param_6 && (*(int *)(iVar2 + 8) != param_5)))) &&
       ((*(int *)(iVar2 + 0x10) != 0 || (*(int *)(iVar2 + 0x14) != 0)))) {
      iVar2 = param_1 - (int)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[iVar2 + 0x13cb3] = cVar1;
      } while (cVar1 != '\0');
      *(undefined4 *)(param_1 + 0x1615c) = 0x1a;
      return 0;
    }
    if (*(int *)(iVar2 + 0x18) != 0) {
      iVar2 = param_1 - (int)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[iVar2 + 0x13cb3] = cVar1;
      } while (cVar1 != '\0');
      *(undefined4 *)(param_1 + 0x1615c) = 0x18;
      return 0;
    }
    *(int *)(iVar2 + 8) = param_5;
    *(int *)(iVar2 + 0x1c) = param_6;
    *(int *)(iVar2 + 0x18) = param_3;
  }
  return param_3;
}



/* FUNCTION 4997 ; VA 0x005b6f90 ; FUN_005b6f90 */

undefined4 *
FUN_005b6f90(int param_1,char *param_2,undefined4 *param_3,undefined4 param_4,int param_5,
            undefined4 param_6,uint param_7,int param_8,code *param_9)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (((param_3 != (undefined4 *)0x0) && (param_2 != (char *)0x0)) && (*param_2 != '\0')) {
    iVar2 = FUN_005b7f30(param_1,param_2);
    if (iVar2 == 0) {
      iVar2 = FUN_005b4ae0(param_1,param_2);
      *(int *)(iVar2 + 4) = param_5;
      *(uint *)(iVar2 + 8) = param_7;
      *(undefined4 *)(iVar2 + 0xc) = 0;
      *(undefined4 *)(iVar2 + 0x10) = 0;
      *(undefined4 *)(iVar2 + 0x18) = 0;
      *(undefined4 *)(iVar2 + 0x1c) = 0;
      *(undefined4 *)(iVar2 + 0x14) = 0;
    }
    else if ((*(int *)(iVar2 + 4) != param_5) ||
            ((*(int *)(iVar2 + 0x1c) == param_8 && (*(uint *)(iVar2 + 8) != param_7)))) {
      iVar2 = param_1 - (int)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[iVar2 + 0x13cb3] = cVar1;
      } while (cVar1 != '\0');
      *(undefined4 *)(param_1 + 0x1615c) = 0x1a;
      return (undefined4 *)0x0;
    }
    if (((param_9 != (code *)0x0) || (param_7 < 4)) || (*param_2 != '#')) {
      puVar3 = (undefined4 *)FUN_0171e1f2(0x18);
      if (puVar3 == (undefined4 *)0x0) {
        *(undefined4 *)(param_1 + 0x1615c) = 0x14;
        return (undefined4 *)0x0;
      }
      *puVar3 = *(undefined4 *)(iVar2 + 0x14);
      puVar3[1] = param_6;
      puVar3[3] = param_8;
      puVar3[4] = param_4;
      puVar3[2] = param_3;
      if (param_9 == (code *)0x0) {
        param_9 = FUN_005b50d0;
      }
      puVar3[5] = param_9;
      *(undefined4 **)(iVar2 + 0x14) = puVar3;
      return param_3;
    }
    *param_3 = *(undefined4 *)(iVar2 + 0x10);
    *(undefined4 **)(iVar2 + 0x10) = param_3;
  }
  return param_3;
}



/* FUNCTION 4998 ; VA 0x005b70d0 ; FUN_005b70d0 */

int * FUN_005b70d0(int param_1,char *param_2,int *param_3,int param_4,undefined4 param_5,
                  uint param_6)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  
  if (((param_3 == (int *)0x0) || (param_2 == (char *)0x0)) || (*param_2 == '\0')) {
    return param_3;
  }
  iVar5 = FUN_005b7f30(param_1,param_2);
  if (iVar5 == 0) {
    iVar5 = FUN_005b4ae0(param_1,param_2);
    *(int *)(iVar5 + 4) = param_4;
    *(undefined4 *)(iVar5 + 8) = param_5;
    *(int **)(iVar5 + 0xc) = param_3;
    *(undefined4 *)(iVar5 + 0x10) = 0;
    *(undefined4 *)(iVar5 + 0x14) = 0;
    *(undefined4 *)(iVar5 + 0x18) = 0;
    *(uint *)(iVar5 + 0x1c) = param_6;
    *param_3 = 0;
    return param_3;
  }
  iVar7 = *(int *)(iVar5 + 0x18);
  if (iVar7 != 0) {
    if (*(int *)(iVar5 + 4) == param_4) {
      if (param_6 <= *(uint *)(iVar5 + 0x1c)) goto LAB_005b724e;
      while (piVar6 = (int *)FUN_005b7fc0(param_1,4), piVar6 != (int *)0x0) {
        *param_3 = (int)piVar6;
        param_6 = param_6 - 1;
        param_3 = piVar6;
        if (param_6 <= *(uint *)(iVar5 + 0x1c)) {
          *piVar6 = *(int *)(iVar5 + 0x18);
          return piVar6;
        }
      }
    }
    else {
      iVar5 = param_1 - (int)param_2;
      do {
        cVar1 = *param_2;
        param_2 = param_2 + 1;
        param_2[iVar5 + 0x13cb3] = cVar1;
      } while (cVar1 != '\0');
      *(undefined4 *)(param_1 + 0x1615c) = 0x1a;
    }
    return (int *)0x0;
  }
  if (param_6 < *(uint *)(iVar5 + 0x1c)) {
    piVar6 = (int *)(iVar5 + 0xc);
    do {
      piVar3 = piVar6;
      piVar4 = (int *)*piVar6;
      while (piVar4 != (int *)0x0) {
        iVar7 = FUN_005b7fc0(param_1,4);
        *piVar3 = iVar7;
        piVar2 = (int *)*piVar4;
        *piVar4 = iVar7;
        piVar3 = (int *)*piVar3;
        piVar4 = piVar2;
      }
      *piVar3 = 0;
      *(int *)(iVar5 + 0x1c) = *(int *)(iVar5 + 0x1c) + -1;
      *(undefined4 *)(iVar5 + 8) = param_5;
      *(undefined4 *)(iVar5 + 0x10) = 0;
    } while (param_6 < *(uint *)(iVar5 + 0x1c));
    iVar5 = *piVar6;
    *piVar6 = (int)param_3;
    *param_3 = iVar5;
    return param_3;
  }
  piVar6 = param_3;
  if (*(uint *)(iVar5 + 0x1c) < param_6) {
    do {
      param_3 = (int *)FUN_005b7fc0(param_1,4);
      *piVar6 = (int)param_3;
      param_6 = param_6 - 1;
      piVar6 = param_3;
    } while (*(uint *)(iVar5 + 0x1c) < param_6);
  }
  iVar7 = *(int *)(iVar5 + 0xc);
  *(int **)(iVar5 + 0xc) = param_3;
LAB_005b724e:
  *param_3 = iVar7;
  return param_3;
}



/* FUNCTION 4999 ; VA 0x005b7270 ; FUN_005b7270 */

undefined *
FUN_005b7270(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined *puVar2;
  char *pcVar3;
  char *pcStack_8;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    if (((*(char *)(param_1 + 0x144b4) == '\0') ||
        (iVar1 = FUN_005b8220(param_1,param_1 + 0x144b4,param_4), iVar1 == 0)) ||
       (iVar1 = FUN_005b8220(param_1,param_1 + 0x144b4,":byte"), iVar1 == 0)) {
      puVar2 = (undefined *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,param_5,1,0,0,0,0);
      if (*(char *)(param_1 + 0x140b4) == '\0') {
        if (puVar2 != (undefined *)0x0) {
          pcVar3 = (char *)FUN_005bde00(param_1);
          if (pcVar3 != (char *)0x0) {
            iVar1 = FUN_0171d785(pcVar3,&pcStack_8,10);
            if (((pcVar3 == pcStack_8) || (*pcStack_8 != '\0')) ||
               ((iVar1 < -0x80 || (0x7f < iVar1)))) {
              *(undefined4 *)(param_1 + 0x1615c) = 4;
            }
            *puVar2 = (char)iVar1;
          }
          if (*(int *)(param_1 + 0x1615c) != 0) {
            return (undefined *)0x0;
          }
        }
      }
      else {
        puVar2 = (undefined *)FUN_005b6f90(param_1,param_1 + 0x140b4,puVar2,0,param_5,0,1,0,0);
      }
      if ((*(short *)(param_1 + 0x309a) == 0) || (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 == 0)
         ) {
        return puVar2;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x1615c) = 4;
      FUN_005bb7f0(param_1);
    }
  }
  return (undefined *)0x0;
}


