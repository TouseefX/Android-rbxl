/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 2500 ; VA 0x0054fda0 ; FUN_0054fda0 */

undefined4 * __fastcall FUN_0054fda0(undefined4 *param_1)

{
  char *pcStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  pcStack_c = "call to empty boost::function";
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&pcStack_c,param_1 + 1);
  *param_1 = boost::bad_function_call::vftable;
  return param_1;
}



/* FUNCTION 2501 ; VA 0x0054fe00 ; FUN_0054fe00 */

undefined4 * __thiscall FUN_0054fe00(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  return param_1;
}



/* FUNCTION 2502 ; VA 0x0054fe20 ; FUN_0054fe20 */

undefined4 * __fastcall FUN_0054fe20(undefined4 *param_1)

{
  *param_1 = boost::exception::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0xffffffff;
  return param_1;
}



/* FUNCTION 2503 ; VA 0x0054fe50 ; FUN_0054fe50 */

undefined4 * __thiscall FUN_0054fe50(undefined4 *param_1,int param_2)

{
  int *piVar1;
  
  *param_1 = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 4);
  param_1[1] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  return param_1;
}



/* FUNCTION 2504 ; VA 0x0054fe90 ; FUN_0054fe90 */

undefined4 * __thiscall FUN_0054fe90(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  return param_1;
}



/* FUNCTION 2505 ; VA 0x0054fec0 ; FUN_0054fec0 */

undefined4 * __thiscall FUN_0054fec0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  
  uStack_c = param_2;
  uStack_8 = 1;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&uStack_c,param_1 + 1);
  return param_1;
}



/* FUNCTION 2506 ; VA 0x0054ff00 ; FUN_0054ff00 */

undefined4 * __thiscall FUN_0054ff00(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  
  *param_1 = *param_2;
  iVar1 = param_2[1];
  param_1[1] = iVar1;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
  }
  return param_1;
}



/* FUNCTION 2507 ; VA 0x0054ff30 ; FUN_0054ff30 */

undefined4 * __thiscall FUN_0054ff30(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::ios_base::failure::vftable;
  return param_1;
}



/* FUNCTION 2508 ; VA 0x0054ff80 ; FUN_0054ff80 */

undefined4 * __thiscall FUN_0054ff80(undefined4 *param_1,char *param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar2 = param_3[1];
  uVar3 = *param_3;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
  uStack_8 = 0;
  FUN_0054f9c0(uVar3,uVar2,auStack_2c);
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  *param_1 = std::ios_base::failure::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2509 ; VA 0x00550050 ; FUN_00550050 */

undefined4 * __fastcall FUN_00550050(undefined4 *param_1)

{
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 2510 ; VA 0x00550060 ; FUN_00550060 */

int __thiscall FUN_00550060(int param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_2 + 4);
  ExceptionList = &pvStack_10;
  *(int **)(param_1 + 4) = piVar1;
  (**(code **)(*piVar1 + 4))();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2511 ; VA 0x005500a0 ; FUN_005500a0 */

undefined4 * __thiscall FUN_005500a0(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  return param_1;
}



/* FUNCTION 2512 ; VA 0x005500e0 ; FUN_005500e0 */

undefined4 * __thiscall FUN_005500e0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  puStack_c = param_2;
  FUN_0170c226(&puStack_c,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  return param_1;
}



/* FUNCTION 2513 ; VA 0x00550130 ; FUN_00550130 */

undefined4 * __thiscall FUN_00550130(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::runtime_error::vftable;
  return param_1;
}



/* FUNCTION 2514 ; VA 0x00550180 ; FUN_00550180 */

undefined4 * __thiscall FUN_00550180(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::_System_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  *param_1 = std::system_error::vftable;
  return param_1;
}



/* FUNCTION 2515 ; VA 0x005501d0 ; FUN_005501d0 */

undefined4 * __thiscall FUN_005501d0(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2516 ; VA 0x00550250 ; FUN_00550250 */

undefined4 * __thiscall
FUN_00550250(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_4;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  param_1[3] = param_2;
  param_1[4] = param_3;
  *param_1 = boost::system::system_error::vftable;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  return param_1;
}



/* FUNCTION 2517 ; VA 0x005502b0 ; FUN_005502b0 */

undefined4 * __fastcall FUN_005502b0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 2518 ; VA 0x005502c0 ; FUN_005502c0 */

undefined4 * __thiscall FUN_005502c0(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  *param_1 = boost::thread_exception::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2519 ; VA 0x00550340 ; FUN_00550340 */

undefined4 * __thiscall FUN_00550340(undefined4 *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = boost::system::system_error::vftable;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x14);
  *param_1 = boost::thread_resource_error::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2520 ; VA 0x005503c0 ; FUN_005503c0 */

undefined4 * __fastcall FUN_005503c0(undefined4 *param_1)

{
  undefined4 uVar1;
  char *pcStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  uVar1 = FUN_01685730();
  *param_1 = std::exception::vftable;
  pcStack_c = "boost::thread_resource_error";
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&pcStack_c,param_1 + 1);
  param_1[4] = uVar1;
  param_1[3] = 0xb;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  *param_1 = boost::thread_resource_error::vftable;
  return param_1;
}



/* FUNCTION 2521 ; VA 0x00550430 ; FUN_00550430 */

void __fastcall FUN_00550430(undefined4 param_1)

{
  FUN_00550450(param_1);
  return;
}



/* FUNCTION 2522 ; VA 0x00550450 ; FUN_00550450 */

void __fastcall FUN_00550450(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar3 = (undefined4 *)(*param_1 + -0x10);
  LOCK();
  piVar1 = (int *)(*param_1 + -4);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1 || iVar2 + -1 < 0) {
    (**(code **)(*(int *)*puVar3 + 4))(puVar3);
  }
  return;
}



/* FUNCTION 2523 ; VA 0x00550470 ; FUN_00550470 */

void __fastcall FUN_00550470(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x10) != 0) {
    ExceptionList = &pvStack_10;
    FUN_01674ea0(*(int *)(param_1 + 0x10),8);
  }
  uVar1 = *(undefined4 *)(param_1 + 4);
  uVar2 = *(undefined4 *)(param_1 + 8);
  uStack_8 = 0;
  iVar3 = FUN_016deec8(uVar2);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  FUN_016dede1(uVar2);
  FUN_016df136(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2524 ; VA 0x005504e0 ; FUN_005504e0 */

void __fastcall FUN_005504e0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005537e0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2525 ; VA 0x00550540 ; FUN_00550540 */

void __fastcall FUN_00550540(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x40);
  return;
}



/* FUNCTION 2526 ; VA 0x00550550 ; FUN_00550550 */

void __fastcall FUN_00550550(int *param_1)

{
  if (*param_1 != 0) {
    FUN_017168b0(*param_1);
  }
  *param_1 = 0;
  return;
}



/* FUNCTION 2527 ; VA 0x00550570 ; FUN_00550570 */

void __fastcall FUN_00550570(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  if ((param_1[0x13] != 0) && (*(undefined4 **)param_1[3] == param_1 + 0xf)) {
    iVar1 = param_1[0x15];
    iVar2 = param_1[0x14];
    *(int *)param_1[3] = iVar2;
    *(int *)param_1[7] = iVar2;
    *(int *)param_1[0xb] = iVar1 - iVar2;
  }
  if (*(char *)(param_1 + 0x12) != '\0') {
    if (param_1[0x13] != 0) {
      FUN_00553750();
      FUN_01718190(param_1[0x13]);
    }
    *(undefined *)(param_1 + 0x12) = 0;
    param_1[3] = param_1 + 1;
    *(undefined *)((int)param_1 + 0x3d) = 0;
    param_1[7] = param_1 + 5;
    param_1[8] = param_1 + 6;
    param_1[0xb] = param_1 + 9;
    param_1[0xc] = param_1 + 10;
    param_1[4] = param_1 + 2;
    param_1[2] = 0;
    *(undefined4 *)param_1[8] = 0;
    *(undefined4 *)param_1[0xc] = 0;
    *(undefined4 *)param_1[3] = 0;
    *(undefined4 *)param_1[7] = 0;
    *(undefined4 *)param_1[0xb] = 0;
    param_1[0x13] = 0;
    param_1[0x10] = DAT_01e90d08;
    param_1[0x11] = DAT_01e90d0c;
    param_1[0xe] = 0;
  }
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = param_1[0xd];
  if (iVar1 != 0) {
    uStack_8 = 0;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar3 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2528 ; VA 0x005506a0 ; FUN_005506a0 */

void __fastcall FUN_005506a0(int param_1)

{
  int iVar1;
  
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x70) + 4) + -0x70 + param_1) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -0x70) + 4);
  *(int *)(iVar1 + -0x74 + param_1) = iVar1 + -0x70;
  FUN_00550570();
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x70) + 4) + -0x70 + param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -0x70) + 4);
  *(int *)(iVar1 + -0x74 + param_1) = iVar1 + -0x18;
  return;
}



/* FUNCTION 2529 ; VA 0x005506f0 ; FUN_005506f0 */

void __fastcall FUN_005506f0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2530 ; VA 0x00550730 ; FUN_00550730 */

void __fastcall FUN_00550730(int param_1)

{
  int iVar1;
  
  *(undefined ***)(*(int *)(*(int *)(param_1 + -0x18) + 4) + -0x18 + param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  iVar1 = *(int *)(*(int *)(param_1 + -0x18) + 4);
  *(int *)(iVar1 + -0x1c + param_1) = iVar1 + -0x18;
  return;
}



/* FUNCTION 2531 ; VA 0x00550750 ; FUN_00550750 */

void __fastcall FUN_00550750(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[0xd];
  ExceptionList = &pvStack_10;
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  if (iVar1 != 0) {
    uStack_8 = 0;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2532 ; VA 0x005507b0 ; FUN_005507b0 */

void __fastcall FUN_005507b0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 2533 ; VA 0x00550800 ; FUN_00550800 */

void __fastcall FUN_00550800(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (7 < (uint)param_1[5]) {
    iVar2 = *param_1;
    iVar1 = param_1[5] * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  return;
}



/* FUNCTION 2534 ; VA 0x00550860 ; FUN_00550860 */

void __fastcall FUN_00550860(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2535 ; VA 0x005508d0 ; FUN_005508d0 */

void __fastcall FUN_005508d0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
             vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2536 ; VA 0x00550940 ; FUN_00550940 */

void __fastcall FUN_00550940(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2537 ; VA 0x00550990 ; FUN_00550990 */

void __fastcall FUN_00550990(uint *param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  uStack_8 = 0;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2538 ; VA 0x005509f0 ; FUN_005509f0 */

void __fastcall FUN_005509f0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00550a77;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00550a77:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 2539 ; VA 0x00550a80 ; FUN_00550a80 */

void __fastcall FUN_00550a80(int *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if ((int *)*param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    cVar1 = (**(code **)(*(int *)*param_1 + 0x10))();
    if (cVar1 != '\0') {
      *param_1 = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2540 ; VA 0x00550ad0 ; FUN_00550ad0 */

void * __fastcall FUN_00550ad0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 4);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 2541 ; VA 0x00550b30 ; FUN_00550b30 */

void __fastcall FUN_00550b30(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00550b59. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 2542 ; VA 0x00550b60 ; FUN_00550b60 */

void __fastcall FUN_00550b60(undefined4 *param_1)

{
  uint uVar1;
  uint *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 1) != '\0') {
    puVar2 = (uint *)*param_1;
    LOCK();
    uVar1 = *puVar2;
    ExceptionList = &pvStack_10;
    *puVar2 = *puVar2 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puVar2;
      *puVar2 = *puVar2 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2543 ; VA 0x00550bc0 ; FUN_00550bc0 */

void __fastcall FUN_00550bc0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,8);
  }
  return;
}



/* FUNCTION 2544 ; VA 0x00550be0 ; FUN_00550be0 */

void __fastcall FUN_00550be0(int *param_1)

{
  if ((undefined4 *)*param_1 != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)*param_1)(1);
  }
  return;
}



/* FUNCTION 2545 ; VA 0x00550bf0 ; FUN_00550bf0 */

void __fastcall FUN_00550bf0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_01519bf0();
    FUN_01674ea0(iVar1,8);
  }
  return;
}



/* FUNCTION 2546 ; VA 0x00550c10 ; FUN_00550c10 */

void __fastcall FUN_00550c10(int *param_1)

{
  if (*param_1 != 0) {
    RegCloseKey(*param_1);
    *param_1 = 0;
  }
  param_1[1] = 0;
  return;
}



/* FUNCTION 2547 ; VA 0x00550c30 ; FUN_00550c30 */

void __fastcall FUN_00550c30(undefined4 *param_1)

{
  CloseServiceHandle(*param_1);
  return;
}



/* FUNCTION 2548 ; VA 0x00550c50 ; FUN_00550c50 */

void __fastcall FUN_00550c50(undefined4 param_1)

{
  FUN_005507b0(param_1);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  return;
}



/* FUNCTION 2549 ; VA 0x00550d00 ; FUN_00550d00 */

void __fastcall FUN_00550d00(undefined4 param_1)

{
  FUN_00550bf0(param_1);
  FUN_00550b30();
  return;
}



/* FUNCTION 2550 ; VA 0x00550d20 ; FUN_00550d20 */

void __fastcall FUN_00550d20(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675290(*param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2551 ; VA 0x00550d50 ; FUN_00550d50 */

void __fastcall FUN_00550d50(undefined4 param_1)

{
  FUN_005507b0(param_1);
  FUN_005507b0();
  return;
}



/* FUNCTION 2552 ; VA 0x00550d80 ; FUN_00550d80 */

void __fastcall FUN_00550d80(undefined4 param_1)

{
  FUN_005504e0(param_1);
  FUN_00550da0();
  return;
}



/* FUNCTION 2553 ; VA 0x00550da0 ; FUN_00550da0 */

void __fastcall FUN_00550da0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x18);
  if (iVar1 != 0) {
    do {
      iVar1 = iVar1 + -1;
      *(int *)(param_1 + 0x18) = iVar1;
    } while (iVar1 != 0);
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x10);
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar2 = *(int *)(*(int *)(param_1 + 0xc) + iVar1 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x10);
    }
  }
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x10) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 8),8);
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 2554 ; VA 0x00550e50 ; FUN_00550e50 */

void __fastcall FUN_00550e50(char *param_1)

{
  if (*param_1 != '\0') {
    FUN_016df136(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 2555 ; VA 0x00550e60 ; FUN_00550e60 */

void __fastcall FUN_00550e60(char *param_1)

{
  if (*param_1 != '\0') {
    FUN_016dede1(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 2556 ; VA 0x00550e70 ; FUN_00550e70 */

void __fastcall FUN_00550e70(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016de2d3(param_1);
  if (*(int *)(param_1 + 0x2c) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0x2c));
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  if (*(int *)(param_1 + 0x24) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0x24));
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (*(int *)(param_1 + 0x1c) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0x1c));
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (*(int *)(param_1 + 0x14) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0x14));
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_017168b0(*(int *)(param_1 + 0xc));
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (*(int *)(param_1 + 4) != 0) {
    FUN_017168b0(*(int *)(param_1 + 4));
  }
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2557 ; VA 0x00550f40 ; FUN_00550f40 */

void __fastcall FUN_00550f40(undefined4 *param_1)

{
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  return;
}



/* FUNCTION 2558 ; VA 0x00550f60 ; FUN_00550f60 */

void __fastcall FUN_00550f60(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::bad_alloc_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2559 ; VA 0x00550fd0 ; FUN_00550fd0 */

void __fastcall FUN_00550fd0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::bad_exception_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2560 ; VA 0x00551040 ; FUN_00551040 */

void __fastcall FUN_00551040(undefined4 *param_1)

{
  *param_1 = boost::exception_detail::clone_base::vftable;
  return;
}



/* FUNCTION 2561 ; VA 0x00551050 ; FUN_00551050 */

void __fastcall FUN_00551050(undefined4 *param_1)

{
  *param_1 = std::_Facet_base::vftable;
  return;
}



/* FUNCTION 2562 ; VA 0x00551060 ; FUN_00551060 */

void __fastcall FUN_00551060(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2563 ; VA 0x005510b0 ; FUN_005510b0 */

void __fastcall FUN_005510b0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 4) + 8))();
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2564 ; VA 0x005510f0 ; FUN_005510f0 */

void * __fastcall FUN_005510f0(int *param_1)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  param_1 = (int *)*param_1;
  pvVar3 = ExceptionList;
  if (param_1 != (int *)0x0) {
    LOCK();
    piVar1 = param_1 + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)(*param_1 + 4))();
      LOCK();
      piVar1 = param_1 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*param_1 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 2565 ; VA 0x00551150 ; FUN_00551150 */

void __fastcall FUN_00551150(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = boost::system::system_error::vftable;
  uVar1 = param_1[10];
  if (0xf < uVar1) {
    iVar2 = param_1[5];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  return;
}



/* FUNCTION 2566 ; VA 0x005511c0 ; FUN_005511c0 */

void __fastcall FUN_005511c0(int param_1)

{
  code *pcVar1;
  int iVar2;
  int unaff_EBP;
  
  if (*(int *)(param_1 + 4) == 0) {
    return;
  }
  FUN_016f4b80(&DAT_01d51160,8);
  iVar2 = FUN_01733dcb();
  pcVar1 = *(code **)(iVar2 + 0xc);
  if (pcVar1 != (code *)0x0) {
    *(undefined4 *)(unaff_EBP + -4) = 0;
    (*(code *)PTR__guard_check_icall_018b37b4)();
    (*pcVar1)();
    *(undefined4 *)(unaff_EBP + -4) = 0xfffffffe;
  }
  FUN_0171d6f3();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 2567 ; VA 0x005511d0 ; FUN_005511d0 */

void __fastcall FUN_005511d0(undefined4 *param_1)

{
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  return;
}



/* FUNCTION 2568 ; VA 0x005511e0 ; FUN_005511e0 */

undefined4 FUN_005511e0(undefined4 param_1,undefined4 param_2)

{
  return param_2;
}



/* FUNCTION 2569 ; VA 0x005511f0 ; FUN_005511f0 */

undefined4 * __thiscall FUN_005511f0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 != param_2) {
    FUN_005507b0();
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
  }
  return param_1;
}



/* FUNCTION 2570 ; VA 0x00551230 ; FUN_00551230 */

undefined4 * __thiscall FUN_00551230(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (param_1 != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  return param_1;
}



/* FUNCTION 2571 ; VA 0x00551260 ; FUN_00551260 */

void FUN_00551260(char *param_1)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar2 - (int)(param_1 + 1));
  return;
}



/* FUNCTION 2572 ; VA 0x00551290 ; FUN_00551290 */

undefined4 * __thiscall FUN_00551290(undefined4 *param_1,undefined4 *param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  
  if (param_1[1] == 0) {
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    return param_1;
  }
  FUN_0171d16a();
  pcVar1 = (code *)swi(3);
  puVar2 = (undefined4 *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 2573 ; VA 0x005512d0 ; FUN_005512d0 */

undefined __fastcall FUN_005512d0(undefined *param_1)

{
  return *param_1;
}



/* FUNCTION 2574 ; VA 0x005512e0 ; FUN_005512e0 */

int __fastcall FUN_005512e0(int *param_1)

{
  if (*param_1 == 0) {
    FUN_016dda75(0);
    if (*param_1 == 0) {
      DAT_021130c8 = DAT_021130c8 + 1;
      *param_1 = DAT_021130c8;
    }
    FUN_016ddacd();
  }
  return *param_1;
}



/* FUNCTION 2575 ; VA 0x00551320 ; FUN_00551320 */

int * __fastcall FUN_00551320(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  
  iVar2 = *param_1;
  piVar3 = *(int **)(iVar2 + 8);
  if (*(char *)((int)piVar3 + 0xd) != '\0') {
    cVar1 = *(char *)(*(int *)(iVar2 + 4) + 0xd);
    iVar5 = *(int *)(iVar2 + 4);
    while ((cVar1 == '\0' && (iVar2 == *(int *)(iVar5 + 8)))) {
      *param_1 = iVar5;
      cVar1 = *(char *)(*(int *)(iVar5 + 4) + 0xd);
      iVar2 = iVar5;
      iVar5 = *(int *)(iVar5 + 4);
    }
    *param_1 = iVar5;
    return param_1;
  }
  cVar1 = *(char *)(*piVar3 + 0xd);
  piVar4 = (int *)*piVar3;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*piVar4 + 0xd);
    piVar3 = piVar4;
    piVar4 = (int *)*piVar4;
  }
  *param_1 = (int)piVar3;
  return param_1;
}



/* FUNCTION 2576 ; VA 0x00551380 ; FUN_00551380 */

void FUN_00551380(int *param_1,int *param_2,char *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  code *pcVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792039;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int **)(*param_2 + -0x10) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piVar6 = (int *)(**(code **)(**(int **)(*param_2 + -0x10) + 0x10))();
    if (piVar6 != (int *)0x0) goto LAB_005513c8;
  }
  piVar6 = (int *)FUN_005527b0();
  piVar6 = (int *)(**(code **)(*piVar6 + 0x10))();
LAB_005513c8:
  uStack_8 = 1;
  if (piVar6 == (int *)0x0) {
    FUN_005522b0(0x80004005);
  }
  else {
    iVar7 = (**(code **)(*piVar6 + 0xc))();
    *param_1 = iVar7 + 0x10;
    uStack_8 = 0;
    if (param_3 == (char *)0x0) {
      iVar8 = 0;
    }
    else {
      pcVar9 = param_3;
      do {
        cVar2 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar2 != '\0');
      iVar8 = (int)pcVar9 - (int)(param_3 + 1);
    }
    iVar3 = *param_2;
    iVar4 = *(int *)(iVar3 + -0xc);
    iVar1 = iVar8 + iVar4;
    if (-1 < iVar1) {
      if ((int)(1U - *(int *)(iVar7 + 0xc) | *(int *)(iVar7 + 8) - iVar1) < 0) {
        FUN_00552b90(iVar1);
      }
      iVar7 = *param_1;
      FUN_00557ba0(iVar7,iVar4,iVar3,iVar4);
      FUN_00557ba0(iVar4 + iVar7,iVar8,param_3,iVar8);
      if (iVar1 <= *(int *)(*param_1 + -8)) {
        *(int *)(*param_1 + -0xc) = iVar1;
        *(undefined *)(iVar1 + *param_1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  FUN_005522b0(0x80070057);
  pcVar5 = (code *)swi(3);
  (*pcVar5)();
  return;
}



/* FUNCTION 2577 ; VA 0x005514a0 ; FUN_005514a0 */

undefined4 FUN_005514a0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iStack_28;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792058;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054f050(param_2);
  uStack_8 = 0;
  uVar1 = FUN_01686150(param_3);
  FUN_0054f050(uVar1);
  if (7 < uStack_14) {
    uVar3 = uStack_14 * 2 + 2;
    iVar2 = iStack_28;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_28 + -4);
      uVar3 = uStack_14 * 2 + 0x25;
      if (0x1f < (iStack_28 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2578 ; VA 0x00551530 ; FUN_00551530 */

void __fastcall FUN_00551530(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_14 [8];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  FUN_0054e560(param_1);
  if (DAT_01d84e8d != '\0') {
    FUN_016774b0(DAT_01d84e8d,"Timed out, committing suicide",0);
  }
  FUN_01675310("Suicide",&DAT_018bc9b8);
  uStack_c = 2;
  uVar1 = FUN_0054db30(auStack_14,uStack_8,&uStack_c);
  FUN_0054e560(uVar1);
  uVar1 = GetCurrentProcess(0xffffffff);
  TerminateProcess(uVar1);
  return;
}



/* FUNCTION 2579 ; VA 0x005515c0 ; FUN_005515c0 */

void __fastcall FUN_005515c0(uint *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 2580 ; VA 0x00551620 ; FUN_00551620 */

void FUN_00551620(char *param_1)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_00554150(param_1,(int)pcVar2 - (int)(param_1 + 1));
  return;
}



/* FUNCTION 2581 ; VA 0x00551650 ; FUN_00551650 */

void __fastcall FUN_00551650(undefined4 param_1)

{
  FUN_005506a0(param_1);
  FUN_005506f0();
  return;
}



/* FUNCTION 2582 ; VA 0x00551680 ; FUN_00551680 */

void __fastcall FUN_00551680(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1 + 6;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x18 + (int)piVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x1c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x18;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2583 ; VA 0x005516e0 ; FUN_005516e0 */

void __fastcall FUN_005516e0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
       ::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2584 ; VA 0x00551780 ; FUN_00551780 */

void __fastcall FUN_00551780(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
             ::vftable;
  param_1[0xb] = boost::exception_detail::
                 clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
                 ::vftable;
  *(undefined ***)(*(int *)(param_1[0x10] + 4) + 0x40 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
       ::vftable;
  *(int *)(*(int *)(param_1[0x10] + 4) + 0x3c + (int)param_1) = *(int *)(param_1[0x10] + 4) + -8;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
             vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  param_1[0x12] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2585 ; VA 0x00551820 ; FUN_00551820 */

void __fastcall FUN_00551820(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
             vftable;
  param_1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
               vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::bad_alloc_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2586 ; VA 0x005518c0 ; FUN_005518c0 */

void __fastcall FUN_005518c0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
             vftable;
  param_1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
               vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  *param_1 = boost::exception_detail::bad_exception_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  param_1[10] = boost::exception_detail::clone_base::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2587 ; VA 0x00551958 ; FUN_00551958 */

void FUN_00551958(void)

{
  FUN_00551a10();
  return;
}



/* FUNCTION 2588 ; VA 0x00551960 ; FUN_00551960 */

void FUN_00551960(void)

{
  FUN_00551aa0();
  return;
}



/* FUNCTION 2589 ; VA 0x00551968 ; FUN_00551968 */

void FUN_00551968(void)

{
  FUN_00551b90();
  return;
}



/* FUNCTION 2590 ; VA 0x00551973 ; FUN_00551973 */

void FUN_00551973(void)

{
  FUN_00551b90();
  return;
}



/* FUNCTION 2591 ; VA 0x0055197b ; FUN_0055197b */

void FUN_0055197b(void)

{
  FUN_00551bc0();
  return;
}



/* FUNCTION 2592 ; VA 0x00551986 ; FUN_00551986 */

void FUN_00551986(void)

{
  FUN_00551bc0();
  return;
}



/* FUNCTION 2593 ; VA 0x0055198e ; FUN_0055198e */

void FUN_0055198e(void)

{
  FUN_00551bf0();
  return;
}



/* FUNCTION 2594 ; VA 0x00551999 ; FUN_00551999 */

void FUN_00551999(void)

{
  FUN_00551bf0();
  return;
}



/* FUNCTION 2595 ; VA 0x005519a1 ; FUN_005519a1 */

void FUN_005519a1(void)

{
  FUN_00551c20();
  return;
}



/* FUNCTION 2596 ; VA 0x005519ac ; FUN_005519ac */

void FUN_005519ac(void)

{
  FUN_00551c20();
  return;
}



/* FUNCTION 2597 ; VA 0x005519b4 ; FUN_005519b4 */

void FUN_005519b4(void)

{
  FUN_00551ce0();
  return;
}



/* FUNCTION 2598 ; VA 0x005519bc ; FUN_005519bc */

void FUN_005519bc(void)

{
  FUN_00551d60();
  return;
}



/* FUNCTION 2599 ; VA 0x005519c4 ; FUN_005519c4 */

void FUN_005519c4(void)

{
  FUN_00551fd0();
  return;
}



/* FUNCTION 2600 ; VA 0x005519cc ; FUN_005519cc */

void FUN_005519cc(void)

{
  FUN_00552050();
  return;
}



/* FUNCTION 2601 ; VA 0x005519e0 ; FUN_005519e0 */

undefined4 __thiscall FUN_005519e0(undefined4 param_1,byte param_2)

{
  FUN_00550570();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 2602 ; VA 0x00551a10 ; FUN_00551a10 */

int __thiscall FUN_00551a10(int param_1,byte param_2)

{
  FUN_00551650();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x70,0xb8);
  }
  return param_1 + -0x70;
}



/* FUNCTION 2603 ; VA 0x00551a40 ; FUN_00551a40 */

undefined4 * __thiscall FUN_00551a40(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2604 ; VA 0x00551aa0 ; FUN_00551aa0 */

int * __thiscall FUN_00551aa0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + -6;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(param_1[-6] + 4) + -0x18 + (int)param_1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*piVar1 + 4) + -0x1c + (int)param_1) = *(int *)(*piVar1 + 4) + -0x18;
  uStack_8 = 0;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(piVar1,0x60);
  }
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 2605 ; VA 0x00551b10 ; FUN_00551b10 */

undefined4 * __thiscall FUN_00551b10(undefined4 *param_1,byte param_2)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[0xd];
  ExceptionList = &pvStack_10;
  *param_1 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  if (iVar1 != 0) {
    uStack_8 = 0;
    if (*(int **)(iVar1 + 4) != (int *)0x0) {
      puVar2 = (undefined4 *)(**(code **)(**(int **)(iVar1 + 4) + 8))();
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2606 ; VA 0x00551b90 ; FUN_00551b90 */

undefined4 __thiscall FUN_00551b90(undefined4 param_1,byte param_2)

{
  FUN_005516e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 2607 ; VA 0x00551bc0 ; FUN_00551bc0 */

undefined4 __thiscall FUN_00551bc0(undefined4 param_1,byte param_2)

{
  FUN_00551780();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 2608 ; VA 0x00551bf0 ; FUN_00551bf0 */

undefined4 __thiscall FUN_00551bf0(undefined4 param_1,byte param_2)

{
  FUN_00551820();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 2609 ; VA 0x00551c20 ; FUN_00551c20 */

undefined4 __thiscall FUN_00551c20(undefined4 param_1,byte param_2)

{
  FUN_005518c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 2610 ; VA 0x00551c50 ; FUN_00551c50 */

undefined4 * __thiscall FUN_00551c50(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 2611 ; VA 0x00551c80 ; FUN_00551c80 */

undefined4 * __thiscall FUN_00551c80(undefined4 *param_1,byte param_2)

{
  *param_1 = std::ctype<char>::vftable;
  if ((int)param_1[4] < 1) {
    if ((int)param_1[4] < 0) {
      FUN_01674ea0(param_1[3]);
    }
  }
  else {
    FUN_017168b0(param_1[3]);
  }
  FUN_017168b0(param_1[5]);
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 2612 ; VA 0x00551ce0 ; FUN_00551ce0 */

undefined4 * __thiscall FUN_00551ce0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::bad_function_call>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2613 ; VA 0x00551d60 ; FUN_00551d60 */

undefined4 * __thiscall FUN_00551d60(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_boost::thread_resource_error>::
             vftable;
  param_1[0xb] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[0xc] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[0xc] + 0x10))();
    if (cVar1 != '\0') {
      param_1[0xc] = 0;
    }
  }
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2614 ; VA 0x00551de0 ; FUN_00551de0 */

int * __thiscall FUN_00551de0(int *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00551e80;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00551e80:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 2615 ; VA 0x00551e90 ; FUN_00551e90 */

undefined4 * __thiscall FUN_00551e90(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::detail::sp_counted_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 2616 ; VA 0x00551ec0 ; FUN_00551ec0 */

undefined4 __thiscall FUN_00551ec0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 2617 ; VA 0x00551ee0 ; FUN_00551ee0 */

undefined4 * __thiscall FUN_00551ee0(undefined4 *param_1,byte param_2)

{
  *param_1 = ATL::CWin32Heap::vftable;
  if ((*(char *)(param_1 + 2) != '\0') && (param_1[1] != 0)) {
    HeapDestroy(param_1[1]);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 2618 ; VA 0x00551f20 ; FUN_00551f20 */

undefined4 * __thiscall FUN_00551f20(undefined4 *param_1,byte param_2)

{
  *param_1 = std::_Facet_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 2619 ; VA 0x00551f50 ; FUN_00551f50 */

undefined4 __thiscall FUN_00551f50(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 2620 ; VA 0x00551f70 ; FUN_00551f70 */

undefined4 * __thiscall FUN_00551f70(undefined4 *param_1,byte param_2)

{
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 2621 ; VA 0x00551fa0 ; FUN_00551fa0 */

undefined4 * __thiscall FUN_00551fa0(undefined4 *param_1,byte param_2)

{
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 2622 ; VA 0x00551fd0 ; FUN_00551fd0 */

undefined4 * __thiscall FUN_00551fd0(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::bad_alloc_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2623 ; VA 0x00552050 ; FUN_00552050 */

undefined4 * __thiscall FUN_00552050(undefined4 *param_1,byte param_2)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::bad_exception_::vftable;
  param_1[5] = std::exception::vftable;
  FUN_0170c289(param_1 + 6);
  *param_1 = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[1] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (cVar1 != '\0') {
      param_1[1] = 0;
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2624 ; VA 0x005520d0 ; FUN_005520d0 */

undefined4 * __thiscall FUN_005520d0(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::exception_detail::clone_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 2625 ; VA 0x00552100 ; FUN_00552100 */

undefined4 * __thiscall FUN_00552100(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = std::ios_base::vftable;
  FUN_016de551(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 2626 ; VA 0x00552160 ; FUN_00552160 */

undefined4 * __thiscall FUN_00552160(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::detail::sp_counted_base::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 2627 ; VA 0x00552190 ; FUN_00552190 */

undefined4 __thiscall FUN_00552190(undefined4 param_1,byte param_2)

{
  FUN_00551150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 2628 ; VA 0x005521c0 ; FUN_005521c0 */

undefined4 * __thiscall FUN_005521c0(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::thread_exception::vftable;
  FUN_00551150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x2c);
  }
  return param_1;
}



/* FUNCTION 2629 ; VA 0x005521f0 ; FUN_005521f0 */

void FUN_005521f0(undefined4 param_1,undefined4 param_2,int param_3,code *param_4)

{
  if (param_3 != 0) {
    do {
      (*param_4)();
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 2630 ; VA 0x00552220 ; FUN_00552220 */

int * __thiscall FUN_00552220(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int *piVar2;
  uint uVar3;
  
  if ((((-1 < param_2) && (0 < 0x7fffffff - param_2)) &&
      (uVar3 = param_2 + 8U & 0xfffffff8, param_2 + 1 <= (int)uVar3)) &&
     (((uVar1 = (uint)((ulonglong)uVar3 * (ulonglong)param_3),
       (int)((ulonglong)uVar3 * (ulonglong)param_3 >> 0x20) == 0 && (uVar1 < 0xfffffff0)) &&
      (piVar2 = (int *)(**(code **)**(undefined4 **)(param_1 + 4))(uVar1 + 0x10),
      piVar2 != (int *)0x0)))) {
    *piVar2 = param_1;
    piVar2[3] = 1;
    piVar2[2] = uVar3 - 1;
    piVar2[1] = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 2631 ; VA 0x00552290 ; FUN_00552290 */

void __thiscall FUN_00552290(int param_1,undefined4 param_2)

{
  HeapAlloc(*(undefined4 *)(param_1 + 4),0,param_2);
  return;
}



/* FUNCTION 2632 ; VA 0x005522b0 ; FUN_005522b0 */

void FUN_005522b0(undefined4 param_1)

{
  FUN_0054d840(param_1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&param_1,&DAT_01c17164);
}



/* FUNCTION 2633 ; VA 0x005522d0 ; FUN_005522d0 */

int __thiscall
FUN_005522d0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,uint *param_8)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_6;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  piVar1 = (int *)param_1[2];
  if (piVar1 == (int *)0x0) {
LAB_00552359:
    ExceptionList = &pvStack_10;
    iVar3 = RegCreateKeyExA(param_2,param_3,0,param_4,param_5,param_6,param_7,&iStack_14,&param_6);
  }
  else {
    if (*piVar1 == 0) {
      ExceptionList = &pvStack_10;
      if (piVar1[1] != 0) goto LAB_00552359;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar3 = GetModuleHandleA("Advapi32.dll");
      if (iVar3 == 0) {
        iVar3 = 1;
        goto LAB_00552379;
      }
      pcVar4 = (code *)GetProcAddress(iVar3,"RegCreateKeyTransactedA");
      if (pcVar4 != (code *)0x0) {
        iVar3 = (*pcVar4)(param_2,param_3,0,param_4,param_5,uVar2,param_7,&iStack_14,&param_6,
                          *piVar1,0);
        goto LAB_00552379;
      }
    }
    iVar3 = 1;
  }
LAB_00552379:
  if (iVar3 == 0) {
    if (param_8 != (uint *)0x0) {
      *param_8 = param_6;
    }
    iVar3 = 0;
    if (*param_1 != 0) {
      iVar3 = RegCloseKey(*param_1);
    }
    *param_1 = iStack_14;
    param_1[1] = uVar2 & 0x300;
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 2634 ; VA 0x005523c0 ; FUN_005523c0 */

undefined4 FUN_005523c0(uint param_1)

{
  undefined4 uVar1;
  
  if ((param_1 < 3) || (param_1 == 6)) {
    DAT_01e90c48 = 1;
    uVar1 = 1;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 2635 ; VA 0x00552400 ; FUN_00552400 */

undefined4 __thiscall FUN_00552400(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)param_1[2];
  if (piVar1 != (int *)0x0) {
    uVar4 = *param_1;
    if (*piVar1 == 0) {
      ExceptionList = &pvStack_10;
      if (piVar1[1] != 0) goto LAB_005524fb;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar2 = GetModuleHandleA("Advapi32.dll");
      if ((iVar2 != 0) &&
         (pcVar3 = (code *)GetProcAddress(iVar2,"RegDeleteKeyTransactedA"), pcVar3 != (code *)0x0))
      {
        uVar4 = (*pcVar3)(uVar4,param_2,0,0,*piVar1,0);
        ExceptionList = pvStack_10;
        return uVar4;
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = &pvStack_10;
  if (DAT_01e90c88 == '\0') {
    ExceptionList = &pvStack_10;
    iVar2 = GetModuleHandleA("Advapi32.dll");
    if (iVar2 == 0) {
      DAT_01e90c88 = '\x01';
    }
    else {
      DAT_01e90c84 = (code *)GetProcAddress(iVar2,"RegDeleteKeyExA");
      DAT_01e90c88 = '\x01';
    }
  }
  if (DAT_01e90c84 != (code *)0x0) {
    uVar4 = (*DAT_01e90c84)(*param_1,param_2,param_1[1],0);
    ExceptionList = pvStack_10;
    return uVar4;
  }
  uVar4 = *param_1;
LAB_005524fb:
  uVar4 = RegDeleteKeyA(uVar4,param_2);
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 2636 ; VA 0x00552520 ; FUN_00552520 */

void __fastcall FUN_00552520(int *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int *piVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  puVar1 = (undefined4 *)(iVar5 + -0x10);
  piVar3 = (int *)*puVar1;
  if (*(int *)(iVar5 + -0xc) != 0) {
    piVar2 = (int *)(iVar5 + -4);
    if (*(int *)(iVar5 + -4) < 0) {
      if (-1 < *(int *)(iVar5 + -8)) {
        *(undefined4 *)(iVar5 + -0xc) = 0;
        *(undefined *)*param_1 = 0;
        return;
      }
      ExceptionList = &pvStack_10;
      FUN_005522b0(0x80070057);
      pcVar4 = (code *)swi(3);
      (*pcVar4)();
      return;
    }
    LOCK();
    iVar5 = *piVar2;
    ExceptionList = &pvStack_10;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1 || iVar5 + -1 < 0) {
      (**(code **)(*(int *)*puVar1 + 4))(puVar1);
    }
    iVar5 = (**(code **)(*piVar3 + 0xc))();
    *param_1 = iVar5 + 0x10;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2637 ; VA 0x005525b0 ; FUN_005525b0 */

void FUN_005525b0(void)

{
  int iVar1;
  undefined auStack_138 [260];
  undefined auStack_34 [12];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017920b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054f570(0);
  uStack_8 = 0;
  iVar1 = FUN_005522d0(0x80000002,
                       "SYSTEM\\CurrentControlSet\\Services\\Eventlog\\Application\\RCCService",0,0,
                       0x2001f,0,0);
  if (iVar1 != 0) {
    FUN_00550130("couldn\'t create RCCService reg key");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  iVar1 = GetModuleFileNameA(0,auStack_138,0x104);
  if (iVar1 == 0) {
    FUN_00550130("GetModuleFileName failed");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_34,&DAT_01c17198);
  }
  FUN_00552f60("EventMessageFile",auStack_138,2);
  FUN_00552f40("TypesSupported",0x1f);
  uStack_8 = 0xffffffff;
  FUN_00550c10();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2638 ; VA 0x005526a0 ; FUN_005526a0 */

void FUN_005526a0(void)

{
  int iVar1;
  
  FUN_0054f570(0);
  iVar1 = FUN_00552ac0(0x80000002,"SYSTEM\\CurrentControlSet\\Services\\Eventlog\\Application",
                       0x20006);
  if (iVar1 == 0) {
    FUN_00552400("RCCService");
  }
  FUN_00550c10();
  return;
}



/* FUNCTION 2639 ; VA 0x005526f0 ; FUN_005526f0 */

void __thiscall FUN_005526f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  undefined4 *puVar5;
  int iVar6;
  
  iVar2 = *param_1;
  iVar3 = *(int *)(iVar2 + -0xc);
  puVar5 = (undefined4 *)(**(code **)(**(int **)(iVar2 + -0x10) + 0x10))();
  iVar6 = (**(code **)*puVar5)(param_2,1);
  if (iVar6 != 0) {
    if (iVar3 < param_2) {
      param_2 = iVar3;
    }
    FUN_00557ba0(iVar6 + 0x10,param_2 + 1,iVar2,param_2 + 1);
    *(int *)(iVar6 + 4) = iVar3;
    LOCK();
    piVar1 = (int *)(iVar2 + -4);
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1 || iVar3 + -1 < 0) {
      (**(code **)(**(int **)(iVar2 + -0x10) + 4))((undefined4 *)(iVar2 + -0x10));
    }
    *param_1 = iVar6 + 0x10;
    return;
  }
  FUN_005534b0();
  pcVar4 = (code *)swi(3);
  (*pcVar4)();
  return;
}



/* FUNCTION 2640 ; VA 0x00552780 ; FUN_00552780 */

void __fastcall FUN_00552780(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00552789. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 4) + 4))();
  return;
}



/* FUNCTION 2641 ; VA 0x00552790 ; FUN_00552790 */

void __thiscall FUN_00552790(int param_1,int param_2)

{
  if (param_2 != 0) {
    HeapFree(*(undefined4 *)(param_1 + 4),0,param_2);
  }
  return;
}



/* FUNCTION 2642 ; VA 0x005527b0 ; FUN_005527b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005527b0(void)

{
  int iVar1;
  
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if (*(int *)(iVar1 + 0x34) < DAT_01e90c98) {
    FUN_016f3809(&DAT_01e90c98);
    if (DAT_01e90c98 == -1) {
      DAT_01e90c90 = GetProcessHeap();
      _DAT_01e90c8c = ATL::CWin32Heap::vftable;
      DAT_01e90c94 = 0;
      FUN_016f3654(&LAB_0187b110);
      FUN_016f37bf(&DAT_01e90c98);
    }
  }
  if (*(int *)(iVar1 + 0x34) < DAT_01e90cb8) {
    FUN_016f3809(&DAT_01e90cb8);
    if (DAT_01e90cb8 == -1) {
      _DAT_01e90c9c = ATL::CAtlStringMgr::vftable;
      _DAT_01e90ca0 = &DAT_01e90c8c;
      _DAT_01e90cb0 = 2;
      _DAT_01e90ca8 = 0;
      _DAT_01e90cac = 0;
      _DAT_01e90cb4 = 0;
      _DAT_01e90ca4 = &DAT_01e90c9c;
      FUN_016f3654(&DAT_0187b140);
      FUN_016f37bf(&DAT_01e90cb8);
    }
  }
  return &DAT_01e90c9c;
}



/* FUNCTION 2643 ; VA 0x005528b0 ; FUN_005528b0 */

int __fastcall FUN_005528b0(int param_1)

{
  LOCK();
  *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 1;
  UNLOCK();
  return param_1 + 8;
}



/* FUNCTION 2644 ; VA 0x005528c0 ; FUN_005528c0 */

void __thiscall FUN_005528c0(int param_1,undefined4 param_2)

{
  HeapSize(*(undefined4 *)(param_1 + 4),0,param_2);
  return;
}



/* FUNCTION 2645 ; VA 0x005528e0 ; FUN_005528e0 */

void FUN_005528e0(void)

{
  FUN_005534c0(3);
  FUN_0086edd0(1,"SERVICE_STOP_PENDING",6);
  FUN_005531f0(4,"SERVICE_STOP_PENDING");
  FUN_0057ffd0();
  WaitForSingleObject(DAT_01e90c44,0xffffffff);
  FUN_005534c0(1);
  FUN_0086edd0(1,"SERVICE_STOPPED",6);
  FUN_005531f0(4,"SERVICE_STOPPED");
  return;
}



/* FUNCTION 2646 ; VA 0x00552950 ; FUN_00552950 */

uint __fastcall FUN_00552950(undefined4 param_1)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = InitializeCriticalSectionEx(param_1,0,0);
  if (iVar1 == 0) {
    uVar2 = GetLastError();
    if (0 < (int)uVar2) {
      return uVar2 & 0xffff | 0x80070000;
    }
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}



/* FUNCTION 2647 ; VA 0x00552980 ; FUN_00552980 */

undefined4 __thiscall FUN_00552980(int *param_1,uint param_2)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined2 *puVar5;
  undefined4 uVar6;
  
  iVar2 = FUN_016f3257(0);
  if (iVar2 != 0) {
    iVar4 = 1;
    do {
      iVar3 = FindResourceExW(iVar2,6,(param_2 >> 4) + 1 & 0xffff,0);
      if ((iVar3 != 0) && (iVar3 = FUN_00553520(iVar2,iVar3,param_2), iVar3 != 0)) {
        if (iVar2 == 0) {
          return 0;
        }
        iVar4 = FindResourceW(iVar2,(param_2 >> 4) + 1 & 0xffff,6);
        if (iVar4 == 0) {
          return 0;
        }
        puVar5 = (undefined2 *)FUN_00553520(iVar2,iVar4,param_2);
        if (puVar5 == (undefined2 *)0x0) {
          return 0;
        }
        iVar2 = WideCharToMultiByte(3,0,puVar5 + 1,*puVar5,0,0,0,0);
        if (-1 < iVar2) {
          iVar4 = *param_1;
          if ((int)(1U - *(int *)(iVar4 + -4) | *(int *)(iVar4 + -8) - iVar2) < 0) {
            FUN_00552b90(iVar2);
            iVar4 = *param_1;
          }
          WideCharToMultiByte(3,0,puVar5 + 1,*puVar5,iVar4,iVar2,0,0);
          if (iVar2 <= *(int *)(*param_1 + -8)) {
            *(int *)(*param_1 + -0xc) = iVar2;
            *(undefined *)(iVar2 + *param_1) = 0;
            return 1;
          }
        }
        FUN_005522b0(0x80070057);
        pcVar1 = (code *)swi(3);
        uVar6 = (*pcVar1)();
        return uVar6;
      }
      iVar2 = FUN_016f3257(iVar4);
      iVar4 = iVar4 + 1;
    } while (iVar2 != 0);
  }
  return 0;
}



/* FUNCTION 2648 ; VA 0x00552ac0 ; FUN_00552ac0 */

int __thiscall FUN_00552ac0(int *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  piVar1 = (int *)param_1[2];
  if (piVar1 == (int *)0x0) {
LAB_00552b3c:
    ExceptionList = &pvStack_10;
    iVar2 = RegOpenKeyExA(param_2,param_3,0,param_4,&iStack_14);
  }
  else {
    if (*piVar1 == 0) {
      ExceptionList = &pvStack_10;
      if (piVar1[1] != 0) goto LAB_00552b3c;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar2 = GetModuleHandleA("Advapi32.dll");
      if (iVar2 == 0) {
        iVar2 = 1;
        goto LAB_00552b4f;
      }
      pcVar3 = (code *)GetProcAddress(iVar2,"RegOpenKeyTransactedA");
      if (pcVar3 != (code *)0x0) {
        iVar2 = (*pcVar3)(param_2,param_3,0,param_4,&iStack_14,*piVar1,0);
        goto LAB_00552b4f;
      }
    }
    iVar2 = 1;
  }
LAB_00552b4f:
  if (iVar2 == 0) {
    iVar2 = 0;
    if (*param_1 != 0) {
      iVar2 = RegCloseKey(*param_1);
    }
    *param_1 = iStack_14;
    param_1[1] = param_4 & 0x300;
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 2649 ; VA 0x00552b90 ; FUN_00552b90 */

void __thiscall FUN_00552b90(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *param_1;
  if (param_2 < *(int *)(iVar1 + -0xc)) {
    param_2 = *(int *)(iVar1 + -0xc);
  }
  if (1 < *(int *)(iVar1 + -4)) {
    FUN_005526f0(param_2);
    return;
  }
  iVar1 = *(int *)(iVar1 + -8);
  if (iVar1 < param_2) {
    if (iVar1 < 0x40000001) {
      iVar2 = iVar1 / 2;
    }
    else {
      iVar2 = 0x100000;
    }
    if (param_2 <= iVar2 + iVar1) {
      param_2 = iVar2 + iVar1;
    }
    FUN_00552c60(param_2);
  }
  return;
}



/* FUNCTION 2650 ; VA 0x00552bf0 ; FUN_00552bf0 */

int __thiscall FUN_00552bf0(undefined4 *param_1,undefined4 param_2,undefined *param_3,int *param_4)

{
  undefined *puVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_4;
  puVar1 = param_3;
  iVar3 = *param_4;
  *param_4 = 0;
  param_4 = (int *)iVar3;
  iVar3 = RegQueryValueExA(*param_1,param_2,0,&param_3,param_3,&param_4);
  if (iVar3 == 0) {
    if ((param_3 != (undefined *)0x1) && (param_3 != (undefined *)0x2)) {
      return 0xd;
    }
    if (puVar1 != (undefined *)0x0) {
      if (param_4 == (int *)0x0) {
        *puVar1 = 0;
      }
      else if (puVar1[(int)param_4 + -1] != '\0') {
        return 0xd;
      }
    }
    *piVar2 = (int)param_4;
    iVar3 = 0;
  }
  return iVar3;
}



/* FUNCTION 2651 ; VA 0x00552c60 ; FUN_00552c60 */

void __thiscall FUN_00552c60(int *param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar3 = (undefined4 *)(*param_1 + -0x10);
  if ((*(int *)(*param_1 + -8) < param_2) && (0 < param_2)) {
    iVar2 = (**(code **)(*(int *)*puVar3 + 8))(puVar3,param_2,1);
    if (iVar2 != 0) {
      *param_1 = iVar2 + 0x10;
      return;
    }
  }
  FUN_005534b0();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 2652 ; VA 0x00552ca0 ; FUN_00552ca0 */

int __thiscall FUN_00552ca0(int param_1,undefined4 param_2,int param_3,uint param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  if ((((-1 < param_3) && (0 < 0x7fffffff - param_3)) &&
      (uVar3 = param_3 + 8U & 0xfffffff8, param_3 + 1 <= (int)uVar3)) &&
     (((uVar1 = (uint)((ulonglong)uVar3 * (ulonglong)param_4),
       (int)((ulonglong)uVar3 * (ulonglong)param_4 >> 0x20) == 0 && (uVar1 < 0xfffffff0)) &&
      (iVar2 = (**(code **)(**(int **)(param_1 + 4) + 8))(param_2,uVar1 + 0x10), iVar2 != 0)))) {
    *(uint *)(iVar2 + 8) = uVar3 - 1;
    return iVar2;
  }
  return 0;
}



/* FUNCTION 2653 ; VA 0x00552d00 ; FUN_00552d00 */

undefined4 __thiscall FUN_00552d00(int *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  
  if (param_2 == 0) {
    uVar1 = (**(code **)*param_1)(param_3);
    return uVar1;
  }
  if (param_3 == 0) {
    (**(code **)(*param_1 + 4))(param_2);
    return 0;
  }
  uVar1 = HeapReAlloc(param_1[1],0,param_2,param_3);
  return uVar1;
}



/* FUNCTION 2654 ; VA 0x00552d40 ; FUN_00552d40 */

undefined4 __fastcall FUN_00552d40(int *param_1)

{
  int iVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = *param_1;
  iVar1 = *(int *)(iVar4 + -0xc);
  if (-1 < iVar1) {
    if ((int)(1U - *(int *)(iVar4 + -4) | *(int *)(iVar4 + -8) - iVar1) < 0) {
      FUN_00552b90(iVar1);
      iVar4 = *param_1;
    }
    uVar3 = PathRemoveFileSpecA(iVar4);
    iVar4 = *param_1;
    if (iVar4 != 0) {
      iVar4 = FUN_01717cb5(iVar4,*(undefined4 *)(iVar4 + -8));
      if (iVar4 < 0) goto LAB_00552d9e;
    }
    if (iVar4 <= *(int *)(*param_1 + -8)) {
      *(int *)(*param_1 + -0xc) = iVar4;
      *(undefined *)(iVar4 + *param_1) = 0;
      return uVar3;
    }
  }
LAB_00552d9e:
  FUN_005522b0(0x80070057);
  pcVar2 = (code *)swi(3);
  uVar3 = (*pcVar2)();
  return uVar3;
}



/* FUNCTION 2655 ; VA 0x00552db0 ; FUN_00552db0 */

void FUN_00552db0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017920d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  DAT_01e90c44 = CreateEventA(0,1,0,"Stopped");
  DAT_01e90c40 = RegisterServiceCtrlHandlerA("RCCService",FUN_005528e0);
  FUN_005534c0(2);
  iStack_8 = 0;
  uVar1 = FUN_0054f030();
  iStack_8._0_1_ = 1;
  FUN_00556600(param_1,param_2,0,0,0,uVar1,0,0);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_005507b0();
  FUN_005534c0(4);
  FUN_00552e87();
  return;
}



/* FUNCTION 2656 ; VA 0x00552e59 ; Catch@00552e59 */

undefined * Catch_00552e59(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x18),6);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_005531f0(1,uVar1);
  return &DAT_00552e90;
}



/* FUNCTION 2657 ; VA 0x00552e87 ; FUN_00552e87 */

void FUN_00552e87(void)

{
  undefined uVar1;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  uVar1 = FUN_005555d0(*(undefined4 *)(unaff_EBP + 8),*(undefined4 *)(unaff_EBP + 0xc));
  *(undefined *)(unaff_EBP + -0x11) = uVar1;
  if (DAT_01d59014 == 4) {
    if (*(char *)(unaff_EBP + -0x11) != '\0') {
      DebugBreak();
      *(undefined *)(unaff_EBP + -0x11) = 0;
    }
    *(undefined4 *)(unaff_EBP + -4) = 3;
    FUN_00577ce0();
    FUN_00552f01();
    return;
  }
  SetEvent(DAT_01e90c44);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 2658 ; VA 0x00552ed3 ; Catch@00552ed3 */

undefined * Catch_00552ed3(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0x1c),6);
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_005531f0(1,uVar1);
  return &DAT_00552f0a;
}



/* FUNCTION 2659 ; VA 0x00552f01 ; FUN_00552f01 */

void FUN_00552f01(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  if (DAT_01d59014 == 4) {
    if (*(char *)(unaff_EBP + -0x11) != '\0') {
      DebugBreak();
      *(undefined *)(unaff_EBP + -0x11) = 0;
    }
    *(undefined4 *)(unaff_EBP + -4) = 3;
    FUN_00577ce0();
    FUN_00552f01();
    return;
  }
  SetEvent(DAT_01e90c44);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 2660 ; VA 0x00552f40 ; FUN_00552f40 */

void __thiscall FUN_00552f40(undefined4 *param_1,undefined4 param_2)

{
  RegSetValueExA(*param_1,param_2,0,4,&stack0x00000008,4);
  return;
}



/* FUNCTION 2661 ; VA 0x00552f60 ; FUN_00552f60 */

undefined4 __thiscall
FUN_00552f60(undefined4 *param_1,undefined4 param_2,char *param_3,undefined4 param_4)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  
  if (param_3 == (char *)0x0) {
    return 0xd;
  }
  pcVar2 = param_3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  uVar3 = RegSetValueExA(*param_1,param_2,0,param_4,param_3,pcVar2 + (1 - (int)(param_3 + 1)));
  return uVar3;
}



/* FUNCTION 2662 ; VA 0x00552fb0 ; FUN_00552fb0 */

void FUN_00552fb0(void)

{
  int iVar1;
  undefined auStack_190 [260];
  undefined auStack_8c [12];
  undefined auStack_80 [12];
  undefined auStack_74 [12];
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01792100;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = GetModuleFileNameA(0,auStack_190,0x104);
  if (iVar1 == 0) {
    FUN_00550130("GetModuleFileName failed");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_68,&DAT_01c17198);
  }
  iStack_24 = OpenSCManagerA(0,0,2);
  iStack_8 = 0;
  iStack_20 = iStack_24;
  iStack_1c = iStack_24;
  iStack_18 = iStack_24;
  if (iStack_24 == 0) {
    FUN_00550130("OpenSCManager failed");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_74,&DAT_01c17198);
  }
  iStack_2c = CreateServiceA(iStack_24,"RCCService","Roblox Compute Cloud Service",0xf01ff,0x10,2,1,
                             auStack_190,0,0,0,0,0);
  iStack_8._0_1_ = 1;
  iStack_28 = iStack_2c;
  iStack_14 = iStack_2c;
  if (iStack_2c == 0) {
    iVar1 = GetLastError();
    if (iVar1 != 0x431) {
      FUN_00550130("CreateService failed");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_80,&DAT_01c17198);
    }
    FUN_00557c40("Service already installed\n");
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    CloseServiceHandle(iStack_14);
    iStack_8 = 0xffffffff;
    CloseServiceHandle(iStack_18);
  }
  else {
    FUN_00557c40("Service installed successfully\n");
    uStack_44 = 100;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = 3;
    uStack_58 = 5000;
    uStack_5c = 1;
    uStack_50 = 55000;
    uStack_54 = 1;
    uStack_48 = 60000;
    uStack_4c = 1;
    puStack_34 = &uStack_5c;
    iStack_30 = iStack_14;
    iVar1 = ChangeServiceConfig2A(iStack_14,2,&uStack_44);
    if (iVar1 == 0) {
      FUN_00550130("ChangeServiceConfig2 failed");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_8c,&DAT_01c17198);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    CloseServiceHandle(iStack_14);
    iStack_8 = 0xffffffff;
    CloseServiceHandle(iStack_18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2663 ; VA 0x005531f0 ; FUN_005531f0 */

void FUN_005531f0(undefined2 param_1)

{
  int iVar1;
  
  iVar1 = RegisterEventSourceA(0,"RCCService");
  if (iVar1 != 0) {
    ReportEventA(iVar1,param_1,0,0x20000001,0,1,0,&stack0x00000008,0);
    DeregisterEventSource(iVar1);
  }
  return;
}



/* FUNCTION 2664 ; VA 0x00553250 ; FUN_00553250 */

void FUN_00553250(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar1 = OpenSCManagerA(0,0,0xf003f);
  iVar2 = OpenServiceA(uVar1,param_1,0x10);
  if (iVar2 == 0) {
    uVar3 = GetLastError();
    FUN_00557c40("OpenService failed (%d)\n",uVar3);
    CloseServiceHandle(0);
    CloseServiceHandle(uVar1);
  }
  else {
    iVar4 = StartServiceA(iVar2,0,0);
    if (iVar4 == 0) {
      uVar3 = GetLastError();
      FUN_00557c40("StartService failed (%d)\n",uVar3);
    }
    else {
      FUN_00557c40("Service Starting\n");
    }
    CloseServiceHandle(iVar2);
    CloseServiceHandle(uVar1);
  }
  return;
}



/* FUNCTION 2665 ; VA 0x00553320 ; FUN_00553320 */

void FUN_00553320(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_3c [28];
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_14 = OpenSCManagerA(0,0,0xf003f);
  uStack_10 = uStack_14;
  uStack_c = uStack_14;
  iStack_20 = OpenServiceA(uStack_14,param_1,0x20);
  iStack_1c = iStack_20;
  iStack_18 = iStack_20;
  iStack_8 = iStack_20;
  if (iStack_20 == 0) {
    uVar1 = GetLastError();
    FUN_00557c40("OpenService failed (%d)\n",uVar1);
    CloseServiceHandle(iStack_8);
    CloseServiceHandle(uStack_c);
  }
  else {
    iVar2 = ControlService(iStack_20,1,auStack_3c);
    if (iVar2 == 0) {
      uVar1 = GetLastError();
      FUN_00557c40("ControlService failed (%d)\n",uVar1);
    }
    CloseServiceHandle(iStack_8);
    CloseServiceHandle(uStack_c);
  }
  return;
}



/* FUNCTION 2666 ; VA 0x005533e0 ; FUN_005533e0 */

bool FUN_005533e0(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  bool bVar5;
  
  uVar1 = OpenSCManagerA(0,0,0xf003f);
  iVar2 = OpenServiceA(uVar1,param_1,0x10000);
  if (iVar2 == 0) {
    uVar3 = GetLastError();
    FUN_00557c40("OpenService failed (%d)\n",uVar3);
    CloseServiceHandle(0);
    CloseServiceHandle(uVar1);
    bVar5 = false;
  }
  else {
    iVar4 = DeleteService(iVar2);
    bVar5 = iVar4 != 0;
    CloseServiceHandle(iVar2);
    CloseServiceHandle(uVar1);
  }
  return bVar5;
}



/* FUNCTION 2667 ; VA 0x005534b0 ; FUN_005534b0 */

void FUN_005534b0(void)

{
  code *pcVar1;
  
  FUN_005522b0(0x8007000e);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 2668 ; VA 0x005534c0 ; FUN_005534c0 */

void FUN_005534c0(undefined4 param_1)

{
  DAT_01d59014 = param_1;
  SetServiceStatus(DAT_01e90c40,&DAT_01d59010);
  return;
}



/* FUNCTION 2669 ; VA 0x005534e0 ; FUN_005534e0 */

void FUN_005534e0(int *param_1,int *param_2)

{
  int iVar1;
  
  *param_2 = *param_2 + 0x23;
  iVar1 = *(int *)(*param_1 + -4);
  if ((*param_1 - iVar1) - 4U < 0x20) {
    *param_1 = iVar1;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 2670 ; VA 0x00553510 ; FUN_00553510 */

void FUN_00553510(void)

{
  return;
}



/* FUNCTION 2671 ; VA 0x00553520 ; FUN_00553520 */

ushort * FUN_00553520(undefined4 param_1,undefined4 param_2,uint param_3)

{
  ushort *puVar1;
  int iVar2;
  ushort *puVar3;
  
  iVar2 = LoadResource(param_1,param_2);
  if ((iVar2 != 0) && (puVar3 = (ushort *)LockResource(iVar2), puVar3 != (ushort *)0x0)) {
    iVar2 = SizeofResource(param_1,param_2);
    puVar1 = (ushort *)((int)puVar3 + iVar2);
    for (param_3 = param_3 & 0xf; param_3 != 0; param_3 = param_3 - 1) {
      if (puVar1 <= puVar3) {
        return (ushort *)0x0;
      }
      puVar3 = puVar3 + *puVar3 + 1;
    }
    if ((puVar3 < puVar1) && (*puVar3 != 0)) {
      return puVar3;
    }
  }
  return (ushort *)0x0;
}



/* FUNCTION 2672 ; VA 0x00553580 ; FUN_00553580 */

void FUN_00553580(undefined4 param_1,undefined4 param_2)

{
  RaiseException(param_1,param_2,0,0);
  return;
}



/* FUNCTION 2673 ; VA 0x005535a0 ; FUN_005535a0 */

void FUN_005535a0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x40);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 2674 ; VA 0x005535c0 ; FUN_005535c0 */

undefined4 FUN_005535c0(undefined4 *param_1)

{
  (**(code **)*param_1)();
  return 0;
}



/* FUNCTION 2675 ; VA 0x005535d0 ; FUN_005535d0 */

int FUN_005535d0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_016df1c8(param_1,param_2);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  return iVar1;
}



/* FUNCTION 2676 ; VA 0x00553600 ; FUN_00553600 */

void __thiscall FUN_00553600(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  uVar1 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar1 < 0x10) {
    uVar4 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar4;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = uVar1;
    param_1[5] = 0xf;
    return;
  }
  uVar5 = uVar1 | 0xf;
  if (0x7fffffff < uVar5) {
    uVar5 = 0x7fffffff;
  }
  uVar4 = FUN_00554060(uVar5 + 1);
  *param_1 = uVar4;
  FUN_0170c6f0(uVar4,param_2,uVar1 + 1);
  param_1[4] = uVar1;
  param_1[5] = uVar5;
  return;
}



/* FUNCTION 2677 ; VA 0x00553670 ; FUN_00553670 */

void __thiscall FUN_00553670(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  
  uVar1 = param_2[4];
  if (7 < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  if (uVar1 < 8) {
    uVar4 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar4;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    param_1[4] = uVar1;
    param_1[5] = 7;
    return;
  }
  uVar5 = uVar1 | 7;
  if (0x7ffffffe < uVar5) {
    uVar5 = 0x7ffffffe;
  }
  uVar4 = FUN_005540c0(uVar5 + 1);
  *param_1 = uVar4;
  FUN_0170c6f0(uVar4,param_2,uVar1 * 2 + 2);
  param_1[4] = uVar1;
  param_1[5] = uVar5;
  return;
}



/* FUNCTION 2678 ; VA 0x005536f0 ; FUN_005536f0 */

int __fastcall FUN_005536f0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  LOCK();
  piVar1 = param_1 + 1;
  iVar3 = *piVar1;
  iVar2 = *piVar1;
  *piVar1 = iVar3 + -1;
  UNLOCK();
  if (iVar3 + -1 == 0) {
    iVar2 = (**(code **)*param_1)();
    LOCK();
    piVar1 = param_1 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00553712. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar3 = (**(code **)(*param_1 + 4))();
      return iVar3;
    }
  }
  return iVar2;
}



/* FUNCTION 2679 ; VA 0x00553720 ; FUN_00553720 */

int __fastcall FUN_00553720(int param_1)

{
  int iVar1;
  int iVar2;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 4) + -1;
  *(int *)(param_1 + 4) = iVar1;
  UNLOCK();
  iVar2 = 0;
  if (iVar1 == 0) {
    iVar2 = param_1;
  }
  return iVar2;
}



/* FUNCTION 2680 ; VA 0x00553740 ; FUN_00553740 */

int __fastcall FUN_00553740(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  LOCK();
  piVar1 = param_1 + 2;
  iVar3 = *piVar1;
  iVar2 = *piVar1;
  *piVar1 = iVar3 + -1;
  UNLOCK();
  if (iVar3 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0055374c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar3 = (**(code **)(*param_1 + 4))();
    return iVar3;
  }
  return iVar2;
}



/* FUNCTION 2681 ; VA 0x00553750 ; FUN_00553750 */

bool __fastcall FUN_00553750(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined auStack_28 [32];
  int iStack_8;
  
  if ((param_1[0xe] == 0) || (*(char *)((int)param_1 + 0x3d) == '\0')) {
    return true;
  }
  iVar1 = (**(code **)(*param_1 + 0xc))(0xffffffff);
  if (iVar1 == -1) {
    return false;
  }
  iVar1 = (**(code **)(*(int *)param_1[0xe] + 0x20))(param_1 + 0x10,auStack_28,&iStack_8,&iStack_8);
  if (iVar1 == 0) {
    *(undefined *)((int)param_1 + 0x3d) = 0;
  }
  else if (iVar1 != 1) {
    if (iVar1 != 3) {
      return false;
    }
    return true;
  }
  iVar1 = iStack_8 - (int)auStack_28;
  if ((iVar1 != 0) && (iVar2 = FUN_01719056(auStack_28,1,iVar1,param_1[0x13]), iVar1 != iVar2)) {
    return false;
  }
  return *(char *)((int)param_1 + 0x3d) == '\0';
}



/* FUNCTION 2682 ; VA 0x005537e0 ; FUN_005537e0 */

void FUN_005537e0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_005537e0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00551de0(0);
    FUN_01674ea0(param_1,0x40);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 2683 ; VA 0x00553830 ; FUN_00553830 */

/* WARNING: Removing unreachable block (ram,0x005538f9) */
/* WARNING: Removing unreachable block (ram,0x00553909) */
/* WARNING: Removing unreachable block (ram,0x00553912) */
/* WARNING: Removing unreachable block (ram,0x00553915) */
/* WARNING: Removing unreachable block (ram,0x00553905) */
/* WARNING: Removing unreachable block (ram,0x00553923) */
/* WARNING: Removing unreachable block (ram,0x0055392f) */
/* WARNING: Removing unreachable block (ram,0x0055393a) */
/* WARNING: Removing unreachable block (ram,0x00553936) */
/* WARNING: Removing unreachable block (ram,0x0055392a) */
/* WARNING: Removing unreachable block (ram,0x0055393d) */

int * __thiscall FUN_00553830(int *param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  FUN_00551320();
  piVar6 = (int *)param_2[2];
  if ((*(char *)(*param_2 + 0xd) == '\0') &&
     (piVar6 = (int *)*param_2, *(char *)(param_2[2] + 0xd) == '\0')) {
    piVar6 = (int *)param_2[2];
  }
  piVar5 = (int *)param_2[1];
  if (*(char *)((int)piVar6 + 0xd) == '\0') {
    piVar6[1] = (int)piVar5;
  }
  if (*(int **)(*param_1 + 4) == param_2) {
    *(int **)(*param_1 + 4) = piVar6;
  }
  else if ((int *)*piVar5 == param_2) {
    *piVar5 = (int)piVar6;
  }
  else {
    piVar5[2] = (int)piVar6;
  }
  if (*(int **)*param_1 == param_2) {
    piVar4 = piVar5;
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      cVar1 = *(char *)(*piVar6 + 0xd);
      piVar2 = (int *)*piVar6;
      piVar4 = piVar6;
      while (piVar3 = piVar2, cVar1 == '\0') {
        piVar2 = (int *)*piVar3;
        cVar1 = *(char *)((int)piVar2 + 0xd);
        piVar4 = piVar3;
      }
    }
    *(int **)*param_1 = piVar4;
  }
  if (*(int **)(*param_1 + 8) == param_2) {
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      cVar1 = *(char *)(piVar6[2] + 0xd);
      piVar4 = (int *)piVar6[2];
      piVar2 = piVar6;
      while (piVar3 = piVar4, cVar1 == '\0') {
        piVar4 = (int *)piVar3[2];
        cVar1 = *(char *)((int)piVar4 + 0xd);
        piVar2 = piVar3;
      }
      *(int **)(*param_1 + 8) = piVar2;
    }
    else {
      *(int **)(*param_1 + 8) = piVar5;
    }
  }
  if (*(char *)(param_2 + 3) == '\x01') {
    if (piVar6 != *(int **)(*param_1 + 4)) {
      do {
        piVar4 = piVar5;
        if (*(char *)(piVar6 + 3) != '\x01') break;
        piVar5 = (int *)*piVar4;
        if (piVar6 == piVar5) {
          piVar5 = (int *)piVar4[2];
          if (*(char *)(piVar5 + 3) == '\0') {
            *(undefined *)(piVar5 + 3) = 1;
            *(undefined *)(piVar4 + 3) = 0;
            FUN_00553e40(piVar4);
            piVar5 = (int *)piVar4[2];
          }
          if (*(char *)((int)piVar5 + 0xd) == '\0') {
            if ((*(char *)(*piVar5 + 0xc) != '\x01') || (*(char *)(piVar5[2] + 0xc) != '\x01')) {
              if (*(char *)(piVar5[2] + 0xc) == '\x01') {
                *(undefined *)(*piVar5 + 0xc) = 1;
                *(undefined *)(piVar5 + 3) = 0;
                FUN_00553f50(piVar5);
                piVar5 = (int *)piVar4[2];
              }
              *(undefined *)(piVar5 + 3) = *(undefined *)(piVar4 + 3);
              *(undefined *)(piVar4 + 3) = 1;
              *(undefined *)(piVar5[2] + 0xc) = 1;
              FUN_00553e40(piVar4);
              break;
            }
LAB_00553a29:
            *(undefined *)(piVar5 + 3) = 0;
          }
        }
        else {
          if (*(char *)(piVar5 + 3) == '\0') {
            *(undefined *)(piVar5 + 3) = 1;
            *(undefined *)(piVar4 + 3) = 0;
            FUN_00553f50(piVar4);
            piVar5 = (int *)*piVar4;
          }
          if (*(char *)((int)piVar5 + 0xd) == '\0') {
            if ((*(char *)(piVar5[2] + 0xc) == '\x01') && (*(char *)(*piVar5 + 0xc) == '\x01'))
            goto LAB_00553a29;
            if (*(char *)(*piVar5 + 0xc) == '\x01') {
              *(undefined *)(piVar5[2] + 0xc) = 1;
              *(undefined *)(piVar5 + 3) = 0;
              FUN_00553e40(piVar5);
              piVar5 = (int *)*piVar4;
            }
            *(undefined *)(piVar5 + 3) = *(undefined *)(piVar4 + 3);
            *(undefined *)(piVar4 + 3) = 1;
            *(undefined *)(*piVar5 + 0xc) = 1;
            FUN_00553f50(piVar4);
            break;
          }
        }
        piVar5 = (int *)piVar4[1];
        piVar6 = piVar4;
      } while (piVar4 != *(int **)(*param_1 + 4));
    }
    *(undefined *)(piVar6 + 3) = 1;
  }
  if (param_1[1] == 0) {
    return param_2;
  }
  param_1[1] = param_1[1] + -1;
  return param_2;
}



/* FUNCTION 2684 ; VA 0x00553aa0 ; FUN_00553aa0 */

int __thiscall FUN_00553aa0(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 4);
  if (param_2 < *(uint *)(iVar1 + 0xc)) {
    iVar2 = *(int *)(*(int *)(iVar1 + 8) + param_2 * 4);
    if (iVar2 != 0) {
      return iVar2;
    }
  }
  else {
    iVar2 = 0;
  }
  if (*(char *)(iVar1 + 0x14) != '\0') {
    iVar1 = FUN_016de17b();
    if (param_2 < *(uint *)(iVar1 + 0xc)) {
      return *(int *)(*(int *)(iVar1 + 8) + param_2 * 4);
    }
    iVar2 = 0;
  }
  return iVar2;
}



/* FUNCTION 2685 ; VA 0x00553ae0 ; FUN_00553ae0 */

void __fastcall FUN_00553ae0(int param_1)

{
  if (**(int **)(param_1 + 0x1c) != 0) {
    return;
  }
  return;
}



/* FUNCTION 2686 ; VA 0x00553b00 ; FUN_00553b00 */

void __fastcall FUN_00553b00(int param_1)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  uStack_8 = 0;
  iVar2 = FUN_016dee6d(*(undefined4 *)(param_1 + 8));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  *(undefined *)(param_1 + 0xc) = 1;
  iVar2 = FUN_016df1a0(*(undefined4 *)(param_1 + 4));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  iVar2 = FUN_016deec8(*(undefined4 *)(param_1 + 8));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  FUN_00551530();
  FUN_016df1dd();
  if (iVar1 != 0) {
    FUN_01674ea0(iVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2687 ; VA 0x00553bb0 ; FUN_00553bb0 */

void __fastcall FUN_00553bb0(int param_1)

{
  LOCK();
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
  UNLOCK();
  return;
}



/* FUNCTION 2688 ; VA 0x00553bc0 ; FUN_00553bc0 */

void __thiscall FUN_00553bc0(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uStack_8;
  
  iVar1 = param_2;
  *(bool *)(param_1 + 0x48) = param_3 == 1;
  *(int *)(param_1 + 0xc) = param_1 + 4;
  *(int *)(param_1 + 0x1c) = param_1 + 0x14;
  *(int *)(param_1 + 0x20) = param_1 + 0x18;
  *(int *)(param_1 + 0x2c) = param_1 + 0x24;
  *(int *)(param_1 + 0x30) = param_1 + 0x28;
  *(undefined *)(param_1 + 0x3d) = 0;
  *(undefined4 **)(param_1 + 0x10) = (undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 8) = 0;
  **(undefined4 **)(param_1 + 0x20) = 0;
  **(undefined4 **)(param_1 + 0x30) = 0;
  **(undefined4 **)(param_1 + 0xc) = 0;
  **(undefined4 **)(param_1 + 0x1c) = 0;
  **(undefined4 **)(param_1 + 0x2c) = 0;
  if (param_2 != 0) {
    param_3 = 0;
    param_2 = 0;
    uStack_8 = 0;
    FUN_017180ab(iVar1,&param_3,&param_2,&uStack_8);
    *(int *)(param_1 + 0xc) = param_3;
    *(int *)(param_1 + 0x10) = param_3;
    *(int *)(param_1 + 0x1c) = param_2;
    *(int *)(param_1 + 0x20) = param_2;
    *(undefined4 *)(param_1 + 0x2c) = uStack_8;
    *(undefined4 *)(param_1 + 0x30) = uStack_8;
  }
  *(int *)(param_1 + 0x4c) = iVar1;
  *(undefined4 *)(param_1 + 0x40) = DAT_01e90d08;
  *(undefined4 *)(param_1 + 0x44) = DAT_01e90d0c;
  *(undefined4 *)(param_1 + 0x38) = 0;
  return;
}



/* FUNCTION 2689 ; VA 0x00553ca0 ; FUN_00553ca0 */

void __fastcall FUN_00553ca0(int param_1)

{
  *(int *)(param_1 + 0xc) = param_1 + 4;
  *(undefined4 **)(param_1 + 0x10) = (undefined4 *)(param_1 + 8);
  *(int *)(param_1 + 0x1c) = param_1 + 0x14;
  *(int *)(param_1 + 0x20) = param_1 + 0x18;
  *(int *)(param_1 + 0x2c) = param_1 + 0x24;
  *(int *)(param_1 + 0x30) = param_1 + 0x28;
  *(undefined4 *)(param_1 + 8) = 0;
  **(undefined4 **)(param_1 + 0x20) = 0;
  **(undefined4 **)(param_1 + 0x30) = 0;
  **(undefined4 **)(param_1 + 0xc) = 0;
  **(undefined4 **)(param_1 + 0x1c) = 0;
  **(undefined4 **)(param_1 + 0x2c) = 0;
  return;
}



/* FUNCTION 2690 ; VA 0x00553d00 ; FUN_00553d00 */

void __fastcall FUN_00553d00(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0x201;
  *(undefined4 *)(param_1 + 0x18) = 6;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  iVar1 = FUN_01674e20(8);
  if (iVar1 != 0) {
    uStack_8 = 0;
    uVar2 = FUN_016de181(1);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    *(int *)(param_1 + 0x30) = iVar1;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2691 ; VA 0x00553dc0 ; FUN_00553dc0 */

void __thiscall FUN_00553dc0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = FUN_016de8aa(param_2,FUN_005535c0,param_1);
  iVar3 = 1;
  if (iVar2 != 4) {
    iVar3 = iVar2;
  }
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  cVar1 = *(char *)(param_1 + 0xc);
  while (cVar1 == '\0') {
    iVar3 = FUN_016df1c8(*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8));
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    cVar1 = *(char *)(param_1 + 0xc);
  }
  return;
}



/* FUNCTION 2692 ; VA 0x00553e20 ; FUN_00553e20 */

void __fastcall FUN_00553e20(int param_1)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_017180f1(*(int *)(param_1 + 0x4c));
  }
  return;
}



/* FUNCTION 2693 ; VA 0x00553e30 ; _guard_check_icall */

void _guard_check_icall(void)

{
  return;
}



/* FUNCTION 2694 ; VA 0x00553e40 ; FUN_00553e40 */

void __thiscall FUN_00553e40(int *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = *(int **)(param_2 + 8);
  *(int *)(param_2 + 8) = *piVar1;
  if (*(char *)(*piVar1 + 0xd) == '\0') {
    *(int *)(*piVar1 + 4) = param_2;
  }
  piVar1[1] = *(int *)(param_2 + 4);
  if (param_2 == *(int *)(*param_1 + 4)) {
    *(int **)(*param_1 + 4) = piVar1;
    *piVar1 = param_2;
    *(int **)(param_2 + 4) = piVar1;
    return;
  }
  piVar2 = *(int **)(param_2 + 4);
  if (param_2 == *piVar2) {
    *piVar2 = (int)piVar1;
    *piVar1 = param_2;
    *(int **)(param_2 + 4) = piVar1;
    return;
  }
  piVar2[2] = (int)piVar1;
  *piVar1 = param_2;
  *(int **)(param_2 + 4) = piVar1;
  return;
}



/* FUNCTION 2695 ; VA 0x00553ea0 ; FUN_00553ea0 */

int FUN_00553ea0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_016dee6d(param_1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  return iVar1;
}



/* FUNCTION 2696 ; VA 0x00553ed0 ; FUN_00553ed0 */

int FUN_00553ed0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_016deec8(param_1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  return iVar1;
}



/* FUNCTION 2697 ; VA 0x00553f00 ; FUN_00553f00 */

void __fastcall FUN_00553f00(int param_1)

{
  if (**(int **)(param_1 + 0x20) != 0) {
    return;
  }
  return;
}



/* FUNCTION 2698 ; VA 0x00553f20 ; FUN_00553f20 */

void __fastcall FUN_00553f20(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (**(int **)(param_1 + 0xc) == param_1 + 0x3c) {
    iVar1 = *(int *)(param_1 + 0x50);
    iVar2 = *(int *)(param_1 + 0x54);
    **(int **)(param_1 + 0xc) = iVar1;
    **(int **)(param_1 + 0x1c) = iVar1;
    **(int **)(param_1 + 0x2c) = iVar2 - iVar1;
  }
  return;
}



/* FUNCTION 2699 ; VA 0x00553f50 ; FUN_00553f50 */

void __thiscall FUN_00553f50(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = *param_2;
  *param_2 = *(int *)(iVar1 + 8);
  if (*(char *)(*(int *)(iVar1 + 8) + 0xd) == '\0') {
    *(int **)(*(int *)(iVar1 + 8) + 4) = param_2;
  }
  *(int *)(iVar1 + 4) = param_2[1];
  if (param_2 == *(int **)(*param_1 + 4)) {
    *(int *)(*param_1 + 4) = iVar1;
    *(int **)(iVar1 + 8) = param_2;
    param_2[1] = iVar1;
    return;
  }
  piVar2 = (int *)param_2[1];
  if (param_2 == (int *)piVar2[2]) {
    piVar2[2] = iVar1;
    *(int **)(iVar1 + 8) = param_2;
    param_2[1] = iVar1;
    return;
  }
  *piVar2 = iVar1;
  *(int **)(iVar1 + 8) = param_2;
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 2700 ; VA 0x00553fb0 ; FUN_00553fb0 */

void __fastcall FUN_00553fb0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005537e0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2701 ; VA 0x00554010 ; FUN_00554010 */

void __fastcall FUN_00554010(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  return;
}



/* FUNCTION 2702 ; VA 0x00554030 ; FUN_00554030 */

void __fastcall FUN_00554030(int param_1)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01718105(*(int *)(param_1 + 0x4c));
  }
  return;
}



/* FUNCTION 2703 ; VA 0x00554040 ; FUN_00554040 */

void FUN_00554040(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("string too long");
}



/* FUNCTION 2704 ; VA 0x00554050 ; FUN_00554050 */

void FUN_00554050(void)

{
  code *pcVar1;
  
  FUN_016ddcf9("invalid string position");
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 2705 ; VA 0x00554060 ; FUN_00554060 */

uint FUN_00554060(uint param_1)

{
  uint uVar1;
  int iVar2;
  
  if (param_1 < 0x1000) {
    if (param_1 != 0) {
      uVar1 = FUN_01674e20(param_1);
      return uVar1;
    }
    return 0;
  }
  uVar1 = param_1 + 0x23;
  if (uVar1 <= param_1) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    return uVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 2706 ; VA 0x005540c0 ; FUN_005540c0 */

uint FUN_005540c0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 2;
  if (param_1 < 0x80000000) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 2707 ; VA 0x00554130 ; FUN_00554130 */

void FUN_00554130(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_00554150(param_1,*puVar1);
  return;
}



/* FUNCTION 2708 ; VA 0x00554150 ; FUN_00554150 */

int * __thiscall FUN_00554150(int *param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  
  uVar2 = param_1[5];
  iVar8 = param_1[4];
  if (param_3 <= uVar2 - iVar8) {
    param_1[4] = iVar8 + param_3;
    piVar4 = param_1;
    if (0xf < uVar2) {
      piVar4 = (int *)*param_1;
    }
    FUN_0170cc70(iVar8 + (int)piVar4,param_2,param_3);
    *(undefined *)(iVar8 + (int)piVar4 + param_3) = 0;
    return param_1;
  }
  if (0x7fffffffU - iVar8 < param_3) {
    FUN_00554040();
LAB_005542a0:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uVar7 = iVar8 + param_3 | 0xf;
  if (uVar7 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar7 = 0x7fffffff;
    }
    else {
      uVar5 = (uVar2 >> 1) + uVar2;
      if (uVar7 < uVar5) {
        uVar7 = uVar5;
      }
    }
  }
  else {
    uVar7 = 0x7fffffff;
  }
  iVar6 = FUN_00554060(uVar7 + 1);
  param_1[4] = iVar8 + param_3;
  param_1[5] = uVar7;
  iVar1 = iVar6 + iVar8;
  if (uVar2 < 0x10) {
    FUN_0170c6f0(iVar6,param_1,iVar8);
    FUN_0170c6f0(iVar1,param_2,param_3);
    *(undefined *)(iVar1 + param_3) = 0;
    *param_1 = iVar6;
    return param_1;
  }
  iVar3 = *param_1;
  FUN_0170c6f0(iVar6,iVar3,iVar8);
  FUN_0170c6f0(iVar1,param_2,param_3);
  uVar7 = uVar2 + 1;
  *(undefined *)(iVar1 + param_3) = 0;
  iVar8 = iVar3;
  if (0xfff < uVar7) {
    iVar8 = *(int *)(iVar3 + -4);
    uVar7 = uVar2 + 0x24;
    if (0x1f < (iVar3 - iVar8) - 4U) goto LAB_005542a0;
  }
  FUN_01674ea0(iVar8,uVar7);
  *param_1 = iVar6;
  return param_1;
}



/* FUNCTION 2709 ; VA 0x005542b0 ; FUN_005542b0 */

undefined FUN_005542b0(void)

{
  return DAT_020c0b1c;
}



/* FUNCTION 2710 ; VA 0x005542c0 ; FUN_005542c0 */

int * __thiscall FUN_005542c0(int *param_1,undefined4 param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  
  uVar2 = param_1[5];
  if (param_3 <= uVar2) {
    piVar7 = param_1;
    if (0xf < uVar2) {
      piVar7 = (int *)*param_1;
    }
    param_1[4] = param_3;
    FUN_0170cc70(piVar7,param_2,param_3);
    *(undefined *)((int)piVar7 + param_3) = 0;
    return param_1;
  }
  if (0x7fffffff < param_3) {
    FUN_00554040();
    pcVar4 = (code *)swi(3);
    piVar7 = (int *)(*pcVar4)();
    return piVar7;
  }
  uVar8 = param_3 | 0xf;
  if (uVar8 < 0x80000000) {
    if (0x7fffffff - (uVar2 >> 1) < uVar2) {
      uVar8 = 0x7fffffff;
    }
    else {
      uVar1 = (uVar2 >> 1) + uVar2;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
  }
  else {
    uVar8 = 0x7fffffff;
  }
  iVar5 = FUN_00554060(uVar8 + 1);
  param_1[5] = uVar8;
  param_1[4] = param_3;
  FUN_0170c6f0(iVar5,param_2,param_3);
  *(undefined *)(iVar5 + param_3) = 0;
  if (0xf < uVar2) {
    uVar8 = uVar2 + 1;
    iVar3 = *param_1;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  *param_1 = iVar5;
  return param_1;
}



/* FUNCTION 2711 ; VA 0x005543b0 ; FUN_005543b0 */

void __thiscall FUN_005543b0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
      return;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
  }
  return;
}



/* FUNCTION 2712 ; VA 0x005543f0 ; FUN_005543f0 */

undefined4 * __fastcall FUN_005543f0(undefined4 *param_1)

{
  if (0xf < (uint)param_1[5]) {
    return (undefined4 *)*param_1;
  }
  return param_1;
}



/* FUNCTION 2713 ; VA 0x00554400 ; FUN_00554400 */

undefined4 * __fastcall FUN_00554400(undefined4 *param_1)

{
  if (7 < (uint)param_1[5]) {
    return (undefined4 *)*param_1;
  }
  return param_1;
}



/* FUNCTION 2714 ; VA 0x00554410 ; FUN_00554410 */

undefined1 * __fastcall FUN_00554410(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 0) {
    return &DAT_018bc9b8;
  }
  if (*(undefined1 **)(iVar1 + 0x18) != (undefined1 *)0x0) {
    return *(undefined1 **)(iVar1 + 0x18);
  }
  return (undefined1 *)(iVar1 + 0x1c);
}



/* FUNCTION 2715 ; VA 0x00554430 ; FUN_00554430 */

void __fastcall FUN_00554430(uint *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  return;
}



/* FUNCTION 2716 ; VA 0x00554460 ; FUN_00554460 */

void __thiscall FUN_00554460(int param_1,uint param_2,char param_3)

{
  undefined4 uVar1;
  uint uVar2;
  char *pcVar3;
  undefined auStack_20 [20];
  undefined auStack_c [8];
  
  *(uint *)(param_1 + 0xc) = param_2 & 0x17;
  uVar2 = *(uint *)(param_1 + 0x10) & param_2 & 0x17;
  if (uVar2 == 0) {
    return;
  }
  if (param_3 != '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(0,0);
  }
  if ((uVar2 & 4) == 0) {
    pcVar3 = "ios_base::failbit set";
    if ((uVar2 & 2) == 0) {
      pcVar3 = "ios_base::eofbit set";
    }
  }
  else {
    pcVar3 = "ios_base::badbit set";
  }
  uVar1 = FUN_00555250(auStack_c,1);
  FUN_0054ff80(pcVar3,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c171ec);
}



/* FUNCTION 2717 ; VA 0x005544d2 ; FUN_005544d2 */

void FUN_005544d2(void)

{
  FUN_005544e0();
  return;
}



/* FUNCTION 2718 ; VA 0x005544e0 ; FUN_005544e0 */

int __fastcall FUN_005544e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179214b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_018bd31c;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::bad_function_call::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::bad_function_call>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 2719 ; VA 0x005545f7 ; FUN_005545f7 */

void FUN_005545f7(void)

{
  FUN_00554600();
  return;
}



/* FUNCTION 2720 ; VA 0x00554600 ; FUN_00554600 */

int __fastcall FUN_00554600(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792193;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x4c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[0x10] = &DAT_018bd2dc;
    puVar1[0x12] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 1;
    FUN_0054f450(param_1 + -0x48);
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
              ::vftable;
    puVar1[0xb] = boost::exception_detail::
                  clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
                  ::vftable;
    uStack_8 = 2;
    *(undefined ***)(*(int *)(puVar1[0x10] + 4) + 0x40 + (int)puVar1) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_boost::thread_resource_error>_>
         ::vftable;
    *(int *)(*(int *)(puVar1[0x10] + 4) + 0x3c + (int)puVar1) = *(int *)(puVar1[0x10] + 4) + -8;
    FUN_00554960(puVar1 + 0xb,-(uint)(param_1 + -0x48 != 0) & param_1 - 0x1cU);
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[0x10] + 4) + 0x40 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 2721 ; VA 0x005546d9 ; FUN_005546d9 */

void FUN_005546d9(void)

{
  FUN_005546f0();
  return;
}



/* FUNCTION 2722 ; VA 0x005546f0 ; FUN_005546f0 */

int __fastcall FUN_005546f0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017921d3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[8] = &DAT_018bd358;
    puVar1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 1;
    FUN_0054fbe0(param_1 + -0x28);
    *puVar1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
              vftable;
    puVar1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::
                vftable;
    uStack_8 = 2;
    *(undefined ***)(*(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1) =
         boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_alloc_>::vftable;
    *(int *)(*(int *)(puVar1[8] + 4) + 0x1c + (int)puVar1) = *(int *)(puVar1[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x28);
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 2723 ; VA 0x005547ba ; FUN_005547ba */

void FUN_005547ba(void)

{
  FUN_005547d0();
  return;
}



/* FUNCTION 2724 ; VA 0x005547d0 ; FUN_005547d0 */

int __fastcall FUN_005547d0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792213;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[8] = &DAT_018bd470;
    puVar1[10] = boost::exception_detail::clone_base::vftable;
    uStack_8 = 1;
    FUN_0054fce0(param_1 + -0x28);
    *puVar1 = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
              vftable;
    puVar1[5] = boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>
                ::vftable;
    uStack_8 = 2;
    *(undefined ***)(*(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1) =
         boost::exception_detail::clone_impl<struct_boost::exception_detail::bad_exception_>::
         vftable;
    *(int *)(*(int *)(puVar1[8] + 4) + 0x1c + (int)puVar1) = *(int *)(puVar1[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x28);
    ExceptionList = pvStack_10;
    return *(int *)(puVar1[8] + 4) + 0x20 + (int)puVar1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 2725 ; VA 0x005548a0 ; FUN_005548a0 */

int __fastcall FUN_005548a0(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) == 0) {
    iVar3 = 0;
  }
  else {
    cVar1 = FUN_00553750();
    iVar3 = param_1;
    if (cVar1 == '\0') {
      iVar3 = 0;
    }
    iVar2 = FUN_01718190(*(undefined4 *)(param_1 + 0x4c));
    if (iVar2 != 0) {
      iVar3 = 0;
    }
  }
  *(undefined *)(param_1 + 0x48) = 0;
  *(int *)(param_1 + 0xc) = param_1 + 4;
  *(undefined4 **)(param_1 + 0x10) = (undefined4 *)(param_1 + 8);
  *(int *)(param_1 + 0x1c) = param_1 + 0x14;
  *(int *)(param_1 + 0x20) = param_1 + 0x18;
  *(int *)(param_1 + 0x2c) = param_1 + 0x24;
  *(int *)(param_1 + 0x30) = param_1 + 0x28;
  *(undefined *)(param_1 + 0x3d) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  **(undefined4 **)(param_1 + 0x20) = 0;
  **(undefined4 **)(param_1 + 0x30) = 0;
  **(undefined4 **)(param_1 + 0xc) = 0;
  **(undefined4 **)(param_1 + 0x1c) = 0;
  **(undefined4 **)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x40) = DAT_01e90d08;
  *(undefined4 *)(param_1 + 0x44) = DAT_01e90d0c;
  *(undefined4 *)(param_1 + 0x38) = 0;
  return iVar3;
}



/* FUNCTION 2726 ; VA 0x00554960 ; FUN_00554960 */

void FUN_00554960(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  piVar1 = param_2;
  puStack_c = &LAB_01792230;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)0x0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((int *)param_2[1] != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piVar3 = (int *)(**(code **)(*(int *)param_2[1] + 0x14))(&param_2);
    piVar3 = (int *)*piVar3;
    iStack_8._0_1_ = 1;
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0xc))();
    }
    iStack_8._0_1_ = 2;
    if ((param_2 != (int *)0x0) && (cVar2 = (**(code **)(*param_2 + 0x10))(), cVar2 != '\0')) {
      param_2 = (int *)0x0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  *(int *)(param_1 + 0xc) = piVar1[3];
  *(int *)(param_1 + 0x10) = piVar1[4];
  *(int *)(param_1 + 8) = piVar1[2];
  if (*(int **)(param_1 + 4) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 4) + 0x10))();
  }
  *(int **)(param_1 + 4) = piVar3;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0xc))();
  }
  iStack_8 = 3;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 2727 ; VA 0x00554a20 ; FUN_00554a20 */

void FUN_00554a20(int param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = param_1;
  if (0xfff < param_2) {
    iVar1 = *(int *)(param_1 + -4);
    param_2 = param_2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,param_2);
  return;
}



/* FUNCTION 2728 ; VA 0x00554a60 ; FUN_00554a60 */

void FUN_00554a60(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 2;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 2729 ; VA 0x00554aa0 ; FUN_00554aa0 */

void __thiscall FUN_00554aa0(undefined4 param_1,undefined4 *param_2,undefined4 param_3)

{
  *param_2 = param_3;
  param_2[1] = param_1;
  return;
}



/* FUNCTION 2730 ; VA 0x00554ac0 ; FUN_00554ac0 */

void __fastcall FUN_00554ac0(undefined4 *param_1)

{
  if (param_1 != (undefined4 *)0x0) {
    (**(code **)*param_1)(1);
  }
  return;
}



/* FUNCTION 2731 ; VA 0x00554ad0 ; FUN_00554ad0 */

void __fastcall FUN_00554ad0(undefined4 *param_1)

{
  int iVar1;
  
  if (param_1[1] == 0) {
    FUN_016df3f6(1);
  }
  iVar1 = FUN_016de7af(*param_1,param_1[1]);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}



/* FUNCTION 2732 ; VA 0x00554b10 ; FUN_00554b10 */

void FUN_00554b10(void)

{
  FUN_0054db20();
  FUN_0058e3e0();
  return;
}



/* FUNCTION 2733 ; VA 0x00554b30 ; FUN_00554b30 */

void __fastcall FUN_00554b30(int param_1)

{
  if (*(undefined4 **)(param_1 + 0xc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xc))(1);
  }
  return;
}



/* FUNCTION 2734 ; VA 0x00554b40 ; FUN_00554b40 */

undefined FUN_00554b40(void)

{
  return 1;
}



/* FUNCTION 2735 ; VA 0x00554b50 ; FUN_00554b50 */

undefined4 FUN_00554b50(void)

{
  return 1;
}



/* FUNCTION 2736 ; VA 0x00554b60 ; FUN_00554b60 */

undefined4
FUN_00554b60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  *param_4 = param_2;
  *param_7 = param_5;
  return 3;
}



/* FUNCTION 2737 ; VA 0x00554b80 ; FUN_00554b80 */

uint FUN_00554b80(undefined4 param_1,int param_2,int param_3,uint param_4)

{
  if ((uint)(param_3 - param_2) < param_4) {
    param_4 = param_3 - param_2;
  }
  return param_4;
}



/* FUNCTION 2738 ; VA 0x00554ba0 ; FUN_00554ba0 */

undefined FUN_00554ba0(undefined param_1)

{
  return param_1;
}



/* FUNCTION 2739 ; VA 0x00554bb0 ; FUN_00554bb0 */

int FUN_00554bb0(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0170c6f0(param_4,param_1,param_2 - param_1);
  return param_2;
}



/* FUNCTION 2740 ; VA 0x00554bd0 ; FUN_00554bd0 */

void __thiscall FUN_00554bd0(int param_1,undefined param_2)

{
  FUN_016ddda7(param_2,param_1 + 8);
  return;
}



/* FUNCTION 2741 ; VA 0x00554bf0 ; FUN_00554bf0 */

undefined * __thiscall FUN_00554bf0(int param_1,undefined *param_2,undefined *param_3)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (int)param_3 - (int)param_2;
  iVar3 = 0;
  if (param_3 < param_2) {
    iVar2 = 0;
  }
  if (iVar2 != 0) {
    do {
      uVar1 = FUN_016ddda7(*param_2,param_1 + 8);
      *param_2 = uVar1;
      iVar3 = iVar3 + 1;
      param_2 = param_2 + 1;
    } while (iVar3 != iVar2);
  }
  return param_2;
}



/* FUNCTION 2742 ; VA 0x00554c40 ; FUN_00554c40 */

void __thiscall FUN_00554c40(int param_1,undefined param_2)

{
  FUN_016ddea5(param_2,param_1 + 8);
  return;
}



/* FUNCTION 2743 ; VA 0x00554c60 ; FUN_00554c60 */

undefined * __thiscall FUN_00554c60(int param_1,undefined *param_2,undefined *param_3)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (int)param_3 - (int)param_2;
  iVar3 = 0;
  if (param_3 < param_2) {
    iVar2 = 0;
  }
  if (iVar2 != 0) {
    do {
      uVar1 = FUN_016ddea5(*param_2,param_1 + 8);
      *param_2 = uVar1;
      iVar3 = iVar3 + 1;
      param_2 = param_2 + 1;
    } while (iVar3 != iVar2);
  }
  return param_2;
}



/* FUNCTION 2744 ; VA 0x00554cb0 ; FUN_00554cb0 */

undefined4
FUN_00554cb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  *param_4 = param_2;
  return 0;
}



/* FUNCTION 2745 ; VA 0x00554cd0 ; FUN_00554cd0 */

undefined FUN_00554cd0(undefined param_1)

{
  return param_1;
}



/* FUNCTION 2746 ; VA 0x00554ce0 ; FUN_00554ce0 */

int FUN_00554ce0(int param_1,int param_2,undefined4 param_3)

{
  FUN_0170c6f0(param_3,param_1,param_2 - param_1);
  return param_2;
}



/* FUNCTION 2747 ; VA 0x00554d00 ; FUN_00554d00 */

bool __fastcall FUN_00554d00(int param_1)

{
  return *(int *)(param_1 + 0x10) == 0;
}



/* FUNCTION 2748 ; VA 0x00554d10 ; FUN_00554d10 */

bool __fastcall FUN_00554d10(int *param_1)

{
  return *param_1 == 0;
}



/* FUNCTION 2749 ; VA 0x00554d20 ; FUN_00554d20 */

void FUN_00554d20(void)

{
  FUN_0054db20();
  FUN_0058e4c0();
  return;
}


