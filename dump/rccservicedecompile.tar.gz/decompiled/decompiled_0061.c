/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 15250 ; VA 0x008db080 ; FUN_008db080 */

int * __thiscall
FUN_008db080(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0deb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DataModel,__int64>::
              GetImpl<__int64_(__thiscall_RBX::DataModel::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::DataModel,__int64>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::DataModel,__int64>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15251 ; VA 0x008db180 ; FUN_008db180 */

undefined4 * __thiscall FUN_008db180(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0e00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_pd<struct_boost::thread_specific_ptr<class_RBX::DataModel::GenericJob*>::delete_data*,struct_boost::detail::do_heap_delete<struct_boost::thread_specific_ptr<class_RBX::DataModel::GenericJob*>::delete_data>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15252 ; VA 0x008db1f3 ; Catch_All@008db1f3 */

void Catch_All_008db1f3(void)

{
  int unaff_EBP;
  
  FUN_008ec4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15253 ; VA 0x008db210 ; FUN_008db210 */

int * __thiscall FUN_008db210(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  piVar3 = (int *)FUN_008db330(param_2);
  iVar1 = param_1[1];
  param_1[1] = *piVar3;
  *piVar3 = iVar1;
  uStack_8._0_1_ = 1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  piVar3 = (int *)(-(uint)(param_2 != 0) & param_2 + 8U);
  if ((piVar3 != (int *)0x0) && ((piVar3[1] == 0 || (*(int *)(piVar3[1] + 4) == 0)))) {
    piVar2 = (int *)param_1[1];
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    *piVar3 = param_2;
    piVar4 = (int *)piVar3[1];
    uStack_8._0_1_ = 2;
    if (piVar2 != piVar4) {
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[2] = piVar2[2] + 1;
        UNLOCK();
        piVar4 = (int *)piVar3[1];
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 8))();
        }
      }
      piVar3[1] = (int)piVar2;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar3 = piVar2 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15254 ; VA 0x008db330 ; FUN_008db330 */

undefined4 * __thiscall FUN_008db330(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0e10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_p<struct_boost::detail::shared_state<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15255 ; VA 0x008db3a5 ; Catch_All@008db3a5 */

void Catch_All_008db3a5(void)

{
  int unaff_EBP;
  
  FUN_0055d6f0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15256 ; VA 0x008db3c0 ; FUN_008db3c0 */

undefined4 * __thiscall
FUN_008db3c0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0192d3c0;
  cVar3 = FUN_008df530(param_2,param_3,param_4,param_5,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15257 ; VA 0x008db4f0 ; FUN_008db4f0 */

undefined4 * __thiscall FUN_008db4f0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0192d3a0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15258 ; VA 0x008db620 ; FUN_008db620 */

undefined4 __thiscall FUN_008db620(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_008db4f0(param_2,param_3,0);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15259 ; VA 0x008db680 ; FUN_008db680 */

undefined4 * __thiscall FUN_008db680(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c0e3b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_9fd023237d719cffa06f26b0b215a4d1>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[4] = param_2[2];
  param_1[5] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[6] = 0;
  FUN_005880d0(param_2 + 4);
  _uStack_8 = CONCAT31(uStack_7,2);
  param_1[0xe] = 0;
  FUN_005880d0(param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15260 ; VA 0x008db750 ; FUN_008db750 */

undefined4 * __fastcall FUN_008db750(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined auStack_17c [72];
  undefined auStack_134 [72];
  undefined auStack_ec [72];
  undefined auStack_a4 [72];
  undefined auStack_5c [72];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0e9b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008e68f0(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008e68f0(auStack_17c);
  uStack_8._0_1_ = 2;
  FUN_008e68f0(auStack_134);
  uStack_8._0_1_ = 3;
  FUN_008e68f0(auStack_ec);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_5c);
  if (cVar2 == '\0') {
    FUN_008e68f0(auStack_5c);
    uStack_8._0_1_ = 5;
    puStack_14 = (undefined4 *)FUN_01674e20(0x48);
    uStack_8._0_1_ = 6;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_008e68f0(auStack_a4);
    }
    param_1[2] = uVar3;
    FUN_008e9ba0();
    FUN_008e9ba0();
    bVar1 = true;
  }
  else {
    FUN_008e9ba0();
    bVar1 = false;
  }
  FUN_008e9ba0();
  ppuVar4 = &PTR_FUN_0192d398;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_008e9ba0();
  FUN_008e9ba0();
  FUN_008e9ba0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15261 ; VA 0x008db890 ; FUN_008db890 */

undefined4 * __thiscall FUN_008db890(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0192d3b8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15262 ; VA 0x008db9c0 ; FUN_008db9c0 */

undefined4 * __thiscall FUN_008db9c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088cb40();
  *param_1 = uVar3;
  param_1[1] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  uVar3 = param_2[1];
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar3;
  param_1[4] = uVar1;
  param_1[5] = uVar2;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uVar3 = FUN_005c9d30();
  param_1[1] = uVar3;
  return param_1;
}



/* FUNCTION 15263 ; VA 0x008dba20 ; FUN_008dba20 */

undefined4 * __thiscall FUN_008dba20(undefined4 *param_1,uint param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint auStack_74 [2];
  undefined auStack_6c [40];
  uint auStack_44 [2];
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0ec8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008e7190(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008e7190(auStack_74);
  uStack_8._0_1_ = 2;
  FUN_008e7190(auStack_44);
  ppuVar2 = &PTR_FUN_0192d3c8;
  cVar1 = FUN_008df690();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  FUN_0056b650();
  uStack_8._0_1_ = 3;
  if (auStack_44[0] != 0) {
    if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_44[0] & 0xfffffffe))(auStack_3c,auStack_3c,2);
    }
    auStack_44[0] = 0;
  }
  FUN_0056b650();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (auStack_74[0] != 0) {
    if (((auStack_74[0] & 1) == 0) && (*(code **)(auStack_74[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_74[0] & 0xfffffffe))(auStack_6c,auStack_6c,2);
    }
    auStack_74[0] = 0;
  }
  FUN_0056b650();
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15264 ; VA 0x008dbb40 ; FUN_008dbb40 */

undefined4 * __thiscall
FUN_008dbb40(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8,
            undefined param_9)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_98 [2];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  uint uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0ef8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_3c = param_2;
    if ((param_2 & 1) == 0) {
      puStack_74 = &uStack_34;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &param_4;
      uStack_80 = CONCAT44(0x8dbba3,(undefined4)uStack_80);
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_4;
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_1c = param_9;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_64 = 0;
  if (uStack_3c != 0) {
    uStack_64 = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      puStack_74 = &uStack_5c;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &uStack_34;
      uStack_80 = CONCAT44(0x8dbbf2,(undefined4)uStack_80);
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    else {
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
    }
  }
  puStack_70 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_98;
  auStack_98[0] = 0;
  uStack_44 = uStack_1c;
  puVar1 = auStack_98;
  if (uStack_64 != 0) {
    auStack_98[0] = uStack_64;
    if ((uStack_64 & 1) == 0) {
      (**(code **)(uStack_64 & 0xfffffffe))(&uStack_5c,&uStack_90,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_90 = uStack_5c;
      uStack_8c = uStack_58;
      uStack_88 = uStack_54;
      uStack_84 = uStack_50;
      uStack_80 = uStack_4c;
      puVar1 = auStack_98;
    }
  }
  puStack_14 = puVar1;
  puStack_78 = (undefined4 *)CONCAT31(puStack_78._1_3_,uStack_44);
  ppuVar3 = &PTR_FUN_0192d2fc;
  cVar2 = FUN_008df800();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_64 != 0) && ((uStack_64 & 1) == 0)) &&
     (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_5c;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0x8dbc87,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(uStack_64 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_34;
      puStack_70 = (undefined4 *)0x2;
      uStack_80 = CONCAT44(0x8dbcb6,(undefined4)uStack_80);
      puStack_74 = puStack_78;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_4;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0x8dbce4,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15265 ; VA 0x008dbd00 ; FUN_008dbd00 */

undefined4 * __thiscall FUN_008dbd00(undefined4 *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_174 [64];
  undefined4 uStack_134;
  undefined auStack_12c [64];
  undefined4 uStack_ec;
  undefined auStack_e4 [64];
  undefined4 uStack_a4;
  undefined auStack_9c [64];
  undefined4 auStack_5c [2];
  undefined auStack_54 [64];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0f5b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008e7950(&stack0x0000000c);
  uStack_134 = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008e7950(auStack_174);
  uStack_ec = uStack_134;
  uStack_8._0_1_ = 2;
  FUN_008e7950(auStack_12c);
  auStack_5c[0] = uStack_ec;
  uStack_8._0_1_ = 3;
  FUN_008e7950(auStack_e4);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_5c);
  if (cVar2 == '\0') {
    uStack_a4 = auStack_5c[0];
    FUN_008e7950(auStack_54);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x48);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_a4;
      FUN_008e7950(auStack_9c);
    }
    param_1[2] = puVar3;
    FUN_008c3510();
    FUN_008c3510();
    bVar1 = true;
  }
  else {
    FUN_008c3510();
    bVar1 = false;
  }
  FUN_008c3510();
  ppuVar4 = &PTR_FUN_0192d368;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_008c3510();
  FUN_008c3510();
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15266 ; VA 0x008dbe80 ; FUN_008dbe80 */

undefined4 * __thiscall
FUN_008dbe80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0f88;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x8dbeed);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x8dbf39);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0192d3f8;
  cStack_11 = FUN_008df9b0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dbfc3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x8dbffe);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dc02c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15267 ; VA 0x008dc050 ; FUN_008dc050 */

undefined4 __thiscall
FUN_008dc050(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0fa8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_008dbe80();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x8dc0ee;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15268 ; VA 0x008dc110 ; FUN_008dc110 */

undefined4 * __thiscall
FUN_008dc110(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c0fd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x8dc17d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x8dc1c9);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0192d408;
  cStack_11 = FUN_008dfb10();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dc253);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x8dc28e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dc2bc);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15269 ; VA 0x008dc2e0 ; FUN_008dc2e0 */

undefined4 * __thiscall
FUN_008dc2e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1008;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x8dc34d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x8dc399);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0192d400;
  cStack_11 = FUN_008dfc70();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dc423);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x8dc45e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x8dc48c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15270 ; VA 0x008dc4b0 ; FUN_008dc4b0 */

undefined4 __thiscall
FUN_008dc4b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1028;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_008dc2e0();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x8dc54e;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15271 ; VA 0x008dc570 ; FUN_008dc570 */

undefined4 * __thiscall
FUN_008dc570(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0192d550;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15272 ; VA 0x008dc660 ; FUN_008dc660 */

undefined4 * __thiscall
FUN_008dc660(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 auStack_b0 [9];
  undefined4 uStack_8c;
  undefined *puStack_88;
  undefined *puStack_84;
  undefined4 *puStack_80;
  undefined auStack_6c [4];
  int *piStack_68;
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1058;
  pvStack_10 = ExceptionList;
  puStack_80 = &param_4;
  uStack_8 = 0;
  puStack_84 = (undefined *)0x8dc69b;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008e75a0();
  uStack_44 = param_2;
  puStack_80 = (undefined4 *)auStack_6c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_84 = (undefined *)0x8dc6b7;
  FUN_008e75a0();
  puStack_80 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_b0;
  auStack_b0[0] = uStack_44;
  FUN_008e75a0(auStack_3c);
  ppuVar4 = &PTR_FUN_0192d3b0;
  cVar3 = FUN_008dfdd0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_2c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc70e;
      puStack_84 = puStack_88;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0x8dc730;
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_64 != 0) {
    if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_5c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc751;
      puStack_84 = puStack_88;
      (**(code **)(uStack_64 & 0xfffffffe))();
    }
    uStack_64 = 0;
  }
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_68[2] + -1;
    piStack_68[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0x8dc770;
      (**(code **)(*piStack_68 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = &stack0x0000001c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc794;
      puStack_84 = puStack_88;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_80 = (undefined4 *)0x8dc7b2;
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15273 ; VA 0x008dc7d0 ; FUN_008dc7d0 */

undefined4 * __thiscall
FUN_008dc7d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 auStack_b0 [9];
  undefined4 uStack_8c;
  undefined *puStack_88;
  undefined *puStack_84;
  undefined4 *puStack_80;
  undefined auStack_6c [4];
  int *piStack_68;
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1088;
  pvStack_10 = ExceptionList;
  puStack_80 = &param_4;
  uStack_8 = 0;
  puStack_84 = (undefined *)0x8dc80b;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008e75a0();
  uStack_44 = param_2;
  puStack_80 = (undefined4 *)auStack_6c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_84 = (undefined *)0x8dc827;
  FUN_008e75a0();
  puStack_80 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_b0;
  auStack_b0[0] = uStack_44;
  FUN_008e75a0(auStack_3c);
  ppuVar4 = &PTR_FUN_0192d3a8;
  cVar3 = FUN_008dff90();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_2c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc87e;
      puStack_84 = puStack_88;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0x8dc8a0;
      (**(code **)(*piStack_38 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_64 != 0) {
    if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = auStack_5c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc8c1;
      puStack_84 = puStack_88;
      (**(code **)(uStack_64 & 0xfffffffe))();
    }
    uStack_64 = 0;
  }
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_68[2] + -1;
    piStack_68[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0x8dc8e0;
      (**(code **)(*piStack_68 + 4))();
    }
  }
  uStack_8 = 5;
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      puStack_88 = &stack0x0000001c;
      puStack_80 = (undefined4 *)0x2;
      uStack_8c = 0x8dc904;
      puStack_84 = puStack_88;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    param_6 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_80 = (undefined4 *)0x8dc922;
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15274 ; VA 0x008dc940 ; FUN_008dc940 */

undefined4 * __thiscall
FUN_008dc940(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0192d320;
  cVar3 = FUN_008e0150(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      iVar2 = param_6[1] + -1;
      param_6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_6)();
        LOCK();
        iVar2 = param_6[2] + -1;
        param_6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_6 + 4))();
        }
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15275 ; VA 0x008dca40 ; FUN_008dca40 */

undefined4 * __thiscall
FUN_008dca40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0192d318;
  cVar3 = FUN_008e0150(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      iVar2 = param_6[1] + -1;
      param_6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_6)();
        LOCK();
        iVar2 = param_6[2] + -1;
        param_6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_6 + 4))();
        }
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15276 ; VA 0x008dcb40 ; FUN_008dcb40 */

undefined4 * __thiscall
FUN_008dcb40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0192d328;
  cVar3 = FUN_008e0150(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      iVar2 = param_6[1] + -1;
      param_6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_6)();
        LOCK();
        iVar2 = param_6[2] + -1;
        param_6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_6 + 4))();
        }
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15277 ; VA 0x008dcc40 ; FUN_008dcc40 */

undefined4 * __thiscall
FUN_008dcc40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined8 param_12)

{
  undefined4 *puVar1;
  char cVar2;
  undefined **ppuVar3;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c10b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_34 = 0;
  if (param_6 != 0) {
    uStack_34 = param_6;
    if ((param_6 & 1) == 0) {
      puStack_50 = (undefined4 *)0x0;
      uStack_58 = CONCAT44(&uStack_2c,&param_8);
      uStack_5c = 0x8dccb8;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      uStack_20 = param_11;
      uStack_1c = param_12;
    }
  }
  puStack_50 = param_1 + 2;
  uStack_8._0_1_ = 1;
  puStack_14 = (undefined *)&uStack_80;
  uStack_80 = param_2;
  uStack_7c = param_3;
  uStack_78 = param_4;
  uStack_70 = 0;
  puVar1 = &uStack_80;
  if (uStack_34 != 0) {
    uStack_70 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_68,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_68 = uStack_2c;
      uStack_64 = uStack_28;
      uStack_60 = uStack_24;
      uStack_5c = uStack_20;
      uStack_58 = uStack_1c;
      puVar1 = &uStack_80;
    }
  }
  puStack_14 = (undefined *)puVar1;
  ppuVar3 = &PTR_FUN_0192d3d0;
  cVar2 = FUN_008e0290();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    puStack_50 = (undefined4 *)0x2;
    uStack_58 = CONCAT44(&uStack_2c,&uStack_2c);
    uStack_5c = 0x8dcd54;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = (undefined4 *)0x2;
    uStack_58 = CONCAT44(&param_8,&param_8);
    uStack_5c = 0x8dcd82;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15278 ; VA 0x008dcda0 ; FUN_008dcda0 */

int * __thiscall FUN_008dcda0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_0090c3e0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 15279 ; VA 0x008dcdf0 ; FUN_008dcdf0 */

int * __thiscall FUN_008dcdf0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_0090c4c0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 15280 ; VA 0x008dce40 ; FUN_008dce40 */

int __thiscall FUN_008dce40(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c10e0;
  pvStack_10 = ExceptionList;
  piVar7 = *(int **)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (piVar7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(param_1 + 8);
  }
  uStack_1c = *(undefined4 *)(param_1 + 4);
  uStack_8 = 0;
  piStack_18 = piVar7;
  uStack_14 = uStack_1c;
  FUN_0054ef60();
  pcVar3 = (code *)*param_3;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = (*pcVar3)();
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15281 ; VA 0x008dcf60 ; FUN_008dcf60 */

undefined * FUN_008dcf60(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c10fc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee068c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0898) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee0898);
      if (DAT_01ee0898 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_008a8c30();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"DataModel",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018832a0);
        FUN_016f37bf(&DAT_01ee0898);
      }
    }
    DAT_01ee068c = &DAT_01ee0690;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee068c;
}



/* FUNCTION 15282 ; VA 0x008dd040 ; FUN_008dd040 */

undefined4 FUN_008dd040(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1110;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008ed990(param_1,param_2);
  uStack_8 = 0;
  FUN_00d88580(param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15283 ; VA 0x008dd09b ; Catch_All@008dd09b */

void Catch_All_008dd09b(void)

{
  int unaff_EBP;
  
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15284 ; VA 0x008dd0c0 ; FUN_008dd0c0 */

int FUN_008dd0c0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00575bc0();
  *(undefined2 *)(iVar4 + 0xc) = 0;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *(undefined4 *)(iVar4 + 0x10) = *param_1;
  *(undefined4 *)(iVar4 + 0x14) = uVar1;
  *(undefined4 *)(iVar4 + 0x18) = uVar2;
  *(undefined4 *)(iVar4 + 0x1c) = uVar3;
  *(undefined8 *)(iVar4 + 0x20) = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  *(undefined4 *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x2c) = 0;
  *(undefined4 *)(iVar4 + 0x28) = param_1[6];
  *(undefined4 *)(iVar4 + 0x2c) = param_1[7];
  param_1[6] = 0;
  param_1[7] = 0;
  return iVar4;
}



/* FUNCTION 15285 ; VA 0x008dd140 ; FUN_008dd140 */

int __thiscall FUN_008dd140(int *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1128;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 5;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 5;
  uVar7 = uVar1;
  if ((uVar9 <= 0x7ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 5;
  if (uVar7 < 0x8000000) {
    if (0xfff < uVar9) goto LAB_008dd1d1;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_008dd1d1:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_008dd3d2;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  puVar12 = puVar11 + iVar5 * 8;
  *puVar12 = 0;
  uVar9 = *param_3;
  uStack_8 = 0;
  if (uVar9 != 0) {
    *puVar12 = uVar9;
    if ((uVar9 & 1) == 0) {
      (**(code **)(uVar9 & 0xfffffffe))(param_3 + 2,puVar12 + 2,0);
    }
    else {
      uVar9 = param_3[3];
      uVar8 = param_3[4];
      uVar4 = param_3[5];
      puVar12[2] = param_3[2];
      puVar12[3] = uVar9;
      puVar12[4] = uVar8;
      puVar12[5] = uVar4;
      uVar9 = param_3[7];
      puVar12[6] = param_3[6];
      puVar12[7] = uVar9;
    }
  }
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    uStack_8._0_1_ = 1;
    puVar10 = puVar11;
    while (puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 == 0) {
LAB_008dd2eb:
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
      else {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
          goto LAB_008dd2eb;
        }
        uVar9 = puVar12[3];
        uVar8 = puVar12[4];
        uVar4 = puVar12[5];
        puVar10[2] = puVar12[2];
        puVar10[3] = uVar9;
        puVar10[4] = uVar8;
        puVar10[5] = uVar4;
        uVar9 = puVar12[7];
        puVar10[6] = puVar12[6];
        puVar10[7] = uVar9;
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_006ce110(puVar10,puVar10,param_1);
  }
  else {
    FUN_008ee3a0(*param_1,param_2,puVar11);
    FUN_008ee3a0(param_2,param_1[1],puVar12 + 8);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffe0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_008dd3d2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 8);
  param_1[2] = (int)(puVar11 + uVar7 * 8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x20;
}



/* FUNCTION 15286 ; VA 0x008dd3a8 ; Catch_All@008dd3a8 */

void Catch_All_008dd3a8(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15287 ; VA 0x008dd3e0 ; FUN_008dd3e0 */

int __thiscall FUN_008dd3e0(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1148;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  iVar3 = (param_1[1] - iVar6) / 0x48;
  if (iVar3 == 0x38e38e3) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar4 = (param_1[2] - iVar6) / 0x48;
  uVar7 = uVar1;
  if ((uVar4 <= 0x38e38e3 - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar5 = FUN_008ee5b0(uVar7);
  iStack_8 = 0;
  iVar6 = ((param_2 - iVar6) / 0x48) * 0x48;
  puVar2 = (undefined4 *)(iVar6 + iVar5);
  *puVar2 = 0;
  FUN_005880d0(param_3);
  iStack_8._0_1_ = 1;
  puVar2[8] = 0;
  FUN_005880d0(param_3 + 0x20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  *(undefined *)(puVar2 + 0x10) = *(undefined *)(param_3 + 0x40);
  if (param_2 == param_1[1]) {
    FUN_008ee430(*param_1,param_1[1],iVar5);
  }
  else {
    FUN_008ee300(*param_1,param_2,iVar5);
    FUN_008ee300(param_2,param_1[1],puVar2 + 0x12);
  }
  FUN_008ed9c0(iVar5,iVar3 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 15288 ; VA 0x008dd542 ; Catch_All@008dd542 */

void Catch_All_008dd542(void)

{
  int unaff_EBP;
  
  FUN_008edc40(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_008f20b0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15289 ; VA 0x008dd570 ; FUN_008dd570 */

int __thiscall FUN_008dd570(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  
  uVar7 = *param_1;
  iVar6 = (int)(param_1[1] - uVar7) / 0x18;
  if (iVar6 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = iVar6 + 1;
  uVar8 = (int)(param_1[2] - uVar7) / 0x18;
  uVar11 = uVar10;
  if ((uVar8 <= 0xaaaaaaa - (uVar8 >> 1)) && (uVar11 = (uVar8 >> 1) + uVar8, uVar11 < uVar10)) {
    uVar11 = uVar10;
  }
  uVar8 = uVar11 * 0x18;
  if (uVar11 < 0xaaaaaab) {
    uVar11 = uVar8;
    if (0xfff < uVar8) goto LAB_008dd60a;
    if (uVar8 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_008dd60a:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_008dd735;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  iVar6 = ((int)(param_2 - uVar7) / 0x18) * 0x18;
  *(undefined4 *)(iVar6 + 0x10 + uVar11) = 0;
  *(undefined4 *)(iVar6 + 0x14 + uVar11) = 0;
  uVar2 = param_3[1];
  uVar3 = param_3[2];
  uVar4 = param_3[3];
  puVar1 = (undefined4 *)(iVar6 + uVar11);
  *puVar1 = *param_3;
  puVar1[1] = uVar2;
  puVar1[2] = uVar3;
  puVar1[3] = uVar4;
  *(undefined8 *)(iVar6 + 0x10 + uVar11) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uVar5 = param_1[1];
  uVar7 = *param_1;
  uVar9 = uVar11;
  if (param_2 != uVar5) {
    FUN_0055c6d0(uVar7,param_2,uVar11,param_1);
    uVar5 = param_1[1];
    uVar7 = param_2;
    uVar9 = iVar6 + 0x18 + uVar11;
  }
  FUN_0055c6d0(uVar7,uVar5,uVar9,param_1);
  if (*param_1 != 0) {
    FUN_00559570(*param_1,param_1[1],param_1);
    uVar7 = *param_1;
    uVar9 = ((int)(param_1[2] - uVar7) / 0x18) * 0x18;
    uVar5 = uVar7;
    if (0xfff < uVar9) {
      uVar5 = *(uint *)(uVar7 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar7 - uVar5) - 4) {
LAB_008dd735:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar9);
  }
  *param_1 = uVar11;
  param_1[1] = uVar11 + uVar10 * 0x18;
  param_1[2] = uVar8 + uVar11;
  return *param_1 + iVar6;
}



/* FUNCTION 15290 ; VA 0x008dd740 ; FUN_008dd740 */

undefined4 * FUN_008dd740(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x58);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_9fd023237d719cffa06f26b0b215a4d1>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  uStack_8 = 1;
  FUN_008e68f0(param_1 + 2);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 15291 ; VA 0x008dd7cb ; Catch_All@008dd7cb */

void Catch_All_008dd7cb(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x58);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15292 ; VA 0x008dd7f0 ; FUN_008dd7f0 */

undefined4 FUN_008dd7f0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1180;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x58);
  uStack_8 = 0;
  FUN_008db680(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15293 ; VA 0x008dd844 ; Catch_All@008dd844 */

void Catch_All_008dd844(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x58);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15294 ; VA 0x008dd860 ; FUN_008dd860 */

void __thiscall
FUN_008dd860(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_008edc70(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_008dd912:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_008dd912;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 15295 ; VA 0x008dd9c0 ; FUN_008dd9c0 */

undefined4 * __thiscall
FUN_008dd9c0(int *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1190;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_0055a140(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar5 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar5 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar5,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_0055a140(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_0055a140(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar4 = (int *)FUN_00551320();
      piVar3 = piStack_18;
      if ((*piVar4 == *param_1) || (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_0055a140(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_0055a140(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_0055af70(auStack_20,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15296 ; VA 0x008ddc08 ; Catch_All@008ddc08 */

void Catch_All_008ddc08(void)

{
  int unaff_EBP;
  
  FUN_005763d0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15297 ; VA 0x008ddc20 ; FUN_008ddc20 */

void __thiscall
FUN_008ddc20(undefined4 *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,int param_5)

{
  char cVar1;
  int iVar2;
  byte bVar3;
  int *piVar4;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_4;
  puStack_c = &LAB_017c11a0;
  piVar6 = (int *)*param_1;
  bVar3 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar6[1] + 0xd);
  piVar4 = piVar6;
  piVar10 = (int *)piVar6[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar4 = piVar10 + 4;
    if (param_3 == '\0') {
      if (0xf < (uint)piVar10[9]) {
        piVar4 = (int *)*piVar4;
      }
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      FUN_0055c2d0(puVar8,puVar5[4],piVar4,piVar10[8]);
      bVar3 = extraout_var_00 >> 7;
    }
    else {
      puVar8 = puVar5;
      if (0xf < (uint)puVar5[5]) {
        puVar8 = (undefined4 *)*puVar5;
      }
      if (0xf < (uint)piVar10[9]) {
        piVar4 = (int *)*piVar4;
      }
      FUN_0055c2d0(piVar4,piVar10[8],puVar8,puVar5[4]);
      bVar3 = extraout_var >> 7 ^ 1;
    }
    if (bVar3 == 0) {
      piVar9 = (int *)piVar10[2];
    }
    else {
      piVar9 = (int *)*piVar10;
    }
    piVar4 = piVar10;
    piVar10 = piVar9;
    cVar1 = *(char *)((int)piVar9 + 0xd);
  }
  piVar10 = piVar4;
  if (bVar3 != 0) {
    if (piVar4 == (int *)*piVar6) {
      bVar3 = 1;
      goto LAB_008ddced;
    }
    if (*(char *)((int)piVar4 + 0xd) == '\0') {
      piVar10 = (int *)*piVar4;
      if (*(char *)((int)piVar10 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar10[2] + 0xd);
        piVar6 = (int *)piVar10[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar6[2] + 0xd);
          piVar10 = piVar6;
          piVar6 = (int *)piVar6[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar4[1] + 0xd);
        piVar6 = (int *)piVar4[1];
        piVar10 = piVar4;
        while ((piVar9 = piVar6, cVar1 == '\0' && (piVar10 == (int *)*piVar9))) {
          cVar1 = *(char *)(piVar9[1] + 0xd);
          piVar6 = (int *)piVar9[1];
          piVar10 = piVar9;
        }
        if (*(char *)((int)piVar10 + 0xd) == '\0') {
          piVar10 = piVar9;
        }
      }
    }
    else {
      piVar10 = (int *)piVar4[2];
    }
  }
  piVar6 = piVar10 + 4;
  puVar8 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar8 = (undefined4 *)*puVar5;
  }
  if (0xf < (uint)piVar10[9]) {
    piVar6 = (int *)*piVar6;
  }
  iVar7 = FUN_0055c2d0(piVar6,piVar10[8],puVar8,puVar5[4]);
  iVar2 = param_5;
  if (-1 < iVar7) {
    FUN_005f53f0(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar2,0x30);
    *param_2 = piVar10;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_008ddced:
  puVar5 = (undefined4 *)FUN_008dd860(&param_3,bVar3,piVar4,puVar5,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15298 ; VA 0x008dddde ; Catch_All@008dddde */

void Catch_All_008dddde(void)

{
  int unaff_EBP;
  
  FUN_008edc70(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15299 ; VA 0x008dde00 ; FUN_008dde00 */

void __thiscall FUN_008dde00(int *param_1,int param_2,uint param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c11b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = param_5 - param_3;
  if (uVar3 != 0) {
    if (0x3333333 < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar2 = FUN_008ee540(uVar3);
    *param_1 = iVar2;
    param_1[1] = iVar2;
    param_1[2] = uVar3 * 0x50 + *param_1;
    iVar2 = *param_1;
    uStack_8 = 1;
    for (; param_3 != param_5; param_3 = param_3 + 1) {
      iVar1 = *(int *)(*(int *)(param_2 + 4) + (*(int *)(param_2 + 8) - 1U & param_3) * 4);
      FUN_008e8ca0(iVar1);
      *(undefined4 *)(iVar2 + 0x48) = *(undefined4 *)(iVar1 + 0x48);
      *(undefined4 *)(iVar2 + 0x4c) = *(undefined4 *)(iVar1 + 0x4c);
      iVar2 = iVar2 + 0x50;
    }
    param_1[1] = iVar2;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15300 ; VA 0x008ddee7 ; Catch_All@008ddee7 */

void Catch_All_008ddee7(void)

{
  FUN_008ee280();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15301 ; VA 0x008ddf00 ; FUN_008ddf00 */

void __thiscall FUN_008ddf00(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  puVar3 = (undefined4 *)param_1[1];
  uVar7 = *param_1;
  uVar4 = (int)((int)puVar3 - uVar7) >> 3;
  uVar6 = (int)(param_1[2] - uVar7) >> 3;
  if (param_2 <= uVar6) {
    if (uVar4 < param_2) {
      iVar2 = param_2 - uVar4;
      if (iVar2 != 0) {
        do {
          *puVar3 = 0xabf77f4e;
          puVar3[1] = 0x8a5180d;
          puVar3 = puVar3 + 2;
          iVar2 = iVar2 + -1;
        } while (iVar2 != 0);
        param_1[1] = (uint)puVar3;
        return;
      }
    }
    else {
      if (param_2 == uVar4) {
        return;
      }
      puVar3 = (undefined4 *)(uVar7 + param_2 * 8);
    }
    param_1[1] = (uint)puVar3;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  uVar6 = uVar7 * 8;
  if (uVar7 < 0x20000000) {
    uVar7 = uVar6;
    if (0xfff < uVar6) goto LAB_008ddf72;
    if (uVar6 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008ddf72:
    uVar1 = uVar7 + 0x23;
    if (uVar1 <= uVar7) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_008de097;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  puVar3 = (undefined4 *)(uVar7 + uVar4 * 8);
  for (iVar2 = param_2 - uVar4; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0xabf77f4e;
    puVar3[1] = 0x8a5180d;
    puVar3 = puVar3 + 2;
  }
  puVar3 = (undefined4 *)*param_1;
  puVar5 = (undefined4 *)param_1[1];
  if (puVar3 != puVar5) {
    iVar2 = uVar7 - (int)puVar3;
    do {
      *(undefined4 *)((int)puVar3 + iVar2) = *puVar3;
      *(undefined4 *)((int)puVar3 + iVar2 + 4) = puVar3[1];
      puVar3 = puVar3 + 2;
    } while (puVar3 != puVar5);
    puVar3 = (undefined4 *)*param_1;
  }
  if (puVar3 != (undefined4 *)0x0) {
    uVar4 = param_1[2] - (int)puVar3 & 0xfffffff8;
    puVar5 = puVar3;
    if (0xfff < uVar4) {
      puVar5 = (undefined4 *)puVar3[-1];
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)puVar3 + (-4 - (int)puVar5))) {
LAB_008de097:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar4);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + param_2 * 8;
  param_1[2] = uVar6 + uVar7;
  return;
}



/* FUNCTION 15302 ; VA 0x008de0a0 ; FUN_008de0a0 */

void FUN_008de0a0(int param_1,int param_2)

{
  undefined4 auStack_58 [8];
  undefined4 uStack_38;
  undefined uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c11e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      param_2 = param_2 + -0x48;
      if (param_1 == param_2) {
        ExceptionList = pvStack_10;
        return;
      }
      auStack_58[0] = 0;
      FUN_005880d0(param_1);
      uStack_8 = 0;
      uStack_38 = 0;
      FUN_005880d0(param_1 + 0x20);
      uStack_18 = *(undefined *)(param_1 + 0x40);
      uStack_8 = 1;
      FUN_008eb4e0(param_2);
      FUN_008eb4e0(auStack_58);
      uStack_8 = 0xffffffff;
      FUN_008c3510();
      param_1 = param_1 + 0x48;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15303 ; VA 0x008de140 ; FUN_008de140 */

void __thiscall FUN_008de140(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c11f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::DataModel::LegacyLock::Implementation::Events>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15304 ; VA 0x008de1ae ; Catch_All@008de1ae */

void Catch_All_008de1ae(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_008ecfd0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15305 ; VA 0x008de1d0 ; FUN_008de1d0 */

void __thiscall FUN_008de1d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1200;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::DataModel::WindowInputState>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15306 ; VA 0x008de23e ; Catch_All@008de23e */

void Catch_All_008de23e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_008ed1f0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15307 ; VA 0x008de260 ; FUN_008de260 */

int __thiscall FUN_008de260(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1210;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AppStorageService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15308 ; VA 0x008de332 ; Catch_All@008de332 */

void Catch_All_008de332(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15309 ; VA 0x008de350 ; FUN_008de350 */

int __thiscall FUN_008de350(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1220;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AssetService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15310 ; VA 0x008de422 ; Catch_All@008de422 */

void Catch_All_008de422(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15311 ; VA 0x008de440 ; FUN_008de440 */

int __thiscall FUN_008de440(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1230;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::BrowserService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15312 ; VA 0x008de512 ; Catch_All@008de512 */

void Catch_All_008de512(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15313 ; VA 0x008de530 ; FUN_008de530 */

int __thiscall FUN_008de530(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1240;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ContextActionService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15314 ; VA 0x008de602 ; Catch_All@008de602 */

void Catch_All_008de602(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15315 ; VA 0x008de620 ; FUN_008de620 */

int __thiscall FUN_008de620(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1250;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ControllerService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15316 ; VA 0x008de6f2 ; Catch_All@008de6f2 */

void Catch_All_008de6f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15317 ; VA 0x008de710 ; FUN_008de710 */

int __thiscall FUN_008de710(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1260;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CoreGuiService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15318 ; VA 0x008de7e2 ; Catch_All@008de7e2 */

void Catch_All_008de7e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15319 ; VA 0x008de800 ; FUN_008de800 */

int * __thiscall FUN_008de800(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1270;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar5 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::DataModel*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
    piVar5 = piVar4;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar5;
  if ((param_2 != 0) &&
     ((piVar4 = *(int **)(param_2 + 0x14), piVar4 == (int *)0x0 || (piVar4[1] == 0)))) {
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4 = (int *)(param_2 + 0xc);
    *(int **)(param_2 + 0x10) = piVar4;
    piVar3 = *(int **)(param_2 + 0x14);
    *(int **)(param_2 + 0x14) = piVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar4 = (int *)(**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar3 = piVar5 + 1;
      iVar2 = *piVar3;
      piVar4 = (int *)*piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar4 = (int *)(**(code **)*piVar5)();
        LOCK();
        piVar3 = piVar5 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piVar4 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 15320 ; VA 0x008de8d7 ; Catch_All@008de8d7 */

void Catch_All_008de8d7(void)

{
  int iVar1;
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = *(int *)(unaff_EBP + 8) + 0xc;
  }
  FUN_005703b0(iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15321 ; VA 0x008de900 ; FUN_008de900 */

int __thiscall FUN_008de900(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1280;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::DebrisService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15322 ; VA 0x008de9d2 ; Catch_All@008de9d2 */

void Catch_All_008de9d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15323 ; VA 0x008de9f0 ; FUN_008de9f0 */

int __thiscall FUN_008de9f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1290;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GameBasicSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15324 ; VA 0x008deac2 ; Catch_All@008deac2 */

void Catch_All_008deac2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15325 ; VA 0x008deae0 ; FUN_008deae0 */

int __thiscall FUN_008deae0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GamePassService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15326 ; VA 0x008debb2 ; Catch_All@008debb2 */

void Catch_All_008debb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15327 ; VA 0x008debd0 ; FUN_008debd0 */

int __thiscall FUN_008debd0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GamepadService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15328 ; VA 0x008deca2 ; Catch_All@008deca2 */

void Catch_All_008deca2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15329 ; VA 0x008decc0 ; FUN_008decc0 */

int __thiscall FUN_008decc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GeometryService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15330 ; VA 0x008ded92 ; Catch_All@008ded92 */

void Catch_All_008ded92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15331 ; VA 0x008dedb0 ; FUN_008dedb0 */

int __thiscall FUN_008dedb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::HttpRbxApiService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15332 ; VA 0x008dee82 ; Catch_All@008dee82 */

void Catch_All_008dee82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15333 ; VA 0x008deea0 ; FUN_008deea0 */

int __thiscall FUN_008deea0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NotificationService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15334 ; VA 0x008def72 ; Catch_All@008def72 */

void Catch_All_008def72(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15335 ; VA 0x008def90 ; FUN_008def90 */

int __thiscall FUN_008def90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c12f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PhysicsService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15336 ; VA 0x008df062 ; Catch_All@008df062 */

void Catch_All_008df062(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15337 ; VA 0x008df080 ; FUN_008df080 */

int __thiscall FUN_008df080(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1300;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ScriptService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15338 ; VA 0x008df152 ; Catch_All@008df152 */

void Catch_All_008df152(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15339 ; VA 0x008df170 ; FUN_008df170 */

int __thiscall FUN_008df170(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1310;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TouchInputService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15340 ; VA 0x008df242 ; Catch_All@008df242 */

void Catch_All_008df242(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15341 ; VA 0x008df260 ; FUN_008df260 */

int __thiscall FUN_008df260(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TweenService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15342 ; VA 0x008df332 ; Catch_All@008df332 */

void Catch_All_008df332(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15343 ; VA 0x008df350 ; FUN_008df350 */

int __thiscall FUN_008df350(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1330;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::VRService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15344 ; VA 0x008df422 ; Catch_All@008df422 */

void Catch_All_008df422(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15345 ; VA 0x008df440 ; FUN_008df440 */

int __thiscall FUN_008df440(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1340;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Workspace*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15346 ; VA 0x008df512 ; Catch_All@008df512 */

void Catch_All_008df512(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 15347 ; VA 0x008df530 ; FUN_008df530 */

undefined FUN_008df530(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,
                      undefined4 *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_1;
  piStack_10 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_c = param_3;
  piStack_8 = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  piVar1 = piStack_10;
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[2] = piStack_8[2] + 1;
      UNLOCK();
    }
    *param_5 = 0;
    param_5[1] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    *param_5 = uStack_14;
    param_5[1] = piStack_10;
    param_5[2] = 0;
    param_5[3] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[2] = piStack_8[2] + 1;
      UNLOCK();
    }
    param_5[2] = uStack_c;
    param_5[3] = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar4 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar4 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return uVar4;
}



/* FUNCTION 15348 ; VA 0x008df690 ; FUN_008df690 */

undefined FUN_008df690(uint param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined4 *in_stack_00000034;
  uint auStack_74 [2];
  undefined auStack_6c [40];
  uint auStack_44 [2];
  undefined auStack_3c [40];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1377;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008e7190(&param_1);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_44);
  if (cVar1 == '\0') {
    FUN_008e7190(auStack_44);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008e7190(auStack_74);
    }
    *in_stack_00000034 = uVar2;
    FUN_0056b650();
    uStack_8._0_1_ = 4;
    if (auStack_74[0] != 0) {
      if (((auStack_74[0] & 1) == 0) && (*(code **)(auStack_74[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_74[0] & 0xfffffffe))(auStack_6c,auStack_6c,2);
      }
      auStack_74[0] = 0;
    }
    FUN_0056b650();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (auStack_44[0] != 0) {
      if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_44[0] & 0xfffffffe))(auStack_3c,auStack_3c,2);
      }
      auStack_44[0] = 0;
    }
    uVar3 = 1;
  }
  else {
    FUN_0056b650();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_44[0] != 0) {
      if (((auStack_44[0] & 1) == 0) && (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_44[0] & 0xfffffffe))(auStack_3c,auStack_3c,2);
      }
      auStack_44[0] = 0;
    }
    uVar3 = 0;
  }
  FUN_0056b650();
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15349 ; VA 0x008df800 ; FUN_008df800 */

undefined FUN_008df800(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined param_8,
                      undefined4 param_9,undefined4 *param_10)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  uint auStack_64 [2];
  undefined auStack_5c [32];
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c13b7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  auStack_3c[0] = 0;
  uStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    auStack_3c[0] = param_1;
    if ((param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_34,0);
    }
    else {
      uStack_34 = param_3;
      uStack_30 = param_4;
      uStack_2c = param_5;
      uStack_28 = param_6;
      uStack_24 = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_14 = param_1;
  uStack_1c = param_8;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_3c);
  if (cVar1 == '\0') {
    FUN_008e7230(auStack_3c);
    uStack_8._0_1_ = 2;
    uStack_14 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    if (uStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008e7230(auStack_64);
    }
    *param_10 = uVar2;
    uStack_8._0_1_ = 4;
    if (auStack_64[0] != 0) {
      if (((auStack_64[0] & 1) == 0) && (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_64[0] & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      auStack_64[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
        uStack_14 = param_1;
      }
      auStack_3c[0] = 0;
    }
    uVar3 = 0;
    param_1 = uStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    param_10._3_1_ = uVar3;
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_10._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15350 ; VA 0x008df9b0 ; FUN_008df9b0 */

undefined FUN_008df9b0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c13ef;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 15351 ; VA 0x008dfb10 ; FUN_008dfb10 */

undefined FUN_008dfb10(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c141f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 15352 ; VA 0x008dfc70 ; FUN_008dfc70 */

undefined FUN_008dfc70(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c144f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 15353 ; VA 0x008dfdd0 ; FUN_008dfdd0 */

undefined FUN_008dfdd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  int *in_stack_00000034;
  undefined auStack_6c [4];
  int *piStack_68;
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 auStack_44 [2];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1487;
  pvStack_10 = ExceptionList;
  auStack_44[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008e75a0(&param_3);
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_44);
  uVar3 = auStack_44[0];
  if (cVar4 == '\0') {
    FUN_008e75a0(auStack_3c);
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      FUN_008e75a0(auStack_6c);
    }
    *in_stack_00000034 = (int)puVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_64 != 0) {
      if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_64 & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      uStack_64 = 0;
    }
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_68[2] + -1;
      piStack_68[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar6 = 0;
  }
  uStack_8 = 7;
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_5 & 0xfffffffe))(&stack0x0000001c,&stack0x0000001c,2);
    }
    param_5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 15354 ; VA 0x008dff90 ; FUN_008dff90 */

undefined FUN_008dff90(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  int *in_stack_00000034;
  undefined auStack_6c [4];
  int *piStack_68;
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 auStack_44 [2];
  undefined auStack_3c [4];
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c14c7;
  pvStack_10 = ExceptionList;
  auStack_44[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008e75a0(&param_3);
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_44);
  uVar3 = auStack_44[0];
  if (cVar4 == '\0') {
    FUN_008e75a0(auStack_3c);
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      FUN_008e75a0(auStack_6c);
    }
    *in_stack_00000034 = (int)puVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_64 != 0) {
      if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_64 & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      uStack_64 = 0;
    }
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_68[2] + -1;
      piStack_68[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar6 = 0;
  }
  uStack_8 = 7;
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_5 & 0xfffffffe))(&stack0x0000001c,&stack0x0000001c,2);
    }
    param_5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 15355 ; VA 0x008e0150 ; FUN_008e0150 */

undefined FUN_008e0150(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      int *param_5,undefined4 param_6,undefined4 *param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  
  uStack_1c = param_1;
  uStack_18 = param_2;
  uStack_14 = param_3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_10 = param_4;
  piStack_c = param_5;
  cVar4 = FUN_00585a40(&uStack_1c);
  piVar2 = piStack_c;
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    param_7[1] = uStack_18;
    *param_7 = uStack_1c;
    param_7[2] = uStack_14;
    param_7[3] = 0;
    param_7[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    param_7[3] = uStack_10;
    param_7[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 15356 ; VA 0x008e0290 ; FUN_008e0290 */

undefined FUN_008e0290(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined8 param_11,
                      undefined4 *param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined auStack_74 [16];
  uint uStack_64;
  undefined auStack_5c [24];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1507;
  pvStack_10 = ExceptionList;
  uStack_44 = param_1;
  uStack_40 = param_2;
  uStack_3c = param_3;
  uStack_8 = 0;
  uStack_34 = 0;
  uStack_14 = param_5;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    uStack_34 = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_2c,0);
    }
    else {
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      uStack_1c = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_14 = param_5;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(&uStack_44);
  if (cVar1 == '\0') {
    FUN_008e72f0(&uStack_44);
    uStack_8._0_1_ = 2;
    uStack_14 = FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    if (uStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_008e72f0(auStack_74);
    }
    *param_12 = uVar2;
    uStack_8._0_1_ = 4;
    if (uStack_64 != 0) {
      if (((uStack_64 & 1) == 0) && (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_64 & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      uStack_64 = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      uStack_34 = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        uStack_14 = param_5;
      }
      uStack_34 = 0;
    }
    uVar3 = 0;
    param_5 = uStack_14;
  }
  uStack_8 = 7;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    param_12._3_1_ = uVar3;
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
    ExceptionList = pvStack_10;
    return param_12._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 15357 ; VA 0x008e0450 ; FUN_008e0450 */

uint * FUN_008e0450(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,undefined4 param_9,int *param_10,
                   undefined4 param_11,int *param_12)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint *puVar4;
  uint uStack_44;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1548;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_12[1] = param_12[1] + 1;
    UNLOCK();
  }
  if (param_10 != (int *)0x0) {
    LOCK();
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  puVar4 = (uint *)FUN_008e7360(param_9,param_10,param_11,param_12);
  uStack_8._0_1_ = 3;
  uStack_44 = 0;
  if (param_2 != 0) {
    uStack_44 = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_3c,0);
    }
    else {
      uStack_3c = param_4;
      uStack_38 = param_5;
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
    }
  }
  uStack_8._0_1_ = 4;
  *param_1 = 0;
  if (uStack_44 != 0) {
    *param_1 = uStack_44;
    if ((uStack_44 & 1) == 0) {
      (**(code **)(uStack_44 & 0xfffffffe))(&uStack_3c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_3c;
      param_1[3] = uStack_38;
      param_1[4] = uStack_34;
      param_1[5] = uStack_30;
      *(undefined8 *)(param_1 + 6) = uStack_2c;
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = *puVar4;
  param_1[9] = puVar4[1];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (puVar4[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = puVar4[2];
  param_1[0xb] = puVar4[3];
  uStack_8._0_1_ = 5;
  if (((uStack_44 != 0) && ((uStack_44 & 1) == 0)) &&
     (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_44 & 0xfffffffe))(&uStack_3c,&uStack_3c,2);
  }
  FUN_0056b650();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  piVar1 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar3 = param_10[1] + -1;
    param_10[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2 + -1;
      *piVar2 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_12;
  if (param_12 != (int *)0x0) {
    LOCK();
    iVar3 = param_12[1] + -1;
    param_12[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_12)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15358 ; VA 0x008e0670 ; FUN_008e0670 */

uint * FUN_008e0670(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,undefined param_9)

{
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1570;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  if (uStack_34 != 0) {
    *param_1 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_2c;
      param_1[3] = uStack_28;
      param_1[4] = uStack_24;
      param_1[5] = uStack_20;
      *(undefined8 *)(param_1 + 6) = uStack_1c;
    }
  }
  *(undefined *)(param_1 + 8) = param_9;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
  }
  uStack_8 = 3;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15359 ; VA 0x008e0790 ; FUN_008e0790 */

undefined4 *
FUN_008e0790(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  undefined4 uVar1;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 *puStack_88;
  ulonglong uStack_84;
  uint uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  undefined8 uStack_64;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c15a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7c = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_7c = param_12;
    if ((param_12 & 1) == 0) {
      uStack_84 = ZEXT48(&uStack_74);
      puStack_88 = &param_14;
      uStack_8c = 0x8e07f7;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_74 = param_14;
      uStack_70 = param_15;
      uStack_6c = param_16;
      puStack_68 = (undefined4 *)param_17;
      uStack_64 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_94,0);
    }
    else {
      uStack_94 = param_7;
      uStack_90 = param_8;
      uStack_8c = param_9;
      puStack_88 = param_10;
      uStack_84 = param_11;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_008e7a20(param_3,param_4);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  uStack_64 = CONCAT44(uVar1,0x8e0869);
  FUN_008e7950();
  uStack_64 = CONCAT44(0x8e0871,(undefined4)uStack_64);
  FUN_008c3510();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_68 = &param_7;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0x8e0892;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = &param_14;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0x8e08c0;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15360 ; VA 0x008e08e0 ; FUN_008e08e0 */

undefined4 *
FUN_008e08e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined *param_11,undefined8 param_12)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c15c8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_64;
  uStack_8 = 1;
  auStack_64[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_64;
  if (param_6 != 0) {
    auStack_64[0] = param_6;
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_5c,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_5c = param_8;
      uStack_58 = param_9;
      uStack_54 = param_10;
      puStack_50 = (undefined4 *)param_11;
      uStack_4c = param_12;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_64;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uVar4 = FUN_008e7650(param_3,param_4,param_5);
  uStack_8._0_1_ = 2;
  *param_1 = param_2;
  uStack_4c = CONCAT44(uVar4,0x8e0990);
  FUN_008e75a0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    puStack_50 = (undefined4 *)auStack_2c;
    uStack_4c = CONCAT44(2,puStack_50);
    uStack_54 = 0x8e09b1;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_4c = CONCAT44(0x8e09d3,(undefined4)uStack_4c);
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      uStack_4c = CONCAT44(0x8e09e7,(undefined4)uStack_4c);
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8 = 4;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = &param_8;
    uStack_4c = CONCAT44(2,puStack_50);
    uStack_54 = 0x8e0a0b;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15361 ; VA 0x008e0a20 ; FUN_008e0a20 */

undefined4 *
FUN_008e0a20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined *param_11,undefined8 param_12)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  int *piStack_38;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c15f8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_64;
  uStack_8 = 1;
  auStack_64[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_64;
  if (param_6 != 0) {
    auStack_64[0] = param_6;
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_5c,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_5c = param_8;
      uStack_58 = param_9;
      uStack_54 = param_10;
      puStack_50 = (undefined4 *)param_11;
      uStack_4c = param_12;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_64;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uVar4 = FUN_008e77d0(param_3,param_4,param_5);
  uStack_8._0_1_ = 2;
  *param_1 = param_2;
  uStack_4c = CONCAT44(uVar4,0x8e0ad0);
  FUN_008e75a0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    puStack_50 = (undefined4 *)auStack_2c;
    uStack_4c = CONCAT44(2,puStack_50);
    uStack_54 = 0x8e0af1;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_4c = CONCAT44(0x8e0b13,(undefined4)uStack_4c);
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      uStack_4c = CONCAT44(0x8e0b27,(undefined4)uStack_4c);
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8 = 4;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = &param_8;
    uStack_4c = CONCAT44(2,puStack_50);
    uStack_54 = 0x8e0b4b;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15362 ; VA 0x008e0b60 ; FUN_008e0b60 */

undefined4 *
FUN_008e0b60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
    piVar1 = param_7 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  piVar1 = param_7 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_6;
  param_1[4] = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 15363 ; VA 0x008e0c60 ; FUN_008e0c60 */

undefined4 *
FUN_008e0c60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined8 param_11,undefined4 param_12,undefined4 param_13)

{
  uint *puVar1;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 *puStack_68;
  undefined4 uStack_64;
  undefined4 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1628;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    uStack_34 = param_5;
    if ((param_5 & 1) == 0) {
      puStack_68 = &uStack_2c;
      uStack_64 = 0;
      uStack_70 = CONCAT44(&param_7,0x8e0cbd);
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      uStack_1c = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_64 = param_13;
  uStack_8._0_1_ = 1;
  puStack_68 = (undefined4 *)param_12;
  puStack_14 = (undefined *)auStack_88;
  auStack_88[0] = 0;
  puVar1 = auStack_88;
  if (uStack_34 != 0) {
    auStack_88[0] = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_80,0);
      puVar1 = (uint *)puStack_14;
    }
    else {
      uStack_80 = uStack_2c;
      uStack_7c = uStack_28;
      uStack_78 = uStack_24;
      uStack_74 = uStack_20;
      uStack_70 = uStack_1c;
      puVar1 = auStack_88;
    }
  }
  puStack_14 = (undefined *)puVar1;
  FUN_008e7d50(param_4);
  uStack_8._0_1_ = 2;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_68 = &uStack_2c;
      uStack_64 = 2;
      uStack_70 = CONCAT44(puStack_68,0x8e0d3e);
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = uStack_5c;
  param_1[4] = 0;
  if (uStack_54 != 0) {
    param_1[4] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      uStack_64 = 0;
      puStack_68 = param_1 + 6;
      uStack_70 = CONCAT44(&uStack_4c,0x8e0d9a);
      (**(code **)(uStack_54 & 0xfffffffe))();
    }
    else {
      param_1[6] = uStack_4c;
      param_1[7] = uStack_48;
      param_1[8] = uStack_44;
      param_1[9] = uStack_40;
      *(undefined8 *)(param_1 + 10) = uStack_3c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = &uStack_4c;
    uStack_64 = 2;
    uStack_70 = CONCAT44(puStack_68,0x8e0dbe);
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_68 = &param_7;
    uStack_64 = 2;
    uStack_70 = CONCAT44(puStack_68,0x8e0dec);
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15364 ; VA 0x008e0f00 ; FUN_008e0f00 */

uint __fastcall FUN_008e0f00(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b73900();
  piVar5 = *(int **)(param_1 + 0x2c);
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar6 = param_1;
  }
  uVar4 = (uint)(iVar6 != 0);
  if (piVar5 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar5 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar5[1];
    iVar6 = *piVar5;
    uStack_8 = 0;
    for (; iVar6 != iVar1; iVar6 = iVar6 + 8) {
      iVar2 = FUN_008e0f00();
      uVar4 = uVar4 + iVar2;
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar5 = piVar3 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 15365 ; VA 0x008e0fd0 ; FUN_008e0fd0 */

uint __fastcall FUN_008e0fd0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_00897b90();
  piVar5 = *(int **)(param_1 + 0x2c);
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar6 = param_1;
  }
  uVar4 = (uint)(iVar6 != 0);
  if (piVar5 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar5 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar5[1];
    iVar6 = *piVar5;
    uStack_8 = 0;
    for (; iVar6 != iVar1; iVar6 = iVar6 + 8) {
      iVar2 = FUN_008e0fd0();
      uVar4 = uVar4 + iVar2;
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar5 = piVar3 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 15366 ; VA 0x008e10a0 ; FUN_008e10a0 */

uint __fastcall FUN_008e10a0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00aff8c0();
  piVar5 = *(int **)(param_1 + 0x2c);
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar6 = param_1;
  }
  uVar4 = (uint)(iVar6 != 0);
  if (piVar5 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar5 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar5[1];
    iVar6 = *piVar5;
    uStack_8 = 0;
    for (; iVar6 != iVar1; iVar6 = iVar6 + 8) {
      iVar2 = FUN_008e10a0();
      uVar4 = uVar4 + iVar2;
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar5 = piVar3 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 15367 ; VA 0x008e1170 ; FUN_008e1170 */

undefined4 * FUN_008e1170(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1670;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ed53f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ed54f0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de260(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15368 ; VA 0x008e1230 ; FUN_008e1230 */

int FUN_008e1230(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1688;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0c28,&LAB_008e0e00);
  uVar2 = FUN_008e39a0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00ed54d0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e1170(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0c28,&LAB_008e0e00);
      uVar2 = FUN_008e39a0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15369 ; VA 0x008e13c0 ; FUN_008e13c0 */

undefined4 * FUN_008e13c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c16d3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ddb150();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ddebf0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de350(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15370 ; VA 0x008e1480 ; FUN_008e1480 */

int FUN_008e1480(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c16e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0c10,&LAB_008e0e10);
  uVar2 = FUN_008e3a20();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00ddb3f0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e13c0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0c10,&LAB_008e0e10);
      uVar2 = FUN_008e3a20();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15371 ; VA 0x008e1610 ; FUN_008e1610 */

undefined4 * FUN_008e1610(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1733;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e9e550();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x8c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e9e9c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de440(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15372 ; VA 0x008e16d0 ; FUN_008e16d0 */

int FUN_008e16d0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1748;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0c20,&LAB_008e0e20);
  uVar2 = FUN_008e3aa0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e9e630();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e1610(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0c20,&LAB_008e0e20);
      uVar2 = FUN_008e3aa0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15373 ; VA 0x008e1860 ; FUN_008e1860 */

undefined4 * FUN_008e1860(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1793;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00df2a90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x11c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00df42d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de530(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15374 ; VA 0x008e1920 ; FUN_008e1920 */

int FUN_008e1920(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c17a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0c00,&LAB_008e0e30);
  uVar2 = FUN_008e3b20();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00df2b70();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e1860(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0c00,&LAB_008e0e30);
      uVar2 = FUN_008e3b20();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15375 ; VA 0x008e1ab0 ; FUN_008e1ab0 */

undefined4 * FUN_008e1ab0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c17f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00db76f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00db8440();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de620(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15376 ; VA 0x008e1b70 ; FUN_008e1b70 */

int FUN_008e1b70(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1808;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0d08,&LAB_008e0e40);
  uVar2 = FUN_008e3ba0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00db79d0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e1ab0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0d08,&LAB_008e0e40);
      uVar2 = FUN_008e3ba0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15377 ; VA 0x008e1d00 ; FUN_008e1d00 */

undefined4 * FUN_008e1d00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1853;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b56db0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b5a1e0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de710(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15378 ; VA 0x008e1dc0 ; FUN_008e1dc0 */

int __fastcall FUN_008e1dc0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1868;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00636a50();
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    FUN_008e1d00(&iStack_18);
    uStack_8 = 0;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01ead658,&LAB_00634090);
    uVar4 = FUN_006350d0();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15379 ; VA 0x008e1eb0 ; FUN_008e1eb0 */

undefined4 * FUN_008e1eb0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c18b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008dcf60();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x4f8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_008e8070(*param_2,*param_3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de800(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15380 ; VA 0x008e1f80 ; FUN_008e1f80 */

undefined4 * FUN_008e1f80(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c18f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e45b70();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x7c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e45d20();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de900(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15381 ; VA 0x008e2040 ; FUN_008e2040 */

int FUN_008e2040(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1908;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0bf8,&LAB_008e0e50);
  uVar2 = FUN_008e3c20();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e45c50();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e1f80(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0bf8,&LAB_008e0e50);
      uVar2 = FUN_008e3c20();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15382 ; VA 0x008e21d0 ; FUN_008e21d0 */

undefined4 * FUN_008e21d0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1953;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00cbd460();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x140);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00cbe370();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008de9f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15383 ; VA 0x008e2290 ; FUN_008e2290 */

undefined4 * FUN_008e2290(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e58650();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e58950();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008deae0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15384 ; VA 0x008e2350 ; FUN_008e2350 */

int FUN_008e2350(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c19a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0bf0,&LAB_008e0e60);
  uVar2 = FUN_008e3ca0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e58730();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e2290(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0bf0,&LAB_008e0e60);
      uVar2 = FUN_008e3ca0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15385 ; VA 0x008e24e0 ; FUN_008e24e0 */

undefined4 * FUN_008e24e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c19f3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ed1ab0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(200);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ed1dc0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008debd0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15386 ; VA 0x008e25a0 ; FUN_008e25a0 */

int __fastcall FUN_008e25a0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1a08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_008e53d0();
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    FUN_008e24e0(&iStack_18);
    uStack_8 = 0;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01ee0d10,&LAB_008e0e70);
    uVar4 = FUN_008e3d20();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15387 ; VA 0x008e2690 ; FUN_008e2690 */

undefined4 * FUN_008e2690(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1a50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e43ed0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e43fd0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008decc0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15388 ; VA 0x008e2750 ; FUN_008e2750 */

int FUN_008e2750(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1a68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0be8,&LAB_008e0e80);
  uVar2 = FUN_008e3da0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e43fb0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e2690(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0be8,&LAB_008e0e80);
      uVar2 = FUN_008e3da0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15389 ; VA 0x008e28e0 ; FUN_008e28e0 */

undefined4 * FUN_008e28e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1ab3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bc46d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x128);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bc7120();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008dedb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15390 ; VA 0x008e29a0 ; FUN_008e29a0 */

int __fastcall FUN_008e29a0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1ac8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_0064f8c0();
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    FUN_008e28e0(&iStack_18);
    uStack_8 = 0;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
    uVar4 = FUN_0064e320();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15391 ; VA 0x008e2a90 ; FUN_008e2a90 */

undefined4 * FUN_008e2a90(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1b13;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e03740();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e04590();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008deea0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15392 ; VA 0x008e2b50 ; FUN_008e2b50 */

int FUN_008e2b50(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1b28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0bd8,&LAB_008e0e90);
  uVar2 = FUN_008e3e20();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e03820();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e2a90(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0bd8,&LAB_008e0e90);
      uVar2 = FUN_008e3e20();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15393 ; VA 0x008e2ce0 ; FUN_008e2ce0 */

undefined4 * FUN_008e2ce0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1b73;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c9aa70();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(300);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_008e95c0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008def90(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15394 ; VA 0x008e2da0 ; FUN_008e2da0 */

int FUN_008e2da0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1b88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
  uVar2 = FUN_006c4340();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00c9ab50();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e2ce0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
      uVar2 = FUN_006c4340();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15395 ; VA 0x008e2f30 ; FUN_008e2f30 */

int FUN_008e2f30(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1ba8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_005641e0();
  iVar5 = *piVar3;
  if (iVar5 == 0) {
    FUN_0055e950(&iStack_18);
    iStack_8 = iVar5;
    FUN_008a5700(param_1);
    FUN_005789c0(&DAT_01ea8a80,&LAB_0055d5a0);
    uVar4 = FUN_00560dc0();
    piVar3 = (int *)FUN_008aa140(uVar4);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *piVar3 = iStack_18;
    piVar1 = (int *)piVar3[1];
    piVar3[1] = (int)piStack_14;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar5 = iStack_18;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15396 ; VA 0x008e3030 ; FUN_008e3030 */

undefined4 * FUN_008e3030(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1bf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e59450();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x58);
    FUN_0089a7a0();
    *(undefined *)(puVar3 + 0x15) = 1;
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::Described<class_RBX::ScriptService,class_RBX::ServiceInstance>::vftable;
    uVar4 = FUN_00e59450();
    puVar3[3] = uVar4;
    *puVar3 = RBX::ScriptService::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008df080(puVar3,param_1);
  uStack_8 = 7;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15397 ; VA 0x008e3120 ; FUN_008e3120 */

int FUN_008e3120(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1c18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0c08,&LAB_008e0ec0);
  uVar2 = FUN_008e3fa0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e59530();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e3030(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0c08,&LAB_008e0ec0);
      uVar2 = FUN_008e3fa0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15398 ; VA 0x008e32b0 ; FUN_008e32b0 */

undefined4 * FUN_008e32b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1c63;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e6c6d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xe4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e6c880();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008df170(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15399 ; VA 0x008e3370 ; FUN_008e3370 */

undefined4 * FUN_008e3370(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1ca3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e8c060();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xa4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e8e350();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008df260(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15400 ; VA 0x008e3430 ; FUN_008e3430 */

int FUN_008e3430(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1cb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee0be0,&LAB_008e0ef0);
  uVar2 = FUN_008e4120();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e8c140();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e3370(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee0be0,&LAB_008e0ef0);
      uVar2 = FUN_008e4120();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15401 ; VA 0x008e35c0 ; FUN_008e35c0 */

undefined4 * FUN_008e35c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1d03;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00baf370();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x148);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bafa10();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008df350(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15402 ; VA 0x008e3680 ; FUN_008e3680 */

int FUN_008e3680(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ead670,&LAB_00634110);
  uVar2 = FUN_006354d0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00baf450();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_008e35c0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ead670,&LAB_00634110);
      uVar2 = FUN_006354d0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15403 ; VA 0x008e3810 ; FUN_008e3810 */

undefined4 * FUN_008e3810(undefined4 *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c1d63;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008aa870();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x358);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_008ada80(-(uint)(*param_2 != 0) & *param_2 + 4U,1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008df440(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15404 ; VA 0x008e38f0 ; FUN_008e38f0 */

void FUN_008e38f0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2[0x3b] != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_2[0x3b] + 8))(param_2 + 0x3c);
  }
  uStack_8 = 1;
  if (param_2[7] != 0) {
    (**(code **)(param_2[7] + 8))(param_2 + 8);
  }
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15405 ; VA 0x008e39a0 ; FUN_008e39a0 */

undefined4 FUN_008e39a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1d7c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d04) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d04);
    if (DAT_01ee0d04 == -1) {
      uStack_8 = 0;
      DAT_01ee0d00 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d04);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d00;
}



/* FUNCTION 15406 ; VA 0x008e3a20 ; FUN_008e3a20 */

undefined4 FUN_008e3a20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1d9c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cec);
    if (DAT_01ee0cec == -1) {
      uStack_8 = 0;
      DAT_01ee0ce8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cec);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0ce8;
}



/* FUNCTION 15407 ; VA 0x008e3aa0 ; FUN_008e3aa0 */

undefined4 FUN_008e3aa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1dbc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cfc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cfc);
    if (DAT_01ee0cfc == -1) {
      uStack_8 = 0;
      DAT_01ee0cf8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cfc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cf8;
}



/* FUNCTION 15408 ; VA 0x008e3b20 ; FUN_008e3b20 */

undefined4 FUN_008e3b20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1ddc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cdc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cdc);
    if (DAT_01ee0cdc == -1) {
      uStack_8 = 0;
      DAT_01ee0cd8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cdc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cd8;
}



/* FUNCTION 15409 ; VA 0x008e3ba0 ; FUN_008e3ba0 */

undefined4 FUN_008e3ba0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1dfc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d1c);
    if (DAT_01ee0d1c == -1) {
      uStack_8 = 0;
      DAT_01ee0d18 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d1c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d18;
}



/* FUNCTION 15410 ; VA 0x008e3c20 ; FUN_008e3c20 */

undefined4 FUN_008e3c20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1e1c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cd4);
    if (DAT_01ee0cd4 == -1) {
      uStack_8 = 0;
      DAT_01ee0cd0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cd4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cd0;
}



/* FUNCTION 15411 ; VA 0x008e3ca0 ; FUN_008e3ca0 */

undefined4 FUN_008e3ca0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1e3c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0ccc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0ccc);
    if (DAT_01ee0ccc == -1) {
      uStack_8 = 0;
      DAT_01ee0cc8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0ccc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cc8;
}



/* FUNCTION 15412 ; VA 0x008e3d20 ; FUN_008e3d20 */

undefined4 FUN_008e3d20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1e5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d34);
    if (DAT_01ee0d34 == -1) {
      uStack_8 = 0;
      DAT_01ee0d30 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d34);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d30;
}



/* FUNCTION 15413 ; VA 0x008e3da0 ; FUN_008e3da0 */

undefined4 FUN_008e3da0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1e7c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cc4);
    if (DAT_01ee0cc4 == -1) {
      uStack_8 = 0;
      DAT_01ee0cc0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cc4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cc0;
}



/* FUNCTION 15414 ; VA 0x008e3e20 ; FUN_008e3e20 */

undefined4 FUN_008e3e20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1e9c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cb4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cb4);
    if (DAT_01ee0cb4 == -1) {
      uStack_8 = 0;
      DAT_01ee0cb0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cb4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cb0;
}



/* FUNCTION 15415 ; VA 0x008e3ea0 ; FUN_008e3ea0 */

undefined4 FUN_008e3ea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1ebc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d44);
    if (DAT_01ee0d44 == -1) {
      uStack_8 = 0;
      DAT_01ee0d40 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d44);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d40;
}



/* FUNCTION 15416 ; VA 0x008e3f20 ; FUN_008e3f20 */

undefined4 FUN_008e3f20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1edc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d4c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d4c);
    if (DAT_01ee0d4c == -1) {
      uStack_8 = 0;
      DAT_01ee0d48 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d4c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d48;
}



/* FUNCTION 15417 ; VA 0x008e3fa0 ; FUN_008e3fa0 */

undefined4 FUN_008e3fa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1efc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0ce4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0ce4);
    if (DAT_01ee0ce4 == -1) {
      uStack_8 = 0;
      DAT_01ee0ce0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0ce4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0ce0;
}



/* FUNCTION 15418 ; VA 0x008e4020 ; FUN_008e4020 */

undefined4 FUN_008e4020(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1f1c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0d54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0d54);
    if (DAT_01ee0d54 == -1) {
      uStack_8 = 0;
      DAT_01ee0d50 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0d54);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0d50;
}



/* FUNCTION 15419 ; VA 0x008e40a0 ; FUN_008e40a0 */

undefined4 FUN_008e40a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1f3c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cf4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cf4);
    if (DAT_01ee0cf4 == -1) {
      uStack_8 = 0;
      DAT_01ee0cf0 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cf4);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cf0;
}



/* FUNCTION 15420 ; VA 0x008e4120 ; FUN_008e4120 */

undefined4 FUN_008e4120(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1f5c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cbc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0cbc);
    if (DAT_01ee0cbc == -1) {
      uStack_8 = 0;
      DAT_01ee0cb8 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee0cbc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee0cb8;
}



/* FUNCTION 15421 ; VA 0x008e41a0 ; FUN_008e41a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008e41a0(byte *param_1,int *param_2,int param_3,undefined4 param_4,int param_5)

{
  byte bVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar7 = param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1f88;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar5,iVar7,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_3 == 0) {
    iStack_8 = 0;
    FUN_008f1a90();
    param_3 = 8;
    FUN_0054ef60(param_4);
    iVar7 = param_5;
    param_4 = 0x20;
    iStack_8._0_1_ = 1;
    FUN_005caf00(param_5);
    iStack_8._0_1_ = 2;
    FUN_005caf00(iVar7 + 0xd0);
    uRam000001c0 = *(undefined4 *)(iVar7 + 0x1a0);
    uVar2 = *(uint *)(param_1 + 8);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    uVar6 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005c6680(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      uVar8 = uVar2 >> 1;
      if (uVar8 + uVar2 <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005c9310(uVar8 + uVar2);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005c6680(iVar7);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar9;
        while (puVar3 != (undefined4 *)0x0) {
          piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar4 = (int)puVar9;
            puVar9 = puVar3;
          }
          else {
            *puVar9 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar4;
            *(undefined4 **)*piVar4 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar9;
        }
      }
    }
    uVar6 = uVar5 % *(uint *)(param_1 + 4);
    piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    _DAT_00000004 = uVar5;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar4 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar9 = piVar4;
      _DAT_00000000 = *piVar4;
      *piVar4 = 0;
    }
    else {
      _DAT_00000000 = *piVar4;
      *(undefined4 *)*puVar9 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = 0;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15422 ; VA 0x008e4390 ; FUN_008e4390 */

int FUN_008e4390(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008dcf60();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1 + -0xc;
    }
  }
  return 0;
}



/* FUNCTION 15423 ; VA 0x008e43d0 ; FUN_008e43d0 */

int FUN_008e43d0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c3ebd0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 15424 ; VA 0x008e4410 ; FUN_008e4410 */

int FUN_008e4410(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01eaad54,&LAB_005f4440);
  uVar3 = FUN_005f5590();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00a5e170();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 15425 ; VA 0x008e44d0 ; FUN_008e44d0 */

undefined4 FUN_008e44d0(int param_1)

{
  undefined4 *puVar1;
  
  if (param_1 != 0) {
    puVar1 = (undefined4 *)FUN_00636b00();
    return *puVar1;
  }
  return 0;
}



/* FUNCTION 15426 ; VA 0x008e44f0 ; FUN_008e44f0 */

undefined4 FUN_008e44f0(int param_1)

{
  undefined4 *puVar1;
  
  if (param_1 != 0) {
    puVar1 = (undefined4 *)FUN_0064f8c0();
    return *puVar1;
  }
  return 0;
}



/* FUNCTION 15427 ; VA 0x008e4510 ; FUN_008e4510 */

undefined4 FUN_008e4510(int param_1)

{
  undefined4 *puVar1;
  
  if (param_1 != 0) {
    puVar1 = (undefined4 *)FUN_006771e0();
    return *puVar1;
  }
  return 0;
}



/* FUNCTION 15428 ; VA 0x008e4530 ; FUN_008e4530 */

int FUN_008e4530(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
  uVar3 = FUN_006353d0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b774a0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 15429 ; VA 0x008e45f0 ; FUN_008e45f0 */

int FUN_008e45f0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01eaddbc,&LAB_00670ca0);
  uVar3 = FUN_00675db0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00c0edd0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 15430 ; VA 0x008e46b0 ; FUN_008e46b0 */

int FUN_008e46b0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd5c,&LAB_00670d60);
  uVar3 = FUN_006763b0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00bdf940();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 15431 ; VA 0x008e4770 ; FUN_008e4770 */

/* WARNING: Type propagation algorithm not settling */

undefined4 __thiscall FUN_008e4770(int param_1,char *param_2)

{
  char *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  char *pcVar5;
  undefined4 *******pppppppuVar6;
  char *pcVar7;
  uint uVar8;
  char *pcVar9;
  uint uVar10;
  int iVar11;
  undefined4 *******apppppppuStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1fb0;
  pvStack_10 = ExceptionList;
  iVar11 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar3,pcVar5,-(uint)(iVar11 != 0) & iVar11 + 1U);
  pcVar1 = param_2;
  if (param_2 != (char *)0x0) {
    iVar11 = *(int *)(param_2 + 0x20);
    iVar4 = FUN_00888530();
    if (iVar11 != iVar4) {
      iVar11 = *(int *)(pcVar1 + 0x20);
      iVar4 = FUN_0088c8c0();
      if (iVar11 != iVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      pcVar5 = pcVar1 + 0x28;
      iVar11 = *(int *)(pcVar1 + 0x24);
      goto LAB_008e48f5;
    }
  }
  aiStack_18[1] = 0;
  pcVar9 = pcVar5;
  if (0xf < *(uint *)(pcVar5 + 0x14)) {
    pcVar9 = *(char **)pcVar5;
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar7 = pcVar9;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(pcVar9,(int)pcVar7 - (int)(pcVar9 + 1));
  uStack_8 = 0;
  cVar2 = FUN_01677920(auStack_40,&uStack_1c,0,aiStack_18,aiStack_18 + 1);
  uStack_8 = 0xffffffff;
  param_2._3_1_ = cVar2;
  if (0xf < uStack_2c) {
    uVar10 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar10 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  if (param_2._3_1_ == '\0') {
    if (pcVar1 != (char *)0x0) {
      iVar11 = *(int *)(pcVar1 + 0xf0);
      iVar4 = FUN_0088c8c0();
      if (iVar11 == iVar4) {
        pcVar5 = pcVar1 + 0xf8;
        iVar11 = *(int *)(pcVar1 + 0xf4);
LAB_008e48f5:
        if (iVar11 == 0) {
          pcVar5 = (char *)0x0;
        }
        ExceptionList = pvStack_10;
        return *(undefined4 *)pcVar5;
      }
      goto LAB_008e4993;
    }
  }
  else {
    if ((aiStack_18[0] != 0) && (aiStack_18[0] != 3)) {
      uVar3 = FUN_008f61a0(aiStack_18[0]);
      if (0xf < *(uint *)(pcVar5 + 0x14)) {
        pcVar5 = *(char **)pcVar5;
      }
      FUN_01675640(apppppppuStack_58,
                   "Flag \'%s\' referenced from Lua as \'%s\', but it was defined as \'%s\'",pcVar5,
                   &DAT_0191cd9c,uVar3);
      uStack_8 = 1;
      if (DAT_01d84e8d != '\0') {
        pppppppuVar6 = apppppppuStack_58;
        if (0xf < uStack_44) {
          pppppppuVar6 = apppppppuStack_58[0];
        }
        FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,pppppppuVar6);
      }
      FUN_005500e0(apppppppuStack_58);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_28,&DAT_01c17198);
    }
    if ((aiStack_18[0] != 0) || (pcVar1 != (char *)0x0)) {
      ExceptionList = pvStack_10;
      return uStack_1c;
    }
  }
  FUN_00910e70(pcVar5);
LAB_008e4993:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15432 ; VA 0x008e49a0 ; FUN_008e49a0 */

uint * __thiscall FUN_008e49a0(int param_1,uint *param_2,char *param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 ***pppuVar5;
  char *pcVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  int iVar10;
  undefined4 **appuStack_60 [5];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint auStack_30 [3];
  undefined auStack_24 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017c1fd8;
  pvStack_10 = ExceptionList;
  iVar10 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005702d0(param_3);
  FUN_00562fc0(&iStack_14,uVar2,param_3,-(uint)(iVar10 != 0) & iVar10 + 1U);
  iVar10 = iStack_14;
  if (iStack_14 != 0) {
    iVar4 = *(int *)(iStack_14 + 0x20);
    iVar3 = FUN_00888530();
    if (iVar4 != iVar3) {
      iVar4 = *(int *)(iVar10 + 0x20);
      iVar3 = FUN_0088cb40();
      if (iVar4 != iVar3) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      iVar4 = iVar10 + 0x28;
      iVar10 = *(int *)(iVar10 + 0x24);
      goto LAB_008e4b8d;
    }
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_8 = 0;
  iStack_14 = 0;
  pcVar8 = param_3;
  if (0xf < *(uint *)(param_3 + 0x14)) {
    pcVar8 = *(char **)param_3;
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcVar6 = pcVar8;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar8,(int)pcVar6 - (int)(pcVar8 + 1));
  uStack_8._0_1_ = 1;
  cVar1 = FUN_01677930(auStack_30,&uStack_48,0,&iStack_18,&iStack_14);
  uStack_8._0_1_ = 0;
  if (0xf < uStack_1c) {
    uVar9 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar9 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uVar7 = uStack_48;
  if (cVar1 == '\0') {
    uStack_8._0_1_ = 0xff;
    uStack_8._1_3_ = 0xffffff;
    FUN_005507b0();
    if (iVar10 != 0) {
      iVar4 = *(int *)(iVar10 + 0xf0);
      iVar3 = FUN_0088cb40();
      if (iVar4 == iVar3) {
        iVar4 = iVar10 + 0xf8;
        iVar10 = *(int *)(iVar10 + 0xf4);
LAB_008e4b8d:
        if (iVar10 == 0) {
          iVar4 = 0;
        }
        FUN_0054ef60(iVar4);
        ExceptionList = pvStack_10;
        return param_2;
      }
      goto LAB_008e4c31;
    }
  }
  else {
    if ((iStack_18 != 0) && (iStack_18 != 2)) {
      uVar2 = FUN_008f61a0(iStack_18);
      if (0xf < *(uint *)(param_3 + 0x14)) {
        param_3 = *(char **)param_3;
      }
      FUN_01675640(appuStack_60,
                   "Flag \'%s\' referenced from Lua as \'%s\', but it was defined as \'%s\'",param_3
                   ,"string",uVar2);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (DAT_01d84e8d != '\0') {
        pppuVar5 = appuStack_60;
        if (0xf < uStack_4c) {
          pppuVar5 = (undefined4 ***)appuStack_60[0];
        }
        FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,pppuVar5);
      }
      FUN_005500e0(appuStack_60);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    if ((iStack_18 != 0) || (iVar10 != 0)) {
      uStack_48 = uStack_48 & 0xffffff00;
      param_2[4] = 0;
      param_2[5] = 0;
      *param_2 = uVar7;
      param_2[1] = uStack_44;
      param_2[2] = uStack_40;
      param_2[3] = uStack_3c;
      *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_34,uStack_38);
      uStack_38 = 0;
      uStack_34 = 0xf;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_00910e70(param_3);
LAB_008e4c31:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15433 ; VA 0x008e4c40 ; FUN_008e4c40 */

/* WARNING: Type propagation algorithm not settling */

char __thiscall FUN_008e4c40(int param_1,char *param_2)

{
  char *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  char *pcVar5;
  undefined4 *******pppppppuVar6;
  char *pcVar7;
  uint uVar8;
  char *pcVar9;
  uint uVar10;
  int iVar11;
  undefined4 *******apppppppuStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [12];
  int aiStack_1c [2];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1fb0;
  pvStack_10 = ExceptionList;
  iVar11 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar3,pcVar5,-(uint)(iVar11 != 0) & iVar11 + 1U);
  pcVar1 = param_2;
  if (param_2 != (char *)0x0) {
    iVar11 = *(int *)(param_2 + 0x20);
    iVar4 = FUN_00888530();
    if (iVar11 != iVar4) {
      iVar11 = *(int *)(pcVar1 + 0x20);
      iVar4 = FUN_0088daf0();
      if (iVar11 != iVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      pcVar5 = pcVar1 + 0x28;
      iVar11 = *(int *)(pcVar1 + 0x24);
      goto LAB_008e4dc5;
    }
  }
  aiStack_1c[1] = 0;
  pcVar9 = pcVar5;
  if (0xf < *(uint *)(pcVar5 + 0x14)) {
    pcVar9 = *(char **)pcVar5;
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar7 = pcVar9;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(pcVar9,(int)pcVar7 - (int)(pcVar9 + 1));
  uStack_8 = 0;
  cVar2 = FUN_01677940(auStack_40,&cStack_11,0,aiStack_1c,aiStack_1c + 1);
  uStack_8 = 0xffffffff;
  param_2._3_1_ = cVar2;
  if (0xf < uStack_2c) {
    uVar10 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar10 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  if (param_2._3_1_ == '\0') {
    if (pcVar1 != (char *)0x0) {
      iVar11 = *(int *)(pcVar1 + 0xf0);
      iVar4 = FUN_0088daf0();
      if (iVar11 == iVar4) {
        pcVar5 = pcVar1 + 0xf8;
        iVar11 = *(int *)(pcVar1 + 0xf4);
LAB_008e4dc5:
        if (iVar11 == 0) {
          pcVar5 = (char *)0x0;
        }
        ExceptionList = pvStack_10;
        return *pcVar5;
      }
      goto LAB_008e4e63;
    }
  }
  else {
    if ((aiStack_1c[0] != 0) && (aiStack_1c[0] != 4)) {
      uVar3 = FUN_008f61a0(aiStack_1c[0]);
      if (0xf < *(uint *)(pcVar5 + 0x14)) {
        pcVar5 = *(char **)pcVar5;
      }
      FUN_01675640(apppppppuStack_58,
                   "Flag \'%s\' referenced from Lua as \'%s\', but it was defined as \'%s\'",pcVar5,
                   &DAT_0192cd70,uVar3);
      uStack_8 = 1;
      if (DAT_01d84e8d != '\0') {
        pppppppuVar6 = apppppppuStack_58;
        if (0xf < uStack_44) {
          pppppppuVar6 = apppppppuStack_58[0];
        }
        FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,pppppppuVar6);
      }
      FUN_005500e0(apppppppuStack_58);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_28,&DAT_01c17198);
    }
    if ((aiStack_1c[0] != 0) || (pcVar1 != (char *)0x0)) {
      ExceptionList = pvStack_10;
      return cStack_11;
    }
  }
  FUN_00910e70(pcVar5);
LAB_008e4e63:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15434 ; VA 0x008e4e70 ; thunk_FUN_0063cc40 */

undefined * thunk_FUN_0063cc40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a028c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead5ec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead5ec);
    if (DAT_01ead5ec == -1) {
      uStack_8 = 0;
      FUN_008e7010();
      FUN_016f3654(&LAB_0187cbb0);
      FUN_016f37bf(&DAT_01ead5ec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ead588;
}



/* FUNCTION 15435 ; VA 0x008e4e80 ; thunk_FUN_0090bd10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0090bd10(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5506;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0b44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0b44);
    if (DAT_01ee0b44 == -1) {
      uStack_8 = 0;
      FUN_009ca470("GameAvatarType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0ae0 = RBX::Reflection::EnumDesc<enum_RBX::GameAvatarType>::vftable;
      FUN_009caf20(&DAT_01d63708,3);
      FUN_016f3654(&LAB_01883000);
      FUN_016f37bf(&DAT_01ee0b44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0ae0;
}



/* FUNCTION 15436 ; VA 0x008e4e90 ; thunk_FUN_0090c0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0090c0c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c55a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0adc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0adc);
    if (DAT_01ee0adc == -1) {
      uStack_8 = 0;
      FUN_009ca470("R15CollisionType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0a78 = RBX::Reflection::EnumDesc<enum_RBX::R15CollisionType>::vftable;
      FUN_009caf20(&DAT_01d63720,2);
      FUN_016f3654(&LAB_018830a0);
      FUN_016f37bf(&DAT_01ee0adc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0a78;
}



/* FUNCTION 15437 ; VA 0x008e4ea0 ; FUN_008e4ea0 */

void FUN_008e4ea0(void)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b3258;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,4);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    *puVar3 = boost::thread_specific_ptr<class_RBX::DataModel::GenericJob*>::delete_data::vftable;
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 15438 ; VA 0x008e4f00 ; FUN_008e4f00 */

int * FUN_008e4f00(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2002;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x160);
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::DataModel::GenericJob>::vftable;
    uVar2 = *param_4;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_008e8b60(*param_2,param_2[1],param_3,uVar2);
  }
  piVar1 = piVar4 + 4;
  *param_1 = (int)piVar1;
  param_1[1] = (int)piVar4;
  if ((piVar1 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar5 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar1;
    piVar1 = (int *)piVar4[7];
    piVar4[7] = (int)piVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15439 ; VA 0x008e5010 ; FUN_008e5010 */

int * FUN_008e5010(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2032;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x160);
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::GenericTelemetryEnabledJob>::vftable;
    uVar1 = *param_4;
    piVar6 = (int *)param_2[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)param_2[1];
    }
    uVar2 = *param_2;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    FUN_008e8b60(uVar2,piVar6,param_3,uVar1);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piVar4[4] = (int)RBX::GenericTelemetryEnabledJob::vftable;
    FUN_00a361f0();
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar3 = piVar6[2] + -1;
        piVar6[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  piVar6 = piVar4 + 4;
  *param_1 = (int)piVar6;
  param_1[1] = (int)piVar4;
  if ((piVar6 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar5 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar6;
    piVar6 = (int *)piVar4[7];
    piVar4[7] = (int)piVar5;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[2] + -1;
      piVar6[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar4 = piVar5 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15440 ; VA 0x008e5180 ; FUN_008e5180 */

void FUN_008e5180(int *param_1,int param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2057;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_RBX::http_status_error>::vftable;
    puVar1[3] = std::exception::vftable;
    *(undefined8 *)(puVar1 + 4) = 0;
    FUN_0170c226(param_2 + 4,puVar1 + 4);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar1[3] = RBX::http_status_error::vftable;
    FUN_0054ef60(param_2 + 0xc);
    puVar1[0xc] = *(undefined4 *)(param_2 + 0x24);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15441 ; VA 0x008e5230 ; FUN_008e5230 */

void FUN_008e5230(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2087;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 0;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3[1] = 1;
    puVar3[2] = 1;
    *puVar3 = std::_Ref_count_obj<class_RBX::http_status_error>::vftable;
    pcVar2 = (char *)*param_3;
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    pcVar4 = pcVar2;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    puStack_14 = puVar3;
    FUN_005542c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_014cc2c0(*param_2,auStack_2c);
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = auStack_2c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_2c[0] - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  *param_1 = (int)(puVar3 + 3);
  param_1[1] = (int)puVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15442 ; VA 0x008e5320 ; FUN_008e5320 */

int * FUN_008e5320(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ee0d08,&LAB_008e0e40);
  uVar3 = FUN_008e3ba0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00db79d0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 15443 ; VA 0x008e53d0 ; FUN_008e53d0 */

int * FUN_008e53d0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ee0d10,&LAB_008e0e70);
  uVar3 = FUN_008e3d20();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00ed1b90();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 15444 ; VA 0x008e5480 ; FUN_008e5480 */

int * FUN_008e5480(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ee0d38,&LAB_008e0ed0);
  uVar3 = FUN_008e4020();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00e46b80();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 15445 ; VA 0x008e5530 ; FUN_008e5530 */

int * FUN_008e5530(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ee0c18,&LAB_008e0ee0);
  uVar3 = FUN_008e40a0();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00e6c7b0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 15446 ; VA 0x008e55e0 ; FUN_008e55e0 */

void __thiscall FUN_008e55e0(int param_1,char *param_2,int param_3,int param_4)

{
  code *pcVar1;
  char *pcVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  char *pcVar7;
  uint uVar8;
  char *pcVar9;
  uint uVar10;
  int iVar11;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_118;
  undefined4 uStack_114;
  int iStack_110;
  int iStack_48;
  undefined auStack_44 [8];
  undefined auStack_3c [4];
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c20ee;
  pvStack_10 = ExceptionList;
  iVar11 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  ExceptionList = &pvStack_10;
  iStack_38 = param_1;
  uVar4 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar4,pcVar2,-(uint)(iVar11 != 0) & iVar11 + 1U);
  pcVar9 = param_2;
  if (param_2 != (char *)0x0) {
    iVar11 = *(int *)(param_2 + 0xf0);
    iVar5 = FUN_0088c8c0();
    if (iVar11 != iVar5) {
      FUN_0054eff0("previous definition in Lua used different type (string, int, bool)");
      uStack_8 = 0;
      FUN_0090cd90(auStack_28,pcVar2);
LAB_008e5819:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iVar11 = *(int *)(pcVar9 + 0xf0);
    iVar5 = FUN_0088c8c0();
    if (iVar11 != iVar5) goto LAB_008e5819;
    piVar6 = (int *)(pcVar9 + 0xf8);
    if (*(int *)(pcVar9 + 0xf4) == 0) {
      piVar6 = (int *)0x0;
    }
    if (*piVar6 == param_3) {
      if (*(int *)(pcVar9 + 0x1c0) == param_4) goto LAB_008e57df;
    }
    else {
      FUN_0054eff0("previous definition in Lua used different default value");
      uStack_8 = 1;
      FUN_0090cd90(auStack_28,pcVar2);
    }
    FUN_0054eff0("previous definition in Lua used different fast type (static, dynamic, etc.)");
    uStack_8 = 2;
    FUN_0090cd90(auStack_28,pcVar2);
LAB_008e585f:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  iStack_2c = 0;
  iStack_30 = 0;
  pcVar9 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar9 = *(char **)pcVar2;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar7 = pcVar9;
  do {
    cVar3 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(pcVar9,(int)pcVar7 - (int)(pcVar9 + 1));
  uStack_8 = 3;
  cVar3 = FUN_01677920(auStack_28,auStack_3c,&iStack_34,&iStack_2c,&iStack_30);
  param_2 = (char *)CONCAT13(cVar3,param_2._0_3_);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar10 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar10 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) goto LAB_008e585f;
    }
    FUN_01674ea0(uVar8,uVar10);
    cVar3 = param_2._3_1_;
  }
  if ((cVar3 == '\0') || (iStack_2c == 0)) {
    uStack_1e8 = FUN_00888530();
    uStack_1e4 = 0;
    uStack_8 = 7;
    uStack_118 = FUN_0088c8c0();
    uStack_114 = 0;
    iStack_110 = param_3;
    uStack_114 = FUN_005c9cc0();
    iStack_48 = param_4;
    uStack_8 = 8;
    FUN_008e41a0(auStack_44,pcVar2,pcVar2,&uStack_1e8);
    uStack_8 = 0xffffffff;
    FUN_008eaef0();
LAB_008e57df:
    FUN_008e4770(pcVar2);
    ExceptionList = pvStack_10;
    return;
  }
  if (iStack_2c == 3) {
    if (iStack_34 == param_3) {
      if (iStack_30 == param_4) goto LAB_008e57df;
      goto LAB_008e58a0;
    }
  }
  else {
    FUN_0054eff0("definition in C++ used different type (string, int, bool)");
    uStack_8 = 4;
    FUN_0090cd90(auStack_28,pcVar2);
  }
  FUN_0054eff0("definition in C++ used different default value");
  uStack_8 = 5;
  FUN_0090cd90(auStack_28,pcVar2);
LAB_008e58a0:
  FUN_0054eff0("definition in C++ used different fast type (static, dynamic, etc.)");
  uStack_8 = 6;
  FUN_0090cd90(auStack_28,pcVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 15447 ; VA 0x008e58c0 ; FUN_008e58c0 */

undefined4 __thiscall FUN_008e58c0(int param_1,undefined4 param_2,char *param_3,undefined4 *param_4)

{
  char *pcVar1;
  char *pcVar2;
  undefined uVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  char *pcVar7;
  undefined4 *puVar8;
  char *pcVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  int iStack_70;
  undefined auStack_6c [8];
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pcVar2 = param_3;
  puStack_c = &LAB_017c2166;
  pvStack_10 = ExceptionList;
  iVar12 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_34 = param_1;
  uVar5 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar5,pcVar2,-(uint)(iVar12 != 0) & iVar12 + 1U);
  pcVar9 = param_3;
  if (param_3 != (char *)0x0) {
    iVar12 = *(int *)(param_3 + 0xf0);
    iVar6 = FUN_0088cb40();
    if (iVar12 != iVar6) {
      FUN_0054eff0("previous definition in Lua used different type (string, int, bool)");
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      FUN_0090cd90(auStack_4c,pcVar2);
LAB_008e5b93:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iVar12 = *(int *)(pcVar9 + 0xf0);
    iVar6 = FUN_0088cb40();
    if (iVar12 != iVar6) goto LAB_008e5b93;
    pcVar7 = pcVar9 + 0xf8;
    if (*(int *)(pcVar9 + 0xf4) == 0) {
      pcVar7 = (char *)0x0;
    }
    puVar8 = &param_4;
    if (0xf < in_stack_00000020) {
      puVar8 = param_4;
    }
    pcVar1 = pcVar7 + 0x10;
    if (0xf < *(uint *)(pcVar7 + 0x14)) {
      pcVar7 = *(char **)pcVar7;
    }
    cVar4 = FUN_0055c360(pcVar7,*(undefined4 *)pcVar1,puVar8,in_stack_0000001c);
    if (cVar4 == '\0') {
      FUN_0054eff0("previous definition in Lua used different default value");
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      FUN_0090cd90(auStack_4c,pcVar2);
    }
    else if (*(int *)(pcVar9 + 0x1c0) == in_stack_00000024) goto LAB_008e5b22;
    FUN_0054eff0("previous definition in Lua used different fast type (static, dynamic, etc.)");
    iStack_8._0_1_ = 3;
    FUN_0090cd90(auStack_4c,pcVar2);
    uVar3 = (undefined)iStack_8;
LAB_008e5bd3:
    iStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = 0;
  iStack_8._0_1_ = 5;
  iStack_14 = 0;
  iStack_18 = 0;
  pcVar9 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar9 = *(char **)pcVar2;
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcVar7 = pcVar9;
  do {
    cVar4 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar4 != '\0');
  FUN_005542c0(pcVar9,(int)pcVar7 - (int)(pcVar9 + 1));
  iStack_8._0_1_ = 6;
  cVar4 = FUN_01677930(auStack_30,auStack_4c,auStack_64,&iStack_14,&iStack_18);
  param_3 = (char *)CONCAT13(cVar4,param_3._0_3_);
  iStack_8._0_1_ = 5;
  uVar3 = (undefined)iStack_8;
  iStack_8._0_1_ = 5;
  if (0xf < uStack_1c) {
    uVar10 = uStack_1c + 1;
    uVar11 = auStack_30[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_30[0] - 4);
      uVar10 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar11) - 4) goto LAB_008e5bd3;
    }
    FUN_01674ea0(uVar11,uVar10);
    cVar4 = param_3._3_1_;
  }
  if ((cVar4 == '\0') || (iStack_14 == 0)) {
    uStack_210 = FUN_00888530();
    uStack_20c = 0;
    iStack_8._0_1_ = 10;
    uStack_140 = FUN_0088cb40();
    uStack_13c = 0;
    FUN_0054ef60(&param_4);
    uStack_13c = FUN_005c9d30();
    iStack_70 = in_stack_00000024;
    iStack_8._0_1_ = 0xb;
    FUN_008e41a0(auStack_6c,pcVar2,pcVar2,&uStack_210);
    FUN_008eaef0();
LAB_008e5b0e:
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
LAB_008e5b22:
    FUN_008e49a0(param_2,pcVar2);
    if (0xf < in_stack_00000020) {
      uVar11 = in_stack_00000020 + 1;
      puVar8 = param_4;
      if (0xfff < uVar11) {
        puVar8 = (undefined4 *)param_4[-1];
        uVar11 = in_stack_00000020 + 0x24;
        if (0x1f < (uint)((int)param_4 + (-4 - (int)puVar8))) goto LAB_008e5c29;
      }
      FUN_01674ea0(puVar8,uVar11);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (iStack_14 == 2) {
    cVar4 = FUN_00684460(auStack_64,&param_4);
    if (cVar4 != '\0') goto LAB_008e5bf3;
    if (iStack_18 == in_stack_00000024) goto LAB_008e5b0e;
  }
  else {
    FUN_0054eff0("definition in C++ used different type (string, int, bool)");
    iStack_8._0_1_ = 7;
    FUN_0090cd90(auStack_30,pcVar2);
LAB_008e5bf3:
    FUN_0054eff0("definition in C++ used different default value");
    iStack_8._0_1_ = 8;
    FUN_0090cd90(auStack_30,pcVar2);
  }
  FUN_0054eff0("definition in C++ used different fast type (static, dynamic, etc.)");
  iStack_8 = CONCAT31(iStack_8._1_3_,9);
  FUN_0090cd90(auStack_30,pcVar2);
LAB_008e5c29:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 15448 ; VA 0x008e5c30 ; FUN_008e5c30 */

void __thiscall FUN_008e5c30(int param_1,char *param_2,char param_3,int param_4)

{
  code *pcVar1;
  char *pcVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  char *pcVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  int iVar10;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_114;
  undefined4 uStack_110;
  char cStack_10c;
  int iStack_44;
  undefined auStack_40 [8];
  int iStack_38;
  int iStack_34;
  int iStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c21be;
  pvStack_10 = ExceptionList;
  iVar10 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  ExceptionList = &pvStack_10;
  iStack_38 = param_1;
  uVar4 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar4,pcVar2,-(uint)(iVar10 != 0) & iVar10 + 1U);
  pcVar8 = param_2;
  if (param_2 != (char *)0x0) {
    iVar10 = *(int *)(param_2 + 0xf0);
    iVar5 = FUN_0088daf0();
    if (iVar10 != iVar5) {
      FUN_0054eff0("previous definition in Lua used different type (string, int, bool)");
      uStack_8 = 0;
      FUN_0090cd90(auStack_2c,pcVar2);
LAB_008e5e69:
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iVar10 = *(int *)(pcVar8 + 0xf0);
    iVar5 = FUN_0088daf0();
    if (iVar10 != iVar5) goto LAB_008e5e69;
    pcVar6 = pcVar8 + 0xf8;
    if (*(int *)(pcVar8 + 0xf4) == 0) {
      pcVar6 = (char *)0x0;
    }
    if (*pcVar6 == param_3) {
      if (*(int *)(pcVar8 + 0x1c0) == param_4) goto LAB_008e5e2f;
    }
    else {
      FUN_0054eff0("previous definition in Lua used different default value");
      uStack_8 = 1;
      FUN_0090cd90(auStack_2c,pcVar2);
    }
    FUN_0054eff0("previous definition in Lua used different fast type (static, dynamic, etc.)");
    uStack_8 = 2;
    FUN_0090cd90(auStack_2c,pcVar2);
LAB_008e5eaf:
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  iStack_30 = 0;
  iStack_34 = 0;
  pcVar8 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar8 = *(char **)pcVar2;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar6 = pcVar8;
  do {
    cVar3 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(pcVar8,(int)pcVar6 - (int)(pcVar8 + 1));
  uStack_8 = 3;
  cVar3 = FUN_01677940(auStack_2c,&uStack_12,&cStack_11,&iStack_30,&iStack_34);
  param_2 = (char *)CONCAT13(cVar3,param_2._0_3_);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    uVar7 = auStack_2c[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_2c[0] - 4);
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar7) - 4) goto LAB_008e5eaf;
    }
    FUN_01674ea0(uVar7,uVar9);
    cVar3 = param_2._3_1_;
  }
  if ((cVar3 == '\0') || (iStack_30 == 0)) {
    uStack_1e4 = FUN_00888530();
    uStack_1e0 = 0;
    uStack_8 = 7;
    uStack_114 = FUN_0088daf0();
    uStack_110 = 0;
    cStack_10c = param_3;
    uStack_110 = FUN_005c9ef0();
    iStack_44 = param_4;
    uStack_8 = 8;
    FUN_008e41a0(auStack_40,pcVar2,pcVar2,&uStack_1e4);
    uStack_8 = 0xffffffff;
    FUN_008eaef0();
LAB_008e5e2f:
    FUN_008e4c40(pcVar2);
    ExceptionList = pvStack_10;
    return;
  }
  if (iStack_30 == 4) {
    if (cStack_11 == param_3) {
      if (iStack_34 == param_4) goto LAB_008e5e2f;
      goto LAB_008e5ef0;
    }
  }
  else {
    FUN_0054eff0("definition in C++ used different type (string, int, bool)");
    uStack_8 = 4;
    FUN_0090cd90(auStack_2c,pcVar2);
  }
  FUN_0054eff0("definition in C++ used different default value");
  uStack_8 = 5;
  FUN_0090cd90(auStack_2c,pcVar2);
LAB_008e5ef0:
  FUN_0054eff0("definition in C++ used different fast type (static, dynamic, etc.)");
  uStack_8 = 6;
  FUN_0090cd90(auStack_2c,pcVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 15449 ; VA 0x008e5f10 ; FUN_008e5f10 */

void FUN_008e5f10(uint param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c21eb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_ec = (undefined4 *)0x8e5f3b;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088cb40();
  puStack_ec = &stack0x00000024;
  puStack_f0 = (undefined *)0x8e5f5a;
  FUN_0054ef60();
  puStack_ec = (undefined4 *)0x8e5f5f;
  puVar3 = (undefined4 *)FUN_005c9d30();
  puStack_14 = (undefined *)&uStack_1b8;
  uStack_8._0_1_ = 2;
  puStack_1b4 = (undefined4 *)0x0;
  uStack_1b8 = uVar2;
  puVar1 = &uStack_1b8;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(auStack_dc,auStack_1b0);
    puVar1 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar1;
  puStack_1b4 = puVar3;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  if (puVar3 != (undefined4 *)0x0) {
    puStack_ec = (undefined4 *)auStack_dc;
    puStack_f0 = (undefined *)0x8e5fca;
    (*(code *)puVar3[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined4 *)0x2;
    uStack_f8 = 0x8e5fee;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  if (0xf < in_stack_00000038) {
    puStack_ec = (undefined4 *)(in_stack_00000038 + 1);
    iVar4 = in_stack_00000024;
    if (0xfff < puStack_ec) {
      iVar4 = *(int *)(in_stack_00000024 + -4);
      puStack_ec = (undefined4 *)(in_stack_00000038 + 0x24);
      if (0x1f < (in_stack_00000024 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_ec = (undefined4 *)&UNK_008e603c;
        FUN_017167a3();
      }
    }
    puStack_f4 = (undefined *)0x8e6025;
    puStack_f0 = (undefined *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15450 ; VA 0x008e6040 ; FUN_008e6040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_008e6040(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  code **ppcStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c221b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_f0 = (int *)0x8e606c;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0088cc80();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded74) {
    piStack_f0 = &DAT_01eded74;
    puStack_f4 = (undefined *)0x8e61ac;
    FUN_016f3809();
    if (DAT_01eded74 == -1) {
      piStack_f0 = &DAT_01eded74;
      DAT_01eded68 = FUN_0057bbb0;
      _DAT_01eded6c = FUN_005880a0;
      DAT_01eded70 = FUN_0057d5e0;
      puStack_f4 = (undefined *)0x8e61e4;
      FUN_016f37bf();
    }
  }
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  ppcStack_1b8 = (code **)0x0;
  uStack_1bc = uVar4;
  (*DAT_01eded68)(&uStack_dc,auStack_1b4);
  ppcStack_1b8 = &DAT_01eded68;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  piStack_f0 = &uStack_dc;
  puStack_f4 = (undefined *)0x8e613c;
  (*DAT_01eded70)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    piStack_f0 = (int *)0x2;
    uStack_fc = 0x8e6160;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_f0 = (int *)0x8e6183;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_f0 = (int *)0x8e6192;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15451 ; VA 0x008e61f0 ; FUN_008e61f0 */

void FUN_008e61f0(uint param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined in_stack_00000024;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined *puStack_ec;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be3c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_ec = (undefined *)0x8e621b;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088daf0();
  auStack_dc[0] = in_stack_00000024;
  puStack_ec = (undefined *)0x8e6239;
  puVar3 = (undefined4 *)FUN_005c9ef0();
  puStack_14 = (undefined *)&uStack_1b8;
  uStack_8._0_1_ = 1;
  puStack_1b4 = (undefined4 *)0x0;
  uStack_1b8 = uVar2;
  puVar1 = &uStack_1b8;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(auStack_dc,auStack_1b0);
    puVar1 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar1;
  puStack_1b4 = puVar3;
  FUN_008c6ce0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 != (undefined4 *)0x0) {
    puStack_ec = auStack_dc;
    puStack_f0 = (undefined *)0x8e62a4;
    (*(code *)puVar3[2])();
  }
  uStack_8 = 3;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined *)0x2;
    uStack_f8 = 0x8e62cb;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15452 ; VA 0x008e62e0 ; FUN_008e62e0 */

void FUN_008e62e0(int param_1,int param_2,code *param_3,undefined4 param_4,undefined4 *param_5)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  uint uStack_5c;
  undefined auStack_54 [24];
  uint auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2248;
  pvStack_10 = ExceptionList;
  auStack_3c[0] = 0;
  puVar3 = (uint *)(param_2 + (-(uint)(param_1 != 0) & param_1 - 0xcU));
  uVar1 = *puVar3;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    auStack_3c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(puVar3 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = puVar3[2];
      uStack_30 = puVar3[3];
      uStack_2c = puVar3[4];
      uStack_28 = puVar3[5];
      uStack_24 = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  piVar4 = (int *)param_5[2];
  uStack_1c = *param_5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_5[2];
  }
  uStack_18 = param_5[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piStack_14 = piVar4;
  FUN_008dc570(uStack_1c,uStack_18,piVar4,0);
  iStack_8._0_1_ = 2;
  FUN_0090cd00(puVar3);
  iStack_8._0_1_ = 3;
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (code *)0x0) {
    (*param_3)(auStack_3c);
  }
  iStack_8 = 4;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15453 ; VA 0x008e6450 ; thunk_FUN_0090bea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0090bea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5546;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee093c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee093c);
    if (DAT_01ee093c == -1) {
      uStack_8 = 0;
      FUN_009ca470("GearType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee08d8 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearType>::vftable;
      FUN_009cafc0(&DAT_01d636a8,9,1,0);
      FUN_016f3654(&LAB_01883040);
      FUN_016f37bf();
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee08d8;
}



/* FUNCTION 15454 ; VA 0x008e6460 ; thunk_FUN_0090c030 */

undefined * thunk_FUN_0090c030(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c557c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0bd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0bd4);
    if (DAT_01ee0bd4 == -1) {
      uStack_8 = 0;
      FUN_00bc5af0();
      FUN_016f3654(&LAB_01883080);
      FUN_016f37bf(&DAT_01ee0bd4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0b70;
}



/* FUNCTION 15455 ; VA 0x008e6470 ; FUN_008e6470 */

undefined4 FUN_008e6470(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_008e65ed:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_008e65ed;
  }
  iVar2 = FUN_0090bea0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_008e6598;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_0090bea0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_008dcda0(&param_3);
      iVar4 = FUN_0090bea0();
      iStack_ec = iVar4;
      iVar5 = FUN_0090bea0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_008e6598:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_0090bea0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 15456 ; VA 0x008e6670 ; FUN_008e6670 */

undefined4 * __thiscall FUN_008e6670(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  return param_1;
}



/* FUNCTION 15457 ; VA 0x008e66d0 ; FUN_008e66d0 */

undefined4 * __thiscall FUN_008e66d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c227e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 1;
  uStack_7 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  _uStack_8 = CONCAT31(uStack_7,2);
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15458 ; VA 0x008e67f0 ; FUN_008e67f0 */

undefined4 * __thiscall FUN_008e67f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c22a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15459 ; VA 0x008e68f0 ; FUN_008e68f0 */

undefined4 * __thiscall FUN_008e68f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c22c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15460 ; VA 0x008e69f0 ; FUN_008e69f0 */

undefined4 * __thiscall FUN_008e69f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c22fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 1;
  uStack_7 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
    }
    else {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    }
  }
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8 = 2;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
    }
    else {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
    }
  }
  param_1[0x16] = param_2[0x16];
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_0054ef60(param_2 + 0x17);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15461 ; VA 0x008e6b20 ; FUN_008e6b20 */

undefined4 * __thiscall FUN_008e6b20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2331;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8._0_1_ = 1;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0x14);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15462 ; VA 0x008e6c20 ; FUN_008e6c20 */

undefined4 * __thiscall
FUN_008e6c20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c238b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::DataModel,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088daf0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15463 ; VA 0x008e6da0 ; FUN_008e6da0 */

undefined4 * __thiscall
FUN_008e6da0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c23eb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_008dcf60();
  FUN_009cb820(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::DataModel,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_RBX::ContentId),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cc80();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088d190();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_00630cf0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d190();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15464 ; VA 0x008e6f20 ; FUN_008e6f20 */

int __thiscall FUN_008e6f20(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  puStack_c = &LAB_017c2408;
  pvStack_10 = ExceptionList;
  iStack_28 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iStack_28 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
    UNLOCK();
    iStack_28 = param_2[1];
  }
  uStack_2c = *param_2;
  iStack_20 = param_2[3];
  if (iStack_20 != 0) {
    LOCK();
    *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
    UNLOCK();
    iStack_20 = param_2[3];
  }
  uStack_24 = param_2[2];
  uStack_1c = 0;
  uStack_18 = 0xffffffff;
  uStack_8 = 0;
  iStack_14 = param_1;
  FUN_008e7ef0(param_3,&uStack_2c,(int)&param_2 + 3);
  FUN_0056b650();
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x10) = *puVar2;
  *(undefined4 *)(param_1 + 0x14) = puVar2[1];
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = puVar2[2];
  *(undefined4 *)(param_1 + 0x1c) = puVar2[3];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15465 ; VA 0x008e7010 ; FUN_008e7010 */

undefined4 * __fastcall FUN_008e7010(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("CreatorType");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::CreatorType>::vftable;
  FUN_009caf20(&DAT_01d63614,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15466 ; VA 0x008e7070 ; FUN_008e7070 */

undefined4 * __fastcall FUN_008e7070(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("SaveFilter");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Instance::SaveFilter_DEPRECATED>::vftable;
  FUN_009caf20(&DAT_01d636f0,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15467 ; VA 0x008e70d0 ; FUN_008e70d0 */

undefined4 * __thiscall
FUN_008e70d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_008dcf60();
  FUN_009cb970(uVar1,param_3,param_4,param_5,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::DataModel,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::DataModel::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15468 ; VA 0x008e7190 ; FUN_008e7190 */

uint * __thiscall FUN_008e7190(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  return param_1;
}



/* FUNCTION 15469 ; VA 0x008e7230 ; FUN_008e7230 */

uint * __thiscall FUN_008e7230(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
      *(undefined *)(param_1 + 8) = *(undefined *)(param_2 + 8);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
  }
  *(undefined *)(param_1 + 8) = *(undefined *)(param_2 + 8);
  return param_1;
}



/* FUNCTION 15470 ; VA 0x008e72a0 ; FUN_008e72a0 */

undefined4 * __thiscall FUN_008e72a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 15471 ; VA 0x008e72f0 ; FUN_008e72f0 */

undefined4 * __thiscall FUN_008e72f0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[4] = 0;
  uVar1 = param_2[4];
  if (uVar1 != 0) {
    param_1[4] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[7];
      uVar3 = param_2[8];
      uVar4 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar2;
      param_1[8] = uVar3;
      param_1[9] = uVar4;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
  }
  return param_1;
}



/* FUNCTION 15472 ; VA 0x008e7360 ; FUN_008e7360 */

undefined4 * __thiscall
FUN_008e7360(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15473 ; VA 0x008e74b0 ; FUN_008e74b0 */

undefined4 * __thiscall FUN_008e74b0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 15474 ; VA 0x008e75a0 ; FUN_008e75a0 */

undefined4 * __thiscall FUN_008e75a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017c2428;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15475 ; VA 0x008e7650 ; FUN_008e7650 */

int __thiscall
FUN_008e7650(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11)

{
  int iVar1;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2468;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_5 != 0) {
    uStack_40 = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_38,0);
    }
    else {
      uStack_38 = param_7;
      uStack_34 = param_8;
      uStack_30 = param_9;
      uStack_2c = param_10;
      uStack_28 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_008e7b50(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 8) = 0;
  if (uStack_40 != 0) {
    *(uint *)(param_1 + 8) = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 0x10,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x10) = uStack_38;
      *(undefined4 *)(param_1 + 0x14) = uStack_34;
      *(undefined4 *)(param_1 + 0x18) = uStack_30;
      *(undefined4 *)(param_1 + 0x1c) = uStack_2c;
      *(undefined8 *)(param_1 + 0x20) = uStack_28;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = 6;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15476 ; VA 0x008e77d0 ; FUN_008e77d0 */

int __thiscall
FUN_008e77d0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined8 param_11)

{
  int iVar1;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c24a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_5 != 0) {
    uStack_40 = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_38,0);
    }
    else {
      uStack_38 = param_7;
      uStack_34 = param_8;
      uStack_30 = param_9;
      uStack_2c = param_10;
      uStack_28 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_008e7b50(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 8) = 0;
  if (uStack_40 != 0) {
    *(uint *)(param_1 + 8) = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 0x10,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x10) = uStack_38;
      *(undefined4 *)(param_1 + 0x14) = uStack_34;
      *(undefined4 *)(param_1 + 0x18) = uStack_30;
      *(undefined4 *)(param_1 + 0x1c) = uStack_2c;
      *(undefined8 *)(param_1 + 0x20) = uStack_28;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = 6;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15477 ; VA 0x008e7950 ; FUN_008e7950 */

uint * __thiscall FUN_008e7950(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c24c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_2[0xb];
      uVar2 = param_2[0xc];
      uVar3 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15478 ; VA 0x008e7a20 ; FUN_008e7a20 */

undefined4 __thiscall
FUN_008e7a20(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c24f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0x8e7a8c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_008e7bc0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x8e7b09;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x8e7b37;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15479 ; VA 0x008e7b50 ; FUN_008e7b50 */

undefined4 * __thiscall FUN_008e7b50(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 15480 ; VA 0x008e7bc0 ; FUN_008e7bc0 */

uint * __thiscall
FUN_008e7bc0(uint *param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            uint param_6,uint param_7,uint param_8,uint param_9,undefined8 param_10,uint param_11,
            undefined4 param_12,uint param_13,uint param_14,uint param_15,uint param_16,
            undefined8 param_17)

{
  uint uStack_38;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined8 uStack_20;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2530;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_30,0);
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  *param_1 = 0;
  if (uStack_38 != 0) {
    *param_1 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_30;
      param_1[3] = uStack_2c;
      param_1[4] = uStack_28;
      param_1[5] = uStack_24;
      *(undefined8 *)(param_1 + 6) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[8] = 0;
  if (param_11 != 0) {
    param_1[8] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 10,0);
    }
    else {
      param_1[10] = param_13;
      param_1[0xb] = param_14;
      param_1[0xc] = param_15;
      param_1[0xd] = param_16;
      *(undefined8 *)(param_1 + 0xe) = param_17;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 6;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15481 ; VA 0x008e7d50 ; FUN_008e7d50 */

undefined4 * __thiscall
FUN_008e7d50(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9)

{
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2558;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_3 != 0) {
    uStack_34 = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
    }
    else {
      uStack_2c = param_5;
      uStack_28 = param_6;
      uStack_24 = param_7;
      uStack_20 = param_8;
      uStack_1c = param_9;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  *param_1 = param_2;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_54 != 0) {
    param_1[2] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_4c;
      param_1[5] = uStack_48;
      param_1[6] = uStack_44;
      param_1[7] = uStack_40;
      *(undefined8 *)(param_1 + 8) = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15482 ; VA 0x008e7ef0 ; FUN_008e7ef0 */

uint * __thiscall FUN_008e7ef0(uint *param_1,uint param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = param_2 * 0x18;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar2 = uVar5 + 0x23;
      if (uVar2 <= uVar5) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar5;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = 0;
        puVar4[1] = 0;
        if (param_3[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_3[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar4 = *param_3;
        puVar4[1] = param_3[1];
        puVar4[2] = 0;
        puVar4[3] = 0;
        if (param_3[3] != 0) {
          LOCK();
          piVar1 = (int *)(param_3[3] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar4[2] = param_3[2];
        puVar4[3] = param_3[3];
        puVar4[4] = param_3[4];
        puVar4[5] = param_3[5];
        puVar4 = puVar4 + 6;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 15483 ; VA 0x008e8010 ; FUN_008e8010 */

undefined4 * __thiscall FUN_008e8010(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar5 = FUN_008ed8d0(param_2[1] - *param_2 >> 4);
  if (cVar5 != '\0') {
    puVar1 = (undefined4 *)param_2[1];
    puVar7 = (undefined4 *)*param_1;
    for (puVar6 = (undefined4 *)*param_2; puVar6 != puVar1; puVar6 = puVar6 + 4) {
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      *puVar7 = *puVar6;
      puVar7[1] = uVar2;
      puVar7[2] = uVar3;
      puVar7[3] = uVar4;
      puVar7 = puVar7 + 4;
    }
    param_1[1] = puVar7;
  }
  return param_1;
}



/* FUNCTION 15484 ; VA 0x008e8070 ; FUN_008e8070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008e8070(undefined4 *param_1,int *param_2,int param_3)

{
  undefined4 uVar1;
  int *piVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined **ppuVar9;
  undefined auStack_38 [8];
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c295a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::IMetric::vftable;
  param_1[1] = RBX::IDataState::vftable;
  LOCK();
  _DAT_01ee05b4 = _DAT_01ee05b4 + 1;
  UNLOCK();
  param_1[2] = RBX::TaskScheduler::Arbiter::vftable;
  puVar7 = param_1 + 3;
  uStack_8 = 2;
  uStack_7 = 0;
  puStack_1c = param_1;
  puStack_18 = puVar7;
  FUN_008a9310(&DAT_018c5f98);
  uStack_8 = 3;
  *puVar7 = RBX::Described<class_RBX::DataModel,class_RBX::ServiceProvider>::vftable;
  uVar4 = FUN_008dcf60();
  param_1[6] = uVar4;
  *param_1 = RBX::DataModel::vftable;
  param_1[1] = RBX::DataModel::vftable;
  param_1[2] = RBX::DataModel::vftable;
  *puVar7 = RBX::DataModel::vftable;
  uStack_20 = param_2;
  param_1[0x21] = param_2;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  *(undefined *)(param_1 + 0x34) = 0;
  param_1[0x35] = 0;
  uStack_8 = 0x18;
  FUN_016827a0(param_1 + 0x36);
  uVar3 = _PTR_018cf0f8;
  *(undefined *)(param_1 + 0x38) = 1;
  *(undefined8 *)(param_1 + 0x3a) = uVar3;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined *)(param_1 + 0x42) = 1;
  param_1[0x44] = 0;
  FUN_016827a0(param_1 + 0x46);
  uVar3 = _PTR_018cf0f8;
  *(undefined *)(param_1 + 0x48) = 1;
  *(undefined8 *)(param_1 + 0x4a) = uVar3;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  *(undefined *)(param_1 + 0x52) = 1;
  *(undefined8 *)(param_1 + 0x50) = 0;
  param_1[0x54] = 0;
  param_1[0x56] = 6;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = &DAT_01d6da40;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  FUN_016830f0(param_1 + 0x5e);
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  uStack_8 = 0x21;
  param_2 = (int *)FUN_01674e20(0x38);
  uStack_8 = 0x22;
  if (param_2 == (int *)0x0) {
    uStack_24 = 0;
  }
  else {
    uStack_24 = FUN_00995130(0);
  }
  param_1[0x72] = uStack_24;
  *(undefined *)(param_1 + 0x73) = 1;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  *(undefined *)(param_1 + 0x77) = 0;
  *(undefined2 *)((int)param_1 + 0x1dd) = 0;
  *(undefined *)((int)param_1 + 0x1df) = 0;
  FUN_016dee4c(param_1 + 0x78,2);
  *(undefined *)(param_1 + 0x84) = 0;
  param_2 = (int *)0xb;
  ppuVar5 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar9 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar5;
  }
  param_1[0x85] = *ppuVar9;
  param_1[0x86] = 0;
  param_1[0x87] = 0x3f800000;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  uStack_8 = 0x25;
  iStack_28 = FUN_01674e20(0x70);
  uStack_8 = 0x26;
  if (iStack_28 == 0) {
    iStack_28 = 0;
  }
  else {
    iStack_28 = FUN_00cc2310();
  }
  param_1[0x8a] = iStack_28;
  uStack_8 = 0x27;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  *(undefined2 *)(param_1 + 0x90) = 0;
  *(undefined *)((int)param_1 + 0x242) = 0;
  param_1[0x91] = 0;
  param_1[0x92] = 0;
  *(undefined *)(param_1 + 0x93) = 0;
  param_1[0x94] = 0;
  FUN_016830f0(param_1 + 0x96);
  param_1[0x98] = 0;
  param_1[0x99] = 0;
  *(undefined *)(param_1 + 0x9a) = 0;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0;
  *(undefined *)(param_1 + 0x9e) = 0;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  param_1[0xa1] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0xf;
  *(undefined *)(param_1 + 0xa2) = 0;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  param_1[0xab] = 0;
  param_1[0xac] = 0;
  param_1[0xad] = 0;
  param_1[0xae] = 0;
  param_1[0xaf] = 0;
  param_1[0xb0] = 0;
  *(undefined *)(param_1 + 0xb1) = 0;
  param_1[0xb2] = 0;
  param_1[0xb3] = 0;
  *(undefined *)(param_1 + 0xb4) = 0;
  param_1[0xb6] = 0;
  param_1[0xbe] = 0;
  *(undefined *)(param_1 + 0xbf) = 0;
  *(undefined8 *)(param_1 + 0xc0) = 0;
  param_1[0xca] = 0;
  param_1[0xcb] = 0xf;
  *(undefined *)(param_1 + 0xc6) = 0;
  puVar7 = param_1 + 0xcc;
  uStack_8 = 0x34;
  *puVar7 = 0;
  param_1[0xcd] = 0;
  param_2 = puVar7;
  uVar4 = FUN_00575b10();
  *puVar7 = uVar4;
  *(undefined *)(param_1 + 0xcf) = 0;
  param_1[0xd0] = 0;
  puVar7 = param_1 + 0xd2;
  uStack_8 = 0x36;
  param_1[0xd6] = 0;
  param_1[0xd7] = 0xf;
  *(undefined *)puVar7 = 0;
  param_2 = puVar7;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0x37;
  FUN_009cbbb0(puVar7);
  FUN_016dee4c(param_1 + 0xd8,2);
  uStack_8 = 0x3a;
  FUN_016f4053(param_1 + 0xe4,8,0xb,FUN_005502b0,FUN_00550b30);
  FUN_016dee4c(param_1 + 0xfa,2);
  puVar7 = param_1 + 0x106;
  uStack_8 = 0x3c;
  *puVar7 = 0;
  param_1[0x107] = 0;
  param_2 = puVar7;
  uVar4 = FUN_00575b10();
  *puVar7 = uVar4;
  *(undefined *)(param_1 + 0x108) = 0;
  param_1[0x10d] = 0;
  param_1[0x10e] = 0xf;
  *(undefined *)(param_1 + 0x109) = 0;
  uStack_8 = 0x3e;
  param_2 = (int *)FUN_01674e20(8);
  if (param_2 == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    *param_2 = (int)param_2;
    *(int **)((int)param_2 + 4) = param_2;
    iVar6 = (int)param_2;
  }
  param_1[0x10f] = iVar6;
  uStack_8 = 0x3f;
  param_1[0x110] = 0;
  param_1[0x111] = 0;
  *(undefined2 *)(param_1 + 0x112) = 0;
  param_1[0x113] = 0xffffffff;
  param_1[0x114] = 0;
  param_2 = (int *)FUN_01674e20(8);
  if (param_2 == (int *)0x0) {
    iVar6 = 0;
  }
  else {
    *param_2 = (int)param_2;
    *(int **)((int)param_2 + 4) = param_2;
    iVar6 = (int)param_2;
  }
  param_1[0x115] = iVar6;
  param_1[0x116] = 0;
  param_1[0x11e] = 0;
  param_1[0x11f] = 0xf;
  uStack_8 = 0x40;
  *(undefined *)(param_1 + 0x11a) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0x41;
  param_1[0x120] = 0;
  param_1[0x121] = 0;
  uVar4 = FUN_01674e20(0x10);
  param_1[0x122] = uVar4;
  uStack_8 = 0x42;
  param_2 = param_1 + 0x123;
  param_2 = (int *)FUN_01674e20(0x18);
  uStack_8 = 0x43;
  if (param_2 == (int *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00b9ec80();
  }
  param_1[0x123] = uVar4;
  puVar7 = param_1 + 0x124;
  uStack_8 = 0x44;
  *puVar7 = 0;
  param_1[0x125] = 0;
  param_2 = puVar7;
  uVar4 = FUN_008ed990(0,0);
  *puVar7 = uVar4;
  param_1[0x126] = 0;
  *(undefined2 *)(param_1 + 0x127) = 0;
  param_1[0x128] = param_3;
  *(undefined *)(param_1 + 0x129) = 0;
  param_1[0x12a] = 0xffffffff;
  param_1[0x12f] = 0;
  param_1[0x130] = 0xf;
  *(undefined *)(param_1 + 299) = 0;
  param_1[0x131] = &DAT_bf800000;
  param_1[0x132] = 0xffffffff;
  param_1[0x133] = 0;
  param_1[0x134] = 0;
  *(undefined *)(param_1 + 0x135) = 0;
  uStack_14 = 0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar9 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar5;
  }
  param_1[0x136] = *ppuVar9;
  param_1[0x137] = 0;
  param_1[0x138] = 0x3f800000;
  param_1[0x139] = 0;
  param_1[0x13a] = 0;
  _uStack_8 = CONCAT31(uStack_7,0x48);
  param_1[0x13b] = 0;
  param_1[0x13c] = 0;
  puStack_18 = param_1;
  puVar7 = (undefined4 *)FUN_008e3810(auStack_30,&puStack_18);
  uVar4 = *puVar7;
  uVar1 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  param_1[0x6e] = uVar4;
  piVar8 = (int *)param_1[0x6f];
  param_1[0x6f] = uVar1;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar6 = piVar8[1] + -1;
    piVar8[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar6 = piVar8[2] + -1;
      piVar8[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if ((param_1[0x128] == 2) || (param_1[0x128] == 3)) {
    *(undefined4 *)(*(int *)(param_1[0x6e] + 0x1b4) + 0x6f4) = 1;
  }
  piVar8 = (int *)FUN_01674e20(0x58);
  uStack_8 = 0x49;
  param_2 = piVar8;
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)0x0;
  }
  else {
    piVar8[1] = 1;
    piVar8[2] = 1;
    *piVar8 = (int)std::_Ref_count_obj<class_RBX::GuiRoot>::vftable;
    FUN_00f590d0();
  }
  _uStack_8 = CONCAT31(uStack_7,0x48);
  if ((piVar8 + 3 != (int *)0x0) && ((piVar8[5] == 0 || (*(int *)(piVar8[5] + 4) == 0)))) {
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[2] = piVar8[2] + 1;
        UNLOCK();
      }
    }
    piVar8[4] = (int)(piVar8 + 3);
    piVar2 = (int *)piVar8[5];
    piVar8[5] = (int)piVar8;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar6 = piVar8[1] + -1;
      piVar8[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar6 = piVar8[2] + -1;
        piVar8[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  param_1[0x70] = piVar8 + 3;
  piVar2 = (int *)param_1[0x71];
  param_1[0x71] = piVar8;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar8 = piVar2 + 2;
      iVar6 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *(undefined4 **)(param_1[0x70] + 0x48) = param_1;
  FUN_0151dd90(DAT_01d633d0);
  LOCK();
  _DAT_01ee05b0 = _DAT_01ee05b0 + 1;
  UNLOCK();
  *(undefined *)((int)param_1 + 0x2e) = 1;
  FUN_008ddf00(2,param_1 + 0x9b);
  FUN_00f5be80(param_1);
  param_1[0xc2] = 0xc0400000;
  puVar7 = (undefined4 *)FUN_016830f0(auStack_38);
  param_1[0xc0] = *puVar7;
  param_1[0xc1] = puVar7[1];
  param_1[0xc3] = 0xc0400000;
  param_1[0xc4] = 0xc0400000;
  param_1[0xc5] = 0xfffffffd;
  FUN_005542c0(&DAT_018bc9b8,0);
  puVar7 = (undefined4 *)FUN_00bbddc0();
  if (param_3 == 1) {
    *puVar7 = 3;
  }
  else if (param_3 == 2) {
    *puVar7 = 4;
    puVar7[1] = 1;
  }
  else {
    *puVar7 = 0;
  }
  uVar4 = FUN_008fba50(&DAT_01d6d1f4);
  param_1[0xce] = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15485 ; VA 0x008e8b60 ; FUN_008e8b60 */

undefined4 * __thiscall
FUN_008e8b60(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c298e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00a360a0(param_4,param_5,0,param_2,param_3,0xb);
  *param_1 = RBX::DataModel::GenericJob::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4a] = param_2;
  param_1[0x4b] = param_3;
  puVar2 = param_1 + 0x4c;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *puVar2 = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  *puVar2 = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined4 **)*puVar2 = puVar2;
  param_1[0x51] = 0;
  *(undefined *)(param_1 + 0x46) = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15486 ; VA 0x008e8ca0 ; FUN_008e8ca0 */

uint * __thiscall FUN_008e8ca0(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c29a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uVar1 = param_2[8];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar1 = param_2[0xb];
      uVar2 = param_2[0xc];
      uVar3 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  *(undefined *)(param_1 + 0x10) = *(undefined *)(param_2 + 0x10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15487 ; VA 0x008e8d60 ; FUN_008e8d60 */

undefined4 * __thiscall FUN_008e8d60(undefined4 *param_1,uint param_2)

{
  uint in_stack_00000024;
  undefined in_stack_00000044;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c29d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_005880d0(&param_2);
  uStack_8._0_1_ = 2;
  param_1[8] = 0;
  FUN_005880d0(&stack0x00000024);
  *(undefined *)(param_1 + 0x10) = in_stack_00000044;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_2 != 0) {
    if (((param_2 & 1) == 0) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
    }
    param_2 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15488 ; VA 0x008e8e20 ; FUN_008e8e20 */

undefined4 * __thiscall FUN_008e8e20(undefined4 *param_1,undefined *param_2,int *param_3)

{
  undefined *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  uint uVar10;
  undefined **ppuVar11;
  undefined4 auStack_10c [2];
  undefined auStack_104 [8];
  undefined4 uStack_fc;
  int iStack_f8;
  int *piStack_f4;
  undefined *puStack_f0;
  undefined **ppuStack_ec;
  undefined auStack_e4 [8];
  undefined4 uStack_dc;
  uint uStack_d8;
  char *pcStack_d4;
  char *pcStack_d0;
  int *piStack_cc;
  undefined auStack_74 [12];
  undefined auStack_68 [12];
  int iStack_5c;
  int *piStack_58;
  undefined *puStack_54;
  int *piStack_50;
  int iStack_4c;
  int iStack_48;
  undefined *puStack_44;
  undefined4 uStack_40;
  int *piStack_38;
  undefined *puStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2a57;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[2] = param_3;
  piStack_14 = param_1 + 4;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  *piStack_14 = 0;
  param_1[5] = 0;
  piStack_38 = param_1 + 6;
  uStack_40 = 0;
  *piStack_38 = 0;
  puVar1 = param_2 + 0x360;
  uStack_8 = 1;
  pcStack_d0 = (char *)0x8e8e95;
  piStack_cc = (int *)puVar1;
  puStack_44 = puVar1;
  puStack_20 = param_1;
  piStack_cc = (int *)FUN_016dee6d();
  if (piStack_cc != (int *)0x0) {
    pcStack_d0 = (char *)0x8e8ea2;
    FUN_016df3c9();
  }
  piStack_50 = *(int **)(param_2 + 0x39c);
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = *(int **)(param_2 + 0x39c);
  }
  puStack_54 = *(undefined **)(param_2 + 0x398);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piStack_1c = piStack_50;
  puStack_18 = puStack_54;
  if (puStack_54 == (undefined *)0x0) {
    piStack_cc = (int *)0x192b2a8;
    pcStack_d0 = (char *)0x8e943f;
    FUN_00550130();
    piStack_cc = (int *)&DAT_01c17198;
    pcStack_d0 = auStack_68;
                    /* WARNING: Subroutine does not return */
    pcStack_d4 = (char *)0x8e944d;
    FUN_0170c2a8();
  }
  piStack_cc = (int *)&LAB_0090a080;
  pcStack_d0 = &DAT_01ee05f4;
  pcStack_d4 = (char *)0x8e8ee9;
  FUN_005789c0();
  pcStack_d4 = (char *)0x8e8eee;
  pcStack_d4 = (char *)FUN_00909ee0();
  uStack_d8 = 0x8e8ef4;
  puVar3 = (undefined4 *)FUN_01689e40();
  if (puVar3 == (undefined4 *)0x0) {
    puVar4 = (undefined *)0x0;
  }
  else {
    puVar4 = (undefined *)*puVar3;
  }
  param_1[3] = puVar4;
  if (puStack_18 == puVar4) {
    if (DAT_01ee4202 != 0) {
      piStack_cc = (int *)0x1;
      pcStack_d0 = param_2;
      uStack_d8 = (uint)DAT_01ee4202;
      pcStack_d4 = "LegacyLock::RecursivelyAcquired DataModel: (%p), type(%d)";
      uStack_dc = 0x8e92e0;
      FUN_01677520();
    }
  }
  else {
    if (DAT_01ee4202 != 0) {
      piStack_cc = (int *)0x1;
      pcStack_d0 = param_2;
      uStack_d8 = (uint)DAT_01ee4202;
      pcStack_d4 = "LegacyLock::Begin, DataModel: (%p), type(%d)";
      uStack_dc = 0x8e8f2a;
      FUN_01677520();
    }
    piStack_cc = (int *)&LAB_0090a080;
    pcStack_d0 = &DAT_01ee05f4;
    pcStack_d4 = (char *)0x8e8f3c;
    FUN_005789c0();
    piStack_cc = (int *)0x8e8f44;
    FUN_00909ee0();
    piStack_cc = (int *)puStack_18;
    pcStack_d0 = (char *)0x8e8f4e;
    FUN_00909060();
    piStack_cc = (int *)&LAB_0090a090;
    pcStack_d0 = &DAT_01ee05e0;
    pcStack_d4 = (char *)0x8e8f5d;
    FUN_005789c0();
    piStack_cc = (int *)0x8e8f65;
    FUN_00909f90();
    piStack_cc = piStack_14;
    pcStack_d0 = (char *)0x8e8f6f;
    cVar2 = FUN_00902a30();
    if (cVar2 == '\0') {
      piStack_cc = (int *)0xc;
      pcStack_d0 = (char *)0x8e8f7e;
      iVar5 = FUN_01674e20();
      uStack_8._0_1_ = 4;
      if (iVar5 == 0) {
        iVar5 = 0;
      }
      else {
        piStack_cc = (int *)0x0;
        pcStack_d0 = (char *)0x8e8f97;
        FUN_0151f360();
        uStack_8._0_1_ = 5;
        piStack_cc = (int *)0x0;
        pcStack_d0 = (char *)0x8e8fa5;
        FUN_0151f360();
        *(undefined *)(iVar5 + 8) = 0;
      }
      piStack_cc = (int *)param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      iStack_2c = 0;
      piStack_28 = (int *)0x0;
      pcStack_d4 = (char *)0x8e8fcb;
      pcStack_d0 = (char *)iVar5;
      FUN_008de140();
      iStack_48 = iStack_2c;
      iVar5 = *piStack_14;
      *piStack_14 = iStack_2c;
      piVar9 = (int *)piStack_14[1];
      iStack_4c = (int)piStack_28;
      piStack_14[1] = (int)piStack_28;
      iStack_2c = iVar5;
      piStack_28 = piVar9;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar5 = piVar9[1] + -1;
        piVar9[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          piStack_cc = (int *)0x8e8ffd;
          (**(code **)*piVar9)();
          LOCK();
          iVar5 = piVar9[2] + -1;
          piVar9[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            piStack_cc = (int *)0x8e900d;
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    piVar9 = (int *)piStack_14[1];
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
      piVar9 = (int *)piStack_14[1];
    }
    iStack_f8 = *piStack_14;
    piVar6 = piVar9 + 1;
    puStack_34 = puStack_18 + 0x130;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    piStack_cc = (int *)0x1;
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    ppuStack_ec = (undefined **)0x0;
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    puStack_f0 = auStack_e4;
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    ppuVar11 = &PTR_FUN_0192d360;
    uStack_fc = 0x8e908a;
    piStack_f4 = piVar9;
    iStack_5c = iStack_f8;
    piStack_58 = piVar9;
    iStack_30 = iStack_f8;
    cVar2 = FUN_0055c750();
    if (cVar2 == '\0') {
      ppuVar11 = (undefined **)0x0;
    }
    ppuStack_ec = ppuVar11;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar5 = piVar9[1] + -1;
      piVar9[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_f0 = (undefined *)0x8e90ae;
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          puStack_f0 = (undefined *)0x8e90be;
          (**(code **)(*piVar9 + 4))();
        }
      }
      LOCK();
      iVar5 = piVar9[1] + -1;
      piVar9[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_f0 = (undefined *)0x8e90cf;
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          puStack_f0 = (undefined *)0x8e90df;
          (**(code **)(*piVar9 + 4))();
        }
      }
      LOCK();
      iVar5 = piVar9[1] + -1;
      piVar9[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        puStack_f0 = (undefined *)0x8e90f0;
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          puStack_f0 = (undefined *)0x8e9100;
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    piVar6 = piVar9 + 1;
    puStack_24 = auStack_10c;
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    auStack_10c[0] = 0;
    if (piVar9 == (int *)0x0) {
      param_3 = (int *)&DAT_00000004;
    }
    else {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      param_3 = piVar6;
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      param_3 = piVar6;
    }
    cVar2 = FUN_0055c750(iStack_30,piVar9,auStack_104);
    if (cVar2 == '\0') {
      *puStack_24 = 0;
    }
    else {
      *puStack_24 = &PTR_FUN_0192d358;
    }
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar5 = *param_3;
      *param_3 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
      LOCK();
      iVar5 = *param_3;
      *param_3 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
      LOCK();
      iVar5 = *param_3;
      *param_3 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    piStack_cc = (int *)FUN_008e8d60();
    uStack_8._0_1_ = 7;
    pcStack_d0 = (char *)0x8e91f9;
    FUN_00907ca0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    piStack_cc = (int *)0x8e9208;
    FUN_008c3510();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    pcStack_d0 = puStack_18;
    piStack_cc = piStack_1c;
    pcStack_d4 = (char *)0x8e9232;
    FUN_0151dbc0();
    *(undefined *)(puStack_20 + 1) = 1;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar5 = *param_3;
      *param_3 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        piStack_cc = (int *)0x8e9251;
        (**(code **)*piVar9)();
        LOCK();
        iVar5 = piVar9[2] + -1;
        piVar9[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          piStack_cc = (int *)0x8e9261;
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_cc = (int *)0x8e9278;
      (**(code **)*piStack_1c)();
      LOCK();
      piVar9 = piStack_1c + 2;
      iVar5 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_cc = (int *)0x8e9288;
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  pcStack_d0 = (char *)0x8e9292;
  piStack_cc = (int *)puVar1;
  piStack_cc = (int *)FUN_016deec8();
  if (piStack_cc != (int *)0x0) {
    pcStack_d0 = (char *)0x8e929f;
    FUN_016df3c9();
  }
  piVar9 = piStack_14;
  uStack_8._0_1_ = 1;
  if (*(char *)(puStack_20 + 1) == '\0') {
    ExceptionList = pvStack_10;
    return puStack_20;
  }
  piStack_cc = (int *)0x8e92bd;
  FUN_0151f430();
  if (*(char *)(*piVar9 + 8) != '\0') {
    piStack_cc = (int *)0x8e9452;
    FUN_008f4a90();
    piStack_cc = piVar9;
    pcStack_d0 = (char *)0x8e945a;
    FUN_00907bb0();
    piStack_cc = (int *)0x192b33c;
    pcStack_d0 = (char *)0x8e9467;
    FUN_00550130();
    piStack_cc = (int *)&DAT_01c17198;
    pcStack_d0 = auStack_74;
                    /* WARNING: Subroutine does not return */
    pcStack_d4 = &UNK_008e9475;
    FUN_0170c2a8();
  }
  piStack_cc = (int *)0x8;
  pcStack_d0 = (char *)0x8e92ef;
  piVar6 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 9;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)0x0;
    goto LAB_008e93e9;
  }
  uVar10 = -(uint)(param_2 != (undefined *)0x0) & (uint)(param_2 + 0xc);
  if (uVar10 == 0) {
LAB_008e9348:
    iVar5 = 0;
  }
  else {
    if (*(int *)(uVar10 + 0x34) != 0) {
      piStack_cc = (int *)0x8e931a;
      uVar10 = FUN_005c8ac0();
    }
    if (uVar10 == 0) goto LAB_008e9348;
    iVar5 = *(int *)(uVar10 + 0xc);
    piStack_cc = (int *)0x8e9328;
    iVar7 = FUN_008dcf60();
    if ((uint)*(ushort *)(iVar7 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) goto LAB_008e9348;
    iVar5 = uVar10 - 0xc;
  }
  *piVar6 = iVar5;
  piVar6[1] = 0;
  piVar9 = piStack_14;
  if (iVar5 != 0) {
    pcStack_d0 = (char *)0x8e9369;
    piStack_cc = (int *)(iVar5 + 1000);
    piStack_cc = (int *)FUN_016dee6d();
    if (piStack_cc != (int *)0x0) {
      pcStack_d0 = (char *)0x8e9376;
      FUN_016df3c9();
    }
    uStack_8._0_1_ = 10;
    if ((DAT_01d635a4 != '\0') &&
       ((*(int *)(*piVar6 + 0x2a0) != 1 || (*(int *)(*piVar6 + 0x2a8) == 0)))) {
      piStack_cc = (int *)&DAT_018bc9b8;
      pcStack_d0 = "InvalidAccess";
      pcStack_d4 = (char *)0x8e93ab;
      FUN_01675310();
    }
    piVar6[1] = *(int *)(*piVar6 + 0x2a8);
    piStack_cc = (int *)0x8e93be;
    uVar8 = GetCurrentThreadId();
    *(undefined4 *)(*piVar6 + 0x2a8) = uVar8;
    uStack_8._0_1_ = 0xb;
    pcStack_d0 = (char *)0x8e93d2;
    piStack_cc = (int *)(iVar5 + 1000);
    piStack_cc = (int *)FUN_016deec8();
    piVar9 = piStack_14;
    if (piStack_cc != (int *)0x0) {
      pcStack_d0 = (char *)0x8e93df;
      FUN_016df3c9();
      piVar9 = piStack_14;
    }
  }
LAB_008e93e9:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_cc = (int *)*piStack_38;
  *piStack_38 = (int)piVar6;
  if (piStack_cc != (int *)0x0) {
    pcStack_d0 = (char *)0x8e93fe;
    FUN_008ec400();
  }
  if (DAT_01ee4202 != 0) {
    piStack_cc = (int *)*piVar9;
    uStack_d8 = (uint)DAT_01ee4202;
    pcStack_d0 = (char *)0x1;
    pcStack_d4 = "LegacyLock::Acquired type(%d), events (%p)";
    uStack_dc = 0x8e9419;
    FUN_01677520();
  }
  ExceptionList = pvStack_10;
  return puStack_20;
}



/* FUNCTION 15489 ; VA 0x008e9480 ; FUN_008e9480 */

undefined4 * __thiscall FUN_008e9480(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2a7f;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    *param_1 = 0;
    return param_1;
  }
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x1c);
  uStack_8 = 0;
  if (iVar1 != 0) {
    uVar2 = FUN_008e8e20(param_2,param_3);
    *param_1 = uVar2;
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15490 ; VA 0x008e9510 ; FUN_008e9510 */

undefined4 * __thiscall
FUN_008e9510(undefined4 *param_1,int param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c2aa7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(0x1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar2 != 0) {
      uVar3 = FUN_008e8e20(param_2,param_4);
      goto LAB_008e9563;
    }
  }
  uVar3 = 0;
LAB_008e9563:
  *param_1 = uVar3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15491 ; VA 0x008e95c0 ; FUN_008e95c0 */

undefined4 * __fastcall FUN_008e95c0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2bb1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::PhysicsService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00c9aa70();
  param_1[3] = uVar1;
  uStack_8 = 1;
  FUN_00f45140();
  *param_1 = RBX::PhysicsService::vftable;
  param_1[0x16] = RBX::PhysicsService::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  *(undefined *)(param_1 + 0x1a) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x1b] = *ppuVar3;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0x3f800000;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  *(undefined *)(param_1 + 0x20) = 0;
  uStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  param_1[0x21] = *ppuVar3;
  param_1[0x22] = 0;
  param_1[0x23] = 0x3f800000;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8._0_1_ = 6;
  FUN_008e6f20(&uStack_28,0);
  FUN_0056b650();
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8._0_1_ = 9;
  FUN_008e6f20(&uStack_28,0);
  FUN_0056b650();
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 1;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  uStack_8._0_1_ = 0x14;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("PhysicsService",0xe);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15492 ; VA 0x008e9840 ; FUN_008e9840 */

int * __thiscall FUN_008e9840(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2bc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_2 + 0x34) != 0) {
      ExceptionList = &pvStack_10;
      param_2 = FUN_005c8ac0();
    }
    if ((param_2 != 0) &&
       (iVar2 = *(int *)(param_2 + 0xc), iVar1 = FUN_008dcf60(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      param_2 = param_2 + -0xc;
      goto LAB_008e98a0;
    }
  }
  param_2 = 0;
LAB_008e98a0:
  *param_1 = param_2;
  if (param_2 != 0) {
    iVar2 = FUN_016dee6d(param_2 + 1000);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    uStack_8 = 0;
    if ((DAT_01d635a4 != '\0') &&
       (((*(int *)(*param_1 + 0x2a0) != 0 || (*(int *)(*param_1 + 0x2a4) != 0)) ||
        (*(int *)(*param_1 + 0x2a8) != 0)))) {
      FUN_01675310("InvalidAccess",&DAT_018bc9b8);
    }
    *(undefined4 *)(*param_1 + 0x2a0) = 1;
    uVar3 = GetCurrentThreadId();
    *(undefined4 *)(*param_1 + 0x2a8) = uVar3;
    uStack_8 = 1;
    iVar2 = FUN_016deec8(param_2 + 1000);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15493 ; VA 0x008e9960 ; FUN_008e9960 */

int * __thiscall FUN_008e9960(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2bc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_2 + 0x34) != 0) {
      ExceptionList = &pvStack_10;
      param_2 = FUN_005c8ac0();
    }
    if (param_2 != 0) {
      iVar2 = *(int *)(param_2 + 0xc);
      iVar1 = FUN_008dcf60();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        param_2 = param_2 + -0xc;
        goto LAB_008e99c0;
      }
    }
  }
  param_2 = 0;
LAB_008e99c0:
  *param_1 = param_2;
  param_1[1] = 0;
  if (param_2 != 0) {
    iVar2 = FUN_016dee6d(param_2 + 1000);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    uStack_8 = 0;
    if ((DAT_01d635a4 != '\0') &&
       ((*(int *)(*param_1 + 0x2a0) != 1 || (*(int *)(*param_1 + 0x2a8) == 0)))) {
      FUN_01675310("InvalidAccess",&DAT_018bc9b8);
    }
    param_1[1] = *(int *)(*param_1 + 0x2a8);
    uVar3 = GetCurrentThreadId();
    *(undefined4 *)(*param_1 + 0x2a8) = uVar3;
    uStack_8 = 1;
    iVar2 = FUN_016deec8(param_2 + 1000);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15494 ; VA 0x008e9a80 ; FUN_008e9a80 */

void __fastcall FUN_008e9a80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x008e9aaf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 15495 ; VA 0x008e9ac0 ; FUN_008e9ac0 */

code * __fastcall FUN_008e9ac0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar4 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar4 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar4 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 15496 ; VA 0x008e9ba0 ; FUN_008e9ba0 */

code * __fastcall FUN_008e9ba0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  pcVar4 = *(code **)(param_1 + 8);
  uStack_8 = 1;
  if (pcVar4 != (code *)0x0) {
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      if (pcVar4 != (code *)0x0) {
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 15497 ; VA 0x008e9c40 ; FUN_008e9c40 */

int __fastcall FUN_008e9c40(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_008e9ba0();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x008e9c5f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 15498 ; VA 0x008e9c70 ; FUN_008e9c70 */

code * __fastcall FUN_008e9c70(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  code *pcVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x70);
  ExceptionList = &pvStack_10;
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x5c);
    uVar8 = uVar3 + 1;
    iVar6 = iVar4;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar6) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar6,uVar8);
  }
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  uVar3 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  pcVar7 = *(code **)(param_1 + 0x18);
  uStack_8 = 1;
  if (pcVar7 != (code *)0x0) {
    if (((uint)pcVar7 & 1) == 0) {
      pcVar7 = *(code **)((uint)pcVar7 & 0xfffffffe);
      if (pcVar7 != (code *)0x0) {
        pcVar7 = (code *)(*pcVar7)(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  piVar5 = *(int **)(param_1 + 0x10);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar7 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar7 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar7 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 8);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar7 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar7 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar7 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar7;
}



/* FUNCTION 15499 ; VA 0x008e9da0 ; FUN_008e9da0 */

code * __fastcall FUN_008e9da0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  code *pcVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 100);
  ExceptionList = &pvStack_10;
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x50);
    uVar7 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar7 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar5,uVar7);
  }
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0xf;
  *(undefined *)(param_1 + 0x50) = 0;
  uVar2 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 1;
  if (pcVar6 != (code *)0x0) {
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      if (pcVar6 != (code *)0x0) {
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar4 = *(int **)(param_1 + 8);
  if (piVar4 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar4 + 2);
    uVar2 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar6 = (code *)(**(code **)(*piVar4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}


