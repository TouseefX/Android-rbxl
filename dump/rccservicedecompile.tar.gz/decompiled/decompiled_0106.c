/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 26500 ; VA 0x00bdcc50 ; FUN_00bdcc50 */

void FUN_00bdcc50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00bd6ff0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar2,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1df5274);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LogService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LogService>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26501 ; VA 0x00bdcda0 ; FUN_00bdcda0 */

void FUN_00bdcda0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      FUN_00bd7070(param_1);
      if (param_3 != 1) {
        return;
      }
      piVar2 = *(int **)(param_1 + 0x10);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = *(int **)(param_1 + 8);
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00bdce5a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar2 = (int *)param_2[4];
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      piVar2 = (int *)param_2[2];
      if (piVar2 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00bdcdf7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df5394);
      iVar4 = 0;
      if (iVar3 == 0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LogService>,class_std::weak_ptr<class_RBX::Player>),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LogService>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::Player>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 26502 ; VA 0x00bdce70 ; FUN_00bdce70 */

int * FUN_00bdce70(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined uStack_11c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 *puStack_44;
  int iStack_40;
  int *piStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801099;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&piStack_24);
  piVar9 = piStack_20;
  uStack_8._0_1_ = 2;
  piVar3 = piStack_24;
  if ((piStack_24 != (int *)0x0) &&
     (piVar3 = (int *)FUN_0098c5a0(piStack_24,1), (char)piVar3 != '\0')) {
    piVar3 = (int *)FUN_00562c90(&iStack_40,&param_3);
    piVar1 = piStack_24;
    uStack_8._0_1_ = 3;
    if (iStack_40 != 0) {
      FUN_00bde1d0(&DAT_01d67eb4);
      uStack_1c = FUN_00928340();
      iVar4 = FUN_005e9db0(&uStack_1c);
      puStack_34 = (undefined4 *)piVar1[0x44];
      iStack_28 = piVar1[0x46];
      puStack_2c = *(undefined4 **)(iStack_28 + iVar4 * 8);
      iStack_30 = iVar4 * 8 + 4;
      puVar5 = puStack_2c;
      while( true ) {
        puVar6 = puStack_34;
        if (puStack_2c != puStack_34) {
          puVar6 = (undefined4 *)**(undefined4 **)(iStack_30 + iStack_28);
        }
        if (puVar5 == puVar6) goto LAB_00bdcfb0;
        if ((puVar5[2] == (int)uStack_1c) && (puVar6 = puVar5, puVar5[3] == uStack_1c._4_4_)) break;
        puVar5 = (undefined4 *)*puVar5;
      }
      while( true ) {
        puVar8 = puStack_34;
        if (puStack_2c != puStack_34) {
          puVar8 = (undefined4 *)**(undefined4 **)(iStack_30 + iStack_28);
        }
        if (((puVar6 == puVar8) || ((int)uStack_1c != puVar6[2])) || (uStack_1c._4_4_ != puVar6[3]))
        break;
        puVar6 = (undefined4 *)*puVar6;
      }
      piVar9 = piStack_20;
      puStack_44 = puVar5;
      puStack_38 = puVar5;
      if (puVar5 == puVar6) {
LAB_00bdcfb0:
        puVar6 = puStack_34;
        puVar5 = puStack_34;
      }
      iVar4 = 0;
      for (; puVar5 != puVar6; puVar5 = (undefined4 *)*puVar5) {
        iVar4 = iVar4 + 1;
      }
      uStack_11 = iVar4 != 0;
      uVar7 = FUN_00927d30(&puStack_38);
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      piStack_48 = piStack_24;
      uStack_1c._4_4_ = 0;
      uStack_8._0_1_ = 4;
      pcVar2 = *(code **)(*piStack_24 + 8);
      uStack_1c._0_4_ = uVar7;
      uStack_124 = FUN_0088daf0();
      uStack_120 = 0;
      uStack_11c = uStack_11;
      uStack_120 = FUN_005c9ef0();
      uStack_8._0_1_ = 5;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_4c = 0;
      FUN_00687980(&uStack_124,&uStack_54,param_2);
      uStack_8._0_1_ = 6;
      (*pcVar2)(&DAT_02132838,&uStack_54,&uStack_1c);
      uStack_8._0_1_ = 7;
      FUN_00577b20();
      uStack_8._0_1_ = 4;
      piVar3 = (int *)FUN_016f32d1(&uStack_124,0xd0,1,FUN_0056e5b0);
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar1 = piVar9 + 1;
        iVar4 = *piVar1;
        piVar3 = (int *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            piVar3 = (int *)(**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_3c + 1;
      iVar4 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar1 = piStack_3c + 2;
        iVar4 = *piVar1;
        piVar3 = (int *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          piVar3 = (int *)(**(code **)(*piStack_3c + 4))();
        }
      }
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar1 = piVar9 + 1;
    iVar4 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar4 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        piVar3 = (int *)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar9 = param_2 + 2;
    iVar4 = *piVar9;
    piVar3 = (int *)*piVar9;
    *piVar9 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar3 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  piVar9 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar4 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_4)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar3 = (int *)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 26503 ; VA 0x00bdd160 ; FUN_00bdd160 */

int FUN_00bdd160(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_74 [8];
  undefined4 uStack_6c;
  int *piStack_68;
  undefined4 uStack_60;
  undefined4 uStack_50;
  undefined *puStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  int *piStack_40;
  undefined4 **ppuStack_3c;
  undefined8 uStack_2c;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018010d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppuStack_3c = &piStack_24;
  piStack_40 = (int *)0xbdd191;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490();
  uStack_8._0_1_ = 2;
  if (piStack_24 != (int *)0x0) {
    ppuStack_3c = (undefined4 **)0x1;
    piStack_40 = piStack_24;
    piStack_44 = (int *)0xbdd1ab;
    iVar3 = FUN_0098c5a0();
    if ((char)iVar3 != '\0') {
      ppuStack_3c = (undefined4 **)&DAT_01d67eb4;
      piStack_40 = (int *)0xbdd1c2;
      FUN_00bde1d0();
      ppuStack_3c = (undefined4 **)&param_3;
      piStack_40 = &iStack_1c;
      piStack_44 = (int *)0xbdd1cf;
      iVar3 = FUN_00562c90();
      uStack_8._0_1_ = 3;
      if (iStack_1c != 0) {
        ppuStack_3c = (undefined4 **)0xbdd1e6;
        uStack_2c = FUN_00928340();
        ppuStack_3c = (undefined4 **)&uStack_2c;
        piStack_40 = &iStack_14;
        piStack_44 = (int *)0xbdd1ff;
        piVar4 = (int *)FUN_00a15ae0();
        if (*piVar4 == piStack_24[0x44]) {
          ppuStack_3c = (undefined4 **)0x0;
          uStack_60 = 0;
          FUN_005587b0(&iStack_1c);
          FUN_005587b0(&param_1);
          FUN_00bd6ae0(auStack_74,FUN_00bd8fd0);
          FUN_00bd59b0();
          piStack_68 = &iStack_1c;
          uStack_6c = 0xbdd279;
          FUN_00557fc0();
          piStack_68 = (int *)0xbdd281;
          iVar3 = FUN_00bdf0f0();
        }
        else {
          uStack_48 = 0xbdd217;
          piStack_44 = &iStack_1c;
          FUN_005587b0();
          puStack_4c = (undefined *)&param_1;
          uStack_50 = 0xbdd225;
          FUN_005587b0();
          puStack_4c = (undefined *)0xbdd22a;
          iVar3 = FUN_00bd8fd0();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar4 = piStack_18 + 1;
        iVar2 = *piVar4;
        iVar3 = *piVar4;
        *piVar4 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          ppuStack_3c = (undefined4 **)0xbdd297;
          (**(code **)*piStack_18)();
          LOCK();
          piVar4 = piStack_18 + 2;
          iVar2 = *piVar4;
          iVar3 = *piVar4;
          *piVar4 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            ppuStack_3c = (undefined4 **)0xbdd2a7;
            iVar3 = (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_20 + 1;
    iVar2 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppuStack_3c = (undefined4 **)0xbdd2bd;
      (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piStack_20 + 2;
      iVar2 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuStack_3c = (undefined4 **)0xbdd2cd;
        iVar3 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 2;
    iVar2 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppuStack_3c = (undefined4 **)0xbdd2e2;
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  piVar4 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppuStack_3c = (undefined4 **)0xbdd2f8;
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppuStack_3c = (undefined4 **)0xbdd307;
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26504 ; VA 0x00bdd320 ; FUN_00bdd320 */

int * FUN_00bdd320(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined auStack_6c [8];
  undefined4 uStack_64;
  int *piStack_60;
  undefined4 uStack_58;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 **ppuStack_34;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018010d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppuStack_34 = &piStack_24;
  piStack_38 = (int *)0xbdd351;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  if (piStack_24 != (int *)0x0) {
    ppuStack_34 = (undefined4 **)0x1;
    piStack_38 = piStack_24;
    uStack_3c = 0xbdd36b;
    piStack_24 = (int *)FUN_0098c5a0();
    if ((char)piStack_24 != '\0') {
      ppuStack_34 = (undefined4 **)&param_3;
      piStack_38 = &iStack_1c;
      uStack_3c = 0xbdd383;
      piStack_24 = (int *)FUN_00562c90();
      uStack_8._0_1_ = 3;
      if (iStack_1c != 0) {
        ppuStack_34 = (undefined4 **)0x0;
        uStack_58 = 0;
        if (DAT_01d67ecc == '\0') {
          FUN_005587b0(&iStack_1c);
          FUN_005587b0(&param_1);
          FUN_00bd6ae0(auStack_6c,FUN_00bd91d0);
          FUN_00bd59b0();
          piStack_60 = &iStack_1c;
          uStack_64 = 0xbdd42a;
          FUN_00557fc0();
          piStack_60 = (int *)0xbdd432;
          piStack_24 = (int *)FUN_00bdf0f0();
        }
        else {
          FUN_005587b0(&iStack_1c);
          FUN_005587b0(&param_1);
          FUN_00bd6ae0(auStack_6c,FUN_00bd91d0);
          FUN_00bd59b0();
          piStack_60 = &iStack_1c;
          uStack_64 = 0xbdd3ea;
          FUN_00557fc0();
          piStack_60 = (int *)0xbdd3f2;
          piStack_24 = (int *)FUN_00bdee80();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_18 + 1;
        iVar3 = *piVar1;
        piStack_24 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          ppuStack_34 = (undefined4 **)0xbdd448;
          (**(code **)*piStack_18)();
          LOCK();
          piVar1 = piStack_18 + 2;
          iVar3 = *piVar1;
          piStack_24 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            ppuStack_34 = (undefined4 **)0xbdd458;
            piStack_24 = (int *)(**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar3 = *piVar1;
    piStack_24 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      ppuStack_34 = (undefined4 **)0xbdd46e;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar3 = *piVar1;
      piStack_24 = (int *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        ppuStack_34 = (undefined4 **)0xbdd47e;
        piStack_24 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar3 = *piVar1;
    piStack_24 = (int *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      ppuStack_34 = (undefined4 **)0xbdd493;
      piStack_24 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  piVar1 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 1;
    iVar3 = *piVar2;
    piStack_24 = (int *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      ppuStack_34 = (undefined4 **)0xbdd4a9;
      piStack_24 = (int *)(**(code **)*param_4)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppuStack_34 = (undefined4 **)0xbdd4b8;
        piStack_24 = (int *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_24;
}



/* FUNCTION 26505 ; VA 0x00bdd4d0 ; FUN_00bdd4d0 */

int FUN_00bdd4d0(undefined4 param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint in_stack_00000020;
  undefined4 uStack_d8;
  uint *puStack_d4;
  undefined auStack_d0 [12];
  undefined4 uStack_c4;
  undefined4 *puStack_c0;
  int *piStack_bc;
  undefined4 auStack_b8 [6];
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined *puStack_98;
  undefined4 uStack_84;
  int iStack_80;
  undefined auStack_7c [24];
  code *pcStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  undefined auStack_58 [24];
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01801143;
  pvStack_10 = ExceptionList;
  puStack_98 = (undefined *)0x1;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_a0 = 0xbdd4ff;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0098c5a0();
  if ((char)iVar4 != '\0') {
    puStack_98 = (undefined *)&param_1;
    piStack_9c = &iStack_28;
    uStack_a0 = 0xbdd51a;
    iVar4 = FUN_00562c90();
    uStack_8 = 2;
    if (iStack_28 != 0) {
      puStack_98 = (undefined *)0x0;
      puStack_14 = auStack_b8;
      piStack_bc = &param_3;
      puStack_c0 = (undefined4 *)0xbdd542;
      FUN_0054ef60();
      puStack_c0 = &uStack_20;
      uStack_8 = 3;
      uStack_c4 = 0xbdd550;
      FUN_0060e0c0();
      puStack_18 = (undefined4 *)auStack_d0;
      uStack_8 = 5;
      puStack_d4 = auStack_40;
      uStack_d8 = 0xbdd565;
      FUN_0054ef60();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
      }
      uStack_d8 = uStack_20;
      puStack_d4 = (uint *)piStack_1c;
      puVar5 = (undefined4 *)FUN_00bd7560();
      puStack_18 = &uStack_84;
      if (puVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar5[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_84 = *puVar5;
      iStack_80 = puVar5[1];
      piStack_bc = puVar5 + 2;
      _uStack_8 = CONCAT31(uStack_7,7);
      puStack_c0 = (undefined4 *)0xbdd5db;
      FUN_0054ef60();
      piStack_bc = (int *)0xbdd5e3;
      FUN_005d11a0();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_bc = (int *)0xbdd5f8;
          (**(code **)(*piStack_1c + 4))();
        }
      }
      uStack_8 = 2;
      if (0xf < uStack_2c) {
        piStack_bc = (int *)(uStack_2c + 1);
        uVar6 = auStack_40[0];
        if (0xfff < piStack_bc) {
          uVar6 = *(uint *)(auStack_40[0] - 4);
          piStack_bc = (int *)(uStack_2c + 0x24);
          if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            piStack_bc = (int *)0xbdd7ae;
            FUN_017167a3();
          }
        }
        uStack_c4 = 0xbdd62d;
        puStack_c0 = (undefined4 *)uVar6;
        FUN_01674ea0();
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      pcStack_64 = FUN_00bdacd0;
      puStack_18 = &uStack_60;
      if (iStack_80 != 0) {
        LOCK();
        *(int *)(iStack_80 + 8) = *(int *)(iStack_80 + 8) + 1;
        UNLOCK();
      }
      uStack_60 = uStack_84;
      iStack_5c = iStack_80;
      piStack_bc = (int *)auStack_7c;
      uStack_8 = 9;
      puStack_c0 = (undefined4 *)0xbdd686;
      FUN_0054ef60();
      *puStack_14 = 0;
      puStack_18 = &uStack_d8;
      if (iStack_5c != 0) {
        LOCK();
        *(int *)(iStack_5c + 8) = *(int *)(iStack_5c + 8) + 1;
        UNLOCK();
      }
      uStack_d8 = uStack_60;
      puStack_d4 = (uint *)iStack_5c;
      uStack_8 = 0xb;
      FUN_0054ef60(auStack_58);
      uStack_8 = 10;
      FUN_00bd65c0();
      piStack_bc = (int *)0xbdd6e9;
      FUN_005d11a0();
      uStack_8 = 2;
      piStack_bc = (int *)0xbdd6f5;
      FUN_005d11a0();
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      puStack_c0 = (undefined4 *)iStack_28;
      piStack_bc = piStack_24;
      uStack_c4 = 0xbdd71e;
      iVar4 = FUN_00bdf0f0();
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puStack_98 = (undefined *)0xbdd731;
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          puStack_98 = (undefined *)0xbdd741;
          iVar4 = (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  piVar1 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puStack_98 = (undefined *)0xbdd757;
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_98 = (undefined *)0xbdd766;
        iVar4 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    puStack_98 = (undefined *)(in_stack_00000020 + 1);
    iVar4 = param_3;
    if (0xfff < puStack_98) {
      iVar4 = *(int *)(param_3 + -4);
      puStack_98 = (undefined *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_98 = &UNK_00bdd7b3;
        FUN_017167a3();
      }
    }
    uStack_a0 = 0xbdd793;
    piStack_9c = (int *)iVar4;
    iVar4 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 26506 ; VA 0x00bdd7c0 ; FUN_00bdd7c0 */

void FUN_00bdd7c0(undefined *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_19c [4];
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined8 uStack_18c;
  undefined4 uStack_158;
  undefined4 *puStack_154;
  int *piStack_150;
  undefined4 auStack_14c [6];
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined auStack_114 [76];
  int *piStack_c8;
  code *pcStack_c4;
  undefined auStack_bc [76];
  int *piStack_70;
  undefined auStack_6c [4];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_5c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018011af;
  pvStack_10 = ExceptionList;
  uStack_12c = DAT_01ef68d4;
  uStack_130 = 0xbdd7ee;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290();
  uStack_8 = 0;
  uStack_134 = 0xbdd800;
  uStack_24 = uVar2;
  iVar3 = FUN_008f7870();
  if (iVar3 != 0) {
    uStack_12c = 1;
    puStack_14 = auStack_14c;
    puStack_154 = &uStack_20;
    uStack_158 = 0xbdd81f;
    FUN_0060e0c0();
    puStack_18 = auStack_6c;
    uStack_8._0_1_ = 1;
    auStack_6c[0] = *param_1;
    uStack_5c = *(undefined8 *)(param_1 + 0x10);
    uStack_68 = *(undefined4 *)(param_1 + 4);
    uStack_64 = *(undefined4 *)(param_1 + 8);
    piStack_150 = (int *)(param_1 + 0x18);
    puStack_154 = (undefined4 *)0xbdd856;
    FUN_0054ef60();
    piStack_150 = (int *)(param_1 + 0x30);
    uStack_8._0_1_ = 2;
    puStack_154 = (undefined4 *)0xbdd866;
    FUN_0054ef60();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    puStack_154 = (undefined4 *)uStack_20;
    piStack_150 = piStack_1c;
    puStack_18 = auStack_19c;
    uStack_8._0_1_ = 5;
    auStack_19c[0] = auStack_6c[0];
    uStack_198 = uStack_68;
    uStack_194 = uStack_64;
    uStack_18c = uStack_5c;
    FUN_0054ef60();
    uStack_8._0_1_ = 6;
    FUN_0054ef60();
    uStack_8._0_1_ = 4;
    piStack_150 = (int *)FUN_00bd7170();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puStack_154 = (undefined4 *)0xbdd904;
    FUN_00bd70d0();
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_70[2] + -1;
      piStack_70[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_150 = (int *)0xbdd91c;
        (**(code **)(*piStack_70 + 4))();
      }
    }
    piStack_150 = (int *)0xbdd927;
    FUN_00bd8160();
    piStack_150 = (int *)0xbdd92f;
    FUN_00bd8160();
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_150 = (int *)0xbdd944;
        (**(code **)(*piStack_1c + 4))();
      }
    }
    pcStack_c4 = FUN_00bd9bc0;
    piStack_150 = (int *)auStack_114;
    uStack_8._0_1_ = 8;
    puStack_154 = (undefined4 *)0xbdd966;
    FUN_00bd70d0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    *puStack_14 = 0;
    FUN_00bd70d0(auStack_bc);
    FUN_00bd60f0();
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_70[2] + -1;
      piStack_70[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_150 = (int *)0xbdd9af;
        (**(code **)(*piStack_70 + 4))();
      }
    }
    piStack_150 = (int *)0xbdd9ba;
    FUN_00bd8160();
    uStack_8 = uStack_8 & 0xffffff00;
    if (piStack_c8 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_c8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_150 = (int *)0xbdd9d5;
        (**(code **)(*piStack_c8 + 4))();
      }
    }
    piStack_150 = (int *)0xbdd9e0;
    FUN_00bd8160();
    piStack_150 = (int *)0xbdd9e7;
    FUN_0090ca30();
  }
  uStack_8 = 10;
  uStack_130 = 0xbdd9f4;
  uStack_12c = uVar2;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26507 ; VA 0x00bdda10 ; FUN_00bdda10 */

uint FUN_00bdda10(undefined4 param_1,int *param_2,byte param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iStack_c;
  int *piStack_8;
  
  uVar5 = FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    uVar5 = (uint)param_3;
    *(byte *)(iStack_c + 300) = param_3;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_8 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      puVar1 = (uint *)(piStack_8 + 2);
      uVar3 = *puVar1;
      uVar5 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar5 = (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      uVar5 = (**(code **)(*param_2 + 4))();
    }
  }
  return uVar5;
}



/* FUNCTION 26508 ; VA 0x00bdda80 ; FUN_00bdda80 */

void __thiscall FUN_00bdda80(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 *puStack_158;
  int *piStack_154;
  undefined4 uStack_150;
  undefined4 uStack_134;
  int iStack_130;
  undefined auStack_118 [76];
  int *piStack_cc;
  code *pcStack_c8;
  undefined auStack_c0 [76];
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801214;
  pvStack_10 = ExceptionList;
  iStack_130 = DAT_01ef68d4;
  uStack_134 = 0xbddaae;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290();
  uStack_8 = 0;
  uStack_24 = uVar3;
  if ((*(char *)(param_1 + 0x98) == '\0') && (*param_2 != 4)) {
    uStack_134 = 0xbddadc;
    iStack_130 = param_1;
    iStack_20 = FUN_008f7870();
    if (iStack_20 != 0) {
      iStack_130 = 1;
      puStack_158 = &puStack_1c;
      uStack_15c = 0xbddafc;
      piStack_154 = (int *)param_1;
      FUN_0060e0c0();
      piStack_154 = param_2;
      uStack_8._0_1_ = 2;
      puStack_158 = (undefined4 *)0xbddb0c;
      FUN_00bd7e80();
      puStack_28 = (undefined *)&puStack_158;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
      puStack_158 = puStack_1c;
      piStack_154 = piStack_18;
      puStack_14 = (undefined *)&uStack_1a0;
      uStack_8._0_1_ = 5;
      uStack_1a0 = uStack_70;
      uStack_19c = uStack_6c;
      FUN_0054ef60();
      uStack_8._0_1_ = 6;
      FUN_0054ef60();
      uStack_168 = uStack_38;
      uStack_164 = uStack_34;
      uStack_160 = uStack_30;
      uStack_15c = uStack_2c;
      uStack_8._0_1_ = 4;
      piStack_154 = (int *)FUN_00bd73b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      puStack_158 = (undefined4 *)0xbddbb2;
      FUN_00bd7310();
      if (piStack_74 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_74[2] + -1;
        piStack_74[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_154 = (int *)0xbddbca;
          (**(code **)(*piStack_74 + 4))();
        }
      }
      piStack_154 = (int *)0xbddbd5;
      FUN_00651cc0();
      piStack_154 = (int *)0xbddbdd;
      FUN_00651cc0();
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_18[2] + -1;
        piStack_18[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_154 = (int *)0xbddbf2;
          (**(code **)(*piStack_18 + 4))();
        }
      }
      pcStack_c8 = FUN_00bd97f0;
      piStack_154 = (int *)auStack_118;
      uStack_8._0_1_ = 8;
      puStack_158 = (undefined4 *)0xbddc14;
      FUN_00bd7310();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      uStack_150 = 0;
      FUN_00bd7310(auStack_c0);
      FUN_00bd6280();
      if (piStack_74 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_74[2] + -1;
        piStack_74[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_154 = (int *)0xbddc5c;
          (**(code **)(*piStack_74 + 4))();
        }
      }
      piStack_154 = (int *)0xbddc67;
      FUN_00651cc0();
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_cc != (int *)0x0) {
        LOCK();
        piVar1 = piStack_cc + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piStack_154 = (int *)0xbddc82;
          (**(code **)(*piStack_cc + 4))();
        }
      }
      piStack_154 = (int *)0xbddc8d;
      FUN_00651cc0();
      piStack_154 = (int *)0xbddc95;
      FUN_0090ca30();
    }
  }
  uStack_8 = 10;
  uStack_134 = 0xbddca2;
  iStack_130 = uVar3;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26509 ; VA 0x00bddcc0 ; FUN_00bddcc0 */

void __thiscall FUN_00bddcc0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_60;
  undefined4 **ppuStack_5c;
  int *piStack_58;
  code *pcStack_48;
  int iStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined auStack_34 [8];
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018012a2;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  if (param_3 != (int *)0x0) {
    piStack_58 = (int *)(uint)DAT_01ef68fc;
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    FUN_0060e0c0(&uStack_60,param_1);
    piStack_58 = (int *)FUN_00b13e80(&pcStack_48,FUN_00bdd320);
    ppuStack_5c = &puStack_20;
    uStack_8 = 0;
    uStack_60 = 0xbddd2f;
    param_3 = (int *)FUN_00bd6c50();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    ppuStack_5c = (undefined4 **)0xbddd42;
    piStack_58 = param_3;
    cVar2 = FUN_01679300();
    if (cVar2 != '\0') {
      piStack_58 = (int *)0xbddd51;
      FUN_01679490();
      piStack_58 = param_3;
      ppuStack_5c = (undefined4 **)0xbddd5f;
      FUN_016791c0();
    }
    if (puStack_20 != (undefined4 *)0x0) {
      piVar4 = puStack_20 + 1;
      LOCK();
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_58 = puStack_20;
        ppuStack_5c = (undefined4 **)0xbddd7d;
        FUN_01674ea0();
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[2] + -1;
      piStack_40[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_58 = (int *)0xbddda1;
        (**(code **)(*piStack_40 + 4))();
      }
    }
    param_3 = (int *)(param_1 + 0x70);
    pcStack_48 = (code *)0x0;
    piStack_58 = (int *)0xbdddc0;
    iStack_44 = param_1;
    FUN_006eccd0();
    piStack_58 = (int *)DAT_02110da8;
    uStack_8 = 2;
    ppuStack_5c = (undefined4 **)0xbdddd2;
    iVar3 = FUN_01675290();
    ppuStack_5c = (undefined4 **)0x28;
    uStack_8 = 3;
    uStack_60 = 0xbddde5;
    iStack_24 = iVar3;
    puStack_20 = (undefined4 *)FUN_01674e20();
    if (puStack_20 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_20 = 0;
      puStack_20[1] = 1;
      puStack_20[2] = FUN_00bda930;
      puStack_20[3] = _guard_check_icall;
      puStack_20[4] = 0;
      puStack_20[5] = param_3;
      puStack_20[6] = FUN_00bdd4d0;
      puStack_20[7] = pcStack_48;
      puStack_20[8] = iStack_44;
      puStack_20[9] = piStack_40;
      puVar6 = puStack_20;
    }
    ppuStack_5c = (undefined4 **)0xbdde2b;
    piStack_58 = puVar6;
    FUN_016797d0();
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_18 = 2;
    uStack_8 = 4;
    ppuStack_5c = (undefined4 **)0xbdde52;
    piStack_58 = (int *)iVar3;
    puStack_20 = puVar6;
    FUN_01675290();
    uStack_8 = 0xffffffff;
    uStack_18 = 1;
    if (puVar6 != (undefined4 *)0x0) {
      piVar4 = puVar6 + 1;
      LOCK();
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppuStack_5c = (undefined4 **)0xbdde7c;
        piStack_58 = puVar6;
        FUN_01674ea0();
      }
    }
    iVar3 = iStack_14;
    piStack_58 = (int *)(uint)DAT_01ef68fc;
    FUN_0060e0c0(&uStack_60,iStack_14);
    piStack_58 = (int *)FUN_00b13e80(&pcStack_48,FUN_00bdce70);
    ppuStack_5c = &puStack_20;
    uStack_8 = 5;
    uStack_60 = 0xbddec1;
    param_3 = (int *)FUN_00bd6c50();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    ppuStack_5c = (undefined4 **)0xbdded4;
    piStack_58 = param_3;
    cVar2 = FUN_01679300();
    if (cVar2 != '\0') {
      piStack_58 = (int *)0xbddee3;
      FUN_01679490();
      piStack_58 = param_3;
      ppuStack_5c = (undefined4 **)0xbddef1;
      FUN_016791c0();
    }
    if (puStack_20 != (undefined4 *)0x0) {
      piVar4 = puStack_20 + 1;
      LOCK();
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_58 = puStack_20;
        ppuStack_5c = (undefined4 **)0xbddf11;
        FUN_01674ea0();
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_40[2] + -1;
      piStack_40[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_58 = (int *)0xbddf30;
        (**(code **)(*piStack_40 + 4))();
      }
    }
    puStack_20 = (undefined4 *)(iVar3 + 0x90);
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ef68fc);
    ppuStack_5c = (undefined4 **)&uStack_3c;
    piStack_58 = (int *)iVar3;
    uStack_60 = 0xbddf4b;
    FUN_0060e0c0();
    piStack_58 = piStack_1c;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piStack_38[2] = piStack_38[2] + 1;
      UNLOCK();
    }
    uStack_60 = uStack_3c;
    ppuStack_5c = (undefined4 **)piStack_38;
    piVar4 = (int *)FUN_00b163b0();
    pcStack_48 = FUN_00bdda10;
    piStack_40 = (int *)piVar4[1];
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[2] = piStack_40[2] + 1;
      UNLOCK();
      piStack_40 = (int *)piVar4[1];
    }
    iStack_44 = *piVar4;
    iStack_24 = iStack_44;
    piStack_1c = piStack_40;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_58 = (int *)0xbddfbe;
        (**(code **)(*piStack_2c + 4))();
      }
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_38[2] + -1;
      piStack_38[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_58 = (int *)0xbddfd3;
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uStack_8 = 7;
    piStack_58 = (int *)0xbddfe5;
    FUN_006eccd0();
    piStack_58 = (int *)DAT_02110da8;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    ppuStack_5c = (undefined4 **)0xbddff4;
    uVar5 = FUN_01675290();
    ppuStack_5c = (undefined4 **)0x24;
    uStack_8 = 9;
    uStack_60 = 0xbde007;
    uStack_28 = uVar5;
    piStack_2c = (int *)FUN_01674e20();
    if (piStack_2c == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      *piStack_2c = 0;
      piStack_2c[1] = 1;
      piStack_2c[2] = (int)FUN_00bda8f0;
      piStack_2c[3] = (int)FUN_0057e090;
      piStack_2c[4] = 0;
      piStack_2c[5] = (int)puStack_20;
      piStack_2c[6] = (int)FUN_00bdda10;
      piStack_2c[7] = 0;
      piStack_2c[8] = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
      }
      piStack_2c[7] = iStack_24;
      piStack_2c[8] = (int)piStack_1c;
      piVar4 = piStack_2c;
    }
    ppuStack_5c = (undefined4 **)0xbde071;
    piStack_58 = piVar4;
    FUN_016797d0();
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    uStack_18 = 9;
    uStack_8 = 10;
    ppuStack_5c = (undefined4 **)0xbde098;
    param_3 = piVar4;
    piStack_58 = (int *)uVar5;
    FUN_01675290();
    piStack_58 = (int *)&param_3;
    uStack_8 = 0xb;
    ppuStack_5c = (undefined4 **)0xbde0b6;
    cVar2 = FUN_01679300();
    if (cVar2 != '\0') {
      piStack_58 = (int *)0xbde0c1;
      FUN_01679490();
      piStack_58 = (int *)&param_3;
      ppuStack_5c = (undefined4 **)0xbde0cc;
      FUN_016791c0();
    }
    if (param_3 != (int *)0x0) {
      piVar4 = param_3 + 1;
      LOCK();
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_58 = param_3;
        ppuStack_5c = (undefined4 **)0xbde0ec;
        FUN_01674ea0();
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_58 = (int *)0xbde10b;
        (**(code **)(*piStack_1c + 4))();
      }
    }
    piStack_58 = (int *)(uint)DAT_01ef68fc;
    FUN_0060e0c0(&uStack_60,iStack_14);
    piStack_58 = (int *)FUN_00b13e80(auStack_34,FUN_00bdd160);
    ppuStack_5c = (undefined4 **)&iStack_24;
    uStack_8 = 0xc;
    uStack_60 = 0xbde14c;
    param_3 = (int *)FUN_00bd6c50();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    ppuStack_5c = (undefined4 **)0xbde166;
    piStack_58 = param_3;
    cVar2 = FUN_01679300();
    if (cVar2 != '\0') {
      piStack_58 = (int *)0xbde171;
      FUN_01679490();
      piStack_58 = param_3;
      ppuStack_5c = (undefined4 **)0xbde17b;
      FUN_016791c0();
    }
    if (iStack_24 != 0) {
      piVar4 = (int *)(iStack_24 + 4);
      LOCK();
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_58 = (int *)iStack_24;
        ppuStack_5c = (undefined4 **)0xbde198;
        FUN_01674ea0();
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar4 = piStack_2c + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_58 = (int *)0xbde1af;
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26510 ; VA 0x00bde1d0 ; FUN_00bde1d0 */

void __thiscall FUN_00bde1d0(int param_1,undefined4 param_2)

{
  byte bVar1;
  longlong lVar2;
  int *piVar3;
  int *piVar4;
  undefined **appuStack_d0 [4];
  undefined *puStack_c0;
  undefined auStack_b8 [80];
  undefined **ppuStack_68;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018012df;
  pvStack_10 = ExceptionList;
  appuStack_d0[0] = &PTR_018bf148;
  puStack_c0 = &DAT_018bf150;
  ppuStack_68 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 0;
  uStack_1c = 1;
  ExceptionList = &pvStack_10;
  FUN_00564f30(auStack_b8,0);
  uStack_8 = 1;
  *(undefined ***)((int)appuStack_d0 + (int)appuStack_d0[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_b8 + (int)(appuStack_d0[0][1] + -0x1c)) = appuStack_d0[0][1] + -0x68;
  FUN_005657a0(param_2,3);
  piVar3 = *(int **)(param_1 + 0x110);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*(int *)(param_1 + 0x110) + 4) = *(int *)(param_1 + 0x110);
  *(undefined4 *)(param_1 + 0x114) = 0;
  if (piVar4 != *(int **)(param_1 + 0x110)) {
    do {
      piVar3 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x10);
      piVar4 = piVar3;
    } while (piVar3 != (int *)*(int *)(param_1 + 0x110));
  }
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_18 = 0;
  piVar3 = (int *)FUN_00bd5d20(&uStack_18);
  bVar1 = *(byte *)(*(int *)(*piVar3 + 4) + 0xc + (int)piVar3);
  lVar2 = uStack_18;
  while (uStack_18 = lVar2, (bVar1 & 6) == 0) {
    uStack_18._4_4_ = (int)((ulonglong)lVar2 >> 0x20);
    if ((-1 < lVar2) &&
       ((0 < uStack_18._4_4_ || (uStack_18._0_4_ = (int)lVar2, (int)uStack_18 != 0)))) {
      FUN_005e5570(auStack_20,&uStack_18,param_2);
      lVar2 = uStack_18;
    }
    uStack_18 = lVar2;
    piVar3 = (int *)FUN_00bd5d20(&uStack_18);
    lVar2 = uStack_18;
    bVar1 = *(byte *)(*(int *)(*piVar3 + 4) + 0xc + (int)piVar3);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26511 ; VA 0x00bde340 ; FUN_00bde340 */

undefined FUN_00bde340(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if ((iStack_c == 0) || (*(int *)(iStack_c + 0x34) == 0)) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar2 = piStack_8[2] + -1;
        piStack_8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    uVar3 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar2 = piStack_8[2] + -1;
        piStack_8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    uVar3 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return uVar3;
}



/* FUNCTION 26512 ; VA 0x00bde3e0 ; FUN_00bde3e0 */

int FUN_00bde3e0(undefined *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if ((((param_1 != &DAT_02132700) && (param_1 != &DAT_021326c0)) && (param_1 != &DAT_021327b8)) &&
     (param_1 != &DAT_021327f8)) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_009cba80(param_1,param_2,param_3);
    ExceptionList = pvStack_10;
    return iVar1;
  }
  piVar4 = (int *)*param_2;
  iVar1 = *piVar4;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cdc0();
  if (iVar1 == iVar2) {
    piVar3 = piVar4 + 2;
    if (piVar4[1] == 0) {
      piVar3 = (int *)0x0;
    }
    piVar4 = (int *)piVar3[1];
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)piVar3[1];
    }
    uStack_8 = 0;
    iVar1 = FUN_00c60220(*piVar3,param_3);
    if ((char)iVar1 != '\0') {
      iVar1 = FUN_009cba80(param_1,param_2,param_3);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      iVar1 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar1 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar1 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26513 ; VA 0x00bde4f0 ; FUN_00bde4f0 */

void __thiscall FUN_00bde4f0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801313;
  pvStack_10 = ExceptionList;
  uVar5 = param_1[4] + 1;
  uVar4 = (param_1[1] - *param_1) / 0x48;
  ExceptionList = &pvStack_10;
  if (uVar4 < uVar5) {
    if (uVar4 == 0) {
      uVar4 = 1;
    }
    for (; uVar4 < uVar5; uVar4 = uVar4 * 2) {
    }
    uVar2 = uVar4 * 2;
    if (uVar4 / 5 + uVar5 < uVar4) {
      uVar2 = uVar4;
    }
    uVar4 = param_1[6];
    if (uVar2 <= (uint)param_1[6]) {
      uVar4 = uVar2;
    }
    ExceptionList = &pvStack_10;
    FUN_00bdf270(uVar4);
  }
  if ((param_1[1] - *param_1) / 0x48 == param_1[4]) {
    if (param_1[4] != 0) {
      FUN_00bdea60(param_1[3],param_2);
      iVar3 = param_1[3] + 0x48;
      param_1[3] = iVar3;
      if (iVar3 == param_1[1]) {
        iVar3 = *param_1;
        param_1[3] = iVar3;
      }
      param_1[2] = iVar3;
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    puVar1 = (undefined4 *)param_1[3];
    uStack_8 = 0;
    if (puVar1 != (undefined4 *)0x0) {
      *puVar1 = *param_2;
      puVar1[1] = param_2[1];
      FUN_0054ef60(param_2 + 2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054ef60(param_2 + 8);
      puVar1[0xe] = param_2[0xe];
      puVar1[0xf] = param_2[0xf];
      puVar1[0x10] = param_2[0x10];
      puVar1[0x11] = param_2[0x11];
    }
    param_1[3] = param_1[3] + 0x48;
    if (param_1[3] == param_1[1]) {
      param_1[3] = *param_1;
    }
    param_1[4] = param_1[4] + 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26514 ; VA 0x00bde650 ; FUN_00bde650 */

int FUN_00bde650(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined8 uVar7;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  int *piStack_108;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [4];
  undefined *puStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801361;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_00928340();
  piStack_14 = (int *)uVar7;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  puVar5 = (undefined4 *)FUN_00bdaf30(&puStack_2c,uVar7,param_1,param_2);
  uStack_44 = *puVar5;
  piVar3 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8._0_1_ = 2;
  piStack_18 = piStack_28;
  piStack_40 = piVar3;
  uStack_20 = uStack_44;
  piStack_14 = piVar3;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_28[1] + -1;
    piStack_28[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar6 = piStack_18[2] + -1;
      piStack_18[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  FUN_00927d30(auStack_30);
  piStack_28 = (int *)0x0;
  puStack_2c = auStack_30;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
  }
  uStack_1c = uStack_20;
  uStack_8._0_1_ = 3;
  pcVar4 = *(code **)(*piStack_24 + 8);
  piStack_18 = piVar3;
  uStack_114 = FUN_008881d0();
  uStack_10c = uStack_20;
  uStack_110 = 0;
  piStack_108 = piStack_14;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_110 = FUN_0058c000();
  uStack_8._0_1_ = 4;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_00687980(&uStack_114,&uStack_44,param_2);
  uStack_8._0_1_ = 5;
  (*pcVar4)(&DAT_02132778,&uStack_3c,&puStack_2c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar6 = FUN_016f32d1(&uStack_114,0xd0,1,FUN_0056e5b0);
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 1;
    iVar2 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar3 = param_2 + 2;
      iVar2 = *piVar3;
      iVar6 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar2 = *piVar3;
    iVar6 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26515 ; VA 0x00bde880 ; FUN_00bde880 */

int FUN_00bde880(int *param_1,int *param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  uint uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018013b7;
  pvStack_10 = ExceptionList;
  uStack_24 = param_4;
  uStack_8 = 0;
  uStack_20 = 0;
  uVar3 = param_3[0x10];
  uVar4 = *param_3;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3 + 2);
  uStack_8._0_1_ = 1;
  pcVar5 = *(code **)(*param_1 + 8);
  uStack_2ac = FUN_0088cb40();
  uStack_2a8 = 0;
  uStack_2a4 = uStack_3c;
  uStack_2a0 = uStack_38;
  uStack_29c = uStack_34;
  uStack_298 = uStack_30;
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_2c = 0;
  uStack_28 = 0xf;
  uStack_2a8 = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1dc = thunk_FUN_0086f380();
  uStack_1d8 = 0;
  uStack_1d4 = uVar4;
  uStack_1d8 = FUN_0086f410();
  uStack_8._0_1_ = 3;
  uStack_10c = FUN_0088c8c0();
  uStack_108 = 0;
  uStack_104 = uVar3;
  uStack_108 = FUN_005c9cc0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_2ac,&uStack_3c,param_1);
  uStack_8._0_1_ = 5;
  (*pcVar5)(&DAT_02132680,&uStack_1c,&uStack_24);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar6 = FUN_016f32d1(&uStack_2ac,0xd0,3,FUN_0056e5b0);
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    uVar7 = uStack_3c;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(uStack_3c - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (uStack_3c - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 26516 ; VA 0x00bdea60 ; FUN_00bdea60 */

void FUN_00bdea60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  piVar1 = param_2 + 2;
  if (param_1 + 2 != piVar1) {
    if (0xf < (uint)param_2[7]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[6]);
  }
  piVar1 = param_2 + 8;
  if (param_1 + 8 != piVar1) {
    if (0xf < (uint)param_2[0xd]) {
      piVar1 = (int *)*piVar1;
    }
    FUN_005542c0(piVar1,param_2[0xc]);
  }
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  return;
}



/* FUNCTION 26517 ; VA 0x00bdead0 ; FUN_00bdead0 */

int FUN_00bdead0(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = param_2[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[1];
  }
  iVar3 = *param_2;
  *param_1 = iVar3;
  piVar2 = (int *)param_1[1];
  param_1[1] = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return iVar3;
}



/* FUNCTION 26518 ; VA 0x00bdeb20 ; FUN_00bdeb20 */

void __fastcall FUN_00bdeb20(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  puStack_18 = (undefined4 *)0x1;
  uStack_20 = 0xbdeb31;
  uStack_1c = param_1;
  cVar1 = FUN_00973950();
  if (cVar1 == '\0') {
    puStack_18 = (undefined4 *)0x1;
    uStack_20 = 0xbdeb7e;
    uStack_1c = param_1;
    cVar1 = FUN_0098c5a0();
    if (cVar1 == '\0') {
      puStack_18 = (undefined4 *)0x0;
      uStack_1c = 0xbdeb92;
      FUN_005e6780();
    }
  }
  else {
    uStack_1c = 0xbdeb3e;
    puStack_18 = (undefined4 *)param_1;
    iVar2 = FUN_0097bfc0();
    if (iVar2 != 0) {
      puStack_18 = &uStack_10;
      uStack_10 = 0;
      uStack_c = 0;
      FUN_0060dcd0(&uStack_20,iVar2);
      FUN_009c10f0(param_1);
      return;
    }
  }
  return;
}



/* FUNCTION 26519 ; VA 0x00bdeba0 ; FUN_00bdeba0 */

void __fastcall FUN_00bdeba0(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  puStack_18 = (undefined4 *)0x1;
  uStack_20 = 0xbdebb1;
  uStack_1c = param_1;
  cVar1 = FUN_00973950();
  if (cVar1 != '\0') {
    uStack_1c = 0xbdebbe;
    puStack_18 = (undefined4 *)param_1;
    iVar2 = FUN_0097bfc0();
    if (iVar2 != 0) {
      puStack_18 = &uStack_10;
      uStack_10 = 0;
      uStack_c = 0;
      FUN_0060dcd0(&uStack_20,iVar2);
      FUN_009c10f0(param_1);
    }
  }
  return;
}



/* FUNCTION 26520 ; VA 0x00bdec00 ; FUN_00bdec00 */

void __fastcall FUN_00bdec00(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  puStack_18 = (undefined4 *)0x1;
  uStack_20 = 0xbdec11;
  uStack_1c = param_1;
  cVar1 = FUN_00973950();
  if (cVar1 != '\0') {
    uStack_1c = 0xbdec1e;
    puStack_18 = (undefined4 *)param_1;
    iVar2 = FUN_0097bfc0();
    if (iVar2 != 0) {
      puStack_18 = &uStack_10;
      uStack_10 = 0;
      uStack_c = 0;
      FUN_0060dcd0(&uStack_20,iVar2);
      FUN_009c10f0(param_1);
    }
  }
  return;
}



/* FUNCTION 26521 ; VA 0x00bdec60 ; FUN_00bdec60 */

void __thiscall
FUN_00bdec60(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 *param_6)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  if (param_4 == param_6) {
    *param_2 = param_3;
    param_2[1] = param_4;
    return;
  }
  if (param_6 == (undefined4 *)0x0) {
    param_6 = (undefined4 *)param_1[3];
  }
  puVar5 = param_6;
  if (param_4 != (undefined4 *)param_1[2]) {
    do {
      puVar3 = param_4;
      if (param_4 == (undefined4 *)*param_1) {
        puVar3 = (undefined4 *)param_1[1];
      }
      param_4 = puVar3 + -0x12;
      puVar4 = (undefined4 *)param_1[1];
      if (puVar5 != (undefined4 *)*param_1) {
        puVar4 = puVar5;
      }
      puVar5 = puVar4 + -0x12;
      *puVar5 = *param_4;
      puVar4[-0x11] = puVar3[-0x11];
      piVar2 = puVar3 + -0x10;
      if (puVar4 + -0x10 != piVar2) {
        if (0xf < (uint)puVar3[-0xb]) {
          piVar2 = (int *)*piVar2;
        }
        FUN_005542c0(piVar2,puVar3[-0xc]);
      }
      piVar2 = puVar3 + -10;
      if (puVar4 + -10 != piVar2) {
        if (0xf < (uint)puVar3[-5]) {
          piVar2 = (int *)*piVar2;
        }
        FUN_005542c0(piVar2,puVar3[-6]);
      }
      puVar4[-4] = puVar3[-4];
      puVar4[-3] = puVar3[-3];
      puVar4[-2] = puVar3[-2];
      puVar4[-1] = puVar3[-1];
    } while (param_4 != (undefined4 *)param_1[2]);
  }
  do {
    FUN_00651cc0();
    param_1[2] = param_1[2] + 0x48;
    if (param_1[2] == param_1[1]) {
      param_1[2] = *param_1;
    }
    iVar1 = param_1[4];
    puVar3 = (undefined4 *)param_1[2];
    param_1[4] = iVar1 + -1;
  } while (puVar3 != puVar5);
  if (puVar3 != param_6) {
    if (param_6 == (undefined4 *)*param_1) {
      param_6 = (undefined4 *)param_1[1];
    }
    *param_2 = param_1;
    param_2[1] = param_6 + -0x12;
    return;
  }
  if (iVar1 + -1 == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  *param_2 = param_1;
  param_2[1] = puVar3;
  return;
}



/* FUNCTION 26522 ; VA 0x00bded70 ; FUN_00bded70 */

void __thiscall
FUN_00bded70(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 *param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  if (param_4 == param_6) {
    *param_2 = param_3;
    param_2[1] = param_4;
    return;
  }
  if (param_6 == (undefined4 *)0x0) {
    param_6 = (undefined4 *)param_1[3];
  }
  puVar3 = (undefined4 *)param_1[2];
  puVar4 = param_6;
  if (param_4 != puVar3) {
    do {
      puVar3 = param_4;
      if (param_4 == (undefined4 *)*param_1) {
        puVar3 = (undefined4 *)param_1[1];
      }
      param_4 = puVar3 + -2;
      puVar5 = puVar4;
      if (puVar4 == (undefined4 *)*param_1) {
        puVar5 = (undefined4 *)param_1[1];
      }
      iVar2 = puVar3[-1];
      puVar4 = puVar5 + -2;
      if (iVar2 != 0) {
        LOCK();
        *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
        UNLOCK();
        iVar2 = puVar3[-1];
      }
      *puVar4 = *param_4;
      piVar1 = (int *)puVar5[-1];
      puVar5[-1] = iVar2;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      puVar3 = (undefined4 *)param_1[2];
    } while (param_4 != puVar3);
  }
  do {
    piVar1 = (int *)puVar3[1];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    param_1[2] = param_1[2] + 8;
    if (param_1[2] == param_1[1]) {
      param_1[2] = *param_1;
    }
    iVar2 = param_1[4];
    puVar3 = (undefined4 *)param_1[2];
    param_1[4] = iVar2 + -1;
  } while (puVar3 != puVar4);
  if (puVar3 == param_6) {
    if (iVar2 + -1 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    *param_2 = param_1;
    param_2[1] = puVar3;
    return;
  }
  if (param_6 == (undefined4 *)*param_1) {
    param_6 = (undefined4 *)param_1[1];
  }
  *param_2 = param_1;
  param_2[1] = param_6 + -2;
  return;
}



/* FUNCTION 26523 ; VA 0x00bdee80 ; FUN_00bdee80 */

void __thiscall
FUN_00bdee80(undefined4 param_1,int param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,undefined4 *param_11)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  undefined4 uStack_80;
  int *piStack_7c;
  int iStack_78;
  int *piStack_74;
  uint uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  int aiStack_50 [4];
  undefined auStack_40 [20];
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180142b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008f7870(param_1);
    if (iVar3 != 0) {
      FUN_014c9d60(&uStack_28,0);
      uStack_8._0_1_ = 2;
      piStack_14 = (int *)uStack_28;
      uVar5 = FUN_00928340();
      puVar4 = (undefined4 *)FUN_00f54f00(auStack_40,uVar5);
      puVar1 = puVar4 + 4;
      uStack_8._0_1_ = 3;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_014cbbc0(puVar4,*puVar1);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      FUN_014cba10(&DAT_018c3c94,3);
      if ((char)param_11 != '\0') {
        FUN_014cb890(2);
      }
      FUN_0060e0c0(&uStack_20,param_1);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      iStack_18 = param_2;
      piStack_14 = param_3;
      param_11 = &uStack_80;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
      }
      uStack_80 = uStack_20;
      piStack_7c = piStack_1c;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      iStack_78 = param_2;
      piStack_74 = param_3;
      uStack_8._0_1_ = 7;
      uStack_70 = 0;
      if (param_4 != 0) {
        uStack_70 = param_4;
        if ((param_4 & 1) == 0) {
          (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_68,0);
        }
        else {
          uStack_68 = param_6;
          uStack_64 = param_7;
          uStack_60 = param_8;
          uStack_5c = param_9;
          uStack_58 = param_10;
        }
      }
      piStack_2c = (int *)0x0;
      uStack_8._0_1_ = 9;
      piStack_2c = (int *)FUN_00bd6080(&uStack_80);
      FUN_00bd7f00();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_014cb530(aiStack_50);
      if (piStack_2c != (int *)0x0) {
        (**(code **)(*piStack_2c + 0x10))
                  (CONCAT31((int3)((uint)aiStack_50 >> 8),piStack_2c != aiStack_50));
        piStack_2c = (int *)0x0;
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar3 = param_3[2] + -1;
        param_3[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_24[2] + -1;
          piStack_24[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 0xb;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26524 ; VA 0x00bdf0f0 ; FUN_00bdf0f0 */

void __thiscall FUN_00bdf0f0(undefined4 param_1,int param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined *in_stack_0000002c;
  undefined auStack_108 [8];
  uint uStack_100;
  uint uStack_fc;
  undefined auStack_f8 [48];
  undefined4 uStack_c8;
  undefined4 uStack_b8;
  undefined *puStack_b4;
  undefined8 uStack_b0;
  undefined *puStack_a8;
  int iStack_a4;
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180146b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    puStack_a8 = (undefined *)0xbdf12a;
    ExceptionList = &pvStack_10;
    iStack_a4 = param_1;
    iVar3 = FUN_008f7870();
    if (iVar3 != 0) {
      piVar1 = *(int **)(iVar3 + 0x43c);
      iVar3 = *piVar1;
      iVar2 = piVar1[1];
      iStack_a4 = 0xbdf14c;
      uStack_b0 = FUN_00928340();
      puStack_b4 = auStack_2c;
      uStack_b8 = 0xbdf159;
      puStack_a8 = (undefined *)(iVar3 - (int)piVar1);
      iStack_a4 = iVar2 - (int)piVar1;
      uVar4 = FUN_00f52e50();
      iStack_a4 = 0;
      puStack_a8 = (undefined *)0x0;
      uStack_8._0_1_ = 2;
      uStack_b0._0_4_ = 0xbdf170;
      uStack_b0._4_4_ = (undefined *)uVar4;
      FUN_014cc090();
      uStack_8._0_1_ = 4;
      iStack_a4 = 0xbdf17c;
      FUN_005507b0();
      iStack_a4 = 0;
      uStack_fc = (uint)DAT_01ef68fd;
      uStack_c8 = 0;
      uStack_100 = (uint)DAT_01ef68fc;
      in_stack_0000002c = auStack_108;
      FUN_0060e0c0(auStack_108,param_1);
      uStack_8._0_1_ = 5;
      FUN_0054f510(&param_4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00bd68f0(auStack_f8,FUN_00bdc080);
      uStack_fc = 0xbdf1ec;
      FUN_00bd5850();
      uStack_c8 = 0xbdf1f7;
      FUN_014ccc70();
      iStack_a4 = 0xbdf202;
      FUN_0056db40();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      iStack_a4 = 0xbdf21b;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iStack_a4 = 0xbdf22a;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_b0._4_4_ = &stack0x00000014;
    iStack_a4 = 2;
    uStack_b0._0_4_ = 0xbdf24e;
    puStack_a8 = uStack_b0._4_4_;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26525 ; VA 0x00bdf270 ; FUN_00bdf270 */

void __thiscall FUN_00bdf270(int *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801480;
  pvStack_10 = ExceptionList;
  if (param_2 != (param_1[1] - *param_1) / 0x48) {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_00bd8a90(param_2);
    uVar1 = param_1[4];
    if (uVar1 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)param_1[2];
    }
    uStack_8 = 0;
    uVar7 = param_2;
    if (uVar1 < param_2) {
      uVar7 = uVar1;
    }
    iVar8 = FUN_00bd8850(uVar7);
    puVar2 = *(undefined4 **)(iVar8 + 4);
    puStack_1c = puVar6;
    if (puVar10 != puVar2) {
      puVar9 = puVar6 + 7;
      do {
        if (puStack_1c != (undefined4 *)0x0) {
          *puStack_1c = *puVar10;
          puVar9[-6] = puVar10[1];
          puVar9[-1] = 0;
          *puVar9 = 0;
          uVar3 = puVar10[3];
          uVar4 = puVar10[4];
          uVar5 = puVar10[5];
          puVar9[-5] = puVar10[2];
          puVar9[-4] = uVar3;
          puVar9[-3] = uVar4;
          puVar9[-2] = uVar5;
          *(undefined8 *)(puVar9 + -1) = *(undefined8 *)(puVar10 + 6);
          puVar10[6] = 0;
          puVar10[7] = 0xf;
          *(undefined *)(puVar10 + 2) = 0;
          puVar9[5] = 0;
          puVar9[6] = 0;
          uVar3 = puVar10[9];
          uVar4 = puVar10[10];
          uVar5 = puVar10[0xb];
          puVar9[1] = puVar10[8];
          puVar9[2] = uVar3;
          puVar9[3] = uVar4;
          puVar9[4] = uVar5;
          uVar3 = puVar10[0xd];
          puVar9[5] = puVar10[0xc];
          puVar9[6] = uVar3;
          puVar10[0xc] = 0;
          puVar10[0xd] = 0xf;
          *(undefined *)(puVar10 + 8) = 0;
          puVar9[7] = puVar10[0xe];
          puVar9[8] = puVar10[0xf];
          puVar9[9] = puVar10[0x10];
          puVar9[10] = puVar10[0x11];
        }
        puVar11 = puVar10 + 0x12;
        if (puVar11 == (undefined4 *)param_1[1]) {
          puVar11 = (undefined4 *)*param_1;
        }
        puVar10 = (undefined4 *)0x0;
        if (puVar11 != (undefined4 *)param_1[3]) {
          puVar10 = puVar11;
        }
        puStack_1c = puStack_1c + 0x12;
        puVar9 = puVar9 + 0x12;
      } while (puVar10 != puVar2);
    }
    FUN_00bd96e0();
    *param_1 = (int)puVar6;
    param_1[2] = (int)puVar6;
    param_1[4] = ((int)puStack_1c - (int)puVar6) / 0x48;
    param_1[1] = (int)(puVar6 + param_2 * 0x12);
    if (puStack_1c == puVar6 + param_2 * 0x12) {
      puStack_1c = puVar6;
    }
    param_1[3] = (int)puStack_1c;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26526 ; VA 0x00bdf40c ; Catch_All@00bdf40c */

void Catch_All_00bdf40c(void)

{
  int unaff_EBP;
  
  FUN_00bd9690(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26527 ; VA 0x00bdf430 ; FUN_00bdf430 */

void __thiscall FUN_00bdf430(int *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801490;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1[1] - *param_1 >> 3) {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)FUN_00bd8b60(param_2);
    uVar1 = param_1[4];
    if (uVar1 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7 = (undefined4 *)param_1[2];
    }
    uStack_8 = 0;
    uVar4 = param_2;
    if (uVar1 < param_2) {
      uVar4 = uVar1;
    }
    iVar5 = FUN_00bd8930(uVar4);
    puVar2 = *(undefined4 **)(iVar5 + 4);
    puVar6 = puVar3;
    while (puVar7 != puVar2) {
      if (puVar6 != (undefined4 *)0x0) {
        *puVar6 = 0;
        puVar6[1] = 0;
        *puVar6 = *puVar7;
        puVar6[1] = puVar7[1];
        *puVar7 = 0;
        puVar7[1] = 0;
      }
      puVar8 = puVar7 + 2;
      if (puVar8 == (undefined4 *)param_1[1]) {
        puVar8 = (undefined4 *)*param_1;
      }
      puVar7 = (undefined4 *)0x0;
      if (puVar8 != (undefined4 *)param_1[3]) {
        puVar7 = puVar8;
      }
      puVar6 = puVar6 + 2;
    }
    FUN_00bd9760();
    *param_1 = (int)puVar3;
    param_1[4] = (int)puVar6 - (int)puVar3 >> 3;
    param_1[2] = (int)puVar3;
    param_1[1] = (int)(puVar3 + param_2 * 2);
    if (puVar6 == puVar3 + param_2 * 2) {
      puVar6 = puVar3;
    }
    param_1[3] = (int)puVar6;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26528 ; VA 0x00bdf530 ; Catch_All@00bdf530 */

void Catch_All_00bdf530(void)

{
  int unaff_EBP;
  
  FUN_00bbcbd0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26529 ; VA 0x00bdf550 ; FUN_00bdf550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bdf550(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018014c0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6b20 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6d38) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6d38);
      if (DAT_01ef6d38 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"AdService",1,uStack_20,0,0,3,0,0);
        _DAT_01ef6d30 = RBX::Creator<class_RBX::AdService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef6b28,&DAT_01ef6d30);
        FUN_016f3654(FUN_018925b0);
        FUN_016f37bf(&DAT_01ef6d38);
      }
    }
    DAT_01ef6b20 = &DAT_01ef6b28;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6b20;
}



/* FUNCTION 26530 ; VA 0x00bdf650 ; FUN_00bdf650 */

void FUN_00bdf650(void)

{
  int iVar1;
  
  if (DAT_01ef6d3c == 0) {
    iVar1 = FUN_00bdf550();
    DAT_01ef6d3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26531 ; VA 0x00bdf670 ; FUN_00bdf670 */

undefined4 * __fastcall FUN_00bdf670(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018014f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::AdService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00bdf550();
  param_1[3] = uVar1;
  *param_1 = RBX::AdService::vftable;
  param_1[0x16] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  FUN_0054eff0("AdService");
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008a6520(aiStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26532 ; VA 0x00bdf730 ; FUN_00bdf730 */

void __fastcall FUN_00bdf730(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::AdService>::vftable;
  uVar1 = FUN_00bdf550(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26533 ; VA 0x00bdf770 ; FUN_00bdf770 */

undefined4 * FUN_00bdf770(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671030(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26534 ; VA 0x00bdf7e0 ; FUN_00bdf7e0 */

uint FUN_00bdf7e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bdf550();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26535 ; VA 0x00bdf800 ; FUN_00bdf800 */

uint FUN_00bdf800(void)

{
  int iVar1;
  
  iVar1 = FUN_00bdf550();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26536 ; VA 0x00bdf840 ; FUN_00bdf840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bdf840(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801570;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6d58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef6f70) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef6f70);
      if (DAT_01ef6f70 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Teams",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef6f68 = RBX::Creator<class_RBX::Teams>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef6d60,&DAT_01ef6f68);
        FUN_016f3654(FUN_01892620);
        FUN_016f37bf(&DAT_01ef6f70);
      }
    }
    DAT_01ef6d58 = &DAT_01ef6d60;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6d58;
}



/* FUNCTION 26537 ; VA 0x00bdf940 ; FUN_00bdf940 */

void FUN_00bdf940(void)

{
  int iVar1;
  
  if (DAT_01ef6f74 == 0) {
    iVar1 = FUN_00bdf840();
    DAT_01ef6f74 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26538 ; VA 0x00bdf960 ; FUN_00bdf960 */

undefined4 * __fastcall FUN_00bdf960(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [3];
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018015ba;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Teams,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00bdf840();
  param_1[3] = uVar1;
  *param_1 = RBX::Teams::vftable;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  iStack_18 = FUN_01674e20(0xc);
  uStack_8._0_1_ = 3;
  if (iStack_18 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00569460(&uStack_24);
  }
  uStack_8._0_1_ = 2;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  FUN_008aaf20(uVar1,iStack_18);
  uStack_8._0_1_ = 5;
  FUN_00577ac0();
  param_1[0x18] = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Teams",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26539 ; VA 0x00bdfaa0 ; FUN_00bdfaa0 */

void __fastcall FUN_00bdfaa0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Teams>::vftable;
  uVar1 = FUN_00bdf840(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26540 ; VA 0x00bdfae0 ; FUN_00bdfae0 */

undefined4 * __thiscall FUN_00bdfae0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Teams::vftable;
  piVar2 = (int *)param_1[0x17];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 26541 ; VA 0x00bdfb50 ; FUN_00bdfb50 */

bool FUN_00bdfb50(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00e40f60();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00bdfb82;
  }
  param_1 = 0;
LAB_00bdfb82:
  return param_1 != 0;
}



/* FUNCTION 26542 ; VA 0x00bdfb90 ; FUN_00bdfb90 */

void FUN_00bdfb90(void)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 uVar10;
  undefined auStack_34 [4];
  undefined auStack_30 [4];
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  char cStack_5;
  
  iStack_18 = 10000;
  cStack_5 = '\0';
  uVar10 = 0x1c;
  uVar9 = 0;
  uStack_14 = 0x1c;
  uStack_1c = 0;
  iVar2 = FUN_005d6c30();
  if (iVar2 != 0) {
    do {
      iStack_2c = *(int *)(**(int **)(iStack_10 + 0x2c) + uVar9 * 8);
      if (((iStack_2c != 0) &&
          (iVar2 = *(int *)(iStack_2c + 0xc), iVar3 = FUN_00e40f60(),
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da))) && (cVar1 = FUN_009501e0(), cVar1 == '\x01')) {
        piVar4 = (int *)FUN_00a6bd20(auStack_30);
        iVar3 = 0;
        iStack_c = 0;
        iStack_24 = *piVar4;
        iVar2 = FUN_0064e810(iStack_10);
        iStack_28 = iVar2;
        iVar5 = FUN_005d6c30();
        if (iVar5 != 0) {
          uVar9 = 0;
          do {
            iVar2 = *(int *)(**(int **)(iVar2 + 0x2c) + uVar9 * 8);
            if (((iVar2 != 0) &&
                (iVar5 = *(int *)(iVar2 + 0xc), iVar6 = FUN_00913630(), iVar3 = iStack_c,
                (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                (uint)*(ushort *)(iVar6 + 0x1da))) &&
               ((*(char *)(iVar2 + 0xa8) == '\0' && (*(int *)(iVar2 + 0x94) == iStack_24)))) {
              iVar3 = iStack_c + 1;
              iStack_c = iVar3;
            }
            iVar2 = iStack_28;
            uVar9 = uVar9 + 1;
            uVar7 = FUN_005d6c30();
            uVar10 = uStack_14;
          } while (uVar9 < uVar7);
        }
        if (iVar3 < iStack_18) {
          puVar8 = (undefined4 *)FUN_00a6bd20(auStack_34);
          cStack_5 = '\x01';
          uVar10 = *puVar8;
          iStack_18 = iVar3;
          uStack_14 = uVar10;
        }
      }
      uVar9 = uStack_1c + 1;
      uStack_1c = uVar9;
      uVar7 = FUN_005d6c30();
    } while (uVar9 < uVar7);
    if (cStack_5 != '\0') {
      FUN_00934a60(uVar10);
      FUN_00933fb0(0);
    }
  }
  return;
}



/* FUNCTION 26543 ; VA 0x00bdfd00 ; FUN_00bdfd00 */

undefined4 * FUN_00bdfd00(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00674a00(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26544 ; VA 0x00bdfd70 ; FUN_00bdfd70 */

void __thiscall FUN_00bdfd70(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  if (0 < DAT_01ef6d44) {
    FUN_00be0410();
  }
  iVar1 = *(int *)(param_1 + 0x30);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x30);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x2c);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 26545 ; VA 0x00bdfdb0 ; FUN_00bdfdb0 */

undefined8 * __thiscall FUN_00bdfdb0(undefined4 param_1,undefined8 *param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined8 *puVar8;
  int *piVar9;
  uint uStack_8;
  
  iVar4 = FUN_0064e810(param_1);
  if (iVar4 != 0) {
    uStack_8 = 0;
    iVar5 = FUN_005d6c30();
    if (iVar5 != 0) {
      do {
        iVar5 = *(int *)(**(int **)(iVar4 + 0x2c) + uStack_8 * 8);
        if ((((iVar5 != 0) &&
             (iVar1 = *(int *)(iVar5 + 0xc), iVar6 = FUN_00913630(),
             (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
             (uint)*(ushort *)(iVar6 + 0x1da))) && (*(char *)(iVar5 + 0xa8) == '\0')) &&
           (*(int *)(iVar5 + 100) != 0)) {
          puVar2 = *(undefined4 **)(*(int *)(iVar5 + 100) + 0x2c);
          if (puVar2 != (undefined4 *)0x0) {
            piVar3 = (int *)puVar2[1];
            for (piVar9 = (int *)*puVar2; piVar9 != piVar3; piVar9 = piVar9 + 2) {
              iVar5 = *piVar9;
              if ((iVar5 != 0) &&
                 (iVar1 = *(int *)(iVar5 + 0xc), iVar6 = FUN_0099be20(),
                 (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                 (uint)*(ushort *)(iVar6 + 0x1da))) goto LAB_00bdfe78;
            }
          }
          iVar5 = 0;
LAB_00bdfe78:
          if (iVar5 == param_3) {
            FUN_00c98ad0(param_2);
            return param_2;
          }
        }
        uStack_8 = uStack_8 + 1;
        uVar7 = FUN_005d6c30();
      } while (uStack_8 < uVar7);
    }
  }
  puVar8 = (undefined8 *)FUN_0115ee70();
  *param_2 = *puVar8;
  *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar8 + 1);
  return param_2;
}



/* FUNCTION 26546 ; VA 0x00bdfee0 ; FUN_00bdfee0 */

undefined4 FUN_00bdfee0(int param_1)

{
  undefined4 uVar1;
  
  if (*(char *)(param_1 + 0xa8) != '\0') {
    return 0;
  }
  uVar1 = FUN_00bdff10(*(undefined4 *)(param_1 + 0x94));
  return uVar1;
}



/* FUNCTION 26547 ; VA 0x00bdff10 ; FUN_00bdff10 */

int __thiscall FUN_00bdff10(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_c [4];
  int iStack_8;
  
  uVar6 = 0;
  iStack_8 = param_1;
  iVar2 = FUN_005d6c30();
  if (iVar2 != 0) {
    do {
      iVar2 = *(int *)(**(int **)(param_1 + 0x2c) + uVar6 * 8);
      if (iVar2 != 0) {
        iVar1 = *(int *)(iVar2 + 0xc);
        iVar3 = FUN_00e40f60();
        if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
          piVar4 = (int *)FUN_00a6bd20(auStack_c);
          if (*piVar4 == param_2) {
            return iVar2;
          }
        }
      }
      param_1 = iStack_8;
      uVar6 = uVar6 + 1;
      uVar5 = FUN_005d6c30();
    } while (uVar6 < uVar5);
  }
  return 0;
}



/* FUNCTION 26548 ; VA 0x00bdffa0 ; FUN_00bdffa0 */

void __thiscall FUN_00bdffa0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  if (0 < DAT_01ef6d44) {
    FUN_00be0410();
  }
  iVar1 = *(int *)(param_1 + 0x5c);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x5c);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x58);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 26549 ; VA 0x00bdffe0 ; FUN_00bdffe0 */

uint FUN_00bdffe0(void)

{
  int iVar1;
  
  iVar1 = FUN_00bdf840();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26550 ; VA 0x00be0000 ; FUN_00be0000 */

uint FUN_00be0000(void)

{
  int iVar1;
  
  iVar1 = FUN_00bdf840();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26551 ; VA 0x00be0020 ; FUN_00be0020 */

void __thiscall FUN_00be0020(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801620;
  pvStack_10 = ExceptionList;
  if ((param_2 != 0) &&
     (iVar5 = *(int *)(param_2 + 0xc), ExceptionList = &pvStack_10, iVar2 = FUN_00e40f60(),
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    piVar3 = (int *)FUN_008a86c0();
    iVar5 = *piVar3;
    puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,param_2);
    uStack_18 = *puVar4;
    piStack_14 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4 = *(undefined4 **)(iVar5 + 4);
    uStack_8 = 1;
    if (*(undefined4 **)(iVar5 + 8) == puVar4) {
      FUN_00603a30(puVar4,&uStack_18);
      piVar3 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_14[1] + -1;
        piStack_14[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    else {
      *puVar4 = uStack_18;
      puVar4[1] = piStack_14;
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 8;
    }
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar3 = piStack_1c + 2;
        iVar5 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (((DAT_01d67f7c != '\0') && (iVar5 = FUN_008f7870(param_1), iVar5 != 0)) &&
       (*(int *)(iVar5 + 0x4a0) == 2)) {
      iVar5 = *(int *)(param_1 + 0x60);
      *(int *)(param_1 + 0x60) = iVar5 + 1;
      FUN_00e41a10(iVar5);
    }
    FUN_00be0310();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26552 ; VA 0x00be0170 ; FUN_00be0170 */

void FUN_00be0170(undefined4 param_1,undefined4 *param_2)

{
  if (param_2 == &DAT_02147898) {
    FUN_00be0310();
  }
  FUN_008a40d0(param_1,param_2);
  return;
}



/* FUNCTION 26553 ; VA 0x00be01a0 ; FUN_00be01a0 */

void FUN_00be01a0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00e40f60();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_00be0310();
    }
  }
  return;
}



/* FUNCTION 26554 ; VA 0x00be01e0 ; FUN_00be01e0 */

void FUN_00be01e0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  if ((param_1 != 0) &&
     (iVar1 = *(int *)(param_1 + 0xc), iVar3 = FUN_00e40f60(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    piVar4 = (int *)FUN_008a86c0();
    iVar1 = *piVar4;
    piVar5 = (int *)FUN_0060dcd0(auStack_10,param_1);
    piVar6 = (int *)((int *)*piVar4)[1];
    piVar4 = *(int **)*piVar4;
    if (piVar4 != piVar6) {
      do {
        if (*piVar4 == *piVar5) break;
        piVar4 = piVar4 + 2;
      } while (piVar4 != piVar6);
    }
    piVar6 = *(int **)(iVar1 + 4);
    piVar4 = piVar4 + 2;
    piStack_8 = piVar6;
    if (piVar4 != piVar6) {
      do {
        iVar3 = *piVar4;
        iVar2 = piVar4[1];
        *piVar4 = 0;
        piVar4[1] = 0;
        piVar4[-2] = iVar3;
        piVar6 = (int *)piVar4[-1];
        piVar4[-1] = iVar2;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar3 = piVar6[1] + -1;
          piVar6[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar3 = piVar6[2] + -1;
            piVar6[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar4 = piVar4 + 2;
      } while (piVar4 != piStack_8);
      piVar6 = *(int **)(iVar1 + 4);
    }
    piVar6 = (int *)piVar6[-1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar3 = piVar6[2] + -1;
        piVar6[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + -8;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_c[1] + -1;
      piStack_c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar6 = piStack_c + 2;
        iVar1 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 26555 ; VA 0x00be0310 ; FUN_00be0310 */

int * __fastcall FUN_00be0310(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bda48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_0064e810(param_1);
  if (piVar4 != (int *)0x0) {
    piVar7 = (int *)piVar4[0x2f];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)piVar4[0x2f];
    }
    piVar1 = (int *)piVar4[0x2e];
    piVar8 = (int *)*piVar1;
    uStack_8 = 0;
    piVar4 = piVar1;
    if (piVar8 != (int *)piVar1[1]) {
      do {
        iVar2 = *piVar8;
        if (iVar2 != 0) {
          iVar3 = *(int *)(iVar2 + 0xc);
          iVar5 = FUN_00913630();
          piVar4 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
          if ((int *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= piVar4
             ) {
            if (*(char *)(iVar2 + 0xa8) == '\0') {
              uVar6 = FUN_00bdff10(*(undefined4 *)(iVar2 + 0x94));
            }
            else {
              uVar6 = 0;
            }
            piVar4 = (int *)FUN_00934ae0(uVar6);
          }
        }
        piVar8 = piVar8 + 2;
      } while (piVar8 != (int *)piVar1[1]);
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar1 = piVar7 + 1;
      iVar2 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar4 = (int *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          piVar4 = (int *)(**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 26556 ; VA 0x00be0410 ; FUN_00be0410 */

void FUN_00be0410(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6d48 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_01255560();
    uVar2 = FUN_01255560(5);
    cVar1 = FUN_01255580(uVar2);
    if (cVar1 == '\0') {
      DAT_01ef6d48 = '\x01';
      FUN_0151f6f0(0xffffffff,0,0);
      uStack_8 = 0;
      FUN_0151fcf0("TeamOrderExposed",1);
      uVar2 = DAT_01ef6d44;
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      pcVar3 = PTR_DAT_01d67f84;
      do {
        cVar1 = *pcVar3;
        pcVar3 = pcVar3 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(PTR_DAT_01d67f84,(int)pcVar3 - (int)(PTR_DAT_01d67f84 + 1));
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_01520d20(auStack_28,uVar2,0);
      FUN_005507b0();
      FUN_0151f7f0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26557 ; VA 0x00be04f0 ; FUN_00be04f0 */

uint * __thiscall FUN_00be04f0(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uStack_8 = 0;
  uVar1 = *param_3;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_3[3];
      uVar2 = param_3[4];
      uVar3 = param_3[5];
      param_1[10] = param_3[2];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_3 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_3 + 2,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26558 ; VA 0x00be05c0 ; FUN_00be05c0 */

undefined4 * __thiscall FUN_00be05c0(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000003c;
  undefined4 auStack_128 [19];
  undefined4 uStack_dc;
  undefined *puStack_d8;
  undefined *puStack_d4;
  undefined4 *puStack_d0;
  undefined auStack_bc [48];
  uint uStack_8c;
  undefined auStack_84 [24];
  undefined4 uStack_6c;
  undefined auStack_64 [48];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180166b;
  pvStack_10 = ExceptionList;
  puStack_d0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_d4 = (undefined *)0xbe0604;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00be24b0();
  uStack_6c = param_2;
  puStack_d0 = (undefined4 *)auStack_bc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_d4 = (undefined *)0xbe0626;
  FUN_00be24b0();
  puStack_d0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_128;
  auStack_128[0] = uStack_6c;
  FUN_00be24b0(auStack_64);
  ppuVar2 = &PTR_FUN_0195f388;
  cVar1 = FUN_00be11c0();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_d8 = auStack_2c;
      puStack_d0 = (undefined4 *)0x2;
      uStack_dc = 0xbe067d;
      puStack_d4 = puStack_d8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_d0 = (undefined4 *)0xbe068f;
  FUN_00be32e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_8c != 0) {
    if (((uStack_8c & 1) == 0) && (*(code **)(uStack_8c & 0xfffffffe) != (code *)0x0)) {
      puStack_d8 = auStack_84;
      puStack_d0 = (undefined4 *)0x2;
      uStack_dc = 0xbe06b3;
      puStack_d4 = puStack_d8;
      (**(code **)(uStack_8c & 0xfffffffe))();
    }
    uStack_8c = 0;
  }
  puStack_d0 = (undefined4 *)0xbe06cb;
  FUN_00be32e0();
  uStack_8 = 5;
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      puStack_d8 = &stack0x00000044;
      puStack_d0 = (undefined4 *)0x2;
      uStack_dc = 0xbe06ef;
      puStack_d4 = puStack_d8;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
    }
    in_stack_0000003c = 0;
  }
  puStack_d0 = (undefined4 *)0xbe0701;
  FUN_00be32e0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26559 ; VA 0x00be0720 ; FUN_00be0720 */

undefined4 * __thiscall
FUN_00be0720(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_a8;
  int *piStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined4 uStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_24 [16];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_018016b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_6c;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_6c = param_4;
  uStack_64 = param_6;
  uStack_60 = param_7;
  piStack_68 = param_5;
  uStack_5c = param_8;
  puStack_80 = (undefined4 *)&stack0x00000024;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_84 = 0xbe079c;
  FUN_00be2ed0();
  uStack_44 = param_2;
  puStack_14 = &uStack_3c;
  *param_1 = 0;
  if (piStack_68 != (int *)0x0) {
    LOCK();
    piStack_68[2] = piStack_68[2] + 1;
    UNLOCK();
  }
  uStack_3c = uStack_6c;
  uStack_34 = uStack_64;
  uStack_30 = uStack_60;
  piStack_38 = piStack_68;
  uStack_2c = uStack_5c;
  puStack_80 = (undefined4 *)auStack_54;
  uStack_8 = 3;
  uStack_84 = 0xbe07f5;
  FUN_00be2ed0();
  puStack_80 = param_1 + 2;
  puStack_14 = &uStack_a8;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piStack_38[2] = piStack_38[2] + 1;
    UNLOCK();
  }
  uStack_a8 = uStack_3c;
  piStack_a4 = piStack_38;
  uStack_a0 = uStack_34;
  uStack_9c = uStack_30;
  uStack_98 = uStack_2c;
  uStack_8 = 5;
  FUN_00be2ed0(auStack_24);
  ppuVar4 = &PTR_FUN_0195f378;
  _uStack_8 = CONCAT31(uStack_7,4);
  cVar3 = FUN_00be1360();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  puStack_80 = (undefined4 *)0xbe0872;
  FUN_00a59a30();
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0xbe088a;
      (**(code **)(*piStack_38 + 4))();
    }
  }
  puStack_80 = (undefined4 *)0xbe0892;
  FUN_00a59a30();
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_68[2] + -1;
    piStack_68[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0xbe08a7;
      (**(code **)(*piStack_68 + 4))();
    }
  }
  puStack_80 = (undefined4 *)0xbe08af;
  FUN_00a59a30();
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_80 = (undefined4 *)0xbe08c3;
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26560 ; VA 0x00be08e0 ; FUN_00be08e0 */

undefined4 * __thiscall
FUN_00be08e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_90;
  int *piStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [16];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_018016f0;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_5c;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_5c = param_4;
  uStack_54 = param_6;
  piStack_58 = param_5;
  uStack_50 = param_7;
  puStack_70 = (undefined4 *)&stack0x0000001c;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_74 = 0xbe0956;
  FUN_00be2ed0();
  uStack_3c = param_2;
  puStack_14 = &uStack_34;
  *param_1 = 0;
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piStack_58[2] = piStack_58[2] + 1;
    UNLOCK();
  }
  uStack_34 = uStack_5c;
  uStack_2c = uStack_54;
  piStack_30 = piStack_58;
  uStack_28 = uStack_50;
  puStack_70 = (undefined4 *)auStack_4c;
  uStack_8 = 3;
  uStack_74 = 0xbe09a9;
  FUN_00be2ed0();
  puStack_70 = param_1 + 2;
  puStack_14 = &uStack_90;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piStack_30[2] = piStack_30[2] + 1;
    UNLOCK();
  }
  uStack_90 = uStack_34;
  piStack_8c = piStack_30;
  uStack_88 = uStack_2c;
  uStack_84 = uStack_28;
  uStack_8 = 5;
  FUN_00be2ed0(auStack_24);
  ppuVar4 = &PTR_FUN_0195f380;
  _uStack_8 = CONCAT31(uStack_7,4);
  cVar3 = FUN_00be14c0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  puStack_70 = (undefined4 *)0xbe0a20;
  FUN_00a59a30();
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[2] + -1;
    piStack_30[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_70 = (undefined4 *)0xbe0a38;
      (**(code **)(*piStack_30 + 4))();
    }
  }
  puStack_70 = (undefined4 *)0xbe0a40;
  FUN_00a59a30();
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_58[2] + -1;
    piStack_58[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_70 = (undefined4 *)0xbe0a55;
      (**(code **)(*piStack_58 + 4))();
    }
  }
  puStack_70 = (undefined4 *)0xbe0a5d;
  FUN_00a59a30();
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_70 = (undefined4 *)0xbe0a71;
      (**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26561 ; VA 0x00be0a90 ; FUN_00be0a90 */

void __thiscall
FUN_00be0a90(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801710;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uStack_40 = 0;
  uVar3 = param_1[0xc];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = param_1 + 0xe;
      uStack_50 = 0xbe0af8;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_1[0xe];
      uStack_34 = param_1[0xf];
      uStack_30 = param_1[0x10];
      uStack_2c = param_1[0x11];
      uStack_28 = *(undefined8 *)(param_1 + 0x12);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = param_1[4];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 6,&uStack_58,0);
    }
    else {
      uStack_58 = param_1[6];
      uStack_54 = param_1[7];
      uStack_50 = param_1[8];
      puStack_4c = (undefined4 *)param_1[9];
      uStack_48 = *(ulonglong *)(param_1 + 10);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(*param_4);
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = param_1[2];
  uVar5 = param_1[3];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar4,uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26562 ; VA 0x00be0bd0 ; FUN_00be0bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00be0bd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801740;
  pvStack_10 = ExceptionList;
  if (DAT_01ef6fa8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef71c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef71c0);
      if (DAT_01ef71c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PointsService",1,uStack_20,0,0,3,0,0);
        _DAT_01ef71b8 = RBX::Creator<class_RBX::PointsService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef6fb0,&DAT_01ef71b8);
        FUN_016f3654(FUN_01892790);
        FUN_016f37bf(&DAT_01ef71c0);
      }
    }
    DAT_01ef6fa8 = &DAT_01ef6fb0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef6fa8;
}



/* FUNCTION 26563 ; VA 0x00be0cd0 ; FUN_00be0cd0 */

void FUN_00be0cd0(void)

{
  int iVar1;
  
  if (DAT_01ef71c4 == 0) {
    iVar1 = FUN_00be0bd0();
    DAT_01ef71c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26564 ; VA 0x00be0cf0 ; FUN_00be0cf0 */

uint * FUN_00be0cf0(undefined4 *param_1,undefined4 *param_2,uint *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint auStack_90 [2];
  undefined auStack_88 [24];
  uint auStack_70 [2];
  undefined auStack_68 [24];
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801773;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar3 = param_1 + 2;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0xffffffff;
      uVar2 = puVar3[-2];
      auStack_50[0] = 0;
      if (uVar2 != 0) {
        auStack_50[0] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3,&uStack_48,0);
        }
        else {
          uStack_48 = *puVar3;
          uStack_44 = puVar3[1];
          uStack_40 = puVar3[2];
          uStack_3c = puVar3[3];
          uStack_38 = puVar3[4];
          uStack_34 = puVar3[5];
        }
      }
      if (param_3 != auStack_50) {
        auStack_90[0] = 0;
        uStack_8._0_1_ = 1;
        uStack_8._1_3_ = 0;
        FUN_005880d0(auStack_50);
        FUN_005880d0(param_3);
        FUN_005880d0(auStack_90);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (((auStack_90[0] != 0) && ((auStack_90[0] & 1) == 0)) &&
           (*(code **)(auStack_90[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_90[0] & 0xfffffffe))(auStack_88,auStack_88,2);
        }
      }
      uStack_8 = 3;
      if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
         (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_50[0] & 0xfffffffe))(&uStack_48,&uStack_48,2);
      }
      uVar2 = puVar3[6];
      uStack_8 = 0xffffffff;
      auStack_30[0] = 0;
      if (uVar2 != 0) {
        auStack_30[0] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 8,&uStack_28,0);
        }
        else {
          uStack_28 = puVar3[8];
          uStack_24 = puVar3[9];
          uStack_20 = puVar3[10];
          uStack_1c = puVar3[0xb];
          uStack_18 = puVar3[0xc];
          uStack_14 = puVar3[0xd];
        }
      }
      if (param_3 + 8 != auStack_30) {
        auStack_70[0] = 0;
        uStack_8._0_1_ = 5;
        uStack_8._1_3_ = 0;
        FUN_005880d0(auStack_30);
        FUN_005880d0(param_3 + 8);
        FUN_005880d0(auStack_70);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (auStack_70[0] != 0) {
          if (((auStack_70[0] & 1) == 0) && (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0))
          {
            (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
          }
          auStack_70[0] = 0;
        }
      }
      uStack_8 = 7;
      if (auStack_30[0] != 0) {
        if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
        }
        auStack_30[0] = 0;
      }
      param_3 = param_3 + 0x10;
      puVar1 = puVar3 + 0xe;
      puVar3 = puVar3 + 0x10;
    } while (puVar1 != param_2);
    ExceptionList = pvStack_10;
    return param_3;
  }
  return param_3;
}



/* FUNCTION 26565 ; VA 0x00be0f10 ; FUN_00be0f10 */

int __thiscall FUN_00be0f10(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01801788;
  pvStack_10 = ExceptionList;
  iVar7 = *param_1;
  iVar2 = param_1[1] - iVar7 >> 6;
  if (iVar2 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = param_1[2] - iVar7 >> 6;
  uVar5 = uVar1;
  if ((uVar3 <= 0x3ffffff - (uVar3 >> 1)) && (uVar5 = (uVar3 >> 1) + uVar3, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008c8200(uVar5);
  uVar3 = param_2 - iVar7 & 0xffffffc0;
  puVar6 = (undefined4 *)(uVar3 + iVar2);
  iStack_8 = 0;
  *puVar6 = 0;
  FUN_005880d0(param_3);
  iStack_8._0_1_ = 1;
  puVar6[8] = 0;
  FUN_005880d0(param_3 + 0x20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == param_1[1]) {
    FUN_00be10c0(*param_1,param_1[1],iVar2,param_1);
  }
  else {
    FUN_00be3ff0(*param_1,param_2,iVar2);
    FUN_00be3ff0(param_2,param_1[1],puVar6 + 0x10);
  }
  iVar7 = *param_1;
  if (iVar7 != 0) {
    iVar8 = param_1[1];
    if (iVar7 != iVar8) {
      do {
        FUN_008c3510();
        iVar7 = iVar7 + 0x40;
      } while (iVar7 != iVar8);
      iVar7 = *param_1;
    }
    uVar4 = param_1[2] - iVar7 & 0xffffffc0;
    iVar8 = iVar7;
    if (0xfff < uVar4) {
      iVar8 = *(int *)(iVar7 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar7 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar4);
  }
  *param_1 = iVar2;
  param_1[1] = uVar1 * 0x40 + iVar2;
  param_1[2] = uVar5 * 0x40 + iVar2;
  ExceptionList = pvStack_10;
  return *param_1 + uVar3;
}



/* FUNCTION 26566 ; VA 0x00be108d ; Catch_All@00be108d */

void Catch_All_00be108d(void)

{
  int unaff_EBP;
  
  FUN_00a59910(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26567 ; VA 0x00be10c0 ; FUN_00be10c0 */

uint * FUN_00be10c0(uint *param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_018017b0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (param_1 != param_2) {
    puVar5 = param_1 + 2;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = 0;
      uVar2 = puVar5[-2];
      if (uVar2 != 0) {
        *param_3 = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar5,param_3 + 2,0);
        }
        else {
          uVar2 = puVar5[1];
          uVar3 = puVar5[2];
          uVar4 = puVar5[3];
          param_3[2] = *puVar5;
          param_3[3] = uVar2;
          param_3[4] = uVar3;
          param_3[5] = uVar4;
          uVar2 = puVar5[5];
          param_3[6] = puVar5[4];
          param_3[7] = uVar2;
        }
      }
      param_3[8] = 0;
      uVar2 = puVar5[6];
      iStack_8._0_1_ = 1;
      if (uVar2 != 0) {
        param_3[8] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 8,param_3 + 10,0);
        }
        else {
          uVar2 = puVar5[9];
          uVar3 = puVar5[10];
          uVar4 = puVar5[0xb];
          param_3[10] = puVar5[8];
          param_3[0xb] = uVar2;
          param_3[0xc] = uVar3;
          param_3[0xd] = uVar4;
          uVar2 = puVar5[0xd];
          param_3[0xe] = puVar5[0xc];
          param_3[0xf] = uVar2;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_3 = param_3 + 0x10;
      puVar1 = puVar5 + 0xe;
      puVar5 = puVar5 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 26568 ; VA 0x00be11c0 ; FUN_00be11c0 */

undefined FUN_00be11c0(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_0000003c;
  int *in_stack_0000005c;
  undefined auStack_bc [48];
  uint uStack_8c;
  undefined auStack_84 [24];
  undefined4 auStack_6c [2];
  undefined auStack_64 [48];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018017ea;
  pvStack_10 = ExceptionList;
  auStack_6c[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00be24b0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_6c);
  uVar1 = auStack_6c[0];
  if (cVar2 == '\0') {
    FUN_00be24b0(auStack_64);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x58);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00be24b0(auStack_bc);
    }
    *in_stack_0000005c = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_8c != 0) {
      if (((uStack_8c & 1) == 0) && (*(code **)(uStack_8c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_8c & 0xfffffffe))(auStack_84,auStack_84,2);
      }
      uStack_8c = 0;
    }
    FUN_00be32e0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00be32e0();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00be32e0();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
    }
    in_stack_0000003c = 0;
  }
  FUN_00be32e0();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 26569 ; VA 0x00be1360 ; FUN_00be1360 */

undefined FUN_00be1360(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  undefined4 *in_stack_00000034;
  undefined auStack_74 [12];
  int *piStack_68;
  undefined4 auStack_44 [2];
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180182f;
  pvStack_10 = ExceptionList;
  auStack_44[0] = param_1;
  puStack_14 = &uStack_3c;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_3c = param_3;
  uStack_34 = param_5;
  uStack_30 = param_6;
  piStack_38 = param_4;
  uStack_2c = param_7;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00be2ed0(&stack0x00000024);
  uStack_8 = 2;
  cVar3 = FUN_00585a40(auStack_44);
  if (cVar3 == '\0') {
    FUN_00be2050(auStack_44);
    uStack_8 = 3;
    puStack_14 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8 = 4;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00be2050(auStack_74);
    }
    *in_stack_00000034 = uVar4;
    FUN_00a59a30();
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_68[2] + -1;
      piStack_68[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
    FUN_00a59a30();
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    FUN_00a59a30();
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_38[2] + -1;
      piStack_38[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
    uVar5 = 0;
  }
  FUN_00a59a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 26570 ; VA 0x00be14c0 ; FUN_00be14c0 */

undefined FUN_00be14c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined uVar6;
  int *in_stack_0000002c;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [16];
  undefined4 auStack_40 [2];
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180187f;
  pvStack_10 = ExceptionList;
  auStack_40[0] = param_1;
  puStack_14 = &uStack_38;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_38 = param_3;
  uStack_30 = param_5;
  piStack_34 = param_4;
  uStack_2c = param_6;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00be2ed0(&stack0x0000001c);
  uStack_8 = 2;
  cVar4 = FUN_00585a40(auStack_40);
  uVar3 = auStack_40[0];
  if (cVar4 == '\0') {
    puStack_14 = &uStack_60;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piStack_34[2] = piStack_34[2] + 1;
      UNLOCK();
    }
    uStack_60 = uStack_38;
    uStack_58 = uStack_30;
    piStack_5c = piStack_34;
    uStack_54 = uStack_2c;
    uStack_8 = 3;
    FUN_00be2ed0(auStack_28);
    uStack_8 = 4;
    puVar5 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8 = 5;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      puStack_18 = puVar5 + 2;
      *puStack_18 = 0;
      puVar5[3] = 0;
      if (piStack_5c != (int *)0x0) {
        LOCK();
        piStack_5c[2] = piStack_5c[2] + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_60;
      puVar5[3] = piStack_5c;
      puVar5[4] = uStack_58;
      puVar5[5] = uStack_54;
      uStack_8 = 6;
      FUN_00be2ed0(auStack_50);
    }
    *in_stack_0000002c = (int)puVar5;
    FUN_00a59a30();
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_5c[2] + -1;
      piStack_5c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
    FUN_00a59a30();
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    FUN_00a59a30();
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    uVar6 = 0;
  }
  FUN_00a59a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 26571 ; VA 0x00be16a0 ; FUN_00be16a0 */

undefined4 *
FUN_00be16a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,uint param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 *param_13,
            ulonglong param_14,uint param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined *param_20,undefined8 param_21)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint auStack_b0 [2];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  ulonglong uStack_98;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined8 uStack_78;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018018c0;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_90;
  puStack_18 = (undefined *)auStack_90;
  uStack_8 = 3;
  auStack_90[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_90;
  if (param_15 != 0) {
    auStack_90[0] = param_15;
    if ((param_15 & 1) == 0) {
      uStack_98 = ZEXT48(&uStack_88);
      puStack_9c = &param_17;
      uStack_a0 = 0xbe1708;
      ExceptionList = &pvStack_10;
      (**(code **)(param_15 & 0xfffffffe))();
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_88 = param_17;
      uStack_84 = param_18;
      uStack_80 = param_19;
      puStack_7c = (undefined4 *)param_20;
      uStack_78 = param_21;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_90;
    }
  }
  puStack_14 = (undefined *)puVar3;
  puStack_18 = (undefined *)auStack_b0;
  uStack_8._0_1_ = 4;
  auStack_b0[0] = 0;
  puVar3 = auStack_b0;
  if (param_8 != 0) {
    auStack_b0[0] = param_8;
    if ((param_8 & 1) == 0) {
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_a8,0);
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_a8 = param_10;
      uStack_a4 = param_11;
      uStack_a0 = param_12;
      puStack_9c = param_13;
      uStack_98 = param_14;
      puVar3 = auStack_b0;
    }
  }
  puStack_18 = (undefined *)puVar3;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  uVar4 = FUN_00be25d0(param_3,param_4,param_5,param_6,param_7);
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  uStack_78 = CONCAT44(uVar4,0xbe17c7);
  FUN_00be24b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_7c = (undefined4 *)auStack_30;
    uStack_78 = CONCAT44(2,puStack_7c);
    uStack_80 = 0xbe17e8;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_78 = CONCAT44(0xbe17fa,(undefined4)uStack_78);
  FUN_00be32e0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_78 = CONCAT44(0xbe1812,(undefined4)uStack_78);
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_78 = CONCAT44(0xbe1828,(undefined4)uStack_78);
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_78 = CONCAT44(0xbe1837,(undefined4)uStack_78);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_7c = &param_10;
    uStack_78 = CONCAT44(2,puStack_7c);
    uStack_80 = 0xbe1858;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_7c = &param_17;
    uStack_78 = CONCAT44(2,puStack_7c);
    uStack_80 = 0xbe1886;
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26572 ; VA 0x00be18a0 ; FUN_00be18a0 */

undefined4 *
FUN_00be18a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,uint param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined8 param_14)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined8 uStack_54;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018018f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_64,0);
    }
    else {
      uStack_64 = param_10;
      uStack_60 = param_11;
      uStack_5c = param_12;
      puStack_58 = (undefined4 *)param_13;
      uStack_54 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00be2250(param_3,param_4,param_5,param_6,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *param_1 = param_2;
  uStack_54 = CONCAT44(uVar3,0xbe1978);
  FUN_00be2170();
  uStack_54 = CONCAT44(0xbe1980,(undefined4)uStack_54);
  FUN_00be32e0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_54 = CONCAT44(0xbe1996,(undefined4)uStack_54);
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_54 = CONCAT44(0xbe19ad,(undefined4)uStack_54);
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_54 = CONCAT44(0xbe19bf,(undefined4)uStack_54);
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_58 = &param_10;
    uStack_54 = CONCAT44(2,puStack_58);
    uStack_5c = 0xbe19e3;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26573 ; VA 0x00be1a00 ; FUN_00be1a00 */

undefined4 *
FUN_00be1a00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 in_stack_0000002c;
  int *piStack_38;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801920;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00be2ed0(&stack0x00000020);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00be2790(param_3,param_4,param_5,param_6,param_7);
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *puVar3;
  param_1[3] = puVar3[1];
  param_1[4] = puVar3[2];
  param_1[5] = puVar3[3];
  param_1[6] = puVar3[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00be2ed0();
  FUN_00a59a30();
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_38 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  FUN_00a59a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26574 ; VA 0x00be1b30 ; FUN_00be1b30 */

undefined4 *
FUN_00be1b30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000028;
  int *piStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801950;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00be2ed0(&stack0x0000001c);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00be2390(param_3,param_4,param_5,param_6);
  *param_1 = param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *puVar3;
  param_1[3] = puVar3[1];
  param_1[4] = puVar3[2];
  param_1[5] = puVar3[3];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00be2ed0();
  FUN_00a59a30();
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[2] + -1;
    piStack_30[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  FUN_00a59a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26575 ; VA 0x00be1c50 ; FUN_00be1c50 */

void FUN_00be1c50(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int iStack_70;
  int iStack_6c;
  char cStack_68;
  int iStack_64;
  char acStack_60 [76];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801968;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff84;
  iStack_70 = -0x3ea8cf1e;
  iStack_6c = 0x7f0725e3;
  cStack_68 = '\0';
  iStack_64 = 0;
  acStack_60[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = iStack_64;
  do {
    iStack_64 = iVar3;
    if (*param_1 == iStack_70) {
LAB_00be1d48:
      if ((iStack_64 != 0) && (iStack_64 != -1)) {
        CloseHandle(iStack_64);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar3 = *param_1;
    if (iVar3 == 0) {
      *param_1 = iStack_6c;
      iVar3 = 0;
    }
    UNLOCK();
    if (iVar3 == 0) {
      if (iStack_64 == 0) {
        if (acStack_60[0] == '\0') {
          FUN_005881c0(acStack_60,param_1);
        }
        iVar3 = OpenEventA(0x100002,0,acStack_60);
        if ((iStack_64 != 0) && (iStack_64 != -1)) {
          CloseHandle(iStack_64);
        }
        iStack_64 = iVar3;
        if (iVar3 != 0) goto LAB_00be1cfe;
      }
      else {
LAB_00be1cfe:
        ResetEvent(iStack_64);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pcVar2 = (code *)*param_2;
      if (param_2[2] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[2] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar2)(param_2[1],param_2[2]);
      FUN_0057b500(param_1,&iStack_70);
      goto LAB_00be1d48;
    }
    if (cStack_68 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_68 = '\x01';
      if (*param_1 == iStack_70) goto LAB_00be1d48;
      if (iStack_64 != 0) goto LAB_00be1dc2;
      if (acStack_60[0] == '\0') {
        FUN_005881c0(acStack_60,param_1);
      }
      iVar3 = CreateEventA(0,1,0,acStack_60);
      if ((iStack_64 != 0) && (iStack_64 != -1)) {
        CloseHandle(iStack_64);
      }
    }
    else {
LAB_00be1dc2:
      WaitForSingleObjectEx(iStack_64,0xffffffff,0);
      iVar3 = iStack_64;
    }
  } while( true );
}



/* FUNCTION 26576 ; VA 0x00be1dd2 ; Catch_All@00be1dd2 */

void Catch_All_00be1dd2(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x6c);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26577 ; VA 0x00be1df0 ; FUN_00be1df0 */

int FUN_00be1df0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01eadd94,&LAB_00670c80);
  uVar2 = FUN_00675cb0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  if (*piVar3 == 0) {
    if (DAT_01ef71c4 == 0) {
      iVar4 = FUN_00be0bd0();
      DAT_01ef71c4 = *(int *)(iVar4 + 4);
    }
    piVar5 = (int *)FUN_008a9ba0(auStack_c,DAT_01ef71c4);
    iVar4 = *piVar5;
    iVar1 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar3 = iVar4;
    piVar5 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar3;
}



/* FUNCTION 26578 ; VA 0x00be1ed0 ; FUN_00be1ed0 */

undefined4 * __thiscall
FUN_00be1ed0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018019cb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00be0bd0();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundYieldFuncDesc<class_RBX::PointsService,int___cdecl(__int64),1>::
             vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088c8c0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088da50();
    iStack_e4 = 0;
    uStack_e0 = *puVar2;
    uStack_dc = puVar2[1];
    iStack_e4 = FUN_005c9e80();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26579 ; VA 0x00be2050 ; FUN_00be2050 */

undefined4 * __thiscall FUN_00be2050(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018019e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  uStack_8 = 0;
  FUN_00be2ed0(param_2 + 8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26580 ; VA 0x00be20e0 ; FUN_00be20e0 */

undefined4 * __thiscall FUN_00be20e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801a08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  uStack_8 = 0;
  FUN_00be2ed0(param_2 + 6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26581 ; VA 0x00be2170 ; FUN_00be2170 */

undefined4 * __thiscall FUN_00be2170(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_01801a28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26582 ; VA 0x00be2250 ; FUN_00be2250 */

undefined4 __thiscall
FUN_00be2250(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined8 param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801a58;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_34,0);
    }
    else {
      uStack_34 = param_9;
      uStack_30 = param_10;
      uStack_2c = param_11;
      puStack_28 = (undefined4 *)param_12;
      uStack_24 = param_13;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00be2bc0(param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_24 = CONCAT44(0xbe232b,(undefined4)uStack_24);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_24 = CONCAT44(0xbe2342,(undefined4)uStack_24);
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_24 = CONCAT44(0xbe2354,(undefined4)uStack_24);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_9;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xbe2378;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26583 ; VA 0x00be2390 ; FUN_00be2390 */

undefined4 FUN_00be2390(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801aa8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00be2ed0(&stack0x00000014);
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  piStack_14 = (int *)param_1;
  uStack_28 = param_1;
  piStack_24 = param_2;
  uStack_8._0_1_ = 3;
  FUN_00be2ed0(auStack_40);
  piVar3 = piStack_14;
  piVar1 = param_2 + 2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_18 = piStack_14;
  piStack_14 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00be28d0(piVar3,param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00be2ed0(auStack_34);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00a59a30();
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00a59a30();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00a59a30();
  ExceptionList = pvStack_10;
  return uStack_1c;
}



/* FUNCTION 26584 ; VA 0x00be24b0 ; FUN_00be24b0 */

undefined4 * __thiscall FUN_00be24b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801ad0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26585 ; VA 0x00be25d0 ; FUN_00be25d0 */

undefined4 __thiscall
FUN_00be25d0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
            uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined8 param_20)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801b08;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_14 != 0) {
    uStack_40 = param_14;
    if ((param_14 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_16;
      uStack_50 = 0xbe263d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_14 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_16;
      uStack_34 = param_17;
      uStack_30 = param_18;
      puStack_2c = (undefined4 *)param_19;
      uStack_28 = param_20;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 4;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_58,0);
    }
    else {
      uStack_58 = param_9;
      uStack_54 = param_10;
      uStack_50 = param_11;
      puStack_4c = param_12;
      uStack_48 = param_13;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00be2d10(param_2,param_3,param_4,param_5,param_6);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xbe26fc,(undefined4)uStack_28);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xbe2713,(undefined4)uStack_28);
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xbe2725,(undefined4)uStack_28);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_9;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xbe2746;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_16;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xbe2774;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26586 ; VA 0x00be2790 ; FUN_00be2790 */

int __thiscall
FUN_00be2790(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801b58;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00be2ed0(&stack0x00000018);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = (int *)param_2;
  uStack_28 = param_2;
  piStack_24 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00be2ed0(auStack_40);
  piVar3 = piStack_18;
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_1c = piStack_18;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00be28d0(piVar3,param_3,param_4,param_5);
  *(undefined4 *)(param_1 + 0x10) = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00be2ed0(auStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00a59a30();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00a59a30();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00a59a30();
  ExceptionList = pvStack_10;
  return iStack_14;
}



/* FUNCTION 26587 ; VA 0x00be28d0 ; FUN_00be28d0 */

undefined4 * __thiscall
FUN_00be28d0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 26588 ; VA 0x00be2950 ; FUN_00be2950 */

undefined4 * __thiscall
FUN_00be2950(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 26589 ; VA 0x00be2a70 ; FUN_00be2a70 */

int __thiscall
FUN_00be2a70(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined8 param_13)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801b90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00be2950(param_2,param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_7 != 0) {
    *(uint *)(param_1 + 0x10) = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,param_1 + 0x18,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x18) = param_9;
      *(undefined4 *)(param_1 + 0x1c) = param_10;
      *(undefined4 *)(param_1 + 0x20) = param_11;
      *(undefined4 *)(param_1 + 0x24) = param_12;
      *(undefined8 *)(param_1 + 0x28) = param_13;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_7 & 0xfffffffe))(&param_9,&param_9,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26590 ; VA 0x00be2bc0 ; FUN_00be2bc0 */

int __thiscall
FUN_00be2bc0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined8 param_13)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801bc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00be2950(param_2,param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_7 != 0) {
    *(uint *)(param_1 + 0x10) = param_7;
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,param_1 + 0x18,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x18) = param_9;
      *(undefined4 *)(param_1 + 0x1c) = param_10;
      *(undefined4 *)(param_1 + 0x20) = param_11;
      *(undefined4 *)(param_1 + 0x24) = param_12;
      *(undefined8 *)(param_1 + 0x28) = param_13;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_7 & 0xfffffffe))(&param_9,&param_9,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26591 ; VA 0x00be2d10 ; FUN_00be2d10 */

int __thiscall
FUN_00be2d10(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
            uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined8 param_20)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801bf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_38,0);
    }
    else {
      uStack_38 = param_9;
      uStack_34 = param_10;
      uStack_30 = param_11;
      puStack_2c = param_12;
      uStack_28 = param_13;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  FUN_00be2a70(param_2,param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x30) = 0;
  if (param_14 != 0) {
    *(uint *)(param_1 + 0x30) = param_14;
    if ((param_14 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x38);
      puStack_2c = &param_16;
      uStack_30 = 0xbe2e15;
      (**(code **)(param_14 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x38) = param_16;
      *(undefined4 *)(param_1 + 0x3c) = param_17;
      *(undefined4 *)(param_1 + 0x40) = param_18;
      *(undefined4 *)(param_1 + 0x44) = param_19;
      *(undefined8 *)(param_1 + 0x48) = param_20;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xbe2e35,(undefined4)uStack_28);
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xbe2e51,(undefined4)uStack_28);
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xbe2e63,(undefined4)uStack_28);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_9;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xbe2e88;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_16;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xbe2eb6;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26592 ; VA 0x00be2ed0 ; FUN_00be2ed0 */

int * __thiscall FUN_00be2ed0(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801c10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = param_2[1] - *param_2 >> 6;
  if (uVar2 != 0) {
    if (0x3ffffff < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_008c8200(uVar2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = uVar2 * 0x40 + *param_1;
    uStack_8 = 0;
    iVar1 = FUN_00be10c0(*param_2,param_2[1],iVar1,param_1);
    param_1[1] = iVar1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26593 ; VA 0x00be2f62 ; Catch_All@00be2f62 */

void Catch_All_00be2f62(void)

{
  FUN_00a59a30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26594 ; VA 0x00be2f80 ; FUN_00be2f80 */

undefined4 * __fastcall FUN_00be2f80(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801c75;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::PointsService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00be0bd0();
  param_1[3] = uVar1;
  *param_1 = RBX::PointsService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  *(undefined *)(param_1 + 0x19) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x1a] = uVar1;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x3f800000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("PointsService",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26595 ; VA 0x00be30d0 ; FUN_00be30d0 */

void __fastcall FUN_00be30d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PointsService>::vftable;
  uVar1 = FUN_00be0bd0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26596 ; VA 0x00be3110 ; FUN_00be3110 */

void __fastcall FUN_00be3110(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_00be32e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26597 ; VA 0x00be3170 ; FUN_00be3170 */

void FUN_00be3170(void)

{
  FUN_00be32e0();
  return;
}



/* FUNCTION 26598 ; VA 0x00be3180 ; FUN_00be3180 */

int __fastcall FUN_00be3180(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a59a30();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00be319f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 26599 ; VA 0x00be31b0 ; FUN_00be31b0 */

int __fastcall FUN_00be31b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a59a30();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00be31cf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 26600 ; VA 0x00be31e0 ; thunk_FUN_00be32e0 */

code * __fastcall thunk_FUN_00be32e0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 26601 ; VA 0x00be31f0 ; FUN_00be31f0 */

int __fastcall FUN_00be31f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a59a30();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00be320f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 26602 ; VA 0x00be3220 ; FUN_00be3220 */

void __fastcall FUN_00be3220(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x30);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x38,param_1 + 0x38,2);
      }
    }
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_00be32e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26603 ; VA 0x00be3280 ; FUN_00be3280 */

int __fastcall FUN_00be3280(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a59a30();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00be329f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 26604 ; VA 0x00be32b0 ; FUN_00be32b0 */

void __fastcall FUN_00be32b0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00a59a30();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 26605 ; VA 0x00be32e0 ; FUN_00be32e0 */

code * __fastcall FUN_00be32e0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 0xc);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      puVar1 = (uint *)(piVar5 + 2);
      uVar3 = *puVar1;
      pcVar6 = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar2 = piVar5 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 26606 ; VA 0x00be3380 ; FUN_00be3380 */

void __fastcall FUN_00be3380(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00be4d30(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26607 ; VA 0x00be3400 ; FUN_00be3400 */

void __fastcall FUN_00be3400(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00be4d30(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 26608 ; VA 0x00be3410 ; FUN_00be3410 */

void FUN_00be3410(void)

{
  FUN_00a59a30();
  return;
}



/* FUNCTION 26609 ; VA 0x00be3420 ; FUN_00be3420 */

int * __thiscall FUN_00be3420(int *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iStack_18;
  
  if (param_1 != param_2) {
    iVar2 = param_2[1];
    iVar7 = *param_2;
    iVar3 = param_1[1];
    iVar6 = *param_1;
    uVar5 = iVar2 - iVar7 >> 6;
    uVar4 = param_1[2] - iVar6 >> 6;
    uVar1 = iVar3 - iVar6 >> 6;
    if (uVar4 < uVar5) {
      if (uVar5 < 0x4000000) {
        uVar1 = uVar5;
        if ((uVar4 <= 0x3ffffff - (uVar4 >> 1)) && (uVar1 = (uVar4 >> 1) + uVar4, uVar1 < uVar5)) {
          uVar1 = uVar5;
        }
        if (iVar6 != 0) {
          if (iVar6 != iVar3) {
            do {
              FUN_008c3510();
              iVar6 = iVar6 + 0x40;
            } while (iVar6 != iVar3);
            iVar6 = *param_1;
          }
          FUN_0089eda0(iVar6,uVar4);
        }
        FUN_00be3f90(uVar1);
        iVar2 = FUN_00be10c0(iVar7,iVar2,*param_1,param_1);
        param_1[1] = iVar2;
        return param_1;
      }
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iStack_18._1_3_ = (uint3)(param_1[2] - iVar6 >> 0xe);
    iStack_18 = (uint)iStack_18._1_3_ << 8;
    if (uVar1 < uVar5) {
      iVar3 = uVar1 * 0x40 + iVar7;
      FUN_00be0cf0(iVar7,iVar3,iVar6,iStack_18);
      iVar2 = FUN_00be10c0(iVar3,iVar2,param_1[1],param_1);
      param_1[1] = iVar2;
      return param_1;
    }
    FUN_00be0cf0(iVar7,iVar2,iVar6,iStack_18);
    iVar2 = param_1[1];
    iVar6 = uVar5 * 0x40 + iVar6;
    for (iVar7 = iVar6; iVar7 != iVar2; iVar7 = iVar7 + 0x40) {
      FUN_008c3510();
    }
    param_1[1] = iVar6;
  }
  return param_1;
}



/* FUNCTION 26610 ; VA 0x00be3570 ; FUN_00be3570 */

int * __thiscall FUN_00be3570(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801c88;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = uVar4;
  if (((int)uVar4 < 1) && ((int)uVar4 < 0)) {
    uVar8 = ~uVar4;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar5 ^ uVar8;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x30);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 26611 ; VA 0x00be37a0 ; FUN_00be37a0 */

/* WARNING: Removing unreachable block (ram,0x00be37fa) */
/* WARNING: Removing unreachable block (ram,0x00be380a) */
/* WARNING: Removing unreachable block (ram,0x00be3810) */

void __fastcall FUN_00be37a0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801cb0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26612 ; VA 0x00be3855 ; Catch@00be3855 */

undefined * Catch_00be3855(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00be3866;
}



/* FUNCTION 26613 ; VA 0x00be3880 ; FUN_00be3880 */

int __thiscall FUN_00be3880(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016790b0();
  FUN_016790b0();
  iVar2 = *(int *)(param_1 + 0x88);
  if (iVar2 != 0) {
    uVar4 = (*(int *)(param_1 + 0x90) - iVar2 >> 3) * 8;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    *(undefined4 *)(param_1 + 0x88) = 0;
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0x90) = 0;
  }
  FUN_00be3380();
  LOCK();
  iVar2 = *(int *)(param_1 + 0x60);
  *(int *)(param_1 + 0x60) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar2 = *(int *)(param_1 + 0x58);
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26614 ; VA 0x00be39a0 ; FUN_00be39a0 */

void FUN_00be39a0(undefined4 param_1,int *param_2,undefined4 *param_3,int *param_4,uint param_5)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined4 ***pppuVar6;
  int in_stack_00000024;
  uint in_stack_00000028;
  uint in_stack_0000002c;
  uint in_stack_0000004c;
  char *pcVar7;
  undefined4 uStack_6c;
  int *piStack_68;
  undefined4 *puStack_64;
  int *piStack_60;
  undefined4 *puStack_5c;
  undefined4 **ppuStack_58;
  undefined4 **appuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  int aiStack_30 [2];
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801da0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffac;
  uStack_8 = 0;
  ppuStack_58 = (undefined4 **)&iStack_28;
  puStack_5c = (undefined4 *)0xbe39d4;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 5;
  if (iStack_28 == 0) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_01675640(&uStack_6c,"%s failed because could not lock datamodel in response.",param_3);
    FUN_005e65e0();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3d52;
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppuStack_58 = (undefined4 **)0xbe3d62;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3d77;
        (**(code **)(*param_2 + 4))();
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar4 = param_4[1] + -1;
      param_4[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3d8d;
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppuStack_58 = (undefined4 **)0xbe3d9c;
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 1;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < in_stack_00000028) {
      ppuStack_58 = (undefined4 **)(in_stack_00000028 + 1);
      uVar5 = param_5;
      if (0xfff < ppuStack_58) {
        uVar5 = *(uint *)(param_5 - 4);
        ppuStack_58 = (undefined4 **)(in_stack_00000028 + 0x24);
        if (0x1f < (param_5 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          ppuStack_58 = (undefined4 **)&UNK_00be3e4a;
          uStack_8._0_1_ = uVar2;
          FUN_017167a3();
        }
      }
      piStack_60 = (int *)0xbe3dcd;
      puStack_5c = (undefined4 *)uVar5;
      FUN_01674ea0();
    }
    in_stack_00000024 = 0;
    in_stack_00000028 = 0xf;
    param_5 = param_5 & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    if (in_stack_0000002c != 0) {
      if (((in_stack_0000002c & 1) == 0) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        piStack_60 = (int *)&stack0x00000034;
        ppuStack_58 = (undefined4 **)0x2;
        puStack_64 = (undefined4 *)0xbe3e03;
        puStack_5c = piStack_60;
        (**(code **)(in_stack_0000002c & 0xfffffffe))();
      }
      in_stack_0000002c = 0;
    }
    uStack_8 = 0xf;
LAB_00be3e14:
    if (((in_stack_0000004c != 0) && ((in_stack_0000004c & 1) == 0)) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      piStack_60 = (int *)&stack0x00000054;
      ppuStack_58 = (undefined4 **)0x2;
      puStack_64 = (undefined4 *)0xbe3e31;
      puStack_5c = piStack_60;
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return;
  }
  ppuStack_58 = (undefined4 **)(iStack_28 + 0xc);
  puStack_5c = (undefined4 *)0xbe39ec;
  iVar4 = FUN_00be1df0();
  if (iVar4 == 0) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_01675640(&uStack_6c,"%s failed because PointsService is unavailable.",param_3);
    FUN_005e65e0();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_24[1] + -1;
      piStack_24[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3a37;
        (**(code **)*piStack_24)();
        LOCK();
        iVar4 = piStack_24[2] + -1;
        piStack_24[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppuStack_58 = (undefined4 **)0xbe3a47;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3a5c;
        (**(code **)(*param_2 + 4))();
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar4 = param_4[1] + -1;
      param_4[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3a72;
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          ppuStack_58 = (undefined4 **)0xbe3a81;
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    ppuStack_58 = (undefined4 **)0xbe3a89;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (in_stack_0000002c != 0) {
      if (((in_stack_0000002c & 1) == 0) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        piStack_60 = (int *)&stack0x00000034;
        ppuStack_58 = (undefined4 **)0x2;
        puStack_64 = (undefined4 *)0xbe3aaa;
        puStack_5c = piStack_60;
        (**(code **)(in_stack_0000002c & 0xfffffffe))();
      }
      in_stack_0000002c = 0;
    }
    uStack_8 = 7;
    goto LAB_00be3e14;
  }
  if (in_stack_00000024 == 0) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_01675640(&uStack_6c,"%s failed because no valid response or exception.",param_3);
    FUN_005e65e0();
    ppuStack_58 = (undefined4 **)0xbe3cb5;
    FUN_00550b30();
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[2] + -1;
      param_2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        ppuStack_58 = (undefined4 **)0xbe3ccb;
        (**(code **)(*param_2 + 4))();
      }
    }
    ppuStack_58 = (undefined4 **)0xbe3cd3;
    FUN_00550b30();
    ppuStack_58 = (undefined4 **)0xbe3cdb;
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (in_stack_0000002c != 0) {
      if (((in_stack_0000002c & 1) == 0) &&
         (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
        piStack_60 = (int *)&stack0x00000034;
        ppuStack_58 = (undefined4 **)0x2;
        puStack_64 = (undefined4 *)0xbe3cfc;
        puStack_5c = piStack_60;
        (**(code **)(in_stack_0000002c & 0xfffffffe))();
      }
      in_stack_0000002c = 0;
    }
    uStack_8 = 0xd;
    goto LAB_00be3e14;
  }
  ppuStack_58 = (undefined4 **)aiStack_30;
  puStack_5c = (undefined4 *)0xbe3ad3;
  FUN_00563d90();
  puStack_5c = (undefined4 *)0x0;
  piStack_60 = aiStack_30;
  uStack_8._0_1_ = 8;
  puStack_64 = &param_5;
  piStack_68 = (int *)0xbe3ae6;
  cVar3 = FUN_0098f070();
  if (cVar3 == '\0') {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    pcVar7 = "%s failed because could not parse JSON response";
  }
  else {
    if ((aiStack_30[0] != 0) && (*(int *)(aiStack_30[0] + 8) != 0)) {
      uStack_18 = 0;
      uStack_38 = 0;
      uStack_34 = 0xf;
      appuStack_48[0] = (undefined4 **)((uint)appuStack_48[0] & 0xffffff00);
      ppuStack_58 = appuStack_48;
      uStack_8._0_1_ = 10;
      puStack_5c = &uStack_18;
      piStack_68 = aiStack_30;
      uStack_6c = 0xbe3bb3;
      FUN_00557fc0();
      piStack_68 = (int *)0xbe3bb8;
      cVar3 = FUN_00be7330();
      if (cVar3 == '\0') {
        pppuVar6 = appuStack_48;
        if (0xf < uStack_34) {
          pppuVar6 = (undefined4 ***)appuStack_48[0];
        }
        if (0xf < (uint)param_3[5]) {
          param_3 = (undefined4 *)*param_3;
        }
        FUN_01675640(&uStack_6c,"%s failed because %s",param_3,pppuVar6);
        FUN_005e65e0();
        ppuStack_58 = (undefined4 **)0xbe3bfa;
        FUN_005507b0();
      }
      else {
        ppuStack_58 = (undefined4 **)0xbe3c1f;
        FUN_005507b0();
        ppuStack_58 = (undefined4 **)uStack_18;
        uStack_8._0_1_ = 8;
        uStack_8._1_3_ = 0;
        puStack_5c = (undefined4 *)0xbe3c31;
        FUN_008927d0();
      }
      ppuStack_58 = (undefined4 **)0xbe3c02;
      FUN_00550b30();
      ppuStack_58 = (undefined4 **)0xbe3c0a;
      FUN_00550b30();
      ppuStack_58 = (undefined4 **)0xbe3c12;
      FUN_0056c200();
      goto LAB_00be3b3a;
    }
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    pcVar7 = "%s failed because JSON table is empty or null.";
  }
  FUN_01675640(&uStack_6c,pcVar7,param_3);
  FUN_005e65e0();
  ppuStack_58 = (undefined4 **)0xbe3b1c;
  FUN_00550b30();
  ppuStack_58 = (undefined4 **)0xbe3b24;
  FUN_00550b30();
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[2] + -1;
    param_2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      ppuStack_58 = (undefined4 **)0xbe3b3a;
      (**(code **)(*param_2 + 4))();
    }
  }
LAB_00be3b3a:
  ppuStack_58 = (undefined4 **)0xbe3b42;
  FUN_00550b30();
  ppuStack_58 = (undefined4 **)0xbe3b4a;
  FUN_005507b0();
  ppuStack_58 = (undefined4 **)0xbe3b52;
  FUN_00550990();
  ppuStack_58 = (undefined4 **)0xbe3b5a;
  FUN_00550990();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26615 ; VA 0x00be3c33 ; Catch@00be3c33 */

undefined4 Catch_00be3c33(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  undefined auStack_18 [20];
  undefined4 uStack_4;
  
  uStack_4 = 0xbe3c3b;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  piVar2 = *(int **)(unaff_EBP + 0x10);
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  FUN_01675640(auStack_18,"%s failed because %s",piVar2,uVar1);
  FUN_005e65e0();
  return 0xbe3bfa;
}



/* FUNCTION 26616 ; VA 0x00be3e50 ; FUN_00be3e50 */

void FUN_00be3e50(undefined4 param_1,int *param_2,undefined4 *param_3,int *param_4,
                 undefined4 *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int in_stack_00000024;
  uint in_stack_00000028;
  uint in_stack_0000002c;
  undefined auStack_34 [8];
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_01801dd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (in_stack_00000024 == 0) {
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    ExceptionList = &pvStack_10;
    FUN_01675640(auStack_34,"%s failed because no valid response or exception.",param_3);
  }
  else {
    puVar3 = &param_5;
    if (0xf < in_stack_00000028) {
      puVar3 = param_5;
    }
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    ExceptionList = &pvStack_10;
    FUN_01675640(auStack_34,"%s failed because %s",param_3,puVar3);
  }
  FUN_005e65e0();
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[2] + -1;
    param_2[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_20 = (undefined *)0xbe3ee1;
      (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_20 = (undefined *)0xbe3ef7;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_20 = (undefined *)0xbe3f06;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000028) {
    puStack_20 = (undefined *)(in_stack_00000028 + 1);
    puStack_24 = param_5;
    if (0xfff < puStack_20) {
      puStack_24 = (undefined4 *)param_5[-1];
      puStack_20 = (undefined *)(in_stack_00000028 + 0x24);
      if (0x1f < (uint)((int)param_5 + (-4 - (int)puStack_24))) {
                    /* WARNING: Subroutine does not return */
        puStack_20 = &UNK_00be3f88;
        FUN_017167a3();
      }
    }
    puStack_28 = (undefined *)0xbe3f37;
    FUN_01674ea0();
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = (undefined4 *)((uint)param_5 & 0xffffff00);
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &stack0x00000034;
    puStack_20 = (undefined *)0x2;
    uStack_2c = 0xbe3f70;
    puStack_24 = (undefined4 *)puStack_28;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26617 ; VA 0x00be3f90 ; FUN_00be3f90 */

undefined4 __thiscall FUN_00be3f90(int *param_1,uint param_2)

{
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (param_2 < 0x4000000) {
    iVar1 = FUN_008c8200(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = param_2 * 0x40 + *param_1;
    return 1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 26618 ; VA 0x00be3ff0 ; FUN_00be3ff0 */

undefined4 * FUN_00be3ff0(int param_1,int param_2,undefined4 *param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01801df0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      *param_3 = 0;
      FUN_005880d0(param_1);
      uStack_8 = 1;
      param_3[8] = 0;
      FUN_005880d0(param_1 + 0x20);
      param_3 = param_3 + 0x10;
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 26619 ; VA 0x00be4080 ; FUN_00be4080 */

void __thiscall FUN_00be4080(int param_1,int param_2,int *param_3,int param_4,uint param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  uint in_stack_00000030;
  char *pcVar6;
  char acStack_d8 [4];
  undefined4 uStack_d4;
  undefined4 *puStack_d0;
  undefined *puStack_cc;
  undefined4 *puStack_c8;
  code **ppcStack_c4;
  undefined auStack_50 [12];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [12];
  int iStack_28;
  undefined uStack_24;
  int iStack_20;
  code *pcStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801e4b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((DAT_01d67fd8 == '\0') && (DAT_01f2ddc0 != 0)) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(&DAT_01d67fc0);
    FUN_005e65e0();
  }
  else {
    ppcStack_c4 = (code **)0xbe40df;
    ExceptionList = &pvStack_10;
    cVar4 = FUN_00be4800();
    if (cVar4 == '\0') {
      puStack_c8 = (undefined4 *)0x0;
      ppcStack_c4 = (code **)0xf;
      acStack_d8[0] = cVar4;
      FUN_005542c0("PointsService requires loadstring to be disabled.",0x31);
      FUN_005e65e0();
    }
    else {
      ppcStack_c4 = (code **)0x1;
      puStack_cc = (undefined *)0xbe4119;
      puStack_c8 = (undefined4 *)param_1;
      cVar4 = FUN_00971ce0();
      iVar3 = param_4;
      piVar2 = param_3;
      if (cVar4 == '\0') {
        pcVar6 = "%s failed because not called from server script.";
      }
      else if (((int)param_3 < 1) && (((int)param_3 < 0 || (param_2 == 0)))) {
        pcVar6 = "%s failed because userId <= 0, please supply a positive userId.";
      }
      else if (param_4 == 0) {
        pcVar6 = "%s failed because trying to award zero points, please supply a non-zero amount.";
      }
      else {
        puStack_c8 = (undefined4 *)0xbe416f;
        ppcStack_c4 = (code **)param_1;
        iStack_20 = FUN_008f7870();
        if (iStack_20 != 0) {
          iStack_28 = param_1 + 0x5c;
          uStack_24 = 0;
          ppcStack_c4 = (code **)0xbe41b0;
          FUN_00587410();
          iVar5 = param_1 + 0x65 + (uint)*(byte *)(param_1 + 100);
          uStack_8._0_1_ = 2;
          ppcStack_c4 = (code **)(-(uint)(iVar5 != 0) & iVar5 + 1U);
          puStack_c8 = &param_2;
          puStack_cc = (undefined *)
                       (((uint)piVar2 >> 2) + (int)piVar2 * 0x40 + param_2 ^ (uint)piVar2);
          puStack_d0 = &param_4;
          uStack_d4 = 0xbe41e9;
          FUN_00606ff0();
          if (param_4 == 0) {
            pcStack_1c = (code *)0x0;
            iStack_18 = 0;
            piStack_14 = (int *)0x0;
            ppcStack_c4 = (code **)&stack0x00000030;
            uStack_8._0_1_ = 4;
            puStack_c8 = &param_5;
            puStack_cc = (undefined *)0xbe4257;
            ppcStack_c4 = (code **)FUN_00be04f0();
            uStack_8._0_1_ = 5;
            puStack_c8 = (undefined4 *)0xbe4264;
            FUN_00be72a0();
            uStack_8._0_1_ = 4;
            ppcStack_c4 = (code **)0xbe4273;
            FUN_008c3510();
            ppcStack_c4 = &pcStack_1c;
            puStack_c8 = (undefined4 *)0xbe427f;
            FUN_00be2ed0();
            ppcStack_c4 = (code **)auStack_34;
            uStack_8._0_1_ = 6;
            puStack_c8 = (undefined4 *)0xbe4292;
            FUN_00be2ed0();
            uStack_44 = 0;
            uStack_40 = 0;
            uStack_3c = 0;
            uStack_38 = 0;
            ppcStack_c4 = (code **)0xbe42a1;
            FUN_00a59a30();
            ppcStack_c4 = (code **)&param_2;
            uStack_8._0_1_ = 7;
            puStack_c8 = (undefined4 *)0xbe42b1;
            iVar5 = FUN_00be3570();
            ppcStack_c4 = (code **)auStack_50;
            *(int *)(iVar5 + 8) = iVar3;
            puStack_c8 = (undefined4 *)0xbe42c5;
            FUN_00be3420();
            *(ulonglong *)(iVar5 + 0x18) = CONCAT44(uStack_40,uStack_44);
            *(ulonglong *)(iVar5 + 0x20) = CONCAT44(uStack_38,uStack_3c);
            ppcStack_c4 = (code **)0xbe42e1;
            FUN_00a59a30();
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            ppcStack_c4 = (code **)0xbe42ed;
            FUN_00a59a30();
          }
          else {
            *(int *)(param_4 + 0x10) = *(int *)(param_4 + 0x10) + iVar3;
            *(undefined8 *)(param_4 + 0x28) = 0;
            ppcStack_c4 = (code **)&stack0x00000030;
            puStack_c8 = &param_5;
            puStack_cc = (undefined *)0xbe420e;
            ppcStack_c4 = (code **)FUN_00be04f0();
            uStack_8._0_1_ = 3;
            puStack_c8 = (undefined4 *)0xbe421a;
            FUN_00be72a0();
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            ppcStack_c4 = (code **)0xbe4226;
            FUN_008c3510();
          }
          ppcStack_c4 = (code **)iStack_20;
          puStack_c8 = &param_2;
          puStack_cc = (undefined *)0xbe42f9;
          FUN_005e5de0();
          piVar2 = param_3;
          if (param_3 != (int *)0x0) {
            LOCK();
            param_3[2] = param_3[2] + 1;
            UNLOCK();
          }
          param_4 = param_2;
          if (param_3 != (int *)0x0) {
            piVar1 = param_3 + 2;
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = iVar3 + -1;
            UNLOCK();
            if (iVar3 + -1 == 0) {
              ppcStack_c4 = (code **)0xbe432f;
              (**(code **)(*param_3 + 4))();
            }
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = iVar3 + -1;
            UNLOCK();
            if (iVar3 + -1 == 0) {
              ppcStack_c4 = (code **)0xbe433e;
              (**(code **)(*piVar2 + 4))();
            }
          }
          pcStack_1c = FUN_00be7900;
          piVar1 = piVar2 + 2;
          if (piVar2 != (int *)0x0) {
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          piStack_14 = piVar2;
          iStack_18 = param_4;
          if (piVar2 != (int *)0x0) {
            LOCK();
            iVar3 = *piVar1;
            *piVar1 = iVar3 + -1;
            UNLOCK();
            if (iVar3 + -1 == 0) {
              ppcStack_c4 = (code **)0xbe436b;
              (**(code **)(*piVar2 + 4))();
            }
          }
          if (param_3 != (int *)0x0) {
            LOCK();
            piVar2 = param_3 + 2;
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              ppcStack_c4 = (code **)0xbe437f;
              (**(code **)(*param_3 + 4))();
            }
          }
          ppcStack_c4 = &pcStack_1c;
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          puStack_c8 = (undefined4 *)&DAT_01ef6fa0;
          puStack_cc = (undefined *)0xbe4391;
          FUN_00be1c50();
          ppcStack_c4 = (code **)0xbe439c;
          FUN_0056b730();
          ppcStack_c4 = (code **)0xbe43a4;
          FUN_00550b60();
          goto LAB_00be43a4;
        }
        pcVar6 = "%s failed because of null datamodel.";
      }
      FUN_01675640(acStack_d8,pcVar6,"PointsService:AwardPoints");
      FUN_005e65e0();
    }
  }
LAB_00be43a4:
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      puStack_cc = &stack0x00000018;
      ppcStack_c4 = (code **)0x2;
      puStack_d0 = (undefined4 *)0xbe43c5;
      puStack_c8 = (undefined4 *)puStack_cc;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    puStack_cc = &stack0x00000038;
    ppcStack_c4 = (code **)0x2;
    puStack_d0 = (undefined4 *)0xbe43f3;
    puStack_c8 = (undefined4 *)puStack_cc;
    (**(code **)(in_stack_00000030 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26620 ; VA 0x00be4410 ; FUN_00be4410 */

undefined * FUN_00be4410(undefined *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801e68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0167e9f0();
  uStack_8 = 0;
  FUN_01681c30();
  FUN_016817b0(PTR_s_amount_01d67fe4,param_2);
  FUN_01681200();
  uVar1 = FUN_01681c00();
  uVar2 = FUN_01680fc0();
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(uVar2,uVar1);
  FUN_0167ec80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26621 ; VA 0x00be44b0 ; FUN_00be44b0 */

void FUN_00be44b0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e30;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef6f94);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xbe4535;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_008bd490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xbe4617;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xbe4637);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26622 ; VA 0x00be4650 ; FUN_00be4650 */

void FUN_00be4650(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef70;
  pvStack_10 = ExceptionList;
  pcStack_18 = param_2;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef6f94);
  uVar1 = *param_5;
  uStack_14 = *param_4;
  uVar2 = param_4[1];
  auStack_70[0] = 0;
  uVar3 = *param_7;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_70;
  puVar5 = auStack_70;
  if (uVar3 != 0) {
    auStack_70[0] = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_7 + 2;
      uStack_80 = 0xbe46dd;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
      puVar4 = (uint *)puStack_20;
      puVar5 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_7[2];
      uStack_64 = param_7[3];
      uStack_60 = param_7[4];
      uStack_5c = param_7[5];
      uStack_58 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
      puVar4 = auStack_70;
      puVar5 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar5;
  puStack_20 = (undefined *)puVar4;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar3 = *param_6;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_6 + 2);
    }
    else {
      uStack_ac = param_6[2];
      uStack_a8 = param_6[3];
      uStack_a4 = param_6[4];
      uStack_a0 = param_6[5];
      uStack_9c = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960050();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xbe47bf;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uVar2,uStack_14);
  uStack_a0 = 0xbe47e2;
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26623 ; VA 0x00be4800 ; FUN_00be4800 */

undefined4 __fastcall FUN_00be4800(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
    return 1;
  }
  if (iVar2 != -0xc) {
    FUN_005789c0(&DAT_01eaddc4,&LAB_00670cf0);
    uVar3 = FUN_00676030();
    piVar4 = (int *)FUN_008aa140(uVar3);
    if (*piVar4 == 0) {
      uVar3 = FUN_00b624e0();
      piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
      iVar2 = *piVar5;
      iVar1 = piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      *piVar4 = iVar2;
      piVar5 = (int *)piVar4[1];
      piVar4[1] = iVar1;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar5 = piStack_8 + 2;
          iVar2 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
    }
    if ((*piVar4 != 0) && (*(char *)(*piVar4 + 0x5c) == '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 26624 ; VA 0x00be48e0 ; FUN_00be48e0 */

undefined4 * __thiscall
FUN_00be48e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801eb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00be4d80;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26625 ; VA 0x00be4a90 ; FUN_00be4a90 */

undefined4 * FUN_00be4a90(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006727a0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26626 ; VA 0x00be4b00 ; FUN_00be4b00 */

void __thiscall FUN_00be4b00(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_005c9cc0();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26627 ; VA 0x00be4d30 ; FUN_00be4d30 */

int __thiscall FUN_00be4d30(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00a59a30();
    FUN_01674ea0(puVar1,0x30);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 26628 ; VA 0x00be4d80 ; FUN_00be4d80 */

void FUN_00be4d80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f87da;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_360 = FUN_0088da50();
  uStack_358 = param_2;
  uStack_35c = 0;
  uStack_354 = param_3;
  uStack_35c = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_290 = FUN_0088c8c0();
  uStack_28c = 0;
  uStack_288 = param_4;
  uStack_28c = FUN_005c9cc0();
  iStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_5;
  uStack_1bc = FUN_005c9cc0();
  iStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_005c9cc0();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,piVar1);
  iStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 6;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  iStack_8 = 7;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26629 ; VA 0x00be4f10 ; FUN_00be4f10 */

void __thiscall FUN_00be4f10(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint in_stack_0000002c;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  puStack_c = &LAB_017c858b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_3)();
  if (1 < uVar3) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 2;
    cVar2 = (**(code **)(*piVar1 + 4))(2,&uStack_ec);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889220();
      param_3 = (int *)*puVar4;
      uStack_8._0_1_ = 3;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00be4fe0;
    }
    uStack_8._0_1_ = 4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8._0_1_ = 1;
  }
  if (*(undefined4 **)(param_1 + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  param_3 = (int *)**(undefined4 **)(param_1 + 0x44);
LAB_00be4fe0:
  uStack_18 = FUN_009269c0(piVar1,param_1 + 0x40);
  FUN_00be4650(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_3,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26630 ; VA 0x00be50a0 ; FUN_00be50a0 */

void __thiscall FUN_00be50a0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00be44b0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26631 ; VA 0x00be5160 ; FUN_00be5160 */

void FUN_00be5160(int *param_1,char *param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  char *pcVar4;
  int iVar5;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801ed0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  if (iVar5 != param_1[1]) {
    do {
      uStack_8 = 0xffffffff;
      uVar2 = uStack_38 >> 8;
      uStack_38 = uVar2 << 8;
      uVar3 = uStack_38;
      pcVar4 = param_2;
      do {
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
      uStack_8 = 0;
      if (*(uint *)(iVar5 + 0x20) == 0) {
        FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      uStack_38 = uVar2 << 8;
      (**(code **)((*(uint *)(iVar5 + 0x20) & 0xfffffffe) + 4))
                (iVar5 + 0x28,uVar3,uStack_34,uStack_30,uStack_2c);
      iVar5 = iVar5 + 0x40;
    } while (iVar5 != param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26632 ; VA 0x00be5240 ; FUN_00be5240 */

void FUN_00be5240(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  
  iVar1 = *param_2;
  iVar7 = *(int *)(iVar1 + 0x270);
  iVar5 = FUN_0088c8c0();
  if (iVar7 == iVar5) {
    puVar6 = (undefined4 *)(iVar1 + 0x278);
    iVar7 = *param_2;
    if (*(int *)(iVar1 + 0x274) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar1 = *(int *)(iVar7 + 0x1a0);
    uVar2 = *puVar6;
    iVar5 = FUN_0088c8c0();
    if (iVar1 == iVar5) {
      puVar6 = (undefined4 *)(iVar7 + 0x1a8);
      iVar1 = *param_2;
      if (*(int *)(iVar7 + 0x1a4) == 0) {
        puVar6 = (undefined4 *)0x0;
      }
      iVar7 = *(int *)(iVar1 + 0xd0);
      uVar3 = *puVar6;
      iVar5 = FUN_0088c8c0();
      if (iVar7 == iVar5) {
        puVar6 = (undefined4 *)(iVar1 + 0xd8);
        param_2 = (int *)*param_2;
        if (*(int *)(iVar1 + 0xd4) == 0) {
          puVar6 = (undefined4 *)0x0;
        }
        iVar1 = *param_2;
        uVar4 = *puVar6;
        iVar7 = FUN_0088da50();
        if (iVar1 == iVar7) {
          piVar8 = param_2 + 2;
          if (param_2[1] == 0) {
            piVar8 = (int *)0x0;
          }
          FUN_00be37a0(*piVar8,piVar8[1],uVar4,uVar3,uVar2);
          return;
        }
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 26633 ; VA 0x00be5310 ; FUN_00be5310 */

void FUN_00be5310(undefined4 param_1,undefined4 param_2,uint param_3)

{
  undefined4 uVar1;
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801ef8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  (**(code **)((param_3 & 0xfffffffe) + 4))(&stack0x00000014,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26634 ; VA 0x00be53c0 ; FUN_00be53c0 */

/* WARNING: Removing unreachable block (ram,0x00be554d) */
/* WARNING: Removing unreachable block (ram,0x00be5579) */
/* WARNING: Removing unreachable block (ram,0x00be5585) */
/* WARNING: Removing unreachable block (ram,0x00be5593) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00be53c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,char *param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined8 uStack_60;
  char *pcStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801f3f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0x1800be53f0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined *)FUN_01674e20();
  uStack_8._0_1_ = 2;
  if (puVar5 == (undefined *)0x0) {
    puVar5 = (undefined *)0x0;
  }
  else {
    *(undefined4 *)(puVar5 + 0x10) = 0;
    *(undefined4 *)(puVar5 + 0x14) = 0xf;
    uStack_40 = 0x2b0195f098;
    *puVar5 = 0;
    puStack_44 = (undefined4 *)0xbe541f;
    FUN_005542c0();
  }
  uStack_8._0_1_ = 1;
  uStack_40 = CONCAT44(param_3,puVar5);
  puStack_44 = (undefined4 *)0xbe5441;
  FUN_005ce7a0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_40 = CONCAT44(param_1,0xbe544b);
  iVar6 = FUN_008f7870();
  if (iVar6 == 0) {
    uStack_54 = 0;
    if (0xf < _DAT_00000014) {
      uStack_54 = _DAT_00000000;
    }
    pcStack_58 = "%s failed because of null datamodel.";
    uStack_60 = CONCAT44(&uStack_50,0xbe546e);
    FUN_01675640();
    uStack_54 = 0xbe5479;
    FUN_005e65e0();
  }
  else {
    uVar1 = *(undefined4 *)(iVar6 + 0x440);
    uVar2 = *(undefined4 *)(iVar6 + 0x444);
    piVar3 = *(int **)(iVar6 + 0x43c);
    iVar6 = *piVar3;
    iVar4 = piVar3[1];
    pcStack_58 = (char *)0x0;
    if (param_11 != (char *)0x0) {
      pcStack_58 = param_11;
      if (((uint)param_11 & 1) == 0) {
        uStack_60 = ZEXT48(&uStack_50);
        puStack_64 = &param_13;
        uStack_68 = 0xbe54e9;
        (**(code **)((uint)param_11 & 0xfffffffe))();
      }
      else {
        uStack_50 = param_13;
        uStack_4c = param_14;
        uStack_48 = param_15;
        puStack_44 = (undefined4 *)param_16;
        uStack_40 = param_17;
      }
    }
    uStack_8._0_1_ = 4;
    if (param_4 != 0) {
      if ((param_4 & 1) == 0) {
        (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_70,0);
      }
      else {
        uStack_70 = param_6;
        uStack_6c = param_7;
        uStack_68 = param_8;
        puStack_64 = param_9;
        uStack_60 = param_10;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00be5600(param_2,param_3,iVar6 - (int)piVar3,iVar4 - (int)piVar3,uVar1,uVar2,0,0);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_44 = &param_6;
    uStack_40 = CONCAT44(2,puStack_44);
    uStack_48 = 0xbe55bb;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_44 = &param_13;
    uStack_40 = CONCAT44(2,puStack_44);
    uStack_48 = 0xbe55e9;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26635 ; VA 0x00be5600 ; FUN_00be5600 */

void FUN_00be5600(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 *param_7,int *param_8,uint param_9)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined **ppuVar7;
  uint in_stack_00000044;
  undefined4 uStack_2fc;
  undefined4 *puStack_2f8;
  undefined auStack_2f4 [4];
  undefined4 uStack_2f0;
  undefined4 *puStack_2ec;
  undefined auStack_2e8 [24];
  undefined4 uStack_2d0;
  undefined4 *puStack_2cc;
  undefined auStack_2c8 [28];
  undefined4 uStack_2ac;
  undefined auStack_2a8 [60];
  undefined4 uStack_26c;
  undefined4 *puStack_268;
  code *pcStack_264;
  undefined4 uStack_260;
  undefined4 *puStack_25c;
  undefined4 uStack_258;
  undefined *puStack_254;
  undefined4 *puStack_250;
  undefined auStack_24c [24];
  undefined4 uStack_234;
  undefined4 *puStack_230;
  undefined **ppuStack_22c;
  undefined4 *puStack_228;
  undefined4 *puStack_224;
  undefined4 *****pppppuStack_220;
  undefined4 uStack_21c;
  undefined4 *****pppppuStack_218;
  undefined *puStack_214;
  int iStack_210;
  undefined auStack_200 [104];
  undefined4 auStack_198 [2];
  undefined auStack_190 [48];
  undefined4 uStack_160;
  undefined auStack_158 [48];
  undefined4 uStack_128;
  undefined auStack_120 [48];
  undefined4 uStack_f0;
  undefined auStack_e8 [48];
  undefined4 uStack_b8;
  undefined auStack_b0 [48];
  undefined4 auStack_80 [2];
  undefined auStack_78 [48];
  undefined4 *****apppppuStack_48 [5];
  uint uStack_34;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01801ff9;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffdf4;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  iStack_210 = 0xbe5632;
  ExceptionList = &pvStack_10;
  cVar5 = FUN_00be4800();
  if (cVar5 == '\0') {
    puStack_228 = (undefined4 *)0x22;
    puStack_214 = (undefined *)0x0;
    iStack_210 = 0xf;
    ppuStack_22c = (undefined **)0x195efd4;
    puStack_224 = (undefined4 *)((uint)puStack_224 & 0xffffff00);
    puStack_230 = (undefined4 *)0xbe565b;
    FUN_005542c0();
    puStack_228 = (undefined4 *)0xbe5663;
    FUN_005e65e0();
    piVar4 = param_8;
    if (param_8 != (int *)0x0) {
      LOCK();
      iVar2 = param_8[1] + -1;
      param_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        iStack_210 = 0xbe567c;
        (**(code **)*param_8)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iStack_210 = 0xbe568b;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (param_9 != 0) {
      if (((param_9 & 1) == 0) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0)) {
        pppppuStack_218 = (undefined4 *****)&stack0x0000002c;
        iStack_210 = 2;
        uStack_21c = 0xbe56ac;
        puStack_214 = (undefined *)pppppuStack_218;
        (**(code **)(param_9 & 0xfffffffe))();
      }
      param_9 = 0;
    }
    uStack_8 = 4;
  }
  else {
    iStack_210 = 1;
    pppppuStack_218 = (undefined4 ******)0xbe5704;
    cVar5 = FUN_00971ce0();
    if (cVar5 == '\0') {
      puStack_228 = param_7;
      if (0xf < (uint)param_7[5]) {
        puStack_228 = (undefined4 *)*param_7;
      }
      puStack_230 = &puStack_224;
      ppuStack_22c = (undefined **)0x195eff8;
      uStack_234 = 0xbe572b;
      FUN_01675640();
      puStack_228 = (undefined4 *)0xbe5736;
      FUN_005e65e0();
      piVar4 = param_8;
      if (param_8 != (int *)0x0) {
        LOCK();
        iVar2 = param_8[1] + -1;
        param_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          iStack_210 = 0xbe574f;
          (**(code **)*param_8)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            iStack_210 = 0xbe575e;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (param_9 != 0) {
        if (((param_9 & 1) == 0) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0)) {
          pppppuStack_218 = (undefined4 *****)&stack0x0000002c;
          iStack_210 = 2;
          uStack_21c = 0xbe577f;
          puStack_214 = (undefined *)pppppuStack_218;
          (**(code **)(param_9 & 0xfffffffe))();
        }
        param_9 = 0;
      }
      uStack_8 = 6;
    }
    else {
      if ((0 < param_2) || ((-1 < param_2 && (param_1 != 0)))) {
        puStack_214 = (undefined *)0xbe5813;
        iStack_20 = FUN_008f7870();
        if (iStack_20 == 0) {
          puStack_228 = param_7;
          if (0xf < (uint)param_7[5]) {
            puStack_228 = (undefined4 *)*param_7;
          }
          puStack_230 = &puStack_224;
          ppuStack_22c = (undefined **)0x195f070;
          uStack_234 = 0xbe5839;
          FUN_01675640();
          puStack_228 = (undefined4 *)0xbe5844;
          FUN_005e65e0();
        }
        else {
          iStack_210 = param_2;
          pppppuStack_220 = apppppuStack_48;
          uStack_8._0_1_ = 9;
          puStack_214 = (undefined *)param_1;
          pppppuStack_218 = (undefined4 *****)param_6;
          uStack_21c = param_5;
          puStack_224 = (undefined4 *)0xbe5886;
          FUN_01075bb0();
          iStack_210 = 0;
          pppppuStack_218 = apppppuStack_48;
          if (0xf < uStack_34) {
            pppppuStack_218 = apppppuStack_48[0];
          }
          puStack_214 = (undefined *)0xb;
          uStack_8._0_1_ = 10;
          uStack_21c = 0xbe58a8;
          FUN_014cc0c0();
          uStack_8._0_1_ = 0xb;
          puStack_214 = (undefined *)0xbe58b2;
          iStack_18 = FUN_0064e700();
          if (iStack_18 != 0) {
            puStack_2c = (undefined *)&ppuStack_22c;
            puStack_24 = auStack_24c;
            param_2 = CONCAT31(param_2._1_3_,DAT_01ef6f94);
            puStack_1c = (undefined *)CONCAT31(puStack_1c._1_3_,DAT_01ef6f94);
            puStack_250 = &stack0x00000044;
            puStack_254 = (undefined *)0xbe58e7;
            FUN_0054f510();
            puStack_250 = (undefined4 *)param_2;
            puStack_25c = &param_7;
            uStack_260 = 0xbe58fb;
            FUN_00557fc0();
            iVar2 = iStack_20;
            puStack_268 = &uStack_260;
            uStack_8._0_1_ = 0xd;
            pcStack_264 = (code *)iStack_20;
            uStack_26c = 0xbe590e;
            FUN_005e5de0();
            uStack_8._0_1_ = 0xb;
            puStack_268 = auStack_198;
            pcStack_264 = FUN_00be3e50;
            uStack_26c = 0xbe5926;
            FUN_00be18a0();
            uStack_160 = auStack_198[0];
            puStack_230 = (undefined4 *)auStack_190;
            uStack_8._0_1_ = 0xe;
            uStack_234 = 0xbe594b;
            FUN_00be2170();
            uStack_8._0_1_ = 0xf;
            uStack_128 = uStack_160;
            puStack_230 = (undefined4 *)auStack_158;
            uStack_234 = 0xbe5976;
            FUN_00be2170();
            uStack_f0 = uStack_128;
            puStack_230 = (undefined4 *)auStack_120;
            uStack_8._0_1_ = 0x10;
            uStack_234 = 0xbe5998;
            FUN_00be2170();
            auStack_80[0] = uStack_f0;
            puStack_230 = (undefined4 *)auStack_e8;
            uStack_8._0_1_ = 0x11;
            uStack_234 = 0xbe59b4;
            FUN_00be2170();
            puStack_230 = auStack_80;
            uStack_8._0_1_ = 0x12;
            uStack_234 = 0xbe59c1;
            cVar5 = FUN_00585a40();
            if (cVar5 == '\0') {
              uStack_b8 = auStack_80[0];
              puStack_230 = (undefined4 *)auStack_78;
              uStack_234 = 0xbe59e0;
              FUN_00be2170();
              puStack_230 = (undefined4 *)0x38;
              uStack_8._0_1_ = 0x13;
              uStack_234 = 0xbe59eb;
              puVar6 = (undefined4 *)FUN_01674e20();
              uStack_8._0_1_ = 0x14;
              if (puVar6 == (undefined4 *)0x0) {
                puVar6 = (undefined4 *)0x0;
              }
              else {
                puStack_230 = (undefined4 *)auStack_b0;
                *puVar6 = uStack_b8;
                uStack_234 = 0xbe5a12;
                FUN_00be2170();
              }
              puStack_230 = (undefined4 *)0xbe5a27;
              puStack_224 = puVar6;
              FUN_00be32e0();
              puStack_230 = (undefined4 *)0xbe5a2f;
              FUN_00be32e0();
              bVar3 = true;
            }
            else {
              puStack_230 = (undefined4 *)0xbe5a40;
              FUN_00be32e0();
              bVar3 = false;
            }
            puStack_230 = (undefined4 *)0xbe5a4f;
            FUN_00be32e0();
            ppuVar7 = &PTR_FUN_0195f390;
            if (!bVar3) {
              ppuVar7 = (undefined **)0x0;
            }
            puStack_230 = (undefined4 *)0xbe5a6c;
            ppuStack_22c = ppuVar7;
            FUN_00be32e0();
            puStack_230 = (undefined4 *)0xbe5a77;
            FUN_00be32e0();
            puStack_230 = (undefined4 *)0xbe5a82;
            FUN_00be32e0();
            uStack_8._0_1_ = 0x15;
            puStack_2cc = &stack0x00000044;
            puStack_250 = (undefined4 *)0x0;
            puStack_28 = auStack_2c8;
            uStack_2d0 = 0xbe5aa5;
            FUN_0054f510();
            puStack_24 = auStack_2e8;
            uStack_8._0_1_ = 0x16;
            puStack_2ec = &param_9;
            uStack_2f0 = 0xbe5aba;
            FUN_0054f510();
            puStack_2ec = (undefined4 *)puStack_1c;
            puStack_2f8 = &param_7;
            puStack_1c = auStack_2f4;
            uStack_2fc = 0xbe5ace;
            FUN_00557fc0();
            uStack_8._0_1_ = 0x18;
            FUN_005e5de0(&uStack_2fc,iVar2);
            uStack_8._0_1_ = 0x15;
            FUN_00be16a0(auStack_2a8,FUN_00be39a0);
            uStack_2ac = 0xbe5afd;
            FUN_00be05c0();
            puStack_250 = (undefined4 *)0x0;
            puStack_254 = auStack_200;
            uStack_8._0_1_ = 0xb;
            uStack_258 = 0xbe5b11;
            FUN_00bcb1e0();
          }
          iStack_210 = 0xbe5b1c;
          FUN_0056db40();
          iStack_210 = 0xbe5b24;
          FUN_005507b0();
        }
        iStack_210 = 0xbe584c;
        FUN_00550b30();
        iStack_210 = 0xbe5854;
        FUN_00550990();
        iStack_210 = 0xbe585c;
        FUN_00550990();
        ExceptionList = pvStack_10;
        return;
      }
      puStack_228 = param_7;
      if (0xf < (uint)param_7[5]) {
        puStack_228 = (undefined4 *)*param_7;
      }
      puStack_230 = &puStack_224;
      ppuStack_22c = (undefined **)0x195f030;
      uStack_234 = 0xbe57c0;
      FUN_01675640();
      puStack_228 = (undefined4 *)0xbe57cb;
      FUN_005e65e0();
      iStack_210 = 0xbe57d3;
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      if (param_9 != 0) {
        if (((param_9 & 1) == 0) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0)) {
          pppppuStack_218 = (undefined4 *****)&stack0x0000002c;
          iStack_210 = 2;
          uStack_21c = 0xbe57f4;
          puStack_214 = (undefined *)pppppuStack_218;
          (**(code **)(param_9 & 0xfffffffe))();
        }
        param_9 = 0;
      }
      uStack_8 = 8;
    }
  }
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    pppppuStack_218 = (undefined4 *****)&stack0x0000004c;
    iStack_210 = 2;
    uStack_21c = 0xbe56e6;
    puStack_214 = (undefined *)pppppuStack_218;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26636 ; VA 0x00be5b29 ; Catch@00be5b29 */

undefined4 Catch_00be5b29(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  undefined auStack_18 [20];
  undefined4 uStack_4;
  
  uStack_4 = 0xbe5b33;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x2c) + 4))();
  piVar2 = *(int **)(unaff_EBP + 0x20);
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  FUN_01675640(auStack_18,"%s failed because %s",piVar2,uVar1);
  FUN_005e65e0();
  return 0xbe5844;
}



/* FUNCTION 26637 ; VA 0x00be5b70 ; FUN_00be5b70 */

void FUN_00be5b70(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_00be0a90(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26638 ; VA 0x00be5bf0 ; FUN_00be5bf0 */

void FUN_00be5bf0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint in_stack_0000001c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4780;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar7 = puVar2[6];
  ExceptionList = &pvStack_10;
  if (uVar7 != 0) {
    if ((uVar7 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar7 & 0xfffffffe))(puVar2 + 8,&uStack_34,0);
    }
    else {
      uStack_34 = puVar2[8];
      uStack_30 = puVar2[9];
      uStack_2c = puVar2[10];
      uStack_28 = puVar2[0xb];
      uStack_24 = *(undefined8 *)(puVar2 + 0xc);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  if (puVar2[5] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = puVar2[4];
  uVar5 = puVar2[5];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[2],puVar2[3],uVar4,uVar5);
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    iVar6 = param_2;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(param_2 + -4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar6) - 4U) {
        uStack_24 = CONCAT44(&UNK_00be5d10,(undefined4)uStack_24);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_24 = CONCAT44(uVar7,iVar6);
    uStack_28 = 0xbe5cf8;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26639 ; VA 0x00be5d20 ; FUN_00be5d20 */

void FUN_00be5d20(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01802020;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar4 = puVar2[6];
  uVar5 = puVar2[4];
  uVar6 = puVar2[5];
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 1;
  FUN_00be2ed0(puVar2 + 8);
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[2],puVar2[3],uVar5,uVar6,uVar4);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26640 ; VA 0x00be5e00 ; FUN_00be5e00 */

void FUN_00be5e00(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f08d0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar4 = puVar2[4];
  uVar5 = puVar2[5];
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  iStack_8._0_1_ = 1;
  FUN_00be2ed0(puVar2 + 6);
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[2],puVar2[3],uVar4,uVar5);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26641 ; VA 0x00be5ee0 ; FUN_00be5ee0 */

uint FUN_00be5ee0(void)

{
  int iVar1;
  
  iVar1 = FUN_00be0bd0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26642 ; VA 0x00be5f00 ; FUN_00be5f00 */

uint FUN_00be5f00(void)

{
  int iVar1;
  
  iVar1 = FUN_00be0bd0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26643 ; VA 0x00be5f20 ; FUN_00be5f20 */

void __fastcall FUN_00be5f20(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d3f11;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    iStack_1c = param_1;
    if ((iVar1 != 0) && (param_1 = iVar1, ExceptionList = &pvStack_10, *(int *)(iVar1 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      uVar4 = FUN_00560d40();
      piStack_14 = (int *)FUN_008aa140(uVar4);
      if (*piStack_14 == 0) {
        uVar4 = FUN_00995770();
        piVar5 = (int *)FUN_008a9ba0(auStack_30,uVar4);
        iVar1 = *piVar5;
        iVar3 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar1;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar3;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_2c != (int *)0x0) {
          LOCK();
          iVar1 = piStack_2c[1] + -1;
          piStack_2c[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_2c)();
            LOCK();
            iVar1 = piStack_2c[2] + -1;
            piStack_2c[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_2c + 4))();
            }
          }
        }
      }
      iVar1 = iStack_1c;
      if (*piStack_14 != 0) {
        iStack_18 = *piStack_14 + 0xd4;
        iStack_8 = 0;
        uVar4 = FUN_01675290(DAT_02110da8);
        iStack_8._0_1_ = 1;
        uStack_24 = uVar4;
        piStack_28 = (int *)FUN_01674e20(0x28);
        if (piStack_28 == (int *)0x0) {
          piVar5 = (int *)0x0;
        }
        else {
          *piStack_28 = 0;
          piStack_28[1] = 1;
          piStack_28[2] = (int)FUN_00838650;
          piStack_28[3] = (int)_guard_check_icall;
          piStack_28[4] = 0;
          piStack_28[5] = iStack_18;
          piStack_28[6] = (int)FUN_00be6700;
          piStack_28[7] = 0;
          piStack_28[8] = iVar1;
          piStack_28[9] = iStack_34;
          piVar5 = piStack_28;
        }
        FUN_016797d0(piVar5);
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        uStack_20 = 1;
        iStack_8._0_1_ = 2;
        piStack_14 = piVar5;
        FUN_01675290(uVar4);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        cVar2 = FUN_01679300(&piStack_14);
        if (cVar2 != '\0') {
          FUN_01679490();
          FUN_016791c0(&piStack_14);
        }
        if (piStack_14 != (int *)0x0) {
          piVar5 = piStack_14 + 1;
          LOCK();
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            FUN_01674ea0(piStack_14);
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26644 ; VA 0x00be6160 ; FUN_00be6160 */

void FUN_00be6160(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180203f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x58);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00be24b0(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x38);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x40,iVar4 + 0x40,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x38) = 0;
        }
        FUN_00be32e0();
        FUN_01674ea0(iVar4,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1df7f6c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(int)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(int)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26645 ; VA 0x00be62f0 ; FUN_00be62f0 */

void FUN_00be62f0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x38);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00be2170(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00be32e0();
        FUN_01674ea0(iVar3,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df7d1c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26646 ; VA 0x00be6440 ; FUN_00be6440 */

void FUN_00be6440(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00be2050(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a59a30();
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df85f4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,__int64,int,class_std::vector<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_std::allocator<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<int>,class_boost::_bi::value<class_std::vector<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_std::allocator<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26647 ; VA 0x00be65a0 ; FUN_00be65a0 */

void FUN_00be65a0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00be20e0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a59a30();
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1df81fc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,__int64,class_std::vector<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_std::allocator<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list4<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<__int64>,class_boost::_bi::value<class_std::vector<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_std::allocator<struct_std::pair<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 26648 ; VA 0x00be6700 ; FUN_00be6700 */

void __thiscall FUN_00be6700(int param_1,uint param_2)

{
  int *piVar1;
  uint *puVar2;
  undefined uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  uint *puVar12;
  double dVar13;
  double dVar14;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [12];
  uint *puStack_30;
  char cStack_2c;
  int iStack_28;
  uint uStack_24;
  uint *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802070;
  pvStack_10 = ExceptionList;
  cStack_2c = '\0';
  puStack_30 = (uint *)(param_1 + 0x5c);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  uStack_18 = FUN_008f7870(param_1);
  if ((uStack_18 != 0) && (uStack_14 = FUN_0064e700(param_1), uStack_14 != 0)) {
    if (param_1 != 0) {
      iVar8 = *(int *)(param_1 + 0x34);
      iVar4 = param_1;
      if ((iVar8 != 0) && (iVar4 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
        iVar4 = FUN_005c8ac0();
      }
      if ((iVar4 != 0) &&
         (iVar8 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        FUN_005c2760();
      }
    }
    FUN_008cec00(auStack_6c);
    uStack_8._0_1_ = 1;
    dVar13 = *(double *)(param_2 + 8) + *(double *)(param_1 + 0x80);
    *(double *)(param_1 + 0x80) = dVar13;
    if ((double)DAT_01d67fa0 <= dVar13) {
      *(undefined4 *)(param_1 + 0x7c) = 0;
    }
    iVar8 = *(int *)(param_1 + 0x88);
    *(int *)(param_1 + 0x8c) = iVar8;
    if (*(int *)(param_1 + 0x6c) == 0) {
      piVar11 = (int *)0x0;
    }
    else {
      piVar11 = *(int **)(*(int *)(param_1 + 0x78) + *(int *)(param_1 + 0x68) * 4);
    }
    if (piVar11 != (int *)0x0) {
      do {
        uStack_24 = piVar11[3];
        iVar8 = piVar11[2];
        dVar14 = *(double *)(param_2 + 8) + *(double *)(piVar11 + 8);
        *(double *)(piVar11 + 8) = dVar14;
        dVar13 = *(double *)(piVar11 + 10) + *(double *)(param_2 + 8);
        *(double *)(piVar11 + 10) = dVar13;
        iStack_28 = iVar8;
        uStack_1c = uStack_24;
        if (((double)DAT_01d67fa8 < dVar13) || ((double)DAT_01d67fb0 < dVar14)) {
          if (*(int *)(param_1 + 0x7c) < DAT_01d67f90) {
            FUN_00be76b0(piVar11[2],piVar11[3],piVar11 + 4,uStack_18,uStack_14);
          }
          else {
            FUN_00be2ed0(piVar11 + 5);
            uStack_8._0_1_ = 2;
            puVar5 = (undefined4 *)
                     FUN_01675640(auStack_54,
                                  "%s failed because the max number of calls per minute has been exceeded. Don\'t call this more than %i times per minute per user."
                                  ,"PointsService:AwardPoints",DAT_01d67f90);
            uStack_8._0_1_ = 3;
            if (0xf < (uint)puVar5[5]) {
              puVar5 = (undefined4 *)*puVar5;
            }
            FUN_00be5160(auStack_3c,puVar5);
            uStack_8._0_1_ = 2;
            uVar3 = (undefined)uStack_8;
            uStack_8._0_1_ = 2;
            if (0xf < uStack_40) {
              uVar9 = uStack_40 + 1;
              uVar10 = auStack_54[0];
              if (0xfff < uVar9) {
                uVar10 = *(uint *)(auStack_54[0] - 4);
                uVar9 = uStack_40 + 0x24;
                if (0x1f < (auStack_54[0] - uVar10) - 4) goto LAB_00be6b52;
              }
              FUN_01674ea0(uVar10,uVar9);
            }
            uStack_44 = 0;
            uStack_40 = 0xf;
            auStack_54[0] = auStack_54[0] & 0xffffff00;
            uStack_8._0_1_ = 1;
            FUN_00a59a30();
          }
          piVar1 = *(int **)(param_1 + 0x8c);
          if (*(int **)(param_1 + 0x90) == piVar1) {
            FUN_00805800(piVar1,&iStack_28);
          }
          else {
            *piVar1 = iVar8;
            piVar1[1] = uStack_1c;
            *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + 8;
          }
          *(int *)(param_1 + 0x7c) = *(int *)(param_1 + 0x7c) + 1;
        }
        piVar11 = (int *)*piVar11;
      } while (piVar11 != (int *)0x0);
      iVar8 = *(int *)(param_1 + 0x8c);
    }
    iVar4 = *(int *)(param_1 + 0x88);
    param_2 = 0;
    if (iVar8 - iVar4 >> 3 != 0) {
      do {
        if (*(int *)(param_1 + 0x6c) != 0) {
          uStack_18 = *(uint *)(iVar4 + param_2 * 8);
          puStack_20 = *(uint **)(iVar4 + 4 + param_2 * 8);
          puVar7 = puStack_20;
          if (((int)puStack_20 < 1) && ((int)puStack_20 < 0)) {
            puVar7 = (uint *)~(uint)puStack_20;
          }
          uStack_1c = ((uint)puVar7 >> 2) + (int)puVar7 * 0x40 + uStack_18 ^ (uint)puVar7;
          uStack_14 = uStack_1c % *(uint *)(param_1 + 0x68);
          uStack_24 = uStack_14 * 4;
          puVar7 = *(uint **)(uStack_24 + *(int *)(param_1 + 0x78));
          if ((puVar7 != (uint *)0x0) && (puVar12 = (uint *)*puVar7, (uint *)*puVar7 != (uint *)0x0)
             ) {
LAB_00be6a00:
            if (puVar12[1] % *(uint *)(param_1 + 0x68) == uStack_14) {
              if (((puVar12[1] != uStack_1c) || (uStack_18 != puVar12[2])) ||
                 (puStack_20 != (uint *)puVar12[3])) goto LAB_00be6a24;
              puStack_20 = (uint *)*puVar12;
              do {
                *puVar7 = *puVar12;
                FUN_00a59a30();
                FUN_01674ea0(puVar12,0x30);
                *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + -1;
                puVar12 = (uint *)*puVar7;
              } while (puVar12 != puStack_20);
              if (puVar12 == (uint *)0x0) {
LAB_00be6acc:
                puVar5 = (undefined4 *)(*(int *)(param_1 + 0x78) + uStack_24);
                if ((uint *)*puVar5 == puVar7) {
                  *puVar5 = 0;
                }
              }
              else {
                uVar10 = puVar12[1] % *(uint *)(param_1 + 0x68);
                if (uStack_14 != uVar10) {
                  *(uint **)(*(int *)(param_1 + 0x78) + uVar10 * 4) = puVar7;
                  goto LAB_00be6acc;
                }
              }
            }
          }
        }
LAB_00be6a34:
        iVar4 = *(int *)(param_1 + 0x88);
        param_2 = param_2 + 1;
      } while (param_2 < (uint)(*(int *)(param_1 + 0x8c) - iVar4 >> 3));
    }
    *(int *)(param_1 + 0x8c) = iVar4;
    uStack_8._0_1_ = 0;
    if (0xf < uStack_58) {
      uVar9 = uStack_58 + 1;
      uVar10 = auStack_6c[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_6c[0] - 4);
        uVar9 = uStack_58 + 0x24;
        uVar3 = (undefined)uStack_8;
        if (0x1f < (auStack_6c[0] - uVar10) - 4) {
LAB_00be6b52:
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_5c = 0;
    uStack_58 = 0xf;
    auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  }
  uStack_8 = 4;
  if (cStack_2c != '\0') {
    LOCK();
    uVar10 = *puStack_30;
    *puStack_30 = *puStack_30 + 0x80000000;
    UNLOCK();
    if (((uVar10 & 0x40000000) == 0) && (-0x80000000 < (int)uVar10)) {
      LOCK();
      uVar10 = *puStack_30;
      *puStack_30 = *puStack_30 | 0x40000000;
      UNLOCK();
      if ((uVar10 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
LAB_00be6a24:
  puVar2 = (uint *)*puVar12;
  puVar7 = puVar12;
  puVar12 = puVar2;
  if (puVar2 == (uint *)0x0) goto LAB_00be6a34;
  goto LAB_00be6a00;
}



/* FUNCTION 26649 ; VA 0x00be6b60 ; FUN_00be6b60 */

void FUN_00be6b60(int param_1,undefined4 param_2)

{
  if (param_1 != 0) {
    FUN_01679490();
  }
  FUN_008a4210(param_1,param_2);
  return;
}



/* FUNCTION 26650 ; VA 0x00be6b90 ; FUN_00be6b90 */

void FUN_00be6b90(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  undefined4 *in_stack_00000020;
  uint in_stack_00000034;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018020a0;
  pvStack_10 = ExceptionList;
  puVar1 = &stack0x00000020;
  if (0xf < in_stack_00000034) {
    puVar1 = in_stack_00000020;
  }
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)
           FUN_01675640(aiStack_28,"Processing PointsService:AwardPoints error: %s. userId = %lld",
                        puVar1,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  FUN_00be5160(&stack0x00000014,puVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[2] + -1;
    param_2[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00a59a30();
  if (0xf < in_stack_00000034) {
    uVar3 = in_stack_00000034 + 1;
    puVar1 = in_stack_00000020;
    if (0xfff < uVar3) {
      puVar1 = (undefined4 *)in_stack_00000020[-1];
      uVar3 = in_stack_00000034 + 0x24;
      if (0x1f < (uint)((int)in_stack_00000020 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26651 ; VA 0x00be6c90 ; FUN_00be6c90 */

void FUN_00be6c90(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint *param_6,uint *param_7,undefined4 param_8,int param_9)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 ****ppppuVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint *puVar8;
  int *piVar9;
  int in_stack_00000034;
  uint in_stack_00000038;
  undefined4 *puVar10;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined auStack_80 [8];
  code *apcStack_78 [2];
  int iStack_70;
  int iStack_6c;
  int *piStack_68;
  int *piStack_64;
  int iStack_60;
  int *piStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  int aiStack_40 [2];
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180218e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_60);
  uStack_8._0_1_ = 3;
  if (iStack_60 == 0) {
    puVar4 = (undefined4 *)
             FUN_01675640(apppuStack_58,
                          "Processing PointsService:AwardPoints but could not get lock on datamodel. userId = %lld"
                          ,param_3,param_4);
    uStack_8._0_1_ = 0x17;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00be5160(&param_6,puVar4);
    if (0xf < uStack_44) {
      uVar7 = uStack_44 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_58[0];
      if (0xfff < uVar7) {
        ppppuVar3 = (undefined4 ****)apppuStack_58[0][-1];
        uVar7 = uStack_44 + 0x24;
        if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar7);
    }
  }
  else {
    piStack_24 = (int *)FUN_00be1df0(iStack_60 + 0xc);
    if (piStack_24 == (int *)0x0) {
      FUN_0086f2f0(3,
                   "Processing PointsService:AwardPoints response and could not find PointsService, userId = %lld"
                   ,param_3,param_4);
    }
    else if (in_stack_00000034 == 0) {
      puVar4 = (undefined4 *)
               FUN_01675640(apppuStack_58,
                            "Processing PointsService:AwardPoints response, but response has length of 0. userId = %lld"
                            ,param_3,param_4);
      uStack_8._0_1_ = 0x16;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_00be5160(&param_6,puVar4);
      FUN_005507b0();
    }
    else {
      FUN_00563d90(aiStack_40);
      piVar9 = aiStack_40;
      uStack_8._0_1_ = 4;
      puVar4 = &param_9;
      FUN_0098f070(puVar4,piVar9,0);
      if ((aiStack_40[0] == 0) || (*(int *)(aiStack_40[0] + 8) == 0)) {
        puVar4 = (undefined4 *)
                 FUN_01675640(apppuStack_58,
                              "Processing PointsService:AwardPoints response, but JSON table is null. userId = %lld"
                              ,param_3,param_4);
        uStack_8._0_1_ = 0x15;
        if (0xf < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_00be5160(&param_6,puVar4);
      }
      else {
        uStack_18 = 0;
        uStack_20 = 0;
        uStack_48 = 0;
        uStack_44 = 0xf;
        apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
        ppppuVar3 = apppuStack_58;
        uStack_8._0_1_ = 5;
        puVar10 = &uStack_18;
        FUN_00557fc0(aiStack_40);
        cVar2 = FUN_00be7330(puVar4,piVar9,puVar10,ppppuVar3);
        if (cVar2 == '\0') {
          ppppuVar3 = apppuStack_58;
          if (0xf < uStack_44) {
            ppppuVar3 = (undefined4 ****)apppuStack_58[0];
          }
          puVar4 = (undefined4 *)
                   FUN_01675640(auStack_80,
                                "Processing PointsService:AwardPoints response, but failed because %s. userId = %lld"
                                ,ppppuVar3,param_3,param_4);
          uStack_8._0_1_ = 6;
          if (0xf < (uint)puVar4[5]) {
            puVar4 = (undefined4 *)*puVar4;
          }
          FUN_00be5160(&param_6,puVar4);
          FUN_005507b0();
        }
        else {
          uStack_1c = param_5;
          pcStack_14 = (code *)FUN_01674e20(0x18);
          if (pcStack_14 == (code *)0x0) {
            piVar9 = (int *)0x0;
          }
          else {
            *(int *)((int)pcStack_14 + 4) = 1;
            *(int *)((int)pcStack_14 + 8) = 1;
            *(undefined ***)pcStack_14 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable
            ;
            *(int *)((int)pcStack_14 + 0xc) = 0;
            *(int *)((int)pcStack_14 + 0x10) = 0;
            *(int *)((int)pcStack_14 + 0x14) = 0;
            piVar9 = (int *)pcStack_14;
          }
          piStack_68 = piVar9 + 3;
          uStack_8._0_1_ = 7;
          piStack_64 = piVar9;
          FUN_005c1470(&param_3);
          uStack_8._0_1_ = 8;
          FUN_005cd7a0(&uStack_150);
          uStack_8._0_1_ = 7;
          FUN_0056e5b0();
          FUN_005c13a0(&uStack_1c);
          uStack_8._0_1_ = 9;
          FUN_005cd7a0(&uStack_150);
          uStack_8._0_1_ = 7;
          FUN_0056e5b0();
          FUN_005c13a0(&uStack_18);
          uStack_8._0_1_ = 10;
          FUN_005cd7a0(&uStack_150);
          uStack_8._0_1_ = 7;
          FUN_0056e5b0();
          FUN_005c13a0(&uStack_20);
          uStack_8._0_1_ = 0xb;
          FUN_005cd7a0(&uStack_150);
          FUN_0056e5b0();
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
          }
          piStack_34 = piVar9 + 3;
          puVar8 = param_6;
          piStack_30 = piVar9;
          if (param_6 != param_7) {
            do {
              if (piVar9 != (int *)0x0) {
                LOCK();
                piVar9[1] = piVar9[1] + 1;
                UNLOCK();
              }
              uStack_8._0_1_ = 0xd;
              if (*puVar8 == 0) {
                piStack_2c = piVar9 + 3;
                piStack_28 = piVar9;
                uVar5 = FUN_0054fda0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0(uVar5);
              }
              piStack_2c = (int *)0x0;
              piStack_28 = (int *)0x0;
              (**(code **)((*puVar8 & 0xfffffffe) + 4))(puVar8 + 2,piVar9 + 3,piVar9);
              puVar8 = puVar8 + 0x10;
            } while (puVar8 != param_7);
          }
          uStack_8._0_1_ = 7;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar6 = piVar9[1] + -1;
            piVar9[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              iVar6 = piVar9[2] + -1;
              piVar9[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          uVar1 = param_4;
          uVar5 = param_3;
          piStack_2c = (int *)0x0;
          piStack_28 = (int *)0x0;
          FUN_00be37a0(param_3,param_4,uStack_1c,uStack_18,uStack_20);
          pcStack_14 = *(code **)(*piStack_24 + 8);
          uStack_3c0 = FUN_0088da50();
          uStack_3bc = 0;
          uStack_3b8 = uVar5;
          uStack_3b4 = uVar1;
          uStack_3bc = FUN_005c9e80();
          uStack_8._0_1_ = 0xf;
          uStack_2f0 = FUN_0088c8c0();
          uStack_2ec = 0;
          uStack_2e8 = uStack_1c;
          uStack_2ec = FUN_005c9cc0();
          uStack_8._0_1_ = 0x10;
          uStack_220 = FUN_0088c8c0();
          uStack_21c = 0;
          uStack_218 = uStack_18;
          uStack_21c = FUN_005c9cc0();
          uStack_8._0_1_ = 0x11;
          uStack_150 = FUN_0088c8c0();
          uStack_14c = 0;
          uStack_148 = uStack_20;
          uStack_14c = FUN_005c9cc0();
          uStack_8._0_1_ = 0x12;
          uStack_38 = 0;
          piStack_34 = (int *)0x0;
          piStack_30 = (int *)0x0;
          FUN_00687980(&uStack_3c0,auStack_80,pcStack_14);
          uStack_8._0_1_ = 0x13;
          (*pcStack_14)(&DAT_02132c58,&uStack_38,&piStack_2c);
          uStack_8._0_1_ = 0x14;
          FUN_00577b20();
          uStack_8._0_1_ = 7;
          FUN_016f32d1(&uStack_3c0,0xd0,4,FUN_0056e5b0);
          apcStack_78[0] = FUN_00be7610;
          piVar9 = *(int **)(iStack_60 + 0x43c);
          iStack_70 = *piVar9 - (int)piVar9;
          iStack_6c = piVar9[1] - (int)piVar9;
          FUN_00942b20(&DAT_01ef6f98,apcStack_78);
          FUN_00550b30();
        }
      }
      FUN_005507b0();
      FUN_00550b30();
    }
  }
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      iVar6 = piStack_5c[2] + -1;
      piStack_5c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar9 = param_2 + 2;
    iVar6 = *piVar9;
    *piVar9 = *piVar9 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00a59a30();
  if (0xf < in_stack_00000038) {
    uVar7 = in_stack_00000038 + 1;
    iVar6 = param_9;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(param_9 + -4);
      uVar7 = in_stack_00000038 + 0x24;
      if (0x1f < (param_9 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26652 ; VA 0x00be72a0 ; FUN_00be72a0 */

void __thiscall FUN_00be72a0(int param_1,int param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01801638;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    ExceptionList = &pvStack_10;
    *puVar1 = 0;
    FUN_005880d0(param_2);
    uStack_8 = 0;
    puVar1[8] = 0;
    FUN_005880d0(param_2 + 0x20);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x40;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00be0f10(puVar1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26653 ; VA 0x00be7330 ; FUN_00be7330 */

undefined4 FUN_00be7330(byte *param_1,int *param_2,uint *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  code *pcVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  undefined4 uVar8;
  char *pcVar9;
  byte *pbVar10;
  byte ****ppppbVar11;
  undefined4 *puVar12;
  bool bVar13;
  undefined auStack_110 [216];
  byte *pbStack_38;
  uint uStack_34;
  uint uStack_30;
  byte ***apppbStack_2c [4];
  uint uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018021c3;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffedc;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_3 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  pbStack_38 = param_1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppbStack_2c[0] = (byte ***)((uint)apppbStack_2c[0] & 0xffffff00);
  pcVar9 = PTR_DAT_01d67fe0;
  do {
    cVar2 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(PTR_DAT_01d67fe0,(int)pcVar9 - (int)(PTR_DAT_01d67fe0 + 1));
  uStack_8._0_1_ = 2;
  if (*(int *)(param_1 + 8) != 0) {
    uStack_30 = FUN_0055c740(param_1 + *param_1 + 1,apppbStack_2c);
    uStack_34 = uStack_30 % *(uint *)(param_1 + 4);
    puVar12 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_34 * 4);
    if (puVar12 == (undefined4 *)0x0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      puVar12 = (undefined4 *)*puVar12;
    }
    for (; puVar12 != (undefined4 *)0x0; puVar12 = (undefined4 *)*puVar12) {
      if (uStack_30 == puVar12[1]) {
        pbVar10 = (byte *)(puVar12 + 2);
        if (0xf < (uint)puVar12[7]) {
          pbVar10 = *(byte **)pbVar10;
        }
        ppppbVar11 = apppbStack_2c;
        if (0xf < uStack_18) {
          ppppbVar11 = (byte ****)apppbStack_2c[0];
        }
        uVar6 = uStack_1c;
        if (uStack_1c == puVar12[6]) {
          while (uVar5 = uVar6 - 4, 3 < uVar6) {
            if (*ppppbVar11 != *(byte ****)pbVar10) goto LAB_00be7447;
            ppppbVar11 = ppppbVar11 + 1;
            pbVar10 = pbVar10 + 4;
            uVar6 = uVar5;
          }
          if (uVar5 == 0xfffffffc) {
LAB_00be747b:
            uVar6 = 0;
          }
          else {
LAB_00be7447:
            bVar13 = *(byte *)ppppbVar11 < *pbVar10;
            if ((*(byte *)ppppbVar11 == *pbVar10) &&
               ((uVar5 == 0xfffffffd ||
                ((bVar13 = *(byte *)((int)ppppbVar11 + 1) < pbVar10[1],
                 *(byte *)((int)ppppbVar11 + 1) == pbVar10[1] &&
                 ((uVar5 == 0xfffffffe ||
                  ((bVar13 = *(byte *)((int)ppppbVar11 + 2) < pbVar10[2],
                   *(byte *)((int)ppppbVar11 + 2) == pbVar10[2] &&
                   ((uVar5 == 0xffffffff ||
                    (bVar13 = *(byte *)((int)ppppbVar11 + 3) < pbVar10[3],
                    *(byte *)((int)ppppbVar11 + 3) == pbVar10[3])))))))))))) goto LAB_00be747b;
            uVar6 = -(uint)bVar13 | 1;
          }
          param_1 = pbStack_38;
          if (uVar6 == 0) {
            if ((undefined4 *)puVar12[9] != (undefined4 *)0x0) {
              (**(code **)puVar12[9])(puVar12 + 10,auStack_110);
            }
            iVar3 = puVar12[9];
            uStack_8._0_1_ = 5;
            if (0xf < uStack_18) {
              uVar6 = uStack_18 + 1;
              ppppbVar11 = (byte ****)apppbStack_2c[0];
              if (0xfff < uVar6) {
                ppppbVar11 = (byte ****)apppbStack_2c[0][-1];
                uVar6 = uStack_18 + 0x24;
                if ((byte *)0x1f < (byte *)((int)apppbStack_2c[0] + (-4 - (int)ppppbVar11))) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(ppppbVar11,uVar6);
            }
            uStack_1c = 0;
            uStack_18 = 0xf;
            apppbStack_2c[0] = (byte ***)((uint)apppbStack_2c[0] & 0xffffff00);
            puVar7 = (uint *)FUN_0088baa0();
            uVar6 = *puVar7;
            uVar5 = puVar7[1];
            if (((int)uVar5 < 0) || (((int)uVar5 < 1 && (uVar6 < 0x80000000)))) {
              if (((int)uVar5 < -1) || ((0x7fffffff < uVar5 && (uVar6 < 0x80000001)))) {
                uVar6 = 0x80000000;
              }
            }
            else {
              uVar6 = 0x7fffffff;
            }
            *param_3 = uVar6;
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            if (iVar3 != 0) {
              (**(code **)(iVar3 + 8))(auStack_110);
            }
            if (param_2 != (int *)0x0) {
              LOCK();
              iVar3 = param_2[1] + -1;
              param_2[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*param_2)();
                LOCK();
                piVar1 = param_2 + 2;
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                  (**(code **)(*param_2 + 4))();
                }
              }
            }
            ExceptionList = pvStack_10;
            return 1;
          }
        }
      }
      else if ((uint)puVar12[1] % *(uint *)(param_1 + 4) != uStack_34) break;
    }
  }
  uVar8 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00917680(uVar8);
  pcVar4 = (code *)swi(3);
  uVar8 = (*pcVar4)();
  return uVar8;
}



/* FUNCTION 26654 ; VA 0x00be75b2 ; Catch@00be75b2 */

undefined * Catch_00be75b2(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x38) + 4))();
  FUN_00551260(uVar1);
  return &LAB_00be75c9;
}



/* FUNCTION 26655 ; VA 0x00be7610 ; FUN_00be7610 */

void FUN_00be7610(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01675640(aiStack_28,&DAT_018bed48,param_1,param_2);
  uStack_8 = 0;
  if (0xf < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  FUN_0087c450(&DAT_018c5f98,"HasAwardedAPoint",puVar1,0,0,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26656 ; VA 0x00be76b0 ; FUN_00be76b0 */

void FUN_00be76b0(undefined4 param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  uint uVar1;
  undefined4 ****ppppuVar2;
  undefined auStack_188 [8];
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 *puStack_178;
  undefined4 uStack_168;
  undefined *puStack_164;
  code *pcStack_160;
  undefined auStack_15c [8];
  undefined4 uStack_154;
  undefined4 *puStack_150;
  undefined auStack_14c [8];
  undefined4 uStack_144;
  undefined *puStack_140;
  uint *puStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_114;
  undefined auStack_110 [8];
  undefined4 uStack_108;
  undefined4 ***pppuStack_104;
  undefined4 uStack_100;
  undefined4 ***pppuStack_fc;
  undefined4 ***pppuStack_f8;
  undefined *puStack_f4;
  undefined auStack_e4 [128];
  undefined4 ***apppuStack_64 [5];
  uint uStack_50;
  undefined *puStack_48;
  undefined *puStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180220b;
  pvStack_10 = ExceptionList;
  pppuStack_104 = apppuStack_64;
  puStack_14 = &stack0xffffff10;
  puStack_f4 = (undefined *)param_2;
  pppuStack_f8 = (undefined4 ***)param_1;
  uStack_8 = 0;
  pppuStack_fc = *(undefined4 ****)(param_4 + 0x444);
  uStack_100 = *(undefined4 *)(param_4 + 0x440);
  uStack_108 = 0xbe76fa;
  ExceptionList = &pvStack_10;
  FUN_01075970();
  pppuStack_f8 = (undefined4 ***)auStack_40;
  uStack_8._0_1_ = 1;
  puStack_f4 = (undefined *)*param_3;
  pppuStack_fc = (undefined4 ***)0xbe770f;
  FUN_00be4410();
  puStack_f4 = (undefined *)0x0;
  pppuStack_fc = apppuStack_64;
  if (0xf < uStack_50) {
    pppuStack_fc = apppuStack_64[0];
  }
  pppuStack_f8 = (undefined4 ***)0xb;
  uStack_8._0_1_ = 2;
  uStack_100 = 0xbe7731;
  FUN_014cc0c0();
  puStack_44 = auStack_110;
  puStack_18 = auStack_110;
  uStack_24 = *param_3;
  uStack_114 = 0;
  uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01ef6f94);
  puStack_140 = (undefined *)(uint)DAT_01ef6f94;
  puStack_48 = auStack_14c;
  uStack_8._0_1_ = 3;
  puStack_150 = param_3 + 1;
  uStack_154 = 0xbe776b;
  puStack_20 = puStack_150;
  FUN_00be2ed0();
  puStack_150 = (undefined4 *)param_2;
  uStack_154 = param_1;
  uStack_8._0_1_ = 4;
  puStack_164 = auStack_15c;
  pcStack_160 = (code *)param_4;
  uStack_168 = 0xbe777f;
  FUN_005e5de0();
  uStack_8._0_1_ = 3;
  pcStack_160 = FUN_00be6b90;
  uStack_168 = 0xbe7793;
  puStack_164 = (undefined *)&puStack_13c;
  FUN_00be1b30();
  puStack_140 = (undefined *)0xbe779e;
  FUN_00be08e0();
  uStack_8._0_1_ = 5;
  uStack_134 = 0;
  uStack_168 = uStack_1c;
  puStack_178 = puStack_20;
  uStack_17c = 0xbe77c1;
  FUN_00be2ed0();
  puStack_178 = (undefined4 *)uStack_24;
  uStack_8._0_1_ = 6;
  uStack_17c = param_2;
  uStack_180 = param_1;
  FUN_005e5de0(auStack_188,param_4);
  uStack_8._0_1_ = 5;
  FUN_00be1a00(&puStack_164,FUN_00be6c90);
  uStack_168 = 0xbe77f6;
  FUN_00be0720();
  puStack_13c = auStack_40;
  uStack_134 = 0;
  uStack_138 = 0;
  puStack_140 = auStack_e4;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_144 = 0xbe7811;
  FUN_00bd0e20();
  puStack_f4 = (undefined *)0xbe781c;
  FUN_0056db40();
  if (0xf < uStack_2c) {
    puStack_f4 = (undefined *)(uStack_2c + 1);
    uVar1 = auStack_40[0];
    if (0xfff < puStack_f4) {
      uVar1 = *(uint *)(auStack_40[0] - 4);
      puStack_f4 = (undefined *)(uStack_2c + 0x24);
      if (0x1f < (auStack_40[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_f4 = (undefined *)0xbe78f1;
        FUN_017167a3();
      }
    }
    pppuStack_fc = (undefined4 ****)0xbe784d;
    pppuStack_f8 = (undefined4 ***)uVar1;
    FUN_01674ea0();
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_50) {
    puStack_f4 = (undefined *)(uStack_50 + 1);
    ppppuVar2 = (undefined4 ****)apppuStack_64[0];
    if (0xfff < puStack_f4) {
      ppppuVar2 = (undefined4 ****)apppuStack_64[0][-1];
      puStack_f4 = (undefined *)(uStack_50 + 0x24);
      if (0x1f < (uint)((int)apppuStack_64[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_f4 = &UNK_00be78f6;
        FUN_017167a3();
      }
    }
    pppuStack_fc = (undefined4 ***)0xbe788f;
    pppuStack_f8 = ppppuVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26657 ; VA 0x00be78a3 ; Catch@00be78a3 */

undefined4 Catch_00be78a3(void)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0x48) + 4))("PointsService:AwardPoints");
  puVar3 = (undefined4 *)FUN_01675640(unaff_EBP + -0x78,"%s failed because %s",uVar2);
  uVar1 = puVar3[5];
  *(undefined *)(unaff_EBP + -4) = 8;
  if (0xf < uVar1) {
    puVar3 = (undefined4 *)*puVar3;
  }
  FUN_00be5160(*(int *)(unaff_EBP + 0x10) + 4,puVar3);
  FUN_005507b0();
  return 0xbe7892;
}



/* FUNCTION 26658 ; VA 0x00be7900 ; FUN_00be7900 */

int FUN_00be7900(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802230;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 != 0) {
    iStack_18 = FUN_00be1df0(iStack_18 + 0xc);
    if (iStack_18 != 0) {
      iStack_18 = FUN_00be5f20();
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iStack_18 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iStack_18 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iStack_18 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 26659 ; VA 0x00be79a0 ; FUN_00be79a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00be79a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802260;
  pvStack_10 = ExceptionList;
  if (DAT_01ef71cc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef73e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef73e0);
      if (DAT_01ef73e0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ReplicatedFirst",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef73d8 = RBX::Creator<class_RBX::ReplicatedFirst>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef71d0,&DAT_01ef73d8);
        FUN_016f3654(FUN_01892860);
        FUN_016f37bf(&DAT_01ef73e0);
      }
    }
    DAT_01ef71cc = &DAT_01ef71d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef71cc;
}



/* FUNCTION 26660 ; VA 0x00be7aa0 ; FUN_00be7aa0 */

void FUN_00be7aa0(void)

{
  int iVar1;
  
  if (DAT_01ef73e4 == 0) {
    iVar1 = FUN_00be79a0();
    DAT_01ef73e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26661 ; VA 0x00be7ac0 ; FUN_00be7ac0 */

void * __thiscall FUN_00be7ac0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  void *pvVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  int *piVar11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017fd690;
  puVar10 = *(undefined4 **)(param_1 + 0x2c);
  pvVar7 = ExceptionList;
  if (puVar10 != (undefined4 *)0x0) {
    piVar8 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(param_1 + 0x30);
      puVar10 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar10[1];
    piVar11 = (int *)*puVar10;
    iStack_8 = 0;
    pvVar7 = pvStack_10;
    for (; piVar11 != piVar1; piVar11 = piVar11 + 2) {
      piVar9 = (int *)piVar11[1];
      iVar2 = *param_2;
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
        piVar9 = (int *)piVar11[1];
      }
      iVar3 = *piVar11;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if (((iVar3 != 0) &&
          (iVar4 = *(int *)(iVar3 + 0xc), iVar6 = FUN_00b739e0(),
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da))) &&
         (cVar5 = (*(code *)**(undefined4 **)(iVar2 + 0x58))(iVar3), cVar5 != '\0')) {
        FUN_00b75290();
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar2 = piVar9[1] + -1;
        piVar9[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar2 = piVar9[2] + -1;
          piVar9[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      pvVar7 = (void *)FUN_00be7ac0(param_2);
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar1 = piVar8 + 1;
      iVar2 = *piVar1;
      pvVar7 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar7 = (void *)(**(code **)*piVar8)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar7 = (void *)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 26662 ; VA 0x00be7c10 ; FUN_00be7c10 */

undefined4 * __thiscall
FUN_00be7c10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00be79a0();
  FUN_009cb970(uVar1,param_3,param_4,CONCAT44(uStack_1c,uStack_20),0);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ReplicatedFirst,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ReplicatedFirst::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ReplicatedFirst,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ReplicatedFirst::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26663 ; VA 0x00be7ce0 ; FUN_00be7ce0 */

undefined4 * __fastcall FUN_00be7ce0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018022a9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ReplicatedFirst,class_RBX::ServiceInstance>::vftable
  ;
  uVar1 = FUN_00be79a0();
  param_1[3] = uVar1;
  param_1[0x16] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::ReplicatedFirst::vftable;
  param_1[0x16] = RBX::ReplicatedFirst::vftable;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  *(undefined2 *)(param_1 + 0x1a) = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("ReplicatedFirst",0xf);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26664 ; VA 0x00be7dd0 ; FUN_00be7dd0 */

void __fastcall FUN_00be7dd0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ReplicatedFirst>::vftable;
  uVar1 = FUN_00be79a0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26665 ; VA 0x00be7e10 ; FUN_00be7e10 */

undefined4 __thiscall FUN_00be7e10(undefined4 param_1,byte param_2)

{
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x6c);
  }
  return param_1;
}



/* FUNCTION 26666 ; VA 0x00be7e50 ; FUN_00be7e50 */

uint FUN_00be7e50(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b739e0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00c6de80();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
      goto LAB_00be7eaa;
    }
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_00be7eaa:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 26667 ; VA 0x00be7ec0 ; FUN_00be7ec0 */

undefined4 * FUN_00be7ec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00672ef0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 26668 ; VA 0x00be7f40 ; FUN_00be7f40 */

void FUN_00be7f40(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  
  uVar1 = *(undefined4 *)(param_1 + 0x18);
  cVar2 = FUN_0097c970(uVar1,1);
  if (cVar2 != '\0') {
    cVar2 = FUN_00971ce0(uVar1,1);
    if (cVar2 != '\0') {
      FUN_00be82a0();
      return;
    }
  }
  return;
}



/* FUNCTION 26669 ; VA 0x00be7f80 ; FUN_00be7f80 */

uint FUN_00be7f80(void)

{
  int iVar1;
  
  iVar1 = FUN_00be79a0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 26670 ; VA 0x00be7fa0 ; FUN_00be7fa0 */

uint FUN_00be7fa0(void)

{
  int iVar1;
  
  iVar1 = FUN_00be79a0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 26671 ; VA 0x00be7fc0 ; FUN_00be7fc0 */

void __thiscall FUN_00be7fc0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802361;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    iVar4 = FUN_008f7870(param_3);
    if (iVar4 != 0) {
      uStack_8 = 0;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 1;
      puVar6 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puVar6 = 0;
        puVar6[1] = 1;
        puVar6[2] = FUN_00be7f40;
        puVar6[3] = _guard_check_icall;
        puVar6[4] = 0;
        puVar6[5] = iVar4 + 0xac;
        puVar6[6] = param_1;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_01675290(uVar5);
      uStack_8 = 0xffffffff;
      if (puVar6 != (undefined4 *)0x0) {
        piVar1 = puVar6 + 1;
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(puVar6);
        }
      }
      if (*(char *)(iVar4 + 0x240) != '\0') {
        cVar3 = FUN_0097c970(param_1,1);
        if (cVar3 != '\0') {
          cVar3 = FUN_00971ce0(param_1,1);
          if (cVar3 != '\0') {
            FUN_00be82a0();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26672 ; VA 0x00be8110 ; FUN_00be8110 */

uint __thiscall FUN_00be8110(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  uint in_EAX;
  int iVar3;
  int iVar4;
  
  if (param_2 == 0) goto LAB_00be81aa;
  if (*(int *)(param_2 + 0x34) != param_1 + -0x58) {
    in_EAX = FUN_008a3680(*(int *)(param_2 + 0x34));
    if ((char)in_EAX == '\0') goto LAB_00be81aa;
  }
  cVar2 = FUN_0097c970(param_2,1);
  if (cVar2 == '\0') {
LAB_00be8154:
    in_EAX = FUN_0097c970(param_2,1);
    if ((char)in_EAX == '\0') goto LAB_00be81aa;
    in_EAX = FUN_00971ce0(param_2,1);
    if ((char)in_EAX != '\0') goto LAB_00be81aa;
  }
  else {
    in_EAX = FUN_00971ce0(param_2,1);
    if ((char)in_EAX == '\0') goto LAB_00be8154;
  }
  if (*(char *)(param_1 + 0x11) != '\0') {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00b739e0();
    in_EAX = (uint)*(ushort *)(iVar3 + 0x1da);
    iVar4 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= in_EAX) {
      iVar4 = param_2;
    }
    if (iVar4 != 0) {
      return CONCAT31((uint3)(byte)(*(ushort *)(iVar3 + 0x1da) >> 8),1);
    }
  }
LAB_00be81aa:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 26673 ; VA 0x00be81c0 ; FUN_00be81c0 */

void FUN_00be81c0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  undefined auStack_e4 [192];
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802380;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_4 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    (*(code *)*param_4)(&stack0x00000014,auStack_e4);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  FUN_00acac20(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_20 = (undefined *)0xbe8263;
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_20 = (undefined *)0xbe8272;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = 2;
  if (param_4 != (undefined4 *)0x0) {
    puStack_20 = &stack0x00000014;
    uStack_24 = 0xbe8289;
    (*(code *)param_4[2])();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26674 ; VA 0x00be82a0 ; FUN_00be82a0 */

void __fastcall FUN_00be82a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined auStack_e4 [192];
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_8;
  
  *(undefined *)(param_1 + 0x69) = 1;
  if (*(int *)(param_1 + 0x2c) != 0) {
    piStack_20 = &iStack_8;
    uStack_24 = 0xbe82c4;
    iStack_8 = param_1;
    FUN_00be7ac0();
  }
  if (DAT_01eeb4f1 != '\0') {
    iVar3 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    if ((iVar3 != 0) && (iVar2 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      piStack_20 = (int *)0xbe82e4;
      iVar2 = FUN_005c8ac0();
    }
    if (iVar2 != 0) {
      iVar3 = *(int *)(iVar2 + 0xc);
      piStack_20 = (int *)0xbe82f6;
      iVar2 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        piStack_20 = (int *)0xbe8318;
        FUN_00674d10();
      }
    }
    uStack_24 = 0xbe8324;
    piStack_20 = (int *)param_1;
    iVar3 = FUN_008f7870();
    if (iVar3 != 0) {
      piVar5 = *(int **)(iVar3 + 0x454);
      iStack_8 = piVar5[1] - (int)piVar5;
      if (((*DAT_01eeb570 - (int)DAT_01eeb570 == *piVar5 - (int)piVar5) &&
          (DAT_01eeb570[1] - (int)DAT_01eeb570 == iStack_8)) &&
         (*DAT_01eeb574 - (int)DAT_01eeb574 == *(int *)(iVar3 + 0x458))) {
        if (DAT_01eeb58c != (undefined4 *)0x0) {
          (*(code *)*DAT_01eeb58c)(&DAT_01eeb590,auStack_e4);
        }
        uVar4 = DAT_01eeb578;
        piVar5 = DAT_01eeb57c;
        if (DAT_01eeb57c != (int *)0x0) {
          LOCK();
          DAT_01eeb57c[1] = DAT_01eeb57c[1] + 1;
          UNLOCK();
          uVar4 = DAT_01eeb578;
          piVar5 = DAT_01eeb57c;
        }
      }
      else {
        FUN_00888530();
        uVar4 = 0;
        piVar5 = (int *)0x0;
      }
      FUN_00be81c0(uVar4,piVar5);
      piVar5 = DAT_01eeb57c;
      DAT_01eeb578 = 0;
      DAT_01eeb57c = (int *)0x0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          piStack_20 = (int *)0xbe8445;
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            piStack_20 = (int *)0xbe8454;
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  piStack_20 = (int *)0xbe845c;
  FUN_006eccd0();
  return;
}



/* FUNCTION 26675 ; VA 0x00be8470 ; FUN_00be8470 */

void __fastcall FUN_00be8470(int param_1)

{
  *(undefined *)(param_1 + 0x68) = 1;
  FUN_006eccd0();
  return;
}



/* FUNCTION 26676 ; VA 0x00be8480 ; FUN_00be8480 */

undefined * FUN_00be8480(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180239c;
  pvStack_10 = ExceptionList;
  if (DAT_01ef73e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef75f8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef75f8);
      if (DAT_01ef75f8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"JointsService",1,uStack_20,0,0,3,0,0);
        FUN_016f3654(&LAB_01892990);
        FUN_016f37bf(&DAT_01ef75f8);
      }
    }
    DAT_01ef73e8 = &DAT_01ef73f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef73e8;
}



/* FUNCTION 26677 ; VA 0x00be8560 ; FUN_00be8560 */

void FUN_00be8560(void)

{
  int iVar1;
  
  if (DAT_01ef75fc == 0) {
    iVar1 = FUN_00be8480();
    DAT_01ef75fc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26678 ; VA 0x00be8580 ; FUN_00be8580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_00be8580(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018023fb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00be8480();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::JointsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    puStack_e4 = (undefined4 *)0x0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288) {
      FUN_016f3809(&DAT_01ead288);
      if (DAT_01ead288 == -1) {
        DAT_01ead27c = FUN_0057bbb0;
        _DAT_01ead280 = FUN_005880a0;
        DAT_01ead284 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ead288);
      }
    }
    puStack_e4 = &DAT_01ead27c;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined4 *)0x0) {
      (*(code *)puStack_e4[2])(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26679 ; VA 0x00be8790 ; FUN_00be8790 */

undefined4 * __fastcall FUN_00be8790(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180248f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::JointsService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00be8480();
  param_1[3] = uVar1;
  *param_1 = RBX::JointsService::vftable;
  param_1[0x16] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0xf;
  *(undefined *)(param_1 + 0x17) = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  FUN_00f31e80();
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  uStack_8._0_1_ = 9;
  param_1[0x37] = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("JointsService",0xd);
  uStack_8._0_1_ = 10;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_11 = 0;
  (**(code **)(*DAT_02119b74 + 0x10))(param_1,&uStack_11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26680 ; VA 0x00be8900 ; FUN_00be8900 */

void __fastcall FUN_00be8900(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0xd8);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    ExceptionList = &pvStack_10;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = *(int **)(param_1 + 0xd0);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_00f31fb0();
  piVar1 = *(int **)(param_1 + 0x88);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x80);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x7c);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x78);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uVar2 = *(uint *)(param_1 + 0x70);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x5c);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x5c) = 0;
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26681 ; VA 0x00be8aa0 ; FUN_00be8aa0 */

undefined4 __thiscall FUN_00be8aa0(undefined4 param_1,byte param_2)

{
  FUN_00be8900();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe0);
  }
  return param_1;
}



/* FUNCTION 26682 ; VA 0x00be8ad0 ; FUN_00be8ad0 */

bool FUN_00be8ad0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c391f0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00be8b02;
  }
  param_1 = 0;
LAB_00be8b02:
  return param_1 != 0;
}



/* FUNCTION 26683 ; VA 0x00be8b10 ; FUN_00be8b10 */

void __fastcall FUN_00be8b10(int param_1)

{
  FUN_00f321d0();
  *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_1 + 0xb0);
  return;
}



/* FUNCTION 26684 ; VA 0x00be8c40 ; FUN_00be8c40 */

void FUN_00be8c40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_00be8f60(param_2,param_3,param_4,param_5);
  return;
}



/* FUNCTION 26685 ; VA 0x00be8c60 ; FUN_00be8c60 */

void FUN_00be8c60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_00be8da0(param_2,param_3,param_4,param_5);
  return;
}



/* FUNCTION 26686 ; VA 0x00be8c80 ; FUN_00be8c80 */

void FUN_00be8c80(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01efa9f8);
  uStack_8 = 0;
  iVar2 = FUN_00ca12e0();
  if ((iVar2 != 0) &&
     (((iVar2 = (**(code **)(*param_2 + 0x10))(), iVar2 - 1U < 0xb && (iVar2 != 4)) ||
      (iVar2 = (**(code **)(*param_2 + 0x10))(), iVar2 == 4)))) {
    FUN_008a65e0(0,0);
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26687 ; VA 0x00be8d20 ; FUN_00be8d20 */

void FUN_00be8d20(undefined4 param_1)

{
  int iVar1;
  
  FUN_008a4130(param_1);
  iVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0115aba0(iVar1);
  }
  return;
}



/* FUNCTION 26688 ; VA 0x00be8d60 ; FUN_00be8d60 */

void FUN_00be8d60(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_0170d75d(*param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0115abe0(iVar1);
  }
  FUN_008a41c0(param_1);
  return;
}



/* FUNCTION 26689 ; VA 0x00be8da0 ; FUN_00be8da0 */

void FUN_00be8da0(int param_1,int param_2,undefined4 param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802508;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01efa9f8);
  uStack_8 = 0;
  uStack_18 = 0xffffffff;
  FUN_00b03160(&uStack_18,&cStack_11,&uStack_1c,param_3);
  if ((param_4 != '\0') || (cStack_11 != '\0')) {
    if (param_2 == 0) {
      if ((*(int *)(param_1 + 0x2c) != 0) && (*(int *)(param_1 + 0x30) != 0)) {
        iVar3 = FUN_00c156f0();
        iVar4 = FUN_00c156f0();
        if (iVar3 != iVar4) goto LAB_00be8f3d;
      }
      if ((*(int *)(param_1 + 0x2c) != 0) || (*(int *)(param_1 + 0x30) != 0)) {
        iVar3 = FUN_00c15700();
        uVar5 = FUN_00b06640(iVar3);
        if (iVar3 != 0) {
          cVar1 = FUN_00b094d0(uVar5);
          if ((cVar1 == '\0') && (cStack_11 != '\0')) {
            FUN_00b0e040(uStack_18,uStack_1c);
          }
          if (param_4 != '\0') {
            uVar5 = FUN_00c155c0();
            FUN_00ca1cb0(uVar5);
          }
        }
      }
    }
    else {
      iVar3 = FUN_00c160f0();
      if (iVar3 != 0) {
        iVar3 = FUN_00c155c0();
        iVar4 = 0;
        if (0 < *(int *)(iVar3 + 0x14)) {
          do {
            iVar6 = *(int *)(*(int *)(iVar3 + 0x10) + iVar4 * 4);
            uVar7 = -(uint)(iVar6 != 0) & iVar6 - 8U;
            cVar1 = FUN_00c1a1b0(uVar7);
            if (cVar1 != '\0') {
              iVar6 = FUN_00ca1550();
              uVar5 = FUN_00b06640(iVar6);
              if (((param_2 == iVar6) || (cVar1 = FUN_00c16ba0(iVar6), cVar1 != '\0')) &&
                 (cVar1 = FUN_00b094d0(uVar5), cVar1 == '\0')) {
                FUN_00b0e040(uStack_18,uStack_1c);
              }
              if (param_4 != '\0') {
                FUN_00ca1cb0(uVar7);
              }
            }
            iVar4 = iVar4 + 1;
          } while (iVar4 < *(int *)(iVar3 + 0x14));
        }
      }
    }
  }
LAB_00be8f3d:
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26690 ; VA 0x00be8f60 ; FUN_00be8f60 */

void FUN_00be8f60(int param_1,int *param_2,int *param_3,char param_4)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802528;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_01675290(DAT_01efa9f8);
  uStack_8 = 0;
  param_1 = 0;
  iStack_14 = 0;
  if ((*(int *)(iVar6 + 0x2c) != 0) && (*(int *)(iVar6 + 0x30) != 0)) {
    iStack_14 = FUN_00c15700();
    param_1 = FUN_00c15700();
    if ((iStack_14 != 0) && ((param_1 != 0 && (3 < (uint)(param_2[1] - *param_2))))) {
      iVar6 = 0;
      do {
        iVar7 = param_1;
        if (iVar6 == 0) {
          iVar7 = iStack_14;
        }
        uVar4 = FUN_00b06640(iVar7);
        cVar3 = FUN_00b094d0(uVar4);
        if (cVar3 == '\0') {
          FUN_00b0e040(*(undefined4 *)(*(int *)*param_2 + 0x1dc),
                       *(char *)(*(int *)*param_2 + 0x22c) == '\x01');
        }
        else {
          FUN_00b0e550(0);
        }
        if (param_4 != '\0') {
          uVar4 = FUN_00c155c0();
          FUN_00ca1cb0(uVar4);
        }
        iVar6 = iVar6 + 1;
      } while (iVar6 < 2);
      goto LAB_00be90e9;
    }
  }
  piVar2 = param_2;
  iVar7 = 0;
  iVar6 = iStack_14;
  do {
    uStack_18 = 0xffffffff;
    piVar5 = param_3;
    iVar1 = param_1;
    if (iVar7 == 0) {
      piVar5 = piVar2;
      iVar1 = iVar6;
    }
    if (iVar1 != 0) {
      FUN_00b03160(&uStack_18,(int)&param_2 + 3,&uStack_20,piVar5);
      uVar4 = FUN_00b06640(iVar1);
      if ((param_2._3_1_ != '\0') && (cVar3 = FUN_00b094d0(uVar4), cVar3 == '\0')) {
        FUN_00b0e040(uStack_18,uStack_20);
      }
      iVar6 = iStack_14;
      if (param_4 != '\0') {
        uVar4 = FUN_00c155c0();
        FUN_00ca1cb0(uVar4);
        iVar6 = iStack_14;
      }
    }
    iVar7 = iVar7 + 1;
  } while (iVar7 < 2);
LAB_00be90e9:
  uStack_8 = 2;
  FUN_01675290(uStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26691 ; VA 0x00be9110 ; FUN_00be9110 */

void __thiscall FUN_00be9110(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_018025a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  FUN_01679490();
  FUN_01679490();
  iVar3 = (int)param_3;
  *(undefined4 *)(param_1 + 0xdc) = 0;
  FUN_008a4210(param_2,param_3);
  if (iVar3 != 0) {
    iVar3 = FUN_00562f00();
    if (iVar3 != 0) {
      *(undefined4 *)(param_1 + 0xdc) = *(undefined4 *)(iVar3 + 0x1b4);
      iVar7 = *(int *)(iVar3 + 0x21c);
      if (iVar7 != 0) {
        LOCK();
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
        UNLOCK();
        iVar7 = *(int *)(iVar3 + 0x21c);
      }
      *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(iVar3 + 0x218);
      piVar1 = *(int **)(param_1 + 0x88);
      *(int *)(param_1 + 0x88) = iVar7;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uVar6 = *(undefined4 *)(param_1 + 0xdc);
      iStack_8 = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      puVar5 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00be8c60;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = uVar6;
        puVar5[6] = param_1;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 2;
      param_3 = puVar5;
      FUN_01675290(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar2 = FUN_01679300(&param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_3);
        }
      }
      iVar3 = *(int *)(param_1 + 0xdc);
      iStack_8 = 3;
      uVar6 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 4;
      puVar5 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00be8c40;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = iVar3 + 4;
        puVar5[6] = param_1;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 5;
      param_3 = puVar5;
      FUN_01675290(uVar6);
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      cVar2 = FUN_01679300(&param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_3);
        }
      }
      iVar3 = *(int *)(param_1 + 0xdc);
      iStack_8 = 6;
      uVar6 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 7;
      puVar5 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00be8c80;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = iVar3 + 0xc;
        puVar5[6] = param_1;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 8;
      param_3 = puVar5;
      FUN_01675290(uVar6);
      iStack_8 = CONCAT31(iStack_8._1_3_,6);
      cVar2 = FUN_01679300(&param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26692 ; VA 0x00be94b0 ; FUN_00be94b0 */

int __thiscall FUN_00be94b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::PVInstance::RTTI_Type_Descriptor,0);
  if (iVar3 == 0) {
    iVar3 = 0;
    piVar4 = (int *)0x0;
  }
  else {
    piVar4 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
  }
  *(int *)(param_1 + 0xcc) = iVar3;
  piVar2 = *(int **)(param_1 + 0xd0);
  *(int **)(param_1 + 0xd0) = piVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar4 = piVar2 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar4 = piVar2 + 2;
      iVar1 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26693 ; VA 0x00be9580 ; FUN_00be9580 */

int __thiscall FUN_00be9580(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::PVInstance::RTTI_Type_Descriptor,0);
  if (iVar3 == 0) {
    iVar3 = 0;
    piVar4 = (int *)0x0;
  }
  else {
    piVar4 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
  }
  *(int *)(param_1 + 0xd4) = iVar3;
  piVar2 = *(int **)(param_1 + 0xd8);
  *(int **)(param_1 + 0xd8) = piVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar4 = piVar2 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar4 = piVar2 + 2;
      iVar1 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 26694 ; VA 0x00be9710 ; FUN_00be9710 */

undefined4 * __thiscall
FUN_00be9710(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  int *in_stack_00000030;
  undefined auStack_74 [8];
  uint uStack_6c;
  undefined auStack_64 [28];
  int *piStack_48;
  undefined auStack_44 [8];
  uint uStack_3c;
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018025c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00bec830(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00bec830(auStack_74);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00bec830(auStack_44);
  ppuVar4 = &PTR_FUN_01960508;
  cVar3 = FUN_00beaf30();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
    }
    uStack_3c = 0;
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_48[2] + -1;
    piStack_48[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_48 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_6c != 0) {
    if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
    }
    uStack_6c = 0;
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000030 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000030 + 4))();
    }
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26695 ; VA 0x00be9860 ; FUN_00be9860 */

undefined4 * __thiscall FUN_00be9860(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 extraout_ECX;
  undefined **ppuVar5;
  int *in_stack_00000010;
  int *in_stack_00000018;
  int *piStack_2c;
  int *piStack_24;
  undefined auStack_20 [12];
  int *piStack_14;
  int *piStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  FUN_00becb30(&stack0x00000004);
  *param_1 = 0;
  FUN_00becb30(extraout_ECX);
  FUN_00becb30(auStack_20);
  ppuVar5 = &PTR_FUN_01960548;
  cVar4 = FUN_00beb220();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[2] + -1;
    piStack_24[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000018[2] + -1;
    in_stack_00000018[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_00000018 + 4))();
    }
  }
  piVar3 = in_stack_00000010;
  if (in_stack_00000010 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000010[1] + -1;
    in_stack_00000010[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000010)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 26696 ; VA 0x00be9970 ; FUN_00be9970 */

undefined4 * __thiscall
FUN_00be9970(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01960558;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 26697 ; VA 0x00be9a60 ; FUN_00be9a60 */

undefined4 * __thiscall FUN_00be9a60(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined4 in_stack_00000024;
  int in_stack_00000028;
  undefined auStack_114 [64];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_b4;
  int iStack_b0;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  undefined auStack_6c [24];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [24];
  undefined4 uStack_34;
  int iStack_30;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802662;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_94;
  uStack_8 = 0;
  uStack_94 = param_2;
  uStack_90 = param_3;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  FUN_00bedad0(&stack0x0000000c);
  if (in_stack_00000028 != 0) {
    LOCK();
    *(int *)(in_stack_00000028 + 8) = *(int *)(in_stack_00000028 + 8) + 1;
    UNLOCK();
  }
  uStack_74 = in_stack_00000024;
  iStack_70 = in_stack_00000028;
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&stack0x0000002c);
  puStack_14 = &uStack_54;
  uStack_8._0_1_ = 3;
  uStack_54 = uStack_94;
  uStack_50 = uStack_90;
  FUN_00bedad0(auStack_8c);
  if (iStack_70 != 0) {
    LOCK();
    *(int *)(iStack_70 + 8) = *(int *)(iStack_70 + 8) + 1;
    UNLOCK();
  }
  uStack_34 = uStack_74;
  iStack_30 = iStack_70;
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_6c);
  puStack_14 = &uStack_d4;
  uStack_8._0_1_ = 6;
  uStack_d4 = uStack_54;
  uStack_d0 = uStack_50;
  FUN_00bedad0(auStack_4c);
  if (iStack_30 != 0) {
    LOCK();
    *(int *)(iStack_30 + 8) = *(int *)(iStack_30 + 8) + 1;
    UNLOCK();
  }
  uStack_b4 = uStack_34;
  iStack_b0 = iStack_30;
  uStack_8._0_1_ = 8;
  FUN_0054ef60(auStack_2c);
  uStack_8._0_1_ = 9;
  cVar2 = FUN_00585a40(&uStack_d4);
  if (cVar2 == '\0') {
    FUN_00becb90(&uStack_d4);
    uStack_8._0_1_ = 10;
    puStack_14 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8._0_1_ = 0xb;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_00becb90(auStack_114);
    }
    param_1[2] = uVar3;
    FUN_00bee030();
    FUN_00bee030();
    bVar1 = true;
  }
  else {
    FUN_00bee030();
    bVar1 = false;
  }
  FUN_00bee030();
  ppuVar4 = &PTR_FUN_01960538;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00bee030();
  FUN_00bee030();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26698 ; VA 0x00be9c80 ; FUN_00be9c80 */

undefined4 * __thiscall FUN_00be9c80(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000002c;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_bc;
  undefined *puStack_b8;
  undefined *puStack_b4;
  undefined4 *puStack_b0;
  undefined auStack_9c [32];
  uint uStack_7c;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [32];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180268b;
  pvStack_10 = ExceptionList;
  puStack_b0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_b4 = (undefined *)0xbe9ccd;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00becef0();
  uStack_5c = param_2;
  uStack_58 = param_3;
  puStack_b0 = (undefined4 *)auStack_9c;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_b4 = (undefined *)0xbe9cf8;
  FUN_00becef0();
  puStack_b0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = &uStack_f8;
  uStack_f8 = uStack_5c;
  uStack_f4 = uStack_58;
  FUN_00becef0(auStack_54);
  ppuVar2 = &PTR_FUN_01960540;
  cVar1 = FUN_00beb370();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_b8 = auStack_2c;
      puStack_b0 = (undefined4 *)0x2;
      uStack_bc = 0xbe9d55;
      puStack_b4 = puStack_b8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_b0 = (undefined4 *)0xbe9d67;
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_7c != 0) {
    if (((uStack_7c & 1) == 0) && (*(code **)(uStack_7c & 0xfffffffe) != (code *)0x0)) {
      puStack_b8 = auStack_74;
      puStack_b0 = (undefined4 *)0x2;
      uStack_bc = 0xbe9d88;
      puStack_b4 = puStack_b8;
      (**(code **)(uStack_7c & 0xfffffffe))();
    }
    uStack_7c = 0;
  }
  puStack_b0 = (undefined4 *)0xbe9d9d;
  FUN_00612320();
  uStack_8 = 5;
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      puStack_b8 = &stack0x00000034;
      puStack_b0 = (undefined4 *)0x2;
      uStack_bc = 0xbe9dc1;
      puStack_b4 = puStack_b8;
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  puStack_b0 = (undefined4 *)0xbe9dd3;
  FUN_00612320();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26699 ; VA 0x00be9df0 ; FUN_00be9df0 */

undefined4 * __thiscall FUN_00be9df0(undefined4 *param_1)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000001c;
  undefined auStack_84 [24];
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018026b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00becc80(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00becc80(auStack_84);
  uStack_8._0_1_ = 2;
  FUN_00becc80(auStack_4c);
  ppuVar2 = &PTR_FUN_01960530;
  cVar1 = FUN_00beb520();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_6c != 0) {
    if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
    }
    uStack_6c = 0;
  }
  uStack_8 = 5;
  if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
     (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26700 ; VA 0x00be9f00 ; FUN_00be9f00 */

void __thiscall FUN_00be9f00(int param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  code *pcVar4;
  int iVar5;
  uint *puVar6;
  int *piVar7;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  ulonglong uStack_58;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  ulonglong uStack_30;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018026e0;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uStack_1c = *(undefined4 *)(param_1 + 8);
  uStack_18 = *(undefined4 *)(param_1 + 0xc);
  uVar2 = *(uint *)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_58 = ZEXT48(&uStack_40);
      iStack_5c = param_1 + 0x18;
      uStack_60 = 0xbe9f68;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = *(undefined4 *)(param_1 + 0x18);
      uStack_3c = *(undefined4 *)(param_1 + 0x1c);
      uStack_38 = *(undefined4 *)(param_1 + 0x20);
      iStack_34 = *(int *)(param_1 + 0x24);
      uStack_30 = *(ulonglong *)(param_1 + 0x28);
      ExceptionList = &pvStack_10;
    }
  }
  puVar3 = (undefined4 *)*param_4;
  piVar7 = (int *)puVar3[1];
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = (int *)puVar3[1];
  }
  uStack_28 = *puVar3;
  puStack_20 = (undefined *)auStack_70;
  uStack_8 = 1;
  pcVar4 = (code *)*param_3;
  auStack_70[0] = 0;
  piStack_24 = piVar7;
  puVar6 = auStack_70;
  uStack_14 = uStack_28;
  if (uStack_48 != 0) {
    auStack_70[0] = uStack_48;
    if ((uStack_48 & 1) == 0) {
      (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_68,0);
      puVar6 = (uint *)puStack_20;
    }
    else {
      uStack_68 = uStack_40;
      uStack_64 = uStack_3c;
      uStack_60 = uStack_38;
      iStack_5c = iStack_34;
      uStack_58 = uStack_30;
      puVar6 = auStack_70;
    }
  }
  puStack_20 = (undefined *)puVar6;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
  }
  (*pcVar4)(uStack_1c,uStack_18,uStack_14,piVar7);
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = piVar7[1] + -1;
    piVar7[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = 2;
  if (((uStack_48 != 0) && ((uStack_48 & 1) == 0)) &&
     (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_40,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26701 ; VA 0x00bea080 ; FUN_00bea080 */

void __thiscall
FUN_00bea080(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802708;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  uVar2 = param_1[0x10];
  ExceptionList = &pvStack_10;
  if ((uVar2 != 0) && (ExceptionList = &pvStack_10, (uVar2 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar2 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar2 = param_1[8];
  if ((uVar2 != 0) && ((uVar2 & 1) == 0)) {
    (**(code **)(uVar2 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 1;
  FUN_00bedad0(param_1 + 1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(*param_4);
  uStack_8 = 0xffffffff;
  FUN_00befd40(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26702 ; VA 0x00bea180 ; FUN_00bea180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00bea180(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802740;
  pvStack_10 = ExceptionList;
  if (DAT_01ef763c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef7850) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef7850);
      if (DAT_01ef7850 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"FriendService",1,uStack_20,0,0,3,0,0);
        _DAT_01ef7848 = RBX::Creator<class_RBX::FriendService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef7640,&DAT_01ef7848);
        FUN_016f3654(FUN_01892a60);
        FUN_016f37bf(&DAT_01ef7850);
      }
    }
    DAT_01ef763c = &DAT_01ef7640;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef763c;
}



/* FUNCTION 26703 ; VA 0x00bea280 ; FUN_00bea280 */

void FUN_00bea280(void)

{
  int iVar1;
  
  if (DAT_01ef7854 == 0) {
    iVar1 = FUN_00bea180();
    DAT_01ef7854 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 26704 ; VA 0x00bea2a0 ; FUN_00bea2a0 */

void __thiscall FUN_00bea2a0(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar2 = param_1[1];
  iVar4 = *param_1;
  uVar3 = param_1[2] - iVar4 >> 6;
  uVar6 = param_3 - param_2 >> 6;
  uVar1 = iVar2 - iVar4 >> 6;
  if (uVar6 <= uVar3) {
    if (uVar1 < uVar6) {
      iVar2 = uVar1 * 0x40 + param_2;
      FUN_00bea410(param_2,iVar2,iVar4);
      iVar2 = FUN_00beae30(iVar2,param_3,param_1[1],param_1);
      param_1[1] = iVar2;
      return;
    }
    FUN_00bea410(param_2,param_3,iVar4);
    iVar2 = param_1[1];
    iVar4 = uVar6 * 0x40 + iVar4;
    for (iVar5 = iVar4; iVar5 != iVar2; iVar5 = iVar5 + 0x40) {
      FUN_008c3510();
    }
    param_1[1] = iVar4;
    return;
  }
  if (uVar6 < 0x4000000) {
    uVar1 = uVar6;
    if ((uVar3 <= 0x3ffffff - (uVar3 >> 1)) && (uVar1 = (uVar3 >> 1) + uVar3, uVar1 < uVar6)) {
      uVar1 = uVar6;
    }
    if (iVar4 != 0) {
      if (iVar4 != iVar2) {
        do {
          FUN_008c3510();
          iVar4 = iVar4 + 0x40;
        } while (iVar4 != iVar2);
        iVar4 = *param_1;
      }
      FUN_0089eda0(iVar4,uVar3);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar1 != 0) {
      if (0x3ffffff < uVar1) goto LAB_00bea3fd;
      iVar2 = FUN_008c8200(uVar1);
      *param_1 = iVar2;
      param_1[1] = iVar2;
      param_1[2] = uVar1 * 0x40 + *param_1;
    }
    iVar2 = FUN_00beae30(param_2,param_3,*param_1,param_1);
    param_1[1] = iVar2;
    return;
  }
LAB_00bea3fd:
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 26705 ; VA 0x00bea410 ; FUN_00bea410 */

int FUN_00bea410(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_1 != param_2) {
    iVar1 = param_1 - param_3;
    do {
      FUN_00bee6d0(param_1);
      FUN_008c4480(iVar1 + 0x20 + param_3);
      param_1 = param_1 + 0x40;
      param_3 = param_3 + 0x40;
    } while (param_1 != param_2);
  }
  return param_3;
}



/* FUNCTION 26706 ; VA 0x00bea450 ; FUN_00bea450 */

void FUN_00bea450(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar3 = param_1 + 8;
    ExceptionList = &pvStack_10;
    do {
      uVar2 = *puVar3;
      uStack_8 = 0;
      if (uVar2 != 0) {
        if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,puVar3 + 2,2);
        }
        *puVar3 = 0;
      }
      uVar2 = puVar3[-8];
      uStack_8 = 1;
      if (uVar2 != 0) {
        if (((uVar2 & 1) == 0) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar3 + -6,puVar3 + -6,2);
        }
        puVar3[-8] = 0;
      }
      puVar1 = puVar3 + 8;
      puVar3 = puVar3 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26707 ; VA 0x00bea500 ; FUN_00bea500 */

int __thiscall FUN_00bea500(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802750;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xd0;
  if (iVar2 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd0;
  uVar7 = uVar1;
  if ((uVar3 <= 0x13b13b1 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00578090(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd0) * 0xd0;
  iVar6 = iVar5 + iVar4;
  FUN_00bebf00(param_1,iVar6,param_3);
  if (param_2 == param_1[1]) {
    FUN_0055c5a0(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar4);
    FUN_005cb700(param_2,param_1[1],iVar6 + 0xd0);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 26708 ; VA 0x00bea644 ; Catch_All@00bea644 */

void Catch_All_00bea644(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26709 ; VA 0x00bea670 ; FUN_00bea670 */

int __thiscall FUN_00bea670(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802760;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  iVar3 = (param_1[1] - iVar6) / 0xd0;
  if (iVar3 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar4 = (param_1[2] - iVar6) / 0xd0;
  uVar9 = uVar1;
  if ((uVar4 <= 0x13b13b1 - (uVar4 >> 1)) && (uVar9 = (uVar4 >> 1) + uVar4, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00578090(uVar9);
  uStack_8 = 0;
  iVar6 = ((param_2 - iVar6) / 0xd0) * 0xd0;
  uVar7 = FUN_008881d0();
  puVar8 = (undefined4 *)(iVar6 + iVar5);
  *puVar8 = uVar7;
  puVar8[1] = 0;
  puVar8[2] = 0;
  puVar8[3] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  puVar8[2] = *param_3;
  puVar8[3] = param_3[1];
  uVar7 = FUN_005ea820();
  *(undefined4 *)(iVar6 + iVar5 + 4) = uVar7;
  if (param_2 == param_1[1]) {
    FUN_0055c5a0(*param_1,param_1[1],iVar5,param_1);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar5);
    FUN_005cb700(param_2,param_1[1],iVar6 + 0xd0 + iVar5);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar5,iVar3 + 1,uVar9);
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 26710 ; VA 0x00bea7ea ; Catch_All@00bea7ea */

void Catch_All_00bea7ea(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26711 ; VA 0x00bea820 ; FUN_00bea820 */

int __thiscall FUN_00bea820(int *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01802778;
  pvStack_10 = ExceptionList;
  iVar7 = *param_1;
  iVar2 = param_1[1] - iVar7 >> 6;
  if (iVar2 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = param_1[2] - iVar7 >> 6;
  uVar5 = uVar1;
  if ((uVar3 <= 0x3ffffff - (uVar3 >> 1)) && (uVar5 = (uVar3 >> 1) + uVar3, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008c8200(uVar5);
  uVar3 = param_2 - iVar7 & 0xffffffc0;
  puVar6 = (undefined4 *)(uVar3 + iVar2);
  iStack_8 = 0;
  *puVar6 = 0;
  FUN_005880d0(param_3);
  iStack_8._0_1_ = 1;
  puVar6[8] = 0;
  FUN_005880d0(param_3 + 0x20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == param_1[1]) {
    FUN_00beae30(*param_1,param_1[1],iVar2,param_1);
  }
  else {
    FUN_00bf0230(*param_1,param_2,iVar2);
    FUN_00bf0230(param_2,param_1[1],puVar6 + 0x10);
  }
  iVar7 = *param_1;
  if (iVar7 != 0) {
    iVar8 = param_1[1];
    if (iVar7 != iVar8) {
      do {
        FUN_008c3510();
        iVar7 = iVar7 + 0x40;
      } while (iVar7 != iVar8);
      iVar7 = *param_1;
    }
    uVar4 = param_1[2] - iVar7 & 0xffffffc0;
    iVar8 = iVar7;
    if (0xfff < uVar4) {
      iVar8 = *(int *)(iVar7 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar7 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar4);
  }
  *param_1 = iVar2;
  param_1[1] = uVar1 * 0x40 + iVar2;
  param_1[2] = uVar5 * 0x40 + iVar2;
  ExceptionList = pvStack_10;
  return *param_1 + uVar3;
}



/* FUNCTION 26712 ; VA 0x00bea99d ; Catch_All@00bea99d */

void Catch_All_00bea99d(void)

{
  int unaff_EBP;
  
  FUN_00a59910(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26713 ; VA 0x00bea9d0 ; FUN_00bea9d0 */

int __thiscall FUN_00bea9d0(int *param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018027a0;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 6;
  iVar6 = param_1[1] - iVar2 >> 6;
  if (iVar6 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 6;
  uVar7 = uVar1;
  if ((uVar9 <= 0x3ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 6;
  if (uVar7 < 0x4000000) {
    if (0xfff < uVar9) goto LAB_00beaa61;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_00beaa61:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_00beac78;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  FUN_00bebe10(param_1,puVar11 + iVar5 * 0x10,param_3,param_4);
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    puVar10 = puVar11;
    while (uStack_8._0_1_ = 1, puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 != 0) {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
        }
        else {
          uVar9 = puVar12[3];
          uVar8 = puVar12[4];
          uVar4 = puVar12[5];
          puVar10[2] = puVar12[2];
          puVar10[3] = uVar9;
          puVar10[4] = uVar8;
          puVar10[5] = uVar4;
          uVar9 = puVar12[7];
          puVar10[6] = puVar12[6];
          puVar10[7] = uVar9;
        }
      }
      puVar10[8] = 0;
      uVar9 = puVar12[8];
      uStack_8._0_1_ = 2;
      if (uVar9 == 0) {
LAB_00beab8e:
        puVar10 = puVar10 + 0x10;
        puVar12 = puVar12 + 0x10;
      }
      else {
        puVar10[8] = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 10,puVar10 + 10,0);
          goto LAB_00beab8e;
        }
        uVar9 = puVar12[0xb];
        uVar8 = puVar12[0xc];
        uVar4 = puVar12[0xd];
        puVar10[10] = puVar12[10];
        puVar10[0xb] = uVar9;
        puVar10[0xc] = uVar8;
        puVar10[0xd] = uVar4;
        uVar9 = puVar12[0xf];
        puVar10[0xe] = puVar12[0xe];
        puVar10[0xf] = uVar9;
        puVar10 = puVar10 + 0x10;
        puVar12 = puVar12 + 0x10;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00bea450(puVar10,puVar10,param_1);
  }
  else {
    FUN_00bf02c0(*param_1,param_2,puVar11);
    FUN_00bf02c0(param_2,param_1[1],puVar11 + iVar5 * 0x10 + 0x10);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00bea450(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffc0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_00beac78:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 0x10);
  param_1[2] = (int)(puVar11 + uVar7 * 0x10);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x40;
}



/* FUNCTION 26714 ; VA 0x00beac4e ; Catch_All@00beac4e */

void Catch_All_00beac4e(void)

{
  int unaff_EBP;
  
  FUN_00bf0210(*(undefined4 *)(unaff_EBP + 0x10),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26715 ; VA 0x00beac80 ; FUN_00beac80 */

int __thiscall FUN_00beac80(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018027b0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xd0;
  if (iVar2 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd0;
  uVar8 = uVar1;
  if ((uVar3 <= 0x13b13b1 - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00578090(uVar8);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd0) * 0xd0;
  uVar6 = FUN_008881d0();
  puVar7 = (undefined4 *)(iVar5 + iVar4);
  *puVar7 = uVar6;
  puVar7[1] = 0;
  puVar7[2] = 0;
  puVar7[3] = 0;
  puVar7[2] = *param_3;
  puVar7[3] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  uVar6 = FUN_005ea820();
  *(undefined4 *)(iVar5 + iVar4 + 4) = uVar6;
  if (param_2 == param_1[1]) {
    FUN_0055c5a0(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar4);
    FUN_005cb700(param_2,param_1[1],iVar5 + 0xd0 + iVar4);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar4,iVar2 + 1,uVar8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 26716 ; VA 0x00beadfc ; Catch_All@00beadfc */

void Catch_All_00beadfc(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26717 ; VA 0x00beae30 ; FUN_00beae30 */

uint * FUN_00beae30(uint *param_1,uint *param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_018027d0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (param_1 != param_2) {
    puVar5 = param_1 + 2;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = 0;
      uVar2 = puVar5[-2];
      if (uVar2 != 0) {
        *param_3 = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar5,param_3 + 2,0);
        }
        else {
          uVar2 = puVar5[1];
          uVar3 = puVar5[2];
          uVar4 = puVar5[3];
          param_3[2] = *puVar5;
          param_3[3] = uVar2;
          param_3[4] = uVar3;
          param_3[5] = uVar4;
          uVar2 = puVar5[5];
          param_3[6] = puVar5[4];
          param_3[7] = uVar2;
        }
      }
      param_3[8] = 0;
      uVar2 = puVar5[6];
      iStack_8._0_1_ = 1;
      if (uVar2 != 0) {
        param_3[8] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 8,param_3 + 10,0);
        }
        else {
          uVar2 = puVar5[9];
          uVar3 = puVar5[10];
          uVar4 = puVar5[0xb];
          param_3[10] = puVar5[8];
          param_3[0xb] = uVar2;
          param_3[0xc] = uVar3;
          param_3[0xd] = uVar4;
          uVar2 = puVar5[0xd];
          param_3[0xe] = puVar5[0xc];
          param_3[0xf] = uVar2;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_3 = param_3 + 0x10;
      puVar1 = puVar5 + 0xe;
      puVar5 = puVar5 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 26718 ; VA 0x00beaf30 ; FUN_00beaf30 */

undefined FUN_00beaf30(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  int *in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined auStack_74 [8];
  uint uStack_6c;
  undefined auStack_64 [28];
  int *piStack_48;
  undefined auStack_44 [8];
  uint uStack_3c;
  undefined auStack_34 [28];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802807;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00bec830(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_44);
  if (cVar3 == '\0') {
    FUN_00bec830(auStack_44);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x30);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00bec830(auStack_74);
    }
    *in_stack_00000034 = uVar4;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (uStack_6c != 0) {
      if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      uStack_6c = 0;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_3c != 0) {
      if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      uStack_3c = 0;
    }
    uVar5 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_3c != 0) {
      if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      uStack_3c = 0;
    }
    uVar5 = 0;
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000030 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000030 + 4))();
    }
  }
  uStack_8 = 7;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 26719 ; VA 0x00beb0d0 ; FUN_00beb0d0 */

void __thiscall
FUN_00beb0d0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_c = param_6;
  uStack_10 = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_28 = param_3;
  uStack_1c = param_6;
  uStack_18 = param_7;
  uStack_2c = param_2;
  uStack_24 = param_4;
  uStack_20 = param_5;
  cVar3 = FUN_00585a40(&uStack_2c);
  if (cVar3 == '\0') {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    uStack_10 = uStack_20;
    uStack_c = uStack_1c;
    uStack_14 = uStack_18;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[2] = piStack_28[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_2c;
    param_1[3] = piStack_28;
    param_1[5] = uStack_20;
    param_1[4] = uStack_24;
    param_1[6] = uStack_1c;
    param_1[7] = uStack_18;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01960570;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 26720 ; VA 0x00beb220 ; FUN_00beb220 */

undefined FUN_00beb220(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined4 extraout_ECX;
  undefined4 extraout_ECX_00;
  undefined uVar5;
  int *in_stack_00000010;
  int *in_stack_00000018;
  int *piStack_28;
  int *piStack_20;
  undefined auStack_1c [12];
  int *piStack_10;
  int *piStack_8;
  
  FUN_00becb30(&stack0x00000004);
  cVar4 = FUN_00585a40(extraout_ECX);
  if (cVar4 == '\0') {
    FUN_00becb30(auStack_1c);
    FUN_00becb30(extraout_ECX_00);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[1] + -1;
      piStack_28[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar2 = piStack_28[2] + -1;
        piStack_28[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[1] + -1;
      piStack_10[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar2 = piStack_10[2] + -1;
        piStack_10[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[1] + -1;
      piStack_10[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        iVar2 = piStack_10[2] + -1;
        piStack_10[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000018[2] + -1;
    in_stack_00000018[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*in_stack_00000018 + 4))();
    }
  }
  piVar3 = in_stack_00000010;
  if (in_stack_00000010 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000010[1] + -1;
    in_stack_00000010[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000010)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 26721 ; VA 0x00beb370 ; FUN_00beb370 */

undefined FUN_00beb370(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined uVar5;
  uint in_stack_0000002c;
  int *in_stack_0000004c;
  undefined auStack_9c [32];
  uint uStack_7c;
  undefined auStack_74 [24];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [32];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180284a;
  pvStack_10 = ExceptionList;
  uStack_5c = param_1;
  uStack_58 = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00becef0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(&uStack_5c);
  uVar2 = uStack_58;
  uVar1 = uStack_5c;
  if (cVar3 == '\0') {
    FUN_00becef0(auStack_54);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x48);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      FUN_00becef0(auStack_9c);
    }
    *in_stack_0000004c = (int)puVar4;
    uStack_8._0_1_ = 4;
    if (uStack_7c != 0) {
      if (((uStack_7c & 1) == 0) && (*(code **)(uStack_7c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_7c & 0xfffffffe))(auStack_74,auStack_74,2);
      }
      uStack_7c = 0;
    }
    FUN_00612320();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00612320();
    uVar5 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00612320();
    uVar5 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
    }
    in_stack_0000002c = 0;
  }
  FUN_00612320();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 26722 ; VA 0x00beb520 ; FUN_00beb520 */

undefined FUN_00beb520(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  uint in_stack_0000001c;
  undefined4 *in_stack_0000003c;
  undefined auStack_84 [24];
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined auStack_4c [24];
  uint uStack_34;
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802887;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00becc80(&stack0x00000004);
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(auStack_4c);
  if (cVar1 == '\0') {
    FUN_00becc80(auStack_4c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x38);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_00becc80(auStack_84);
    }
    *in_stack_0000003c = uVar2;
    uStack_8._0_1_ = 4;
    if (uStack_6c != 0) {
      if (((uStack_6c & 1) == 0) && (*(code **)(uStack_6c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_6c & 0xfffffffe))(auStack_64,auStack_64,2);
      }
      uStack_6c = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    uVar3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
     (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 26723 ; VA 0x00beb670 ; FUN_00beb670 */

undefined4 *
FUN_00beb670(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018028c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_13 != 0) {
    uStack_84 = param_13;
    if ((param_13 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_15;
      uStack_94 = 0xbeb6d7;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_15;
      uStack_78 = param_16;
      uStack_74 = param_17;
      puStack_70 = (undefined4 *)param_18;
      uStack_6c = param_19;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_9c,0);
    }
    else {
      uStack_9c = param_8;
      uStack_98 = param_9;
      uStack_94 = param_10;
      puStack_90 = param_11;
      uStack_8c = param_12;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00becdc0(param_4,param_5);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_6c = CONCAT44(uVar1,0xbeb754);
  FUN_00beccf0();
  uStack_6c = CONCAT44(0xbeb75c,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_8;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xbeb77d;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_15;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xbeb7ab;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26724 ; VA 0x00beb7c0 ; FUN_00beb7c0 */

undefined4 *
FUN_00beb7c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  uint in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined8 in_stack_00000048;
  uint in_stack_00000050;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined8 in_stack_00000068;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802900;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000050 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000050 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000050 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  if ((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0(&stack0x00000018);
  uStack_8._0_1_ = 2;
  FUN_00bed200(param_4,param_5);
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00bed110();
  FUN_00bee360();
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000030 != 0) {
    if (((in_stack_00000030 & 1) == 0) &&
       (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000030 & 0xfffffffe))();
    }
    in_stack_00000030 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000050 != 0) && ((in_stack_00000050 & 1) == 0)) &&
     (*(code **)(in_stack_00000050 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000050 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26725 ; VA 0x00beb930 ; FUN_00beb930 */

undefined4 *
FUN_00beb930(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uint *puVar1;
  undefined4 uVar2;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined *in_stack_00000044;
  undefined8 in_stack_00000048;
  undefined auStack_98 [12];
  undefined4 uStack_8c;
  undefined4 *puStack_88;
  undefined4 *puStack_84;
  undefined4 uStack_80;
  uint auStack_7c [2];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  undefined8 uStack_64;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802930;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_7c;
  puStack_18 = (undefined *)auStack_7c;
  uStack_8 = 1;
  auStack_7c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar1 = auStack_7c;
  if (in_stack_00000030 != 0) {
    auStack_7c[0] = in_stack_00000030;
    if ((in_stack_00000030 & 1) == 0) {
      puStack_84 = &uStack_74;
      uStack_80 = 0;
      puStack_88 = &stack0x00000038;
      uStack_8c = 0xbeb997;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000030 & 0xfffffffe))();
      puVar1 = (uint *)puStack_14;
    }
    else {
      uStack_74 = in_stack_00000038;
      uStack_70 = in_stack_0000003c;
      uStack_6c = in_stack_00000040;
      puStack_68 = (undefined4 *)in_stack_00000044;
      uStack_64 = in_stack_00000048;
      ExceptionList = &pvStack_10;
      puVar1 = auStack_7c;
    }
  }
  puStack_14 = (undefined *)puVar1;
  uStack_80 = in_stack_0000002c;
  uStack_8._0_1_ = 2;
  puStack_18 = auStack_98;
  FUN_00bedad0(&stack0x00000014);
  uStack_8._0_1_ = 1;
  uVar2 = FUN_00becf90(param_4);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_64 = CONCAT44(uVar2,0xbeb9e1);
  FUN_00becef0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = (undefined4 *)auStack_30;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0xbeba02;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_64 = CONCAT44(0xbeba14,(undefined4)uStack_64);
  FUN_00612320();
  uStack_64 = CONCAT44(0xbeba1c,(undefined4)uStack_64);
  FUN_00612320();
  uStack_8 = 5;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = &stack0x00000038;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0xbeba40;
    (**(code **)(in_stack_00000030 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26726 ; VA 0x00beba60 ; FUN_00beba60 */

undefined4 *
FUN_00beba60(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,uint param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined8 param_14)

{
  undefined4 uStack_80;
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802960;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    uStack_34 = param_8;
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_2c,0);
    }
    else {
      uStack_2c = param_10;
      uStack_28 = param_11;
      uStack_24 = param_12;
      uStack_20 = param_13;
      uStack_1c = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  uStack_74 = 0;
  if (uStack_54 != 0) {
    uStack_74 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_4c;
      uStack_68 = uStack_48;
      uStack_64 = uStack_44;
      uStack_60 = uStack_40;
      uStack_5c = uStack_3c;
    }
  }
  uStack_8._0_1_ = 3;
  if (uStack_54 != 0) {
    if (((uStack_54 & 1) == 0) && (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_54 = 0;
  }
  uStack_8._0_1_ = 4;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = uStack_80;
  param_1[4] = param_5;
  param_1[5] = param_6;
  param_1[6] = 0;
  if (uStack_74 != 0) {
    param_1[6] = uStack_74;
    if ((uStack_74 & 1) == 0) {
      (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,param_1 + 8,0);
    }
    else {
      param_1[8] = uStack_6c;
      param_1[9] = uStack_68;
      param_1[10] = uStack_64;
      param_1[0xb] = uStack_60;
      *(undefined8 *)(param_1 + 0xc) = uStack_5c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((uStack_74 != 0) && ((uStack_74 & 1) == 0)) &&
     (*(code **)(uStack_74 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_6c,2);
  }
  uStack_8 = 7;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_8 & 0xfffffffe))(&param_10,&param_10,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26727 ; VA 0x00bebc90 ; FUN_00bebc90 */

undefined4 *
FUN_00bebc90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uint in_stack_00000034;
  uint in_stack_00000054;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018029a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000054 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000054 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  if ((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  FUN_00bedad0();
  uStack_8._0_1_ = 2;
  FUN_00bed440(param_4);
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00bed350();
  FUN_00bee3f0();
  FUN_00612320();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26728 ; VA 0x00bebe10 ; FUN_00bebe10 */

void FUN_00bebe10(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  
  piVar3 = (int *)param_3[1];
  uVar4 = *param_3;
  *param_3 = 0;
  param_3[1] = 0;
  uVar5 = param_3[3];
  piVar1 = piVar3 + 2;
  uVar6 = param_3[2];
  uVar7 = param_3[4];
  uVar8 = param_3[5];
  if (piVar3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_3 = (undefined4 *)uVar5;
  FUN_00beb0d0(uVar4,piVar3,uVar6,uVar5,uVar7,uVar8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar3 + 4))();
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  param_3 = (undefined4 *)CONCAT31(param_3._1_3_,*param_4);
  cVar9 = FUN_00585a40(&param_3);
  if (cVar9 == '\0') {
    param_2[8] = &DAT_01960579;
    return;
  }
  param_2[8] = 0;
  return;
}



/* FUNCTION 26729 ; VA 0x00bebf00 ; FUN_00bebf00 */

void FUN_00bebf00(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_008881d0();
  *param_2 = uVar3;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[2] = *param_3;
  iVar2 = _tls_index;
  param_2[3] = param_3[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  param_2[1] = &DAT_01ea8a90;
  return;
}



/* FUNCTION 26730 ; VA 0x00bebfb0 ; FUN_00bebfb0 */

void FUN_00bebfb0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = FUN_008881d0();
  *param_2 = uVar1;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[2] = *param_3;
  param_2[3] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  uVar1 = FUN_005ea820();
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 26731 ; VA 0x00bec000 ; FUN_00bec000 */

void __thiscall FUN_00bec000(int param_1,int param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018029b8;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    ExceptionList = &pvStack_10;
    *puVar1 = 0;
    FUN_005880d0(param_2);
    uStack_8 = 0;
    puVar1[8] = 0;
    FUN_005880d0(param_2 + 0x20);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x40;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00bea820(puVar1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26732 ; VA 0x00bec090 ; FUN_00bec090 */

undefined4 * __thiscall
FUN_00bec090(byte *param_1,undefined4 *param_2,uint *param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018029d8;
  pvStack_10 = ExceptionList;
  uVar3 = param_3[1];
  uVar1 = *param_3;
  puStack_18 = (undefined4 *)uVar1;
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar3 = ~uVar3;
    puStack_18 = (undefined4 *)~uVar1;
  }
  uVar3 = (uVar3 >> 2) + uVar3 * 0x40 + uVar1 ^ uVar3;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_3,uVar3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  puStack_18 = (undefined4 *)0x0;
  uStack_1c = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  uStack_8 = 0;
  uStack_14 = 0;
  puStack_18 = (undefined4 *)FUN_01674e20(0x10);
  uStack_14 = 0x101;
  *puStack_18 = 0;
  puStack_18[1] = 0;
  *(undefined8 *)(puStack_18 + 2) = 0;
  puStack_18[2] = *param_4;
  puStack_18[3] = param_4[1];
  FUN_0062b610(*(int *)(param_1 + 8) + 1);
  puVar2 = (undefined4 *)FUN_005c5550(&param_3,&uStack_1c,uVar3);
  *param_2 = *puVar2;
  *(undefined *)(param_2 + 1) = 1;
  if (puStack_18 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_18,0x10);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 26733 ; VA 0x00bec1d0 ; FUN_00bec1d0 */

void __thiscall FUN_00bec1d0(int param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018029f8;
  pvStack_10 = ExceptionList;
  uVar8 = param_3[1];
  uVar11 = uVar8;
  if (((int)uVar8 < 1) && ((int)uVar8 < 0)) {
    uVar11 = ~uVar8;
  }
  puVar1 = (uint *)(param_1 + 4);
  uVar11 = (uVar11 >> 2) + uVar11 * 0x40 + *param_3 ^ uVar11;
  uVar12 = uVar11 % *puVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar9 = (int *)0x0;
  }
  else {
    puVar13 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar12 * 4);
    if (puVar13 == (undefined4 *)0x0) {
      piVar9 = (int *)0x0;
    }
    else {
      piVar9 = (int *)*puVar13;
    }
    if (piVar9 == (int *)0x0) goto LAB_00bec2a8;
    do {
      if (uVar11 == piVar9[1]) {
        if ((*param_3 == piVar9[2]) && (uVar8 == piVar9[3])) break;
      }
      else if ((uint)piVar9[1] % *puVar1 != uVar12) goto LAB_00bec2a8;
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
  }
  if (piVar9 != (int *)0x0) {
    *param_2 = piVar9;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_00bec2a8:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar9 = (int *)FUN_01674e20(0x18);
  *piVar9 = 0;
  piVar9[1] = 0;
  piVar9[2] = 0;
  piVar9[3] = 0;
  piVar9[4] = 0;
  piVar9[5] = 0;
  iVar5 = param_4[1];
  iVar6 = param_4[2];
  iVar7 = param_4[3];
  piVar9[2] = *param_4;
  piVar9[3] = iVar5;
  piVar9[4] = iVar6;
  piVar9[5] = iVar7;
  uVar12 = *(uint *)(param_1 + 8);
  uVar8 = uVar12 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *puVar1) {
      uVar8 = *puVar1;
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar10 = uVar12 >> 1;
    if (uVar12 + (uVar12 >> 1) <= uVar8) {
      uVar10 = 1;
    }
    uVar8 = FUN_005d6bb0(uVar10 + *(int *)(param_1 + 8));
    if (uVar8 != *puVar1) {
      FUN_005d2b00(uVar8);
      puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
      puVar4 = (undefined4 *)*puVar13;
      while (puVar4 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *puVar1) * 4) == 0) {
          *piVar2 = (int)puVar13;
          puVar13 = puVar4;
        }
        else {
          *puVar13 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar13;
      }
    }
  }
  piVar9[1] = uVar11;
  uVar8 = *puVar1;
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar11 % uVar8) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (*piVar3 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar8) * 4) = piVar9;
    }
    *piVar2 = (int)piVar3;
    *piVar9 = *piVar3;
    *piVar3 = (int)piVar9;
  }
  else {
    *piVar9 = *(int *)*piVar2;
    *(int **)*piVar2 = piVar9;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar9;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 26734 ; VA 0x00bec420 ; thunk_FUN_00bfa7a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00bfa7a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804046;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef78cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef78cc);
    if (DAT_01ef78cc == -1) {
      uStack_8 = 0;
      FUN_009ca470("FriendRequestEvent");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef7868 = RBX::Reflection::EnumDesc<enum_RBX::FriendService_FriendEventType>::vftable;
      FUN_009caf20(&DAT_01d6808c,4);
      FUN_016f3654(&LAB_01892a40);
      FUN_016f37bf(&DAT_01ef78cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef7868;
}



/* FUNCTION 26735 ; VA 0x00bec430 ; thunk_FUN_00935e70 */

undefined * thunk_FUN_00935e70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee225c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee225c);
    if (DAT_01ee225c == -1) {
      uStack_8 = 0;
      FUN_00becc20();
      FUN_016f3654(&LAB_01884a60);
      FUN_016f37bf(&DAT_01ee225c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee21f8;
}



/* FUNCTION 26736 ; VA 0x00bec440 ; FUN_00bec440 */

undefined4 * FUN_00bec440(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802a4c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = GetProcessHeap(0,0x44);
  puVar2 = (undefined4 *)HeapAlloc(uVar1);
  if (puVar2 == (undefined4 *)0x0) {
    uVar1 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar1);
  }
  else {
    *puVar2 = boost::detail::thread_data_base::vftable;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    uVar1 = FUN_00575ab0();
    puVar2[4] = uVar1;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[0xb] = 0;
    puVar2[0xc] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar3 = CreateEventA(0,1,0,0);
    if (iVar3 != 0) {
      puVar2[0xd] = iVar3;
      *(undefined *)(puVar2 + 0xe) = 1;
      *puVar2 = boost::detail::thread_data<class_<lambda_d5f63754a90d675107e7d16ac6c82d45>_>::
                vftable;
      puVar2[0xf] = *param_1;
      puVar2[0x10] = param_1[1];
      ExceptionList = pvStack_10;
      return puVar2;
    }
  }
  uVar1 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar1);
}



/* FUNCTION 26737 ; VA 0x00bec539 ; Catch_All@00bec539 */

void Catch_All_00bec539(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 26738 ; VA 0x00bec580 ; FUN_00bec580 */

uint * FUN_00bec580(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802a68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar1 = *param_2;
  if (uVar1 != 0) {
    *param_1 = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar1 = param_2[3];
      uVar2 = param_2[4];
      uVar3 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar1;
      param_1[4] = uVar2;
      param_1[5] = uVar3;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  uStack_8 = 0;
  uVar1 = *param_3;
  if (uVar1 != 0) {
    param_1[8] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar1 = param_3[3];
      uVar2 = param_3[4];
      uVar3 = param_3[5];
      param_1[10] = param_3[2];
      param_1[0xb] = uVar1;
      param_1[0xc] = uVar2;
      param_1[0xd] = uVar3;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_3 + 6);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_3 + 2,param_1 + 10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26739 ; VA 0x00bec650 ; FUN_00bec650 */

void FUN_00bec650(int *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<__int64,enum_RBX::FriendService_FriendStatus,struct_boost::hash<__int64>,struct_std::equal_to<__int64>,class_std::allocator<struct_std::pair<__int64_const_,enum_RBX::FriendService_FriendStatus>_>_>_>
              ::vftable;
    *(undefined *)(puVar1 + 3) = 0;
    uVar2 = FUN_00588320(0xb);
    puVar1[4] = uVar2;
    puVar1[5] = 0;
    puVar1[6] = 0x3f800000;
    puVar1[7] = 0;
    puVar1[8] = 0;
    param_1[1] = (int)puVar1;
    *param_1 = (int)(puVar1 + 3);
    return;
  }
  param_1[1] = 0;
  *param_1 = 0xc;
  return;
}



/* FUNCTION 26740 ; VA 0x00bec6d0 ; FUN_00bec6d0 */

code * FUN_00bec6d0(code *param_1)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined uVar5;
  undefined4 uVar6;
  int *in_stack_00000028;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined auStack_f0 [4];
  undefined4 *puStack_ec;
  undefined auStack_e8 [216];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01802aae;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_005c1420(&stack0x00000024);
  uStack_8._0_1_ = 2;
  puStack_ec = (undefined4 *)0x0;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)*puStack_1bc)(auStack_1b8,auStack_e8);
  }
  puStack_ec = puStack_1bc;
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (param_1 == (code *)0x0) {
    uStack_8._0_1_ = uVar5;
    uVar6 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  pcVar3 = *(code **)(((uint)param_1 & 0xfffffffe) + 4);
  FUN_005caf00(auStack_f0);
  (*pcVar3)(&stack0x0000000c);
  uStack_8._0_1_ = 5;
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8._0_1_ = 6;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)puStack_1bc[2])(auStack_1b8);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    param_1 = (code *)(*param_1)(&stack0x0000000c,&stack0x0000000c,2);
  }
  piVar4 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (code *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26741 ; VA 0x00bec830 ; FUN_00bec830 */

undefined4 * __thiscall FUN_00bec830(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  return param_1;
}



/* FUNCTION 26742 ; VA 0x00bec8c0 ; FUN_00bec8c0 */

int __thiscall FUN_00bec8c0(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  uVar1 = *(uint *)(param_2 + 0x18);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x18) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x24);
      uVar3 = *(undefined4 *)(param_2 + 0x28);
      uVar4 = *(undefined4 *)(param_2 + 0x2c);
      *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
      *(undefined4 *)(param_1 + 0x24) = uVar2;
      *(undefined4 *)(param_1 + 0x28) = uVar3;
      *(undefined4 *)(param_1 + 0x2c) = uVar4;
      *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_2 + 0x30);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x20,param_1 + 0x20,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26743 ; VA 0x00bec960 ; FUN_00bec960 */

int __thiscall FUN_00bec960(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802ad3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  uVar1 = *(uint *)(param_2 + 0x18);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x18) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x20,param_1 + 0x20,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0x24);
      uVar3 = *(undefined4 *)(param_2 + 0x28);
      uVar4 = *(undefined4 *)(param_2 + 0x2c);
      *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
      *(undefined4 *)(param_1 + 0x24) = uVar2;
      *(undefined4 *)(param_1 + 0x28) = uVar3;
      *(undefined4 *)(param_1 + 0x2c) = uVar4;
      *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_2 + 0x30);
    }
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  uVar1 = *(uint *)(param_2 + 0x38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x38) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x44);
      uVar3 = *(undefined4 *)(param_2 + 0x48);
      uVar4 = *(undefined4 *)(param_2 + 0x4c);
      *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_2 + 0x40);
      *(undefined4 *)(param_1 + 0x44) = uVar2;
      *(undefined4 *)(param_1 + 0x48) = uVar3;
      *(undefined4 *)(param_1 + 0x4c) = uVar4;
      *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(param_2 + 0x50);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x40,param_1 + 0x40,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26744 ; VA 0x00beca40 ; FUN_00beca40 */

undefined4 * __thiscall FUN_00beca40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802aeb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[4] = 0;
  uVar2 = param_2[4];
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
    }
    else {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
    }
  }
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  if (param_2[0x15] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x15] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x14] = param_2[0x14];
  param_1[0x15] = param_2[0x15];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26745 ; VA 0x00becb30 ; FUN_00becb30 */

undefined4 * __thiscall FUN_00becb30(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 26746 ; VA 0x00becb90 ; FUN_00becb90 */

undefined4 * __thiscall FUN_00becb90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802b16;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  FUN_00bedad0(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  uStack_8 = 1;
  FUN_0054ef60(param_2 + 10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26747 ; VA 0x00becc20 ; FUN_00becc20 */

undefined4 * __fastcall FUN_00becc20(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("FriendStatus");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::FriendService_FriendStatus>::vftable;
  FUN_009caf20(&DAT_01d68064,5);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 26748 ; VA 0x00becc80 ; FUN_00becc80 */

undefined4 * __thiscall FUN_00becc80(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uVar2 = param_2[3];
  uVar3 = param_2[4];
  uVar4 = param_2[5];
  param_1[2] = param_2[2];
  param_1[3] = uVar2;
  param_1[4] = uVar3;
  param_1[5] = uVar4;
  param_1[6] = 0;
  uVar1 = param_2[6];
  if (uVar1 != 0) {
    param_1[6] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[9];
      uVar3 = param_2[10];
      uVar4 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar2;
      param_1[10] = uVar3;
      param_1[0xb] = uVar4;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
  }
  return param_1;
}



/* FUNCTION 26749 ; VA 0x00beccf0 ; FUN_00beccf0 */

undefined4 * __thiscall FUN_00beccf0(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01802b28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}


