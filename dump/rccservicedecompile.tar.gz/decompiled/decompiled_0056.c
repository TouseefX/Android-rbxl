/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 14000 ; VA 0x008933a0 ; FUN_008933a0 */

void __thiscall FUN_008933a0(undefined4 *param_1,int *param_2)

{
  void **ppvVar1;
  char cVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined auStack_34 [4];
  undefined auStack_30 [4];
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bacf8;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined4 *)*param_2;
  puStack_2c = (undefined4 *)param_2[1];
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  puStack_28 = param_1;
  if (puStack_20 != puStack_2c) {
    do {
      puVar6 = (undefined4 *)*puStack_20;
      piVar3 = (int *)param_1[1];
      piStack_1c = (int *)*param_1;
      iVar7 = (int)piVar3 - (int)piStack_1c >> 2;
      puStack_18 = (undefined4 *)0x0;
      puStack_14 = puVar6;
      if (0 < iVar7) {
        do {
          iVar8 = iVar7 >> 1;
          piStack_24 = piStack_1c + iVar8;
          cVar2 = FUN_00892930(*piStack_24,puVar6);
          if (cVar2 != '\0') {
            piStack_1c = piStack_24 + 1;
            iVar8 = iVar7 + (-1 - iVar8);
          }
          iVar7 = iVar8;
        } while (0 < iVar8);
        piVar3 = (int *)puStack_28[1];
        param_1 = puStack_28;
      }
      if (piStack_1c == piVar3) {
        FUN_00892fc0(auStack_30,piStack_1c,&puStack_14);
        puVar6 = puStack_14;
        piStack_24 = (int *)puStack_14[1];
        if (0xf < (uint)piStack_24[5]) {
          piStack_24 = (int *)*piStack_24;
        }
        if ((uint)(((int)(param_1[4] - param_1[3]) >> 3) * 3) >> 2 <= (uint)param_1[6]) {
          FUN_00893680();
        }
        iVar7 = FUN_00893040(&piStack_24);
        *(undefined4 **)(iVar7 + 4) = puVar6;
        if (param_1[0xe] == 0) {
          uVar5 = FUN_0054fda0();
          uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar5);
        }
        pcVar4 = *(code **)((param_1[0xe] & 0xfffffffe) + 4);
        puVar9 = param_1 + 0x10;
        puVar10 = puVar6;
        goto LAB_0089357d;
      }
      puVar9 = (undefined4 *)*piStack_1c;
      if (puVar9 != puVar6) {
        if (puVar9[1] == puVar6[1]) {
          *piStack_1c = (int)puVar6;
          piStack_24 = (int *)puVar6[1];
          if (0xf < (uint)piStack_24[5]) {
            piStack_24 = (int *)*piStack_24;
          }
          puStack_18 = puVar9;
          if ((uint)(((int)(param_1[4] - param_1[3]) >> 3) * 3) >> 2 <= (uint)param_1[6]) {
            FUN_00893680();
          }
          iVar7 = FUN_00893040(&piStack_24);
          *(undefined4 **)(iVar7 + 4) = puVar6;
          if (param_1[0xe] == 0) {
            uVar5 = FUN_0054fda0();
            uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
            FUN_0054e5e0(uVar5);
          }
          (**(code **)((param_1[0xe] & 0xfffffffe) + 4))(param_1 + 0x10,puVar6);
          pcVar4 = DAT_01eded9c;
          puVar9 = puVar6;
          puVar10 = puStack_18;
          if (DAT_01eded9c != (code *)0x0) goto LAB_0089357d;
        }
        else {
          FUN_00892fc0(auStack_34,piStack_1c,&puStack_14);
          puVar6 = puStack_14;
          piStack_24 = (int *)puStack_14[1];
          if (0xf < (uint)piStack_24[5]) {
            piStack_24 = (int *)*piStack_24;
          }
          if ((uint)(((int)(param_1[4] - param_1[3]) >> 3) * 3) >> 2 <= (uint)param_1[6]) {
            FUN_00893680();
          }
          iVar7 = FUN_00893040(&piStack_24);
          *(undefined4 **)(iVar7 + 4) = puVar6;
          if (param_1[0xe] == 0) {
            uVar5 = FUN_0054fda0();
            uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
            FUN_0054e5e0(uVar5);
          }
          pcVar4 = *(code **)((param_1[0xe] & 0xfffffffe) + 4);
          puVar9 = param_1 + 0x10;
          puVar10 = puVar6;
LAB_0089357d:
          (*pcVar4)(puVar9,puVar10);
        }
        iVar7 = param_1[9];
        if (iVar7 != param_1[10]) {
          do {
            FUN_00892b40(puVar6,puStack_18);
            iVar7 = iVar7 + 4;
          } while (iVar7 != param_1[10]);
        }
      }
      puStack_20 = puStack_20 + 1;
      ppvVar1 = (void **)ExceptionList;
    } while (puStack_20 != puStack_2c);
  }
  ExceptionList = ppvVar1;
  if (param_2[0xc] != 0) {
    FUN_008933a0(param_2[0xc]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14001 ; VA 0x00893620 ; FUN_00893620 */

void __thiscall FUN_00893620(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_2;
  param_2 = *(undefined4 *)(param_2 + 4);
  if ((uint)(((*(int *)(param_1 + 500) - *(int *)(param_1 + 0x1f0)) / 0xc) * 3) >> 2 <=
      *(uint *)(param_1 + 0x1fc)) {
    FUN_00893880();
  }
  iVar2 = FUN_00731e30(&param_2);
  *(int *)(iVar2 + 4) = iVar1;
  *(undefined4 *)(iVar2 + 8) = param_3;
  return;
}



/* FUNCTION 14002 ; VA 0x00893680 ; FUN_00893680 */

void __fastcall FUN_00893680(int *param_1)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  byte *pbVar11;
  bool bVar12;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  byte *pbStack_34;
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bad18;
  pvStack_10 = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar9 = 0x10;
  }
  else {
    iVar9 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_28 = param_1[4];
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  FUN_0060e8c0(iVar9,&iStack_28,&uStack_11);
  pbStack_34 = (byte *)param_1[4];
  iStack_38 = 0;
  iVar9 = *param_1;
  uStack_8 = 0;
  uStack_20 = 0;
  if (param_1[1] - iVar9 >> 3 != 0) {
    do {
      pbVar11 = *(byte **)(iVar9 + uStack_20 * 8);
      puStack_18 = (undefined4 *)(iVar9 + uStack_20 * 8);
      pbVar7 = (byte *)param_1[4];
      pbVar4 = pbVar11;
      do {
        bVar1 = *pbVar4;
        bVar12 = bVar1 < *pbVar7;
        if (bVar1 != *pbVar7) {
LAB_00893732:
          uVar5 = -(uint)bVar12 | 1;
          goto LAB_00893737;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar12 = bVar1 < pbVar7[1];
        if (bVar1 != pbVar7[1]) goto LAB_00893732;
        pbVar4 = pbVar4 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_00893737:
      if (uVar5 != 0) {
        uVar10 = (iStack_40 - iStack_44 >> 3) - 1;
        uStack_24 = uVar10;
        uVar5 = FUN_00888920(pbVar11);
        uVar5 = uVar5 & uVar10;
        uVar10 = 0;
        do {
          pbVar11 = *(byte **)(iStack_44 + uVar5 * 8);
          puStack_1c = (undefined4 *)(iStack_44 + uVar5 * 8);
          pbVar7 = pbVar11;
          pbVar4 = pbStack_34;
          do {
            bVar1 = *pbVar7;
            bVar12 = bVar1 < *pbVar4;
            if (bVar1 != *pbVar4) {
LAB_00893791:
              uVar6 = -(uint)bVar12 | 1;
              goto LAB_00893796;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar7[1];
            bVar12 = bVar1 < pbVar4[1];
            if (bVar1 != pbVar4[1]) goto LAB_00893791;
            pbVar7 = pbVar7 + 2;
            pbVar4 = pbVar4 + 2;
          } while (bVar1 != 0);
          uVar6 = 0;
LAB_00893796:
          pbVar7 = (byte *)*puStack_18;
          puVar8 = puStack_1c;
          if (uVar6 == 0) {
            *puStack_1c = pbVar7;
            iStack_38 = iStack_38 + 1;
            goto LAB_008937e6;
          }
          do {
            bVar1 = *pbVar11;
            bVar12 = bVar1 < *pbVar7;
            if (bVar1 != *pbVar7) {
LAB_008937c0:
              uVar6 = -(uint)bVar12 | 1;
              goto LAB_008937c5;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar11[1];
            bVar12 = bVar1 < pbVar7[1];
            if (bVar1 != pbVar7[1]) goto LAB_008937c0;
            pbVar11 = pbVar11 + 2;
            pbVar7 = pbVar7 + 2;
          } while (bVar1 != 0);
          uVar6 = 0;
LAB_008937c5:
          if (uVar6 == 0) goto LAB_008937e6;
          uVar5 = uVar5 + 1 + uVar10;
          uVar10 = uVar10 + 1;
          uVar5 = uVar5 & uStack_24;
        } while (uVar10 <= uStack_24);
        puVar8 = (undefined4 *)0x0;
LAB_008937e6:
        *puVar8 = *puStack_18;
        puVar8[1] = puStack_18[1];
        iVar9 = *piStack_2c;
        param_1 = piStack_2c;
      }
      uStack_20 = uStack_20 + 1;
    } while (uStack_20 < (uint)(param_1[1] - iVar9 >> 3));
  }
  if (param_1 != &iStack_44) {
    *param_1 = iStack_44;
    iVar2 = param_1[1];
    param_1[1] = iStack_40;
    iVar3 = param_1[2];
    param_1[2] = iStack_3c;
    iStack_44 = iVar9;
    iStack_40 = iVar2;
    iStack_3c = iVar3;
  }
  if (iStack_44 != 0) {
    uVar5 = iStack_3c - iStack_44 & 0xfffffff8;
    iVar9 = iStack_44;
    if (0xfff < uVar5) {
      iVar9 = *(int *)(iStack_44 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iStack_44 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14003 ; VA 0x00893880 ; FUN_00893880 */

void __fastcall FUN_00893880(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  uint uStack_34;
  int aiStack_2c [2];
  int *piStack_24;
  int *piStack_1c;
  uint uStack_18;
  uint uStack_14;
  int iStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar4 = 0x10;
  }
  else {
    iVar4 = ((param_1[1] - *param_1) / 0xc) * 2;
  }
  aiStack_2c[0] = param_1[4];
  aiStack_2c[1] = 0;
  piStack_24 = param_1;
  piStack_1c = param_1;
  FUN_00806e90(iVar4,aiStack_2c,&uStack_5);
  uStack_34 = param_1[4];
  iVar4 = *param_1;
  iStack_38 = 0;
  iVar1 = param_1[1] - iVar4 >> 0x1f;
  uStack_14 = 0;
  if ((param_1[1] - iVar4) / 0xc + iVar1 != iVar1) {
    iStack_10 = 0;
    do {
      uVar8 = *(uint *)(iStack_10 + iVar4);
      puStack_c = (uint *)(iStack_10 + iVar4);
      if (uVar8 != param_1[4]) {
        uVar6 = (iStack_40 - iStack_44) / 0xc - 1;
        uVar3 = (uVar8 >> 3) + uVar8;
        uVar7 = 0;
        do {
          uVar3 = uVar3 & uVar6;
          puVar5 = (uint *)(iStack_44 + uVar3 * 0xc);
          if (*puVar5 == uStack_34) {
            iStack_38 = iStack_38 + 1;
            *puVar5 = uVar8;
            uVar8 = *puStack_c;
            goto LAB_00893971;
          }
          if (*puVar5 == uVar8) goto LAB_00893971;
          uVar3 = uVar3 + 1 + uVar7;
          uVar7 = uVar7 + 1;
        } while (uVar7 <= uVar6);
        puVar5 = (uint *)0x0;
LAB_00893971:
        *puVar5 = uVar8;
        puVar5[1] = puStack_c[1];
        puVar5[2] = puStack_c[2];
        iVar4 = *piStack_1c;
        param_1 = piStack_1c;
      }
      iStack_10 = iStack_10 + 0xc;
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < (uint)((param_1[1] - iVar4) / 0xc));
  }
  if (param_1 != &iStack_44) {
    *param_1 = iStack_44;
    iVar1 = param_1[1];
    param_1[1] = iStack_40;
    iVar2 = param_1[2];
    param_1[2] = iStack_3c;
    iStack_44 = iVar4;
    iStack_40 = iVar1;
    iStack_3c = iVar2;
  }
  uStack_18 = uStack_34;
  FUN_00617ad0();
  return;
}



/* FUNCTION 14004 ; VA 0x008939f0 ; FUN_008939f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008939f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bad8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edefb0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edefb0);
    if (DAT_01edefb0 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_20 = uStack_20 & 0xffffff00;
      FUN_00888700("<<<ROOT>>>",uStack_20,0,uVar1);
      uStack_8._0_1_ = 1;
      _DAT_01ededa8 = RBX::Reflection::ClassDescriptor::vftable;
      FUN_00892390(0);
      uStack_8._0_1_ = 2;
      FUN_00892390(0);
      uStack_8._0_1_ = 3;
      FUN_00892390(0);
      uStack_8._0_1_ = 4;
      FUN_00892390(0);
      uStack_8._0_1_ = 5;
      FUN_00892390(0);
      _DAT_01edef78 = 0;
      DAT_01edef7c = DAT_01edef7c & 0xffffffed | 0xd;
      _DAT_01edef80 = 0;
      _DAT_01edef84 = 0;
      uRam01edef88 = 0;
      _DAT_01edef8c = 0;
      uRam01edef90 = 0;
      _DAT_01edef94 = 0;
      uStack_8._0_1_ = 7;
      FUN_00806e90();
      _DAT_01edefa4 = 0;
      _DAT_01edefa8 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00893cc0(&DAT_01ededc0,0);
      FUN_00893cc0(&DAT_01edee18,1);
      FUN_00893cc0(&DAT_01edee70,2);
      FUN_00893cc0(&DAT_01edeec8,3);
      FUN_00893cc0(&DAT_01edef20,4);
      FUN_016f3654(&LAB_01880b80);
      FUN_016f37bf(&DAT_01edefb0);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ededa8;
}



/* FUNCTION 14005 ; VA 0x00893bd0 ; FUN_00893bd0 */

void FUN_00893bd0(int param_1,uint param_2)

{
  uint *puVar1;
  int *piVar2;
  uint *puVar3;
  uint *puVar4;
  int iVar5;
  uint *puVar6;
  uint *puStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  piVar2 = (int *)FUN_00892e90();
  if (piVar2 == (int *)0x0) {
    return;
  }
  puVar1 = (uint *)*piVar2;
  uStack_c = *(uint *)(param_1 + 4);
  puVar3 = (uint *)puVar1[1];
  puVar6 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      if (puVar3[4] < uStack_c) {
        puVar4 = (uint *)puVar3[2];
      }
      else {
        puVar4 = (uint *)*puVar3;
        puVar6 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if ((puVar6 != puVar1) && (puStack_10 = puVar6, puVar6[4] <= uStack_c)) goto LAB_00893c4b;
  }
  puStack_10 = &uStack_c;
  iVar5 = FUN_005f81a0(&DAT_018bdeda,&puStack_10,&uStack_5);
  FUN_00687600(&puStack_10,puVar6,iVar5 + 0x10,iVar5);
LAB_00893c4b:
  puStack_10[5] = param_2;
  return;
}



/* FUNCTION 14006 ; VA 0x00893c60 ; FUN_00893c60 */

undefined4 * FUN_00893c60(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edefc0) {
    FUN_016f3809(&DAT_01edefc0);
    if (DAT_01edefc0 == -1) {
      FUN_016f3654(&LAB_01880b20);
      FUN_016f37bf(&DAT_01edefc0);
    }
  }
  return &DAT_01edefb4;
}



/* FUNCTION 14007 ; VA 0x00893cc0 ; FUN_00893cc0 */

void __thiscall FUN_00893cc0(uint param_1,int param_2,undefined4 *param_3)

{
  byte bVar1;
  undefined4 *puVar2;
  char cVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  byte *pbVar7;
  uint uVar8;
  bool bVar9;
  uint auStack_70 [2];
  undefined auStack_68 [24];
  uint auStack_50 [2];
  code *pcStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 *puStack_3c;
  code *pcStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017badb0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_1c = *(int *)(param_2 + 0xc);
  uVar8 = *(int *)(param_2 + 0x10) - iStack_1c >> 3;
  if (uVar8 != 0) {
    do {
      pbVar4 = *(byte **)(iStack_1c + uStack_14 * 8);
      pbVar7 = *(byte **)(param_2 + 0x1c);
      do {
        bVar1 = *pbVar4;
        bVar9 = bVar1 < *pbVar7;
        if (bVar1 != *pbVar7) {
LAB_00893d27:
          uVar5 = -(uint)bVar9 | 1;
          goto LAB_00893d2c;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar9 = bVar1 < pbVar7[1];
        if (bVar1 != pbVar7[1]) goto LAB_00893d27;
        pbVar4 = pbVar4 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar1 != 0);
      uVar5 = 0;
LAB_00893d2c:
    } while ((uVar5 == 0) && (uStack_14 = uStack_14 + 1, uStack_14 < uVar8));
  }
  uStack_18 = *(int *)(param_2 + 0x10) - iStack_1c >> 3;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  do {
    if (uStack_14 == uStack_18) {
      pcStack_30 = FUN_00893620;
      uStack_2c = 0;
      puStack_24 = puVar2;
      uStack_28 = param_1;
      cVar3 = FUN_00585a40(&pcStack_30);
      if (cVar3 == '\0') {
        auStack_50[0] = 0x191d17d;
        pcStack_48 = pcStack_30;
        uStack_44 = uStack_2c;
        uStack_40 = uStack_28;
        puStack_3c = puStack_24;
      }
      else {
        auStack_50[0] = 0;
      }
      if ((uint *)(param_2 + 0x38) != auStack_50) {
        auStack_70[0] = 0;
        uStack_8._0_1_ = 1;
        uStack_8._1_3_ = 0;
        FUN_005880d0(auStack_50);
        FUN_005880d0((uint *)(param_2 + 0x38));
        FUN_005880d0(auStack_70);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (auStack_70[0] != 0) {
          if (((auStack_70[0] & 1) == 0) && (*(code **)(auStack_70[0] & 0xfffffffe) != (code *)0x0))
          {
            (**(code **)(auStack_70[0] & 0xfffffffe))(auStack_68,auStack_68,2);
          }
          auStack_70[0] = 0;
        }
      }
      uStack_8 = 3;
      if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
         (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_50[0] & 0xfffffffe))(&pcStack_48,&pcStack_48,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    iStack_1c = uStack_14 * 8;
    uStack_20 = *(int *)(iStack_1c + 4 + *(int *)(param_2 + 0xc));
    param_3 = *(undefined4 **)(uStack_20 + 4);
    if ((uint)(((*(int *)(param_1 + 500) - *(int *)(param_1 + 0x1f0)) / 0xc) * 3) >> 2 <=
        *(uint *)(param_1 + 0x1fc)) {
      FUN_00893880();
    }
    iVar6 = FUN_00731e30(&param_3);
    *(uint *)(iVar6 + 4) = uStack_20;
    *(undefined4 **)(iVar6 + 8) = puVar2;
    uStack_20 = *(int *)(param_2 + 0x10) - *(int *)(param_2 + 0xc) >> 3;
    param_3 = (undefined4 *)(iStack_1c + *(int *)(param_2 + 0xc));
    do {
      param_3 = param_3 + 2;
      uStack_14 = uStack_14 + 1;
      if (uStack_20 <= uStack_14) break;
      pbVar4 = (byte *)*param_3;
      pbVar7 = *(byte **)(param_2 + 0x1c);
      do {
        bVar1 = *pbVar4;
        bVar9 = bVar1 < *pbVar7;
        if (bVar1 != *pbVar7) {
LAB_00893e23:
          uVar8 = -(uint)bVar9 | 1;
          goto LAB_00893e28;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar4[1];
        bVar9 = bVar1 < pbVar7[1];
        if (bVar1 != pbVar7[1]) goto LAB_00893e23;
        pbVar4 = pbVar4 + 2;
        pbVar7 = pbVar7 + 2;
      } while (bVar1 != 0);
      uVar8 = 0;
LAB_00893e28:
    } while (uVar8 == 0);
  } while( true );
}



/* FUNCTION 14008 ; VA 0x00893f30 ; thunk_FUN_0088d190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088d190(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9a4);
    if (DAT_01ede9a4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Content",0x30,0,0,0);
      _DAT_01ede980 = RBX::Reflection::TType<class_RBX::ContentId>::vftable;
      FUN_016f3654(&LAB_01880a00);
      FUN_016f37bf(&DAT_01ede9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede980;
}



/* FUNCTION 14009 ; VA 0x00893fb0 ; thunk_FUN_00da8f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00da8f20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181f4ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f102e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f102e4);
    if (DAT_01f102e4 == -1) {
      uStack_8 = 0;
      FUN_00888860("TweenInfo",0x36,0,0,0);
      _DAT_01f102c0 = RBX::Reflection::TType<class_RBX::TweenInfo>::vftable;
      FUN_016f3654(&LAB_0189d6d0);
      FUN_016f37bf(&DAT_01f102e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f102c0;
}



/* FUNCTION 14010 ; VA 0x00893fc0 ; thunk_FUN_00da9bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00da9bd0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181f5fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1038c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f1038c);
    if (DAT_01f1038c == -1) {
      uStack_8 = 0;
      FUN_00888860("DockWidgetPluginGuiInfo",0x37,0,0,0);
      _DAT_01f10368 = RBX::Reflection::TType<class_RBX::DockWidgetPluginGuiInfo>::vftable;
      FUN_016f3654(&LAB_0189d6e0);
      FUN_016f37bf(&DAT_01f1038c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f10368;
}



/* FUNCTION 14011 ; VA 0x00893fd0 ; thunk_FUN_00da6440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00da6440(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181f1ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f10294) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f10294);
    if (DAT_01f10294 == -1) {
      uStack_8 = 0;
      FUN_00888860("PluginDrag",0x38,0,0,0);
      _DAT_01f10270 = RBX::Reflection::TType<class_RBX::PluginDrag>::vftable;
      FUN_016f3654(&LAB_0189d690);
      FUN_016f37bf(&DAT_01f10294);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f10270;
}



/* FUNCTION 14012 ; VA 0x00893fe0 ; thunk_FUN_00da88a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00da88a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181f49c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f102bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f102bc);
    if (DAT_01f102bc == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_01988cc8,0x39,0,0,0);
      _DAT_01f10298 = RBX::Reflection::TType<class_RBX::Random>::vftable;
      FUN_016f3654(&LAB_0189d6a0);
      FUN_016f37bf(&DAT_01f102bc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f10298;
}



/* FUNCTION 14013 ; VA 0x00893ff0 ; thunk_FUN_00d89a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00d89a00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181d64c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0fd64) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f0fd64);
    if (DAT_01f0fd64 == -1) {
      uStack_8 = 0;
      FUN_00888860("RaycastParams",0x3d,0,0,0);
      _DAT_01f0fd40 = RBX::Reflection::TType<class_RBX::LuaRaycastParams>::vftable;
      FUN_016f3654(&LAB_0189d260);
      FUN_016f37bf(&DAT_01f0fd64);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f0fd40;
}



/* FUNCTION 14014 ; VA 0x00894010 ; thunk_FUN_00da48e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00da48e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181eebc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1025c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01f1025c);
    if (DAT_01f1025c == -1) {
      uStack_8 = 0;
      FUN_00888860("CatalogSearchParams",0x41,0,0,0);
      _DAT_01f10238 = RBX::Reflection::TType<class_RBX::CatalogSearchParams>::vftable;
      FUN_016f3654(&LAB_0189d680);
      FUN_016f37bf(&DAT_01f1025c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01f10238;
}



/* FUNCTION 14015 ; VA 0x00894020 ; thunk_FUN_00d7fd90 */

void thunk_FUN_00d7fd90(void)

{
  FUN_00d7fd90();
  return;
}



/* FUNCTION 14016 ; VA 0x008940f0 ; thunk_FUN_00e40f60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00e40f60(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182c660;
  pvStack_10 = ExceptionList;
  if (DAT_01f1aa44 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1ac58) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f1ac58);
      if (DAT_01f1ac58 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_018dbc64,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f1ac50 = RBX::Creator<class_RBX::Team>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f1aa48,&DAT_01f1ac50);
        FUN_016f3654(FUN_018a2510);
        FUN_016f37bf(&DAT_01f1ac58);
      }
    }
    DAT_01f1aa44 = &DAT_01f1aa48;
  }
  ExceptionList = pvStack_10;
  return DAT_01f1aa44;
}



/* FUNCTION 14017 ; VA 0x00894100 ; thunk_FUN_00897b90 */

undefined * thunk_FUN_00897b90(void)

{
  int iVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017baff8;
  pvStack_10 = ExceptionList;
  if (DAT_01edf5cc == (undefined *)0x0) {
    iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iVar1 + 0x34) < DAT_01edf7d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edf7d8);
      if (DAT_01edf7d8 == -1) {
        iStack_8 = 0;
        if (*(int *)(iVar1 + 0x34) < DAT_01edefb0) {
          FUN_016f3809(&DAT_01edefb0);
          if (DAT_01edefb0 == -1) {
            iStack_8._0_1_ = 1;
            FUN_00891e30();
            FUN_016f3654(&LAB_01880b80);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_016f37bf(&DAT_01edefb0);
          }
        }
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(&DAT_01ededa8,&DAT_0191cd78,0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018813b0);
        FUN_016f37bf(&DAT_01edf7d8);
      }
    }
    DAT_01edf5cc = &DAT_01edf5d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01edf5cc;
}



/* FUNCTION 14018 ; VA 0x00894520 ; thunk_FUN_00e63280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00e63280(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018300d0;
  pvStack_10 = ExceptionList;
  if (DAT_01f1d4ec == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1d700) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f1d700);
      if (DAT_01f1d700 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Animation",0,uStack_20,0,0,0x1b,0,&DAT_01f127c8);
        _DAT_01f1d6f8 = RBX::Creator<class_RBX::Animation>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f1d4f0,&DAT_01f1d6f8);
        FUN_016f3654(FUN_018a2d30);
        FUN_016f37bf(&DAT_01f1d700);
      }
    }
    DAT_01f1d4ec = &DAT_01f1d4f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01f1d4ec;
}



/* FUNCTION 14019 ; VA 0x008946e0 ; thunk_FUN_00e70350 */

undefined * thunk_FUN_00e70350(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183139c;
  pvStack_10 = ExceptionList;
  if (DAT_01f1f10c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1f318) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f1f318);
      if (DAT_01f1f318 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PVInstance",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018a36b0);
        FUN_016f37bf(&DAT_01f1f318);
      }
    }
    DAT_01f1f10c = &DAT_01f1f110;
  }
  ExceptionList = pvStack_10;
  return DAT_01f1f10c;
}



/* FUNCTION 14020 ; VA 0x00894800 ; thunk_FUN_00e469a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00e469a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0182cf30;
  pvStack_10 = ExceptionList;
  if (DAT_01f1bf7c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f1c190) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f1c190);
      if (DAT_01f1c190 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e8aac0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SpawnLocation",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f1c188 = RBX::Creator<class_RBX::SpawnLocation>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f1bf80,&DAT_01f1c188);
        FUN_016f3654(FUN_018a2830);
        FUN_016f37bf(&DAT_01f1c190);
      }
    }
    DAT_01f1bf7c = &DAT_01f1bf80;
  }
  ExceptionList = pvStack_10;
  return DAT_01f1bf7c;
}



/* FUNCTION 14021 ; VA 0x00894840 ; thunk_FUN_00d1e830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00d1e830(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018181f0;
  pvStack_10 = ExceptionList;
  if (DAT_01f07568 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f07780) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f07780);
      if (DAT_01f07780 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Camera",0,uStack_20,0,0,0x19,0,0);
        _DAT_01f07778 = RBX::Creator<class_RBX::Camera>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f07570,&DAT_01f07778);
        FUN_016f3654(FUN_0189aa40);
        FUN_016f37bf(&DAT_01f07780);
      }
    }
    DAT_01f07568 = &DAT_01f07570;
  }
  ExceptionList = pvStack_10;
  return DAT_01f07568;
}



/* FUNCTION 14022 ; VA 0x00894b40 ; thunk_FUN_00dba540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00dba540(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018213b0;
  pvStack_10 = ExceptionList;
  if (DAT_01f14168 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f14380) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f14380);
      if (DAT_01f14380 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00dba460();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_0198f5ac,0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f14378 = RBX::Creator<class_RBX::Hole>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f14170,&DAT_01f14378);
        FUN_016f3654(FUN_0189eab0);
        FUN_016f37bf(&DAT_01f14380);
      }
    }
    DAT_01f14168 = &DAT_01f14170;
  }
  ExceptionList = pvStack_10;
  return DAT_01f14168;
}



/* FUNCTION 14023 ; VA 0x00894e10 ; thunk_FUN_00ee4f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00ee4f90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0183b0a0;
  pvStack_10 = ExceptionList;
  if (DAT_01f28e4c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f29060) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f29060);
      if (DAT_01f29060 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SoundGroup",0,uStack_20,0,0,0x1b,0,&DAT_01ef904c);
        _DAT_01f29058 = RBX::Creator<class_RBX::Soundscape::SoundGroup>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f28e50,&DAT_01f29058);
        FUN_016f3654(FUN_018a8290);
        FUN_016f37bf(&DAT_01f29060);
      }
    }
    DAT_01f28e4c = &DAT_01f28e50;
  }
  ExceptionList = pvStack_10;
  return DAT_01f28e4c;
}



/* FUNCTION 14024 ; VA 0x00895170 ; FUN_00895170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895170(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf504) {
    FUN_016f3809(&DAT_01edf504);
    if (DAT_01edf504 == -1) {
      _DAT_01edf4f8 = FUN_005c65e0;
      _DAT_01edf4fc = FUN_005c65e0;
      _DAT_01edf500 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf504);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf4f8) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf4f8;
  return param_1;
}



/* FUNCTION 14025 ; VA 0x00895220 ; FUN_00895220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895220(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf564) {
    FUN_016f3809(&DAT_01edf564);
    if (DAT_01edf564 == -1) {
      _DAT_01edf558 = FUN_005c65e0;
      _DAT_01edf55c = FUN_005c65e0;
      _DAT_01edf560 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf564);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf558) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf558;
  return param_1;
}



/* FUNCTION 14026 ; VA 0x008952d0 ; FUN_008952d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008952d0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf4d4) {
    FUN_016f3809(&DAT_01edf4d4);
    if (DAT_01edf4d4 == -1) {
      _DAT_01edf4c8 = FUN_005c65e0;
      _DAT_01edf4cc = FUN_005c65e0;
      _DAT_01edf4d0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf4d4);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf4c8) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf4c8;
  return param_1;
}



/* FUNCTION 14027 ; VA 0x00895380 ; FUN_00895380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895380(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf554) {
    FUN_016f3809(&DAT_01edf554);
    if (DAT_01edf554 == -1) {
      _DAT_01edf548 = FUN_005c65e0;
      _DAT_01edf54c = FUN_005c65e0;
      _DAT_01edf550 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf554);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf548) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf548;
  return param_1;
}



/* FUNCTION 14028 ; VA 0x00895430 ; FUN_00895430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895430(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf534) {
    FUN_016f3809(&DAT_01edf534);
    if (DAT_01edf534 == -1) {
      _DAT_01edf528 = FUN_005c65e0;
      _DAT_01edf52c = FUN_005c65e0;
      DAT_01edf530 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf534);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf528) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf528;
  return param_1;
}



/* FUNCTION 14029 ; VA 0x008954e0 ; FUN_008954e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008954e0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf514) {
    FUN_016f3809(&DAT_01edf514);
    if (DAT_01edf514 == -1) {
      _DAT_01edf508 = FUN_005c65e0;
      _DAT_01edf50c = FUN_005c65e0;
      _DAT_01edf510 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf514);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf508) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf508;
  return param_1;
}



/* FUNCTION 14030 ; VA 0x00895590 ; FUN_00895590 */

int * __fastcall FUN_00895590(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896d50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14031 ; VA 0x008955c0 ; thunk_FUN_00896ba0 */

undefined * thunk_FUN_00896ba0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017badec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf314) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf314);
    if (DAT_01edf314 == -1) {
      uStack_8 = 0;
      FUN_00aa5390();
      FUN_016f3654(&LAB_01880b90);
      FUN_016f37bf(&DAT_01edf314);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf2b0;
}



/* FUNCTION 14032 ; VA 0x008955d0 ; thunk_FUN_00896c30 */

undefined * thunk_FUN_00896c30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf0a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf0a4);
    if (DAT_01edf0a4 == -1) {
      uStack_8 = 0;
      FUN_00ccf750();
      FUN_016f3654(&LAB_01880bb0);
      FUN_016f37bf(&DAT_01edf0a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf040;
}



/* FUNCTION 14033 ; VA 0x008955e0 ; thunk_FUN_00896cc0 */

undefined * thunk_FUN_00896cc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf44c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf44c);
    if (DAT_01edf44c == -1) {
      uStack_8 = 0;
      FUN_00d28570();
      FUN_016f3654(&LAB_01880bd0);
      FUN_016f37bf(&DAT_01edf44c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf3e8;
}



/* FUNCTION 14034 ; VA 0x008955f0 ; thunk_FUN_00896d50 */

undefined * thunk_FUN_00896d50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf10c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf10c);
    if (DAT_01edf10c == -1) {
      uStack_8 = 0;
      FUN_00e35c70();
      FUN_016f3654(&LAB_01880bf0);
      FUN_016f37bf(&DAT_01edf10c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf0a8;
}



/* FUNCTION 14035 ; VA 0x00895600 ; thunk_FUN_00896e70 */

undefined * thunk_FUN_00896e70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf1dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf1dc);
    if (DAT_01edf1dc == -1) {
      uStack_8 = 0;
      FUN_00b00ba0();
      FUN_016f3654(&LAB_01880c30);
      FUN_016f37bf(&DAT_01edf1dc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf178;
}



/* FUNCTION 14036 ; VA 0x00895610 ; thunk_FUN_00896f00 */

undefined * thunk_FUN_00896f00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baeac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf174) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf174);
    if (DAT_01edf174 == -1) {
      uStack_8 = 0;
      FUN_00911670();
      FUN_016f3654(&LAB_01880c50);
      FUN_016f37bf(&DAT_01edf174);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf110;
}



/* FUNCTION 14037 ; VA 0x00895620 ; thunk_FUN_00896fb0 */

undefined * thunk_FUN_00896fb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baecc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf2ac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf2ac);
    if (DAT_01edf2ac == -1) {
      uStack_8 = 0;
      FUN_00e359d0();
      FUN_016f3654(&LAB_01880c70);
      FUN_016f37bf(&DAT_01edf2ac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf248;
}



/* FUNCTION 14038 ; VA 0x00895630 ; thunk_FUN_008970d0 */

undefined * thunk_FUN_008970d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf244) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf244);
    if (DAT_01edf244 == -1) {
      uStack_8 = 0;
      FUN_00dae130();
      FUN_016f3654(&LAB_01880cb0);
      FUN_016f37bf(&DAT_01edf244);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf1e0;
}



/* FUNCTION 14039 ; VA 0x00895640 ; thunk_FUN_00897160 */

undefined * thunk_FUN_00897160(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf4b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf4b4);
    if (DAT_01edf4b4 == -1) {
      uStack_8 = 0;
      FUN_009116d0();
      FUN_016f3654(&LAB_01880cd0);
      FUN_016f37bf(&DAT_01edf4b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf450;
}



/* FUNCTION 14040 ; VA 0x00895650 ; FUN_00895650 */

undefined4 __fastcall FUN_00895650(undefined4 param_1)

{
  undefined4 uVar1;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  code *apcStack_28 [6];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017badd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01160660();
  thunk_FUN_00add460();
  FUN_00c86270();
  FUN_00db52d0();
  thunk_FUN_009fb580();
  FUN_00db6e20();
  _guard_check_icall();
  auStack_30[0] = 0;
  FUN_00896ae0(apcStack_28,apcStack_28,2);
  apcStack_28[0] = FUN_00896b60;
  auStack_30[0] = 0x191da35;
  auStack_50[0] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_005880d0(auStack_30);
  FUN_005880d0(&DAT_02110d88);
  FUN_005880d0(auStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (auStack_50[0] != 0) {
    if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
    }
    auStack_50[0] = 0;
  }
  uStack_8 = 3;
  if (auStack_30[0] != 0) {
    if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(apcStack_28,apcStack_28,2);
    }
    auStack_30[0] = 0;
  }
  uStack_8 = 0xffffffff;
  uVar1 = FUN_01679ce0();
  FUN_0171d758(uVar1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14041 ; VA 0x00895780 ; FUN_00895780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895780(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_G3D::Vector3::Axis>::vftable;
  _DAT_01edf008 = _DAT_01edf008 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14042 ; VA 0x008957b0 ; FUN_008957b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008957b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::DataStoreService::DataStoreRequestType>::vftable;
  _DAT_01edf038 = _DAT_01edf038 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14043 ; VA 0x008957e0 ; FUN_008957e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008957e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Text::Font>::vftable;
  _DAT_01edeff0 = _DAT_01edeff0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14044 ; VA 0x00895810 ; FUN_00895810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895810(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::KeyCode>::vftable;
  _DAT_01edf030 = _DAT_01edf030 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14045 ; VA 0x00895840 ; FUN_00895840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895840(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::KeywordFilterType>::vftable;
  _DAT_01edeff8 = _DAT_01edeff8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14046 ; VA 0x00895870 ; FUN_00895870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895870(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PartMaterial>::vftable;
  _DAT_01edf020 = _DAT_01edf020 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14047 ; VA 0x008958a0 ; FUN_008958a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008958a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Time::SampleMethod>::vftable;
  _DAT_01edf028 = _DAT_01edf028 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14048 ; VA 0x008958d0 ; FUN_008958d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008958d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::SoundType>::vftable;
  _DAT_01edf010 = _DAT_01edf010 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14049 ; VA 0x00895900 ; FUN_00895900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895900(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Legacy::SurfaceConstraint>::vftable;
  _DAT_01edf000 = _DAT_01edf000 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14050 ; VA 0x00895930 ; FUN_00895930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895930(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::SurfaceType>::vftable;
  _DAT_01edf018 = _DAT_01edf018 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14051 ; VA 0x00895960 ; FUN_00895960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00895960(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TaskScheduler::ThreadPoolConfig>::vftable;
  _DAT_01edefe8 = _DAT_01edefe8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14052 ; VA 0x00895990 ; FUN_00895990 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895990(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896ba0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf504) {
      FUN_016f3809(&DAT_01edf504);
      if (DAT_01edf504 == -1) {
        _DAT_01edf4f8 = FUN_005c65e0;
        _DAT_01edf4fc = FUN_005c65e0;
        _DAT_01edf500 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf504);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf4f8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf4f8;
  }
  return;
}



/* FUNCTION 14053 ; VA 0x00895a50 ; FUN_00895a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895a50(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896c30();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf564) {
      FUN_016f3809(&DAT_01edf564);
      if (DAT_01edf564 == -1) {
        _DAT_01edf558 = FUN_005c65e0;
        _DAT_01edf55c = FUN_005c65e0;
        _DAT_01edf560 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf564);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf558) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf558;
  }
  return;
}



/* FUNCTION 14054 ; VA 0x00895b10 ; FUN_00895b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895b10(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896cc0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf4d4) {
      FUN_016f3809(&DAT_01edf4d4);
      if (DAT_01edf4d4 == -1) {
        _DAT_01edf4c8 = FUN_005c65e0;
        _DAT_01edf4cc = FUN_005c65e0;
        _DAT_01edf4d0 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf4d4);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf4c8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf4c8;
  }
  return;
}



/* FUNCTION 14055 ; VA 0x00895bd0 ; FUN_00895bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895bd0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896d50();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf554) {
      FUN_016f3809(&DAT_01edf554);
      if (DAT_01edf554 == -1) {
        _DAT_01edf548 = FUN_005c65e0;
        _DAT_01edf54c = FUN_005c65e0;
        _DAT_01edf550 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf554);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf548) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf548;
  }
  return;
}



/* FUNCTION 14056 ; VA 0x00895c90 ; FUN_00895c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895c90(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896de0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf4e4) {
      FUN_016f3809(&DAT_01edf4e4);
      if (DAT_01edf4e4 == -1) {
        _DAT_01edf4d8 = FUN_005c65e0;
        _DAT_01edf4dc = FUN_005c65e0;
        _DAT_01edf4e0 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf4e4);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf4d8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf4d8;
  }
  return;
}



/* FUNCTION 14057 ; VA 0x00895d50 ; FUN_00895d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895d50(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896e70();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf534) {
      FUN_016f3809(&DAT_01edf534);
      if (DAT_01edf534 == -1) {
        _DAT_01edf528 = FUN_005c65e0;
        _DAT_01edf52c = FUN_005c65e0;
        DAT_01edf530 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf534);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf528) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf528;
  }
  return;
}



/* FUNCTION 14058 ; VA 0x00895e10 ; FUN_00895e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895e10(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896f00();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf544) {
      FUN_016f3809(&DAT_01edf544);
      if (DAT_01edf544 == -1) {
        _DAT_01edf538 = FUN_005c65e0;
        _DAT_01edf53c = FUN_005c65e0;
        _DAT_01edf540 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf544);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf538) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf538;
  }
  return;
}



/* FUNCTION 14059 ; VA 0x00895ed0 ; FUN_00895ed0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895ed0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00896fb0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf514) {
      FUN_016f3809(&DAT_01edf514);
      if (DAT_01edf514 == -1) {
        _DAT_01edf508 = FUN_005c65e0;
        _DAT_01edf50c = FUN_005c65e0;
        _DAT_01edf510 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf514);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf508) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf508;
  }
  return;
}



/* FUNCTION 14060 ; VA 0x00895f90 ; FUN_00895f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00895f90(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00897040();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf4f4) {
      FUN_016f3809(&DAT_01edf4f4);
      if (DAT_01edf4f4 == -1) {
        _DAT_01edf4e8 = FUN_005c65e0;
        _DAT_01edf4ec = FUN_005c65e0;
        _DAT_01edf4f0 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf4f4);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf4e8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf4e8;
  }
  return;
}



/* FUNCTION 14061 ; VA 0x00896050 ; FUN_00896050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00896050(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_008970d0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf524) {
      FUN_016f3809(&DAT_01edf524);
      if (DAT_01edf524 == -1) {
        _DAT_01edf518 = FUN_005c65e0;
        _DAT_01edf51c = FUN_005c65e0;
        _DAT_01edf520 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf524);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf518) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf518;
  }
  return;
}



/* FUNCTION 14062 ; VA 0x00896110 ; FUN_00896110 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00896110(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00897160();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf4c4) {
      FUN_016f3809(&DAT_01edf4c4);
      if (DAT_01edf4c4 == -1) {
        _DAT_01edf4b8 = FUN_005c65e0;
        _DAT_01edf4bc = FUN_005c65e0;
        _DAT_01edf4c0 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf4c4);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf4b8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf4b8;
  }
  return;
}



/* FUNCTION 14063 ; VA 0x008961d0 ; FUN_008961d0 */

void FUN_008961d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896ba0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14064 ; VA 0x00896210 ; FUN_00896210 */

void FUN_00896210(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896c30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14065 ; VA 0x00896250 ; FUN_00896250 */

void FUN_00896250(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896cc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14066 ; VA 0x00896290 ; FUN_00896290 */

void FUN_00896290(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896d50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14067 ; VA 0x008962d0 ; FUN_008962d0 */

void FUN_008962d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14068 ; VA 0x00896310 ; FUN_00896310 */

void FUN_00896310(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896e70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14069 ; VA 0x00896350 ; FUN_00896350 */

void FUN_00896350(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896f00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14070 ; VA 0x00896390 ; FUN_00896390 */

void FUN_00896390(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896fb0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14071 ; VA 0x008963d0 ; FUN_008963d0 */

void FUN_008963d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00897040();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14072 ; VA 0x00896410 ; FUN_00896410 */

void FUN_00896410(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008970d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14073 ; VA 0x00896450 ; FUN_00896450 */

void FUN_00896450(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00897160();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14074 ; VA 0x00896490 ; FUN_00896490 */

void FUN_00896490(void)

{
  undefined **ppuVar1;
  int iVar2;
  
  ppuVar1 = &PTR_thunk_FUN_00888530_0191d188;
  iVar2 = 0;
  do {
    (*(code *)*ppuVar1)();
    iVar2 = iVar2 + 1;
    ppuVar1 = ppuVar1 + 1;
  } while (iVar2 != 0x3c);
  ppuVar1 = &PTR_thunk_FUN_00d7fd90_0191d278;
  iVar2 = 0;
  do {
    (*(code *)*ppuVar1)();
    iVar2 = iVar2 + 1;
    ppuVar1 = ppuVar1 + 1;
  } while (iVar2 != 0x1a1);
  thunk_FUN_00a65740();
  thunk_FUN_00c08100();
  thunk_FUN_00db7510();
  thunk_FUN_00db9730();
  thunk_FUN_00bd5640();
  thunk_FUN_00c7d230();
  thunk_FUN_00c7d400();
  thunk_FUN_00d99c10();
  thunk_FUN_00da9580();
  thunk_FUN_00c7d370();
  thunk_FUN_00c45940();
  thunk_FUN_00c459d0();
  thunk_FUN_00c456c0();
  thunk_FUN_00c458b0();
  thunk_FUN_00d25f00();
  thunk_FUN_00935b10();
  thunk_FUN_00d25e50();
  thunk_FUN_00daf140();
  thunk_FUN_00dba240();
  thunk_FUN_00bc0d60();
  thunk_FUN_00dbc6b0();
  thunk_FUN_00dbc760();
  thunk_FUN_00dbc810();
  thunk_FUN_009c68d0();
  thunk_FUN_009c65d0();
  thunk_FUN_009c6730();
  thunk_FUN_0098d050();
  thunk_FUN_009c6680();
  thunk_FUN_009c6470();
  thunk_FUN_009c6520();
  thunk_FUN_009c67e0();
  thunk_FUN_0063cc40();
  thunk_FUN_0090bf80();
  thunk_FUN_0090bdc0();
  thunk_FUN_0090bea0();
  thunk_FUN_008a7680();
  thunk_FUN_00b0f6f0();
  thunk_FUN_00aeea60();
  thunk_FUN_00d39cc0();
  thunk_FUN_00c6cea0();
  thunk_FUN_00c8d570();
  thunk_FUN_00d0fb10();
  thunk_FUN_00b0f630();
  thunk_FUN_00b84860();
  thunk_FUN_00b798a0();
  thunk_FUN_00b79950();
  thunk_FUN_00b849a0();
  thunk_FUN_00bb1980();
  thunk_FUN_00bb1a30();
  thunk_FUN_00b9dae0();
  thunk_FUN_00b9d9a0();
  thunk_FUN_00b9db90();
  thunk_FUN_00dd4470();
  thunk_FUN_00dd4310();
  thunk_FUN_00a8cb50();
  thunk_FUN_00a8caa0();
  thunk_FUN_00a8cc00();
  thunk_FUN_00a4d330();
  thunk_FUN_00b31840();
  thunk_FUN_00b318f0();
  thunk_FUN_00cff800();
  thunk_FUN_00cc1bc0();
  thunk_FUN_00cc1c80();
  thunk_FUN_00cc1b10();
  thunk_FUN_00c51570();
  thunk_FUN_00c51450();
  thunk_FUN_00c51600();
  thunk_FUN_00c514e0();
  thunk_FUN_00cc1d30();
  thunk_FUN_00dd5710();
  thunk_FUN_00c7d2c0();
  thunk_FUN_00d69b50();
  thunk_FUN_00dd7f50();
  thunk_FUN_00dd8000();
  thunk_FUN_00dd7ea0();
  thunk_FUN_00afe430();
  thunk_FUN_00afe380();
  thunk_FUN_00afe4e0();
  thunk_FUN_00afe640();
  thunk_FUN_00afe590();
  thunk_FUN_00d3f7c0();
  thunk_FUN_00b84a30();
  thunk_FUN_00d82070();
  thunk_FUN_009eb4b0();
  thunk_FUN_00b61fb0();
  thunk_FUN_00b62060();
  thunk_FUN_00935d50();
  thunk_FUN_00935c30();
  thunk_FUN_00935ba0();
  thunk_FUN_00935de0();
  thunk_FUN_00935cc0();
  thunk_FUN_00b319a0();
  thunk_FUN_00c28850();
  thunk_FUN_00c287a0();
  thunk_FUN_00ae1680();
  thunk_FUN_00999de0();
  thunk_FUN_00c7d1a0();
  thunk_FUN_00c7d110();
  thunk_FUN_00db7200();
  thunk_FUN_00db7150();
  thunk_FUN_00dda5f0();
  thunk_FUN_00ca6a20();
  thunk_FUN_00ca6ad0();
  thunk_FUN_00ca6970();
  thunk_FUN_00b317b0();
  thunk_FUN_00debdb0();
  thunk_FUN_00debc50();
  thunk_FUN_00debd00();
  thunk_FUN_00debe60();
  thunk_FUN_00ded0d0();
  thunk_FUN_00dee020();
  thunk_FUN_00deedd0();
  thunk_FUN_00deee80();
  thunk_FUN_00df22f0();
  thunk_FUN_00dfe970();
  thunk_FUN_00dfe8c0();
  thunk_FUN_00dd43c0();
  thunk_FUN_00dd4260();
  thunk_FUN_00c45800();
  thunk_FUN_00c45750();
  thunk_FUN_008bbd90();
  thunk_FUN_00c551a0();
  thunk_FUN_00d25fb0();
  thunk_FUN_008bbc30();
  thunk_FUN_00a9e800();
  thunk_FUN_00935e70();
  thunk_FUN_00bfa7a0();
  thunk_FUN_00adb7d0();
  thunk_FUN_00adb880();
  thunk_FUN_00adb720();
  thunk_FUN_00b84910();
  thunk_FUN_00890320();
  thunk_FUN_00b0f580();
  thunk_FUN_00b0f780();
  thunk_FUN_0086f380();
  thunk_FUN_00bd30e0();
  thunk_FUN_00dfea20();
  thunk_FUN_00e06ab0();
  thunk_FUN_00e06b60();
  thunk_FUN_00b9da50();
  thunk_FUN_00e08e70();
  thunk_FUN_00e0b140();
  thunk_FUN_00e0c140();
  thunk_FUN_00e0ca50();
  thunk_FUN_00e0eb50();
  thunk_FUN_00d8a170();
  thunk_FUN_00e117d0();
  thunk_FUN_00c12520();
  thunk_FUN_00d99a60();
  thunk_FUN_00e2bdc0();
  thunk_FUN_00d999d0();
  thunk_FUN_0098cfc0();
  thunk_FUN_00e2be70();
  thunk_FUN_00e35660();
  thunk_FUN_00b73400();
  thunk_FUN_00b73560();
  thunk_FUN_00b734b0();
  FUN_01675170();
  return;
}



/* FUNCTION 14075 ; VA 0x00896800 ; FUN_00896800 */

void FUN_00896800(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_2);
  return;
}



/* FUNCTION 14076 ; VA 0x00896820 ; FUN_00896820 */

void FUN_00896820(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896ba0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14077 ; VA 0x00896860 ; FUN_00896860 */

void FUN_00896860(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896c30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14078 ; VA 0x008968a0 ; FUN_008968a0 */

void FUN_008968a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896cc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14079 ; VA 0x008968e0 ; FUN_008968e0 */

void FUN_008968e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896d50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14080 ; VA 0x00896920 ; FUN_00896920 */

void FUN_00896920(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896de0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14081 ; VA 0x00896960 ; FUN_00896960 */

void FUN_00896960(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896e70();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14082 ; VA 0x008969a0 ; FUN_008969a0 */

void FUN_008969a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896f00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14083 ; VA 0x008969e0 ; FUN_008969e0 */

void FUN_008969e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00896fb0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14084 ; VA 0x00896a20 ; FUN_00896a20 */

void FUN_00896a20(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00897040();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14085 ; VA 0x00896a60 ; FUN_00896a60 */

void FUN_00896a60(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008970d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14086 ; VA 0x00896aa0 ; FUN_00896aa0 */

void FUN_00896aa0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00897160();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14087 ; VA 0x00896ae0 ; FUN_00896ae0 */

void FUN_00896ae0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da2ffc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01da2ff8;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14088 ; VA 0x00896b60 ; FUN_00896b60 */

void FUN_00896b60(int *param_1)

{
  undefined4 uVar1;
  
  if (DAT_01d84e8e != '\0') {
    FUN_016774b0(DAT_01d84e8e,"Slot Exception",0);
  }
  uVar1 = (**(code **)(*param_1 + 4))();
  FUN_0086f2f0(3,"exception while signaling: %s",uVar1);
  return;
}



/* FUNCTION 14089 ; VA 0x00896ba0 ; FUN_00896ba0 */

undefined * FUN_00896ba0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017badec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf314) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf314);
    if (DAT_01edf314 == -1) {
      uStack_8 = 0;
      FUN_00aa5390();
      FUN_016f3654(&LAB_01880b90);
      FUN_016f37bf(&DAT_01edf314);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf2b0;
}



/* FUNCTION 14090 ; VA 0x00896c30 ; FUN_00896c30 */

undefined * FUN_00896c30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf0a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf0a4);
    if (DAT_01edf0a4 == -1) {
      uStack_8 = 0;
      FUN_00ccf750();
      FUN_016f3654(&LAB_01880bb0);
      FUN_016f37bf(&DAT_01edf0a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf040;
}



/* FUNCTION 14091 ; VA 0x00896cc0 ; FUN_00896cc0 */

undefined * FUN_00896cc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf44c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf44c);
    if (DAT_01edf44c == -1) {
      uStack_8 = 0;
      FUN_00d28570();
      FUN_016f3654(&LAB_01880bd0);
      FUN_016f37bf(&DAT_01edf44c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf3e8;
}



/* FUNCTION 14092 ; VA 0x00896d50 ; FUN_00896d50 */

undefined * FUN_00896d50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf10c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf10c);
    if (DAT_01edf10c == -1) {
      uStack_8 = 0;
      FUN_00e35c70();
      FUN_016f3654(&LAB_01880bf0);
      FUN_016f37bf(&DAT_01edf10c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf0a8;
}



/* FUNCTION 14093 ; VA 0x00896de0 ; FUN_00896de0 */

undefined * FUN_00896de0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae6c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf3e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf3e4);
    if (DAT_01edf3e4 == -1) {
      uStack_8 = 0;
      FUN_00e35780();
      FUN_016f3654(&LAB_01880c10);
      FUN_016f37bf(&DAT_01edf3e4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf380;
}



/* FUNCTION 14094 ; VA 0x00896e70 ; FUN_00896e70 */

undefined * FUN_00896e70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bae8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf1dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf1dc);
    if (DAT_01edf1dc == -1) {
      uStack_8 = 0;
      FUN_00b00ba0();
      FUN_016f3654(&LAB_01880c30);
      FUN_016f37bf(&DAT_01edf1dc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf178;
}



/* FUNCTION 14095 ; VA 0x00896f00 ; FUN_00896f00 */

undefined * FUN_00896f00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baeac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf174) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf174);
    if (DAT_01edf174 == -1) {
      uStack_8 = 0;
      FUN_00911670();
      FUN_016f3654(&LAB_01880c50);
      FUN_016f37bf(&DAT_01edf174);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf110;
}



/* FUNCTION 14096 ; VA 0x00896fb0 ; FUN_00896fb0 */

undefined * FUN_00896fb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baecc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf2ac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf2ac);
    if (DAT_01edf2ac == -1) {
      uStack_8 = 0;
      FUN_00e359d0();
      FUN_016f3654(&LAB_01880c70);
      FUN_016f37bf(&DAT_01edf2ac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf248;
}



/* FUNCTION 14097 ; VA 0x00897040 ; FUN_00897040 */

undefined * FUN_00897040(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baeec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf37c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf37c);
    if (DAT_01edf37c == -1) {
      uStack_8 = 0;
      FUN_00e357e0();
      FUN_016f3654(&LAB_01880c90);
      FUN_016f37bf(&DAT_01edf37c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf318;
}



/* FUNCTION 14098 ; VA 0x008970d0 ; FUN_008970d0 */

undefined * FUN_008970d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf244) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf244);
    if (DAT_01edf244 == -1) {
      uStack_8 = 0;
      FUN_00dae130();
      FUN_016f3654(&LAB_01880cb0);
      FUN_016f37bf(&DAT_01edf244);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf1e0;
}



/* FUNCTION 14099 ; VA 0x00897160 ; FUN_00897160 */

undefined * FUN_00897160(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf4b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf4b4);
    if (DAT_01edf4b4 == -1) {
      uStack_8 = 0;
      FUN_009116d0();
      FUN_016f3654(&LAB_01880cd0);
      FUN_016f37bf(&DAT_01edf4b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf450;
}



/* FUNCTION 14100 ; VA 0x008971f0 ; FUN_008971f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008971f0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf504) {
    FUN_016f3809(&DAT_01edf504);
    if (DAT_01edf504 == -1) {
      _DAT_01edf4f8 = FUN_005c65e0;
      _DAT_01edf4fc = FUN_005c65e0;
      _DAT_01edf500 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf504);
    }
  }
  return &DAT_01edf4f8;
}



/* FUNCTION 14101 ; VA 0x00897260 ; FUN_00897260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897260(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf564) {
    FUN_016f3809(&DAT_01edf564);
    if (DAT_01edf564 == -1) {
      _DAT_01edf558 = FUN_005c65e0;
      _DAT_01edf55c = FUN_005c65e0;
      _DAT_01edf560 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf564);
    }
  }
  return &DAT_01edf558;
}



/* FUNCTION 14102 ; VA 0x008972d0 ; FUN_008972d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008972d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf4d4) {
    FUN_016f3809(&DAT_01edf4d4);
    if (DAT_01edf4d4 == -1) {
      _DAT_01edf4c8 = FUN_005c65e0;
      _DAT_01edf4cc = FUN_005c65e0;
      _DAT_01edf4d0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf4d4);
    }
  }
  return &DAT_01edf4c8;
}



/* FUNCTION 14103 ; VA 0x00897340 ; FUN_00897340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897340(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf554) {
    FUN_016f3809(&DAT_01edf554);
    if (DAT_01edf554 == -1) {
      _DAT_01edf548 = FUN_005c65e0;
      _DAT_01edf54c = FUN_005c65e0;
      _DAT_01edf550 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf554);
    }
  }
  return &DAT_01edf548;
}



/* FUNCTION 14104 ; VA 0x008973b0 ; FUN_008973b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008973b0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf534) {
    FUN_016f3809(&DAT_01edf534);
    if (DAT_01edf534 == -1) {
      _DAT_01edf528 = FUN_005c65e0;
      _DAT_01edf52c = FUN_005c65e0;
      DAT_01edf530 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf534);
    }
  }
  return &DAT_01edf528;
}



/* FUNCTION 14105 ; VA 0x00897420 ; FUN_00897420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897420(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf544) {
    FUN_016f3809(&DAT_01edf544);
    if (DAT_01edf544 == -1) {
      _DAT_01edf538 = FUN_005c65e0;
      _DAT_01edf53c = FUN_005c65e0;
      _DAT_01edf540 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf544);
    }
  }
  return &DAT_01edf538;
}



/* FUNCTION 14106 ; VA 0x00897490 ; FUN_00897490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897490(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf514) {
    FUN_016f3809(&DAT_01edf514);
    if (DAT_01edf514 == -1) {
      _DAT_01edf508 = FUN_005c65e0;
      _DAT_01edf50c = FUN_005c65e0;
      _DAT_01edf510 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf514);
    }
  }
  return &DAT_01edf508;
}



/* FUNCTION 14107 ; VA 0x00897500 ; FUN_00897500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897500(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf524) {
    FUN_016f3809(&DAT_01edf524);
    if (DAT_01edf524 == -1) {
      _DAT_01edf518 = FUN_005c65e0;
      _DAT_01edf51c = FUN_005c65e0;
      _DAT_01edf520 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf524);
    }
  }
  return &DAT_01edf518;
}



/* FUNCTION 14108 ; VA 0x00897570 ; FUN_00897570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00897570(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf4c4) {
    FUN_016f3809(&DAT_01edf4c4);
    if (DAT_01edf4c4 == -1) {
      _DAT_01edf4b8 = FUN_005c65e0;
      _DAT_01edf4bc = FUN_005c65e0;
      _DAT_01edf4c0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf4c4);
    }
  }
  return &DAT_01edf4b8;
}



/* FUNCTION 14109 ; VA 0x008975e0 ; FUN_008975e0 */

int * __thiscall
FUN_008975e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00897b90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Instance,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_(__thiscall_RBX::Instance::*)(void)const_,void_(__thiscall_RBX::Instance::*)(class_RBX::BinaryString)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Instance,class_RBX::BinaryString>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Instance,class_RBX::BinaryString>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14110 ; VA 0x008976e0 ; FUN_008976e0 */

int * __thiscall
FUN_008976e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00897b90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Instance,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Instance::*)(void)const_,void_(__thiscall_RBX::Instance::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Instance,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Instance,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14111 ; VA 0x008977e0 ; FUN_008977e0 */

undefined4 * __thiscall FUN_008977e0(undefined4 *param_1)

{
  char cVar1;
  uint uVar2;
  undefined **ppuVar3;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined auStack_bc [44];
  undefined4 uStack_90;
  uint uStack_8c;
  uint *puStack_88;
  undefined auStack_7c [28];
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined auStack_48 [28];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bafd0;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_7c;
  uStack_8 = 0;
  puStack_88 = (uint *)&stack0x00000004;
  uStack_8c = 0x89781b;
  ExceptionList = &pvStack_10;
  FUN_00d88710();
  puStack_88 = &stack0x00000020;
  uStack_8._0_1_ = 1;
  uStack_8c = 0x89782b;
  FUN_0054ef60();
  puStack_14 = auStack_48;
  uStack_8._0_1_ = 2;
  puStack_88 = (uint *)auStack_7c;
  *param_1 = 0;
  uStack_8c = 0x897847;
  FUN_00d88710();
  puStack_88 = auStack_60;
  uStack_8._0_1_ = 3;
  uStack_8c = 0x897857;
  FUN_0054ef60();
  puStack_88 = param_1 + 2;
  uStack_8._0_1_ = 4;
  puStack_14 = auStack_bc;
  FUN_00d88710(auStack_48);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_2c);
  ppuVar3 = &PTR_FUN_0191e888;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  cVar1 = FUN_00898910();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_18) {
    puStack_88 = (uint *)(uStack_18 + 1);
    uVar2 = auStack_2c[0];
    if (0xfff < puStack_88) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      puStack_88 = (uint *)(uStack_18 + 0x24);
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_88 = (uint *)0x89799a;
        FUN_017167a3();
      }
    }
    uStack_90 = 0x8978cc;
    uStack_8c = uVar2;
    FUN_01674ea0();
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  puStack_88 = (uint *)0x8978e9;
  FUN_00d88aa0();
  if (0xf < uStack_4c) {
    puStack_88 = (uint *)(uStack_4c + 1);
    uVar2 = auStack_60[0];
    if (0xfff < puStack_88) {
      uVar2 = *(uint *)(auStack_60[0] - 4);
      puStack_88 = (uint *)(uStack_4c + 0x24);
      if (0x1f < (auStack_60[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_88 = (uint *)0x89799f;
        FUN_017167a3();
      }
    }
    uStack_90 = 0x89791a;
    uStack_8c = uVar2;
    FUN_01674ea0();
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  puStack_88 = (uint *)0x897937;
  FUN_00d88aa0();
  if (0xf < in_stack_00000034) {
    puStack_88 = (uint *)(in_stack_00000034 + 1);
    uVar2 = in_stack_00000020;
    if (0xfff < puStack_88) {
      uVar2 = *(uint *)(in_stack_00000020 - 4);
      puStack_88 = (uint *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_88 = (uint *)&UNK_008979a4;
        FUN_017167a3();
      }
    }
    uStack_90 = 0x897964;
    uStack_8c = uVar2;
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  puStack_88 = (uint *)0x897981;
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14112 ; VA 0x008979b0 ; FUN_008979b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008979b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  uVar4 = FUN_0088cd20();
  iVar5 = _tls_index;
  *param_1 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar5 * 4) + 0x34) < DAT_01eded64) {
    FUN_016f3809(&DAT_01eded64);
    if (DAT_01eded64 == -1) {
      _DAT_01eded58 = FUN_0057bbb0;
      _DAT_01eded5c = FUN_005880a0;
      _DAT_01eded60 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01eded64);
    }
  }
  puVar2 = (undefined *)param_1[1];
  if (puVar2 == &DAT_01eded58) {
    iVar5 = param_2[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = param_2[1];
    }
    param_1[2] = *param_2;
    piVar3 = (int *)param_1[3];
    param_1[3] = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar3 = (int *)(param_2[1] + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  param_1[1] = &DAT_01eded58;
  return param_1;
}



/* FUNCTION 14113 ; VA 0x00897ae0 ; FUN_00897ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00897ae0(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf8cc) {
    FUN_016f3809(&DAT_01edf8cc);
    if (DAT_01edf8cc == -1) {
      _DAT_01edf8c0 = FUN_005c65e0;
      _DAT_01edf8c4 = FUN_005c65e0;
      _DAT_01edf8c8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf8cc);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01edf8c0) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01edf8c0;
  return param_1;
}



/* FUNCTION 14114 ; VA 0x00897b90 ; FUN_00897b90 */

undefined * FUN_00897b90(void)

{
  int iVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017baff8;
  pvStack_10 = ExceptionList;
  if (DAT_01edf5cc == (undefined *)0x0) {
    iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iVar1 + 0x34) < DAT_01edf7d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edf7d8);
      if (DAT_01edf7d8 == -1) {
        iStack_8 = 0;
        if (*(int *)(iVar1 + 0x34) < DAT_01edefb0) {
          FUN_016f3809(&DAT_01edefb0);
          if (DAT_01edefb0 == -1) {
            iStack_8._0_1_ = 1;
            FUN_00891e30();
            FUN_016f3654(&LAB_01880b80);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_016f37bf(&DAT_01edefb0);
          }
        }
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(&DAT_01ededa8,&DAT_0191cd78,0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_018813b0);
        FUN_016f37bf(&DAT_01edf7d8);
      }
    }
    DAT_01edf5cc = &DAT_01edf5d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01edf5cc;
}



/* FUNCTION 14115 ; VA 0x00897cc0 ; FUN_00897cc0 */

void FUN_00897cc0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_0089c680();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  return;
}



/* FUNCTION 14116 ; VA 0x00897ce0 ; FUN_00897ce0 */

int __thiscall FUN_00897ce0(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_8 = 0xff;
  uStack_7 = 0xffffff;
  puStack_c = &LAB_017bb028;
  pvStack_10 = ExceptionList;
  uVar13 = *param_1;
  iVar6 = (int)(param_1[1] - uVar13) >> 6;
  if (iVar6 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar10 = (int)(param_1[2] - uVar13) >> 6;
  uVar7 = uVar1;
  if ((uVar10 <= 0x3ffffff - (uVar10 >> 1)) && (uVar7 = (uVar10 >> 1) + uVar10, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar10 = uVar7 << 6;
  if (uVar7 < 0x4000000) {
    if (0xfff < uVar10) goto LAB_00897d71;
    if (uVar10 == 0) {
      uVar10 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar10 = FUN_01674e20(uVar10);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_00897d71:
    uVar8 = uVar10 + 0x23;
    if (uVar8 <= uVar10) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar6 = FUN_01674e20(uVar8);
    if (iVar6 == 0) goto LAB_00897f92;
    uVar10 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar10 - 4) = iVar6;
  }
  iVar6 = ((int)(param_2 - uVar13) >> 6) * 0x40;
  puVar9 = (undefined4 *)(iVar6 + uVar10);
  puVar9[4] = 0;
  puVar9[5] = 0;
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar9 = *param_3;
  puVar9[1] = uVar3;
  puVar9[2] = uVar4;
  puVar9[3] = uVar5;
  *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00d88710(param_3 + 6);
  iVar11 = iVar6 + uVar10;
  uStack_8 = 0;
  *(undefined4 *)(iVar11 + 0x34) = 0;
  *(undefined4 *)(iVar11 + 0x38) = 0;
  *(undefined4 *)(iVar11 + 0x34) = param_3[0xd];
  *(undefined4 *)(iVar11 + 0x38) = param_3[0xe];
  param_3[0xd] = 0;
  param_3[0xe] = 0;
  *(undefined4 *)(iVar11 + 0x3c) = param_3[0xf];
  uVar13 = param_1[1];
  if (param_2 == uVar13) {
    uVar12 = uVar10;
    for (uVar8 = *param_1; uStack_8 = 2, uVar8 != uVar13; uVar8 = uVar8 + 0x40) {
      FUN_0054ef60(uVar8);
      uStack_8 = 3;
      FUN_00d88710(uVar8 + 0x18);
      *(undefined4 *)(uVar12 + 0x34) = 0;
      *(undefined4 *)(uVar12 + 0x38) = 0;
      if (*(int *)(uVar8 + 0x38) != 0) {
        LOCK();
        piVar2 = (int *)(*(int *)(uVar8 + 0x38) + 8);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *(undefined4 *)(uVar12 + 0x34) = *(undefined4 *)(uVar8 + 0x34);
      *(undefined4 *)(uVar12 + 0x38) = *(undefined4 *)(uVar8 + 0x38);
      *(undefined4 *)(uVar12 + 0x3c) = *(undefined4 *)(uVar8 + 0x3c);
      uVar12 = uVar12 + 0x40;
    }
  }
  else {
    FUN_0089c880(*param_1,param_2,uVar10);
    FUN_0089c880(param_2,param_1[1],puVar9 + 0x10);
  }
  uVar13 = *param_1;
  if (uVar13 != 0) {
    uVar8 = param_1[1];
    if (uVar13 != uVar8) {
      do {
        FUN_0089b470();
        uVar13 = uVar13 + 0x40;
      } while (uVar13 != uVar8);
      uVar13 = *param_1;
    }
    uVar12 = param_1[2] - uVar13 & 0xffffffc0;
    uVar8 = uVar13;
    if (0xfff < uVar12) {
      uVar8 = *(uint *)(uVar13 - 4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (uVar13 - uVar8) - 4) {
LAB_00897f92:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar12);
  }
  *param_1 = uVar10;
  param_1[1] = uVar1 * 0x40 + uVar10;
  param_1[2] = uVar7 * 0x40 + uVar10;
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 14117 ; VA 0x00897f68 ; Catch_All@00897f68 */

void Catch_All_00897f68(void)

{
  int unaff_EBP;
  
  FUN_0089c6e0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14118 ; VA 0x00897fa0 ; FUN_00897fa0 */

void __thiscall
FUN_00897fa0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x9249247 < (uint)param_1[1]) {
    FUN_0089c710(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00898052:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00898052;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 14119 ; VA 0x00898100 ; FUN_00898100 */

void __thiscall
FUN_00898100(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0xcccccca < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00897cc0(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00898158;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00898158;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00898158:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_008981b1:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_008981b1;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 14120 ; VA 0x00898260 ; FUN_00898260 */

undefined4 * __thiscall
FUN_00898260(undefined4 *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb040;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00897fa0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00897fa0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00897fa0(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00897fa0(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00897fa0(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      FUN_00551320();
      if ((piStack_18 == (int *)*param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00897fa0(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00897fa0(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00898460(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14121 ; VA 0x0089844b ; Catch_All@0089844b */

void Catch_All_0089844b(void)

{
  int unaff_EBP;
  
  FUN_0089c710(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14122 ; VA 0x00898460 ; FUN_00898460 */

void __thiscall
FUN_00898460(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  bool bVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb050;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar3 = true;
  piVar1 = (int *)*param_1;
  piVar4 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    piVar1 = (int *)piVar1[1];
    do {
      piVar4 = piVar1;
      if (param_3 == '\0') {
        bVar3 = *param_4 < (uint)piVar4[4];
      }
      else {
        bVar3 = *param_4 <= (uint)piVar4[4];
      }
      if (bVar3 == false) {
        piVar1 = (int *)piVar4[2];
      }
      else {
        piVar1 = (int *)*piVar4;
      }
    } while (*(char *)((int)piVar1 + 0xd) == '\0');
    piVar1 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar4;
  if (bVar3 != false) {
    if (piVar4 == (int *)*piVar1) {
      bVar3 = true;
      ExceptionList = &pvStack_10;
      goto LAB_008984e7;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  piVar1 = _param_3;
  if (*param_4 <= (uint)_param_3[4]) {
    FUN_0089c710(param_5);
    *param_2 = piVar1;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_008984e7:
  puVar2 = (undefined4 *)FUN_00897fa0(&param_3,bVar3,piVar4,param_4,param_5);
  *param_2 = *puVar2;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14123 ; VA 0x00898552 ; Catch_All@00898552 */

void Catch_All_00898552(void)

{
  int unaff_EBP;
  
  FUN_0089c710(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14124 ; VA 0x00898570 ; FUN_00898570 */

undefined4 * __thiscall
FUN_00898570(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb060;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar6 = piVar5;
      if (param_3 == '\0') {
        bVar7 = *param_4 < (uint)piVar6[4];
      }
      else {
        bVar7 = *param_4 <= (uint)piVar6[4];
      }
      if (bVar7 == false) {
        piVar5 = (int *)piVar6[2];
      }
      else {
        piVar5 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_008985f9;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar5 = (int *)*piVar6;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar5 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar6[2];
    }
  }
  if (*param_4 <= (uint)piVar5[4]) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_008985f9:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00898100(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14125 ; VA 0x008986b0 ; Catch_All@008986b0 */

void Catch_All_008986b0(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14126 ; VA 0x008986c0 ; FUN_008986c0 */

int __thiscall FUN_008986c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb070;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CollectionService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14127 ; VA 0x00898792 ; Catch_All@00898792 */

void Catch_All_00898792(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14128 ; VA 0x008987b0 ; FUN_008987b0 */

undefined4 * __thiscall FUN_008987b0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb0a7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    *puVar3 = 0;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar3[2] = param_2;
    puVar3[3] = 8;
    puVar4 = (undefined4 *)FUN_01674e20(8);
    piVar1 = param_4 + 1;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = 0;
      puVar4[1] = 0;
      if (param_4 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *puVar4 = param_3;
      puVar4[1] = param_4;
    }
    puVar3[4] = puVar4;
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*param_4)();
        LOCK();
        iVar2 = param_4[2] + -1;
        param_4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar2 = param_4[1] + -1;
      param_4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_4)();
        LOCK();
        iVar2 = param_4[2] + -1;
        param_4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
  }
  puVar4 = *(undefined4 **)(param_1 + 0x24);
  if (puVar4 == (undefined4 *)0x0) {
    *(undefined4 **)(param_1 + 0x20) = puVar3;
  }
  else {
    *puVar4 = puVar3;
  }
  *(undefined4 **)(param_1 + 0x24) = puVar3;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    puVar4 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 14129 ; VA 0x00898910 ; FUN_00898910 */

uint FUN_00898910(void)

{
  char cVar1;
  undefined *puVar2;
  uint uVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined3 uStack00000038;
  undefined auStack_7c [28];
  undefined auStack_60 [24];
  undefined auStack_48 [28];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb0ff;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_7c;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d88710(&stack0x00000004);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000020);
  uStack_8._0_1_ = 2;
  cVar1 = FUN_00585a40(auStack_7c);
  if (cVar1 == '\0') {
    puStack_14 = auStack_48;
    FUN_00d88710(auStack_7c);
    uStack_8._0_1_ = 3;
    FUN_0054ef60(auStack_60);
    uStack_8._0_1_ = 4;
    puVar2 = (undefined *)FUN_01674e20(0x34);
    uStack_8._0_1_ = 5;
    puStack_14 = puVar2;
    if (puVar2 == (undefined *)0x0) {
      puVar2 = (undefined *)0x0;
    }
    else {
      FUN_00d88710(auStack_48);
      uStack_8._0_1_ = 6;
      FUN_0054ef60(auStack_2c);
    }
    *_uStack00000038 = (int)puVar2;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_00d88aa0();
    FUN_0089ab50();
    _uStack00000038 = (int *)CONCAT13(1,uStack00000038);
  }
  else {
    FUN_0089ab50();
    _uStack00000038 = (int *)((uint)_uStack00000038 & 0xffffff);
  }
  if (0xf < in_stack_00000034) {
    uVar4 = in_stack_00000034 + 1;
    uVar3 = in_stack_00000020;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(in_stack_00000020 - 4);
      uVar4 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  FUN_00d88aa0();
  ExceptionList = pvStack_10;
  return (uint)_uStack00000038 >> 0x18;
}



/* FUNCTION 14130 ; VA 0x00898aa0 ; FUN_00898aa0 */

void __thiscall FUN_00898aa0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  undefined auStack_1ac [4];
  int *piStack_1a8;
  undefined auStack_124 [4];
  int *piStack_120;
  undefined auStack_9c [4];
  int *piStack_98;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb14b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00899aa0(&param_2);
  uStack_8._0_1_ = 1;
  FUN_00899aa0(auStack_1ac);
  uStack_8._0_1_ = 2;
  cVar4 = FUN_00585a40(auStack_9c);
  if (cVar4 == '\0') {
    FUN_00899aa0(auStack_9c);
    uStack_8._0_1_ = 3;
    iStack_14 = FUN_01674e20(0x88);
    uStack_8._0_1_ = 4;
    if (iStack_14 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00899aa0(auStack_124);
    }
    param_1[2] = uVar5;
    FUN_0089b470();
    FUN_0089b470();
    if (piStack_120 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_120[2] + -1;
      piStack_120[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_120 + 4))();
      }
    }
    FUN_0089b470();
    FUN_0089b470();
    if (piStack_98 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_98[2] + -1;
      piStack_98[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_98 + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    FUN_0089b470();
    FUN_0089b470();
    if (piStack_98 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_98[2] + -1;
      piStack_98[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_98 + 4))();
      }
    }
    bVar3 = false;
  }
  FUN_0089b470();
  FUN_0089b470();
  if (piStack_1a8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1a8[2] + -1;
    piStack_1a8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1a8 + 4))();
    }
  }
  ppuVar6 = &PTR_FUN_0191e880;
  if (!bVar3) {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  FUN_0089b470();
  FUN_0089b470();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14131 ; VA 0x00898c50 ; FUN_00898c50 */

void FUN_00898c50(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb168;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00898d1a:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00898cfa;
      }
      else {
LAB_00898cfa:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0089bae0();
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00898d1a;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00898d1a;
      if (iStack_60 != 0) goto LAB_00898d94;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00898d94:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 14132 ; VA 0x00898da4 ; Catch_All@00898da4 */

void Catch_All_00898da4(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14133 ; VA 0x00898dc0 ; FUN_00898dc0 */

undefined4 * __thiscall FUN_00898dc0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_0089f8b0;
    puVar3[3] = FUN_0068b170;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = 0;
    puVar3[7] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[6] = *param_3;
    puVar3[7] = param_3[1];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14134 ; VA 0x00898ea0 ; FUN_00898ea0 */

undefined4 * __thiscall FUN_00898ea0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_0089fb30;
    puVar3[3] = FUN_0068b170;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = 0;
    puVar3[7] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[6] = *param_3;
    puVar3[7] = param_3[1];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14135 ; VA 0x00898f80 ; FUN_00898f80 */

undefined4 * FUN_00898f80(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb1b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00d11090();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00d11a40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_008986c0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14136 ; VA 0x00899040 ; FUN_00899040 */

int FUN_00899040(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb1c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01eb18c4,&LAB_0075d250);
  uVar2 = FUN_0075d470();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00d11170();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00898f80(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01eb18c4,&LAB_0075d250);
      uVar2 = FUN_0075d470();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 14137 ; VA 0x008991d0 ; FUN_008991d0 */

undefined4 FUN_008991d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00899040();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 14138 ; VA 0x00899230 ; FUN_00899230 */

undefined4 FUN_00899230(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_005cf2a0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 14139 ; VA 0x00899290 ; FUN_00899290 */

int __fastcall FUN_00899290(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00e70750();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 14140 ; VA 0x008992d0 ; FUN_008992d0 */

void __thiscall FUN_008992d0(int param_1,undefined4 *param_2,uint param_3,undefined4 param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar4 = param_3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (puVar2 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar2;
    }
    if (piVar5 != (int *)0x0) {
      do {
        if (param_3 == piVar5[1]) {
          cVar3 = FUN_00558b30(param_4,piVar5 + 2);
          if (cVar3 != '\0') break;
        }
        else if ((uint)piVar5[1] % uVar1 != uVar4) {
          *param_2 = 0;
          return;
        }
        piVar5 = (int *)*piVar5;
        if (piVar5 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar5;
  return;
}



/* FUNCTION 14141 ; VA 0x00899370 ; FUN_00899370 */

int * __thiscall FUN_00899370(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cd20();
  if (iVar4 != iVar1) {
    puVar2 = (undefined4 *)param_1[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_1 + 2,auStack_d8);
      puVar2 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088a2c0();
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    uStack_8 = 1;
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)puVar2[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = *param_1;
  iVar1 = FUN_0088cd20();
  if (iVar4 == iVar1) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar4 = piVar3[1];
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = piVar3[1];
    }
    *param_2 = *piVar3;
    param_2[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14142 ; VA 0x008994a0 ; FUN_008994a0 */

undefined4 __thiscall FUN_008994a0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cf00();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = thunk_FUN_0088c0c0();
    FUN_0054ef60(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088cf00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14143 ; VA 0x008995a0 ; thunk_FUN_008a7680 */

undefined * thunk_FUN_008a7680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5dc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf84c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf84c);
    if (DAT_01edf84c == -1) {
      uStack_8 = 0;
      FUN_008e7070();
      FUN_016f3654(&LAB_018812b0);
      FUN_016f37bf(&DAT_01edf84c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf7e8;
}



/* FUNCTION 14144 ; VA 0x008995b0 ; FUN_008995b0 */

void __thiscall FUN_008995b0(int param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  bool bVar9;
  uint uStack_c;
  uint uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  iVar3 = param_1;
  if (param_1 == -0xc) {
    iVar3 = 0;
  }
  uVar4 = *(int *)(iVar3 + 0x28) + 1;
  if (*(uint *)(param_1 + 0x24) < uVar4) {
    uVar6 = 0xffffffff;
    if ((float)(((double)(int)uVar4 + (double)(&DAT_018c0d90)[-((int)uVar4 >> 0x1f)]) /
                (double)*(float *)(param_1 + 0x20) + DAT_018c0d60) < DAT_018c0d80) {
      uVar6 = FUN_016f3cd0();
    }
    FUN_008a7870(uVar6,param_3);
  }
  uVar6 = FUN_00563b90(param_3,*(undefined4 *)(param_1 + 0x10));
  iVar5 = FUN_008a4250(uVar6);
  piVar1 = (int *)(*(int *)(param_1 + 0x1c) + iVar5 * 4);
  piVar7 = (int *)*piVar1;
  while (piVar7 != (int *)0x0) {
    uVar4 = -(uint)(piVar7 != (int *)0x0) & (uint)(piVar7 + -8);
    cVar2 = FUN_00558b30(param_3,uVar4);
    if (cVar2 != '\0') goto LAB_008996e0;
    piVar8 = piVar7 + 1;
    bVar9 = *(int **)*piVar8 == piVar7;
    piVar7 = (int *)0x0;
    if (bVar9) {
      piVar7 = (int *)*piVar8;
    }
  }
  uVar4 = FUN_008a31c0(param_3,&uStack_8,param_4);
  uStack_c = uStack_8;
  if (uVar4 == uStack_8) {
    piVar8 = (int *)(-(uint)(*(int *)(iVar3 + 4) != 0) & *(int *)(iVar3 + 4) + 0x20U);
    piVar7 = (int *)(-(uint)(uStack_8 != 0) & uStack_8 + 0x20);
    if ((int *)*piVar1 == (int *)0x0) {
      iVar3 = *piVar8;
      *piVar7 = iVar3;
      piVar7[1] = *(int *)(*piVar8 + 4);
      *(int **)(iVar3 + 4) = piVar1;
      *piVar1 = (int)piVar7;
      *piVar8 = (int)piVar7;
    }
    else {
      *piVar7 = *(int *)*piVar1;
      piVar7[1] = *piVar1;
      *piVar1 = (int)piVar7;
      *(int **)piVar7[1] = piVar7;
    }
  }
LAB_008996e0:
  *param_2 = uVar4;
  if (uVar4 == uStack_c) {
    *(undefined *)(param_2 + 1) = 1;
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14145 ; VA 0x00899710 ; FUN_00899710 */

void __thiscall FUN_00899710(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar2 != (undefined4 *)0x0) {
    puVar2[1] = 1;
    puVar2[2] = 1;
    *puVar2 = std::
              _Ref_count_obj<class_RBX::Lua::EventSignalWrapper<void___cdecl(void),class_rbx::signal<void___cdecl(void)>_>_>
              ::vftable;
    puVar2[3] = RBX::Lua::
                EventSignalWrapper<void___cdecl(void),class_rbx::signal<void___cdecl(void)>_>::
                vftable;
    puVar2[4] = 0;
    puVar2[5] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar2[4] = *param_3;
    puVar2[5] = param_3[1];
    *param_2 = (int)(puVar2 + 3);
    param_2[1] = (int)puVar2;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 14146 ; VA 0x00899790 ; FUN_00899790 */

void __thiscall FUN_00899790(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x10,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_rbx::signal<void___cdecl(void)>_>::vftable;
    puVar1[3] = 0;
    puVar1[3] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 14147 ; VA 0x008997f0 ; FUN_008997f0 */

undefined4 * FUN_008997f0(undefined4 *param_1,int *param_2,int *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb1e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_1c = param_3;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_0071ea10(&piStack_20,&stack0x00000010);
  if (param_2 != param_3) {
    piStack_18 = (int *)(*piVar5 + 0x18);
    do {
      cVar4 = FUN_00d88e00(piStack_18);
      if (cVar4 != '\0') break;
      param_2 = param_2 + 0x10;
    } while (param_2 != param_3);
    if ((param_2 != param_3) && (piStack_18 = param_2 + 0x10, piStack_18 != piStack_1c)) {
      piStack_14 = param_2 + 0xe;
      piVar5 = param_2 + 0x1e;
      do {
        cVar4 = FUN_00d88e00(&stack0x00000028);
        if (cVar4 == '\0') {
          if (param_2 != piStack_18) {
            uVar1 = piStack_14[-9];
            if (0xf < uVar1) {
              iVar2 = *param_2;
              uVar7 = uVar1 + 1;
              iVar6 = iVar2;
              if (0xfff < uVar7) {
                iVar6 = *(int *)(iVar2 + -4);
                uVar7 = uVar1 + 0x24;
                if (0x1f < (iVar2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(iVar6,uVar7);
            }
            piStack_14[-10] = 0;
            piStack_14[-9] = 0xf;
            *(undefined *)param_2 = 0;
            iVar2 = piStack_18[1];
            iVar6 = piStack_18[2];
            iVar3 = piStack_18[3];
            *param_2 = *piStack_18;
            param_2[1] = iVar2;
            param_2[2] = iVar6;
            param_2[3] = iVar3;
            iVar2 = piStack_18[5];
            param_2[4] = piStack_18[4];
            param_2[5] = iVar2;
            piVar5[-10] = 0;
            piVar5[-9] = 0xf;
            *(undefined *)piStack_18 = 0;
          }
          FUN_00d88cd0(piVar5 + -8);
          iVar2 = piVar5[-1];
          iVar6 = *piVar5;
          piVar5[-1] = 0;
          *piVar5 = 0;
          piStack_14[-1] = iVar2;
          piStack_20 = (int *)*piStack_14;
          *piStack_14 = iVar6;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_20[2] + -1;
            piStack_20[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
          param_2 = param_2 + 0x10;
          piStack_14[1] = piVar5[1];
          piStack_14 = piStack_14 + 0x10;
        }
        piVar5 = piVar5 + 0x10;
        piStack_18 = piStack_18 + 0x10;
      } while (piStack_18 != piStack_1c);
    }
  }
  *param_1 = param_2;
  FUN_0089b470();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14148 ; VA 0x008999a0 ; FUN_008999a0 */

void * __thiscall FUN_008999a0(int param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  piVar4 = *(int **)(param_1 + 0x2c);
  pvVar2 = ExceptionList;
  if (piVar4 != (int *)0x0) {
    piVar3 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(param_1 + 0x30);
      piVar4 = *(int **)(param_1 + 0x2c);
    }
    iVar1 = piVar4[1];
    iVar5 = *piVar4;
    uStack_8 = 0;
    pvVar2 = pvStack_10;
    for (; iVar5 != iVar1; iVar5 = iVar5 + 8) {
      (*(code *)*param_2)(param_2[1],iVar5);
      pvVar2 = (void *)FUN_008999a0(param_2);
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      pvVar2 = (void *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar2 = (void *)(**(code **)*piVar3)();
        LOCK();
        piVar4 = piVar3 + 2;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar2 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar2;
}



/* FUNCTION 14149 ; VA 0x00899a50 ; FUN_00899a50 */

undefined4 __thiscall FUN_00899a50(undefined4 param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb208;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00d88710(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0x1c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14150 ; VA 0x00899aa0 ; FUN_00899aa0 */

undefined4 * __thiscall FUN_00899aa0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb243;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  uStack_8._0_1_ = 1;
  FUN_00d88710(param_2 + 8);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  if (param_2[0x10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x10] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x12);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00d88710(param_2 + 0x18);
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  if (param_2[0x20] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x20] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x1f] = param_2[0x1f];
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14151 ; VA 0x00899ba0 ; FUN_00899ba0 */

undefined4 * __thiscall
FUN_00899ba0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb29b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00897b90();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Instance,struct_RBX::Lua::EventInstance___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088caa0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14152 ; VA 0x00899d20 ; FUN_00899d20 */

undefined4 * __thiscall
FUN_00899d20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb29b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00897b90();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cdc0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14153 ; VA 0x00899ea0 ; FUN_00899ea0 */

undefined4 * __thiscall
FUN_00899ea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined param_7,undefined4 param_8,
            undefined8 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb2ce;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb790(uVar1,param_4,param_8,param_9,param_10);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,bool),2>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined *)FUN_01674e20(1);
  if (puVar2 == (undefined *)0x0) {
    puVar2 = (undefined *)0x0;
  }
  else {
    *puVar2 = param_7;
  }
  param_1[0x11] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0089ede0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14154 ; VA 0x00899f50 ; FUN_00899f50 */

undefined4 * __thiscall
FUN_00899f50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb32b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00897b90();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Instance,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_006874f0(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088cdc0();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14155 ; VA 0x0089a0b0 ; FUN_0089a0b0 */

undefined4 * __thiscall
FUN_0089a0b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb29b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00897b90();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Instance,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
             ::vftable;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088daf0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  param_1[0x12] = param_2;
  param_1[0x13] = param_3;
  *param_1 = RBX::Reflection::
             CustomBoundFuncDesc<class_RBX::Instance,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
             ::vftable;
  param_1[0xd] = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14156 ; VA 0x0089a250 ; FUN_0089a250 */

undefined4 *
FUN_0089a250(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb361;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb970(uVar1,param_3,param_5,param_6,param_7);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  iStack_8 = 0;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
                ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687810(auStack_f8,&uStack_20,param_5);
  iStack_8._0_1_ = 2;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = uStack_20;
    puStack_14[0xb] = uStack_1c;
    puStack_14[0xc] = uStack_18;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 14157 ; VA 0x0089a380 ; FUN_0089a380 */

/* WARNING: Removing unreachable block (ram,0x0089a413) */

int * __thiscall
FUN_0089a380(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb38b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088cb40();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14158 ; VA 0x0089a430 ; FUN_0089a430 */

/* WARNING: Removing unreachable block (ram,0x0089a4c3) */

int * __thiscall
FUN_0089a430(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb3bb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088cf00();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14159 ; VA 0x0089a4e0 ; FUN_0089a4e0 */

/* WARNING: Removing unreachable block (ram,0x0089a573) */

int * __thiscall
FUN_0089a4e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb3eb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088da50();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14160 ; VA 0x0089a590 ; FUN_0089a590 */

undefined4 * __thiscall
FUN_0089a590(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,undefined param_8,undefined4 param_9)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  param_1[1] = param_2;
  param_1[2] = param_3;
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  param_1[3] = param_4;
  param_1[4] = param_5;
  param_1[5] = param_6;
  param_1[6] = param_7;
  *(undefined *)(param_1 + 7) = param_8;
  param_1[8] = param_9;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 14161 ; VA 0x0089a650 ; FUN_0089a650 */

undefined4 * __thiscall FUN_0089a650(undefined4 *param_1,char *param_2)

{
  char cVar1;
  undefined uVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb470;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008922b0();
  puStack_18 = param_1 + 5;
  *puStack_18 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_009c9030(param_1 + 6);
  LOCK();
  DAT_01ea851c = DAT_01ea851c + 1;
  UNLOCK();
  uStack_8._0_1_ = 3;
  *param_1 = RBX::Instance::vftable;
  *(undefined4 *)((int)param_1 + 0x21) = 1;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcVar4 = param_2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
  uStack_8._0_1_ = 4;
  FUN_008a3220(param_1 + 10,auStack_30);
  uStack_8._0_1_ = 3;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0x10] = param_1[0x10] & 0xe0000000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  uVar3 = FUN_00897b90();
  param_1[3] = uVar3;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14162 ; VA 0x0089a7a0 ; FUN_0089a7a0 */

undefined4 * __fastcall FUN_0089a7a0(undefined4 *param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb470;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008922b0();
  puStack_18 = param_1 + 5;
  *puStack_18 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_009c9030(param_1 + 6);
  LOCK();
  DAT_01ea851c = DAT_01ea851c + 1;
  UNLOCK();
  uStack_8._0_1_ = 3;
  *param_1 = RBX::Instance::vftable;
  *(undefined4 *)((int)param_1 + 0x21) = 1;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0(&DAT_0191cd78,8);
  uStack_8._0_1_ = 4;
  FUN_008a3220(param_1 + 10,auStack_30);
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0x10] = param_1[0x10] & 0xe0000000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  uVar2 = FUN_00897b90();
  param_1[3] = uVar2;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14163 ; VA 0x0089a8e0 ; FUN_0089a8e0 */

undefined4 * __fastcall FUN_0089a8e0(undefined4 *param_1)

{
  undefined uVar1;
  undefined **ppuVar2;
  undefined *puVar3;
  uint uVar4;
  undefined **ppuVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb4f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::OnDemandInstance::vftable;
  param_1[2] = 0;
  uStack_8 = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  *(undefined *)(param_1 + 9) = 1;
  *(undefined *)(param_1 + 10) = 0;
  puStack_14 = (undefined4 *)0xb;
  puStack_18 = param_1;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar5 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar2;
  }
  param_1[0xb] = *ppuVar5;
  param_1[0xc] = 0;
  param_1[0xd] = 0x3f800000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  *(undefined *)(param_1 + 0x10) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar5 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar2;
  }
  param_1[0x11] = *ppuVar5;
  param_1[0x12] = 0;
  param_1[0x13] = 0x3f800000;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  puStack_14 = param_1 + 0x16;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8._0_1_ = 9;
  FUN_008a3220(puStack_14,auStack_30);
  uStack_8._0_1_ = 8;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  puVar3 = (undefined *)FUN_01674e20(0x18);
  if (puVar3 == (undefined *)0x0) {
    puVar3 = (undefined *)0x0;
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puStack_14 = (undefined4 *)0xb;
    ppuVar2 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
    ppuVar5 = ppuVar2 + -1;
    if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar5 = ppuVar2;
    }
    *(undefined **)(puVar3 + 4) = *ppuVar5;
    *(undefined4 *)(puVar3 + 8) = 0;
    *(undefined4 *)(puVar3 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar3 + 0x10) = 0;
    *(undefined4 *)(puVar3 + 0x14) = 0;
  }
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  FUN_005c1af0(puVar3,puStack_18);
  param_1[0x1a] = 0xffffffff;
  param_1[0x1b] = 0xffffffff;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14164 ; VA 0x0089ab00 ; FUN_0089ab00 */

undefined4 * __fastcall FUN_0089ab00(undefined4 *param_1)

{
  param_1[1] = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  *param_1 = RBX::Lua::WeakThreadRef::vftable;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}



/* FUNCTION 14165 ; VA 0x0089ab40 ; thunk_FUN_0089b470 */

void __fastcall thunk_FUN_0089b470(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)param_1[0xe];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00d88aa0();
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar3 = *param_1;
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 14166 ; VA 0x0089ab50 ; FUN_0089ab50 */

void __fastcall FUN_0089ab50(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x30);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x1c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0xf;
  *(undefined *)(param_1 + 0x1c) = 0;
  FUN_00d88aa0();
  return;
}



/* FUNCTION 14167 ; VA 0x0089abb0 ; FUN_0089abb0 */

int __fastcall FUN_0089abb0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0089b470();
  iVar4 = FUN_0089b470();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0089abd7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 14168 ; VA 0x0089abe0 ; FUN_0089abe0 */

void FUN_0089abe0(void)

{
  LOCK();
  DAT_01ea851c = DAT_01ea851c + -1;
  UNLOCK();
  return;
}



/* FUNCTION 14169 ; VA 0x0089abf0 ; FUN_0089abf0 */

void FUN_0089abf0(void)

{
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 14170 ; VA 0x0089ac00 ; FUN_0089ac00 */

void FUN_0089ac00(void)

{
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 14171 ; VA 0x0089ac10 ; FUN_0089ac10 */

void __fastcall FUN_0089ac10(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  if (iVar5 == 0) goto LAB_0089acf5;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(iVar5 + 0x1c);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  if (*(int *)(iVar5 + 0xc) != 0) {
    uVar4 = FUN_009c91f0(param_1 + 1);
    uVar7 = uVar4 % *(uint *)(iVar5 + 8);
    piVar1 = *(int **)(uVar7 * 4 + *(int *)(iVar5 + 0x18));
    if (piVar1 != (int *)0x0) {
      iVar3 = *piVar1;
      while( true ) {
        if ((iVar3 == 0) || (*(uint *)(iVar3 + 4) % *(uint *)(iVar5 + 8) != uVar7))
        goto LAB_0089acc4;
        if ((*(uint *)(iVar3 + 4) == uVar4) && (cVar2 = FUN_009c8f50(iVar3 + 8), cVar2 != '\0'))
        break;
        piVar1 = (int *)*piVar1;
        iVar3 = *piVar1;
      }
      FUN_0061ad00(piVar1,*(undefined4 *)*piVar1);
      if (*piVar1 != 0) {
        uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(iVar5 + 8);
        if (uVar7 == uVar4) goto LAB_0089acc4;
        *(int **)(*(int *)(iVar5 + 0x18) + uVar4 * 4) = piVar1;
      }
      puVar6 = (undefined4 *)(*(int *)(iVar5 + 0x18) + uVar7 * 4);
      if ((int *)*puVar6 == piVar1) {
        *puVar6 = 0;
      }
    }
  }
LAB_0089acc4:
  uStack_8 = 0;
  iVar5 = FUN_016deec8(iVar5 + 0x1c);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  *param_1 = 0;
  FUN_00611620();
LAB_0089acf5:
  FUN_00611620();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14172 ; VA 0x0089ad50 ; FUN_0089ad50 */

void __fastcall FUN_0089ad50(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_0089c7e0(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x14);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14173 ; VA 0x0089adf0 ; FUN_0089adf0 */

void __fastcall FUN_0089adf0(undefined4 *param_1)

{
  FUN_01674ea0(*param_1,0x1c);
  return;
}



/* FUNCTION 14174 ; VA 0x0089ae00 ; FUN_0089ae00 */

void __fastcall FUN_0089ae00(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x40) {
    FUN_0089b470();
  }
  return;
}



/* FUNCTION 14175 ; VA 0x0089ae30 ; FUN_0089ae30 */

void __fastcall FUN_0089ae30(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*(int *)(param_1 + 4) != 0) {
    iVar1 = *(int *)(param_1 + 8);
    uVar3 = *(int *)(param_1 + 4) * 4;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 14176 ; VA 0x0089ae70 ; FUN_0089ae70 */

void __fastcall FUN_0089ae70(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  LOCK();
  iVar1 = *(int *)(*param_1 + 0x18) + -1;
  ExceptionList = &pvStack_10;
  *(int *)(*param_1 + 0x18) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_008a3020();
    uVar2 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar3 = FUN_0089d8f0(param_1);
    if (cVar3 != '\0') {
      FUN_0089fdd0(*param_1);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14177 ; VA 0x0089aef0 ; FUN_0089aef0 */

void __fastcall FUN_0089aef0(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar2,0x10);
    }
  }
  return;
}



/* FUNCTION 14178 ; VA 0x0089af20 ; FUN_0089af20 */

void __fastcall FUN_0089af20(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0089c760(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14179 ; VA 0x0089af80 ; FUN_0089af80 */

void __fastcall FUN_0089af80(uint param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  
  iVar1 = *(int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 4);
  puVar8 = (undefined4 *)(-(uint)(iVar1 != 0) & iVar1 + 0x20U);
  puVar3 = (undefined4 *)*puVar8;
  while (puVar3 != puVar8) {
    puVar2 = (undefined4 *)*puVar3;
    piVar7 = puVar3 + -8;
    uVar6 = puVar3[-3];
    if (0xf < uVar6) {
      iVar1 = *piVar7;
      uVar5 = uVar6 + 1;
      iVar4 = iVar1;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar1 + -4);
        uVar5 = uVar6 + 0x24;
        if (0x1f < (iVar1 - iVar4) - 4U) goto LAB_0089b045;
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    puVar3[-4] = 0;
    puVar3[-3] = 0xf;
    *(undefined *)piVar7 = 0;
    FUN_01674ea0(piVar7,0x28);
    puVar3 = puVar2;
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar1 = *(int *)(param_1 + 0x1c);
    uVar6 = *(int *)(param_1 + 0x18) * 4;
    iVar4 = iVar1;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) {
LAB_0089b045:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x28);
  return;
}



/* FUNCTION 14180 ; VA 0x0089b050 ; FUN_0089b050 */

void __fastcall FUN_0089b050(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_0089c7e0(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x14);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14181 ; VA 0x0089b060 ; FUN_0089b060 */

void __fastcall FUN_0089b060(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14182 ; VA 0x0089b0c0 ; FUN_0089b0c0 */

void __fastcall FUN_0089b0c0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0089b470();
        iVar2 = iVar2 + 0x40;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xffffffc0;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 14183 ; VA 0x0089b130 ; FUN_0089b130 */

void __fastcall FUN_0089b130(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[4];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  return;
}



/* FUNCTION 14184 ; VA 0x0089b190 ; FUN_0089b190 */

void __fastcall FUN_0089b190(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  return;
}



/* FUNCTION 14185 ; VA 0x0089b1f0 ; FUN_0089b1f0 */

int __fastcall FUN_0089b1f0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_EAX;
  int iVar4;
  
  piVar3 = (int *)param_1[2];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
    *param_1 = RBX::Instance::ICombinedSignalData::vftable;
    return iVar4;
  }
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  return in_EAX;
}



/* FUNCTION 14186 ; VA 0x0089b230 ; FUN_0089b230 */

void __fastcall FUN_0089b230(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Instance::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  if ((undefined4 *)param_1[0x11] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x11])(1);
  }
  piVar1 = (int *)param_1[0xc];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 0;
  LOCK();
  piVar1 = (int *)(param_1[10] + 0x18);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1) {
    FUN_008a3020();
    uVar3 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar4 = FUN_0089d8f0(param_1 + 10);
    if (cVar4 != '\0') {
      FUN_0089fdd0(param_1[10]);
    }
    LeaveCriticalSection(uVar3);
  }
  LOCK();
  DAT_01ea851c = DAT_01ea851c + -1;
  UNLOCK();
  FUN_0089ac10();
  FUN_00892570();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14187 ; VA 0x0089b310 ; FUN_0089b310 */

void __fastcall FUN_0089b310(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::OnDemandInstance::vftable;
  FUN_0089b0c0();
  piVar1 = (int *)param_1[0x18];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 0;
  LOCK();
  piVar1 = (int *)(param_1[0x16] + 0x18);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1) {
    FUN_008a3020();
    uVar3 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar4 = FUN_0089d8f0(param_1 + 0x16);
    if (cVar4 != '\0') {
      FUN_0089fdd0(param_1[0x16]);
    }
    LeaveCriticalSection(uVar3);
  }
  FUN_0075ddb0();
  FUN_006123a0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14188 ; VA 0x0089b410 ; thunk_FUN_009ca940 */

void __fastcall thunk_FUN_009ca940(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::PropertyDescriptor::vftable;
  FUN_008925b0();
  return;
}



/* FUNCTION 14189 ; VA 0x0089b420 ; FUN_0089b420 */

void __fastcall FUN_0089b420(int *param_1)

{
  *(undefined *)(*param_1 + 0x23) = 0;
  return;
}



/* FUNCTION 14190 ; VA 0x0089b430 ; FUN_0089b430 */

void __fastcall FUN_0089b430(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 14191 ; VA 0x0089b470 ; FUN_0089b470 */

void __fastcall FUN_0089b470(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)param_1[0xe];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00d88aa0();
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar3 = *param_1;
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 14192 ; VA 0x0089b4e0 ; FUN_0089b4e0 */

undefined4 FUN_0089b4e0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb508;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3320(&iStack_14,param_1);
  uStack_8 = 0;
  uVar4 = FUN_0089b580(&iStack_14);
  uStack_8 = 1;
  LOCK();
  iVar1 = *(int *)(iStack_14 + 0x18) + -1;
  *(int *)(iStack_14 + 0x18) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_008a3020();
    uVar2 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar3 = FUN_0089d8f0(&iStack_14);
    if (cVar3 != '\0') {
      FUN_0089fdd0(iStack_14);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 14193 ; VA 0x0089b580 ; FUN_0089b580 */

int * __thiscall FUN_0089b580(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x18);
  ExceptionList = &pvStack_10;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_2 = (int *)*param_1;
  *param_1 = iVar2;
  uStack_8 = 0;
  LOCK();
  iVar2 = *(int *)((int)param_2 + 0x18) + -1;
  *(int *)((int)param_2 + 0x18) = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    FUN_008a3020();
    uVar3 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar4 = FUN_0089d8f0(&param_2);
    if (cVar4 != '\0') {
      FUN_0089fdd0(param_2);
    }
    LeaveCriticalSection(uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14194 ; VA 0x0089b610 ; FUN_0089b610 */

undefined4 FUN_0089b610(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb508;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3420(&iStack_14,param_1);
  uStack_8 = 0;
  uVar4 = FUN_0089b580(&iStack_14);
  uStack_8 = 1;
  LOCK();
  iVar1 = *(int *)(iStack_14 + 0x18) + -1;
  *(int *)(iStack_14 + 0x18) = iVar1;
  UNLOCK();
  if (iVar1 == 0) {
    FUN_008a3020();
    uVar2 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar3 = FUN_0089d8f0(&iStack_14);
    if (cVar3 != '\0') {
      FUN_0089fdd0(iStack_14);
    }
    LeaveCriticalSection(uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 14195 ; VA 0x0089b6b0 ; FUN_0089b6b0 */

uint __thiscall FUN_0089b6b0(float *param_1,float *param_2)

{
  float *pfVar1;
  float fVar2;
  undefined4 in_EAX;
  float fVar3;
  
  fVar2 = *param_1;
  fVar3 = (float)((uint)CONCAT21((short)((uint)in_EAX >> 0x10),
                                 (fVar2 == *param_2) << 6 | (NAN(fVar2) || NAN(*param_2)) << 2 | 2U
                                 | fVar2 < *param_2) << 8);
  if (((NAN(fVar2) || NAN(*param_2)) != (fVar2 == *param_2)) &&
     (fVar3 = param_1[1], fVar3 == param_2[1])) {
    fVar2 = param_1[2];
    pfVar1 = param_2 + 2;
    fVar3 = (float)((uint)CONCAT21((short)((uint)fVar3 >> 0x10),
                                   (fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U
                                   | fVar2 < *pfVar1) << 8);
    if (((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) &&
       (fVar3 = param_1[3], fVar3 == param_2[3])) {
      return CONCAT31((int3)((uint)fVar3 >> 8),1);
    }
  }
  return (uint)fVar3 & 0xffffff00;
}



/* FUNCTION 14196 ; VA 0x0089b6f0 ; FUN_0089b6f0 */

int * __thiscall FUN_0089b6f0(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb530;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_00563b90(param_2);
  FUN_008992d0(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005c9310(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 14197 ; VA 0x0089b930 ; FUN_0089b930 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_0089b930(byte *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb548;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar7 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00619db0();
    _DAT_0000000c = 0;
    _DAT_00000010 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = uVar4;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar1);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (uint *)0x1;
      uVar4 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar4 = 1;
      }
      iVar5 = FUN_005c9310(uVar4 + uVar2);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar6 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar6;
            *(undefined4 **)*piVar6 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar4 = uVar7 % *(uint *)(param_1 + 4);
    piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    _DAT_00000004 = uVar7;
    if (piVar6 == (int *)0x0) {
      piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar6 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar6;
      _DAT_00000000 = *piVar6;
    }
    else {
      _DAT_00000000 = *piVar6;
      piVar6 = (int *)*puVar8;
    }
    *piVar6 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 14198 ; VA 0x0089bae0 ; FUN_0089bae0 */

void FUN_0089bae0(void)

{
  undefined4 *puVar1;
  
  if (DAT_01d62be8 != '\0') {
    puVar1 = &DAT_01d7a8e8;
    if (0xf < DAT_01d7a8fc) {
      puVar1 = DAT_01d7a8e8;
    }
    FUN_0087c6f0(&DAT_018bee70,"RemotePlayerBackpackAccess",puVar1,0,0,0,3);
    return;
  }
  puVar1 = &DAT_01d7a8e8;
  if (0xf < DAT_01d7a8fc) {
    puVar1 = DAT_01d7a8e8;
  }
  FUN_0087c450(&DAT_018bee70,"RemotePlayerBackpackAccess",puVar1,0,0,0);
  return;
}



/* FUNCTION 14199 ; VA 0x0089bb40 ; FUN_0089bb40 */

void __fastcall FUN_0089bb40(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_7c [20];
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined4 uStack_4c;
  undefined **ppuStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined *puStack_28;
  undefined auStack_24 [4];
  undefined *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bb578;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)0x0;
  piVar5 = (int *)0x0;
  iVar3 = param_1[1];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    piVar6 = (int *)(iVar3 + 4);
    iVar3 = *(int *)(iVar3 + 4);
    ExceptionList = &pvStack_10;
    while (iVar3 != 0) {
      LOCK();
      iVar2 = *piVar6;
      if (iVar3 == iVar2) {
        *piVar6 = iVar3 + 1;
        iVar2 = iVar3;
      }
      UNLOCK();
      if (iVar2 == iVar3) {
        piVar6 = (int *)*param_1;
        piVar5 = (int *)param_1[1];
        goto LAB_0089bb9d;
      }
      iVar3 = *piVar6;
    }
    piVar6 = (int *)0x0;
    piVar5 = (int *)0x0;
  }
LAB_0089bb9d:
  iStack_8 = 0;
  if (piVar6 != (int *)0x0) {
    iVar3 = piVar6[0x11];
    if (iVar3 == 0) {
      uStack_40 = 0x89bbba;
      iVar3 = (**(code **)(*piVar6 + 0x14))();
      puVar4 = (undefined4 *)piVar6[0x11];
      piVar6[0x11] = iVar3;
      if (puVar4 != (undefined4 *)0x0) {
        uStack_40 = 1;
        uStack_44 = 0x89bbca;
        (**(code **)*puVar4)();
      }
      iVar3 = piVar6[0x11];
    }
    uStack_14 = *(undefined4 *)(iVar3 + 0x74);
    puStack_1c = (undefined4 *)(iVar3 + 0x70);
    puStack_20 = auStack_7c;
    uStack_18 = *puStack_1c;
    FUN_0054ef60(param_1 + 0x12);
    iStack_8._0_1_ = 1;
    FUN_00d88710(param_1 + 0x18);
    uVar1 = uStack_14;
    if (param_1[0x20] != 0) {
      LOCK();
      piVar6 = (int *)(param_1[0x20] + 8);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    ppuStack_48 = (undefined **)param_1[0x1f];
    uStack_44 = param_1[0x20];
    uStack_40 = param_1[0x21];
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    puVar4 = (undefined4 *)FUN_008997f0(auStack_24,uStack_18,uStack_14);
    uStack_40 = uVar1;
    uStack_44 = *puVar4;
    ppuStack_48 = &puStack_28;
    uStack_4c = 0x89bc5e;
    FUN_0089ff70();
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      uStack_40 = 0x89bc74;
      (**(code **)*piVar5)();
      LOCK();
      piVar6 = piVar5 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_40 = 0x89bc83;
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  puStack_28 = (undefined *)&uStack_44;
  uStack_44 = 0;
  uStack_40 = 0;
  iStack_8 = 2;
  puStack_64 = param_1 + 8;
  uStack_68 = 0x89bcad;
  FUN_00d88710();
  iStack_8 = 0xffffffff;
  puStack_64 = (undefined4 *)0x89bcb9;
  FUN_008a5470();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14200 ; VA 0x0089bce0 ; FUN_0089bce0 */

/* WARNING: Removing unreachable block (ram,0x0089bd32) */
/* WARNING: Removing unreachable block (ram,0x0089bd42) */
/* WARNING: Removing unreachable block (ram,0x0089bd48) */

void * __thiscall
FUN_0089bce0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb5b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14201 ; VA 0x0089bde7 ; Catch@0089bde7 */

undefined * Catch_0089bde7(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0089bdf8;
}



/* FUNCTION 14202 ; VA 0x0089be10 ; FUN_0089be10 */

/* WARNING: Removing unreachable block (ram,0x0089be62) */
/* WARNING: Removing unreachable block (ram,0x0089be72) */
/* WARNING: Removing unreachable block (ram,0x0089be78) */

void * __thiscall FUN_0089be10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb5d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14203 ; VA 0x0089bee3 ; Catch@0089bee3 */

undefined * Catch_0089bee3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0089bef4;
}



/* FUNCTION 14204 ; VA 0x0089bf10 ; FUN_0089bf10 */

/* WARNING: Removing unreachable block (ram,0x0089bf62) */
/* WARNING: Removing unreachable block (ram,0x0089bf72) */
/* WARNING: Removing unreachable block (ram,0x0089bf78) */

void * __thiscall FUN_0089bf10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bb608;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 14205 ; VA 0x0089bfe6 ; Catch@0089bfe6 */

undefined * Catch_0089bfe6(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0089bff7;
}



/* FUNCTION 14206 ; VA 0x0089c010 ; FUN_0089c010 */

undefined4 __thiscall FUN_0089c010(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14207 ; VA 0x0089c040 ; FUN_0089c040 */

int __thiscall FUN_0089c040(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14208 ; VA 0x0089c080 ; FUN_0089c080 */

int __thiscall FUN_0089c080(int param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x44);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14209 ; VA 0x0089c100 ; FUN_0089c100 */

int __thiscall FUN_0089c100(int param_1,byte param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14210 ; VA 0x0089c170 ; FUN_0089c170 */

undefined4 __thiscall FUN_0089c170(undefined4 param_1,byte param_2)

{
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 14211 ; VA 0x0089c1a0 ; FUN_0089c1a0 */

int __thiscall FUN_0089c1a0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),8);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 14212 ; VA 0x0089c1e0 ; FUN_0089c1e0 */

undefined4 __thiscall FUN_0089c1e0(undefined4 param_1,byte param_2)

{
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 14213 ; VA 0x0089c210 ; FUN_0089c210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0089c210(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Instance::SaveFilter_DEPRECATED>::vftable;
  _DAT_01edf7e0 = _DAT_01edf7e0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 14214 ; VA 0x0089c240 ; FUN_0089c240 */

undefined4 * __thiscall FUN_0089c240(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::
             TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 14215 ; VA 0x0089c270 ; FUN_0089c270 */

undefined4 * __thiscall FUN_0089c270(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<int>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 14216 ; VA 0x0089c2a0 ; FUN_0089c2a0 */

undefined4 * __thiscall FUN_0089c2a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 14217 ; VA 0x0089c2d0 ; FUN_0089c2d0 */

undefined4 * __thiscall FUN_0089c2d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Instance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 14218 ; VA 0x0089c300 ; FUN_0089c300 */

undefined4 * __thiscall FUN_0089c300(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<__int64>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 14219 ; VA 0x0089c330 ; FUN_0089c330 */

int __thiscall FUN_0089c330(int param_1,byte param_2)

{
  if (*(undefined4 **)(param_1 + 0x38) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x38))(1);
  }
  FUN_009ca940();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3c);
  }
  return param_1;
}



/* FUNCTION 14220 ; VA 0x0089c370 ; FUN_0089c370 */

undefined4 __thiscall FUN_0089c370(undefined4 param_1,byte param_2)

{
  FUN_0089b130();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 14221 ; VA 0x0089c3a0 ; FUN_0089c3a0 */

undefined4 * __thiscall FUN_0089c3a0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[6];
  if (0xf < uVar1) {
    iVar2 = param_1[1];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[5] = 0;
  param_1[6] = 0xf;
  *(undefined *)(param_1 + 1) = 0;
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 14222 ; VA 0x0089c410 ; FUN_0089c410 */

undefined4 * __thiscall FUN_0089c410(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 14223 ; VA 0x0089c460 ; FUN_0089c460 */

undefined4 * __thiscall FUN_0089c460(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Instance*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14224 ; VA 0x0089c490 ; FUN_0089c490 */

undefined4 * __thiscall FUN_0089c490(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14225 ; VA 0x0089c4c0 ; FUN_0089c4c0 */

undefined4 * __thiscall FUN_0089c4c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<__int64>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 14226 ; VA 0x0089c4f0 ; FUN_0089c4f0 */

undefined4 * __thiscall FUN_0089c4f0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::OnDemandInstance::vftable;
  FUN_0089b0c0();
  piVar1 = (int *)param_1[0x18];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 0;
  LOCK();
  piVar1 = (int *)(param_1[0x16] + 0x18);
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1) {
    FUN_008a3020();
    uVar3 = DAT_01edf5c0;
    EnterCriticalSection(DAT_01edf5c0);
    cVar4 = FUN_0089d8f0(param_1 + 0x16);
    if (cVar4 != '\0') {
      FUN_0089fdd0(param_1[0x16]);
    }
    LeaveCriticalSection(uVar3);
  }
  FUN_0075ddb0();
  FUN_006123a0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14227 ; VA 0x0089c600 ; FUN_0089c600 */

undefined4 __thiscall FUN_0089c600(undefined4 param_1,byte param_2)

{
  FUN_00d88aa0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 14228 ; VA 0x0089c660 ; FUN_0089c660 */

void FUN_0089c660(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x14);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 14229 ; VA 0x0089c680 ; FUN_0089c680 */

void __fastcall FUN_0089c680(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 14230 ; VA 0x0089c6a0 ; FUN_0089c6a0 */

void __fastcall FUN_0089c6a0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x14);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0089c6b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 14231 ; VA 0x0089c6c0 ; FUN_0089c6c0 */

void FUN_0089c6c0(void)

{
  FUN_016790b0();
  return;
}



/* FUNCTION 14232 ; VA 0x0089c6d0 ; FUN_0089c6d0 */

void __fastcall FUN_0089c6d0(int param_1)

{
  FUN_005703b0(*(undefined4 *)(param_1 + 0xc));
  return;
}



/* FUNCTION 14233 ; VA 0x0089c6e0 ; FUN_0089c6e0 */

void FUN_0089c6e0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_0089b470();
      param_1 = param_1 + 0x40;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 14234 ; VA 0x0089c710 ; FUN_0089c710 */

void FUN_0089c710(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x1c);
  return;
}



/* FUNCTION 14235 ; VA 0x0089c760 ; FUN_0089c760 */

undefined4 __thiscall FUN_0089c760(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_0089c760(param_2[2]);
    piVar2 = (int *)param_2[6];
    piVar3 = (int *)*param_2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_2,0x1c);
    param_2 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return param_1;
}



/* FUNCTION 14236 ; VA 0x0089c7e0 ; FUN_0089c7e0 */

void FUN_0089c7e0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_0089c7e0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_01674ea0(param_1,0x14);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 14237 ; VA 0x0089c820 ; FUN_0089c820 */

void __fastcall FUN_0089c820(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0089c760(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14238 ; VA 0x0089c880 ; FUN_0089c880 */

undefined4 * FUN_0089c880(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bba40;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar5 = param_1 + 0xe;
    ExceptionList = &pvStack_10;
    do {
      param_3[4] = 0;
      param_3[5] = 0;
      uVar2 = puVar5[-0xd];
      uVar3 = puVar5[-0xc];
      uVar4 = puVar5[-0xb];
      *param_3 = puVar5[-0xe];
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      *(undefined8 *)(param_3 + 4) = *(undefined8 *)(puVar5 + -10);
      puVar5[-10] = 0;
      puVar5[-9] = 0xf;
      *(undefined *)(puVar5 + -0xe) = 0;
      uStack_8 = 1;
      FUN_00d88710(puVar5 + -8);
      param_3[0xd] = 0;
      param_3[0xe] = 0;
      puVar1 = puVar5 + 2;
      param_3[0xd] = puVar5[-1];
      param_3[0xe] = *puVar5;
      puVar5[-1] = 0;
      *puVar5 = 0;
      param_3[0xf] = puVar5[1];
      param_3 = param_3 + 0x10;
      puVar5 = puVar5 + 0x10;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 14239 ; VA 0x0089c960 ; FUN_0089c960 */

undefined4 FUN_0089c960(int *param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  double *pdVar3;
  undefined4 uVar4;
  int iVar5;
  int *piVar6;
  float *pfVar7;
  double *pdVar8;
  int *piVar9;
  float *pfVar10;
  
  iVar1 = *param_1;
  if (*(int *)(iVar1 + 0x1c) != *(int *)(*param_2 + 0x1c)) {
    return 0;
  }
  switch(*(int *)(iVar1 + 0x1c)) {
  case 0:
    return 1;
  case 1:
    iVar5 = FUN_0088daf0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088daf0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) && (*(char *)piVar9 == *(char *)piVar6))
    {
      return 1;
    }
    break;
  case 2:
    iVar5 = FUN_0088c8c0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088c8c0();
    if (iVar1 == iVar5) {
LAB_0089ca6f:
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    goto LAB_0089ca7a;
  case 4:
    iVar5 = FUN_0088c960();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088c960();
    if (iVar1 == iVar5) {
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    if (((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
       ((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7))) {
      return 1;
    }
    break;
  case 5:
    iVar5 = FUN_0088ca00();
    if (iVar1 == iVar5) {
      pdVar8 = (double *)(param_1 + 2);
      if (param_1[1] == 0) {
        pdVar8 = (double *)0x0;
      }
    }
    else {
      pdVar8 = (double *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088ca00();
    if (iVar1 == iVar5) {
      pdVar3 = (double *)(param_2 + 2);
      if (param_2[1] == 0) {
        pdVar3 = (double *)0x0;
      }
    }
    else {
      pdVar3 = (double *)0x0;
    }
    if (((pdVar8 != (double *)0x0) && (pdVar3 != (double *)0x0)) &&
       ((NAN(*pdVar8) || NAN(*pdVar3)) != (*pdVar8 == *pdVar3))) {
      return 1;
    }
    break;
  case 6:
    iVar5 = FUN_0088cb40();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088cb40();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       (cVar2 = FUN_00558b30(piVar9,piVar6), cVar2 != '\0')) {
      return 1;
    }
    break;
  case 10:
    iVar5 = FUN_0088d370();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d370();
    if (iVar1 == iVar5) {
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    if ((((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
        (((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7) &&
         (((NAN(pfVar10[1]) || NAN(pfVar7[1])) != (pfVar10[1] == pfVar7[1]) &&
          ((NAN(pfVar10[2]) || NAN(pfVar7[2])) != (pfVar10[2] == pfVar7[2]))))))) &&
       (((NAN(pfVar10[3]) || NAN(pfVar7[3])) != (pfVar10[3] == pfVar7[3]) &&
        (((NAN(pfVar10[4]) || NAN(pfVar7[4])) != (pfVar10[4] == pfVar7[4]) &&
         ((NAN(pfVar10[5]) || NAN(pfVar7[5])) != (pfVar10[5] == pfVar7[5]))))))) {
      return 1;
    }
    break;
  case 0xb:
    iVar5 = FUN_0088d730();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d730();
    if (iVar1 == iVar5) {
LAB_0089ce25:
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    goto LAB_0089ce30;
  case 0xc:
    iVar5 = FUN_0088d870();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d870();
    if (iVar1 == iVar5) {
LAB_0089cda5:
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    goto LAB_0089cdb0;
  case 0xd:
    iVar5 = FUN_0088d7d0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d7d0();
    if (iVar1 == iVar5) goto LAB_0089ca6f;
    piVar6 = (int *)0x0;
    goto LAB_0089ca7a;
  case 0xe:
    iVar5 = FUN_0088d910();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d910();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if ((((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
        (*(short *)piVar9 == *(short *)piVar6)) &&
       ((*(short *)((int)piVar9 + 2) == *(short *)((int)piVar6 + 2) &&
        (*(short *)(piVar9 + 1) == *(short *)(piVar6 + 1))))) {
      return 1;
    }
    break;
  case 0xf:
    iVar5 = FUN_0088d410();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d410();
    if (iVar1 == iVar5) {
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    if ((((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
        (((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7) &&
         (((NAN(pfVar10[1]) || NAN(pfVar7[1])) != (pfVar10[1] == pfVar7[1]) &&
          ((NAN(pfVar10[2]) || NAN(pfVar7[2])) != (pfVar10[2] == pfVar7[2]))))))) &&
       ((NAN(pfVar10[3]) || NAN(pfVar7[3])) != (pfVar10[3] == pfVar7[3]))) {
      return 1;
    }
    break;
  case 0x10:
    iVar5 = FUN_00b00260();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00b00260();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (piVar9 == (int *)0x0) {
      return 0;
    }
    if (piVar6 == (int *)0x0) {
      return 0;
    }
    goto LAB_0089cf7a;
  case 0x11:
    iVar5 = FUN_0088d050();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d050();
    if (iVar1 == iVar5) goto LAB_0089cda5;
    pfVar7 = (float *)0x0;
LAB_0089cdb0:
    if (((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
       (((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7) &&
        (((NAN(pfVar10[1]) || NAN(pfVar7[1])) != (pfVar10[1] == pfVar7[1]) &&
         ((NAN(pfVar10[2]) || NAN(pfVar7[2])) != (pfVar10[2] == pfVar7[2]))))))) {
      return 1;
    }
    break;
  case 0x12:
    iVar5 = FUN_0088d0f0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d0f0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if ((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) {
      if (((char)*(undefined2 *)piVar6 == *(char *)piVar9) &&
         ((param_1._1_1_ = (char)((ushort)*(undefined2 *)piVar6 >> 8),
          param_1._1_1_ == *(char *)((int)piVar9 + 1) &&
          (*(char *)((int)piVar6 + 2) == *(char *)((int)piVar9 + 2))))) {
        return 1;
      }
    }
    break;
  case 0x13:
    iVar5 = FUN_0088d690();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d690();
    if (iVar1 == iVar5) {
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    if (((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
       (((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7) && (pfVar10[1] == pfVar7[1])))) {
      return 1;
    }
    break;
  case 0x14:
    iVar5 = FUN_0088d5f0();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d5f0();
    if (iVar1 == iVar5) {
      pfVar7 = (float *)(param_2 + 2);
      if (param_2[1] == 0) {
        pfVar7 = (float *)0x0;
      }
    }
    else {
      pfVar7 = (float *)0x0;
    }
    if (((((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
         ((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7))) &&
        ((pfVar10[1] == pfVar7[1] &&
         ((NAN(pfVar10[2]) || NAN(pfVar7[2])) != (pfVar10[2] == pfVar7[2]))))) &&
       (pfVar10[3] == pfVar7[3])) {
      return 1;
    }
    break;
  case 0x15:
    iVar5 = FUN_0088d230();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d230();
    if (iVar1 == iVar5) goto LAB_0089ca6f;
    piVar6 = (int *)0x0;
    goto LAB_0089ca7a;
  case 0x16:
    iVar5 = FUN_0088ce60();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088ce60();
    if (iVar1 == iVar5) goto LAB_0089ca6f;
    piVar6 = (int *)0x0;
    goto LAB_0089ca7a;
  case 0x17:
    iVar5 = FUN_00a73110();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00a73110();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (piVar9 == (int *)0x0) {
      return 0;
    }
    if (piVar6 == (int *)0x0) {
      return 0;
    }
    if ((NAN((float)piVar9[0xc]) || NAN((float)piVar6[0xc])) ==
        ((float)piVar9[0xc] == (float)piVar6[0xc])) {
      return 0;
    }
    if ((NAN((float)piVar9[0xd]) || NAN((float)piVar6[0xd])) ==
        ((float)piVar9[0xd] == (float)piVar6[0xd])) {
      return 0;
    }
    if ((NAN((float)piVar9[0xe]) || NAN((float)piVar6[0xe])) ==
        ((float)piVar9[0xe] == (float)piVar6[0xe])) {
      return 0;
    }
LAB_0089cf7a:
    if (((((NAN((float)piVar9[9]) || NAN((float)piVar6[9])) !=
           ((float)piVar9[9] == (float)piVar6[9])) &&
         ((NAN((float)piVar9[10]) || NAN((float)piVar6[10])) !=
          ((float)piVar9[10] == (float)piVar6[10]))) &&
        ((NAN((float)piVar9[0xb]) || NAN((float)piVar6[0xb])) !=
         ((float)piVar9[0xb] == (float)piVar6[0xb]))) &&
       (cVar2 = FUN_01160ab0(piVar6), cVar2 != '\0')) {
      return 1;
    }
    break;
  case 0x18:
    iVar5 = FUN_00b33940();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00b33940();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (piVar9 == (int *)0x0) {
      return 0;
    }
    if (piVar6 == (int *)0x0) {
      return 0;
    }
    if (*(short *)piVar9 != *(short *)piVar6) {
      return 0;
    }
    if (*(short *)((int)piVar9 + 2) != *(short *)((int)piVar6 + 2)) {
      return 0;
    }
    if (*(short *)(piVar9 + 1) != *(short *)(piVar6 + 1)) {
      return 0;
    }
    if (*(short *)((int)piVar9 + 6) != *(short *)((int)piVar6 + 6)) {
      return 0;
    }
    if (*(short *)(piVar9 + 2) == *(short *)(piVar6 + 2)) {
      if (*(short *)((int)piVar9 + 10) == *(short *)((int)piVar6 + 10)) {
        return 1;
      }
      return 0;
    }
    return 0;
  case 0x1b:
    iVar5 = FUN_0088d2d0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088d2d0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       ((((*(char *)piVar9 == *(char *)piVar6 &&
          (((NAN((float)piVar9[1]) || NAN((float)piVar6[1])) !=
            ((float)piVar9[1] == (float)piVar6[1]) &&
           ((NAN((float)piVar9[3]) || NAN((float)piVar6[3])) !=
            ((float)piVar9[3] == (float)piVar6[3]))))) &&
         ((NAN((float)piVar9[2]) || NAN((float)piVar6[2])) != ((float)piVar9[2] == (float)piVar6[2])
         )) && (((NAN((float)piVar9[4]) || NAN((float)piVar6[4])) !=
                 ((float)piVar9[4] == (float)piVar6[4]) &&
                ((NAN((float)piVar9[5]) || NAN((float)piVar6[5])) !=
                 ((float)piVar9[5] == (float)piVar6[5]))))))) {
      return 1;
    }
    break;
  case 0x1c:
    iVar5 = FUN_0088cfa0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_0088cfa0();
    if (iVar1 == iVar5) goto LAB_0089ca6f;
    piVar6 = (int *)0x0;
LAB_0089ca7a:
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) && (*piVar9 == *piVar6)) {
      return 1;
    }
    break;
  case 0x20:
    uVar4 = FUN_009cb2e0(param_1,param_2);
    return uVar4;
  case 0x29:
    iVar5 = FUN_00a8dcc0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00a8dcc0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       (cVar2 = FUN_00a8e650(piVar6), cVar2 != '\0')) {
      return 1;
    }
    break;
  case 0x2a:
    iVar5 = FUN_00a8dd60();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00a8dd60();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       (cVar2 = FUN_00a8e6e0(piVar6), cVar2 != '\0')) {
      return 1;
    }
    break;
  case 0x2b:
    iVar5 = FUN_00b33310();
    if (iVar1 == iVar5) {
      pfVar10 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar10 = (float *)0x0;
      }
    }
    else {
      pfVar10 = (float *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00b33310();
    if (iVar1 == iVar5) goto LAB_0089ce25;
    pfVar7 = (float *)0x0;
LAB_0089ce30:
    if ((((pfVar10 != (float *)0x0) && (pfVar7 != (float *)0x0)) &&
        ((NAN(*pfVar10) || NAN(*pfVar7)) != (*pfVar10 == *pfVar7))) &&
       ((NAN(pfVar10[1]) || NAN(pfVar7[1])) != (pfVar10[1] == pfVar7[1]))) {
      return 1;
    }
    break;
  case 0x2c:
    iVar5 = FUN_00a92ae0();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00a92ae0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       (cVar2 = FUN_00a92f70(piVar6), cVar2 != '\0')) {
      return 1;
    }
    break;
  case 0x2d:
    iVar5 = FUN_00a92b80();
    if (iVar1 == iVar5) {
      piVar9 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar9 = (int *)0x0;
      }
    }
    else {
      piVar9 = (int *)0x0;
    }
    iVar1 = *param_2;
    iVar5 = FUN_00a92b80();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
    }
    else {
      piVar6 = (int *)0x0;
    }
    if (((piVar9 != (int *)0x0) && (piVar6 != (int *)0x0)) &&
       (cVar2 = FUN_006e28e0(piVar6), cVar2 != '\0')) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 14240 ; VA 0x0089d4d0 ; FUN_0089d4d0 */

int __thiscall FUN_0089d4d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bba58;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)param_3[1];
  ExceptionList = &pvStack_10;
  if (piVar4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_3[1];
  }
  param_3 = (undefined4 *)*param_3;
  uStack_8 = 0;
  iVar3 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(param_2,&param_3);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14241 ; VA 0x0089d560 ; FUN_0089d560 */

undefined4 __thiscall FUN_0089d560(int *param_1,int *param_2,char param_3)

{
  char cVar1;
  int *piVar2;
  
  piVar2 = param_1;
  if (param_1 != (int *)0x0) {
    do {
      if (piVar2 == param_2) {
        return 0;
      }
      piVar2 = (int *)piVar2[0xd];
    } while (piVar2 != (int *)0x0);
  }
  if ((((param_3 == '\0') || ((int *)param_2[0xd] != param_1)) &&
      (cVar1 = (**(code **)(*param_1 + 0x70))(param_2), cVar1 == '\0')) &&
     (cVar1 = (**(code **)(*param_2 + 0x74))(param_1), cVar1 == '\0')) {
    cVar1 = (**(code **)(*param_1 + 0x6c))(param_2);
    if ((cVar1 == '\0') && (cVar1 = (**(code **)(*param_2 + 0x78))(param_1), cVar1 == '\0')) {
      return 0;
    }
    return 1;
  }
  return 0;
}



/* FUNCTION 14242 ; VA 0x0089d5d0 ; FUN_0089d5d0 */

void __fastcall FUN_0089d5d0(int *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piStack_5c;
  int **ppiStack_58;
  int *apiStack_4c [5];
  uint uStack_38;
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [8];
  int *piStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba88;
  pvStack_10 = ExceptionList;
  if ((param_1[0xd] != 0) && (*(int *)(param_1[0xd] + 0x44) != 0)) {
    ppiStack_58 = (int **)param_1[10];
    piStack_5c = (int *)0x89d612;
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    FUN_0054ef60();
    piVar9 = (int *)param_1[0xd];
    iStack_8 = 0;
    iVar6 = piVar9[0x11];
    if (iVar6 == 0) {
      ppiStack_58 = (int **)0x89d62c;
      iVar6 = (**(code **)(*piVar9 + 0x14))();
      puVar1 = (undefined4 *)piVar9[0x11];
      piVar9[0x11] = iVar6;
      if (puVar1 != (undefined4 *)0x0) {
        ppiStack_58 = (int **)0x1;
        piStack_5c = (int *)0x89d63c;
        (**(code **)*puVar1)();
        iVar6 = piVar9[0x11];
      }
    }
    piStack_1c = *(int **)(iVar6 + 0x74);
    puStack_20 = (undefined4 *)(iVar6 + 0x70);
    piVar9 = (int *)*puStack_20;
    ppiStack_58 = (int **)piStack_1c;
    if (piVar9 != piStack_1c) {
      piVar10 = piVar9 + 0xe;
      do {
        ppiStack_58 = apiStack_4c;
        piStack_5c = piVar9;
        piStack_18 = piVar10;
        cVar5 = FUN_00558b30();
        if (cVar5 != '\0') {
          iStack_34 = 0;
          piStack_30 = (int *)0x0;
          if (*piStack_18 != 0) {
            piVar10 = (int *)(*piStack_18 + 4);
            iVar6 = *piVar10;
            while (iVar6 != 0) {
              LOCK();
              iVar7 = *piVar10;
              if (iVar6 == iVar7) {
                *piVar10 = iVar6 + 1;
                iVar7 = iVar6;
              }
              UNLOCK();
              if (iVar7 == iVar6) {
                iStack_34 = piStack_18[-1];
                piStack_30 = (int *)*piStack_18;
                break;
              }
              iVar6 = *piVar10;
            }
          }
          piVar10 = piStack_30;
          iStack_8._0_1_ = 1;
          if (iStack_34 != 0) {
            ppiStack_58 = (int **)piStack_18[1];
            piStack_5c = (int *)0x89d6c1;
            FUN_009eee80();
          }
          iStack_8._0_1_ = 0;
          if (piVar10 != (int *)0x0) {
            LOCK();
            iVar6 = piVar10[1] + -1;
            piVar10[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              ppiStack_58 = (int **)0x89d6d9;
              (**(code **)*piVar10)();
              LOCK();
              iVar6 = piVar10[2] + -1;
              piVar10[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                ppiStack_58 = (int **)0x89d6ea;
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          piStack_24 = (int *)&piStack_5c;
          FUN_0060dcd0(&piStack_5c,piStack_14);
          piVar10 = piStack_18;
          iStack_8._0_1_ = 2;
          FUN_00d88710(piStack_18 + -8);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_008a5470();
        }
        piVar9 = piVar9 + 0x10;
        piVar10 = piVar10 + 0x10;
      } while (piVar9 != piStack_1c);
      piVar2 = (int *)puStack_20[1];
      piVar9 = (int *)*puStack_20;
      ppiStack_58 = (int **)piVar2;
      piStack_1c = piVar2;
      piStack_18 = piVar10;
      if (piVar9 != piVar2) {
        do {
          ppiStack_58 = apiStack_4c;
          piStack_5c = piVar9;
          cVar5 = FUN_00558b30();
          if (cVar5 != '\0') break;
          piVar9 = piVar9 + 0x10;
        } while (piVar9 != piVar2);
        ppiStack_58 = (int **)piVar2;
        if ((piVar9 != piVar2) &&
           (piVar10 = piVar9 + 0x10, ppiStack_58 = (int **)piStack_1c, piVar10 != piStack_1c)) {
          piStack_14 = piVar9 + 0xe;
          piStack_18 = piVar9 + 0x1e;
          do {
            ppiStack_58 = apiStack_4c;
            piStack_5c = piVar10;
            cVar5 = FUN_00558b30();
            if (cVar5 == '\0') {
              if (piVar9 != piVar10) {
                uVar3 = piStack_14[-9];
                if (0xf < uVar3) {
                  piVar2 = (int *)*piVar9;
                  ppiStack_58 = (int **)(uVar3 + 1);
                  piVar8 = piVar2;
                  if (0xfff < ppiStack_58) {
                    piVar8 = (int *)piVar2[-1];
                    ppiStack_58 = (int **)(uVar3 + 0x24);
                    if (0x1f < (uint)((int)piVar2 + (-4 - (int)piVar8))) goto LAB_0089d8df;
                  }
                  piStack_5c = piVar8;
                  FUN_01674ea0();
                }
                piStack_14[-10] = 0;
                piStack_14[-9] = 0xf;
                *(undefined *)piVar9 = 0;
                iVar6 = piVar10[1];
                iVar7 = piVar10[2];
                iVar4 = piVar10[3];
                *piVar9 = *piVar10;
                piVar9[1] = iVar6;
                piVar9[2] = iVar7;
                piVar9[3] = iVar4;
                iVar6 = piVar10[5];
                piVar9[4] = piVar10[4];
                piVar9[5] = iVar6;
                piStack_18[-10] = 0;
                piStack_18[-9] = 0xf;
                *(undefined *)piVar10 = 0;
              }
              ppiStack_58 = (int **)(piStack_18 + -8);
              piStack_5c = (int *)0x89d832;
              FUN_00d88cd0();
              iVar6 = piStack_18[-1];
              iVar7 = *piStack_18;
              piStack_18[-1] = 0;
              *piStack_18 = 0;
              piStack_14[-1] = iVar6;
              piStack_24 = (int *)*piStack_14;
              *piStack_14 = iVar7;
              if (piStack_24 != (int *)0x0) {
                LOCK();
                iVar6 = piStack_24[2] + -1;
                piStack_24[2] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  ppiStack_58 = (int **)0x89d869;
                  (**(code **)(*piStack_24 + 4))();
                }
              }
              piVar9 = piVar9 + 0x10;
              piStack_14[1] = piStack_18[1];
              piStack_14 = piStack_14 + 0x10;
            }
            piStack_18 = piStack_18 + 0x10;
            piVar10 = piVar10 + 0x10;
            ppiStack_58 = (int **)piStack_1c;
          } while (piVar10 != piStack_1c);
        }
      }
    }
    piStack_5c = piVar9;
    FUN_0089ff70(auStack_2c);
    if (0xf < uStack_38) {
      ppiStack_58 = (int **)(uStack_38 + 1);
      piVar9 = apiStack_4c[0];
      if (0xfff < ppiStack_58) {
        piVar9 = (int *)apiStack_4c[0][-1];
        ppiStack_58 = (int **)(uStack_38 + 0x24);
        if (0x1f < (uint)((int)apiStack_4c[0] + (-4 - (int)piVar9))) {
LAB_0089d8df:
                    /* WARNING: Subroutine does not return */
          ppiStack_58 = (int **)&UNK_0089d8e4;
          FUN_017167a3();
        }
      }
      piStack_5c = piVar9;
      FUN_01674ea0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14243 ; VA 0x0089d8f0 ; FUN_0089d8f0 */

undefined4 FUN_0089d8f0(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  piVar1 = (int *)(iVar2 + 0x1c);
  *piVar1 = *piVar1 + -1;
  return CONCAT31((int3)((uint)iVar2 >> 8),*piVar1 == 0);
}



/* FUNCTION 14244 ; VA 0x0089d910 ; FUN_0089d910 */

void __fastcall FUN_0089d910(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  if (*(int *)(param_1 + 8) != 0) {
    FUN_0057d4d0(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0x14);
    puVar1 = puVar2 + *(int *)(param_1 + 4);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  return;
}



/* FUNCTION 14245 ; VA 0x0089d950 ; FUN_0089d950 */

undefined4 * __thiscall FUN_0089d950(undefined4 param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bbac0;
  pvStack_10 = ExceptionList;
  puStack_24 = (undefined4 *)0x0;
  iStack_20 = 0;
  uStack_1c = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0060dcd0(&piStack_18,param_1);
  uStack_8 = 2;
  FUN_00603a30(0,uVar3);
  uStack_8 = 1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piStack_18 = (int *)0x0;
  piStack_14 = (int *)0x0;
  piStack_18 = (int *)FUN_00575ad0();
  uStack_8 = 3;
  FUN_0089dad0(&puStack_24,&piStack_18,&uStack_30,param_3,0,0);
  piVar1 = piStack_18;
  uStack_8 = 4;
  FUN_0089c760(piStack_18[1]);
  _uStack_8 = CONCAT31(uStack_7,1);
  piStack_18[1] = (int)piVar1;
  *piStack_18 = (int)piVar1;
  piStack_18[2] = (int)piVar1;
  piStack_14 = (int *)0x0;
  FUN_01674ea0(piStack_18,0x1c);
  if (iStack_20 - (int)puStack_24 >> 3 == 0) {
    FUN_0060dcd0(param_2,0);
  }
  else {
    *param_2 = 0;
    param_2[1] = 0;
    if (puStack_24[1] != 0) {
      LOCK();
      piVar1 = (int *)(puStack_24[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *puStack_24;
    param_2[1] = puStack_24[1];
  }
  FUN_00577ac0();
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14246 ; VA 0x0089dad0 ; FUN_0089dad0 */

void FUN_0089dad0(int param_1,int *param_2,int *param_3,undefined4 param_4,char param_5,
                 undefined4 param_6)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  undefined4 *puVar11;
  uint *puVar12;
  uint *puStack_44;
  code *pcStack_3c;
  undefined4 **ppuStack_38;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbafc;
  pvStack_10 = ExceptionList;
  puStack_34 = (undefined4 *)0x0;
  uStack_30 = 0;
  ExceptionList = &pvStack_10;
  puStack_34 = (undefined4 *)FUN_0089c660();
  ppuStack_38 = &puStack_34;
  uStack_8 = 0;
  pcStack_3c = FUN_008a4e70;
  puStack_18 = (uint *)*param_3;
  puVar2 = (uint *)param_3[1];
  puStack_14 = puVar2;
  if (puStack_18 != puVar2) {
    do {
      uVar3 = *puStack_18;
      if ((uVar3 != 0) && (piVar10 = *(int **)(uVar3 + 0x2c), piVar10 != (int *)0x0)) {
        piVar7 = *(int **)(uVar3 + 0x30);
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
          piVar10 = *(int **)(uVar3 + 0x2c);
          piVar7 = *(int **)(uVar3 + 0x30);
        }
        iVar1 = piVar10[1];
        iVar8 = *piVar10;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piStack_28 = piVar7;
        piStack_2c = piVar10;
        for (; iVar8 != iVar1; iVar8 = iVar8 + 8) {
          (*pcStack_3c)(ppuStack_38,iVar8);
          FUN_008999a0(&pcStack_3c);
          puVar2 = puStack_14;
        }
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar1 = piVar7[1] + -1;
          piVar7[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            iVar1 = piVar7[2] + -1;
            piVar7[2] = iVar1;
            UNLOCK();
            puVar2 = puStack_14;
            if (iVar1 == 0) {
              (**(code **)(*piVar7 + 4))();
              puVar2 = puStack_14;
            }
          }
        }
      }
      puStack_18 = puStack_18 + 2;
    } while (puStack_18 != puVar2);
    puStack_18 = (uint *)*param_3;
    puVar2 = (uint *)param_3[1];
  }
  puStack_1c = (uint *)0x0;
  puStack_44 = (uint *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar11 = puStack_34;
  puStack_14 = puVar2;
  if (puStack_18 != puVar2) {
    do {
      uVar3 = *puStack_18;
      if (uVar3 != 0) {
        puVar4 = (undefined4 *)puVar11[1];
        puVar5 = puVar11;
        puVar2 = puStack_14;
        if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
          do {
            if ((uint)puVar4[4] < uVar3) {
              puVar6 = (undefined4 *)puVar4[2];
            }
            else {
              puVar6 = (undefined4 *)*puVar4;
              puVar5 = puVar4;
            }
            puVar4 = puVar6;
          } while (*(char *)((int)puVar6 + 0xd) == '\0');
          if ((puVar5 != puVar11) && ((uint)puVar5[4] <= uVar3)) goto LAB_0089dc66;
        }
        if (puStack_44 == (uint *)0x0) {
          FUN_005c1970(0,puStack_18);
          puVar2 = puStack_14;
          puVar11 = puStack_34;
        }
        else {
          *puStack_44 = 0;
          puStack_44[1] = 0;
          if (puStack_18[1] != 0) {
            LOCK();
            piVar10 = (int *)(puStack_18[1] + 4);
            *piVar10 = *piVar10 + 1;
            UNLOCK();
          }
          *puStack_44 = *puStack_18;
          puStack_44[1] = puStack_18[1];
          puStack_44 = puStack_44 + 2;
          puVar11 = puStack_34;
        }
      }
LAB_0089dc66:
      puStack_18 = puStack_18 + 2;
    } while (puStack_18 != puVar2);
  }
  puStack_1c = (uint *)0x0;
  puVar2 = (uint *)0x0;
  if (puStack_44 != (uint *)0x0) {
    do {
      FUN_0089e020(param_2,puVar2,param_4,param_6,1);
      puVar2 = puVar2 + 2;
    } while (puVar2 != puStack_44);
  }
  piVar10 = (int *)*param_2;
  piStack_20 = (int *)*piVar10;
  piStack_28 = piVar10;
  if (piStack_20 != piVar10) {
    piStack_24 = (int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    do {
      piVar7 = (int *)piStack_20[4];
      puStack_14 = (uint *)piStack_20[5];
      piVar9 = *(int **)(piVar7[3] + 0x18);
      puStack_18 = (uint *)piVar7;
      if (piVar9 != *(int **)(piVar7[3] + 0x1c)) {
        do {
          puStack_18 = (uint *)*piVar9;
          if ((((uint)((int *)puStack_18)[9] >> 6 & 1) != 0) ||
             (((byte)((int *)puStack_18)[9] & 0x18) == 0x18)) {
            iVar1 = ((int *)puStack_18)[10];
            if ((*(int *)(*piStack_24 + 0x34) < DAT_01ead028) &&
               (FUN_016f3809(&DAT_01ead028), DAT_01ead028 == -1)) {
              uStack_8._0_1_ = 3;
              DAT_01ead024 = FUN_0086e8f0("Object");
              uStack_8 = CONCAT31(uStack_8._1_3_,2);
              FUN_016f37bf(&DAT_01ead028);
            }
            if (*(int *)(iVar1 + 4) == DAT_01ead024) {
              uVar3 = (**(code **)(*puStack_18 + 0x44))(piVar7);
              puVar11 = (undefined4 *)*param_2;
              puVar4 = (undefined4 *)puVar11[1];
              puVar5 = puVar11;
              if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
                do {
                  if ((uint)puVar4[4] < uVar3) {
                    puVar6 = (undefined4 *)puVar4[2];
                  }
                  else {
                    puVar6 = (undefined4 *)*puVar4;
                    puVar5 = puVar4;
                  }
                  puVar4 = puVar6;
                } while (*(char *)((int)puVar6 + 0xd) == '\0');
                if ((puVar5 == puVar11) || (uVar3 < (uint)puVar5[4])) goto LAB_0089dd5d;
              }
              else {
LAB_0089dd5d:
                puVar5 = puVar11;
              }
              if (puVar5 != puVar11) {
                uVar3 = puVar5[5];
              }
              (**(code **)(*puStack_18 + 0x48))(puStack_14,uVar3);
            }
            else {
              (**(code **)(*puStack_18 + 0x24))(piVar7,puStack_14);
            }
          }
          piVar9 = piVar9 + 1;
          piVar10 = piStack_28;
        } while (piVar9 != *(int **)(piVar7[3] + 0x1c));
      }
      FUN_00551320();
    } while (piStack_20 != piVar10);
    piVar10 = (int *)*param_2;
  }
  puStack_18 = puStack_1c;
  if (puStack_1c != puStack_44) {
    do {
      puVar11 = (undefined4 *)*param_2;
      uVar3 = *puStack_18;
      puVar4 = (undefined4 *)puVar11[1];
      puVar5 = puVar11;
      if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
        do {
          if ((uint)puVar4[4] < uVar3) {
            puVar6 = (undefined4 *)puVar4[2];
          }
          else {
            puVar6 = (undefined4 *)*puVar4;
            puVar5 = puVar4;
          }
          puVar4 = puVar6;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
        if (((puVar5 != puVar11) && ((uint)puVar5[4] <= uVar3)) &&
           (piVar10 = *(int **)(uVar3 + 0x2c), piVar10 != (int *)0x0)) {
          piStack_28 = *(int **)(uVar3 + 0x30);
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[1] = piStack_28[1] + 1;
            UNLOCK();
            piStack_28 = *(int **)(uVar3 + 0x30);
            piVar10 = *(int **)(uVar3 + 0x2c);
          }
          iVar1 = piVar10[1];
          iVar8 = *piVar10;
          uStack_8._0_1_ = 4;
          piVar7 = piStack_28;
          piStack_2c = piVar10;
          for (; piStack_20 = piVar7, iVar8 != iVar1; iVar8 = iVar8 + 8) {
            FUN_008a4ef0(param_2,iVar8);
            piVar7 = piStack_20;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar1 = piVar7[1] + -1;
            piVar7[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar1 = piVar7[2] + -1;
              piVar7[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
        }
      }
      puStack_18 = puStack_18 + 2;
    } while (puStack_18 != puStack_44);
    piVar10 = (int *)*param_2;
  }
  puVar2 = puStack_1c;
  piStack_20 = (int *)*piVar10;
  while (piStack_20 != piVar10) {
    if (*(int *)(piStack_20[4] + 0x44) != 0) {
      if (piStack_20[6] != 0) {
        LOCK();
        piVar7 = (int *)(piStack_20[6] + 4);
        *piVar7 = *piVar7 + 1;
        UNLOCK();
      }
      FUN_0089be10(piStack_20[5],piStack_20[6]);
    }
    FUN_00551320();
  }
  if (param_5 != '\0') {
    for (; puVar2 != puStack_44; puVar2 = puVar2 + 2) {
      puVar11 = (undefined4 *)*param_2;
      uVar3 = *puVar2;
      puVar4 = (undefined4 *)puVar11[1];
      puVar5 = puVar11;
      if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
        do {
          if ((uint)puVar4[4] < uVar3) {
            puVar6 = (undefined4 *)puVar4[2];
          }
          else {
            puVar6 = (undefined4 *)*puVar4;
            puVar5 = puVar4;
          }
          puVar4 = puVar6;
        } while (*(char *)((int)puVar6 + 0xd) == '\0');
        if ((puVar5 == puVar11) || (uVar3 < (uint)puVar5[4])) goto LAB_0089df0d;
      }
      else {
LAB_0089df0d:
        puVar5 = puVar11;
      }
      if (puVar5 != puVar11) {
        FUN_008a65e0(*(undefined4 *)(uVar3 + 0x34),0);
      }
    }
  }
  puVar2 = (uint *)param_3[1];
  puVar12 = (uint *)*param_3;
  do {
    if (puVar12 == puVar2) {
      FUN_00577ac0();
      FUN_0089ad50();
      ExceptionList = pvStack_10;
      return;
    }
    puVar11 = (undefined4 *)*param_2;
    puVar5 = puVar11;
    puVar4 = (undefined4 *)puVar11[1];
    if (*(char *)((int)puVar11[1] + 0xd) == '\0') {
      do {
        puVar6 = puVar4;
        if ((uint)puVar6[4] < *puVar12) {
          puVar4 = (undefined4 *)puVar6[2];
          puVar6 = puVar5;
        }
        else {
          puVar4 = (undefined4 *)*puVar6;
        }
        puVar5 = puVar6;
      } while (*(char *)((int)puVar4 + 0xd) == '\0');
      if ((puVar6 == puVar11) || (*puVar12 < (uint)puVar6[4])) goto LAB_0089df6f;
    }
    else {
LAB_0089df6f:
      puVar6 = puVar11;
    }
    if (puVar6 != puVar11) {
      puVar11 = *(undefined4 **)(param_1 + 4);
      if (*(undefined4 **)(param_1 + 8) == puVar11) {
        FUN_005c1970(puVar11,puVar6 + 5);
      }
      else {
        *puVar11 = 0;
        puVar11[1] = 0;
        if (puVar6[6] != 0) {
          LOCK();
          piVar10 = (int *)(puVar6[6] + 4);
          *piVar10 = *piVar10 + 1;
          UNLOCK();
        }
        *puVar11 = puVar6[5];
        puVar11[1] = puVar6[6];
        *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
      }
    }
    puVar12 = puVar12 + 2;
  } while( true );
}



/* FUNCTION 14247 ; VA 0x0089e020 ; FUN_0089e020 */

void FUN_0089e020(int *param_1,uint *param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  bool bVar4;
  uint *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined auStack_58 [24];
  undefined auStack_40 [24];
  int iStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbb30;
  pvStack_10 = ExceptionList;
  param_2 = (uint *)*param_2;
  uVar2 = param_2[3];
  if ((*(uint *)(uVar2 + 0x1d4) >> 2 & 1) == 0) {
    return;
  }
  if (((char)param_4 == '\0') && (*(char *)((int)param_2 + 0x21) == '\0')) {
    return;
  }
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00601f20(&puStack_18,&param_2);
  if (*piVar6 != *param_1) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 0;
  if (DAT_01d62bd8 == '\0') {
    uVar8 = *(undefined4 *)(uVar2 + 4);
    uVar11 = param_3;
  }
  else {
    if ((param_5 == '\0') &&
       (iVar7 = FUN_00eb3a50(),
       (uint)*(ushort *)(uVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
       (uint)*(ushort *)(iVar7 + 0x1da))) {
      bVar4 = true;
    }
    else {
      bVar4 = false;
    }
    uVar11 = param_3;
    if (bVar4) {
      uVar11 = 3;
    }
    uVar8 = *(undefined4 *)(*(int *)(*puVar5 + 0xc) + 4);
  }
  uVar8 = FUN_0061a170(&piStack_1c,uVar8,uVar11);
  FUN_005587e0(uVar8);
  FUN_00550b30();
  if (iStack_28 == 0) {
    FUN_0054db20();
    FUN_008a2380(auStack_40);
    uStack_8._0_1_ = 1;
    uVar8 = FUN_005543f0();
    uVar8 = FUN_01675640(auStack_58,"%s cannot be cloned",uVar8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005500e0(uVar8);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  puVar3 = (undefined4 *)*param_1;
  uStack_14 = *puVar5;
  puVar9 = (undefined4 *)puVar3[1];
  puVar12 = puVar3;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      if ((uint)puVar9[4] < uStack_14) {
        puVar10 = (undefined4 *)puVar9[2];
      }
      else {
        puVar10 = (undefined4 *)*puVar9;
        puVar12 = puVar9;
      }
      puVar9 = puVar10;
    } while (*(char *)((int)puVar10 + 0xd) == '\0');
    if ((puVar12 != puVar3) && ((uint)puVar12[4] <= uStack_14)) goto LAB_0089e172;
  }
  puStack_18 = &uStack_14;
  iVar7 = FUN_00559250(&DAT_018bdeda,&puStack_18,(int)&param_2 + 3);
  FUN_00898260(&param_2,puVar12,iVar7 + 0x10,iVar7);
LAB_0089e172:
  FUN_0056ecd0(&iStack_28);
  uVar2 = *puVar5;
  piVar6 = *(int **)(uVar2 + 0x2c);
  if (piVar6 != (int *)0x0) {
    puStack_18 = *(uint **)(uVar2 + 0x30);
    if (puStack_18 != (uint *)0x0) {
      LOCK();
      puStack_18[1] = puStack_18[1] + 1;
      UNLOCK();
      puStack_18 = *(uint **)(uVar2 + 0x30);
      piVar6 = *(int **)(uVar2 + 0x2c);
    }
    iVar7 = piVar6[1];
    iVar13 = *piVar6;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar5 = puStack_18;
    piStack_1c = piVar6;
    for (; param_2 = puVar5, iVar13 != iVar7; iVar13 = iVar13 + 8) {
      FUN_0089e020(param_1,iVar13,param_3,param_4,0);
      puVar5 = param_2;
    }
    if (puVar5 != (uint *)0x0) {
      LOCK();
      uVar2 = puVar5[1] - 1;
      puVar5[1] = uVar2;
      UNLOCK();
      if (uVar2 == 0) {
        (**(code **)*puVar5)();
        LOCK();
        puVar1 = puVar5 + 2;
        uVar2 = *puVar1;
        *puVar1 = *puVar1 - 1;
        UNLOCK();
        if (uVar2 == 1) {
          (**(code **)(*puVar5 + 4))();
        }
      }
    }
  }
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14248 ; VA 0x0089e260 ; FUN_0089e260 */

int FUN_0089e260(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)(*param_1 + 0x3c))();
  *param_3 = *param_3 + iVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14249 ; VA 0x0089e2d0 ; FUN_0089e2d0 */

undefined4 * __thiscall
FUN_0089e2d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbb71;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089f750;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}


