/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 5250 ; VA 0x005c6580 ; FUN_005c6580 */

void __fastcall FUN_005c6580(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0xf0);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    FUN_0170d1f0(puVar1 + 2,0,0xe8);
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00560ab0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 5251 ; VA 0x005c65e0 ; FUN_005c65e0 */

void FUN_005c65e0(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  return;
}



/* FUNCTION 5252 ; VA 0x005c65f0 ; FUN_005c65f0 */

void FUN_005c65f0(undefined4 param_1)

{
  FUN_0054ef60(param_1);
  return;
}



/* FUNCTION 5253 ; VA 0x005c6600 ; FUN_005c6600 */

void FUN_005c6600(undefined8 *param_1,undefined8 *param_2)

{
  *param_2 = *param_1;
  *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 1);
  return;
}



/* FUNCTION 5254 ; VA 0x005c6620 ; FUN_005c6620 */

void FUN_005c6620(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  return;
}



/* FUNCTION 5255 ; VA 0x005c6640 ; FUN_005c6640 */

void FUN_005c6640(undefined *param_1,undefined *param_2)

{
  *param_2 = *param_1;
  return;
}



/* FUNCTION 5256 ; VA 0x005c6650 ; FUN_005c6650 */

void __thiscall FUN_005c6650(int param_1,undefined4 param_2,undefined4 param_3)

{
  param_2 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&param_2);
  return;
}



/* FUNCTION 5257 ; VA 0x005c6680 ; FUN_005c6680 */

/* WARNING: Removing unreachable block (ram,0x005c672e) */
/* WARNING: Removing unreachable block (ram,0x005c677a) */
/* WARNING: Removing unreachable block (ram,0x005c6775) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_005c6680(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017989e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = (ulonglong)(uint)uStack_18;
  ExceptionList = &pvStack_10;
  FUN_005c24c0((int)&uStack_18 + 4,param_2 + 1);
  if (*(int *)(param_1 + 0x14) != 0) {
    *(undefined4 *)(param_2 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar4 = iVar1 + 4;
    iVar2 = *(int *)(param_1 + 0x14);
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x27;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5258 ; VA 0x005c67a0 ; FUN_005c67a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_005c67a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined *puStack_288;
  undefined8 uStack_284;
  undefined4 uStack_27c;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined8 **)(param_1 + 0x48);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = FUN_0088d050();
    puStack_288 = (undefined *)0x0;
    uStack_284 = *puVar1;
    uStack_27c = *(undefined4 *)(puVar1 + 1);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c08)
       && (FUN_016f3809(&DAT_01ea8c08), DAT_01ea8c08 == -1)) {
      _DAT_01ea8bfc = FUN_005c6600;
      _DAT_01ea8c00 = FUN_005c6600;
      DAT_01ea8c04 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c08);
    }
    puStack_288 = &DAT_01ea8bfc;
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d050();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, puStack_288 != (undefined *)0x0)) {
    (**(code **)(puStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5259 ; VA 0x005c6b20 ; FUN_005c6b20 */

void __thiscall
FUN_005c6b20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_005c9cc0();
    puVar4 = &uStack_28c;
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5260 ; VA 0x005c6f30 ; FUN_005c6f30 */

void __thiscall
FUN_005c6f30(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798d19;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar2);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_005c9cc0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088c8c0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_005c9cc0();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088c8c0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x4c));
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,param_2);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x50) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x50));
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,param_2);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x100) != 0) {
    uVar6 = uVar6 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x54);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0x15;
    uVar6 = uVar6 | 0x800;
  }
  else {
    uStack_28c = FUN_008882f0();
    iStack_288 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_284 = *puVar5;
    uStack_280 = puVar5[1];
    iStack_288 = FUN_005c9da0();
    puVar5 = &uStack_28c;
    uStack_8 = 0x14;
    uVar6 = uVar6 | 0x400;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_008882f0();
  uVar4 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x800) != 0) {
    uVar6 = uVar6 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x400) != 0) && (uStack_8 = 0x17, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5261 ; VA 0x005c7520 ; FUN_005c7520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_005c7520(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puStack_18 = &uStack_1bc;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088da50();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c28)
       && (FUN_016f3809(&DAT_01ea8c28), DAT_01ea8c28 == -1)) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c28);
    }
    puStack_e8 = &DAT_01ea8c1c;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5262 ; VA 0x005c77b0 ; FUN_005c77b0 */

void FUN_005c77b0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 5263 ; VA 0x005c7800 ; FUN_005c7800 */

bool __thiscall FUN_005c7800(int param_1,int param_2,int param_3)

{
  return *(int *)(*(int *)(param_1 + 8) + param_2) == *(int *)(*(int *)(param_1 + 8) + param_3);
}



/* FUNCTION 5264 ; VA 0x005c7820 ; FUN_005c7820 */

void __fastcall FUN_005c7820(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005c782c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x34) + 0x14))();
  return;
}



/* FUNCTION 5265 ; VA 0x005c7830 ; FUN_005c7830 */

undefined4 FUN_005c7830(void)

{
  return 0;
}



/* FUNCTION 5266 ; VA 0x005c7840 ; FUN_005c7840 */

undefined4 FUN_005c7840(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined4 uVar6;
  undefined4 uStack_100;
  int iStack_fc;
  undefined auStack_f8 [200];
  undefined auStack_30 [8];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798dc3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  if (2 < iVar4) {
    puVar5 = (undefined8 *)FUN_01257810(param_2,param_3 + 3,DAT_01ea8be8);
    if (puVar5 != (undefined8 *)0x0) {
      uStack_20 = *puVar5;
      uStack_28 = *(undefined4 *)(puVar5 + 1);
      uStack_18 = uStack_28;
      goto LAB_005c7985;
    }
    if (2 < iVar4) {
      uStack_100 = FUN_00888530();
      iStack_fc = 0;
      uStack_8 = 0;
      cVar3 = FUN_009d1bf0(param_2,param_3 + 3,&uStack_100,1);
      if (cVar3 != '\0') {
        puVar5 = (undefined8 *)FUN_0088a700();
        uStack_20 = *puVar5;
        uStack_18 = *(undefined4 *)(puVar5 + 1);
        uStack_8 = 1;
        if (iStack_fc != 0) {
          (**(code **)(iStack_fc + 8))(auStack_f8);
        }
        uStack_8 = 0xffffffff;
        goto LAB_005c7985;
      }
      uStack_8 = 2;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(auStack_f8);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = *(undefined8 **)(iStack_14 + 0x48);
  if (puVar5 == (undefined8 *)0x0) {
    FUN_016756b0(auStack_30,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  uStack_20 = *puVar5;
  uStack_18 = *(undefined4 *)(puVar5 + 1);
LAB_005c7985:
  uStack_24 = FUN_009d05b0(param_2,param_3,2,iVar4,iStack_14 + 0x44);
  uVar6 = FUN_009d05b0(param_2,param_3,1,iVar4,iStack_14 + 0x40);
  uVar6 = (**(code **)(iStack_14 + 0x38))(&uStack_20,uVar6,uStack_24,uStack_20,uStack_18);
  uStack_8 = 3;
  uVar6 = FUN_009d5730(param_2,uVar6);
  piVar2 = uStack_20._4_4_;
  if (uStack_20._4_4_ != (int *)0x0) {
    LOCK();
    iVar4 = uStack_20._4_4_[1] + -1;
    uStack_20._4_4_[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*uStack_20._4_4_)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5267 ; VA 0x005c7a50 ; FUN_005c7a50 */

undefined4 FUN_005c7a50(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iStack_98;
  int iStack_94;
  uint *puStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int aiStack_6c [5];
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01798df0;
  pvStack_1c = ExceptionList;
  iStack_7c = param_2;
  iStack_80 = 0x5c7a8c;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300();
  iStack_80 = (int)pcStack_28 + 0x4c;
  iVar3 = iVar3 - param_3;
  iStack_88 = 4;
  iStack_8c = param_3;
  puStack_90 = (uint *)param_2;
  iStack_94 = 0x5c7aa6;
  iStack_84 = iVar3;
  uStack_2c = FUN_009d05b0();
  iStack_94 = (int)pcStack_28 + 0x48;
  iStack_98 = iVar3;
  puStack_30 = (undefined *)FUN_009d05b0(param_2,param_3,3);
  uStack_34 = FUN_009d09d0(aiStack_6c,param_2,param_3,2,iVar3,(int)pcStack_28 + 0x44);
  puStack_90 = auStack_54;
  iStack_7c = (int)pcStack_28 + 0x40;
  uStack_14 = 0;
  iStack_84 = 1;
  iStack_88 = param_3;
  iStack_8c = param_2;
  iStack_94 = 0x5c7afa;
  iStack_80 = iVar3;
  uVar4 = FUN_009d09d0();
  iStack_7c = uStack_2c;
  iStack_80 = (int)puStack_30;
  uStack_14._0_1_ = 1;
  puStack_30 = (undefined *)&iStack_98;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uStack_34);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar4);
  uStack_14._0_1_ = 1;
  uVar4 = (*pcStack_28)(auStack_3c);
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  pcStack_28 = (code *)FUN_009d5730(param_2,uVar4);
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_38[1] + -1;
    piStack_38[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piStack_38 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  pcVar2 = pcStack_28;
  if (0xf < uStack_40) {
    uVar5 = uStack_40 + 1;
    uVar6 = auStack_54[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_54[0] - 4);
      uVar5 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  if (0xf < uStack_58) {
    uVar6 = uStack_58 + 1;
    iVar3 = aiStack_6c[0];
    if (0xfff < uVar6) {
      iVar3 = *(int *)(aiStack_6c[0] + -4);
      uVar6 = uStack_58 + 0x24;
      if (0x1f < (aiStack_6c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar6);
  }
  ExceptionList = pvStack_1c;
  return pcVar2;
}



/* FUNCTION 5268 ; VA 0x005c7c20 ; FUN_005c7c20 */

undefined4 FUN_005c7c20(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iStack_80;
  int iStack_7c;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [4];
  int *piStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined *puStack_44;
  code *pcStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined3 uStack_2f;
  undefined uStack_2c;
  undefined3 uStack_2b;
  int *piStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01798e20;
  pvStack_1c = ExceptionList;
  iStack_7c = param_2;
  iStack_80 = 0x5c7c5c;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300();
  iStack_80 = iStack_24 + 0x54;
  iVar3 = iVar3 - param_3;
  piStack_28 = (int *)FUN_009d11e0(auStack_54,param_2,param_3,6,iVar3);
  uStack_14 = 0;
  uVar2 = FUN_009d1aa0(param_2,param_3,5,iVar3,iStack_24 + 0x50);
  _uStack_2c = CONCAT31(uStack_2b,uVar2);
  uVar2 = FUN_009d1aa0(param_2,param_3,4,iVar3,iStack_24 + 0x4c);
  _uStack_30 = CONCAT31(uStack_2f,uVar2);
  iStack_7c = iStack_24 + 0x48;
  iStack_80 = iVar3;
  uStack_34 = FUN_009d05b0(param_2,param_3,3);
  uStack_38 = FUN_009d05b0(param_2,param_3,2,iVar3,iStack_24 + 0x44);
  uVar4 = FUN_009d09d0(auStack_6c,param_2,param_3,1,iVar3,iStack_24 + 0x40);
  pcStack_40 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  puStack_44 = (undefined *)&iStack_80;
  if (piStack_28[1] != 0) {
    LOCK();
    piVar1 = (int *)(piStack_28[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_80 = *piStack_28;
  iStack_7c = piStack_28[1];
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar4);
  uStack_14._0_1_ = 1;
  uVar4 = (*pcStack_40)(auStack_4c);
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  pcStack_40 = (code *)FUN_009d5730(param_2,uVar4);
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_48[1] + -1;
    piStack_48[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      iVar3 = piStack_48[2] + -1;
      piStack_48[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  if (0xf < uStack_58) {
    uVar6 = uStack_58 + 1;
    uVar5 = auStack_6c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_6c[0] - 4);
      uVar6 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_50[1] + -1;
    piStack_50[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piStack_50 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_40;
}



/* FUNCTION 5269 ; VA 0x005c7e30 ; FUN_005c7e30 */

undefined4 __thiscall FUN_005c7e30(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_3);
  uVar4 = FUN_009d09d0(aiStack_30,param_3,param_4,1,iVar3 - param_4,param_1 + 0x40);
  pcVar2 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar4);
  uVar4 = (*pcVar2)(auStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar4 = FUN_009d5980(param_3,uVar4);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 5270 ; VA 0x005c7f30 ; FUN_005c7f30 */

undefined4 FUN_005c7f30(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  uStack_18 = FUN_009d1940(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar3 = FUN_009d09d0(aiStack_30,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar3);
  (*pcVar1)();
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 5271 ; VA 0x005c8010 ; FUN_005c8010 */

void __thiscall
FUN_005c8010(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  code *pcVar1;
  undefined uVar2;
  uint in_stack_ffffffc4;
  uint uVar3;
  undefined4 in_stack_ffffffc8;
  undefined4 in_stack_ffffffcc;
  undefined4 in_stack_ffffffd0;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uStack_24;
  int iStack_20;
  undefined8 uStack_14;
  undefined4 uStack_c;
  int iStack_8;
  
  iStack_20 = 0;
  uStack_24 = 0;
  uVar4 = 0;
  uVar5 = 0xf;
  uVar3 = in_stack_ffffffc4 & 0xffffff00;
  iStack_8 = param_1;
  FUN_005542c0("ExportScene",0xb);
  FUN_005c54b0(uVar3,in_stack_ffffffc8,in_stack_ffffffcc,in_stack_ffffffd0,uVar4,uVar5);
  uStack_24 = 0x5c8050;
  iStack_20 = param_1;
  FUN_005c3ac0();
  iStack_20 = param_6;
  uStack_24 = 0;
  uVar2 = FUN_008ba510();
  uStack_c = CONCAT31(uStack_c._1_3_,uVar2);
  uStack_14 = 0;
  pcVar1 = *(code **)(*param_2 + 0xc);
  FUN_005c4330(&uStack_24,-(uint)(*(int *)(param_1 + 0x34) != 0) & *(int *)(param_1 + 0x34) - 0xcU);
  (*pcVar1)();
  (**(code **)(*param_2 + 0x48))(param_3,param_4);
  (**(code **)(*param_2 + 0x6c))(0,0,1,param_7,param_5,param_6,uStack_c,&uStack_14);
  (**(code **)(*param_2 + 0xc))(0,0);
  (**(code **)(*param_2 + 0x4c))();
  if ((int)uStack_14 != 0 || uStack_14._4_4_ != 0) {
    uVar2 = 0;
    FUN_005542c0("SceneGraphLoaded",0x10);
    FUN_005c54b0(uVar2);
  }
  uVar2 = 0;
  FUN_005542c0("SceneExported",0xd);
  FUN_005c54b0(uVar2);
  return;
}



/* FUNCTION 5272 ; VA 0x005c8160 ; FUN_005c8160 */

/* WARNING: Restarted to delay deadcode elimination for space: ram */

void __thiscall
FUN_005c8160(int param_1,int *param_2,undefined4 *param_3,undefined4 param_4,undefined4 *****param_5
            )

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  int iVar7;
  int iVar8;
  undefined **ppuVar9;
  undefined4 uVar10;
  undefined4 *****pppppuVar11;
  undefined4 ****ppppuVar12;
  undefined4 *puVar13;
  undefined4 *****pppppuVar14;
  undefined **ppuVar15;
  undefined4 *puVar16;
  undefined4 uStack_250;
  code **ppcStack_24c;
  undefined auStack_248 [148];
  undefined4 uStack_1b4;
  char *pcStack_1b0;
  undefined4 uStack_1ac;
  undefined uStack_1a8;
  undefined4 uStack_1a4;
  char *pcStack_1a0;
  undefined4 uStack_19c;
  uint uStack_198;
  undefined4 ****ppppuStack_194;
  undefined4 uStack_190;
  undefined4 ****ppppuStack_18c;
  undefined4 ****ppppuStack_188;
  undefined4 ****ppppuStack_184;
  undefined4 *puStack_180;
  undefined4 *puStack_17c;
  undefined4 uStack_168;
  undefined4 ****ppppuStack_164;
  undefined8 uStack_a0;
  undefined4 ***pppuStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  undefined auStack_80 [4];
  undefined *puStack_7c;
  undefined4 uStack_78;
  undefined4 ***pppuStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 ****appppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 uStack_50;
  undefined4 ****ppppuStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 ****ppppuStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 ****ppppuStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798e9a;
  pvStack_10 = ExceptionList;
  puStack_17c = (undefined4 *)0x0;
  puStack_180 = (undefined4 *)0x0;
  uStack_19c = 0xf;
  ppppuStack_188 = (undefined4 ****)0x0;
  ppppuStack_184 = (undefined4 ****)0xf;
  pcStack_1a0 = "ExportSplitObjs";
  uStack_198 = uStack_198 & 0xffffff00;
  uStack_1a4 = 0x5c81ab;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  FUN_005542c0();
  uStack_19c = 0x5c81b2;
  FUN_005c54b0();
  puStack_180 = (undefined4 *)0x5c81b8;
  puStack_17c = (undefined4 *)param_1;
  uStack_14 = FUN_005c3ac0();
  if (param_1 == 0) {
LAB_005c820e:
    uStack_34 = 0;
  }
  else {
    iVar8 = *(int *)(param_1 + 0x34);
    if ((iVar8 != 0) && (param_1 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
      puStack_17c = (undefined4 *)0x5c81d5;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) goto LAB_005c820e;
    iVar8 = *(int *)(param_1 + 0xc);
    puStack_17c = (undefined4 *)0x5c81e7;
    iVar7 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar7 + 0x1da) <
        (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) goto LAB_005c820e;
    puStack_17c = (undefined4 *)0x5c8209;
    uStack_34 = FUN_005c2a10();
  }
  if (iStack_24 == 0) {
LAB_005c8261:
    iVar8 = 0;
  }
  else {
    iVar8 = *(int *)(iStack_24 + 0x34);
    iVar7 = iStack_24;
    if ((iVar8 != 0) && (iVar7 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
      puStack_17c = (undefined4 *)0x5c822f;
      iVar7 = FUN_005c8ac0();
    }
    if (iVar7 == 0) goto LAB_005c8261;
    iVar8 = *(int *)(iVar7 + 0xc);
    puStack_17c = (undefined4 *)0x5c823d;
    iVar7 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar7 + 0x1da) <
        (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8)) goto LAB_005c8261;
    puStack_17c = (undefined4 *)0x5c825f;
    iVar8 = FUN_005c3230();
  }
  puStack_30 = (undefined4 *)0x0;
  puVar16 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  uStack_8 = 0;
  puVar13 = (undefined4 *)**(int **)(iVar8 + 0x58);
  iStack_18 = iVar8;
  if (puVar13 != (undefined4 *)(*(int **)(iVar8 + 0x58))[1]) {
    do {
      if (puVar16 == puStack_2c) {
        ppppuStack_184 = (undefined4 ****)0x5c82bd;
        puStack_180 = puStack_2c;
        puStack_17c = puVar13;
        FUN_005c1970();
        puVar16 = puStack_28;
      }
      else {
        *puStack_2c = 0;
        puStack_2c[1] = 0;
        if (puVar13[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar13[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puStack_2c = *puVar13;
        puStack_2c[1] = puVar13[1];
        puStack_2c = puStack_2c + 2;
      }
      puVar13 = puVar13 + 2;
    } while (puVar13 != *(undefined4 **)(*(int *)(iVar8 + 0x58) + 4));
  }
  puVar13 = puStack_30;
  puStack_17c = (undefined4 *)0x5c82d9;
  FUN_009e0150();
  puStack_17c = param_5;
  puStack_180 = (undefined4 *)0x0;
  ppppuStack_184 = (undefined4 ****)0x5c82e6;
  uVar6 = FUN_008ba510();
  uStack_50 = CONCAT31(uStack_50._1_3_,uVar6);
  ppppuStack_188 = (undefined4 ****)&puStack_180;
  ppppuStack_184 =
       (undefined4 ****)
       (-(uint)(*(int *)(iStack_24 + 0x34) != 0) & *(int *)(iStack_24 + 0x34) - 0xcU);
  pcVar2 = *(code **)(*param_2 + 0xc);
  ppppuStack_18c = (undefined4 ****)0x5c830c;
  FUN_005c4330();
  ppppuStack_184 = (undefined4 ****)0x5c8314;
  (*pcVar2)();
  ppppuStack_184 = &param_5;
  auStack_80[0] = 0;
  ppppuStack_188 = (undefined4 ****)&boost::lock_error::vftable_meta_ptr;
  ppppuStack_18c = (undefined4 ****)&DAT_018be100;
  param_5 = (undefined4 *****)&DAT_0000000b;
  uStack_190 = 0x5c8332;
  ppuVar9 = (undefined **)FUN_00563d40();
  puVar16 = puStack_2c;
  ppuVar15 = ppuVar9 + -1;
  if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar15 = ppuVar9;
  }
  puStack_7c = *ppuVar15;
  uStack_78 = 0;
  pppuStack_74 = (undefined4 ****)0x3f800000;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_8._0_1_ = 1;
  for (; puVar13 != puVar16; puVar13 = puVar13 + 2) {
    param_5 = (undefined4 *****)*puVar13;
    if (param_5 != (undefined4 *****)0x0) {
      ppppuStack_184 = (undefined4 ****)0x5c8385;
      FUN_009e0150();
      ppppuStack_184 = (undefined4 ****)*puVar13;
      ppppuStack_188 = (undefined4 ****)0x5c838f;
      FUN_009dffd0();
      uStack_58 = 0;
      uStack_54 = 0xf;
      appppuStack_68[0] = (undefined4 ****)((uint)appppuStack_68[0] & 0xffffff00);
      ppppuStack_184 = (undefined4 ****)&uStack_a0;
      ppppuStack_188 = (undefined4 ****)uStack_50;
      ppppuStack_18c = &pppuStack_98;
      uStack_8._0_1_ = 2;
      uStack_190 = param_4;
      ppppuStack_194 = appppuStack_68;
      uStack_a0 = 0;
      uStack_198 = 1;
      uStack_19c = 0;
      pcStack_1a0 = (char *)0x1;
      pppuStack_98 = (undefined4 ****)0x7f7fffff;
      uStack_94 = 0x7f7fffff;
      uStack_90 = 0x7f7fffff;
      uStack_8c = DAT_018c45d0;
      uStack_88 = DAT_018c45d0;
      uStack_84 = DAT_018c45d0;
      uStack_1a4 = 0x5c8411;
      (**(code **)(*param_2 + 0x6c))();
      uStack_3c = 0;
      ppppuStack_38 = (undefined4 *****)0x0;
      param_5 = (undefined4 *****)param_5[10];
      uStack_14 = (uint)param_5[4];
      if (0xf < param_5[5]) {
        param_5 = (undefined4 *****)*param_5;
      }
      if (uStack_14 < 0x10) {
        ppppuStack_4c = *param_5;
        uStack_48 = param_5[1];
        uStack_44 = param_5[2];
        uStack_40 = param_5[3];
        ppppuStack_38 = (undefined4 ****)&DAT_0000000f;
      }
      else {
        ppppuStack_1c = (undefined4 ****)(uStack_14 | 0xf);
        if ((undefined4 *****)0x7fffffff < ppppuStack_1c) {
          ppppuStack_1c = (undefined4 *****)0x7fffffff;
        }
        ppppuStack_184 = (undefined4 ****)((int)ppppuStack_1c + 1);
        if (ppppuStack_184 < &DAT_00001000) {
          if ((undefined4 *****)ppppuStack_184 == (undefined4 *****)0x0) {
            ppppuStack_18c = (undefined4 *****)0x0;
          }
          else {
            ppppuStack_188 = (undefined4 ****)0x5c84a2;
            ppppuStack_18c = (undefined4 ****)FUN_01674e20();
          }
        }
        else {
          pppppuVar11 = (undefined4 *****)ppppuStack_1c + 9;
          if (pppppuVar11 <= ppppuStack_184) {
            pppppuVar11 = (undefined4 *****)0xffffffff;
          }
          ppppuStack_188 = (undefined4 *****)0x5c8482;
          ppppuStack_184 = pppppuVar11;
          ppppuVar12 = (undefined4 ****)FUN_01674e20();
          if (ppppuVar12 == (undefined4 ****)0x0) goto LAB_005c8877;
          ppppuStack_18c = (undefined4 ****)((int)ppppuVar12 + 0x23U & 0xffffffe0);
          ((undefined4 *****)ppppuStack_18c)[-1] = ppppuVar12;
        }
        ppppuStack_184 = (undefined4 ****)(uStack_14 + 1);
        ppppuStack_188 = param_5;
        uStack_190 = 0x5c84bc;
        ppppuStack_4c = ppppuStack_18c;
        FUN_0170c6f0();
        ppppuStack_38 = ppppuStack_1c;
      }
      ppppuStack_184 = &ppppuStack_4c;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      ppppuStack_188 = (undefined4 *****)0x5c84db;
      uStack_3c = uStack_14;
      iVar8 = FUN_005c4c00();
      param_5 = (undefined4 *****)(iVar8 + 0x18);
      ppppuStack_184 = (undefined4 ****)0x5c84e6;
      uVar10 = FUN_0088cb40();
      *param_5 = (undefined4 ****)uVar10;
      ppppuStack_184 = (undefined4 ****)0x5c84f0;
      uStack_14 = FUN_005c9d30();
      uVar3 = (uint)param_5[1];
      ppppuStack_184 = param_5 + 2;
      if (uVar3 == uStack_14) {
        if ((undefined4 *****)ppppuStack_184 != appppuStack_68) {
          ppppuStack_184 = (undefined4 ****)uStack_58;
          ppppuStack_188 = appppuStack_68;
          if (0xf < uStack_54) {
            ppppuStack_188 = appppuStack_68[0];
          }
          ppppuStack_18c = (undefined4 *****)0x5c851a;
          FUN_005542c0();
        }
      }
      else {
        if (uVar3 != 0) {
          ppppuStack_188 = (undefined4 ****)0x5c8529;
          ppppuStack_1c = ppppuStack_184;
          (**(code **)(uVar3 + 8))();
          param_5[1] = (undefined4 ****)0x0;
        }
        ppppuStack_184 = appppuStack_68;
        ppppuStack_188 = (undefined4 *****)0x5c8542;
        FUN_0054ef60();
        param_5[1] = (undefined4 ****)uStack_14;
      }
      uStack_8._0_1_ = 2;
      if (&DAT_0000000f < ppppuStack_38) {
        ppppuStack_184 = (undefined4 ****)((int)ppppuStack_38 + 1);
        pppppuVar11 = (undefined4 *****)ppppuStack_4c;
        if ((undefined4 *****)0xfff < ppppuStack_184) {
          pppppuVar11 = (undefined4 *****)ppppuStack_4c[-1];
          ppppuStack_184 = ppppuStack_38 + 9;
          if ((undefined *)0x1f < (undefined *)((int)ppppuStack_4c + (-4 - (int)pppppuVar11)))
          goto LAB_005c8877;
        }
        ppppuStack_18c = (undefined4 *****)0x5c8580;
        ppppuStack_188 = pppppuVar11;
        FUN_01674ea0();
      }
      uStack_3c = 0;
      ppppuStack_38 = (undefined4 ****)&DAT_0000000f;
      ppppuStack_4c = (undefined4 ****)((uint)ppppuStack_4c & 0xffffff00);
      uStack_8._0_1_ = 1;
      if (0xf < uStack_54) {
        ppppuStack_184 = (undefined4 ****)(uStack_54 + 1);
        pppppuVar11 = (undefined4 *****)appppuStack_68[0];
        if (0xfff < ppppuStack_184) {
          pppppuVar11 = (undefined4 *****)appppuStack_68[0][-1];
          ppppuStack_184 = (undefined4 ****)(uStack_54 + 0x24);
          if ((undefined *)0x1f < (undefined *)((int)appppuStack_68[0] + (-4 - (int)pppppuVar11)))
          goto LAB_005c8877;
        }
        ppppuStack_18c = (undefined4 *****)0x5c85ca;
        ppppuStack_188 = pppppuVar11;
        FUN_01674ea0();
      }
    }
  }
  ppppuStack_184 = (undefined4 ****)0x18;
  ppppuStack_188 = (undefined4 ****)0x5c85df;
  pppppuVar11 = (undefined4 *****)FUN_01674e20();
  param_5 = pppppuVar11;
  if (pppppuVar11 == (undefined4 *****)0x0) {
    ppppuStack_188 = (undefined4 *****)0x0;
  }
  else {
    *(undefined *)pppppuVar11 = 0;
    ppppuStack_184 = (undefined4 ****)uStack_78;
    ppppuStack_188 = (undefined4 ****)0x5c85fc;
    ppppuVar12 = (undefined4 ****)FUN_005c9310();
    pppppuVar11[1] = ppppuVar12;
    pppppuVar11[2] = (undefined4 ****)0x0;
    pppppuVar11[3] = (undefined4 ****)pppuStack_74;
    pppppuVar11[4] = (undefined4 ****)0x0;
    pppppuVar11[5] = (undefined4 ****)0x0;
    ppppuStack_184 = (undefined4 ****)auStack_80;
    uStack_8._0_1_ = 5;
    ppppuStack_188 = (undefined4 ****)0x5c862d;
    FUN_005c9140();
    ppppuStack_188 = pppppuVar11;
  }
  ppppuStack_184 = (undefined4 ****)param_2;
  uStack_8._0_1_ = 1;
  uStack_20 = 0;
  ppppuStack_1c = (undefined4 *****)0x0;
  ppppuStack_18c = (undefined4 *****)0x5c864f;
  FUN_005c1af0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  ppppuStack_184 = (undefined4 ****)0x5c8658;
  uVar10 = FUN_008881d0();
  uStack_168 = uStack_20;
  ppppuStack_164 = ppppuStack_1c;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
    ppppuStack_184 = (undefined4 ****)&DAT_01ea8a9c;
    ppppuStack_188 = (undefined4 *****)0x5c8837;
    FUN_016f3809();
    if (DAT_01ea8a9c == -1) {
      ppppuStack_184 = (undefined4 ****)&DAT_01ea8a9c;
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      ppppuStack_188 = (undefined4 *****)0x5c886f;
      FUN_016f37bf();
    }
  }
  param_5 = (undefined4 *****)&uStack_250;
  uStack_8._0_1_ = 8;
  ppcStack_24c = (code **)0x0;
  uStack_250 = uVar10;
  (*DAT_01ea8a90)(&uStack_168,auStack_248);
  ppcStack_24c = &DAT_01ea8a90;
  puVar13 = (undefined4 *)FUN_009e5df0(&pppuStack_98);
  if (param_3 != puVar13) {
    uVar3 = param_3[5];
    if (0xf < uVar3) {
      pppppuVar11 = (undefined4 *****)*param_3;
      ppppuStack_184 = (undefined4 ****)(uVar3 + 1);
      pppppuVar14 = pppppuVar11;
      if (0xfff < ppppuStack_184) {
        pppppuVar14 = (undefined4 *****)pppppuVar11[-1];
        ppppuStack_184 = (undefined4 ****)(uVar3 + 0x24);
        if (0x1f < (uint)((int)pppppuVar11 + (-4 - (int)pppppuVar14))) goto LAB_005c8877;
      }
      ppppuStack_18c = (undefined4 *****)0x5c872f;
      ppppuStack_188 = pppppuVar14;
      FUN_01674ea0();
    }
    param_3[4] = 0;
    param_3[5] = 0xf;
    *(undefined *)param_3 = 0;
    uVar10 = puVar13[1];
    uVar4 = puVar13[2];
    uVar5 = puVar13[3];
    *param_3 = *puVar13;
    param_3[1] = uVar10;
    param_3[2] = uVar4;
    param_3[3] = uVar5;
    *(undefined8 *)(param_3 + 4) = *(undefined8 *)(puVar13 + 4);
    puVar13[4] = 0;
    puVar13[5] = 0xf;
    *(undefined *)puVar13 = 0;
  }
  if (0xf < uStack_84) {
    ppppuStack_184 = (undefined4 ****)(uStack_84 + 1);
    ppppuVar12 = (undefined4 ****)pppuStack_98;
    if (0xfff < ppppuStack_184) {
      ppppuVar12 = (undefined4 ****)pppuStack_98[-1];
      ppppuStack_184 = (undefined4 ****)(uStack_84 + 0x24);
      if (0x1f < (uint)((int)pppuStack_98 + (-4 - (int)ppppuVar12))) {
LAB_005c8877:
                    /* WARNING: Subroutine does not return */
        ppppuStack_184 = (undefined4 ****)&UNK_005c887c;
        FUN_017167a3();
      }
    }
    ppppuStack_18c = (undefined4 ****)0x5c8798;
    ppppuStack_188 = ppppuVar12;
    FUN_01674ea0();
  }
  ppppuStack_188 = (undefined4 ****)0x0;
  ppppuStack_184 = (undefined4 ****)0x0;
  ppppuStack_18c = (undefined4 ****)0x5c87b9;
  (**(code **)(*param_2 + 0xc))();
  ppppuStack_18c = (undefined4 ****)0x5c87c0;
  (**(code **)(*param_2 + 0x4c))();
  ppppuStack_18c = (undefined4 ****)0x0;
  uStack_190 = 0;
  uStack_1ac = 0x11;
  uStack_198 = 0;
  ppppuStack_194 = (undefined4 ****)0xf;
  pcStack_1b0 = "SplitObjsExported";
  uStack_1a8 = 0;
  uStack_1b4 = 0x5c87e6;
  FUN_005542c0();
  uStack_1ac = 0x5c87ee;
  FUN_005c54b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  ppppuStack_18c = (undefined4 ****)&uStack_168;
  uStack_190 = 0x5c8808;
  (*DAT_01ea8a98)();
  ppppuStack_18c = (undefined4 ****)0x5c8813;
  FUN_0056d080();
  ppppuStack_18c = (undefined4 ****)0x5c881b;
  thunk_FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5273 ; VA 0x005c8880 ; FUN_005c8880 */

int FUN_005c8880(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 5274 ; VA 0x005c88e0 ; FUN_005c88e0 */

undefined8 *
FUN_005c88e0(undefined8 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,
            undefined4 *param_6)

{
  undefined4 uVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined8 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ea8be8);
    if (puVar3 != (undefined8 *)0x0) {
      uVar1 = *(undefined4 *)(puVar3 + 1);
      *param_1 = *puVar3;
      *(undefined4 *)(param_1 + 1) = uVar1;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
      if (cVar2 != '\0') {
        puVar3 = (undefined8 *)FUN_0088a700();
        uVar1 = *(undefined4 *)(puVar3 + 1);
        *param_1 = *puVar3;
        *(undefined4 *)(param_1 + 1) = uVar1;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar3 = (undefined8 *)*param_6;
  if (puVar3 != (undefined8 *)0x0) {
    uVar1 = *(undefined4 *)(puVar3 + 1);
    *param_1 = *puVar3;
    *(undefined4 *)(param_1 + 1) = uVar1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 5275 ; VA 0x005c8a60 ; FUN_005c8a60 */

void __thiscall FUN_005c8a60(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x30);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x30);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x2c);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 5276 ; VA 0x005c8a90 ; thunk_FUN_005591a0 */

void thunk_FUN_005591a0(void)

{
  int iVar1;
  
  if (DAT_01ea8744 == 0) {
    iVar1 = FUN_00559080();
    DAT_01ea8744 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5277 ; VA 0x005c8aa0 ; FUN_005c8aa0 */

undefined4 __fastcall FUN_005c8aa0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x28);
}



/* FUNCTION 5278 ; VA 0x005c8ab0 ; FUN_005c8ab0 */

undefined4 __fastcall FUN_005c8ab0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}



/* FUNCTION 5279 ; VA 0x005c8ac0 ; FUN_005c8ac0 */

int __fastcall FUN_005c8ac0(int param_1)

{
  int iVar1;
  
  do {
    iVar1 = param_1;
    param_1 = *(int *)(iVar1 + 0x34);
  } while (param_1 != 0);
  return iVar1;
}



/* FUNCTION 5280 ; VA 0x005c8ae0 ; FUN_005c8ae0 */

undefined4 * FUN_005c8ae0(undefined4 *param_1)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  uint uVar9;
  undefined4 ****ppppuVar10;
  int iVar11;
  int iStack_1e4;
  byte abStack_1d8 [4];
  undefined auStack_1d4 [168];
  undefined auStack_12c [24];
  undefined auStack_114 [24];
  undefined auStack_fc [24];
  undefined auStack_e4 [24];
  undefined2 auStack_cc [8];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined2 auStack_b4 [8];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined2 auStack_9c [8];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined2 auStack_84 [8];
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [8];
  undefined4 ***apppuStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 ***apppuStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798fc5;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00554b40();
  if (cVar3 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("This method is not available");
  }
  puVar4 = (undefined4 *)FUN_00558ce0(auStack_6c,&stack0x00000008,&DAT_018bf1c0);
  uStack_bc = 0;
  uStack_b8 = 7;
  auStack_cc[0] = 0;
  iVar11 = puVar4[4];
  uStack_8._0_1_ = 2;
  if (iVar11 != 0) {
    puVar5 = puVar4;
    if (0xf < (uint)puVar4[5]) {
      puVar5 = (undefined4 *)*puVar4;
    }
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar6 = FUN_01686580();
    FUN_01685950(puVar4,iVar11 + (int)puVar5,auStack_cc,uVar6);
  }
  uStack_a4 = 0;
  uStack_a0 = 7;
  auStack_b4[0] = 0;
  uStack_8._0_1_ = 4;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  FUN_005542c0("modules",7);
  uStack_8._0_1_ = 5;
  if (iStack_18 != 0) {
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    iVar11 = (int)ppppuVar7 + iStack_18;
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    uVar6 = FUN_01686580();
    FUN_01685950(ppppuVar7,iVar11,auStack_b4,uVar6);
  }
  uStack_8._0_1_ = 4;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar8) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0][-1];
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar7))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar8);
  }
  uStack_8c = 0;
  uStack_88 = 7;
  auStack_9c[0] = 0;
  uStack_8._0_1_ = 7;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  FUN_005542c0("thumbnails",10);
  uStack_8._0_1_ = 8;
  if (iStack_18 != 0) {
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    iVar11 = (int)ppppuVar7 + iStack_18;
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    uVar6 = FUN_01686580();
    FUN_01685950(ppppuVar7,iVar11,auStack_9c,uVar6);
  }
  uStack_8._0_1_ = 7;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar8) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0][-1];
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar7))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar8);
  }
  uStack_74 = 0;
  uStack_70 = 7;
  auStack_84[0] = 0;
  uStack_8._0_1_ = 10;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  FUN_005542c0("internalscripts",0xf);
  uStack_8._0_1_ = 0xb;
  if (iStack_18 != 0) {
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    iVar11 = (int)ppppuVar7 + iStack_18;
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    uVar6 = FUN_01686580();
    FUN_01685950(ppppuVar7,iVar11,auStack_84,uVar6);
  }
  uStack_8._0_1_ = 10;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar8) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0][-1];
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar7))) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar8);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8._0_1_ = 0xc;
  uVar6 = FUN_01518d10(auStack_12c,0,3,0);
  uStack_8._0_1_ = 0xd;
  uVar6 = FUN_005514a0(auStack_114,uVar6,auStack_84);
  uStack_8._0_1_ = 0xe;
  uVar6 = FUN_005514a0(auStack_fc,uVar6,auStack_9c);
  uStack_8._0_1_ = 0xf;
  uVar6 = FUN_005514a0(auStack_e4,uVar6,auStack_b4);
  uStack_8._0_1_ = 0x10;
  FUN_005514a0(apppuStack_4c,uVar6,auStack_cc);
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  FUN_00550800();
  uStack_8._0_1_ = 0x1a;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1a;
  if (0xf < uStack_58) {
    uVar9 = uStack_58 + 1;
    uVar8 = auStack_6c[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_6c[0] - 4);
      uVar9 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  if (DAT_01d59104 != '\0') {
    uStack_8._0_1_ = 0x1b;
    iStack_18 = 0;
    uStack_14 = 0xf;
    apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
    uStack_34 = 2;
    if (iStack_3c != 0) {
      ppppuVar7 = apppuStack_4c;
      if (7 < uStack_38) {
        ppppuVar7 = (undefined4 ****)apppuStack_4c[0];
      }
      ppppuVar10 = apppuStack_4c;
      if (7 < uStack_38) {
        ppppuVar10 = (undefined4 ****)apppuStack_4c[0];
      }
      uVar6 = FUN_01686580();
      FUN_01685a20(ppppuVar10,(int)ppppuVar7 + iStack_3c * 2,apppuStack_28,uVar6);
    }
    ppppuVar7 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_01677520(DAT_01d59104,"Loading thumbnail module script file %s",ppppuVar7);
    uStack_8._0_1_ = 0x1a;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      ppppuVar7 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar8) {
        ppppuVar7 = (undefined4 ****)apppuStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar7,uVar8);
    }
  }
  ppppuVar7 = apppuStack_4c;
  if (7 < uStack_38) {
    ppppuVar7 = (undefined4 ****)apppuStack_4c[0];
  }
  FUN_0054ebd0(ppppuVar7,1,0x40,1);
  uStack_8._0_1_ = 0x1d;
  if ((abStack_1d8[*(int *)(iStack_1e4 + 4)] & 6) == 0) {
    FUN_00565940(3,1);
    uStack_8._0_1_ = 0x1e;
    FUN_0056f130(auStack_1d4);
    FUN_005c30b0(&piStack_30);
    uStack_8._0_1_ = 0x1f;
    (**(code **)(*piStack_30 + 0x38))(&stack0x00000008);
    *(undefined *)(piStack_30 + 0x3b) = 1;
    FUN_0058c420(auStack_6c);
    uStack_8._0_1_ = 0x20;
    uVar6 = FUN_00886c00(auStack_54,auStack_6c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x21);
    FUN_009ed830(uVar6);
    FUN_0056e380();
    FUN_0056e380();
    FUN_005507b0();
    piVar1 = piStack_30;
    piStack_30 = (int *)0x0;
    *param_1 = piVar1;
    param_1[1] = uStack_2c;
    uStack_2c = 0;
    FUN_005705c0();
    FUN_00551650();
    FUN_00550800();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Module with name %s does not exist",uVar6);
}



/* FUNCTION 5281 ; VA 0x005c90c0 ; FUN_005c90c0 */

undefined4 __thiscall FUN_005c90c0(int param_1,int param_2)

{
  return *(undefined4 *)(param_2 + *(int *)(param_1 + 8));
}



/* FUNCTION 5282 ; VA 0x005c90d0 ; FUN_005c90d0 */

void __thiscall FUN_005c90d0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  uVar3 = FUN_0088c8c0();
  *param_3 = uVar3;
  iVar4 = FUN_005c9cc0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 5283 ; VA 0x005c9130 ; FUN_005c9130 */

void __fastcall FUN_005c9130(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005c9136. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x14))();
  return;
}



/* FUNCTION 5284 ; VA 0x005c9140 ; FUN_005c9140 */

void __thiscall FUN_005c9140(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798fe0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 8) != 0) {
    ExceptionList = &pvStack_10;
    FUN_005c6680(*(undefined4 *)(param_1 + 4));
    uStack_8._1_3_ = 0;
    if (*(int *)(param_2 + 8) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar5 != (undefined4 *)0x0) {
      uStack_8._0_1_ = 0;
      puVar2 = (undefined4 *)FUN_01674e20(0xf0);
      *puVar2 = 0;
      puVar2[1] = 0;
      FUN_0170d1f0(puVar2 + 2,0,0xe8);
      FUN_0054ef60(puVar5 + 2);
      uStack_8._0_1_ = 1;
      puVar2[8] = puVar5[8];
      puVar2[9] = 0;
      puVar3 = (undefined4 *)puVar5[9];
      if (puVar3 != (undefined4 *)0x0) {
        (*(code *)*puVar3)(puVar5 + 10,puVar2 + 10);
        puVar3 = (undefined4 *)puVar5[9];
      }
      puVar2[9] = puVar3;
      puVar2[1] = puVar5[1];
      *puVar1 = puVar2;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar2 = (undefined4 *)*puVar1;
      puVar5 = (undefined4 *)*puVar5;
      uVar4 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
      puVar3 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
        *puVar3 = puVar1;
        puVar1 = puVar2;
      }
      else {
        *puVar1 = *puVar2;
        *puVar2 = *(undefined4 *)*puVar3;
        *(undefined4 **)*puVar3 = puVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5285 ; VA 0x005c92b0 ; FUN_005c92b0 */

uint __fastcall FUN_005c92b0(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(*(int *)(param_1 + 0xc) + 0x1d4);
  return CONCAT31((uint3)(uVar1 >> 10),~(byte)(uVar1 >> 2)) & 0xffffff01;
}



/* FUNCTION 5286 ; VA 0x005c92d0 ; FUN_005c92d0 */

undefined FUN_005c92d0(void)

{
  return 0;
}



/* FUNCTION 5287 ; VA 0x005c92e0 ; FUN_005c92e0 */

void __fastcall FUN_005c92e0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005c92e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x34) + 4))();
  return;
}



/* FUNCTION 5288 ; VA 0x005c92f0 ; FUN_005c92f0 */

undefined4 __thiscall FUN_005c92f0(int param_1,int param_2)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0x28) >> 8),*(int *)(param_1 + 0x28) == param_2);
}



/* FUNCTION 5289 ; VA 0x005c9300 ; FUN_005c9300 */

void __fastcall FUN_005c9300(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005c9308. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x34) + 8))();
  return;
}



/* FUNCTION 5290 ; VA 0x005c9310 ; FUN_005c9310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_005c9310(int param_1,int param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  float10 fVar3;
  
  fVar3 = (float10)FUN_01725280(((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]) /
                                (double)*(float *)(param_1 + 0xc));
  if ((double)fVar3 + DAT_018c0d60 < _DAT_018c4e98) {
    param_2 = FUN_016f3eb1();
  }
  else {
    param_2 = 0xffffffff;
  }
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar2 = ppuVar1 + -1;
  if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar1;
  }
  return *ppuVar2;
}



/* FUNCTION 5291 ; VA 0x005c93a0 ; FUN_005c93a0 */

void FUN_005c93a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 5292 ; VA 0x005c93e0 ; FUN_005c93e0 */

void __thiscall FUN_005c93e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_005c1970(puVar2,param_2);
  return;
}



/* FUNCTION 5293 ; VA 0x005c9430 ; FUN_005c9430 */

void __thiscall FUN_005c9430(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = param_1[1];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = param_1[1];
  }
  *param_2 = *param_1;
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 5294 ; VA 0x005c9460 ; FUN_005c9460 */

void __thiscall FUN_005c9460(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  FUN_005c6680(param_2);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
  while (puVar2 != (undefined4 *)0x0) {
    uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
      *piVar1 = (int)puVar4;
      puVar4 = puVar2;
    }
    else {
      *puVar4 = *puVar2;
      *puVar2 = *(undefined4 *)*piVar1;
      *(undefined4 **)*piVar1 = puVar2;
    }
    puVar2 = (undefined4 *)*puVar4;
  }
  return;
}



/* FUNCTION 5295 ; VA 0x005c94c0 ; FUN_005c94c0 */

void __thiscall FUN_005c94c0(int param_1,int *param_2,undefined4 param_3,int param_4,int param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  code *pcVar4;
  undefined uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint in_stack_ffffff00;
  undefined4 in_stack_ffffff04;
  undefined4 in_stack_ffffff08;
  undefined4 in_stack_ffffff0c;
  undefined4 uVar11;
  undefined4 uVar12;
  int *piStack_e8;
  int *piStack_e4;
  undefined auStack_a0 [48];
  undefined4 uStack_70;
  int iStack_6c;
  int iStack_5c;
  undefined4 uStack_50;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179902a;
  pvStack_10 = ExceptionList;
  piStack_e4 = (int *)0x0;
  piStack_e8 = (int *)0x0;
  uVar11 = 0;
  uVar12 = 0xf;
  uVar9 = in_stack_ffffff00 & 0xffffff00;
  ExceptionList = &pvStack_10;
  iStack_3c = param_1;
  FUN_005542c0("RenderThumb",0xb);
  FUN_005c54b0(uVar9,in_stack_ffffff04,in_stack_ffffff08,in_stack_ffffff0c,uVar11,uVar12);
  piStack_e4 = (int *)param_4;
  piStack_e8 = (int *)0x5c951c;
  iStack_40 = FUN_011603d0();
  cStack_11 = '\0';
  if (*(char *)(param_4 + 0x20) != '\0') {
    piStack_e8 = (int *)0x5c9532;
    piStack_e4 = (int *)param_1;
    iVar6 = FUN_005c2df0();
    *(undefined *)(iVar6 + 0xa8) = 0;
    piStack_e4 = (int *)0x5c9543;
    piStack_e4 = (int *)FUN_0115ee70();
    piStack_e8 = (int *)0x5c954b;
    FUN_009d86d0();
    if (iStack_40 == 2) {
      cStack_11 = '\x01';
      piStack_e4 = (int *)0x0;
    }
    else {
      piStack_e4 = (int *)0x3f800000;
    }
    piStack_e8 = (int *)0x5c956d;
    FUN_009d8690();
  }
  if (*(char *)(param_4 + 0x3c) != '\0') {
    piStack_e8 = (int *)0x5c957d;
    piStack_e4 = (int *)param_1;
    piVar7 = (int *)FUN_005c2df0();
    piStack_e8 = &iStack_2c;
    FUN_005c25e0();
    uStack_8 = 0;
    piStack_e4 = (int *)0x3f000000;
    piStack_e8 = (int *)0x5c95a1;
    FUN_009d9b10();
    piStack_e4 = (int *)&DAT_bf800000;
    piStack_e8 = (int *)0x5c95b1;
    FUN_009d9b40();
    piStack_e4 = (int *)(param_4 + 0x40);
    piStack_e8 = (int *)0x5c95c0;
    FUN_009d9ba0();
    piStack_e4 = (int *)0x0;
    piStack_e8 = piVar7;
    FUN_008a65e0();
    uStack_8 = 0xffffffff;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_28[1] + -1;
      piStack_28[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        piStack_e4 = (int *)0x5c95e4;
        (**(code **)*piStack_28)();
        LOCK();
        iVar6 = piStack_28[2] + -1;
        piStack_28[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          piStack_e4 = (int *)0x5c95f4;
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  piStack_e8 = (int *)0x5c95fa;
  piStack_e4 = (int *)param_1;
  piStack_20 = (int *)FUN_005c3ac0();
  iStack_38 = 0;
  uStack_1c = (ulonglong)(uint)uStack_1c;
  piStack_34 = (int *)0x0;
  piStack_30 = (int *)0x0;
  uStack_8 = 1;
  if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      piStack_e4 = (int *)0x5c9630;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar6 = *(int *)(param_1 + 0xc);
      piStack_e4 = (int *)0x5c9642;
      iVar8 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        piStack_e4 = (int *)0x5c9664;
        piStack_28 = (int *)FUN_005c2c60();
        goto LAB_005c9668;
      }
    }
  }
  piStack_28 = (int *)0x0;
LAB_005c9668:
  puVar2 = (undefined4 *)piStack_28[0xb];
  if (puVar2 != (undefined4 *)0x0) {
    piVar3 = (int *)puVar2[1];
    for (piVar7 = (int *)*puVar2; piVar7 != piVar3; piVar7 = piVar7 + 2) {
      iVar6 = *(int *)(*piVar7 + 0xc);
      piStack_e4 = (int *)0x5c968a;
      iVar8 = FUN_009d9200();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        if (piStack_30 == uStack_1c._4_4_) {
          piStack_e8 = uStack_1c._4_4_;
          piStack_e4 = piVar7;
          FUN_005c1970();
          uStack_1c = CONCAT44(piStack_34,(uint)uStack_1c);
        }
        else {
          *uStack_1c._4_4_ = 0;
          uStack_1c._4_4_[1] = 0;
          if (piVar7[1] != 0) {
            LOCK();
            piVar1 = (int *)(piVar7[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          *uStack_1c._4_4_ = *piVar7;
          uStack_1c._4_4_[1] = piVar7[1];
          piStack_34 = uStack_1c._4_4_ + 2;
          uStack_1c = CONCAT44(piStack_34,(uint)uStack_1c);
        }
      }
    }
  }
  piStack_e4 = (int *)0x5c9703;
  iVar6 = (**(code **)(*(int *)((int)piStack_20 + 0x144) + 4))();
  if ((iVar6 != 0) && (puVar2 = *(undefined4 **)(iVar6 + 0x2c), puVar2 != (undefined4 *)0x0)) {
    piVar3 = (int *)puVar2[1];
    for (piVar7 = (int *)*puVar2; piVar7 != piVar3; piVar7 = piVar7 + 2) {
      iVar6 = *(int *)(*piVar7 + 0xc);
      piStack_e4 = (int *)0x5c972a;
      iVar8 = FUN_009d9200();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        if (piStack_30 == uStack_1c._4_4_) {
          piStack_e8 = uStack_1c._4_4_;
          piStack_e4 = piVar7;
          FUN_005c1970();
        }
        else {
          *uStack_1c._4_4_ = 0;
          uStack_1c._4_4_[1] = 0;
          if (piVar7[1] != 0) {
            LOCK();
            piVar1 = (int *)(piVar7[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          *uStack_1c._4_4_ = *piVar7;
          uStack_1c._4_4_[1] = piVar7[1];
          piStack_34 = uStack_1c._4_4_ + 2;
        }
        uStack_1c = CONCAT44(piStack_34,(uint)uStack_1c);
      }
    }
  }
  uVar10 = 0;
  uVar9 = (int)uStack_1c._4_4_ - iStack_38 >> 3;
  if (uVar9 != 0) {
    do {
      piStack_e4 = (int *)0x5c97aa;
      FUN_008a5010();
      uVar10 = uVar10 + 1;
    } while (uVar10 < uVar9);
  }
  piStack_e4 = (int *)0x64;
  piStack_e8 = (int *)0x5c97b9;
  piStack_20 = (int *)FUN_01674e20();
  uStack_8._0_1_ = 2;
  if (piStack_20 == (int *)0x0) {
    piStack_e8 = (int *)0x0;
  }
  else {
    piStack_e4 = (int *)0x5c97ce;
    piStack_e8 = (int *)FUN_009d94f0();
  }
  piStack_e4 = (int *)param_4;
  uStack_8._0_1_ = 1;
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  FUN_005c1b80();
  uStack_8._0_1_ = 3;
  piStack_e4 = (int *)0x0;
  piStack_e8 = (int *)0x5c9804;
  FUN_009d96a0();
  piStack_e4 = (int *)0x0;
  piStack_e8 = piStack_28;
  FUN_008a65e0();
  piStack_e4 = (int *)(param_4 + 0x24);
  piStack_e8 = (int *)(uint)(*(char *)(param_4 + 0x20) == '\0');
  uVar5 = FUN_008ba510();
  piStack_28 = (int *)CONCAT31(piStack_28._1_3_,uVar5);
  piStack_e4 = (int *)0x5c9838;
  FUN_0114e0c0();
  piStack_e4 = (int *)0x4;
  piStack_e8 = *(int **)(param_4 + 0x1c);
  iVar6 = *(int *)(iStack_3c + 0x34);
  FUN_0115f610(*(undefined4 *)(param_4 + 0x18));
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_1c = 0;
  pcVar4 = *(code **)(*param_2 + 0xc);
  FUN_005c4330(&piStack_e8,-(uint)(iVar6 != 0) & iVar6 - 0xcU);
  (*pcVar4)();
  (**(code **)(*param_2 + 0x44))
            (uStack_50,*(undefined4 *)(param_4 + 0x18),*(undefined4 *)(param_4 + 0x1c),
             CONCAT31((int3)((uint)*param_2 >> 8),*(undefined *)(param_4 + 0x21)),piStack_28,
             param_4 + 0x24,&uStack_1c);
  (**(code **)(*param_2 + 0xc))(0,0);
  (**(code **)(*param_2 + 0x4c))();
  iVar6 = iStack_3c;
  if ((uint)uStack_1c != 0 || uStack_1c._4_4_ != (int *)0x0) {
    uVar5 = 0;
    FUN_005542c0("SceneGraphLoaded",0x10);
    iVar6 = iStack_3c;
    FUN_005c54b0(uVar5);
  }
  uVar5 = 0;
  FUN_005542c0("ThumbnailRendered",0x11);
  FUN_005c54b0(uVar5);
  if (cStack_11 == '\0') {
    FUN_0115fd10();
  }
  if (param_5 != 0) {
    FUN_0115f210();
    uStack_8._0_1_ = 5;
    FUN_0115f530(1);
    FUN_01160090(iStack_40,auStack_a0);
    FUN_005c39d0(uStack_70,iStack_6c + iStack_5c,param_5,param_4);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0115f2b0();
  }
  if (*(char *)(param_4 + 0x20) != '\0') {
    FUN_005c3ac0(iVar6);
    FUN_008ba510(0,param_4 + 0x24);
  }
  FUN_0115f820();
  piVar7 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piVar7 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  thunk_FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5296 ; VA 0x005c9a20 ; FUN_005c9a20 */

void __thiscall FUN_005c9a20(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005c9310(param_2);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005c6680(uVar3);
    return;
  }
  if (*(uint *)(param_1 + 0x10) < param_2) {
    uVar3 = (*(uint *)(param_1 + 8) >> 1) + *(int *)(param_1 + 8);
    if (param_2 < uVar3) {
      param_2 = uVar3;
    }
    iVar4 = FUN_005c9310(param_2);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005c6680(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar1 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  return;
}



/* FUNCTION 5297 ; VA 0x005c9ac0 ; FUN_005c9ac0 */

void __fastcall FUN_005c9ac0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x005c9ac3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x3c))();
  return;
}



/* FUNCTION 5298 ; VA 0x005c9ad0 ; FUN_005c9ad0 */

void __thiscall FUN_005c9ad0(int param_1,int param_2,int *param_3)

{
  if (*(int *)(*(int *)(param_1 + 8) + param_2) != *param_3) {
    *(int *)(*(int *)(param_1 + 8) + param_2) = *param_3;
    if (*(code **)(param_1 + 0x10) != (code *)0x0) {
      (**(code **)(param_1 + 0x10))(*(undefined4 *)(param_1 + 4));
    }
    FUN_008a4940(*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 5299 ; VA 0x005c9b10 ; FUN_005c9b10 */

void __thiscall FUN_005c9b10(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_dc [200];
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179904b;
  pvStack_10 = ExceptionList;
  iVar5 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088c8c0();
  if (iVar5 == iVar1) {
    iVar5 = *piVar4;
    iVar1 = FUN_0088c8c0();
    if (iVar5 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = piVar4 + 2;
    if (piVar4[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar5 = *piVar2;
  }
  else {
    puVar3 = (undefined4 *)piVar4[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(piVar4 + 2,auStack_dc);
      puVar3 = (undefined4 *)piVar4[1];
    }
    uStack_8 = 0;
    piVar4 = (int *)FUN_00889220();
    iVar5 = *piVar4;
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_dc);
    }
    uStack_8 = 0xffffffff;
  }
  param_3 = (int *)iVar5;
  (*pcStack_14)(param_2,&param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5300 ; VA 0x005c9c10 ; FUN_005c9c10 */

undefined4 * __thiscall FUN_005c9c10(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_10 [12];
  
  iVar1 = param_1[1];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    piVar3 = (int *)(iVar1 + 4);
    iVar1 = *(int *)(iVar1 + 4);
    while (iVar1 != 0) {
      LOCK();
      iVar2 = *piVar3;
      if (iVar1 == iVar2) {
        *piVar3 = iVar1 + 1;
        iVar2 = iVar1;
      }
      UNLOCK();
      if (iVar2 == iVar1) {
        *param_2 = *param_1;
        param_2[1] = param_1[1];
        return param_2;
      }
      iVar1 = *piVar3;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c21d80);
}



/* FUNCTION 5301 ; VA 0x005c9c90 ; FUN_005c9c90 */

undefined FUN_005c9c90(void)

{
  undefined uVar1;
  
  uVar1 = DAT_01ea8bc6;
  LOCK();
  DAT_01ea8bc6 = 1;
  UNLOCK();
  if (DAT_01ea8bc0 != 0) {
    FUN_0151f3f0();
    uVar1 = FUN_00586350();
    return uVar1;
  }
  return uVar1;
}



/* FUNCTION 5302 ; VA 0x005c9cc0 ; FUN_005c9cc0 */

undefined4 * FUN_005c9cc0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c18) {
    FUN_016f3809(&DAT_01ea8c18);
    if (DAT_01ea8c18 == -1) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
  }
  return &DAT_01ea8c0c;
}



/* FUNCTION 5303 ; VA 0x005c9d30 ; FUN_005c9d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005c9d30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
    FUN_016f3809(&DAT_01ea8c48);
    if (DAT_01ea8c48 == -1) {
      _DAT_01ea8c3c = FUN_005c65f0;
      _DAT_01ea8c40 = FUN_005c93a0;
      DAT_01ea8c44 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ea8c48);
    }
  }
  return &DAT_01ea8c3c;
}



/* FUNCTION 5304 ; VA 0x005c9da0 ; FUN_005c9da0 */

undefined4 * FUN_005c9da0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38) {
    FUN_016f3809(&DAT_01ea8c38);
    if (DAT_01ea8c38 == -1) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
  }
  return &DAT_01ea8c2c;
}



/* FUNCTION 5305 ; VA 0x005c9e10 ; FUN_005c9e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005c9e10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c08) {
    FUN_016f3809(&DAT_01ea8c08);
    if (DAT_01ea8c08 == -1) {
      _DAT_01ea8bfc = FUN_005c6600;
      _DAT_01ea8c00 = FUN_005c6600;
      DAT_01ea8c04 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c08);
    }
  }
  return &DAT_01ea8bfc;
}



/* FUNCTION 5306 ; VA 0x005c9e80 ; FUN_005c9e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_005c9e80(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c28) {
    FUN_016f3809(&DAT_01ea8c28);
    if (DAT_01ea8c28 == -1) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c28);
    }
  }
  return &DAT_01ea8c1c;
}



/* FUNCTION 5307 ; VA 0x005c9ef0 ; FUN_005c9ef0 */

undefined4 * FUN_005c9ef0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8bf8) {
    FUN_016f3809(&DAT_01ea8bf8);
    if (DAT_01ea8bf8 == -1) {
      DAT_01ea8bec = FUN_005c6640;
      DAT_01ea8bf0 = FUN_005c6640;
      DAT_01ea8bf4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8bf8);
    }
  }
  return &DAT_01ea8bec;
}



/* FUNCTION 5308 ; VA 0x005c9f60 ; FUN_005c9f60 */

void FUN_005c9f60(void)

{
  undefined4 *puVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  bool bVar7;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179907f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(4);
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    pcStack_14 = FUN_005ca050;
    iVar5 = FUN_005c3cd0(&pcStack_14);
    *piVar4 = iVar5;
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 1;
    cVar3 = FUN_0168a8f0();
    if (cVar3 == '\0') {
      uVar6 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar6);
    }
  }
  piVar2 = DAT_01ea8bc0;
  bVar7 = DAT_01ea8bc0 != (int *)0x0;
  DAT_01ea8bc0 = piVar4;
  if (bVar7) {
    uStack_8 = 3;
    FUN_016899e0();
    puVar1 = (undefined4 *)*piVar2;
    if (puVar1 != (undefined4 *)0x0) {
      LOCK();
      iVar5 = puVar1[1] + -1;
      puVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*puVar1)(0);
        uVar6 = GetProcessHeap(0,puVar1);
        HeapFree(uVar6);
      }
    }
    FUN_01674ea0(piVar2,4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5309 ; VA 0x005ca050 ; FUN_005ca050 */

void FUN_005ca050(void)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 ***pppuVar7;
  uint uVar8;
  uint uVar9;
  undefined **appuStack_104 [8];
  undefined uStack_e2;
  undefined uStack_d8;
  undefined4 auStack_d0 [10];
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_84;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined4 uStack_78;
  undefined4 **appuStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined uStack_54;
  undefined uStack_53;
  undefined2 uStack_52;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  char cStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017990c6;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed8;
  ExceptionList = &pvStack_10;
  FUN_005e4c40();
  uStack_80 = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 1;
  FUN_0114e0c0();
  appuStack_104[0] = ThumbnailRenderSettings::vftable;
  uStack_d8 = 1;
  uStack_e2 = 0;
  FUN_0147bc80();
  auStack_d0[0] = uStack_1c;
  thunk_FUN_01747ee0();
  piStack_18 = (int *)FUN_0114e040(4,auStack_d0,appuStack_104);
  while( true ) {
    if (DAT_01ea8bc6 != '\0') {
      if (piStack_18 != (int *)0x0) {
        (**(code **)(*piStack_18 + 0x90))(1);
      }
      FUN_005e4d00();
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0151f430();
    piVar4 = piStack_18;
    uStack_64 = 0;
    uStack_60 = 0xf;
    appuStack_74[0] = (undefined4 **)((uint)appuStack_74[0] & 0xffffff00);
    uStack_50 = 0x7f7fffff;
    uStack_4c = 0x7f7fffff;
    uStack_48 = 0x7f7fffff;
    uStack_44 = DAT_018c45d0;
    uStack_40 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
    cStack_38 = '\0';
    puStack_84 = &DAT_01ea8bb8;
    do {
      LOCK();
      uVar2 = DAT_01ea8bb8 & 1;
      DAT_01ea8bb8 = DAT_01ea8bb8 | 1;
      UNLOCK();
    } while (uVar2 != 0);
    uStack_8._0_1_ = 3;
    if (DAT_01ea8bb4 != 0) break;
    DAT_01ea8bb8 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005c4b70();
  }
  puVar5 = DAT_01ea8ba4;
  if (DAT_01ea8ba4 != (undefined4 *)0x0) {
    puVar5 = (undefined4 *)*DAT_01ea8ba4;
  }
  puVar5 = *(undefined4 **)(puVar5[1] + (puVar5[2] - 1 & DAT_01ea8bb0) * 4);
  uStack_78 = *puVar5;
  pppuVar7 = (undefined4 ***)(puVar5 + 1);
  puStack_7c = puVar5;
  if (appuStack_74 != pppuVar7) {
    if (0xf < (uint)puVar5[6]) {
      pppuVar7 = (undefined4 ***)*pppuVar7;
    }
    FUN_005542c0(pppuVar7,puVar5[5]);
  }
  uStack_5c = puVar5[7];
  uStack_58 = puVar5[8];
  uStack_54 = *(undefined *)(puVar5 + 9);
  uStack_53 = *(undefined *)((int)puVar5 + 0x25);
  uStack_50 = puVar5[10];
  uStack_4c = puVar5[0xb];
  uStack_48 = puVar5[0xc];
  uStack_44 = puVar5[0xd];
  uStack_40 = *(undefined8 *)(puVar5 + 0xe);
  if (cStack_38 == '\0') {
    if (*(char *)(puVar5 + 0x10) != '\0') {
      uStack_34 = *(undefined8 *)(puVar5 + 0x11);
      uStack_2c = puVar5[0x13];
      cStack_38 = '\x01';
    }
  }
  else if (*(char *)(puVar5 + 0x10) == '\0') {
    cStack_38 = '\0';
  }
  else {
    uStack_34 = *(undefined8 *)(puVar5 + 0x11);
    uStack_2c = puVar5[0x13];
  }
  uStack_28 = puStack_7c[0x14];
  puStack_24 = (uint *)puStack_7c[0x15];
  uStack_20 = puStack_7c[0x16];
  FUN_005c4b70();
  DAT_01ea8bb4 = DAT_01ea8bb4 + -1;
  if (DAT_01ea8bb4 == 0) {
    DAT_01ea8bb0 = 0;
  }
  else {
    DAT_01ea8bb0 = DAT_01ea8bb0 + 1;
  }
  DAT_01ea8bb8 = 0;
  uStack_8._0_1_ = 4;
  FUN_008e9960(uStack_78);
  pppuVar7 = appuStack_74;
  if (0xf < uStack_60) {
    pppuVar7 = (undefined4 ***)appuStack_74[0];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar6 = FUN_01717aae(pppuVar7,&DAT_018c4a18);
  if (iVar6 == 0) {
    FUN_005c8010(piVar4,uStack_5c,uStack_58,
                 CONCAT13((undefined)uStack_50,CONCAT21(uStack_52,uStack_53)),&uStack_50,uStack_28);
  }
  else {
    pppuVar7 = appuStack_74;
    if (0xf < uStack_60) {
      pppuVar7 = (undefined4 ***)appuStack_74[0];
    }
    iVar6 = FUN_01717aae(pppuVar7,"splitobjs");
    if (iVar6 == 0) {
      FUN_005c8160(piVar4,uStack_28,CONCAT13((undefined)uStack_50,CONCAT21(uStack_52,uStack_53)),
                   &uStack_50);
    }
    else {
      FUN_005c94c0(piVar4,uStack_1c,appuStack_74,uStack_28);
    }
  }
  puVar3 = puStack_24;
  uStack_98 = 0;
  uStack_94 = 0xf;
  uStack_a8 = uStack_a8 & 0xffffff00;
  if (puStack_24 != &uStack_a8) {
    uVar2 = puStack_24[5];
    if (0xf < uVar2) {
      uVar1 = *puStack_24;
      uVar9 = uVar2 + 1;
      uVar8 = uVar1;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uVar1 - 4);
        uVar9 = uVar2 + 0x24;
        if (0x1f < (uVar1 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    puVar3[5] = 0xf;
    *puVar3 = uStack_a8;
    puVar3[1] = uStack_a4;
    puVar3[2] = uStack_a0;
    puVar3[3] = uStack_9c;
    *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_94,uStack_98);
  }
  FUN_008eb200();
  FUN_005ca424();
  return;
}



/* FUNCTION 5310 ; VA 0x005ca3a5 ; Catch@005ca3a5 */

undefined * Catch_005ca3a5(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x84) + 4))();
  *(undefined4 *)(unaff_EBP + -0xac) = 0;
  *(undefined4 *)(unaff_EBP + -0xa8) = 0xf;
  *(undefined *)(unaff_EBP + -0xbc) = 0;
  FUN_005542c0("renderThumb failed: ",0x14);
  *(undefined *)(unaff_EBP + -4) = 7;
  uVar1 = FUN_00558c80(unaff_EBP + -0x118,unaff_EBP + -0xbc,uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  FUN_005507b0();
  return &DAT_005ca421;
}



/* FUNCTION 5311 ; VA 0x005ca424 ; FUN_005ca424 */

void FUN_005ca424(void)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  int unaff_EBP;
  undefined4 unaff_ESI;
  
  *(undefined4 *)(unaff_EBP + -4) = 2;
  FUN_0151f3f0();
  while( true ) {
    *(uint **)(unaff_EBP + -0x80) = &DAT_01ea8bb8;
    do {
      LOCK();
      uVar1 = DAT_01ea8bb8 & 1;
      DAT_01ea8bb8 = DAT_01ea8bb8 | 1;
      UNLOCK();
    } while (uVar1 != 0);
    *(undefined *)(unaff_EBP + -4) = 3;
    if (DAT_01ea8bb4 != 0) break;
    DAT_01ea8bb8 = 0;
    *(undefined *)(unaff_EBP + -4) = 1;
    FUN_005c4b70();
    if (DAT_01ea8bc6 != '\0') {
      if (*(int **)(unaff_EBP + -0x14) != (int *)0x0) {
        (**(code **)(**(int **)(unaff_EBP + -0x14) + 0x90))(1);
      }
      FUN_005e4d00();
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return;
    }
    FUN_0151f430();
    uVar2 = DAT_018c45d0;
    *(undefined4 *)(unaff_EBP + -0x60) = 0;
    *(undefined4 *)(unaff_EBP + -0x5c) = 0xf;
    *(undefined *)(unaff_EBP + -0x70) = 0;
    *(undefined4 *)(unaff_EBP + -0x4c) = 0x7f7fffff;
    *(undefined4 *)(unaff_EBP + -0x48) = 0x7f7fffff;
    *(undefined4 *)(unaff_EBP + -0x44) = 0x7f7fffff;
    *(undefined4 *)(unaff_EBP + -0x40) = uVar2;
    *(undefined4 *)(unaff_EBP + -0x3c) = uVar2;
    *(undefined4 *)(unaff_EBP + -0x38) = uVar2;
    *(undefined *)(unaff_EBP + -0x34) = 0;
    unaff_ESI = *(undefined4 *)(unaff_EBP + -0x14);
  }
  puVar7 = DAT_01ea8ba4;
  if (DAT_01ea8ba4 != (undefined4 *)0x0) {
    puVar7 = (undefined4 *)*DAT_01ea8ba4;
  }
  puVar7 = *(undefined4 **)(puVar7[1] + (puVar7[2] - 1 & DAT_01ea8bb0) * 4);
  *(undefined4 **)(unaff_EBP + -0x78) = puVar7;
  piVar8 = puVar7 + 1;
  *(undefined4 *)(unaff_EBP + -0x74) = *puVar7;
  puVar11 = puVar7;
  if ((int *)(unaff_EBP + -0x70) != piVar8) {
    if (0xf < (uint)puVar7[6]) {
      piVar8 = (int *)*piVar8;
    }
    FUN_005542c0(piVar8,puVar7[5]);
    puVar11 = *(undefined4 **)(unaff_EBP + -0x78);
  }
  *(undefined4 *)(unaff_EBP + -0x58) = puVar7[7];
  *(undefined4 *)(unaff_EBP + -0x54) = puVar7[8];
  *(undefined *)(unaff_EBP + -0x50) = *(undefined *)(puVar7 + 9);
  *(undefined *)(unaff_EBP + -0x4f) = *(undefined *)((int)puVar7 + 0x25);
  uVar2 = puVar7[0xb];
  uVar3 = puVar7[0xc];
  uVar4 = puVar7[0xd];
  *(undefined4 *)(unaff_EBP + -0x4c) = puVar7[10];
  *(undefined4 *)(unaff_EBP + -0x48) = uVar2;
  *(undefined4 *)(unaff_EBP + -0x44) = uVar3;
  *(undefined4 *)(unaff_EBP + -0x40) = uVar4;
  *(undefined8 *)(unaff_EBP + -0x3c) = *(undefined8 *)(puVar7 + 0xe);
  if (*(char *)(unaff_EBP + -0x34) == '\0') {
    if (*(char *)(puVar7 + 0x10) != '\0') {
      *(undefined8 *)(unaff_EBP + -0x30) = *(undefined8 *)(puVar7 + 0x11);
      *(undefined4 *)(unaff_EBP + -0x28) = puVar7[0x13];
      *(undefined *)(unaff_EBP + -0x34) = 1;
    }
  }
  else if (*(char *)(puVar7 + 0x10) == '\0') {
    *(undefined *)(unaff_EBP + -0x34) = 0;
  }
  else {
    *(undefined4 *)(unaff_EBP + -0x30) = puVar7[0x11];
    *(undefined4 *)(unaff_EBP + -0x2c) = puVar7[0x12];
    *(undefined4 *)(unaff_EBP + -0x28) = puVar7[0x13];
  }
  *(undefined4 *)(unaff_EBP + -0x24) = puVar11[0x14];
  *(undefined4 *)(unaff_EBP + -0x20) = puVar11[0x15];
  *(undefined4 *)(unaff_EBP + -0x1c) = puVar11[0x16];
  FUN_005c4b70();
  DAT_01ea8bb4 = DAT_01ea8bb4 + -1;
  if (DAT_01ea8bb4 == 0) {
    DAT_01ea8bb0 = 0;
  }
  else {
    DAT_01ea8bb0 = DAT_01ea8bb0 + 1;
  }
  DAT_01ea8bb8 = 0;
  *(undefined *)(unaff_EBP + -4) = 4;
  FUN_008e9960(*(undefined4 *)(unaff_EBP + -0x74));
  iVar9 = unaff_EBP + -0x70;
  if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
    iVar9 = *(int *)(unaff_EBP + -0x70);
  }
  *(undefined *)(unaff_EBP + -4) = 5;
  iVar9 = FUN_01717aae(iVar9,&DAT_018c4a18);
  if (iVar9 == 0) {
    FUN_005c8010(unaff_ESI,*(undefined4 *)(unaff_EBP + -0x58),*(undefined4 *)(unaff_EBP + -0x54),
                 *(undefined4 *)(unaff_EBP + -0x4f),unaff_EBP + -0x4c,
                 *(undefined4 *)(unaff_EBP + -0x24));
  }
  else {
    iVar9 = unaff_EBP + -0x70;
    if (0xf < *(uint *)(unaff_EBP + -0x5c)) {
      iVar9 = *(int *)(unaff_EBP + -0x70);
    }
    iVar9 = FUN_01717aae(iVar9,"splitobjs");
    if (iVar9 == 0) {
      FUN_005c8160(unaff_ESI,*(undefined4 *)(unaff_EBP + -0x24),*(undefined4 *)(unaff_EBP + -0x4f),
                   unaff_EBP + -0x4c);
    }
    else {
      FUN_005c94c0(unaff_ESI,*(undefined4 *)(unaff_EBP + -0x18),unaff_EBP + -0x70,
                   *(undefined4 *)(unaff_EBP + -0x24));
    }
  }
  piVar8 = *(int **)(unaff_EBP + -0x20);
  *(undefined4 *)(unaff_EBP + -0x94) = 0;
  *(undefined4 *)(unaff_EBP + -0x90) = 0xf;
  *(undefined *)(unaff_EBP + -0xa4) = 0;
  if (piVar8 != (int *)(unaff_EBP + -0xa4)) {
    uVar1 = piVar8[5];
    if (0xf < uVar1) {
      iVar9 = *piVar8;
      uVar12 = uVar1 + 1;
      iVar10 = iVar9;
      if (0xfff < uVar12) {
        iVar10 = *(int *)(iVar9 + -4);
        uVar12 = uVar1 + 0x24;
        if (0x1f < (iVar9 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar10,uVar12);
    }
    iVar9 = *(int *)(unaff_EBP + -0xa4);
    iVar10 = *(int *)(unaff_EBP + -0xa0);
    iVar5 = *(int *)(unaff_EBP + -0x9c);
    iVar6 = *(int *)(unaff_EBP + -0x98);
    piVar8[5] = 0xf;
    *piVar8 = iVar9;
    piVar8[1] = iVar10;
    piVar8[2] = iVar5;
    piVar8[3] = iVar6;
    *(undefined8 *)(piVar8 + 4) = *(undefined8 *)(unaff_EBP + -0x94);
  }
  FUN_008eb200();
  FUN_005ca424();
  return;
}



/* FUNCTION 5312 ; VA 0x005ca490 ; FUN_005ca490 */

char * FUN_005ca490(void)

{
  return "bad_weak_ptr";
}



/* FUNCTION 5313 ; VA 0x005ca4a0 ; FUN_005ca4a0 */

void FUN_005ca4a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_005cb2b0(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  return;
}



/* FUNCTION 5314 ; VA 0x005ca4f0 ; FUN_005ca4f0 */

int __thiscall FUN_005ca4f0(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017990d0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  iVar1 = (param_1[1] - iVar4) / 0xd0;
  if (iVar1 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar1 + 1;
  uVar2 = (param_1[2] - iVar4) / 0xd0;
  uVar8 = uVar7;
  if ((uVar2 <= 0x13b13b1 - (uVar2 >> 1)) && (uVar8 = (uVar2 >> 1) + uVar2, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00578090(uVar8);
  uStack_8 = 0;
  iVar4 = ((param_2 - iVar4) / 0xd0) * 0xd0;
  iVar5 = iVar4 + iVar3;
  FUN_005caaf0(param_1,iVar5,param_3);
  if (param_2 == param_1[1]) {
    FUN_0055c5a0(*param_1,param_1[1],iVar3,param_1);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar3);
    FUN_005cb700(param_2,param_1[1],iVar5 + 0xd0);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00559720(*param_1,param_1[1],param_1);
    uVar7 = ((param_1[2] - *param_1) / 0xd0) * 0xd0;
    iVar5 = *param_1;
    iVar6 = iVar5;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  *param_1 = iVar3;
  param_1[1] = (iVar1 + 1) * 0xd0 + iVar3;
  param_1[2] = uVar8 * 0xd0 + iVar3;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 5315 ; VA 0x005ca697 ; Catch_All@005ca697 */

void Catch_All_005ca697(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5316 ; VA 0x005ca6d0 ; FUN_005ca6d0 */

void FUN_005ca6d0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  
  uVar4 = 0;
  uVar2 = (uint)((int)param_2 + (3 - (int)param_1)) >> 2;
  if (param_2 < param_1) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    puVar5 = param_1;
    if (3 < uVar2) {
      uVar1 = *param_3;
      if ((param_3 < param_1) || (param_1 + (uVar2 - 1) < param_3)) {
        do {
          uVar4 = uVar4 + 4;
        } while (uVar4 != (uVar2 & 0xfffffffc));
        puVar5 = param_1 + (uVar2 & 0xfffffffc);
        for (uVar3 = uVar2 & 0x3ffffffc; uVar3 != 0; uVar3 = uVar3 - 1) {
          *param_1 = uVar1;
          param_1 = param_1 + 1;
        }
      }
    }
    for (; uVar4 != uVar2; uVar4 = uVar4 + 1) {
      *puVar5 = *param_3;
      puVar5 = puVar5 + 1;
    }
  }
  return;
}



/* FUNCTION 5317 ; VA 0x005ca750 ; FUN_005ca750 */

void __thiscall FUN_005ca750(int param_1,int *param_2,undefined4 *param_3,int *param_4)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char cVar5;
  int *piVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017990e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar9 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar9 = (undefined4 *)*param_3;
  }
  uVar8 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar8 + (int)puVar9);
      uVar8 = uVar8 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar8 < (uint)param_3[4]);
  }
  iVar11 = *(int *)(param_1 + 4);
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar10) * 8;
  piVar6 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  ExceptionList = &pvStack_10;
  if (iVar11 != *piVar6) {
    iVar11 = *(int *)piVar6[1];
    ExceptionList = &pvStack_10;
    while (iVar11 != *piVar6) {
      iVar11 = *(int *)(iVar11 + 4);
      piVar7 = (int *)(iVar11 + 8);
      if (0xf < *(uint *)(iVar11 + 0x1c)) {
        piVar7 = (int *)*piVar7;
      }
      puVar9 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar9 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar9,param_3[4],piVar7,*(undefined4 *)(iVar11 + 0x18));
      if (cVar5 != '\0') {
        *(int *)param_4[1] = *param_4;
        *(int *)(*param_4 + 4) = param_4[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        FUN_005cb4a0(param_4);
        *param_2 = iVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  iVar3 = *param_4;
  if (iVar11 != iVar3) {
    *(int *)param_4[1] = iVar3;
    **(int **)(iVar3 + 4) = iVar11;
    **(undefined4 **)(iVar11 + 4) = param_4;
    iVar4 = *(int *)(iVar11 + 4);
    *(undefined4 *)(iVar11 + 4) = *(undefined4 *)(iVar3 + 4);
    *(int *)(iVar3 + 4) = param_4[1];
    param_4[1] = iVar4;
  }
  piVar6 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if (*piVar6 == *(int *)(param_1 + 4)) {
    *piVar6 = (int)param_4;
    *(int **)(*(int *)(param_1 + 0xc) + 4 + iVar2) = param_4;
  }
  else if (*piVar6 == iVar11) {
    *piVar6 = (int)param_4;
  }
  else {
    piVar7 = *(int **)piVar6[1];
    piVar6[1] = (int)piVar7;
    if (piVar7 != param_4) {
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar2) =
           *(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4 + iVar2) + 4);
    }
  }
  uStack_8 = 2;
  FUN_005cb370();
  *param_2 = (int)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5318 ; VA 0x005ca8d1 ; Catch_All@005ca8d1 */

void Catch_All_005ca8d1(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + 0xc));
  FUN_005cc1c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5319 ; VA 0x005ca900 ; FUN_005ca900 */

void __thiscall FUN_005ca900(int param_1,int *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017990f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar2 = param_3[4];
  puVar8 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar8 = (undefined4 *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (uVar2 != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)puVar8);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < uVar2);
  }
  iVar9 = (*(uint *)(param_1 + 0x18) & uVar10) * 8;
  piVar12 = *(int **)(param_1 + 4);
  piVar5 = (int *)(*(int *)(param_1 + 0xc) + iVar9);
  ExceptionList = &pvStack_10;
  if (piVar12 != (int *)*piVar5) {
    piVar12 = *(int **)piVar5[1];
    ExceptionList = &pvStack_10;
    while (piVar12 != (int *)*piVar5) {
      piVar12 = (int *)piVar12[1];
      piVar11 = piVar12 + 2;
      if (0xf < (uint)piVar12[7]) {
        piVar11 = (int *)*piVar11;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar4 = FUN_0055c360(puVar8,uVar2,piVar11,piVar12[6]);
      if (cVar4 != '\0') {
        *param_2 = (int)piVar12;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  uStack_8 = 0xffffffff;
  iVar3 = **(int **)(param_1 + 4);
  puVar8 = *(undefined4 **)(iVar3 + 4);
  uVar6 = FUN_005ca4a0(iVar3,puVar8,param_3);
  if (*(int *)(param_1 + 8) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *(undefined4 *)(iVar3 + 4) = uVar6;
  *puVar8 = uVar6;
  piVar5 = *(int **)(param_1 + 4);
  puVar8 = (undefined4 *)*piVar5;
  piVar11 = (int *)*puVar8;
  if (piVar12 != piVar11) {
    *(int **)puVar8[1] = piVar11;
    *(int **)piVar11[1] = piVar12;
    *(undefined4 **)piVar12[1] = puVar8;
    iVar3 = piVar12[1];
    piVar12[1] = piVar11[1];
    piVar11[1] = puVar8[1];
    puVar8[1] = iVar3;
    piVar5 = *(int **)(param_1 + 4);
  }
  piVar11 = (int *)(iVar9 + *(int *)(param_1 + 0xc));
  if ((int *)*piVar11 == piVar5) {
    *piVar11 = (int)puVar8;
    *(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar9) = puVar8;
  }
  else if ((int *)*piVar11 == piVar12) {
    *piVar11 = (int)puVar8;
  }
  else {
    iVar3 = *(int *)piVar11[1];
    piVar11[1] = iVar3;
    if ((undefined4 *)iVar3 != puVar8) {
      iVar9 = iVar9 + *(int *)(param_1 + 0xc);
      *(undefined4 *)(iVar9 + 4) = *(undefined4 *)(*(int *)(iVar9 + 4) + 4);
    }
  }
  uStack_8 = 2;
  FUN_005cb370();
  *param_2 = (int)puVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5320 ; VA 0x005caab0 ; Catch_All@005caab0 */

void Catch_All_005caab0(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_005cc1c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5321 ; VA 0x005caaf0 ; FUN_005caaf0 */

void FUN_005caaf0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179910b;
  pvStack_10 = ExceptionList;
  puVar1 = param_3 + 2;
  ExceptionList = &pvStack_10;
  *param_2 = *param_3;
  param_2[1] = 0;
  iVar2 = param_3[1];
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 4))(puVar1,param_2 + 2);
    iVar2 = param_3[1];
  }
  param_2[1] = iVar2;
  if (param_3[1] != 0) {
    (**(code **)(param_3[1] + 8))(puVar1);
    param_3[1] = 0;
  }
  uStack_8 = 0;
  uVar3 = FUN_00888530();
  *param_3 = uVar3;
  if (param_3[1] != 0) {
    (**(code **)(param_3[1] + 8))(puVar1);
    param_3[1] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5322 ; VA 0x005cab90 ; FUN_005cab90 */

void __thiscall FUN_005cab90(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_005caaf0(param_1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xd0;
    return;
  }
  FUN_005ca4f0(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 5323 ; VA 0x005cabd0 ; FUN_005cabd0 */

void FUN_005cabd0(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179912f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x20);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<class_PBRSynth::Image<struct_PBRSynth::Vec<unsigned_char,4>_>_>::
              vftable;
    FUN_005cad90(param_2);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5324 ; VA 0x005cac50 ; FUN_005cac50 */

void __thiscall FUN_005cac50(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 5325 ; VA 0x005cacb0 ; FUN_005cacb0 */

undefined4 FUN_005cacb0(char *param_1)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar2 = param_1;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_1,(int)pcVar2 - (int)(param_1 + 1));
  uStack_8 = 0;
  cVar1 = FUN_009ee5c0(auStack_38,&uStack_14);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    uVar3 = auStack_38[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_38[0] - 4);
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return uStack_14;
  }
  FUN_016756b0(auStack_20,"deserializeTexturePack: unable to parse %s.",param_1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 5326 ; VA 0x005cad90 ; FUN_005cad90 */

undefined4 * __thiscall FUN_005cad90(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_1 != param_2) {
    FUN_01674ea0(0);
    *param_1 = *param_2;
    param_1[1] = param_2[1];
    param_1[2] = param_2[2];
    param_1[3] = param_2[3];
    param_1[4] = param_2[4];
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
  }
  return param_1;
}



/* FUNCTION 5327 ; VA 0x005cae20 ; FUN_005cae20 */

undefined4 * __fastcall FUN_005cae20(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 5328 ; VA 0x005cae50 ; FUN_005cae50 */

undefined4 __thiscall FUN_005cae50(undefined4 param_1,undefined4 param_2)

{
  FUN_0054ef60(param_2);
  return param_1;
}



/* FUNCTION 5329 ; VA 0x005cae70 ; FUN_005cae70 */

undefined4 * __fastcall FUN_005cae70(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798678;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RCCTexturePackGenerator,class_RBX::Instance>::vftable;
  uVar1 = FUN_00558f80();
  param_1[3] = uVar1;
  *(undefined *)(param_1 + 0x15) = 1;
  *param_1 = RCCTexturePackGenerator::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5330 ; VA 0x005caee0 ; FUN_005caee0 */

undefined * __fastcall FUN_005caee0(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 5331 ; VA 0x005caf00 ; FUN_005caf00 */

undefined4 * __thiscall FUN_005caf00(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179916b;
  pvStack_10 = ExceptionList;
  puVar1 = param_2 + 2;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  iVar2 = param_2[1];
  if (iVar2 != 0) {
    (**(code **)(iVar2 + 4))(puVar1,param_1 + 2);
    iVar2 = param_2[1];
  }
  param_1[1] = iVar2;
  if (param_2[1] != 0) {
    (**(code **)(param_2[1] + 8))(puVar1);
    param_2[1] = 0;
  }
  uStack_8 = 0;
  uVar3 = FUN_00888530();
  *param_2 = uVar3;
  if (param_2[1] != 0) {
    (**(code **)(param_2[1] + 8))(puVar1);
    param_2[1] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5332 ; VA 0x005cafa0 ; FUN_005cafa0 */

void __fastcall FUN_005cafa0(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x10));
  return;
}



/* FUNCTION 5333 ; VA 0x005cafb0 ; FUN_005cafb0 */

void __fastcall FUN_005cafb0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_005cb010();
  return;
}



/* FUNCTION 5334 ; VA 0x005cb010 ; FUN_005cb010 */

void __fastcall FUN_005cb010(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[7];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[2];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[6] = 0;
      piVar7[7] = 0xf;
      *(undefined *)(piVar7 + 2) = 0;
      FUN_01674ea0(piVar7,0x20);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x20);
  return;
}



/* FUNCTION 5335 ; VA 0x005cb0a0 ; FUN_005cb0a0 */

void __fastcall FUN_005cb0a0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_005cb010();
  return;
}



/* FUNCTION 5336 ; VA 0x005cb0b0 ; FUN_005cb0b0 */

void __fastcall FUN_005cb0b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x005cb14f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 5337 ; VA 0x005cb160 ; FUN_005cb160 */

void __fastcall FUN_005cb160(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1 + 4,0x18,4,FUN_005507b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5338 ; VA 0x005cb1a0 ; FUN_005cb1a0 */

uint FUN_005cb1a0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar3 = FUN_0055c360(param_1,*puVar2,param_2,*puVar1);
  return uVar3 ^ 1;
}



/* FUNCTION 5339 ; VA 0x005cb1e0 ; FUN_005cb1e0 */

int __thiscall FUN_005cb1e0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x44));
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_005c4ed0(*(int *)(param_1 + 0x40));
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 5340 ; VA 0x005cb230 ; FUN_005cb230 */

undefined4 __thiscall FUN_005cb230(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 5341 ; VA 0x005cb250 ; FUN_005cb250 */

undefined4 * __thiscall FUN_005cb250(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RCCTexturePackGenerator::vftable;
  piVar2 = (int *)param_1[0x17];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 5342 ; VA 0x005cb2b0 ; FUN_005cb2b0 */

void FUN_005cb2b0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x20);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 5343 ; VA 0x005cb2e0 ; FUN_005cb2e0 */

void __thiscall FUN_005cb2e0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00559720(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xd0) * 0xd0;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0xd0 + param_2;
  param_1[2] = param_4 * 0xd0 + param_2;
  return;
}



/* FUNCTION 5344 ; VA 0x005cb370 ; FUN_005cb370 */

void __fastcall FUN_005cb370(float *param_1)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  undefined auStack_c [8];
  
  fVar2 = param_1[7];
  fVar3 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar2 + (double)(&DAT_018c0d90)[-((int)fVar2 >> 0x1f)]);
  if (*param_1 <= fVar3 && fVar3 != *param_1) {
    if ((uint)fVar2 < 0x200) {
      fVar2 = (float)((int)fVar2 << 3);
    }
    else if ((uint)fVar2 < 0x1fffffff) {
      fVar2 = (float)((int)fVar2 * 2);
    }
    FUN_005cb500(fVar2);
    pfVar1 = (float *)param_1[1];
    if ((float *)*pfVar1 != pfVar1) {
      fVar2 = pfVar1[1];
      do {
        fVar3 = *(float *)param_1[1];
        FUN_005ca750(auStack_c,(int)fVar3 + 8,fVar3);
      } while (fVar3 != fVar2);
    }
  }
  return;
}



/* FUNCTION 5345 ; VA 0x005cb410 ; FUN_005cb410 */

void __fastcall FUN_005cb410(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x1c));
  return;
}



/* FUNCTION 5346 ; VA 0x005cb420 ; FUN_005cb420 */

void FUN_005cb420(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5347 ; VA 0x005cb460 ; FUN_005cb460 */

uint FUN_005cb460(uint param_1,int param_2,uint param_3)

{
  byte *pbVar1;
  uint uVar2;
  
  uVar2 = 0;
  if (param_3 == 0) {
    return param_1;
  }
  do {
    pbVar1 = (byte *)(uVar2 + param_2);
    uVar2 = uVar2 + 1;
    param_1 = (*pbVar1 ^ param_1) * 0x1000193;
  } while (uVar2 < param_3);
  return param_1;
}



/* FUNCTION 5348 ; VA 0x005cb4a0 ; FUN_005cb4a0 */

void FUN_005cb4a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x20);
  return;
}



/* FUNCTION 5349 ; VA 0x005cb500 ; FUN_005cb500 */

void __thiscall FUN_005cb500(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar2 = *(int *)(param_1 + 0xc);
  iVar3 = *(int *)(param_1 + 0x14);
  piVar1 = (int *)(param_1 + 0xc);
  uVar7 = param_2 * 2;
  if ((uint)(iVar3 - iVar2 >> 2) < uVar7) {
    if (0x3fffffff < uVar7) goto LAB_005cb638;
    FUN_005cb650(uVar7);
    iVar2 = *piVar1;
    iVar3 = *(int *)(param_1 + 0x14);
  }
  uStack_c = *(undefined4 *)(param_1 + 4);
  uVar4 = iVar3 - iVar2 >> 2;
  uVar5 = *(int *)(param_1 + 0x10) - iVar2 >> 2;
  uStack_8 = uStack_c;
  if (uVar4 < uVar7) {
    if (0x3fffffff < uVar7) {
LAB_005cb638:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = uVar7;
    if ((uVar4 <= 0x3fffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < uVar7)) {
      uVar5 = uVar7;
    }
    if (iVar2 != 0) {
      FUN_0057d270(iVar2,uVar4);
    }
    *piVar1 = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
    if (uVar5 != 0) {
      if (0x3fffffff < uVar5) goto LAB_005cb638;
      iVar2 = FUN_00577ed0(uVar5);
      *piVar1 = iVar2;
      *(int *)(param_1 + 0x10) = iVar2;
      *(uint *)(param_1 + 0x14) = *piVar1 + uVar5 * 4;
    }
    puVar6 = (undefined4 *)*piVar1;
    for (; uVar7 != 0; uVar7 = uVar7 - 1) {
      *puVar6 = uStack_8;
      puVar6 = puVar6 + 1;
    }
  }
  else if (uVar5 < uVar7) {
    FUN_005ca6d0(iVar2,*(int *)(param_1 + 0x10),&uStack_c);
    puVar6 = *(undefined4 **)(param_1 + 0x10);
    for (iVar2 = uVar7 - uVar5; iVar2 != 0; iVar2 = iVar2 + -1) {
      *puVar6 = uStack_8;
      puVar6 = puVar6 + 1;
    }
  }
  else {
    puVar6 = (undefined4 *)(iVar2 + param_2 * 8);
    FUN_005ca6d0(iVar2,puVar6,&uStack_c);
  }
  *(undefined4 **)(param_1 + 0x10) = puVar6;
  *(int *)(param_1 + 0x18) = param_2 + -1;
  *(int *)(param_1 + 0x1c) = param_2;
  return;
}



/* FUNCTION 5350 ; VA 0x005cb640 ; FUN_005cb640 */

void FUN_005cb640(undefined4 *param_1,undefined4 param_2)

{
  *param_1 = param_2;
  return;
}



/* FUNCTION 5351 ; VA 0x005cb650 ; FUN_005cb650 */

void __thiscall FUN_005cb650(uint *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  uVar1 = param_1[1];
  uVar2 = *param_1;
  uVar4 = FUN_00577ed0(param_2);
  puVar5 = (undefined4 *)*param_1;
  uVar9 = 0;
  uVar8 = (param_1[1] - (int)puVar5) + 3 >> 2;
  if ((undefined4 *)param_1[1] < puVar5) {
    uVar8 = 0;
  }
  if (uVar8 != 0) {
    iVar7 = uVar4 - (int)puVar5;
    do {
      uVar3 = *puVar5;
      puVar5 = puVar5 + 1;
      uVar9 = uVar9 + 1;
      *(undefined4 *)(iVar7 + -4 + (int)puVar5) = uVar3;
    } while (uVar9 != uVar8);
    puVar5 = (undefined4 *)*param_1;
  }
  if (puVar5 != (undefined4 *)0x0) {
    uVar8 = param_1[2] - (int)puVar5 & 0xfffffffc;
    puVar6 = puVar5;
    if (0xfff < uVar8) {
      puVar6 = (undefined4 *)puVar5[-1];
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uint)((int)puVar5 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar8);
  }
  *param_1 = uVar4;
  param_1[1] = uVar4 + ((int)(uVar1 - uVar2) >> 2) * 4;
  param_1[2] = uVar4 + param_2 * 4;
  return;
}



/* FUNCTION 5352 ; VA 0x005cb700 ; FUN_005cb700 */

int __thiscall FUN_005cb700(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792828;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      ExceptionList = ppvVar1;
      FUN_005caaf0(param_1,param_4,param_2);
      param_4 = param_4 + 0xd0;
      param_2 = param_2 + 0xd0;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  uStack_8 = 1;
  FUN_00559720(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 5353 ; VA 0x005cb790 ; FUN_005cb790 */

void __thiscall
FUN_005cb790(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0055c5a0(param_2,param_3,param_4,param_1);
  return;
}



/* FUNCTION 5354 ; VA 0x005cb7b0 ; FUN_005cb7b0 */

void __thiscall FUN_005cb7b0(int param_1,undefined4 param_2)

{
  if ((DAT_01d59328 != '\0') && (*(int *)(param_1 + 0x58) != 0)) {
    FUN_0054ef60(param_2);
    FUN_005db7a0();
  }
  return;
}



/* FUNCTION 5355 ; VA 0x005cb800 ; FUN_005cb800 */

int FUN_005cb800(uint param_1,uint param_2,int param_3,int param_4,int param_5)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = 0;
  if (param_4 != 0) {
    do {
      uVar1 = param_1 >> 1;
      iVar2 = iVar2 + param_1 * param_2 * param_3;
      if (uVar1 == 0) {
        uVar1 = 1;
      }
      param_2 = param_2 >> 1;
      if (param_2 == 0) {
        param_2 = 1;
      }
      param_4 = param_4 + -1;
      param_1 = uVar1;
    } while (param_4 != 0);
  }
  return iVar2 * param_5;
}



/* FUNCTION 5356 ; VA 0x005cb850 ; FUN_005cb850 */

void __fastcall FUN_005cb850(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[7];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0x20);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 5357 ; VA 0x005cb8d0 ; FUN_005cb8d0 */

int * FUN_005cb8d0(int *param_1,int param_2,int param_3)

{
  longlong lVar1;
  int iVar2;
  
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 1;
  param_1[3] = 1;
  if (param_2 * param_3 != 0) {
    lVar1 = (ulonglong)(uint)(param_2 * param_3) * 4;
    iVar2 = FUN_01674e20(-(uint)((int)((ulonglong)lVar1 >> 0x20) != 0) | (uint)lVar1);
    param_1[4] = iVar2;
    return param_1;
  }
  param_1[4] = 0;
  return param_1;
}



/* FUNCTION 5358 ; VA 0x005cb930 ; FUN_005cb930 */

int * FUN_005cb930(int *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017991f7;
  pvStack_10 = ExceptionList;
  uStack_28 = 1;
  uStack_24 = 1;
  uStack_20 = 1;
  uStack_1c = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(4);
  uStack_8 = 0;
  uStack_18 = uVar1;
  puVar2 = (undefined4 *)FUN_01674e20(0x20);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2[1] = 1;
    puVar2[2] = 1;
    *puVar2 = std::_Ref_count_obj<class_PBRSynth::Image<struct_PBRSynth::Vec<unsigned_char,4>_>_>::
              vftable;
    FUN_005cad90(&uStack_28);
    uVar1 = uStack_18;
  }
  *param_1 = (int)(puVar2 + 3);
  param_1[1] = (int)puVar2;
  FUN_01674ea0(uVar1);
  **(undefined4 **)(*param_1 + 0x10) = *param_2;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5359 ; VA 0x005cb9f0 ; FUN_005cb9f0 */

void __thiscall FUN_005cb9f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar1);
    iStack_1b8 = FUN_005c9d30();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5360 ; VA 0x005cbc20 ; FUN_005cbc20 */

undefined4 * FUN_005cbc20(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 uVar4;
  char *pcVar5;
  undefined auStack_b0 [96];
  uint uStack_50;
  undefined4 *apuStack_4c [2];
  undefined auStack_44 [4];
  undefined auStack_40 [4];
  undefined auStack_3c [4];
  undefined auStack_38 [4];
  undefined auStack_34 [4];
  undefined auStack_30 [4];
  undefined auStack_2c [12];
  undefined auStack_20 [12];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017992ae;
  pvStack_10 = ExceptionList;
  uVar4 = 1;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008ccd70(1);
  FUN_008cdc80(apuStack_4c,param_3,uVar2,uVar4);
  uStack_8 = 0;
  FUN_01660050();
  uStack_8._0_1_ = 1;
  if (0xf < (uint)apuStack_4c[0][5]) {
    apuStack_4c[0] = (undefined4 *)*apuStack_4c[0];
  }
  FUN_01661320(auStack_20,apuStack_4c[0],0x54);
  cVar1 = FUN_00554d10();
  if (cVar1 == '\0') {
    pcVar5 = "deserializeTexturePack: ill-formed XML.";
  }
  else {
    FUN_01660d00(auStack_14);
    FUN_01660820(auStack_30,"texturepack_version");
    FUN_01660820(auStack_34,"color");
    FUN_01660820(auStack_38,"normal");
    FUN_01660820(auStack_3c,"metalness");
    FUN_01660820(auStack_40,"roughness");
    FUN_01660820(auStack_44,"alphamode");
    cVar1 = FUN_00554d10();
    if (cVar1 == '\0') {
      cVar1 = FUN_00554d10();
      if (cVar1 == '\0') {
        cVar1 = FUN_00554d10();
        if (cVar1 == '\0') {
          cVar1 = FUN_00554d10();
          if (cVar1 == '\0') {
            cVar1 = FUN_00554d10();
            if (cVar1 == '\0') {
              cVar1 = FUN_00554d10();
              if (cVar1 == '\0') {
                FUN_016f4053(auStack_b0,0x18,4,FUN_005caee0,FUN_005507b0);
                uStack_8._0_1_ = 2;
                uStack_50 = 0;
                uVar2 = FUN_01660890();
                uVar2 = FUN_005cacb0(uVar2);
                uVar4 = FUN_01660890();
                uVar4 = FUN_005ccb60(auStack_2c,uVar4);
                FUN_005511f0(uVar4);
                FUN_005507b0();
                uVar4 = FUN_01660890();
                uVar4 = FUN_005ccb60(auStack_2c,uVar4);
                FUN_005511f0(uVar4);
                FUN_005507b0();
                uVar4 = FUN_01660890();
                uVar4 = FUN_005ccb60(auStack_2c,uVar4);
                FUN_005511f0(uVar4);
                FUN_005507b0();
                uVar4 = FUN_01660890();
                uVar4 = FUN_005ccb60(auStack_2c,uVar4);
                FUN_005511f0(uVar4);
                FUN_005507b0();
                uVar4 = FUN_01660890();
                uVar3 = FUN_005cacb0(uVar4);
                if (uVar3 < 2) {
                  *param_1 = uVar2;
                  uStack_8._0_1_ = 3;
                  uStack_50 = uVar3;
                  FUN_016f40fd(param_1 + 1,auStack_b0,0x18,4,FUN_0054ef20,FUN_005507b0);
                  param_1[0x19] = uStack_50;
                  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                  FUN_016f32d1(auStack_b0,0x18,4,FUN_005507b0);
                  FUN_016600b0();
                  FUN_00550b30();
                  ExceptionList = pvStack_10;
                  return param_1;
                }
                FUN_016756b0(auStack_20,"deserializeTexturePack: invalid alpha mode (%i).",uVar3);
                goto LAB_005cbf1f;
              }
              pcVar5 = "deserializeTexturePack: no alphamode node.";
            }
            else {
              pcVar5 = "deserializeTexturePack: no roughness node.";
            }
          }
          else {
            pcVar5 = "deserializeTexturePack: no metalness node.";
          }
        }
        else {
          pcVar5 = "deserializeTexturePack: no normal node.";
        }
      }
      else {
        pcVar5 = "deserializeTexturePack: no color node.";
      }
    }
    else {
      pcVar5 = "deserializeTexturePack: no texturepack_version node.";
    }
  }
  FUN_00550130(pcVar5);
LAB_005cbf1f:
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 5361 ; VA 0x005cbf30 ; FUN_005cbf30 */

undefined4
FUN_005cbf30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined **ppuStack_f4;
  undefined auStack_f0 [72];
  undefined4 uStack_a8;
  undefined **appuStack_a4 [18];
  undefined4 ***pppuStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ***pppuStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799302;
  pvStack_10 = ExceptionList;
  uStack_34 = 0xf00000000;
  pppuStack_44 = (undefined4 ***)((uint)pppuStack_44 & 0xffffff00);
  ppuStack_f4 = &PTR_018be314;
  uStack_8 = 1;
  uStack_14 = 1;
  appuStack_a4[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_a8 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(auStack_f0,0);
  uStack_8 = 3;
  *(undefined ***)(auStack_f0 + (int)(ppuStack_f4[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_f0 + (int)(ppuStack_f4[1] + -8)) = ppuStack_f4[1] + -0x50;
  FUN_005658e0(2);
  uStack_8._0_1_ = 4;
  FUN_01666be0(&ppuStack_f4,param_4,param_5,param_6);
  FUN_0058c420(&pppuStack_5c);
  FUN_005507b0();
  pppuStack_44 = pppuStack_5c;
  uStack_40 = uStack_58;
  uStack_3c = uStack_54;
  uStack_38 = uStack_50;
  *(undefined ***)(auStack_f0 + (int)(ppuStack_f4[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_f0 + (int)(ppuStack_f4[1] + -8)) = ppuStack_f4[1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(auStack_f0 + (int)(ppuStack_f4[1] + -4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(auStack_f0 + (int)(ppuStack_f4[1] + -8)) = ppuStack_f4[1] + -8;
  uStack_8._0_1_ = 5;
  appuStack_a4[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_a4);
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  ppppuVar2 = &pppuStack_44;
  if (0xf < uStack_48) {
    ppppuVar2 = (undefined4 ****)pppuStack_5c;
  }
  FUN_005c39d0(ppppuVar2,uStack_4c,apppuStack_2c,uStack_14);
  uVar1 = FUN_00558890(param_1,&DAT_018c35d8,param_3,&DAT_018c5244);
  uVar1 = FUN_00558890(uVar1);
  uVar1 = FUN_00558890(uVar1);
  ppppuVar2 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
  }
  uVar1 = FUN_0055b3b0(uVar1,ppppuVar2,uStack_1c,&DAT_018c35d8);
  FUN_00558890(uVar1);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  if (0xf < uStack_48) {
    uVar3 = uStack_48 + 1;
    ppppuVar2 = (undefined4 ****)pppuStack_5c;
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)pppuStack_5c[-1];
      uVar3 = uStack_48 + 0x24;
      if (0x1f < (uint)((int)pppuStack_5c + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5362 ; VA 0x005cc1c0 ; FUN_005cc1c0 */

void __thiscall FUN_005cc1c0(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_005cb4a0(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 5363 ; VA 0x005cc270 ; FUN_005cc270 */

undefined4 FUN_005cc270(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_4c [5];
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799328;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  uVar3 = FUN_009d09d0(aiStack_4c,param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uStack_8 = 0;
  uVar4 = FUN_009d09d0(auStack_34,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8._0_1_ = 1;
  uVar3 = (**(code **)(iStack_14 + 0x38))(auStack_1c,uVar4,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_009d5730(param_2,uVar3);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    uVar6 = auStack_34[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_34[0] - 4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (0xf < uStack_38) {
    uVar6 = uStack_38 + 1;
    iVar2 = aiStack_4c[0];
    if (0xfff < uVar6) {
      iVar2 = *(int *)(aiStack_4c[0] + -4);
      uVar6 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 5364 ; VA 0x005cc3d0 ; FUN_005cc3d0 */

undefined4 FUN_005cc3d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined8 uVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_2);
  uVar4 = FUN_009d1940(param_2,param_3,2,iVar1 - param_3,iStack_14 + 0x44);
  uStack_18 = (undefined4)uVar4;
  uVar2 = FUN_009d09d0(aiStack_30,param_2,param_3,1,iVar1 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  (**(code **)(iStack_14 + 0x38))(uVar2,uStack_18,(int)((ulonglong)uVar4 >> 0x20));
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar1 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 5365 ; VA 0x005cc4a0 ; thunk_FUN_00559180 */

void thunk_FUN_00559180(void)

{
  int iVar1;
  
  if (DAT_01ea8964 == 0) {
    iVar1 = FUN_00558f80();
    DAT_01ea8964 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 5366 ; VA 0x005cc4b0 ; FUN_005cc4b0 */

int * FUN_005cc4b0(int *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_140;
  int iStack_13c;
  undefined auStack_138 [200];
  undefined auStack_70 [24];
  int aiStack_58 [5];
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799394;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 1;
    puStack_18[2] = 1;
    *puStack_18 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_18[3] = 0;
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    puVar3 = puStack_18;
  }
  *param_1 = (int)(puVar3 + 3);
  param_1[1] = (int)puVar3;
  uStack_8 = 0;
  uStack_14 = 3;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_3c = FUN_005cb2b0(0,0);
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_8 = 2;
  uStack_40 = 0x3f800000;
  FUN_005cb500(8);
  iVar6 = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  param_3 = param_3 + 4;
  do {
    if (*(int *)(param_3 + 0x10) != 0) {
      uVar2 = FUN_009cc5b0(aiStack_58);
      uStack_8._0_1_ = 4;
      FUN_005ca900(auStack_1c,uVar2,param_1);
      uStack_8._0_1_ = 3;
      if (0xf < uStack_44) {
        uVar5 = uStack_44 + 1;
        iVar4 = aiStack_58[0];
        if (0xfff < uVar5) {
          iVar4 = *(int *)(aiStack_58[0] + -4);
          uVar5 = uStack_44 + 0x24;
          if (0x1f < (aiStack_58[0] - iVar4) - 4U) goto LAB_005cc741;
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      if ((char)puStack_18 != '\0') {
        FUN_0054ef60(param_3);
        uStack_8._0_1_ = 5;
        cVar1 = FUN_008cc060(aiStack_58);
        if (cVar1 == '\0') {
          FUN_0054eb90();
          uVar2 = FUN_005543f0();
          uVar2 = FUN_01675640(auStack_70,"Failed to format asset id \'%s\'.",uVar2);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          FUN_005500e0(uVar2);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_20,&DAT_01c17198);
        }
        iVar4 = *param_1;
        uStack_140 = FUN_0088cb40();
        iStack_13c = 0;
        FUN_0054ef60(aiStack_58);
        iStack_13c = FUN_005c9d30();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        if (*(int *)(iVar4 + 8) == *(int *)(iVar4 + 4)) {
          FUN_005ca4f0(*(int *)(iVar4 + 4),&uStack_140);
        }
        else {
          FUN_005caaf0(iVar4);
          *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0xd0;
        }
        uStack_8._0_1_ = 8;
        if (iStack_13c != 0) {
          (**(code **)(iStack_13c + 8))(auStack_138);
        }
        uStack_8._0_1_ = 3;
        if (0xf < uStack_44) {
          uVar5 = uStack_44 + 1;
          iVar4 = aiStack_58[0];
          if (0xfff < uVar5) {
            iVar4 = *(int *)(aiStack_58[0] + -4);
            uVar5 = uStack_44 + 0x24;
            if (0x1f < (aiStack_58[0] - iVar4) - 4U) {
LAB_005cc741:
              uStack_8._0_1_ = 3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar5);
        }
      }
    }
    iVar6 = iVar6 + 1;
    param_3 = param_3 + 0x18;
    if (3 < iVar6) {
      FUN_005cafb0();
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 5367 ; VA 0x005cc750 ; FUN_005cc750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005cc750(undefined *param_1,undefined4 param_2)

{
  undefined uVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 ******ppppppuVar5;
  undefined4 uVar6;
  uint uVar7;
  byte *pbVar8;
  uint uVar9;
  uint uVar10;
  byte *pbVar11;
  bool bVar12;
  undefined4 *****apppppuStack_3c [4];
  uint uStack_2c;
  uint uStack_28;
  undefined auStack_24 [12];
  undefined4 *****pppppuStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792448;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uVar10 = 0;
  uStack_8 = 0;
  uVar9 = uStack_2c;
  if (uStack_2c != 0) {
    do {
      ppppppuVar5 = apppppuStack_3c;
      if (0xf < uStack_28) {
        ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
      }
      iVar2 = FUN_0171dc5a(*(undefined *)((int)ppppppuVar5 + uVar10));
      if (iVar2 != 0) {
        ppppppuVar5 = apppppuStack_3c;
        if (0xf < uStack_28) {
          ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
        }
        uVar1 = FUN_01725677(*(undefined *)((int)ppppppuVar5 + uVar10));
        ppppppuVar5 = apppppuStack_3c;
        if (0xf < uStack_28) {
          ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
        }
        *(undefined *)((int)ppppppuVar5 + uVar10) = uVar1;
      }
      uVar10 = uVar10 + 1;
      uVar9 = uStack_2c;
    } while (uVar10 < uStack_2c);
  }
  pppppuStack_18 = apppppuStack_3c;
  if (0xf < uStack_28) {
    pppppuStack_18 = apppppuStack_3c[0];
  }
  if (4 < uVar9) {
    iStack_14 = (int)pppppuStack_18 + (uVar9 - 4);
    for (pbVar3 = (byte *)FUN_0170db20(pppppuStack_18,0x68,iStack_14 - (int)pppppuStack_18);
        pbVar3 != (byte *)0x0;
        pbVar3 = (byte *)FUN_0170db20(pbVar3 + 1,0x68,iStack_14 - (int)(pbVar3 + 1))) {
      pbVar11 = &DAT_018c526c;
      iVar2 = 1;
      pbVar8 = pbVar3;
      if (*(int *)pbVar3 == _DAT_018c526c) {
        pbVar8 = pbVar3 + 4;
        iVar2 = -3;
        pbVar11 = &DAT_018c5270;
      }
      bVar12 = *pbVar8 < *pbVar11;
      if ((*pbVar8 == *pbVar11) &&
         ((iVar2 == -3 ||
          (((bVar12 = pbVar8[1] < pbVar11[1], pbVar8[1] == pbVar11[1] &&
            (bVar12 = pbVar8[2] < pbVar11[2], pbVar8[2] == pbVar11[2])) &&
           (bVar12 = pbVar8[3] < pbVar11[3], pbVar8[3] == pbVar11[3])))))) {
        uVar10 = 0;
      }
      else {
        uVar10 = -(uint)bVar12 | 1;
      }
      if (uVar10 == 0) {
        if ((int)pbVar3 - (int)pppppuStack_18 != -1) {
          uVar10 = ((int)pbVar3 - (int)pppppuStack_18) + 5;
          ppppppuVar5 = apppppuStack_3c;
          if (0xf < uStack_28) {
            ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
          }
          if ((uVar10 < uVar9) &&
             (iVar2 = FUN_0170db20((int)ppppppuVar5 + uVar10,0x26,uVar9 - uVar10), iVar2 != 0)) {
            uVar4 = iVar2 - (int)ppppppuVar5;
          }
          else {
            uVar4 = 0xffffffff;
          }
          *(undefined4 *)(param_1 + 0x10) = 0;
          *(undefined4 *)(param_1 + 0x14) = 0xf;
          *param_1 = 0;
          if (uVar10 <= uVar9) {
            uVar7 = uVar9;
            if (uVar4 != 0xffffffff) {
              uVar7 = uVar4;
            }
            uVar4 = uVar7 - uVar10;
            if (uVar9 - uVar10 < uVar7 - uVar10) {
              uVar4 = uVar9 - uVar10;
            }
            ppppppuVar5 = apppppuStack_3c;
            if (0xf < uStack_28) {
              ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
            }
            FUN_005542c0((int)ppppppuVar5 + uVar10,uVar4);
            if (0xf < uStack_28) {
              uVar9 = uStack_28 + 1;
              ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0];
              if (0xfff < uVar9) {
                ppppppuVar5 = (undefined4 ******)apppppuStack_3c[0][-1];
                uVar9 = uStack_28 + 0x24;
                if (0x1f < (uint)((int)apppppuStack_3c[0] + (-4 - (int)ppppppuVar5)))
                goto LAB_005cc973;
              }
              FUN_01674ea0(ppppppuVar5,uVar9);
            }
            ExceptionList = pvStack_10;
            return param_1;
          }
          FUN_00554050();
LAB_005cc973:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        break;
      }
    }
  }
  FUN_0054eb90();
  uVar6 = FUN_005543f0();
  FUN_016756b0(auStack_24,"unable to parse texture pack hash from \'%s\'.",uVar6);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 5368 ; VA 0x005cc980 ; FUN_005cc980 */

undefined4 * FUN_005cc980(undefined4 *param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 uVar7;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *apuStack_1c [2];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017993cf;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (in_stack_0000001c == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    if (0xf < in_stack_00000020) {
      uVar6 = in_stack_00000020 + 1;
      iVar5 = param_3;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(param_3 + -4);
        uVar6 = in_stack_00000020 + 0x24;
        if (0x1f < (param_3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar7 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_008ccda0(1);
  FUN_008cdc80(apuStack_1c,&param_3,uVar3,uVar7);
  uStack_8._0_1_ = 1;
  puStack_14 = (undefined4 *)FUN_01674e20(0x14);
  uStack_8._0_1_ = 2;
  if (puStack_14 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4 = apuStack_1c[0] + 4;
    if (0xf < (uint)apuStack_1c[0][5]) {
      apuStack_1c[0] = (undefined4 *)*apuStack_1c[0];
    }
    puVar4 = (undefined4 *)FUN_0115f690(apuStack_1c[0],*puVar4,5);
  }
  uStack_8._0_1_ = 3;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  puStack_14 = puVar4;
  if ((0 < (int)puVar4[3]) && (0 < (int)puVar4[4])) {
    cVar2 = FUN_0115fe50();
    if (cVar2 != '\0') {
      FUN_005cb8d0(&uStack_30,puVar4[3],puVar4[4]);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uVar3 = FUN_005cb800(uStack_30,uStack_2c,4,uStack_28,uStack_24);
      FUN_0170c6f0(uStack_20,puVar4[1],uVar3);
      FUN_005cad90(&uStack_30);
      FUN_01674ea0(uStack_20);
      (**(code **)*puVar4)(1);
      FUN_00550b30();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar3 = FUN_005543f0();
    FUN_016756b0(&uStack_28,"Unable to convert to texture (id:%s) to RGBA.",uVar3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_28,&DAT_01c17198);
  }
  uStack_8._0_1_ = uVar1;
  uVar3 = FUN_005543f0();
  FUN_016756b0(&uStack_28,"Unable to load textureId \'%s\'.",uVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&uStack_28,&DAT_01c17198);
}



/* FUNCTION 5369 ; VA 0x005ccb60 ; FUN_005ccb60 */

undefined * FUN_005ccb60(undefined *param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017993f0;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  uStack_8 = 0;
  cVar1 = FUN_009ee890(auStack_30,&uStack_18);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  if (cVar1 == '\0') {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar2 = FUN_009cc3c0(aiStack_48,uStack_18,uStack_14);
  uStack_8 = 1;
  FUN_0054ef60(uVar2);
  if (0xf < uStack_34) {
    uVar6 = uStack_34 + 1;
    iVar4 = aiStack_48[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_48[0] + -4);
      uVar6 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5370 ; VA 0x005ccca0 ; FUN_005ccca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_005ccca0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined ****param_4)

{
  undefined *puVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuVar5;
  undefined4 uVar6;
  undefined4 *******pppppppuVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  undefined4 in_stack_fffffcb8;
  undefined4 in_stack_fffffcbc;
  undefined ***pppuStack_340;
  undefined **ppuStack_33c;
  undefined **ppuStack_338;
  int *piStack_334;
  undefined8 uStack_330;
  undefined auStack_31c [4];
  undefined *apuStack_318 [24];
  int iStack_2b8;
  undefined *apuStack_2b4 [4];
  undefined4 uStack_2a4;
  undefined auStack_2a0 [20];
  undefined auStack_28c [20];
  undefined auStack_278 [20];
  int iStack_264;
  int *piStack_260;
  int iStack_25c;
  int *piStack_258;
  undefined4 uStack_254;
  int *piStack_250;
  int iStack_24c;
  int *piStack_248;
  undefined auStack_244 [44];
  undefined auStack_218 [44];
  undefined auStack_1ec [44];
  undefined auStack_1c0 [56];
  int aiStack_188 [5];
  uint uStack_174;
  undefined **ppuStack_170;
  undefined auStack_16c [72];
  undefined4 uStack_124;
  undefined **appuStack_120 [18];
  double dStack_d8;
  double dStack_d0;
  undefined auStack_c8 [4];
  int *piStack_c4;
  undefined4 ******ppppppuStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined4 ******ppppppuStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined **ppuStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017994bc;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffcd8;
  uStack_18 = 0;
  uStack_330 = 6.36727062995327e-313;
  uStack_28 = 0;
  uStack_24 = 0xf;
  ppuStack_38 = (undefined **)((uint)ppuStack_38 & 0xffffff00);
  piStack_334 = (int *)0x5cccee;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 1;
  if ((DAT_01d59328 != '\0') && (*(int *)(param_1 + 0x58) != 0)) {
    uStack_330 = 0.0;
    FUN_0054ef60(&ppuStack_38);
    FUN_005db7a0(in_stack_fffffcb8,in_stack_fffffcbc);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    ppuVar5 = ppuStack_38;
    if (0xfff < uVar9) {
      ppuVar5 = (undefined **)ppuStack_38[-1];
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)ppuStack_38 + (-4 - (int)ppuVar5))) {
        uStack_330 = (double)CONCAT44(0x5cd72b,(undefined *)uStack_330);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_330 = (double)CONCAT44(uVar9,ppuVar5);
    piStack_334 = (int *)0x5ccd53;
    FUN_01674ea0();
  }
  uStack_8 = 2;
  ppuVar5 = (undefined **)param_4;
  if ((undefined *)0xf < ((undefined **)param_4)[5]) {
    ppuVar5 = (undefined **)*param_4;
  }
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  uStack_330 = (double)CONCAT44(ppuVar5,param_3);
  piStack_334 = (int *)0x18c52c4;
  ppuStack_338 = (undefined **)0x1;
  ppuStack_33c = (undefined **)0x5ccd83;
  FUN_0086f2f0();
  uStack_330 = (double)CONCAT44(2,&dStack_d8);
  piStack_334 = (int *)0x5ccd94;
  FUN_01683070();
  if (param_1 != 0) {
    iVar11 = *(int *)(param_1 + 0x34);
    if ((iVar11 != 0) && (param_1 = iVar11, *(int *)(iVar11 + 0x34) != 0)) {
      uStack_330 = (double)CONCAT44(0x5ccdae,(undefined *)uStack_330);
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar11 = *(int *)(param_1 + 0xc);
      uStack_330 = (double)CONCAT44(0x5ccdc0,(undefined *)uStack_330);
      iVar4 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        uStack_330 = (double)CONCAT44(0x5ccde2,(undefined *)uStack_330);
        param_3 = (undefined4 *)FUN_005c2760();
        goto LAB_005ccdee;
      }
    }
  }
  param_3 = (undefined4 *)0x0;
LAB_005ccdee:
  uStack_330 = (double)CONCAT44(param_4,aiStack_188);
  piStack_334 = (int *)0x5ccdfd;
  FUN_009cc590();
  uStack_8._0_1_ = 3;
  uStack_330 = (double)CONCAT44(aiStack_188,auStack_50);
  piStack_334 = (int *)0x5cce14;
  FUN_005cc750();
  uStack_8._0_1_ = 4;
  piStack_334 = (int *)auStack_31c;
  uStack_330 = (double)CONCAT44(aiStack_188,param_3);
  ppuStack_338 = (undefined **)0x5cce2f;
  FUN_005cbc20();
  uStack_330 = 6.382854697840481e-307;
  piStack_334 = (int *)0x4;
  ppuStack_338 = (undefined **)0x14;
  ppuStack_33c = apuStack_2b4;
  uStack_8._0_1_ = 5;
  pppuStack_340 = (undefined ***)0x5cce50;
  FUN_016f4053();
  uStack_8._0_1_ = 6;
  for (iVar11 = 0; iVar11 < 4; iVar11 = iVar11 + 1) {
    param_4 = &pppuStack_340;
    FUN_0054ef60(apuStack_318 + iVar11 * 6);
    ppuVar5 = (undefined **)FUN_005cc980(&uStack_b4,param_3);
    param_4 = (undefined ****)(apuStack_2b4 + iVar11 * 5);
    if (param_4 != (undefined ****)ppuVar5) {
      uStack_330 = (double)CONCAT44((&uStack_2a4)[iVar11 * 5],0x5ccea6);
      FUN_01674ea0();
      *param_4 = (undefined ***)*ppuVar5;
      ((undefined **)param_4)[1] = ppuVar5[1];
      ((undefined **)param_4)[2] = ppuVar5[2];
      ((undefined **)param_4)[3] = ppuVar5[3];
      ((undefined **)param_4)[4] = ppuVar5[4];
      *ppuVar5 = (undefined *)0x0;
      ppuVar5[1] = (undefined *)0x0;
      ppuVar5[2] = (undefined *)0x0;
      ppuVar5[3] = (undefined *)0x0;
      ppuVar5[4] = (undefined *)0x0;
    }
    uStack_330 = (double)CONCAT44(uStack_a4,0x5ccef5);
    FUN_01674ea0();
  }
  ppuStack_38 = apuStack_2b4;
  uStack_28 = 0x3f59999a;
  puStack_34 = auStack_2a0;
  puStack_30 = auStack_28c;
  puStack_2c = auStack_278;
  uStack_330 = (double)CONCAT44(3,&ppuStack_38);
  piStack_334 = &iStack_264;
  uStack_24 = 0x400;
  ppuStack_338 = (undefined **)0x5ccf45;
  FUN_016658b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (iStack_264 == 0) {
    param_4 = (undefined ****)DAT_018c4ec4;
    if (iStack_2b8 == 0) {
      param_4 = (undefined ****)DAT_018c4ec0;
    }
    ppuStack_33c = (undefined **)&param_4;
    uStack_330 = (double)CONCAT44(uStack_28,3 - (uint)((char)((uint)param_4 >> 0x18) != -1));
    pppuStack_340 = &ppuStack_338;
    FUN_005cb930();
    ppuStack_33c = (undefined **)0x5ccf9e;
    FUN_01666550();
  }
  if (iStack_25c == 0) {
    uStack_330 = 2.12199579145934e-314;
    pppuStack_340 = &ppuStack_338;
    ppuStack_33c = (undefined **)&DAT_018c4ec8;
    FUN_005cb930();
    ppuStack_33c = (undefined **)0x5ccfc9;
    FUN_01666660();
  }
  if (iStack_24c == 0) {
    ppuStack_338 = (undefined **)&uStack_330;
    piStack_334 = (int *)&DAT_018c4ecc;
    ppuStack_33c = (undefined **)0x5ccfe2;
    FUN_005cb930();
    piStack_334 = (int *)0x5ccff0;
    FUN_01666900();
  }
  uStack_84 = 0;
  uStack_78 = 0x42480000;
  uStack_74 = 8;
  uStack_70 = 0x400;
  uStack_6c = 0;
  uStack_80 = 1;
  uStack_7c = 2;
  uStack_a0 = 0;
  uStack_94 = 0x42480000;
  uStack_90 = 8;
  uStack_8c = 0x400;
  uStack_88 = 0;
  uStack_9c = 2;
  uStack_98 = 2;
  uStack_58 = 0xf00000000;
  ppppppuStack_68 = (undefined4 ******)((uint)ppppppuStack_68 & 0xffffff00);
  ppuStack_170 = &PTR_018be314;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  uStack_330 = (double)ZEXT48(auStack_16c);
  uStack_18 = 2;
  appuStack_120[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_124 = 0x48;
  piStack_334 = (int *)0x5cd0b0;
  FUN_00554f20();
  uStack_8 = 0xb;
  *(undefined ***)(auStack_16c + (int)(ppuStack_170[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&uStack_174 + (int)ppuStack_170[1]) = ppuStack_170[1] + -0x50;
  uStack_330 = 4.24699688197074e-314;
  FUN_005658e0();
  uStack_8._0_1_ = 0xc;
  uStack_330 = (double)CONCAT44(&DAT_018c52f0,&ppuStack_170);
  piStack_334 = (int *)0x5cd100;
  FUN_00558890();
  uStack_330 = (double)CONCAT44("\"image_formats\": {\n",&ppuStack_170);
  piStack_334 = (int *)0x5cd114;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_84,auStack_244);
  piStack_334 = (int *)iStack_264;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c530c;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018c5308,uVar6);
  piStack_334 = (int *)0x5cd14b;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_a0,auStack_244);
  piStack_334 = (int *)iStack_264;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c5318;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018c5308,uVar6);
  piStack_334 = (int *)0x5cd185;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_84,auStack_1ec);
  piStack_334 = (int *)uStack_254;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c5324;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018c5308,uVar6);
  piStack_334 = (int *)0x5cd1bc;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_a0,auStack_218);
  piStack_334 = (int *)iStack_25c;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c5330;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018c5308,uVar6);
  piStack_334 = (int *)0x5cd1f6;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_84,auStack_1c0);
  piStack_334 = (int *)iStack_24c;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c533c;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018c5308,uVar6);
  piStack_334 = (int *)0x5cd22d;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&uStack_a0,auStack_1c0);
  piStack_334 = (int *)iStack_24c;
  ppuStack_33c = (undefined **)auStack_50;
  ppuStack_338 = (undefined **)0x18c5348;
  pppuStack_340 = &ppuStack_170;
  uVar6 = FUN_005cbf30();
  uStack_330 = (double)CONCAT44(&DAT_018bcfa8,uVar6);
  piStack_334 = (int *)0x5cd267;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&DAT_018c5354,&ppuStack_170);
  piStack_334 = (int *)0x5cd27b;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&DAT_018c5354,&ppuStack_170);
  piStack_334 = (int *)0x5cd28f;
  FUN_00558890();
  uStack_330 = (double)CONCAT44(&ppppppuStack_b8,0x5cd2a4);
  FUN_0058c420();
  uStack_18 = 10;
  ppppppuStack_68 = ppppppuStack_b8;
  uStack_64 = uStack_b4;
  uStack_60 = uStack_b0;
  uStack_5c = uStack_ac;
  uVar9 = uStack_a4;
  *(undefined ***)(auStack_16c + (int)(ppuStack_170[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  uStack_58._4_4_ = uVar9;
  *(undefined **)((int)&uStack_174 + (int)ppuStack_170[1]) = ppuStack_170[1] + -0x50;
  uStack_330 = (double)CONCAT44(0x5cd2f5,(undefined *)uStack_330);
  FUN_0056b950();
  *(undefined ***)(auStack_16c + (int)(ppuStack_170[1] + -4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&uStack_174 + (int)ppuStack_170[1]) = ppuStack_170[1] + -8;
  uStack_330._4_4_ = appuStack_120;
  uStack_8._0_1_ = 0xd;
  appuStack_120[0] = std::ios_base::vftable;
  uStack_330._0_4_ = (undefined *)0x5cd336;
  FUN_016de551();
  uStack_330 = (double)CONCAT44(uStack_330._4_4_,0xc);
  uStack_8._0_1_ = 8;
  piStack_334 = (int *)0x5cd341;
  iVar11 = FUN_01674e20();
  uStack_8._0_1_ = 0xe;
  if (iVar11 == 0) {
    iVar11 = 0;
  }
  else {
    uStack_330 = (double)CONCAT44((int)&param_4 + 3,2);
    piStack_334 = (int *)0x5cd35e;
    FUN_00569550();
  }
  uStack_8._0_1_ = 8;
  uStack_330 = (double)CONCAT44(param_4,iVar11);
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  piStack_334 = (int *)0x5cd380;
  FUN_0055ba30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  puVar8 = (undefined4 *)*piStack_20;
  uStack_330 = (double)CONCAT44(0x5cd38e,(undefined *)uStack_330);
  uVar6 = FUN_0088cb40();
  *puVar8 = uVar6;
  uStack_330 = (double)CONCAT44(0x5cd395,(undefined *)uStack_330);
  param_4 = (undefined ****)FUN_005c9d30();
  iVar11 = puVar8[1];
  if ((undefined ****)iVar11 == param_4) {
    if ((undefined4 *******)(puVar8 + 2) != &ppppppuStack_68) {
      pppppppuVar7 = &ppppppuStack_68;
      if (0xf < uStack_a4) {
        pppppppuVar7 = (undefined4 *******)ppppppuStack_b8;
      }
      uStack_330 = (double)CONCAT44(uStack_a8,pppppppuVar7);
      piStack_334 = (int *)0x5cd3c5;
      FUN_005542c0();
    }
  }
  else {
    if (iVar11 != 0) {
      uStack_330 = (double)CONCAT44(puVar8 + 2,0x5cd3d1);
      (**(code **)(iVar11 + 8))();
      puVar8[1] = 0;
    }
    uStack_330 = (double)CONCAT44(&ppppppuStack_68,0x5cd3e7);
    FUN_0054ef60();
    puVar8[1] = param_4;
  }
  piStack_334 = (int *)auStack_c8;
  uStack_330 = (double)CONCAT44(auStack_31c,param_3);
  ppuStack_338 = (undefined **)0x5cd401;
  puVar8 = (undefined4 *)FUN_005cc4b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  iVar11 = *piStack_20;
  uStack_330 = (double)CONCAT44(0x5cd41a,(undefined *)uStack_330);
  uVar6 = FUN_008882f0();
  iVar4 = _tls_index;
  *(undefined4 *)(iVar11 + 0xd0) = uVar6;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01ea8cd0) {
    uStack_330 = 1.982255572875732e-299;
    FUN_016f3809();
    if (DAT_01ea8cd0 == -1) {
      _DAT_01ea8cc4 = FUN_0057bbb0;
      _DAT_01ea8cc8 = FUN_005880a0;
      DAT_01ea8ccc = FUN_0057d5e0;
      uStack_330 = 1.9822555728757468e-299;
      FUN_016f37bf();
      puVar8 = (undefined4 *)FUN_005cd43c();
      return puVar8;
    }
  }
  puVar1 = *(undefined **)(iVar11 + 0xd4);
  if (puVar1 == &DAT_01ea8cc4) {
    uVar6 = *puVar8;
    uVar2 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(iVar11 + 0xd8) = uVar6;
    piVar3 = *(int **)(iVar11 + 0xdc);
    *(undefined4 *)(iVar11 + 0xdc) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar11 = piVar3[1] + -1;
      piVar3[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_330 = (double)CONCAT44(0x5cd478,(undefined *)uStack_330);
        (**(code **)*piVar3)();
        LOCK();
        iVar11 = piVar3[2] + -1;
        piVar3[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          uStack_330 = (double)CONCAT44(0x5cd488,(undefined *)uStack_330);
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      uStack_330 = (double)CONCAT44(iVar11 + 0xd8,0x5cd497);
      (**(code **)(puVar1 + 8))();
      *(undefined4 *)(iVar11 + 0xd4) = 0;
    }
    *(undefined4 *)(iVar11 + 0xd8) = 0;
    *(undefined4 *)(iVar11 + 0xdc) = 0;
    *(undefined4 *)(iVar11 + 0xd8) = *puVar8;
    *(undefined4 *)(iVar11 + 0xdc) = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined **)(iVar11 + 0xd4) = &DAT_01ea8cc4;
  }
  uStack_8._0_1_ = 0xf;
  if (piStack_c4 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_c4[1] + -1;
    piStack_c4[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      uStack_330 = (double)CONCAT44(0x5cd4ee,(undefined *)uStack_330);
      (**(code **)*piStack_c4)();
      LOCK();
      iVar11 = piStack_c4[2] + -1;
      piStack_c4[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_330 = (double)CONCAT44(0x5cd4fe,(undefined *)uStack_330);
        (**(code **)(*piStack_c4 + 4))();
      }
    }
  }
  uStack_330 = (double)CONCAT44(2,&dStack_d0);
  piStack_334 = (int *)0x5cd50c;
  FUN_01683070();
  uStack_330 = (dStack_d0 - dStack_d8) * DAT_018c0d70;
  piStack_334 = (int *)0x18c5358;
  ppuStack_338 = (undefined **)0x1;
  ppuStack_33c = (undefined **)0x5cd53b;
  FUN_0086f2f0();
  *param_2 = piStack_20;
  param_2[1] = uStack_1c;
  uStack_18 = 0xb;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_58._4_4_) {
    uVar9 = uStack_58._4_4_ + 1;
    pppppppuVar7 = (undefined4 *******)ppppppuStack_68;
    if (0xfff < uVar9) {
      pppppppuVar7 = (undefined4 *******)ppppppuStack_68[-1];
      uVar9 = uStack_58._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppppuStack_68 + (-4 - (int)pppppppuVar7))) {
        uStack_330 = (double)CONCAT44(0x5cd77a,(undefined *)uStack_330);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_330 = (double)CONCAT44(uVar9,pppppppuVar7);
    piStack_334 = (int *)0x5cd588;
    FUN_01674ea0();
  }
  if (piStack_248 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_248[1] + -1;
    piStack_248[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      uStack_330 = (double)CONCAT44(0x5cd5a4,(undefined *)uStack_330);
      (**(code **)*piStack_248)();
      LOCK();
      iVar11 = piStack_248[2] + -1;
      piStack_248[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_330 = (double)CONCAT44(0x5cd5b4,(undefined *)uStack_330);
        (**(code **)(*piStack_248 + 4))();
      }
    }
  }
  if (piStack_250 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_250[1] + -1;
    piStack_250[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      uStack_330 = (double)CONCAT44(0x5cd5cd,(undefined *)uStack_330);
      (**(code **)*piStack_250)();
      LOCK();
      iVar11 = piStack_250[2] + -1;
      piStack_250[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_330 = (double)CONCAT44(0x5cd5dd,(undefined *)uStack_330);
        (**(code **)(*piStack_250 + 4))();
      }
    }
  }
  if (piStack_258 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_258[1] + -1;
    piStack_258[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      uStack_330 = (double)CONCAT44(0x5cd5f6,(undefined *)uStack_330);
      (**(code **)*piStack_258)();
      LOCK();
      iVar11 = piStack_258[2] + -1;
      piStack_258[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        uStack_330 = (double)CONCAT44(0x5cd606,(undefined *)uStack_330);
        (**(code **)(*piStack_258 + 4))();
      }
    }
  }
  if (piStack_260 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_260[1] + -1;
    piStack_260[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      uStack_330 = (double)CONCAT44(0x5cd61f,(undefined *)uStack_330);
      (**(code **)*piStack_260)();
      LOCK();
      piVar3 = piStack_260 + 2;
      iVar11 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        uStack_330 = (double)CONCAT44(0x5cd62e,(undefined *)uStack_330);
        (**(code **)(*piStack_260 + 4))();
      }
    }
  }
  uStack_330 = 6.382854693039045e-307;
  piStack_334 = (int *)0x14;
  ppuStack_338 = apuStack_2b4;
  uStack_8._0_1_ = 5;
  ppuStack_33c = (undefined **)0x5cd647;
  FUN_016f32d1();
  uStack_330 = 4.6793368432117175e-307;
  piStack_334 = (int *)0x18;
  ppuStack_338 = apuStack_318;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  ppuStack_33c = (undefined **)0x5cd660;
  FUN_016f32d1();
  if (0xf < uStack_3c) {
    uVar10 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar10 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
        uStack_330 = (double)CONCAT44(0x5cd77f,(undefined *)uStack_330);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_330 = (double)CONCAT44(uVar10,uVar9);
    piStack_334 = (int *)0x5cd691;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  if (0xf < uStack_174) {
    uVar9 = uStack_174 + 1;
    iVar11 = aiStack_188[0];
    if (0xfff < uVar9) {
      iVar11 = *(int *)(aiStack_188[0] + -4);
      uVar9 = uStack_174 + 0x24;
      if (0x1f < (aiStack_188[0] - iVar11) - 4U) {
        uStack_330 = (double)CONCAT44(Catch_005cd784,(undefined *)uStack_330);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_330 = (double)CONCAT44(uVar9,iVar11);
    piStack_334 = (int *)0x5cd6dd;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5371 ; VA 0x005cd43c ; FUN_005cd43c */

undefined4 FUN_005cd43c(void)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int unaff_EBP;
  int unaff_ESI;
  undefined4 *unaff_EDI;
  
  puVar2 = *(undefined **)(unaff_ESI + 4);
  if (puVar2 == &DAT_01ea8cc4) {
    uVar3 = *unaff_EDI;
    uVar4 = unaff_EDI[1];
    *unaff_EDI = 0;
    unaff_EDI[1] = 0;
    *(undefined4 *)(unaff_ESI + 8) = uVar3;
    piVar5 = *(int **)(unaff_ESI + 0xc);
    *(undefined4 *)(unaff_ESI + 0xc) = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar8 = piVar5[1] + -1;
      piVar5[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar8 = piVar5[2] + -1;
        piVar5[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  else {
    if (puVar2 != (undefined *)0x0) {
      (**(code **)(puVar2 + 8))();
      *(undefined4 *)(unaff_ESI + 4) = 0;
    }
    *(undefined4 *)(unaff_ESI + 8) = 0;
    *(undefined4 *)(unaff_ESI + 0xc) = 0;
    *(undefined4 *)(unaff_ESI + 8) = *unaff_EDI;
    *(undefined4 *)(unaff_ESI + 0xc) = unaff_EDI[1];
    *unaff_EDI = 0;
    unaff_EDI[1] = 0;
    *(undefined **)(unaff_ESI + 4) = &DAT_01ea8cc4;
  }
  piVar5 = *(int **)(unaff_EBP + -0xc0);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_01683070(unaff_EBP + -0xcc,2);
  FUN_0086f2f0(1,"RCCTexturePackGenerator::process() success in %lf ms.",
               (*(double *)(unaff_EBP + -0xcc) - *(double *)(unaff_EBP + -0xd4)) * DAT_018c0d70);
  puVar6 = *(undefined4 **)(unaff_EBP + 8);
  *puVar6 = *(undefined4 *)(unaff_EBP + -0x1c);
  puVar6[1] = *(undefined4 *)(unaff_EBP + -0x18);
  uVar7 = *(uint *)(unaff_EBP + -0x50);
  *(undefined4 *)(unaff_EBP + -0x14) = 0xb;
  *(undefined *)(unaff_EBP + -4) = 7;
  if (0xf < uVar7) {
    iVar8 = *(int *)(unaff_EBP + -100);
    uVar10 = uVar7 + 1;
    iVar9 = iVar8;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar8 + -4);
      uVar10 = uVar7 + 0x24;
      if (0x1f < (iVar8 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  piVar5 = *(int **)(unaff_EBP + -0x244);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(unaff_EBP + -0x24c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(unaff_EBP + -0x254);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = *(int **)(unaff_EBP + -0x25c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 5;
  FUN_016f32d1(unaff_EBP + -0x2b0,0x14,4,FUN_005cafa0);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  FUN_016f32d1(unaff_EBP + -0x314,0x18,4,FUN_005507b0);
  uVar7 = *(uint *)(unaff_EBP + -0x38);
  if (0xf < uVar7) {
    iVar8 = *(int *)(unaff_EBP + -0x4c);
    uVar10 = uVar7 + 1;
    iVar9 = iVar8;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar8 + -4);
      uVar10 = uVar7 + 0x24;
      if (0x1f < (iVar8 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  uVar7 = *(uint *)(unaff_EBP + -0x170);
  *(undefined4 *)(unaff_EBP + -0x3c) = 0;
  *(undefined4 *)(unaff_EBP + -0x38) = 0xf;
  *(undefined *)(unaff_EBP + -0x4c) = 0;
  if (0xf < uVar7) {
    iVar8 = *(int *)(unaff_EBP + -0x184);
    uVar10 = uVar7 + 1;
    iVar9 = iVar8;
    if (0xfff < uVar10) {
      iVar9 = *(int *)(iVar8 + -4);
      uVar10 = uVar7 + 0x24;
      if (0x1f < (iVar8 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar10);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return *(undefined4 *)(unaff_EBP + 8);
}



/* FUNCTION 5372 ; VA 0x005cd6f6 ; Catch@005cd6f6 */

void Catch_005cd6f6(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = *(undefined4 *)(unaff_EBP + -0xbc);
  FUN_0086ed30(3,uVar1,6);
  FUN_005500e0(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -400,&DAT_01c17198);
}



/* FUNCTION 5373 ; VA 0x005cd784 ; Catch@005cd784 */

void Catch_005cd784(void)

{
  int unaff_EBP;
  
  FUN_0086eff0(3,*(undefined4 *)(unaff_EBP + -0xb8),6);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5374 ; VA 0x005cd7a0 ; FUN_005cd7a0 */

void __thiscall FUN_005cd7a0(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_005caaf0(param_1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xd0;
    return;
  }
  FUN_005ca4f0(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 5375 ; VA 0x005cd7e0 ; FUN_005cd7e0 */

void FUN_005cd7e0(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  uVar4 = 0;
  if (param_1[4] != 0) {
    do {
      puVar3 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar3 = (undefined4 *)*param_1;
      }
      iVar2 = FUN_0171dc5a(*(undefined *)((int)puVar3 + uVar4));
      if (iVar2 != 0) {
        puVar3 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar3 = (undefined4 *)*param_1;
        }
        uVar1 = FUN_01725677(*(undefined *)((int)puVar3 + uVar4));
        puVar3 = param_1;
        if (0xf < (uint)param_1[5]) {
          puVar3 = (undefined4 *)*param_1;
        }
        *(undefined *)((int)puVar3 + uVar4) = uVar1;
      }
      uVar4 = uVar4 + 1;
    } while (uVar4 < (uint)param_1[4]);
  }
  return;
}



/* FUNCTION 5376 ; VA 0x005cd840 ; FUN_005cd840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_005cd840(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8cd0) {
    FUN_016f3809(&DAT_01ea8cd0);
    if (DAT_01ea8cd0 == -1) {
      _DAT_01ea8cc4 = FUN_0057bbb0;
      _DAT_01ea8cc8 = FUN_005880a0;
      DAT_01ea8ccc = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8cd0);
    }
  }
  return &DAT_01ea8cc4;
}



/* FUNCTION 5377 ; VA 0x005cd8b0 ; FUN_005cd8b0 */

int __thiscall FUN_005cd8b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017994d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::SoapMicroprofiling::SimulationJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5378 ; VA 0x005cd984 ; Catch_All@005cd984 */

void Catch_All_005cd984(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5379 ; VA 0x005cd9a0 ; FUN_005cd9a0 */

void __fastcall FUN_005cd9a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_1[4];
  while (iVar5 != 0) {
    piVar1 = *(int **)(param_1[1] + (iVar5 + param_1[3] + -1 & param_1[2] - 1) * 4);
    uVar4 = piVar1[5];
    if (0xf < uVar4) {
      iVar5 = *piVar1;
      uVar3 = uVar4 + 1;
      iVar2 = iVar5;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iVar5 + -4);
        uVar3 = uVar4 + 0x24;
        if (0x1f < (iVar5 - iVar2) - 4U) goto LAB_005cda8f;
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar5 = param_1[4];
  }
  iVar5 = param_1[2];
  while (iVar5 != 0) {
    iVar5 = iVar5 + -1;
    iVar2 = *(int *)(param_1[1] + iVar5 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x1c);
    }
  }
  iVar5 = param_1[1];
  if (iVar5 != 0) {
    uVar4 = param_1[2] * 4;
    iVar2 = iVar5;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar5 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar5 - iVar2) - 4U) {
LAB_005cda8f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 5380 ; VA 0x005cdaa0 ; FUN_005cdaa0 */

void __fastcall FUN_005cdaa0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0152dda0(*param_1,param_1[1],param_1[2],param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5381 ; VA 0x005cdae0 ; FUN_005cdae0 */

undefined4 __thiscall FUN_005cdae0(undefined4 param_1,byte param_2)

{
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf8);
  }
  return param_1;
}



/* FUNCTION 5382 ; VA 0x005cdb10 ; FUN_005cdb10 */

void __thiscall FUN_005cdb10(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x9249249 - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_005cdcec:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_005cdb74;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_005cdb74:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_005cdcec;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_005cdcec;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 5383 ; VA 0x005cdd00 ; FUN_005cdd00 */

void FUN_005cdd00(int param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 uVar5;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179950a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_1);
  uStack_1c = in_stack_0000001c;
  puStack_14 = &DAT_01ea8cec;
  do {
    LOCK();
    uVar4 = DAT_01ea8cec & 1;
    DAT_01ea8cec = DAT_01ea8cec | 1;
    UNLOCK();
  } while (uVar4 != 0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01ea8ce0 <= DAT_01ea8ce8 + 1U) {
    FUN_005cdb10(1);
  }
  DAT_01ea8ce4 = DAT_01ea8ce0 - 1 & DAT_01ea8ce4;
  iVar3 = (DAT_01ea8ce0 - 1 & DAT_01ea8ce4 + DAT_01ea8ce8) * 4;
  if (*(int *)(iVar3 + DAT_01ea8cdc) == 0) {
    uVar1 = FUN_01674e20(0x1c);
    *(undefined4 *)(iVar3 + DAT_01ea8cdc) = uVar1;
  }
  iVar3 = *(int *)(iVar3 + DAT_01ea8cdc);
  FUN_0054ef60(aiStack_34);
  *(undefined4 *)(iVar3 + 0x18) = uStack_1c;
  DAT_01ea8ce8 = DAT_01ea8ce8 + 1;
  uStack_8._0_1_ = 1;
  DAT_01ea8cec = 0;
  if (DAT_01ea8cd4 == '\0') {
    DAT_01ea8cd4 = '\x01';
    puVar2 = (undefined4 *)FUN_01674e20(0xf8);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      FUN_01522c10("SoapMicroprofilingHeartbeatJob",0,0,0);
      *puVar2 = RBX::SoapMicroprofiling::SimulationJob::vftable;
    }
    uStack_8._0_1_ = 1;
    uVar1 = 0;
    uVar5 = 0;
    FUN_005cd8b0(puVar2,uStack_18);
    FUN_0151d950(uVar1,uVar5);
  }
  if (0xf < uStack_20) {
    uVar4 = uStack_20 + 1;
    iVar3 = aiStack_34[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_34[0] + -4);
      uVar4 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar3 = param_1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_1 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5384 ; VA 0x005cdee0 ; FUN_005cdee0 */

undefined4 FUN_005cdee0(void)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *****pppppuVar4;
  int iVar5;
  undefined4 *****pppppuVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined1 *puVar10;
  uint uVar11;
  undefined8 uVar12;
  int aiStack_1b4 [14];
  int aiStack_17c [6];
  int iStack_164;
  int iStack_108;
  undefined **appuStack_104 [2];
  undefined8 uStack_fc;
  undefined **appuStack_f4 [16];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_a0;
  undefined **ppuStack_9c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 *puStack_44;
  undefined4 ****appppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***pppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179958c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iVar7 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar7 + 0x34) < DAT_01ea8d08) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ea8d08), DAT_01ea8d08 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("SoapMicroprofiling",&DAT_018c5418,0xffffffff);
    DAT_01ea8d04 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ea8d00 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ea8d08);
  }
  uStack_24 = DAT_01ea8d00;
  uStack_54 = DAT_01ea8d00;
  uStack_20 = DAT_01ea8d04;
  uStack_50 = DAT_01ea8d04;
  uStack_4c = FUN_0152d930(DAT_01ea8d00,DAT_01ea8d04);
  uStack_8 = 1;
  uStack_1c = uStack_4c;
  if (*(int *)(iVar7 + 0x34) < DAT_01ea8d18) {
    FUN_016f3809(&DAT_01ea8d18);
    if (DAT_01ea8d18 == -1) {
      FUN_016f3654(&LAB_0187b800);
      FUN_016f37bf(&DAT_01ea8d18);
    }
  }
  if (DAT_01ea8d0c == 0) {
    uStack_30 = 0;
    uStack_2c = 0xf;
    appppuStack_40[0] = (undefined4 ****)((uint)appppuStack_40[0] & 0xffffff00);
    pppuStack_28 = (undefined4 ****)0x0;
    puStack_44 = &DAT_01ea8cec;
    do {
      LOCK();
      uVar11 = DAT_01ea8cec & 1;
      DAT_01ea8cec = DAT_01ea8cec | 1;
      UNLOCK();
    } while (uVar11 != 0);
    uStack_8._0_1_ = 3;
    if (DAT_01ea8ce8 == 0) {
      DAT_01ea8cec = 0;
    }
    else {
      puVar8 = DAT_01ea8cd8;
      if (DAT_01ea8cd8 != (undefined4 *)0x0) {
        puVar8 = (undefined4 *)*DAT_01ea8cd8;
      }
      pppppuVar6 = *(undefined4 ******)(puVar8[1] + (puVar8[2] - 1 & DAT_01ea8ce4) * 4);
      if (appppuStack_40 != pppppuVar6) {
        pppppuVar4 = pppppuVar6;
        if ((undefined4 ****)0xf < pppppuVar6[5]) {
          pppppuVar4 = (undefined4 *****)*pppppuVar6;
        }
        FUN_005542c0(pppppuVar4,pppppuVar6[4]);
      }
      uVar3 = uStack_2c;
      uVar2 = uStack_30;
      pppuStack_28 = pppppuVar6[6];
      piVar1 = *(int **)(DAT_01ea8cdc + (DAT_01ea8ce0 - 1U & DAT_01ea8ce4) * 4);
      uVar11 = piVar1[5];
      if (0xf < uVar11) {
        iVar7 = *piVar1;
        uVar9 = uVar11 + 1;
        iVar5 = iVar7;
        if (0xfff < uVar9) {
          iVar5 = *(int *)(iVar7 + -4);
          uVar9 = uVar11 + 0x24;
          if (0x1f < (iVar7 - iVar5) - 4U) goto LAB_005ce423;
        }
        FUN_01674ea0(iVar5,uVar9);
      }
      piVar1[4] = 0;
      piVar1[5] = 0xf;
      *(undefined *)piVar1 = 0;
      DAT_01ea8ce8 = DAT_01ea8ce8 + -1;
      if (DAT_01ea8ce8 == 0) {
        DAT_01ea8ce4 = 0;
      }
      else {
        DAT_01ea8ce4 = DAT_01ea8ce4 + 1;
      }
      uStack_8._0_1_ = 2;
      DAT_01ea8cec = 0;
      pppppuVar6 = appppuStack_40;
      if (0xf < uVar3) {
        pppppuVar6 = (undefined4 *****)appppuStack_40[0];
      }
      FUN_005542c0(pppppuVar6,uVar2);
      DAT_01ea8d14 = (int)pppuStack_28 * 0x3c;
      DAT_01ea8d10 = DAT_01ea8d14 + 300;
      FUN_0152de00();
      if (DAT_01e90d59 != '\0') {
        FUN_01677520(DAT_01e90d59,"Soap Microprofiling Popped job from queue");
      }
      DAT_01ea8d0c = 1;
    }
    uStack_8._0_1_ = 1;
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_40[0];
      if (0xfff < uVar11) {
        pppppuVar6 = (undefined4 *****)appppuStack_40[0][-1];
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (uint)((int)appppuStack_40[0] + (-4 - (int)pppppuVar6))) {
LAB_005ce423:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar11);
    }
  }
  else if ((DAT_01ea8d10 == 0) || (DAT_01ea8d10 = DAT_01ea8d10 + -1, DAT_01ea8d10 == 0)) {
    appuStack_104[0] = &PTR_018bf148;
    appuStack_f4[0] = (undefined **)&DAT_018bf150;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_14 = 1;
    ppuStack_9c = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_a0 = 0x50;
    uStack_fc = 0;
    FUN_00554f20(appuStack_f4 + 2,0);
    *(undefined ***)((int)appuStack_f4 + (int)appuStack_f4[0][1]) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)appuStack_f4 + (int)(appuStack_f4[0][1] + -4)) = appuStack_f4[0][1] + -8;
    *(undefined ***)((int)appuStack_104 + (int)appuStack_104[0][1]) =
         std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)&iStack_108 + (int)appuStack_104[0][1]) = appuStack_104[0][1] + -0x20;
    uStack_8 = 10;
    *(undefined ***)((int)appuStack_104 + (int)appuStack_104[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_108 + (int)appuStack_104[0][1]) = appuStack_104[0][1] + -0x68;
    FUN_0054ee60();
    appuStack_f4[2] =
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_b4 = 0;
    uStack_b0 = 0;
    uStack_8._0_1_ = 0xb;
    FUN_0152d8a0(appuStack_104,DAT_01ea8d14);
    FUN_0152dea0();
    puVar8 = &DAT_01d596d4;
    if (0xf < DAT_01d596e8) {
      puVar8 = DAT_01d596d4;
    }
    FUN_00565320(puVar8,2,0x40,1);
    *(undefined ***)((int)aiStack_1b4 + *(int *)(aiStack_1b4[0] + 4)) =
         std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
    *(int *)((int)aiStack_1b4 + *(int *)(aiStack_1b4[0] + 4) + -4) =
         *(int *)(aiStack_1b4[0] + 4) + -0x68;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    puVar10 = &DAT_018bdf50;
    if (iStack_164 == 0) {
      puVar10 = &DAT_018bdf48;
    }
    FUN_0056f130(appuStack_f4 + 2);
    iVar7 = FUN_005548a0();
    if (iVar7 == 0) {
      FUN_00554460((uint)(*(int *)((int)aiStack_17c + *(int *)(aiStack_1b4[0] + 4)) == 0) * 4 + 2 |
                   *(uint *)((int)aiStack_1b4 + *(int *)(aiStack_1b4[0] + 4) + 0xc),0);
    }
    if (DAT_01e90d59 != '\0') {
      puVar8 = &DAT_01d596d4;
      if (0xf < DAT_01d596e8) {
        puVar8 = DAT_01d596d4;
      }
      FUN_01677520(DAT_01e90d59,
                   "Soap Microprofiling Finishing job outputTicks: %d, filename: %s, open OK %s",
                   DAT_01ea8d14,puVar8,puVar10);
    }
    DAT_01ea8d0c = 0;
    FUN_00570460();
    FUN_005705c0();
  }
  uStack_8 = 0xd;
  FUN_0152dda0(uStack_24,uStack_20,uStack_1c);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 5385 ; VA 0x005ce430 ; FUN_005ce430 */

undefined * __thiscall FUN_005ce430(undefined *param_1,undefined4 *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)*param_2;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  *(undefined4 *)(param_1 + 0x18) = param_2[1];
  return param_1;
}



/* FUNCTION 5386 ; VA 0x005ce480 ; FUN_005ce480 */

undefined4 * __thiscall FUN_005ce480(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[6] = param_2[6];
  return param_1;
}



/* FUNCTION 5387 ; VA 0x005ce4d0 ; FUN_005ce4d0 */

undefined4 * __thiscall FUN_005ce4d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = param_2;
  uStack_8 = param_3;
  *param_1 = 0;
  cVar1 = FUN_00585a40(&uStack_c);
  if (cVar1 == '\0') {
    param_1[2] = uStack_c;
    param_1[3] = uStack_8;
    *param_1 = &DAT_018c6f25;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 5388 ; VA 0x005ce530 ; FUN_005ce530 */

undefined4 * __thiscall
FUN_005ce530(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int param_5)

{
  char cVar1;
  int iVar2;
  undefined **ppuVar3;
  uint in_stack_00000024;
  int in_stack_00000028;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_78;
  int iStack_74;
  int *piStack_70;
  int aiStack_58 [5];
  uint uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017995b8;
  pvStack_10 = ExceptionList;
  piStack_70 = &param_5;
  uStack_8 = 0;
  iStack_74 = 0x5ce577;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60();
  iStack_40 = in_stack_00000028;
  uStack_3c = param_2;
  uStack_38 = param_3;
  uStack_34 = param_4;
  piStack_70 = aiStack_58;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  iStack_74 = 0x5ce5a5;
  FUN_0054ef60();
  iStack_18 = iStack_40;
  piStack_70 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = &uStack_98;
  uStack_98 = uStack_3c;
  uStack_94 = uStack_38;
  uStack_90 = uStack_34;
  FUN_0054ef60(aiStack_30);
  iStack_74 = iStack_18;
  ppuVar3 = &PTR_FUN_018c6f2c;
  cVar1 = FUN_005cebb0();
  if (cVar1 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  if (0xf < uStack_1c) {
    piStack_70 = (int *)(uStack_1c + 1);
    iVar2 = aiStack_30[0];
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      piStack_70 = (int *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)0x5ce69c;
        FUN_017167a3();
      }
    }
    uStack_78 = 0x5ce620;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < uStack_44) {
    piStack_70 = (int *)(uStack_44 + 1);
    iVar2 = aiStack_58[0];
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(aiStack_58[0] + -4);
      piStack_70 = (int *)(uStack_44 + 0x24);
      if (0x1f < (aiStack_58[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)0x5ce6a1;
        FUN_017167a3();
      }
    }
    uStack_78 = 0x5ce650;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000024) {
    piStack_70 = (int *)(in_stack_00000024 + 1);
    iVar2 = param_5;
    if (0xfff < piStack_70) {
      iVar2 = *(int *)(param_5 + -4);
      piStack_70 = (int *)(in_stack_00000024 + 0x24);
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_70 = (int *)&UNK_005ce6a6;
        FUN_017167a3();
      }
    }
    uStack_78 = 0x5ce680;
    iStack_74 = iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5389 ; VA 0x005ce6b0 ; FUN_005ce6b0 */

uint FUN_005ce6b0(undefined4 *param_1,char *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  uint uVar4;
  
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar4 = FUN_0055c360(param_1,*puVar1,param_2,(int)pcVar3 - (int)(param_2 + 1));
  return uVar4 ^ 1;
}



/* FUNCTION 5390 ; VA 0x005ce6f0 ; FUN_005ce6f0 */

undefined4 __thiscall FUN_005ce6f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  
  puVar5 = param_2;
  puVar3 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar3 = (undefined4 *)*param_2;
    puVar5 = (undefined4 *)*param_2;
  }
  if (puVar3 == (undefined4 *)(param_2[4] + (int)puVar5)) {
    return param_1;
  }
  iVar2 = FUN_01687bc0();
  iVar1 = param_2[4];
  if (iVar1 != 0) {
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uVar4 = FUN_01686580();
    FUN_01685950(param_2,(int)puVar3 + iVar1,param_1,uVar4);
  }
  if (iVar2 != 0) {
    FUN_01687c10(iVar2);
  }
  return param_1;
}



/* FUNCTION 5391 ; VA 0x005ce7a0 ; FUN_005ce7a0 */

void __thiscall FUN_005ce7a0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017995d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5392 ; VA 0x005ce80e ; Catch_All@005ce80e */

void Catch_All_005ce80e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00571be0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5393 ; VA 0x005ce830 ; FUN_005ce830 */

void __thiscall FUN_005ce830(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017995e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<bool>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5394 ; VA 0x005ce89e ; Catch_All@005ce89e */

void Catch_All_005ce89e(void)

{
  int unaff_EBP;
  
  FUN_01674ea0(*(undefined4 *)(unaff_EBP + 8),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5395 ; VA 0x005ce8c0 ; FUN_005ce8c0 */

int __thiscall FUN_005ce8c0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017995f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TimerService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5396 ; VA 0x005ce992 ; Catch_All@005ce992 */

void Catch_All_005ce992(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 5397 ; VA 0x005ce9b0 ; FUN_005ce9b0 */

void __thiscall FUN_005ce9b0(undefined4 *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  uint uVar5;
  uint uVar6;
  uint in_stack_0000003c;
  undefined4 in_stack_0000004c;
  uint in_stack_00000050;
  undefined4 uStack_110;
  undefined auStack_10c [80];
  undefined4 uStack_bc;
  undefined auStack_b8 [52];
  uint uStack_84;
  undefined4 uStack_74;
  uint uStack_70;
  undefined4 uStack_68;
  undefined auStack_64 [52];
  uint uStack_30;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799635;
  pvStack_10 = ExceptionList;
  uStack_bc = param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005cfc20(&stack0x00000008);
  uStack_110 = uStack_bc;
  uStack_8._0_1_ = 1;
  FUN_005cfc20(auStack_b8);
  uStack_8._0_1_ = 2;
  cVar2 = FUN_00585a40(&uStack_110);
  if (cVar2 == '\0') {
    uStack_68 = uStack_110;
    FUN_005cfc20(auStack_10c);
    uStack_8._0_1_ = 3;
    puVar3 = (undefined4 *)FUN_01674e20(0x54);
    uStack_8._0_1_ = 4;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_68;
      FUN_005cfc20(auStack_64);
    }
    param_1[2] = puVar3;
    if (0xf < uStack_1c) {
      uVar6 = uStack_1c + 1;
      uVar5 = uStack_30;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_30 - 4);
        uVar6 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    FUN_005d1210();
    FUN_005d1060();
    bVar1 = true;
  }
  else {
    FUN_005d1060();
    bVar1 = false;
  }
  if (0xf < uStack_70) {
    uVar6 = uStack_70 + 1;
    uVar5 = uStack_84;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_84 - 4);
      uVar6 = uStack_70 + 0x24;
      if (0x1f < (uStack_84 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = uStack_84 & 0xffffff00;
  FUN_005d1210();
  ppuVar4 = &PTR_FUN_018c6f00;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (0xf < in_stack_00000050) {
    uVar6 = in_stack_00000050 + 1;
    uVar5 = in_stack_0000003c;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(in_stack_0000003c - 4);
      uVar6 = in_stack_00000050 + 0x24;
      if (0x1f < (in_stack_0000003c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  in_stack_0000004c = 0;
  in_stack_00000050 = 0xf;
  in_stack_0000003c = in_stack_0000003c & 0xffffff00;
  FUN_005d1210();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5398 ; VA 0x005cebb0 ; FUN_005cebb0 */

undefined FUN_005cebb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined uVar9;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  int aiStack_58 [5];
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799667;
  pvStack_10 = ExceptionList;
  uStack_3c = param_1;
  uStack_38 = param_2;
  uStack_34 = param_3;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_4);
  uStack_18 = in_stack_00000028;
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(&uStack_3c);
  uVar3 = uStack_34;
  uVar2 = uStack_38;
  uVar1 = uStack_3c;
  if (cVar4 == '\0') {
    FUN_0054ef60(auStack_30);
    uStack_40 = uStack_18;
    uStack_8._0_1_ = 2;
    puVar5 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar1;
      puVar5[1] = uVar2;
      puVar5[2] = uVar3;
      FUN_0054ef60(aiStack_58);
      puVar5[9] = uStack_40;
    }
    *in_stack_0000002c = (int)puVar5;
    if (0xf < uStack_44) {
      uVar7 = uStack_44 + 1;
      iVar6 = aiStack_58[0];
      if (0xfff < uVar7) {
        iVar6 = *(int *)(aiStack_58[0] + -4);
        uVar7 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      uVar7 = auStack_30[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_30[0] - 4);
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uVar9 = 1;
  }
  else {
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      uVar7 = auStack_30[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_30[0] - 4);
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uVar9 = 0;
  }
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_1c = 0xf;
  uStack_20 = 0;
  if (0xf < in_stack_00000024) {
    uVar7 = in_stack_00000024 + 1;
    iVar6 = param_4;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(param_4 + -4);
      uVar7 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 5399 ; VA 0x005ced90 ; FUN_005ced90 */

undefined4 *
FUN_005ced90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int *in_stack_00000038;
  undefined4 *in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_00000054;
  undefined *in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined4 uStack_a4;
  int *piStack_a0;
  undefined4 *puStack_9c;
  undefined auStack_98 [24];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined *puStack_78;
  uint uStack_34;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017996c8;
  pvStack_10 = ExceptionList;
  puStack_78 = (undefined *)in_stack_00000060;
  uStack_7c = in_stack_0000005c;
  uStack_8 = 4;
  uStack_80 = in_stack_00000058;
  puStack_9c = &stack0x00000040;
  piStack_a0 = (int *)0x5cedd7;
  ExceptionList = &pvStack_10;
  in_stack_00000058 = auStack_98;
  FUN_0054ef60();
  puStack_9c = in_stack_0000003c;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  uStack_a4 = in_stack_00000034;
  piStack_a0 = in_stack_00000038;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  in_stack_0000003c = &uStack_a4;
  FUN_0054ef60(&param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  puStack_78 = (undefined *)FUN_005cfd00(param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  *param_1 = param_2;
  uStack_7c = 0x5cee93;
  FUN_005cfc20();
  if (0xf < uStack_20) {
    puStack_78 = (undefined *)(uStack_20 + 1);
    uVar3 = uStack_34;
    if (0xfff < puStack_78) {
      uVar3 = *(uint *)(uStack_34 - 4);
      puStack_78 = (undefined *)(uStack_20 + 0x24);
      if (0x1f < (uStack_34 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_78 = (undefined *)0x5cefd2;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x5ceec4;
    uStack_7c = uVar3;
    FUN_01674ea0();
  }
  puStack_78 = (undefined *)0x5ceee1;
  FUN_005d1210();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[2] + -1;
    param_4[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      puStack_78 = (undefined *)0x5ceef9;
      (**(code **)(*param_4 + 4))();
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_78 = (undefined *)(in_stack_00000028 + 1);
    uVar3 = param_5;
    if (0xfff < puStack_78) {
      uVar3 = *(uint *)(param_5 - 4);
      puStack_78 = (undefined *)(in_stack_00000028 + 0x24);
      if (0x1f < (param_5 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_78 = (undefined *)0x5cefd7;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x5cef2a;
    uStack_7c = uVar3;
    FUN_01674ea0();
  }
  piVar2 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      puStack_78 = (undefined *)0x5cef55;
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_78 = (undefined *)0x5cef65;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = in_stack_00000038;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar4 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      puStack_78 = (undefined *)0x5cef7b;
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        puStack_78 = (undefined *)0x5cef8a;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000054) {
    puStack_78 = (undefined *)(in_stack_00000054 + 1);
    iVar4 = in_stack_00000040;
    if (0xfff < puStack_78) {
      iVar4 = *(int *)(in_stack_00000040 + -4);
      puStack_78 = (undefined *)(in_stack_00000054 + 0x24);
      if (0x1f < (in_stack_00000040 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_78 = &UNK_005cefdc;
        FUN_017167a3();
      }
    }
    uStack_80 = 0x5cefb7;
    uStack_7c = iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5400 ; VA 0x005cefe0 ; FUN_005cefe0 */

undefined4 *
FUN_005cefe0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int param_5)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int aiStack_78 [5];
  uint uStack_64;
  undefined4 uStack_60;
  int aiStack_5c [5];
  uint uStack_48;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799708;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(aiStack_5c);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_44);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(aiStack_2c);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_60 = in_stack_0000002c;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_30) {
    uVar3 = uStack_30 + 1;
    iVar2 = aiStack_44[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      uVar3 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_48) {
    uVar3 = uStack_48 + 1;
    iVar2 = aiStack_5c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_5c[0] + -4);
      uVar3 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  FUN_0054ef60(aiStack_78);
  param_1[9] = uStack_60;
  if (0xf < uStack_64) {
    uVar3 = uStack_64 + 1;
    iVar2 = aiStack_78[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_78[0] + -4);
      uVar3 = uStack_64 + 0x24;
      if (0x1f < (aiStack_78[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_00000028) {
    uVar3 = in_stack_00000028 + 1;
    iVar2 = param_5;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_5 + -4);
      uVar3 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5401 ; VA 0x005cf1e0 ; FUN_005cf1e0 */

undefined4 * FUN_005cf1e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799750;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009eead0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x6c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_009eecb0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_005ce8c0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5402 ; VA 0x005cf2a0 ; FUN_005cf2a0 */

int FUN_005cf2a0(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799768;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ea8ddc,&LAB_005cf1c0);
  uVar2 = FUN_005cf500();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_009eebd0();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_005cf1e0(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ea8ddc,&LAB_005cf1c0);
      uVar2 = FUN_005cf500();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 5403 ; VA 0x005cf430 ; FUN_005cf430 */

void FUN_005cf430(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 5404 ; VA 0x005cf480 ; FUN_005cf480 */

undefined4 FUN_005cf480(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179978c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8df8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8df8);
    if (DAT_01ea8df8 == -1) {
      uStack_8 = 0;
      DAT_01ea8df4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8df8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8df4;
}



/* FUNCTION 5405 ; VA 0x005cf500 ; FUN_005cf500 */

undefined4 FUN_005cf500(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017997ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8de8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8de8);
    if (DAT_01ea8de8 == -1) {
      uStack_8 = 0;
      DAT_01ea8de4 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8de8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8de4;
}



/* FUNCTION 5406 ; VA 0x005cf580 ; FUN_005cf580 */

undefined4 FUN_005cf580(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017997cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8e08) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8e08);
    if (DAT_01ea8e08 == -1) {
      uStack_8 = 0;
      DAT_01ea8e04 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ea8e08);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8e04;
}



/* FUNCTION 5407 ; VA 0x005cf600 ; FUN_005cf600 */

int * __thiscall FUN_005cf600(byte *param_1,int *param_2,int param_3,int param_4)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017997e8;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uStack_14,iVar2,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_3 != 0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  uStack_8 = 0;
  FUN_005d2a40();
  iVar3 = iStack_1c;
  iVar2 = param_4;
  FUN_0054ef60(param_4);
  *(undefined4 *)(iVar3 + 0x20) = *(undefined4 *)(iVar2 + 0x18);
  uStack_18._1_1_ = '\x01';
  FUN_005d99d0(*(int *)(param_1 + 8) + 1);
  piVar4 = (int *)FUN_005c5550(&param_3,&uStack_20,uStack_14);
  iVar2 = iStack_1c;
  *param_2 = *piVar4;
  *(undefined *)(param_2 + 1) = 1;
  if (iStack_1c != 0) {
    if (uStack_18._1_1_ != '\0') {
      FUN_005cf430(uStack_20,iStack_1c + 8);
    }
    FUN_01674ea0(iVar2,0x24);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5408 ; VA 0x005cf720 ; FUN_005cf720 */

int __fastcall FUN_005cf720(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_009fb200();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 5409 ; VA 0x005cf750 ; FUN_005cf750 */

int FUN_005cf750(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
  uVar3 = FUN_00560c40();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00961660();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 5410 ; VA 0x005cf810 ; FUN_005cf810 */

int FUN_005cf810(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
  uVar3 = FUN_005cf480();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009fb760();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 5411 ; VA 0x005cf8d0 ; FUN_005cf8d0 */

int FUN_005cf8d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 == 0) {
    return 0;
  }
  FUN_005789c0(&DAT_01ea8dfc,&LAB_005cf1d0);
  uVar3 = FUN_005cf580();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009ef740();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return *piVar4;
}



/* FUNCTION 5412 ; VA 0x005cf990 ; FUN_005cf990 */

void FUN_005cf990(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  param_1[6] = *param_3;
  return;
}



/* FUNCTION 5413 ; VA 0x005cf9e0 ; FUN_005cf9e0 */

int * FUN_005cf9e0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
  uVar3 = FUN_005cf480();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009fb760();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5414 ; VA 0x005cfa90 ; FUN_005cfa90 */

int * FUN_005cfa90(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01ea8ddc,&LAB_005cf1c0);
  uVar3 = FUN_005cf500();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_009eebd0();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return piVar4;
}



/* FUNCTION 5415 ; VA 0x005cfb40 ; FUN_005cfb40 */

undefined4 * __thiscall FUN_005cfb40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799829;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_2 + 0xd);
  param_1[0x13] = param_2[0x13];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5416 ; VA 0x005cfc20 ; FUN_005cfc20 */

undefined4 * __thiscall FUN_005cfc20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799850;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  uStack_8 = 1;
  FUN_0054ef60(param_2 + 0xd);
  param_1[0x13] = param_2[0x13];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5417 ; VA 0x005cfd00 ; FUN_005cfd00 */

undefined4 __thiscall FUN_005cfd00(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017998a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005d0960(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5418 ; VA 0x005cfef0 ; FUN_005cfef0 */

undefined4 * __thiscall
FUN_005cfef0(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017998e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[2] + -1;
    param_3[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < uStack_20) {
    uVar4 = uStack_20 + 1;
    iVar3 = aiStack_34[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_34[0] + -4);
      uVar4 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  param_1[8] = in_stack_00000024;
  param_1[9] = in_stack_00000028;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[2] + -1;
    param_3[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    uVar4 = param_4;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_4 - 4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  piVar1 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar3 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5419 ; VA 0x005d00a0 ; FUN_005d00a0 */

int __thiscall FUN_005d00a0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01799918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_005cfef0(param_2,param_3);
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x28) = in_stack_0000002c;
  *(int **)(param_1 + 0x2c) = in_stack_00000030;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5420 ; VA 0x005d0230 ; FUN_005d0230 */

int __thiscall FUN_005d0230(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01799960;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8 = 5;
  uStack_7 = 0;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  FUN_005d00a0(param_2,param_3);
  *(undefined4 *)(param_1 + 0x30) = in_stack_00000034;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5421 ; VA 0x005d03c0 ; FUN_005d03c0 */

undefined4 __thiscall FUN_005d03c0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017999b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8 = 6;
  uStack_7 = 0;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_005d0230(param_2,param_3);
  _uStack_8 = CONCAT31(uStack_7,7);
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5422 ; VA 0x005d05a0 ; FUN_005d05a0 */

int __thiscall FUN_005d05a0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017998a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005d03c0(param_2,param_3);
  *(undefined4 *)(param_1 + 0x4c) = in_stack_00000050;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5423 ; VA 0x005d0780 ; FUN_005d0780 */

undefined4 __thiscall FUN_005d0780(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017998a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005d05a0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5424 ; VA 0x005d0960 ; FUN_005d0960 */

undefined4 __thiscall FUN_005d0960(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017998a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_005d0780(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    if (0xfff < in_stack_00000020 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5425 ; VA 0x005d0b40 ; FUN_005d0b40 */

undefined * __thiscall FUN_005d0b40(undefined *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  uVar1 = FUN_00588320(param_2);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  return param_1;
}



/* FUNCTION 5426 ; VA 0x005d0b80 ; FUN_005d0b80 */

int * __thiscall FUN_005d0b80(int *param_1,uint param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x3fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00577ed0(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = *param_1 + param_2 * 4;
    puVar2 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar2 = *param_3;
        puVar2 = puVar2 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (int)puVar2;
  }
  return param_1;
}



/* FUNCTION 5427 ; VA 0x005d0bf0 ; FUN_005d0bf0 */

undefined4 * __fastcall FUN_005d0bf0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017999ec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 1;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0xb] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0xc) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 2;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x1e] = 0x1e;
  param_1[0x1f] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined *)(param_1 + 0x20) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5428 ; VA 0x005d0d40 ; FUN_005d0d40 */

undefined4 * __thiscall FUN_005d0d40(undefined4 *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float10 fVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_01799a60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[6] = *param_2;
  param_1[7] = param_2[1];
  uStack_8 = 3;
  uStack_7 = 0;
  fVar5 = (float10)FUN_01160660();
  *(double *)(param_1 + 8) = (double)fVar5;
  *(undefined *)(param_1 + 10) = 0;
  uVar3 = FUN_00588320(0xb);
  param_1[0xb] = uVar3;
  param_1[0xc] = 0;
  param_1[0xd] = 0x3f800000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x10] = *param_3;
  param_1[0x11] = param_3[1];
  puVar4 = (undefined4 *)(*param_3 + 0x30);
  uStack_8 = 5;
  if (0xf < *(uint *)(*param_3 + 0x44)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_01675640(param_1 + 0x12,"games.api.%s",puVar4);
  puVar4 = (undefined4 *)(*param_3 + 0x30);
  uStack_8 = 6;
  if (0xf < *(uint *)(*param_3 + 0x44)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_01675640(param_1 + 0x18,"gameinstances.api.%s",puVar4);
  puVar4 = (undefined4 *)(*param_3 + 0x30);
  uStack_8 = 7;
  if (0xf < *(uint *)(*param_3 + 0x44)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_01675640(param_1 + 0x1e,"assetgame.%s",puVar4);
  puVar4 = (undefined4 *)(*param_3 + 0x30);
  _uStack_8 = CONCAT31(uStack_7,8);
  if (0xf < *(uint *)(*param_3 + 0x44)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_01675640(param_1 + 0x24,"api.%s",puVar4);
  if ((DAT_01d59fd0 == '\0') || (*(int *)(param_1[0x10] + 0x10) == 3)) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
  }
  *(undefined *)(param_1 + 0x2a) = uVar2;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x36] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x37] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5429 ; VA 0x005d0f00 ; FUN_005d0f00 */

undefined * __fastcall FUN_005d0f00(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  param_1[0x18] = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  param_1[0x30] = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  param_1[0x48] = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  param_1[0x60] = 0;
  return param_1;
}



/* FUNCTION 5430 ; VA 0x005d0f60 ; FUN_005d0f60 */

void __fastcall FUN_005d0f60(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x34);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_005d1057;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  piVar4 = *(int **)(param_1 + 0x2c);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0x24);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar2 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_005d1057:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x005d1050. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar4 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 5431 ; VA 0x005d1060 ; FUN_005d1060 */

void __fastcall FUN_005d1060(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x4c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x38);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0xf;
  *(undefined *)(param_1 + 0x38) = 0;
  FUN_005d1210();
  return;
}



/* FUNCTION 5432 ; VA 0x005d10c0 ; FUN_005d10c0 */

void __fastcall FUN_005d10c0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x34);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0xf;
  *(undefined *)(param_1 + 0x34) = 0;
  FUN_005d1210();
  return;
}



/* FUNCTION 5433 ; VA 0x005d1120 ; FUN_005d1120 */

void __fastcall FUN_005d1120(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_005cf430(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 5434 ; VA 0x005d1150 ; FUN_005d1150 */

void __fastcall FUN_005d1150(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00560a10(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x38);
  }
  return;
}



/* FUNCTION 5435 ; VA 0x005d1180 ; FUN_005d1180 */

void __fastcall FUN_005d1180(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x18);
  }
  return;
}



/* FUNCTION 5436 ; VA 0x005d11a0 ; FUN_005d11a0 */

void __fastcall FUN_005d11a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005d11f9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 5437 ; VA 0x005d1210 ; FUN_005d1210 */

void __fastcall FUN_005d1210(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_005d11a0();
  return;
}



/* FUNCTION 5438 ; VA 0x005d1270 ; FUN_005d1270 */

void __fastcall FUN_005d1270(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_005d11a0();
  return;
}



/* FUNCTION 5439 ; VA 0x005d1280 ; FUN_005d1280 */

void __fastcall FUN_005d1280(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_005d133d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_005d133d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 5440 ; VA 0x005d1350 ; FUN_005d1350 */

void __fastcall FUN_005d1350(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_005d133d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_005d133d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 5441 ; VA 0x005d1360 ; FUN_005d1360 */

undefined4 * __thiscall FUN_005d1360(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  if (param_1 != param_2) {
    FUN_005507b0();
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    uVar3 = param_2[3];
    *param_1 = *param_2;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
  }
  puVar4 = param_2 + 6;
  if (param_1 + 6 != puVar4) {
    FUN_005507b0();
    uVar1 = param_2[7];
    uVar2 = param_2[8];
    uVar3 = param_2[9];
    param_1[6] = *puVar4;
    param_1[7] = uVar1;
    param_1[8] = uVar2;
    param_1[9] = uVar3;
    *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    param_2[10] = 0;
    param_2[0xb] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  puVar4 = param_2 + 0xc;
  if (param_1 + 0xc != puVar4) {
    FUN_005507b0();
    uVar1 = param_2[0xd];
    uVar2 = param_2[0xe];
    uVar3 = param_2[0xf];
    param_1[0xc] = *puVar4;
    param_1[0xd] = uVar1;
    param_1[0xe] = uVar2;
    param_1[0xf] = uVar3;
    *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    param_2[0x10] = 0;
    param_2[0x11] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  puVar4 = param_2 + 0x12;
  if (param_1 + 0x12 != puVar4) {
    FUN_005507b0();
    uVar1 = param_2[0x13];
    uVar2 = param_2[0x14];
    uVar3 = param_2[0x15];
    param_1[0x12] = *puVar4;
    param_1[0x13] = uVar1;
    param_1[0x14] = uVar2;
    param_1[0x15] = uVar3;
    *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
    param_2[0x16] = 0;
    param_2[0x17] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  puVar4 = param_2 + 0x18;
  if (param_1 + 0x18 != puVar4) {
    FUN_005507b0();
    uVar1 = param_2[0x19];
    uVar2 = param_2[0x1a];
    uVar3 = param_2[0x1b];
    param_1[0x18] = *puVar4;
    param_1[0x19] = uVar1;
    param_1[0x1a] = uVar2;
    param_1[0x1b] = uVar3;
    *(undefined8 *)(param_1 + 0x1c) = *(undefined8 *)(param_2 + 0x1c);
    param_2[0x1c] = 0;
    param_2[0x1d] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  return param_1;
}



/* FUNCTION 5442 ; VA 0x005d1470 ; FUN_005d1470 */

int __thiscall FUN_005d1470(byte *param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int aiStack_38 [5];
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799a80;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar4,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return param_2 + 8;
  }
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_20 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  FUN_005d2a40();
  iVar4 = iStack_1c;
  FUN_0054ef60(aiStack_38);
  if ((undefined4 *)(iVar4 + 0x20) != (undefined4 *)0x0) {
    *(undefined4 *)(iVar4 + 0x20) = 0;
  }
  uStack_18._1_1_ = '\x01';
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_24) {
    uVar5 = uStack_24 + 1;
    iVar4 = aiStack_38[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_38[0] + -4);
      uVar5 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  FUN_005d99d0(*(int *)(param_1 + 8) + 1);
  piVar3 = (int *)FUN_005c5550(&param_2,&uStack_20,uStack_14);
  iVar2 = iStack_1c;
  iVar4 = *piVar3;
  if (iStack_1c != 0) {
    if (uStack_18._1_1_ != '\0') {
      FUN_005cf430(uStack_20,iStack_1c + 8);
    }
    FUN_01674ea0(iVar2,0x24);
  }
  ExceptionList = pvStack_10;
  return iVar4 + 8;
}



/* FUNCTION 5443 ; VA 0x005d15d0 ; FUN_005d15d0 */

int * __thiscall FUN_005d15d0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799aa0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005702d0(param_2);
  uStack_14 = uVar3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar10 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar9 = uStack_14;
    if (puVar10 == (undefined4 *)0x0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)*puVar10;
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      if (uVar3 == puVar10[1]) {
        piVar4 = puVar10 + 2;
        if (0xf < (uint)puVar10[7]) {
          piVar4 = (int *)*piVar4;
        }
        puVar6 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar6 = (undefined4 *)*param_2;
        }
        cVar2 = FUN_0055c360(puVar6,param_2[4],piVar4,puVar10[6]);
        uVar9 = uStack_14;
        if (cVar2 != '\0') {
          if (puVar10 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar10 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar10[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != -3) & param_1 + 4U;
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar4 = (int *)FUN_01674e20(0x38);
  piStack_18 = piVar4 + 2;
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_20 = piVar4;
  FUN_0170d1f0(piStack_18,0,0x30);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  piVar4[0xc] = 0;
  piVar4[0xd] = 0xf;
  *(undefined *)(piVar4 + 8) = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar9) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar9 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005d6bb0(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    uStack_14 = 1;
    uVar7 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar9) {
      uVar7 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar7 + uVar1);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar6 = (undefined4 *)*puVar10;
      while (puVar6 != (undefined4 *)0x0) {
        uVar9 = (uint)puVar6[1] % *(uint *)(param_1 + 4);
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar9 * 4) == 0) {
          *piVar8 = (int)puVar10;
          puVar10 = puVar6;
        }
        else {
          *puVar10 = *puVar6;
          *puVar6 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar6;
        }
        puVar6 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uVar3;
  uVar3 = uVar3 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *puVar10 = piVar8;
    *piVar4 = *piVar8;
  }
  else {
    *piVar4 = *piVar8;
    piVar8 = (int *)*puVar10;
  }
  *piVar8 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 5444 ; VA 0x005d1850 ; FUN_005d1850 */

int * __thiscall FUN_005d1850(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799ab8;
  pvStack_10 = ExceptionList;
  uVar3 = param_2[1];
  iVar4 = *param_2;
  uVar8 = uVar3;
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar8 = ~uVar3;
  }
  uVar8 = (uVar8 >> 2) + uVar8 * 0x40 + iVar4 ^ uVar8;
  uVar9 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar8 == puVar5[1]) {
        if ((iVar4 == puVar5[2]) && (uVar3 == puVar5[3])) {
          return puVar5 + 2;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar9) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01674e20(0x18);
  *piVar2 = 0;
  piVar2[1] = 0;
  piVar2[4] = 0;
  piVar2[5] = 0;
  piVar2[3] = uVar3;
  piVar7 = piVar2 + 4;
  piVar2[2] = iVar4;
  if (piVar7 != (int *)0x0) {
    piVar7[0] = 0;
    piVar7[1] = 0;
  }
  uVar9 = *(uint *)(param_1 + 8);
  uVar3 = uVar9 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    uVar6 = uVar9 >> 1;
    if (uVar9 + (uVar9 >> 1) <= uVar3) {
      uVar6 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar6 + uVar9);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar5;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar7 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar7 = (int)puVar5;
          puVar5 = puVar1;
        }
        else {
          *puVar5 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar7;
          *(undefined4 **)*piVar7 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar5;
      }
    }
  }
  piVar2[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar2;
    }
    *puVar5 = piVar7;
    *piVar2 = *piVar7;
  }
  else {
    *piVar2 = *piVar7;
    piVar7 = (int *)*puVar5;
  }
  *piVar7 = (int)piVar2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar2 + 2;
}



/* FUNCTION 5445 ; VA 0x005d1a60 ; FUN_005d1a60 */

int __thiscall FUN_005d1a60(byte *param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int aiStack_38 [5];
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined2 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799a80;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar5,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_2 == 0) {
    iStack_1c = 0;
    uStack_18 = 0;
    uStack_20 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
    iStack_8 = 0;
    FUN_0054ef60(iVar5);
    iStack_8._0_1_ = 1;
    FUN_005d2a40();
    iVar5 = iStack_1c;
    FUN_0054ef60(aiStack_38);
    if ((undefined4 *)(iVar5 + 0x20) != (undefined4 *)0x0) {
      *(undefined4 *)(iVar5 + 0x20) = 0;
    }
    uStack_18._1_1_ = '\x01';
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_24) {
      uVar4 = uStack_24 + 1;
      iVar5 = aiStack_38[0];
      if (0xfff < uVar4) {
        iVar5 = *(int *)(aiStack_38[0] + -4);
        uVar4 = uStack_24 + 0x24;
        if (0x1f < (aiStack_38[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar4);
    }
    FUN_005d99d0(*(int *)(param_1 + 8) + 1);
    piVar3 = (int *)FUN_005c5550(&param_2,&uStack_20,uStack_14);
    iVar2 = iStack_1c;
    iVar5 = *piVar3 + 8;
    if (iStack_1c != 0) {
      if (uStack_18._1_1_ != '\0') {
        FUN_005cf430(uStack_20,iStack_1c + 8);
      }
      FUN_01674ea0(iVar2,0x24);
    }
  }
  else {
    iVar5 = param_2 + 8;
  }
  ExceptionList = pvStack_10;
  return iVar5 + 0x18;
}



/* FUNCTION 5446 ; VA 0x005d1bb0 ; FUN_005d1bb0 */

int __thiscall FUN_005d1bb0(int *param_1,int param_2)

{
  return *param_1 + param_2 * 4;
}



/* FUNCTION 5447 ; VA 0x005d1bc0 ; FUN_005d1bc0 */

int __thiscall FUN_005d1bc0(int *param_1,int param_2)

{
  return *param_1 + param_2 * 8;
}



/* FUNCTION 5448 ; VA 0x005d1bd0 ; FUN_005d1bd0 */

void __fastcall FUN_005d1bd0(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  undefined auStack_1f4 [80];
  undefined auStack_1a4 [80];
  undefined auStack_154 [80];
  undefined auStack_104 [80];
  undefined auStack_b4 [80];
  undefined4 uStack_64;
  int iStack_60;
  undefined4 uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799b47;
  pvStack_10 = ExceptionList;
  if ((*(char *)param_1[10] == '\0') &&
     (ExceptionList = &pvStack_10, iVar2 = FUN_005cf2a0(), iVar2 != 0)) {
    puStack_14 = &uStack_64;
    iStack_60 = param_1[1];
    if (iStack_60 != 0) {
      LOCK();
      *(int *)(iStack_60 + 8) = *(int *)(iStack_60 + 8) + 1;
      UNLOCK();
      iStack_60 = param_1[1];
    }
    uStack_64 = *param_1;
    uStack_8 = 0;
    FUN_0054ef60(param_1 + 2);
    iStack_40 = param_1[9];
    if (iStack_40 != 0) {
      LOCK();
      *(int *)(iStack_40 + 4) = *(int *)(iStack_40 + 4) + 1;
      UNLOCK();
      iStack_40 = param_1[9];
    }
    uStack_44 = param_1[8];
    iStack_38 = param_1[0xb];
    if (iStack_38 != 0) {
      LOCK();
      *(int *)(iStack_38 + 4) = *(int *)(iStack_38 + 4) + 1;
      UNLOCK();
      iStack_38 = param_1[0xb];
    }
    uStack_3c = param_1[10];
    uStack_34 = param_1[0xc];
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0054ef60(param_1 + 0xd);
    uStack_18 = param_1[0x13];
    uStack_8 = 4;
    FUN_005cfb40(&uStack_64);
    uStack_8._0_1_ = 5;
    FUN_005cfb40(auStack_1f4);
    uStack_8._0_1_ = 6;
    FUN_005cfb40(auStack_1a4);
    uStack_8._0_1_ = 7;
    FUN_005cfb40(auStack_154);
    uStack_8._0_1_ = 8;
    cVar1 = FUN_00585a40(auStack_b4);
    if (cVar1 == '\0') {
      FUN_005cfb40(auStack_b4);
      uStack_8._0_1_ = 9;
      puStack_14 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 10;
      if (puStack_14 != (undefined4 *)0x0) {
        FUN_005cfb40(auStack_104);
      }
      FUN_005d0f60();
      FUN_005d0f60();
    }
    else {
      FUN_005d0f60();
    }
    FUN_005d0f60();
    FUN_005d0f60();
    FUN_005d0f60();
    uStack_8 = 0xffffffff;
    FUN_005d0f60();
    FUN_009eef30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5449 ; VA 0x005d1e10 ; FUN_005d1e10 */

void FUN_005d1e10(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  int iVar6;
  int aiStack_5c [5];
  uint uStack_48;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_01799b89;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_34 = 0;
  uStack_30 = 7;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffff0000);
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01518d10(aiStack_5c,1,0,&DAT_018c0e28);
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  iVar6 = puVar1[4];
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  uStack_14 = 1;
  if (iVar6 != 0) {
    puVar2 = puVar1;
    if (7 < (uint)puVar1[5]) {
      puVar2 = (undefined4 *)*puVar1;
    }
    if (7 < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    uVar3 = FUN_01686580();
    FUN_01685a20(puVar1,(int)puVar2 + iVar6 * 2,apppuStack_2c,uVar3);
  }
  uStack_34 = 0;
  ppppuVar4 = apppuStack_44;
  if (7 < uStack_30) {
    ppppuVar4 = (undefined4 ****)apppuStack_44[0];
  }
  *(undefined2 *)ppppuVar4 = 0;
  if (iStack_1c != 0) {
    ppppuVar4 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    }
    iVar6 = (int)ppppuVar4 + iStack_1c;
    ppppuVar4 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    }
    uVar3 = FUN_01686580();
    FUN_01685950(ppppuVar4,iVar6,apppuStack_44,uVar3);
  }
  iStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (7 < uStack_48) {
    uVar5 = uStack_48 * 2 + 2;
    iVar6 = aiStack_5c[0];
    if (0xfff < uVar5) {
      iVar6 = *(int *)(aiStack_5c[0] + -4);
      uVar5 = uStack_48 * 2 + 0x25;
      if (0x1f < (aiStack_5c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  FUN_005ce6f0(param_1);
  FUN_0168bc20(apppuStack_44,0);
  if (7 < uStack_30) {
    uVar5 = uStack_30 * 2 + 2;
    ppppuVar4 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)apppuStack_44[0][-1];
      uVar5 = uStack_30 * 2 + 0x25;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5450 ; VA 0x005d1ff0 ; FUN_005d1ff0 */

undefined * FUN_005d1ff0(undefined *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  int aiStack_5c [5];
  uint uStack_48;
  undefined4 ***apppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799be2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_1c = 0;
  uStack_18 = 7;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffff0000);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01518d10(aiStack_5c,1,0,&DAT_018c0e28);
  iStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  iVar8 = puVar2[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uStack_14 = 2;
  if (iVar8 != 0) {
    puVar3 = puVar2;
    if (7 < (uint)puVar2[5]) {
      puVar3 = (undefined4 *)*puVar2;
    }
    if (7 < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    uVar4 = FUN_01686580();
    FUN_01685a20(puVar2,(int)puVar3 + iVar8 * 2,apppuStack_44,uVar4);
  }
  iStack_1c = 0;
  ppppuVar5 = apppuStack_2c;
  if (7 < uStack_18) {
    ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
  }
  *(undefined2 *)ppppuVar5 = 0;
  if (iStack_34 != 0) {
    ppppuVar5 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar5 = (undefined4 ****)apppuStack_44[0];
    }
    iVar8 = (int)ppppuVar5 + iStack_34;
    ppppuVar5 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar5 = (undefined4 ****)apppuStack_44[0];
    }
    uVar4 = FUN_01686580();
    FUN_01685950(ppppuVar5,iVar8,apppuStack_2c,uVar4);
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_44[0][-1];
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  iStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (7 < uStack_48) {
    uVar6 = uStack_48 * 2 + 2;
    iVar8 = aiStack_5c[0];
    if (0xfff < uVar6) {
      iVar8 = *(int *)(aiStack_5c[0] + -4);
      uVar6 = uStack_48 * 2 + 0x25;
      if (0x1f < (aiStack_5c[0] - iVar8) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar6);
  }
  FUN_005ce6f0(param_2);
  FUN_005ce6f0(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 4;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (iStack_1c != 0) {
    ppppuVar5 = apppuStack_2c;
    if (7 < uStack_18) {
      ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
    }
    iVar8 = iStack_1c * 2;
    ppppuVar7 = apppuStack_2c;
    if (7 < uStack_18) {
      ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
    }
    uVar4 = FUN_01686580();
    FUN_01685a20(ppppuVar7,(undefined2 *)((int)ppppuVar5 + iVar8),param_1,uVar4);
  }
  if (7 < uStack_18) {
    uVar6 = uStack_18 * 2 + 2;
    ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar6 = uStack_18 * 2 + 0x25;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5451 ; VA 0x005d2220 ; FUN_005d2220 */

uint __thiscall FUN_005d2220(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0x40000000) {
    iVar1 = FUN_00577ed0(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar1 = *param_1 + param_2 * 4;
    param_1[2] = iVar1;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 5452 ; VA 0x005d2280 ; FUN_005d2280 */

void FUN_005d2280(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_0039b956a706ce0dfb3654c316d8b63f>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
             ::vftable;
  return;
}



/* FUNCTION 5453 ; VA 0x005d2290 ; FUN_005d2290 */

void __thiscall FUN_005d2290(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_02dc363b9a35ab9e2ee86a8d63dfd0fa>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5454 ; VA 0x005d22b0 ; FUN_005d22b0 */

void __thiscall FUN_005d22b0(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_59ca0768fa2655ef42894aca9e59632f>,void>::vftable
  ;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 5455 ; VA 0x005d22d0 ; FUN_005d22d0 */

void FUN_005d22d0(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_5ec7961a904fad14b9b35ea2c27dcfe0>,void,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
  return;
}



/* FUNCTION 5456 ; VA 0x005d22e0 ; FUN_005d22e0 */

void FUN_005d22e0(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_e488513700340f6127a1ed40ae0ee935>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
  return;
}



/* FUNCTION 5457 ; VA 0x005d22f0 ; FUN_005d22f0 */

void __fastcall FUN_005d22f0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    uVar2 = piVar1[5];
    if (0xf < uVar2) {
      iVar3 = *piVar1;
      uVar5 = uVar2 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    FUN_01674ea0(piVar1,0x18);
  }
  return;
}



/* FUNCTION 5458 ; VA 0x005d2350 ; FUN_005d2350 */

void __fastcall FUN_005d2350(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xc),1);
  return;
}



/* FUNCTION 5459 ; VA 0x005d2360 ; FUN_005d2360 */

undefined * FUN_005d2360(undefined *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799c09;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_009c9100(param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5460 ; VA 0x005d23c0 ; FUN_005d23c0 */

void FUN_005d23c0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799c39;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_14 = 1;
  ExceptionList = &pvStack_10;
  FUN_0058a190(param_2[4] + 1);
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_00554150(param_2,*puVar1);
  FUN_00554150(&DAT_018c1030,1);
  FUN_005d3680(DAT_01d59738,param_1,auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5461 ; VA 0x005d24a0 ; FUN_005d24a0 */

void __fastcall FUN_005d24a0(int param_1)

{
  *(undefined *)(*(int *)(param_1 + 4) + 0xd0) = 1;
  FUN_0152de00();
  return;
}



/* FUNCTION 5462 ; VA 0x005d24b0 ; FUN_005d24b0 */

void FUN_005d24b0(void)

{
  FUN_005d1e10();
  return;
}



/* FUNCTION 5463 ; VA 0x005d24c0 ; FUN_005d24c0 */

undefined4 FUN_005d24c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_005d1ff0(param_1,param_2,param_3);
  return param_1;
}



/* FUNCTION 5464 ; VA 0x005d24e0 ; FUN_005d24e0 */

TypeDescriptor * FUN_005d24e0(void)

{
  return &<lambda_0039b956a706ce0dfb3654c316d8b63f>::RTTI_Type_Descriptor;
}



/* FUNCTION 5465 ; VA 0x005d24f0 ; FUN_005d24f0 */

TypeDescriptor * FUN_005d24f0(void)

{
  return &<lambda_02dc363b9a35ab9e2ee86a8d63dfd0fa>::RTTI_Type_Descriptor;
}



/* FUNCTION 5466 ; VA 0x005d2500 ; FUN_005d2500 */

TypeDescriptor * FUN_005d2500(void)

{
  return &<lambda_59ca0768fa2655ef42894aca9e59632f>::RTTI_Type_Descriptor;
}



/* FUNCTION 5467 ; VA 0x005d2510 ; FUN_005d2510 */

TypeDescriptor * FUN_005d2510(void)

{
  return &<lambda_5ec7961a904fad14b9b35ea2c27dcfe0>::RTTI_Type_Descriptor;
}



/* FUNCTION 5468 ; VA 0x005d2520 ; FUN_005d2520 */

TypeDescriptor * FUN_005d2520(void)

{
  return &<lambda_e488513700340f6127a1ed40ae0ee935>::RTTI_Type_Descriptor;
}



/* FUNCTION 5469 ; VA 0x005d2530 ; FUN_005d2530 */

int FUN_005d2530(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined *puVar4;
  int iVar5;
  
  if ((undefined *)*param_1 != (undefined *)0x0) {
    *(undefined *)*param_1 = 1;
  }
  puVar4 = (undefined *)FUN_01674e20(1);
  if (puVar4 == (undefined *)0x0) {
    puVar4 = (undefined *)0x0;
  }
  else {
    *puVar4 = 0;
  }
  FUN_005ce830(puVar4,param_1);
  *param_1 = 0;
  piVar3 = (int *)param_1[1];
  iVar5 = 0;
  param_1[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar5;
}



/* FUNCTION 5470 ; VA 0x005d25b0 ; FUN_005d25b0 */

uint __fastcall FUN_005d25b0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  float10 fVar6;
  undefined8 uVar7;
  int iStack_20;
  int *piStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799c58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != 0) {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"RCCMonitoring::cacheServerStats started.",0);
  }
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_20 == 0) {
    uVar5 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d26cf;
    uVar7 = 0x18c67c0;
  }
  else {
    FUN_00562d80();
    if (DAT_01d597d4 == '\0') {
      fVar6 = (float10)FUN_009994d0();
    }
    else {
      fVar6 = (float10)FUN_00999eb0();
    }
    *(double *)(param_1 + 0xb0) = (double)fVar6;
    if (DAT_01d597e4 != '\0') {
      fVar6 = (float10)FUN_005d2710();
      *(double *)(param_1 + 200) = (double)fVar6;
    }
    iVar4 = FUN_005cf2a0();
    if (iVar4 == 0) {
      uVar5 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005d26cf;
      uVar7 = 0x18c6840;
    }
    else {
      FUN_005ce4d0(FUN_005d25b0,param_1,0);
      FUN_009eef30();
      uVar5 = (uint)DAT_01ea8d1c;
      if (DAT_01ea8d1c == 0) goto LAB_005d26cf;
      uVar7 = CONCAT44(DAT_01d59720,"TimerService scheduled next cache heartbeat in %d");
    }
  }
  uVar5 = FUN_016774b0(uVar5,uVar7);
LAB_005d26cf:
  if (piStack_1c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_1c + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar5 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 5471 ; VA 0x005d2710 ; FUN_005d2710 */

int * FUN_005d2710(void)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  char cVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int iVar10;
  char acStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  double dStack_44;
  int iStack_3c;
  int *piStack_38;
  double dStack_34;
  undefined auStack_28 [4];
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799c88;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff80;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_3c);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_3c == 0) {
    piVar5 = (int *)(uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      piVar5 = (int *)FUN_016774b0(DAT_01d596f0,
                                   "ERROR (calculateAveragePing) - DataModel is unexpectedly null.",
                                   0);
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_38 + 1);
      uVar3 = *puVar1;
      piVar5 = (int *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        piVar5 = (int *)(**(code **)*piStack_38)();
        LOCK();
        piVar7 = piStack_38 + 2;
        iVar8 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          piVar5 = (int *)(**(code **)(*piStack_38 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return piVar5;
  }
  iStack_1c = 0;
  dStack_34 = 0.0;
  dStack_44 = 0.0;
  FUN_005789c0(&DAT_01ea8dec,&LAB_005cf1b0);
  uVar6 = FUN_005cf480();
  piVar7 = (int *)FUN_008aa140(uVar6);
  piVar5 = piVar7;
  if (*piVar7 == 0) {
    uVar6 = FUN_009fb760();
    piVar5 = (int *)FUN_008a9ba0(auStack_28,uVar6);
    iVar8 = *piVar5;
    iVar10 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar7 = iVar8;
    piVar9 = (int *)piVar7[1];
    piVar7[1] = iVar10;
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar2 = piVar9 + 1;
      iVar8 = *piVar2;
      piVar5 = (int *)*piVar2;
      *piVar2 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        piVar2 = piVar9 + 2;
        iVar8 = *piVar2;
        piVar5 = (int *)*piVar2;
        *piVar2 = iVar8 + -1;
        UNLOCK();
        if (iVar8 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piVar9 + 4))();
        }
      }
    }
    piVar9 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_24 + 1;
      iVar8 = *piVar2;
      piVar5 = (int *)*piVar2;
      *piVar2 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar2 = piVar9 + 2;
        iVar8 = *piVar2;
        piVar5 = (int *)*piVar2;
        *piVar2 = iVar8 + -1;
        UNLOCK();
        if (iVar8 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piVar9 + 4))();
        }
      }
    }
  }
  if (*piVar7 != 0) {
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = 0;
    FUN_005542c0(&DAT_018c5904,7);
    uStack_8._0_1_ = 1;
    iVar8 = FUN_008a1240(auStack_5c);
    uStack_8._0_1_ = 0;
    iStack_18 = iVar8;
    piVar5 = (int *)FUN_005507b0();
    if (iVar8 != 0) {
      for (piVar7 = (int *)0x0; piStack_24 = piVar7, piVar5 = (int *)FUN_005d6c30(), piVar7 < piVar5
          ; piVar7 = (int *)((int)piVar7 + 1)) {
        piStack_20 = *(int **)(**(int **)(iVar8 + 0x2c) + (int)piVar7 * 8);
        piVar9 = (int *)piStack_20[10];
        piVar5 = piVar9 + 4;
        if (0xf < (uint)piVar9[5]) {
          piVar9 = (int *)*piVar9;
        }
        cVar4 = FUN_0055c360(piVar9,*piVar5,"Packets Thread",0xe);
        if (cVar4 == '\0') {
          uStack_64 = 0;
          uStack_60 = 0xf;
          acStack_74[0] = cVar4;
          FUN_005542c0(&DAT_018c5ca8,4);
          uStack_8._0_1_ = 2;
          piStack_20 = (int *)FUN_008a1240(acStack_74);
          uStack_8._0_1_ = 0;
          FUN_005507b0();
          if (piStack_20 != (int *)0x0) {
            iVar8 = piStack_20[3];
            iVar10 = FUN_009fb200();
            piVar5 = (int *)0x0;
            if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
                (uint)*(ushort *)(iVar10 + 0x1da)) {
              piVar5 = piStack_20;
            }
            iVar8 = iStack_18;
            if (piVar5 != (int *)0x0) {
              uStack_8 = CONCAT31(uStack_8._1_3_,3);
              (**(code **)(*piVar5 + 0xa4))();
              dStack_44 = *(double *)(piVar5 + 0x16) + dStack_34;
              iStack_1c = iStack_1c + 1;
              piVar5 = (int *)FUN_005d29c3();
              return piVar5;
            }
          }
        }
      }
      if (0 < iStack_1c) {
        dStack_44 = dStack_34 / (double)iStack_1c;
        goto LAB_005d29ff;
      }
    }
  }
  dStack_44 = 0.0;
LAB_005d29ff:
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piVar7 = piStack_38 + 1;
    iVar8 = *piVar7;
    piVar5 = (int *)*piVar7;
    *piVar7 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_38)();
      LOCK();
      piVar7 = piStack_38 + 2;
      iVar8 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_38 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 5472 ; VA 0x005d298b ; Catch@005d298b */

undefined * Catch_005d298b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d596f0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x28) + 4))();
    FUN_016774b0(DAT_01d596f0,"ERROR - Exception when examining ping: %s",uVar1);
  }
  return &DAT_005d29b8;
}



/* FUNCTION 5473 ; VA 0x005d29c3 ; FUN_005d29c3 */

uint FUN_005d29c3(void)

{
  uint *puVar1;
  uint uVar2;
  double dVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  int *piVar7;
  undefined4 uVar8;
  int iVar9;
  int unaff_EBX;
  int unaff_EBP;
  int *piVar10;
  uint unaff_EDI;
  undefined8 in_XMM0_Qa;
  
  *(undefined8 *)(unaff_EBP + -0x30) = in_XMM0_Qa;
  *(undefined4 *)(unaff_EBP + -4) = 0;
  do {
    iVar4 = *(int *)(unaff_EBP + -0x14);
    do {
      do {
        unaff_EDI = unaff_EDI + 1;
        *(uint *)(unaff_EBP + -0x20) = unaff_EDI;
        uVar6 = FUN_005d6c30();
        if (uVar6 <= unaff_EDI) {
          if (*(int *)(unaff_EBP + -0x18) < 1) {
            *(undefined8 *)(unaff_EBP + -0x40) = 0;
          }
          else {
            *(double *)(unaff_EBP + -0x40) =
                 *(double *)(unaff_EBP + -0x30) / (double)*(int *)(unaff_EBP + -0x18);
          }
          piVar10 = *(int **)(unaff_EBP + -0x34);
          if (piVar10 != (int *)0x0) {
            LOCK();
            puVar1 = (uint *)(piVar10 + 1);
            uVar2 = *puVar1;
            uVar6 = *puVar1;
            *puVar1 = uVar2 + unaff_EBX;
            UNLOCK();
            if (uVar2 + unaff_EBX == 0) {
              uVar6 = (**(code **)*piVar10)();
              LOCK();
              piVar7 = piVar10 + 2;
              iVar4 = *piVar7;
              *piVar7 = *piVar7 + unaff_EBX;
              UNLOCK();
              if (iVar4 == 1) {
                uVar6 = (**(code **)(*piVar10 + 4))();
              }
            }
          }
          ExceptionList = *(void **)(unaff_EBP + -0xc);
          return uVar6;
        }
        iVar9 = *(int *)(**(int **)(iVar4 + 0x2c) + unaff_EDI * 8);
        *(int *)(unaff_EBP + -0x1c) = iVar9;
        piVar7 = *(int **)(iVar9 + 0x28);
        piVar10 = piVar7 + 4;
        if (0xf < (uint)piVar7[5]) {
          piVar7 = (int *)*piVar7;
        }
        cVar5 = FUN_0055c360(piVar7,*piVar10,"Packets Thread",0xe);
      } while (cVar5 != '\0');
      *(undefined4 *)(unaff_EBP + -0x60) = 0;
      *(undefined4 *)(unaff_EBP + -0x5c) = 0xf;
      *(undefined *)(unaff_EBP + -0x70) = 0;
      FUN_005542c0(&DAT_018c5ca8,4);
      *(undefined *)(unaff_EBP + -4) = 2;
      uVar8 = FUN_008a1240(unaff_EBP + -0x70);
      *(undefined4 *)(unaff_EBP + -0x1c) = uVar8;
      *(undefined *)(unaff_EBP + -4) = 0;
      FUN_005507b0();
    } while (*(int *)(unaff_EBP + -0x1c) == 0);
    iVar4 = *(int *)(*(int *)(unaff_EBP + -0x1c) + 0xc);
    iVar9 = FUN_009fb200();
    piVar10 = (int *)0x0;
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
        (uint)*(ushort *)(iVar9 + 0x1da)) {
      piVar10 = *(int **)(unaff_EBP + -0x1c);
    }
  } while (piVar10 == (int *)0x0);
  iVar4 = *piVar10;
  *(undefined *)(unaff_EBP + -4) = 3;
  (**(code **)(iVar4 + 0xa4))();
  dVar3 = *(double *)(piVar10 + 0x16);
  *(int *)(unaff_EBP + -0x18) = *(int *)(unaff_EBP + -0x18) + 1;
  *(double *)(unaff_EBP + -0x40) = dVar3 + *(double *)(unaff_EBP + -0x30);
  uVar6 = FUN_005d29c3();
  return uVar6;
}



/* FUNCTION 5474 ; VA 0x005d2a40 ; FUN_005d2a40 */

void __fastcall FUN_005d2a40(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x24);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined8 *)(puVar1 + 6) = 0;
    puVar1[8] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_005cf430(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 5475 ; VA 0x005d2aa0 ; FUN_005d2aa0 */

void __fastcall FUN_005d2aa0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x38);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    FUN_0170d1f0(puVar1 + 2,0,0x30);
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00560a10(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 5476 ; VA 0x005d2b00 ; FUN_005d2b00 */

/* WARNING: Removing unreachable block (ram,0x005d2bae) */
/* WARNING: Removing unreachable block (ram,0x005d2bfa) */
/* WARNING: Removing unreachable block (ram,0x005d2bf5) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_005d2b00(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799ca8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = (ulonglong)(uint)uStack_18;
  ExceptionList = &pvStack_10;
  FUN_005c24c0((int)&uStack_18 + 4,param_2 + 1);
  if (*(int *)(param_1 + 0x14) != 0) {
    *(undefined4 *)(param_2 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar4 = iVar1 + 4;
    iVar2 = *(int *)(param_1 + 0x14);
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x27;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5477 ; VA 0x005d2c20 ; FUN_005d2c20 */

void FUN_005d2c20(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 *param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  undefined uVar2;
  uint uVar3;
  undefined4 auStack_1bc [7];
  int iStack_1a0;
  int iStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined auStack_18c [20];
  undefined4 uStack_178;
  int iStack_174;
  undefined4 *puStack_170;
  undefined *puStack_16c;
  undefined4 auStack_168 [5];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_d4;
  undefined auStack_d0 [52];
  uint uStack_9c;
  undefined4 uStack_8c;
  uint uStack_88;
  undefined4 uStack_80;
  undefined auStack_7c [52];
  uint uStack_48;
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799cf6;
  pvStack_10 = ExceptionList;
  uStack_148 = 0;
  uStack_14c = 0;
  uStack_150 = param_2;
  uStack_154 = 0x5d2c53;
  ExceptionList = &pvStack_10;
  FUN_014cc090();
  iStack_8 = 0;
  if (DAT_01d5a4c0 == '\0') {
    uStack_148 = 0;
    iStack_20 = *param_3;
    puStack_18 = auStack_168;
    uStack_1c = CONCAT31(uStack_1c._1_3_,0x100 < *(uint *)(iStack_20 + 0x10));
    puStack_16c = (undefined *)(uint)DAT_01ea8d2d;
    puStack_170 = (undefined4 *)(uint)DAT_01ea8d2b;
    iStack_174 = param_7;
    puStack_24 = auStack_18c;
    uStack_190 = param_6;
    uStack_194 = 0x5d2cc7;
    FUN_0054ef60();
    uStack_190 = param_5;
    puStack_28 = (undefined *)&uStack_198;
    if (param_4[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_198 = *param_4;
    uStack_194 = param_4[1];
    puStack_2c = (undefined *)&iStack_1a0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iStack_1a0 = *param_3;
    iStack_19c = param_3[1];
    iStack_8._0_1_ = 3;
    auStack_1bc[0] = param_2;
    FUN_0054ef60();
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    auStack_1bc[0] = param_1[1];
    iStack_8._0_1_ = 0;
    FUN_005ced90(&uStack_d4,FUN_005d2ec0,*param_1);
    uStack_80 = uStack_d4;
    puStack_16c = auStack_d0;
    iStack_8._0_1_ = 4;
    puStack_170 = (undefined4 *)0x5d2d8e;
    FUN_005cfc20();
    auStack_1bc[0] = uStack_80;
    puStack_14 = (undefined *)auStack_1bc;
    iStack_8._0_1_ = 5;
    *puStack_18 = 0;
    FUN_005cfc20(auStack_7c);
    FUN_005ce9b0();
    iStack_8._0_1_ = 4;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 4;
    if (0xf < uStack_34) {
      puStack_16c = (undefined *)(uStack_34 + 1);
      uVar3 = uStack_48;
      if (0xfff < puStack_16c) {
        uVar3 = *(uint *)(uStack_48 - 4);
        puStack_16c = (undefined *)(uStack_34 + 0x24);
        if (0x1f < (uStack_48 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_16c = (undefined *)0x5d2eb2;
          iStack_8._0_1_ = uVar2;
          FUN_017167a3();
        }
      }
      iStack_174 = 0x5d2df0;
      puStack_170 = (undefined4 *)uVar3;
      FUN_01674ea0();
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    uStack_48 = uStack_48 & 0xffffff00;
    puStack_16c = (undefined *)0x5d2e0d;
    FUN_005d1210();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_88) {
      puStack_16c = (undefined *)(uStack_88 + 1);
      uVar3 = uStack_9c;
      if (0xfff < puStack_16c) {
        uVar3 = *(uint *)(uStack_9c - 4);
        puStack_16c = (undefined *)(uStack_88 + 0x24);
        if (0x1f < (uStack_9c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_16c = &UNK_005d2eb7;
          FUN_017167a3();
        }
      }
      iStack_174 = 0x5d2e44;
      puStack_170 = (undefined4 *)uVar3;
      FUN_01674ea0();
    }
    uStack_8c = 0;
    uStack_88 = 0xf;
    uStack_9c = uStack_9c & 0xffffff00;
    puStack_16c = (undefined *)0x5d2e6d;
    FUN_005d1210();
    puStack_16c = (undefined *)uStack_1c;
    puStack_170 = &DAT_01d79f98;
    iStack_174 = iStack_20;
    uStack_178 = 0x5d2e83;
    FUN_014cd990();
  }
  uStack_148 = param_7;
  uStack_14c = param_6;
  uStack_150 = 0x5d2e8f;
  FUN_005dabb0();
  uStack_148 = 0x5d2e9d;
  FUN_0056db40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5478 ; VA 0x005d2ec0 ; FUN_005d2ec0 */

void FUN_005d2ec0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
                 int param_5,undefined4 param_6,undefined4 param_7,int param_8,int *param_9)

{
  char cVar1;
  int iVar2;
  undefined auStack_1f8 [80];
  undefined auStack_1a8 [80];
  undefined auStack_158 [80];
  undefined auStack_108 [80];
  undefined auStack_b8 [80];
  undefined4 uStack_68;
  int iStack_64;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  undefined4 uStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799d7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_8 != 0) && (ExceptionList = &pvStack_10, DAT_01ea8d1c != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  if (param_9 != (int *)0x0) {
    if (DAT_01d596f0 != '\0') {
      (**(code **)(*param_9 + 4))();
      FUN_016774b0();
    }
    if (((DAT_01d597fc == '\0') && (*(char *)*param_4 == '\0')) &&
       ((DAT_01d59764 < 0 || (param_5 < DAT_01d59764)))) {
      FUN_00587490();
      iStack_8 = 0;
      if (iStack_18 != 0) {
        iStack_64 = param_1[1];
        if (iStack_64 != 0) {
          LOCK();
          *(int *)(iStack_64 + 8) = *(int *)(iStack_64 + 8) + 1;
          UNLOCK();
          iStack_64 = param_1[1];
        }
        uStack_68 = *param_1;
        iStack_8._0_1_ = 1;
        iStack_8._1_3_ = 0;
        FUN_0054ef60(param_2);
        iStack_44 = param_3[1];
        if (iStack_44 != 0) {
          LOCK();
          *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
          UNLOCK();
          iStack_44 = param_3[1];
        }
        uStack_48 = *param_3;
        iStack_3c = param_4[1];
        if (iStack_3c != 0) {
          LOCK();
          *(int *)(iStack_3c + 4) = *(int *)(iStack_3c + 4) + 1;
          UNLOCK();
          iStack_3c = param_4[1];
        }
        uStack_40 = *param_4;
        iStack_8._0_1_ = 4;
        iStack_38 = param_5;
        FUN_0054ef60(param_6);
        uStack_1c = param_7;
        iStack_8._0_1_ = 5;
        FUN_005cfb40(&uStack_68);
        iStack_8._0_1_ = 6;
        FUN_005cfb40(auStack_1f8);
        iStack_8._0_1_ = 7;
        FUN_005cfb40(auStack_1a8);
        iStack_8._0_1_ = 8;
        FUN_005cfb40(auStack_158);
        iStack_8._0_1_ = 9;
        cVar1 = FUN_00585a40(auStack_b8);
        if (cVar1 == '\0') {
          FUN_005cfb40(auStack_b8);
          iStack_8._0_1_ = 10;
          iVar2 = FUN_01674e20(0x50);
          iStack_8._0_1_ = 0xb;
          if (iVar2 != 0) {
            FUN_005cfb40(auStack_108);
          }
          FUN_005d0f60();
          FUN_005d0f60();
        }
        else {
          FUN_005d0f60();
        }
        FUN_005d0f60();
        FUN_005d0f60();
        FUN_005d0f60();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005d0f60();
        FUN_0090ca30();
      }
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5479 ; VA 0x005d3170 ; FUN_005d3170 */

void FUN_005d3170(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_3 * 0x24;
  iVar1 = param_2;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_2 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 5480 ; VA 0x005d31b0 ; FUN_005d31b0 */

int __thiscall FUN_005d31b0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  iVar6 = 0;
  puVar5 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar5;
    uVar1 = puVar5[7];
    if (0xf < uVar1) {
      iVar2 = puVar5[2];
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    puVar5[6] = 0;
    puVar5[7] = 0xf;
    *(undefined *)(puVar5 + 2) = 0;
    FUN_01674ea0(puVar5,0x24);
    iVar6 = iVar6 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar5 = (undefined4 *)*param_2;
  } while (puVar5 != param_3);
  return iVar6;
}



/* FUNCTION 5481 ; VA 0x005d3240 ; FUN_005d3240 */

uint FUN_005d3240(undefined4 param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR during connecting - Monitoring object has been destroyed too early!"
                           ,0);
    }
  }
  else {
    FUN_005d7140(&param_2);
    uVar6 = FUN_005d7350(&param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      puVar1 = (uint *)(piStack_14 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5482 ; VA 0x005d3310 ; FUN_005d3310 */

uint FUN_005d3310(void)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799db8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 == 0) {
    uVar5 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar5 = FUN_016774b0(DAT_01d596f0,
                           "ERROR during game close callback - Monitoring object has been destroyed too early!"
                           ,0);
    }
  }
  else {
    uVar5 = FUN_005d6c50();
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar5 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 5483 ; VA 0x005d33b0 ; FUN_005d33b0 */

uint FUN_005d33b0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR during player leaving - Monitoring object has been destroyed too early!"
                           ,0);
    }
  }
  else {
    FUN_005dacb0(&param_2);
    FUN_005d7a90(&param_2);
    uVar6 = FUN_005d77c0(&param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      puVar1 = (uint *)(piStack_14 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5484 ; VA 0x005d3490 ; FUN_005d3490 */

uint FUN_005d3490(undefined4 param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR during player added - Monitoring object has been destroyed too early!"
                           ,0);
    }
  }
  else {
    FUN_005d7350(&param_2);
    uVar6 = FUN_005d7140(&param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      puVar1 = (uint *)(piStack_14 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5485 ; VA 0x005d3560 ; FUN_005d3560 */

uint FUN_005d3560(undefined4 param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 != 0) {
      uVar6 = FUN_016774b0(DAT_01d596f0,
                           "ERROR during disconnecting - Monitoring object has been destroyed too early!"
                           ,0);
    }
  }
  else {
    if ((DAT_01d597ec != '\0') && (*(int *)(*(int *)(iStack_18 + 0x40) + 0x10) == 3)) {
      FUN_005da930(&param_2);
    }
    FUN_005dacb0(&param_2);
    FUN_005d77c0(&param_2);
    uVar6 = FUN_005d7a90(&param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      puVar1 = (uint *)(piStack_14 + 2);
      uVar3 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar6 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar5 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 5486 ; VA 0x005d3660 ; FUN_005d3660 */

int FUN_005d3660(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x005d367a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar3 = (**(code **)(*piVar2 + 4))();
      return iVar3;
    }
  }
  return param_1;
}



/* FUNCTION 5487 ; VA 0x005d3680 ; FUN_005d3680 */

void __thiscall FUN_005d3680(int param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  uint *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *****pppppuVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uVar10;
  int iVar11;
  undefined auStack_418 [24];
  undefined auStack_400 [152];
  undefined auStack_368 [24];
  undefined auStack_350 [148];
  int aiStack_2bc [15];
  int aiStack_280 [29];
  int aiStack_20c [15];
  int aiStack_1d0 [30];
  char acStack_158 [64];
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  uint uStack_100;
  uint uStack_fc;
  uint uStack_f8;
  uint uStack_f4;
  undefined8 uStack_f0;
  undefined auStack_e8 [24];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  uint uStack_b8;
  uint uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 ****appppuStack_a0 [4];
  int iStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  int iStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  uint uStack_4c;
  undefined8 uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  undefined4 ****appppuStack_28 [2];
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799f17;
  pvStack_10 = ExceptionList;
  uStack_48 = (ulonglong)(uint)uStack_48;
  if (*(char *)(param_1 + 0xd0) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00565940(3,1);
    uStack_8 = 0;
    FUN_00565940(3,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar3 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar3 = (undefined4 *)*param_4;
    }
    cVar1 = FUN_0055c360(puVar3,param_4[4],&DAT_018bc9b8,0);
    if (cVar1 == '\0') {
      FUN_0152d810(auStack_368,param_2);
    }
    FUN_0152d8a0(auStack_418,param_2);
    FUN_0152dea0();
    *(undefined *)(param_1 + 0xd0) = 0;
    uStack_78 = 0xf00000000;
    uStack_88 = uStack_88 & 0xffffff00;
    uStack_a8 = 0xf00000000;
    uStack_b8 = uStack_b8 & 0xffffff00;
    iStack_90 = 0;
    uStack_8c = 0xf;
    appppuStack_a0[0] = (undefined4 ****)((uint)appppuStack_a0[0] & 0xffffff00);
    uStack_8._0_1_ = 4;
    FUN_009c9100(appppuStack_a0);
    puVar3 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar3 = (undefined4 *)*param_4;
    }
    cVar1 = FUN_0055c360(puVar3,param_4[4],&DAT_018bc9b8,0);
    if (cVar1 == '\0') {
      uStack_8._0_1_ = 5;
      uStack_18 = 0;
      uStack_14 = 0xf;
      uStack_48 = CONCAT44(1,(uint)uStack_48);
      appppuStack_28[0]._0_1_ = cVar1;
      FUN_0058a190(param_3[4] + 0x13);
      puVar3 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar3 = (undefined4 *)*param_3;
      }
      FUN_00554150(puVar3,param_3[4]);
      FUN_00554150("/MicroprofileDetail",0x13);
      FUN_00558c20(&uStack_d0,appppuStack_28,param_4);
      uStack_8._0_1_ = 6;
      puVar2 = (uint *)FUN_00554150(&DAT_018c3bec,4);
      uStack_50 = *puVar2;
      uStack_4c = puVar2[1];
      uStack_38 = puVar2[2];
      uStack_34 = puVar2[3];
      uStack_58 = *(undefined8 *)(puVar2 + 4);
      puVar2[4] = 0;
      puVar2[5] = 0xf;
      *(undefined *)puVar2 = 0;
      uStack_40 = uStack_50;
      uStack_3c = uStack_4c;
      uStack_30 = uStack_58;
      uStack_48._0_4_ = uStack_38;
      uStack_48._4_4_ = uStack_34;
      FUN_005507b0();
      uStack_30 = 0xf00000000;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = (uint)uStack_48;
      uStack_7c = uStack_48._4_4_;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_78 = uStack_58;
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 7;
      uStack_18 = 0;
      uStack_14 = 0xf;
      appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0]._1_3_ << 8);
      uStack_48 = CONCAT44(6,(uint)uStack_48);
      FUN_0058a190(param_3[4] + 0x14);
      puVar3 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_00554150(param_3,*puVar3);
      FUN_00554150("/MicroprofileSummary",0x14);
      FUN_00558c20(&uStack_d0,appppuStack_28,param_4);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puVar2 = (uint *)FUN_00554150(&DAT_018c6aa8,3);
      uStack_50 = *puVar2;
      uStack_4c = puVar2[1];
      uStack_38 = puVar2[2];
      uStack_34 = puVar2[3];
      uStack_48 = *(ulonglong *)(puVar2 + 2);
      uStack_58 = *(undefined8 *)(puVar2 + 4);
      puVar2[4] = 0;
      puVar2[5] = 0xf;
      *(undefined *)puVar2 = 0;
      uStack_40 = uStack_50;
      uStack_3c = uStack_4c;
      uStack_30 = uStack_58;
      FUN_005507b0();
      uStack_30 = 0xf00000000;
      uStack_b8 = uStack_50;
      uStack_b4 = uStack_4c;
      uStack_b0 = (uint)uStack_48;
      uStack_ac = uStack_48._4_4_;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_a8 = uStack_58;
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uVar10 = 10;
    }
    else {
      uStack_58 = FUN_0171e1b0(0);
      FUN_0170d1f0(acStack_158,0,0x40);
      uVar10 = FUN_0172468b(&uStack_58);
      FUN_01724efb(acStack_158,0x40,"microprofile_%Y%m%d-%H%M%S.html",uVar10);
      uStack_8._0_1_ = 9;
      uStack_30 = 0xf00000000;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_48 = CONCAT44(0x10,(uint)uStack_48);
      FUN_0058a190(iStack_90 + 4);
      FUN_00554150(&DAT_018c0e58,4);
      pppppuVar6 = appppuStack_a0;
      if (0xf < uStack_8c) {
        pppppuVar6 = (undefined4 *****)appppuStack_a0[0];
      }
      FUN_00554150(pppppuVar6,iStack_90);
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018c6ae4,1);
      uStack_48 = CONCAT44(0x30,(uint)uStack_48);
      uStack_d0 = *puVar3;
      uStack_cc = puVar3[1];
      uStack_c8 = puVar3[2];
      uStack_c4 = puVar3[3];
      uStack_c0 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      uStack_8._0_1_ = 10;
      FUN_00558c20(auStack_e8,&uStack_d0,param_3);
      uStack_8._0_1_ = 0xb;
      puVar3 = (undefined4 *)FUN_00554150(&DAT_018c6ae4,1);
      uStack_48 = CONCAT44(0x70,(uint)uStack_48);
      uStack_118 = *puVar3;
      uStack_114 = puVar3[1];
      uStack_110 = puVar3[2];
      uStack_10c = puVar3[3];
      uStack_108 = *(undefined8 *)(puVar3 + 4);
      puVar3[4] = 0;
      puVar3[5] = 0xf;
      *(undefined *)puVar3 = 0;
      pcVar7 = acStack_158;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      do {
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      puVar2 = (uint *)FUN_00554150(acStack_158,(int)pcVar7 - (int)(acStack_158 + 1));
      uStack_100 = *puVar2;
      uStack_fc = puVar2[1];
      uStack_f8 = puVar2[2];
      uStack_f4 = puVar2[3];
      uStack_f0 = *(undefined8 *)(puVar2 + 4);
      puVar2[4] = 0;
      puVar2[5] = 0xf;
      *(undefined *)puVar2 = 0;
      uStack_48 = uStack_f0;
      uStack_20 = uStack_100;
      uStack_1c = uStack_fc;
      uStack_18 = uStack_f8;
      uStack_14 = uStack_f4;
      FUN_005507b0();
      uStack_f0 = 0xf00000000;
      uStack_88 = uStack_20;
      uStack_84 = uStack_1c;
      uStack_80 = uStack_18;
      uStack_7c = uStack_14;
      uStack_100 = uStack_100 & 0xffffff00;
      uStack_78 = uStack_48;
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uVar10 = 0xe0;
    }
    iStack_60 = 0;
    uStack_5c = 7;
    uStack_70 = (undefined4 *)((uint)uStack_70._2_2_ << 0x10);
    uStack_8._0_1_ = 0xd;
    puVar3 = (undefined4 *)FUN_01518d10(auStack_e8,1,0,&DAT_018c0e28);
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    iVar11 = puVar3[4];
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    uStack_48 = CONCAT44(uVar10,(uint)uStack_48) | 0x10000000000;
    if (iVar11 != 0) {
      puVar4 = puVar3;
      if (7 < (uint)puVar3[5]) {
        puVar4 = (undefined4 *)*puVar3;
      }
      if (7 < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      uVar5 = FUN_01686580();
      FUN_01685a20(puVar3,(int)puVar4 + iVar11 * 2,appppuStack_28,uVar5);
    }
    iStack_60 = 0;
    puVar3 = &uStack_70;
    if (7 < uStack_5c) {
      puVar3 = uStack_70;
    }
    *(undefined2 *)puVar3 = 0;
    if (uStack_18 != 0) {
      pppppuVar6 = appppuStack_28;
      if (0xf < uStack_14) {
        pppppuVar6 = (undefined4 *****)appppuStack_28[0];
      }
      iVar11 = (int)pppppuVar6 + uStack_18;
      pppppuVar6 = appppuStack_28;
      if (0xf < uStack_14) {
        pppppuVar6 = (undefined4 *****)appppuStack_28[0];
      }
      uVar5 = FUN_01686580();
      FUN_01685950(pppppuVar6,iVar11,&uStack_70,uVar5);
    }
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_28[0];
      if (0xfff < uVar8) {
        pppppuVar6 = (undefined4 *****)appppuStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_8._0_1_ = 0xd;
    FUN_00550800();
    FUN_005ce6f0(&uStack_88);
    uStack_8._0_1_ = 0x10;
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    uStack_48 = CONCAT44(uVar10,(uint)uStack_48) | 0x20000000000;
    if (iStack_60 != 0) {
      puVar3 = &uStack_70;
      if (7 < uStack_5c) {
        puVar3 = uStack_70;
      }
      iVar11 = iStack_60 * 2;
      puVar4 = &uStack_70;
      if (7 < uStack_5c) {
        puVar4 = uStack_70;
      }
      uVar10 = FUN_01686580();
      FUN_01685a20(puVar4,(undefined2 *)((int)puVar3 + iVar11),appppuStack_28,uVar10);
    }
    pppppuVar6 = appppuStack_28;
    if (0xf < uStack_14) {
      pppppuVar6 = (undefined4 *****)appppuStack_28[0];
    }
    FUN_00565320(pppppuVar6,2,0x40,1);
    *(undefined ***)((int)aiStack_2bc + *(int *)(aiStack_2bc[1] + 4) + 4) =
         std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
    *(int *)((int)aiStack_2bc + *(int *)(aiStack_2bc[1] + 4)) = *(int *)(aiStack_2bc[1] + 4) + -0x68
    ;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    if (0xf < uStack_14) {
      uVar8 = uStack_14 + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_28[0];
      if (0xfff < uVar8) {
        pppppuVar6 = (undefined4 *****)appppuStack_28[0][-1];
        uVar8 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)appppuStack_28[0] + (-4 - (int)pppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar8);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    appppuStack_28[0] = (undefined4 ****)((uint)appppuStack_28[0] & 0xffffff00);
    FUN_0056f130(auStack_400);
    iVar11 = FUN_005548a0();
    if (iVar11 == 0) {
      FUN_00554460((uint)(*(int *)((int)aiStack_280 + *(int *)(aiStack_2bc[1] + 4)) == 0) * 4 + 2 |
                   *(uint *)((int)aiStack_2bc + *(int *)(aiStack_2bc[1] + 4) + 0x10),0);
    }
    puVar3 = param_4 + 4;
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    cVar1 = FUN_0055c360(param_4,*puVar3,&DAT_018bc9b8,0);
    if (cVar1 == '\0') {
      uStack_30 = 0x700000000;
      uStack_40 = uStack_40 & 0xffff0000;
      uStack_8._0_1_ = 0x13;
      FUN_01518d10(&uStack_d0,1,0,&DAT_018c0e28);
      uStack_8._0_1_ = 0x14;
      uVar10 = FUN_005569d0(auStack_e8);
      uStack_8._0_1_ = 0x15;
      FUN_0058ccf0(uVar10);
      FUN_005507b0();
      uStack_8._0_1_ = 0x13;
      FUN_00550800();
      FUN_005ce6f0(&uStack_b8);
      puVar3 = (undefined4 *)FUN_005569d0(auStack_e8);
      uStack_8._0_1_ = 0x16;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_00565320(puVar3,2,0x40,1);
      *(undefined ***)((int)aiStack_20c + *(int *)(aiStack_20c[1] + 4) + 4) =
           std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
      *(int *)((int)aiStack_20c + *(int *)(aiStack_20c[1] + 4)) =
           *(int *)(aiStack_20c[1] + 4) + -0x68;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
      FUN_005507b0();
      FUN_0056f130(auStack_350);
      iVar11 = FUN_005548a0();
      if (iVar11 == 0) {
        FUN_00554460((uint)(*(int *)((int)aiStack_1d0 + *(int *)(aiStack_20c[1] + 4)) == 0) * 4 + 2
                     | *(uint *)((int)aiStack_20c + *(int *)(aiStack_20c[1] + 4) + 0x10),0);
      }
      FUN_00570460();
      FUN_00550800();
    }
    FUN_00570460();
    FUN_00550800();
    if (0xf < uStack_8c) {
      uVar8 = uStack_8c + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_a0[0];
      if (0xfff < uVar8) {
        pppppuVar6 = (undefined4 *****)appppuStack_a0[0][-1];
        uVar8 = uStack_8c + 0x24;
        if (0x1f < (uint)((int)appppuStack_a0[0] + (-4 - (int)pppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar8);
    }
    iStack_90 = 0;
    uStack_8c = 0xf;
    appppuStack_a0[0] = (undefined4 ****)((uint)appppuStack_a0[0] & 0xffffff00);
    if (0xf < uStack_a8._4_4_) {
      uVar9 = uStack_a8._4_4_ + 1;
      uVar8 = uStack_b8;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_b8 - 4);
        uVar9 = uStack_a8._4_4_ + 0x24;
        if (0x1f < (uStack_b8 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_a8 = 0xf00000000;
    uStack_b8 = uStack_b8 & 0xffffff00;
    if (0xf < uStack_78._4_4_) {
      uVar9 = uStack_78._4_4_ + 1;
      uVar8 = uStack_88;
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(uStack_88 - 4);
        uVar9 = uStack_78._4_4_ + 0x24;
        if (0x1f < (uStack_88 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_78 = 0xf00000000;
    uStack_88 = uStack_88 & 0xffffff00;
    FUN_005705c0();
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 5488 ; VA 0x005d40e0 ; FUN_005d40e0 */

undefined4 __thiscall
FUN_005d40e0(byte *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_00562fc0(param_2,param_3,param_4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2;
}



/* FUNCTION 5489 ; VA 0x005d4110 ; FUN_005d4110 */

void __thiscall FUN_005d4110(int param_1,undefined4 *param_2,uint param_3,undefined4 *param_4)

{
  uint uVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  
  uVar1 = *(uint *)(param_1 + 4);
  uVar5 = param_3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (puVar4 == (undefined4 *)0x0) {
      piVar6 = (int *)0x0;
    }
    else {
      piVar6 = (int *)*puVar4;
    }
    if (piVar6 != (int *)0x0) {
      do {
        if (param_3 == piVar6[1]) {
          piVar3 = piVar6 + 2;
          if (0xf < (uint)piVar6[7]) {
            piVar3 = (int *)*piVar3;
          }
          puVar4 = param_4;
          if (0xf < (uint)param_4[5]) {
            puVar4 = (undefined4 *)*param_4;
          }
          cVar2 = FUN_0055c360(puVar4,param_4[4],piVar3,piVar6[6]);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar6[1] % uVar1 != uVar5) {
          *param_2 = 0;
          return;
        }
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar6;
  return;
}



/* FUNCTION 5490 ; VA 0x005d41c0 ; FUN_005d41c0 */

undefined * __fastcall FUN_005d41c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  undefined auStack_d0 [28];
  undefined4 uStack_b4;
  code *pcStack_b0;
  int iStack_ac;
  undefined4 uStack_a8;
  undefined auStack_a4 [24];
  undefined4 uStack_8c;
  undefined *puStack_88;
  undefined8 uStack_84;
  undefined auStack_70 [24];
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_2b [3];
  int iStack_28;
  int *piStack_24;
  int iStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799f48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ea8d1c != 0) {
    puStack_88 = (undefined *)(uint)DAT_01ea8d1c;
    uStack_84 = 1.28354835855287e-316;
    uStack_8c = 0x5d41f9;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  uStack_84 = (double)CONCAT44(&iStack_28,0x5d4208);
  FUN_00587490();
  iStack_8 = 0;
  if (iStack_28 == 0) {
    puVar6 = (undefined *)(uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d43c3;
    uStack_84 = 1.28355132294674e-316;
  }
  else {
    iStack_1c = iStack_28 + 0xc;
    uStack_84 = (double)CONCAT44(0x5d423b,(undefined4)uStack_84);
    iVar5 = FUN_005cf750();
    if (((iVar5 != 0) && (-1 < DAT_01d59730)) &&
       (DAT_01d59730 <= (*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) >> 3)) {
      uStack_84 = (double)CONCAT44(0x5d4270,(undefined4)uStack_84);
      iStack_18 = FUN_005cf2a0();
      if (iStack_18 != 0) {
        iVar5 = (*(int **)(iVar5 + 0xb8))[1] - **(int **)(iVar5 + 0xb8) >> 3;
        if (iVar5 < 0) {
          uStack_84 = (double)CONCAT44(-iVar5,auStack_2b);
          puStack_88 = (undefined *)0x5d4299;
          iVar5 = FUN_00591870();
          *(undefined *)(iVar5 + -1) = 0x2d;
          puVar6 = (undefined *)(iVar5 + -1);
        }
        else {
          uStack_84 = (double)CONCAT44(iVar5,auStack_2b);
          puStack_88 = (undefined *)0x5d42a9;
          puVar6 = (undefined *)FUN_00591870();
        }
        uStack_48 = 0;
        uStack_44 = 0xf;
        auStack_58[0] = 0;
        if (puVar6 != auStack_2b) {
          uStack_84 = (double)CONCAT44((int)auStack_2b - (int)puVar6,puVar6);
          puStack_88 = (undefined *)0x5d42d3;
          FUN_005542c0();
        }
        iStack_8._0_1_ = 1;
        puStack_88 = auStack_70;
        uStack_84 = (double)CONCAT44(auStack_58,"Player-");
        uStack_8c = 0x5d42e9;
        FUN_00558d90();
        iStack_8._0_1_ = 3;
        uStack_84 = (double)CONCAT44(0x5d42f8,(undefined4)uStack_84);
        FUN_005507b0();
        *(undefined *)(param_1 + 0xd0) = 1;
        uStack_84 = (double)CONCAT44(0x5d4304,(undefined4)uStack_84);
        FUN_0152de00();
        uVar4 = DAT_01d59738;
        puStack_14 = auStack_a4;
        uStack_84 = (double)DAT_01d59740;
        uStack_a8 = 0;
        FUN_0054ef60(auStack_70);
        FUN_005cefe0(auStack_d0,FUN_005d3680,param_1,uVar4);
        FUN_005ce530();
        uStack_a8 = 0x5d435c;
        FUN_009eef30();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        uStack_84 = (double)CONCAT44(0x5d4368,(undefined4)uStack_84);
        FUN_005507b0();
      }
    }
    uStack_84 = (double)CONCAT44(0x5d4372,(undefined4)uStack_84);
    puVar6 = (undefined *)FUN_005cf2a0();
    if (puVar6 == (undefined *)0x0) goto LAB_005d43c3;
    uStack_84 = (double)DAT_01ea8d20;
    uStack_a8 = 0;
    pcStack_b0 = FUN_005d41c0;
    uStack_b4 = 0x5d439c;
    iStack_ac = param_1;
    FUN_005ce4d0();
    uStack_a8 = 0x5d43a3;
    FUN_009eef30();
    puVar6 = (undefined *)(uint)DAT_01ea8d1c;
    if (DAT_01ea8d1c == 0) goto LAB_005d43c3;
    uStack_84 = (double)CONCAT44(DAT_01ea8d20,
                                 "TimerService scheduled next generateMicroProfileDataOnServer in %d"
                                );
  }
  uStack_8c = 0x5d43c0;
  puStack_88 = puVar6;
  puVar6 = (undefined *)FUN_016774b0();
LAB_005d43c3:
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar3 = *puVar1;
    puVar6 = (undefined *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uStack_84 = (double)CONCAT44(0x5d43dc,(undefined4)uStack_84);
      puVar6 = (undefined *)(**(code **)*piStack_24)();
      LOCK();
      piVar2 = piStack_24 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uStack_84 = (double)CONCAT44(0x5d43eb,(undefined4)uStack_84);
        puVar6 = (undefined *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 5491 ; VA 0x005d4400 ; FUN_005d4400 */

undefined4 __thiscall
FUN_005d4400(int param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 *param_5,
            int *param_6,char param_7)

{
  double dVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  float10 fVar7;
  float10 fVar8;
  double dVar9;
  undefined8 uVar10;
  int iStack_5c;
  uint uStack_48;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01799f70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fVar7 = (float10)FUN_01160660();
  dVar1 = *(double *)(param_1 + 0x20);
  if (DAT_01d597e4 == '\0') {
    fVar8 = (float10)FUN_005d2710();
    dVar9 = (double)fVar8;
  }
  else {
    dVar9 = *(double *)(param_1 + 200);
  }
  uStack_14 = 0;
  if (DAT_01d597dc != '\0') {
    uStack_14 = FUN_00644b60();
  }
  FUN_005caee0();
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x40) + 0x80);
  iStack_8 = 0;
  if (0xf < *(uint *)(*(int *)(param_1 + 0x40) + 0x94)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151b710("apiKey",puVar4);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x40) + 0x48);
  if (0xf < *(uint *)(*(int *)(param_1 + 0x40) + 0x5c)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151b710("gameId",puVar4);
  FUN_0151ba20("placeId",7,**(undefined4 **)(param_1 + 0x40),(*(undefined4 **)(param_1 + 0x40))[1]);
  FUN_0151b870("gameCapacity",0xc,*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x7c));
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x40) + 0x60);
  if (0xf < *(uint *)(*(int *)(param_1 + 0x40) + 0x74)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151b710("ipAddress",puVar4);
  FUN_0151b870(&DAT_018c5e3c,4,*(undefined4 *)(param_3 + 0x104));
  fVar8 = (float10)FUN_00999e90();
  FUN_0151b940(&DAT_018c5e44,3,(double)fVar8);
  FUN_0151b940("heartbeatRate",0xd,*(undefined8 *)(param_1 + 0xb0));
  FUN_0151b940(&DAT_018c5e58,4,dVar9);
  fVar8 = (float10)FUN_00999800();
  FUN_0151b940("physicsLoadAverage",0x12,(double)fVar8);
  fVar8 = (float10)FUN_009997d0();
  FUN_0151b940("physicsEnvironmentSpeed",0x17,(double)fVar8);
  FUN_0151b940("gameTime",8,(double)(fVar7 - (float10)dVar1));
  FUN_0151ba20("universeId",10,*(undefined4 *)(*(int *)(param_1 + 0x40) + 8),
               *(undefined4 *)(*(int *)(param_1 + 0x40) + 0xc));
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x40) + 0x14);
  if (0xf < *(uint *)(*(int *)(param_1 + 0x40) + 0x28)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151b710("gameCode",puVar4);
  FUN_0151b870("matchmakingContextId",0x14,*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x10));
  uVar2 = FUN_006444a0();
  FUN_0151b870("clientCount",0xb,uVar2);
  if (DAT_01d597dc != '\0') {
    FUN_0151b870("botCount",8,uStack_14);
  }
  FUN_0151b870("preferredPlayerCapacity",0x17,*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x98));
  iVar5 = *(int *)(*(int *)(param_1 + 0x40) + 0x10);
  if ((iVar5 == 3) || (puVar3 = &DAT_018bdf48, iVar5 == 4)) {
    puVar3 = &DAT_018bdf50;
  }
  FUN_0151b710("isCloudEdit",puVar3);
  puVar4 = (undefined4 *)FUN_00912100();
  iStack_8._0_1_ = 1;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0151b710("rccVersion",puVar4);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_48) {
    uVar6 = uStack_48 + 1;
    iVar5 = iStack_5c;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iStack_5c + -4);
      uVar6 = uStack_48 + 0x24;
      if (0x1f < (iStack_5c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  if (0xf < (uint)param_5[5]) {
    param_5 = (undefined4 *)*param_5;
  }
  FUN_0151b710("eventSource",param_5);
  if (*param_6 != 0) {
    uVar10 = FUN_00928340();
    FUN_0151ba20("originatingPlayerId",0x13,uVar10);
  }
  puVar3 = &DAT_018bdf50;
  if (param_7 == '\0') {
    puVar3 = &DAT_018bdf48;
  }
  FUN_0151b710("isStreamingEnabled",puVar3);
  FUN_0151b940("cpuUsage",8,*(double *)(param_1 + 0xc0) + *(double *)(param_1 + 0xb8));
  uVar10 = FUN_01522960();
  FUN_0151ba20("usedMemoryBytes",0xf,uVar10);
  FUN_0151ba20("seqNum",6,*(undefined4 *)(param_1 + 0xd8),*(undefined4 *)(param_1 + 0xdc));
  FUN_0054ef60();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 5492 ; VA 0x005d4890 ; FUN_005d4890 */

undefined4 __thiscall FUN_005d4890(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x2a8);
  return param_2;
}



/* FUNCTION 5493 ; VA 0x005d48b0 ; FUN_005d48b0 */

undefined4 __fastcall FUN_005d48b0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x450);
}



/* FUNCTION 5494 ; VA 0x005d48e0 ; FUN_005d48e0 */

undefined * FUN_005d48e0(undefined *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 ***pppuVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  char *pcVar12;
  undefined4 uVar13;
  char *pcVar14;
  undefined4 ****ppppuVar15;
  uint *puVar16;
  undefined8 uVar17;
  int aiStack_f8 [5];
  uint uStack_e4;
  int iStack_e0;
  int *piStack_dc;
  int *piStack_d8;
  int *piStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  int *piStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  int iStack_78;
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  int *piStack_38;
  int *piStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799fda;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_78 == 0) {
    if (DAT_01d596f0 != '\0') {
      FUN_016774b0(DAT_01d596f0,"ERROR (getPlayerPostData) - DataModel is unexpectedly null.",0);
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_74[1] + -1;
      piStack_74[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_74)();
        LOCK();
        piVar2 = piStack_74 + 2;
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piStack_74 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar7 = FUN_005cf750();
  piStack_d4 = *(int **)(iVar7 + 0xbc);
  if (piStack_d4 != (int *)0x0) {
    LOCK();
    piStack_d4[1] = piStack_d4[1] + 1;
    UNLOCK();
    piStack_d4 = *(int **)(iVar7 + 0xbc);
  }
  piVar2 = *(int **)(iVar7 + 0xb8);
  uStack_8._0_1_ = 1;
  piStack_d8 = piVar2;
  piStack_38 = piStack_d4;
  FUN_0167e9f0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01681c30();
  FUN_01681d10();
  FUN_01681c10();
  if (piVar2 != (int *)0x0) {
    cStack_11 = '\0';
    uVar8 = FUN_0065b3d0(&DAT_01d5ab10,0x62,&cStack_11);
    uStack_2c = uVar8;
    uStack_28 = FUN_0065b3d0(&DAT_01d5ab10,0x72,&cStack_11);
    uStack_28 = uStack_28 | uVar8;
    if (cStack_11 != '\0') {
      FUN_006688b0();
    }
    piVar11 = (int *)*piVar2;
    piStack_70 = (int *)piVar2[1];
    piStack_30 = piVar11;
    if (piVar11 != piStack_70) {
      do {
        piStack_30 = piVar11;
        if (*piVar11 == 0) {
LAB_005d4aad:
          puVar10 = &uStack_98;
          uVar8 = uStack_18 | 4;
          piStack_94 = (int *)0x0;
          iVar7 = 0;
        }
        else {
          iVar7 = *(int *)(*piVar11 + 0xc);
          iVar9 = FUN_00913630();
          if ((uint)*(ushort *)(iVar9 + 0x1da) <
              (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8))
          goto LAB_005d4aad;
          piStack_9c = (int *)piVar11[1];
          iVar7 = *piVar11;
          if (piStack_9c != (int *)0x0) {
            LOCK();
            piStack_9c[1] = piStack_9c[1] + 1;
            UNLOCK();
            piStack_9c = (int *)piVar11[1];
          }
          uVar8 = uStack_18 | 2;
          puVar10 = &uStack_a0;
        }
        piVar2 = (int *)puVar10[1];
        uStack_18 = uVar8 | 8;
        *puVar10 = 0;
        puVar10[1] = 0;
        piVar11 = piStack_94;
        iStack_e0 = iVar7;
        piStack_dc = piVar2;
        if (((uVar8 & 4) != 0) && (uStack_18 = uVar8 & 0xfffffffb | 8, piStack_94 != (int *)0x0)) {
          LOCK();
          iVar9 = piStack_94[1] + -1;
          piStack_94[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_94)();
            LOCK();
            piVar1 = piVar11 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        piVar11 = piStack_9c;
        if (((uStack_18 & 2) != 0) && (uStack_18 = uStack_18 & 0xfffffffd, piStack_9c != (int *)0x0)
           ) {
          LOCK();
          iVar9 = piStack_9c[1] + -1;
          piStack_9c[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_9c)();
            LOCK();
            piVar1 = piVar11 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 3;
        if (iVar7 != 0) {
          uVar17 = FUN_00928340();
          uStack_40 = uVar17;
          FUN_0054ef60();
          pppuVar4 = apppuStack_58[0];
          ppppuVar15 = apppuStack_58;
          if (0xf < uStack_44) {
            ppppuVar15 = (undefined4 ****)apppuStack_58[0];
          }
          uVar5 = FUN_0055c360(ppppuVar15,uStack_48,&DAT_018bc9b8,0);
          uStack_5c = CONCAT31(uStack_5c._1_3_,uVar5) ^ 1;
          if (0xf < uStack_44) {
            uVar8 = uStack_44 + 1;
            ppppuVar15 = (undefined4 ****)pppuVar4;
            if (0xfff < uVar8) {
              ppppuVar15 = (undefined4 ****)pppuVar4[-1];
              uVar8 = uStack_44 + 0x24;
              uVar5 = (undefined)uStack_8;
              if (0x1f < (uint)((int)pppuVar4 + (-4 - (int)ppppuVar15))) goto LAB_005d5035;
            }
            FUN_01674ea0(ppppuVar15,uVar8);
          }
          iVar9 = FUN_005d1850();
          uStack_68 = *(undefined8 *)(iVar9 + 8);
          FUN_0054ef60();
          uStack_18 = uStack_18 | 0x30;
          uStack_8._0_1_ = 4;
          uStack_80 = 0;
          uStack_7c = 0xf;
          auStack_90[0] = auStack_90[0] & 0xffffff00;
          FUN_005542c0("Unknown",7);
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          piVar11 = (int *)FUN_0065b150();
          piStack_6c = piVar11;
          if (piVar11 != (int *)0x0) {
            cVar6 = (**(code **)(*piVar11 + 0x22c))();
            if (cVar6 == '\0') {
              cVar6 = (**(code **)(*piVar11 + 0x230))();
              if (cVar6 == '\0') goto LAB_005d4c8c;
              uVar17 = 0x5018c5d58;
            }
            else {
              uVar17 = 0x3018c5d54;
            }
            FUN_005542c0(uVar17);
          }
LAB_005d4c8c:
          FUN_01681c30();
          FUN_016816e0("UserId",uStack_40);
          FUN_01680f40(&DAT_018c5d68,uStack_5c);
          FUN_01681020("GameTimeWhenJoined",uStack_68);
          FUN_01681e50("GameSessionId",auStack_d0);
          uStack_60 = *(undefined4 *)(iVar7 + 0x450);
          FUN_00920c80(auStack_b8);
          uStack_8._0_1_ = 6;
          FUN_01681e50("MembershipType",auStack_b8);
          FUN_01681e50("BotCheckStatus",auStack_90);
          FUN_01681d10();
          FUN_01681c30();
          if (piVar11 != (int *)0x0) {
            puVar16 = &DAT_018d0a58;
            uVar8 = uStack_28;
            do {
              uVar3 = *puVar16;
              if ((uVar8 & uVar3) != 0) {
                pcVar12 = (char *)FUN_00658300();
                uStack_48 = 0;
                uStack_44 = 0xf;
                apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
                uStack_68 = CONCAT44(pcVar12 + 1,(undefined4)uStack_68);
                pcVar14 = pcVar12;
                do {
                  cVar6 = *pcVar14;
                  pcVar14 = pcVar14 + 1;
                } while (cVar6 != '\0');
                FUN_005542c0(pcVar12,(int)pcVar14 - (int)(pcVar12 + 1));
                uStack_8._0_1_ = 7;
                uVar13 = FUN_0065b0c0(aiStack_f8,uVar3);
                uStack_8._0_1_ = 8;
                FUN_01681d60(apppuStack_58,uVar13);
                uStack_8._0_1_ = 7;
                uVar5 = (undefined)uStack_8;
                uStack_8._0_1_ = 7;
                if (0xf < uStack_e4) {
                  iVar7 = aiStack_f8[0];
                  if ((0xfff < uStack_e4 + 1) &&
                     (iVar7 = *(int *)(aiStack_f8[0] + -4), 0x1f < (aiStack_f8[0] - iVar7) - 4U))
                  goto LAB_005d5035;
                  FUN_01674ea0(iVar7);
                }
                uStack_8._0_1_ = 6;
                uVar8 = uStack_28;
                if (0xf < uStack_44) {
                  ppppuVar15 = (undefined4 ****)apppuStack_58[0];
                  if ((0xfff < uStack_44 + 1) &&
                     (ppppuVar15 = (undefined4 ****)apppuStack_58[0][-1],
                     uVar5 = (undefined)uStack_8,
                     0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar15))))
                  goto LAB_005d5035;
                  FUN_01674ea0(ppppuVar15);
                  uVar8 = uStack_28;
                }
              }
              puVar16 = puVar16 + 1;
            } while (puVar16 != (uint *)"DynamicIpBlock");
          }
          FUN_01681200();
          FUN_01681200();
          uStack_8._0_1_ = 5;
          if (0xf < uStack_a4) {
            uVar8 = auStack_b8[0];
            if ((0xfff < uStack_a4 + 1) &&
               (uVar8 = *(uint *)(auStack_b8[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_b8[0] - uVar8) - 4)) goto LAB_005d5035;
            FUN_01674ea0(uVar8);
          }
          uStack_a8 = 0;
          uStack_a4 = 0xf;
          auStack_b8[0] = auStack_b8[0] & 0xffffff00;
          uStack_8._0_1_ = 4;
          if (0xf < uStack_7c) {
            uVar8 = auStack_90[0];
            if ((0xfff < uStack_7c + 1) &&
               (uVar8 = *(uint *)(auStack_90[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_90[0] - uVar8) - 4)) goto LAB_005d5035;
            FUN_01674ea0(uVar8);
          }
          uStack_80 = 0;
          uStack_7c = 0xf;
          auStack_90[0] = auStack_90[0] & 0xffffff00;
          uStack_8._0_1_ = 3;
          if (0xf < uStack_bc) {
            uVar8 = auStack_d0[0];
            if ((0xfff < uStack_bc + 1) &&
               (uVar8 = *(uint *)(auStack_d0[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_d0[0] - uVar8) - 4)) {
LAB_005d5035:
              uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
            FUN_01674ea0(uVar8);
          }
          uStack_c0 = 0;
          uStack_bc = 0xf;
          auStack_d0[0] = auStack_d0[0] & 0xffffff00;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar7 = piVar2[1] + -1;
          piVar2[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar7 = piVar2[2] + -1;
            piVar2[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar11 = piStack_30 + 2;
        piStack_30 = piVar11;
      } while (piVar11 != piStack_70);
    }
  }
  FUN_016811a0();
  FUN_01681d10();
  FUN_01681cd0();
  FUN_01681200();
  FUN_01681c50();
  FUN_0167ec80();
  piVar2 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_38[1] + -1;
    piStack_38[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar11 = piVar2 + 2;
      iVar7 = *piVar11 + -1;
      *piVar11 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_74 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_74[1] + -1;
    piStack_74[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_74)();
      LOCK();
      piVar2 = piStack_74 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_74 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5495 ; VA 0x005d5040 ; FUN_005d5040 */

undefined * FUN_005d5040(undefined *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 ***pppuVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  undefined4 *puVar10;
  int *piVar11;
  char *pcVar12;
  undefined4 uVar13;
  char *pcVar14;
  undefined4 ****ppppuVar15;
  uint *puVar16;
  undefined8 uVar17;
  int aiStack_f8 [5];
  uint uStack_e4;
  int iStack_e0;
  int *piStack_dc;
  int *piStack_d8;
  int *piStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_98;
  int *piStack_94;
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  int iStack_78;
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  int *piStack_38;
  int *piStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799fda;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_78 == 0) {
    if (DAT_01d596f0 != '\0') {
      FUN_016774b0(DAT_01d596f0,
                   "ERROR (getPlayerPostData_deprecated) - DataModel is unexpectedly null.",0);
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_74[1] + -1;
      piStack_74[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_74)();
        LOCK();
        piVar2 = piStack_74 + 2;
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piStack_74 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar7 = FUN_005cf750();
  piStack_d4 = *(int **)(iVar7 + 0xbc);
  if (piStack_d4 != (int *)0x0) {
    LOCK();
    piStack_d4[1] = piStack_d4[1] + 1;
    UNLOCK();
    piStack_d4 = *(int **)(iVar7 + 0xbc);
  }
  piVar2 = *(int **)(iVar7 + 0xb8);
  uStack_8._0_1_ = 1;
  piStack_d8 = piVar2;
  piStack_38 = piStack_d4;
  FUN_0167e9f0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01681c30();
  FUN_01681d10();
  FUN_01681c10();
  if (piVar2 != (int *)0x0) {
    cStack_11 = '\0';
    uVar8 = FUN_0065b3d0(&DAT_01d5ab10,0x62,&cStack_11);
    uStack_2c = uVar8;
    uStack_28 = FUN_0065b3d0(&DAT_01d5ab10,0x72,&cStack_11);
    uStack_28 = uStack_28 | uVar8;
    if (cStack_11 != '\0') {
      FUN_006688b0();
    }
    piVar11 = (int *)*piVar2;
    piStack_70 = (int *)piVar2[1];
    piStack_30 = piVar11;
    if (piVar11 != piStack_70) {
      do {
        piStack_30 = piVar11;
        if (*piVar11 == 0) {
LAB_005d520d:
          puVar10 = &uStack_98;
          uVar8 = uStack_18 | 4;
          piStack_94 = (int *)0x0;
          iVar7 = 0;
        }
        else {
          iVar7 = *(int *)(*piVar11 + 0xc);
          iVar9 = FUN_00913630();
          if ((uint)*(ushort *)(iVar9 + 0x1da) <
              (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8))
          goto LAB_005d520d;
          piStack_9c = (int *)piVar11[1];
          iVar7 = *piVar11;
          if (piStack_9c != (int *)0x0) {
            LOCK();
            piStack_9c[1] = piStack_9c[1] + 1;
            UNLOCK();
            piStack_9c = (int *)piVar11[1];
          }
          uVar8 = uStack_18 | 2;
          puVar10 = &uStack_a0;
        }
        piVar2 = (int *)puVar10[1];
        uStack_18 = uVar8 | 8;
        *puVar10 = 0;
        puVar10[1] = 0;
        piVar11 = piStack_94;
        iStack_e0 = iVar7;
        piStack_dc = piVar2;
        if (((uVar8 & 4) != 0) && (uStack_18 = uVar8 & 0xfffffffb | 8, piStack_94 != (int *)0x0)) {
          LOCK();
          iVar9 = piStack_94[1] + -1;
          piStack_94[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_94)();
            LOCK();
            piVar1 = piVar11 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        piVar11 = piStack_9c;
        if (((uStack_18 & 2) != 0) && (uStack_18 = uStack_18 & 0xfffffffd, piStack_9c != (int *)0x0)
           ) {
          LOCK();
          iVar9 = piStack_9c[1] + -1;
          piStack_9c[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_9c)();
            LOCK();
            piVar1 = piVar11 + 2;
            iVar9 = *piVar1 + -1;
            *piVar1 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        uStack_8._0_1_ = 3;
        if (iVar7 != 0) {
          uVar17 = FUN_00928340();
          uStack_40 = uVar17;
          FUN_0054ef60();
          pppuVar4 = apppuStack_58[0];
          ppppuVar15 = apppuStack_58;
          if (0xf < uStack_44) {
            ppppuVar15 = (undefined4 ****)apppuStack_58[0];
          }
          uVar5 = FUN_0055c360(ppppuVar15,uStack_48,&DAT_018bc9b8,0);
          uStack_5c = CONCAT31(uStack_5c._1_3_,uVar5) ^ 1;
          if (0xf < uStack_44) {
            uVar8 = uStack_44 + 1;
            ppppuVar15 = (undefined4 ****)pppuVar4;
            if (0xfff < uVar8) {
              ppppuVar15 = (undefined4 ****)pppuVar4[-1];
              uVar8 = uStack_44 + 0x24;
              uVar5 = (undefined)uStack_8;
              if (0x1f < (uint)((int)pppuVar4 + (-4 - (int)ppppuVar15))) goto LAB_005d5795;
            }
            FUN_01674ea0(ppppuVar15,uVar8);
          }
          iVar9 = FUN_005d1850();
          uStack_68 = *(undefined8 *)(iVar9 + 8);
          FUN_0054ef60();
          uStack_18 = uStack_18 | 0x30;
          uStack_8._0_1_ = 4;
          uStack_80 = 0;
          uStack_7c = 0xf;
          auStack_90[0] = auStack_90[0] & 0xffffff00;
          FUN_005542c0("Unknown",7);
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          piVar11 = (int *)FUN_0065b150();
          piStack_6c = piVar11;
          if (piVar11 != (int *)0x0) {
            cVar6 = (**(code **)(*piVar11 + 0x22c))();
            if (cVar6 == '\0') {
              cVar6 = (**(code **)(*piVar11 + 0x230))();
              if (cVar6 == '\0') goto LAB_005d53ec;
              uVar17 = 0x5018c5d58;
            }
            else {
              uVar17 = 0x3018c5d54;
            }
            FUN_005542c0(uVar17);
          }
LAB_005d53ec:
          FUN_01681c30();
          FUN_016816e0("UserId",uStack_40);
          FUN_01680f40(&DAT_018c5d68,uStack_5c);
          FUN_01681020("GameTimeWhenJoined",uStack_68);
          FUN_01681e50("GameSessionId",auStack_d0);
          uStack_60 = *(undefined4 *)(iVar7 + 0x450);
          FUN_00920c80(auStack_b8);
          uStack_8._0_1_ = 6;
          FUN_01681e50("MembershipType",auStack_b8);
          FUN_01681e50("BotCheckStatus",auStack_90);
          FUN_01681d10();
          FUN_01681c30();
          if (piVar11 != (int *)0x0) {
            puVar16 = &DAT_018d0a58;
            uVar8 = uStack_28;
            do {
              uVar3 = *puVar16;
              if ((uVar8 & uVar3) != 0) {
                pcVar12 = (char *)FUN_00658300();
                uStack_48 = 0;
                uStack_44 = 0xf;
                apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
                uStack_68 = CONCAT44(pcVar12 + 1,(undefined4)uStack_68);
                pcVar14 = pcVar12;
                do {
                  cVar6 = *pcVar14;
                  pcVar14 = pcVar14 + 1;
                } while (cVar6 != '\0');
                FUN_005542c0(pcVar12,(int)pcVar14 - (int)(pcVar12 + 1));
                uStack_8._0_1_ = 7;
                uVar13 = FUN_0065b0c0(aiStack_f8,uVar3);
                uStack_8._0_1_ = 8;
                FUN_01681d60(apppuStack_58,uVar13);
                uStack_8._0_1_ = 7;
                uVar5 = (undefined)uStack_8;
                uStack_8._0_1_ = 7;
                if (0xf < uStack_e4) {
                  iVar7 = aiStack_f8[0];
                  if ((0xfff < uStack_e4 + 1) &&
                     (iVar7 = *(int *)(aiStack_f8[0] + -4), 0x1f < (aiStack_f8[0] - iVar7) - 4U))
                  goto LAB_005d5795;
                  FUN_01674ea0(iVar7);
                }
                uStack_8._0_1_ = 6;
                uVar8 = uStack_28;
                if (0xf < uStack_44) {
                  ppppuVar15 = (undefined4 ****)apppuStack_58[0];
                  if ((0xfff < uStack_44 + 1) &&
                     (ppppuVar15 = (undefined4 ****)apppuStack_58[0][-1],
                     uVar5 = (undefined)uStack_8,
                     0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar15))))
                  goto LAB_005d5795;
                  FUN_01674ea0(ppppuVar15);
                  uVar8 = uStack_28;
                }
              }
              puVar16 = puVar16 + 1;
            } while (puVar16 != (uint *)"DynamicIpBlock");
          }
          FUN_01681200();
          FUN_01681200();
          uStack_8._0_1_ = 5;
          if (0xf < uStack_a4) {
            uVar8 = auStack_b8[0];
            if ((0xfff < uStack_a4 + 1) &&
               (uVar8 = *(uint *)(auStack_b8[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_b8[0] - uVar8) - 4)) goto LAB_005d5795;
            FUN_01674ea0(uVar8);
          }
          uStack_a8 = 0;
          uStack_a4 = 0xf;
          auStack_b8[0] = auStack_b8[0] & 0xffffff00;
          uStack_8._0_1_ = 4;
          if (0xf < uStack_7c) {
            uVar8 = auStack_90[0];
            if ((0xfff < uStack_7c + 1) &&
               (uVar8 = *(uint *)(auStack_90[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_90[0] - uVar8) - 4)) goto LAB_005d5795;
            FUN_01674ea0(uVar8);
          }
          uStack_80 = 0;
          uStack_7c = 0xf;
          auStack_90[0] = auStack_90[0] & 0xffffff00;
          uStack_8._0_1_ = 3;
          if (0xf < uStack_bc) {
            uVar8 = auStack_d0[0];
            if ((0xfff < uStack_bc + 1) &&
               (uVar8 = *(uint *)(auStack_d0[0] - 4), uVar5 = (undefined)uStack_8,
               0x1f < (auStack_d0[0] - uVar8) - 4)) {
LAB_005d5795:
              uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
            FUN_01674ea0(uVar8);
          }
          uStack_c0 = 0;
          uStack_bc = 0xf;
          auStack_d0[0] = auStack_d0[0] & 0xffffff00;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar7 = piVar2[1] + -1;
          piVar2[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar7 = piVar2[2] + -1;
            piVar2[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar11 = piStack_30 + 2;
        piStack_30 = piVar11;
      } while (piVar11 != piStack_70);
    }
  }
  FUN_016811a0();
  FUN_01681d10();
  FUN_01681cd0();
  FUN_01681200();
  FUN_01681c50();
  FUN_0167ec80();
  piVar2 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_38[1] + -1;
    piStack_38[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar11 = piVar2 + 2;
      iVar7 = *piVar11 + -1;
      *piVar11 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_74 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_74[1] + -1;
    piStack_74[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_74)();
      LOCK();
      piVar2 = piStack_74 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_74 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 5496 ; VA 0x005d57a0 ; FUN_005d57a0 */

void __thiscall FUN_005d57a0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xbc);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0xbc);
  }
  *param_2 = *(undefined4 *)(param_1 + 0xb8);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 5497 ; VA 0x005d5800 ; FUN_005d5800 */

undefined4 __thiscall FUN_005d5800(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x214);
  return param_2;
}



/* FUNCTION 5498 ; VA 0x005d5820 ; FUN_005d5820 */

float10 __fastcall FUN_005d5820(int *param_1)

{
  (**(code **)(*param_1 + 0xa4))();
  return (float10)*(double *)(param_1 + 0x16);
}



/* FUNCTION 5499 ; VA 0x005d5840 ; FUN_005d5840 */

uint __fastcall FUN_005d5840(int param_1)

{
  int *piVar1;
  uint *puVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  undefined8 uVar10;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a028;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  if (DAT_01ea8d1c != 0) {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ea8d1c,"RCCMonitoring::heartbeat started.",0);
  }
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_38 == 0) {
    uVar6 = (uint)DAT_01d596f0;
    if (DAT_01d596f0 == 0) goto LAB_005d5b8a;
    uVar10 = 0x18c68c0;
  }
  else {
    uStack_30 = 0;
    iStack_2c = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("HeartBeat",9);
    uStack_8._0_1_ = 2;
    FUN_005da4c0(auStack_60,&uStack_30);
    uStack_8._0_1_ = 1;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_4c) {
      uVar8 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar8 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_30 = 0;
    iStack_2c = 0;
    uStack_8._0_1_ = 3;
    uStack_50 = 0;
    uStack_4c = 0xf;
    auStack_60[0] = auStack_60[0] & 0xffffff00;
    FUN_005542c0("HeartBeat",9);
    uStack_8._0_1_ = 4;
    FUN_005da090(auStack_60,&uStack_30);
    uStack_8._0_1_ = 3;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_4c) {
      uVar8 = uStack_4c + 1;
      uVar6 = auStack_60[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_60[0] - 4);
        uVar8 = uStack_4c + 0x24;
        if (0x1f < (auStack_60[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (DAT_01d597c4 != '\0') {
      FUN_005d9c80();
    }
    iStack_2c = iStack_38 + 0xc;
    iVar4 = FUN_00562e40();
    if ((iVar4 != 0) && (piVar7 = *(int **)(iVar4 + 0x2c), piVar7 != (int *)0x0)) {
      piStack_3c = *(int **)(iVar4 + 0x30);
      if (piStack_3c != (int *)0x0) {
        LOCK();
        piStack_3c[1] = piStack_3c[1] + 1;
        UNLOCK();
        piStack_3c = *(int **)(iVar4 + 0x30);
        piVar7 = *(int **)(iVar4 + 0x2c);
      }
      piStack_24 = (int *)piVar7[1];
      piVar9 = (int *)*piVar7;
      piStack_40 = piVar7;
      piStack_18 = piStack_3c;
      if (piVar9 != piStack_24) {
        do {
          piStack_44 = (int *)piVar9[1];
          if (piStack_44 != (int *)0x0) {
            LOCK();
            piStack_44[1] = piStack_44[1] + 1;
            UNLOCK();
            piStack_44 = (int *)piVar9[1];
          }
          piStack_48 = (int *)*piVar9;
          iVar4 = piStack_48[3];
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          piStack_20 = piStack_48;
          piStack_1c = piStack_44;
          iVar5 = FUN_005ee350();
          piVar7 = (int *)0x0;
          if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
              (uint)*(ushort *)(iVar5 + 0x1da)) {
            piVar7 = piStack_20;
          }
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x234))();
          }
          piVar7 = piStack_1c;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar4 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              piVar1 = piVar7 + 2;
              iVar4 = *piVar1 + -1;
              *piVar1 = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          piVar9 = piVar9 + 2;
          param_1 = iStack_28;
        } while (piVar9 != piStack_24);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_18[1] + -1;
        piStack_18[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar4 = piStack_18[2] + -1;
          piStack_18[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    cStack_11 = '\0';
    FUN_0065b3d0(&DAT_01d5ab10,0x62,&cStack_11);
    if (cStack_11 != '\0') {
      FUN_006688b0();
    }
    FUN_005d7f70();
    if (DAT_01ea8d1c != 0) {
      FUN_016774b0(DAT_01ea8d1c,"Executed Heartbeat API calls.",0);
    }
    iVar4 = FUN_005cf2a0();
    if (iVar4 == 0) {
      uVar6 = (uint)DAT_01d596f0;
      if (DAT_01d596f0 == 0) goto LAB_005d5b8a;
      uVar10 = 0x18c6958;
    }
    else {
      FUN_005ce4d0(FUN_005d5840,param_1,0);
      uVar6 = FUN_009eef30();
      if (DAT_01ea8d1c == 0) goto LAB_005d5b8a;
      uVar6 = (uint)DAT_01ea8d1c;
      uVar10 = CONCAT44(*(undefined4 *)(*(int *)(param_1 + 0x40) + 0x78),
                        "TimerService scheduled next heartbeat in %d");
    }
  }
  uVar6 = FUN_016774b0(uVar6,uVar10);
LAB_005d5b8a:
  if (piStack_34 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(piStack_34 + 1);
    uVar8 = *puVar2;
    uVar6 = *puVar2;
    *puVar2 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar6 = (**(code **)*piStack_34)();
      LOCK();
      piVar7 = piStack_34 + 2;
      iVar4 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}


