/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 24250 ; VA 0x00b516f0 ; FUN_00b516f0 */

uint * __thiscall FUN_00b516f0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3d48;
  pvStack_10 = ExceptionList;
  uVar9 = *param_2;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 != 0) {
    ExceptionList = pvStack_10;
    return (uint *)(iStack_14 + 8);
  }
  uStack_8 = 0;
  piVar4 = (int *)FUN_01674e20(0x10);
  puVar1 = (uint *)(piVar4 + 2);
  *piVar4 = 0;
  piVar4[1] = 0;
  puVar1[0] = 0;
  puVar1[1] = 0;
  *puVar1 = uVar9;
  if (piVar4 + 3 != (int *)0x0) {
    piVar4[3] = 0;
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar5 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar5 = FUN_005c9310(uVar5);
    if (uVar5 <= *(uint *)(param_1 + 4)) {
      uVar5 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar5);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar5) {
    iStack_14 = 1;
    uVar7 = uVar2 >> 1;
    if ((uVar2 >> 1) + uVar2 <= uVar5) {
      uVar7 = 1;
    }
    iVar6 = FUN_005c9310(uVar7 + uVar2);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar10;
      while (puVar3 != (undefined4 *)0x0) {
        piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar8 = (int)puVar10;
          puVar10 = puVar3;
        }
        else {
          *puVar10 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar8;
          *(undefined4 **)*piVar8 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uVar9;
  uVar9 = uVar9 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *puVar10 = piVar8;
    *piVar4 = *piVar8;
  }
  else {
    *piVar4 = *piVar8;
    piVar8 = (int *)*puVar10;
  }
  *piVar8 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 24251 ; VA 0x00b518b0 ; FUN_00b518b0 */

int * __thiscall FUN_00b518b0(byte *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3d68;
  pvStack_10 = ExceptionList;
  uVar7 = param_2[1] * 0x127409f ^ *param_2 * 0x466f45d;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    iVar6 = *piVar1;
    iVar2 = piVar1[1];
    uStack_8 = 0;
    param_2 = (int *)FUN_01674e20(0x14);
    *param_2 = 0;
    piVar1 = param_2 + 2;
    param_2[1] = 0;
    param_2[4] = 0;
    *piVar1 = iVar6;
    param_2[3] = iVar2;
    if (param_2 + 4 != (int *)0x0) {
      param_2[4] = 0;
    }
    uVar3 = *(uint *)(param_1 + 8);
    uVar5 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      uVar8 = uVar3 >> 1;
      if (uVar8 + uVar3 <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar3);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar4 = (undefined4 *)*puVar10;
        while (puVar4 != (undefined4 *)0x0) {
          piVar9 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar9 = (int)puVar10;
            puVar10 = puVar4;
          }
          else {
            *puVar10 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar9;
            *(undefined4 **)*piVar9 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar10;
        }
      }
    }
    param_2[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (piVar9 == (int *)0x0) {
      piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar9 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4)
             = param_2;
      }
      *puVar10 = piVar9;
      *param_2 = *piVar9;
    }
    else {
      *param_2 = *piVar9;
      piVar9 = (int *)*puVar10;
    }
    *piVar9 = (int)param_2;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 24252 ; VA 0x00b51a8e ; FUN_00b51a8e */

void FUN_00b51a8e(void)

{
  FUN_00b51ab0();
  return;
}



/* FUNCTION 24253 ; VA 0x00b51a9c ; FUN_00b51a9c */

void FUN_00b51a9c(void)

{
  FUN_00b51ae0();
  return;
}



/* FUNCTION 24254 ; VA 0x00b51ab0 ; FUN_00b51ab0 */

int __thiscall FUN_00b51ab0(int param_1,byte param_2)

{
  FUN_00b51590();
  *(undefined ***)(param_1 + 0x1c4) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c8);
  }
  return param_1;
}



/* FUNCTION 24255 ; VA 0x00b51ae0 ; FUN_00b51ae0 */

undefined4 __thiscall FUN_00b51ae0(undefined4 param_1,byte param_2)

{
  FUN_00b4d790();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x158);
  }
  return param_1;
}



/* FUNCTION 24256 ; VA 0x00b51b10 ; FUN_00b51b10 */

undefined4 * __thiscall FUN_00b51b10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PartInstance::FormFactor>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24257 ; VA 0x00b51b40 ; FUN_00b51b40 */

undefined4 * __thiscall FUN_00b51b40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::RenderFidelity>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24258 ; VA 0x00b51b70 ; FUN_00b51b70 */

undefined4 * __thiscall FUN_00b51b70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24259 ; VA 0x00b51ba0 ; FUN_00b51ba0 */

undefined4 * __thiscall FUN_00b51ba0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::PartInstance::FormFactor>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24260 ; VA 0x00b51bd0 ; FUN_00b51bd0 */

undefined4 * __thiscall FUN_00b51bd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::RenderFidelity>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24261 ; VA 0x00b51c00 ; FUN_00b51c00 */

undefined4 __thiscall FUN_00b51c00(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (0x30c30c3 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0x54;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24262 ; VA 0x00b51cc0 ; FUN_00b51cc0 */

undefined4 __thiscall FUN_00b51cc0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0xc;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24263 ; VA 0x00b51d80 ; FUN_00b51d80 */

void __fastcall FUN_00b51d80(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x54) * 0x54;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 24264 ; VA 0x00b51df0 ; FUN_00b51df0 */

void __thiscall FUN_00b51df0(int param_1,undefined8 *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar3 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
    fVar3 = *(float *)(param_1 + 0x114);
  }
  fVar2 = *(float *)(param_1 + 0x118);
  fVar1 = DAT_018c45c4;
  if (fVar3 <= DAT_018c45c4) {
    fVar1 = fVar3;
  }
  fVar3 = DAT_018f76ac;
  if (DAT_018f76ac <= fVar2) {
    fVar3 = fVar2;
  }
  fVar4 = DAT_018c45c4;
  if (fVar3 <= DAT_018c45c4) {
    fVar4 = fVar3;
  }
  fVar3 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
    fVar3 = *(float *)(param_1 + 0x11c);
  }
  fVar6 = DAT_018c45c4;
  if (fVar3 <= DAT_018c45c4) {
    fVar6 = fVar3;
  }
  fVar3 = param_3[1] / fVar4;
  if (*param_3 / fVar1 <= param_3[1] / fVar4) {
    fVar3 = *param_3 / fVar1;
  }
  fVar1 = param_3[2] / fVar6;
  if (fVar3 <= param_3[2] / fVar6) {
    fVar1 = fVar3;
  }
  fVar6 = fVar1 - DAT_018e452c / *(float *)(param_1 + 0x114);
  fVar2 = fVar1 - DAT_018e452c / fVar2;
  fVar4 = fVar1 - DAT_018e452c / *(float *)(param_1 + 0x11c);
  fVar3 = fVar2;
  if (fVar6 <= fVar2) {
    fVar3 = fVar6;
  }
  fVar5 = fVar4;
  if (fVar3 <= fVar4) {
    fVar5 = fVar3;
  }
  if (fVar5 < DAT_018f76ac) {
    *param_2 = CONCAT44(fVar1,fVar1);
    *(float *)(param_2 + 1) = fVar1;
    return;
  }
  *param_2 = CONCAT44(fVar2,fVar6);
  *(float *)(param_2 + 1) = fVar4;
  return;
}



/* FUNCTION 24265 ; VA 0x00b51f00 ; FUN_00b51f00 */

void __thiscall FUN_00b51f00(int param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar1 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
    fVar1 = *(float *)(param_1 + 0x114);
  }
  fVar2 = DAT_018c45c4;
  if (fVar1 <= DAT_018c45c4) {
    fVar2 = fVar1;
  }
  fVar1 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x118)) {
    fVar1 = *(float *)(param_1 + 0x118);
  }
  fVar3 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
    fVar3 = *(float *)(param_1 + 0x11c);
  }
  fVar4 = DAT_018c45c4;
  if (fVar3 <= DAT_018c45c4) {
    fVar4 = fVar3;
  }
  fVar3 = DAT_018c45c4;
  if (fVar1 <= DAT_018c45c4) {
    fVar3 = fVar1;
  }
  fVar1 = param_3[1] / fVar3;
  if (*param_3 / fVar2 <= param_3[1] / fVar3) {
    fVar1 = *param_3 / fVar2;
  }
  fVar2 = param_3[2] / fVar4;
  if (fVar1 <= param_3[2] / fVar4) {
    fVar2 = fVar1;
  }
  *param_2 = fVar2;
  param_2[1] = fVar2;
  param_2[2] = fVar2;
  return;
}



/* FUNCTION 24266 ; VA 0x00b51f90 ; FUN_00b51f90 */

void __fastcall FUN_00b51f90(int *param_1)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3ed8;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b550f0(auStack_34);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = 1;
  FUN_00b554b0(auStack_34);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = 2;
  (**(code **)(*param_1 + 0x154))(auStack_34);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    uVar4 = auStack_34[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_34[0] - 4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (DAT_01d67098 != '\0') {
    piVar3 = (int *)FUN_00a33c70();
    uStack_8 = 3;
    cVar2 = FUN_005e0cd0(piVar3);
    if (cVar2 != '\0') {
      iVar1 = *piVar3;
      LOCK();
      piVar3 = (int *)(iVar1 + 0x28);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      iStack_14 = param_1[0x60];
      param_1[0x60] = iVar1;
      FUN_0056cd30();
      FUN_008a4940(&DAT_01eeec34);
    }
    uStack_8 = 0xffffffff;
    FUN_0056cd30();
    piVar3 = (int *)FUN_00a33c70();
    uStack_8 = 4;
    cVar2 = FUN_005e0cd0(piVar3);
    if (cVar2 != '\0') {
      iVar1 = *piVar3;
      LOCK();
      piVar3 = (int *)(iVar1 + 0x28);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      iStack_14 = param_1[0x61];
      param_1[0x61] = iVar1;
      FUN_0056cd30();
      FUN_008a4940(&DAT_01eeec6c);
    }
    FUN_0056cd30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24267 ; VA 0x00b521c0 ; FUN_00b521c0 */

undefined4 FUN_00b521c0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00b08320();
  FUN_00b51df0(param_1,uVar1);
  return param_1;
}



/* FUNCTION 24268 ; VA 0x00b521e0 ; FUN_00b521e0 */

/* WARNING: Type propagation algorithm not settling */

undefined FUN_00b521e0(int *param_1,int *param_2,byte param_3,int *param_4)

{
  undefined *puVar1;
  undefined **ppuVar2;
  float *pfVar3;
  float *pfVar4;
  int iVar5;
  int *piVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  int *piVar11;
  undefined8 *puVar12;
  int iVar13;
  undefined8 *puVar14;
  int iVar15;
  int iVar16;
  float10 fVar17;
  double dVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined auStack_110 [8];
  undefined auStack_108 [24];
  float fStack_f0;
  float fStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  float fStack_dc;
  float fStack_d8;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  byte bStack_98;
  undefined auStack_97 [3];
  undefined *puStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 *puStack_84;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 *puStack_60;
  undefined8 *puStack_5c;
  undefined8 *puStack_58;
  int iStack_54;
  int *piStack_50;
  int aiStack_4c [2];
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  undefined8 uStack_38;
  int *piStack_30;
  int *piStack_2c;
  undefined uStack_25;
  uint uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017f3f0b;
  pvStack_1c = ExceptionList;
  puVar14 = (undefined8 *)0x0;
  piStack_50 = (int *)(param_2[1] - *param_2 >> 2);
  puStack_60 = (undefined8 *)0x0;
  puStack_5c = (undefined8 *)0x0;
  puStack_58 = (undefined8 *)0x0;
  uStack_68 = (double)CONCAT44((param_1[1] - *param_1) / 0x54,(undefined4)uStack_68);
  uStack_14 = 0;
  bStack_98 = 0;
  aiStack_4c[1] = 0xb;
  ExceptionList = &pvStack_1c;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,aiStack_4c + 1);
  ppuVar7 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar2;
  }
  puStack_94 = *ppuVar7;
  iStack_90 = 0;
  uStack_8c = 0x3f800000;
  uStack_88 = 0;
  puStack_84 = (undefined4 *)0x0;
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  aiStack_4c[1] = 0;
  piStack_2c = (int *)0x0;
  puVar12 = (undefined8 *)0x0;
  if (piStack_50 != (int *)0x0) {
    uStack_80 = (double)CONCAT44(3,(undefined4)uStack_80);
    do {
      uStack_24 = (int)piStack_2c * 4;
      iVar15 = *param_2;
      iVar5 = *(int *)(iVar15 + uStack_24);
      iVar13 = *param_1;
      pfVar3 = (float *)(iVar5 * 0x54 + iVar13);
      pfVar4 = (float *)(*(int *)(iVar15 + 4 + uStack_24) * 0x54 + iVar13);
      fStack_a4 = pfVar4[2];
      fVar21 = *pfVar4 - *pfVar3;
      fVar20 = pfVar4[1] - pfVar3[1];
      pfVar4 = (float *)(*(int *)(iVar15 + 8 + uStack_24) * 0x54 + iVar13);
      fStack_f0 = pfVar4[4];
      fStack_ec = pfVar4[5];
      fStack_e8 = pfVar4[6];
      fStack_e4 = pfVar4[7];
      fStack_e0 = pfVar4[8];
      fStack_dc = pfVar4[9];
      fStack_d8 = pfVar4[10];
      fStack_d4 = pfVar4[0xb];
      fStack_d0 = pfVar4[0xc];
      fStack_cc = pfVar4[0xd];
      fStack_c8 = pfVar4[0xe];
      fStack_c4 = pfVar4[0xf];
      fStack_c0 = pfVar4[0x10];
      fStack_bc = pfVar4[0x11];
      fStack_b8 = pfVar4[0x12];
      fStack_b4 = pfVar4[0x13];
      fVar24 = pfVar4[1] - pfVar3[1];
      iVar13 = *param_4;
      fStack_a8 = fStack_a4 - pfVar3[2];
      fVar23 = pfVar4[2] - pfVar3[2];
      fVar19 = *pfVar4 - *pfVar3;
      fVar22 = fVar23 * fVar20 - fVar24 * fStack_a8;
      fVar23 = fVar19 * fStack_a8 - fVar23 * fVar21;
      fVar19 = fVar24 * fVar21 - fVar19 * fVar20;
      *(float *)(iVar13 + iVar5 * 0xc) = *(float *)(iVar13 + iVar5 * 0xc) + fVar22;
      *(float *)(iVar13 + 4 + iVar5 * 0xc) = *(float *)(iVar13 + 4 + iVar5 * 0xc) + fVar23;
      *(float *)(iVar13 + 8 + iVar5 * 0xc) = *(float *)(iVar13 + 8 + iVar5 * 0xc) + fVar19;
      iVar5 = *(int *)(iVar15 + 4 + uStack_24);
      *(float *)(iVar13 + iVar5 * 0xc) = *(float *)(iVar13 + iVar5 * 0xc) + fVar22;
      *(float *)(iVar13 + 4 + iVar5 * 0xc) = *(float *)(iVar13 + 4 + iVar5 * 0xc) + fVar23;
      *(float *)(iVar13 + 8 + iVar5 * 0xc) = *(float *)(iVar13 + 8 + iVar5 * 0xc) + fVar19;
      iVar15 = *(int *)(iVar15 + 8 + uStack_24);
      *(float *)(iVar13 + iVar15 * 0xc) = *(float *)(iVar13 + iVar15 * 0xc) + fVar22;
      *(float *)(iVar13 + 4 + iVar15 * 0xc) = *(float *)(iVar13 + 4 + iVar15 * 0xc) + fVar23;
      *(float *)(iVar13 + 8 + iVar15 * 0xc) = *(float *)(iVar13 + 8 + iVar15 * 0xc) + fVar19;
      iVar15 = 0;
      fStack_a0 = fStack_a4;
      fStack_9c = fStack_a4;
      do {
        uStack_38 = (double)CONCAT44(iVar15 + 1,(undefined4)uStack_38);
        piVar10 = *(int **)(uStack_24 + *param_2);
        piVar11 = *(int **)(*param_2 + ((iVar15 + 1) % (int)uStack_80._4_4_ + (int)piStack_2c) * 4);
        piStack_30 = piVar11;
        if ((int)piVar11 < (int)piVar10) {
          piStack_30 = piVar10;
          piVar10 = piVar11;
        }
        uStack_78 = (double)CONCAT44(piStack_30,piVar10);
        FUN_00606ff0((int)&uStack_70 + 4,(int)piVar10 * 0x466f45d ^ (int)piStack_30 * 0x127409f,
                     &uStack_78,
                     -(uint)(auStack_97 + bStack_98 != (undefined *)0x0) &
                     (uint)(auStack_97 + bStack_98 + 1));
        if (uStack_70._4_4_ == 0) {
          piStack_40 = piStack_30;
          piStack_3c = (int *)0x1;
          piStack_44 = piVar10;
          if (puStack_58 == puVar14) {
            FUN_00b50440(puVar14,&piStack_44);
          }
          else {
            *(int **)puVar14 = piVar10;
            *(int **)((int)puVar14 + 4) = piStack_30;
            *(undefined4 *)(puVar14 + 1) = 1;
            puStack_5c = (undefined8 *)((int)puVar14 + 0xc);
          }
          iVar15 = aiStack_4c[1];
          puVar14 = puStack_5c;
          aiStack_4c[1] = aiStack_4c[1] + 1;
          iVar5 = FUN_00b518b0(&uStack_78);
          *(int *)(iVar5 + 8) = iVar15;
        }
        else {
          piVar10 = (int *)((int)puStack_60 + *(int *)(uStack_70._4_4_ + 0x10) * 0xc + 8);
          *piVar10 = *piVar10 + 1;
        }
        puVar9 = puStack_84;
        puVar1 = puStack_94;
        uStack_24 = uStack_24 + 4;
        iVar15 = uStack_38._4_4_;
      } while (uStack_38._4_4_ < 3);
      piStack_2c = (int *)((int)piStack_2c + 3);
    } while (piStack_2c < piStack_50);
    puVar12 = puStack_60;
    if (iStack_90 != 0) {
      puVar8 = (undefined4 *)puStack_84[(int)puStack_94];
      do {
        puVar9[(int)puVar1] = *puVar8;
        FUN_01674ea0(puVar8,0x14);
        iStack_90 = iStack_90 + -1;
        puVar8 = (undefined4 *)puVar9[(int)puVar1];
      } while (puVar8 != (undefined4 *)0x0);
      for (puVar9 = puStack_84; puVar12 = puStack_60, puVar14 = puStack_5c,
          puVar9 != puStack_84 + (int)puStack_94; puVar9 = puVar9 + 1) {
        *puVar9 = 0;
      }
    }
  }
  if (uStack_68._4_4_ != 0) {
    uStack_24 = 0;
    iVar15 = uStack_68._4_4_;
    do {
      iVar5 = *param_4;
      fVar23 = *(float *)(iVar5 + 4 + uStack_24);
      fVar19 = *(float *)(iVar5 + 8 + uStack_24);
      uStack_80 = (double)(*(float *)(iVar5 + uStack_24) * *(float *)(iVar5 + uStack_24) +
                           fVar23 * fVar23 + fVar19 * fVar19);
      if (NAN(uStack_80) == (uStack_80 == 0.0)) {
        uStack_70 = (double)CONCAT44((uint)((ulonglong)(uStack_80 - 0.0) >> 0x20) &
                                     DAT_018c0da0._4_4_,
                                     SUB84(uStack_80 - 0.0,0) & (uint)DAT_018c0da0);
        uStack_78 = (double)CONCAT44((uint)((ulonglong)uStack_80 >> 0x20) & DAT_018c0da0._4_4_,
                                     SUB84(uStack_80,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
        fVar17 = (float10)FUN_01160810();
        uStack_38 = (double)fVar17;
        dVar18 = DAT_018f76b0;
        if ((NAN(uStack_78) || NAN(uStack_38)) == (uStack_78 == uStack_38)) {
          dVar18 = uStack_78 * DAT_018f76b0;
        }
        if (uStack_70 <= dVar18) goto LAB_00b526d5;
        dVar18 = uStack_80;
        FUN_017267a0();
        pfVar3 = (float *)(*param_4 + uStack_24);
        fVar23 = DAT_018ce2f8 / (float)dVar18;
        *pfVar3 = fVar23 * *pfVar3;
        pfVar3[1] = fVar23 * pfVar3[1];
        pfVar3[2] = fVar23 * pfVar3[2];
      }
      else {
LAB_00b526d5:
        iVar5 = *param_4;
        piStack_3c = (int *)0x0;
        *(undefined8 *)(iVar5 + uStack_24) = 0;
        *(undefined4 *)((undefined8 *)(iVar5 + uStack_24) + 1) = 0;
      }
      uStack_24 = uStack_24 + 0xc;
      iVar15 = iVar15 + -1;
      puVar12 = puStack_60;
      puVar14 = puStack_5c;
    } while (iVar15 != 0);
  }
  piVar10 = (int *)0x0;
  piStack_44 = (int *)0x0;
  piVar11 = (int *)0x0;
  piStack_40 = (int *)0x0;
  piStack_3c = (int *)0x0;
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  piVar6 = piStack_44;
  for (; piStack_44 = piVar6, puVar12 != puVar14; puVar12 = (undefined8 *)((int)puVar12 + 0xc)) {
    if (*(int *)(puVar12 + 1) == 1) {
      if (piVar11 == piVar10) {
        FUN_00b50440(piVar10,puVar12);
        piVar10 = piStack_40;
        piVar11 = piStack_3c;
      }
      else {
        *(undefined8 *)piVar10 = *puVar12;
        piVar10[2] = *(int *)(puVar12 + 1);
        piStack_40 = piVar10 + 3;
        piVar10 = piStack_40;
      }
    }
    piVar6 = piStack_44;
  }
  puStack_5c = puStack_60;
  if (piVar6 == piVar10) {
    uStack_25 = 0;
  }
  else {
    dVar18 = (double)(((float)param_3 * DAT_018f8ff4) / DAT_01900a20);
    FUN_017279f0();
    piVar6 = piVar6 + 3;
    uStack_80 = (double)CONCAT44((float)dVar18,(undefined4)uStack_80);
    do {
      iStack_54 = piVar6[-3];
      piStack_50 = (int *)piVar6[-2];
      piStack_30 = piVar6;
      FUN_00b50590(auStack_108,0,&iStack_54,uStack_38._4_4_);
      FUN_00b50590(auStack_110,0,&piStack_50,uStack_38._4_4_);
      piVar10 = piVar6;
      if (piVar6 != piStack_40) {
        uStack_24 = iStack_54 * 0x54;
        iVar15 = *param_1;
        do {
          iVar5 = *piVar6;
          uStack_70 = (double)CONCAT44(iVar5,(undefined4)uStack_70);
          aiStack_4c[0] = iVar5;
          iVar13 = iVar5 * 0x54;
          aiStack_4c[1] = piVar6[1];
          if (((*(int *)(uStack_24 + iVar15) == *(int *)(iVar13 + iVar15)) &&
              (*(int *)(uStack_24 + 4 + iVar15) == *(int *)(iVar13 + 4 + iVar15))) &&
             (*(int *)(uStack_24 + 8 + iVar15) == *(int *)(iVar13 + 8 + iVar15))) {
            piStack_2c = (int *)(piVar6[1] * 0x54 + iVar15);
            piVar10 = (int *)((int)piStack_50 * 0x54 + iVar15);
            uStack_68 = (double)CONCAT44(piVar10,(undefined4)uStack_68);
            if (((*piVar10 != *piStack_2c) || (piVar10[1] != piStack_2c[1])) ||
               (piVar10[2] != piStack_2c[2])) goto LAB_00b52872;
LAB_00b528e8:
            uStack_24 = 0;
            do {
              iVar15 = *(int *)((int)&iStack_54 + uStack_24);
              if (*(int *)(iVar15 * 0x54 + 0x18 + *param_1) ==
                  *(int *)(*(int *)((int)aiStack_4c + uStack_24) * 0x54 + 0x18 + *param_1)) {
                iVar5 = *param_4;
                fVar23 = *(float *)(iVar5 + iVar15 * 0xc);
                fVar19 = *(float *)(iVar5 + 4 + iVar15 * 0xc);
                fVar20 = *(float *)(iVar5 + 8 + iVar15 * 0xc);
                dVar18 = (double)(fVar23 * fVar23 + fVar19 * fVar19 + fVar20 * fVar20);
                if (NAN(dVar18) == (dVar18 == 0.0)) {
                  uStack_38 = (double)CONCAT44((uint)((ulonglong)dVar18 >> 0x20) &
                                               DAT_018c0da0._4_4_,
                                               SUB84(dVar18,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
                  uStack_68 = (double)CONCAT44((uint)((ulonglong)(dVar18 - 0.0) >> 0x20) &
                                               DAT_018c0da0._4_4_,
                                               SUB84(dVar18 - 0.0,0) & (uint)DAT_018c0da0);
                  fVar17 = (float10)FUN_01160810();
                  uStack_70 = (double)fVar17;
                  dVar18 = DAT_018f76b0;
                  if ((NAN(uStack_38) || NAN(uStack_70)) == (uStack_38 == uStack_70)) {
                    dVar18 = uStack_38 * DAT_018f76b0;
                  }
                  if (dVar18 < uStack_68) {
                    iVar5 = *(int *)((int)aiStack_4c + uStack_24);
                    iVar13 = *param_4;
                    fVar23 = *(float *)(iVar13 + iVar5 * 0xc);
                    fVar19 = *(float *)(iVar13 + 4 + iVar5 * 0xc);
                    fVar20 = *(float *)(iVar13 + 8 + iVar5 * 0xc);
                    dVar18 = (double)(fVar23 * fVar23 + fVar19 * fVar19 + fVar20 * fVar20);
                    if (NAN(dVar18) == (dVar18 == 0.0)) {
                      uStack_38 = (double)CONCAT44((uint)((ulonglong)dVar18 >> 0x20) &
                                                   DAT_018c0da0._4_4_,
                                                   SUB84(dVar18,0) & (uint)DAT_018c0da0) +
                                  DAT_018c0d60;
                      uStack_68 = (double)CONCAT44((uint)((ulonglong)(dVar18 - 0.0) >> 0x20) &
                                                   DAT_018c0da0._4_4_,
                                                   SUB84(dVar18 - 0.0,0) & (uint)DAT_018c0da0);
                      fVar17 = (float10)FUN_01160810();
                      uStack_70 = (double)fVar17;
                      dVar18 = DAT_018f76b0;
                      if ((NAN(uStack_38) || NAN(uStack_70)) == (uStack_38 == uStack_70)) {
                        dVar18 = uStack_38 * DAT_018f76b0;
                      }
                      if (dVar18 < uStack_68) {
                        iVar13 = *param_4;
                        if (uStack_80._4_4_ <=
                            *(float *)(iVar13 + 4 + iVar15 * 0xc) *
                            *(float *)(iVar13 + 4 + iVar5 * 0xc) +
                            *(float *)(iVar13 + iVar5 * 0xc) * *(float *)(iVar13 + iVar15 * 0xc) +
                            *(float *)(iVar13 + 8 + iVar15 * 0xc) *
                            *(float *)(iVar13 + 8 + iVar5 * 0xc)) {
                          if (*(int *)((int)&iStack_54 + uStack_24) !=
                              *(int *)((int)aiStack_4c + uStack_24)) {
                            uStack_78 = (double)CONCAT44(*(int *)((int)aiStack_4c + uStack_24),
                                                         *(int *)((int)&iStack_54 + uStack_24));
                            FUN_00b506e0(&fStack_a0,0,&uStack_78,uStack_38._4_4_);
                          }
                        }
                      }
                    }
                  }
                }
              }
              uStack_24 = uStack_24 + 4;
              piVar10 = piStack_30;
            } while (uStack_24 < 8);
            break;
          }
LAB_00b52872:
          piStack_2c = (int *)(piVar6[1] * 0x54 + iVar15);
          if (((*(int *)(uStack_24 + iVar15) == *piStack_2c) &&
              (*(int *)(uStack_24 + 4 + iVar15) == piStack_2c[1])) &&
             ((*(int *)(uStack_24 + 8 + iVar15) == piStack_2c[2] &&
              (((iVar16 = (int)piStack_50 * 0x54,
                *(int *)(iVar16 + iVar15) == *(int *)(iVar13 + iVar15) &&
                (*(int *)(iVar16 + 4 + iVar15) == *(int *)(iVar13 + 4 + iVar15))) &&
               (*(int *)(iVar16 + 8 + iVar15) == *(int *)(iVar13 + 8 + iVar15))))))) {
            aiStack_4c[0] = piVar6[1];
            aiStack_4c[1] = iVar5;
            goto LAB_00b528e8;
          }
          piVar6 = piVar6 + 3;
          piVar10 = piStack_30;
        } while (piVar6 != piStack_40);
      }
      piVar6 = piVar10 + 3;
    } while (piVar10 != piStack_40);
    uStack_25 = 1;
    piStack_30 = piVar6;
  }
  FUN_00617ad0();
  FUN_0061ac80();
  FUN_00617ad0();
  ExceptionList = pvStack_1c;
  return uStack_25;
}



/* FUNCTION 24269 ; VA 0x00b52b20 ; FUN_00b52b20 */

void FUN_00b52b20(int *param_1,int *param_2,int *param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined **ppuVar7;
  int iVar8;
  undefined **ppuVar9;
  uint *puVar10;
  undefined8 *puVar11;
  int *piVar12;
  uint *puVar13;
  uint *puVar14;
  uint uVar15;
  float10 fVar16;
  double dVar17;
  float fVar18;
  int *piVar19;
  float fVar20;
  double dStack_b0;
  double dStack_a8;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  int aiStack_94 [3];
  int aiStack_88 [3];
  byte bStack_7c;
  undefined auStack_7b [3];
  undefined *puStack_78;
  int iStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  uint *puStack_64;
  uint *puStack_60;
  uint *puStack_5c;
  undefined4 *puStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  int *piStack_48;
  float fStack_44;
  undefined auStack_40 [4];
  uint *puStack_3c;
  undefined8 uStack_38;
  int *piStack_30;
  uint uStack_2c;
  uint *puStack_28;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f3f4e;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  FUN_016f4053(aiStack_94,0xc,2,FUN_00569440,FUN_0056d320);
  uStack_14 = 0;
  fStack_24 = -NAN;
  FUN_005f87c0(param_2[1] * 2,aiStack_94,&fStack_24);
  fStack_24 = -NAN;
  FUN_005f87c0(param_2[1] * 2,aiStack_88,&fStack_24);
  bStack_7c = 0;
  fStack_24 = 1.54143e-44;
  ppuVar7 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_24);
  ppuVar9 = ppuVar7 + -1;
  if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar7;
  }
  puStack_78 = *ppuVar9;
  iStack_74 = 0;
  uStack_70 = 0x3f800000;
  uStack_6c = 0;
  iStack_68 = 0;
  uStack_14._0_1_ = 1;
  puStack_58 = (undefined4 *)0x0;
  uStack_54 = 0;
  puStack_58 = (undefined4 *)FUN_0089c660();
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  uStack_2c = 0;
  piStack_30 = *(int **)*param_2;
  if (piStack_30 != (int *)*param_2) {
    do {
      puVar11 = &uStack_38;
      uStack_38 = *(double *)((int)piStack_30 + 0x10);
      puStack_28 = (uint *)0x1;
      uStack_50 = (double)CONCAT44(2,(undefined4)uStack_50);
      do {
        puVar10 = puStack_28;
        FUN_00606ea0(&fStack_24,*(undefined4 *)puVar11,puVar11,
                     -(uint)(auStack_7b + bStack_7c != (undefined *)0x0) &
                     (uint)(auStack_7b + bStack_7c + 1));
        uVar15 = uStack_2c;
        if (fStack_24 == 0.0) {
          *(undefined4 *)(aiStack_94[0] + uStack_2c * 4) =
               *(undefined4 *)((int)&uStack_38 + ((uint)puVar10 & 1) * 4);
          iVar8 = FUN_00b516f0(puVar11);
          *(uint *)(iVar8 + 4) = uVar15;
          uStack_2c = uVar15 + 1;
        }
        else {
          iVar8 = *(int *)((int)fStack_24 + 0xc);
          piStack_48 = *(int **)((int)fStack_24 + 8);
          fStack_44 = *(float *)((int)&uStack_38 + ((uint)puStack_28 & 1) * 4);
          if ((*(float *)(aiStack_94[0] + iVar8 * 4) != fStack_44) &&
             (fVar18 = *(float *)(aiStack_88[0] + iVar8 * 4), fVar18 != fStack_44)) {
            if (fVar18 == -NAN) {
              *(float *)(aiStack_88[0] + iVar8 * 4) = fStack_44;
            }
            else {
              FUN_00b50590(&dStack_b0,0,&piStack_48,uStack_38._4_4_);
              FUN_00b50590(&dStack_a8,0,&fStack_44,uStack_38._4_4_);
              FUN_00b50590(auStack_40,0,aiStack_94[0] + iVar8 * 4,uStack_38._4_4_);
              FUN_00b50590(&puStack_60,0,aiStack_88[0] + iVar8 * 4,uStack_38._4_4_);
            }
          }
        }
        puStack_28 = (uint *)((int)puStack_28 + 1);
        puVar11 = (undefined8 *)((int)puVar11 + 4);
        iVar8 = (int)uStack_50._4_4_ + -1;
        uStack_50 = (double)CONCAT44(iVar8,(undefined4)uStack_50);
      } while (iVar8 != 0);
      FUN_00551320();
    } while (piStack_30 != (int *)*param_2);
  }
  puVar5 = puStack_58;
  puVar2 = (undefined4 *)*puStack_58;
  while (puVar2 != puVar5) {
    fStack_24 = (float)puVar2[4];
    iVar8 = FUN_00b516f0(&fStack_24);
    *(undefined4 *)(iVar8 + 4) = 0xffffffff;
    puVar3 = (undefined4 *)puVar2[2];
    if (*(char *)((int)puVar3 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar3 + 0xd);
      puVar2 = puVar3;
      puVar3 = (undefined4 *)*puVar3;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar3 + 0xd);
        puVar2 = puVar3;
        puVar3 = (undefined4 *)*puVar3;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar2[1] + 0xd);
      puVar6 = (undefined4 *)puVar2[1];
      puVar3 = puVar2;
      while ((puVar2 = puVar6, cVar1 == '\0' && (puVar3 == (undefined4 *)puVar2[2]))) {
        cVar1 = *(char *)((int)puVar2[1] + 0xd);
        puVar6 = (undefined4 *)puVar2[1];
        puVar3 = puVar2;
      }
    }
  }
  puStack_3c = (uint *)0x0;
  puStack_64 = (uint *)0x0;
  puStack_60 = (uint *)0x0;
  puStack_28 = (uint *)0x0;
  puStack_5c = (uint *)0x0;
  uStack_14._1_3_ = (undefined3)((uint)uStack_14 >> 8);
  uStack_14._0_1_ = 3;
  if (iStack_74 == 0) {
    piVar12 = (int *)0x0;
  }
  else {
    piVar12 = *(int **)(iStack_68 + (int)puStack_78 * 4);
  }
  piStack_30 = piVar12;
  if (piVar12 != (int *)0x0) {
    do {
      puVar10 = puStack_3c;
      uStack_2c = piVar12[2];
      uStack_50 = (double)CONCAT44(uStack_2c,(undefined4)uStack_50);
      puStack_60 = puStack_3c;
      piStack_30 = piVar12;
      iVar8 = FUN_00b516f0((int)&uStack_50 + 4);
      fStack_44 = *(float *)(iVar8 + 4);
      if (fStack_44 != -NAN) {
        if (puStack_28 == puStack_3c) {
          FUN_0063d9b0(puStack_3c,(int)&uStack_50 + 4);
          puStack_28 = puStack_5c;
          uStack_2c = (uint)uStack_50._4_4_;
        }
        else {
          puStack_60 = puStack_3c + 1;
          *puStack_3c = uStack_2c;
        }
        uVar15 = uStack_2c;
        puVar10 = puStack_60;
        iVar8 = FUN_00b516f0((int)&uStack_50 + 4);
        fStack_24 = 2.8026e-45;
        *(undefined4 *)(iVar8 + 4) = 0xffffffff;
        piStack_48 = aiStack_94;
        fVar18 = fStack_44;
        do {
          uStack_50 = (double)CONCAT44(uVar15,(undefined4)uStack_50);
          puVar14 = *(uint **)(*piStack_48 + (int)fVar18 * 4);
          puStack_3c = puVar14;
          while (puVar14 != (uint *)0xffffffff) {
            puStack_3c = puVar14;
            iVar8 = FUN_00b516f0(&puStack_3c);
            uStack_38 = (double)CONCAT44(*(int *)(iVar8 + 4),(undefined4)uStack_38);
            fVar18 = fStack_44;
            if (*(int *)(iVar8 + 4) == -1) break;
            if (puStack_28 == puVar10) {
              FUN_0063d9b0(puVar10,&puStack_3c);
              puStack_28 = puStack_5c;
              puVar13 = puStack_3c;
            }
            else {
              *puVar10 = (uint)puVar14;
              puStack_60 = puVar10 + 1;
              puVar13 = puVar14;
            }
            puVar10 = puStack_60;
            iVar8 = FUN_00b516f0(&puStack_3c);
            *(undefined4 *)(iVar8 + 4) = 0xffffffff;
            puVar14 = *(uint **)(aiStack_94[0] + uStack_38._4_4_ * 4);
            puStack_3c = puVar14;
            if (puVar14 == uStack_50._4_4_) {
              puVar14 = *(uint **)(aiStack_88[0] + uStack_38._4_4_ * 4);
              puStack_3c = puVar14;
            }
            uStack_50 = (double)CONCAT44(puVar13,(undefined4)uStack_50);
            fVar18 = fStack_44;
          }
          piStack_48 = piStack_48 + 3;
          fStack_24 = (float)((int)fStack_24 + -1);
          uVar15 = uStack_2c;
        } while (fStack_24 != 0.0);
        puStack_3c = puStack_64;
        piVar12 = piStack_30;
        puVar10 = puStack_60;
      }
      if (1 < (uint)((int)puVar10 - (int)puStack_3c >> 2)) {
        uStack_38 = (double)((ulonglong)uStack_38 & 0xffffffff);
        dVar17 = uStack_38;
        uStack_2c = ((int)puVar10 - (int)puStack_3c) + 3U >> 2;
        uStack_50 = (double)CONCAT44(puStack_3c,(undefined4)uStack_50);
        fVar18 = 0.0;
        piVar19 = (int *)0x0;
        if (puVar10 < puStack_3c) {
          uStack_2c = 0;
        }
        fStack_24 = 0.0;
        piStack_48 = (int *)0x0;
        fVar20 = 0.0;
        fStack_44 = 0.0;
        if (uStack_2c != 0) {
          uStack_38._4_4_ = 0;
          iVar8 = *param_1;
          puVar10 = puStack_3c;
          do {
            uVar15 = *puVar10;
            uStack_38._4_4_ = uStack_38._4_4_ + 1;
            puVar10 = puVar10 + 1;
            fVar18 = fVar18 + *(float *)(iVar8 + uVar15 * 0xc);
            piVar19 = (int *)((float)piVar19 + *(float *)(iVar8 + 4 + uVar15 * 0xc));
            fVar20 = fVar20 + *(float *)(iVar8 + 8 + uVar15 * 0xc);
            piVar12 = piStack_30;
            piStack_48 = piVar19;
            fStack_44 = fVar20;
            fStack_24 = fVar18;
          } while (uStack_38._4_4_ != uStack_2c);
        }
        dStack_b0 = (double)((float)piStack_48 * (float)piStack_48 + fStack_24 * fStack_24 +
                            fStack_44 * fStack_44);
        uStack_38 = dVar17;
        if (NAN(dStack_b0) == (dStack_b0 == 0.0)) {
          dStack_a8 = (double)CONCAT44((uint)((ulonglong)(dStack_b0 - 0.0) >> 0x20) &
                                       DAT_018c0da0._4_4_,
                                       SUB84(dStack_b0 - 0.0,0) & (uint)DAT_018c0da0);
          uStack_38 = (double)CONCAT44((uint)((ulonglong)dStack_b0 >> 0x20) & DAT_018c0da0._4_4_,
                                       SUB84(dStack_b0,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
          fVar16 = (float10)FUN_01160810();
          uStack_50 = (double)fVar16;
          dVar17 = DAT_018f76b0;
          if ((NAN(uStack_38) || NAN(uStack_50)) == (uStack_38 == uStack_50)) {
            dVar17 = uStack_38 * DAT_018f76b0;
          }
          if (dVar17 < dStack_a8) {
            dVar17 = dStack_b0;
            FUN_017267a0();
            uVar15 = 0;
            uStack_38 = (double)CONCAT44(puStack_3c,(undefined4)uStack_38);
            fStack_98 = DAT_018ce2f8 / (float)dVar17;
            fStack_a0 = fStack_24 * fStack_98;
            fStack_9c = (float)piStack_48 * fStack_98;
            fStack_98 = fStack_44 * fStack_98;
            if (uStack_2c != 0) {
              puVar10 = puStack_3c;
              do {
                uVar4 = *puVar10;
                puVar10 = puVar10 + 1;
                uVar15 = uVar15 + 1;
                iVar8 = *param_3;
                *(ulonglong *)(uVar4 * 0x54 + 0xc + iVar8) = CONCAT44(fStack_9c,fStack_a0);
                *(float *)(uVar4 * 0x54 + 0x14 + iVar8) = fStack_98;
                piVar12 = piStack_30;
              } while (uVar15 != uStack_2c);
            }
          }
        }
      }
      piVar12 = (int *)*piVar12;
    } while (piVar12 != (int *)0x0);
    piStack_30 = (int *)0x0;
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  if (puStack_3c != (uint *)0x0) {
    uVar15 = (int)puStack_28 - (int)puStack_3c & 0xfffffffc;
    puVar10 = puStack_3c;
    if (0xfff < uVar15) {
      puVar10 = (uint *)puStack_3c[-1];
      uVar15 = uVar15 + 0x23;
      if (0x1f < (uint)((int)puStack_3c + (-4 - (int)puVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar15);
  }
  FUN_0089ad50();
  FUN_00612320();
  uStack_14 = 0xffffffff;
  FUN_016f32d1(aiStack_94,0xc,2,FUN_0056d320);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 24270 ; VA 0x00b53190 ; FUN_00b53190 */

void __thiscall FUN_00b53190(int param_1,float *param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  pfVar1 = (float *)FUN_00b08320();
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
    fVar2 = *(float *)(param_1 + 0x114);
  }
  fVar3 = DAT_018c45c4;
  if (fVar2 <= DAT_018c45c4) {
    fVar3 = fVar2;
  }
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x118)) {
    fVar2 = *(float *)(param_1 + 0x118);
  }
  fVar5 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
    fVar5 = *(float *)(param_1 + 0x11c);
  }
  fVar4 = DAT_018c45c4;
  if (fVar2 <= DAT_018c45c4) {
    fVar4 = fVar2;
  }
  fVar2 = DAT_018c45c4;
  if (fVar5 <= DAT_018c45c4) {
    fVar2 = fVar5;
  }
  fVar5 = pfVar1[1] / fVar4;
  if (*pfVar1 / fVar3 <= pfVar1[1] / fVar4) {
    fVar5 = *pfVar1 / fVar3;
  }
  fVar3 = pfVar1[2] / fVar2;
  if (fVar5 <= pfVar1[2] / fVar2) {
    fVar3 = fVar5;
  }
  *param_2 = fVar3;
  param_2[1] = fVar3;
  param_2[2] = fVar3;
  return;
}



/* FUNCTION 24271 ; VA 0x00b53220 ; FUN_00b53220 */

undefined4 * FUN_00b53220(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b50b90(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24272 ; VA 0x00b53290 ; FUN_00b53290 */

undefined4 * FUN_00b53290(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b50db0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24273 ; VA 0x00b53300 ; FUN_00b53300 */

undefined4 * FUN_00b53300(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b50e80(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24274 ; VA 0x00b53370 ; FUN_00b53370 */

undefined4 FUN_00b53370(int param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int *piStack_d8;
  int *piStack_d4;
  int *piStack_c8;
  uint *puStack_c4;
  int *piStack_b8;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  uint *puStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3f8c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if ((DAT_01d6c7ac == '\0') || (param_1 == 0)) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  param_1 = (*(int *)(iVar1 + 0x44) - *(int *)(iVar1 + 0x40) >> 2) + -1;
  uStack_8 = 0;
  FUN_005af750(&param_1,4,0);
  iVar4 = 0;
  if (0 < param_1) {
    do {
      FUN_005af750(*(int *)(iVar1 + 0x40) + iVar4 * 4 + 4,4,0);
      iVar4 = iVar4 + 1;
    } while (iVar4 < param_1);
  }
  puStack_34 = &uStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_14 = 2;
  if (((uStack_a8 & 2) == 0) && (uVar2 = *puStack_c4, uVar2 != 0)) {
    if (uVar2 < uStack_ac) {
      uVar2 = uStack_ac;
    }
    iVar1 = *piStack_d4;
    iVar4 = uVar2 - iVar1;
  }
  else {
    if (((uStack_a8 & 4) != 0) || (*piStack_c8 == 0)) goto LAB_00b5348f;
    iVar1 = *piStack_d8;
    iVar4 = (*piStack_c8 - iVar1) + *piStack_b8;
  }
  FUN_005542c0(iVar1,iVar4);
LAB_00b5348f:
  uStack_4c = uStack_30;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_48 = uStack_2c;
  uStack_44 = uStack_28;
  uStack_40 = uStack_24;
  uStack_3c = uStack_20;
  uStack_38 = uStack_1c;
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_8 = 2;
  FUN_00b4f680(&uStack_4c);
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    uVar2 = uStack_4c;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(uStack_4c - 4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (uStack_4c - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 24275 ; VA 0x00b53540 ; FUN_00b53540 */

undefined4 FUN_00b53540(int param_1,int param_2)

{
  char cVar1;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined uStack_24;
  undefined4 uStack_20;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3fb0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb0;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00cfa600();
    if (cVar1 != '\0') {
      uStack_44 = 0;
      uStack_40 = 0;
      iStack_3c = 0;
      uStack_38 = 0;
      uStack_34 = 0x10;
      uStack_30 = 0;
      uStack_2c = 0;
      iStack_28 = 0;
      uStack_24 = 0;
      uStack_20 = 0x10;
      uStack_8._0_1_ = 2;
      uStack_8._1_3_ = 0;
      if (param_2 != 2) {
        FUN_00b53700(param_1,&uStack_44,&uStack_30);
      }
      FUN_00b4dd00(param_2,&uStack_44,&uStack_30);
      uStack_8._0_1_ = 3;
      uStack_2c = 0;
      if (iStack_28 != 0) {
        FUN_01674ee0(uStack_30);
        iStack_28 = 0;
        uStack_30 = 0;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_40 = 0;
      if (iStack_3c != 0) {
        FUN_01674ee0(uStack_44);
      }
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24276 ; VA 0x00b5364f ; Catch@00b5364f */

undefined4 Catch_00b5364f(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  piVar2 = *(int **)(*(int *)(unaff_EBP + -0x14) + 0x28);
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  FUN_0086f2f0(3,"Generating Physics Data for %s Failed: %s",piVar2,uVar1);
  return 0xb5367c;
}



/* FUNCTION 24277 ; VA 0x00b536a0 ; FUN_00b536a0 */

void __fastcall FUN_00b536a0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = (**(code **)(param_1 + 8))();
  uVar2 = (**(code **)(param_1 + 8))();
  FUN_009cbaa0(uVar2,uVar1);
  return;
}



/* FUNCTION 24278 ; VA 0x00b53700 ; FUN_00b53700 */

void FUN_00b53700(int param_1,int *param_2,int *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  
  iVar4 = (*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0x10)) / 0x54;
  uVar6 = iVar4 * 3;
  if ((((uint)param_2[2] < uVar6) && (iVar4 = iVar4 * 0xc, iVar4 != 0)) &&
     (iVar4 = FUN_01674fa0(iVar4,param_2[4]), iVar4 != 0)) {
    FUN_0099eb50(iVar4,*param_2,param_2[1]);
    if (param_2[2] != 0) {
      FUN_01674ee0(*param_2);
    }
    *param_2 = iVar4;
    param_2[2] = uVar6;
  }
  puVar8 = *(undefined4 **)(param_1 + 0x14);
  puVar5 = *(undefined4 **)(param_1 + 0x10);
  if (puVar5 != puVar8) {
    uVar6 = param_2[1];
    do {
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      uVar3 = puVar5[2];
      uVar9 = param_2[2];
      if (uVar9 == uVar6) {
        uVar6 = 2;
        if (uVar9 != 0) {
          uVar6 = uVar9 * 2;
        }
        for (; uVar6 < uVar9 + 1; uVar6 = uVar6 * 2) {
        }
        if (((uVar9 < uVar6) && (uVar6 * 4 != 0)) &&
           (iVar4 = FUN_01674fa0(uVar6 * 4,param_2[4]), iVar4 != 0)) {
          FUN_0099eb50(iVar4,*param_2,param_2[1]);
          if (param_2[2] != 0) {
            FUN_01674ee0(*param_2);
          }
          *param_2 = iVar4;
          param_2[2] = uVar6;
        }
      }
      *(undefined4 *)(*param_2 + param_2[1] * 4) = uVar1;
      param_2[1] = param_2[1] + 1;
      uVar6 = param_2[2];
      if (uVar6 == param_2[1]) {
        uVar9 = 2;
        if (uVar6 != 0) {
          uVar9 = uVar6 * 2;
        }
        for (; uVar9 < uVar6 + 1; uVar9 = uVar9 * 2) {
        }
        if (((uVar6 < uVar9) && (uVar9 * 4 != 0)) &&
           (iVar4 = FUN_01674fa0(uVar9 * 4,param_2[4]), iVar4 != 0)) {
          FUN_0099eb50(iVar4,*param_2,param_2[1]);
          if (param_2[2] != 0) {
            FUN_01674ee0(*param_2);
          }
          *param_2 = iVar4;
          param_2[2] = uVar9;
        }
      }
      *(undefined4 *)(*param_2 + param_2[1] * 4) = uVar2;
      param_2[1] = param_2[1] + 1;
      uVar6 = param_2[2];
      if (uVar6 == param_2[1]) {
        uVar9 = 2;
        if (uVar6 != 0) {
          uVar9 = uVar6 * 2;
        }
        for (; uVar9 < uVar6 + 1; uVar9 = uVar9 * 2) {
        }
        if (((uVar6 < uVar9) && (uVar9 * 4 != 0)) &&
           (iVar4 = FUN_01674fa0(uVar9 * 4,param_2[4]), iVar4 != 0)) {
          FUN_0099eb50(iVar4,*param_2,param_2[1]);
          if (param_2[2] != 0) {
            FUN_01674ee0(*param_2);
          }
          *param_2 = iVar4;
          param_2[2] = uVar9;
        }
      }
      *(undefined4 *)(*param_2 + param_2[1] * 4) = uVar3;
      param_2[1] = param_2[1] + 1;
      puVar5 = puVar5 + 0x15;
      uVar6 = param_2[1];
    } while (puVar5 != puVar8);
  }
  FUN_009c14b0(*(int *)(param_1 + 0x20) - *(int *)(param_1 + 0x1c) >> 2);
  puVar8 = *(undefined4 **)(param_1 + 0x1c);
  uVar9 = *(int *)(param_1 + 0x20) - (int)puVar8 >> 2;
  iVar4 = param_3[1];
  uVar6 = uVar9 + iVar4;
  if ((uint)param_3[2] < uVar6) {
    uVar7 = 2;
    if (param_3[2] != 0) {
      uVar7 = param_3[2] * 2;
    }
    for (; uVar7 < uVar6; uVar7 = uVar7 * 2) {
    }
    FUN_009c14b0(uVar7);
  }
  uVar6 = *param_3 + iVar4 * 4;
  if (uVar6 < (uint)(*param_3 + param_3[1] * 4)) {
    uVar7 = (int)((param_3[1] * 4 - uVar6) + *param_3) >> 2;
    if (*(char *)(param_3 + 3) == '\0') {
      if (uVar7 < 0x10) {
        if (uVar7 != 0) {
          puVar5 = (undefined4 *)(uVar6 + (uVar7 - 1) * 4);
          puVar10 = (undefined4 *)(uVar6 + ((uVar9 - 1) + uVar7) * 4);
          do {
            uVar1 = *puVar5;
            puVar5 = puVar5 + -1;
            *puVar10 = uVar1;
            puVar10 = puVar10 + -1;
            uVar7 = uVar7 - 1;
          } while (uVar7 != 0);
        }
        goto LAB_00b53a2c;
      }
    }
    else if (uVar7 < 0x10) {
      if (uVar7 != 0) {
        puVar5 = (undefined4 *)(uVar6 + (uVar7 - 1) * 4);
        puVar10 = (undefined4 *)(uVar6 + ((uVar9 - 1) + uVar7) * 4);
        do {
          uVar1 = *puVar5;
          puVar5 = puVar5 + -1;
          *puVar10 = uVar1;
          puVar10 = puVar10 + -1;
          uVar7 = uVar7 - 1;
        } while (uVar7 != 0);
      }
      goto LAB_00b53a2c;
    }
    FUN_0170cc70(uVar6 + uVar9 * 4,uVar6,uVar7 * 4);
  }
LAB_00b53a2c:
  uVar7 = 0;
  if (uVar9 != 0) {
    do {
      uVar1 = *puVar8;
      puVar8 = puVar8 + 1;
      *(undefined4 *)(uVar6 + uVar7 * 4) = uVar1;
      uVar7 = uVar7 + 1;
    } while (uVar7 < uVar9);
  }
  param_3[1] = param_3[1] + uVar9;
  return;
}



/* FUNCTION 24279 ; VA 0x00b53a50 ; FUN_00b53a50 */

int __fastcall FUN_00b53a50(int param_1)

{
  return param_1 + 0x180;
}



/* FUNCTION 24280 ; VA 0x00b53a60 ; FUN_00b53a60 */

int __fastcall FUN_00b53a60(int param_1)

{
  return param_1 + 0x150;
}



/* FUNCTION 24281 ; VA 0x00b53a70 ; FUN_00b53a70 */

void FUN_00b53a70(void)

{
  int iVar1;
  
  if (DAT_01eef4e4 == 0) {
    iVar1 = FUN_00b50140();
    DAT_01eef4e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24282 ; VA 0x00b53a90 ; FUN_00b53a90 */

void FUN_00b53a90(void)

{
  int iVar1;
  
  if (DAT_01eef0a4 == 0) {
    iVar1 = FUN_00b50240();
    DAT_01eef0a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24283 ; VA 0x00b53ab0 ; FUN_00b53ab0 */

void FUN_00b53ab0(void)

{
  int iVar1;
  
  if (DAT_01eef2c4 == 0) {
    iVar1 = FUN_00b50340();
    DAT_01eef2c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24284 ; VA 0x00b53ad0 ; FUN_00b53ad0 */

int * __thiscall FUN_00b53ad0(int param_1,int *param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined4 ***apppuStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3a00;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)(param_1 + 400);
  iVar6 = param_1;
  if (param_3 != 0) {
    iVar6 = param_3;
  }
  if (*piVar3 != 0) goto LAB_00b53dba;
  if (*(char *)(param_1 + 0x1a0) != '\0') {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_005c28f0(iVar6);
    FUN_005c3670(uVar2);
    uVar2 = FUN_008ccd80();
    piVar3 = (int *)FUN_009dbec0(auStack_20,param_1 + 0x1a4,uVar2,1);
    iStack_14 = piVar3[1];
    iVar6 = *piVar3;
    if (iStack_14 != 0) {
      LOCK();
      *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
      UNLOCK();
      iStack_14 = piVar3[1];
    }
    iStack_18 = iVar6;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar3 = piStack_1c + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar6 != 0) {
      iVar4 = *(int *)(iVar6 + 0x58);
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = *(int *)(iVar6 + 0x58);
      }
      *param_2 = *(int *)(iVar6 + 0x54);
      param_2[1] = iVar4;
    }
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (DAT_01d67098 == '\0') {
    ExceptionList = &pvStack_10;
    iVar6 = FUN_008f78c0(iVar6);
    if ((iVar6 != 0) && (iVar6 != -0xc)) {
      FUN_0055e000();
    }
    FUN_00d17720(apppuStack_58,param_1 + 0x168);
    ppppuVar7 = apppuStack_58;
    if (0xf < uStack_44) {
      ppppuVar7 = (undefined4 ****)apppuStack_58[0];
    }
    uStack_8 = 1;
    cVar1 = FUN_0055c360(ppppuVar7,uStack_48,&DAT_018bc9b8,0);
    if (cVar1 != '\0') {
      *param_2 = 0;
      param_2[1] = 0;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar2 = FUN_00939ef0(auStack_28,param_1);
    FUN_005587e0(uVar2);
    FUN_00550b30();
LAB_00b53d7f:
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  else {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00a33fa0();
    if (*(int *)(iVar4 + 0x10) == 0) {
      iVar6 = FUN_008f78c0(iVar6);
      if ((iVar6 != 0) && (iVar6 != -0xc)) {
        FUN_0055e000();
      }
      FUN_00d17720(apppuStack_40,param_1 + 0x168);
      ppppuVar7 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar7 = (undefined4 ****)apppuStack_40[0];
      }
      uStack_8 = 0;
      cVar1 = FUN_0055c360(ppppuVar7,uStack_30,&DAT_018bc9b8,0);
      if (cVar1 != '\0') {
        *param_2 = 0;
        param_2[1] = 0;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      uVar2 = FUN_00939ef0(auStack_20,param_1);
      FUN_005587e0(uVar2);
      FUN_00550b30();
      goto LAB_00b53d7f;
    }
    puVar5 = (undefined4 *)FUN_00cfa7a0();
    uVar2 = (**(code **)*puVar5)();
    iStack_18 = 0;
    iStack_14 = 0;
    FUN_00727ee0(uVar2,param_2);
    FUN_005587e0(&iStack_18);
    FUN_00550b30();
    FUN_00cf9ed0(iVar4);
  }
  if (*piVar3 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00b54d20();
LAB_00b53dba:
  iVar6 = *(int *)(param_1 + 0x194);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = *(int *)(param_1 + 0x194);
  }
  *param_2 = *piVar3;
  param_2[1] = iVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24285 ; VA 0x00b53e00 ; FUN_00b53e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b53e00(void)

{
  float fVar1;
  
  fVar1 = (float)DAT_01d66b94 / DAT_018ce324;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeee84) {
    FUN_016f3809(&DAT_01eeee84);
    if (DAT_01eeee84 == -1) {
      _DAT_01eeee78 = fVar1;
      _DAT_01eeee7c = fVar1;
      _DAT_01eeee80 = fVar1;
      FUN_016f37bf(&DAT_01eeee84);
    }
  }
  return &DAT_01eeee78;
}



/* FUNCTION 24286 ; VA 0x00b53e90 ; FUN_00b53e90 */

float10 __fastcall FUN_00b53e90(int *param_1)

{
  float *pfVar1;
  
  pfVar1 = (float *)(**(code **)(*param_1 + 0xb8))();
  return (float10)*pfVar1;
}



/* FUNCTION 24287 ; VA 0x00b53ea0 ; FUN_00b53ea0 */

float10 __fastcall FUN_00b53ea0(int *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0xb8))();
  return (float10)*(float *)(iVar1 + 4);
}



/* FUNCTION 24288 ; VA 0x00b53eb0 ; FUN_00b53eb0 */

int * __thiscall FUN_00b53eb0(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ***pppuVar5;
  undefined4 **appuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 **appuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3fd0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1a0) != '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    return param_2;
  }
  if (*(int *)(param_1 + 400) != 0) goto LAB_00b540f3;
  if (DAT_01d67098 == '\0') {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_008f7870(param_1);
    if ((iVar2 == 0) || (iVar2 == -0xc)) goto LAB_00b5412b;
    iVar2 = FUN_0055e000();
    if (iVar2 == 0) goto LAB_00b5412b;
    FUN_00d17720(appuStack_50,param_1 + 0x168);
    pppuVar5 = appuStack_50;
    if (0xf < uStack_3c) {
      pppuVar5 = (undefined4 ***)appuStack_50[0];
    }
    uStack_8 = 1;
    cVar1 = FUN_0055c360(pppuVar5,uStack_40,&DAT_018bc9b8,0);
    if (cVar1 != '\0') {
      *param_2 = 0;
      param_2[1] = 0;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    uVar4 = FUN_00939ef0(auStack_20,param_1);
    FUN_005587e0(uVar4);
    FUN_00550b30();
LAB_00b540db:
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00a33fa0();
    if (*(int *)(iVar2 + 0x10) == 0) {
      iVar2 = FUN_008f7870(param_1);
      if ((iVar2 == 0) || (iVar2 == -0xc)) goto LAB_00b5412b;
      iVar2 = FUN_0055e000();
      if (iVar2 == 0) goto LAB_00b5412b;
      FUN_00d17720(appuStack_38,param_1 + 0x168);
      pppuVar5 = appuStack_38;
      if (0xf < uStack_24) {
        pppuVar5 = (undefined4 ***)appuStack_38[0];
      }
      uStack_8 = 0;
      cVar1 = FUN_0055c360(pppuVar5,uStack_28,&DAT_018bc9b8,0);
      if (cVar1 != '\0') {
        *param_2 = 0;
        param_2[1] = 0;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      uVar4 = FUN_00939ef0(&uStack_18,param_1);
      FUN_005587e0(uVar4);
      FUN_00550b30();
      goto LAB_00b540db;
    }
    puVar3 = (undefined4 *)FUN_00cfa7a0();
    uVar4 = (**(code **)*puVar3)();
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_00727ee0(uVar4,param_2);
    FUN_005587e0(&uStack_18);
    FUN_00550b30();
    FUN_00cf9ed0(iVar2);
  }
  if (*(int *)(param_1 + 400) == 0) {
LAB_00b5412b:
    *param_2 = 0;
    param_2[1] = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00b54d20();
LAB_00b540f3:
  iVar2 = *(int *)(param_1 + 0x194);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = *(int *)(param_1 + 0x194);
  }
  *param_2 = *(int *)(param_1 + 400);
  param_2[1] = iVar2;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24289 ; VA 0x00b54150 ; FUN_00b54150 */

void __thiscall FUN_00b54150(int param_1,float *param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined auStack_10 [12];
  
  pfVar1 = (float *)FUN_00b082f0(auStack_10);
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
    fVar2 = *(float *)(param_1 + 0x114);
  }
  fVar3 = DAT_018c45c4;
  if (fVar2 <= DAT_018c45c4) {
    fVar3 = fVar2;
  }
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x118)) {
    fVar2 = *(float *)(param_1 + 0x118);
  }
  fVar5 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
    fVar5 = *(float *)(param_1 + 0x11c);
  }
  fVar4 = DAT_018c45c4;
  if (fVar2 <= DAT_018c45c4) {
    fVar4 = fVar2;
  }
  fVar2 = DAT_018c45c4;
  if (fVar5 <= DAT_018c45c4) {
    fVar2 = fVar5;
  }
  fVar5 = pfVar1[1] / fVar4;
  if (*pfVar1 / fVar3 <= pfVar1[1] / fVar4) {
    fVar5 = *pfVar1 / fVar3;
  }
  fVar3 = pfVar1[2] / fVar2;
  if (fVar5 <= pfVar1[2] / fVar2) {
    fVar3 = fVar5;
  }
  *param_2 = fVar3;
  param_2[1] = fVar3;
  param_2[2] = fVar3;
  return;
}



/* FUNCTION 24290 ; VA 0x00b541e0 ; FUN_00b541e0 */

float10 __fastcall FUN_00b541e0(int param_1)

{
  return (float10)*(byte *)(param_1 + 0x18c);
}



/* FUNCTION 24291 ; VA 0x00b54230 ; FUN_00b54230 */

void __thiscall FUN_00b54230(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b0f630();
  *param_3 = uVar3;
  iVar4 = FUN_00b0f950();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 24292 ; VA 0x00b54290 ; FUN_00b54290 */

void __thiscall FUN_00b54290(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b0f830();
  *param_3 = uVar3;
  iVar4 = FUN_00b0faa0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 24293 ; VA 0x00b542f0 ; FUN_00b542f0 */

undefined4 __thiscall FUN_00b542f0(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (param_2 == &DAT_01eee910) {
    cVar1 = FUN_00973950(param_1,1);
    if ((cVar1 != '\0') && (cVar1 = FUN_00983210(param_1), cVar1 == '\0')) {
      return 1;
    }
    return 0;
  }
  if ((DAT_01d67090 == '\0') && (param_2 == &DAT_01eeee40)) {
    return 1;
  }
  uVar2 = FUN_00b09610(param_2);
  return uVar2;
}



/* FUNCTION 24294 ; VA 0x00b54350 ; FUN_00b54350 */

uint FUN_00b54350(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50140();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24295 ; VA 0x00b54370 ; FUN_00b54370 */

uint FUN_00b54370(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50240();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24296 ; VA 0x00b54390 ; FUN_00b54390 */

uint FUN_00b54390(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50340();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24297 ; VA 0x00b543b0 ; FUN_00b543b0 */

uint FUN_00b543b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50140();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24298 ; VA 0x00b543d0 ; FUN_00b543d0 */

uint FUN_00b543d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50240();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24299 ; VA 0x00b543f0 ; FUN_00b543f0 */

uint FUN_00b543f0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b50340();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24300 ; VA 0x00b54410 ; FUN_00b54410 */

int * FUN_00b54410(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b544f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b54466. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1de5f34);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_RBX::PartOperation>),class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::PartOperation>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 24301 ; VA 0x00b54510 ; FUN_00b54510 */

void __thiscall FUN_00b54510(int param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined auStack_58 [24];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4050;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1a0) == '\0') {
    if (param_4 == '\0') {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_00a33fa0();
      if (*(int *)(iVar3 + 0x10) != 0) {
        FUN_0054ef60(iVar3);
        uStack_40 = uStack_28;
        uStack_28 = uStack_28 & 0xffffff00;
        uStack_3c = uStack_24;
        uStack_38 = uStack_20;
        uStack_34 = uStack_1c;
        uStack_18 = 0;
        uStack_14 = 0xf;
        uStack_8 = 10;
        FUN_00b550f0(&uStack_40);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        FUN_0093b080(param_1,1);
        uVar2 = FUN_00a33c70();
        uStack_8 = 0xb;
        FUN_00b55090(uVar2);
        uStack_8 = 0xffffffff;
        FUN_0056cd30();
      }
      iVar3 = FUN_00a33fa0();
      if (*(int *)(iVar3 + 0x10) == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0054ef60(iVar3);
      uStack_40 = uStack_28;
      uStack_28 = uStack_28 & 0xffffff00;
      uStack_3c = uStack_24;
      uStack_38 = uStack_20;
      uStack_34 = uStack_1c;
      uStack_30 = CONCAT44(uStack_14,uStack_18);
      uStack_18 = 0;
      uStack_14 = 0xf;
      uStack_8 = 0xc;
      FUN_00b554b0(&uStack_40);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      FUN_0093aac0(param_1,1);
      uVar2 = FUN_00a33c70();
      uStack_8 = 0xd;
      FUN_00b55450(uVar2);
    }
    else {
      iVar3 = param_1 + 0x150;
      ExceptionList = &pvStack_10;
      cVar1 = FUN_00d173f0(iVar3);
      if (cVar1 != '\0') {
        FUN_00d178f0(iVar3);
        cVar1 = FUN_00d173f0(iVar3);
        if (cVar1 == '\0') {
          FUN_0054ef60(iVar3);
          uStack_8 = 2;
          uStack_18 = 0;
          uStack_14 = 0xf;
          uStack_28 = uStack_28 & 0xffffff00;
          FUN_005542c0(&DAT_018bc9b8,0);
          uStack_40 = uStack_28;
          uStack_3c = uStack_24;
          uStack_38 = uStack_20;
          uStack_34 = uStack_1c;
          uStack_30 = CONCAT44(uStack_14,uStack_18);
          uStack_8._0_1_ = 3;
          FUN_00b550f0(&uStack_40);
          uStack_8._0_1_ = 2;
          FUN_005507b0();
          uVar2 = FUN_00a33be0(auStack_58);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_00b55090(uVar2);
          FUN_0056cd30();
          uStack_8 = 0xffffffff;
          FUN_005507b0();
        }
        else {
          uStack_18 = 0;
          uStack_14 = 0xf;
          uStack_28 = uStack_28 & 0xffffff00;
          FUN_005542c0(&DAT_018bc9b8,0);
          uStack_40 = uStack_28;
          uStack_3c = uStack_24;
          uStack_38 = uStack_20;
          uStack_34 = uStack_1c;
          uStack_30 = CONCAT44(uStack_14,uStack_18);
          uStack_8 = 0;
          FUN_00b550f0(&uStack_40);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          uVar2 = FUN_00a33c70();
          uStack_8 = 1;
          FUN_00b55090(uVar2);
          uStack_8 = 0xffffffff;
          FUN_0056cd30();
        }
      }
      param_1 = param_1 + 0x168;
      cVar1 = FUN_00d173f0(param_1);
      if (cVar1 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00d178f0(param_1);
      cVar1 = FUN_00d173f0(param_1);
      if (cVar1 == '\0') {
        FUN_0054ef60(param_1);
        uStack_8 = 7;
        uStack_18 = 0;
        uStack_14 = 0xf;
        uStack_28 = uStack_28 & 0xffffff00;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_40 = uStack_28;
        uStack_3c = uStack_24;
        uStack_38 = uStack_20;
        uStack_34 = uStack_1c;
        uStack_30 = CONCAT44(uStack_14,uStack_18);
        uStack_8._0_1_ = 8;
        FUN_00b554b0(&uStack_40);
        uStack_8._0_1_ = 7;
        FUN_005507b0();
        uVar2 = FUN_00a33be0(auStack_58);
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        FUN_00b55450(uVar2);
        FUN_0056cd30();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      uStack_28 = uStack_28 & 0xffffff00;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_40 = uStack_28;
      uStack_3c = uStack_24;
      uStack_38 = uStack_20;
      uStack_34 = uStack_1c;
      uStack_30 = CONCAT44(uStack_14,uStack_18);
      uStack_8 = 5;
      FUN_00b554b0(&uStack_40);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      uVar2 = FUN_00a33c70();
      uStack_8 = 6;
      FUN_00b55450(uVar2);
    }
    FUN_0056cd30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24302 ; VA 0x00b548f0 ; FUN_00b548f0 */

void __thiscall FUN_00b548f0(int param_1,int param_2,int param_3)

{
  char cVar1;
  undefined4 *puVar2;
  
  FUN_00b0a250(param_2,param_3);
  if (param_2 == 0) {
    if (param_3 != 0) {
      FUN_006714d0(param_1);
      FUN_006721e0(param_1);
      FUN_0093aac0(param_1,1);
      FUN_0093b080(param_1,1);
    }
  }
  else if (param_3 == 0) {
    FUN_006714d0(param_1);
    FUN_006721e0(param_1);
    FUN_0093a860(param_1);
    FUN_0093afe0(param_1);
  }
  if ((DAT_01d67088 != '\0') && (DAT_01d67061 != '\0')) {
    cVar1 = FUN_00983210(param_1);
    if (cVar1 == '\0') {
      if (*(int *)(param_1 + 0x188) != 0) {
        return;
      }
      puVar2 = &DAT_01d7a8e8;
      if (0xf < DAT_01d7a8fc) {
        puVar2 = DAT_01d7a8e8;
      }
      FUN_0087c450(&DAT_018c5f98,"CSGObjectAutomaticRenderFidelity",puVar2,0,0,0);
    }
    DAT_01d67061 = '\0';
  }
  return;
}



/* FUNCTION 24303 ; VA 0x00b549c0 ; FUN_00b549c0 */

undefined4 * __thiscall FUN_00b549c0(int param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined auStack_50 [16];
  int iStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3fd0;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1;
  if (DAT_01d67098 == '\0') {
    if (*(char *)(param_1 + 0x1a0) == '\0') {
      iVar5 = param_1;
      if (param_3 != 0) {
        iVar5 = param_3;
      }
      ExceptionList = &pvStack_10;
      FUN_00b51060(iVar5);
      iStack_18 = FUN_006721e0(iVar5);
      param_1 = param_1 + 0x150;
      cVar2 = FUN_00d173f0(param_1);
      if (cVar2 != '\0') {
        FUN_00d17720(auStack_50,param_1);
        uStack_8 = 1;
        if (iStack_40 != 0) {
          FUN_0054ef60(auStack_50);
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00d17720(param_2,param_1);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    else {
      iVar5 = param_1;
      if (param_3 != 0) {
        iVar5 = param_3;
      }
      ExceptionList = &pvStack_10;
      uVar3 = FUN_005c28f0(iVar5);
      FUN_005c3670(uVar3);
      uVar3 = FUN_008ccd80();
      piVar4 = (int *)FUN_009dbec0(auStack_20,param_1 + 0x1a4,uVar3,1);
      piVar6 = (int *)piVar4[1];
      iStack_18 = *piVar4;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)piVar4[1];
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar5 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      if (iStack_18 == 0) {
        param_1 = iStack_14 + 0x150;
      }
      else {
        param_1 = iStack_18 + 0x74;
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar4 = piVar6 + 2;
          iVar5 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
LAB_00b54c76:
    FUN_0054ef60(param_1);
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (*(char *)(param_1 + 0x1a0) == '\0') {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00a33fa0();
    if (*(int *)(iVar5 + 0x10) == 0) {
      iVar5 = param_1;
      if (param_3 != 0) {
        iVar5 = param_3;
      }
      FUN_00b51060(iVar5);
      iStack_18 = FUN_006721e0(iVar5);
      param_1 = param_1 + 0x150;
      cVar2 = FUN_00d173f0(param_1);
      if (cVar2 != '\0') {
        FUN_00d17720(&uStack_38,param_1);
        uStack_8 = 0;
        if (iStack_28 != 0) {
          FUN_0054ef60(&uStack_38);
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00d17720(param_2,param_1);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      goto LAB_00b54c76;
    }
  }
  else {
    iVar5 = param_1;
    if (param_3 != 0) {
      iVar5 = param_3;
    }
    ExceptionList = &pvStack_10;
    uVar3 = FUN_005c28f0(iVar5);
    FUN_005c3670(uVar3);
    uVar3 = FUN_008ccd80();
    piVar4 = (int *)FUN_009dbec0(auStack_20,param_1 + 0x1a4,uVar3,1);
    piVar6 = (int *)piVar4[1];
    iStack_18 = *piVar4;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)piVar4[1];
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar5 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (iStack_18 == 0) {
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar4 = piVar6 + 2;
          iVar5 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      iVar1 = iStack_14;
      iVar5 = FUN_00a33fa0();
      if (*(int *)(iVar5 + 0x10) == 0) {
        iVar5 = iVar1 + 0x150;
      }
    }
    else {
      iVar5 = iStack_18 + 0x74;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar1 = piVar6[1] + -1;
        piVar6[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar4 = piVar6 + 2;
          iVar1 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
  }
  FUN_0054ef60(iVar5);
  param_2[4] = 0;
  param_2[5] = 0;
  *param_2 = uStack_38;
  param_2[1] = uStack_34;
  param_2[2] = uStack_30;
  param_2[3] = uStack_2c;
  *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_24,iStack_28);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24304 ; VA 0x00b54d20 ; FUN_00b54d20 */

void __fastcall FUN_00b54d20(undefined4 param_1)

{
  int iVar1;
  undefined auStack_54 [4];
  undefined4 uStack_50;
  undefined auStack_4c [12];
  undefined4 uStack_40;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uStack_20 = 0xb54d31;
  uStack_1c = param_1;
  iVar1 = FUN_008f7870();
  if (iVar1 != 0) {
    uStack_1c = 1;
    uStack_40 = 0;
    FUN_0060dcd0(auStack_54,param_1);
    FUN_005919d0(auStack_4c,FUN_00b54d80);
    uStack_50 = 0xb54d6d;
    FUN_00b50050();
    uStack_40 = 0xb54d75;
    FUN_0090ca30();
  }
  return;
}



/* FUNCTION 24305 ; VA 0x00b54d80 ; FUN_00b54d80 */

int FUN_00b54d80(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4068;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008a4940(&DAT_01eeee08);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 24306 ; VA 0x00b54df0 ; FUN_00b54df0 */

void __fastcall FUN_00b54df0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4088;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x108) == 0) {
    if (param_1 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(param_1 + 0xa8);
    }
    ExceptionList = &pvStack_10;
    iVar4 = (**(code **)(**(int **)(iVar4 + 0x1ac) + 8))();
    if (iVar4 != 3) {
      if (param_1 != 0) {
        FUN_00c17120(3);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00c17120(3);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_00d173f0(param_1 + 0xf8);
    if (cVar3 == '\0') {
      FUN_00b4e260(0);
      ExceptionList = pvStack_10;
      return;
    }
    iVar4 = FUN_008f7870(param_1);
    if ((iVar4 != 0) && (iVar4 != -0xc)) {
      iVar4 = FUN_0055e000();
      if (iVar4 != 0) {
        puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_1);
        uStack_8 = 0;
        uVar1 = *puVar5;
        uVar2 = puVar5[1];
        *puVar5 = 0;
        puVar5[1] = 0;
        FUN_008b80e0(uVar1,uVar2);
        FUN_00550b30();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24307 ; VA 0x00b54f30 ; FUN_00b54f30 */

void __thiscall FUN_00b54f30(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  
  if ((((uint)param_1[2] < param_2) && (param_2 << 4 != 0)) &&
     (puVar6 = (undefined4 *)FUN_01674fa0(param_2 << 4,param_1[4]), puVar6 != (undefined4 *)0x0)) {
    iVar2 = *param_1;
    iVar8 = param_1[1];
    if (*(char *)(param_1 + 3) == '\0') {
      if (iVar8 != 0) {
        puVar7 = puVar6;
        do {
          if (puVar7 != (undefined4 *)0x0) {
            puVar1 = (undefined4 *)((iVar2 - (int)puVar6) + (int)puVar7);
            uVar3 = puVar1[1];
            uVar4 = puVar1[2];
            uVar5 = puVar1[3];
            *puVar7 = *puVar1;
            puVar7[1] = uVar3;
            puVar7[2] = uVar4;
            puVar7[3] = uVar5;
          }
          puVar7 = puVar7 + 4;
          iVar8 = iVar8 + -1;
        } while (iVar8 != 0);
      }
    }
    else {
      FUN_0170c6f0(puVar6,iVar2,iVar8 << 4);
    }
    if (param_1[2] != 0) {
      FUN_01674ee0(*param_1);
    }
    *param_1 = (int)puVar6;
    param_1[2] = param_2;
  }
  return;
}



/* FUNCTION 24308 ; VA 0x00b54fb0 ; FUN_00b54fb0 */

void __thiscall FUN_00b54fb0(int param_1,undefined4 *param_2)

{
  undefined uVar1;
  char cVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad668;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d67080 == '\0') {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_008d0870(&param_2);
    if (cVar2 != '\0') {
      *(undefined *)(param_1 + 0x1a0) = 1;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_008d0870(&param_2);
    *(undefined *)(param_1 + 0x1a0) = uVar1;
  }
  cVar2 = FUN_00684460(&param_2,(undefined4 *)(param_1 + 0x1a4));
  if ((undefined4 **)(param_1 + 0x1a4) != &param_2) {
    puVar3 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar3 = param_2;
    }
    FUN_005542c0(puVar3,in_stack_00000014);
  }
  if (cVar2 != '\0') {
    FUN_008a4940(&DAT_01eeed90);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar4) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24309 ; VA 0x00b55090 ; FUN_00b55090 */

void __thiscall FUN_00b55090(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  
  cVar3 = FUN_005e0cd0(param_2);
  if (cVar3 != '\0') {
    iVar2 = *param_2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + 0x180) = iVar2;
    FUN_0056cd30();
    FUN_008a4940(&DAT_01eeec34);
  }
  return;
}



/* FUNCTION 24310 ; VA 0x00b550f0 ; FUN_00b550f0 */

void __thiscall FUN_00b550f0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x150);
  iVar2 = param_2[4];
  piVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar4 = (int *)*param_2;
  }
  piVar5 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x164)) {
    piVar5 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar5,*(undefined4 *)(param_1 + 0x160),piVar4,iVar2);
  if (cVar3 == '\0') {
    if (piVar1 != param_2) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,iVar2);
    }
    FUN_008a4940(&DAT_01eeebc4);
  }
  return;
}



/* FUNCTION 24311 ; VA 0x00b55160 ; FUN_00b55160 */

void __thiscall FUN_00b55160(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x19c) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 24312 ; VA 0x00b55180 ; FUN_00b55180 */

void __thiscall FUN_00b55180(int *param_1,float *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  float10 fVar4;
  double dVar5;
  undefined auStack_24 [4];
  double dStack_20;
  undefined auStack_18 [4];
  double dStack_14;
  double dStack_c;
  
  if ((((NAN((float)param_1[0x45]) || NAN(*param_2)) == ((float)param_1[0x45] == *param_2)) ||
      ((NAN((float)param_1[0x46]) || NAN(param_2[1])) == ((float)param_1[0x46] == param_2[1]))) ||
     ((NAN((float)param_1[0x47]) || NAN(param_2[2])) == ((float)param_1[0x47] == param_2[2]))) {
    *(undefined8 *)(param_1 + 0x45) = *(undefined8 *)param_2;
    param_1[0x47] = (int)param_2[2];
    FUN_008a4940(&DAT_01eeecdc);
    cVar1 = FUN_00b4e040();
    if ((cVar1 != '\0') &&
       (dVar5 = (double)((float)param_1[0x45] * (float)param_1[0x45] +
                         (float)param_1[0x46] * (float)param_1[0x46] +
                        (float)param_1[0x47] * (float)param_1[0x47]), NAN(dVar5) == (dVar5 == 0.0)))
    {
      dStack_c = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84(dVar5,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      dStack_20 = (double)CONCAT44((uint)((ulonglong)(dVar5 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar5 - 0.0,0) & (uint)DAT_018c0da0);
      fVar4 = (float10)FUN_01160810();
      dStack_14 = (double)fVar4;
      dVar5 = DAT_018f76b0;
      if ((NAN(dStack_c) || NAN(dStack_14)) == (dStack_c == dStack_14)) {
        dVar5 = dStack_c * DAT_018f76b0;
      }
      if (dVar5 < dStack_20) {
        uVar2 = (**(code **)(*param_1 + 0x15c))(auStack_24);
        uVar3 = (**(code **)(*param_1 + 0x160))(auStack_18);
        FUN_00b4fdd0(uVar3,uVar2);
      }
    }
  }
  return;
}



/* FUNCTION 24313 ; VA 0x00b552d0 ; FUN_00b552d0 */

void __thiscall FUN_00b552d0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f40b0;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00727ee0(param_2,param_2);
  *(undefined4 *)(param_1 + 400) = uStack_20;
  piVar4 = *(int **)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x194) = uStack_1c;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    param_1 = iStack_14;
    if (iVar2 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      param_1 = iStack_14;
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 4))();
        param_1 = iStack_14;
      }
    }
  }
  FUN_00cfa850(&uStack_38);
  uStack_50 = uStack_38;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_4c = uStack_34;
  uStack_48 = uStack_30;
  uStack_44 = uStack_2c;
  uStack_3c = uStack_24;
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_8 = 0;
  FUN_00b554b0(&uStack_50);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    uVar5 = uStack_50;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_50 - 4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (uStack_50 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if (DAT_01d67098 != '\0') {
    piVar4 = (int *)FUN_00a33c70();
    uStack_8 = 1;
    cVar3 = FUN_005e0cd0(piVar4);
    if (cVar3 != '\0') {
      iVar2 = *piVar4;
      LOCK();
      piVar4 = (int *)(iVar2 + 0x28);
      *piVar4 = *piVar4 + 1;
      UNLOCK();
      *(int *)(param_1 + 0x184) = iVar2;
      FUN_0056cd30();
      FUN_008a4940(&DAT_01eeec6c);
    }
    FUN_0056cd30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24314 ; VA 0x00b55450 ; FUN_00b55450 */

void __thiscall FUN_00b55450(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  
  cVar3 = FUN_005e0cd0(param_2);
  if (cVar3 != '\0') {
    iVar2 = *param_2;
    LOCK();
    piVar1 = (int *)(iVar2 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + 0x184) = iVar2;
    FUN_0056cd30();
    FUN_008a4940(&DAT_01eeec6c);
  }
  return;
}



/* FUNCTION 24315 ; VA 0x00b554b0 ; FUN_00b554b0 */

void __thiscall FUN_00b554b0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  
  piVar1 = (int *)(param_1 + 0x168);
  iVar2 = param_2[4];
  piVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar4 = (int *)*param_2;
  }
  piVar5 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x17c)) {
    piVar5 = (int *)*piVar1;
  }
  cVar3 = FUN_0055c360(piVar5,*(undefined4 *)(param_1 + 0x178),piVar4,iVar2);
  if (cVar3 == '\0') {
    if (piVar1 != param_2) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,iVar2);
    }
    FUN_008a4940(&DAT_01eeebfc);
  }
  return;
}



/* FUNCTION 24316 ; VA 0x00b55520 ; FUN_00b55520 */

void __thiscall FUN_00b55520(int param_1,float *param_2)

{
  char cVar1;
  float *pfVar2;
  undefined4 uVar3;
  float10 fVar4;
  float fVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fStack_24;
  undefined8 uStack_20;
  undefined auStack_18 [4];
  double dStack_14;
  double dStack_c;
  
  pfVar2 = (float *)FUN_00b08320();
  if ((((NAN(*param_2) || NAN(*pfVar2)) == (*param_2 == *pfVar2)) ||
      ((NAN(param_2[1]) || NAN(pfVar2[1])) == (param_2[1] == pfVar2[1]))) ||
     ((NAN(param_2[2]) || NAN(pfVar2[2])) == (param_2[2] == pfVar2[2]))) {
    cVar1 = FUN_00b4e040();
    if ((cVar1 != '\0') &&
       (dVar7 = (double)(*(float *)(param_1 + 0x114) * *(float *)(param_1 + 0x114) +
                         *(float *)(param_1 + 0x118) * *(float *)(param_1 + 0x118) +
                        *(float *)(param_1 + 0x11c) * *(float *)(param_1 + 0x11c)),
       NAN(dVar7) == (dVar7 == 0.0))) {
      dStack_c = (double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84(dVar7,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      uStack_20 = (double)CONCAT44((uint)((ulonglong)(dVar7 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar7 - 0.0,0) & (uint)DAT_018c0da0);
      fVar4 = (float10)FUN_01160810();
      dStack_14 = (double)fVar4;
      dVar7 = DAT_018f76b0;
      if ((NAN(dStack_c) || NAN(dStack_14)) == (dStack_c == dStack_14)) {
        dVar7 = dStack_c * DAT_018f76b0;
      }
      if (dVar7 < uStack_20) {
        fVar8 = DAT_018f76ac;
        if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
          fVar8 = *(float *)(param_1 + 0x114);
        }
        fVar5 = DAT_018c45c4;
        if (fVar8 <= DAT_018c45c4) {
          fVar5 = fVar8;
        }
        fVar8 = DAT_018f76ac;
        if (DAT_018f76ac <= *(float *)(param_1 + 0x118)) {
          fVar8 = *(float *)(param_1 + 0x118);
        }
        fVar9 = DAT_018f76ac;
        if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
          fVar9 = *(float *)(param_1 + 0x11c);
        }
        fVar6 = DAT_018c45c4;
        if (fVar8 <= DAT_018c45c4) {
          fVar6 = fVar8;
        }
        fVar8 = DAT_018c45c4;
        if (fVar9 <= DAT_018c45c4) {
          fVar8 = fVar9;
        }
        fVar9 = param_2[1] / fVar6;
        if (*param_2 / fVar5 <= param_2[1] / fVar6) {
          fVar9 = *param_2 / fVar5;
        }
        fStack_24 = param_2[2] / fVar8;
        if (fVar9 <= param_2[2] / fVar8) {
          fStack_24 = fVar9;
        }
        uStack_20 = (double)CONCAT44(fStack_24,fStack_24);
        uVar3 = FUN_00b51df0(auStack_18,param_2);
        FUN_00b4fdd0(uVar3,&fStack_24);
      }
    }
    FUN_00c18e20(param_2);
    FUN_008a4940(&DAT_01eed1b0);
    FUN_008a4940(&DAT_01eed1e8);
  }
  return;
}



/* FUNCTION 24317 ; VA 0x00b556d0 ; FUN_00b556d0 */

void __thiscall FUN_00b556d0(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  undefined auStack_1c [8];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4088;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar4 = FUN_00b4e040();
  if (cVar4 == '\0') {
    piVar1 = (int *)(param_1 + 0xf8);
    iVar6 = param_2[4];
    piVar5 = param_2;
    if (0xf < (uint)param_2[5]) {
      piVar5 = (int *)*param_2;
    }
    piVar8 = piVar1;
    if (0xf < *(uint *)(param_1 + 0x10c)) {
      piVar8 = (int *)*piVar1;
    }
    cVar4 = FUN_0055c360(piVar8,*(undefined4 *)(param_1 + 0x108),piVar5,iVar6);
    iVar11 = param_1;
    if (cVar4 == '\0') {
      if (piVar1 != param_2) {
        if (0xf < (uint)param_2[5]) {
          param_2 = (int *)*param_2;
        }
        FUN_005542c0(param_2,iVar6);
      }
      FUN_008a4940(&DAT_01eeeca4);
      uVar9 = *(uint *)(param_1 + 0x108);
      piVar5 = piVar1;
      if (0xf < *(uint *)(param_1 + 0x10c)) {
        piVar5 = (int *)*piVar1;
      }
      cVar4 = FUN_0055c360(piVar5,uVar9,&DAT_018bc9b8,0);
      if ((cVar4 != '\0') && (0xf < *(uint *)(param_1 + 0x10c))) {
        if (uVar9 < 0x10) {
          iVar6 = *piVar1;
          FUN_0170c6f0(piVar1,iVar6,uVar9 + 1);
          uVar9 = *(int *)(param_1 + 0x10c) + 1;
          iVar10 = iVar6;
          if (0xfff < uVar9) {
            iVar10 = *(int *)(iVar6 + -4);
            uVar9 = *(int *)(param_1 + 0x10c) + 0x24;
            if (0x1f < (iVar6 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar10,uVar9);
          *(undefined4 *)(param_1 + 0x10c) = 0xf;
        }
        else {
          uVar9 = uVar9 | 0xf;
          if (0x7fffffff < uVar9) {
            uVar9 = 0x7fffffff;
          }
          if (uVar9 < *(uint *)(param_1 + 0x10c)) {
            iVar6 = FUN_00554060(uVar9 + 1);
            FUN_0170c6f0(iVar6,*piVar1,*(int *)(param_1 + 0x108) + 1);
            FUN_00554a20(*piVar1,*(int *)(param_1 + 0x10c) + 1);
            *piVar1 = iVar6;
            *(uint *)(param_1 + 0x10c) = uVar9;
            iVar11 = iStack_14;
          }
        }
      }
    }
    if (*(int *)(param_1 + 0x108) == 0) {
      if (iVar11 == 0) {
        iVar6 = 0;
      }
      else {
        iVar6 = *(int *)(iVar11 + 0xa8);
      }
      iVar6 = (**(code **)(**(int **)(iVar6 + 0x1ac) + 8))();
      if (iVar6 != 3) {
        if (iVar11 == 0) {
          FUN_00c17120(3);
          ExceptionList = pvStack_10;
          return;
        }
        FUN_00c17120(3);
        ExceptionList = pvStack_10;
        return;
      }
    }
    else {
      cVar4 = FUN_00d173f0(piVar1);
      if (cVar4 == '\0') {
        FUN_00b4e260(0);
        ExceptionList = pvStack_10;
        return;
      }
      iVar6 = FUN_008f7870(iVar11);
      if (((iVar6 != 0) && (iVar6 != -0xc)) && (iVar6 = FUN_0055e000(), iVar6 != 0)) {
        puVar7 = (undefined4 *)FUN_0060dcd0(auStack_1c,iVar11);
        uStack_8 = 0;
        uVar2 = *puVar7;
        uVar3 = puVar7[1];
        *puVar7 = 0;
        puVar7[1] = 0;
        FUN_008b80e0(uVar2,uVar3);
        FUN_00550b30();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24318 ; VA 0x00b55940 ; FUN_00b55940 */

void __thiscall FUN_00b55940(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((param_2 != 2) && (param_2 != *(int *)(param_1 + 0x188))) {
    *(int *)(param_1 + 0x188) = param_2;
    FUN_008a4940(&DAT_01eeedc8);
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8af8,&LAB_0055d590);
      uVar3 = FUN_00560d40();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00995770();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      if ((*piVar4 != 0) && ((iVar1 = *(int *)(*piVar4 + 0x68), iVar1 == 1 || (iVar1 == 2)))) {
        FUN_0086f2f0(2,"Cannot change SolidModel RenderFidelity during Run-Time");
      }
    }
  }
  return;
}



/* FUNCTION 24319 ; VA 0x00b55a90 ; FUN_00b55a90 */

void __thiscall FUN_00b55a90(int param_1,float param_2)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  char cVar6;
  float fVar7;
  float fVar8;
  
  if (DAT_01d67090 != '\0') {
    fVar7 = DAT_01900a20;
    if ((DAT_01900a20 < param_2) || (fVar7 = param_2, fVar8 = 0.0, 0.0 <= param_2)) {
      fVar8 = fVar7;
    }
    cVar6 = (char)(int)fVar8;
    param_2 = (float)((int)fVar8 & 0xff);
    if (cVar6 != *(char *)(param_1 + 0x18c)) {
      iVar4 = FUN_008f7870(param_1);
      if (iVar4 != 0) {
        iVar4 = *(int *)(iVar4 + 0x4a0);
        cVar3 = FUN_00983210(param_1);
        if ((cVar3 == '\0') || (iVar4 != 2)) {
          bVar1 = false;
        }
        else {
          bVar1 = true;
        }
        if ((cVar3 == '\0') && (iVar4 == 3)) {
          bVar2 = true;
        }
        else {
          bVar2 = false;
        }
        if ((bVar1) || (bVar2)) {
          cVar3 = FUN_00b55cb0(param_2);
          if (cVar3 == '\0') {
            FUN_0086f2f0(2,"SolidModel SmoothingAngle compute failed.");
            puVar5 = &DAT_01d7a8e8;
            if (0xf < DAT_01d7a8fc) {
              puVar5 = DAT_01d7a8e8;
            }
            FUN_0087c450(&DAT_018c5f98,"NormalSmoothing",puVar5,0,0,0);
          }
          else {
            FUN_0087c450(&DAT_018c5f98,"NormalSmoothing","Success",0,0,0);
          }
        }
      }
      *(char *)(param_1 + 0x18c) = cVar6;
      FUN_008a4940(&DAT_01eeee40);
    }
  }
  return;
}



/* FUNCTION 24320 ; VA 0x00b55ba0 ; FUN_00b55ba0 */

void __thiscall FUN_00b55ba0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x198) != param_2) {
    *(char *)(param_1 + 0x198) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 24321 ; VA 0x00b55bd0 ; FUN_00b55bd0 */

void __thiscall FUN_00b55bd0(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined auStack_24 [24];
  
  param_2 = auStack_24;
  pcVar1 = *(code **)(param_1 + 0x18);
  FUN_0054ef60(param_3);
  (*pcVar1)();
  return;
}



/* FUNCTION 24322 ; VA 0x00b55c10 ; FUN_00b55c10 */

void __thiscall FUN_00b55c10(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b0f630();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24323 ; VA 0x00b55c60 ; FUN_00b55c60 */

void __thiscall FUN_00b55c60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b0f830();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24324 ; VA 0x00b55cb0 ; FUN_00b55cb0 */

undefined __thiscall FUN_00b55cb0(int *param_1,undefined4 param_2)

{
  float fVar1;
  float fVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  char cVar7;
  int ****ppppiVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  int ****ppppiVar14;
  float10 fVar15;
  double dVar16;
  float fVar17;
  int *piVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  int ***pppiStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  uint uStack_b4;
  uint auStack_ac [4];
  int iStack_9c;
  uint uStack_98;
  int aiStack_94 [3];
  double dStack_88;
  double dStack_80;
  int aiStack_74 [3];
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  int ***pppiStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  int iStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f4106;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  piStack_60 = param_1;
  FUN_00b53ad0(&piStack_68,0);
  uStack_14._0_1_ = 0;
  uStack_14._1_3_ = 0;
  if (piStack_68 == (int *)0x0) {
    uStack_21 = 0;
  }
  else {
    FUN_00b549c0(auStack_ac,param_1);
    uStack_14._0_1_ = 1;
    if (iStack_9c == 0) {
      uStack_21 = 0;
    }
    else {
      piVar13 = piStack_68 + 4;
      piStack_5c = piStack_68 + 7;
      uStack_4c = 0;
      uStack_48 = 0.0;
      piStack_2c = piVar13;
      FUN_00b511b0((piStack_68[5] - *piVar13) / 0x54,&uStack_4c,&uStack_21);
      uStack_14._0_1_ = 2;
      uStack_40 = 0;
      iStack_3c = 0;
      uStack_40 = FUN_00601dc0();
      uStack_14._0_1_ = 3;
      piStack_38 = (int *)0x0;
      uStack_34 = 0;
      piStack_38 = (int *)FUN_0089c660();
      uStack_14._0_1_ = 4;
      piVar18 = piVar13;
      cVar7 = FUN_00b521e0(piVar13,piStack_5c,param_2,aiStack_94,&uStack_40,&piStack_38);
      if (cVar7 == '\0') {
        uStack_21 = 0;
      }
      else {
        FUN_00b510c0(piVar13);
        piVar13 = piStack_38;
        uStack_14._0_1_ = 5;
        piStack_28 = (int *)*piStack_38;
        while (piStack_28 != piVar13) {
          puVar3 = (undefined4 *)piStack_28[4];
          fVar17 = *(float *)(aiStack_94[0] + 4 + (int)puVar3 * 0xc);
          fVar1 = *(float *)(aiStack_94[0] + (int)puVar3 * 0xc);
          fVar2 = *(float *)(aiStack_94[0] + 8 + (int)puVar3 * 0xc);
          dVar16 = (double)(fVar1 * fVar1 + fVar17 * fVar17 + fVar2 * fVar2);
          puStack_30 = puVar3;
          if (NAN(dVar16) == (dVar16 == 0.0)) {
            dStack_80 = (double)CONCAT44((uint)((ulonglong)dVar16 >> 0x20) & DAT_018c0da0._4_4_,
                                         SUB84(dVar16,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
            uStack_48 = (double)CONCAT44((uint)((ulonglong)(dVar16 - 0.0) >> 0x20) &
                                         DAT_018c0da0._4_4_,
                                         SUB84(dVar16 - 0.0,0) & (uint)DAT_018c0da0);
            fVar15 = (float10)FUN_01160810();
            dStack_88 = (double)fVar15;
            dVar16 = DAT_018f76b0;
            if ((NAN(dStack_80) || NAN(dStack_88)) == (dStack_80 == dStack_88)) {
              dVar16 = dStack_80 * DAT_018f76b0;
            }
            if (dVar16 < uStack_48) {
              uVar20 = *(undefined4 *)(aiStack_94[0] + 8 + (int)puVar3 * 0xc);
              *(undefined8 *)((int)puStack_30 * 0x54 + 0xc + aiStack_74[0]) =
                   *(undefined8 *)(aiStack_94[0] + (int)puVar3 * 0xc);
              *(undefined4 *)((int)puStack_30 * 0x54 + 0x14 + aiStack_74[0]) = uVar20;
            }
          }
          FUN_00551320();
        }
        if (iStack_3c != 0) {
          FUN_00b52b20(aiStack_94,&uStack_40,aiStack_74);
        }
        piVar5 = piStack_38;
        dVar16 = DAT_01954608;
        FUN_017279f0();
        piVar13 = (int *)*piVar5;
        puStack_30 = (undefined4 *)(float)dVar16;
        while (piVar13 != piVar5) {
          piStack_28 = (int *)(piVar13[4] * 0x54);
          fVar17 = *(float *)((int)piStack_28 + aiStack_74[0] + 0xc);
          fVar1 = *(float *)((int)piStack_28 + aiStack_74[0] + 0x10);
          fVar2 = *(float *)((int)piStack_28 + aiStack_74[0] + 0x14);
          dVar16 = (double)(fVar17 * fVar17 + fVar1 * fVar1 + fVar2 * fVar2);
          if (NAN(dVar16) == (dVar16 == 0.0)) {
            uStack_48 = (double)CONCAT44((uint)((ulonglong)dVar16 >> 0x20) & DAT_018c0da0._4_4_,
                                         SUB84(dVar16,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
            dStack_80 = (double)CONCAT44((uint)((ulonglong)(dVar16 - 0.0) >> 0x20) &
                                         DAT_018c0da0._4_4_,
                                         SUB84(dVar16 - 0.0,0) & (uint)DAT_018c0da0);
            fVar15 = (float10)FUN_01160810();
            dStack_88 = (double)fVar15;
            dVar16 = DAT_018f76b0;
            if ((NAN(uStack_48) || NAN(dStack_88)) == (uStack_48 == dStack_88)) {
              dVar16 = uStack_48 * DAT_018f76b0;
            }
            if (dVar16 < dStack_80) {
              iVar9 = *piStack_2c;
              fVar17 = *(float *)((int)piStack_28 + iVar9 + 0x10);
              fVar1 = *(float *)((int)piStack_28 + iVar9 + 0xc);
              fVar2 = *(float *)((int)piStack_28 + iVar9 + 0x14);
              dVar16 = (double)(fVar1 * fVar1 + fVar17 * fVar17 + fVar2 * fVar2);
              FUN_017267a0();
              iVar9 = *piStack_2c;
              fVar17 = DAT_018ce2f8 / (float)dVar16;
              if (*(float *)((int)piStack_28 + aiStack_74[0] + 0x10) *
                  fVar17 * *(float *)((int)piStack_28 + iVar9 + 0x10) +
                  fVar17 * *(float *)((int)piStack_28 + iVar9 + 0xc) *
                  *(float *)((int)piStack_28 + aiStack_74[0] + 0xc) +
                  *(float *)((int)piStack_28 + aiStack_74[0] + 0x14) *
                  fVar17 * *(float *)((int)piStack_28 + iVar9 + 0x14) < (float)puStack_30) {
                puStack_30 = (undefined4 *)(**(code **)(*piStack_68 + 4))();
                FUN_00cfa630(aiStack_74,piStack_5c);
                FUN_00cfa850(&pppiStack_c8);
                piVar5 = piStack_60;
                uVar11 = uStack_b4;
                uVar20 = uStack_b8;
                ppppiVar14 = (int ****)pppiStack_c8;
                pppiStack_c8 = (int ***)((uint)pppiStack_c8 & 0xffffff00);
                uStack_48 = (double)CONCAT44(uStack_b4,uStack_b8);
                pppiStack_58 = (int ***)ppppiVar14;
                uStack_54 = uStack_c4;
                uStack_50 = uStack_c0;
                uStack_4c = uStack_bc;
                uStack_b8 = 0;
                uStack_b4 = 0xf;
                uStack_14 = CONCAT31(uStack_14._1_3_,6);
                piVar13 = piStack_60 + 0x5a;
                ppppiVar8 = &pppiStack_58;
                if (0xf < uVar11) {
                  ppppiVar8 = ppppiVar14;
                }
                if (0xf < (uint)piStack_60[0x5f]) {
                  piVar13 = (int *)piStack_60[0x5a];
                }
                uVar19 = 0xb561a3;
                cVar7 = FUN_0055c360(piVar13,piStack_60[0x5e],ppppiVar8,uVar20);
                if (cVar7 == '\0') {
                  if ((int ****)(piVar5 + 0x5a) != &pppiStack_58) {
                    ppppiVar8 = &pppiStack_58;
                    if (0xf < uStack_48._4_4_) {
                      ppppiVar8 = ppppiVar14;
                    }
                    FUN_005542c0(ppppiVar8,(undefined4)uStack_48);
                    ppppiVar14 = (int ****)pppiStack_58;
                  }
                  FUN_008a4940(&DAT_01eeebfc);
                }
                uStack_14._0_1_ = 5;
                if (0xf < uStack_48._4_4_) {
                  uVar11 = uStack_48._4_4_ + 1;
                  ppppiVar8 = ppppiVar14;
                  if (0xfff < uVar11) {
                    ppppiVar8 = (int ****)ppppiVar14[-1];
                    uVar11 = uStack_48._4_4_ + 0x24;
                    if (0x1f < (uint)((int)ppppiVar14 + (-4 - (int)ppppiVar8))) {
                    /* WARNING: Subroutine does not return */
                      FUN_017167a3();
                    }
                  }
                  FUN_01674ea0(ppppiVar8,uVar11);
                }
                iVar9 = FUN_008f7870(piVar5);
                if ((iVar9 != 0) && (iVar9 != -0xc)) {
                  FUN_0055e000();
                }
                uVar20 = 0xb56234;
                FUN_0093aac0(piVar5,1);
                if (piVar5[0x58] == 0) {
                  piStack_2c = (int *)piVar5[0xd];
                  if (piStack_2c == (int *)0x0) {
                    piStack_2c = piVar5;
                  }
                  else if (piStack_2c[0xd] != 0) {
                    piStack_2c = (int *)FUN_005c8ac0();
                  }
                  if ((piStack_2c != (int *)0x0) &&
                     (iVar9 = piStack_2c[3], iVar10 = FUN_008a8c30(),
                     (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
                     (uint)*(ushort *)(iVar10 + 0x1da))) {
                    FUN_0055e310();
                  }
                  FUN_00b550f0(auStack_ac);
                  uVar20 = 0xb562ac;
                  FUN_0093b080(piVar5,1);
                }
                if (DAT_01d67098 != '\0') {
                  FUN_00a33c70();
                  uStack_14 = CONCAT31(uStack_14._1_3_,7);
                  cVar7 = FUN_005e0cd0(&piStack_2c);
                  if (cVar7 != '\0') {
                    LOCK();
                    piStack_2c[10] = piStack_2c[10] + 1;
                    UNLOCK();
                    piStack_28 = (int *)piVar5[0x61];
                    piVar5[0x61] = (int)piStack_2c;
                    FUN_0056cd30();
                    FUN_008a4940(&DAT_01eeec6c);
                  }
                  cVar7 = FUN_005e0cd0(&piStack_2c);
                  if (cVar7 != '\0') {
                    LOCK();
                    piStack_2c[10] = piStack_2c[10] + 1;
                    UNLOCK();
                    piStack_28 = (int *)piVar5[0x60];
                    piVar5[0x60] = (int)piStack_2c;
                    FUN_0056cd30();
                    FUN_008a4940(&DAT_01eeec34);
                  }
                  uStack_14._0_1_ = 5;
                  FUN_0056cd30();
                }
                if (puStack_30 != (undefined4 *)0x0) {
                  (**(code **)*puStack_30)(1);
                }
                FUN_00b54fb0((uint)piVar18 & 0xffffff00,uVar19,piVar13,uVar20,0,0xf);
                piVar5[100] = 0;
                piVar13 = (int *)piVar5[0x65];
                piVar5[0x65] = 0;
                if (piVar13 != (int *)0x0) {
                  LOCK();
                  iVar9 = piVar13[1] + -1;
                  piVar13[1] = iVar9;
                  UNLOCK();
                  if (iVar9 == 0) {
                    (**(code **)*piVar13)();
                    LOCK();
                    iVar9 = piVar13[2] + -1;
                    piVar13[2] = iVar9;
                    UNLOCK();
                    if (iVar9 == 0) {
                      (**(code **)(*piVar13 + 4))();
                    }
                  }
                }
                break;
              }
            }
          }
          piVar4 = (int *)piVar13[2];
          if (*(char *)((int)piVar4 + 0xd) == '\0') {
            cVar7 = *(char *)(*piVar4 + 0xd);
            piVar13 = piVar4;
            piVar4 = (int *)*piVar4;
            while (cVar7 == '\0') {
              cVar7 = *(char *)(*piVar4 + 0xd);
              piVar13 = piVar4;
              piVar4 = (int *)*piVar4;
            }
          }
          else {
            cVar7 = *(char *)(piVar13[1] + 0xd);
            piVar6 = (int *)piVar13[1];
            piVar4 = piVar13;
            while ((piVar13 = piVar6, cVar7 == '\0' && (piVar4 == (int *)piVar13[2]))) {
              cVar7 = *(char *)(piVar13[1] + 0xd);
              piVar6 = (int *)piVar13[1];
              piVar4 = piVar13;
            }
          }
        }
        uStack_21 = 1;
        FUN_00b51d80();
      }
      FUN_0089ad50();
      FUN_00729fa0();
      FUN_00617ad0();
    }
    if (0xf < uStack_98) {
      uVar12 = uStack_98 + 1;
      uVar11 = auStack_ac[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_ac[0] - 4);
        uVar12 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    iStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  }
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_64[1] + -1;
    piStack_64[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_64)();
      LOCK();
      piVar13 = piStack_64 + 2;
      iVar9 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piStack_64 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_21;
}



/* FUNCTION 24325 ; VA 0x00b56440 ; FUN_00b56440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b56440(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_0088d730();
  iVar1 = _tls_index;
  *param_1 = uVar2;
  param_1[1] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ead418) {
    FUN_016f3809(&DAT_01ead418);
    if (DAT_01ead418 == -1) {
      DAT_01ead40c = FUN_005c6620;
      _DAT_01ead410 = FUN_005c6620;
      DAT_01ead414 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead418);
    }
  }
  param_1[1] = &DAT_01ead40c;
  return param_1;
}



/* FUNCTION 24326 ; VA 0x00b564e0 ; FUN_00b564e0 */

int * __thiscall
FUN_00b564e0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b56f90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StarterGuiService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::StarterGuiService::*)(void)const_,void_(__thiscall_RBX::StarterGuiService::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StarterGuiService,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::StarterGuiService,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24327 ; VA 0x00b565e0 ; FUN_00b565e0 */

undefined4 * __thiscall
FUN_00b565e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4128;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xb5664d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xb56699);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01955544;
  cStack_11 = FUN_00b59030();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb56723);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xb5675e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb5678c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24328 ; VA 0x00b567b0 ; FUN_00b567b0 */

undefined4 * __thiscall
FUN_00b567b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4158;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xb5681d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xb56869);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01955574;
  cStack_11 = FUN_00b59190();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb568f3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xb5692e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb5695c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24329 ; VA 0x00b56980 ; FUN_00b56980 */

undefined4 __thiscall
FUN_00b56980(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4178;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00b567b0();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0xb56a1e;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24330 ; VA 0x00b56a40 ; FUN_00b56a40 */

undefined4 * __thiscall
FUN_00b56a40(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f41a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_2c,&param_4);
      uStack_6c = 0xb56aa4;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_4c,&uStack_2c);
      uStack_6c = 0xb56aed;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  puStack_60 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_80;
  auStack_80[0] = 0;
  puVar1 = auStack_80;
  if (uStack_54 != 0) {
    auStack_80[0] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_78,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      puVar1 = auStack_80;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_0195553c;
  cVar2 = FUN_00b592f0();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_6c = 0xb56b72;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = (undefined4 *)0x2;
      uStack_68 = CONCAT44(&uStack_2c,&uStack_2c);
      uStack_6c = 0xb56b9d;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&param_4,&param_4);
    uStack_6c = 0xb56bcb;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24331 ; VA 0x00b56bf0 ; FUN_00b56bf0 */

undefined4 * __thiscall FUN_00b56bf0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = *param_2;
  uVar3 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar2;
  piVar4 = (int *)param_1[1];
  param_1[1] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[2] + -1;
    piVar4[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)(*piVar4 + 4))();
    }
  }
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[2] = uVar2;
  piVar4 = (int *)param_1[3];
  param_1[3] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 24332 ; VA 0x00b56c80 ; FUN_00b56c80 */

int * __thiscall FUN_00b56c80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b62210();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24333 ; VA 0x00b56cd0 ; FUN_00b56cd0 */

undefined * FUN_00b56cd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f41cc;
  pvStack_10 = ExceptionList;
  if (DAT_01eef940 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefb50) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eefb50);
      if (DAT_01eefb50 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"BasePlayerGui",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188e400);
        FUN_016f37bf(&DAT_01eefb50);
      }
    }
    DAT_01eef940 = &DAT_01eef948;
  }
  ExceptionList = pvStack_10;
  return DAT_01eef940;
}



/* FUNCTION 24334 ; VA 0x00b56db0 ; FUN_00b56db0 */

undefined * FUN_00b56db0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f41ec;
  pvStack_10 = ExceptionList;
  if (DAT_01eef728 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef938) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eef938);
      if (DAT_01eef938 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b56cd0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CoreGui",1,uStack_20,0,0,1,1,0);
        FUN_016f3654(&LAB_0188e410);
        FUN_016f37bf(&DAT_01eef938);
      }
    }
    DAT_01eef728 = &DAT_01eef730;
  }
  ExceptionList = pvStack_10;
  return DAT_01eef728;
}



/* FUNCTION 24335 ; VA 0x00b56e90 ; FUN_00b56e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b56e90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4220;
  pvStack_10 = ExceptionList;
  if (DAT_01eefb58 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefd70) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eefd70);
      if (DAT_01eefd70 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b56cd0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PlayerGui",0,uStack_20,0,0,5,0,0);
        _DAT_01eefd68 = RBX::Creator<class_RBX::PlayerGui>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eefb60,&DAT_01eefd68);
        FUN_016f3654(FUN_0188e420);
        FUN_016f37bf(&DAT_01eefd70);
      }
    }
    DAT_01eefb58 = &DAT_01eefb60;
  }
  ExceptionList = pvStack_10;
  return DAT_01eefb58;
}



/* FUNCTION 24336 ; VA 0x00b56f90 ; FUN_00b56f90 */

undefined * FUN_00b56f90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f423c;
  pvStack_10 = ExceptionList;
  if (DAT_01eef510 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef720) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eef720);
      if (DAT_01eef720 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b56cd0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"StarterGui",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188e480);
        FUN_016f37bf(&DAT_01eef720);
      }
    }
    DAT_01eef510 = &DAT_01eef518;
  }
  ExceptionList = pvStack_10;
  return DAT_01eef510;
}



/* FUNCTION 24337 ; VA 0x00b57070 ; FUN_00b57070 */

void FUN_00b57070(void)

{
  int iVar1;
  
  if (DAT_01eef93c == 0) {
    iVar1 = FUN_00b56db0();
    DAT_01eef93c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24338 ; VA 0x00b57090 ; FUN_00b57090 */

void FUN_00b57090(void)

{
  int iVar1;
  
  if (DAT_01eef724 == 0) {
    iVar1 = FUN_00b56f90();
    DAT_01eef724 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24339 ; VA 0x00b570b0 ; FUN_00b570b0 */

void __thiscall
FUN_00b570b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,int param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,int param_12,int param_13)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00b57740(param_10,param_3,param_11,param_5 - param_12,param_13,param_7,param_8,param_1
                      );
  FUN_00b57120(param_2,param_10,uVar1,param_12,param_13,param_7,param_8,param_9);
  FUN_00b57120(uVar1,param_11,param_4,param_5 - param_12,param_6 - param_13,param_7,param_8,param_9)
  ;
  return;
}



/* FUNCTION 24340 ; VA 0x00b57120 ; FUN_00b57120 */

int * FUN_00b57120(int *param_1,int *param_2,int *param_3,int param_4,int param_5,undefined4 param_6
                  ,int param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  bool bVar8;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  int iStack_c;
  
  if (param_2 == param_3) {
    return param_2;
  }
  if (param_1 == param_2) {
    return param_2;
  }
  do {
    iVar7 = *param_2;
    iVar2 = param_5;
    if (DAT_01d6889c == '\0') {
      uStack_10 = -0x80000000;
      if ((iVar7 != 0) &&
         (iVar7 = *(int *)(iVar7 + 0xc), iVar3 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        uStack_10 = FUN_00c699d0();
      }
      iStack_c = -0x80000000;
      if (*param_1 != 0) {
        iVar7 = *(int *)(*param_1 + 0xc);
        iVar3 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
          iStack_c = -0x80000000;
        }
        else {
          iStack_c = FUN_00c699d0();
        }
      }
      bVar8 = SBORROW4(uStack_10,iStack_c);
      iStack_c = uStack_10 - iStack_c;
LAB_00b5727b:
      piVar5 = param_3;
      if (bVar8 != iStack_c < 0) break;
    }
    else {
      uStack_10 = 0xffffffff;
      iStack_c = 0;
      if ((iVar7 != 0) &&
         (iVar7 = *(int *)(iVar7 + 0xc), iVar3 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        iStack_c = FUN_00c699d0();
        uStack_10 = FUN_00c69a20();
        uStack_10 = uStack_10 & 0xff;
      }
      uVar4 = 0xffffffff;
      iVar7 = 0;
      if (*param_1 != 0) {
        iVar7 = *(int *)(*param_1 + 0xc);
        iVar3 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar3 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
          uVar4 = 0xffffffff;
          iVar7 = 0;
        }
        else {
          iVar7 = FUN_00c699d0();
          uVar4 = FUN_00c69a20();
          uVar4 = uVar4 & 0xff;
        }
      }
      piVar5 = param_3;
      if ((int)uStack_10 < (int)uVar4) break;
      if ((int)uStack_10 <= (int)uVar4) {
        bVar8 = SBORROW4(iStack_c,iVar7);
        iStack_c = iStack_c - iVar7;
        goto LAB_00b5727b;
      }
    }
    param_4 = param_4 + -1;
    param_1 = param_1 + 2;
    if (param_1 == param_2) {
      return param_2;
    }
  } while( true );
LAB_00b572a0:
  param_5 = iVar2;
  param_3 = piVar5;
  piVar5 = param_3 + -2;
  if (param_2 == piVar5) {
    iVar7 = *param_2;
    iVar2 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    FUN_007752e0(param_1,param_2,param_3);
    *param_1 = iVar7;
    piVar5 = (int *)param_1[1];
    param_1[1] = iVar2;
    piVar6 = piVar5;
    goto LAB_00b57553;
  }
  iVar7 = *piVar5;
  iVar2 = param_5 + -1;
  if (DAT_01d6889c == '\0') {
    iStack_18 = -0x80000000;
    if ((iVar7 != 0) &&
       (iVar7 = *(int *)(iVar7 + 0xc), iVar3 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      iStack_18 = FUN_00c699d0();
    }
    if (param_2[-2] == 0) {
      iVar7 = -0x80000000;
    }
    else {
      iVar7 = *(int *)(param_2[-2] + 0xc);
      iVar3 = FUN_00c68a10();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        iVar7 = -0x80000000;
      }
      else {
        iVar7 = FUN_00c699d0();
      }
    }
    bVar8 = SBORROW4(iStack_18,iVar7);
    iStack_18 = iStack_18 - iVar7;
  }
  else {
    uStack_14 = 0xffffffff;
    iStack_18 = 0;
    if ((iVar7 != 0) &&
       (iVar7 = *(int *)(iVar7 + 0xc), iVar3 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      iStack_18 = FUN_00c699d0();
      uStack_14 = FUN_00c69a20();
      uStack_14 = uStack_14 & 0xff;
    }
    uVar4 = 0xffffffff;
    iStack_c = 0;
    iVar7 = 0;
    if (param_2[-2] != 0) {
      iVar7 = *(int *)(param_2[-2] + 0xc);
      iVar3 = FUN_00c68a10();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        uVar4 = 0xffffffff;
        iVar7 = iStack_c;
      }
      else {
        iVar7 = FUN_00c699d0();
        uVar4 = FUN_00c69a20();
        uVar4 = uVar4 & 0xff;
      }
    }
    if ((int)uStack_14 < (int)uVar4) goto LAB_00b57417;
    if ((int)uVar4 < (int)uStack_14) goto LAB_00b572a0;
    bVar8 = SBORROW4(iStack_18,iVar7);
    iStack_18 = iStack_18 - iVar7;
  }
  if (bVar8 != iStack_18 < 0) {
LAB_00b57417:
    if (param_4 != 1) {
      if ((param_4 <= param_5) && (param_4 <= param_7)) {
        piVar5 = (int *)FUN_00b578b0(param_1,param_2,param_3,param_6,param_8);
        return piVar5;
      }
      if (param_5 <= param_7) {
        piVar5 = (int *)FUN_00b57bd0(param_1,param_2,param_3,param_6,param_8);
        return piVar5;
      }
      if (param_4 <= param_5) {
        iVar7 = FUN_00b599f0(param_2,param_3,param_1 + (param_4 >> 1) * 2,param_8);
        piVar5 = (int *)FUN_00b570b0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8
                                     ,param_1 + (param_4 >> 1) * 2,iVar7,param_4 >> 1,
                                     iVar7 - (int)param_2 >> 3);
        return piVar5;
      }
      iVar7 = FUN_00b59cd0(param_1,param_2,param_2 + (param_5 >> 1) * 2,param_8);
      piVar5 = (int *)FUN_00b570b0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,
                                   iVar7,param_2 + (param_5 >> 1) * 2,iVar7 - (int)param_1 >> 3,
                                   param_5 >> 1);
      return piVar5;
    }
    iVar7 = *param_1;
    iVar2 = param_1[1];
    *param_1 = 0;
    param_1[1] = 0;
    piVar5 = (int *)FUN_00775350(param_2,param_3,param_1);
    *piVar5 = iVar7;
    piVar6 = (int *)piVar5[1];
    piVar5[1] = iVar2;
LAB_00b57553:
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar7 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        piVar5 = (int *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          piVar5 = (int *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
    return piVar5;
  }
  goto LAB_00b572a0;
}



/* FUNCTION 24341 ; VA 0x00b57590 ; FUN_00b57590 */

void FUN_00b57590(int param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4260;
  pvStack_10 = ExceptionList;
  iVar1 = param_1;
  ExceptionList = &pvStack_10;
  if (0x20 < param_3) {
    iVar5 = (param_3 - 0x21U >> 5) + 1;
    ExceptionList = &pvStack_10;
    do {
      iVar1 = FUN_00b57f80(iVar1,iVar1 + 0x100,param_5);
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
  }
  FUN_00b57f80(iVar1,param_2,param_5);
  iStack_18 = 0x20;
  if (0x20 < param_3) {
    iStack_14 = param_1;
    uStack_8 = 0;
    iVar1 = param_4;
    iVar5 = param_3;
    do {
      iVar5 = iVar5 + -0x20;
      iVar4 = 0x20;
      if (iVar5 < 0x20) {
        iVar4 = iVar5;
      }
      iVar5 = iVar5 - iVar4;
      iVar4 = iStack_14 + 0x100 + iVar4 * 8;
      iVar1 = FUN_00b58d60(iStack_14,iStack_14 + 0x100,iVar4,iVar1,param_5);
      iStack_14 = iVar4;
    } while (0x20 < iVar5);
    FUN_00b58fc0(iVar4,param_2,iVar1);
    FUN_00b5a770();
    uStack_8 = 1;
    while( true ) {
      iVar5 = iStack_18 * 2;
      iStack_14 = param_1;
      iVar4 = param_4;
      iVar1 = param_4;
      iVar3 = param_3;
      if (iVar5 < param_3) {
        do {
          iVar3 = iVar3 + iStack_18 * -2;
          iVar2 = iVar4 + iStack_18 * 0x10;
          iVar1 = iVar5;
          if (iVar3 < iVar5) {
            iVar1 = iVar3;
          }
          iVar3 = iVar3 - iVar1;
          iVar1 = iVar2 + iVar1 * 8;
          iStack_14 = FUN_00b58880(iVar4,iVar2,iVar1,iStack_14,param_5);
          iVar4 = iVar1;
        } while (iVar5 < iVar3);
      }
      FUN_00775350(iVar1,param_4 + param_3 * 8,iStack_14);
      iVar1 = iStack_18 * 4;
      if (param_3 <= iVar1) break;
      iStack_14 = param_4;
      iVar5 = param_1;
      iVar4 = param_3;
      do {
        iVar4 = iVar4 + iStack_18 * -4;
        iVar3 = iVar5 + iStack_18 * 0x20;
        iVar2 = iVar1;
        if (iVar4 < iVar1) {
          iVar2 = iVar4;
        }
        iVar4 = iVar4 - iVar2;
        iVar2 = iVar3 + iVar2 * 8;
        iStack_14 = FUN_00b58880(iVar5,iVar3,iVar2,iStack_14,param_5);
        iVar5 = iVar2;
      } while (iVar1 < iVar4);
      FUN_00775350(iVar2,param_2,iStack_14);
      iStack_18 = iVar1;
    }
    FUN_00b5a770();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24342 ; VA 0x00b57740 ; FUN_00b57740 */

undefined4 *
FUN_00b57740(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,int param_4,int param_5,
            undefined4 param_6,int param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  if (param_4 == 0) {
    return param_3;
  }
  if (param_5 == 0) {
    return param_1;
  }
  if ((param_4 <= param_5) && (param_4 <= param_7)) {
    uVar1 = FUN_00b58fc0(param_1,param_2,param_6);
    puVar2 = (undefined4 *)FUN_00775350(param_2,param_3,param_1);
    FUN_00775350(param_6,uVar1,puVar2);
    FUN_00b5a770();
    return puVar2;
  }
  if (param_5 <= param_7) {
    uVar1 = FUN_00b58fc0(param_2,param_3,param_6);
    FUN_007752e0(param_1,param_2,param_3);
    puVar2 = (undefined4 *)FUN_00775350(param_6,uVar1,param_1);
    FUN_00b5a770();
    return puVar2;
  }
  if (param_1 == param_2) {
    return param_3;
  }
  puVar2 = param_2;
  puVar6 = param_1;
  if (param_2 != param_3) {
    do {
      puVar3 = puVar2 + -2;
      puVar4 = param_3;
      puVar5 = param_2;
      if (puVar6 == puVar3) break;
      uVar1 = *puVar6;
      *puVar6 = *puVar3;
      *puVar3 = uVar1;
      uVar1 = puVar6[1];
      puVar6[1] = puVar2[-1];
      puVar6 = puVar6 + 2;
      puVar2[-1] = uVar1;
      puVar2 = puVar3;
    } while (puVar6 != puVar3);
    do {
      puVar2 = puVar4 + -2;
      if (puVar5 == puVar2) break;
      uVar1 = *puVar5;
      *puVar5 = *puVar2;
      *puVar2 = uVar1;
      uVar1 = puVar5[1];
      puVar5[1] = puVar4[-1];
      puVar5 = puVar5 + 2;
      puVar4[-1] = uVar1;
      puVar4 = puVar2;
    } while (puVar5 != puVar2);
    puVar2 = param_3;
    puVar6 = param_1;
    if (param_1 != param_3) {
      do {
        puVar4 = puVar2 + -2;
        if (puVar6 == puVar4) break;
        uVar1 = *puVar6;
        *puVar6 = *puVar4;
        *puVar4 = uVar1;
        uVar1 = puVar6[1];
        puVar6[1] = puVar2[-1];
        puVar6 = puVar6 + 2;
        puVar2[-1] = uVar1;
        puVar2 = puVar4;
      } while (puVar6 != puVar4);
    }
    param_1 = param_1 + ((int)param_3 - (int)param_2 >> 3) * 2;
  }
  return param_1;
}



/* FUNCTION 24343 ; VA 0x00b578b0 ; FUN_00b578b0 */

void FUN_00b578b0(undefined4 *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4278;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00b58fc0(param_1,param_2,param_4);
  uVar1 = *param_2;
  uVar2 = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = uVar1;
  piVar9 = (int *)param_1[1];
  uStack_8 = 0;
  param_1[1] = uVar2;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar7 = piVar9[1] + -1;
    piVar9[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      iVar7 = piVar9[2] + -1;
      piVar9[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar10 = param_1 + 2;
  piVar9 = param_2 + 2;
  do {
    while (iVar7 = *piVar9, DAT_01d6889c == '\0') {
      param_2 = (undefined4 *)0x80000000;
      if ((iVar7 != 0) &&
         (iVar7 = *(int *)(iVar7 + 0xc), iVar5 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        param_2 = (undefined4 *)FUN_00c699d0();
      }
      if (*param_4 == 0) {
        iVar7 = -0x80000000;
      }
      else {
        iVar7 = *(int *)(*param_4 + 0xc);
        iVar5 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
          iVar7 = -0x80000000;
        }
        else {
          iVar7 = FUN_00c699d0();
        }
      }
      if ((int)param_2 < iVar7) goto LAB_00b57b67;
LAB_00b57a0f:
      iVar7 = *param_4;
      iVar5 = param_4[1];
      *param_4 = 0;
      param_4[1] = 0;
      *piVar10 = iVar7;
      piVar3 = (int *)piVar10[1];
      piVar10[1] = iVar5;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar7 = piVar3[1] + -1;
        piVar3[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar7 = piVar3[2] + -1;
          piVar3[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar10 = piVar10 + 2;
      param_4 = param_4 + 2;
      if (param_4 == (int *)(iVar4 + -8)) {
        puVar8 = (undefined4 *)FUN_00775350(piVar9,param_3,piVar10);
        uVar1 = *(undefined4 *)(iVar4 + -8);
        uVar2 = *(undefined4 *)(iVar4 + -4);
        *(undefined4 *)(iVar4 + -8) = 0;
        *(undefined4 *)(iVar4 + -4) = 0;
        *puVar8 = uVar1;
        piVar9 = (int *)puVar8[1];
        puVar8[1] = uVar2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar4 = piVar9[1] + -1;
          piVar9[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            piVar10 = piVar9 + 2;
            iVar4 = *piVar10;
            *piVar10 = *piVar10 + -1;
            UNLOCK();
            if (iVar4 == 1) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        goto LAB_00b57ab9;
      }
    }
    uStack_14 = 0xffffffff;
    iStack_18 = 0;
    if ((iVar7 != 0) &&
       (iVar7 = *(int *)(iVar7 + 0xc), iVar5 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      iStack_18 = FUN_00c699d0();
      uStack_14 = FUN_00c69a20();
      uStack_14 = uStack_14 & 0xff;
    }
    uVar6 = 0xffffffff;
    param_2 = (undefined4 *)0x0;
    iVar7 = 0;
    if (*param_4 != 0) {
      iVar7 = *(int *)(*param_4 + 0xc);
      iVar5 = FUN_00c68a10();
      if ((uint)*(ushort *)(iVar5 + 0x1da) <
          (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
        uVar6 = 0xffffffff;
        iVar7 = (int)param_2;
      }
      else {
        iVar7 = FUN_00c699d0();
        uVar6 = FUN_00c69a20();
        uVar6 = uVar6 & 0xff;
      }
    }
    if (((int)uVar6 <= (int)uStack_14) && (((int)uVar6 < (int)uStack_14 || (iVar7 <= iStack_18))))
    goto LAB_00b57a0f;
LAB_00b57b67:
    iVar7 = *piVar9;
    iVar5 = piVar9[1];
    *piVar9 = 0;
    piVar9[1] = 0;
    *piVar10 = iVar7;
    piVar3 = (int *)piVar10[1];
    piVar10[1] = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar7 = piVar3[1] + -1;
      piVar3[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar7 = piVar3[2] + -1;
        piVar3[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar9 = piVar9 + 2;
    piVar10 = piVar10 + 2;
  } while (piVar9 != param_3);
  FUN_00775350(param_4,iVar4,piVar10);
LAB_00b57ab9:
  FUN_00b5a770();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24344 ; VA 0x00b57bd0 ; FUN_00b57bd0 */

void FUN_00b57bd0(int *param_1,int param_2,int *param_3,int *param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4278;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b58fc0(param_2,param_3,param_4);
  uVar1 = *(undefined4 *)(param_2 + -4);
  piVar5 = (int *)((int)param_3 + -8);
  iVar4 = *(int *)(param_2 + -8);
  *(undefined4 *)(param_2 + -8) = 0;
  *(undefined4 *)(param_2 + -4) = 0;
  *piVar5 = iVar4;
  piVar7 = *(int **)((int)param_3 + -4);
  *(undefined4 *)((int)param_3 + -4) = uVar1;
  uStack_8 = 0;
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar4 = piVar7[1] + -1;
    piVar7[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      iVar4 = piVar7[2] + -1;
      piVar7[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  param_3 = (int *)(iVar2 + -8);
  piVar7 = (int *)(param_2 + -0x10);
LAB_00b57c70:
  do {
    piVar6 = piVar5;
    iVar4 = *param_3;
    if (DAT_01d6889c == '\0') {
      param_2 = -0x80000000;
      if ((iVar4 != 0) &&
         (iVar4 = *(int *)(iVar4 + 0xc), iVar2 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) {
        param_2 = FUN_00c699d0();
      }
      if (*piVar7 == 0) {
        iVar4 = -0x80000000;
      }
      else {
        iVar4 = *(int *)(*piVar7 + 0xc);
        iVar2 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
          iVar4 = -0x80000000;
        }
        else {
          iVar4 = FUN_00c699d0();
        }
      }
      if (param_2 < iVar4) goto LAB_00b57eca;
    }
    else {
      uStack_14 = 0xffffffff;
      iStack_18 = 0;
      if ((iVar4 != 0) &&
         (iVar4 = *(int *)(iVar4 + 0xc), iVar2 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) {
        iStack_18 = FUN_00c699d0();
        uStack_14 = FUN_00c69a20();
        uStack_14 = uStack_14 & 0xff;
      }
      uVar3 = 0xffffffff;
      param_2 = 0;
      iVar4 = 0;
      if (*piVar7 != 0) {
        iVar4 = *(int *)(*piVar7 + 0xc);
        iVar2 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
          uVar3 = 0xffffffff;
          iVar4 = param_2;
        }
        else {
          iVar4 = FUN_00c699d0();
          uVar3 = FUN_00c69a20();
          uVar3 = uVar3 & 0xff;
        }
      }
      if (((int)uStack_14 < (int)uVar3) || (((int)uStack_14 <= (int)uVar3 && (iStack_18 < iVar4))))
      {
LAB_00b57eca:
        iVar4 = *piVar7;
        iVar2 = piVar7[1];
        *piVar7 = 0;
        piVar7[1] = 0;
        piVar6[-2] = iVar4;
        piVar5 = (int *)piVar6[-1];
        piVar6[-1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar4 = piVar5[1] + -1;
          piVar5[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar4 = piVar5[2] + -1;
            piVar5[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (param_1 == piVar7) {
          iVar4 = *param_3;
          iVar2 = param_3[1];
          *param_3 = 0;
          param_3[1] = 0;
          piVar6[-4] = iVar4;
          piVar7 = (int *)piVar6[-3];
          piVar6[-3] = iVar2;
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar4 = piVar7[1] + -1;
            piVar7[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              piVar5 = piVar7 + 2;
              iVar4 = *piVar5;
              *piVar5 = *piVar5 + -1;
              UNLOCK();
              if (iVar4 == 1) {
                (**(code **)(*piVar7 + 4))();
              }
            }
          }
          FUN_007752e0(param_4,param_3,piVar6 + -4);
          goto LAB_00b57e25;
        }
        piVar7 = piVar7 + -2;
        piVar5 = piVar6 + -2;
        goto LAB_00b57c70;
      }
    }
    iVar4 = *param_3;
    iVar2 = param_3[1];
    *param_3 = 0;
    param_3[1] = 0;
    piVar6[-2] = iVar4;
    piVar5 = (int *)piVar6[-1];
    piVar6[-1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar4 = piVar5[1] + -1;
      piVar5[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar4 = piVar5[2] + -1;
        piVar5[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    param_3 = param_3 + -2;
    piVar5 = piVar6 + -2;
    if (param_4 == param_3) {
      iVar4 = *piVar7;
      iVar2 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      piVar6[-4] = iVar4;
      piVar5 = (int *)piVar6[-3];
      piVar6[-3] = iVar2;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      FUN_007752e0(param_1,piVar7,piVar6 + -4);
      iVar4 = *param_4;
      iVar2 = param_4[1];
      *param_4 = 0;
      param_4[1] = 0;
      *param_1 = iVar4;
      piVar7 = (int *)param_1[1];
      param_1[1] = iVar2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar4 = piVar7[1] + -1;
        piVar7[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar5 = piVar7 + 2;
          iVar4 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
LAB_00b57e25:
      FUN_00b5a770();
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 24345 ; VA 0x00b57f80 ; FUN_00b57f80 */

int * FUN_00b57f80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void **ppvVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  bool bVar11;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4298;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    ppvVar4 = &pvStack_10;
    for (piVar7 = param_1 + 2; ExceptionList = ppvVar4, piVar7 != param_2; piVar7 = piVar7 + 2) {
      iVar1 = *piVar7;
      iVar2 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      uStack_8 = 0;
      piStack_1c = piVar7;
      if (DAT_01d6889c == '\0') {
        uStack_24 = -0x80000000;
        if ((iVar1 != 0) &&
           (iVar6 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          uStack_24 = FUN_00c699d0();
        }
        iVar6 = -0x80000000;
        if (*param_1 != 0) {
          iVar6 = *(int *)(*param_1 + 0xc);
          iVar5 = FUN_00c68a10();
          if ((uint)*(ushort *)(iVar5 + 0x1da) <
              (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
            iVar6 = -0x80000000;
          }
          else {
            iVar6 = FUN_00c699d0();
          }
        }
        if ((int)uStack_24 < iVar6) goto LAB_00b581ec;
LAB_00b580b0:
        piVar8 = piStack_1c + -2;
        if (DAT_01d6889c == '\0') {
          uStack_24 = -0x80000000;
          if ((iVar1 != 0) &&
             (iVar6 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
             (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
             (uint)*(ushort *)(iVar5 + 0x1da))) {
            uStack_24 = FUN_00c699d0();
          }
          if (*piVar8 == 0) {
            iStack_18 = -0x80000000;
          }
          else {
            iVar6 = *(int *)(*piVar8 + 0xc);
            iVar5 = FUN_00c68a10();
            if ((uint)*(ushort *)(iVar5 + 0x1da) <
                (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
              iStack_18 = -0x80000000;
            }
            else {
              iStack_18 = FUN_00c699d0();
            }
          }
          bVar11 = SBORROW4(uStack_24,iStack_18);
          iStack_18 = uStack_24 - iStack_18;
LAB_00b5834a:
          if (bVar11 == iStack_18 < 0) goto LAB_00b58396;
LAB_00b5834c:
          iVar6 = *piVar8;
          iVar5 = piStack_1c[-1];
          *piVar8 = 0;
          piStack_1c[-1] = 0;
          *piStack_1c = iVar6;
          piVar10 = (int *)piStack_1c[1];
          piStack_1c[1] = iVar5;
          piStack_1c = piVar8;
          if (piVar10 != (int *)0x0) {
            LOCK();
            iVar6 = piVar10[1] + -1;
            piVar10[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piVar10)();
              LOCK();
              iVar6 = piVar10[2] + -1;
              piVar10[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piVar10 + 4))();
              }
            }
          }
          goto LAB_00b580b0;
        }
        uStack_24 = 0xffffffff;
        uStack_20 = 0;
        if ((iVar1 != 0) &&
           (iVar6 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          uStack_20 = FUN_00c699d0();
          uStack_24 = FUN_00c69a20();
          uStack_24 = uStack_24 & 0xff;
        }
        uVar9 = 0xffffffff;
        iStack_18 = 0;
        if (*piVar8 != 0) {
          iVar6 = *(int *)(*piVar8 + 0xc);
          iVar5 = FUN_00c68a10();
          if ((uint)*(ushort *)(iVar5 + 0x1da) <
              (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
            uVar9 = 0xffffffff;
          }
          else {
            iStack_18 = FUN_00c699d0();
            uVar9 = FUN_00c69a20();
            uVar9 = uVar9 & 0xff;
          }
        }
        if ((int)uStack_24 < (int)uVar9) goto LAB_00b5834c;
        if ((int)uStack_24 <= (int)uVar9) {
          bVar11 = SBORROW4(uStack_20,iStack_18);
          iStack_18 = uStack_20 - iStack_18;
          goto LAB_00b5834a;
        }
LAB_00b58396:
        *piStack_1c = iVar1;
        piVar8 = (int *)piStack_1c[1];
        piStack_1c[1] = iVar2;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar1 = piVar8[1] + -1;
          piVar8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar1 = piVar8[2] + -1;
            piVar8[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      else {
        uStack_20 = 0xffffffff;
        uStack_24 = 0;
        if ((iVar1 != 0) &&
           (iVar6 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          uStack_24 = FUN_00c699d0();
          uStack_20 = FUN_00c69a20();
          uStack_20 = uStack_20 & 0xff;
        }
        uVar9 = 0xffffffff;
        iStack_18 = 0;
        if ((*param_1 != 0) &&
           (iVar6 = *(int *)(*param_1 + 0xc), iVar5 = FUN_00c68a10(),
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          iStack_18 = FUN_00c699d0();
          uVar9 = FUN_00c69a20();
          uVar9 = uVar9 & 0xff;
        }
        if (((int)uVar9 <= (int)uStack_20) &&
           (((int)uVar9 < (int)uStack_20 || (iStack_18 <= (int)uStack_24)))) goto LAB_00b580b0;
LAB_00b581ec:
        if (piVar7 != param_1) {
          piVar8 = piVar7 + 2;
          piVar10 = piVar7 + -1;
          do {
            iVar6 = piVar10[-1];
            iVar5 = *piVar10;
            piVar10[-1] = 0;
            *piVar10 = 0;
            piVar8[-2] = iVar6;
            piVar3 = (int *)piVar8[-1];
            piVar8[-1] = iVar5;
            if (piVar3 != (int *)0x0) {
              LOCK();
              iVar6 = piVar3[1] + -1;
              piVar3[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)*piVar3)();
                LOCK();
                iVar6 = piVar3[2] + -1;
                piVar3[2] = iVar6;
                UNLOCK();
                if (iVar6 == 0) {
                  (**(code **)(*piVar3 + 4))();
                }
              }
            }
            piVar3 = piVar10 + -1;
            piVar8 = piVar8 + -2;
            piVar10 = piVar10 + -2;
          } while (piVar3 != param_1);
        }
        *param_1 = iVar1;
        piVar8 = (int *)param_1[1];
        param_1[1] = iVar2;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar1 = piVar8[1] + -1;
          piVar8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar1 = piVar8[2] + -1;
            piVar8[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
      ppvVar4 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24346 ; VA 0x00b58410 ; FUN_00b58410 */

undefined4 * FUN_00b58410(undefined4 *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void **ppvVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  bool bVar11;
  uint uStack_28;
  uint uStack_24;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4298;
  pvStack_10 = ExceptionList;
  if ((param_2 == param_3) || (piVar8 = param_2 + 2, ppvVar4 = &pvStack_10, piVar8 == param_3)) {
    *param_1 = param_3;
    return param_1;
  }
  do {
    ExceptionList = ppvVar4;
    iVar1 = *piVar8;
    iVar2 = piVar8[1];
    *piVar8 = 0;
    piVar8[1] = 0;
    uStack_8 = 0;
    piVar9 = piVar8;
    if (DAT_01d6889c == '\0') {
      uStack_28 = -0x80000000;
      if ((iVar1 != 0) &&
         (iVar7 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        uStack_28 = FUN_00c699d0();
      }
      if (*param_2 == 0) {
        iVar7 = -0x80000000;
      }
      else {
        iVar7 = *(int *)(*param_2 + 0xc);
        iVar5 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
          iVar7 = -0x80000000;
        }
        else {
          iVar7 = FUN_00c699d0();
        }
      }
      if (iVar7 <= (int)uStack_28) goto LAB_00b58542;
LAB_00b58687:
      if (piVar8 != param_2) {
        piVar9 = piVar8 + -1;
        piVar10 = piVar8 + 2;
        do {
          iVar7 = piVar9[-1];
          iVar5 = *piVar9;
          piVar9[-1] = 0;
          *piVar9 = 0;
          piVar10[-2] = iVar7;
          piVar3 = (int *)piVar10[-1];
          piVar10[-1] = iVar5;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar7 = piVar3[1] + -1;
            piVar3[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar7 = piVar3[2] + -1;
              piVar3[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          piVar3 = piVar9 + -1;
          piVar9 = piVar9 + -2;
          piVar10 = piVar10 + -2;
        } while (piVar3 != param_2);
      }
      *param_2 = iVar1;
      piVar10 = (int *)param_2[1];
      param_2[1] = iVar2;
    }
    else {
      uStack_24 = 0xffffffff;
      uStack_28 = 0;
      if ((iVar1 != 0) &&
         (iVar7 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        uStack_28 = FUN_00c699d0();
        uStack_24 = FUN_00c69a20();
        uStack_24 = uStack_24 & 0xff;
      }
      uVar6 = 0xffffffff;
      iStack_18 = 0;
      if (*param_2 != 0) {
        iVar7 = *(int *)(*param_2 + 0xc);
        iVar5 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
          uVar6 = 0xffffffff;
        }
        else {
          iStack_18 = FUN_00c699d0();
          uVar6 = FUN_00c69a20();
          uVar6 = uVar6 & 0xff;
        }
      }
      if (((int)uStack_24 < (int)uVar6) ||
         (((int)uStack_24 <= (int)uVar6 && ((int)uStack_28 < iStack_18)))) goto LAB_00b58687;
LAB_00b58542:
      piVar10 = piVar9 + -2;
      if (DAT_01d6889c == '\0') {
        uStack_28 = -0x80000000;
        if ((iVar1 != 0) &&
           (iVar7 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
           (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
           (uint)*(ushort *)(iVar5 + 0x1da))) {
          uStack_28 = FUN_00c699d0();
        }
        if (*piVar10 == 0) {
          iStack_1c = -0x80000000;
        }
        else {
          iVar7 = *(int *)(*piVar10 + 0xc);
          iVar5 = FUN_00c68a10();
          if ((uint)*(ushort *)(iVar5 + 0x1da) <
              (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
            iStack_1c = -0x80000000;
          }
          else {
            iStack_1c = FUN_00c699d0();
          }
        }
        bVar11 = SBORROW4(uStack_28,iStack_1c);
        iStack_1c = uStack_28 - iStack_1c;
LAB_00b587a8:
        if (bVar11 == iStack_1c < 0) goto LAB_00b587f1;
LAB_00b587aa:
        iVar7 = *piVar10;
        iVar5 = piVar9[-1];
        *piVar10 = 0;
        piVar9[-1] = 0;
        *piVar9 = iVar7;
        piVar3 = (int *)piVar9[1];
        piVar9[1] = iVar5;
        piVar9 = piVar10;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar7 = piVar3[1] + -1;
          piVar3[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar7 = piVar3[2] + -1;
            piVar3[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        goto LAB_00b58542;
      }
      uStack_28 = 0xffffffff;
      uStack_24 = 0;
      if ((iVar1 != 0) &&
         (iVar7 = *(int *)(iVar1 + 0xc), iVar5 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        uStack_24 = FUN_00c699d0();
        uStack_28 = FUN_00c69a20();
        uStack_28 = uStack_28 & 0xff;
      }
      uVar6 = 0xffffffff;
      iStack_1c = 0;
      if (*piVar10 != 0) {
        iVar7 = *(int *)(*piVar10 + 0xc);
        iVar5 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
          uVar6 = 0xffffffff;
        }
        else {
          iStack_1c = FUN_00c699d0();
          uVar6 = FUN_00c69a20();
          uVar6 = uVar6 & 0xff;
        }
      }
      if ((int)uStack_28 < (int)uVar6) goto LAB_00b587aa;
      if ((int)uStack_28 <= (int)uVar6) {
        bVar11 = SBORROW4(uStack_24,iStack_1c);
        iStack_1c = uStack_24 - iStack_1c;
        goto LAB_00b587a8;
      }
LAB_00b587f1:
      *piVar9 = iVar1;
      piVar10 = (int *)piVar9[1];
      piVar9[1] = iVar2;
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar1 = piVar10[1] + -1;
      piVar10[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar1 = piVar10[2] + -1;
        piVar10[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar10 + 4))();
        }
      }
    }
    piVar8 = piVar8 + 2;
    ppvVar4 = (void **)ExceptionList;
    if (piVar8 == param_3) {
      *param_1 = param_3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 24347 ; VA 0x00b58880 ; FUN_00b58880 */

void FUN_00b58880(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  int *piStack_8;
  
  piStack_8 = param_2;
  do {
    while (iVar4 = *piStack_8, DAT_01d6889c != '\0') {
      uStack_10 = 0xffffffff;
      iStack_14 = 0;
      if ((iVar4 != 0) &&
         (iVar4 = *(int *)(iVar4 + 0xc), iVar2 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) {
        iStack_14 = FUN_00c699d0();
        uStack_10 = FUN_00c69a20();
        uStack_10 = uStack_10 & 0xff;
      }
      uVar3 = 0xffffffff;
      iStack_c = 0;
      iVar4 = 0;
      if (*param_1 != 0) {
        iVar4 = *(int *)(*param_1 + 0xc);
        iVar2 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
          uVar3 = 0xffffffff;
          iVar4 = iStack_c;
        }
        else {
          iVar4 = FUN_00c699d0();
          uVar3 = FUN_00c69a20();
          uVar3 = uVar3 & 0xff;
        }
      }
      if (((int)uStack_10 < (int)uVar3) || (((int)uStack_10 <= (int)uVar3 && (iStack_14 < iVar4))))
      goto LAB_00b58a4a;
LAB_00b5896b:
      iVar4 = *param_1;
      iVar2 = param_1[1];
      *param_1 = 0;
      param_1[1] = 0;
      *param_4 = iVar4;
      piVar1 = (int *)param_4[1];
      param_4[1] = iVar2;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar4 = piVar1[1] + -1;
        piVar1[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar4 = piVar1[2] + -1;
          piVar1[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 2;
      param_4 = param_4 + 2;
      if (param_1 == param_2) {
        FUN_00775350(piStack_8,param_3,param_4);
        return;
      }
    }
    iStack_14 = -0x80000000;
    if ((iVar4 != 0) &&
       (iVar4 = *(int *)(iVar4 + 0xc), iVar2 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      iStack_14 = FUN_00c699d0();
    }
    if (*param_1 == 0) {
      iVar4 = -0x80000000;
    }
    else {
      iVar4 = *(int *)(*param_1 + 0xc);
      iVar2 = FUN_00c68a10();
      if ((uint)*(ushort *)(iVar2 + 0x1da) <
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
        iVar4 = -0x80000000;
      }
      else {
        iVar4 = FUN_00c699d0();
      }
    }
    if (iVar4 <= iStack_14) goto LAB_00b5896b;
LAB_00b58a4a:
    iVar4 = *piStack_8;
    iVar2 = piStack_8[1];
    *piStack_8 = 0;
    piStack_8[1] = 0;
    *param_4 = iVar4;
    piVar1 = (int *)param_4[1];
    param_4[1] = iVar2;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piStack_8 = piStack_8 + 2;
    param_4 = param_4 + 2;
    if (piStack_8 == param_3) {
      FUN_00775350(param_1,param_2,param_4);
      return;
    }
  } while( true );
}



/* FUNCTION 24348 ; VA 0x00b58ad0 ; FUN_00b58ad0 */

int __thiscall FUN_00b58ad0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f42b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ScreenGui*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24349 ; VA 0x00b58ba2 ; Catch_All@00b58ba2 */

void Catch_All_00b58ba2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24350 ; VA 0x00b58bc0 ; FUN_00b58bc0 */

int __thiscall FUN_00b58bc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f42c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TextLabel*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24351 ; VA 0x00b58c92 ; Catch_All@00b58c92 */

void Catch_All_00b58c92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24352 ; VA 0x00b58cb0 ; FUN_00b58cb0 */

void FUN_00b58cb0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5,
                 undefined4 param_6)

{
  int iVar1;
  int iVar2;
  
  if (param_3 < 0x21) {
    FUN_00b57f80(param_1,param_2,param_6);
    return;
  }
  iVar2 = param_3 >> 1;
  param_3 = param_3 - iVar2;
  iVar1 = param_1 + param_3 * 8;
  if (param_5 < param_3) {
    FUN_00b58cb0(param_1,iVar1,param_3,param_4,param_5,param_6);
    FUN_00b58cb0(param_1 + param_3 * 8,param_2,iVar2,param_4,param_5,param_6);
  }
  else {
    FUN_00b57590(param_1,iVar1,param_3,param_4);
    FUN_00b57590(param_1 + param_3 * 8,param_2,iVar2,param_4,param_6);
  }
  FUN_00b57120(param_1,param_1 + param_3 * 8,param_2,param_3,iVar2,param_4,param_5,param_6);
  return;
}



/* FUNCTION 24353 ; VA 0x00b58d60 ; FUN_00b58d60 */

undefined4 FUN_00b58d60(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4278;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = param_2;
  do {
    while (piVar7 = piVar5, piVar6 = param_4, iVar3 = *piVar7, DAT_01d6889c == '\0') {
      param_4 = (int *)0x80000000;
      if ((iVar3 != 0) &&
         (iVar3 = *(int *)(iVar3 + 0xc), iVar1 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
         (uint)*(ushort *)(iVar1 + 0x1da))) {
        param_4 = (int *)FUN_00c699d0();
      }
      if (*param_1 == 0) {
        iVar3 = -0x80000000;
      }
      else {
        iVar3 = *(int *)(*param_1 + 0xc);
        iVar1 = FUN_00c68a10();
        if ((uint)*(ushort *)(iVar1 + 0x1da) <
            (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) {
          iVar3 = -0x80000000;
        }
        else {
          iVar3 = FUN_00c699d0();
        }
      }
      if ((int)param_4 < iVar3) goto LAB_00b58f6f;
LAB_00b58e71:
      *piVar6 = 0;
      piVar6[1] = 0;
      *piVar6 = *param_1;
      piVar6[1] = param_1[1];
      *param_1 = 0;
      param_1[1] = 0;
      param_1 = param_1 + 2;
      param_4 = piVar6 + 2;
      piVar8 = param_3;
      piVar5 = piVar7;
      if (param_1 == param_2) goto LAB_00b58eaf;
    }
    uStack_14 = 0xffffffff;
    iStack_18 = 0;
    if ((iVar3 != 0) &&
       (iVar3 = *(int *)(iVar3 + 0xc), iVar1 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
       (uint)*(ushort *)(iVar1 + 0x1da))) {
      iStack_18 = FUN_00c699d0();
      uStack_14 = FUN_00c69a20();
      uStack_14 = uStack_14 & 0xff;
    }
    uVar2 = 0xffffffff;
    param_4 = (int *)0x0;
    iVar3 = 0;
    if (*param_1 != 0) {
      iVar3 = *(int *)(*param_1 + 0xc);
      iVar1 = FUN_00c68a10();
      if ((uint)*(ushort *)(iVar1 + 0x1da) <
          (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) {
        uVar2 = 0xffffffff;
        iVar3 = (int)param_4;
      }
      else {
        iVar3 = FUN_00c699d0();
        uVar2 = FUN_00c69a20();
        uVar2 = uVar2 & 0xff;
      }
    }
    if (((int)uVar2 <= (int)uStack_14) && (((int)uVar2 < (int)uStack_14 || (iVar3 <= iStack_18))))
    goto LAB_00b58e71;
LAB_00b58f6f:
    *piVar6 = 0;
    piVar6[1] = 0;
    *piVar6 = *piVar7;
    piVar6[1] = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    piVar5 = piVar7 + 2;
    param_4 = piVar6 + 2;
    piVar7 = param_1;
    piVar8 = param_2;
  } while (piVar5 != param_3);
LAB_00b58eaf:
  uVar4 = FUN_00b58fc0(piVar7,piVar8,piVar6 + 2);
  FUN_00b5a770();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 24354 ; VA 0x00b58fc0 ; FUN_00b58fc0 */

undefined4 * FUN_00b58fc0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_1 != param_2) {
    iVar3 = (int)param_3 - (int)param_1;
    puVar2 = param_1 + 1;
    do {
      *param_3 = 0;
      *(undefined4 *)((int)puVar2 + iVar3) = 0;
      puVar1 = puVar2 + 1;
      *param_3 = puVar2[-1];
      param_3 = param_3 + 2;
      *(undefined4 *)((int)puVar2 + iVar3) = *puVar2;
      puVar2[-1] = 0;
      *puVar2 = 0;
      puVar2 = puVar2 + 2;
    } while (puVar1 != param_2);
  }
  FUN_00b5a770();
  return param_3;
}



/* FUNCTION 24355 ; VA 0x00b59030 ; FUN_00b59030 */

undefined FUN_00b59030(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f42ef;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 24356 ; VA 0x00b59190 ; FUN_00b59190 */

undefined FUN_00b59190(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f431f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 24357 ; VA 0x00b592f0 ; FUN_00b592f0 */

undefined FUN_00b592f0(uint param_1,undefined4 param_2,uint param_3,uint param_4,uint param_5,
                      uint param_6,undefined8 param_7,undefined4 *param_8)

{
  uint *puVar1;
  undefined uVar2;
  uint uStack_54;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4357;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    uStack_54 = param_1;
    if ((param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_4c,0);
    }
    else {
      uStack_4c = param_3;
      uStack_48 = param_4;
      uStack_44 = param_5;
      uStack_40 = param_6;
      uStack_3c = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  if (uStack_54 == 0) {
    uVar2 = 0;
  }
  else {
    uStack_34 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_2c,0);
    }
    else {
      uStack_2c = uStack_4c;
      uStack_28 = uStack_48;
      uStack_24 = uStack_44;
      uStack_20 = uStack_40;
      uStack_1c = uStack_3c;
    }
    uStack_8._0_1_ = 2;
    puVar1 = (uint *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar1;
    if (puVar1 == (uint *)0x0) {
      puVar1 = (uint *)0x0;
    }
    else {
      *puVar1 = 0;
      if (uStack_34 != 0) {
        *puVar1 = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar1 + 2,0);
        }
        else {
          puVar1[2] = uStack_2c;
          puVar1[3] = uStack_28;
          puVar1[4] = uStack_24;
          puVar1[5] = uStack_20;
          *(undefined8 *)(puVar1 + 6) = uStack_1c;
        }
      }
    }
    *param_8 = puVar1;
    uStack_8._0_1_ = 4;
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      uStack_34 = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
       (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uVar2 = 1;
  }
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    param_8._3_1_ = uVar2;
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_8._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 24358 ; VA 0x00b594b0 ; FUN_00b594b0 */

int FUN_00b594b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4378;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00636b00();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_00634830(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
        uVar4 = FUN_006352d0();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24359 ; VA 0x00b59600 ; FUN_00b59600 */

undefined4 * FUN_00b59600(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f43c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c68a10();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x280);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c68ef0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b58ad0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24360 ; VA 0x00b596c0 ; FUN_00b596c0 */

undefined4 * FUN_00b596c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4403;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ea39d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x548);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ea3ad0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b58bc0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24361 ; VA 0x00b59780 ; FUN_00b59780 */

void FUN_00b59780(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00d88a30();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 24362 ; VA 0x00b597e0 ; FUN_00b597e0 */

int FUN_00b597e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00e956e0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 24363 ; VA 0x00b59820 ; FUN_00b59820 */

int FUN_00b59820(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c6de80();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 24364 ; VA 0x00b59860 ; FUN_00b59860 */

int FUN_00b59860(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00dcddb0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 24365 ; VA 0x00b598a0 ; FUN_00b598a0 */

int FUN_00b598a0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ee0bf8,&LAB_008e0e50);
      uVar3 = FUN_008e3c20();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00e45c50();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 24366 ; VA 0x00b599b0 ; FUN_00b599b0 */

int __fastcall FUN_00b599b0(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00dcddb0();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 24367 ; VA 0x00b599f0 ; FUN_00b599f0 */

int FUN_00b599f0(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iStack_c;
  uint uStack_8;
  
  iVar2 = param_2 - param_1 >> 3;
joined_r0x00b59a04:
  do {
    iVar1 = iVar2;
    if (iVar1 < 1) {
      return param_1;
    }
    iVar2 = iVar1 >> 1;
    iVar5 = *(int *)(param_1 + iVar2 * 8);
    if (DAT_01d6889c == '\0') goto LAB_00b59af8;
    uStack_8 = 0xffffffff;
    iStack_c = 0;
    if ((iVar5 != 0) &&
       (iVar5 = *(int *)(iVar5 + 0xc), iVar3 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      iStack_c = FUN_00c699d0();
      uStack_8 = FUN_00c69a20();
      uStack_8 = uStack_8 & 0xff;
    }
    uVar6 = 0xffffffff;
    param_2 = 0;
    iVar5 = 0;
    if ((*param_3 != 0) &&
       (iVar3 = *(int *)(*param_3 + 0xc), iVar4 = FUN_00c68a10(), iVar5 = param_2,
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      iVar5 = FUN_00c699d0();
      uVar6 = FUN_00c69a20();
      uVar6 = uVar6 & 0xff;
    }
  } while (((int)uVar6 <= (int)uStack_8) && (((int)uVar6 < (int)uStack_8 || (iVar5 <= iStack_c))));
  goto LAB_00b59b7d;
LAB_00b59af8:
  param_2 = -0x80000000;
  if ((iVar5 != 0) &&
     (iVar5 = *(int *)(iVar5 + 0xc), iVar3 = FUN_00c68a10(),
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    param_2 = FUN_00c699d0();
  }
  iVar5 = -0x80000000;
  if (*param_3 != 0) {
    iVar5 = *(int *)(*param_3 + 0xc);
    iVar3 = FUN_00c68a10();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      iVar5 = -0x80000000;
    }
    else {
      iVar5 = FUN_00c699d0();
    }
  }
  if (param_2 < iVar5) {
LAB_00b59b7d:
    param_1 = param_1 + iVar2 * 8 + 8;
    iVar2 = iVar1 + (-1 - iVar2);
  }
  goto joined_r0x00b59a04;
}



/* FUNCTION 24368 ; VA 0x00b59ba0 ; FUN_00b59ba0 */

void FUN_00b59ba0(uint param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000024;
  undefined4 *in_stack_00000028;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined *puStack_ec;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = in_stack_00000024;
  puStack_c = &LAB_017f442b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != (undefined4 *)0x0) {
    puStack_ec = auStack_dc;
    puStack_f0 = &stack0x0000002c;
    puStack_f4 = (undefined *)0xb59bef;
    ExceptionList = &pvStack_10;
    (*(code *)*in_stack_00000028)();
  }
  puVar2 = in_stack_00000028;
  puStack_14 = (undefined *)&uStack_1b8;
  uStack_8._0_1_ = 2;
  uStack_1b8 = uVar1;
  puStack_1b4 = (undefined4 *)0x0;
  puVar3 = &uStack_1b8;
  if (in_stack_00000028 != (undefined4 *)0x0) {
    (*(code *)*in_stack_00000028)(auStack_dc,auStack_1b0);
    puVar3 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar3;
  puStack_1b4 = puVar2;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  if (puVar2 != (undefined4 *)0x0) {
    puStack_ec = auStack_dc;
    puStack_f0 = (undefined *)0xb59c60;
    (*(code *)puVar2[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined *)0x2;
    uStack_f8 = 0xb59c84;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (in_stack_00000028 != (undefined4 *)0x0) {
    puStack_ec = &stack0x0000002c;
    puStack_f0 = (undefined *)0xb59ca5;
    (*(code *)in_stack_00000028[2])();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24369 ; VA 0x00b59cc0 ; thunk_FUN_00b61fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b61fb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4f96;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefdec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefdec);
    if (DAT_01eefdec == -1) {
      uStack_8 = 0;
      FUN_009ca470("CoreGuiType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eefd88 = RBX::Reflection::EnumDesc<enum_RBX::StarterGuiService::CoreGuiType>::vftable;
      FUN_009caf20(&DAT_01d670dc,6);
      FUN_016f3654(&LAB_0188e320);
      FUN_016f37bf(&DAT_01eefdec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eefd88;
}



/* FUNCTION 24370 ; VA 0x00b59cd0 ; FUN_00b59cd0 */

int * FUN_00b59cd0(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iStack_10;
  uint uStack_c;
  
  iVar3 = param_2 - (int)param_1 >> 3;
joined_r0x00b59ce4:
  do {
    iVar2 = iVar3;
    if (iVar2 < 1) {
      return param_1;
    }
    iVar3 = iVar2 >> 1;
    piVar1 = param_1 + iVar3 * 2;
    iVar6 = *param_3;
    if (DAT_01d6889c == '\0') goto LAB_00b59de5;
    uStack_c = 0xffffffff;
    iStack_10 = 0;
    if ((iVar6 != 0) &&
       (iVar6 = *(int *)(iVar6 + 0xc), iVar4 = FUN_00c68a10(),
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      iStack_10 = FUN_00c699d0();
      uStack_c = FUN_00c69a20();
      uStack_c = uStack_c & 0xff;
    }
    uVar7 = 0xffffffff;
    param_2 = 0;
    iVar6 = 0;
    if ((*piVar1 != 0) &&
       (iVar4 = *(int *)(*piVar1 + 0xc), iVar5 = FUN_00c68a10(), iVar6 = param_2,
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
       (uint)*(ushort *)(iVar5 + 0x1da))) {
      iVar6 = FUN_00c699d0();
      uVar7 = FUN_00c69a20();
      uVar7 = uVar7 & 0xff;
    }
  } while (((int)uStack_c < (int)uVar7) || (((int)uStack_c <= (int)uVar7 && (iStack_10 < iVar6))));
  goto LAB_00b59dc3;
LAB_00b59de5:
  param_2 = -0x80000000;
  if ((iVar6 != 0) &&
     (iVar6 = *(int *)(iVar6 + 0xc), iVar4 = FUN_00c68a10(),
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    param_2 = FUN_00c699d0();
  }
  iVar6 = -0x80000000;
  if (*piVar1 != 0) {
    iVar6 = *(int *)(*piVar1 + 0xc);
    iVar4 = FUN_00c68a10();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
      iVar6 = -0x80000000;
    }
    else {
      iVar6 = FUN_00c699d0();
    }
  }
  if (iVar6 <= param_2) {
LAB_00b59dc3:
    param_1 = piVar1 + 2;
    iVar3 = iVar2 + (-1 - iVar3);
  }
  goto joined_r0x00b59ce4;
}



/* FUNCTION 24371 ; VA 0x00b59e80 ; FUN_00b59e80 */

undefined4 FUN_00b59e80(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b59ffd:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b59ffd;
  }
  iVar2 = FUN_00b61fb0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b59fa8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b61fb0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b56c80(&param_3);
      iVar4 = FUN_00b61fb0();
      iStack_ec = iVar4;
      iVar5 = FUN_00b61fb0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b59fa8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b61fb0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 24372 ; VA 0x00b5a080 ; FUN_00b5a080 */

undefined4 * __fastcall FUN_00b5a080(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f449e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::BasePlayerGui,class_RBX::Instance>::vftable;
  uVar1 = FUN_00b56cd0();
  param_1[3] = uVar1;
  param_1[0x15] = RBX::IScriptFilter::vftable;
  *param_1 = RBX::BasePlayerGui::vftable;
  param_1[0x15] = RBX::BasePlayerGui::vftable;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  *(undefined *)(param_1 + 0x19) = 1;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    puVar2[1] = 0;
    puVar2[2] = 0;
    *puVar2 = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[3] = 0;
    puStack_18 = puVar2 + 6;
    puVar2[7] = 0;
    puVar2[8] = 0;
    *puStack_18 = 0;
  }
  uStack_8._0_1_ = 3;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  FUN_008aafb0(puVar2,puStack_18);
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  param_1[0x21] = (uint)(DAT_01d670d4 != '\0') * 2 + 2;
  if (DAT_01ee41ef != '\0') {
    FUN_016774b0(DAT_01ee41ef,"BasePlayerGui created: %p",param_1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24373 ; VA 0x00b5a1e0 ; FUN_00b5a1e0 */

undefined4 * __fastcall FUN_00b5a1e0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f44f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b5a080();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CoreGuiService,class_RBX::BasePlayerGui>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::CoreGuiService,class_RBX::BasePlayerGui>::vftable;
  uVar1 = FUN_00b56db0();
  param_1[3] = uVar1;
  *(undefined *)(param_1 + 0x22) = 1;
  *param_1 = RBX::CoreGuiService::vftable;
  param_1[0x15] = RBX::CoreGuiService::vftable;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  *(undefined *)(param_1 + 0x25) = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 5;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("CoreGui",7);
  uStack_8._0_1_ = 5;
  FUN_008a6520(auStack_2c);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_00714e40(3,param_1 + 0x29);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24374 ; VA 0x00b5a320 ; FUN_00b5a320 */

undefined4 * __fastcall FUN_00b5a320(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4526;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b5a080();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::PlayerGui,class_RBX::BasePlayerGui>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::PlayerGui,class_RBX::BasePlayerGui>::vftable;
  uVar1 = FUN_00b56e90();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::PlayerGui::vftable;
  param_1[0x15] = RBX::PlayerGui::vftable;
  param_1[0x22] = 0x3f000000;
  *(undefined *)(param_1 + 0x23) = 1;
  FUN_01682800(param_1 + 0x24);
  param_1[0x26] = 0;
  uVar1 = 0;
  uStack_8._0_1_ = 2;
  if (DAT_01d670d4 != '\0') {
    uVar1 = 4;
  }
  uStack_1c = 0;
  param_1[0x27] = uVar1;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("PlayerGui",9);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24375 ; VA 0x00b5a440 ; FUN_00b5a440 */

undefined4 * __fastcall FUN_00b5a440(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined **ppuVar2;
  int iVar3;
  undefined **ppuVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f458e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00b5a080();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::StarterGuiService,class_RBX::BasePlayerGui>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::StarterGuiService,class_RBX::BasePlayerGui>::vftable;
  uVar1 = FUN_00b56f90();
  param_1[3] = uVar1;
  *(undefined *)(param_1 + 0x22) = 1;
  *param_1 = RBX::StarterGuiService::vftable;
  param_1[0x15] = RBX::StarterGuiService::vftable;
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x23) = 0;
  iStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_14);
  ppuVar4 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar2;
  }
  param_1[0x24] = *ppuVar4;
  param_1[0x25] = 0;
  param_1[0x26] = 0x3f800000;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  *(undefined *)(param_1 + 0x29) = 0;
  iStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_14);
  ppuVar4 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar2;
  }
  param_1[0x2a] = *ppuVar4;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0x3f800000;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  *(undefined *)(param_1 + 0x2f) = 0;
  iStack_14 = 0xb;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&iStack_14);
  ppuVar4 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar2;
  }
  param_1[0x30] = *ppuVar4;
  param_1[0x31] = 0;
  param_1[0x32] = 0x3f800000;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  *(undefined2 *)(param_1 + 0x37) = 0x101;
  *(undefined *)((int)param_1 + 0xde) = 0;
  uStack_8._0_1_ = 6;
  param_1[0x38] = (uint)(DAT_01d670d4 != '\0') * 2 + 2;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("StarterGui",10);
  uStack_8._0_1_ = 7;
  FUN_008a6520(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  iVar7 = 0;
  do {
    iStack_14 = iVar7;
    iVar3 = FUN_00b5abd0(&iStack_14);
    iVar7 = iVar7 + 1;
    *(undefined *)(iVar3 + 4) = 1;
  } while (iVar7 < 6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24376 ; VA 0x00b5a690 ; FUN_00b5a690 */

void __fastcall FUN_00b5a690(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),1);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 24377 ; VA 0x00b5a700 ; FUN_00b5a700 */

void __fastcall FUN_00b5a700(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PlayerGui>::vftable;
  uVar1 = FUN_00b56e90(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24378 ; VA 0x00b5a740 ; thunk_FUN_00b5a8b0 */

void __fastcall thunk_FUN_00b5a8b0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BasePlayerGui::vftable;
  param_1[0x15] = RBX::BasePlayerGui::vftable;
  if (DAT_01ee41ef != '\0') {
    FUN_016774b0(DAT_01ee41ef,"BasePlayerGui destroyed: %p",param_1);
  }
  piVar2 = (int *)param_1[0x20];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1e];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00577ac0();
  piVar2 = (int *)param_1[0x18];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24379 ; VA 0x00b5a750 ; FUN_00b5a750 */

void __fastcall FUN_00b5a750(undefined4 *param_1)

{
  if (0x200 < (uint)param_1[1]) {
    FUN_01674ea0(*param_1);
  }
  return;
}



/* FUNCTION 24380 ; VA 0x00b5a770 ; FUN_00b5a770 */

void __fastcall FUN_00b5a770(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1[1];
  for (iVar4 = *param_1; iVar4 != iVar1; iVar4 = iVar4 + 8) {
    piVar2 = *(int **)(iVar4 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 24381 ; VA 0x00b5a7c0 ; FUN_00b5a7c0 */

void __fastcall FUN_00b5a7c0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00b59780(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x40);
  }
  return;
}



/* FUNCTION 24382 ; VA 0x00b5a7f0 ; FUN_00b5a7f0 */

void __fastcall FUN_00b5a7f0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b59780(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 24383 ; VA 0x00b5a8a0 ; FUN_00b5a8a0 */

void __fastcall FUN_00b5a8a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b59780(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x40);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 24384 ; VA 0x00b5a8b0 ; FUN_00b5a8b0 */

void __fastcall FUN_00b5a8b0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::BasePlayerGui::vftable;
  param_1[0x15] = RBX::BasePlayerGui::vftable;
  if (DAT_01ee41ef != '\0') {
    FUN_016774b0(DAT_01ee41ef,"BasePlayerGui destroyed: %p",param_1);
  }
  piVar2 = (int *)param_1[0x20];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x1e];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00577ac0();
  piVar2 = (int *)param_1[0x18];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24385 ; VA 0x00b5a980 ; FUN_00b5a980 */

int * __thiscall FUN_00b5a980(byte *param_1,int param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  byte *pbVar8;
  undefined4 *puVar9;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f45b0;
  pvStack_10 = ExceptionList;
  pbVar8 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_0055c740(pbVar8,param_2);
  FUN_008992d0(&param_2,uStack_14,iVar4,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar3 = (int *)FUN_01674e20(0x40);
  piStack_18 = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_20 = piVar3;
  FUN_0170d1f0(piStack_18,0,0x38);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  piVar3[9] = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  piVar3[0xd] = 0;
  piVar3[0xe] = 0;
  piVar3[8] = (int)RBX::Lua::WeakFunctionRef::vftable;
  piVar3[0xf] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar7 = uStack_28 + 1;
    iVar4 = aiStack_3c[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_3c[0] + -4);
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = 1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    iVar4 = FUN_005c9310(uVar5 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar9;
      while (puVar2 != (undefined4 *)0x0) {
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar6 = (int)puVar9;
          puVar9 = puVar2;
        }
        else {
          *puVar9 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar3[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar9 = piVar6;
    *piVar3 = *piVar6;
  }
  else {
    *piVar3 = *piVar6;
    piVar6 = (int *)*puVar9;
  }
  *piVar6 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 24386 ; VA 0x00b5abd0 ; FUN_00b5abd0 */

uint * __thiscall FUN_00b5abd0(int param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f45c8;
  pvStack_10 = ExceptionList;
  uVar3 = *param_2;
  uVar11 = uVar3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar11 * 4);
    if (puVar8 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)*puVar8;
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      if (uVar3 == puVar8[1]) {
        if (uVar3 == puVar8[2]) {
          if (puVar8 != (undefined4 *)0x0) {
            return puVar8 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar8[1] % *(uint *)(param_1 + 4) != uVar11) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_01674e20(0x10);
  puVar1 = (uint *)(piVar6 + 2);
  *piVar6 = 0;
  piVar6[1] = 0;
  puVar1[0] = 0;
  puVar1[1] = 0;
  *puVar1 = uVar3;
  if (piVar6 + 3 != (int *)0x0) {
    *(undefined *)(piVar6 + 3) = 0;
  }
  uVar4 = *(uint *)(param_1 + 8);
  uVar11 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar11 = FUN_005c9310(uVar11);
    if (uVar11 <= *(uint *)(param_1 + 4)) {
      uVar11 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar11);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar11) {
    uVar9 = uVar4 >> 1;
    if (uVar4 + (uVar4 >> 1) <= uVar11) {
      uVar9 = 1;
    }
    iVar7 = FUN_005c9310(uVar9 + *(int *)(param_1 + 8));
    if (iVar7 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar5 = (undefined4 *)*puVar8;
      while (puVar5 != (undefined4 *)0x0) {
        uVar11 = (uint)puVar5[1] % *(uint *)(param_1 + 4);
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar11 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar11 * 4) == 0) {
          *piVar2 = (int)puVar8;
          puVar8 = puVar5;
        }
        else {
          *puVar8 = *puVar5;
          *puVar5 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar5;
        }
        puVar5 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar6[1] = uVar3;
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar3 % *(uint *)(param_1 + 4)) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar10 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar6;
    }
    *piVar2 = (int)piVar10;
    *piVar6 = *piVar10;
  }
  else {
    *piVar6 = *(int *)*piVar2;
    piVar10 = (int *)*piVar2;
  }
  *piVar10 = (int)piVar6;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 24387 ; VA 0x00b5abf5 ; FUN_00b5abf5 */

undefined4 * __fastcall FUN_00b5abf5(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 in_EAX;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint unaff_EBX;
  int unaff_EBP;
  
  uVar10 = (uint)(CONCAT44(param_2,in_EAX) % (ulonglong)*(uint *)(param_1 + 4));
  if (*(int *)(param_1 + 8) != 0) {
    puVar7 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar10 * 4);
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puVar7 = (undefined4 *)*puVar7;
    }
    for (; puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
      if (unaff_EBX == puVar7[1]) {
        if (unaff_EBX == puVar7[2]) {
          if (puVar7 != (undefined4 *)0x0) {
            ExceptionList = *(void **)(unaff_EBP + -0xc);
            return puVar7 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar7[1] % *(uint *)(param_1 + 4) != uVar10) break;
    }
  }
  *(undefined4 *)(unaff_EBP + -0x18) = 0;
  *(uint *)(unaff_EBP + -0x1c) = -(uint)(param_1 != -3) & param_1 + 4U;
  *(undefined4 *)(unaff_EBP + -4) = 0;
  *(undefined2 *)(unaff_EBP + -0x14) = 0;
  piVar5 = (int *)FUN_01674e20(0x10);
  *(undefined *)(unaff_EBP + -0x14) = 1;
  puVar1 = (uint *)(piVar5 + 2);
  *(int **)(unaff_EBP + -0x18) = piVar5;
  *(uint **)(unaff_EBP + -0x10) = puVar1;
  *piVar5 = 0;
  piVar5[1] = 0;
  puVar1[0] = 0;
  puVar1[1] = 0;
  *puVar1 = unaff_EBX;
  if (piVar5 + 3 != (int *)0x0) {
    *(undefined *)(piVar5 + 3) = 0;
  }
  iVar6 = *(int *)(param_1 + 0x14);
  uVar3 = *(uint *)(param_1 + 8);
  *(undefined *)(unaff_EBP + -0x13) = 1;
  uVar10 = uVar3 + 1;
  if (iVar6 == 0) {
    uVar10 = FUN_005c9310(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    *(undefined4 *)(unaff_EBP + 8) = 1;
    uVar8 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar10) {
      uVar8 = *(uint *)(unaff_EBP + 8);
    }
    iVar6 = FUN_005c9310(uVar8 + *(int *)(param_1 + 8));
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar7 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar7;
      while (puVar4 != (undefined4 *)0x0) {
        uVar10 = (uint)puVar4[1] % *(uint *)(param_1 + 4);
        piVar5 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar10 * 4) == 0) {
          *piVar5 = (int)puVar7;
          puVar7 = puVar4;
        }
        else {
          *puVar7 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar5;
          *(undefined4 **)*piVar5 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar7;
      }
      piVar5 = *(int **)(unaff_EBP + -0x18);
    }
  }
  piVar5[1] = unaff_EBX;
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (unaff_EBX % *(uint *)(param_1 + 4)) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *piVar2 = (int)piVar9;
    *piVar5 = *piVar9;
  }
  else {
    *piVar5 = *(int *)*piVar2;
    piVar9 = (int *)*piVar2;
  }
  puVar7 = *(undefined4 **)(unaff_EBP + -0x10);
  *piVar9 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return puVar7;
}



/* FUNCTION 24388 ; VA 0x00b5ada0 ; FUN_00b5ada0 */

int __thiscall FUN_00b5ada0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 24389 ; VA 0x00b5adf0 ; FUN_00b5adf0 */

undefined4 __thiscall FUN_00b5adf0(undefined4 param_1,byte param_2)

{
  FUN_00b5a690();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 24390 ; VA 0x00b5ae20 ; FUN_00b5ae20 */

int __thiscall FUN_00b5ae20(int param_1,byte param_2)

{
  if (*(int **)(param_1 + 0x44) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x44) + 4))(1);
  }
  FUN_005c4ac0();
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 24391 ; VA 0x00b5ae60 ; FUN_00b5ae60 */

int __thiscall FUN_00b5ae60(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),1);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 24392 ; VA 0x00b5aeb0 ; FUN_00b5aeb0 */

undefined4 __thiscall FUN_00b5aeb0(undefined4 param_1,byte param_2)

{
  FUN_00b5a8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x88);
  }
  return param_1;
}



/* FUNCTION 24393 ; VA 0x00b5aee0 ; FUN_00b5aee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b5aee0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::StarterGuiService::CoreGuiType>::vftable;
  _DAT_01eefd78 = _DAT_01eefd78 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24394 ; VA 0x00b5af10 ; FUN_00b5af10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b5af10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::BasePlayerGui::ScreenOrientation>::vftable;
  _DAT_01eefd80 = _DAT_01eefd80 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24395 ; VA 0x00b5af40 ; FUN_00b5af40 */

undefined4 * __thiscall FUN_00b5af40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::BasePlayerGui::ScreenOrientation>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 24396 ; VA 0x00b5af70 ; FUN_00b5af70 */

undefined4 * __thiscall FUN_00b5af70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::GuiObject*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 24397 ; VA 0x00b5afa0 ; FUN_00b5afa0 */

undefined4 * __thiscall FUN_00b5afa0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::BasePlayerGui::ScreenOrientation>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 24398 ; VA 0x00b5afd0 ; FUN_00b5afd0 */

int __thiscall FUN_00b5afd0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_00577ac0();
  piVar2 = *(int **)(param_1 + 0x9c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x90);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00b5a8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  return param_1;
}



/* FUNCTION 24399 ; VA 0x00b5b060 ; FUN_00b5b060 */

undefined4 * __thiscall FUN_00b5b060(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::GuiObject*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24400 ; VA 0x00b5b090 ; FUN_00b5b090 */

undefined4 * __thiscall FUN_00b5b090(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::BasePlayerGui::ScreenOrientation>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24401 ; VA 0x00b5b0c0 ; FUN_00b5b0c0 */

undefined4 __thiscall FUN_00b5b0c0(undefined4 param_1,byte param_2)

{
  FUN_016790b0();
  FUN_00b5a8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa0);
  }
  return param_1;
}



/* FUNCTION 24402 ; VA 0x00b5b100 ; FUN_00b5b100 */

undefined4 __thiscall FUN_00b5b100(undefined4 param_1,byte param_2)

{
  FUN_016790b0();
  FUN_016790b0();
  FUN_00b5a7f0();
  FUN_00b5a7f0();
  FUN_00612320();
  FUN_00b5a8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe4);
  }
  return param_1;
}



/* FUNCTION 24403 ; VA 0x00b5b160 ; thunk_FUN_00b62060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b62060(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4fb6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe54);
    if (DAT_01eefe54 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ScreenOrientation");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eefdf0 = RBX::Reflection::EnumDesc<enum_RBX::BasePlayerGui::ScreenOrientation>::vftable
      ;
      FUN_009cada0(0,"LandscapeLeft");
      FUN_009cada0(1,"LandscapeRight");
      FUN_009cada0(2,"LandscapeSensor");
      FUN_009cada0(3,"Portrait");
      FUN_009cada0(4,"Sensor");
      FUN_016f3654(&LAB_0188e340);
      FUN_016f37bf(&DAT_01eefe54);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eefdf0;
}



/* FUNCTION 24404 ; VA 0x00b5b170 ; FUN_00b5b170 */

void __thiscall FUN_00b5b170(int param_1,int param_2)

{
  if (param_2 != 0) {
    FUN_008a65e0(*(undefined4 *)(param_1 + 0x8c),0);
  }
  return;
}



/* FUNCTION 24405 ; VA 0x00b5b190 ; FUN_00b5b190 */

uint __thiscall FUN_00b5b190(int param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  bool bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 uVar11;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4a30;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00d5e4a0();
  if ((uint)*(ushort *)(iVar6 + 0x1da) <
      (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
    iVar4 = *(int *)(iVar7 + 0xc);
    iVar6 = FUN_00e95050();
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
      ExceptionList = pvStack_10;
      return (uint)*(ushort *)(iVar6 + 0x1da);
    }
  }
  iVar4 = *(int *)(iVar7 + 0xc);
  piStack_30 = (int *)&DAT_80000000;
  uStack_28 = 0xffffffff;
  iStack_2c = 0;
  iVar7 = FUN_00c68a10();
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
      (uint)*(ushort *)(iVar7 + 0x1da)) {
    if (DAT_01d6889c == '\0') {
      piStack_30 = (int *)FUN_00c699d0();
    }
    else {
      iStack_2c = FUN_00c699d0();
      uStack_28 = FUN_00c69a20();
      uStack_28 = uStack_28 & 0xff;
    }
  }
  iVar4 = *(int *)(param_1 + 0x68);
  iVar7 = *(int *)(param_1 + 0x6c);
  do {
    if (iVar7 == iVar4) {
      uVar11 = FUN_0060dcd0(auStack_24,param_2);
      uStack_8 = 1;
      uVar9 = FUN_00a63250(&param_2,*(undefined4 *)(param_1 + 0x68),uVar11);
      piVar10 = piStack_20;
LAB_00b5b34b:
      if (piVar10 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piVar10 + 1);
        uVar3 = *puVar1;
        uVar9 = *puVar1;
        *puVar1 = uVar3 - 1;
        UNLOCK();
        if (uVar3 - 1 == 0) {
          uVar9 = (**(code **)*piVar10)();
          LOCK();
          piVar2 = piVar10 + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            uVar9 = (**(code **)(*piVar10 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar9;
    }
    iStack_18 = *(int *)(iVar7 + -8);
    uStack_1c = 0xffffffff;
    iStack_14 = 0;
    piStack_20 = (int *)&DAT_80000000;
    uVar9 = 0xffffffff;
    piVar10 = (int *)&DAT_80000000;
    if ((iStack_18 != 0) &&
       (iVar6 = *(int *)(iStack_18 + 0xc), iVar8 = FUN_00c68a10(), uVar9 = uStack_1c,
       piVar10 = piStack_20,
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
       (uint)*(ushort *)(iVar8 + 0x1da))) {
      if (DAT_01d6889c == '\0') {
        piVar10 = (int *)FUN_00c699d0();
        uVar9 = uStack_1c;
      }
      else {
        iStack_14 = FUN_00c699d0();
        uVar9 = FUN_00c69a20();
        uVar9 = uVar9 & 0xff;
        piVar10 = piStack_20;
      }
    }
    if (DAT_01d6889c == '\0') {
      bVar5 = (int)piVar10 <= (int)piStack_30;
    }
    else if (((int)uStack_28 < (int)uVar9) ||
            (((int)uStack_28 <= (int)uVar9 && (iStack_2c < iStack_14)))) {
      bVar5 = false;
    }
    else {
      bVar5 = true;
    }
    if (bVar5) {
      uVar11 = FUN_0060dcd0(auStack_34,param_2);
      uStack_8 = 0;
      uVar9 = FUN_00a63250(&param_2,iVar7,uVar11);
      piVar10 = piStack_30;
      goto LAB_00b5b34b;
    }
    iVar7 = iVar7 + -8;
  } while( true );
}



/* FUNCTION 24406 ; VA 0x00b5b3b0 ; FUN_00b5b3b0 */

bool __thiscall FUN_00b5b3b0(int *param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_1 + 0x78))(param_2);
  return cVar1 == '\0';
}



/* FUNCTION 24407 ; VA 0x00b5b3d0 ; FUN_00b5b3d0 */

void FUN_00b5b3d0(undefined4 param_1,code *param_2,undefined4 param_3,uint param_4,uint *param_5,
                 uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4a58;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eef505);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0xb5b447;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00b567b0();
  uStack_8._0_1_ = 2;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xb5b52c;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a8 = param_4;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_a8 = 0xb5b553;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24408 ; VA 0x00b5b570 ; FUN_00b5b570 */

int __thiscall
FUN_00b5b570(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4a88;
  pvStack_10 = ExceptionList;
  iVar4 = 0;
  uStack_18 = 0x47435000;
  uStack_1c = 0x47435000;
  iStack_14 = 0;
  piStack_2c = (int *)0x0;
  piStack_28 = (int *)0x0;
  iStack_24 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  FUN_00b5bab0(&piStack_2c,param_1);
  piVar5 = piStack_2c;
  if (piStack_2c != piStack_28) {
    do {
      if ((param_4 == 0) || (iVar1 = *piVar5, iVar1 == param_4)) {
LAB_00b5b649:
        cVar2 = FUN_00b5f550(param_3,param_2,*piVar5,&uStack_1c,&uStack_18,iVar4);
        if (cVar2 != '\0') {
          iVar4 = *piVar5;
          iStack_14 = iVar4;
        }
      }
      else {
        if (param_5 != (int *)0x0) {
          LOCK();
          param_5[1] = param_5[1] + 1;
          UNLOCK();
        }
        iVar4 = *(int *)(iVar1 + 0x34);
        if (param_4 == iVar4) {
          cVar2 = '\x01';
        }
        else if (iVar4 == 0) {
          cVar2 = '\0';
        }
        else {
          cVar2 = FUN_00620ec0(param_4);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (param_5 != (int *)0x0) {
          LOCK();
          iVar4 = param_5[1] + -1;
          param_5[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*param_5)();
            LOCK();
            iVar4 = param_5[2] + -1;
            param_5[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*param_5 + 4))();
            }
          }
        }
        iVar4 = iStack_14;
        if (cVar2 != '\0') goto LAB_00b5b649;
      }
      piVar5 = piVar5 + 1;
    } while (piVar5 != piStack_28);
  }
  if (piStack_2c != (int *)0x0) {
    uVar3 = iStack_24 - (int)piStack_2c & 0xfffffffc;
    piVar5 = piStack_2c;
    if (0xfff < uVar3) {
      piVar5 = (int *)piStack_2c[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)piStack_2c + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar5,uVar3);
    piStack_2c = (int *)0x0;
    piStack_28 = (int *)0x0;
    iStack_24 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar5 = param_5 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 24409 ; VA 0x00b5b710 ; FUN_00b5b710 */

int FUN_00b5b710(undefined4 param_1,undefined4 param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piStack_34;
  int *piStack_30;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4ab0;
  pvStack_10 = ExceptionList;
  iVar5 = 0;
  param_3 = (int *)*param_3;
  uStack_18 = 0x47435000;
  uStack_1c = 0x47435000;
  iStack_14 = 0;
  if ((param_3 != (int *)0x0) &&
     (iVar2 = param_3[1] - *param_3 >> 0x1f, (param_3[1] - *param_3) / 0xd0 + iVar2 != iVar2)) {
    ExceptionList = &pvStack_10;
    FUN_006d07c0(param_3);
    iStack_8 = 0;
    if (piStack_34 != piStack_30) {
      do {
        iVar5 = *piStack_34;
        iVar2 = FUN_0088cdc0();
        if (iVar5 == iVar2) {
          iVar5 = *piStack_34;
          iVar2 = FUN_0088cdc0();
          if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          piVar3 = piStack_34 + 2;
          if (piStack_34[1] == 0) {
            piVar3 = (int *)0x0;
          }
          piVar6 = (int *)piVar3[1];
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar6[1] = piVar6[1] + 1;
            UNLOCK();
            piVar6 = (int *)piVar3[1];
          }
          iVar5 = *piVar3;
          iStack_8._0_1_ = 1;
          if ((iVar5 != 0) &&
             (iVar2 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00c6de80(),
             (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
             (uint)*(ushort *)(iVar4 + 0x1da))) {
            iVar2 = FUN_00b599b0();
            cVar1 = FUN_00c77f80();
            if (((cVar1 != '\0') || ((iVar2 != 0 && (cVar1 = FUN_00c77f80(), cVar1 != '\0')))) &&
               (cVar1 = FUN_00b5f550(param_2,param_1,iVar5,&uStack_1c,&uStack_18,iStack_14),
               cVar1 != '\0')) {
              iStack_14 = iVar5;
            }
          }
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar5 = piVar6[1] + -1;
            piVar6[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar5 = piVar6[2] + -1;
              piVar6[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        piStack_34 = piStack_34 + 0x34;
        iVar5 = iStack_14;
      } while (piStack_34 != piStack_30);
    }
    iStack_8 = 2;
    FUN_00577b20();
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24410 ; VA 0x00b5b8b0 ; FUN_00b5b8b0 */

undefined4 FUN_00b5b8b0(undefined4 param_1,float *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (DAT_01d6ecc8 == '\0') {
    if ((DAT_018ce2f0 < param_2[1]) && (iVar2 = FUN_00c76f80(), iVar2 != 0)) {
      FUN_00c76f80();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c76f80();
        return uVar3;
      }
    }
    if ((param_2[1] <= 0.0 && param_2[1] != 0.0) && (iVar2 = FUN_00c77070(), iVar2 != 0)) {
      FUN_00c77070();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c77070();
        return uVar3;
      }
    }
    if ((DAT_018ce2f0 < *param_2) && (iVar2 = FUN_00c77020(), iVar2 != 0)) {
      FUN_00c77020();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c77020();
        return uVar3;
      }
    }
    if (0.0 < *param_2 || *param_2 == 0.0) {
      return 0;
    }
  }
  else {
    if (((NAN(*param_2) != (*param_2 == 0.0)) &&
        ((NAN(param_2[1]) || NAN(DAT_018ce2f8)) != (param_2[1] == DAT_018ce2f8))) &&
       (iVar2 = FUN_00c76f80(), iVar2 != 0)) {
      FUN_00c76f80();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c76f80();
        return uVar3;
      }
    }
    if (((NAN(*param_2) != (*param_2 == 0.0)) &&
        ((NAN(param_2[1]) || NAN(DAT_018f7864)) != (param_2[1] == DAT_018f7864))) &&
       (iVar2 = FUN_00c77070(), iVar2 != 0)) {
      FUN_00c77070();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c77070();
        return uVar3;
      }
    }
    if ((((NAN(*param_2) || NAN(DAT_018ce2f8)) != (*param_2 == DAT_018ce2f8)) &&
        (NAN(param_2[1]) != (param_2[1] == 0.0))) && (iVar2 = FUN_00c77020(), iVar2 != 0)) {
      FUN_00c77020();
      cVar1 = FUN_00c77f80();
      if (cVar1 != '\0') {
        uVar3 = FUN_00c77020();
        return uVar3;
      }
    }
    if ((NAN(*param_2) || NAN(DAT_018f7864)) == (*param_2 == DAT_018f7864)) {
      return 0;
    }
    if (NAN(param_2[1]) == (param_2[1] == 0.0)) {
      return 0;
    }
  }
  iVar2 = FUN_00c76fd0();
  if (iVar2 != 0) {
    FUN_00c76fd0();
    cVar1 = FUN_00c77f80();
    if (cVar1 != '\0') {
      uVar3 = FUN_00c76fd0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 24411 ; VA 0x00b5bab0 ; FUN_00b5bab0 */

int * FUN_00b5bab0(undefined4 param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9308;
  pvStack_10 = ExceptionList;
  if (param_2 != (int *)0x0) {
    piVar5 = (int *)param_2[0xc];
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = (int *)param_2[0xc];
    }
    param_2 = (int *)param_2[0xb];
    uStack_8 = 0;
    if ((param_2 != (int *)0x0) && (piVar6 = (int *)*param_2, piVar6 != (int *)param_2[1])) {
      do {
        if ((*piVar6 != 0) &&
           (iVar4 = *(int *)(*piVar6 + 0xc), iVar2 = FUN_00d5e4a0(),
           (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
           (uint)*(ushort *)(iVar2 + 0x1da))) {
          iVar4 = *piVar6;
          if (iVar4 == 0) {
LAB_00b5bb9b:
            iVar4 = FUN_00b597e0(iVar4);
            if (iVar4 != 0) {
              cVar1 = *(char *)(iVar4 + 0x15c);
              goto LAB_00b5bbae;
            }
          }
          else {
            iVar2 = *(int *)(iVar4 + 0xc);
            iVar3 = FUN_00c68a10();
            if ((uint)*(ushort *)(iVar3 + 0x1da) <
                (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
              iVar4 = *piVar6;
              if (iVar4 != 0) {
                iVar2 = *(int *)(iVar4 + 0xc);
                iVar3 = FUN_00e98320();
                if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                    (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_00b5bc12;
                iVar4 = *piVar6;
              }
              goto LAB_00b5bb9b;
            }
LAB_00b5bc12:
            cVar1 = *(char *)(iVar4 + 0x15c);
LAB_00b5bbae:
            if (cVar1 == '\0') goto LAB_00b5bbbd;
          }
          FUN_00d65b60(param_1);
        }
LAB_00b5bbbd:
        FUN_00b5bab0(param_1,*piVar6);
        piVar6 = piVar6 + 2;
      } while (piVar6 != (int *)param_2[1]);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar6 = piVar5 + 1;
      iVar4 = *piVar6;
      param_2 = (int *)*piVar6;
      *piVar6 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        param_2 = (int *)(**(code **)*piVar5)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar4 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          param_2 = (int *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24412 ; VA 0x00b5bc20 ; FUN_00b5bc20 */

undefined4 * __thiscall
FUN_00b5bc20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4481;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00922680;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24413 ; VA 0x00b5bdc0 ; FUN_00b5bdc0 */

undefined4 * __thiscall
FUN_00b5bdc0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4af1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b5d770;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24414 ; VA 0x00b5bf60 ; FUN_00b5bf60 */

void FUN_00b5bf60(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b61fb0();
    *param_2 = uVar3;
    iVar4 = FUN_00b62210();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24415 ; VA 0x00b5bfc0 ; FUN_00b5bfc0 */

void FUN_00b5bfc0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b62060();
    *param_2 = uVar3;
    iVar4 = FUN_00b62280();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24416 ; VA 0x00b5c020 ; FUN_00b5c020 */

void FUN_00b5c020(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b61fb0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24417 ; VA 0x00b5c060 ; FUN_00b5c060 */

void FUN_00b5c060(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b62060();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24418 ; VA 0x00b5c0a0 ; FUN_00b5c0a0 */

undefined4 * FUN_00b5c0a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_009165a0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24419 ; VA 0x00b5c110 ; FUN_00b5c110 */

void __thiscall FUN_00b5c110(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088cc80();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_005c9cc0();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24420 ; VA 0x00b5c330 ; FUN_00b5c330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b5c330(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088cc80();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088d730();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar3;
    uStack_e0 = puVar3[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead418)
       && (FUN_016f3809(&DAT_01ead418), DAT_01ead418 == -1)) {
      DAT_01ead40c = FUN_005c6620;
      _DAT_01ead410 = FUN_005c6620;
      DAT_01ead414 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead418);
    }
    puStack_e8 = &DAT_01ead40c;
    puVar3 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar3 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    puVar3 = (undefined4 *)FUN_006ea440(*(int *)(iStack_1c + 0x44));
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24421 ; VA 0x00b5c5a0 ; FUN_00b5c5a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b5c5a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_360;
  int iStack_35c;
  undefined auStack_358 [200];
  undefined4 uStack_290;
  int iStack_28c;
  undefined4 auStack_288 [50];
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4ba8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar2 = *(undefined **)(param_1 + 0x40);
  if (puVar2 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puStack_18 = &uStack_1c0;
    uVar5 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    puStack_ec = (undefined4 *)0x0;
    uStack_e8 = CONCAT31(uStack_e8._1_3_,*puVar2);
    puStack_ec = (undefined4 *)FUN_005c9ef0();
    puStack_18 = &uStack_f0;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar2 == (undefined *)0x0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar6 = &uStack_1c0;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    puStack_ec = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar6;
    uStack_e4 = puVar6[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288)
       && (FUN_016f3809(&DAT_01ead288), DAT_01ead288 == -1)) {
      DAT_01ead27c = FUN_0057bbb0;
      _DAT_01ead280 = FUN_005880a0;
      DAT_01ead284 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead288);
    }
    puStack_ec = &DAT_01ead27c;
    puVar6 = &uStack_f0;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(iStack_20 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_360 = FUN_00888530();
    iStack_35c = 0;
    puVar6 = &uStack_360;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_290 = thunk_FUN_00890320();
    iStack_28c = 0;
    auStack_288[0] = *puVar6;
    iStack_28c = FUN_00890440();
    puVar6 = &uStack_290;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar3 = thunk_FUN_00890320();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_35c != 0) {
      (**(code **)(iStack_35c + 8))(auStack_358);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_28c != 0)) {
    (**(code **)(iStack_28c + 8))(auStack_288);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24422 ; VA 0x00b5c940 ; FUN_00b5c940 */

void __thiscall FUN_00b5c940(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar6 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = *puVar6;
    puStack_e8 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)puVar6[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar6 + 2,auStack_e4);
      puVar4 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
    puStack_e8 = puVar4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24423 ; VA 0x00b5cb50 ; FUN_00b5cb50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b5cb50(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_00d88470();
    puStack_e8 = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c)
       && (FUN_016f3809(&DAT_01ee047c), DAT_01ee047c == -1)) {
      _DAT_01ee0470 = FUN_008c9370;
      _DAT_01ee0474 = FUN_008c9370;
      DAT_01ee0478 = FUN_008ca540;
      FUN_016f37bf(&DAT_01ee047c);
    }
    puStack_e8 = &DAT_01ee0470;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined *)0x0)) {
    (**(code **)(puStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24424 ; VA 0x00b5cdc0 ; FUN_00b5cdc0 */

void __thiscall FUN_00b5cdc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_00b61fb0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_00b62210();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_00b61fb0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(param_1 + 0x44);
  if (puVar1 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar1;
    iStack_1b8 = FUN_005c9ef0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24425 ; VA 0x00b5cfe0 ; FUN_00b5cfe0 */

void __fastcall FUN_00b5cfe0(int param_1)

{
  *(undefined *)(param_1 + 100) = 1;
  return;
}



/* FUNCTION 24426 ; VA 0x00b5cff0 ; FUN_00b5cff0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b5cff0(int param_1,int param_2,undefined4 param_3,double param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined8 *puVar9;
  float *pfVar10;
  uint *puVar11;
  uint uVar12;
  uint uVar13;
  undefined4 *puVar14;
  float fVar15;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  undefined auStack_4c [8];
  float fStack_44;
  float fStack_40;
  undefined auStack_34 [4];
  int *piStack_30;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4c01;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  if (param_2 < 3) {
    iVar2 = *(int *)(param_1 + 0xa4);
    piVar6 = *(int **)(iVar2 + 4 + param_2 * 8);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(iVar2 + 4 + param_2 * 8);
    }
    iStack_24 = *(int *)(iVar2 + param_2 * 8);
    uStack_8 = 0;
    piStack_20 = piVar6;
    iStack_18 = iStack_24;
    iStack_14 = param_1;
    if (iStack_24 != 0) {
      FUN_01255470(1,0,0,0);
      FUN_01255490();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00b598a0(param_1);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      FUN_00e45f30(iStack_18,piVar6,0,0);
      FUN_01255500();
    }
    uStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    iVar2 = iStack_14;
    FUN_00d5c5d0(auStack_4c);
    puVar4 = (undefined4 *)FUN_00b596c0(&iStack_24);
    uVar5 = puVar4[1];
    puVar14 = (undefined4 *)(*(int *)(iVar2 + 0xa4) + param_2 * 8);
    puVar4[1] = 0;
    uVar3 = *puVar4;
    *puVar4 = 0;
    *puVar14 = uVar3;
    piVar6 = (int *)puVar14[1];
    puVar14[1] = uVar5;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar6 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    FUN_005542c0("BottomRightControl",0x12);
    uStack_8 = 2;
    uVar5 = FUN_008a13b0(auStack_64);
    piVar6 = (int *)FUN_0060dcd0(auStack_34,uVar5);
    iStack_24 = *piVar6;
    piStack_20 = (int *)piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    uStack_8 = 2;
    piStack_1c = piStack_20;
    iStack_18 = iStack_24;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_30[1] + -1;
      piStack_30[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar2 = piStack_30[2] + -1;
        piStack_30[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if ((iStack_18 == 0) ||
       (iVar2 = *(int *)(iStack_18 + 0xc), iVar7 = FUN_00dd4970(),
       (uint)*(ushort *)(iVar7 + 0x1da) <
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
      iStack_18 = 0;
    }
    piVar6 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_50) {
      uVar13 = uStack_50 + 1;
      uVar12 = auStack_64[0];
      if (0xfff < uVar13) {
        uVar12 = *(uint *)(auStack_64[0] - 4);
        uVar13 = uStack_50 + 0x24;
        if (0x1f < (auStack_64[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar13);
    }
    iVar2 = iStack_14;
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    iVar7 = iStack_18;
    if (iStack_18 == 0) {
      iVar7 = *(int *)(iStack_14 + 0x8c);
    }
    FUN_008a65e0(iVar7,0);
    piStack_1c = *(int **)(*(int *)(iVar2 + 0xa4) + param_2 * 8);
    if ((piStack_1c != (int *)0x0) &&
       (iVar7 = *(int *)((int)piStack_1c + 0xc), iVar8 = FUN_00ea39d0(),
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
       (uint)*(ushort *)(iVar8 + 0x1da))) {
      FUN_00fab5f0(4);
      puVar9 = (undefined8 *)FUN_0115ee70();
      FUN_00fac4c0((int)*puVar9,(int)((ulonglong)*puVar9 >> 0x20),*(undefined4 *)(puVar9 + 1));
      FUN_0054ef60(param_3);
      FUN_00fac1b0();
      if (iStack_18 == 0) {
        FUN_008a65e0(*(undefined4 *)(iVar2 + 0x8c),0);
        puVar4 = (undefined4 *)FUN_00da7df0(0,300,0,0x1e);
        FUN_00c7c8c0(*puVar4,puVar4[1],puVar4[2],puVar4[3]);
        iVar8 = (int)fStack_40 + (param_2 * 5 + 10) * -4;
        fVar15 = 0.0;
        iVar7 = (int)fStack_44 + -300;
      }
      else {
        FUN_008a65e0(iStack_18,0);
        pfVar10 = (float *)FUN_00fa7a50(auStack_34);
        puVar4 = (undefined4 *)FUN_00da7df0(0,(int)*pfVar10,0x3f800000,0);
        FUN_00c7c8c0(*puVar4,puVar4[1],puVar4[2],puVar4[3]);
        puVar11 = (uint *)FUN_00fa7a50(auStack_34);
        iVar8 = 0;
        fVar15 = (float)(DAT_01955588 - ((double)param_2 + _PTR_018cf0f8));
        iVar7 = (int)(float)(*puVar11 ^ DAT_018c4ea0);
      }
      puVar4 = (undefined4 *)FUN_00da7df0(0x3f800000,iVar7,fVar15,iVar8);
      FUN_00c7c400(*puVar4,puVar4[1],puVar4[2],puVar4[3]);
      puVar9 = (undefined8 *)FUN_0115e910();
      FUN_00c7bb90((int)*puVar9,(int)((ulonglong)*puVar9 >> 0x20),*(undefined4 *)(puVar9 + 1));
      FUN_00c7bce0(0x3f000000);
      FUN_00c7beb0(0);
    }
    if ((NAN(param_4) || NAN(_PTR_018c6f48)) == (param_4 == _PTR_018c6f48)) {
      FUN_01255470(1,0,0,0);
      FUN_01255490();
      uStack_8 = 5;
      FUN_00b598a0(iVar2);
      puVar4 = (undefined4 *)(*(int *)(iVar2 + 0xa4) + param_2 * 8);
      if (puVar4[1] != 0) {
        LOCK();
        piVar6 = (int *)(puVar4[1] + 4);
        *piVar6 = *piVar6 + 1;
        UNLOCK();
      }
      FUN_00e45f30(*puVar4,puVar4[1],SUB84(param_4,0),(int)((ulonglong)param_4 >> 0x20));
      FUN_01255500();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24427 ; VA 0x00b5d580 ; FUN_00b5d580 */

int FUN_00b5d580(void)

{
  int *piVar1;
  int iVar2;
  int **ppiVar3;
  uint uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  int extraout_ECX;
  int *piVar8;
  uint uVar9;
  int aiStack_1028 [1020];
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int **ppiStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4c2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f40d0();
  piVar1 = (int *)(extraout_ECX + 0x68);
  *(undefined *)(extraout_ECX + 100) = 0;
  ppiStack_24 = *(int ***)(extraout_ECX + 0x6c);
  piStack_28 = (int *)*piVar1;
  piStack_2c = (int *)0xb5d5bc;
  piStack_20 = piVar1;
  FUN_005596d0();
  *(int *)(extraout_ECX + 0x6c) = *piVar1;
  piStack_34 = (int *)0xb5d5c8;
  iStack_30 = extraout_ECX;
  piStack_2c = piVar1;
  FUN_00b5e470();
  iVar7 = *(int *)(extraout_ECX + 0x6c);
  piVar1 = (int *)*piVar1;
  piVar8 = (int *)(iVar7 - (int)piVar1 >> 3);
  if ((int)piVar8 < 0x21) {
    if (1 < (int)piVar8) {
      piStack_2c = (int *)&stack0xffffffec;
      iStack_30 = 0xb5d5f6;
      piStack_28 = piVar1;
      ppiStack_24 = (int **)iVar7;
      piStack_20 = piVar8;
      FUN_00b58410();
    }
  }
  else {
    uVar9 = (int)piVar8 - (iVar7 - (int)piVar1 >> 4);
    uVar4 = 0x7fffffff;
    if ((int)uVar9 < 0x7fffffff) {
      uVar4 = uVar9;
    }
    if (0x200 < uVar9) {
      uVar9 = uVar4;
      if (uVar4 < 0x20000000) {
        for (; 0 < (int)uVar9; uVar9 = (int)uVar9 / 2) {
          ppiStack_24 = (int **)(uVar9 * 8);
          piStack_20 = (int *)&DAT_021133ac;
          piStack_28 = (int *)0xb5d635;
          piVar5 = (int *)FUN_01674e50();
          if (piVar5 != (int *)0x0) {
            if (0x200 < uVar9) goto LAB_00b5d663;
            goto LAB_00b5d64f;
          }
        }
      }
      piVar5 = (int *)0x0;
LAB_00b5d64f:
      ppiStack_24 = (int **)0xb5d655;
      piStack_20 = piVar5;
      FUN_01674ea0();
      uVar9 = 0x200;
    }
    piVar5 = aiStack_1028;
LAB_00b5d663:
    uStack_8 = 0;
    uStack_38 = 0xb5d685;
    piStack_34 = piVar1;
    iStack_30 = iVar7;
    piStack_2c = piVar8;
    piStack_28 = piVar5;
    ppiStack_24 = (int **)uVar9;
    piStack_20 = piVar8;
    FUN_00b58cb0();
    uStack_8 = 0xffffffff;
    if (0x200 < uVar9) {
      ppiStack_24 = (int **)0xb5d6a6;
      piStack_20 = piVar5;
      FUN_01674ea0();
    }
  }
  ppiStack_24 = &piStack_28;
  piStack_28 = (int *)0xb5d6b9;
  puVar6 = (undefined4 *)FUN_0060dcd0();
  piVar1 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piStack_20 = (int *)&stack0xffffffe4;
  uStack_8 = 2;
  ppiStack_24 = (int **)0xb5d6f8;
  iVar7 = FUN_0115acb0();
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar8 = piVar1 + 1;
    iVar2 = *piVar8;
    iVar7 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0xb5d711;
      (**(code **)*piVar1)();
      LOCK();
      piVar8 = piVar1 + 2;
      iVar2 = *piVar8;
      iVar7 = *piVar8;
      *piVar8 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_20 = (int *)0xb5d721;
        iVar7 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ppiVar3 = ppiStack_24;
  if (ppiStack_24 != (int **)0x0) {
    LOCK();
    piVar1 = (int *)(ppiStack_24 + 1);
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0xb5d737;
      iVar7 = (*(code *)**ppiStack_24)();
      LOCK();
      piVar1 = (int *)(ppiVar3 + 2);
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0xb5d746;
        iVar7 = (**(code **)((int)*ppiVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 24428 ; VA 0x00b5d770 ; FUN_00b5d770 */

void FUN_00b5d770(int param_1,undefined4 param_2,undefined param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00b61fb0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00b62210();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24429 ; VA 0x00b5d8a0 ; FUN_00b5d8a0 */

void FUN_00b5d8a0(void)

{
  FUN_00b60040();
  return;
}



/* FUNCTION 24430 ; VA 0x00b5d8b0 ; FUN_00b5d8b0 */

void __thiscall FUN_00b5d8b0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint in_stack_0000002c;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf41b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8._0_1_ = 2;
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_110);
    if (cVar2 != '\0') {
      uVar4 = FUN_008898b0();
      FUN_0054ef60(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      FUN_005507b0();
      goto LAB_00b5d9aa;
    }
    uStack_8._0_1_ = 5;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(param_1 + 0x40));
LAB_00b5d9aa:
  uStack_8._0_1_ = 6;
  FUN_00b5b3d0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),aiStack_40,
               &param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24431 ; VA 0x00b5da90 ; FUN_00b5da90 */

undefined4 FUN_00b5da90(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  uVar3 = FUN_009d05b0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uVar4 = FUN_009d05b0(param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uVar3 = (**(code **)(iStack_14 + 0x38))(auStack_1c,uVar4,uVar3);
  uStack_8 = 0;
  uVar3 = FUN_009d5920(param_2,uVar3);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 24432 ; VA 0x00b5db60 ; FUN_00b5db60 */

undefined4 FUN_00b5db60(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  float10 fVar7;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined auStack_28 [12];
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4c53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  fVar7 = (float10)FUN_009d0730(param_2,param_3,2,iVar4,iStack_1c + 0x44);
  if (0 < iVar4) {
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + 1,DAT_01ede6c4);
    if (puVar5 != (undefined4 *)0x0) {
      uStack_18 = *puVar5;
      piStack_14 = (int *)puVar5[1];
      goto LAB_00b5dcb0;
    }
    if (0 < iVar4) {
      uStack_f8 = FUN_00888530();
      iStack_f4 = 0;
      uStack_8 = 0;
      cVar3 = FUN_009d1bf0(param_2,param_3 + 1,&uStack_f8,1);
      if (cVar3 != '\0') {
        puVar5 = (undefined4 *)FUN_0088b680();
        uStack_18 = *puVar5;
        piStack_14 = (int *)puVar5[1];
        uStack_8 = 1;
        if (iStack_f4 != 0) {
          (**(code **)(iStack_f4 + 8))(auStack_f0);
        }
        uStack_8 = 0xffffffff;
        goto LAB_00b5dcb0;
      }
      uStack_8 = 2;
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = *(undefined4 **)(iStack_1c + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_28,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  uStack_18 = *puVar5;
  piStack_14 = (int *)puVar5[1];
LAB_00b5dcb0:
  uVar6 = (**(code **)(iStack_1c + 0x38))(&uStack_18,uStack_18,piStack_14,(float)fVar7);
  uStack_8 = 3;
  uVar6 = FUN_009d5920(param_2,uVar6);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 24433 ; VA 0x00b5dd50 ; FUN_00b5dd50 */

undefined4 FUN_00b5dd50(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  undefined uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uStack_100;
  int iStack_fc;
  undefined auStack_f8 [200];
  undefined auStack_30 [12];
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4c7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_01256300(param_2);
  iVar5 = iVar5 - param_3;
  if (2 < iVar5) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54)
       && (FUN_016f3809(&DAT_01eded54), DAT_01eded54 == -1)) {
      uStack_8 = 0;
      FUN_0088dcb0();
      FUN_016f3654(&LAB_01880900);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eded54);
    }
    cVar3 = FUN_009d1e20(&DAT_01edecf0,param_2,param_3 + 3,&uStack_1c);
    uStack_18 = uStack_1c;
    if (cVar3 != '\0') goto LAB_00b5de88;
  }
  if (2 < iVar5) {
    uStack_100 = FUN_00888530();
    iStack_fc = 0;
    uStack_8 = 1;
    cVar3 = FUN_009d1bf0(param_2,param_3 + 3,&uStack_100,1);
    if (cVar3 != '\0') {
      puVar6 = (undefined4 *)thunk_FUN_0088c260();
      uStack_18 = *puVar6;
      uStack_8 = 2;
      if (iStack_fc != 0) {
        (**(code **)(iStack_fc + 8))(auStack_f8);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00b5de88;
    }
    uStack_8 = 3;
    if (iStack_fc != 0) {
      (**(code **)(iStack_fc + 8))(auStack_f8);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(undefined4 **)(iStack_14 + 0x48) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_30,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_30,&DAT_01c17198);
  }
  uStack_18 = **(undefined4 **)(iStack_14 + 0x48);
LAB_00b5de88:
  puVar6 = (undefined4 *)FUN_009d1340(auStack_24,param_2,param_3,2,iVar5,iStack_14 + 0x44);
  uStack_8 = 4;
  uVar4 = FUN_009d1aa0(param_2,param_3,1,iVar5,iStack_14 + 0x40);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(uVar4,*puVar6,puVar6[1],uStack_18);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24434 ; VA 0x00b5dfb0 ; FUN_00b5dfb0 */

undefined4 FUN_00b5dfb0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iStack_90;
  undefined *puStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  int iStack_78;
  undefined4 uStack_74;
  undefined auStack_68 [32];
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f4ca8;
  pvStack_1c = ExceptionList;
  uStack_74 = param_2;
  iStack_78 = 0xb5dfec;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300();
  puStack_8c = auStack_68;
  iStack_78 = (int)pcStack_28 + 0x44;
  uStack_80 = 2;
  iStack_84 = param_3;
  uStack_88 = param_2;
  iStack_90 = 0xb5e00a;
  iStack_7c = iVar1 - param_3;
  uStack_2c = FUN_009d1820();
  iStack_90 = (int)pcStack_28 + 0x40;
  uStack_14 = 0;
  uVar2 = FUN_009d09d0(auStack_48,param_2,param_3,1,iVar1 - param_3);
  puStack_30 = (undefined *)&iStack_90;
  uStack_14._0_1_ = 1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_00d88580(uStack_2c);
  uStack_14._0_1_ = 2;
  FUN_0054ef60(uVar2);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  (*pcStack_28)();
  if (0xf < uStack_34) {
    uVar4 = uStack_34 + 1;
    uVar3 = auStack_48[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_48[0] - 4);
      uVar4 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 24435 ; VA 0x00b5e0d0 ; FUN_00b5e0d0 */

undefined4 __thiscall FUN_00b5e0d0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  
  uVar1 = param_3;
  iVar4 = FUN_01256300(param_3);
  iVar4 = iVar4 - param_4;
  uVar2 = FUN_009d1aa0(uVar1,param_4,2,iVar4,param_1 + 0x44);
  if (0 < iVar4) {
    uVar5 = FUN_00b61fb0();
    cVar3 = FUN_009d1e20(uVar5,uVar1,param_4 + 1,&param_3);
    uVar5 = param_3;
    if (cVar3 != '\0') goto LAB_00b5e140;
  }
  uVar5 = FUN_00b59e80(uVar1,param_4,1,iVar4,param_1 + 0x40);
LAB_00b5e140:
  (**(code **)(param_1 + 0x38))(uVar5,uVar2);
  return 0;
}



/* FUNCTION 24436 ; VA 0x00b5e160 ; FUN_00b5e160 */

void __thiscall FUN_00b5e160(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = param_3;
  iVar3 = FUN_01256300(param_3);
  iVar3 = iVar3 - param_4;
  if (0 < iVar3) {
    uVar4 = FUN_00b61fb0();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_4 + 1,&param_3);
    uVar4 = param_3;
    if (cVar2 != '\0') goto LAB_00b5e1b6;
  }
  uVar4 = FUN_00b59e80(uVar1,param_4,1,iVar3,param_1 + 0x40);
LAB_00b5e1b6:
  uVar4 = (**(code **)(param_1 + 0x38))(uVar4);
  FUN_009d5ac0(uVar1,uVar4);
  return;
}



/* FUNCTION 24437 ; VA 0x00b5e1e0 ; FUN_00b5e1e0 */

void FUN_00b5e1e0(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  int *piVar7;
  
  iVar2 = *param_2;
  iVar6 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088daf0();
  if (iVar6 == iVar4) {
    puVar5 = (undefined *)(iVar2 + 0xd8);
    piVar3 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar5 = (undefined *)0x0;
    }
    iVar2 = *piVar3;
    uVar1 = *puVar5;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar6 = FUN_00b61fb0();
    if (iVar2 == iVar6) {
      piVar7 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar7 = (int *)0x0;
      }
      param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
      FUN_005e66b0(*piVar7,param_2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24438 ; VA 0x00b5e260 ; FUN_00b5e260 */

undefined4 *
FUN_00b5e260(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6c4);
    if (puVar3 != (undefined4 *)0x0) {
      uVar1 = puVar3[1];
      *param_1 = *puVar3;
      param_1[1] = uVar1;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar2 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
      if (cVar2 != '\0') {
        puVar3 = (undefined4 *)FUN_0088b680();
        uVar1 = puVar3[1];
        *param_1 = *puVar3;
        param_1[1] = uVar1;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar3 = (undefined4 *)*param_6;
  if (puVar3 != (undefined4 *)0x0) {
    *param_1 = *puVar3;
    param_1[1] = puVar3[1];
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 24439 ; VA 0x00b5e3d0 ; FUN_00b5e3d0 */

float10 FUN_00b5e3d0(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  double dVar7;
  
  fVar1 = *param_2;
  fVar2 = *param_1;
  fVar3 = param_2[1];
  fVar4 = param_1[1];
  FUN_01163170(0x358637bd);
  fVar5 = *param_3;
  fVar6 = param_3[1];
  FUN_01163170(0x358637bd);
  dVar7 = (double)(fVar5 * (fVar1 - fVar2) + (fVar3 - fVar4) * fVar6);
  FUN_01729d90();
  return (float10)(float)dVar7;
}



/* FUNCTION 24440 ; VA 0x00b5e470 ; FUN_00b5e470 */

int * FUN_00b5e470(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c59b0;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)(param_1 + 0x30);
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(param_1 + 0x30);
  }
  piStack_1c = *(int **)(param_1 + 0x2c);
  iStack_8 = 0;
  piStack_18 = piVar8;
  piStack_14 = piStack_1c;
  if ((piStack_1c != (int *)0x0) && (piVar7 = (int *)*piStack_1c, piVar7 != (int *)piStack_1c[1])) {
    do {
      iVar3 = *(int *)(*piVar7 + 0xc);
      iVar5 = FUN_00d5e4a0();
      if (((uint)*(ushort *)(iVar5 + 0x1da) <
           (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) &&
         (iVar3 = *(int *)(*piVar7 + 0xc), iVar5 = FUN_00e95050(),
         (uint)*(ushort *)(iVar5 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
        iVar3 = *(int *)(*piVar7 + 0xc);
        iVar5 = FUN_00b9e640();
        if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
            (uint)*(ushort *)(iVar5 + 0x1da)) goto LAB_00b5e5c4;
      }
      else {
        puVar6 = (undefined4 *)FUN_0060dcd0(auStack_24,*piVar7);
        puVar4 = *(undefined4 **)(param_2 + 4);
        iStack_8._0_1_ = 1;
        if (*(undefined4 **)(param_2 + 8) == puVar4) {
          FUN_00603a30(puVar4,puVar6);
        }
        else {
          *puVar4 = 0;
          puVar4[1] = 0;
          *puVar4 = *puVar6;
          puVar4[1] = puVar6[1];
          *puVar6 = 0;
          puVar6[1] = 0;
          *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 8;
        }
        piVar2 = piStack_20;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_20[1] + -1;
          piStack_20[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
LAB_00b5e5c4:
        FUN_00b5e470(*piVar7,param_2);
      }
      piVar7 = piVar7 + 2;
    } while (piVar7 != (int *)piStack_14[1]);
  }
  piVar7 = piStack_14;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar2 = piVar8 + 1;
    iVar3 = *piVar2;
    piVar7 = (int *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar7 = (int *)(**(code **)*piVar8)();
      LOCK();
      piVar2 = piVar8 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar7 = (int *)(**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 24441 ; VA 0x00b5e620 ; FUN_00b5e620 */

void FUN_00b5e620(void)

{
  int iVar1;
  
  if (DAT_01eefb54 == 0) {
    iVar1 = FUN_00b56cd0();
    DAT_01eefb54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24442 ; VA 0x00b5e640 ; FUN_00b5e640 */

void FUN_00b5e640(void)

{
  int iVar1;
  
  if (DAT_01eefd74 == 0) {
    iVar1 = FUN_00b56e90();
    DAT_01eefd74 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24443 ; VA 0x00b5e660 ; FUN_00b5e660 */

undefined4 FUN_00b5e660(float *param_1,float *param_2,float *param_3,float *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar3 = DAT_018ce2f4;
  if ((((*param_1 <= param_2[2]) && (param_1[1] <= param_2[3])) && (*param_2 <= param_1[2])) &&
     (param_2[1] <= param_1[3])) {
    return 0;
  }
  fVar1 = param_4[1];
  fVar2 = param_3[1];
  if (fVar1 <= fVar2) {
    if (fVar1 < fVar2) {
      fVar5 = (param_1[3] - param_1[1]) * DAT_018ce2f4;
      fVar4 = (param_2[3] - param_2[1]) * DAT_018ce2f4 + fVar1;
      if (fVar4 < fVar2 - fVar5) {
        fVar2 = (fVar1 + fVar2) * DAT_018ce2f4;
        fVar1 = fVar2;
        if (fVar4 <= fVar2) {
          fVar1 = fVar4;
        }
        param_4[1] = fVar1;
        fVar5 = param_3[1] - fVar5;
        if (fVar2 <= fVar5) {
          fVar2 = fVar5;
        }
        param_3[1] = fVar2;
      }
      else {
        param_4[1] = fVar4;
        param_3[1] = fVar4;
      }
    }
  }
  else {
    fVar5 = (param_2[3] - param_2[1]) * DAT_018ce2f4;
    fVar4 = (param_1[3] - param_1[1]) * DAT_018ce2f4 + fVar2;
    if (fVar4 < fVar1 - fVar5) {
      fVar2 = (fVar1 + fVar2) * DAT_018ce2f4;
      fVar1 = fVar2;
      if (fVar4 <= fVar2) {
        fVar1 = fVar4;
      }
      param_3[1] = fVar1;
      fVar5 = param_4[1] - fVar5;
      if (fVar2 <= fVar5) {
        fVar2 = fVar5;
      }
      param_4[1] = fVar2;
    }
    else {
      param_3[1] = fVar4;
      param_4[1] = fVar4;
    }
  }
  fVar1 = *param_3;
  fVar2 = *param_4;
  if (fVar1 < fVar2) {
    fVar5 = (param_2[2] - *param_2) * fVar3;
    fVar4 = (param_1[2] - *param_1) * fVar3 + fVar1;
    if (fVar2 - fVar5 <= fVar4) {
      *param_3 = fVar4;
      *param_4 = fVar4;
      return 1;
    }
    fVar3 = (fVar2 + fVar1) * fVar3;
    fVar1 = fVar3;
    if (fVar4 <= fVar3) {
      fVar1 = fVar4;
    }
    *param_3 = fVar1;
    fVar5 = *param_4 - fVar5;
    if (fVar3 <= fVar5) {
      fVar3 = fVar5;
    }
    *param_4 = fVar3;
    return 1;
  }
  if (fVar2 < fVar1) {
    fVar5 = (param_1[2] - *param_1) * fVar3;
    fVar4 = (param_2[2] - *param_2) * fVar3 + fVar2;
    if (fVar1 - fVar5 <= fVar4) {
      *param_4 = fVar4;
      *param_3 = fVar4;
      return 1;
    }
    fVar3 = (fVar2 + fVar1) * fVar3;
    fVar1 = fVar3;
    if (fVar4 <= fVar3) {
      fVar1 = fVar4;
    }
    *param_4 = fVar1;
    fVar5 = *param_3 - fVar5;
    if (fVar3 <= fVar5) {
      fVar3 = fVar5;
    }
    *param_3 = fVar3;
  }
  return 1;
}



/* FUNCTION 24444 ; VA 0x00b5e860 ; FUN_00b5e860 */

void __thiscall FUN_00b5e860(undefined *param_1,int *param_2)

{
  int iVar1;
  undefined **ppuVar2;
  int **ppiVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined8 in_stack_00000054;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_100;
  undefined *puStack_fc;
  undefined4 *puStack_f8;
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 *puStack_e4;
  undefined4 uStack_e0;
  undefined *puStack_dc;
  undefined4 *puStack_d8;
  undefined4 *puStack_d4;
  undefined auStack_d0 [4];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined *puStack_b0;
  char *pcStack_ac;
  int *piStack_a8;
  undefined auStack_a4 [4];
  undefined4 uStack_a0;
  int **ppiStack_9c;
  undefined4 *puStack_98;
  int *piStack_94;
  int *piStack_90;
  uint uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined auStack_5c [20];
  int *piStack_48;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4d20;
  pvStack_10 = ExceptionList;
  piStack_90 = (int *)0x1;
  uStack_8 = 2;
  puStack_98 = (undefined4 *)0xb5e891;
  ExceptionList = &pvStack_10;
  piStack_94 = (int *)param_1;
  puStack_1c = param_1;
  cVar4 = FUN_0097c970();
  if (cVar4 == '\0') {
    piStack_90 = (int *)0x6;
    piStack_94 = (int *)0x19552a8;
    puStack_98 = (undefined4 *)0x2;
    ppiStack_9c = (int **)0xb5e8a6;
    FUN_0086edd0();
  }
  else {
    param_1 = param_1 + (byte)param_1[0xbc] + 0xbd;
    piStack_90 = (int *)&param_2;
    puStack_98 = (undefined4 *)0xb5e8ca;
    piStack_94 = (int *)param_1;
    puStack_98 = (undefined4 *)FUN_0055c740();
    piStack_94 = (int *)&param_2;
    piStack_90 = (int *)(-(uint)(param_1 != (undefined *)0x0) & (uint)(param_1 + 1));
    ppiStack_9c = &piStack_18;
    uStack_a0 = 0xb5e8e7;
    FUN_008992d0();
    if (piStack_18 == (int *)0x0) {
      if (DAT_01d670b4 == '\0') {
        piStack_a8 = (int *)&param_2;
        if (0xf < in_stack_00000018) {
          piStack_a8 = param_2;
        }
        puStack_b0 = auStack_a4;
        pcStack_ac = "GetCore: %s has not been registered by the CoreScripts";
        uStack_b4 = 0xb5ebcd;
        FUN_01675640();
        piStack_a8 = (int *)0xb5ebd8;
        FUN_005e65e0();
      }
      else {
        piStack_90 = (int *)&param_2;
        if (0xf < in_stack_00000018) {
          piStack_90 = param_2;
        }
        piStack_94 = (int *)0x19552fc;
        puStack_98 = (undefined4 *)0x2;
        ppiStack_9c = (int **)0xb5eb8e;
        FUN_0086f2f0();
        puStack_34 = (undefined *)&uStack_15c;
        uStack_15c = FUN_00888530();
        uStack_158 = 0;
        FUN_008c6ce0();
      }
    }
    else {
      piStack_90 = piStack_18 + 8;
      piStack_94 = (int *)0xb5e8fe;
      FUN_00d88580();
      piStack_14 = piStack_48;
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + 1;
      UNLOCK();
      piStack_20 = piStack_48;
      if (piStack_48 != (int *)0x0) {
        LOCK();
        *piStack_48 = *piStack_48 + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (piStack_48 != (int *)0x0) {
        if (piStack_48[2] != 0) {
          piStack_90 = (int *)0x1c;
          piStack_94 = (int *)0xb5e93a;
          piStack_18 = (int *)FUN_01674e20();
          if (piStack_18 == (int *)0x0) {
            piStack_18 = (int *)0x0;
          }
          else {
            piStack_90 = (int *)0xb5e94b;
            piStack_18 = (int *)FUN_0089ab00();
          }
          piVar6 = piStack_18;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            piStack_18[1] = piStack_18[1] + 1;
            UNLOCK();
          }
          piStack_90 = (int *)0x18;
          uStack_8._0_1_ = 5;
          piStack_94 = (int *)0xb5e972;
          piStack_24 = piStack_18;
          puVar5 = (undefined4 *)FUN_01674e20();
          puStack_dc = puStack_1c;
          if (puVar5 == (undefined4 *)0x0) {
            puVar5 = (undefined4 *)0x0;
          }
          else {
            puVar5[1] = 1;
            puVar5[2] = 1;
            *puVar5 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
            puVar5[3] = 0;
            puVar5[4] = 0;
            puVar5[5] = 0;
          }
          puStack_3c = puVar5 + 3;
          puStack_28 = (undefined *)&piStack_90;
          if (piVar6 != (int *)0x0) {
            LOCK();
            piVar6[1] = piVar6[1] + 1;
            UNLOCK();
          }
          puStack_2c = (undefined *)&puStack_b0;
          uStack_8._0_1_ = 7;
          uStack_7c = 0;
          piStack_90 = piVar6;
          puStack_38 = puVar5;
          ppuVar2 = &puStack_b0;
          ppiVar3 = &piStack_90;
          if (in_stack_0000003c != 0) {
            uStack_7c = in_stack_0000003c;
            if ((in_stack_0000003c & 1) == 0) {
              uStack_b4 = 0;
              uStack_bc = CONCAT44(&uStack_74,&stack0x00000044);
              uStack_c0 = 0xb5ea18;
              (**(code **)(in_stack_0000003c & 0xfffffffe))();
              ppuVar2 = (undefined **)puStack_2c;
              ppiVar3 = (int **)puStack_28;
            }
            else {
              uStack_74 = in_stack_00000044;
              uStack_70 = in_stack_00000048;
              uStack_6c = in_stack_0000004c;
              uStack_68 = in_stack_00000050;
              uStack_64 = in_stack_00000054;
              ppuVar2 = &puStack_b0;
              ppiVar3 = &piStack_90;
            }
          }
          puStack_28 = (undefined *)ppiVar3;
          puStack_2c = (undefined *)ppuVar2;
          uStack_b4 = 0;
          puStack_30 = (undefined *)&puStack_dc;
          uStack_8._0_1_ = 8;
          puStack_d4 = (undefined4 *)0x0;
          ppuVar2 = &puStack_dc;
          if (uStack_7c != 0) {
            puStack_d4 = (undefined4 *)uStack_7c;
            if ((uStack_7c & 1) == 0) {
              puStack_e4 = &uStack_cc;
              uStack_e0 = 0;
              puStack_e8 = &uStack_74;
              uStack_ec = 0xb5ea69;
              (**(code **)(uStack_7c & 0xfffffffe))();
              ppuVar2 = (undefined **)puStack_30;
            }
            else {
              uStack_cc = uStack_74;
              uStack_c8 = uStack_70;
              uStack_c4 = uStack_6c;
              uStack_c0 = uStack_68;
              uStack_bc = uStack_64;
              ppuVar2 = &puStack_dc;
            }
          }
          puStack_30 = (undefined *)ppuVar2;
          uStack_e0 = 0xb5ea73;
          FUN_00b565e0();
          uStack_8._0_1_ = 9;
          if (((uStack_7c != 0) && ((uStack_7c & 1) == 0)) &&
             (*(code **)(uStack_7c & 0xfffffffe) != (code *)0x0)) {
            uStack_b4 = 2;
            uStack_bc = CONCAT44(&uStack_74,&uStack_74);
            uStack_c0 = 0xb5ea98;
            (**(code **)(uStack_7c & 0xfffffffe))();
          }
          puStack_30 = auStack_d0;
          uStack_8._0_1_ = 10;
          puStack_f8 = &stack0x0000001c;
          puStack_d4 = (undefined4 *)0x0;
          puStack_fc = (undefined *)0xb5eabe;
          FUN_0054f510();
          puStack_f8 = (undefined4 *)0xb5eac5;
          FUN_00b56a40();
          puStack_1c = (undefined *)&puStack_d8;
          if (puVar5 != (undefined4 *)0x0) {
            LOCK();
            puVar5[1] = puVar5[1] + 1;
            UNLOCK();
          }
          puStack_d8 = puVar5 + 3;
          uStack_8._0_1_ = 0xc;
          puStack_fc = auStack_5c;
          uStack_100 = 0xb5eafc;
          puStack_d4 = puVar5;
          FUN_00d88580();
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          puStack_fc = (undefined *)0xb5eb05;
          FUN_0094a8d0();
          piStack_90 = (int *)0xb5eb10;
          FUN_00550b30();
          if (piStack_18 != (int *)0x0) {
            piVar6 = piStack_18 + 1;
            LOCK();
            iVar1 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (((iVar1 == 1) && (piVar6 != (int *)0x0)) && (piStack_18 != (int *)0x0)) {
              piStack_90 = (int *)0x1;
              piStack_94 = (int *)0xb5eb37;
              (**(code **)(*piStack_18 + 4))();
            }
          }
        }
        piVar6 = piStack_14;
        LOCK();
        iVar1 = *piStack_14;
        *piStack_14 = *piStack_14 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          piStack_90 = (int *)0xb5eb51;
          FUN_00d88950();
          piStack_90 = (int *)0x10;
          puStack_98 = (undefined4 *)0xb5eb59;
          piStack_94 = piVar6;
          FUN_01674ea0();
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      piStack_90 = (int *)0xb5eb6b;
      FUN_00d88a30();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    piStack_90 = (int *)(in_stack_00000018 + 1);
    piVar6 = param_2;
    if ((int *)0xfff < piStack_90) {
      piVar6 = (int *)param_2[-1];
      piStack_90 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
        piStack_90 = (int *)&UNK_00b5ec8b;
        FUN_017167a3();
      }
    }
    puStack_98 = (undefined4 *)0xb5ec0d;
    piStack_94 = piVar6;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (int *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      puStack_98 = (undefined4 *)&stack0x00000024;
      piStack_90 = (int *)0x2;
      ppiStack_9c = (int **)0xb5ec43;
      piStack_94 = puStack_98;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_98 = &stack0x00000044;
    piStack_90 = (int *)0x2;
    ppiStack_9c = (int **)0xb5ec71;
    piStack_94 = puStack_98;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24445 ; VA 0x00b5ec90 ; FUN_00b5ec90 */

undefined __fastcall FUN_00b5ec90(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_0086edd0(2,"StarterGui:GetCoreGuiEnabled must be called from a local script.",6);
    return 0;
  }
  iVar2 = FUN_00b5abd0(&stack0x00000004);
  return *(undefined *)(iVar2 + 4);
}



/* FUNCTION 24446 ; VA 0x00b5ece0 ; FUN_00b5ece0 */

undefined4 __fastcall FUN_00b5ece0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x9c);
}



/* FUNCTION 24447 ; VA 0x00b5ecf0 ; FUN_00b5ecf0 */

undefined4 * __thiscall FUN_00b5ecf0(int param_1,undefined4 *param_2,int param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4d40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0088dc10(&uStack_18);
  uStack_8 = 0;
  if (*(char *)(param_1 + 100) != '\0') {
    FUN_00b5d580();
  }
  FUN_00569460(param_1 + 0x68);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_28 != iStack_2c) {
    do {
      piVar1 = (int *)(iStack_28 + -8);
      iStack_28 = iStack_28 + -8;
      if (*piVar1 != 0) {
        iVar3 = *(int *)(*piVar1 + 0xc);
        iVar5 = FUN_00d5e4a0();
        if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
            (uint)*(ushort *)(iVar5 + 0x1da)) {
          FUN_00d65770(&uStack_18,(float)param_3,(float)param_4,0);
        }
      }
    } while (iStack_28 != iStack_2c);
  }
  uVar4 = uStack_18;
  uStack_18 = 0;
  *param_2 = uVar4;
  param_2[1] = piStack_14;
  piStack_14 = (int *)0x0;
  FUN_00577ac0();
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24448 ; VA 0x00b5ee10 ; FUN_00b5ee10 */

undefined4 __thiscall FUN_00b5ee10(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  int iVar1;
  
  iVar1 = FUN_006ebc30(param_1);
  if (iVar1 != 0) {
    param_3 = param_3 + (int)*(float *)(iVar1 + 0xf8);
    param_4 = param_4 + (int)*(float *)(iVar1 + 0xfc);
  }
  FUN_00b5ecf0(param_2,param_3,param_4);
  return param_2;
}



/* FUNCTION 24449 ; VA 0x00b5ee60 ; FUN_00b5ee60 */

undefined4 * __thiscall
FUN_00b5ee60(int param_1,undefined4 *param_2,float param_3,float param_4,undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  float *pfVar5;
  int iVar6;
  int iStack_2c;
  int iStack_28;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4d40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00b594b0(param_1);
  pfVar5 = (float *)FUN_01126580(&fStack_20);
  fStack_20 = param_3 + *pfVar5;
  fStack_1c = pfVar5[1] + param_4;
  FUN_0088dc10(&uStack_18);
  uStack_8 = 0;
  if (*(char *)(param_1 + 100) != '\0') {
    FUN_00b5d580();
  }
  FUN_00569460(param_1 + 0x68);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_28 != iStack_2c) {
    do {
      piVar1 = (int *)(iStack_28 + -8);
      iStack_28 = iStack_28 + -8;
      if (*piVar1 != 0) {
        iVar3 = *(int *)(*piVar1 + 0xc);
        iVar6 = FUN_00d5e4a0();
        if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          FUN_00d65770(&uStack_18,fStack_20,fStack_1c,param_5);
        }
      }
    } while (iStack_28 != iStack_2c);
  }
  uVar4 = uStack_18;
  uStack_18 = 0;
  *param_2 = uVar4;
  param_2[1] = piStack_14;
  piStack_14 = (int *)0x0;
  FUN_00577ac0();
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24450 ; VA 0x00b5efb0 ; FUN_00b5efb0 */

void __thiscall FUN_00b5efb0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x8c) == 0) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_00b59600(auStack_18);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x8c) = uVar1;
    piVar3 = *(int **)(param_1 + 0x90);
    *(undefined4 *)(param_1 + 0x90) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar8 = piVar3[1] + -1;
      piVar3[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar8 = piVar3[2] + -1;
        piVar3[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar8 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    FUN_00d69b00(1);
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    pcVar4 = *(code **)(**(int **)(param_1 + 0x8c) + 0x38);
    FUN_005542c0("RobloxGui",9);
    uStack_8 = 0;
    (*pcVar4)(auStack_30);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar6 = auStack_30[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_30[0] - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_008a65e0(param_1,0);
  }
  iVar8 = *(int *)(param_1 + 0x90);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar8 != 0) {
    LOCK();
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
    UNLOCK();
    iVar8 = *(int *)(param_1 + 0x90);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x8c);
  param_2[1] = iVar8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24451 ; VA 0x00b5f140 ; FUN_00b5f140 */

undefined4 __fastcall FUN_00b5f140(int param_1)

{
  return *(undefined4 *)(param_1 + 0x7c);
}



/* FUNCTION 24452 ; VA 0x00b5f150 ; FUN_00b5f150 */

float10 __fastcall FUN_00b5f150(int param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 != '\0') {
    return (float10)*(float *)(param_1 + 0x88);
  }
  FUN_00550130("PlayerGui:GetTopbarTransparency should only be accessed from a local script.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 24453 ; VA 0x00b5f190 ; FUN_00b5f190 */

void __thiscall FUN_00b5f190(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00b62060();
  *param_3 = uVar3;
  iVar4 = FUN_00b62280();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 24454 ; VA 0x00b5f1f0 ; FUN_00b5f1f0 */

void FUN_00b5f1f0(int *param_1,int param_2)

{
  uint uVar1;
  undefined uVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  uint in_stack_0000001c;
  undefined auStack_60 [8];
  undefined4 uStack_58;
  undefined4 ***pppuStack_54;
  undefined4 ***pppuStack_50;
  undefined4 *puStack_4c;
  uint uStack_48;
  undefined4 **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4d70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_48 = 0;
  iVar4 = *param_1;
  uVar1 = *(uint *)(iVar4 + 8);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      pppuStack_50 = &ppuStack_40;
      puStack_4c = (undefined4 *)0x0;
      pppuStack_54 = (undefined4 ***)(iVar4 + 0x10);
      uStack_58 = 0xb5f252;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      ppuStack_40 = *(undefined4 ***)(iVar4 + 0x10);
      uStack_3c = *(undefined4 *)(iVar4 + 0x14);
      uStack_38 = *(undefined4 *)(iVar4 + 0x18);
      uStack_34 = *(undefined4 *)(iVar4 + 0x1c);
      uStack_30 = *(undefined8 *)(iVar4 + 0x20);
      ExceptionList = &pvStack_10;
    }
  }
  puStack_4c = &param_2;
  uStack_8._0_1_ = 1;
  pppuStack_50 = (undefined4 ****)0xb5f265;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  ppppuVar3 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_01675640(auStack_60,"GetCore: Unexpected error while invoking callback: %s",ppppuVar3);
  FUN_005e65e0();
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_14) {
    puStack_4c = (undefined4 *)(uStack_14 + 1);
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < puStack_4c) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
      puStack_4c = (undefined4 *)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        puStack_4c = (undefined4 *)0xb5f33d;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    pppuStack_54 = (undefined4 ****)0xb5f2c1;
    pppuStack_50 = ppppuVar3;
    FUN_01674ea0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_48 != 0) && ((uStack_48 & 1) == 0)) &&
     (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
    pppuStack_54 = &ppuStack_40;
    puStack_4c = (undefined4 *)0x2;
    uStack_58 = 0xb5f2f7;
    pppuStack_50 = pppuStack_54;
    (**(code **)(uStack_48 & 0xfffffffe))();
  }
  if (0xf < in_stack_0000001c) {
    puStack_4c = (undefined4 *)(in_stack_0000001c + 1);
    iVar4 = param_2;
    if (0xfff < puStack_4c) {
      iVar4 = *(int *)(param_2 + -4);
      puStack_4c = (undefined4 *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_4c = (undefined4 *)&UNK_00b5f342;
        FUN_017167a3();
      }
    }
    pppuStack_54 = (undefined4 ***)0xb5f327;
    pppuStack_50 = (undefined4 ***)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24455 ; VA 0x00b5f350 ; FUN_00b5f350 */

void FUN_00b5f350(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [192];
  undefined4 uStack_28;
  undefined *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f4d90;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uStack_f0 = param_2;
  puStack_ec = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  if (param_3 != (undefined4 *)0x0) {
    uStack_f8 = CONCAT44(auStack_e8,&stack0x00000010);
    uStack_fc = 0xb5f3ab;
    ExceptionList = &pvStack_10;
    (*(code *)*param_3)();
  }
  puStack_ec = param_3;
  iStack_8._0_1_ = 1;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_108,0);
    }
    else {
      uStack_108 = puVar1[4];
      uStack_104 = puVar1[5];
      uStack_100 = puVar1[6];
      uStack_fc = puVar1[7];
      uStack_f8 = *(undefined8 *)(puVar1 + 8);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar2)();
  iStack_8 = 2;
  if (param_3 != (undefined4 *)0x0) {
    puStack_24 = &stack0x00000010;
    uStack_28 = 0xb5f420;
    (*(code *)param_3[2])();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24456 ; VA 0x00b5f440 ; FUN_00b5f440 */

/* WARNING: Removing unreachable block (ram,0x00b5f4d8) */
/* WARNING: Removing unreachable block (ram,0x00b5f4e4) */
/* WARNING: Removing unreachable block (ram,0x00b5f4f2) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00b5f440(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  param_1 = &uStack_e8;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_e8 = FUN_0088cbe0();
  puStack_e4 = (undefined4 *)0x0;
  uStack_e0 = param_2;
  uStack_dc = param_3;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8) &&
     (FUN_016f3809(&DAT_01ead3c8), DAT_01ead3c8 == -1)) {
    DAT_01ead3bc = FUN_0057bbb0;
    _DAT_01ead3c0 = FUN_005880a0;
    DAT_01ead3c4 = FUN_0057d5e0;
    FUN_016f37bf(&DAT_01ead3c8);
  }
  puStack_e4 = &DAT_01ead3bc;
  uVar1 = FUN_008c6ce0();
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 24457 ; VA 0x00b5f550 ; FUN_00b5f550 */

undefined FUN_00b5f550(float *param_1,float *param_2,int param_3,float *param_4,float *param_5,
                      int param_6)

{
  char cVar1;
  float *pfVar2;
  int iVar3;
  uint uVar4;
  undefined uVar5;
  float10 fVar6;
  float fVar7;
  float fVar8;
  double dVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  int iStack_50;
  uint uStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined auStack_28 [8];
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4da8;
  pvStack_10 = ExceptionList;
  if (param_3 == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(*(undefined4 *)(param_3 + 0x28));
  uStack_8 = 0;
  FUN_00d5c5d0(&fStack_38);
  fStack_20 = (*param_1 + param_1[2]) * DAT_018ce2f4;
  fStack_1c = (param_1[3] + param_1[1]) * DAT_018ce2f4;
  fStack_18 = (fStack_30 + fStack_38) * DAT_018ce2f4;
  fStack_14 = (fStack_34 + fStack_2c) * DAT_018ce2f4;
  cVar1 = FUN_00b5e660(param_1,&fStack_38,&fStack_20,&fStack_18);
  if ((cVar1 == '\0') || ((NAN(*param_4) || NAN(DAT_01920400)) == (*param_4 == DAT_01920400))) {
    if (cVar1 == '\0') {
      fVar13 = (fStack_30 + fStack_38) * DAT_018ce2f4;
      fVar8 = (*param_1 + param_1[2]) * DAT_018ce2f4;
      fVar7 = (param_1[3] + param_1[1]) * DAT_018ce2f4;
      fVar14 = (fStack_34 + fStack_2c) * DAT_018ce2f4;
      fStack_18 = fVar13 - fVar8;
      fStack_14 = fVar14 - fVar7;
      FUN_01163170(0x358637bd);
      fStack_20 = *param_2;
      fStack_1c = param_2[1];
      FUN_01163170(0x358637bd);
      dVar9 = (double)(fStack_1c * fStack_14 + fStack_20 * fStack_18);
      FUN_01729d90();
      if ((((uint)(float)dVar9 & 0x7f800000) != 0x7f800000) && ((float)dVar9 <= DAT_0195557c)) {
        fVar7 = fVar7 - fVar14;
        fVar8 = fVar8 - fVar13;
        dVar9 = (double)(fVar7 * fVar7 + fVar8 * fVar8);
        FUN_017267a0();
        if ((float)dVar9 < *param_4) {
          *param_4 = (float)dVar9;
LAB_00b5f9fa:
          uVar5 = 1;
          goto LAB_00b5f88a;
        }
      }
    }
  }
  else {
    fVar6 = (float10)FUN_00b5e3d0(&fStack_20,&fStack_18,param_2);
    if ((((uint)(float)fVar6 & 0x7f800000) != 0x7f800000) && ((float)fVar6 <= DAT_0195557c)) {
      fVar7 = fStack_18 - fStack_20;
      fVar14 = *param_2 * DAT_01955580;
      fVar13 = param_2[1] * DAT_01955580;
      fVar8 = fStack_14 - fStack_1c;
      dVar9 = (double)(fVar13 * fVar13 + fVar14 * fVar14);
      FUN_017267a0();
      if (0.0 < (float)dVar9) {
        fVar11 = *param_5;
        fVar7 = (fVar13 * fVar8 + fVar14 * fVar7) / (float)dVar9;
        if (fVar7 < fVar11) {
          *param_5 = fVar7;
          uVar5 = 1;
          goto LAB_00b5f88a;
        }
        if (((NAN(fVar7) || NAN(fVar11)) != (fVar7 == fVar11)) && (param_6 != 0)) {
          fVar7 = param_1[2];
          fVar8 = *param_1;
          fVar13 = param_1[3];
          fVar14 = param_1[1];
          pfVar2 = (float *)FUN_00d5c5d0(auStack_28);
          fVar11 = (fVar8 + fVar7) * DAT_018ce2f4 - (*pfVar2 + pfVar2[2]) * DAT_018ce2f4;
          fVar12 = (fVar14 + fVar13) * DAT_018ce2f4 - (pfVar2[3] + pfVar2[1]) * DAT_018ce2f4;
          fVar7 = *param_1;
          fVar8 = param_1[3];
          fVar13 = param_1[1];
          fVar14 = param_1[2];
          pfVar2 = (float *)FUN_00d5c5d0(auStack_28);
          fVar7 = (fVar14 + fVar7) * DAT_018ce2f4 - (*pfVar2 + pfVar2[2]) * DAT_018ce2f4;
          fVar8 = (fVar8 + fVar13) * DAT_018ce2f4 - (pfVar2[3] + pfVar2[1]) * DAT_018ce2f4;
          dVar9 = (double)(fVar12 * fVar12 + fVar11 * fVar11);
          FUN_017267a0();
          dVar10 = (double)(fVar8 * fVar8 + fVar7 * fVar7);
          FUN_017267a0();
          if ((float)dVar9 < (float)dVar10) goto LAB_00b5f9fa;
        }
      }
    }
  }
  uVar5 = 0;
LAB_00b5f88a:
  if (0xf < uStack_3c) {
    uVar4 = uStack_3c + 1;
    iVar3 = iStack_50;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_50 + -4);
      uVar4 = uStack_3c + 0x24;
      if (0x1f < (iStack_50 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 24458 ; VA 0x00b5fa30 ; FUN_00b5fa30 */

uint FUN_00b5fa30(void)

{
  int iVar1;
  
  iVar1 = FUN_00b56e90();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24459 ; VA 0x00b5fa50 ; FUN_00b5fa50 */

uint FUN_00b5fa50(void)

{
  int iVar1;
  
  iVar1 = FUN_00b56e90();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24460 ; VA 0x00b5fa70 ; FUN_00b5fa70 */

void FUN_00b5fa70(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b61fb0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24461 ; VA 0x00b5fab0 ; FUN_00b5fab0 */

void FUN_00b5fab0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b62060();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24462 ; VA 0x00b5faf0 ; FUN_00b5faf0 */

void FUN_00b5faf0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1de6cd4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_fa73da778e3ac09ca3b79ebed7ac18cd>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 24463 ; VA 0x00b5fc60 ; FUN_00b5fc60 */

void FUN_00b5fc60(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1de6bf4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_RBX::Reflection::Variant),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 24464 ; VA 0x00b5fdd0 ; FUN_00b5fdd0 */

void FUN_00b5fdd0(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_0054f510(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1de6d0c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::function<void___cdecl(class_RBX::Reflection::Variant)>::
                   RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 24465 ; VA 0x00b5ff40 ; FUN_00b5ff40 */

void FUN_00b5ff40(undefined4 param_1)

{
  int iVar1;
  
  FUN_008a4130(param_1);
  FUN_00b5b190(param_1);
  iVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    FUN_0115aba0(iVar1);
  }
  return;
}



/* FUNCTION 24466 ; VA 0x00b5ff90 ; FUN_00b5ff90 */

void __thiscall FUN_00b5ff90(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  iVar3 = FUN_0170d75d(*param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IAdornable::RTTI_Type_Descriptor,0);
  if (iVar3 != 0) {
    FUN_0115abe0(iVar3);
  }
  piVar2 = *(int **)(param_1 + 0x6c);
  piVar4 = *(int **)(param_1 + 0x68);
  if (*(int **)(param_1 + 0x68) != piVar2) {
    while (piVar1 = piVar4 + 2, *piVar4 != *param_2) {
      piVar4 = piVar1;
      if (piVar1 == piVar2) {
        FUN_008a41c0(param_2);
        return;
      }
    }
    FUN_00775350(piVar1,piVar2,piVar4);
    piVar2 = *(int **)(*(int *)(param_1 + 0x6c) + -4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + -8;
  }
  FUN_008a41c0(param_2);
  return;
}



/* FUNCTION 24467 ; VA 0x00b60040 ; FUN_00b60040 */

void __fastcall FUN_00b60040(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if ((DAT_01eeb4f1 != '\0') && (param_1 != 0)) {
    iVar1 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar1 != 0) && (param_1 = iVar1, ExceptionList = &pvStack_10, *(int *)(iVar1 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead2e4,&LAB_00605b60);
      uVar3 = FUN_00606020();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        piStack_14 = piVar4;
        uVar3 = FUN_00ac1050();
        piVar5 = (int *)FUN_008a9ba0(auStack_20,uVar3);
        piVar4 = piStack_14;
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar1;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar1 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar1 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_1c + 4))();
            }
          }
        }
      }
      iVar1 = *piVar4;
      if (iVar1 != 0) {
        piVar4 = *(int **)(iVar1 + 0x78);
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
          piVar4 = *(int **)(iVar1 + 0x78);
        }
        piStack_14 = *(int **)(iVar1 + 0x74);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar2 = piVar4[1] + -1;
          piVar4[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar5 = piVar4 + 2;
            iVar2 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (piStack_14 != (int *)0x0) {
          piStack_14 = *(int **)(iVar1 + 0x78);
          if (piStack_14 != (int *)0x0) {
            LOCK();
            *(int *)((int)piStack_14 + 4) = *(int *)((int)piStack_14 + 4) + 1;
            UNLOCK();
            piStack_14 = *(int **)(iVar1 + 0x78);
          }
          piStack_18 = *(int **)(iVar1 + 0x74);
          uStack_8 = 0;
          (**(code **)(*piStack_18 + 0x2c))();
          FUN_00550b30();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24468 ; VA 0x00b601e0 ; FUN_00b601e0 */

void __thiscall FUN_00b601e0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4de9;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_008f7870(param_1);
    uVar4 = *(undefined4 *)(param_1 + 0x84);
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("PlayerGuiSetScreenOrientationTouchDevice",0x28);
    uStack_8 = 0;
    FUN_00b60db0(auStack_38,uVar4,uVar2,param_1 + 0x8c,1,param_1 + 0x90);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      uVar6 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar6 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  if (param_3 != 0) {
    iVar3 = FUN_009172e0();
    if (iVar3 != 0) {
      FUN_005e6780(*(undefined4 *)(iVar3 + 0xe0));
    }
    iVar3 = FUN_008f7870(param_3);
    if (iVar3 != 0) {
      if (*(char *)(iVar3 + 0x240) == '\0') {
        uStack_8 = 1;
        uVar4 = FUN_01675290(DAT_02110da8);
        uStack_8._0_1_ = 2;
        uStack_1c = uVar4;
        puStack_20 = (undefined4 *)FUN_01674e20(0x1c);
        if (puStack_20 == (undefined4 *)0x0) {
          puVar7 = (undefined4 *)0x0;
        }
        else {
          *puStack_20 = 0;
          puStack_20[1] = 1;
          puStack_20[2] = FUN_00b5d8a0;
          puStack_20[3] = _guard_check_icall;
          puStack_20[4] = 0;
          puStack_20[5] = iVar3 + 0xac;
          puStack_20[6] = iStack_14;
          puVar7 = puStack_20;
        }
        FUN_016797d0(puVar7);
        if (puVar7 != (undefined4 *)0x0) {
          LOCK();
          puVar7[1] = puVar7[1] + 1;
          UNLOCK();
        }
        uStack_18 = 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        puStack_20 = puVar7;
        FUN_01675290(uVar4);
        uStack_8 = 0xffffffff;
        if (puVar7 != (undefined4 *)0x0) {
          piVar1 = puVar7 + 1;
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            FUN_01674ea0(puVar7);
          }
        }
      }
      else {
        FUN_00b60040();
      }
    }
  }
  FUN_008a4210(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24469 ; VA 0x00b603e0 ; FUN_00b603e0 */

int * __thiscall FUN_00b603e0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  undefined4 uStack_78;
  int *piStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  uint uStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4e10;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x58) = 0;
  uStack_14 = 0;
  iStack_1c = param_1;
  if (*(char *)(param_1 + 100) != '\0') {
    FUN_00b5d580();
  }
  FUN_00569460(param_1 + 0x68);
  uStack_8 = 0;
  iStack_18 = iStack_30;
  iVar7 = iStack_30;
  uVar8 = 0;
  if (iStack_30 != iStack_34) {
    do {
      piVar6 = *(int **)(iVar7 + -8);
      iStack_18 = iVar7;
      if ((piVar6 == (int *)0x0) ||
         (iVar1 = piVar6[3], iVar2 = FUN_00e94ec0(),
         (uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
        piVar6 = (int *)0x0;
      }
      if (piVar6 != (int *)0x0) {
        (**(code **)(*piVar6 + 0xa4))(&iStack_48,param_3);
        if (iStack_48 == 1) {
          iStack_40 = 1;
          *param_2 = 1;
          param_2[1] = iStack_44;
          param_2[2] = 1;
          param_2[3] = uStack_3c;
          param_2[4] = (int)piStack_38;
          uStack_3c = 0;
          piStack_38 = (int *)0x0;
          goto LAB_00b606aa;
        }
        if (iStack_40 == 1) {
          uStack_14 = 0;
          piVar6 = (int *)0x0;
          if (piStack_38 == (int *)0x0) {
LAB_00b604da:
            if (piVar6 != (int *)0x0) {
              LOCK();
              iVar1 = piVar6[1] + -1;
              piVar6[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piVar6)();
                LOCK();
                iVar1 = piVar6[2] + -1;
                piVar6[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piVar6 + 4))();
                }
              }
            }
          }
          else {
            piVar6 = piStack_38 + 1;
            iVar1 = *piVar6;
            while (iVar7 = iStack_18, iVar1 != 0) {
              LOCK();
              iVar2 = *piVar6;
              if (iVar1 == iVar2) {
                *piVar6 = iVar1 + 1;
                iVar2 = iVar1;
              }
              UNLOCK();
              if (iVar2 == iVar1) {
                uStack_14 = uStack_3c;
                piVar6 = piStack_38;
                goto LAB_00b604da;
              }
              iVar1 = *piVar6;
            }
            uStack_14 = 0;
          }
          *(undefined *)(iStack_1c + 0x58) = 1;
        }
        if (piStack_38 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_38[2] + -1;
          piStack_38[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_38 + 4))();
          }
        }
      }
      iStack_18 = iVar7 + -8;
      iVar7 = iStack_18;
      uVar8 = uStack_14;
    } while (iStack_18 != iStack_34);
  }
  if (*(char *)(iStack_1c + 0x58) == '\0') {
    iStack_1c = 0;
    piStack_74 = (int *)0x0;
    param_3 = 0;
    uStack_78 = 0;
    uVar5 = 0xc;
    iStack_18 = 0;
    puVar3 = &uStack_78;
    uStack_50 = 0;
  }
  else {
    iStack_5c = 0;
    iStack_58 = 0;
    iStack_54 = 1;
    FUN_0060e0c0(&uStack_50,0);
    puVar3 = &uStack_50;
    param_3 = iStack_58;
    uVar5 = 0x1a;
    iStack_18 = iStack_54;
    iStack_1c = iStack_5c;
  }
  iStack_70 = iStack_1c;
  iStack_6c = param_3;
  iStack_68 = iStack_18;
  piVar6 = (int *)puVar3[1];
  uStack_64 = uStack_50;
  piStack_60 = piVar6;
  *puVar3 = 0;
  puVar3[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (((uVar5 & 4) != 0) &&
     (uStack_14 = uVar5 & 0xfffffffb, uVar5 = uStack_14, piStack_74 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_74[2] + -1;
    piStack_74[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piStack_74 + 4))();
      uVar5 = uStack_14;
    }
  }
  if (((uVar5 & 2) != 0) && (piStack_4c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_4c[2] + -1;
    piStack_4c[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*piStack_4c + 4))();
    }
  }
  piVar4 = (int *)FUN_0060e0c0(auStack_28,uVar8);
  uStack_14 = piVar4[1];
  iVar7 = *piVar4;
  *piVar4 = 0;
  piVar4[1] = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[2] + -1;
    piVar6[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piVar6 + 4))();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_24 + 2;
    iVar1 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      (**(code **)(*piStack_24 + 4))();
    }
  }
  *param_2 = iStack_1c;
  param_2[1] = param_3;
  param_2[2] = iStack_18;
  param_2[3] = iVar7;
  param_2[4] = uStack_14;
LAB_00b606aa:
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24470 ; VA 0x00b606d0 ; FUN_00b606d0 */

undefined4 * __thiscall FUN_00b606d0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  if (*(char *)(param_1 + 0xdc) != '\0') {
    FUN_00b603e0(param_2,param_3);
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 24471 ; VA 0x00b60720 ; FUN_00b60720 */

void __thiscall FUN_00b60720(undefined4 param_1,uint param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4e30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_0086edd0(2,"StarterGui:RegisterGetCore must be called from a local script.",6);
  }
  else {
    puVar4 = &stack0x0000001c;
    FUN_00b5a980(&param_2);
    FUN_00d88b50(puVar4);
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    uVar2 = param_2;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_2 - 4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24472 ; VA 0x00b607e0 ; FUN_00b607e0 */

void __thiscall FUN_00b607e0(undefined4 param_1,uint param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4e30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_0086edd0(2,"StarterGui:RegisterSetCore must be called from a local script.",6);
  }
  else {
    puVar4 = &stack0x0000001c;
    FUN_00b5a980(&param_2);
    FUN_00d88b50(puVar4);
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    uVar2 = param_2;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_2 - 4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24473 ; VA 0x00b608a0 ; FUN_00b608a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b608a0(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  char ****ppppcVar6;
  undefined4 ****ppppuVar7;
  undefined4 ****ppppuVar8;
  char ****ppppcVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined auStack_d4 [8];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  float fStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 ***apppuStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 ***apppuStack_60 [4];
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  char ***pppcStack_2c;
  char **ppcStack_28;
  char **ppcStack_24;
  char **ppcStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_8 = 0xff;
  uStack_7 = 0xffffff;
  puStack_c = &LAB_017f4e60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 100) != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00b5d580();
  }
  FUN_0115afb0(param_2);
  if (DAT_01d670cc != 0) {
    iStack_48 = 0;
    puVar11 = (undefined4 *)0x0;
    do {
      uVar12 = DAT_01d670cc;
      puStack_14 = &DAT_01d670bc;
      if (0xf < DAT_01d670d0) {
        puStack_14 = DAT_01d670bc;
      }
      if ((puVar11 < DAT_01d670cc) &&
         (iVar4 = FUN_0170db20((int)puStack_14 + (int)puVar11,0x2c,DAT_01d670cc - (int)puVar11),
         iVar4 != 0)) {
        puStack_14 = (undefined4 *)(iVar4 - (int)puStack_14);
      }
      else {
        puStack_14 = (undefined4 *)0xffffffff;
      }
      iStack_50 = 0;
      uStack_4c = 0xf;
      apppuStack_60[0] = (undefined4 ***)((uint)apppuStack_60[0] & 0xffffff00);
      if (uVar12 < puVar11) {
        FUN_00554050();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
      }
      uVar12 = uVar12 - (int)puVar11;
      uVar10 = (int)puStack_14 - (int)puVar11;
      if (uVar12 < (uint)((int)puStack_14 - (int)puVar11)) {
        uVar10 = uVar12;
      }
      puVar5 = &DAT_01d670bc;
      if (0xf < DAT_01d670d0) {
        puVar5 = DAT_01d670bc;
      }
      FUN_005542c0((int)puVar5 + (int)puVar11,uVar10);
      if (iStack_50 != 0) {
        uStack_68 = 0;
        uStack_64 = 0xf;
        apppuStack_78[0] = (undefined4 ***)((uint)apppuStack_78[0] & 0xffffff00);
        uStack_1c = 0xf00000000;
        pppcStack_2c = (char ***)((uint)pppcStack_2c & 0xffffff00);
        uStack_8 = 2;
        uStack_7 = 0;
        cVar3 = FUN_016779b0(apppuStack_60,apppuStack_78,0);
        if (cVar3 == '\0') {
          cVar3 = FUN_016779b0(apppuStack_60,apppuStack_78,1);
          if (cVar3 == '\0') {
            ppppuVar8 = apppuStack_60;
            if (0xf < uStack_4c) {
              ppppuVar8 = (undefined4 ****)apppuStack_60[0];
            }
            ppppcVar6 = (char ****)FUN_01675640(auStack_44,"%s = undefined",ppppuVar8);
          }
          else {
            ppppuVar8 = apppuStack_78;
            if (0xf < uStack_64) {
              ppppuVar8 = (undefined4 ****)apppuStack_78[0];
            }
            ppppuVar7 = apppuStack_60;
            if (0xf < uStack_4c) {
              ppppuVar7 = (undefined4 ****)apppuStack_60[0];
            }
            ppppcVar6 = (char ****)
                        FUN_01675640(auStack_44,"%s = %s (not defined in C++!)",ppppuVar7,ppppuVar8)
            ;
          }
          if (&pppcStack_2c != ppppcVar6) {
            FUN_005507b0();
            pppcStack_2c = *ppppcVar6;
            ppcStack_28 = (char **)ppppcVar6[1];
            ppcStack_24 = (char **)ppppcVar6[2];
            ppcStack_20 = (char **)ppppcVar6[3];
            uStack_1c = *(undefined8 *)(ppppcVar6 + 4);
            ppppcVar6[4] = (char ***)0x0;
            ppppcVar6[5] = (char ***)0xf;
            *(undefined *)ppppcVar6 = 0;
          }
        }
        else {
          ppppuVar8 = apppuStack_78;
          if (0xf < uStack_64) {
            ppppuVar8 = (undefined4 ****)apppuStack_78[0];
          }
          ppppuVar7 = apppuStack_60;
          if (0xf < uStack_4c) {
            ppppuVar7 = (undefined4 ****)apppuStack_60[0];
          }
          ppppcVar6 = (char ****)FUN_01675640(auStack_44,"%s = %s",ppppuVar7,ppppuVar8);
          if (&pppcStack_2c != ppppcVar6) {
            pppcStack_2c = *ppppcVar6;
            ppcStack_28 = (char **)ppppcVar6[1];
            ppcStack_24 = (char **)ppppcVar6[2];
            ppcStack_20 = (char **)ppppcVar6[3];
            uStack_1c = *(undefined8 *)(ppppcVar6 + 4);
            ppppcVar6[4] = (char ***)0x0;
            ppppcVar6[5] = (char ***)0xf;
            *(undefined *)ppppcVar6 = 0;
          }
        }
        if (0xf < uStack_30) {
          uVar10 = uStack_30 + 1;
          uVar12 = auStack_44[0];
          if (0xfff < uVar10) {
            uVar12 = *(uint *)(auStack_44[0] - 4);
            uVar10 = uStack_30 + 0x24;
            uVar2 = uStack_8;
            if (0x1f < (auStack_44[0] - uVar12) - 4) goto LAB_00b60d4c;
          }
          FUN_01674ea0(uVar12,uVar10);
        }
        uStack_cc = _DAT_018e3fc0;
        uStack_c8 = _UNK_018e3fc4;
        uStack_c4 = _UNK_018e3fc8;
        uStack_c0 = _UNK_018e3fcc;
        uStack_bc = 0;
        uStack_98 = _DAT_018e3fd0;
        uStack_94 = _UNK_018e3fd4;
        uStack_90 = _UNK_018e3fd8;
        uStack_8c = _UNK_018e3fdc;
        uStack_80 = 0;
        uStack_7c = 0;
        puVar11 = (undefined4 *)FUN_0115e910();
        uStack_a8 = *puVar11;
        uStack_a4 = puVar11[1];
        uStack_a0 = puVar11[2];
        uStack_9c = 0x3f800000;
        puVar11 = (undefined4 *)FUN_0115eb80();
        iVar4 = iStack_48;
        uStack_b8 = *puVar11;
        ppppcVar6 = &pppcStack_2c;
        if (0xf < uStack_1c._4_4_) {
          ppppcVar6 = (char ****)pppcStack_2c;
        }
        uStack_b4 = puVar11[1];
        uStack_b0 = puVar11[2];
        fStack_84 = (float)iStack_48;
        uStack_ac = 0x3f800000;
        uStack_88 = 0;
        uStack_34 = 0;
        uStack_30 = 0xf;
        auStack_44[0] = auStack_44[0] & 0xffffff00;
        ppppcVar9 = ppppcVar6;
        do {
          cVar3 = *(char *)ppppcVar9;
          ppppcVar9 = (char ****)((int)ppppcVar9 + 1);
        } while (cVar3 != '\0');
        FUN_005542c0(ppppcVar6,(int)ppppcVar9 - (int)((int)ppppcVar6 + 1));
        uStack_8 = 3;
        FUN_0114e430(auStack_d4,auStack_44,&uStack_88,0x41c00000,0,&uStack_b8,&uStack_a8,4,1,0,
                     &uStack_80,&uStack_98,&uStack_cc,1);
        uStack_8 = 2;
        uVar2 = uStack_8;
        uStack_8 = 2;
        if (0xf < uStack_30) {
          uVar10 = uStack_30 + 1;
          uVar12 = auStack_44[0];
          if (0xfff < uVar10) {
            uVar12 = *(uint *)(auStack_44[0] - 4);
            uVar10 = uStack_30 + 0x24;
            if (0x1f < (auStack_44[0] - uVar12) - 4) goto LAB_00b60d4c;
          }
          FUN_01674ea0(uVar12,uVar10);
        }
        iStack_48 = iVar4 + 0x18;
        uStack_34 = 0;
        uStack_30 = 0xf;
        auStack_44[0] = auStack_44[0] & 0xffffff00;
        uStack_8 = 1;
        if (0xf < uStack_1c._4_4_) {
          uVar12 = uStack_1c._4_4_ + 1;
          ppppcVar6 = (char ****)pppcStack_2c;
          if (0xfff < uVar12) {
            ppppcVar6 = (char ****)pppcStack_2c[-1];
            uVar12 = uStack_1c._4_4_ + 0x24;
            uVar2 = uStack_8;
            if ((char *)0x1f < (char *)((int)pppcStack_2c + (-4 - (int)ppppcVar6)))
            goto LAB_00b60d4c;
          }
          FUN_01674ea0(ppppcVar6,uVar12);
        }
        uStack_8 = 0;
        if (0xf < uStack_64) {
          uVar12 = uStack_64 + 1;
          ppppuVar8 = (undefined4 ****)apppuStack_78[0];
          if (0xfff < uVar12) {
            ppppuVar8 = (undefined4 ****)apppuStack_78[0][-1];
            uVar12 = uStack_64 + 0x24;
            uVar2 = uStack_8;
            if (0x1f < (uint)((int)apppuStack_78[0] + (-4 - (int)ppppuVar8))) goto LAB_00b60d4c;
          }
          FUN_01674ea0(ppppuVar8,uVar12);
        }
        uStack_68 = 0;
        uStack_64 = 0xf;
        apppuStack_78[0] = (undefined4 ***)((uint)apppuStack_78[0] & 0xffffff00);
      }
      uStack_8 = 0xff;
      uStack_7 = 0xffffff;
      puVar11 = puStack_14;
      if (puStack_14 != (undefined4 *)0xffffffff) {
        puVar11 = (undefined4 *)((int)puStack_14 + 1);
      }
      if (0xf < uStack_4c) {
        uVar12 = uStack_4c + 1;
        ppppuVar8 = (undefined4 ****)apppuStack_60[0];
        if (0xfff < uVar12) {
          ppppuVar8 = (undefined4 ****)apppuStack_60[0][-1];
          uVar12 = uStack_4c + 0x24;
          uVar2 = uStack_8;
          if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)ppppuVar8))) {
LAB_00b60d4c:
            uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar8,uVar12);
      }
    } while (puVar11 != (undefined4 *)0xffffffff);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24474 ; VA 0x00b60d60 ; FUN_00b60d60 */

void __fastcall FUN_00b60d60(int param_1)

{
  if (*(char *)(param_1 + 0xdc) != '\0') {
    FUN_00b608a0();
    return;
  }
  return;
}



/* FUNCTION 24475 ; VA 0x00b60d80 ; FUN_00b60d80 */

void FUN_00b60d80(void)

{
  FUN_0115b000();
  return;
}



/* FUNCTION 24476 ; VA 0x00b60d90 ; FUN_00b60d90 */

void __fastcall FUN_00b60d90(int param_1)

{
  if (*(char *)(param_1 + 0xdc) != '\0') {
    FUN_0115b000();
    return;
  }
  return;
}



/* FUNCTION 24477 ; VA 0x00b60db0 ; FUN_00b60db0 */

void FUN_00b60db0(undefined4 *param_1,undefined4 param_2,undefined1 **param_3,char *param_4,
                 char param_5,double *param_6)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  double *pdVar4;
  undefined **ppuVar5;
  uint uVar6;
  undefined **ppuVar7;
  uint uVar8;
  int iVar9;
  double dVar10;
  undefined auStack_184 [16];
  undefined4 uStack_174;
  undefined *puStack_170;
  undefined1 *puStack_16c;
  undefined4 *****pppppuStack_168;
  undefined4 *puStack_164;
  char *pcStack_160;
  undefined8 uStack_15c;
  int *piStack_13c;
  int *piStack_138;
  int *piStack_12c;
  uint *puStack_128;
  int *piStack_11c;
  uint uStack_110;
  uint uStack_10c;
  undefined4 *****apppppuStack_b4 [4];
  undefined4 uStack_a4;
  uint uStack_a0;
  undefined auStack_9c [16];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 *****pppppuStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  undefined uStack_54;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [4];
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined8 uStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar9 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4f02;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  uVar8 = -(uint)(param_3 != (undefined1 **)0x0) & (int)param_3 + 0xcU;
  if (uVar8 == 0) {
    return;
  }
  uStack_15c._4_4_ = (undefined8 *)&LAB_00634100;
  uStack_15c._0_4_ = (undefined **)&DAT_01ead600;
  pcStack_160 = (char *)0xb60dfa;
  ExceptionList = &pvStack_10;
  FUN_005789c0();
  uStack_15c._4_4_ = (undefined8 *)0xb60e02;
  uStack_15c._4_4_ = (undefined8 *)FUN_00635450();
  uStack_15c._0_4_ = (undefined **)0xb60e0a;
  piStack_14 = (int *)FUN_008aa140();
  if (*piStack_14 == 0) {
    uStack_15c._4_4_ = (undefined8 *)0xb60e1b;
    uStack_15c._4_4_ = (undefined8 *)FUN_00b7a190();
    uStack_15c._0_4_ = (undefined **)auStack_24;
    pcStack_160 = (char *)0xb60e27;
    piVar3 = (int *)FUN_008a9ba0();
    iVar9 = *piVar3;
    iVar1 = piVar3[1];
    *piVar3 = 0;
    piVar3[1] = 0;
    *piStack_14 = iVar9;
    piVar3 = (int *)piStack_14[1];
    piStack_14[1] = iVar1;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar9 = piVar3[1] + -1;
      piVar3[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_15c._4_4_ = (undefined8 *)0xb60e58;
        (**(code **)*piVar3)();
        LOCK();
        iVar9 = piVar3[2] + -1;
        piVar3[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          uStack_15c._4_4_ = (undefined8 *)0xb60e6b;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    iVar9 = (int)param_3;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_15c._4_4_ = (undefined8 *)0xb60e82;
        (**(code **)*piStack_20)();
        LOCK();
        piVar3 = piStack_20 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        iVar9 = (int)param_3;
        if (iVar1 == 1) {
          uStack_15c._4_4_ = (undefined8 *)0xb60e94;
          (**(code **)(*piStack_20 + 4))();
          iVar9 = (int)param_3;
        }
      }
    }
  }
  if (*piStack_14 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uStack_15c._4_4_ = (undefined8 *)0xb60ea9;
  cVar2 = FUN_00b83620();
  if (cVar2 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (*param_4 == '\0') {
    if (param_5 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    uStack_15c._4_4_ = (undefined8 *)auStack_24;
    uStack_15c._0_4_ = (undefined **)0xb60ecc;
    pdVar4 = (double *)FUN_01682800();
    dVar10 = *pdVar4 - *param_6;
  }
  else {
    dVar10 = 0.0;
  }
  param_3 = (undefined1 **)(int)dVar10;
  *param_4 = '\0';
  uStack_15c._4_4_ = (undefined8 *)0xb60ef1;
  FUN_00b62060();
  uStack_15c._4_4_ = (undefined8 *)param_2;
  uStack_15c._0_4_ = (undefined **)apppppuStack_b4;
  pcStack_160 = (char *)0xb60f02;
  FUN_009cb090();
  uStack_8 = 1;
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_15c._4_4_ = (undefined8 *)(param_1[4] + 1);
  uStack_54 = 0;
  piStack_14 = (int *)0x3;
  uStack_15c._0_4_ = (undefined **)0xb60f32;
  FUN_0058a190();
  uStack_15c._0_4_ = (undefined **)param_1;
  if (0xf < (uint)param_1[5]) {
    uStack_15c._0_4_ = (undefined **)*param_1;
  }
  uStack_15c._4_4_ = (undefined8 *)param_1[4];
  pcStack_160 = (char *)0xb60f4b;
  FUN_00554150();
  uStack_15c._4_4_ = (undefined8 *)0x1;
  uStack_15c._0_4_ = (undefined **)&DAT_018bf378;
  pcStack_160 = (char *)0xb60f5a;
  FUN_00554150();
  uStack_15c._4_4_ = (undefined8 *)uStack_a4;
  uStack_15c._0_4_ = (undefined **)apppppuStack_b4;
  if (0xf < uStack_a0) {
    uStack_15c._0_4_ = (undefined **)apppppuStack_b4[0];
  }
  pcStack_160 = (char *)0xb60f7d;
  piVar3 = (int *)FUN_00554150();
  pppppuStack_6c = (undefined4 *****)*piVar3;
  iStack_68 = piVar3[1];
  iStack_64 = piVar3[2];
  iStack_60 = piVar3[3];
  uStack_5c = *(undefined8 *)(piVar3 + 4);
  piVar3[4] = 0;
  piVar3[5] = 0xf;
  *(undefined *)piVar3 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_15c._4_4_ = (undefined8 *)0xb60fb9;
  FUN_005507b0();
  if (iVar9 == 0) {
    uStack_1c = 0;
    uStack_15c = 0;
  }
  else {
    uStack_15c._4_4_ = (undefined8 *)0xb60fc4;
    uStack_15c = FUN_005ea010();
  }
  puStack_164 = (undefined4 *)auStack_84;
  pcStack_160 = "placeId: %lld";
  pppppuStack_168 = (undefined4 *****)0xb60fe4;
  puStack_164 = (undefined4 *)FUN_01675640();
  uStack_8._0_1_ = 4;
  if (0xf < (uint)puStack_164[5]) {
    puStack_164 = (undefined4 *)*puStack_164;
  }
  uStack_15c._4_4_ = (undefined8 *)0x0;
  pppppuStack_168 = &pppppuStack_6c;
  if (0xf < uStack_5c._4_4_) {
    pppppuStack_168 = pppppuStack_6c;
  }
  uStack_15c._0_4_ = (undefined **)((int)param_3 >> 0x1f);
  pcStack_160 = (char *)param_3;
  puStack_16c = &DAT_018c5f98;
  puStack_170 = (undefined *)0xb61014;
  FUN_0087c450();
  uStack_8._0_1_ = 3;
  uStack_15c._4_4_ = (undefined8 *)0xb61023;
  FUN_005507b0();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef50c) {
    uStack_15c._4_4_ = (undefined8 *)&DAT_01eef50c;
    uStack_15c._0_4_ = (undefined **)0xb6124f;
    FUN_016f3809();
    if (DAT_01eef50c == -1) {
      uStack_8._0_1_ = 5;
      uStack_15c._4_4_ = (undefined8 *)0xb61268;
      uVar6 = FUN_01679ce0();
      uStack_8._0_1_ = 3;
      DAT_01eef508 = uVar6 % 10000;
      uStack_15c._4_4_ = (undefined8 *)&DAT_01eef50c;
      uStack_15c._0_4_ = (undefined **)0xb61285;
      FUN_016f37bf();
    }
  }
  if (DAT_01eef4e8 <= (int)DAT_01eef508) goto LAB_00b61208;
  uStack_15c._4_4_ = (undefined8 *)0x1;
  uStack_15c._0_4_ = (undefined **)0x2;
  pcStack_160 = (char *)0xb61063;
  FUN_00565520();
  uStack_15c._4_4_ = (undefined8 *)param_3;
  uStack_8._0_1_ = 6;
  uStack_15c._0_4_ = (undefined **)0xb61075;
  FUN_005af260();
  uStack_15c._4_4_ = (undefined8 *)&param_3;
  auStack_3c[0] = 0;
  uStack_15c._0_4_ = &boost::lock_error::vftable_meta_ptr;
  pcStack_160 = "\x11";
  param_3 = (undefined1 **)0xb;
  puStack_164 = (undefined4 *)0xb61093;
  ppuVar5 = (undefined **)FUN_00563d40();
  ppuVar7 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar5;
  }
  puStack_38 = *ppuVar7;
  uStack_34 = 0;
  uStack_30 = 0x3f800000;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uStack_8c = 0;
  uStack_88 = 0xf;
  auStack_9c[0] = 0;
  piStack_14 = (int *)0x15;
  if (((uStack_10c & 2) == 0) && (uVar6 = *puStack_128, uVar6 != 0)) {
    if (uVar6 < uStack_110) {
      uVar6 = uStack_110;
    }
    uStack_15c._0_4_ = (undefined **)*piStack_138;
    uStack_15c._4_4_ = (undefined8 *)(uVar6 - (int)(undefined **)uStack_15c);
LAB_00b6113b:
    pcStack_160 = (char *)0xb61148;
    FUN_005542c0();
  }
  else if (((uStack_10c & 4) == 0) && (*piStack_12c != 0)) {
    uStack_15c._0_4_ = (undefined **)*piStack_13c;
    uStack_15c._4_4_ = (undefined8 *)((*piStack_12c - (int)(undefined **)uStack_15c) + *piStack_11c)
    ;
    goto LAB_00b6113b;
  }
  uStack_15c._4_4_ = (undefined8 *)0x2;
  uStack_15c._0_4_ = (undefined **)&DAT_0192b7dc;
  uStack_8 = 9;
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = 0;
  pcStack_160 = (char *)0xb61170;
  FUN_005542c0();
  uStack_15c._4_4_ = (undefined8 *)auStack_9c;
  uStack_8._0_1_ = 10;
  uStack_15c._0_4_ = (undefined **)auStack_84;
  pcStack_160 = (undefined *)0xb61187;
  FUN_005d15d0();
  uStack_15c._0_4_ = (undefined **)0xb6118f;
  FUN_005511f0();
  uStack_15c._4_4_ = (undefined8 *)0xb61197;
  FUN_005507b0();
  uStack_8._0_1_ = 7;
  uStack_15c._4_4_ = (undefined8 *)0xb611a6;
  FUN_005507b0();
  param_3 = &puStack_16c;
  piStack_14 = (int *)&puStack_16c;
  puStack_170 = auStack_3c;
  uStack_174 = 0xb611ba;
  FUN_0060e660();
  piStack_14 = (int *)auStack_184;
  uStack_8._0_1_ = 0xb;
  FUN_0054ef60(apppppuStack_b4);
  uStack_8._0_1_ = 0xc;
  FUN_0054ef60(param_1);
  uStack_8._0_1_ = 7;
  FUN_0087a3e0(uVar8);
  uStack_15c._4_4_ = (undefined8 *)0xb611f9;
  FUN_0056cfd0();
  uStack_8._0_1_ = 3;
  uStack_15c._4_4_ = (undefined8 *)0xb61208;
  FUN_00570540();
LAB_00b61208:
  uStack_15c._4_4_ = &uStack_1c;
  uStack_15c._0_4_ = (undefined **)0xb61211;
  FUN_01682800();
  *(undefined4 *)param_6 = (undefined4)uStack_1c;
  *(undefined4 *)((int)param_6 + 4) = uStack_1c._4_4_;
  uStack_15c._4_4_ = (undefined8 *)0xb6122a;
  FUN_005507b0();
  uStack_15c._4_4_ = (undefined8 *)0xb61235;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24478 ; VA 0x00b61290 ; FUN_00b61290 */

void __fastcall FUN_00b61290(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 != (int *)0x0) {
    puVar2 = (undefined4 *)*piVar1;
    puVar6 = (undefined4 *)piVar1[1];
    while (puVar6 != puVar2) {
      iVar3 = puVar6[-2];
      puVar6 = puVar6 + -2;
      if ((iVar3 != 0) &&
         ((iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00d5e4a0(),
          (uint)*(ushort *)(iVar5 + 0x1da) <
          (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) ||
          (*(char *)(iVar3 + 0x174) != '\0')))) {
        (**(code **)(*(int *)*puVar6 + 0x2c))();
      }
    }
  }
  return;
}



/* FUNCTION 24479 ; VA 0x00b61300 ; FUN_00b61300 */

byte __thiscall FUN_00b61300(int param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00b739e0();
  iVar5 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar5 = param_2;
  }
  if (iVar5 != 0) {
    iVar3 = FUN_0097bfc0(param_1 + -0x54);
    if ((iVar3 != 0) && (*(int *)(param_1 + -0x20) == iVar3)) {
      return 1;
    }
    return 0;
  }
  bVar1 = FUN_00971ce0(param_1 + -0x54,0);
  if (DAT_01d68ab4 != '\0') {
    iVar3 = *(int *)(param_1 + -0x20);
    if (iVar3 != 0) {
      iVar5 = *(int *)(iVar3 + 0xc);
      iVar4 = FUN_00913630();
      iVar2 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar2 = iVar3;
      }
      if (iVar2 != 0) {
        return bVar1 & 1;
      }
    }
    bVar1 = 0;
  }
  return bVar1;
}



/* FUNCTION 24480 ; VA 0x00b613d0 ; FUN_00b613d0 */

int __thiscall FUN_00b613d0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_74 [16];
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4f30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  iStack_14 = FUN_006ebc30(param_1);
  if (iStack_14 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  piVar6 = (int *)0x0;
  uStack_44 = 0;
  piVar8 = (int *)0x0;
  piStack_40 = (int *)0x0;
  piStack_3c = (int *)0x0;
  piStack_38 = (int *)0x0;
  uStack_8 = 0;
  uVar1 = FUN_00b98d90(param_1);
  FUN_0060dcd0(&iStack_2c,uVar1);
  uStack_8._0_1_ = 1;
  if (iStack_2c == 0) {
    iStack_14 = 0;
  }
  else {
    puVar2 = (undefined4 *)FUN_00d5c5d0(auStack_74);
    piVar9 = piStack_28;
    uStack_54 = *puVar2;
    uStack_50 = puVar2[1];
    uStack_4c = puVar2[2];
    uStack_48 = puVar2[3];
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    puVar2 = (undefined4 *)FUN_00b98fc0(auStack_64,iStack_2c,piStack_28);
    uStack_44 = *puVar2;
    piVar6 = (int *)puVar2[1];
    *puVar2 = 0;
    puVar2[1] = 0;
    piVar8 = (int *)puVar2[3];
    piStack_3c = (int *)puVar2[2];
    puVar2[2] = 0;
    puVar2[3] = 0;
    piStack_40 = piVar6;
    piStack_38 = piVar8;
    piStack_24 = piVar6;
    piStack_1c = piStack_3c;
    FUN_0096bfc0();
    iStack_14 = 0;
    iVar3 = FUN_00b5b8b0(&iStack_2c,param_2);
    if (iVar3 == 0) {
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
      }
      piStack_34 = piStack_1c;
      uStack_8._0_1_ = 2;
      piStack_30 = piVar8;
      if (piStack_1c == (int *)0x0) {
        uVar1 = 0;
        piVar5 = (int *)0x0;
        if (piVar6 != (int *)0x0) {
          piVar7 = piVar6 + 1;
          iVar3 = piVar6[1];
          while (piVar9 = piStack_28, piVar6 = piStack_40, piVar8 = piStack_38, iVar3 != 0) {
            LOCK();
            iVar4 = *piVar7;
            if (iVar3 == iVar4) {
              *piVar7 = iVar3 + 1;
              iVar4 = iVar3;
            }
            UNLOCK();
            uVar1 = uStack_44;
            piVar5 = piStack_24;
            if (iVar4 == iVar3) goto LAB_00b6157a;
            iVar3 = *piVar7;
          }
          uVar1 = 0;
          piVar5 = (int *)0x0;
        }
LAB_00b6157a:
        uStack_8._0_1_ = 3;
        uStack_20 = 0;
        piStack_1c = (int *)0x0;
        iStack_14 = FUN_00b5b570(param_2,&uStack_54,uVar1,piVar5);
        FUN_00550b30();
      }
      else {
        iVar3 = piStack_1c[1] - *piStack_1c >> 0x1f;
        if ((piStack_1c[1] - *piStack_1c) / 0xd0 + iVar3 != iVar3) {
          iStack_14 = FUN_00b5b710(param_2,&uStack_54,&piStack_3c);
        }
      }
      uStack_8._0_1_ = 1;
      FUN_00550b30();
      piStack_28 = piVar9;
      iVar3 = iStack_14;
      if (iStack_14 == 0) goto LAB_00b615f3;
    }
    iStack_14 = iVar3;
    iVar3 = FUN_006ebc30(uStack_18);
    piStack_28 = piVar9;
    if (iVar3 != 0) {
      FUN_00b9d020(iStack_14,uStack_18);
    }
  }
LAB_00b615f3:
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = piVar8[1] + -1;
    piVar8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar3 = piVar8[2] + -1;
      piVar8[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar8 = piVar6 + 2;
    iVar3 = *piVar8;
    *piVar8 = *piVar8 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar6 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iStack_14;
}



/* FUNCTION 24481 ; VA 0x00b61670 ; FUN_00b61670 */

void __thiscall FUN_00b61670(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xde)) {
    *(char *)(param_1 + 0xde) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 24482 ; VA 0x00b616a0 ; FUN_00b616a0 */

void __thiscall FUN_00b616a0(int param_1,uint param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_00000020;
  undefined auStack_60 [20];
  int *piStack_4c;
  undefined auStack_40 [12];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_24;
  undefined auStack_20 [4];
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017f4f68;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff94;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_0086edd0(2,"StarterGui:SetCore must be called from a local script.",6);
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < in_stack_00000018) {
      uVar5 = in_stack_00000018 + 1;
      uVar4 = param_2;
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(param_2 - 4);
        uVar5 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_2 = param_2 & 0xffffff00;
    uStack_8 = 2;
  }
  else {
    iVar6 = param_1 + 0xa5 + (uint)*(byte *)(param_1 + 0xa4);
    uVar2 = FUN_0055c740(iVar6,&param_2);
    FUN_008992d0(&piStack_18,uVar2,&param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
    if (piStack_18 == (int *)0x0) {
      uVar2 = FUN_005543f0();
      FUN_016756b0(auStack_40,"SetCore: %s has not been registered by the CoreScripts",uVar2);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
    FUN_00d88580(piStack_18 + 8);
    piStack_18 = piStack_4c;
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    piStack_24 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      *piStack_4c = *piStack_4c + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    if (piStack_4c != (int *)0x0) {
      if (piStack_4c[2] != 0) {
        iVar6 = *(int *)(param_1 + 0x34);
        iVar3 = iStack_1c;
        if ((iVar6 != 0) && (iVar3 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
          iVar3 = FUN_005c8ac0();
        }
        if (((iVar3 != 0) &&
            (iVar6 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
            (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da))) && (iVar6 = FUN_0055ea10(), iVar6 != 0)) {
          uStack_34 = 0;
          uStack_30 = 0;
          uStack_2c = 0;
          uStack_8._0_1_ = 6;
          FUN_0098ded0(0,&stack0x0000001c);
          FUN_0094b750(auStack_20,auStack_60,&uStack_34);
          FUN_00550b30();
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          FUN_00577b20();
          FUN_00b618af();
          return;
        }
      }
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar6 = *piStack_4c;
        *piStack_4c = *piStack_4c + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piStack_4c,0x10);
        }
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    FUN_00d88a30();
    FUN_005507b0();
    uStack_8 = 9;
  }
  if (in_stack_00000020 != 0) {
    (**(code **)(in_stack_00000020 + 8))(&stack0x00000024);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24483 ; VA 0x00b6188e ; Catch@00b6188e */

undefined * Catch_00b6188e(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
  FUN_0086f2f0(3,"SetCore: Unexpected error while invoking callback: %s",uVar1);
  return &DAT_00b618ac;
}



/* FUNCTION 24484 ; VA 0x00b618af ; FUN_00b618af */

void FUN_00b618af(void)

{
  int iVar1;
  int unaff_EBP;
  int *unaff_EDI;
  
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    iVar1 = *unaff_EDI;
    *unaff_EDI = *unaff_EDI + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_00d88950();
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  FUN_00d88a30();
  FUN_005507b0();
  *(undefined4 *)(unaff_EBP + -4) = 9;
  if (*(int *)(unaff_EBP + 0x24) != 0) {
    (**(code **)(*(int *)(unaff_EBP + 0x24) + 8))(unaff_EBP + 0x28);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 24485 ; VA 0x00b61930 ; FUN_00b61930 */

void __thiscall FUN_00b61930(undefined4 param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iStack_8;
  
  cVar1 = FUN_0097c970(param_1,1);
  uVar3 = param_3;
  if (cVar1 == '\0') {
    FUN_0086edd0(2,"StarterGui:SetCoreGuiEnabled must be called from a local script.",6);
    return;
  }
  if (param_2 == 4) {
    iVar4 = 0;
    do {
      param_3 = iVar4;
      iVar2 = FUN_00b5abd0(&param_3);
      iVar4 = iVar4 + 1;
      *(char *)(iVar2 + 4) = (char)uVar3;
    } while (iVar4 < 6);
  }
  else {
    iVar4 = FUN_00b5abd0(&param_2);
    uVar3 = param_3;
    iVar2 = 0;
    cVar1 = (char)param_3;
    param_3 = CONCAT13(cVar1,(undefined3)param_3);
    *(char *)(iVar4 + 4) = cVar1;
    do {
      if ((iVar2 != 4) &&
         (iStack_8 = iVar2, iVar4 = FUN_00b5abd0(&iStack_8), cVar1 != *(char *)(iVar4 + 4))) {
        param_3 = 4;
        iVar4 = FUN_00b5abd0(&param_3);
        *(undefined *)(iVar4 + 4) = 0;
        iVar4 = FUN_00b5abd0(&iStack_8);
        param_3 = CONCAT13(*(char *)(iVar4 + 4),(undefined3)param_3);
        if (*(char *)(iVar4 + 4) != cVar1) goto LAB_00b61a08;
        break;
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < 6);
    iStack_8 = 4;
    iVar4 = FUN_00b5abd0(&iStack_8);
    *(undefined *)(iVar4 + 4) = param_3._3_1_;
  }
LAB_00b61a08:
  FUN_005e66b0(param_2,uVar3);
  return;
}



/* FUNCTION 24486 ; VA 0x00b61a30 ; FUN_00b61a30 */

void __thiscall FUN_00b61a30(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00c6de80(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 24487 ; VA 0x00b61ae0 ; FUN_00b61ae0 */

void __thiscall FUN_00b61ae0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xdd) != param_2) {
    *(char *)(param_1 + 0xdd) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 24488 ; VA 0x00b61b10 ; FUN_00b61b10 */

void __thiscall FUN_00b61b10(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_1 + 0x84);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar3 = FUN_008f7870(param_1);
  uVar1 = *(undefined4 *)(param_1 + 0x84);
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("PlayerGuiSetScreenOrientationTouchDevice",0x28);
  iVar2 = iStack_14;
  uStack_8 = 0;
  FUN_00b60db0(auStack_2c,uVar1,uVar3,iStack_14 + 0x8c,iVar5 != param_2,iStack_14 + 0x90);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_18) {
    uVar7 = uStack_18 + 1;
    uVar6 = auStack_2c[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_2c[0] - 4);
      uVar7 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  if (*(int *)(iVar2 + 0x84) != param_2) {
    *(int *)(iVar2 + 0x84) = param_2;
    FUN_008a4940(&DAT_0212c3d8);
    iVar5 = *(int *)(iVar2 + 0x34);
    iVar4 = iVar2;
    if ((iVar5 != 0) && (iVar4 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      iVar4 = FUN_005c8ac0();
    }
    if (((iVar4 != 0) &&
        (iVar5 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_009172e0(), iVar5 != 0)) {
      FUN_005e6780(*(undefined4 *)(iVar2 + 0x84));
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24489 ; VA 0x00b61c70 ; FUN_00b61c70 */

void __thiscall FUN_00b61c70(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xe0) != param_2) {
    *(int *)(param_1 + 0xe0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 24490 ; VA 0x00b61ca0 ; FUN_00b61ca0 */

void __thiscall FUN_00b61ca0(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 != *(int *)(param_1 + 0x7c)) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x7c) = uVar1;
    piVar3 = *(int **)(param_1 + 0x80);
    *(undefined4 *)(param_1 + 0x80) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_0212c2dc);
  }
  return;
}



/* FUNCTION 24491 ; VA 0x00b61d50 ; FUN_00b61d50 */

void __thiscall FUN_00b61d50(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_2 != *(int *)(param_1 + 0x7c)) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x7c) = uVar1;
    piVar3 = *(int **)(param_1 + 0x80);
    *(undefined4 *)(param_1 + 0x80) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_0212c2a0);
  }
  return;
}



/* FUNCTION 24492 ; VA 0x00b61e00 ; FUN_00b61e00 */

void __thiscall FUN_00b61e00(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xdc) != param_2) {
    *(char *)(param_1 + 0xdc) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 24493 ; VA 0x00b61e30 ; FUN_00b61e30 */

void __thiscall FUN_00b61e30(int param_1,float param_2)

{
  char cVar1;
  float fVar2;
  float fVar3;
  undefined auStack_10 [12];
  
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 != '\0') {
    cVar1 = FUN_01160820(param_2);
    if (cVar1 != '\0') {
      fVar2 = 0.0;
      if (0.0 <= param_2) {
        fVar2 = param_2;
      }
      fVar3 = DAT_018ce2f8;
      if (fVar2 <= DAT_018ce2f8) {
        fVar3 = fVar2;
      }
      if ((NAN(*(float *)(param_1 + 0x88)) || NAN(fVar3)) == (*(float *)(param_1 + 0x88) == fVar3))
      {
        *(float *)(param_1 + 0x88) = fVar3;
        FUN_0091b810(fVar3);
      }
    }
    return;
  }
  FUN_00550130("PlayerGui:SetTopbarTransparency can only be set from a local script.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 24494 ; VA 0x00b61ec0 ; FUN_00b61ec0 */

int __thiscall
FUN_00b61ec0(int param_1,undefined param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  
  *(undefined *)(param_1 + 0x94) = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x98) = param_3;
  piVar1 = *(int **)(param_1 + 0x9c);
  *(int **)(param_1 + 0x9c) = param_4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  *(int *)(param_1 + 0xa0) = param_5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    param_5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_5 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_5;
}



/* FUNCTION 24495 ; VA 0x00b61f60 ; FUN_00b61f60 */

void __thiscall FUN_00b61f60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00b62060();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24496 ; VA 0x00b61fb0 ; FUN_00b61fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b61fb0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4f96;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefdec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefdec);
    if (DAT_01eefdec == -1) {
      uStack_8 = 0;
      FUN_009ca470("CoreGuiType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eefd88 = RBX::Reflection::EnumDesc<enum_RBX::StarterGuiService::CoreGuiType>::vftable;
      FUN_009caf20(&DAT_01d670dc,6);
      FUN_016f3654(&LAB_0188e320);
      FUN_016f37bf(&DAT_01eefdec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eefd88;
}



/* FUNCTION 24497 ; VA 0x00b62060 ; FUN_00b62060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b62060(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4fb6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe54);
    if (DAT_01eefe54 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ScreenOrientation");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eefdf0 = RBX::Reflection::EnumDesc<enum_RBX::BasePlayerGui::ScreenOrientation>::vftable
      ;
      FUN_009cada0(0,"LandscapeLeft");
      FUN_009cada0(1,"LandscapeRight");
      FUN_009cada0(2,"LandscapeSensor");
      FUN_009cada0(3,"Portrait");
      FUN_009cada0(4,"Sensor");
      FUN_016f3654(&LAB_0188e340);
      FUN_016f37bf(&DAT_01eefe54);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eefdf0;
}



/* FUNCTION 24498 ; VA 0x00b62160 ; FUN_00b62160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b62160(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4fcc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe7c);
    if (DAT_01eefe7c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01eefe58 = RBX::Reflection::RefType<class_RBX::GuiObject*>::vftable;
      FUN_016f3654(&LAB_0188e490);
      FUN_016f37bf(&DAT_01eefe7c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eefe58;
}



/* FUNCTION 24499 ; VA 0x00b62210 ; FUN_00b62210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b62210(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe8c) {
    FUN_016f3809(&DAT_01eefe8c);
    if (DAT_01eefe8c == -1) {
      _DAT_01eefe80 = FUN_005c65e0;
      _DAT_01eefe84 = FUN_005c65e0;
      _DAT_01eefe88 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eefe8c);
    }
  }
  return &DAT_01eefe80;
}


