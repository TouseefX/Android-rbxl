/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 21750 ; VA 0x00a95020 ; FUN_00a95020 */

undefined4 * FUN_00a95020(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5d30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e40f60();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x6c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e411a0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a949f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21751 ; VA 0x00a950e0 ; FUN_00a950e0 */

undefined4 * FUN_00a950e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5d73;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c39bb0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3ae40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94ae0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21752 ; VA 0x00a951a0 ; FUN_00a951a0 */

void __thiscall FUN_00a951a0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_00725d90(puVar2,param_2);
  return;
}



/* FUNCTION 21753 ; VA 0x00a951f0 ; FUN_00a951f0 */

void __thiscall FUN_00a951f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = FUN_0088cdc0();
    *puVar1 = uVar2;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[2] = *param_2;
    puVar1[3] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar2 = FUN_006309e0();
    puVar1[1] = uVar2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xd0;
    return;
  }
  FUN_00a94390(puVar1,param_2);
  return;
}



/* FUNCTION 21754 ; VA 0x00a95260 ; FUN_00a95260 */

void __thiscall FUN_00a95260(int param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5d88;
  pvStack_10 = ExceptionList;
  uVar3 = *param_3;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar9 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar9;
    }
    if (piVar5 == (int *)0x0) goto LAB_00a952fe;
    do {
      if (uVar8 == piVar5[1]) {
        if (uVar3 == piVar5[2]) break;
      }
      else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar7) goto LAB_00a952fe;
      piVar5 = (int *)*piVar5;
    } while (piVar5 != (int *)0x0);
  }
  if (piVar5 != (int *)0x0) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_00a952fe:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(0xc);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  piVar5[2] = *param_4;
  uVar7 = *(uint *)(param_1 + 8);
  uVar3 = uVar7 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005c9310(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    uVar6 = uVar7 >> 1;
    if (uVar7 + (uVar7 >> 1) <= uVar3) {
      uVar6 = 1;
    }
    iVar4 = FUN_005c9310(uVar6 + uVar7);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar9;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar2 = (int)puVar9;
          puVar9 = puVar1;
        }
        else {
          *puVar9 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar9 = piVar2;
    *piVar5 = *piVar2;
    *piVar2 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar2;
    *(int **)*puVar9 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21755 ; VA 0x00a95450 ; FUN_00a95450 */

undefined8 *
FUN_00a95450(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5dbc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1b8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb1b8);
    if (DAT_01eeb1b8 == -1) {
      uStack_8 = 0;
      uVar7 = FUN_0152dab0(&DAT_018cb3fc,"getHitLocationPartFilterDescendents",0xffffffff);
      DAT_01eeb1b4 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eeb1b0 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eeb1b8);
    }
  }
  uStack_1c = DAT_01eeb1b0;
  uStack_18 = DAT_01eeb1b4;
  uVar7 = FUN_0152d930(DAT_01eeb1b0,DAT_01eeb1b4);
  uStack_8 = 1;
  iStack_14 = 0;
  FUN_00f9b960(param_2);
  uStack_8._0_1_ = 2;
  FUN_00a9d1f0(&uStack_30,auStack_24,param_3,param_4,param_5,param_6,param_7,&iStack_14,param_9,
               param_10,param_11,param_12,param_13,0,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_14 == 0) {
    *param_8 = 0;
    piVar3 = (int *)param_8[1];
    param_8[1] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    *param_1 = uStack_30;
    *(undefined4 *)(param_1 + 1) = uStack_28;
    uStack_8 = 4;
  }
  else {
    uVar5 = FUN_00b06640(iStack_14);
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_24,uVar5);
    uVar5 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *param_8 = uVar5;
    piVar3 = (int *)param_8[1];
    param_8[1] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar3 = piStack_20 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    *param_1 = uStack_30;
    *(undefined4 *)(param_1 + 1) = uStack_28;
    uStack_8 = 3;
  }
  FUN_0152dda0(uStack_1c,uStack_18,uVar7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21756 ; VA 0x00a95690 ; FUN_00a95690 */

undefined8 *
FUN_00a95690(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined8 uStack_54;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5dec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1a8) {
    uStack_54._4_4_ = &DAT_01eeb1a8;
    uStack_54._0_4_ = (char *)0xa958a2;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eeb1a8 == -1) {
      uStack_54._4_4_ = (undefined4 *)0xffffffff;
      uStack_54._0_4_ = "getHitLocationPartFilterDescendents";
      uStack_8 = 0;
      uVar7 = FUN_0152dab0(&DAT_018cb3fc);
      DAT_01eeb1a4 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eeb1a0 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eeb1a8);
    }
  }
  uStack_54._4_4_ = (undefined4 *)DAT_01eeb1a4;
  uStack_54._0_4_ = (char *)DAT_01eeb1a0;
  uStack_1c = DAT_01eeb1a0;
  uStack_18 = DAT_01eeb1a4;
  uVar7 = FUN_0152d930();
  uStack_8 = 1;
  iStack_14 = 0;
  FUN_0060dcd0(&uStack_54,param_2);
  FUN_00f9b8c0();
  uStack_54._4_4_ = (undefined4 *)0x1;
  uStack_54._0_4_ = (char *)0x0;
  uStack_8._0_1_ = 2;
  FUN_00a9d1f0(&uStack_34,auStack_28,param_3,param_4,param_5,param_6,param_7,&iStack_14,param_9,
               param_10,param_11,param_12,param_13);
  piVar4 = piStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_54._4_4_ = (undefined4 *)0xa95774;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa95784;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (iStack_14 == 0) {
    *param_8 = 0;
    piVar4 = (int *)param_8[1];
    param_8[1] = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa95848;
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_54._4_4_ = (undefined4 *)0xa95857;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    *param_1 = uStack_34;
    *(undefined4 *)(param_1 + 1) = uStack_2c;
    uStack_8 = 4;
  }
  else {
    uStack_54._4_4_ = (undefined4 *)iStack_14;
    uStack_54._0_4_ = (char *)0xa95795;
    uStack_54._0_4_ = (char *)FUN_00b06640();
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_24);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *param_8 = uVar2;
    piVar4 = (int *)param_8[1];
    param_8[1] = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa957d2;
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_54._4_4_ = (undefined4 *)0xa957e2;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa957f8;
        (**(code **)*piStack_20)();
        LOCK();
        piVar4 = piStack_20 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_54._4_4_ = (undefined4 *)0xa95807;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    *param_1 = uStack_34;
    *(undefined4 *)(param_1 + 1) = uStack_2c;
    uStack_8 = 3;
  }
  uStack_54 = uVar7;
  FUN_0152dda0(uStack_1c,uStack_18);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21757 ; VA 0x00a958f0 ; FUN_00a958f0 */

undefined8 *
FUN_00a958f0(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  undefined8 uStack_54;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5e1c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1c8) {
    uStack_54._4_4_ = &DAT_01eeb1c8;
    uStack_54._0_4_ = (char *)0xa95b03;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eeb1c8 == -1) {
      uStack_54._4_4_ = (undefined4 *)0xffffffff;
      uStack_54._0_4_ = "getHitLocationPartFilterDescendents";
      uStack_8 = 0;
      uVar7 = FUN_0152dab0(&DAT_018cb3fc);
      DAT_01eeb1c4 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01eeb1c0 = (undefined4)uVar7;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eeb1c8);
    }
  }
  uStack_54._4_4_ = (undefined4 *)DAT_01eeb1c4;
  uStack_54._0_4_ = (char *)DAT_01eeb1c0;
  uStack_1c = DAT_01eeb1c0;
  uStack_18 = DAT_01eeb1c4;
  uVar7 = FUN_0152d930();
  uStack_8 = 1;
  iStack_14 = 0;
  FUN_0060dcd0(&uStack_54,param_2);
  FUN_00f9b8c0();
  uStack_54._4_4_ = (undefined4 *)0x0;
  uStack_54._0_4_ = (char *)param_14;
  uStack_8._0_1_ = 2;
  FUN_00a9d1f0(&uStack_34,auStack_28,param_3,param_4,param_5,param_6,param_7,&iStack_14,param_9,
               param_10,param_11,param_12,param_13);
  piVar4 = piStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_54._4_4_ = (undefined4 *)0xa959d5;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa959e5;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (iStack_14 == 0) {
    *param_8 = 0;
    piVar4 = (int *)param_8[1];
    param_8[1] = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa95aa9;
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_54._4_4_ = (undefined4 *)0xa95ab8;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    *param_1 = uStack_34;
    *(undefined4 *)(param_1 + 1) = uStack_2c;
    uStack_8 = 4;
  }
  else {
    uStack_54._4_4_ = (undefined4 *)iStack_14;
    uStack_54._0_4_ = (char *)0xa959f6;
    uStack_54._0_4_ = (char *)FUN_00b06640();
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_24);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *param_8 = uVar2;
    piVar4 = (int *)param_8[1];
    param_8[1] = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa95a33;
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_54._4_4_ = (undefined4 *)0xa95a43;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_54._4_4_ = (undefined4 *)0xa95a59;
        (**(code **)*piStack_20)();
        LOCK();
        piVar4 = piStack_20 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          uStack_54._4_4_ = (undefined4 *)0xa95a68;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    *param_1 = uStack_34;
    *(undefined4 *)(param_1 + 1) = uStack_2c;
    uStack_8 = 3;
  }
  uStack_54 = uVar7;
  FUN_0152dda0(uStack_1c,uStack_18);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21758 ; VA 0x00a95b50 ; FUN_00a95b50 */

undefined4 *
FUN_00a95b50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,int *param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11)

{
  int *piVar1;
  int iVar2;
  undefined auStack_44 [12];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e5e50;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_14 = 0x700;
  ExceptionList = &pvStack_10;
  FUN_00a95450(auStack_44,param_7,param_2,param_3,param_4,param_5,param_6,&uStack_1c,&uStack_38,
               &uStack_14,param_9,param_10,param_11);
  FUN_008c05f0(&piStack_2c);
  uStack_8 = 2;
  if ((uint)((piStack_2c[2] - *piStack_2c) / 0xd0) < 4) {
    FUN_00a974c0(4);
  }
  piVar1 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  uStack_24 = uStack_1c;
  piStack_20 = piStack_18;
  uStack_8 = 3;
  FUN_00a951f0(&uStack_24);
  _uStack_8 = CONCAT31(uStack_7,2);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a940b0(piStack_2c[1],auStack_44);
  }
  else {
    FUN_00912980(auStack_44);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a940b0(piStack_2c[1],&uStack_38);
  }
  else {
    FUN_00912980(&uStack_38);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a94220(piStack_2c[1],&uStack_14);
  }
  else {
    FUN_00a94bd0(piStack_2c);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  *param_1 = piStack_2c;
  param_1[1] = uStack_28;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21759 ; VA 0x00a95d50 ; FUN_00a95d50 */

undefined4 *
FUN_00a95d50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,int *param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11)

{
  int *piVar1;
  int iVar2;
  undefined auStack_44 [12];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e5e80;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_14 = 0x700;
  ExceptionList = &pvStack_10;
  FUN_00a95690(auStack_44,param_7,param_2,param_3,param_4,param_5,param_6,&uStack_1c,&uStack_38,
               &uStack_14,param_9,param_10,param_11);
  FUN_008c05f0(&piStack_2c);
  uStack_8 = 2;
  if ((uint)((piStack_2c[2] - *piStack_2c) / 0xd0) < 4) {
    FUN_00a974c0(4);
  }
  piVar1 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  uStack_24 = uStack_1c;
  piStack_20 = piStack_18;
  uStack_8 = 3;
  FUN_00a951f0(&uStack_24);
  _uStack_8 = CONCAT31(uStack_7,2);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar2 = piStack_20[2] + -1;
      piStack_20[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a940b0(piStack_2c[1],auStack_44);
  }
  else {
    FUN_00912980(auStack_44);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a940b0(piStack_2c[1],&uStack_38);
  }
  else {
    FUN_00912980(&uStack_38);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  if (piStack_2c[2] == piStack_2c[1]) {
    FUN_00a94220(piStack_2c[1],&uStack_14);
  }
  else {
    FUN_00a94bd0(piStack_2c);
    piStack_2c[1] = piStack_2c[1] + 0xd0;
  }
  *param_1 = piStack_2c;
  param_1[1] = uStack_28;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21760 ; VA 0x00a95f50 ; FUN_00a95f50 */

undefined4
FUN_00a95f50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,int *param_8,undefined4 param_9
            ,undefined4 param_10)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5e98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  FUN_00a95b50(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,0);
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar1 = param_8[1] + -1;
    param_8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar1 = param_8[2] + -1;
      param_8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21761 ; VA 0x00a96000 ; FUN_00a96000 */

undefined4
FUN_00a96000(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,int *param_8,undefined4 param_9
            ,undefined4 param_10)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5eb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  FUN_00a95d50(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,0);
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar1 = param_8[1] + -1;
    param_8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar1 = param_8[2] + -1;
      param_8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21762 ; VA 0x00a960b0 ; FUN_00a960b0 */

undefined4
FUN_00a960b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,int *param_8,undefined4 param_9
            )

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5e98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  FUN_00a95b50(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,0,param_9,1);
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar1 = param_8[1] + -1;
    param_8[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar1 = param_8[2] + -1;
      param_8[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21763 ; VA 0x00a96160 ; thunk_FUN_00a9e750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00a9e750(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb134) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb134);
    if (DAT_01eeb134 == -1) {
      uStack_8 = 0;
      FUN_009ca470("BulkMoveMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb0d0 = RBX::Reflection::EnumDesc<enum_RBX::BulkMoveMode>::vftable;
      FUN_009caf20(&DAT_01d66538,2);
      FUN_016f3654(&LAB_0188ae40);
      FUN_016f37bf(&DAT_01eeb134);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb0d0;
}



/* FUNCTION 21764 ; VA 0x00a96170 ; thunk_FUN_00a9e800 */

undefined * thunk_FUN_00a9e800(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb19c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb19c);
    if (DAT_01eeb19c == -1) {
      uStack_8 = 0;
      FUN_00e00d40();
      FUN_016f3654(&LAB_0188ae60);
      FUN_016f37bf(&DAT_01eeb19c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb138;
}



/* FUNCTION 21765 ; VA 0x00a96180 ; FUN_00a96180 */

undefined4 FUN_00a96180(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00a962fd:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00a962fd;
  }
  iVar2 = FUN_00a9e750();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00a962a8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00a9e750();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00a93f30(&param_3);
      iVar4 = FUN_00a9e750();
      iStack_ec = iVar4;
      iVar5 = FUN_00a9e750();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00a962a8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00a9e750();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21766 ; VA 0x00a96380 ; FUN_00a96380 */

void * __thiscall FUN_00a96380(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_30 [8];
  undefined4 *puStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017e5ee0;
  puStack_28 = *(undefined4 **)(param_1 + 0x2c);
  pvVar3 = ExceptionList;
  if (puStack_28 != (undefined4 *)0x0) {
    piStack_24 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
      piStack_24 = *(int **)(param_1 + 0x30);
      puStack_28 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puStack_28[1];
    piVar5 = (int *)*puStack_28;
    iStack_8 = 0;
    piVar4 = piStack_24;
    pvVar3 = pvStack_10;
    for (; piStack_18 = piVar4, piVar5 != piVar1; piVar5 = piVar5 + 2) {
      piVar4 = (int *)piVar5[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = (int *)piVar5[1];
      }
      iStack_20 = *piVar5;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      piStack_1c = piVar4;
      if (iStack_20 != 0) {
        iStack_14 = *(int *)(iStack_20 + 0xc);
        iVar2 = FUN_00aff8c0();
        if ((uint)*(ushort *)(iStack_14 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
            (uint)*(ushort *)(iVar2 + 0x1da)) {
          iStack_14 = *(int *)(iStack_20 + 0xa8);
          FUN_00a95260(auStack_30,&iStack_14,&iStack_14);
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar2 = piVar4[2] + -1;
          piVar4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      pvVar3 = (void *)FUN_00a96380(param_2);
      piVar4 = piStack_18;
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar2 = *piVar1;
      pvVar3 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar3 = (void *)(**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar3 = (void *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 21767 ; VA 0x00a964d0 ; FUN_00a964d0 */

undefined4 * __thiscall
FUN_00a964d0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,int *param_11,undefined4 param_12,
            undefined8 param_13,undefined4 param_14)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5f2c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a93fd0();
  FUN_009cb790(uVar3,param_4,param_12,param_13,param_14);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::WorldRoot,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(class_RBX::RbxRay,class_std::shared_ptr<class_RBX::Instance>,bool,bool),4>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 2;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_11 != (int *)0x0) {
      LOCK();
      param_11[1] = param_11[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_10;
    puVar4[1] = param_11;
  }
  param_1[0x12] = puVar4;
  uStack_8._0_1_ = 3;
  puVar5 = (undefined *)FUN_01674e20(1);
  if (puVar5 == (undefined *)0x0) {
    puVar5 = (undefined *)0x0;
  }
  else {
    *puVar5 = param_9._1_1_;
  }
  param_1[0x13] = puVar5;
  uStack_8._0_1_ = 4;
  puVar5 = (undefined *)FUN_01674e20(1);
  if (puVar5 == (undefined *)0x0) {
    puVar5 = (undefined *)0x0;
  }
  else {
    *puVar5 = (undefined)param_9;
  }
  param_1[0x14] = puVar5;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00a98700(param_5,param_6,param_7,param_8);
  if (param_11 != (int *)0x0) {
    LOCK();
    iVar2 = param_11[1] + -1;
    param_11[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_11)();
      LOCK();
      piVar1 = param_11 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_11 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21768 ; VA 0x00a96610 ; FUN_00a96610 */

undefined4 * __thiscall
FUN_00a96610(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5f69;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93fd0();
  FUN_009cb790(uVar1,param_4,param_9,param_10,param_11);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::WorldRoot,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_RBX::Region3,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,int),3>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_8;
  }
  param_1[0x13] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00a98ad0(param_5,param_6,param_7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21769 ; VA 0x00a966d0 ; FUN_00a966d0 */

undefined4 * __thiscall
FUN_00a966d0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,int *param_10,undefined4 param_11,undefined8 param_12,
            undefined4 param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5fb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00a93fd0();
  FUN_009cb790(uVar3,param_4,param_11,param_12,param_13);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::WorldRoot,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_RBX::Region3,class_std::shared_ptr<class_RBX::Instance>,int),3>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 2;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (param_10 != (int *)0x0) {
      LOCK();
      param_10[1] = param_10[1] + 1;
      UNLOCK();
    }
    *puVar4 = param_9;
    puVar4[1] = param_10;
  }
  param_1[0x12] = puVar4;
  uStack_8._0_1_ = 3;
  puVar4 = (undefined4 *)FUN_01674e20(4);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = param_8;
  }
  param_1[0x13] = puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00a98d80(param_5,param_6,param_7);
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = param_10 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21770 ; VA 0x00a967f0 ; FUN_00a967f0 */

undefined4 * __thiscall
FUN_00a967f0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e60df;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_6 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_01946fd0;
    param_1[0x1e] = &DAT_01946fd8;
    param_1[0x7b] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)(param_6 != (undefined4 *)0x0);
  puStack_18 = param_1;
  FUN_00b64520(0);
  *param_1 = RBX::Described<class_RBX::WorldRoot,class_RBX::ModelInstance>::vftable;
  param_1[0x16] = RBX::Described<class_RBX::WorldRoot,class_RBX::ModelInstance>::vftable;
  param_1[0x1d] = RBX::Described<class_RBX::WorldRoot,class_RBX::ModelInstance>::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::Described<class_RBX::WorldRoot,class_RBX::ModelInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xf4;
  uVar5 = FUN_00a93fd0();
  param_1[3] = uVar5;
  param_1[0x51] = RBX::ICameraOwner::vftable;
  puVar9 = param_1 + 0x52;
  *puVar9 = RBX::IVisuallyMovingManager::vftable;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  puVar1 = param_1 + 0x56;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_6 = puVar9;
  puStack_1c = puVar1;
  uVar5 = FUN_00575b50(0,0);
  param_1[0x57] = uVar5;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  uStack_8._0_1_ = 7;
  *puVar1 = 0x3f800000;
  FUN_005cb500(8);
  puVar1 = puStack_18;
  *(undefined *)(param_1 + 0x5e) = 1;
  *puVar9 = RBX::WorldRoot::vftable;
  *puStack_18 = RBX::WorldRoot::vftable;
  puStack_18[0x16] = RBX::WorldRoot::vftable;
  puStack_18[0x1d] = RBX::WorldRoot::vftable;
  puStack_18[0x51] = RBX::WorldRoot::vftable;
  *(undefined ***)(*(int *)(puStack_18[0x15] + 4) + 0x54 + (int)puStack_18) =
       RBX::WorldRoot::vftable;
  *(int *)(*(int *)(puStack_18[0x15] + 4) + 0x50 + (int)puStack_18) =
       *(int *)(puStack_18[0x15] + 4) + -0x198;
  puStack_18[0x5f] = 0;
  puStack_18[0x60] = 0;
  puStack_18[0x61] = 0;
  *(undefined *)(puStack_18 + 0x62) = 0;
  puStack_18[99] = 0;
  puStack_18[100] = 0;
  puStack_18[0x65] = 0;
  puStack_18[0x66] = 0;
  puStack_18[0x67] = 0;
  puStack_18[0x68] = 0;
  puStack_18[0x69] = 0;
  puStack_18[0x6a] = 0;
  puStack_18[0x6b] = 0x44480000;
  puStack_18[0x6c] = 0x44160000;
  puStack_18[0x6d] = 0;
  *(undefined *)(puStack_18 + 0x6e) = 1;
  puStack_18[0x70] = 0;
  puStack_18[0x71] = 0;
  puStack_18[0x6f] = 0;
  puStack_18[0x72] = 0;
  puStack_18[0x73] = 0;
  puStack_18[0x74] = 0;
  puStack_18[0x75] = 0;
  puStack_18[0x76] = 0;
  puStack_18[0x77] = 0;
  puStack_18[0x78] = 0;
  puStack_18[0x79] = 0;
  uStack_8._0_1_ = 0x10;
  uVar5 = FUN_01675290(DAT_01ef3714);
  uStack_8._0_1_ = 0x11;
  puStack_1c = (undefined4 *)uVar5;
  param_6 = (undefined4 *)FUN_01674e20(0x760);
  uStack_8._0_1_ = 0x12;
  if (param_6 == (undefined4 *)0x0) {
    uVar6 = 0;
  }
  else {
    uStack_24 = param_4;
    uStack_2c = param_2;
    uStack_20 = param_5;
    uStack_28 = param_3;
    uVar6 = FUN_00bb9af0(&uStack_2c);
  }
  iVar3 = puVar1[0x6d];
  uStack_8._0_1_ = 0x11;
  puVar1[0x6d] = uVar6;
  if (iVar3 != 0) {
    FUN_00bbad20();
    FUN_01674ea0(iVar3,0x760);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("Default",7);
  uStack_8._0_1_ = 0x13;
  FUN_00bbc550(auStack_44);
  iVar3 = puVar1[0x6d];
  uStack_8._0_1_ = 0x14;
  uVar6 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x15;
  param_2 = (undefined4 *)FUN_01674e20(0x1c);
  puVar1 = puStack_18;
  if (param_2 == (undefined4 *)0x0) {
    param_2 = (undefined4 *)0x0;
  }
  else {
    *param_2 = 0;
    param_2[1] = 1;
    param_2[2] = FUN_00a9ac40;
    param_2[3] = _guard_check_icall;
    param_2[4] = 0;
    param_2[5] = iVar3 + 0x10;
    param_2[6] = puStack_18;
  }
  FUN_016797d0(param_2);
  param_6 = param_2;
  if (param_2 != (undefined4 *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_14 = uStack_14 | 4;
  uStack_8._0_1_ = 0x16;
  FUN_01675290(uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  cVar4 = FUN_01679300(&param_6);
  if (cVar4 != '\0') {
    FUN_01679490();
    FUN_016791c0(&param_6);
  }
  uStack_14 = uStack_14 & 0xfffffffb;
  if (param_6 != (undefined4 *)0x0) {
    piVar2 = param_6 + 1;
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(param_6);
    }
  }
  uStack_8._0_1_ = 0x11;
  if (0xf < uStack_30) {
    uVar8 = uStack_30 + 1;
    uVar7 = auStack_44[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_44[0] - 4);
      uVar8 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  FUN_01675290(uVar5);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 21771 ; VA 0x00a96c80 ; FUN_00a96c80 */

void __fastcall FUN_00a96c80(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),1);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),1);
  }
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x18);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21772 ; VA 0x00a96d00 ; FUN_00a96d00 */

void __fastcall FUN_00a96d00(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),1);
  }
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x18);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21773 ; VA 0x00a96d70 ; FUN_00a96d70 */

void __fastcall FUN_00a96d70(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21774 ; VA 0x00a96de0 ; FUN_00a96de0 */

void __fastcall FUN_00a96de0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21775 ; VA 0x00a96e90 ; FUN_00a96e90 */

void __fastcall FUN_00a96e90(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x54) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x54),4);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0x30);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21776 ; VA 0x00a96f30 ; FUN_00a96f30 */

void __fastcall FUN_00a96f30(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 21777 ; VA 0x00a96f90 ; thunk_FUN_00b648f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall thunk_FUN_00b648f0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  *param_1 = RBX::ModelInstance::vftable;
  param_1[0x16] = RBX::ModelInstance::vftable;
  param_1[0x1d] = RBX::ModelInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::ModelInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xf4;
  piVar2 = (int *)param_1[0x4f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_1[0x4b];
  if (iVar3 != 0) {
    uVar5 = param_1[0x4d] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x4b] = 0;
    param_1[0x4c] = 0;
    param_1[0x4d] = 0;
  }
  FUN_0056cd30();
  piVar2 = (int *)param_1[0x26];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  LOCK();
  _DAT_01ef0310 = _DAT_01ef0310 + -1;
  UNLOCK();
  param_1[0x1d] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1e] + 4) + 0x78 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_00e704a0();
  return;
}



/* FUNCTION 21778 ; VA 0x00a96fa0 ; thunk_FUN_0087dcc0 */

void __fastcall thunk_FUN_0087dcc0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x10);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar4 = *(int **)(param_1 + 0xc);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087dd2d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 21779 ; VA 0x00a96fb0 ; FUN_00a96fb0 */

void __fastcall FUN_00a96fb0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x30);
  }
  return;
}



/* FUNCTION 21780 ; VA 0x00a96fd0 ; FUN_00a96fd0 */

void __fastcall FUN_00a96fd0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_0087dcc0();
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 21781 ; VA 0x00a96ff0 ; FUN_00a96ff0 */

void __fastcall FUN_00a96ff0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x18);
  }
  return;
}



/* FUNCTION 21782 ; VA 0x00a97010 ; FUN_00a97010 */

void __fastcall FUN_00a97010(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x3c);
  }
  return;
}



/* FUNCTION 21783 ; VA 0x00a97030 ; FUN_00a97030 */

void __fastcall FUN_00a97030(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00bbad20();
    FUN_01674ea0(iVar1,0x760);
  }
  return;
}



/* FUNCTION 21784 ; VA 0x00a97050 ; FUN_00a97050 */

int __fastcall FUN_00a97050(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_EAX;
  int iVar4;
  
  piVar3 = (int *)param_1[2];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
    *param_1 = RBX::HitTestFilter::vftable;
    return iVar4;
  }
  *param_1 = RBX::HitTestFilter::vftable;
  return in_EAX;
}



/* FUNCTION 21785 ; VA 0x00a97090 ; FUN_00a97090 */

void __fastcall FUN_00a97090(undefined4 *param_1)

{
  *param_1 = RBX::ICameraOwner::vftable;
  return;
}



/* FUNCTION 21786 ; VA 0x00a970a0 ; FUN_00a970a0 */

void __fastcall FUN_00a970a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::WorldRoot::vftable;
  param_1[0x16] = RBX::WorldRoot::vftable;
  param_1[0x1d] = RBX::WorldRoot::vftable;
  param_1[0x51] = RBX::WorldRoot::vftable;
  param_1[0x52] = RBX::WorldRoot::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::WorldRoot::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x198
  ;
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x79];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_00577ac0();
  piVar1 = (int *)param_1[0x75];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x73];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 1;
  FUN_01674ea0(param_1[0x6f]);
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  iVar4 = param_1[0x6d];
  if (iVar4 != 0) {
    FUN_00bbad20();
    FUN_01674ea0(iVar4,0x760);
  }
  FUN_00577ac0();
  FUN_00577ac0();
  FUN_00c3e210();
  param_1[0x51] = RBX::ICameraOwner::vftable;
  FUN_00b648f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21787 ; VA 0x00a9722c ; FUN_00a9722c */

void FUN_00a9722c(void)

{
  FUN_00a973d0();
  return;
}



/* FUNCTION 21788 ; VA 0x00a97240 ; FUN_00a97240 */

undefined4 __thiscall FUN_00a97240(undefined4 param_1,byte param_2)

{
  FUN_00a96c80();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 21789 ; VA 0x00a97270 ; FUN_00a97270 */

undefined4 __thiscall FUN_00a97270(undefined4 param_1,byte param_2)

{
  FUN_00a96d00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21790 ; VA 0x00a972a0 ; FUN_00a972a0 */

undefined4 __thiscall FUN_00a972a0(undefined4 param_1,byte param_2)

{
  FUN_00a96d70();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21791 ; VA 0x00a972d0 ; FUN_00a972d0 */

int __thiscall FUN_00a972d0(int param_1,byte param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 != 0) {
    FUN_0087dcc0();
    FUN_01674ea0(iVar1,0x28);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21792 ; VA 0x00a97340 ; FUN_00a97340 */

undefined4 __thiscall FUN_00a97340(undefined4 param_1,byte param_2)

{
  FUN_00a96de0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21793 ; VA 0x00a97370 ; FUN_00a97370 */

undefined4 __thiscall FUN_00a97370(undefined4 param_1,byte param_2)

{
  FUN_00a96e90();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 21794 ; VA 0x00a973a0 ; FUN_00a973a0 */

undefined4 __thiscall FUN_00a973a0(undefined4 param_1,byte param_2)

{
  FUN_00a96f30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 21795 ; VA 0x00a973d0 ; FUN_00a973d0 */

int __thiscall FUN_00a973d0(int param_1,byte param_2)

{
  FUN_00b648f0();
  *(undefined ***)(param_1 + 0x148) = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14c);
  }
  return param_1;
}



/* FUNCTION 21796 ; VA 0x00a97400 ; FUN_00a97400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a97400(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::BulkMoveMode>::vftable;
  _DAT_01eeaeb4 = _DAT_01eeaeb4 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21797 ; VA 0x00a97430 ; FUN_00a97430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a97430(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::IkDragCollisionsMode>::vftable;
  _DAT_01f1788c = _DAT_01f1788c + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21798 ; VA 0x00a97460 ; FUN_00a97460 */

undefined4 * __thiscall FUN_00a97460(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::ICameraOwner::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 21799 ; VA 0x00a97490 ; FUN_00a97490 */

undefined4 __thiscall FUN_00a97490(undefined4 param_1,byte param_2)

{
  FUN_00c3e210();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 21800 ; VA 0x00a974c0 ; FUN_00a974c0 */

void __thiscall FUN_00a974c0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6330;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00578090(param_2);
  uStack_8 = 0;
  FUN_005cb790(*param_1,param_1[1],uVar3);
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(uVar3,(iVar1 - iVar2) / 0xd0,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21801 ; VA 0x00a97543 ; Catch_All@00a97543 */

void Catch_All_00a97543(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0057d370(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21802 ; VA 0x00a97570 ; FUN_00a97570 */

undefined __thiscall FUN_00a97570(int param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  void **ppvVar3;
  undefined uVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e6350;
  pvStack_10 = ExceptionList;
  iStack_14 = *(int *)(param_1 + 0x1b4);
  uStack_20 = *(undefined4 *)(iStack_14 + 0x6ac);
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_2c = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  piVar6 = (int *)*param_2;
  piStack_1c = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (piVar6 != piStack_1c) {
    do {
      iVar1 = *piVar6;
      iVar2 = *(int *)(iVar1 + 0xc);
      iVar5 = FUN_00aff8c0();
      iVar8 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iVar8 = iVar1;
      }
      if (iVar8 == 0) {
        piVar6 = (int *)FUN_0054db20();
        (**(code **)(*piVar6 + 0x10))();
        uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("All objects passed to ArePartsTouchingOthers must be BaseParts, got a %s.",
                     uVar7);
      }
      iStack_18 = *(int *)(iVar8 + 0xa8);
      if (*(int *)(iStack_18 + 0x1a8) != iStack_14) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("All parts passed to ArePartsTouchingOthers must be in the WorldRoot");
      }
      FUN_007c5360(&iStack_18);
      piVar6 = piVar6 + 2;
      ppvVar3 = (void **)ExceptionList;
    } while (piVar6 != piStack_1c);
  }
  ExceptionList = ppvVar3;
  uVar4 = FUN_00ce58a0(&uStack_2c,param_4);
  _uStack_8 = CONCAT31(uStack_7,2);
  FUN_01674ea0(uStack_2c);
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 21803 ; VA 0x00a976e0 ; FUN_00a976e0 */

int FUN_00a976e0(int *param_1,int *param_2,int *param_3,int *param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6370;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iVar6 = param_1[1] - *param_1 >> 3;
  iVar2 = (param_3[1] - *param_3) / 0xd0;
  if (iVar6 != iVar2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Length of part list (%d) and length of CFrame list (%d) do not match.",iVar6,iVar2
                );
  }
  iVar8 = 0;
  ExceptionList = &pvStack_10;
  if (0 < iVar6) {
    iStack_14 = 0;
    ExceptionList = &pvStack_10;
    do {
      iVar2 = *(int *)(*(int *)(*param_1 + iVar8 * 8) + 0xc);
      iVar1 = FUN_00aff8c0();
      if ((uint)*(ushort *)(iVar1 + 0x1da) <
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8)) {
        iVar2 = iVar8;
        FUN_0054db20(iVar8);
        FUN_005d1bc0(iVar2);
        piVar3 = (int *)FUN_0054db20();
        (**(code **)(*piVar3 + 0x10))();
        uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Can only call BulkMoveTo on BaseParts, partList[%d] is a %s.",iVar8 + 1,uVar4)
        ;
      }
      iVar1 = *(int *)(iStack_14 + *param_3);
      iVar2 = FUN_00b00260();
      if (iVar1 != iVar2) {
        iVar2 = iVar8;
        FUN_0054db20(iVar8);
        FUN_0056f520(iVar2);
        FUN_0054db20();
        uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("CFrame list must only contain CFrames, cframeList[%d] is a %s.",iVar8 + 1,
                     uVar4);
      }
      iStack_14 = iStack_14 + 0xd0;
      iVar8 = iVar8 + 1;
    } while (iVar8 < iVar6);
  }
  iStack_14 = 0;
  if (0 < iVar6) {
    iStack_18 = 0;
    do {
      piVar3 = *(int **)(*param_1 + iStack_14 * 8);
      iVar2 = piVar3[3];
      iVar8 = FUN_00aff8c0();
      piVar7 = (int *)0x0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
          (uint)*(ushort *)(iVar8 + 0x1da)) {
        piVar7 = piVar3;
      }
      piVar3 = (int *)(*param_3 + iStack_18);
      iVar2 = *piVar3;
      iVar8 = FUN_00b00260();
      if (iVar2 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar5 = piVar3 + 2;
      if (piVar3[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (param_5 == 0) {
        iVar2 = (**(code **)(*piVar7 + 0x108))(piVar5);
      }
      else {
        iVar2 = param_5 + -1;
        if (iVar2 == 0) {
          iVar2 = (**(code **)(*piVar7 + 0x104))(piVar5);
        }
      }
      iStack_18 = iStack_18 + 0xd0;
      iStack_14 = iStack_14 + 1;
    } while (iStack_14 < iVar6);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 1;
    iVar6 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar3 = param_2 + 2;
      iVar6 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar2 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar6 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar2 = (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar2 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 21804 ; VA 0x00a97920 ; FUN_00a97920 */

undefined4 FUN_00a97920(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if ((iVar1 != 0) && (iVar1 != param_1)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 21805 ; VA 0x00a97940 ; FUN_00a97940 */

void FUN_00a97940(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00a9e750();
    *param_2 = uVar3;
    iVar4 = FUN_00a9e890();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 21806 ; VA 0x00a979a0 ; FUN_00a979a0 */

void FUN_00a979a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00a9e800();
    *param_2 = uVar3;
    iVar4 = FUN_00a9e900();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 21807 ; VA 0x00a97a00 ; FUN_00a97a00 */

void FUN_00a97a00(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a9e750();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21808 ; VA 0x00a97a40 ; FUN_00a97a40 */

void FUN_00a97a40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00a9e800();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21809 ; VA 0x00a97a80 ; FUN_00a97a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a97a80(int param_1,uint param_2,int *param_3,int *param_4,int param_5)

{
  int *piVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 uVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  int *piVar11;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6388;
  pvStack_10 = ExceptionList;
  iVar8 = *(int *)(param_1 + 0x1c0);
  piVar11 = (int *)(param_1 + 0x1bc);
  ExceptionList = &pvStack_10;
  piStack_34 = piVar11;
  iStack_30 = param_1;
  if (iVar8 != 0) {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x1c0) = 0;
    if (*(int *)(param_1 + 0x1c4) < 0) {
      if (*(int *)(param_1 + 0x1c4) == 0) {
        *(undefined4 *)(param_1 + 0x1c4) = 0;
      }
      else {
        *(undefined4 *)(param_1 + 0x1c4) = 10;
      }
      FUN_0078c480(iVar8);
    }
  }
  uVar2 = *(undefined4 *)(param_2 + 0xa8);
  uStack_28 = uVar2;
  uStack_2c = FUN_00c15960();
  FUN_00ce4fb0(uStack_2c,uVar2,0,piVar11);
  iStack_18 = 0;
  iStack_20 = 0;
  iVar8 = 0;
  if (0 < *(int *)(param_1 + 0x1c0)) {
    do {
      uStack_24 = *(undefined4 *)(*piVar11 + iStack_20 * 4);
      uVar6 = FUN_00b06640(uStack_24);
      uVar4 = uStack_24;
      uVar2 = uStack_28;
      if (param_3 != (int *)0x0) {
        iVar8 = *param_3;
        if ((iVar8 != param_3[1]) && (uVar6 != param_3[4])) {
          uVar7 = (uVar6 >> 3) + uVar6;
          uStack_1c = (param_3[1] - iVar8 >> 2) - 1;
          uVar10 = 0;
          do {
            uVar3 = *(uint *)(iVar8 + (uVar7 & uStack_1c) * 4);
            if (uVar3 == uVar6) goto LAB_00a97cfa;
            if (uVar3 == param_3[4]) break;
            uVar7 = (uVar7 & uStack_1c) + 1 + uVar10;
            uVar10 = uVar10 + 1;
          } while (uVar10 <= uStack_1c);
        }
      }
      if (param_4 == (int *)0x0) {
LAB_00a97bd6:
        iVar8 = FUN_00c15be0(uStack_28,uStack_24,0);
        if (iVar8 == 0) {
          uVar9 = FUN_00c15960();
          cVar5 = FUN_00c9f4c0(uVar9,0x3d4ccccd);
          if (cVar5 == '\0') {
            uStack_6c = _DAT_018e3fb0;
            uStack_68 = _UNK_018e3fb4;
            uStack_64 = _UNK_018e3fb8;
            uStack_60 = _UNK_018e3fbc;
            uStack_5c = _DAT_018e3fb0;
            uStack_58 = _UNK_018e3fb4;
            uStack_54 = _UNK_018e3fb8;
            uStack_50 = _UNK_018e3fbc;
            uStack_4c = _DAT_018e3fb0;
            uStack_48 = _UNK_018e3fb4;
            uStack_44 = _UNK_018e3fb8;
            uStack_40 = _UNK_018e3fbc;
            uStack_9c = _DAT_018e3fb0;
            uStack_98 = _UNK_018e3fb4;
            uStack_94 = _UNK_018e3fb8;
            uStack_90 = _UNK_018e3fbc;
            uStack_8c = _DAT_018e3fb0;
            uStack_88 = _UNK_018e3fb4;
            uStack_84 = _UNK_018e3fb8;
            uStack_80 = _UNK_018e3fbc;
            uStack_7c = _DAT_018e3fb0;
            uStack_78 = _UNK_018e3fb4;
            uStack_74 = _UNK_018e3fb8;
            uStack_70 = _UNK_018e3fbc;
            cStack_11 = cVar5;
            FUN_00a9e970(&iStack_3c,uVar2,uVar4,&uStack_6c,&uStack_9c,&cStack_11);
            uStack_8 = 0;
            if (iStack_3c != 0) {
              uVar7 = param_2;
              if (cStack_11 != '\0') {
                uVar7 = uVar6;
                uVar6 = param_2;
              }
              FUN_00c3d740(uVar7);
              FUN_00c3d770(uVar6);
              FUN_00c3ceb0(&uStack_6c);
              FUN_00c3cee0(&uStack_9c);
              FUN_008a65e0(uVar7,0);
              iStack_18 = iStack_18 + 1;
            }
            piVar11 = piStack_38;
            uStack_8 = 0xffffffff;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              iVar8 = piStack_38[1] + -1;
              piStack_38[1] = iVar8;
              UNLOCK();
              if (iVar8 == 0) {
                (**(code **)*piStack_38)();
                LOCK();
                piVar1 = piVar11 + 2;
                iVar8 = *piVar1 + -1;
                *piVar1 = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)(*piVar11 + 4))();
                }
              }
            }
          }
        }
      }
      else {
        iVar8 = *param_4;
        if ((iVar8 != param_4[1]) && (uVar6 != param_4[4])) {
          uVar7 = (uVar6 >> 3) + uVar6;
          uStack_1c = (param_4[1] - iVar8 >> 2) - 1;
          uVar10 = 0;
          do {
            uVar3 = *(uint *)(iVar8 + (uVar7 & uStack_1c) * 4);
            if (uVar3 == uVar6) goto LAB_00a97bd6;
            if (uVar3 == param_4[4]) break;
            uVar7 = (uVar7 & uStack_1c) + 1 + uVar10;
            uVar10 = uVar10 + 1;
          } while (uVar10 <= uStack_1c);
        }
      }
LAB_00a97cfa:
      iStack_20 = iStack_20 + 1;
      iVar8 = iStack_18;
      piVar11 = piStack_34;
      param_1 = iStack_30;
    } while (iStack_20 < *(int *)(iStack_30 + 0x1c0));
  }
  piVar11 = (int *)(*(int *)(param_1 + 0x1b4) + 0x6f8 + param_5 * 4);
  *piVar11 = *piVar11 + iVar8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21810 ; VA 0x00a97d40 ; FUN_00a97d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a97d40(int param_1,uint param_2,uint *param_3,uint *param_4,int param_5)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint *puVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  uint uVar13;
  int iVar14;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined auStack_44 [8];
  int *piStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e63a8;
  pvStack_10 = ExceptionList;
  iVar14 = *(int *)(param_1 + 0x1c0);
  piVar12 = (int *)(param_1 + 0x1bc);
  ExceptionList = &pvStack_10;
  piStack_3c = piVar12;
  iStack_38 = param_1;
  if (iVar14 != 0) {
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0x1c0) = 0;
    if (*(int *)(param_1 + 0x1c4) < 0) {
      if (*(int *)(param_1 + 0x1c4) == 0) {
        *(undefined4 *)(param_1 + 0x1c4) = 0;
      }
      else {
        *(undefined4 *)(param_1 + 0x1c4) = 10;
      }
      FUN_0078c480(iVar14);
    }
  }
  iVar14 = *(int *)(param_2 + 0xa8);
  iStack_18 = iVar14;
  uStack_34 = FUN_00c15960();
  FUN_00ce4fb0(uStack_34,iVar14,0,piVar12);
  iStack_20 = 0;
  iStack_2c = 0;
  iVar11 = 0;
  if (0 < *(int *)(param_1 + 0x1c0)) {
    do {
      iStack_30 = *(int *)(*piVar12 + iStack_2c * 4);
      uVar5 = FUN_00b06640(iStack_30);
      iVar11 = iStack_30;
      if (param_3 != (uint *)0x0) {
        uStack_1c = *param_3;
        iVar14 = iStack_18;
        if ((uStack_1c != param_3[1]) && (uVar5 != param_3[4])) {
          uVar6 = (uVar5 >> 3) + uVar5;
          uVar13 = ((int)(param_3[1] - uStack_1c) >> 2) - 1;
          uVar10 = 0;
          do {
            uVar6 = uVar6 & uVar13;
            uVar2 = *(uint *)(uStack_1c + uVar6 * 4);
            if (uVar2 == uVar5) goto LAB_00a9808b;
            if (uVar2 == param_3[4]) break;
            uVar6 = uVar6 + 1 + uVar10;
            uVar10 = uVar10 + 1;
          } while (uVar10 <= uVar13);
        }
      }
      if (param_4 == (uint *)0x0) {
LAB_00a97e97:
        iVar7 = FUN_00c15be0(iVar14,iStack_30,0);
        if (iVar7 == 0) {
          uVar8 = FUN_00c15960();
          cVar4 = FUN_00c9f4c0(uVar8,0x3d4ccccd);
          if (cVar4 == '\0') {
            uStack_7c = _DAT_018e3fb0;
            uStack_78 = _UNK_018e3fb4;
            uStack_74 = _UNK_018e3fb8;
            uStack_70 = _UNK_018e3fbc;
            uStack_6c = _DAT_018e3fb0;
            uStack_68 = _UNK_018e3fb4;
            uStack_64 = _UNK_018e3fb8;
            uStack_60 = _UNK_018e3fbc;
            uStack_28 = 0;
            uStack_5c = _DAT_018e3fb0;
            uStack_58 = _UNK_018e3fb4;
            uStack_54 = _UNK_018e3fb8;
            uStack_50 = _UNK_018e3fbc;
            piStack_24 = (int *)0x0;
            uStack_ac = _DAT_018e3fb0;
            uStack_a8 = _UNK_018e3fb4;
            uStack_a4 = _UNK_018e3fb8;
            uStack_a0 = _UNK_018e3fbc;
            uStack_9c = _DAT_018e3fb0;
            uStack_98 = _UNK_018e3fb4;
            uStack_94 = _UNK_018e3fb8;
            uStack_90 = _UNK_018e3fbc;
            uStack_8c = _DAT_018e3fb0;
            uStack_88 = _UNK_018e3fb4;
            uStack_84 = _UNK_018e3fb8;
            uStack_80 = _UNK_018e3fbc;
            uStack_8 = 0;
            cStack_11 = cVar4;
            if ((DAT_01d6f2c0 == '\0') || ((param_5 != 3 && (param_5 != 1)))) {
              puVar9 = (uint *)FUN_00a9ed70(auStack_4c,iVar14,iVar11,&uStack_7c,&uStack_ac,
                                            &cStack_11);
              piVar3 = piStack_48;
              uVar6 = *puVar9;
              piVar12 = (int *)puVar9[1];
              *puVar9 = 0;
              puVar9[1] = 0;
              uStack_28 = uVar6;
              piStack_24 = piVar12;
              uStack_1c = uVar6;
              if (piStack_48 != (int *)0x0) {
                LOCK();
                iVar14 = piStack_48[1] + -1;
                piStack_48[1] = iVar14;
                UNLOCK();
                if (iVar14 == 0) {
                  (**(code **)*piStack_48)();
                  LOCK();
                  piVar1 = piVar3 + 2;
                  iVar14 = *piVar1 + -1;
                  *piVar1 = iVar14;
                  UNLOCK();
                  uVar6 = uStack_1c;
                  if (iVar14 == 0) {
                    (**(code **)(*piVar3 + 4))();
                    uVar6 = uStack_1c;
                  }
                }
              }
            }
            else {
              iVar7 = (**(code **)(**(int **)(iVar14 + 0x1ac) + 8))();
              if ((iVar7 == 1) ||
                 (iVar7 = (**(code **)(**(int **)(iVar11 + 0x1ac) + 8))(), iVar7 == 1)) {
                uStack_8 = 0xffffffff;
                goto LAB_00a9808b;
              }
              uVar8 = FUN_00a9eff0(auStack_44,iVar14,iVar11,&uStack_7c,&uStack_ac,&cStack_11);
              FUN_005587e0(uVar8);
              FUN_00550b30();
              uVar6 = uStack_28;
              piVar12 = piStack_24;
            }
            if (uVar6 != 0) {
              uStack_1c = param_2;
              if (cStack_11 != '\0') {
                uStack_1c = uVar5;
                uVar5 = param_2;
              }
              FUN_00c3d740(uStack_1c);
              FUN_00c3d770(uVar5);
              FUN_00c3ceb0(&uStack_7c);
              FUN_00c3cee0(&uStack_ac);
              FUN_008a65e0(uStack_1c,0);
              iStack_20 = iStack_20 + 1;
            }
            uStack_8 = 0xffffffff;
            iVar14 = iStack_18;
            if (piVar12 != (int *)0x0) {
              LOCK();
              iVar11 = piVar12[1] + -1;
              piVar12[1] = iVar11;
              UNLOCK();
              if (iVar11 == 0) {
                (**(code **)*piVar12)();
                LOCK();
                iVar11 = piVar12[2] + -1;
                piVar12[2] = iVar11;
                UNLOCK();
                iVar14 = iStack_18;
                if (iVar11 == 0) {
                  (**(code **)(*piVar12 + 4))();
                  iVar14 = iStack_18;
                }
              }
            }
          }
        }
      }
      else {
        uStack_1c = *param_4;
        iVar14 = iStack_18;
        if ((uStack_1c != param_4[1]) && (uVar5 != param_4[4])) {
          uVar6 = (uVar5 >> 3) + uVar5;
          uVar13 = ((int)(param_4[1] - uStack_1c) >> 2) - 1;
          uVar10 = 0;
          do {
            uVar6 = uVar6 & uVar13;
            uVar2 = *(uint *)(uStack_1c + uVar6 * 4);
            if (uVar2 == uVar5) goto LAB_00a97e97;
            if (uVar2 == param_4[4]) break;
            uVar6 = uVar6 + 1 + uVar10;
            uVar10 = uVar10 + 1;
          } while (uVar10 <= uVar13);
        }
      }
LAB_00a9808b:
      iStack_2c = iStack_2c + 1;
      iVar11 = iStack_20;
      piVar12 = piStack_3c;
      param_1 = iStack_38;
    } while (iStack_2c < *(int *)(iStack_38 + 0x1c0));
  }
  piVar12 = (int *)(*(int *)(param_1 + 0x1b4) + 0x6f8 + param_5 * 4);
  *piVar12 = *piVar12 + iVar11;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21811 ; VA 0x00a980d0 ; FUN_00a980d0 */

void __thiscall
FUN_00a980d0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e64a5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93dd0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d370();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x50) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x50));
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21812 ; VA 0x00a98450 ; FUN_00a98450 */

void __thiscall FUN_00a98450(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6558;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93dd0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d370();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21813 ; VA 0x00a98700 ; FUN_00a98700 */

void __thiscall
FUN_00a98700(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6655;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93dd0(iVar2);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088d370();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,param_2);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x50) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    puVar5 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x50));
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar6 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21814 ; VA 0x00a98ad0 ; FUN_00a98ad0 */

void __thiscall FUN_00a98ad0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [204];
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6558;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cc80();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    param_2 = &uStack_ec;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c13a0(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21815 ; VA 0x00a98d80 ; FUN_00a98d80 */

void __thiscall FUN_00a98d80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6708;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cc80();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar2);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_00a73110();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    puVar5 = (undefined4 *)FUN_005c13a0(*(int *)(param_1 + 0x4c));
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088c8c0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21816 ; VA 0x00a99080 ; FUN_00a99080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a99080(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined auStack_e4 [4];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e67d3;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar4 = FUN_00d99d10();
  *(undefined4 *)(param_1 + 0x24) = uVar4;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00912980(iVar2);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar4 = FUN_0088d870();
  uVar5 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar5,uVar4,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    param_2 = (undefined4 *)FUN_00912980(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar4 = FUN_0088d870();
  uVar5 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar5,uVar4,param_2);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined **)(param_1 + 0x4c);
  if (puVar3 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar7 = &uStack_35c;
    uStack_8 = 10;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_00d89a00();
    puStack_e8 = (undefined *)0x0;
    auStack_e4[0] = *puVar3;
    uStack_e0 = *(undefined4 *)(puVar3 + 4);
    if (*(int *)(puVar3 + 0xc) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(puVar3 + 0xc) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_dc = *(undefined4 *)(puVar3 + 8);
    uStack_d8 = *(undefined4 *)(puVar3 + 0xc);
    uStack_8 = 8;
    FUN_0054ef60(puVar3 + 0x10);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee4440)
       && (FUN_016f3809(&DAT_01ee4440), DAT_01ee4440 == -1)) {
      _DAT_01ee4434 = FUN_009d0320;
      _DAT_01ee4438 = FUN_009d0320;
      DAT_01ee443c = FUN_009d05a0;
      FUN_016f37bf(&DAT_01ee4440);
    }
    puStack_e8 = &DAT_01ee4434;
    puVar7 = &uStack_ec;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar4 = FUN_00d89a00();
  uVar5 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar5,uVar4,puVar7);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xc, puStack_e8 != (undefined *)0x0)) {
    (**(code **)(puStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21817 ; VA 0x00a99420 ; FUN_00a99420 */

void __thiscall FUN_00a99420(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00912980(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1510(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21818 ; VA 0x00a99600 ; FUN_00a99600 */

void __thiscall FUN_00a99600(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ec8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_ec = FUN_00888530();
    puStack_e8 = (undefined4 *)0x0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_008aa360(iVar2);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088cc80();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_008882f0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38)
       && (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
    puStack_e8 = &DAT_01ea8c2c;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_008882f0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_00a9e750();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_00a9e890();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00a9e750();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21819 ; VA 0x00a99980 ; FUN_00a99980 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00a99980(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_360;
  int iStack_35c;
  undefined auStack_358 [200];
  undefined4 uStack_290;
  int iStack_28c;
  undefined4 auStack_288 [50];
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6907;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puStack_20 = &uStack_1c0;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    puStack_ec = (undefined *)0x0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    puStack_ec = (undefined *)FUN_006309e0();
    puStack_20 = &uStack_f0;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_20);
  if ((uVar5 & 2) != 0) {
    uStack_14 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uVar5 = uStack_14;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
      uVar5 = uStack_14;
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_14 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 8;
    puVar4 = &uStack_1c0;
    uStack_8 = 5;
  }
  else {
    uStack_f0 = FUN_00b00260();
    puStack_ec = (undefined *)0x0;
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    uStack_e0 = puVar4[2];
    uStack_dc = puVar4[3];
    uStack_d8 = puVar4[4];
    uStack_d4 = puVar4[5];
    uStack_d0 = puVar4[6];
    uStack_cc = puVar4[7];
    uStack_c8 = puVar4[8];
    uStack_c4 = puVar4[9];
    uStack_c0 = puVar4[10];
    uStack_bc = puVar4[0xb];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3d8)
       && (FUN_016f3809(&DAT_01ead3d8), DAT_01ead3d8 == -1)) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
    puStack_ec = &DAT_01ead3cc;
    uStack_14 = uStack_14 | 4;
    puVar4 = &uStack_f0;
    uStack_8 = 4;
  }
  uVar2 = FUN_00b00260();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 8) != 0) {
    uStack_14 = uStack_14 & 0xfffffff7;
    uStack_8 = 6;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 4) != 0) {
    uStack_14 = uStack_14 & 0xfffffffb;
    uStack_8 = 7;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x4c) == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x20;
    param_2 = &uStack_1c0;
    uStack_8 = 9;
  }
  else {
    param_2 = (undefined4 *)FUN_006ea440(*(int *)(iStack_1c + 0x4c));
    uStack_14 = uStack_14 | 0x10;
    uStack_8 = 8;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uStack_14 & 0x20) != 0) {
    uStack_14 = uStack_14 & 0xffffffdf;
    uStack_8 = 10;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x10) != 0) {
    uStack_14 = uStack_14 & 0xffffffef;
    uStack_8 = 0xb;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x50) == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x80;
    param_2 = &uStack_1c0;
    uStack_8 = 0xd;
  }
  else {
    param_2 = (undefined4 *)FUN_006ea440(*(int *)(iStack_1c + 0x50));
    uStack_14 = uStack_14 | 0x40;
    uStack_8 = 0xc;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((char)uStack_14 < '\0') {
    uStack_14 = uStack_14 & 0xffffff7f;
    uStack_8 = 0xe;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x40) != 0) {
    uStack_14 = uStack_14 & 0xffffffbf;
    uStack_8 = 0xf;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x54);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_360 = FUN_00888530();
    iStack_35c = 0;
    puVar4 = &uStack_360;
    uStack_8 = 0x11;
    uVar5 = uStack_14 | 0x200;
  }
  else {
    uStack_290 = thunk_FUN_00a9e800();
    iStack_28c = 0;
    auStack_288[0] = *puVar4;
    iStack_28c = FUN_00a9e900();
    puVar4 = &uStack_290;
    uStack_8 = 0x10;
    uVar5 = uStack_14 | 0x100;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00a9e800();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x200) != 0) {
    uVar5 = uVar5 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar5;
    if (iStack_35c != 0) {
      (**(code **)(iStack_35c + 8))(auStack_358);
    }
  }
  if (((uVar5 & 0x100) != 0) && (uStack_8 = 0x13, iStack_28c != 0)) {
    (**(code **)(iStack_28c + 8))(auStack_288);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21820 ; VA 0x00a99f10 ; FUN_00a99f10 */

void __thiscall FUN_00a99f10(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_008aa360(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_006ea440(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21821 ; VA 0x00a9a0f0 ; FUN_00a9a0f0 */

void __thiscall FUN_00a9a0f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_00a73110();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_008aa360(*(int *)(param_1 + 0x48));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cc80();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21822 ; VA 0x00a9a2d0 ; FUN_00a9a2d0 */

void __thiscall FUN_00a9a2d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_00a93e70(iVar2);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_00a73110();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x48);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar6 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21823 ; VA 0x00a9a500 ; FUN_00a9a500 */

void __thiscall FUN_00a9a500(int param_1,uint param_2,int *param_3,char param_4,char param_5)

{
  byte *pbVar1;
  int *piVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  void **ppvVar7;
  int *piVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  int *piVar17;
  char cStack00000013;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6930;
  pvStack_10 = ExceptionList;
  iVar9 = *(int *)(param_1 + 400);
  piVar3 = (int *)(param_1 + 0x18c);
  uStack_18 = iVar9 - *(int *)(param_1 + 0x18c) >> 3;
  piVar17 = (int *)(param_1 + 0x198);
  uStack_24 = *(int *)(param_1 + 0x19c) - *(int *)(param_1 + 0x198) >> 3;
  iStack_14 = 0;
  ExceptionList = &pvStack_10;
  ppvVar7 = &pvStack_10;
  iStack_20 = param_1;
  piStack_1c = piVar17;
  if (0 < *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3) {
    do {
      piVar8 = (int *)FUN_00c156d0(iStack_14);
      if (piVar8 != (int *)0x0) {
        if ((param_5 == '\0') ||
           (((iVar9 = (**(code **)(*piVar8 + 0x10))(), iVar9 != 1 && (iVar9 != 3)) &&
            ((iVar9 < 7 || (10 < iVar9)))))) {
          if (param_4 != '\0') {
            iVar9 = (**(code **)(*piVar8 + 0x10))();
            if ((iVar9 == 2) || (((4 < iVar9 && (iVar9 < 7)) || (iVar9 == 0xb)))) goto LAB_00a9a65c;
            iVar9 = (**(code **)(*piVar8 + 0x10))();
            if ((iVar9 != 4) || (iVar9 = FUN_00ca12e0(), iVar9 == 0)) goto LAB_00a9a6ee;
            puVar10 = (undefined4 *)FUN_0060dcd0(auStack_34,iVar9 + -0x54);
            puVar5 = *(undefined4 **)(param_1 + 0x19c);
            uStack_8 = 1;
            if (*(undefined4 **)(param_1 + 0x1a0) == puVar5) {
              FUN_00603a30(puVar5,puVar10);
              piVar8 = piStack_30;
            }
            else {
              *puVar5 = 0;
              puVar5[1] = 0;
              *puVar5 = *puVar10;
              puVar5[1] = puVar10[1];
              *puVar10 = 0;
              puVar10[1] = 0;
              *(int *)(param_1 + 0x19c) = *(int *)(param_1 + 0x19c) + 8;
              piVar8 = piStack_30;
            }
            goto LAB_00a9a6c2;
          }
        }
        else {
LAB_00a9a65c:
          iVar9 = FUN_00ca12e0();
          if (iVar9 != 0) {
            puVar10 = (undefined4 *)FUN_0060dcd0(auStack_2c,iVar9 + -0x70);
            puVar5 = *(undefined4 **)(param_1 + 400);
            uStack_8 = 0;
            if (*(undefined4 **)(param_1 + 0x194) == puVar5) {
              FUN_00603a30(puVar5,puVar10);
              piVar8 = piStack_28;
            }
            else {
              *puVar5 = 0;
              puVar5[1] = 0;
              *puVar5 = *puVar10;
              puVar5[1] = puVar10[1];
              *puVar10 = 0;
              puVar10[1] = 0;
              *(int *)(param_1 + 400) = *(int *)(param_1 + 400) + 8;
              piVar8 = piStack_28;
            }
LAB_00a9a6c2:
            uStack_8 = 0xffffffff;
            if (piVar8 != (int *)0x0) {
              LOCK();
              iVar9 = piVar8[1] + -1;
              piVar8[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)*piVar8)();
                LOCK();
                iVar9 = piVar8[2] + -1;
                piVar8[2] = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  (**(code **)(*piVar8 + 4))();
                }
              }
            }
          }
        }
      }
LAB_00a9a6ee:
      iStack_14 = iStack_14 + 1;
    } while (iStack_14 < *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3);
    iVar9 = *(int *)(param_1 + 400);
    ppvVar7 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar7;
  iVar13 = *piVar3;
  uVar16 = uStack_18;
  if (uStack_18 < (uint)(iVar9 - iVar13 >> 3)) {
    do {
      piStack_28 = *(int **)(iVar13 + uVar16 * 8);
      iVar9 = (**(code **)piStack_28[0x1c])();
      uVar12 = *(uint *)(iVar9 + 0x2c);
      if (param_2 == uVar12) {
        uVar12 = *(uint *)(iVar9 + 0x30);
      }
      if (param_3 != (int *)0x0) {
        iVar9 = *param_3;
        if ((iVar9 != param_3[1]) && (uVar12 != param_3[4])) {
          uVar11 = (uVar12 >> 3) + uVar12;
          uVar15 = (param_3[1] - iVar9 >> 2) - 1;
          uVar14 = 0;
          do {
            uVar11 = uVar11 & uVar15;
            uVar6 = *(uint *)(iVar9 + uVar11 * 4);
            if (uVar6 == uVar12) goto LAB_00a9a79e;
            if (uVar6 == param_3[4]) break;
            iVar9 = *param_3;
            uVar11 = uVar11 + 1 + uVar14;
            uVar14 = uVar14 + 1;
          } while (uVar14 <= uVar15);
        }
      }
      FUN_008a65e0(0,0);
LAB_00a9a79e:
      uVar16 = uVar16 + 1;
      iVar13 = *piVar3;
      piVar17 = piStack_1c;
    } while (uVar16 < (uint)(*(int *)(param_1 + 400) - iVar13 >> 3));
  }
  FUN_00714e40(uStack_18,piVar3);
  if (*(int *)(iStack_20 + 0x1b4) == 0) {
    cStack00000013 = '\0';
  }
  else {
    cStack00000013 = *(char *)(*(int *)(iStack_20 + 0x1b4) + 0x40);
  }
  iVar9 = *piVar17;
  uStack_18 = uStack_24;
  if (uStack_24 < (uint)(piVar17[1] - iVar9 >> 3)) {
    do {
      iStack_14 = uStack_18 * 8;
      iVar9 = (*(code *)**(undefined4 **)(*(int *)(iStack_14 + iVar9) + 0x54))();
      uVar16 = *(uint *)(iVar9 + 0x2c);
      if (param_2 == uVar16) {
        uVar16 = *(uint *)(iVar9 + 0x30);
      }
      if (param_3 != (int *)0x0) {
        piStack_28 = (int *)*param_3;
        if ((piStack_28 != (int *)param_3[1]) && (uVar16 != param_3[4])) {
          uVar12 = (uVar16 >> 3) + uVar16;
          uVar11 = (param_3[1] - (int)piStack_28 >> 2) - 1;
          uVar14 = 0;
          do {
            uVar12 = uVar12 & uVar11;
            if (piStack_28[uVar12] == uVar16) goto LAB_00a9a8df;
            piVar17 = piStack_1c;
            if (piStack_28[uVar12] == param_3[4]) break;
            uVar12 = uVar12 + 1 + uVar14;
            uVar14 = uVar14 + 1;
          } while (uVar14 <= uVar11);
        }
      }
      if (cStack00000013 == '\0') {
        FUN_008a65e0(0,0);
      }
      else {
        piVar8 = (int *)(*piVar17 + iStack_14);
        cVar4 = *(char *)(*piVar8 + 0x74);
        FUN_00b4c8e0(0);
        pbVar1 = (byte *)(*piVar8 + 0x74);
        *pbVar1 = *pbVar1 ^ (cVar4 << 2 ^ *(byte *)(*piVar8 + 0x74)) & 4;
        piVar3 = *(int **)(iStack_20 + 0x1dc);
        if (*(int **)(iStack_20 + 0x1e0) == piVar3) {
          FUN_00603260(piVar3,piVar8);
        }
        else {
          *piVar3 = 0;
          piVar3[1] = 0;
          if (piVar8[1] != 0) {
            LOCK();
            piVar2 = (int *)(piVar8[1] + 4);
            *piVar2 = *piVar2 + 1;
            UNLOCK();
          }
          *piVar3 = *piVar8;
          piVar3[1] = piVar8[1];
          *(int *)(iStack_20 + 0x1dc) = *(int *)(iStack_20 + 0x1dc) + 8;
        }
      }
LAB_00a9a8df:
      iVar9 = *piVar17;
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < (uint)(piVar17[1] - iVar9 >> 3));
  }
  FUN_00714e40(uStack_24,piVar17);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21824 ; VA 0x00a9a920 ; FUN_00a9a920 */

void __thiscall FUN_00a9a920(int param_1,int *param_2)

{
  byte *pbVar1;
  int *piVar2;
  char cVar3;
  int *piVar4;
  
  cVar3 = *(char *)(*param_2 + 0x74);
  FUN_00b4c8e0(0);
  pbVar1 = (byte *)(*param_2 + 0x74);
  *pbVar1 = *pbVar1 ^ (cVar3 << 2 ^ *(byte *)(*param_2 + 0x74)) & 4;
  piVar4 = *(int **)(param_1 + 0x1dc);
  if (*(int **)(param_1 + 0x1e0) != piVar4) {
    *piVar4 = 0;
    piVar4[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar2 = (int *)(param_2[1] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    *piVar4 = *param_2;
    piVar4[1] = param_2[1];
    *(int *)(param_1 + 0x1dc) = *(int *)(param_1 + 0x1dc) + 8;
    return;
  }
  FUN_00603260(piVar4,param_2);
  return;
}



/* FUNCTION 21825 ; VA 0x00a9a9a0 ; FUN_00a9a9a0 */

int __fastcall FUN_00a9a9a0(int param_1)

{
  char *pcVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6948;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x1b4);
  if ((iVar4 != 0) &&
     (pcVar1 = (char *)(iVar4 + 0x40), iVar4 = CONCAT31((int3)((uint)iVar4 >> 8),*pcVar1),
     *pcVar1 != '\0')) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00ca12e0();
    if (iVar4 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = iVar4 + -0x54;
    }
    uVar5 = FUN_0060dcd0(auStack_18,iVar4);
    uStack_8 = 0;
    iVar4 = FUN_00a9a920(uVar5);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_14 + 1;
      iVar3 = *piVar2;
      iVar4 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)*piStack_14)();
        LOCK();
        piVar2 = piStack_14 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar4 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21826 ; VA 0x00a9aa40 ; FUN_00a9aa40 */

int __thiscall FUN_00a9aa40(int param_1,int param_2)

{
  char *pcVar1;
  byte *pbVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  void **ppvVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  undefined4 *puStack_2c;
  int *piStack_24;
  int iStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017e6970;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  puVar13 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0x0;
  piStack_24 = (int *)0x0;
  uStack_8 = 0;
  piStack_18 = (int *)0x0;
  iVar7 = *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3;
  ExceptionList = &pvStack_10;
  ppvVar6 = &pvStack_10;
  iStack_14 = param_1;
  if (0 < iVar7) {
    do {
      piVar8 = (int *)FUN_00c156d0(piStack_18);
      iVar7 = (**(code **)(*piVar8 + 0x10))();
      if (iVar7 == 4) {
        piStack_24 = piVar8;
        if (puVar13 == (undefined4 *)0x0) {
          FUN_006030d0(0,&piStack_24);
          puVar13 = puStack_2c;
        }
        else {
          *puVar13 = piVar8;
          puStack_2c = puVar13 + 1;
          puVar13 = puStack_2c;
        }
      }
      piStack_18 = (int *)((int)piStack_18 + 1);
      iVar7 = *(int *)(param_2 + 0x1d4) - *(int *)(param_2 + 0x1d0) >> 3;
      ppvVar6 = (void **)ExceptionList;
    } while ((int)piStack_18 < iVar7);
  }
  ExceptionList = ppvVar6;
  iStack_20 = 0;
  piStack_24 = (int *)0x0;
  puVar10 = (undefined4 *)0x0;
  iVar12 = iStack_14;
  if (puVar13 != (undefined4 *)0x0) {
    do {
      iVar7 = *(int *)(iVar12 + 0x1b4);
      if ((iVar7 != 0) &&
         (pcVar1 = (char *)(iVar7 + 0x40), iVar7 = CONCAT31((int3)((uint)iVar7 >> 8),*pcVar1),
         *pcVar1 != '\0')) {
        iVar7 = FUN_00ca12e0();
        if (iVar7 == 0) {
          iVar7 = 0;
        }
        else {
          iVar7 = iVar7 + -0x54;
        }
        piVar9 = (int *)FUN_0060dcd0(auStack_1c,iVar7);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        cVar5 = *(char *)(*piVar9 + 0x74);
        FUN_00b4c8e0(0);
        pbVar2 = (byte *)(*piVar9 + 0x74);
        *pbVar2 = *pbVar2 ^ (cVar5 << 2 ^ *(byte *)(*piVar9 + 0x74)) & 4;
        piVar8 = *(int **)(iStack_14 + 0x1dc);
        if (*(int **)(iStack_14 + 0x1e0) == piVar8) {
          iVar7 = FUN_00603260(piVar8,piVar9);
        }
        else {
          *piVar8 = 0;
          piVar8[1] = 0;
          if (piVar9[1] != 0) {
            LOCK();
            piVar3 = (int *)(piVar9[1] + 4);
            *piVar3 = *piVar3 + 1;
            UNLOCK();
          }
          *piVar8 = *piVar9;
          iVar7 = piVar9[1];
          piVar8[1] = iVar7;
          *(int *)(iStack_14 + 0x1dc) = *(int *)(iStack_14 + 0x1dc) + 8;
        }
        piVar8 = piStack_18;
        uStack_8 = uStack_8 & 0xffffff00;
        iVar12 = iStack_14;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piVar9 = piStack_18 + 1;
          iVar4 = *piVar9;
          iVar7 = *piVar9;
          *piVar9 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar9 = piVar8 + 2;
            iVar4 = *piVar9;
            iVar7 = *piVar9;
            *piVar9 = iVar4 + -1;
            UNLOCK();
            iVar12 = iStack_14;
            if (iVar4 + -1 == 0) {
              iVar7 = (**(code **)(*piVar8 + 4))();
              iVar12 = iStack_14;
            }
          }
        }
      }
      puVar10 = puVar10 + 1;
    } while (puVar10 != puVar13);
  }
  if (iStack_20 != 0) {
    uVar11 = (int)piStack_24 - iStack_20 & 0xfffffffc;
    iVar7 = iStack_20;
    if (0xfff < uVar11) {
      iVar7 = *(int *)(iStack_20 + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iStack_20 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar7 = FUN_01674ea0(iVar7,uVar11);
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 21827 ; VA 0x00a9ac40 ; FUN_00a9ac40 */

void FUN_00a9ac40(undefined4 param_1,undefined4 param_2)

{
  FUN_00a9a9a0(param_2);
  return;
}



/* FUNCTION 21828 ; VA 0x00a9ac60 ; FUN_00a9ac60 */

int FUN_00a9ac60(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined auStack_68 [24];
  undefined8 uStack_50;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6990;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar7 = FUN_01256300(param_2);
  iVar7 = iVar7 - param_3;
  uVar6 = FUN_009d1aa0(param_2,param_3,4,iVar7,iStack_24 + 0x50);
  uStack_28 = CONCAT31(uStack_28._1_3_,uVar6);
  uVar6 = FUN_009d1aa0(param_2,param_3,3,iVar7,iStack_24 + 0x4c);
  uStack_2c = CONCAT31(uStack_2c._1_3_,uVar6);
  puStack_30 = (undefined4 *)FUN_009d1050(auStack_40,param_2,param_3,2,iVar7,iStack_24 + 0x48);
  uStack_14 = 0;
  puVar8 = (undefined4 *)FUN_00a9cd40(auStack_68,param_2,param_3,1,iVar7,iStack_24 + 0x44);
  uVar2 = *(undefined8 *)(puVar8 + 4);
  uStack_50 = *(undefined8 *)(iStack_24 + 0x38);
  uVar9 = *puVar8;
  uVar3 = puVar8[1];
  uVar4 = puVar8[2];
  uVar5 = puVar8[3];
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar9 = (*(code *)uStack_50)
                    (auStack_38,uVar9,uVar3,uVar4,uVar5,uVar2,*puStack_30,puStack_30[1],uStack_2c,
                     uStack_28);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_24 = FUN_009d5730(param_2,uVar9);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_34[1] + -1;
    piStack_34[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar7 = piStack_34[2] + -1;
      piStack_34[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_24;
}



/* FUNCTION 21829 ; VA 0x00a9ae00 ; FUN_00a9ae00 */

int FUN_00a9ae00(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined auStack_68 [24];
  undefined8 uStack_50;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e69b0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar7 = FUN_01256300(param_2);
  iVar7 = iVar7 - param_3;
  uVar6 = FUN_009d1aa0(param_2,param_3,3,iVar7,iStack_24 + 0x4c);
  uStack_28 = CONCAT31(uStack_28._1_3_,uVar6);
  puStack_2c = (undefined4 *)FUN_009d1050(auStack_3c,param_2,param_3,2,iVar7,iStack_24 + 0x48);
  uStack_14 = 0;
  puVar8 = (undefined4 *)FUN_00a9cd40(auStack_68,param_2,param_3,1,iVar7,iStack_24 + 0x44);
  uVar2 = *(undefined8 *)(puVar8 + 4);
  uStack_50 = *(undefined8 *)(iStack_24 + 0x38);
  uVar9 = *puVar8;
  uVar3 = puVar8[1];
  uVar4 = puVar8[2];
  uVar5 = puVar8[3];
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar9 = (*(code *)uStack_50)
                    (auStack_34,uVar9,uVar3,uVar4,uVar5,uVar2,*puStack_2c,puStack_2c[1],uStack_28);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_24 = FUN_009d5730(param_2,uVar9);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_30[1] + -1;
    piStack_30[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar7 = piStack_30[2] + -1;
      piStack_30[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_38[1] + -1;
    piStack_38[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piStack_38 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_24;
}



/* FUNCTION 21830 ; VA 0x00a9af90 ; FUN_00a9af90 */

int FUN_00a9af90(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined auStack_68 [24];
  undefined8 uStack_50;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e69d0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar7 = FUN_01256300(param_2);
  iVar7 = iVar7 - param_3;
  uVar6 = FUN_009d1aa0(param_2,param_3,4,iVar7,iStack_24 + 0x50);
  uStack_28 = CONCAT31(uStack_28._1_3_,uVar6);
  uVar6 = FUN_009d1aa0(param_2,param_3,3,iVar7,iStack_24 + 0x4c);
  uStack_2c = CONCAT31(uStack_2c._1_3_,uVar6);
  puStack_30 = (undefined4 *)FUN_009d1340(auStack_40,param_2,param_3,2,iVar7,iStack_24 + 0x48);
  uStack_14 = 0;
  puVar8 = (undefined4 *)FUN_00a9cd40(auStack_68,param_2,param_3,1,iVar7,iStack_24 + 0x44);
  uVar2 = *(undefined8 *)(puVar8 + 4);
  uStack_50 = *(undefined8 *)(iStack_24 + 0x38);
  uVar9 = *puVar8;
  uVar3 = puVar8[1];
  uVar4 = puVar8[2];
  uVar5 = puVar8[3];
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar9 = (*(code *)uStack_50)
                    (auStack_38,uVar9,uVar3,uVar4,uVar5,uVar2,*puStack_30,puStack_30[1],uStack_2c,
                     uStack_28);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_24 = FUN_009d5730(param_2,uVar9);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_34[1] + -1;
    piStack_34[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar7 = piStack_34[2] + -1;
      piStack_34[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_24;
}



/* FUNCTION 21831 ; VA 0x00a9b130 ; FUN_00a9b130 */

int FUN_00a9b130(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  undefined auStack_8c [60];
  undefined8 uStack_50;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e69f0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar14 = FUN_01256300(param_2);
  iVar14 = iVar14 - param_3;
  uStack_2c = FUN_009d05b0(param_2,param_3,3,iVar14,iStack_28 + 0x4c);
  puStack_30 = (undefined4 *)FUN_009d1050(auStack_40,param_2,param_3,2,iVar14,iStack_28 + 0x48);
  uStack_14 = 0;
  puVar15 = (undefined4 *)FUN_00a9cec0(auStack_8c,param_2,param_3,1,iVar14,iStack_28 + 0x44);
  uVar16 = puVar15[4];
  uVar3 = puVar15[5];
  uVar4 = puVar15[6];
  uVar5 = puVar15[7];
  uStack_50 = *(undefined8 *)(iStack_28 + 0x38);
  uVar6 = puVar15[8];
  uVar7 = puVar15[9];
  uVar8 = puVar15[10];
  uVar9 = puVar15[0xb];
  uVar2 = *(undefined8 *)(puVar15 + 0xc);
  uVar10 = *puVar15;
  uVar11 = puVar15[1];
  uVar12 = puVar15[2];
  uVar13 = puVar15[3];
  iStack_28 = puVar15[0xe];
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar16 = (*(code *)uStack_50)
                     (auStack_38,uVar10,uVar11,uVar12,uVar13,uVar16,uVar3,uVar4,uVar5,uVar6,uVar7,
                      uVar8,uVar9,uVar2,iStack_28,*puStack_30,puStack_30[1],uStack_2c);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_28 = FUN_009d5920(param_2,uVar16);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_34[1] + -1;
    piStack_34[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar14 = piStack_34[2] + -1;
      piStack_34[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar14 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar14 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_28;
}



/* FUNCTION 21832 ; VA 0x00a9b2d0 ; FUN_00a9b2d0 */

int FUN_00a9b2d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  undefined auStack_8c [60];
  undefined8 uStack_50;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6a10;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar14 = FUN_01256300(param_2);
  iVar14 = iVar14 - param_3;
  uStack_2c = FUN_009d05b0(param_2,param_3,3,iVar14,iStack_28 + 0x4c);
  puStack_30 = (undefined4 *)FUN_009d1340(auStack_40,param_2,param_3,2,iVar14,iStack_28 + 0x48);
  uStack_14 = 0;
  puVar15 = (undefined4 *)FUN_00a9cec0(auStack_8c,param_2,param_3,1,iVar14,iStack_28 + 0x44);
  uVar16 = puVar15[4];
  uVar3 = puVar15[5];
  uVar4 = puVar15[6];
  uVar5 = puVar15[7];
  uStack_50 = *(undefined8 *)(iStack_28 + 0x38);
  uVar6 = puVar15[8];
  uVar7 = puVar15[9];
  uVar8 = puVar15[10];
  uVar9 = puVar15[0xb];
  uVar2 = *(undefined8 *)(puVar15 + 0xc);
  uVar10 = *puVar15;
  uVar11 = puVar15[1];
  uVar12 = puVar15[2];
  uVar13 = puVar15[3];
  iStack_28 = puVar15[0xe];
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar16 = (*(code *)uStack_50)
                     (auStack_38,uVar10,uVar11,uVar12,uVar13,uVar16,uVar3,uVar4,uVar5,uVar6,uVar7,
                      uVar8,uVar9,uVar2,iStack_28,*puStack_30,puStack_30[1],uStack_2c);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_28 = FUN_009d5920(param_2,uVar16);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_34[1] + -1;
    piStack_34[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar14 = piStack_34[2] + -1;
      piStack_34[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar14 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar14 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_28;
}



/* FUNCTION 21833 ; VA 0x00a9b470 ; FUN_00a9b470 */

undefined4 FUN_00a9b470(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined auStack_a0 [40];
  undefined auStack_78 [36];
  int *piStack_54;
  undefined auStack_50 [12];
  undefined auStack_44 [12];
  undefined8 uStack_38;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6a33;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_28 = FUN_00a9cb10(auStack_a0,param_2,param_3,3,iVar2,iStack_24 + 0x4c);
  uStack_14 = 0;
  uVar3 = FUN_009d16a0(auStack_44,param_2,param_3,2,iVar2,iStack_24 + 0x48);
  uVar4 = FUN_009d16a0(auStack_50,param_2,param_3,1,iVar2,iStack_24 + 0x44);
  uStack_38 = *(undefined8 *)(iStack_24 + 0x38);
  uVar3 = (*(code *)uStack_38)(auStack_78,uVar4,uVar3,uStack_28);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  uStack_28 = FUN_009d59a0(param_2,uVar3);
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_54[1] + -1;
    piStack_54[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar1 = piStack_54 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  FUN_0087dcc0();
  ExceptionList = pvStack_1c;
  return uStack_28;
}



/* FUNCTION 21834 ; VA 0x00a9b5a0 ; FUN_00a9b5a0 */

undefined4 FUN_00a9b5a0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined4 uStack_18;
  int iStack_14;
  
  iVar2 = FUN_01256300(param_2);
  uVar1 = FUN_009d1aa0(param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x48);
  uStack_18 = CONCAT31(uStack_18._1_3_,uVar1);
  uVar3 = FUN_009d16a0(auStack_34,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x44);
  uStack_28 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_28)(uVar3,uStack_18);
  return 0;
}



/* FUNCTION 21835 ; VA 0x00a9b640 ; FUN_00a9b640 */

undefined4 FUN_00a9b640(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  code *pcStack_50;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6a50;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar5 = FUN_01256300(param_2);
  iVar5 = iVar5 - param_3;
  if (2 < iVar5) {
    uVar6 = FUN_00a9e750();
    cVar4 = FUN_009d1e20(uVar6,param_2,param_3 + 3,&puStack_2c);
    if (cVar4 != '\0') goto LAB_00a9b6c3;
  }
  puStack_2c = (undefined4 *)FUN_00a96180(param_2,param_3,3,iVar5,iStack_24 + 0x4c);
LAB_00a9b6c3:
  puStack_28 = puStack_2c;
  puStack_2c = (undefined4 *)FUN_009d11e0(auStack_3c,param_2,param_3,2,iVar5,iStack_24 + 0x48);
  uStack_14 = 0;
  puVar7 = (undefined4 *)FUN_009d1050(auStack_34,param_2,param_3,1,iVar5,iStack_24 + 0x44);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  uVar2 = *(undefined8 *)(iStack_24 + 0x38);
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = *puStack_2c;
  uVar3 = puStack_2c[1];
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_50 = (code *)uVar2;
  (*pcStack_50)(*puVar7,puVar7[1],uVar6,uVar3,puStack_28);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piStack_38 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 21836 ; VA 0x00a9b7f0 ; FUN_00a9b7f0 */

undefined4 FUN_00a9b7f0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  float *pfVar4;
  undefined4 *puVar5;
  float10 fVar6;
  undefined4 uStack_158;
  int iStack_154;
  undefined auStack_150 [204];
  undefined auStack_84 [12];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined8 auStack_40 [2];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6a8a;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  if (iVar3 < 5) {
LAB_00a9b930:
    if (*(float **)(iStack_24 + 0x54) == (float *)0x0) {
      FUN_016756b0(auStack_84,"Argument %d missing or nil",5);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_84,&DAT_01c17198);
    }
    fStack_28 = **(float **)(iStack_24 + 0x54);
  }
  else {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb19c) {
      FUN_016f3809(&DAT_01eeb19c);
      if (DAT_01eeb19c == -1) {
        uStack_14 = 0;
        FUN_00e00d40();
        FUN_016f3654(&LAB_0188ae60);
        uStack_14 = 0xffffffff;
        FUN_016f37bf(&DAT_01eeb19c);
      }
    }
    cVar2 = FUN_009d1e20(&DAT_01eeb138,param_2,param_3 + 5,&fStack_2c);
    if (cVar2 == '\0') {
      if (4 < iVar3) {
        uStack_158 = FUN_00888530();
        iStack_154 = 0;
        uStack_14 = 1;
        cVar2 = FUN_009d1bf0(param_2,param_3 + 5,&uStack_158,1);
        if (cVar2 != '\0') {
          pfVar4 = (float *)FUN_00e00340();
          fStack_28 = *pfVar4;
          uStack_14 = 2;
          if (iStack_154 != 0) {
            (**(code **)(iStack_154 + 8))(auStack_150);
          }
          uStack_14 = 0xffffffff;
          goto LAB_00a9b943;
        }
        uStack_14 = 3;
        if (iStack_154 != 0) {
          (**(code **)(iStack_154 + 8))(auStack_150);
        }
        uStack_14 = 0xffffffff;
      }
      goto LAB_00a9b930;
    }
    fStack_28 = fStack_2c;
  }
LAB_00a9b943:
  fVar6 = (float10)FUN_009d0730(param_2,param_3,4,iVar3,iStack_24 + 0x50);
  fStack_2c = (float)fVar6;
  fVar6 = (float10)FUN_009d0730(param_2,param_3,3,iVar3,iStack_24 + 0x4c);
  fStack_30 = (float)fVar6;
  if (iVar3 < 2) {
LAB_00a9ba53:
    puVar5 = *(undefined4 **)(iStack_24 + 0x48);
    if (puVar5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_40,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_40,&DAT_01c17198);
    }
  }
  else {
    FUN_0060efa0();
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + 2,DAT_01ede6d4);
    if (puVar5 == (undefined4 *)0x0) {
      if (1 < iVar3) {
        uStack_158 = FUN_00888530();
        iStack_154 = 0;
        uStack_14 = 4;
        cVar2 = FUN_009d1bf0(param_2,param_3 + 2,&uStack_158,1);
        if (cVar2 != '\0') {
          puVar5 = (undefined4 *)FUN_0088ab30();
          uStack_78 = *puVar5;
          uStack_74 = puVar5[1];
          uStack_70 = puVar5[2];
          uStack_6c = puVar5[3];
          uStack_68 = puVar5[4];
          uStack_64 = puVar5[5];
          uStack_60 = puVar5[6];
          uStack_5c = puVar5[7];
          uStack_58 = puVar5[8];
          uStack_54 = puVar5[9];
          uStack_50 = puVar5[10];
          uStack_4c = puVar5[0xb];
          uStack_14 = 5;
          if (iStack_154 != 0) {
            (**(code **)(iStack_154 + 8))(auStack_150);
          }
          uStack_14 = 0xffffffff;
          goto LAB_00a9ba78;
        }
        uStack_14 = 6;
        if (iStack_154 != 0) {
          (**(code **)(iStack_154 + 8))(auStack_150);
        }
        uStack_14 = 0xffffffff;
      }
      goto LAB_00a9ba53;
    }
  }
  uStack_78 = *puVar5;
  uStack_74 = puVar5[1];
  uStack_70 = puVar5[2];
  uStack_6c = puVar5[3];
  uStack_68 = puVar5[4];
  uStack_64 = puVar5[5];
  uStack_60 = puVar5[6];
  uStack_5c = puVar5[7];
  uStack_58 = puVar5[8];
  uStack_54 = puVar5[9];
  uStack_50 = puVar5[10];
  uStack_4c = puVar5[0xb];
LAB_00a9ba78:
  puVar5 = (undefined4 *)FUN_009d1340(auStack_48,param_2,param_3,1,iVar3,iStack_24 + 0x44);
  uStack_14 = 7;
  auStack_40[0] = *(undefined8 *)(iStack_24 + 0x38);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*(code *)auStack_40[0])(*puVar5,puVar5[1],&uStack_78,fStack_30,fStack_2c,fStack_28);
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_44[1] + -1;
    piStack_44[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 21837 ; VA 0x00a9bbe0 ; FUN_00a9bbe0 */

undefined4 FUN_00a9bbe0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  float10 fVar6;
  code *pcStack_40;
  undefined auStack_30 [4];
  int *piStack_2c;
  float fStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bda48;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  fVar6 = (float10)FUN_009d0730(param_2,param_3,2,iVar3 - param_3,iStack_24 + 0x48);
  fStack_28 = (float)fVar6;
  puVar4 = (undefined4 *)FUN_009d1050(auStack_30,param_2,param_3,1,iVar3 - param_3,iStack_24 + 0x44)
  ;
  uStack_14 = 0;
  uVar2 = *(undefined8 *)(iStack_24 + 0x38);
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  uVar5 = (*pcStack_40)(*puVar4,puVar4[1],fStack_28);
  uVar5 = FUN_009d5ac0(param_2,uVar5);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 21838 ; VA 0x00a9bd00 ; FUN_00a9bd00 */

int FUN_00a9bd00(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  undefined auStack_84 [60];
  undefined8 uStack_48;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_2c;
  int iStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6aa8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar14 = FUN_01256300(param_2);
  puStack_2c = (undefined4 *)
               FUN_009d1050(auStack_38,param_2,param_3,2,iVar14 - param_3,iStack_28 + 0x48);
  uStack_14 = 0;
  puVar15 = (undefined4 *)
            FUN_00a9cec0(auStack_84,param_2,param_3,1,iVar14 - param_3,iStack_28 + 0x44);
  uVar16 = puVar15[4];
  uVar3 = puVar15[5];
  uVar4 = puVar15[6];
  uVar5 = puVar15[7];
  uStack_48 = *(undefined8 *)(iStack_28 + 0x38);
  uVar6 = puVar15[8];
  uVar7 = puVar15[9];
  uVar8 = puVar15[10];
  uVar9 = puVar15[0xb];
  uVar2 = *(undefined8 *)(puVar15 + 0xc);
  uVar10 = *puVar15;
  uVar11 = puVar15[1];
  uVar12 = puVar15[2];
  uVar13 = puVar15[3];
  iStack_28 = puVar15[0xe];
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar16 = (*(code *)uStack_48)
                     (uVar10,uVar11,uVar12,uVar13,uVar16,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,
                      uVar2,iStack_28,*puStack_2c,puStack_2c[1]);
  iStack_28 = FUN_009d5ac0(param_2,uVar16);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_34[1] + -1;
    piStack_34[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar14 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_28;
}



/* FUNCTION 21839 ; VA 0x00a9be50 ; FUN_00a9be50 */

int FUN_00a9be50(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  undefined auStack_84 [60];
  undefined8 uStack_48;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_2c;
  int iStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e6ac8;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar14 = FUN_01256300(param_2);
  puStack_2c = (undefined4 *)
               FUN_009d1340(auStack_38,param_2,param_3,2,iVar14 - param_3,iStack_28 + 0x48);
  uStack_14 = 0;
  puVar15 = (undefined4 *)
            FUN_00a9cec0(auStack_84,param_2,param_3,1,iVar14 - param_3,iStack_28 + 0x44);
  uVar16 = puVar15[4];
  uVar3 = puVar15[5];
  uVar4 = puVar15[6];
  uVar5 = puVar15[7];
  uStack_48 = *(undefined8 *)(iStack_28 + 0x38);
  uVar6 = puVar15[8];
  uVar7 = puVar15[9];
  uVar8 = puVar15[10];
  uVar9 = puVar15[0xb];
  uVar2 = *(undefined8 *)(puVar15 + 0xc);
  uVar10 = *puVar15;
  uVar11 = puVar15[1];
  uVar12 = puVar15[2];
  uVar13 = puVar15[3];
  iStack_28 = puVar15[0xe];
  if (puStack_2c[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_2c[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar16 = (*(code *)uStack_48)
                     (uVar10,uVar11,uVar12,uVar13,uVar16,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,
                      uVar2,iStack_28,*puStack_2c,puStack_2c[1]);
  iStack_28 = FUN_009d5ac0(param_2,uVar16);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_34[1] + -1;
    piStack_34[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar14 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iStack_28;
}



/* FUNCTION 21840 ; VA 0x00a9bfa0 ; FUN_00a9bfa0 */

void FUN_00a9bfa0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 == 0) {
    FUN_005c3ac0();
    return;
  }
  return;
}



/* FUNCTION 21841 ; VA 0x00a9bfc0 ; FUN_00a9bfc0 */

int * __thiscall FUN_00a9bfc0(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined **ppuVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  int iVar12;
  int *piVar13;
  int iVar14;
  int *piVar15;
  int *in_stack_00000044;
  int *in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined8 uStack_88;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined auStack_70 [4];
  undefined *puStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [4];
  undefined auStack_54 [8];
  undefined auStack_4c [4];
  undefined auStack_48 [8];
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  undefined *puStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6b10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar3 = (undefined8 *)FUN_00a735a0(auStack_58);
  puVar4 = (undefined8 *)FUN_00a735f0(auStack_4c);
  piStack_28 = (int *)&DAT_0000000b;
  uStack_88 = *puVar4;
  uStack_80 = *(undefined4 *)(puVar4 + 1);
  uStack_7c = *puVar3;
  uStack_74 = *(undefined4 *)(puVar3 + 1);
  auStack_70[0] = 0;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_28);
  ppuVar11 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar11 = ppuVar5;
  }
  puStack_6c = *ppuVar11;
  uStack_68 = 0;
  uStack_64 = 0x3f800000;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar14 = param_1;
  if (in_stack_00000044 != (int *)0x0) {
    puStack_2c = auStack_70;
    piVar13 = (int *)*in_stack_00000044;
    piVar8 = (int *)in_stack_00000044[1];
    iVar14 = iStack_1c;
    iStack_30 = param_1;
    piStack_18 = piVar13;
    piStack_14 = piVar8;
    if (piVar13 != piVar8) {
      do {
        iVar14 = *piVar13;
        if (iVar14 != 0) {
          iVar7 = *(int *)(iVar14 + 0xc);
          piStack_18 = piVar13;
          iVar6 = FUN_00aff8c0();
          iVar12 = 0;
          if ((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            iVar12 = iVar14;
          }
          if (iVar12 != 0) {
            piStack_20 = *(int **)(iVar12 + 0xa8);
            FUN_00a95260(auStack_48,&piStack_20,&piStack_20);
          }
          iVar14 = *piVar13;
          piVar15 = *(int **)(iVar14 + 0x2c);
          piVar8 = piStack_14;
          if (piVar15 != (int *)0x0) {
            piStack_3c = *(int **)(iVar14 + 0x30);
            if (piStack_3c != (int *)0x0) {
              LOCK();
              piStack_3c[1] = piStack_3c[1] + 1;
              UNLOCK();
              piStack_3c = *(int **)(iVar14 + 0x30);
              piVar15 = *(int **)(iVar14 + 0x2c);
            }
            piVar13 = (int *)piVar15[1];
            piVar1 = piStack_3c;
            piStack_40 = piVar15;
            for (piVar8 = (int *)*piVar15; uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8),
                piStack_28 = piVar1, piVar8 != piVar13; piVar8 = piVar8 + 2) {
              piStack_34 = (int *)piVar8[1];
              if (piStack_34 != (int *)0x0) {
                LOCK();
                piStack_34[1] = piStack_34[1] + 1;
                UNLOCK();
                piStack_34 = (int *)piVar8[1];
              }
              iStack_38 = *piVar8;
              uStack_8._0_1_ = 3;
              piStack_20 = piStack_34;
              if ((iStack_38 != 0) &&
                 (iVar14 = *(int *)(iStack_38 + 0xc), iVar7 = FUN_00aff8c0(),
                 (uint)*(ushort *)(iVar14 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
                 (uint)*(ushort *)(iVar7 + 0x1da))) {
                uStack_24 = *(undefined4 *)(iStack_38 + 0xa8);
                FUN_00a95260(auStack_54,&uStack_24,&uStack_24);
              }
              piVar15 = piStack_20;
              uStack_8 = CONCAT31(uStack_8._1_3_,2);
              if (piStack_20 != (int *)0x0) {
                LOCK();
                iVar14 = piStack_20[1] + -1;
                piStack_20[1] = iVar14;
                UNLOCK();
                if (iVar14 == 0) {
                  (**(code **)*piStack_20)();
                  LOCK();
                  piVar1 = piVar15 + 2;
                  iVar14 = *piVar1 + -1;
                  *piVar1 = iVar14;
                  UNLOCK();
                  if (iVar14 == 0) {
                    (**(code **)(*piVar15 + 4))();
                  }
                }
              }
              FUN_00a96380(&iStack_30);
              piVar1 = piStack_28;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            piVar8 = piStack_14;
            piVar13 = piStack_18;
            if (piVar1 != (int *)0x0) {
              LOCK();
              iVar14 = piVar1[1] + -1;
              piVar1[1] = iVar14;
              UNLOCK();
              if (iVar14 == 0) {
                (**(code **)*piVar1)();
                LOCK();
                iVar14 = piVar1[2] + -1;
                piVar1[2] = iVar14;
                UNLOCK();
                piVar8 = piStack_14;
                piVar13 = piStack_18;
                if (iVar14 == 0) {
                  (**(code **)(*piVar1 + 4))();
                  piVar8 = piStack_14;
                  piVar13 = piStack_18;
                }
              }
            }
          }
        }
        piVar13 = piVar13 + 2;
        iVar14 = iStack_1c;
        piStack_18 = piVar13;
      } while (piVar13 != piVar8);
    }
  }
  iVar7 = *(int *)(iVar14 + 0x1c0);
  piVar13 = (int *)(iVar14 + 0x1bc);
  piStack_28 = piVar13;
  if (iVar7 != 0) {
    *(undefined4 *)(iVar14 + 0x1c0) = 0;
    if (*(int *)(iVar14 + 0x1c4) < 0) {
      if (*(int *)(iVar14 + 0x1c4) == 0) {
        *(undefined4 *)(iVar14 + 0x1c4) = 0;
      }
      else {
        *(undefined4 *)(iVar14 + 0x1c4) = 10;
      }
      FUN_0078c480(iVar7);
    }
  }
  FUN_00ce4b20(&uStack_88,auStack_70,in_stack_0000004c,piVar13,in_stack_00000050);
  FUN_0088dc10(&iStack_30);
  iVar14 = 0;
  uStack_8._0_1_ = 4;
  if (0 < *(int *)(iStack_1c + 0x1c0)) {
    do {
      uVar9 = FUN_00b06640(*(undefined4 *)(*piVar13 + iVar14 * 4));
      puVar10 = (undefined4 *)FUN_0060dcd0(&piStack_40,uVar9);
      uStack_8._0_1_ = 5;
      puVar2 = *(undefined4 **)(iStack_30 + 4);
      if (*(undefined4 **)(iStack_30 + 8) == puVar2) {
        FUN_00603a30(puVar2,puVar10);
      }
      else {
        *puVar2 = 0;
        puVar2[1] = 0;
        *puVar2 = *puVar10;
        puVar2[1] = puVar10[1];
        *puVar10 = 0;
        puVar10[1] = 0;
        *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 8;
      }
      piVar13 = piStack_3c;
      uStack_8._0_1_ = 4;
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          piVar8 = piVar13 + 2;
          iVar7 = *piVar8 + -1;
          *piVar8 = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      iVar14 = iVar14 + 1;
      piVar13 = piStack_28;
    } while (iVar14 < *(int *)(iStack_1c + 0x1c0));
  }
  *param_2 = iStack_30;
  param_2[1] = (int)puStack_2c;
  FUN_006e27a0();
  if (in_stack_00000048 != (int *)0x0) {
    LOCK();
    iVar14 = in_stack_00000048[1] + -1;
    in_stack_00000048[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*in_stack_00000048)();
      LOCK();
      piVar13 = in_stack_00000048 + 2;
      iVar14 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*in_stack_00000048 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21842 ; VA 0x00a9c380 ; FUN_00a9c380 */

undefined4
FUN_00a9c380(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined8 param_14,undefined4 param_15,int param_16,int *param_17,
            undefined4 param_18)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6b30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0088dc10(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_16 != 0) {
    piVar2 = *(int **)(iStack_1c + 4);
    if (*(int **)(iStack_1c + 8) == piVar2) {
      FUN_005c1970(piVar2,&param_16);
    }
    else {
      *piVar2 = 0;
      piVar2[1] = 0;
      if (param_17 != (int *)0x0) {
        LOCK();
        param_17[1] = param_17[1] + 1;
        UNLOCK();
      }
      *piVar2 = param_16;
      piVar2[1] = (int)param_17;
      *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 8;
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  FUN_00a9bfc0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11,param_12,param_13,param_14,param_15,iStack_1c,piStack_18,param_18,0);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar2 = param_17;
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar3 = param_17[1] + -1;
    param_17[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_17)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21843 ; VA 0x00a9c4c0 ; FUN_00a9c4c0 */

undefined4
FUN_00a9c4c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined8 param_14,undefined4 param_15,undefined4 param_16,
            int *param_17,undefined4 param_18)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6b48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_17 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  FUN_00a9bfc0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11,param_12,param_13,param_14,param_15,param_16,param_17,param_18,0);
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar1 = param_17[1] + -1;
    param_17[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_17)();
      LOCK();
      iVar1 = param_17[2] + -1;
      param_17[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21844 ; VA 0x00a9c590 ; FUN_00a9c590 */

undefined4
FUN_00a9c590(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined8 param_14,undefined4 param_15,undefined4 param_16,
            int *param_17,undefined4 param_18)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6b48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_17 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  FUN_00a9bfc0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
               param_11,param_12,param_13,param_14,param_15,param_16,param_17,param_18,1);
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar1 = param_17[1] + -1;
    param_17[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_17)();
      LOCK();
      iVar1 = param_17[2] + -1;
      param_17[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21845 ; VA 0x00a9c660 ; FUN_00a9c660 */

undefined4 * FUN_00a9c660(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  float fStack_48;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6b70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined8 *)FUN_006e0af0();
  uStack_50 = *(undefined4 *)puVar4;
  uStack_4c = *(undefined4 *)((int)puVar4 + 4);
  uStack_40 = *puVar4;
  fStack_48 = *(float *)(puVar4 + 1);
  fStack_44 = *(float *)((int)puVar4 + 0xc);
  fStack_30 = *(float *)(puVar4 + 2);
  fStack_2c = *(float *)((int)puVar4 + 0x14);
  uStack_18 = puVar4[2];
  if (*param_2 != param_2[1]) {
    fStack_38 = fStack_48;
    fStack_34 = fStack_44;
    FUN_00587490(&iStack_28);
    iStack_8 = 0;
    if (iStack_28 == 0) {
      *param_1 = uStack_50;
      param_1[1] = uStack_4c;
      param_1[2] = fStack_48;
      param_1[3] = fStack_44;
      *(undefined8 *)(param_1 + 4) = uStack_18;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar8 = piStack_24 + 2;
          iVar3 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    iStack_20 = *param_2;
    uStack_1c = 0;
    if (param_2[1] - iStack_20 >> 3 != 0) {
      do {
        iVar3 = *(int *)(iStack_20 + 4 + uStack_1c * 8);
        uStack_18 = 0;
        iVar5 = 0;
        if (iVar3 != 0) {
          piVar8 = (int *)(iVar3 + 4);
          iVar3 = *(int *)(iVar3 + 4);
          while (iVar3 != 0) {
            LOCK();
            iVar5 = *piVar8;
            if (iVar3 == iVar5) {
              *piVar8 = iVar3 + 1;
              iVar5 = iVar3;
            }
            UNLOCK();
            if (iVar5 == iVar3) {
              iVar5 = *(int *)(iStack_20 + uStack_1c * 8);
              uStack_18 = CONCAT44(*(undefined4 *)(iStack_20 + 4 + uStack_1c * 8),iVar5);
              goto LAB_00a9c77a;
            }
            iVar3 = *piVar8;
          }
          uStack_18._0_4_ = 0;
          iVar5 = (int)uStack_18;
        }
LAB_00a9c77a:
        iStack_8._0_1_ = 1;
        if (iVar5 != 0) {
          uVar6 = FUN_00b077e0();
          uVar7 = FUN_00c157b0();
          FUN_00c9eef0(&fStack_68,uVar7,uVar6);
          if (fStack_60 <= fStack_38) {
            fStack_38 = fStack_60;
          }
          fVar2 = uStack_40._4_4_;
          if (fStack_64 <= uStack_40._4_4_) {
            fVar2 = fStack_64;
          }
          if (fStack_68 <= (float)uStack_40) {
            uStack_40._0_4_ = fStack_68;
          }
          uStack_40 = CONCAT44(fVar2,(float)uStack_40);
          if (fStack_2c <= fStack_54) {
            fStack_2c = fStack_54;
          }
          if (fStack_30 <= fStack_58) {
            fStack_30 = fStack_58;
          }
          fStack_44 = fStack_2c;
          if (fStack_34 <= fStack_5c) {
            fStack_34 = fStack_5c;
          }
        }
        piVar8 = uStack_18._4_4_;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (uStack_18._4_4_ != (int *)0x0) {
          LOCK();
          iVar3 = uStack_18._4_4_[1] + -1;
          uStack_18._4_4_[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*uStack_18._4_4_)();
            LOCK();
            piVar1 = piVar8 + 2;
            iVar3 = *piVar1 + -1;
            *piVar1 = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        uStack_1c = uStack_1c + 1;
        iStack_20 = *param_2;
      } while (uStack_1c < (uint)(param_2[1] - iStack_20 >> 3));
      uStack_18 = CONCAT44(fStack_2c,fStack_30);
      uStack_50 = (float)uStack_40;
      uStack_4c = uStack_40._4_4_;
      fStack_48 = fStack_38;
      fStack_44 = fStack_34;
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar8 = piStack_24 + 2;
        iVar3 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  *param_1 = uStack_50;
  param_1[1] = uStack_4c;
  param_1[2] = fStack_48;
  param_1[3] = fStack_44;
  *(undefined8 *)(param_1 + 4) = uStack_18;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21846 ; VA 0x00a9c980 ; FUN_00a9c980 */

undefined4 *
FUN_00a9c980(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    FUN_0060efa0();
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6d4);
    if (puVar5 != (undefined4 *)0x0) {
      uVar1 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_1 = *puVar5;
      param_1[1] = uVar1;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      uVar1 = puVar5[5];
      uVar2 = puVar5[6];
      uVar3 = puVar5[7];
      param_1[4] = puVar5[4];
      param_1[5] = uVar1;
      param_1[6] = uVar2;
      param_1[7] = uVar3;
      uVar1 = puVar5[9];
      uVar2 = puVar5[10];
      uVar3 = puVar5[0xb];
      param_1[8] = puVar5[8];
      param_1[9] = uVar1;
      param_1[10] = uVar2;
      param_1[0xb] = uVar3;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar4 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
      if (cVar4 != '\0') {
        puVar5 = (undefined4 *)FUN_0088ab30();
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *param_1 = *puVar5;
        param_1[1] = uVar1;
        param_1[2] = uVar2;
        param_1[3] = uVar3;
        uVar1 = puVar5[5];
        uVar2 = puVar5[6];
        uVar3 = puVar5[7];
        param_1[4] = puVar5[4];
        param_1[5] = uVar1;
        param_1[6] = uVar2;
        param_1[7] = uVar3;
        uVar1 = puVar5[9];
        uVar2 = puVar5[10];
        uVar3 = puVar5[0xb];
        param_1[8] = puVar5[8];
        param_1[9] = uVar1;
        param_1[10] = uVar2;
        param_1[0xb] = uVar3;
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = (undefined4 *)*param_6;
  if (puVar5 != (undefined4 *)0x0) {
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *param_1 = *puVar5;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    param_1[4] = puVar5[4];
    param_1[5] = uVar1;
    param_1[6] = uVar2;
    param_1[7] = uVar3;
    uVar1 = puVar5[9];
    uVar2 = puVar5[10];
    uVar3 = puVar5[0xb];
    param_1[8] = puVar5[8];
    param_1[9] = uVar1;
    param_1[10] = uVar2;
    param_1[0xb] = uVar3;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 21847 ; VA 0x00a9cb10 ; FUN_00a9cb10 */

undefined *
FUN_00a9cb10(undefined *param_1,undefined4 param_2,int param_3,int param_4,int param_5,
            undefined4 *param_6)

{
  undefined4 *puVar1;
  int iVar2;
  char cVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uStack_114;
  int iStack_110;
  undefined auStack_10c [200];
  undefined auStack_44 [12];
  undefined auStack_38 [4];
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6b9e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    FUN_00d89aa0();
    uStack_8 = 0;
    puVar4 = (undefined *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede698);
    piVar5 = piStack_2c;
    if (puVar4 != (undefined *)0x0) {
      auStack_38[0] = *puVar4;
      uStack_34 = *(undefined4 *)(puVar4 + 4);
      piVar7 = *(int **)(puVar4 + 0xc);
      if (piVar7 != (int *)0x0) {
        LOCK();
        *(int *)((int)piVar7 + 4) = *(int *)((int)piVar7 + 4) + 1;
        UNLOCK();
        piVar7 = *(int **)(puVar4 + 0xc);
      }
      uStack_30 = *(undefined4 *)(puVar4 + 8);
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          puVar1 = (undefined4 *)*piStack_2c;
          piStack_2c = piVar7;
          (*(code *)*puVar1)();
          LOCK();
          piVar7 = piVar5 + 2;
          iVar2 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          piVar7 = piStack_2c;
          if (iVar2 == 1) {
            (**(code **)(*piVar5 + 4))();
            piVar7 = piStack_2c;
          }
        }
      }
      piStack_2c = piVar7;
      piVar5 = (int *)(puVar4 + 0x10);
      if ((int *)auStack_28 != piVar5) {
        if (0xf < *(uint *)(puVar4 + 0x24)) {
          piVar5 = (int *)*piVar5;
        }
        FUN_005542c0(piVar5,*(undefined4 *)(puVar4 + 0x20));
      }
      FUN_009cf9e0(auStack_38);
      FUN_0087dcc0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 0xffffffff;
    FUN_0087dcc0();
    uStack_114 = FUN_00888530();
    iStack_110 = 0;
    uStack_8 = 1;
    cVar3 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_114,1);
    if (cVar3 != '\0') {
      uVar6 = FUN_00d898a0();
      FUN_009cf9e0(uVar6);
      uStack_8 = 2;
      if (iStack_110 == 0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(iStack_110 + 8))(auStack_10c);
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = 3;
    if (iStack_110 != 0) {
      (**(code **)(iStack_110 + 8))(auStack_10c);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = (undefined *)*param_6;
  if (puVar4 != (undefined *)0x0) {
    *param_1 = *puVar4;
    *(undefined4 *)(param_1 + 4) = *(undefined4 *)(puVar4 + 4);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    if (*(int *)(puVar4 + 0xc) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(puVar4 + 0xc) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(puVar4 + 8);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(puVar4 + 0xc);
    uStack_8 = 4;
    FUN_0054ef60(puVar4 + 0x10);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_44,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_44,&DAT_01c17198);
}



/* FUNCTION 21848 ; VA 0x00a9cd40 ; FUN_00a9cd40 */

undefined4 *
FUN_00a9cd40(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6b8);
    if (puVar5 != (undefined4 *)0x0) {
      uVar1 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_1 = *puVar5;
      param_1[1] = uVar1;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar5 + 4);
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_ec = FUN_00888530();
      iStack_e8 = 0;
      uStack_8 = 0;
      cVar4 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_ec,1);
      if (cVar4 != '\0') {
        puVar5 = (undefined4 *)FUN_0088aec0();
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *param_1 = *puVar5;
        param_1[1] = uVar1;
        param_1[2] = uVar2;
        param_1[3] = uVar3;
        *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar5 + 4);
        uStack_8 = 1;
        if (iStack_e8 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_e8 + 8))(auStack_e4);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = (undefined4 *)*param_6;
  if (puVar5 != (undefined4 *)0x0) {
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *param_1 = *puVar5;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar5 + 4);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 21849 ; VA 0x00a9cec0 ; FUN_00a9cec0 */

undefined4 *
FUN_00a9cec0(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uStack_128;
  int iStack_124;
  undefined auStack_120 [260];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6bbb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    FUN_00a73410();
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6f0);
    if (puVar5 != (undefined4 *)0x0) {
      uVar1 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_1 = *puVar5;
      param_1[1] = uVar1;
      param_1[2] = uVar2;
      param_1[3] = uVar3;
      uVar1 = puVar5[5];
      uVar2 = puVar5[6];
      uVar3 = puVar5[7];
      param_1[4] = puVar5[4];
      param_1[5] = uVar1;
      param_1[6] = uVar2;
      param_1[7] = uVar3;
      uVar1 = puVar5[9];
      uVar2 = puVar5[10];
      uVar3 = puVar5[0xb];
      param_1[8] = puVar5[8];
      param_1[9] = uVar1;
      param_1[10] = uVar2;
      param_1[0xb] = uVar3;
      uVar1 = puVar5[0xe];
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(puVar5 + 0xc);
      param_1[0xe] = uVar1;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_128 = FUN_00888530();
      iStack_124 = 0;
      uStack_8 = 0;
      cVar4 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_128,1);
      if (cVar4 != '\0') {
        puVar5 = (undefined4 *)FUN_0088b0e0();
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *param_1 = *puVar5;
        param_1[1] = uVar1;
        param_1[2] = uVar2;
        param_1[3] = uVar3;
        uVar1 = puVar5[5];
        uVar2 = puVar5[6];
        uVar3 = puVar5[7];
        param_1[4] = puVar5[4];
        param_1[5] = uVar1;
        param_1[6] = uVar2;
        param_1[7] = uVar3;
        uVar1 = puVar5[9];
        uVar2 = puVar5[10];
        uVar3 = puVar5[0xb];
        param_1[8] = puVar5[8];
        param_1[9] = uVar1;
        param_1[10] = uVar2;
        param_1[0xb] = uVar3;
        uVar1 = puVar5[0xe];
        *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(puVar5 + 0xc);
        param_1[0xe] = uVar1;
        uStack_8 = 1;
        if (iStack_124 == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_124 + 8))(auStack_120);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_124 != 0) {
        (**(code **)(iStack_124 + 8))(auStack_120);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = (undefined4 *)*param_6;
  if (puVar5 != (undefined4 *)0x0) {
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *param_1 = *puVar5;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    param_1[4] = puVar5[4];
    param_1[5] = uVar1;
    param_1[6] = uVar2;
    param_1[7] = uVar3;
    uVar1 = puVar5[9];
    uVar2 = puVar5[10];
    uVar3 = puVar5[0xb];
    param_1[8] = puVar5[8];
    param_1[9] = uVar1;
    param_1[10] = uVar2;
    param_1[0xb] = uVar3;
    uVar1 = puVar5[0xe];
    *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(puVar5 + 0xc);
    param_1[0xe] = uVar1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 21850 ; VA 0x00a9d0b0 ; FUN_00a9d0b0 */

void FUN_00a9d0b0(void)

{
  int iVar1;
  
  if (DAT_01eeb0cc == 0) {
    iVar1 = FUN_00a93fd0();
    DAT_01eeb0cc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 21851 ; VA 0x00a9d0d0 ; FUN_00a9d0d0 */

undefined4 __fastcall FUN_00a9d0d0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x1d0);
}



/* FUNCTION 21852 ; VA 0x00a9d0e0 ; FUN_00a9d0e0 */

uint FUN_00a9d0e0(uint param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1 != 0) {
    do {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar1 = FUN_00a93fd0();
      uVar3 = 0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        uVar3 = param_1;
      }
      if (uVar3 != 0) {
        iVar2 = FUN_008f78c0(uVar3);
        return -(uint)(iVar2 != 0) & uVar3;
      }
      param_1 = *(uint *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 21853 ; VA 0x00a9d140 ; FUN_00a9d140 */

int FUN_00a9d140(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00a93fd0();
      iVar4 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar4 = param_1;
      }
      if (iVar4 != 0) {
        iVar1 = *(int *)(param_1 + 0xc);
        iVar3 = FUN_008aa870();
        iVar2 = 0;
        if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
            (uint)*(ushort *)(iVar3 + 0x1da)) {
          iVar2 = param_1;
        }
        if (iVar2 == 0) {
          return iVar4;
        }
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 21854 ; VA 0x00a9d1c0 ; FUN_00a9d1c0 */

undefined4 FUN_00a9d1c0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x1b4) != 0)) {
    return *(undefined4 *)(*(int *)(iVar1 + 0x1b4) + 0x6ac);
  }
  return 0;
}



/* FUNCTION 21855 ; VA 0x00a9d1f0 ; FUN_00a9d1f0 */

undefined8 *
FUN_00a9d1f0(undefined8 *param_1,undefined4 param_2,float param_3,float param_4,float param_5,
            float param_6,float param_7,float param_8,int *param_9,undefined8 *param_10,
            undefined4 *param_11,undefined4 param_12,undefined param_13,undefined param_14,
            int param_15,char param_16)

{
  char cVar1;
  bool bVar2;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined uStack_c;
  undefined uStack_b;
  undefined uStack_a;
  undefined4 uStack_8;
  
  bVar2 = DAT_01d69070 != '\0';
  uStack_10 = param_2;
  uStack_c = param_13;
  uStack_a = 0;
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)((int)param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  uStack_8 = 0;
  uStack_b = param_14;
  if ((bVar2) && (param_16 != '\0')) {
    FUN_00ce1fd0();
  }
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  if (param_15 == 0) {
    cVar1 = FUN_00ce2b90(&param_3,&uStack_10,&iStack_30);
  }
  else {
    cVar1 = FUN_00ce2dc0(&param_3,&uStack_10,param_15,&iStack_30);
  }
  if (cVar1 == '\0') {
    *param_9 = 0;
  }
  else {
    *param_9 = iStack_30;
    *param_1 = CONCAT44(uStack_28,uStack_2c);
    *param_10 = CONCAT44(uStack_1c,uStack_20);
    *(undefined4 *)(param_10 + 1) = uStack_18;
    *(undefined4 *)(param_1 + 1) = uStack_24;
    *param_11 = uStack_14;
    if (*param_9 != 0) {
      return param_1;
    }
  }
  *param_1 = CONCAT44(param_4 + param_7,param_3 + param_6);
  *(float *)(param_1 + 1) = param_5 + param_8;
  return param_1;
}



/* FUNCTION 21856 ; VA 0x00a9d322 ; FUN_00a9d322 */

void FUN_00a9d322(void)

{
  FUN_00b659b0();
  return;
}



/* FUNCTION 21857 ; VA 0x00a9d330 ; FUN_00a9d330 */

char FUN_00a9d330(void)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("ExplicitAutoJoints",0x12);
  uStack_8 = 0;
  cVar1 = FUN_00f25cf0(auStack_28,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return (cVar1 != '\0') + '\x01';
}



/* FUNCTION 21858 ; VA 0x00a9d3e0 ; FUN_00a9d3e0 */

undefined4 __fastcall FUN_00a9d3e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x1c8);
}



/* FUNCTION 21859 ; VA 0x00a9d3f0 ; FUN_00a9d3f0 */

undefined4 FUN_00a9d3f0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + 0x1b4);
  }
  return 0;
}



/* FUNCTION 21860 ; VA 0x00a9d410 ; FUN_00a9d410 */

int FUN_00a9d410(int param_1,int *param_2,undefined4 *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined auStack_160 [244];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6bf3;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_1 == 0) ||
     (iVar5 = *(int *)(param_1 + 0xc), ExceptionList = &pvStack_10, iVar4 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    piStack_30 = (int *)0x0;
    puVar7 = &uStack_34;
    iStack_14 = 0;
    uVar6 = 6;
  }
  else {
    iStack_14 = param_1;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_38 = param_2;
    puVar7 = &uStack_3c;
    uVar6 = 5;
  }
  piStack_1c = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  piVar2 = piStack_30;
  iStack_20 = iStack_14;
  if (((uVar6 & 2) != 0) &&
     (uStack_18 = uVar6 & 0xfffffffd, uVar6 = uStack_18, piStack_30 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      uVar6 = uStack_18;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        uVar6 = uStack_18;
      }
    }
  }
  piVar2 = piStack_38;
  if (((uVar6 & 1) != 0) && (piStack_38 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (iStack_14 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Part must be a Part.");
  }
  cVar3 = FUN_00c93d40(param_3);
  if (cVar3 != '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid CFrame. Must contain valid finite values.");
  }
  uStack_6c = *param_3;
  uStack_68 = param_3[1];
  uStack_64 = param_3[2];
  uStack_60 = param_3[3];
  uStack_5c = param_3[4];
  uStack_58 = param_3[5];
  uStack_54 = param_3[6];
  uStack_50 = param_3[7];
  uStack_4c = param_3[8];
  uStack_48 = param_3[9];
  uStack_44 = param_3[10];
  uStack_40 = param_3[0xb];
  FUN_00c94b40(&uStack_6c);
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8._0_1_ = 2;
  FUN_00725d90(0,&iStack_20);
  FUN_00e00da0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00e02770(&uStack_2c,1,param_6,0);
  FUN_00e01e50(auStack_160,&uStack_6c,param_4,param_5,param_6);
  FUN_00e01be0();
  FUN_00e00fa0();
  iVar5 = FUN_00777020();
  piVar2 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar4 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21861 ; VA 0x00a9d670 ; FUN_00a9d670 */

void __thiscall
FUN_00a9d670(undefined4 param_1,int *param_2,int param_3,undefined4 param_4,int *param_5,
            char param_6,undefined4 param_7)

{
  void **ppvVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint uVar10;
  bool bVar11;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined auStack_24 [4];
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_5;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6c20;
  pvStack_10 = ExceptionList;
  puVar7 = (undefined4 *)*param_2;
  puVar9 = (undefined4 *)param_2[1];
  bVar11 = puVar7 == puVar9;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  uStack_14 = param_1;
  if (!bVar11) {
    do {
      FUN_00b061f0(*puVar7,piVar4);
      puVar7 = puVar7 + 2;
    } while (puVar7 != puVar9);
    puVar7 = (undefined4 *)*param_2;
    puVar9 = (undefined4 *)param_2[1];
    bVar11 = puVar7 == puVar9;
    ppvVar1 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar1;
  uVar3 = param_4;
  piVar4 = param_5;
  if (!bVar11) {
    do {
      (**(code **)(*(int *)*puVar7 + 0x58))(uVar3);
      puVar7 = puVar7 + 2;
    } while (puVar7 != puVar9);
    puVar7 = (undefined4 *)*param_2;
    puVar9 = (undefined4 *)param_2[1];
    piVar4 = param_5;
  }
  for (; param_5 = piVar4, puVar7 != puVar9; puVar7 = puVar7 + 2) {
    FUN_008a65e0(uVar3,0);
    piVar4 = param_5;
  }
  if (((char)param_7 != '\0') && (*piVar4 != piVar4[1])) {
    uVar3 = FUN_01675290(DAT_01ee1098);
    uStack_8 = 0;
    param_7 = uVar3;
    if (DAT_01ee05b8 == 0) {
      piVar4 = (int *)FUN_00910e00();
      cStack_18 = '\0';
      iVar6 = *piVar4;
      puStack_1c = (uint *)(iVar6 + 0xac);
      FUN_00587410();
      uStack_8._0_1_ = 2;
      if (DAT_01ee05b8 == 0) {
        FUN_008e21d0(auStack_24);
        uStack_8._0_1_ = 3;
        FUN_008a65e0(iVar6,0);
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_20[1] + -1;
          piStack_20[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar4 = piStack_20 + 2;
            iVar6 = *piVar4;
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
      }
      iVar6 = DAT_01ee05b8;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (cStack_18 != '\0') {
        LOCK();
        uVar8 = *puStack_1c;
        *puStack_1c = *puStack_1c + 0x80000000;
        UNLOCK();
        if (((uVar8 & 0x40000000) == 0) && (-0x80000000 < (int)uVar8)) {
          LOCK();
          uVar8 = *puStack_1c;
          *puStack_1c = *puStack_1c | 0x40000000;
          UNLOCK();
          if ((uVar8 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
          }
        }
      }
      uStack_8 = 5;
    }
    else {
      uStack_8 = 1;
      iVar6 = DAT_01ee05b8;
    }
    FUN_01675290(uVar3);
    piVar4 = param_5;
    uStack_8 = 0xffffffff;
    if (*(char *)(iVar6 + 0xc4) != '\0') {
      FUN_00a9dc70(param_5);
    }
  }
  if (param_3 == 1) {
    param_2 = (int *)0x0;
    FUN_0060e810(0,&param_2,(int)&param_7 + 3);
    uStack_30 = 0;
    iStack_2c = 0;
    uStack_8 = 6;
    iVar6 = FUN_00f28b80(piVar4,&iStack_3c);
    if (iVar6 != 0) {
      uVar8 = 0;
      uVar10 = iStack_38 - iStack_3c >> 2;
      if (uVar10 != 0) {
        do {
          if (*(int *)(iStack_3c + uVar8 * 4) != iStack_2c) break;
          uVar8 = uVar8 + 1;
        } while (uVar8 < uVar10);
      }
LAB_00a9d880:
      piVar4 = param_5;
      if (uVar8 != uVar10) {
        FUN_00a97a80(*(undefined4 *)(iStack_3c + uVar8 * 4),0,&iStack_3c,4);
        do {
          uVar8 = uVar8 + 1;
          if ((uint)(iStack_38 - iStack_3c >> 2) <= uVar8) break;
        } while (*(int *)(iStack_3c + uVar8 * 4) == iStack_2c);
        goto LAB_00a9d880;
      }
    }
    uStack_8 = 0xffffffff;
    if (iStack_3c != 0) {
      uVar8 = iStack_34 - iStack_3c & 0xfffffffc;
      iVar6 = iStack_3c;
      if (0xfff < uVar8) {
        iVar6 = *(int *)(iStack_3c + -4);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (iStack_3c - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar8);
      iStack_3c = 0;
      iStack_38 = 0;
      iStack_34 = 0;
    }
  }
  if (((param_6 != '\0') && (iVar6 = FUN_008f7870(uStack_14), iVar6 != 0)) &&
     (cVar2 = FUN_008ff0a0(), cVar2 != '\0')) {
    FUN_00f284f0(piVar4,4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21862 ; VA 0x00a9d950 ; FUN_00a9d950 */

undefined FUN_00a9d950(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12
                      ,undefined8 param_13,undefined4 param_14,undefined4 param_15,int *param_16)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piStack_1c;
  int *piStack_18;
  bool bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6c40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_16 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_16[1] = param_16[1] + 1;
    UNLOCK();
  }
  FUN_00a9c4c0(&piStack_1c,param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
               param_10,param_11,param_12,param_13,param_14,param_15,param_16,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*piStack_1c == piStack_1c[1]) {
    cVar3 = FUN_00cea140(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                         param_10,param_11,param_12,param_13,param_14);
    bStack_11 = cVar3 == '\0';
  }
  else {
    bStack_11 = false;
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_16 != (int *)0x0) {
    LOCK();
    iVar2 = param_16[1] + -1;
    param_16[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_16)();
      LOCK();
      piVar1 = param_16 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_16 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return bStack_11;
}



/* FUNCTION 21863 ; VA 0x00a9daa0 ; FUN_00a9daa0 */

undefined FUN_00a9daa0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12
                      ,undefined8 param_13,undefined4 param_14,int param_15,int *param_16)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_24;
  int *piStack_20;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6c60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0088dc10(&iStack_24);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (param_15 != 0) {
    piVar2 = *(int **)(iStack_24 + 4);
    if (*(int **)(iStack_24 + 8) == piVar2) {
      FUN_005c1970(piVar2,&param_15);
    }
    else {
      *piVar2 = 0;
      piVar2[1] = 0;
      if (param_16 != (int *)0x0) {
        LOCK();
        param_16[1] = param_16[1] + 1;
        UNLOCK();
      }
      *piVar2 = param_15;
      piVar2[1] = (int)param_16;
      *(int *)(iStack_24 + 4) = *(int *)(iStack_24 + 4) + 8;
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  uStack_11 = FUN_00a9d950(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                           param_10,param_11,param_12,param_13,param_14,iStack_24,piStack_20);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar3 = piStack_20[2] + -1;
      piStack_20[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piVar2 = param_16;
  if (param_16 != (int *)0x0) {
    LOCK();
    iVar3 = param_16[1] + -1;
    param_16[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_16)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
      ExceptionList = pvStack_10;
      return uStack_11;
    }
  }
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 21864 ; VA 0x00a9dbf0 ; FUN_00a9dbf0 */

void FUN_00a9dbf0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a9e750();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21865 ; VA 0x00a9dc30 ; FUN_00a9dc30 */

void FUN_00a9dc30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00a9e800();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21866 ; VA 0x00a9dc70 ; FUN_00a9dc70 */

uint __thiscall FUN_00a9dc70(int param_1,uint *param_2)

{
  float *pfVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  float *pfVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6c90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  iVar5 = (**(code **)(*(int *)(param_1 + 0x144) + 4))();
  uStack_54 = *(undefined8 *)(iVar5 + 0xc0);
  fStack_4c = *(float *)(iVar5 + 200);
  FUN_00eb65e0(auStack_3c);
  uStack_8 = 0;
  uVar6 = FUN_008f7870(param_1);
  uStack_18 = FUN_00eb6280(uVar6);
  uStack_8 = 0xffffffff;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_38[1] + -1;
    piStack_38[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar5 = piStack_38[2] + -1;
      piStack_38[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if ((uStack_18 == 0) || (cStack_11 = '\x01', *(char *)(uStack_18 + 0x75) == '\0')) {
    cStack_11 = '\0';
  }
  uVar8 = *param_2;
  if (uVar8 != param_2[1]) {
    FUN_00a9c660(&fStack_90,param_2);
    pfVar7 = (float *)FUN_006e0af0();
    if (((((NAN(fStack_90) || NAN(*pfVar7)) != (fStack_90 == *pfVar7)) &&
         ((NAN(fStack_8c) || NAN(pfVar7[1])) != (fStack_8c == pfVar7[1]))) &&
        ((NAN(fStack_88) || NAN(pfVar7[2])) != (fStack_88 == pfVar7[2]))) &&
       (((NAN(fStack_84) || NAN(pfVar7[3])) != (fStack_84 == pfVar7[3]) &&
        ((NAN(fStack_80) || NAN(pfVar7[4])) != (fStack_80 == pfVar7[4]))))) {
      pfVar1 = pfVar7 + 5;
      if ((NAN(fStack_7c) || NAN(*pfVar1)) != (fStack_7c == *pfVar1)) {
        ExceptionList = pvStack_10;
        return (uint)CONCAT11((fStack_7c == *pfVar1) << 6 | (NAN(fStack_7c) || NAN(*pfVar1)) << 2 |
                              2U | fStack_7c < *pfVar1,(char)pfVar7);
      }
    }
    piVar10 = (int *)0x0;
    piStack_48 = (int *)0x0;
    piStack_44 = (int *)0x0;
    piStack_40 = (int *)0x0;
    uStack_1c = *param_2;
    uStack_8._1_3_ = 0;
    uVar8 = (int)(param_2[1] - uStack_1c) >> 3;
    uStack_18 = 0;
    if (uVar8 != 0) {
      do {
        iVar5 = *(int *)(uStack_1c + 4 + uStack_18 * 8);
        iStack_2c = 0;
        piStack_28 = (int *)0x0;
        if (iVar5 != 0) {
          piVar2 = (int *)(iVar5 + 4);
          iVar5 = *(int *)(iVar5 + 4);
          while (piVar10 = piStack_44, iVar5 != 0) {
            LOCK();
            iVar9 = *piVar2;
            if (iVar5 == iVar9) {
              *piVar2 = iVar5 + 1;
              iVar9 = iVar5;
            }
            UNLOCK();
            if (iVar9 == iVar5) {
              iStack_2c = *(int *)(uStack_1c + uStack_18 * 8);
              piStack_28 = *(int **)(uStack_1c + 4 + uStack_18 * 8);
              break;
            }
            iVar5 = *piVar2;
          }
        }
        piVar2 = piStack_28;
        uStack_8._0_1_ = 2;
        if (iStack_2c != 0) {
          iStack_20 = iStack_2c;
          if (piStack_40 == piVar10) {
            FUN_0063d9b0(piVar10,&iStack_20);
            piVar10 = piStack_44;
          }
          else {
            *piVar10 = iStack_2c;
            piStack_44 = piVar10 + 1;
            piVar10 = piStack_44;
          }
        }
        uStack_8._0_1_ = 1;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar5 = piVar2[1] + -1;
          piVar2[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar5 = piVar2[2] + -1;
            piVar2[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_18 = uStack_18 + 1;
        uStack_1c = *param_2;
        uVar8 = (int)(param_2[1] - uStack_1c) >> 3;
      } while (uStack_18 < uVar8);
      if ((piStack_48 != piVar10) && (cStack_11 == '\0')) {
        uVar8 = FUN_00587490(&iStack_34);
        uStack_8._0_1_ = 3;
        if (iStack_34 != 0) {
          pfVar7 = (float *)FUN_00b077e0();
          uStack_60 = 0;
          fVar13 = (fStack_80 + fStack_8c) * DAT_018ce2f4;
          uStack_5c = 0;
          fVar12 = (fStack_84 + fStack_90) * DAT_018ce2f4;
          uStack_58 = 0;
          fVar11 = (fStack_7c + fStack_88) * DAT_018ce2f4;
          fStack_6c = (float)uStack_54 -
                      (fVar13 * pfVar7[1] + fVar12 * *pfVar7 + fVar11 * pfVar7[2] + pfVar7[9]);
          fStack_68 = uStack_54._4_4_ -
                      (fVar13 * pfVar7[4] + fVar12 * pfVar7[3] + fVar11 * pfVar7[5] + pfVar7[10]);
          fStack_64 = fStack_4c -
                      (fVar13 * pfVar7[7] + fVar12 * pfVar7[6] + fVar11 * pfVar7[8] + pfVar7[0xb]);
          FUN_00f298c0(&uStack_78,&fStack_6c,&uStack_60);
          uVar8 = FUN_00a9e0a0(param_2,uStack_78,uStack_70,1,0);
        }
        if (piStack_30 != (int *)0x0) {
          LOCK();
          puVar3 = (uint *)(piStack_30 + 1);
          uVar4 = *puVar3;
          uVar8 = *puVar3;
          *puVar3 = uVar4 - 1;
          UNLOCK();
          if (uVar4 - 1 == 0) {
            uVar8 = (**(code **)*piStack_30)();
            LOCK();
            piVar10 = piStack_30 + 2;
            iVar5 = *piVar10;
            *piVar10 = *piVar10 + -1;
            UNLOCK();
            if (iVar5 == 1) {
              uVar8 = (**(code **)(*piStack_30 + 4))();
            }
          }
        }
      }
      if (piStack_48 != (int *)0x0) {
        uVar8 = (int)piStack_40 - (int)piStack_48 & 0xfffffffc;
        piVar10 = piStack_48;
        if (0xfff < uVar8) {
          piVar10 = (int *)piStack_48[-1];
          uVar8 = uVar8 + 0x23;
          if (0x1f < (uint)((int)piStack_48 + (-4 - (int)piVar10))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        uVar8 = FUN_01674ea0(piVar10,uVar8);
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 21867 ; VA 0x00a9e0a0 ; FUN_00a9e0a0 */

void __thiscall
FUN_00a9e0a0(undefined4 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4,int param_5
            ,undefined4 param_6)

{
  undefined auStack_28 [12];
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6cab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00fe14b0(0,param_2,param_1,1);
  uStack_8 = 0;
  uStack_1c = param_3;
  uStack_14 = param_4;
  FUN_00fe1950(0,0);
  if (param_5 == 0) {
    FUN_00fe1920(auStack_28,&uStack_1c);
  }
  else {
    FUN_00fe17d0(auStack_28,&uStack_1c,1);
  }
  FUN_00fe15e0(param_6);
  FUN_00fe15a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21868 ; VA 0x00a9e150 ; FUN_00a9e150 */

void __thiscall
FUN_00a9e150(undefined4 param_1,int *param_2,float param_3,float param_4,float param_5,
            undefined4 param_6)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_64 [48];
  undefined auStack_34 [8];
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6cd3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0089eb50(param_2);
  if (cVar2 != '\0') {
    iVar3 = (**(code **)(*piVar1 + 0xa8))();
    if (iVar3 != 0) {
      uStack_1c = 0;
      uStack_18 = 0;
      uStack_14 = 0;
      uStack_8 = 0;
      FUN_0063d9b0(0,&param_2);
      piVar1 = param_2;
      iVar3 = (*(code *)**(undefined4 **)((int)param_2 + *(int *)(param_2[0x15] + 4) + 0x54))
                        (auStack_64);
      fStack_24 = param_3 - *(float *)(iVar3 + 0x24);
      fStack_20 = 0.0;
      param_2 = (int *)(param_4 - *(float *)(iVar3 + 0x28));
      fStack_2c = param_5 - *(float *)(iVar3 + 0x2c);
      puVar5 = &uStack_1c;
      uVar6 = param_6;
      uVar4 = (**(code **)(*piVar1 + 0xa8))(puVar5,param_1,param_6);
      FUN_00fe13a0(uVar4,puVar5,param_1,uVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      fStack_28 = fStack_24;
      fStack_24 = (float)param_2;
      fStack_20 = fStack_2c;
      FUN_00fe1950(0,0);
      FUN_00fe17d0(auStack_34,&fStack_28,1);
      FUN_00fe15e0(0);
      FUN_00fe15a0();
      FUN_0056d320();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21869 ; VA 0x00a9e590 ; FUN_00a9e590 */

void __fastcall FUN_00a9e590(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined auStack_78 [48];
  undefined auStack_48 [48];
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  uint uStack_8;
  
  iVar3 = *(int *)(param_1 + 0x1d8);
  piVar1 = (int *)(param_1 + 0x1d8);
  iVar5 = *(int *)(param_1 + 0x1dc);
  uStack_8 = 0;
  iStack_18 = param_1;
  if (iVar5 - iVar3 >> 3 != 0) {
    do {
      uVar4 = uStack_8;
      iStack_14 = uStack_8 * 8;
      if (*(int *)(iStack_14 + iVar3) != 0) {
        iStack_c = FUN_00b4c020();
        iStack_10 = FUN_00b4c070();
        if ((iStack_c != 0) && (iStack_10 != 0)) {
          FUN_00b077e0();
          FUN_0071fcc0(auStack_48);
          uVar2 = FUN_00b077e0();
          uVar2 = FUN_0071f260(auStack_78,uVar2);
          FUN_00b4c660(uVar2);
          FUN_00b4c8e0(*(byte *)(*(int *)(iStack_14 + *piVar1) + 0x74) >> 2 & 1);
          uVar4 = uStack_8;
        }
      }
      iVar5 = *(int *)(param_1 + 0x1dc);
      uStack_8 = uVar4 + 1;
      iVar3 = *piVar1;
    } while (uStack_8 < (uint)(iVar5 - iVar3 >> 3));
  }
  FUN_005596d0(iVar3,iVar5,piVar1);
  *(int *)(param_1 + 0x1dc) = *piVar1;
  if (*(int *)(iStack_18 + 0x1b4) != 0) {
    *(undefined *)(*(int *)(iStack_18 + 0x1b4) + 0x40) = 0;
  }
  return;
}



/* FUNCTION 21870 ; VA 0x00a9e690 ; FUN_00a9e690 */

void __thiscall FUN_00a9e690(int *param_1,uint param_2)

{
  if ((uint)((param_1[2] - *param_1) / 0xd0) < param_2) {
    if (0x13b13b1 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00a974c0(param_2);
  }
  return;
}



/* FUNCTION 21871 ; VA 0x00a9e6d0 ; FUN_00a9e6d0 */

void __thiscall FUN_00a9e6d0(int param_1,undefined param_2)

{
  if (*(int *)(param_1 + 0x1b4) != 0) {
    *(undefined *)(*(int *)(param_1 + 0x1b4) + 0x40) = param_2;
  }
  return;
}



/* FUNCTION 21872 ; VA 0x00a9e6f0 ; FUN_00a9e6f0 */

void __thiscall FUN_00a9e6f0(int param_1,undefined8 *param_2,char param_3)

{
  undefined auStack_1c [12];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(char *)(param_1 + 0x188) = param_3;
  if (param_3 == '\0') {
    uStack_10 = 0;
    uStack_c = 0;
    uStack_8 = 0;
    param_2 = (undefined8 *)FUN_00f298c0(auStack_1c,param_2,&uStack_10);
  }
  *(undefined8 *)(param_1 + 0x17c) = *param_2;
  *(undefined4 *)(param_1 + 0x184) = *(undefined4 *)(param_2 + 1);
  return;
}



/* FUNCTION 21873 ; VA 0x00a9e750 ; FUN_00a9e750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a9e750(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb134) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb134);
    if (DAT_01eeb134 == -1) {
      uStack_8 = 0;
      FUN_009ca470("BulkMoveMode");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb0d0 = RBX::Reflection::EnumDesc<enum_RBX::BulkMoveMode>::vftable;
      FUN_009caf20(&DAT_01d66538,2);
      FUN_016f3654(&LAB_0188ae40);
      FUN_016f37bf(&DAT_01eeb134);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb0d0;
}



/* FUNCTION 21874 ; VA 0x00a9e800 ; FUN_00a9e800 */

undefined * FUN_00a9e800(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb19c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb19c);
    if (DAT_01eeb19c == -1) {
      uStack_8 = 0;
      FUN_00e00d40();
      FUN_016f3654(&LAB_0188ae60);
      FUN_016f37bf(&DAT_01eeb19c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb138;
}



/* FUNCTION 21875 ; VA 0x00a9e890 ; FUN_00a9e890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a9e890(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1e8) {
    FUN_016f3809(&DAT_01eeb1e8);
    if (DAT_01eeb1e8 == -1) {
      _DAT_01eeb1dc = FUN_005c65e0;
      _DAT_01eeb1e0 = FUN_005c65e0;
      _DAT_01eeb1e4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeb1e8);
    }
  }
  return &DAT_01eeb1dc;
}



/* FUNCTION 21876 ; VA 0x00a9e900 ; FUN_00a9e900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a9e900(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1d8) {
    FUN_016f3809(&DAT_01eeb1d8);
    if (DAT_01eeb1d8 == -1) {
      _DAT_01eeb1cc = FUN_005c65e0;
      _DAT_01eeb1d0 = FUN_005c65e0;
      _DAT_01eeb1d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeb1d8);
    }
  }
  return &DAT_01eeb1cc;
}



/* FUNCTION 21877 ; VA 0x00a9e970 ; FUN_00a9e970 */

int * FUN_00a9e970(int *param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,
                  char *param_6)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  bool bVar8;
  float10 fVar9;
  float fVar10;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  int iStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  float fStack_1c;
  int iStack_18;
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_28 = FUN_00c157b0();
  piStack_2c = (int *)FUN_00c157b0();
  iVar7 = 0;
  do {
    iVar6 = iVar7 % 3;
    fVar10 = (float)((iVar7 / 3) * -2 + 1);
    uStack_44 = (uint)(*(float *)(iStack_28 + iVar6 * 4) * fVar10) ^ DAT_018c4ea0;
    uStack_40 = (uint)(*(float *)(iStack_28 + 0xc + iVar6 * 4) * fVar10) ^ DAT_018c4ea0;
    uStack_3c = (uint)(*(float *)(iStack_28 + 0x18 + iVar6 * 4) * fVar10) ^ DAT_018c4ea0;
    piStack_20 = (int *)FUN_00c935d0(&uStack_44,piStack_2c);
    cStack_13 = *(char *)(param_2 + 0x22f + iVar7);
    iStack_18 = 0;
    cStack_12 = *(char *)(param_3 + 0x22f + (int)piStack_20);
    cStack_11 = '\0';
    cVar2 = FUN_00fe20e0(param_2,param_3,iVar7,piStack_20,param_4,param_5,&iStack_18,&cStack_11);
    if (cVar2 != '\0') {
      if (iStack_18 == 6) {
        *param_6 = cStack_11;
        piVar5 = (int *)FUN_00a94d20(auStack_30);
        goto LAB_00a9ed0b;
      }
      fStack_1c = (float)param_2;
      if (cStack_11 != '\0') {
        fStack_1c = (float)param_3;
      }
      uStack_50 = 0;
      uStack_4c = 0;
      uStack_48 = 0;
      uVar3 = FUN_00c157b0();
      uVar4 = FUN_00c157b0();
      fVar9 = (float10)FUN_00ccde40(uVar4,uVar3,param_4,param_5,&uStack_50);
      fStack_1c = (float)fVar9;
      iStack_38 = 0;
      iStack_34 = 0;
      uStack_8 = 0;
      if (iStack_18 == 8) {
        piVar5 = (int *)FUN_00a94de0(auStack_24);
LAB_00a9ebcf:
        piVar1 = piStack_20;
        iStack_38 = *piVar5;
        iStack_34 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        piStack_2c = (int *)iStack_38;
        iStack_28 = iStack_34;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_20[1] + -1;
          piStack_20[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            piVar5 = piVar1 + 2;
            iVar7 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar7 == 1) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        piVar5 = piStack_2c;
        FUN_00c3ce90(fStack_1c);
        *param_6 = cStack_11;
        *param_1 = (int)piVar5;
        param_1[1] = iStack_28;
        ExceptionList = pvStack_10;
        return param_1;
      }
      if (iStack_18 == 7) {
        piVar5 = (int *)FUN_00a94ea0(auStack_24);
        goto LAB_00a9ebcf;
      }
      uStack_8 = 0xffffffff;
    }
    if ((cStack_13 == '\x02') || (cStack_12 == '\x02')) {
      cVar2 = '\x01';
    }
    else {
      cVar2 = '\0';
    }
    if (cStack_13 == '\x03') {
      bVar8 = cStack_12 == '\x04';
LAB_00a9eb29:
      if (bVar8) goto LAB_00a9eb34;
LAB_00a9eb2b:
      if (cStack_13 == '\x03') {
LAB_00a9eb30:
        if (cStack_12 == '\x05') goto LAB_00a9eb34;
      }
      bVar8 = false;
    }
    else {
      if (cStack_13 == '\x04') {
        if (cStack_12 != '\x03') goto LAB_00a9eb30;
      }
      else {
        if (cStack_13 != '\x05') goto LAB_00a9eb2b;
        if ((cStack_12 != '\x05') && (cStack_12 != '\x04')) {
          bVar8 = cStack_12 == '\x03';
          goto LAB_00a9eb29;
        }
      }
LAB_00a9eb34:
      bVar8 = true;
    }
    cStack_12 = cVar2;
    if (((cVar2 != '\0') || (bVar8)) &&
       (cVar2 = FUN_00fe2840(param_2,param_3,iVar7,piStack_20,param_4,param_5), cVar2 != '\0')) {
      if (cStack_12 == '\0') {
        piVar5 = (int *)FUN_00a94f60(auStack_30);
      }
      else {
        piVar5 = (int *)FUN_00a950e0();
      }
LAB_00a9ed0b:
      piVar1 = piStack_2c;
      *param_1 = *piVar5;
      *piVar5 = 0;
      param_1[1] = piVar5[1];
      piVar5[1] = 0;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar7 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar5 = piVar1 + 2;
          iVar7 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar7 == 1) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_78 = 0;
    uStack_74 = 0;
    uStack_70 = 0;
    uStack_6c = 0;
    uStack_68 = 0;
    uStack_64 = 0;
    uStack_60 = 0;
    uStack_5c = 0;
    uStack_58 = 0;
    uStack_54 = 0;
    cVar2 = FUN_00fe1b10(param_2,param_3,iVar7,piStack_20,param_4,param_5,&uStack_80);
    if (cVar2 != '\0') {
      FUN_00a94c60(&iStack_38);
      uStack_8 = 1;
      if (DAT_01efa9e0 == '\0') {
        iVar7 = (*(code *)**(undefined4 **)(iStack_38 + 0x70))();
        *(undefined4 *)(iVar7 + 0xa8) = uStack_80;
        *(undefined4 *)(iVar7 + 0xac) = uStack_7c;
        *(undefined4 *)(iVar7 + 0xb0) = uStack_78;
        *(undefined4 *)(iVar7 + 0xb4) = uStack_74;
        *(undefined4 *)(iVar7 + 0xb8) = uStack_70;
        *(undefined4 *)(iVar7 + 0xbc) = uStack_6c;
        *(undefined4 *)(iVar7 + 0xc0) = uStack_68;
        *(undefined4 *)(iVar7 + 0xc4) = uStack_64;
        *(undefined4 *)(iVar7 + 200) = uStack_60;
        *(undefined4 *)(iVar7 + 0xcc) = uStack_5c;
        *(undefined4 *)(iVar7 + 0xd0) = uStack_58;
        *(undefined4 *)(iVar7 + 0xd4) = uStack_54;
        *param_1 = iStack_38;
        param_1[1] = iStack_34;
        ExceptionList = pvStack_10;
        return param_1;
      }
      FUN_00c3d490(&uStack_80);
      *param_1 = iStack_38;
      param_1[1] = iStack_34;
      ExceptionList = pvStack_10;
      return param_1;
    }
    iVar7 = iVar7 + 1;
    if (5 < iVar7) {
      *param_1 = 0;
      param_1[1] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 21878 ; VA 0x00a9ed70 ; FUN_00a9ed70 */

undefined4 *
FUN_00a9ed70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,char *param_6)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  float10 fVar9;
  float fVar10;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  float fStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6d68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_20 = FUN_00c157b0();
  uStack_24 = FUN_00c157b0();
  iVar8 = 0;
  do {
    iVar7 = iVar8 % 3;
    fVar10 = (float)((iVar8 / 3) * -2 + 1);
    uStack_40 = (uint)(*(float *)(iStack_20 + iVar7 * 4) * fVar10) ^ DAT_018c4ea0;
    uStack_3c = (uint)(fVar10 * *(float *)(iStack_20 + 0xc + iVar7 * 4)) ^ DAT_018c4ea0;
    uStack_38 = (uint)(fVar10 * *(float *)(iStack_20 + 0x18 + iVar7 * 4)) ^ DAT_018c4ea0;
    uVar4 = FUN_00c935d0(&uStack_40,uStack_24);
    iStack_18 = 0;
    cStack_11 = '\0';
    cVar3 = FUN_00fe20e0(param_2,param_3,iVar8,uVar4,param_4,param_5,&iStack_18,&cStack_11);
    if (cVar3 != '\0') {
      if (iStack_18 == 6) {
        *param_6 = cStack_11;
        puVar6 = (undefined4 *)FUN_00a94d20(&uStack_2c);
        piVar1 = piStack_28;
        *param_1 = *puVar6;
        param_1[1] = puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_28[1] + -1;
          piStack_28[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            piVar2 = piVar1 + 2;
            iVar8 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return param_1;
      }
      fStack_1c = (float)param_2;
      if (cStack_11 != '\0') {
        fStack_1c = (float)param_3;
      }
      uStack_4c = 0;
      uStack_48 = 0;
      uStack_44 = 0;
      uVar4 = FUN_00c157b0();
      uVar5 = FUN_00c157b0();
      fVar9 = (float10)FUN_00ccde40(uVar5,uVar4,param_4,param_5,&uStack_4c);
      fStack_1c = (float)fVar9;
      uStack_2c = 0;
      piStack_28 = (int *)0x0;
      uStack_8 = 0;
      if (iStack_18 == 8) {
        puVar6 = (undefined4 *)FUN_00a94de0(auStack_34);
LAB_00a9ef05:
        uStack_2c = *puVar6;
        piStack_28 = (int *)puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        uStack_24 = uStack_2c;
        iStack_20 = (int)piStack_28;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_30[1] + -1;
          piStack_30[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            piVar1 = piStack_30 + 2;
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piStack_30 + 4))();
            }
          }
        }
        uVar4 = uStack_24;
        FUN_00c3ce90(fStack_1c);
        *param_6 = cStack_11;
        *param_1 = uVar4;
        param_1[1] = iStack_20;
        ExceptionList = pvStack_10;
        return param_1;
      }
      if (iStack_18 == 7) {
        puVar6 = (undefined4 *)FUN_00a94ea0(auStack_34);
        goto LAB_00a9ef05;
      }
      uStack_8 = 0xffffffff;
    }
    iVar8 = iVar8 + 1;
    if (5 < iVar8) {
      *param_1 = 0;
      param_1[1] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 21879 ; VA 0x00a9eff0 ; FUN_00a9eff0 */

undefined4 *
FUN_00a9eff0(undefined4 *param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  float fVar8;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  undefined auStack_10 [4];
  int *piStack_c;
  undefined4 uStack_8;
  
  piVar3 = (int *)FUN_00c157b0();
  piStack_c = piVar3;
  uStack_8 = FUN_00c157b0();
  iVar7 = 0;
  do {
    iVar6 = iVar7 % 3;
    fVar8 = (float)((iVar7 / 3) * -2 + 1);
    uStack_1c = (uint)((float)piVar3[iVar6] * fVar8) ^ DAT_018c4ea0;
    uStack_18 = (uint)((float)piVar3[iVar6 + 3] * fVar8) ^ DAT_018c4ea0;
    uStack_14 = (uint)((float)piVar3[iVar6 + 6] * fVar8) ^ DAT_018c4ea0;
    iVar6 = FUN_00c935d0(&uStack_1c,uStack_8);
    iVar4 = (**(code **)(**(int **)(param_2 + 0x1ac) + 8))();
    if (((iVar4 != 2) || (iVar7 == 0)) || (iVar7 == 3)) {
      iVar4 = (**(code **)(**(int **)(param_3 + 0x1ac) + 8))();
      if (((iVar4 != 2) || (iVar6 == 0)) || (iVar6 == 3)) {
        cVar2 = FUN_00fe2840(param_2,param_3,iVar7,iVar6,param_4,param_5);
        if (cVar2 != '\0') {
          puVar5 = (undefined4 *)FUN_00a950e0(auStack_10);
          piVar3 = piStack_c;
          *param_1 = *puVar5;
          param_1[1] = puVar5[1];
          *puVar5 = 0;
          puVar5[1] = 0;
          if (piStack_c != (int *)0x0) {
            LOCK();
            iVar7 = piStack_c[1] + -1;
            piStack_c[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_c)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar7 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar7 == 1) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          return param_1;
        }
      }
    }
    iVar7 = iVar7 + 1;
    piVar3 = piStack_c;
  } while (iVar7 < 6);
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 21880 ; VA 0x00a9f170 ; FUN_00a9f170 */

undefined4 * __thiscall
FUN_00a9f170(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00a9f8f0(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 21881 ; VA 0x00a9f270 ; FUN_00a9f270 */

undefined4 * __thiscall
FUN_00a9f270(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_019474e4;
  cVar3 = FUN_00a9fa00(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 21882 ; VA 0x00a9f360 ; FUN_00a9f360 */

undefined4 * __thiscall FUN_00a9f360(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_0000004c;
  undefined4 auStack_158 [23];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  undefined4 *puStack_f0;
  undefined auStack_dc [64];
  uint uStack_9c;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  undefined auStack_74 [64];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6d9b;
  pvStack_10 = ExceptionList;
  puStack_f0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_f4 = (undefined *)0xa9f3a4;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00aa0560();
  uStack_7c = param_2;
  puStack_f0 = (undefined4 *)auStack_dc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_f4 = (undefined *)0xa9f3c6;
  FUN_00aa0560();
  puStack_f0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_158;
  auStack_158[0] = uStack_7c;
  FUN_00aa0560(auStack_74);
  ppuVar2 = &PTR_FUN_019474cc;
  cVar1 = FUN_00a9fb20();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = auStack_2c;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0xa9f41d;
      puStack_f4 = puStack_f8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_f0 = (undefined4 *)0xa9f42f;
  FUN_00aa1290();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_9c != 0) {
    if (((uStack_9c & 1) == 0) && (*(code **)(uStack_9c & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = auStack_94;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0xa9f456;
      puStack_f4 = puStack_f8;
      (**(code **)(uStack_9c & 0xfffffffe))();
    }
    uStack_9c = 0;
  }
  puStack_f0 = (undefined4 *)0xa9f46e;
  FUN_00aa1290();
  uStack_8 = 5;
  if (in_stack_0000004c != 0) {
    if (((in_stack_0000004c & 1) == 0) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = &stack0x00000054;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0xa9f492;
      puStack_f4 = puStack_f8;
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
    }
    in_stack_0000004c = 0;
  }
  puStack_f0 = (undefined4 *)0xa9f4a4;
  FUN_00aa1290();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21883 ; VA 0x00a9f4c0 ; FUN_00a9f4c0 */

void __thiscall
FUN_00a9f4c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  code *pcVar1;
  uint *puVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6dc8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_3c;
  pcVar1 = (code *)*param_1;
  uStack_8 = 1;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_3c;
  if (param_13 != 0) {
    auStack_3c[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_15;
      uStack_4c = 0xa9f52d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar2 = param_2;
    }
    else {
      uStack_34 = param_15;
      uStack_30 = param_16;
      uStack_2c = param_17;
      uStack_28 = param_18;
      uStack_24 = param_19;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_3c;
    }
  }
  param_2 = puVar2;
  uStack_8._0_1_ = 2;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_54,0);
    }
    else {
      uStack_54 = param_8;
      uStack_50 = param_9;
      uStack_4c = param_10;
      puStack_48 = param_11;
      uStack_44 = param_12;
    }
  }
  uStack_8._0_1_ = 1;
  (*pcVar1)(param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  uStack_8 = 4;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_13 & 0xfffffffe))(&param_15,&param_15,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21884 ; VA 0x00a9f5f0 ; FUN_00a9f5f0 */

void __thiscall
FUN_00a9f5f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  code *pcVar1;
  uint *puVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6df8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_3c;
  pcVar1 = (code *)*param_1;
  uStack_8 = 1;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_3c;
  if (param_13 != 0) {
    auStack_3c[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_15;
      uStack_4c = 0xa9f65d;
      ExceptionList = &pvStack_10;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar2 = param_2;
    }
    else {
      uStack_34 = param_15;
      uStack_30 = param_16;
      uStack_2c = param_17;
      uStack_28 = param_18;
      uStack_24 = param_19;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_3c;
    }
  }
  param_2 = puVar2;
  uStack_8._0_1_ = 2;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_54,0);
    }
    else {
      uStack_54 = param_8;
      uStack_50 = param_9;
      uStack_4c = param_10;
      puStack_48 = param_11;
      uStack_44 = param_12;
    }
  }
  uStack_8._0_1_ = 1;
  (*pcVar1)(param_3,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_6 & 0xfffffffe))(&param_8,&param_8,2);
  }
  uStack_8 = 4;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_13 & 0xfffffffe))(&param_15,&param_15,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21885 ; VA 0x00a9f720 ; FUN_00a9f720 */

int __thiscall FUN_00a9f720(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  
  uVar3 = *param_1;
  iVar9 = (int)((int)param_2 - uVar3) >> 2;
  iVar2 = (int)(param_1[1] - uVar3) >> 2;
  if (iVar2 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar5 = (int)(param_1[2] - uVar3) >> 2;
  uVar3 = uVar1;
  if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar3 = (uVar5 >> 1) + uVar5, uVar3 < uVar1)) {
    uVar3 = uVar1;
  }
  uVar5 = uVar3 * 4;
  if (uVar3 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00a9f78f;
    if (uVar5 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00a9f78f:
    uVar4 = uVar5 + 0x23;
    if (uVar4 <= uVar5) {
      uVar4 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar4);
    if (iVar2 == 0) goto LAB_00a9f8e4;
    puVar10 = (undefined4 *)(iVar2 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar2;
  }
  uVar5 = 0;
  puVar10[iVar9] = *param_3;
  param_3 = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  if (param_2 == param_3) {
    uVar4 = (uint)((int)param_3 + (3 - (int)puVar6)) >> 2;
    if (param_3 < puVar6) {
      uVar4 = 0;
    }
    puVar8 = puVar10;
    if (uVar4 != 0) {
      do {
        uVar5 = uVar5 + 1;
        *puVar8 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar8 = puVar8 + 1;
      } while (uVar5 != uVar4);
    }
  }
  else {
    uVar4 = (uint)((int)param_2 + (3 - (int)puVar6)) >> 2;
    if (param_2 < puVar6) {
      uVar4 = 0;
    }
    puVar8 = puVar10;
    if (uVar4 != 0) {
      do {
        uVar5 = uVar5 + 1;
        *puVar8 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar8 = puVar8 + 1;
      } while (uVar5 != uVar4);
      param_3 = (undefined4 *)param_1[1];
    }
    uVar5 = 0;
    uVar4 = (param_1[1] - (int)param_2) + 3 >> 2;
    if (param_3 < param_2) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      puVar6 = puVar10 + iVar9 + 1;
      do {
        uVar5 = uVar5 + 1;
        *puVar6 = *(undefined4 *)((int)puVar6 + ((int)param_2 - (int)(puVar10 + iVar9 + 1)));
        puVar6 = puVar6 + 1;
      } while (uVar5 != uVar4);
    }
  }
  uVar5 = *param_1;
  if (uVar5 != 0) {
    uVar7 = param_1[2] - uVar5 & 0xfffffffc;
    uVar4 = uVar5;
    if (0xfff < uVar7) {
      uVar4 = *(uint *)(uVar5 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar5 - uVar4) - 4) {
LAB_00a9f8e4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar7);
  }
  *param_1 = (uint)puVar10;
  param_1[1] = (uint)(puVar10 + uVar1);
  param_1[2] = (uint)(puVar10 + uVar3);
  return *param_1 + iVar9 * 4;
}



/* FUNCTION 21886 ; VA 0x00a9f8f0 ; FUN_00a9f8f0 */

undefined ** __thiscall
FUN_00a9f8f0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019474dc;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 21887 ; VA 0x00a9fa00 ; FUN_00a9fa00 */

undefined FUN_00a9fa00(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_10 = param_1;
  piStack_c = param_2;
  uStack_8 = param_3;
  cVar4 = FUN_00585a40(&uStack_10);
  piVar2 = piStack_c;
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    *param_4 = 0;
    param_4[1] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    *param_4 = uStack_10;
    param_4[1] = piStack_c;
    param_4[2] = uStack_8;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 21888 ; VA 0x00a9fb20 ; FUN_00a9fb20 */

undefined FUN_00a9fb20(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_0000004c;
  int *in_stack_0000006c;
  undefined auStack_dc [64];
  uint uStack_9c;
  undefined auStack_94 [24];
  undefined4 auStack_7c [2];
  undefined auStack_74 [64];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6e3a;
  pvStack_10 = ExceptionList;
  auStack_7c[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00aa0560(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_7c);
  uVar1 = auStack_7c[0];
  if (cVar2 == '\0') {
    FUN_00aa0560(auStack_74);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x68);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00aa0560(auStack_dc);
    }
    *in_stack_0000006c = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_9c != 0) {
      if (((uStack_9c & 1) == 0) && (*(code **)(uStack_9c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_9c & 0xfffffffe))(auStack_94,auStack_94,2);
      }
      uStack_9c = 0;
    }
    FUN_00aa1290();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00aa1290();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00aa1290();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_0000004c != 0) {
    if (((in_stack_0000004c & 1) == 0) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000004c & 0xfffffffe))(&stack0x00000054,&stack0x00000054,2);
    }
    in_stack_0000004c = 0;
  }
  FUN_00aa1290();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 21889 ; VA 0x00a9fcc0 ; FUN_00a9fcc0 */

undefined4 *
FUN_00a9fcc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined8 param_8,
            undefined4 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 *param_15,ulonglong param_16,
            uint param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
            undefined4 param_21,undefined *param_22,undefined8 param_23)

{
  int iVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint auStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  ulonglong uStack_a8;
  uint auStack_a0 [2];
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined8 uStack_88;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6e78;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_a0;
  puStack_18 = (undefined *)auStack_a0;
  uStack_8 = 2;
  auStack_a0[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_a0;
  if (param_17 != 0) {
    auStack_a0[0] = param_17;
    if ((param_17 & 1) == 0) {
      uStack_a8 = ZEXT48(&uStack_98);
      puStack_ac = &param_19;
      uStack_b0 = 0xa9fd28;
      ExceptionList = &pvStack_10;
      (**(code **)(param_17 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_98 = param_19;
      uStack_94 = param_20;
      uStack_90 = param_21;
      puStack_8c = (undefined4 *)param_22;
      uStack_88 = param_23;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_a0;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_c0;
  uStack_8._0_1_ = 3;
  auStack_c0[0] = 0;
  puVar2 = auStack_c0;
  if (param_10 != 0) {
    auStack_c0[0] = param_10;
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_b8,0);
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_b8 = param_12;
      uStack_b4 = param_13;
      uStack_b0 = param_14;
      puStack_ac = param_15;
      uStack_a8 = param_16;
      puVar2 = auStack_c0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uVar3 = FUN_00aa0680(param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  uStack_8._0_1_ = 4;
  *param_1 = param_2;
  uStack_88 = CONCAT44(uVar3,0xa9fde7);
  FUN_00aa0560();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = (undefined4 *)auStack_30;
    uStack_88 = CONCAT44(2,puStack_8c);
    uStack_90 = 0xa9fe08;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_88 = CONCAT44(0xa9fe1a,(undefined4)uStack_88);
  FUN_00aa1290();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_88 = CONCAT44(0xa9fe31,(undefined4)uStack_88);
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_88 = CONCAT44(0xa9fe42,(undefined4)uStack_88);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &param_12;
    uStack_88 = CONCAT44(2,puStack_8c);
    uStack_90 = 0xa9fe63;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_17 != 0) && ((param_17 & 1) == 0)) &&
     (*(code **)(param_17 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &param_19;
    uStack_88 = CONCAT44(2,puStack_8c);
    uStack_90 = 0xa9fe91;
    (**(code **)(param_17 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21890 ; VA 0x00a9feb0 ; FUN_00a9feb0 */

undefined4 *
FUN_00a9feb0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6ec0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((param_16 != 0) && (ExceptionList = &pvStack_10, (param_16 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((param_9 != 0) && ((param_9 & 1) == 0)) {
    (**(code **)(param_9 & 0xfffffffe))(&param_11);
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  FUN_00aa0380(param_3,param_4,param_5,param_6);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *param_1 = param_2;
  FUN_00aa0260();
  FUN_00aa1320();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21891 ; VA 0x00aa00a0 ; FUN_00aa00a0 */

void __fastcall FUN_00aa00a0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar1 = *param_1;
  iVar2 = FUN_00aa0140();
  if (((iVar1 == iVar2) && (param_1[1] != 0)) && (param_1 != (int *)0xfffffff8)) {
    return;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    FUN_005502b0();
    iVar1 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00aa0140();
  uVar3 = FUN_005543f0();
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar4,uVar3);
}



/* FUNCTION 21892 ; VA 0x00aa0140 ; FUN_00aa0140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00aa0140(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6edc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb224) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb224);
    if (DAT_01eeb224 == -1) {
      uStack_8 = 0;
      FUN_00888860("PathWaypoint",0x3a,0,0,0);
      _DAT_01eeb200 = RBX::Reflection::TType<class_RBX::PathWaypoint>::vftable;
      FUN_016f3654(&LAB_0188aeb0);
      FUN_016f37bf(&DAT_01eeb224);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb200;
}



/* FUNCTION 21893 ; VA 0x00aa01e0 ; thunk_FUN_00aa49a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00aa49a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7376;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb29c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb29c);
    if (DAT_01eeb29c == -1) {
      uStack_8 = 0;
      FUN_009ca470("PathWaypointAction");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb238 = RBX::Reflection::EnumDesc<enum_RBX::PathWaypoint::Action>::vftable;
      FUN_009cada0(0,&DAT_019473ec);
      FUN_009cada0(1,&DAT_018d7b94);
      FUN_016f3654(&LAB_0188ae90);
      FUN_016f37bf(&DAT_01eeb29c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb238;
}



/* FUNCTION 21894 ; VA 0x00aa01f0 ; FUN_00aa01f0 */

undefined4 * __fastcall FUN_00aa01f0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("PathWaypointAction");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PathWaypoint::Action>::vftable;
  FUN_009cada0(0,&DAT_019473ec);
  FUN_009cada0(1,&DAT_018d7b94);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21895 ; VA 0x00aa0260 ; FUN_00aa0260 */

undefined4 * __thiscall FUN_00aa0260(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6f00;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
    }
    else {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    }
  }
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21896 ; VA 0x00aa0380 ; FUN_00aa0380 */

undefined4 __thiscall
FUN_00aa0380(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 *param_13,
            ulonglong param_14,uint param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined8 param_21)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6f38;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_15 != 0) {
    uStack_40 = param_15;
    if ((param_15 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_17;
      uStack_50 = 0xaa03ed;
      ExceptionList = &pvStack_10;
      (**(code **)(param_15 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_17;
      uStack_34 = param_18;
      uStack_30 = param_19;
      puStack_2c = (undefined4 *)param_20;
      uStack_28 = param_21;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 4;
  if (param_8 != 0) {
    if ((param_8 & 1) == 0) {
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_58,0);
    }
    else {
      uStack_58 = param_10;
      uStack_54 = param_11;
      uStack_50 = param_12;
      puStack_4c = param_13;
      uStack_48 = param_14;
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00aa0bd0(param_2,param_3,param_4,param_5,param_6,param_7);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xaa04b0,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0xaa04c3,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xaa04da,(undefined4)uStack_28);
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xaa04ec,(undefined4)uStack_28);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_10;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa050d;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_17;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa053b;
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21897 ; VA 0x00aa0560 ; FUN_00aa0560 */

undefined4 * __thiscall FUN_00aa0560(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6f60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  *(undefined8 *)(param_1 + 2) = *(undefined8 *)(param_2 + 2);
  param_1[4] = param_2[4];
  *(undefined8 *)(param_1 + 5) = *(undefined8 *)(param_2 + 5);
  param_1[7] = param_2[7];
  param_1[8] = 0;
  uVar2 = param_2[8];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[8] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 10,param_1 + 10,0);
    }
    else {
      uVar3 = param_2[0xb];
      uVar4 = param_2[0xc];
      uVar5 = param_2[0xd];
      param_1[10] = param_2[10];
      param_1[0xb] = uVar3;
      param_1[0xc] = uVar4;
      param_1[0xd] = uVar5;
      *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  param_1[0x10] = 0;
  uVar2 = param_2[0x10];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0x10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x13];
      uVar4 = param_2[0x14];
      uVar5 = param_2[0x15];
      param_1[0x12] = param_2[0x12];
      param_1[0x13] = uVar3;
      param_1[0x14] = uVar4;
      param_1[0x15] = uVar5;
      *(undefined8 *)(param_1 + 0x16) = *(undefined8 *)(param_2 + 0x16);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x12,param_1 + 0x12,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21898 ; VA 0x00aa0680 ; FUN_00aa0680 */

undefined4 __thiscall
FUN_00aa0680(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 *param_14,ulonglong param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int iVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6f90;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_16 != 0) {
    uStack_40 = param_16;
    if ((param_16 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_18;
      uStack_50 = 0xaa06ed;
      ExceptionList = &pvStack_10;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_18;
      uStack_34 = param_19;
      uStack_30 = param_20;
      puStack_2c = (undefined4 *)param_21;
      uStack_28 = param_22;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_58,0);
    }
    else {
      uStack_58 = param_11;
      uStack_54 = param_12;
      uStack_50 = param_13;
      puStack_4c = param_14;
      uStack_48 = param_15;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00aa0da0(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xaa07ad,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xaa07be,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_11;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa07df;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_18;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa080d;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21899 ; VA 0x00aa0830 ; FUN_00aa0830 */

int __thiscall
FUN_00aa0830(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 param_13,undefined8 param_14)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6fc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00944e50(param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 8) = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0xc) = param_6;
  *(int **)(param_1 + 0x10) = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (param_8 != 0) {
    *(uint *)(param_1 + 0x18) = param_8;
    if ((param_8 & 1) == 0) {
      (**(code **)(param_8 & 0xfffffffe))(&param_10,param_1 + 0x20,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x20) = param_10;
      *(undefined4 *)(param_1 + 0x24) = param_11;
      *(undefined4 *)(param_1 + 0x28) = param_12;
      *(undefined4 *)(param_1 + 0x2c) = param_13;
      *(undefined8 *)(param_1 + 0x30) = param_14;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_8 & 0xfffffffe))(&param_10,&param_10,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21900 ; VA 0x00aa0a40 ; FUN_00aa0a40 */

int __thiscall
FUN_00aa0a40(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined8 param_5,
            undefined4 param_6,undefined8 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e6fe8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00944e50(param_2,param_3,param_4);
  *(undefined8 *)(param_1 + 8) = param_5;
  *(undefined4 *)(param_1 + 0x10) = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  *(undefined8 *)(param_1 + 0x14) = param_7;
  *(undefined4 *)(param_1 + 0x1c) = param_8;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (param_9 != 0) {
    *(uint *)(param_1 + 0x20) = param_9;
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,param_1 + 0x28,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x28) = param_11;
      *(undefined4 *)(param_1 + 0x2c) = param_12;
      *(undefined4 *)(param_1 + 0x30) = param_13;
      *(undefined4 *)(param_1 + 0x34) = param_14;
      *(undefined8 *)(param_1 + 0x38) = param_15;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21901 ; VA 0x00aa0bd0 ; FUN_00aa0bd0 */

int __thiscall
FUN_00aa0bd0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 *param_13,ulonglong param_14,
            uint param_15,undefined4 param_16,undefined4 param_17,undefined4 param_18,
            undefined4 param_19,undefined4 param_20,undefined8 param_21)

{
  int iVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7028;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_38,0);
    }
    else {
      uStack_38 = param_10;
      uStack_34 = param_11;
      uStack_30 = param_12;
      puStack_2c = param_13;
      uStack_28 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00aa0830(param_2,param_3,param_4,param_5,param_6,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_15 != 0) {
    *(uint *)(param_1 + 0x38) = param_15;
    if ((param_15 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x40);
      puStack_2c = &param_17;
      uStack_30 = 0xaa0cd8;
      (**(code **)(param_15 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = param_17;
      *(undefined4 *)(param_1 + 0x44) = param_18;
      *(undefined4 *)(param_1 + 0x48) = param_19;
      *(undefined4 *)(param_1 + 0x4c) = param_20;
      *(undefined8 *)(param_1 + 0x50) = param_21;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xaa0cf5,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xaa0d06,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar1 = param_7[1] + -1;
    param_7[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xaa0d20,(undefined4)uStack_28);
      (**(code **)*param_7)();
      LOCK();
      iVar1 = param_7[2] + -1;
      param_7[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xaa0d31,(undefined4)uStack_28);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_10;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa0d56;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_17;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa0d84;
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21902 ; VA 0x00aa0da0 ; FUN_00aa0da0 */

int __thiscall
FUN_00aa0da0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined8 param_5,
            undefined4 param_6,undefined8 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 *param_14,ulonglong param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int iVar1;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7060;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_38,0);
    }
    else {
      uStack_38 = param_11;
      uStack_34 = param_12;
      uStack_30 = param_13;
      puStack_2c = param_14;
      uStack_28 = param_15;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00aa0a40(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined4 *)(param_1 + 0x40) = 0;
  if (param_16 != 0) {
    *(uint *)(param_1 + 0x40) = param_16;
    if ((param_16 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x48);
      puStack_2c = &param_18;
      uStack_30 = 0xaa0ea5;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x48) = param_18;
      *(undefined4 *)(param_1 + 0x4c) = param_19;
      *(undefined4 *)(param_1 + 0x50) = param_20;
      *(undefined4 *)(param_1 + 0x54) = param_21;
      *(undefined8 *)(param_1 + 0x58) = param_22;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_28 = CONCAT44(0xaa0ec2,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_28 = CONCAT44(0xaa0ed3,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_11;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa0ef8;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_18;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xaa0f26;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21903 ; VA 0x00aa0f40 ; FUN_00aa0f40 */

undefined4 * __thiscall FUN_00aa0f40(undefined4 *param_1,uint *param_2)

{
  uint uVar1;
  void *pvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar2 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017976b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  if (param_2 != (uint *)0x0) {
    do {
      LOCK();
      uVar1 = *param_2;
      *param_2 = *param_2 | 1;
      UNLOCK();
    } while ((uVar1 & 1) != 0);
    *(undefined *)(param_1 + 1) = 1;
    ExceptionList = pvVar2;
    return param_1;
  }
  uVar3 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar3);
}



/* FUNCTION 21904 ; VA 0x00aa0fb0 ; FUN_00aa0fb0 */

undefined4 * __thiscall FUN_00aa0fb0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  float fVar4;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e70a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  param_1[4] = 0;
  param_1[5] = 0;
  *(undefined2 *)(param_1 + 6) = 0x100;
  param_1[7] = (float)DAT_01d70098;
  fVar4 = (float)DAT_01d7009c;
  param_1[9] = 1;
  param_1[8] = fVar4;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uStack_8 = 4;
  puStack_14 = param_1;
  puVar2 = (undefined4 *)FUN_005c4330(auStack_1c,*(undefined4 *)(*param_2 + 0x58));
  iVar3 = puVar2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 8) = *(int *)(iVar3 + 8) + 1;
    UNLOCK();
    iVar3 = puVar2[1];
  }
  param_1[4] = *puVar2;
  piVar1 = (int *)param_1[5];
  param_1[5] = iVar3;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21905 ; VA 0x00aa10f0 ; FUN_00aa10f0 */

undefined8 * __thiscall FUN_00aa10f0(undefined8 *param_1,undefined8 *param_2,undefined4 param_3)

{
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  *(undefined4 *)((int)param_1 + 0xc) = param_3;
  FUN_005502b0();
  return param_1;
}



/* FUNCTION 21906 ; VA 0x00aa1120 ; FUN_00aa1120 */

undefined4 * __fastcall FUN_00aa1120(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_005502b0();
  return param_1;
}



/* FUNCTION 21907 ; VA 0x00aa1150 ; FUN_00aa1150 */

void __fastcall FUN_00aa1150(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  FUN_00aa1290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21908 ; VA 0x00aa11b0 ; FUN_00aa11b0 */

void FUN_00aa11b0(void)

{
  FUN_00aa1320();
  return;
}



/* FUNCTION 21909 ; VA 0x00aa11c0 ; thunk_FUN_00aa1320 */

void __fastcall thunk_FUN_00aa1320(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_00a7c8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21910 ; VA 0x00aa11d0 ; FUN_00aa11d0 */

void __fastcall FUN_00aa11d0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  FUN_00aa1290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21911 ; VA 0x00aa1230 ; FUN_00aa1230 */

void __fastcall FUN_00aa1230(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_00a7c8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21912 ; VA 0x00aa1290 ; FUN_00aa1290 */

code * __fastcall FUN_00aa1290(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x20);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x28,param_1 + 0x28,2);
      }
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 21913 ; VA 0x00aa1320 ; FUN_00aa1320 */

void __fastcall FUN_00aa1320(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_00a7c8d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21914 ; VA 0x00aa13b0 ; FUN_00aa13b0 */

void __fastcall FUN_00aa13b0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xac);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xb4) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xac) = 0;
    *(undefined4 *)(param_1 + 0xb0) = 0;
    *(undefined4 *)(param_1 + 0xb4) = 0;
  }
  FUN_00aa1430();
  FUN_00aa1430();
  return;
}



/* FUNCTION 21915 ; VA 0x00aa1430 ; FUN_00aa1430 */

void __fastcall FUN_00aa1430(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  
  iVar6 = param_1[0xc];
  if (iVar6 != 0) {
    if (param_1[9] != 0) {
      puVar3 = (undefined4 *)(iVar6 + param_1[8] * 4);
      puVar5 = (undefined4 *)*puVar3;
      do {
        *puVar3 = *puVar5;
        FUN_01674ea0(puVar5,0x14);
        param_1[9] = param_1[9] + -1;
        puVar5 = (undefined4 *)*puVar3;
      } while (puVar5 != (undefined4 *)0x0);
      iVar6 = param_1[0xc];
    }
    uVar8 = param_1[8] * 4 + 4;
    iVar7 = iVar6;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar6 + -4);
      uVar8 = param_1[8] * 4 + 0x27;
      if (0x1f < (iVar6 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
    param_1[0xc] = 0;
    param_1[0xb] = 0;
  }
  if (param_1[1] != 0) {
    iVar6 = param_1[2];
    uVar8 = param_1[3];
    puVar3 = (undefined4 *)param_1[1];
    puVar5 = (undefined4 *)*param_1;
    if (uVar8 < 4) {
      uVar8 = 4;
    }
    if ((uVar8 & 3) != 0) {
      uVar8 = (uVar8 - (uVar8 & 3)) + 4;
    }
    do {
      iVar7 = iVar6 + -8;
      puVar1 = *(undefined4 **)((int)puVar3 + iVar6 + -8);
      iVar6 = *(int *)((int)puVar3 + iVar6 + -4);
      for (puVar4 = puVar3; puVar4 != (undefined4 *)(iVar7 + (int)puVar3);
          puVar4 = (undefined4 *)((int)puVar4 + uVar8)) {
        if (puVar4 == puVar5) {
          puVar5 = (undefined4 *)*puVar5;
        }
      }
      FUN_01674ea0(puVar3);
      puVar3 = puVar1;
    } while (puVar1 != (undefined4 *)0x0);
    param_1[1] = 0;
  }
  iVar6 = param_1[2];
  iVar7 = param_1[1];
  if (param_1[1] != 0) {
    do {
      iVar2 = *(int *)(iVar6 + -8 + iVar7);
      iVar6 = *(int *)(iVar6 + iVar7 + -4);
      FUN_01674ea0(iVar7);
      iVar7 = iVar2;
    } while (iVar2 != 0);
    param_1[1] = 0;
    *param_1 = 0;
    param_1[4] = param_1[5];
  }
  return;
}



/* FUNCTION 21916 ; VA 0x00aa1570 ; FUN_00aa1570 */

undefined8 * __thiscall FUN_00aa1570(undefined8 *param_1,undefined8 *param_2)

{
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
  *(undefined4 *)((int)param_1 + 0xc) = *(undefined4 *)((int)param_2 + 0xc);
  return param_1;
}



/* FUNCTION 21917 ; VA 0x00aa1590 ; FUN_00aa1590 */

uint __thiscall FUN_00aa1590(float *param_1,float *param_2)

{
  float *pfVar1;
  float fVar2;
  undefined4 in_EAX;
  float fVar3;
  undefined2 uVar4;
  
  fVar2 = *param_1;
  uVar4 = (undefined2)((uint)in_EAX >> 0x10);
  fVar3 = (float)((uint)CONCAT21(uVar4,(fVar2 == *param_2) << 6 | (NAN(fVar2) || NAN(*param_2)) << 2
                                       | 2U | fVar2 < *param_2) << 8);
  if ((NAN(fVar2) || NAN(*param_2)) != (fVar2 == *param_2)) {
    fVar2 = param_1[1];
    pfVar1 = param_2 + 1;
    fVar3 = (float)((uint)CONCAT21(uVar4,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2
                                         | 2U | fVar2 < *pfVar1) << 8);
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = param_1[2];
      pfVar1 = param_2 + 2;
      fVar3 = (float)((uint)CONCAT21(uVar4,(fVar2 == *pfVar1) << 6 |
                                           (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U | fVar2 < *pfVar1)
                     << 8);
      if (((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) &&
         (fVar3 = param_1[3], fVar3 == param_2[3])) {
        return CONCAT31((int3)((uint)fVar3 >> 8),1);
      }
    }
  }
  return (uint)fVar3 & 0xffffff00;
}



/* FUNCTION 21918 ; VA 0x00aa15e0 ; FUN_00aa15e0 */

uint __thiscall FUN_00aa15e0(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (uVar1 == *param_2) {
    uVar1 = param_2[1] ^ param_1[1];
    if (((uVar1 & 0xfffff) == 0) && (((param_2[1] ^ param_1[1]) & 0xfff00000) == 0)) {
      return CONCAT31((int3)(uVar1 >> 8),1);
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 21919 ; VA 0x00aa1620 ; FUN_00aa1620 */

uint __thiscall FUN_00aa1620(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (uVar1 == *param_2) {
    uVar1 = param_2[1] ^ param_1[1];
    if (((uVar1 & 0xfffff) == 0) && (((param_2[1] ^ param_1[1]) & 0xfff00000) == 0)) {
      return uVar1 & 0xffffff00;
    }
  }
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 21920 ; VA 0x00aa1660 ; FUN_00aa1660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00aa1660(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PathWaypoint::Action>::vftable;
  _DAT_01eeb1f8 = _DAT_01eeb1f8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 21921 ; VA 0x00aa1690 ; FUN_00aa1690 */

undefined4 __thiscall FUN_00aa1690(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 21922 ; VA 0x00aa16c0 ; FUN_00aa16c0 */

undefined4 __thiscall FUN_00aa16c0(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc4);
  }
  return param_1;
}



/* FUNCTION 21923 ; VA 0x00aa16f0 ; FUN_00aa16f0 */

void __fastcall FUN_00aa16f0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x18);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x20) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00577ac0();
  return;
}



/* FUNCTION 21924 ; VA 0x00aa1750 ; FUN_00aa1750 */

void FUN_00aa1750(void)

{
  FUN_00aa13b0();
  return;
}



/* FUNCTION 21925 ; VA 0x00aa1760 ; FUN_00aa1760 */

int __thiscall FUN_00aa1760(int param_1,float *param_2,int param_3,undefined4 *param_4,int *param_5)

{
  float fVar1;
  int iVar2;
  undefined3 uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  float fVar7;
  float fVar8;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e70cf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005502b0();
  if (0 < (int)param_5) {
    iStack_18 = param_4[(int)param_5 * 2 + -2];
    iStack_14 = param_4[(int)param_5 * 2 + -1];
  }
  piVar4 = (int *)FUN_01674e20(0x24);
  uStack_8 = 0;
  param_5 = piVar4;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::PathWaypoint>::vftable;
    *(undefined8 *)(piVar4 + 3) = *(undefined8 *)param_2;
    piVar4[5] = (int)param_2[2];
    piVar4[6] = param_3;
    FUN_005502b0();
  }
  piStack_20 = piVar4 + 3;
  piVar4[7] = iStack_18;
  piVar4[8] = iStack_14;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piVar6 = *(int **)(param_1 + 4);
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_1c = piVar4;
  if (*(int **)(param_1 + 8) == piVar6) {
    FUN_00603a30(piVar6,&piStack_20);
    piVar6 = piStack_1c;
  }
  else {
    *piVar6 = (int)piStack_20;
    piVar6[1] = (int)piVar4;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    piVar6 = (int *)0x0;
    uStack_8._1_3_ = uVar3;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar5 = piVar6[2] + -1;
      piVar6[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  fVar7 = *(float *)(param_1 + 0x20);
  if (param_2[2] <= *(float *)(param_1 + 0x20)) {
    fVar7 = param_2[2];
  }
  fVar8 = *(float *)(param_1 + 0x1c);
  if (param_2[1] <= *(float *)(param_1 + 0x1c)) {
    fVar8 = param_2[1];
  }
  fVar1 = *(float *)(param_1 + 0x18);
  if (*param_2 <= *(float *)(param_1 + 0x18)) {
    fVar1 = *param_2;
  }
  *(ulonglong *)(param_1 + 0x18) = CONCAT44(fVar8,fVar1);
  *(float *)(param_1 + 0x20) = fVar7;
  piStack_1c = (int *)*(float *)(param_1 + 0x2c);
  if (*(float *)(param_1 + 0x2c) <= param_2[2]) {
    piStack_1c = (int *)param_2[2];
  }
  fVar7 = *(float *)(param_1 + 0x28);
  if (*(float *)(param_1 + 0x28) <= param_2[1]) {
    fVar7 = param_2[1];
  }
  fVar8 = *(float *)(param_1 + 0x24);
  if (*(float *)(param_1 + 0x24) <= *param_2) {
    fVar8 = *param_2;
  }
  *(ulonglong *)(param_1 + 0x24) = CONCAT44(fVar7,fVar8);
  *(int **)(param_1 + 0x2c) = piStack_1c;
  piVar6 = *(int **)(param_1 + 0x10);
  param_2 = (float *)CONCAT22(*(undefined2 *)(*(int *)*param_4 + 0xc),
                              *(undefined2 *)(*(int *)*param_4 + 8));
  iVar5 = (int)param_2;
  if ((*(int **)(param_1 + 0xc) == piVar6) || ((float *)piVar6[-1] != param_2)) {
    if (*(int **)(param_1 + 0x14) == piVar6) {
      iVar5 = FUN_00a9f720(piVar6,&param_2);
    }
    else {
      *piVar6 = (int)param_2;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 4;
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar6 = piVar4 + 1;
    iVar2 = *piVar6;
    iVar5 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar6 = piVar4 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21926 ; VA 0x00aa1980 ; FUN_00aa1980 */

void __thiscall FUN_00aa1980(int param_1,int param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  int *piVar5;
  int *piVar6;
  float fVar7;
  uint in_stack_00000028;
  undefined auStack_314 [8];
  undefined4 uStack_30c;
  int **ppiStack_308;
  undefined4 uStack_304;
  undefined4 *puStack_300;
  undefined auStack_2fc [24];
  undefined4 uStack_2e4;
  undefined4 *puStack_2e0;
  char *pcStack_2dc;
  undefined4 uStack_2d8;
  undefined uStack_2d4;
  undefined4 uStack_2cc;
  int *piStack_2c8;
  undefined *puStack_2c4;
  undefined **ppuStack_2c0;
  undefined4 auStack_2b0 [2];
  undefined auStack_2a8 [88];
  undefined4 uStack_250;
  undefined auStack_248 [88];
  undefined4 uStack_1f0;
  undefined auStack_1e8 [88];
  undefined4 uStack_190;
  undefined auStack_188 [88];
  undefined4 uStack_130;
  undefined auStack_128 [88];
  undefined4 auStack_d0 [2];
  undefined auStack_c8 [100];
  undefined **appuStack_64 [2];
  undefined4 *puStack_5c;
  undefined *puStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined4 *puStack_38;
  char cStack_34;
  int *piStack_30;
  undefined *puStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e7179;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppuStack_2c0 = &puStack_2c;
  puStack_2c4 = (undefined *)0xaa19b9;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  puStack_1c = puStack_2c;
  if (puStack_2c == (undefined *)0x0) {
    uStack_2d8 = 0x34;
    puStack_2c4 = puStack_2c;
    ppuStack_2c0 = (undefined **)0xf;
    pcStack_2dc = "Unexpected error. NavigationService doest not exist.";
    uStack_2d4 = 0;
    puStack_2e0 = (undefined4 *)0xaa19e7;
    FUN_005542c0();
    uStack_2d8 = 0xaa19ef;
    FUN_005e65e0();
  }
  else {
    piVar5 = (int *)(param_1 + 0x28);
    ppuStack_2c0 = (undefined **)(param_1 + 0x30);
    puStack_2c4 = (undefined *)0xaa1a03;
    FUN_00aa0f40();
    piVar6 = *(int **)(param_1 + 0x2c);
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x2c);
    }
    piVar1 = (int *)*piVar5;
    uStack_8._0_1_ = 3;
    if (cStack_34 != '\0') {
      *puStack_38 = 0;
    }
    piStack_30 = piVar5;
    piStack_24 = piVar1;
    piStack_20 = piVar6;
    if (piVar1 == (int *)0x0) {
LAB_00aa1ca6:
      if (param_3 == 0) {
        ppuStack_2c0 = (undefined **)0xaa1d77;
        ppuStack_2c0 = (undefined **)FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        puStack_2c4 = &UNK_00aa1d81;
        FUN_0054e5e0();
      }
      puStack_2c4 = &stack0x00000010;
      ppuStack_2c0 = (undefined **)0xffffffff;
      piStack_2c8 = (int *)0xaa1cbf;
      (**(code **)((param_3 & 0xfffffffe) + 4))();
    }
    else {
      if (*piVar1 == piVar1[1]) goto LAB_00aa1ca6;
      if ((param_2 <= piVar1[1] - *piVar1 >> 3) && (0 < param_2)) {
        puStack_3c = (undefined *)&pcStack_2dc;
        uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eeb1ec);
        puStack_2e0 = &stack0x00000028;
        uStack_2e4 = 0xaa1a7b;
        FUN_0054f510();
        puStack_40 = auStack_2fc;
        uStack_8._0_1_ = 5;
        puStack_300 = &param_3;
        uStack_304 = 0xaa1a90;
        FUN_0054f510();
        puStack_44 = (undefined *)&uStack_304;
        ppiStack_308 = &piStack_24;
        uStack_30c = 0xaa1aa1;
        FUN_00557fc0();
        iVar2 = iStack_18;
        ppiStack_308 = (int **)param_2;
        uStack_30c = uStack_14;
        uStack_8._0_1_ = 7;
        FUN_00aa4950(auStack_314);
        uStack_8._0_1_ = 3;
        FUN_00a9feb0(auStack_2b0,FUN_00aa1d90);
        uStack_250 = auStack_2b0[0];
        ppuStack_2c0 = (undefined **)auStack_2a8;
        uStack_8._0_1_ = 8;
        puStack_2c4 = (undefined *)0xaa1aed;
        FUN_00aa0260();
        uStack_1f0 = uStack_250;
        ppuStack_2c0 = (undefined **)auStack_248;
        uStack_8._0_1_ = 9;
        appuStack_64[0] = (undefined **)0x0;
        puStack_2c4 = (undefined *)0xaa1b16;
        FUN_00aa0260();
        uStack_190 = uStack_1f0;
        ppuStack_2c0 = (undefined **)auStack_1e8;
        uStack_8._0_1_ = 10;
        puStack_2c4 = (undefined *)0xaa1b38;
        FUN_00aa0260();
        auStack_d0[0] = uStack_190;
        ppuStack_2c0 = (undefined **)auStack_188;
        uStack_8._0_1_ = 0xb;
        puStack_2c4 = (undefined *)0xaa1b5a;
        FUN_00aa0260();
        ppuStack_2c0 = (undefined **)auStack_d0;
        uStack_8._0_1_ = 0xc;
        puStack_2c4 = (undefined *)0xaa1b6a;
        cVar4 = FUN_00585a40();
        if (cVar4 == '\0') {
          uStack_130 = auStack_d0[0];
          ppuStack_2c0 = (undefined **)auStack_c8;
          puStack_2c4 = (undefined *)0xaa1b8f;
          FUN_00aa0260();
          ppuStack_2c0 = (undefined **)0x60;
          uStack_8._0_1_ = 0xd;
          puStack_2c4 = (undefined *)0xaa1b9a;
          puStack_5c = (undefined4 *)FUN_01674e20();
          uStack_8._0_1_ = 0xe;
          if (puStack_5c == (undefined4 *)0x0) {
            puStack_5c = (undefined4 *)0x0;
          }
          else {
            ppuStack_2c0 = (undefined **)auStack_128;
            *puStack_5c = uStack_130;
            puStack_2c4 = (undefined *)0xaa1bc1;
            FUN_00aa0260();
          }
          ppuStack_2c0 = (undefined **)0xaa1bd3;
          FUN_00aa1320();
          ppuStack_2c0 = (undefined **)0xaa1bde;
          FUN_00aa1320();
          bVar3 = true;
        }
        else {
          ppuStack_2c0 = (undefined **)0xaa1bef;
          FUN_00aa1320();
          bVar3 = false;
        }
        ppuStack_2c0 = (undefined **)0xaa1bfe;
        FUN_00aa1320();
        appuStack_64[0] = &PTR_FUN_019474d4;
        if (!bVar3) {
          appuStack_64[0] = (undefined **)0x0;
        }
        ppuStack_2c0 = (undefined **)0xaa1c19;
        FUN_00aa1320();
        ppuStack_2c0 = (undefined **)0xaa1c24;
        FUN_00aa1320();
        ppuStack_2c0 = (undefined **)0xaa1c2f;
        FUN_00aa1320();
        fVar7 = *(float *)(iVar2 + 0x20);
        uStack_8._0_1_ = 0xf;
        if (0.0 <= fVar7) {
          fVar7 = fVar7 + DAT_018fee54;
        }
        ppuStack_2c0 = (undefined **)appuStack_64;
        puStack_2c4 = (undefined *)(int)fVar7;
        piStack_2c8 = piVar1 + 6;
        uStack_2cc = 0xaa1c5d;
        FUN_00fe8570();
        ppuStack_2c0 = (undefined **)0xaa1c65;
        FUN_00550990();
        ppuStack_2c0 = (undefined **)0xaa1c6d;
        FUN_00550b30();
        ppuStack_2c0 = (undefined **)0xaa1c75;
        FUN_00550b30();
        goto LAB_00aa1d0a;
      }
      uStack_2d8 = 0x1c;
      puStack_2c4 = (undefined *)0x0;
      ppuStack_2c0 = (undefined **)0xf;
      pcStack_2dc = "Start point value is invalid";
      uStack_2d4 = 0;
      puStack_2e0 = (undefined4 *)0xaa1c9c;
      FUN_005542c0();
      uStack_2d8 = 0xaa1ca4;
      FUN_005e65e0();
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        ppuStack_2c0 = (undefined **)0xaa1cd5;
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          ppuStack_2c0 = (undefined **)0xaa1ce5;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      ppuStack_2c0 = (undefined **)0xaa1cfb;
      (**(code **)*piStack_28)();
      LOCK();
      piVar6 = piStack_28 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppuStack_2c0 = (undefined **)0xaa1d0a;
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
LAB_00aa1d0a:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      piStack_2c8 = (int *)&stack0x00000010;
      ppuStack_2c0 = (undefined **)0x2;
      uStack_2cc = 0xaa1d2b;
      puStack_2c4 = (undefined *)piStack_2c8;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 0x11;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    piStack_2c8 = (int *)&stack0x00000030;
    ppuStack_2c0 = (undefined **)0x2;
    uStack_2cc = 0xaa1d59;
    puStack_2c4 = (undefined *)piStack_2c8;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21927 ; VA 0x00aa1d90 ; FUN_00aa1d90 */

void __thiscall FUN_00aa1d90(int param_1,undefined4 param_2,int param_3,int *param_4,uint param_5)

{
  int *piVar1;
  float *pfVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  uint in_stack_00000030;
  uint in_stack_fffffe54;
  undefined4 in_stack_fffffe58;
  undefined4 in_stack_fffffe5c;
  undefined4 in_stack_fffffe60;
  undefined4 uVar10;
  undefined auStack_188 [312];
  undefined auStack_50 [12];
  undefined auStack_44 [4];
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar7 = param_4;
  puStack_c = &LAB_017e71b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((*(int *)(param_1 + 0x24) == 0) && (1 < (uint)(((int *)*param_4)[1] - *(int *)*param_4 >> 3)))
  {
    ExceptionList = &pvStack_10;
    FUN_0126fef0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_012724e0(param_2);
    iVar9 = param_3;
    piVar1 = (int *)*piVar7;
    if ((piVar1[1] - *piVar1 >> 3 < param_3) || (param_3 < 1)) {
      uVar5 = 0;
      uVar10 = 0xf;
      uVar8 = in_stack_fffffe54 & 0xffffff00;
      FUN_005542c0("Start point value is invalid",0x1c);
      FUN_005e65e0(uVar8,in_stack_fffffe58,in_stack_fffffe5c,in_stack_fffffe60,uVar5,uVar10);
      FUN_00aa13b0();
    }
    else {
      FUN_005502b0();
      uVar8 = iVar9 - 1;
      pfStack_14 = (float *)0x0;
      iVar6 = -1;
      piVar7 = (int *)*piVar7;
      iVar9 = *piVar7;
      uStack_18 = uVar8;
      if (uVar8 < (uint)(piVar7[1] - iVar9 >> 3)) {
        do {
          iVar6 = *(int *)(iVar9 + uVar8 * 8);
          bVar3 = false;
          iStack_20 = *(int *)(iVar6 + 0x10);
          uStack_1c = *(undefined4 *)(iVar6 + 0x14);
          pfVar2 = *(float **)(iVar9 + uVar8 * 8);
          uStack_18 = uVar8;
          cVar4 = FUN_0126f470();
          if (cVar4 == '\0') {
            uStack_34 = 0x3f000000;
            uStack_30 = 0x3f000000;
            uStack_2c = 0x3f000000;
            iVar6 = FUN_01270b30(pfVar2,&uStack_34,*param_4 + 0x30,&iStack_20,&fStack_40);
            if (((iVar6 < 0) || (iStack_20 == 0)) ||
               (DAT_018ce2f4 <
                (fStack_3c - pfVar2[1]) * (fStack_3c - pfVar2[1]) +
                (fStack_40 - *pfVar2) * (fStack_40 - *pfVar2) +
                (fStack_38 - pfVar2[2]) * (fStack_38 - pfVar2[2]))) {
              bVar3 = true;
            }
            else {
              iVar9 = *(int *)(iVar9 + uVar8 * 8);
              *(int *)(iVar9 + 0x10) = iStack_20;
              *(undefined4 *)(iVar9 + 0x14) = uStack_1c;
            }
          }
          piVar7 = param_4;
          if (iStack_28 != 0) {
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01eeb1f4) && (FUN_016f3809(&DAT_01eeb1f4), DAT_01eeb1f4 == -1)) {
              DAT_01eeb1f0 = 3.7252903e-09;
              FUN_016f37bf(&DAT_01eeb1f4);
            }
            piVar7 = param_4;
            if ((pfVar2[1] - pfStack_14[1]) * (pfVar2[1] - pfStack_14[1]) +
                (*pfVar2 - *pfStack_14) * (*pfVar2 - *pfStack_14) +
                (pfVar2[2] - pfStack_14[2]) * (pfVar2[2] - pfStack_14[2]) < DAT_01eeb1f0)
            goto LAB_00aa1fbf;
            iVar9 = 0x10;
            do {
              FUN_005502b0();
              piVar7 = param_4;
              iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            FUN_01272580(&iStack_28,pfStack_14,pfVar2,*param_4 + 0x30,auStack_50,(int)&param_3 + 3,
                         auStack_188,auStack_44,0x10);
            uVar8 = uStack_18;
            if (param_3._3_1_ != '\0') goto LAB_00aa1fbf;
LAB_00aa1ffc:
            iVar6 = uStack_18 + 1;
            goto LAB_00aa1fef;
          }
LAB_00aa1fbf:
          if (bVar3) goto LAB_00aa1ffc;
          iStack_28 = iStack_20;
          uVar8 = uVar8 + 1;
          uStack_24 = uStack_1c;
          iVar9 = *(int *)*piVar7;
          pfStack_14 = pfVar2;
        } while (uVar8 < (uint)(((int *)*piVar7)[1] - iVar9 >> 3));
        iVar6 = -1;
        uStack_18 = uVar8;
      }
LAB_00aa1fef:
      if (param_5 == 0) {
        uVar5 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar5);
      }
      (**(code **)((param_5 & 0xfffffffe) + 4))(&stack0x00000018,iVar6);
      FUN_00aa13b0();
    }
  }
  else {
    uVar5 = 0;
    uVar10 = 0xf;
    uVar8 = in_stack_fffffe54 & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("Error. Path is not valid.",0x19);
    FUN_005e65e0(uVar8,in_stack_fffffe58,in_stack_fffffe5c,in_stack_fffffe60,uVar5,uVar10);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_5 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
    }
    param_5 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21928 ; VA 0x00aa2130 ; FUN_00aa2130 */

void __thiscall
FUN_00aa2130(int param_1,float *param_2,float *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  uint *puVar4;
  undefined *puVar5;
  char cVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined8 uStack_174;
  float fStack_16c;
  undefined8 uStack_168;
  float fStack_160;
  uint auStack_15c [2];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 *puStack_148;
  ulonglong uStack_144;
  uint auStack_13c [2];
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined8 uStack_124;
  undefined auStack_11c [72];
  undefined4 uStack_d4;
  char *pcStack_d0;
  undefined4 uStack_cc;
  undefined uStack_c8;
  undefined4 uStack_c0;
  float *pfStack_bc;
  float *pfStack_b8;
  float **ppfStack_b4;
  uint auStack_a8 [2];
  float afStack_a0 [6];
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  undefined8 uStack_70;
  float fStack_68;
  undefined8 uStack_60;
  float fStack_58;
  float *pfStack_50;
  int *piStack_4c;
  undefined *puStack_48;
  undefined *puStack_44;
  undefined *puStack_40;
  float *pfStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  float fStack_30;
  float fStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017e71f9;
  pvStack_1c = ExceptionList;
  uStack_14 = 0;
  ppfStack_b4 = &pfStack_50;
  pfStack_b8 = (float *)0xaa2179;
  ExceptionList = &pvStack_1c;
  FUN_00587490();
  uStack_14._0_1_ = 2;
  if (pfStack_50 == (float *)0x0) {
    uStack_cc = 0x34;
    pfStack_b8 = pfStack_50;
    ppfStack_b4 = (float **)0xf;
    pcStack_d0 = "Unexpected error. NavigationService doest not exist.";
    uStack_c8 = 0;
    uStack_d4 = 0xaa21a2;
    FUN_005542c0();
    uStack_cc = 0xaa21aa;
    FUN_005e65e0();
  }
  else {
    fStack_58 = param_2[2];
    fStack_68 = param_3[2];
    if (fStack_68 < fStack_58) {
      fStack_68 = fStack_58;
    }
    fVar7 = param_3[1];
    fVar9 = param_2[1];
    fVar10 = fVar7;
    if (fVar7 < fVar9) {
      fVar10 = fVar9;
    }
    fVar2 = *param_3;
    fVar8 = *param_2;
    fStack_28 = fVar2;
    if (fVar2 < fVar8) {
      fStack_28 = fVar8;
    }
    if (param_3[2] <= fStack_58) {
      fStack_58 = param_3[2];
    }
    if (fVar7 <= fVar9) {
      fVar9 = fVar7;
    }
    if (fVar2 <= fVar8) {
      fVar8 = fVar2;
    }
    fVar7 = (float)DAT_01d70068 * DAT_018df584;
    fStack_80 = fStack_58 - fVar7;
    _fStack_88 = CONCAT44(fVar9 - fVar7,fVar8 - fVar7);
    fStack_74 = fVar7 + fStack_68;
    _fStack_7c = CONCAT44(fVar7 + fVar10,fVar7 + fStack_28);
    fVar7 = *(float *)(param_1 + 0x20);
    if (0.0 <= fVar7) {
      fVar7 = fVar7 + DAT_018fee54;
    }
    uStack_60 = *(undefined8 *)param_3;
    pfStack_3c = (float *)(int)fVar7;
    ppfStack_b4 = (float **)0x0;
    puStack_38 = auStack_11c;
    puStack_40 = (undefined *)auStack_13c;
    puStack_44 = (undefined *)auStack_13c;
    uStack_70 = *(undefined8 *)param_2;
    fStack_28 = param_3[2];
    fStack_30 = param_2[2];
    uStack_34 = CONCAT31(uStack_34._1_3_,DAT_01eeb1ec);
    auStack_13c[0] = 0;
    puVar4 = auStack_13c;
    puVar5 = auStack_11c;
    if (param_11 != 0) {
      auStack_13c[0] = param_11;
      if ((param_11 & 1) == 0) {
        uStack_144 = ZEXT48(&uStack_134);
        puStack_148 = &param_13;
        uStack_14c = 0xaa233d;
        (**(code **)(param_11 & 0xfffffffe))();
        puVar4 = (uint *)puStack_40;
        puVar5 = puStack_38;
      }
      else {
        uStack_134 = param_13;
        uStack_130 = param_14;
        uStack_12c = param_15;
        uStack_128 = param_16;
        uStack_124 = param_17;
        puVar4 = auStack_13c;
        puVar5 = auStack_11c;
      }
    }
    puStack_38 = puVar5;
    puStack_40 = (undefined *)puVar4;
    puStack_44 = (undefined *)auStack_15c;
    puStack_48 = (undefined *)auStack_15c;
    uStack_14._0_1_ = 3;
    auStack_15c[0] = 0;
    puVar4 = auStack_15c;
    if (param_4 != 0) {
      auStack_15c[0] = param_4;
      if ((param_4 & 1) == 0) {
        fStack_160 = 0.0;
        uStack_168 = CONCAT44(&uStack_154,&param_6);
        fStack_16c = 1.562478e-38;
        (**(code **)(param_4 & 0xfffffffe))();
        puVar4 = (uint *)puStack_44;
      }
      else {
        uStack_154 = param_6;
        uStack_150 = param_7;
        uStack_14c = param_8;
        puStack_148 = param_9;
        uStack_144 = param_10;
        puVar4 = auStack_15c;
      }
    }
    puStack_44 = (undefined *)puVar4;
    uStack_14._0_1_ = 4;
    uStack_168 = uStack_60;
    fStack_160 = fStack_28;
    uStack_178 = uStack_34;
    puStack_48 = (undefined *)&uStack_180;
    uStack_174 = uStack_70;
    fStack_16c = fStack_30;
    uStack_180 = 0;
    uStack_17c = 0;
    cVar6 = FUN_00602ce0(param_1);
    if (cVar6 == '\0') {
      FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&uStack_70,&DAT_01c21d80);
    }
    uStack_14._0_1_ = 2;
    FUN_00a9fcc0(puStack_38,&LAB_00aa2780);
    uStack_124 = CONCAT44(0xaa23fc,(undefined4)uStack_124);
    FUN_00a9f360();
    ppfStack_b4 = (float **)auStack_a8;
    uStack_14._0_1_ = 5;
    pfStack_b8 = pfStack_3c;
    pfStack_bc = &fStack_88;
    uStack_c0 = 0xaa2415;
    FUN_00fe8570();
    uStack_14._0_1_ = 6;
    if (auStack_a8[0] != 0) {
      if (((auStack_a8[0] & 1) == 0) && (*(code **)(auStack_a8[0] & 0xfffffffe) != (code *)0x0)) {
        pfStack_bc = afStack_a0;
        ppfStack_b4 = (float **)0x2;
        uStack_c0 = 0xaa243c;
        pfStack_b8 = pfStack_bc;
        (**(code **)(auStack_a8[0] & 0xfffffffe))();
      }
      auStack_a8[0] = 0;
    }
  }
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppfStack_b4 = (float **)0xaa2462;
      (**(code **)*piStack_4c)();
      LOCK();
      piVar1 = piStack_4c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppfStack_b4 = (float **)0xaa2471;
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,7);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    pfStack_bc = (float *)&param_6;
    ppfStack_b4 = (float **)0x2;
    uStack_c0 = 0xaa2492;
    pfStack_b8 = pfStack_bc;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 8;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    pfStack_bc = (float *)&param_13;
    ppfStack_b4 = (float **)0x2;
    uStack_c0 = 0xaa24c0;
    pfStack_b8 = pfStack_bc;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 21929 ; VA 0x00aa24f0 ; FUN_00aa24f0 */

void FUN_00aa24f0(float *param_1,float *param_2,undefined8 *param_3,float *param_4,float *param_5)

{
  uint uVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar4 = *param_1 - param_1[1] * 0.0;
  fVar6 = param_1[1] * 0.0 - param_1[2];
  fVar5 = param_1[2] * 0.0 - *param_1 * 0.0;
  dVar2 = (double)(fVar5 * fVar5 + fVar6 * fVar6 + fVar4 * fVar4);
  FUN_017267a0();
  fVar3 = DAT_018ce2f8 / (float)dVar2;
  *(ulonglong *)param_4 = CONCAT44(fVar5 * fVar3,fVar6 * fVar3);
  param_4[2] = fVar4 * fVar3;
  fVar4 = *param_2 - param_2[1] * 0.0;
  fVar6 = param_2[1] * 0.0 - param_2[2];
  fVar5 = param_2[2] * 0.0 - *param_2 * 0.0;
  dVar2 = (double)(fVar5 * fVar5 + fVar6 * fVar6 + fVar4 * fVar4);
  FUN_017267a0();
  fVar3 = DAT_018ce2f8 / (float)dVar2;
  *(ulonglong *)param_5 = CONCAT44(fVar5 * fVar3,fVar6 * fVar3);
  param_5[2] = fVar4 * fVar3;
  uVar1 = DAT_018c4ea0;
  fVar3 = *param_4;
  fVar6 = *param_5;
  fVar4 = param_5[2];
  fVar5 = param_4[2];
  if (0.0 < fVar3 * fVar4 - fVar6 * fVar5) {
    fVar5 = (float)((uint)fVar5 ^ DAT_018c4ea0);
    *(ulonglong *)param_4 = CONCAT44((uint)param_4[1] ^ DAT_018c4ea0,(uint)fVar3 ^ DAT_018c4ea0);
    param_4[2] = fVar5;
    *(ulonglong *)param_5 = CONCAT44((uint)param_5[1] ^ uVar1,(uint)*param_5 ^ uVar1);
    param_5[2] = (float)((uint)param_5[2] ^ uVar1);
    fVar3 = *param_4;
    fVar6 = *param_5;
    fVar5 = param_4[2];
    fVar4 = param_5[2];
  }
  fVar6 = fVar6 + fVar3;
  fVar3 = param_4[1] + param_5[1];
  fVar4 = fVar4 + fVar5;
  dVar2 = (double)(fVar6 * fVar6 + fVar3 * fVar3 + fVar4 * fVar4);
  FUN_017267a0();
  fVar5 = DAT_018ce2f8 / (float)dVar2;
  *param_3 = CONCAT44(fVar3 * fVar5,fVar6 * fVar5);
  *(float *)(param_3 + 1) = fVar4 * fVar5;
  return;
}



/* FUNCTION 21930 ; VA 0x00aa3790 ; FUN_00aa3790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aa3790(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00aa49a0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eeb2ac) {
      FUN_016f3809(&DAT_01eeb2ac);
      if (DAT_01eeb2ac == -1) {
        _DAT_01eeb2a0 = FUN_005c65e0;
        _DAT_01eeb2a4 = FUN_005c65e0;
        _DAT_01eeb2a8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eeb2ac);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eeb2a0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eeb2a0;
  }
  return;
}



/* FUNCTION 21931 ; VA 0x00aa3850 ; FUN_00aa3850 */

undefined * FUN_00aa3850(undefined *param_1,int param_2)

{
  undefined8 uVar1;
  undefined uVar2;
  undefined4 uVar3;
  uint *puVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int aiStack_5c [5];
  uint uStack_48;
  undefined4 ***pppuStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017e72d9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  iStack_8 = 0;
  uStack_14 = 1;
  FUN_00d86ac0(aiStack_5c,param_2);
  iStack_8 = 1;
  puVar4 = (uint *)FUN_00585d40(0,&DAT_0194740c,1);
  uStack_14 = 3;
  uStack_2c = *puVar4;
  uStack_28 = puVar4[1];
  uStack_24 = puVar4[2];
  uStack_20 = puVar4[3];
  uStack_1c = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  iStack_8._0_1_ = 2;
  piVar5 = (int *)FUN_00554150(&DAT_0193486c,1);
  uStack_14 = 7;
  pppuStack_44 = (undefined4 ***)*piVar5;
  iStack_40 = piVar5[1];
  iStack_3c = piVar5[2];
  iStack_38 = piVar5[3];
  uVar1 = *(undefined8 *)(piVar5 + 4);
  piVar5[4] = 0;
  piVar5[5] = 0xf;
  *(undefined *)piVar5 = 0;
  uStack_34._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
  uStack_34._0_4_ = (undefined4)uVar1;
  iStack_8._0_1_ = 3;
  ppppuVar6 = &pppuStack_44;
  if (0xf < uStack_34._4_4_) {
    ppppuVar6 = (undefined4 ****)pppuStack_44;
  }
  uVar3 = (undefined4)uStack_34;
  uStack_34 = uVar1;
  FUN_00554150(ppppuVar6,uVar3);
  iStack_8._0_1_ = 2;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  if (0xf < uStack_34._4_4_) {
    uVar8 = uStack_34._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_44;
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)pppuStack_44[-1];
      uVar8 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_44 + (-4 - (int)ppppuVar6))) {
        iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar8);
  }
  iStack_8._0_1_ = 1;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_1c._4_4_) {
    uVar9 = uStack_1c._4_4_ + 1;
    uVar8 = uStack_2c;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(uStack_2c - 4);
      uVar9 = uStack_1c._4_4_ + 0x24;
      if (0x1f < (uStack_2c - uVar8) - 4) {
        iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_1c = 0xf00000000;
  uStack_2c = uStack_2c & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_48) {
    uVar8 = uStack_48 + 1;
    iVar7 = aiStack_5c[0];
    if (0xfff < uVar8) {
      iVar7 = *(int *)(aiStack_5c[0] + -4);
      uVar8 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  FUN_00554150(&DAT_018cecfc,2);
  FUN_00aa49a0();
  FUN_009cb090(&pppuStack_44,*(undefined4 *)(param_2 + 0xc));
  uStack_14 = 0xf;
  ppppuVar6 = &pppuStack_44;
  if (0xf < uStack_34._4_4_) {
    ppppuVar6 = (undefined4 ****)pppuStack_44;
  }
  iStack_8 = 4;
  FUN_00554150(ppppuVar6,(undefined4)uStack_34);
  if (0xf < uStack_34._4_4_) {
    uVar8 = uStack_34._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_44;
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)pppuStack_44[-1];
      uVar8 = uStack_34._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_44 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21932 ; VA 0x00aa3ab0 ; FUN_00aa3ab0 */

void FUN_00aa3ab0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00aa49a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21933 ; VA 0x00aa3af0 ; FUN_00aa3af0 */

bool FUN_00aa3af0(float *param_1,float *param_2)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb1f4) {
    FUN_016f3809(&DAT_01eeb1f4);
    if (DAT_01eeb1f4 == -1) {
      DAT_01eeb1f0 = 3.7252903e-09;
      FUN_016f37bf(&DAT_01eeb1f4);
    }
  }
  return (param_2[1] - param_1[1]) * (param_2[1] - param_1[1]) +
         (*param_2 - *param_1) * (*param_2 - *param_1) +
         (param_2[2] - param_1[2]) * (param_2[2] - param_1[2]) < DAT_01eeb1f0;
}



/* FUNCTION 21934 ; VA 0x00aa3b90 ; FUN_00aa3b90 */

int __thiscall FUN_00aa3b90(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined auStack_2c [12];
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7300;
  pvStack_10 = ExceptionList;
  if (param_2 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00587490(&iStack_20);
    uStack_8 = 0;
    if (iStack_20 != 0) {
      uStack_18 = 0;
      piStack_14 = (int *)0x0;
      cVar4 = FUN_00602ce0(param_1);
      if (cVar4 == '\0') {
        FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_2c,&DAT_01c21d80);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00fe7d70(&uStack_18);
      piVar2 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_14[1] + -1;
        piStack_14[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piStack_1c + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1 + 0x38;
}



/* FUNCTION 21935 ; VA 0x00aa3c80 ; FUN_00aa3c80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00aa3c80(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uStack_108;
  undefined *puStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  int *piStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  char cStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e732b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&piStack_24);
  puVar4 = (undefined4 *)(param_1 + 0x28);
  uStack_8 = 0;
  FUN_00aa0f40(param_1 + 0x30);
  piVar5 = *(int **)(param_1 + 0x2c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0x2c);
  }
  piVar1 = (int *)*puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (cStack_2c != '\0') {
    *puStack_30 = 0;
  }
  piStack_38 = piVar1;
  piStack_34 = piVar5;
  puStack_28 = puVar4;
  piStack_1c = piVar5;
  piStack_18 = piVar1;
  if (piVar1 != (int *)0x0) {
    puStack_14 = (undefined4 *)(piVar1[1] - *piVar1 >> 3);
    if ((uint)((piStack_24[2] - *piStack_24) / 0xd0) < puStack_14) {
      if (0x13b13b1 < puStack_14) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      FUN_00a974c0(puStack_14);
    }
    puVar4 = (undefined4 *)*piVar1;
    puStack_14 = (undefined4 *)piStack_18[1];
    if (puVar4 != puStack_14) {
      piStack_18 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
      do {
        puVar2 = (undefined8 *)*puVar4;
        uStack_108 = FUN_0088d870();
        puStack_104 = (undefined *)0x0;
        uStack_100 = *puVar2;
        uStack_f8 = *(undefined4 *)(puVar2 + 1);
        if ((piStack_18[0xd] < DAT_01ead408) && (FUN_016f3809(&DAT_01ead408), DAT_01ead408 == -1)) {
          _DAT_01ead3fc = FUN_005c6600;
          _DAT_01ead400 = FUN_005c6600;
          DAT_01ead404 = _guard_check_icall;
          FUN_016f37bf(&DAT_01ead408);
        }
        puStack_104 = &DAT_01ead3fc;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (piStack_24[2] == piStack_24[1]) {
          FUN_005ca4f0(piStack_24[1],&uStack_108);
        }
        else {
          FUN_005caaf0(piStack_24);
          piStack_24[1] = piStack_24[1] + 0xd0;
        }
        uStack_8._0_1_ = 3;
        if (puStack_104 != (undefined *)0x0) {
          (**(code **)(puStack_104 + 8))(&uStack_100);
        }
        puVar4 = puVar4 + 2;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piVar5 = piStack_1c;
      } while (puVar4 != puStack_14);
    }
  }
  *param_2 = piStack_24;
  param_2[1] = uStack_20;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21936 ; VA 0x00aa3eb0 ; FUN_00aa3eb0 */

undefined4 * __thiscall FUN_00aa3eb0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uStack_108;
  int iStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined8 uStack_f0;
  int *piStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  char cStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e732b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&piStack_24);
  piVar4 = (int *)(param_1 + 0x28);
  uStack_8 = 0;
  FUN_00aa0f40(param_1 + 0x30);
  piVar3 = *(int **)(param_1 + 0x2c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = *(int **)(param_1 + 0x2c);
  }
  piStack_38 = (int *)*piVar4;
  uStack_8._0_1_ = 1;
  if (cStack_2c != '\0') {
    *puStack_30 = 0;
  }
  piStack_34 = piVar3;
  piStack_28 = piVar4;
  piStack_1c = piVar3;
  piStack_18 = piStack_38;
  if (piStack_38 != (int *)0x0) {
    piStack_14 = (int *)(piStack_38[1] - *piStack_38 >> 3);
    if ((uint)((piStack_24[2] - *piStack_24) / 0xd0) < piStack_14) {
      if (0x13b13b1 < piStack_14) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      FUN_00a974c0(piStack_14);
    }
    piStack_14 = (int *)*piStack_18;
    piStack_18 = (int *)piStack_18[1];
    if (piStack_14 != piStack_18) {
      do {
        puVar1 = (undefined4 *)*piStack_14;
        uStack_108 = FUN_00aa0140();
        iStack_104 = 0;
        uStack_100 = *puVar1;
        uStack_fc = puVar1[1];
        uStack_f8 = puVar1[2];
        uStack_f4 = puVar1[3];
        uStack_f0 = *(undefined8 *)(puVar1 + 4);
        iStack_104 = FUN_00631000();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (piStack_24[2] == piStack_24[1]) {
          FUN_005ca4f0(piStack_24[1],&uStack_108);
        }
        else {
          FUN_005caaf0(piStack_24);
          piStack_24[1] = piStack_24[1] + 0xd0;
        }
        uStack_8._0_1_ = 3;
        if (iStack_104 != 0) {
          (**(code **)(iStack_104 + 8))(&uStack_100);
        }
        piStack_14 = piStack_14 + 2;
        uStack_8._0_1_ = 1;
        piVar3 = piStack_1c;
      } while (piStack_14 != piStack_18);
    }
  }
  *param_2 = piStack_24;
  param_2[1] = uStack_20;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21937 ; VA 0x00aa4070 ; FUN_00aa4070 */

/* WARNING: Removing unreachable block (ram,0x00aa40b4) */
/* WARNING: Removing unreachable block (ram,0x00aa40c7) */
/* WARNING: Removing unreachable block (ram,0x00aa40d4) */
/* WARNING: Removing unreachable block (ram,0x00aa40e2) */
/* WARNING: Removing unreachable block (ram,0x00aa40e9) */

undefined4 FUN_00aa4070(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00602ce0(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21938 ; VA 0x00aa4100 ; FUN_00aa4100 */

void FUN_00aa4100(int param_1)

{
  FUN_005e6780(*(undefined4 *)(param_1 + 8));
  return;
}



/* FUNCTION 21939 ; VA 0x00aa4120 ; FUN_00aa4120 */

void FUN_00aa4120(int *param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_3c = 0;
  uVar2 = *(uint *)(iVar1 + 0x48);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_3c = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      iStack_48 = iVar1 + 0x50;
      uStack_4c = 0xaa4187;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_34 = *(undefined4 *)(iVar1 + 0x50);
      uStack_30 = *(undefined4 *)(iVar1 + 0x54);
      uStack_2c = *(undefined4 *)(iVar1 + 0x58);
      uStack_28 = *(undefined4 *)(iVar1 + 0x5c);
      uStack_24 = *(undefined8 *)(iVar1 + 0x60);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *(uint *)(iVar1 + 0x28);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x30,&uStack_54,0);
    }
    else {
      uStack_54 = *(undefined4 *)(iVar1 + 0x30);
      uStack_50 = *(undefined4 *)(iVar1 + 0x34);
      uStack_4c = *(undefined4 *)(iVar1 + 0x38);
      iStack_48 = *(int *)(iVar1 + 0x3c);
      uStack_44 = *(ulonglong *)(iVar1 + 0x40);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00a9f4c0(iVar1 + 8,param_2,iVar1 + 0x10,iVar1 + 0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21940 ; VA 0x00aa4200 ; FUN_00aa4200 */

void FUN_00aa4200(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b108;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uVar2 = *(undefined4 *)(iVar1 + 0x10);
  uStack_40 = 0;
  uVar3 = *(uint *)(iVar1 + 0x40);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_40 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar1 + 0x48;
      uStack_50 = 0xaa426f;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar1 + 0x48);
      uStack_34 = *(undefined4 *)(iVar1 + 0x4c);
      uStack_30 = *(undefined4 *)(iVar1 + 0x50);
      uStack_2c = *(undefined4 *)(iVar1 + 0x54);
      uStack_28 = *(undefined8 *)(iVar1 + 0x58);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = *(uint *)(iVar1 + 0x20);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar1 + 0x28,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar1 + 0x28);
      uStack_54 = *(undefined4 *)(iVar1 + 0x2c);
      uStack_50 = *(undefined4 *)(iVar1 + 0x30);
      iStack_4c = *(int *)(iVar1 + 0x34);
      uStack_48 = *(ulonglong *)(iVar1 + 0x38);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00a9f5f0(iVar1 + 8,param_2,uVar2,iVar1 + 0x14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21941 ; VA 0x00aa42f0 ; FUN_00aa42f0 */

void FUN_00aa42f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00aa49a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21942 ; VA 0x00aa4330 ; FUN_00aa4330 */

int * FUN_00aa4330(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00aa4419. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd1be4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_7b418556ec3729fa7993986c26999926>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 21943 ; VA 0x00aa4440 ; FUN_00aa4440 */

int * FUN_00aa4440(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00aa4521. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00aa4496. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd1bac);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ae4c4627c92e68eb3f945f84ad601e71>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 21944 ; VA 0x00aa4540 ; FUN_00aa4540 */

void FUN_00aa4540(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d05ef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x68);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00aa0560(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x48);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x50,iVar4 + 0x50,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x48) = 0;
        }
        FUN_00aa1290();
        FUN_01674ea0(iVar4,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dd1e44);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::NavigationPath,class_dtNavMesh*,class_G3D::Vector3_const&,class_G3D::Vector3_const&,class_boost::function<void___cdecl(void)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::NavigationPath>_>,struct_boost::arg<1>,class_boost::_bi::value<class_G3D::Vector3>,class_boost::_bi::value<class_G3D::Vector3>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21945 ; VA 0x00aa46d0 ; FUN_00aa46d0 */

void FUN_00aa46d0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x60);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00aa0260(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00aa1320();
        FUN_01674ea0(iVar3,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd1c1c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::NavigationPath,class_dtNavMesh*,int,class_std::shared_ptr<struct_RBX::PathData_const_>_const&,class_boost::function<void___cdecl(int)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::NavigationPath>_>,struct_boost::arg<1>,class_boost::_bi::value<int>,class_boost::_bi::value<class_std::shared_ptr<struct_RBX::PathData_const_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(int)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21946 ; VA 0x00aa4820 ; FUN_00aa4820 */

void FUN_00aa4820(undefined4 param_1,undefined4 param_2,undefined4 *param_3,float *param_4,
                 undefined4 param_5,float *param_6,undefined4 *param_7)

{
  int iVar1;
  undefined auStack_44 [40];
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  int iStack_c;
  char cStack_5;
  
  iVar1 = 5;
  do {
    FUN_005502b0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  FUN_01272580(param_3,param_4,param_5,param_2,param_6,&cStack_5,auStack_44,&iStack_c,5);
  if (cStack_5 == '\0') {
    fStack_1c = (*param_6 - *param_4) * DAT_018ce2f4 + *param_4;
    fStack_18 = (param_6[1] - param_4[1]) * DAT_018ce2f4 + param_4[1];
    fStack_14 = (param_6[2] - param_4[2]) * DAT_018ce2f4 + param_4[2];
    FUN_01272580(param_3,param_4,&fStack_1c,param_2,param_6,&cStack_5,auStack_44,&iStack_c,5);
    if (cStack_5 == '\0') {
      *param_7 = *param_3;
      param_7[1] = param_3[1];
      *param_6 = *param_4;
      param_6[1] = param_4[1];
      param_6[2] = param_4[2];
      return;
    }
  }
  fStack_10 = 0.0;
  FUN_01271b20(auStack_44 + iStack_c * 8 + -8,param_6,&fStack_10);
  param_6[1] = fStack_10;
  *param_7 = *(undefined4 *)(auStack_44 + iStack_c * 8 + -8);
  param_7[1] = *(undefined4 *)(auStack_44 + iStack_c * 8 + -4);
  return;
}



/* FUNCTION 21947 ; VA 0x00aa4950 ; FUN_00aa4950 */

undefined4 * __thiscall FUN_00aa4950(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined auStack_10 [12];
  
  *param_2 = 0;
  param_2[1] = 0;
  cVar1 = FUN_00602ce0(param_1);
  if (cVar1 != '\0') {
    return param_2;
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c21d80);
}



/* FUNCTION 21948 ; VA 0x00aa49a0 ; FUN_00aa49a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00aa49a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e7376;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb29c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeb29c);
    if (DAT_01eeb29c == -1) {
      uStack_8 = 0;
      FUN_009ca470("PathWaypointAction");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeb238 = RBX::Reflection::EnumDesc<enum_RBX::PathWaypoint::Action>::vftable;
      FUN_009cada0(0,&DAT_019473ec);
      FUN_009cada0(1,&DAT_018d7b94);
      FUN_016f3654(&LAB_0188ae90);
      FUN_016f37bf(&DAT_01eeb29c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeb238;
}



/* FUNCTION 21949 ; VA 0x00aa4a60 ; FUN_00aa4a60 */

code * __fastcall FUN_00aa4a60(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  float fVar6;
  code *apcStack_6c [2];
  undefined auStack_64 [24];
  code *pcStack_4c;
  char cStack_48;
  int *piStack_44;
  undefined auStack_40 [8];
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  code *pcStack_28;
  int *piStack_24;
  code *pcStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e73a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00587490(&pcStack_28);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  pcStack_1c = pcStack_28;
  if (pcStack_28 != (code *)0x0) {
    piVar5 = (int *)(param_1 + 0x28);
    pcStack_28 = (code *)FUN_00aa0f40(param_1 + 0x30);
    piVar4 = *(int **)(param_1 + 0x2c);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0x2c);
    }
    iVar2 = *piVar5;
    uStack_8._0_1_ = 1;
    if (cStack_48 != '\0') {
      *(undefined4 *)pcStack_4c = 0;
      pcStack_28 = pcStack_4c;
    }
    piStack_44 = piVar5;
    iStack_30 = iVar2;
    piStack_2c = piVar4;
    if ((((iVar2 != 0) && (*(float *)(iVar2 + 0x18) <= *(float *)(iVar2 + 0x24))) &&
        (*(float *)(iVar2 + 0x1c) <= *(float *)(iVar2 + 0x28))) &&
       (*(float *)(iVar2 + 0x20) <= *(float *)(iVar2 + 0x2c))) {
      puVar3 = (undefined4 *)FUN_00aa4950(auStack_40);
      piVar5 = (int *)puVar3[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
        piVar5 = (int *)puVar3[1];
      }
      uStack_38 = *puVar3;
      piStack_34 = piVar5;
      uStack_14 = uStack_38;
      FUN_00550b30();
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[2] = piVar5[2] + 1;
        UNLOCK();
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      FUN_00a9f170(uStack_14,piVar5,iVar2,piVar4,0);
      uStack_8._0_1_ = 3;
      fVar6 = *(float *)(iStack_18 + 0x20);
      if (0.0 <= fVar6) {
        fVar6 = fVar6 + DAT_018fee54;
      }
      FUN_00fe8680(iVar2 + 0xc,(int)fVar6,apcStack_6c);
      uStack_8._0_1_ = 4;
      if (((apcStack_6c[0] != (code *)0x0) && (((uint)apcStack_6c[0] & 1) == 0)) &&
         (apcStack_6c[0] = *(code **)((uint)apcStack_6c[0] & 0xfffffffe),
         apcStack_6c[0] != (code *)0x0)) {
        apcStack_6c[0] = (code *)(*apcStack_6c[0])(auStack_64,auStack_64,2);
      }
      pcStack_28 = apcStack_6c[0];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        pcStack_28 = (code *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pcStack_28 = (code *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar5 = piVar4 + 1;
      iVar2 = *piVar5;
      pcStack_28 = (code *)*piVar5;
      *piVar5 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar2 = *piVar5;
        pcStack_28 = (code *)*piVar5;
        *piVar5 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pcStack_28 = (code *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_24 + 1;
    iVar2 = *piVar5;
    pcStack_28 = (code *)*piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pcStack_28 = (code *)(**(code **)*piStack_24)();
      LOCK();
      piVar5 = piStack_24 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcStack_28 = (code *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcStack_28;
}



/* FUNCTION 21950 ; VA 0x00aa4c60 ; FUN_00aa4c60 */

void __thiscall FUN_00aa4c60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  float fVar2;
  int *piVar3;
  char cVar4;
  undefined *puVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  float *pfVar10;
  int *in_stack_fffffe14;
  float *in_stack_fffffe18;
  float *in_stack_fffffe1c;
  int iVar11;
  float *pfVar12;
  undefined4 *puVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined auStack_1bc [312];
  float afStack_84 [3];
  undefined auStack_78 [12];
  undefined auStack_6c [4];
  float fStack_68;
  float fStack_64;
  float fStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  uint uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  float *pfStack_2c;
  float *pfStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar7 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e73d3;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  iStack_34 = param_1;
  if ((uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3) < 2) goto LAB_00aa4ee2;
  ExceptionList = &pvStack_10;
  FUN_0126fef0();
  uStack_8 = 0;
  FUN_012724e0(param_2);
  FUN_005502b0();
  iVar9 = 0;
  pfStack_2c = (float *)0x0;
  iStack_40 = 0;
  piStack_3c = (int *)0x0;
  uStack_8._0_1_ = 1;
  piVar8 = (int *)((undefined4 *)*piVar7)[1];
  piVar7 = *(int **)*piVar7;
  uStack_14 = (int)piVar8 - (int)piVar7 >> 3;
  if (piVar8 != piVar7) {
    do {
      piVar7 = piVar8 + -2;
      iStack_24 = *(int *)(piVar8[-2] + 0x10);
      uStack_20 = *(undefined4 *)(piVar8[-2] + 0x14);
      pfStack_28 = (float *)*piVar7;
      piStack_18 = piVar7;
      if ((iVar9 == 0) || (piVar6 = piStack_3c, *(int *)(iVar9 + 0xc) != 1)) {
        cVar4 = FUN_0126f470();
        pfVar10 = pfStack_28;
        if (cVar4 == '\0') {
          uStack_5c = 0x3f000000;
          puVar5 = (undefined *)(*param_3 + 0x30);
          uStack_58 = 0x3f000000;
          puVar13 = &uStack_5c;
          uStack_54 = 0x3f000000;
          iVar11 = 0xaa4d66;
          pfVar12 = pfStack_28;
          iVar9 = FUN_01270b30(pfStack_28,puVar13,puVar5,&iStack_24,&fStack_68);
          if (((-1 < iVar9) && (iStack_24 != 0)) &&
             ((fStack_64 - pfVar10[1]) * (fStack_64 - pfVar10[1]) +
              (fStack_68 - *pfVar10) * (fStack_68 - *pfVar10) +
              (fStack_60 - pfVar10[2]) * (fStack_60 - pfVar10[2]) <= DAT_018ce2f4)) {
            iStack_44 = piVar8[-1];
            iStack_48 = *piVar7;
            if (iStack_44 != 0) {
              LOCK();
              *(int *)(iStack_44 + 4) = *(int *)(iStack_44 + 4) + 1;
              UNLOCK();
              iStack_44 = piVar8[-1];
            }
            *(int *)(iStack_48 + 0x10) = iStack_24;
            *(undefined4 *)(iStack_48 + 0x14) = uStack_20;
            FUN_00550b30();
            goto LAB_00aa4de4;
          }
LAB_00aa4efe:
          uStack_38 = uStack_14;
          if ((0 < (int)uStack_14) && (uStack_14 != *(uint *)(iStack_34 + 0x34))) {
            iVar9 = *(int *)(iStack_34 + 0x14);
            iStack_1c = 0;
            piStack_18 = (int *)0x0;
            if (iVar9 == 0) goto LAB_00aa4f49;
            iVar1 = *(int *)(iVar9 + 4);
            piVar7 = (int *)(iVar9 + 4);
            goto joined_r0x00aa4f29;
          }
          break;
        }
LAB_00aa4de4:
        if (uStack_14 < (uint)(((int *)*param_3)[1] - *(int *)*param_3 >> 3)) {
          iVar9 = 0x10;
          do {
            FUN_005502b0();
            pfVar10 = pfStack_28;
            iVar9 = iVar9 + -1;
          } while (iVar9 != 0);
          puVar5 = auStack_1bc;
          puVar13 = (undefined4 *)((int)&param_2 + 3);
          iVar11 = *param_3 + 0x30;
          pfVar12 = afStack_84;
          in_stack_fffffe14 = &iStack_24;
          in_stack_fffffe18 = pfStack_28;
          in_stack_fffffe1c = pfStack_2c;
          FUN_01272580(in_stack_fffffe14,pfStack_28,pfStack_2c,iVar11,pfVar12,puVar13,puVar5,
                       auStack_6c,0x10);
          piVar7 = piStack_18;
          if (param_2._3_1_ == '\0') goto LAB_00aa4efe;
        }
        piVar3 = piStack_3c;
        iStack_50 = iStack_24;
        uStack_4c = uStack_20;
        piVar6 = (int *)piVar8[-1];
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
          piVar6 = (int *)piVar8[-1];
        }
        iVar9 = *piVar7;
        iStack_40 = iVar9;
        pfStack_2c = pfVar10;
        if (piStack_3c != (int *)0x0) {
          LOCK();
          iVar11 = piStack_3c[1] + -1;
          piStack_3c[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            puVar13 = (undefined4 *)*piStack_3c;
            piStack_3c = piVar6;
            (*(code *)*puVar13)();
            LOCK();
            piVar8 = piVar3 + 2;
            iVar11 = *piVar8 + -1;
            *piVar8 = iVar11;
            UNLOCK();
            piVar6 = piStack_3c;
            if (iVar11 == 0) {
              (**(code **)(*piVar3 + 4))();
              piVar6 = piStack_3c;
            }
          }
        }
      }
      piStack_3c = piVar6;
      uStack_14 = uStack_14 - 1;
      piVar8 = piVar7;
    } while (piVar7 != *(int **)*param_3);
    goto LAB_00aa4eb2;
  }
  goto LAB_00aa4ed7;
joined_r0x00aa4f29:
  if (iVar1 == 0) goto LAB_00aa4f49;
  LOCK();
  iVar9 = *piVar7;
  if (iVar1 == iVar9) {
    *piVar7 = iVar1 + 1;
    iVar9 = iVar1;
  }
  UNLOCK();
  if (iVar9 == iVar1) {
    iStack_1c = *(int *)(iStack_34 + 0x10);
    piStack_18 = *(int **)(iStack_34 + 0x14);
    goto LAB_00aa4f49;
  }
  iVar1 = *piVar7;
  goto joined_r0x00aa4f29;
LAB_00aa4f49:
  piVar7 = piStack_18;
  uStack_8._0_1_ = 2;
  if (iStack_1c != 0) {
    uStack_30 = 0;
    pfStack_2c = (float *)0x0;
    uVar14 = 0xaa4f6c;
    cVar4 = FUN_00602ce0(iStack_34);
    pfVar10 = pfStack_2c;
    if (cVar4 == '\0') {
      FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_78,&DAT_01c21d80);
    }
    uVar15 = 1;
    uStack_8._0_1_ = 3;
    if (pfStack_2c != (float *)0x0) {
      LOCK();
      pfStack_2c[1] = (float)((int)pfStack_2c[1] + 1);
      UNLOCK();
    }
    FUN_00a9f270(uStack_30,pfStack_2c,uStack_14,0);
    FUN_0090ca30(in_stack_fffffe14,in_stack_fffffe18,in_stack_fffffe1c,iVar11,pfVar12,puVar13,puVar5
                 ,uVar14,uVar15);
    if (pfVar10 != (float *)0x0) {
      LOCK();
      fVar2 = (float)((int)pfVar10[1] + -1);
      pfVar10[1] = fVar2;
      UNLOCK();
      if (fVar2 == 0.0) {
        (**(code **)*pfVar10)();
        LOCK();
        fVar2 = (float)((int)pfVar10[2] + -1);
        pfVar10[2] = fVar2;
        UNLOCK();
        if (fVar2 == 0.0) {
          (**(code **)((int)*pfVar10 + 4))();
        }
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar9 = piVar7[1] + -1;
    piVar7[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      iVar9 = piVar7[2] + -1;
      piVar7[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
LAB_00aa4eb2:
  piVar7 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar9 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar8 = piVar7 + 2;
      iVar9 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
LAB_00aa4ed7:
  FUN_00aa13b0();
LAB_00aa4ee2:
  *(uint *)(iStack_34 + 0x34) = uStack_38;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21951 ; VA 0x00aa5040 ; FUN_00aa5040 */

void FUN_00aa5040(int param_1,undefined4 param_2,undefined4 param_3,float *param_4)

{
  float *pfVar1;
  int iVar2;
  float10 fVar3;
  double dVar4;
  float fVar5;
  char cStack_f1;
  float fStack_f0;
  float fStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  float fStack_dc;
  undefined4 uStack_d8;
  int iStack_d4;
  double dStack_d0;
  float afStack_c8 [2];
  undefined auStack_c0 [188];
  
  pfVar1 = *(float **)(*(int *)(param_1 + 4) + -8);
  dVar4 = (double)((pfVar1[1] - param_4[1]) * (pfVar1[1] - param_4[1]) +
                   (*pfVar1 - *param_4) * (*pfVar1 - *param_4) +
                  (pfVar1[2] - param_4[2]) * (pfVar1[2] - param_4[2]));
  FUN_017267a0();
  fStack_f0 = (float)dVar4;
  if (fStack_f0 <= 0.0) {
    fStack_ec = DAT_018e3f8c;
  }
  else {
    dStack_d0 = (double)(fStack_f0 * DAT_018e1340);
    fVar3 = (float10)FUN_01725160(dStack_d0);
    dStack_d0 = (double)fVar3;
    fStack_ec = fStack_f0 / (float)fVar3;
  }
  iVar2 = 0x10;
  do {
    FUN_005502b0();
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  if (fStack_ec < fStack_f0) {
    fStack_f0 = *param_4;
    fStack_e8 = param_4[2];
    do {
      pfVar1 = *(float **)(*(int *)(param_1 + 4) + -8);
      afStack_c8[1] = pfVar1[1];
      fStack_f0 = fStack_f0 - *pfVar1;
      afStack_c8[0] = param_4[1] - afStack_c8[1];
      fStack_e8 = fStack_e8 - pfVar1[2];
      dStack_d0 = (double)CONCAT44(dStack_d0._4_4_,pfVar1[2]);
      dVar4 = (double)(afStack_c8[0] * afStack_c8[0] + fStack_f0 * fStack_f0 + fStack_e8 * fStack_e8
                      );
      FUN_017267a0();
      fVar5 = DAT_018ce2f8 / (float)dVar4;
      fStack_e4 = fVar5 * fStack_f0 * fStack_ec + *pfVar1;
      fStack_e0 = afStack_c8[0] * fVar5 * fStack_ec + afStack_c8[1];
      fStack_dc = fStack_e8 * fVar5 * fStack_ec + dStack_d0._0_4_;
      FUN_01272580(pfVar1 + 4,pfVar1,&fStack_e4,param_3,&fStack_e4,&cStack_f1,auStack_c0,&iStack_d4,
                   0x10);
      if (cStack_f1 == '\0') {
        return;
      }
      uStack_d8 = 0;
      FUN_01271b20(afStack_c8 + iStack_d4 * 2,&fStack_e4,&uStack_d8);
      fStack_e0 = (float)uStack_d8;
      FUN_00aa1760(&fStack_e4,0,afStack_c8 + iStack_d4 * 2,1);
      fStack_f0 = *param_4;
      fStack_e8 = param_4[2];
      dVar4 = (double)((fStack_dc - fStack_e8) * (fStack_dc - fStack_e8) +
                      (fStack_e4 - fStack_f0) * (fStack_e4 - fStack_f0));
      FUN_017267a0();
    } while (fStack_ec < (float)dVar4);
  }
  return;
}



/* FUNCTION 21952 ; VA 0x00aa52d0 ; FUN_00aa52d0 */

int * __fastcall FUN_00aa52d0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = thunk_FUN_00896ba0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_00aa5356:
    thunk_FUN_00896ba0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00aa5740(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_00aa5356;
    FUN_00895170(&piStack_8);
    iVar4 = thunk_FUN_00896ba0();
    *param_1 = iVar4;
    iVar2 = thunk_FUN_00896ba0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21953 ; VA 0x00aa5390 ; FUN_00aa5390 */

undefined4 * __fastcall FUN_00aa5390(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470(&DAT_019474ec);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_G3D::Vector3::Axis>::vftable;
  FUN_009caf20(&DAT_01d6654c,3);
  FUN_009cad30(&DAT_01d66564,6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21954 ; VA 0x00aa5400 ; FUN_00aa5400 */

int FUN_00aa5400(uint param_1)

{
  if (param_1 < 3) {
    return 1 << ((byte)param_1 & 0x1f);
  }
  return 0;
}



/* FUNCTION 21955 ; VA 0x00aa5420 ; FUN_00aa5420 */

undefined4 FUN_00aa5420(int param_1)

{
  if (param_1 == 0) {
    return 0;
  }
  if (param_1 != 1) {
    if (param_1 != 2) {
      return 6;
    }
    return 2;
  }
  return 1;
}



/* FUNCTION 21956 ; VA 0x00aa5450 ; FUN_00aa5450 */

undefined * FUN_00aa5450(undefined *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  uint uVar4;
  undefined1 *puVar5;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e59a1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 1;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uVar3 = 0;
  uStack_14 = 1;
  uVar4 = 1;
  do {
    uVar1 = uVar4;
    if (2 < uVar3) {
      uVar1 = 0;
    }
    if ((*param_2 & uVar1) != 0) {
      ppppuVar2 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_00554150(ppppuVar2,uStack_1c);
      if (uVar3 == 0) {
        puVar5 = &DAT_0191c6d0;
LAB_00aa5525:
        FUN_00554150(puVar5,1);
      }
      else {
        if (uVar3 == 1) {
          puVar5 = &DAT_0191c6d4;
          goto LAB_00aa5525;
        }
        if (uVar3 == 2) {
          puVar5 = &DAT_0191c6d8;
          goto LAB_00aa5525;
        }
      }
      FUN_005542c0(&DAT_018cecfc,2);
    }
    uVar3 = uVar3 + 1;
    uVar4 = uVar4 << 1 | (uint)((int)uVar4 < 0);
    if (2 < (int)uVar3) {
      if (0xf < uStack_18) {
        uVar3 = uStack_18 + 1;
        ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
        if (0xfff < uVar3) {
          ppppuVar2 = (undefined4 ****)apppuStack_2c[0][-1];
          uVar3 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar2,uVar3);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 21957 ; VA 0x00aa5590 ; FUN_00aa5590 */

undefined FUN_00aa5590(undefined4 *param_1,uint *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined1 *puVar3;
  undefined1 **ppuVar4;
  uint uVar5;
  undefined1 *puVar6;
  uint uVar7;
  undefined uVar8;
  undefined1 *puVar9;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined1 *puStack_30;
  int iStack_2c;
  undefined1 *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined1 *puStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f08;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  puStack_1c = (undefined1 *)param_1[4];
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar8 = 0;
  puStack_20 = param_1;
  while( true ) {
    do {
      if (puStack_1c == (undefined1 *)0x0) {
        ExceptionList = pvStack_10;
        return uVar8;
      }
      puVar3 = (undefined1 *)FUN_01683820(&DAT_018cecfc,2,0);
      puVar1 = puStack_20;
      puVar9 = puStack_1c;
      if (puVar3 == (undefined1 *)0xffffffff) {
        ppuVar4 = &puStack_28;
        puStack_28 = &DAT_018bc9b8;
        uStack_24 = 0;
      }
      else {
        if (puVar3 <= puStack_1c) {
          puVar9 = puVar3;
        }
        puVar6 = puStack_1c;
        if (puVar3 + 1 <= puStack_1c) {
          puVar6 = puVar3 + 1;
        }
        iStack_2c = -1;
        if ((int)puStack_1c - (int)puVar6 != -1) {
          iStack_2c = (int)puStack_1c - (int)puVar6;
        }
        ppuVar4 = &puStack_30;
        puStack_30 = puVar6 + (int)puStack_20;
      }
      puStack_20 = (undefined4 *)*ppuVar4;
      puStack_1c = ppuVar4[1];
    } while (puVar9 == (undefined1 *)0x0);
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    if (puVar1 != (undefined4 *)0x0) {
      FUN_005542c0(puVar1,puVar9);
    }
    uStack_8 = 0;
    cVar2 = FUN_00aa5740(auStack_48,&uStack_14);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      uVar5 = auStack_48[0];
      if (0xfff < uVar7) {
        uVar5 = *(uint *)(auStack_48[0] - 4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar7);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    if (cVar2 == '\0') break;
    if (uStack_14 < 3) {
      uVar8 = 1;
      *param_2 = *param_2 | 1 << ((byte)uStack_14 & 0x1f);
    }
    else {
      uVar8 = 1;
      *param_2 = *param_2;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 21958 ; VA 0x00aa5740 ; FUN_00aa5740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aa5740(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e73f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf314) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf314);
    if (DAT_01edf314 == -1) {
      uStack_8 = 0;
      FUN_009ca470(&DAT_019474ec);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edf2b0 = RBX::Reflection::EnumDesc<enum_G3D::Vector3::Axis>::vftable;
      FUN_009caf20(&DAT_01d6654c,3);
      FUN_009cad30(&DAT_01d66564,6);
      FUN_016f3654(&LAB_01880b90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf314);
    }
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_009cb180(param_1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21959 ; VA 0x00aa5820 ; FUN_00aa5820 */

undefined4 __thiscall FUN_00aa5820(uint *param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = 1 << ((byte)param_2 & 0x1f);
  if (2 < param_2) {
    uVar1 = 0;
  }
  return CONCAT31((int3)(uVar1 >> 8),(*param_1 & uVar1) != 0);
}



/* FUNCTION 21960 ; VA 0x00aa5850 ; FUN_00aa5850 */

bool __thiscall FUN_00aa5850(uint *param_1,undefined4 param_2)

{
  switch(param_2) {
  case 0:
  case 3:
    return (*param_1 & 1) != 0;
  case 1:
  case 4:
    return (*param_1 & 2) != 0;
  case 2:
  case 5:
    return (*param_1 & 4) != 0;
  default:
    return false;
  }
}



/* FUNCTION 21961 ; VA 0x00aa58b0 ; FUN_00aa58b0 */

undefined4 FUN_00aa58b0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
  case 3:
    return 0;
  case 1:
  case 4:
    return 1;
  case 2:
  case 5:
    return 2;
  default:
    return 0xffffffff;
  }
}



/* FUNCTION 21962 ; VA 0x00aa5900 ; FUN_00aa5900 */

undefined4
FUN_00aa5900(uint *param_1,uint param_2,byte *param_3,uint param_4,undefined4 param_5,int param_6)

{
  byte *pbVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  uint uStack_48;
  uint uStack_44;
  uint *puStack_40;
  uint *puStack_3c;
  uint *puStack_38;
  uint uStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  if (2 < param_4) {
    uStack_8 = 0;
    uStack_44 = 0;
    uStack_c = 0;
    puStack_38 = (uint *)((param_2 - 4) + (int)param_1);
    uStack_48 = 0;
    puStack_40 = param_1;
    puStack_3c = param_1;
    if (4 < param_2) {
      if ((param_4 & 1) == 0) {
        FUN_00ab1270(&uStack_34,param_5,param_3[param_4 - 1]);
        pbVar7 = param_3 + (param_4 - 2);
        FUN_00ab1270(&uStack_24,param_5,param_3[param_4 - 2]);
        uVar5 = 0;
      }
      else {
        FUN_00ab1270(&uStack_24,param_5,param_3[param_4 - 1]);
        FUN_00ab1270(&uStack_34,param_5,param_3[param_4 - 2]);
        pbVar7 = param_3 + (param_4 - 3);
        FUN_00ab11c0(&uStack_48,&uStack_24,param_3[param_4 - 3]);
        if (param_6 == 0) {
          FUN_00ab00f0(&uStack_48);
          param_1 = puStack_3c;
          uStack_8 = uStack_44;
          uStack_c = uStack_48;
          uVar5 = uStack_44;
        }
        else {
          uStack_8 = uStack_44 & 7;
          *puStack_3c = uStack_48;
          param_1 = (uint *)((int)puStack_3c + (uStack_44 >> 3));
          uStack_48 = uStack_48 >> ((byte)((uStack_44 >> 3) << 3) & 0x1f);
          uVar5 = uStack_8;
          uStack_44 = uStack_8;
          puStack_3c = param_1;
          uStack_c = uStack_48;
        }
      }
      if (param_3 < pbVar7) {
        uStack_10 = uStack_24;
        param_4 = uStack_34;
        do {
          pbVar1 = pbVar7 + -1;
          pbVar7 = pbVar7 + -2;
          uVar3 = param_4 + *(int *)(iStack_2c + 4 + (uint)*pbVar1 * 8);
          uVar4 = uVar3 >> 0x10;
          iStack_14 = uVar5 + uVar4;
          uVar6 = *(uint *)(&DAT_01948670 + uVar4 * 4) & param_4;
          param_4 = (uint)*(ushort *)
                           (iStack_30 +
                           (((int)param_4 >> ((byte)(uVar3 >> 0x10) & 0x1f)) +
                           *(int *)(iStack_2c + (uint)*pbVar1 * 8)) * 2);
          uVar3 = uStack_10 + *(int *)(iStack_1c + 4 + (uint)*pbVar7 * 8);
          uVar4 = uVar3 >> 0x10;
          uVar5 = iStack_14 + uVar4;
          uStack_c = uVar6 << ((byte)uStack_8 & 0x1f) |
                     (*(uint *)(&DAT_01948670 + uVar4 * 4) & uStack_10) << ((byte)iStack_14 & 0x1f)
                     | uStack_c;
          uStack_24 = (uint)*(ushort *)
                             (iStack_20 +
                             (((int)uStack_10 >> ((byte)(uVar3 >> 0x10) & 0x1f)) +
                             *(int *)(iStack_1c + (uint)*pbVar7 * 8)) * 2);
          uVar3 = uVar5 >> 3;
          if (param_6 == 0) {
            *param_1 = uStack_c;
            puStack_3c = (uint *)((int)param_1 + uVar3);
            if (puStack_38 < puStack_3c) {
              puStack_3c = puStack_38;
            }
          }
          else {
            *param_1 = uStack_c;
            puStack_3c = (uint *)((int)param_1 + uVar3);
          }
          uVar5 = uVar5 & 7;
          uStack_48 = uStack_c >> ((byte)(uVar3 << 3) & 0x1f);
          param_1 = puStack_3c;
          uStack_44 = uVar5;
          uStack_34 = param_4;
          uStack_10 = uStack_24;
          uStack_c = uStack_48;
          uStack_8 = uVar5;
        } while (param_3 < pbVar7);
      }
      FUN_00ab1220(&uStack_48,&uStack_34);
      FUN_00ab1220(&uStack_48,&uStack_24);
      uVar2 = FUN_00ab0060(&uStack_48);
      return uVar2;
    }
  }
  return 0;
}



/* FUNCTION 21963 ; VA 0x00aa5b20 ; FUN_00aa5b20 */

uint FUN_00aa5b20(int *param_1,uint *param_2,uint *param_3,int param_4,int param_5,int *param_6)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint *puVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  int *piVar12;
  int *piVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  
  puVar8 = (uint *)((int)param_3 + param_4);
  uVar14 = *param_2;
  piVar2 = param_6 + 0x200;
  FUN_0170d1f0(param_6,0,0x1000);
  if (param_4 == 0) {
    FUN_0170d1f0(param_1,0,uVar14 + 1);
    *param_2 = 0;
    return 0;
  }
  if (uVar14 == 0) {
    uVar14 = 0xff;
  }
  uVar9 = *param_3;
  for (param_3 = param_3 + 1; param_3 < (uint *)((int)puVar8 + -0xf); param_3 = param_3 + 4) {
    uVar11 = *param_3;
    param_6[uVar9 & 0xff] = param_6[uVar9 & 0xff] + 1;
    param_6[(uVar9 >> 8 & 0xff) + 0x100] = param_6[(uVar9 >> 8 & 0xff) + 0x100] + 1;
    piVar2[uVar9 >> 0x10 & 0xff] = piVar2[uVar9 >> 0x10 & 0xff] + 1;
    param_6[(uVar9 >> 0x18) + 0x300] = param_6[(uVar9 >> 0x18) + 0x300] + 1;
    uVar9 = param_3[1];
    param_6[uVar11 & 0xff] = param_6[uVar11 & 0xff] + 1;
    param_6[(uVar11 >> 8 & 0xff) + 0x100] = param_6[(uVar11 >> 8 & 0xff) + 0x100] + 1;
    piVar2[uVar11 >> 0x10 & 0xff] = piVar2[uVar11 >> 0x10 & 0xff] + 1;
    param_6[(uVar11 >> 0x18) + 0x300] = param_6[(uVar11 >> 0x18) + 0x300] + 1;
    uVar11 = param_3[2];
    param_6[uVar9 & 0xff] = param_6[uVar9 & 0xff] + 1;
    param_6[(uVar9 >> 8 & 0xff) + 0x100] = param_6[(uVar9 >> 8 & 0xff) + 0x100] + 1;
    piVar2[uVar9 >> 0x10 & 0xff] = piVar2[uVar9 >> 0x10 & 0xff] + 1;
    param_6[(uVar9 >> 0x18) + 0x300] = param_6[(uVar9 >> 0x18) + 0x300] + 1;
    uVar9 = param_3[3];
    param_6[uVar11 & 0xff] = param_6[uVar11 & 0xff] + 1;
    param_6[(uVar11 >> 8 & 0xff) + 0x100] = param_6[(uVar11 >> 8 & 0xff) + 0x100] + 1;
    piVar2[uVar11 >> 0x10 & 0xff] = piVar2[uVar11 >> 0x10 & 0xff] + 1;
    param_6[(uVar11 >> 0x18) + 0x300] = param_6[(uVar11 >> 0x18) + 0x300] + 1;
  }
  param_3 = param_3 + -1;
  uVar11 = 0;
  uVar9 = (int)puVar8 - (int)param_3;
  if (puVar8 < param_3) {
    uVar9 = 0;
  }
  if (uVar9 != 0) {
    do {
      bVar4 = *(byte *)param_3;
      param_3 = (uint *)((int)param_3 + 1);
      uVar11 = uVar11 + 1;
      param_6[bVar4] = param_6[bVar4] + 1;
    } while (uVar11 < uVar9);
  }
  piVar12 = param_6 + 0x100;
  if ((param_5 != 0) && (param_3 = (uint *)0xff, uVar14 < 0xff)) {
    piVar10 = param_6 + 0x2ff;
    do {
      piVar13 = (int *)(((int)param_6 - (int)piVar2) + (int)piVar10);
      *piVar13 = *piVar13 + piVar10[0x100] + piVar10[-0x100] + *piVar10;
      if (*piVar13 != 0) {
        return 0xffffffd0;
      }
      piVar10 = piVar10 + -1;
      param_3 = (uint *)((int)param_3 - 1);
    } while (uVar14 < param_3);
  }
  param_3 = (uint *)0x0;
  if ((uVar14 + 1 < 8) || (DAT_021137e0 < 2)) {
    uVar9 = 0;
  }
  else {
    param_3 = (uint *)0x0;
    if (((((param_6 + uVar14 < param_1) || (param_1 + uVar14 < param_6)) &&
         ((piVar12 + uVar14 < param_1 || (param_1 + uVar14 < piVar12)))) &&
        ((piVar2 + uVar14 < param_1 || (param_1 + uVar14 < piVar2)))) &&
       ((piVar2 + uVar14 + 0x100 < param_1 || (param_1 + uVar14 < param_6 + 0x300)))) {
      uVar9 = 0;
      uVar11 = 0;
      uVar20 = 0;
      uVar21 = 0;
      uVar22 = 0;
      uVar23 = 0;
      uVar24 = 0;
      uVar25 = 0;
      piVar10 = param_6 + 0x204;
      piVar13 = piVar12;
      do {
        piVar1 = piVar13 + 8;
        param_3 = (uint *)((int)param_3 + 8);
        piVar3 = (int *)((int)param_6 + (0xbe0 - (int)piVar12) + (int)piVar1);
        uVar16 = *piVar3 + piVar10[-4] + *piVar13 + piVar13[-0x100];
        uVar17 = piVar3[1] + piVar10[-3] + piVar13[1] + piVar13[-0xff];
        uVar18 = piVar3[2] + piVar10[-2] + piVar13[2] + piVar13[-0xfe];
        uVar19 = piVar3[3] + piVar10[-1] + piVar13[3] + piVar13[-0xfd];
        iVar15 = *piVar10;
        iVar5 = piVar10[1];
        iVar6 = piVar10[2];
        iVar7 = piVar10[3];
        puVar8 = (uint *)((int)param_1 + (-0x20 - (int)piVar12) + (int)piVar1);
        *puVar8 = uVar16;
        puVar8[1] = uVar17;
        puVar8[2] = uVar18;
        puVar8[3] = uVar19;
        uVar9 = (uVar9 < uVar16) * uVar16 | (uVar9 >= uVar16) * uVar9;
        uVar11 = (uVar11 < uVar17) * uVar17 | (uVar11 >= uVar17) * uVar11;
        uVar20 = (uVar20 < uVar18) * uVar18 | (uVar20 >= uVar18) * uVar20;
        uVar21 = (uVar21 < uVar19) * uVar19 | (uVar21 >= uVar19) * uVar21;
        piVar13 = (int *)((int)piVar10 + (int)param_6 + (0xc00 - (int)piVar2));
        piVar3 = (int *)((int)piVar10 + ((int)param_6 - (int)piVar2));
        uVar16 = *piVar13 + iVar15 + piVar10[-0x100] + *piVar3;
        uVar17 = piVar13[1] + iVar5 + piVar10[-0xff] + piVar3[1];
        uVar18 = piVar13[2] + iVar6 + piVar10[-0xfe] + piVar3[2];
        uVar19 = piVar13[3] + iVar7 + piVar10[-0xfd] + piVar3[3];
        puVar8 = (uint *)((int)param_1 + (-0x20 - (int)piVar2) + (int)(piVar10 + 8));
        *puVar8 = uVar16;
        puVar8[1] = uVar17;
        puVar8[2] = uVar18;
        puVar8[3] = uVar19;
        uVar22 = (uVar22 < uVar16) * uVar16 | (uVar22 >= uVar16) * uVar22;
        uVar23 = (uVar23 < uVar17) * uVar17 | (uVar23 >= uVar17) * uVar23;
        uVar24 = (uVar24 < uVar18) * uVar18 | (uVar24 >= uVar18) * uVar24;
        uVar25 = (uVar25 < uVar19) * uVar19 | (uVar25 >= uVar19) * uVar25;
        piVar10 = piVar10 + 8;
        piVar13 = piVar1;
      } while (param_3 <= uVar14 - (uVar14 + 1 & 7));
      uVar9 = (uVar9 < uVar22) * uVar22 | (uVar9 >= uVar22) * uVar9;
      uVar11 = (uVar11 < uVar23) * uVar23 | (uVar11 >= uVar23) * uVar11;
      uVar20 = (uVar20 < uVar24) * uVar24 | (uVar20 >= uVar24) * uVar20;
      uVar21 = (uVar21 < uVar25) * uVar25 | (uVar21 >= uVar25) * uVar21;
      uVar9 = (uVar9 < uVar20) * uVar20 | (uVar9 >= uVar20) * uVar9;
      uVar11 = (uVar11 < uVar21) * uVar21 | (uVar11 >= uVar21) * uVar11;
      uVar9 = (uVar9 < uVar11) * uVar11 | (uVar9 >= uVar11) * uVar9;
      if (uVar14 < param_3) goto LAB_00aa5ef2;
    }
    else {
      uVar9 = 0;
    }
  }
  iVar15 = (uVar14 - (int)param_3) + 1;
  piVar12 = piVar2 + (int)param_3;
  uVar11 = uVar9;
  do {
    uVar9 = *piVar12 +
            *(int *)((int)piVar12 + ((int)param_6 - (int)piVar2)) + piVar12[0x100] + piVar12[-0x100]
    ;
    *(uint *)((int)piVar12 + ((int)param_1 - (int)piVar2)) = uVar9;
    if (uVar9 <= uVar11) {
      uVar9 = uVar11;
    }
    iVar15 = iVar15 + -1;
    piVar12 = piVar12 + 1;
    uVar11 = uVar9;
  } while (iVar15 != 0);
LAB_00aa5ef2:
  iVar15 = param_1[uVar14];
  while (iVar15 == 0) {
    uVar14 = uVar14 - 1;
    iVar15 = param_1[uVar14];
  }
  *param_2 = uVar14;
  return uVar9;
}



/* FUNCTION 21964 ; VA 0x00aa5f10 ; FUN_00aa5f10 */

undefined4 FUN_00aa5f10(int param_1,uint param_2,int param_3,uint param_4,uint param_5)

{
  short *psVar1;
  short sVar2;
  longlong lVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  byte bVar9;
  uint uVar10;
  uint uVar11;
  bool bVar12;
  ulonglong uVar13;
  uint uStack_18;
  int iStack_14;
  
  bVar9 = (byte)param_2;
  uVar4 = param_4 >> (bVar9 & 0x1f);
  uVar10 = 0;
  uVar5 = param_4 * 3 >> (bVar9 + 1 & 0x1f);
  uVar6 = 0;
  do {
    uVar11 = *(uint *)(param_3 + uVar6 * 4);
    if (uVar11 == 0) {
LAB_00aa5f78:
      *(short *)(param_1 + uVar6 * 2) = (short)uVar11;
    }
    else if (uVar4 < uVar11) {
      if (uVar5 < uVar11) {
        uVar11 = 0xfffffffe;
        goto LAB_00aa5f78;
      }
      uVar10 = uVar10 + 1;
      *(undefined2 *)(param_1 + uVar6 * 2) = 1;
      param_4 = param_4 - *(int *)(param_3 + uVar6 * 4);
    }
    else {
      uVar10 = uVar10 + 1;
      *(undefined2 *)(param_1 + uVar6 * 2) = 0xffff;
      param_4 = param_4 - *(int *)(param_3 + uVar6 * 4);
    }
    uVar6 = uVar6 + 1;
    if (param_5 < uVar6) {
      iVar7 = 1 << (bVar9 & 0x1f);
      uVar4 = iVar7 - uVar10;
      if (uVar5 < param_4 / uVar4) {
        uVar5 = param_4 * 3;
        uVar6 = 0;
        do {
          if ((*(short *)(param_1 + uVar6 * 2) == -2) &&
             (*(uint *)(param_3 + uVar6 * 4) <= uVar5 / (uVar4 * 2))) {
            uVar10 = uVar10 + 1;
            *(undefined2 *)(param_1 + uVar6 * 2) = 1;
            param_4 = param_4 - *(int *)(param_3 + uVar6 * 4);
          }
          uVar6 = uVar6 + 1;
        } while (uVar6 <= param_5);
        uVar4 = iVar7 - uVar10;
      }
      if (uVar10 == param_5 + 1) {
        uVar10 = 0;
        uVar5 = 0;
        uVar6 = 0;
        do {
          uVar11 = *(uint *)(param_3 + uVar10 * 4);
          uVar8 = uVar10;
          if (uVar11 <= uVar6) {
            uVar8 = uVar5;
          }
          uVar10 = uVar10 + 1;
          if (uVar11 <= uVar6) {
            uVar11 = uVar6;
          }
          uVar5 = uVar8;
          uVar6 = uVar11;
        } while (uVar10 <= param_5);
        psVar1 = (short *)(param_1 + uVar8 * 2);
        *psVar1 = *psVar1 + (short)uVar4;
      }
      else {
        if (param_4 != 0) {
          uVar11 = -param_2 + 0x3e;
          uVar5 = -param_2 + 0x3d;
          uVar6 = 1 << (uVar5 & 0x1f);
          uVar10 = 0;
          if (0x1f < uVar5) {
            uVar10 = uVar6;
          }
          uVar6 = uVar6 ^ uVar10;
          if (0x3f < uVar5) {
            uVar10 = uVar6;
          }
          param_2 = uVar6 - 1;
          iStack_14 = (uVar10 - 1) + (uint)(uVar6 != 0);
          uVar5 = 1 << (uVar11 & 0x1f);
          uVar6 = 0;
          if (0x1f < uVar11) {
            uVar6 = uVar5;
          }
          uVar5 = uVar5 ^ uVar6;
          if (0x3f < uVar11) {
            uVar6 = uVar5;
          }
          lVar3 = (ulonglong)uVar5 * (ulonglong)uVar4;
          uVar5 = (uint)lVar3;
          uVar13 = FUN_016f3c60(uVar5 + param_2,
                                uVar6 * uVar4 + (int)((ulonglong)lVar3 >> 0x20) + iStack_14 +
                                (uint)CARRY4(uVar5,param_2),param_4,0);
          uVar4 = 0;
          param_4 = iStack_14;
          uStack_18 = param_2;
          do {
            if (*(short *)(param_1 + uVar4 * 2) == -2) {
              uVar5 = *(uint *)(param_3 + uVar4 * 4);
              lVar3 = (uVar13 & 0xffffffff) * (ulonglong)uVar5;
              uVar6 = (uint)lVar3;
              bVar12 = CARRY4(uVar6,param_2);
              param_2 = uVar6 + param_2;
              param_4 = (int)(uVar13 >> 0x20) * uVar5 + (int)((ulonglong)lVar3 >> 0x20) + param_4 +
                        (uint)bVar12;
              iVar7 = (int)(CONCAT44(param_4,param_2) >> (ulonglong)uVar11) -
                      (int)(CONCAT44(iStack_14,uStack_18) >> (ulonglong)uVar11);
              if (iVar7 == 0) {
                return 0xffffffff;
              }
              *(short *)(param_1 + uVar4 * 2) = (short)iVar7;
              uStack_18 = param_2;
              iStack_14 = param_4;
            }
            uVar4 = uVar4 + 1;
          } while (uVar4 <= param_5);
          return 0;
        }
        uVar5 = 0;
        if (uVar4 != 0) {
          do {
            sVar2 = *(short *)(param_1 + uVar5 * 2);
            if (0 < sVar2) {
              uVar4 = uVar4 - 1;
              *(short *)(param_1 + uVar5 * 2) = sVar2 + 1;
            }
            uVar5 = (uVar5 + 1) % (param_5 + 1);
          } while (uVar4 != 0);
          return 0;
        }
      }
      return 0;
    }
  } while( true );
}



/* FUNCTION 21965 ; VA 0x00aa6170 ; FUN_00aa6170 */

undefined *
FUN_00aa6170(undefined *param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  short sVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  bool bVar10;
  int iStack_14;
  int iStack_10;
  undefined *puStack_8;
  
  iVar3 = param_2;
  iStack_10 = 1 << ((byte)param_5 & 0x1f);
  uVar6 = 0;
  uVar8 = param_5 - 5;
  iStack_14 = param_5 + 1;
  param_5 = iStack_10 + 1;
  puStack_8 = param_1;
  iVar5 = 4;
  param_2 = 4;
  if (1 < param_5) {
    bVar10 = false;
    do {
      uVar7 = uVar6;
      if (bVar10) {
        sVar1 = *(short *)(param_3 + uVar6 * 2);
        while (sVar1 == 0) {
          uVar7 = uVar7 + 1;
          sVar1 = *(short *)(param_3 + uVar7 * 2);
        }
        uVar4 = uVar6 + 0x18;
        iVar5 = param_2;
        uVar2 = uVar6;
        if (uVar4 <= uVar7) {
          do {
            uVar8 = uVar8 + (0xffff << ((byte)param_2 & 0x1f));
            uVar4 = uVar4 + 0x18;
            uVar6 = uVar6 + 0x18;
            if ((param_6 == 0) && (param_1 + iVar3 + -2 < puStack_8)) {
              return (undefined *)0xffffffba;
            }
            *puStack_8 = (char)uVar8;
            puStack_8[1] = (char)(uVar8 >> 8);
            puStack_8 = puStack_8 + 2;
            uVar8 = uVar8 >> 0x10;
            uVar2 = uVar6;
          } while (uVar4 <= uVar7);
        }
        while( true ) {
          if (uVar7 < uVar2 + 3) break;
          uVar6 = uVar6 + 3;
          uVar8 = uVar8 + (3 << ((byte)iVar5 & 0x1f));
          iVar5 = iVar5 + 2;
          uVar2 = uVar2 + 3;
        }
        param_2 = iVar5 + 2;
        uVar8 = uVar8 + (uVar7 - uVar6 << ((byte)iVar5 & 0x1f));
        if (0x10 < param_2) {
          if ((param_6 == 0) && (param_1 + iVar3 + -2 < puStack_8)) {
            return (undefined *)0xffffffba;
          }
          *puStack_8 = (char)uVar8;
          puStack_8[1] = (char)(uVar8 >> 8);
          puStack_8 = puStack_8 + 2;
          uVar8 = uVar8 >> 0x10;
          param_2 = iVar5 + -0xe;
        }
      }
      iVar9 = iStack_10 * 2 - param_5;
      uVar4 = (uint)*(short *)(param_3 + uVar7 * 2);
      uVar6 = uVar7 + 1;
      iVar5 = iVar9 + -1;
      param_5 = param_5 - ((uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f));
      if ((int)(uVar4 + 1) < iStack_10) {
        iVar9 = 1;
      }
      iVar9 = iVar9 + uVar4;
      uVar8 = uVar8 + (iVar9 << ((byte)param_2 & 0x1f));
      iVar5 = param_2 + (iStack_14 - (uint)(iVar9 < iVar5));
      bVar10 = iVar9 == 1;
      if (param_5 < 1) {
        return (undefined *)0xffffffff;
      }
      for (; param_5 < iStack_10; iStack_10 = iStack_10 >> 1) {
        iStack_14 = iStack_14 + -1;
      }
      if (0x10 < iVar5) {
        if ((param_6 == 0) && (param_1 + iVar3 + -2 < puStack_8)) {
          return (undefined *)0xffffffba;
        }
        *puStack_8 = (char)uVar8;
        puStack_8[1] = (char)(uVar8 >> 8);
        puStack_8 = puStack_8 + 2;
        uVar8 = uVar8 >> 0x10;
        iVar5 = iVar5 + -0x10;
      }
      param_2 = iVar5;
    } while (1 < param_5);
  }
  if ((param_6 == 0) && (param_1 + iVar3 + -2 < puStack_8)) {
    return (undefined *)0xffffffba;
  }
  *puStack_8 = (char)uVar8;
  puStack_8[1] = (char)(uVar8 >> 8);
  if (param_4 + 1U < uVar6) {
    return (undefined *)0xffffffff;
  }
  return puStack_8 + (((int)(iVar5 + 7 + (iVar5 + 7 >> 0x1f & 7U)) >> 3) - (int)param_1);
}



/* FUNCTION 21966 ; VA 0x00aa63a0 ; FUN_00aa63a0 */

uint FUN_00aa63a0(int param_1,undefined2 *param_2,int param_3,int param_4,uint param_5,int param_6,
                 undefined4 param_7)

{
  undefined2 *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  
  if (param_6 == 0) {
    uVar4 = param_5 + 3 >> 2;
    if ((uint)(param_3 - (int)param_2) < 0x11) {
      uVar2 = 0;
    }
    else if (param_5 < 0xc) {
      uVar2 = 0;
    }
    else {
      puVar1 = param_2 + 3;
      uVar2 = FUN_00ab1bc0(puVar1,param_3 - (int)puVar1,param_4,uVar4,param_7);
      if ((uVar2 < 0xffffff89) && (uVar2 != 0)) {
        iVar5 = (int)puVar1 + uVar2;
        *param_2 = (short)uVar2;
        uVar2 = FUN_00ab1bc0(iVar5,param_3 - iVar5,param_4 + uVar4,uVar4,param_7);
        if ((uVar2 < 0xffffff89) && (uVar2 != 0)) {
          iVar5 = iVar5 + uVar2;
          param_2[1] = (short)uVar2;
          iVar3 = param_4 + uVar4 + uVar4;
          uVar2 = FUN_00ab1bc0(iVar5,param_3 - iVar5,iVar3,uVar4,param_7);
          if ((uVar2 < 0xffffff89) && (uVar2 != 0)) {
            iVar5 = iVar5 + uVar2;
            iVar3 = iVar3 + uVar4;
            param_2[2] = (short)uVar2;
            uVar2 = FUN_00ab1bc0(iVar5,param_3 - iVar5,iVar3,(param_4 + param_5) - iVar3,param_7);
            if ((uVar2 < 0xffffff89) && (uVar2 != 0)) {
              uVar2 = (uVar2 - (int)param_2) + iVar5;
            }
          }
        }
      }
    }
  }
  else {
    uVar2 = FUN_00ab1bc0(param_2,param_3 - (int)param_2,param_4,param_5,param_7);
  }
  if (uVar2 < 0xffffff89) {
    if ((uVar2 != 0) && (uVar4 = (int)param_2 + (uVar2 - param_1), uVar4 < param_5 - 1)) {
      return uVar4;
    }
    uVar2 = 0;
  }
  return uVar2;
}



/* FUNCTION 21967 ; VA 0x00aa64e0 ; FUN_00aa64e0 */

uint FUN_00aa64e0(undefined *param_1,int param_2,undefined *param_3,uint param_4,uint param_5,
                 uint param_6,undefined4 param_7,int param_8,undefined *param_9,undefined4 *param_10
                 ,int *param_11,int param_12)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  char *pcVar12;
  undefined4 *puVar13;
  
  piVar10 = param_11;
  iVar7 = param_8;
  if (param_9 < 0x1800) {
    return 0xffffffff;
  }
  if ((param_4 != 0) && (param_2 != 0)) {
    if (0x20000 < param_4) {
      return 0xffffffb8;
    }
    if (0xc < param_6) {
      return 0xffffffd4;
    }
    if (param_5 == 0) {
      param_5 = 0xff;
    }
    uVar5 = 0xb;
    if (param_6 != 0) {
      uVar5 = param_6;
    }
    param_9 = (undefined *)((int)param_9 - 0x800);
    puVar6 = (undefined4 *)(param_8 + 0x400);
    param_8 = param_8 + 0x800;
    if (((param_12 != 0) && (param_11 != (int *)0x0)) && (*param_11 == 2)) {
LAB_00aa6734:
      uVar5 = FUN_00aa63a0(param_1,param_1,param_1 + param_2,param_3,param_4,param_7,param_10);
      return uVar5;
    }
    uVar4 = FUN_00ab0940(iVar7,&param_5,param_3,param_4,param_8);
    if (0xffffff88 < uVar4) {
      return uVar4;
    }
    if (uVar4 == param_4) {
      *param_1 = *param_3;
      return 1;
    }
    if ((param_4 >> 7) + 1 < uVar4) {
      if (((piVar10 != (int *)0x0) && (*piVar10 == 1)) && (iVar8 = 0, -1 < (int)param_5)) {
        bVar3 = false;
        pcVar12 = (char *)((int)param_10 + 2);
        do {
          iVar1 = iVar8 * 4;
          iVar8 = iVar8 + 1;
          bVar3 = (bool)(bVar3 | (*(int *)(iVar7 + iVar1) != 0 && *pcVar12 == '\0'));
          pcVar12 = pcVar12 + 4;
        } while (iVar8 <= (int)param_5);
        piVar10 = param_11;
        if (bVar3) {
          *param_11 = 0;
        }
      }
      if (((param_12 != 0) && (piVar10 != (int *)0x0)) && (*piVar10 != 0)) goto LAB_00aa6734;
      uVar4 = param_4 - 1;
      iVar8 = 0x1f;
      if (uVar4 != 0) {
        for (; uVar4 >> iVar8 == 0; iVar8 = iVar8 + -1) {
        }
      }
      iVar1 = 0x1f;
      if (uVar4 != 0) {
        for (; uVar4 >> iVar1 == 0; iVar1 = iVar1 + -1) {
        }
      }
      iVar2 = 0x1f;
      if (param_5 != 0) {
        for (; param_5 >> iVar2 == 0; iVar2 = iVar2 + -1) {
        }
      }
      uVar4 = iVar2 + 2U;
      if (iVar1 + 1U < iVar2 + 2U) {
        uVar4 = iVar1 + 1U;
      }
      if (uVar5 == 0) {
        uVar5 = 0xb;
      }
      uVar9 = iVar8 - 1U;
      if (uVar5 <= iVar8 - 1U) {
        uVar9 = uVar5;
      }
      if (uVar4 <= uVar9) {
        uVar4 = uVar9;
      }
      if (uVar4 < 5) {
        uVar4 = 5;
      }
      else if (0xc < uVar4) {
        uVar4 = 0xc;
      }
      param_9 = (undefined *)FUN_00ab1830(puVar6,iVar7,param_5,uVar4,param_8,param_9);
      if (0xffffff88 < param_9) {
        return (uint)param_9;
      }
      FUN_0170d1f0(iVar7 + 0x404 + param_5 * 4,0,(0xff - param_5) * 4);
      param_9 = (undefined *)FUN_00ab2530(param_1,param_2,puVar6,param_5,param_9);
      if (0xffffff88 < param_9) {
        return (uint)param_9;
      }
      if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
        iVar8 = FUN_00aa81d0(puVar6,iVar7,param_5);
        uVar5 = FUN_00aa81d0(param_10,iVar7,param_5);
        if ((uVar5 <= (uint)(iVar8 + (int)param_9)) ||
           (piVar10 = param_11, param_4 <= (int)param_9 + 0xcU)) goto LAB_00aa6734;
      }
      if ((int)param_9 + 0xcU < param_4) {
        param_9 = param_1 + (int)param_9;
        if (piVar10 != (int *)0x0) {
          *piVar10 = 0;
        }
        if (param_10 != (undefined4 *)0x0) {
          puVar11 = puVar6;
          puVar13 = param_10;
          for (iVar7 = 0x100; iVar7 != 0; iVar7 = iVar7 + -1) {
            *puVar13 = *puVar11;
            puVar11 = puVar11 + 1;
            puVar13 = puVar13 + 1;
          }
        }
        uVar5 = FUN_00aa63a0(param_1,param_9,param_1 + param_2,param_3,param_4,param_7,puVar6);
        return uVar5;
      }
    }
  }
  return 0;
}



/* FUNCTION 21968 ; VA 0x00aa67c0 ; FUN_00aa67c0 */

undefined4 FUN_00aa67c0(undefined *param_1,int *param_2,int param_3,char param_4)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (uint)(*param_2 << ((byte)param_2[1] & 0x1f)) >> (-param_4 & 0x1fU);
  iVar1 = param_3 + uVar2 * 4;
  *param_1 = *(undefined *)(param_3 + uVar2 * 4);
  if (*(char *)(iVar1 + 3) == '\x01') {
    param_2[1] = param_2[1] + (uint)*(byte *)(iVar1 + 2);
    return 1;
  }
  if ((uint)param_2[1] < 0x20) {
    uVar2 = (uint)*(byte *)(iVar1 + 2) + param_2[1];
    if (0x20 < uVar2) {
      uVar2 = 0x20;
    }
    param_2[1] = uVar2;
  }
  return 1;
}



/* FUNCTION 21969 ; VA 0x00aa6830 ; FUN_00aa6830 */

undefined FUN_00aa6830(int *param_1,int param_2,char param_3)

{
  undefined uVar1;
  uint uVar2;
  
  uVar2 = (uint)(*param_1 << ((byte)param_1[1] & 0x1f)) >> (-param_3 & 0x1fU);
  uVar1 = *(undefined *)(param_2 + uVar2 * 2);
  param_1[1] = param_1[1] + (uint)*(byte *)(param_2 + 1 + uVar2 * 2);
  return uVar1;
}



/* FUNCTION 21970 ; VA 0x00aa6860 ; FUN_00aa6860 */

undefined FUN_00aa6860(undefined2 *param_1,int *param_2,int param_3,char param_4)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (uint)(*param_2 << ((byte)param_2[1] & 0x1f)) >> (-param_4 & 0x1fU);
  iVar1 = param_3 + uVar2 * 4;
  *param_1 = *(undefined2 *)(param_3 + uVar2 * 4);
  param_2[1] = param_2[1] + (uint)*(byte *)(iVar1 + 2);
  return *(undefined *)(iVar1 + 3);
}



/* FUNCTION 21971 ; VA 0x00aa68a0 ; FUN_00aa68a0 */

uint FUN_00aa68a0(undefined *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  byte bVar1;
  undefined4 uVar2;
  uint uVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  undefined *puVar7;
  bool bVar8;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  undefined4 *puStack_10;
  undefined *puStack_8;
  
  puVar7 = param_1;
  puStack_8 = param_1 + param_2;
  uVar2 = *param_5;
  puStack_10 = param_5 + 1;
  uVar3 = FUN_00ab0130(&iStack_28,param_3,param_4);
  if (0xffffff88 < uVar3) {
    return uVar3;
  }
  param_1 = (undefined *)iStack_28;
  bVar4 = -(char)((uint)uVar2 >> 0x10) & 0x1f;
  while (uStack_24 < 0x21) {
    if (piStack_20 < piStack_18) {
      if (piStack_20 == piStack_1c) break;
      uVar3 = uStack_24 >> 3;
      bVar8 = (int *)((int)piStack_20 - uVar3) < piStack_1c;
      if (bVar8) {
        uVar3 = (int)piStack_20 - (int)piStack_1c;
      }
      piStack_20 = (int *)((int)piStack_20 - uVar3);
      uStack_24 = uStack_24 + uVar3 * -8;
      param_1 = (undefined *)*piStack_20;
      if (bVar8) break;
    }
    else {
      piStack_20 = (int *)((int)piStack_20 - (uStack_24 >> 3));
      uStack_24 = uStack_24 & 7;
      param_1 = (undefined *)*piStack_20;
    }
    if (puStack_8 + -4 < puVar7) break;
    uVar3 = (uint)((int)param_1 << ((byte)uStack_24 & 0x1f)) >> bVar4;
    iVar5 = *(byte *)((int)puStack_10 + uVar3 * 2 + 1) + uStack_24;
    *puVar7 = *(undefined *)((int)puStack_10 + uVar3 * 2);
    uVar3 = (uint)((int)param_1 << ((byte)iVar5 & 0x1f)) >> bVar4;
    bVar1 = *(byte *)((int)puStack_10 + uVar3 * 2 + 1);
    puVar7[1] = *(undefined *)((int)puStack_10 + uVar3 * 2);
    puVar7 = puVar7 + 2;
    uStack_24 = (uint)bVar1 + iVar5;
  }
  do {
    if (0x20 < uStack_24) {
LAB_00aa6a1b:
      uVar3 = (int)puStack_8 - (int)puVar7;
      uStack_14 = 0;
      if (puStack_8 < puVar7) {
        uVar3 = 0;
      }
      if (uVar3 != 0) {
        do {
          uVar6 = (uint)((int)param_1 << ((byte)uStack_24 & 0x1f)) >> bVar4;
          uStack_24 = uStack_24 + *(byte *)((int)puStack_10 + uVar6 * 2 + 1);
          *puVar7 = *(undefined *)((int)puStack_10 + uVar6 * 2);
          uStack_14 = uStack_14 + 1;
          puVar7 = puVar7 + 1;
        } while (uStack_14 < uVar3);
      }
      if ((piStack_20 == piStack_1c) && (uStack_24 == 0x20)) {
        return param_2;
      }
      return 0xffffffec;
    }
    if (piStack_20 < piStack_18) {
      if (piStack_20 == piStack_1c) goto LAB_00aa6a1b;
      uVar3 = uStack_24 >> 3;
      bVar8 = (int *)((int)piStack_20 - uVar3) < piStack_1c;
      if (bVar8) {
        uVar3 = (int)piStack_20 - (int)piStack_1c;
      }
      piStack_20 = (int *)((int)piStack_20 - uVar3);
      uStack_24 = uStack_24 + uVar3 * -8;
      param_1 = (undefined *)*piStack_20;
      if (bVar8) goto LAB_00aa6a1b;
    }
    else {
      piStack_20 = (int *)((int)piStack_20 - (uStack_24 >> 3));
      uStack_24 = uStack_24 & 7;
      param_1 = (undefined *)*piStack_20;
    }
    if (puStack_8 <= puVar7) goto LAB_00aa6a1b;
    uVar3 = (uint)((int)param_1 << ((byte)uStack_24 & 0x1f)) >> bVar4;
    uStack_24 = uStack_24 + *(byte *)((int)puStack_10 + uVar3 * 2 + 1);
    *puVar7 = *(undefined *)((int)puStack_10 + uVar3 * 2);
    puVar7 = puVar7 + 1;
  } while( true );
}



/* FUNCTION 21972 ; VA 0x00aa6a90 ; FUN_00aa6a90 */

uint FUN_00aa6a90(undefined2 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                 uint *param_5)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  sbyte sVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  bool bVar8;
  int iStack_30;
  uint uStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined2 *puStack_18;
  undefined2 *puStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined2 *puStack_8;
  
  uVar2 = FUN_00ab0130(&iStack_30,param_3,param_4);
  if (0xffffff88 < uVar2) {
    return uVar2;
  }
  puStack_c = param_5 + 1;
  puStack_18 = (undefined2 *)(param_2 + (int)param_1);
  uStack_1c = *param_5 >> 0x10 & 0xff;
  uStack_10 = -uStack_1c & 0x1f;
  puStack_14 = (undefined2 *)((int)puStack_18 - 3);
  piVar5 = piStack_28;
  do {
    if (uStack_2c < 0x21) {
      if (piVar5 < piStack_20) {
        if (piVar5 == piStack_24) {
          puStack_8 = (undefined2 *)(2 - (uStack_2c < 0x20));
          goto LAB_00aa6b5f;
        }
        uVar2 = uStack_2c >> 3;
        bVar8 = (int *)((int)piVar5 - uVar2) < piStack_24;
        if (bVar8) {
          uVar2 = (int)piVar5 - (int)piStack_24;
        }
        puStack_8 = (undefined2 *)(uint)bVar8;
        uStack_2c = uStack_2c + uVar2 * -8;
      }
      else {
        puStack_8 = (undefined2 *)0x0;
        uVar2 = uStack_2c >> 3;
        uStack_2c = uStack_2c & 7;
      }
      piVar5 = (int *)((int)piVar5 - uVar2);
      iStack_30 = *piVar5;
      piStack_28 = piVar5;
    }
    else {
      puStack_8 = (undefined2 *)0x3;
    }
LAB_00aa6b5f:
    sVar4 = (sbyte)uStack_10;
    if (puStack_8 != (undefined2 *)0x0 || puStack_14 <= param_1) break;
    uVar2 = (uint)(iStack_30 << ((byte)uStack_2c & 0x1f)) >> sVar4;
    *param_1 = *(undefined2 *)(puStack_c + uVar2);
    iVar6 = *(byte *)((int)param_5 + uVar2 * 4 + 6) + uStack_2c;
    param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)param_5 + uVar2 * 4 + 7));
    puVar1 = puStack_c + ((uint)(iStack_30 << ((byte)iVar6 & 0x1f)) >> sVar4);
    *param_1 = *(undefined2 *)puVar1;
    uStack_2c = (uint)*(byte *)((int)puVar1 + 2) + iVar6;
    param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar1 + 3));
  } while( true );
  puStack_8 = puStack_18 + -1;
  iVar6 = iStack_30;
  do {
    if (uStack_2c < 0x21) {
      if (piVar5 < piStack_20) {
        if (piVar5 == piStack_24) {
          uVar2 = 2 - (uStack_2c < 0x20);
          goto LAB_00aa6c3e;
        }
        uVar3 = uStack_2c >> 3;
        bVar8 = (int *)((int)piVar5 - uVar3) < piStack_24;
        if (bVar8) {
          uVar3 = (int)piVar5 - (int)piStack_24;
        }
        uVar2 = (uint)bVar8;
        uVar7 = uStack_2c + uVar3 * -8;
      }
      else {
        uVar7 = uStack_2c & 7;
        uVar3 = uStack_2c >> 3;
        uVar2 = 0;
      }
      piVar5 = (int *)((int)piVar5 - uVar3);
      iVar6 = *piVar5;
      iStack_30 = iVar6;
      uStack_2c = uVar7;
      piStack_28 = piVar5;
    }
    else {
      uVar2 = 3;
    }
LAB_00aa6c3e:
    if (uVar2 != 0 || puStack_8 < param_1) {
      for (; param_1 <= puStack_8;
          param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar1 + 3))) {
        puVar1 = puStack_c + ((uint)(iVar6 << ((byte)uStack_2c & 0x1f)) >> sVar4);
        *param_1 = *(undefined2 *)puVar1;
        uStack_2c = uStack_2c + *(byte *)((int)puVar1 + 2);
        piVar5 = piStack_28;
      }
      if (param_1 < puStack_18) {
        FUN_00aa67c0(param_1,&iStack_30,puStack_c,uStack_1c);
        piVar5 = piStack_28;
      }
      if ((piVar5 == piStack_24) && (uStack_2c == 0x20)) {
        return param_2;
      }
      return 0xffffffec;
    }
    puVar1 = puStack_c + ((uint)(iVar6 << ((byte)uStack_2c & 0x1f)) >> sVar4);
    *param_1 = *(undefined2 *)puVar1;
    uStack_2c = uStack_2c + *(byte *)((int)puVar1 + 2);
    param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar1 + 3));
  } while( true );
}



/* FUNCTION 21973 ; VA 0x00aa6d00 ; FUN_00aa6d00 */

uint FUN_00aa6d00(undefined *param_1,uint param_2,ushort *param_3,uint param_4,uint *param_5)

{
  undefined *puVar1;
  undefined *puVar2;
  byte bVar3;
  char cVar4;
  uint *puVar5;
  undefined uVar6;
  undefined *puVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  undefined *puVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  byte bVar17;
  undefined *puVar18;
  uint uVar19;
  uint uVar20;
  bool bVar21;
  undefined8 uVar22;
  int iStack_64;
  uint uStack_60;
  int *piStack_5c;
  int *piStack_58;
  int *piStack_54;
  int iStack_50;
  uint uStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  uint uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  uint *puStack_8;
  
  if (9 < param_4) {
    puVar7 = param_1 + param_2;
    puStack_8 = param_5 + 1;
    uVar8 = (uint)*param_3;
    uVar9 = (uint)param_3[1];
    uVar10 = (uint)param_3[2];
    iVar11 = uVar8 + (int)(param_3 + 3);
    uVar20 = (((param_4 - uVar10) - uVar9) - uVar8) - 6;
    uVar12 = param_2 + 3 >> 2;
    puVar1 = param_1 + uVar12;
    puVar2 = puVar1 + uVar12;
    puVar13 = puVar2 + uVar12;
    uVar12 = *param_5;
    uVar19 = uVar12 >> 0x10 & 0xff;
    if (uVar20 <= param_4) {
      puStack_14 = puVar13;
      puStack_10 = puVar2;
      puStack_c = puVar1;
      uVar8 = FUN_00ab0130(&iStack_64,param_3 + 3,uVar8);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      uVar8 = FUN_00ab0130(&iStack_28,iVar11,uVar9);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      uVar8 = FUN_00ab0130(&iStack_50,iVar11 + uVar9,uVar10);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      uVar8 = FUN_00ab0130(&iStack_3c,uVar10 + iVar11 + uVar9,uVar20);
      if (0xffffff88 < uVar8) {
        return uVar8;
      }
      iVar11 = FUN_00ab0260(&iStack_3c);
      iVar14 = FUN_00ab0260(&iStack_50);
      iVar15 = FUN_00ab0260(&iStack_28);
      iVar16 = FUN_00ab0260(&iStack_64);
      cVar4 = (char)(uVar12 >> 0x10);
      puVar18 = puStack_14;
      if (((iVar11 == 0 && iVar14 == 0) && iVar15 == 0) && iVar16 == 0) {
        bVar17 = -cVar4;
        puVar18 = puVar13;
        do {
          puVar5 = puStack_8;
          if (puVar7 + -7 <= puVar18) break;
          uVar6 = FUN_00aa6830(&iStack_64,puStack_8,uVar19);
          *param_1 = uVar6;
          uVar6 = FUN_00aa6830(&iStack_28,puVar5,uVar19);
          *puStack_c = uVar6;
          puStack_c = puStack_c + 1;
          uVar6 = FUN_00aa6830(&iStack_50,puVar5,uVar19);
          *puStack_10 = uVar6;
          puStack_10 = puStack_10 + 1;
          uVar6 = FUN_00aa6830(&iStack_3c,puVar5,uVar19);
          uVar12 = (uint)(iStack_64 << ((byte)uStack_60 & 0x1f)) >> (bVar17 & 0x1f);
          *puVar18 = uVar6;
          uStack_60 = uStack_60 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          param_1[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          param_1 = param_1 + 2;
          uVar12 = (uint)(iStack_28 << ((byte)uStack_24 & 0x1f)) >> (bVar17 & 0x1f);
          uStack_24 = uStack_24 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          *puStack_c = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puStack_c = puStack_c + 1;
          uVar12 = (uint)(iStack_50 << ((byte)uStack_4c & 0x1f)) >> (bVar17 & 0x1f);
          uStack_4c = uStack_4c + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          *puStack_10 = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puStack_10 = puStack_10 + 1;
          uVar12 = (uint)(iStack_3c << ((byte)uStack_38 & 0x1f)) >> (bVar17 & 0x1f);
          uStack_38 = uStack_38 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          puVar18[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puVar18 = puVar18 + 2;
          iVar11 = FUN_00ab0260(&iStack_3c);
          iVar14 = FUN_00ab0260(&iStack_50);
          iVar15 = FUN_00ab0260(&iStack_28);
          iVar16 = FUN_00ab0260(&iStack_64);
        } while (((iVar11 == 0 && iVar14 == 0) && iVar15 == 0) && iVar16 == 0);
      }
      puStack_14 = puVar18;
      if (((param_1 <= puVar1) && (puStack_c <= puVar2)) && (puStack_10 <= puVar13)) {
        bVar17 = -cVar4 & 0x1f;
        while (uStack_60 < 0x21) {
          if (piStack_5c < piStack_54) {
            if (piStack_5c == piStack_58) goto LAB_00aa7091;
            uVar12 = uStack_60 >> 3;
            bVar21 = (int *)((int)piStack_5c - uVar12) < piStack_58;
            if (bVar21) {
              uVar12 = (int)piStack_5c - (int)piStack_58;
            }
            piStack_5c = (int *)((int)piStack_5c - uVar12);
            iStack_64 = *piStack_5c;
            uStack_60 = uStack_60 + uVar12 * -8;
            if (bVar21) goto LAB_00aa7091;
          }
          else {
            piStack_5c = (int *)((int)piStack_5c - (uStack_60 >> 3));
            uStack_60 = uStack_60 & 7;
            iStack_64 = *piStack_5c;
          }
          if (puVar1 + -4 < param_1) goto LAB_00aa7091;
          uVar12 = (uint)(iStack_64 << ((byte)uStack_60 & 0x1f)) >> bVar17;
          iVar11 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1) + uStack_60;
          *param_1 = *(undefined *)((int)puStack_8 + uVar12 * 2);
          uVar12 = (uint)(iStack_64 << ((byte)iVar11 & 0x1f)) >> bVar17;
          bVar3 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          param_1[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          param_1 = param_1 + 2;
          uStack_60 = (uint)bVar3 + iVar11;
        }
LAB_00aa7122:
        uVar12 = (int)puVar1 - (int)param_1;
        uVar8 = 0;
        if (puVar1 < param_1) {
          uVar12 = 0;
        }
        if (uVar12 != 0) {
          do {
            uVar8 = uVar8 + 1;
            uVar9 = (uint)(iStack_64 << ((byte)uStack_60 & 0x1f)) >> bVar17;
            uStack_60 = uStack_60 + *(byte *)((int)puStack_8 + uVar9 * 2 + 1);
            *param_1 = *(undefined *)((int)puStack_8 + uVar9 * 2);
            param_1 = param_1 + 1;
          } while (uVar8 < uVar12);
        }
        while (uStack_24 < 0x21) {
          if (piStack_20 < piStack_18) {
            if (piStack_20 == piStack_1c) goto LAB_00aa7240;
            uVar12 = uStack_24 >> 3;
            bVar21 = (int *)((int)piStack_20 - uVar12) < piStack_1c;
            if (bVar21) {
              uVar12 = (int)piStack_20 - (int)piStack_1c;
            }
            piStack_20 = (int *)((int)piStack_20 - uVar12);
            uStack_24 = uStack_24 + uVar12 * -8;
            iStack_28 = *piStack_20;
            if (bVar21) goto LAB_00aa7240;
          }
          else {
            piStack_20 = (int *)((int)piStack_20 - (uStack_24 >> 3));
            uStack_24 = uStack_24 & 7;
            iStack_28 = *piStack_20;
          }
          if (puVar2 + -4 < puStack_c) goto LAB_00aa7240;
          uVar12 = (uint)(iStack_28 << ((byte)uStack_24 & 0x1f)) >> bVar17;
          iVar11 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1) + uStack_24;
          *puStack_c = *(undefined *)((int)puStack_8 + uVar12 * 2);
          uVar12 = (uint)(iStack_28 << ((byte)iVar11 & 0x1f)) >> bVar17;
          bVar3 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          puStack_c[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puStack_c = puStack_c + 2;
          uStack_24 = (uint)bVar3 + iVar11;
        }
LAB_00aa72d1:
        uVar12 = (int)puVar2 - (int)puStack_c;
        uVar8 = 0;
        if (puVar2 < puStack_c) {
          uVar12 = 0;
        }
        if (uVar12 != 0) {
          do {
            uVar8 = uVar8 + 1;
            uVar9 = (uint)(iStack_28 << ((byte)uStack_24 & 0x1f)) >> bVar17;
            uStack_24 = uStack_24 + *(byte *)((int)puStack_8 + uVar9 * 2 + 1);
            *puStack_c = *(undefined *)((int)puStack_8 + uVar9 * 2);
            puStack_c = puStack_c + 1;
          } while (uVar8 < uVar12);
        }
        while (uStack_4c < 0x21) {
          if (piStack_48 < piStack_40) {
            if (piStack_48 == piStack_44) goto LAB_00aa73e7;
            uVar12 = uStack_4c >> 3;
            bVar21 = (int *)((int)piStack_48 - uVar12) < piStack_44;
            if (bVar21) {
              uVar12 = (int)piStack_48 - (int)piStack_44;
            }
            piStack_48 = (int *)((int)piStack_48 - uVar12);
            iStack_50 = *piStack_48;
            uStack_4c = uStack_4c + uVar12 * -8;
            if (bVar21) goto LAB_00aa73e7;
          }
          else {
            piStack_48 = (int *)((int)piStack_48 - (uStack_4c >> 3));
            uStack_4c = uStack_4c & 7;
            iStack_50 = *piStack_48;
          }
          if (puVar13 + -4 < puStack_10) goto LAB_00aa73e7;
          uVar12 = (uint)(iStack_50 << ((byte)uStack_4c & 0x1f)) >> bVar17;
          iVar11 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1) + uStack_4c;
          *puStack_10 = *(undefined *)((int)puStack_8 + uVar12 * 2);
          uVar12 = (uint)(iStack_50 << ((byte)iVar11 & 0x1f)) >> bVar17;
          bVar3 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          puStack_10[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puStack_10 = puStack_10 + 2;
          uStack_4c = (uint)bVar3 + iVar11;
        }
LAB_00aa7478:
        uVar12 = (int)puVar13 - (int)puStack_10;
        uVar8 = 0;
        if (puVar13 < puStack_10) {
          uVar12 = 0;
        }
        if (uVar12 != 0) {
          do {
            uVar8 = uVar8 + 1;
            uVar9 = (uint)(iStack_50 << ((byte)uStack_4c & 0x1f)) >> bVar17;
            uStack_4c = uStack_4c + *(byte *)((int)puStack_8 + uVar9 * 2 + 1);
            *puStack_10 = *(undefined *)((int)puStack_8 + uVar9 * 2);
            puStack_10 = puStack_10 + 1;
          } while (uVar8 < uVar12);
        }
        while (uStack_38 < 0x21) {
          if (piStack_34 < piStack_2c) {
            if (piStack_34 == piStack_30) goto LAB_00aa7590;
            uVar12 = uStack_38 >> 3;
            bVar21 = (int *)((int)piStack_34 - uVar12) < piStack_30;
            if (bVar21) {
              uVar12 = (int)piStack_34 - (int)piStack_30;
            }
            piStack_34 = (int *)((int)piStack_34 - uVar12);
            iStack_3c = *piStack_34;
            uStack_38 = uStack_38 + uVar12 * -8;
            if (bVar21) goto LAB_00aa7590;
          }
          else {
            piStack_34 = (int *)((int)piStack_34 - (uStack_38 >> 3));
            uStack_38 = uStack_38 & 7;
            iStack_3c = *piStack_34;
          }
          if (puVar7 + -4 < puStack_14) goto LAB_00aa7590;
          uVar12 = (uint)(iStack_3c << ((byte)uStack_38 & 0x1f)) >> bVar17;
          iVar11 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1) + uStack_38;
          *puStack_14 = *(undefined *)((int)puStack_8 + uVar12 * 2);
          uVar12 = (uint)(iStack_3c << ((byte)iVar11 & 0x1f)) >> bVar17;
          bVar3 = *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
          puStack_14[1] = *(undefined *)((int)puStack_8 + uVar12 * 2);
          puStack_14 = puStack_14 + 2;
          uStack_38 = (uint)bVar3 + iVar11;
        }
LAB_00aa7621:
        uVar12 = (int)puVar7 - (int)puStack_14;
        uVar8 = 0;
        if (puVar7 < puStack_14) {
          uVar12 = 0;
        }
        if (uVar12 != 0) {
          do {
            uVar8 = uVar8 + 1;
            uVar9 = (uint)(iStack_3c << ((byte)uStack_38 & 0x1f)) >> bVar17;
            uStack_38 = uStack_38 + *(byte *)((int)puStack_8 + uVar9 * 2 + 1);
            *puStack_14 = *(undefined *)((int)puStack_8 + uVar9 * 2);
            puStack_14 = puStack_14 + 1;
          } while (uVar8 < uVar12);
        }
        FUN_00ab00d0(&iStack_3c);
        FUN_00ab00d0(&iStack_50);
        FUN_00ab00d0(&iStack_28);
        uVar22 = FUN_00ab00d0(&iStack_64);
        if (((uint)uVar22 & (uint)((ulonglong)uVar22 >> 0x20)) != 0) {
          return param_2;
        }
      }
    }
  }
  return 0xffffffec;
LAB_00aa7091:
  if (0x20 < uStack_60) goto LAB_00aa7122;
  if (piStack_5c < piStack_54) {
    if (piStack_5c == piStack_58) goto LAB_00aa7122;
    uVar12 = uStack_60 >> 3;
    bVar21 = (int *)((int)piStack_5c - uVar12) < piStack_58;
    if (bVar21) {
      uVar12 = (int)piStack_5c - (int)piStack_58;
    }
    piStack_5c = (int *)((int)piStack_5c - uVar12);
    uStack_60 = uStack_60 + uVar12 * -8;
    iStack_64 = *piStack_5c;
    if (bVar21) goto LAB_00aa7122;
  }
  else {
    piStack_5c = (int *)((int)piStack_5c - (uStack_60 >> 3));
    uStack_60 = uStack_60 & 7;
    iStack_64 = *piStack_5c;
  }
  if (puVar1 <= param_1) goto LAB_00aa7122;
  uVar12 = (uint)(iStack_64 << ((byte)uStack_60 & 0x1f)) >> bVar17;
  uStack_60 = uStack_60 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
  *param_1 = *(undefined *)((int)puStack_8 + uVar12 * 2);
  param_1 = param_1 + 1;
  goto LAB_00aa7091;
LAB_00aa7240:
  if (0x20 < uStack_24) goto LAB_00aa72d1;
  if (piStack_20 < piStack_18) {
    if (piStack_20 == piStack_1c) goto LAB_00aa72d1;
    uVar12 = uStack_24 >> 3;
    bVar21 = (int *)((int)piStack_20 - uVar12) < piStack_1c;
    if (bVar21) {
      uVar12 = (int)piStack_20 - (int)piStack_1c;
    }
    piStack_20 = (int *)((int)piStack_20 - uVar12);
    uStack_24 = uStack_24 + uVar12 * -8;
    iStack_28 = *piStack_20;
    if (bVar21) goto LAB_00aa72d1;
  }
  else {
    piStack_20 = (int *)((int)piStack_20 - (uStack_24 >> 3));
    uStack_24 = uStack_24 & 7;
    iStack_28 = *piStack_20;
  }
  if (puVar2 <= puStack_c) goto LAB_00aa72d1;
  uVar12 = (uint)(iStack_28 << ((byte)uStack_24 & 0x1f)) >> bVar17;
  uStack_24 = uStack_24 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
  *puStack_c = *(undefined *)((int)puStack_8 + uVar12 * 2);
  puStack_c = puStack_c + 1;
  goto LAB_00aa7240;
LAB_00aa73e7:
  if (0x20 < uStack_4c) goto LAB_00aa7478;
  if (piStack_48 < piStack_40) {
    if (piStack_48 == piStack_44) goto LAB_00aa7478;
    uVar12 = uStack_4c >> 3;
    bVar21 = (int *)((int)piStack_48 - uVar12) < piStack_44;
    if (bVar21) {
      uVar12 = (int)piStack_48 - (int)piStack_44;
    }
    piStack_48 = (int *)((int)piStack_48 - uVar12);
    uStack_4c = uStack_4c + uVar12 * -8;
    iStack_50 = *piStack_48;
    if (bVar21) goto LAB_00aa7478;
  }
  else {
    piStack_48 = (int *)((int)piStack_48 - (uStack_4c >> 3));
    uStack_4c = uStack_4c & 7;
    iStack_50 = *piStack_48;
  }
  if (puVar13 <= puStack_10) goto LAB_00aa7478;
  uVar12 = (uint)(iStack_50 << ((byte)uStack_4c & 0x1f)) >> bVar17;
  uStack_4c = uStack_4c + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
  *puStack_10 = *(undefined *)((int)puStack_8 + uVar12 * 2);
  puStack_10 = puStack_10 + 1;
  goto LAB_00aa73e7;
LAB_00aa7590:
  if (0x20 < uStack_38) goto LAB_00aa7621;
  if (piStack_34 < piStack_2c) {
    if (piStack_34 == piStack_30) goto LAB_00aa7621;
    uVar12 = uStack_38 >> 3;
    bVar21 = (int *)((int)piStack_34 - uVar12) < piStack_30;
    if (bVar21) {
      uVar12 = (int)piStack_34 - (int)piStack_30;
    }
    piStack_34 = (int *)((int)piStack_34 - uVar12);
    uStack_38 = uStack_38 + uVar12 * -8;
    iStack_3c = *piStack_34;
    if (bVar21) goto LAB_00aa7621;
  }
  else {
    piStack_34 = (int *)((int)piStack_34 - (uStack_38 >> 3));
    uStack_38 = uStack_38 & 7;
    iStack_3c = *piStack_34;
  }
  if (puVar7 <= puStack_14) goto LAB_00aa7621;
  uVar12 = (uint)(iStack_3c << ((byte)uStack_38 & 0x1f)) >> bVar17;
  uStack_38 = uStack_38 + *(byte *)((int)puStack_8 + uVar12 * 2 + 1);
  *puStack_14 = *(undefined *)((int)puStack_8 + uVar12 * 2);
  puStack_14 = puStack_14 + 1;
  goto LAB_00aa7590;
}



/* FUNCTION 21974 ; VA 0x00aa76b0 ; FUN_00aa76b0 */

uint FUN_00aa76b0(undefined2 *param_1,uint param_2,ushort *param_3,uint param_4,uint *param_5)

{
  uint *puVar1;
  byte bVar2;
  undefined2 *puVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  byte bVar11;
  undefined2 *puVar12;
  int *piVar13;
  uint *puVar14;
  uint uVar15;
  bool bVar16;
  undefined8 uVar17;
  int iStack_80;
  uint uStack_7c;
  int *piStack_78;
  int *piStack_74;
  int *piStack_70;
  int iStack_6c;
  uint uStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  int iStack_58;
  uint uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int iStack_44;
  uint uStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined2 *puStack_30;
  undefined2 *puStack_2c;
  uint uStack_28;
  undefined2 *puStack_24;
  undefined2 *puStack_20;
  undefined2 *puStack_1c;
  undefined2 *puStack_18;
  undefined2 *puStack_14;
  undefined2 *puStack_10;
  uint *puStack_c;
  uint uStack_8;
  
  if (9 < param_4) {
    puStack_30 = (undefined2 *)(param_2 + (int)param_1);
    puStack_c = param_5 + 1;
    uVar4 = (uint)*param_3;
    uStack_8 = (uint)param_3[1];
    uVar5 = (uint)param_3[2];
    iVar6 = uVar4 + (int)(param_3 + 3);
    uVar15 = (((param_4 - uVar5) - uStack_8) - uVar4) - 6;
    puStack_24 = (undefined2 *)(iVar6 + uStack_8);
    uVar7 = param_2 + 3 >> 2;
    puVar12 = (undefined2 *)(uVar7 + (int)param_1);
    puStack_2c = (undefined2 *)((int)puVar12 + uVar7);
    puStack_18 = (undefined2 *)((int)puStack_2c + uVar7);
    uStack_28 = *param_5 >> 0x10 & 0xff;
    if (uVar15 <= param_4) {
      puStack_20 = puVar12;
      puStack_1c = puVar12;
      puStack_14 = puStack_2c;
      puStack_10 = puStack_18;
      uVar4 = FUN_00ab0130(&iStack_44,param_3 + 3,uVar4);
      if (0xffffff88 < uVar4) {
        return uVar4;
      }
      uVar4 = FUN_00ab0130(&iStack_6c,iVar6,uStack_8);
      if (0xffffff88 < uVar4) {
        return uVar4;
      }
      uVar4 = FUN_00ab0130(&iStack_58,puStack_24,uVar5);
      if (0xffffff88 < uVar4) {
        return uVar4;
      }
      uVar4 = FUN_00ab0130(&iStack_80,uVar5 + (int)puStack_24,uVar15);
      if (0xffffff88 < uVar4) {
        return uVar4;
      }
      iVar6 = FUN_00ab0260(&iStack_80);
      iVar8 = FUN_00ab0260(&iStack_58);
      iVar9 = FUN_00ab0260(&iStack_6c);
      iVar10 = FUN_00ab0260(&iStack_44);
      puVar3 = puStack_1c;
      if (puStack_18 < (undefined2 *)((int)puStack_30 + -3) &&
          (((iVar6 == 0 && iVar8 == 0) && iVar9 == 0) && iVar10 == 0)) {
        bVar2 = -(char)uStack_28;
        do {
          puVar14 = puStack_c;
          iVar6 = FUN_00aa6860(param_1,&iStack_44,puStack_c,uStack_28);
          iVar8 = FUN_00aa6860(puVar12,&iStack_6c,puVar14,uStack_28);
          puVar3 = puStack_2c;
          iVar9 = FUN_00aa6860(puStack_2c,&iStack_58,puVar14,uStack_28);
          iVar10 = FUN_00aa6860(puStack_10,&iStack_80,puStack_c,uStack_28);
          puVar14 = puStack_c + ((uint)(iStack_44 << ((byte)uStack_40 & 0x1f)) >> (bVar2 & 0x1f));
          *(undefined2 *)((int)param_1 + iVar6) = *(undefined2 *)puVar14;
          uStack_40 = uStack_40 + *(byte *)((int)puVar14 + 2);
          param_1 = (undefined2 *)((int)param_1 + iVar6 + (uint)*(byte *)((int)puVar14 + 3));
          puVar14 = puStack_c + ((uint)(iStack_6c << ((byte)uStack_68 & 0x1f)) >> (bVar2 & 0x1f));
          *(undefined2 *)((int)puVar12 + iVar8) = *(undefined2 *)puVar14;
          uStack_68 = uStack_68 + *(byte *)((int)puVar14 + 2);
          puVar12 = (undefined2 *)((int)puVar12 + iVar8 + (uint)*(byte *)((int)puVar14 + 3));
          puVar14 = puStack_c + ((uint)(iStack_58 << ((byte)uStack_54 & 0x1f)) >> (bVar2 & 0x1f));
          *(undefined2 *)((int)puVar3 + iVar9) = *(undefined2 *)puVar14;
          uStack_54 = uStack_54 + *(byte *)((int)puVar14 + 2);
          puStack_2c = (undefined2 *)((int)puVar3 + iVar9 + (uint)*(byte *)((int)puVar14 + 3));
          puVar14 = puStack_c + ((uint)(iStack_80 << ((byte)uStack_7c & 0x1f)) >> (bVar2 & 0x1f));
          *(undefined2 *)((int)puStack_10 + iVar10) = *(undefined2 *)puVar14;
          uStack_7c = uStack_7c + *(byte *)((int)puVar14 + 2);
          puStack_10 = (undefined2 *)((int)puStack_10 + iVar10 + (uint)*(byte *)((int)puVar14 + 3));
          iVar6 = FUN_00ab0260(&iStack_80);
          iVar8 = FUN_00ab0260(&iStack_58);
          iVar9 = FUN_00ab0260(&iStack_6c);
          iVar10 = FUN_00ab0260(&iStack_44);
          puVar3 = puVar12;
        } while (puStack_10 < (undefined2 *)((int)puStack_30 + -3) &&
                 (((iVar6 == 0 && iVar8 == 0) && iVar9 == 0) && iVar10 == 0));
      }
      puStack_1c = puVar3;
      if (((param_1 <= puStack_20) && (puVar12 <= puStack_14)) && (puStack_2c <= puStack_18)) {
        puStack_24 = (undefined2 *)((int)puStack_20 - 3);
        bVar2 = -(char)uStack_28;
        bVar11 = bVar2 & 0x1f;
        do {
          if (uStack_40 < 0x21) {
            if (piStack_3c < piStack_34) {
              if (piStack_3c == piStack_38) {
                uStack_8 = 2 - (uStack_40 < 0x20);
                goto LAB_00aa7a21;
              }
              uVar4 = uStack_40 >> 3;
              bVar16 = (int *)((int)piStack_3c - uVar4) < piStack_38;
              if (bVar16) {
                uVar4 = (int)piStack_3c - (int)piStack_38;
              }
              uStack_8 = (uint)bVar16;
              uStack_40 = uStack_40 + uVar4 * -8;
            }
            else {
              uStack_8 = 0;
              uVar4 = uStack_40 >> 3;
              uStack_40 = uStack_40 & 7;
            }
            piStack_3c = (int *)((int)piStack_3c - uVar4);
            iStack_44 = *piStack_3c;
          }
          else {
            uStack_8 = 3;
          }
LAB_00aa7a21:
          if (uStack_8 != 0 || puStack_24 <= param_1) goto LAB_00aa7a8e;
          uVar4 = (uint)(iStack_44 << ((byte)uStack_40 & 0x1f)) >> bVar11;
          *param_1 = *(undefined2 *)(puStack_c + uVar4);
          iVar6 = *(byte *)((int)puStack_c + uVar4 * 4 + 2) + uStack_40;
          param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puStack_c + uVar4 * 4 + 3));
          puVar14 = puStack_c + ((uint)(iStack_44 << ((byte)iVar6 & 0x1f)) >> bVar11);
          *param_1 = *(undefined2 *)puVar14;
          uStack_40 = (uint)*(byte *)((int)puVar14 + 2) + iVar6;
          param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar14 + 3));
        } while( true );
      }
    }
  }
  return 0xffffffec;
LAB_00aa7a8e:
  piVar13 = piStack_3c;
  do {
    if (uStack_40 < 0x21) {
      if (piVar13 < piStack_34) {
        if (piVar13 == piStack_38) {
          uStack_8 = 2 - (uStack_40 < 0x20);
          goto LAB_00aa7b0e;
        }
        uVar4 = uStack_40 >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_38;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_38;
        }
        uStack_8 = (uint)bVar16;
        uStack_40 = uStack_40 + uVar4 * -8;
      }
      else {
        uStack_8 = 0;
        uVar4 = uStack_40 >> 3;
        uStack_40 = uStack_40 & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_44 = *piVar13;
      piStack_3c = piVar13;
    }
    else {
      uStack_8 = 3;
    }
LAB_00aa7b0e:
    if (uStack_8 != 0 || puStack_20 + -1 < param_1) break;
    puVar14 = puStack_c + ((uint)(iStack_44 << ((byte)uStack_40 & 0x1f)) >> bVar11);
    *param_1 = *(undefined2 *)puVar14;
    uStack_40 = uStack_40 + *(byte *)((int)puVar14 + 2);
    param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar14 + 3));
  } while( true );
  for (; param_1 <= puStack_20 + -1;
      param_1 = (undefined2 *)((int)param_1 + (uint)*(byte *)((int)puVar14 + 3))) {
    puVar14 = puStack_c + ((uint)(iStack_44 << ((byte)uStack_40 & 0x1f)) >> bVar11);
    *param_1 = *(undefined2 *)puVar14;
    uStack_40 = uStack_40 + *(byte *)((int)puVar14 + 2);
  }
  if (param_1 < puStack_20) {
    FUN_00aa67c0(param_1,&iStack_44,puStack_c,uStack_28);
  }
  puVar14 = puStack_c;
  puStack_24 = (undefined2 *)((int)puStack_14 + -3);
  piVar13 = piStack_64;
  do {
    if (uStack_68 < 0x21) {
      if (piVar13 < piStack_5c) {
        if (piVar13 == piStack_60) {
          uStack_8 = 2 - (uStack_68 < 0x20);
          goto LAB_00aa7c1c;
        }
        uVar4 = uStack_68 >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_60;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_60;
        }
        uStack_8 = (uint)bVar16;
        uStack_68 = uStack_68 + uVar4 * -8;
      }
      else {
        uStack_8 = 0;
        uVar4 = uStack_68 >> 3;
        uStack_68 = uStack_68 & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_6c = *piVar13;
      piStack_64 = piVar13;
    }
    else {
      uStack_8 = 3;
    }
LAB_00aa7c1c:
    if (uStack_8 != 0 || puStack_24 <= puStack_1c) break;
    uVar4 = (uint)(iStack_6c << ((byte)uStack_68 & 0x1f)) >> (bVar2 & 0x1f);
    *puStack_1c = *(undefined2 *)(puStack_c + uVar4);
    iVar6 = *(byte *)((int)puStack_c + uVar4 * 4 + 2) + uStack_68;
    puStack_1c = (undefined2 *)((int)puStack_1c + (uint)*(byte *)((int)puStack_c + uVar4 * 4 + 3));
    puVar1 = puStack_c + ((uint)(iStack_6c << ((byte)iVar6 & 0x1f)) >> (bVar2 & 0x1f));
    *puStack_1c = *(undefined2 *)puVar1;
    uStack_68 = (uint)*(byte *)((int)puVar1 + 2) + iVar6;
    puStack_1c = (undefined2 *)((int)puStack_1c + (uint)*(byte *)((int)puVar1 + 3));
  } while( true );
  puStack_20 = puStack_14 + -1;
  puVar12 = puStack_1c;
  do {
    if (uStack_68 < 0x21) {
      if (piVar13 < piStack_5c) {
        if (piVar13 == piStack_60) {
          puStack_1c = (undefined2 *)(2 - (uStack_68 < 0x20));
          goto LAB_00aa7d0e;
        }
        uVar4 = uStack_68 >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_60;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_60;
        }
        puStack_1c = (undefined2 *)(uint)bVar16;
        uStack_68 = uStack_68 + uVar4 * -8;
      }
      else {
        puStack_1c = (undefined2 *)0x0;
        uVar4 = uStack_68 >> 3;
        uStack_68 = uStack_68 & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_6c = *piVar13;
      piStack_64 = piVar13;
    }
    else {
      puStack_1c = (undefined2 *)0x3;
    }
LAB_00aa7d0e:
    if (puStack_1c != (undefined2 *)0x0 || puStack_20 < puVar12) break;
    puVar1 = puStack_c + ((uint)(iStack_6c << ((byte)uStack_68 & 0x1f)) >> (bVar2 & 0x1f));
    *puVar12 = *(undefined2 *)puVar1;
    uStack_68 = uStack_68 + *(byte *)((int)puVar1 + 2);
    puVar12 = (undefined2 *)((int)puVar12 + (uint)*(byte *)((int)puVar1 + 3));
  } while( true );
  for (; puVar12 <= puStack_20;
      puVar12 = (undefined2 *)((int)puVar12 + (uint)*(byte *)((int)puVar1 + 3))) {
    puVar1 = puStack_c + ((uint)(iStack_6c << ((byte)uStack_68 & 0x1f)) >> (bVar2 & 0x1f));
    *puVar12 = *(undefined2 *)puVar1;
    uStack_68 = uStack_68 + *(byte *)((int)puVar1 + 2);
  }
  if (puVar12 < puStack_14) {
    FUN_00aa67c0(puVar12,&iStack_6c,puStack_c,uStack_28);
  }
  puStack_24 = (undefined2 *)((int)puStack_18 + -3);
  piVar13 = piStack_50;
  do {
    if (uStack_54 < 0x21) {
      if (piVar13 < piStack_48) {
        if (piVar13 == piStack_4c) {
          puStack_14 = (undefined2 *)(2 - (uStack_54 < 0x20));
          goto LAB_00aa7e16;
        }
        uVar4 = uStack_54 >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_4c;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_4c;
        }
        puStack_14 = (undefined2 *)(uint)bVar16;
        uStack_54 = uStack_54 + uVar4 * -8;
      }
      else {
        puStack_14 = (undefined2 *)0x0;
        uVar4 = uStack_54 >> 3;
        uStack_54 = uStack_54 & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_58 = *piVar13;
      piStack_50 = piVar13;
    }
    else {
      puStack_14 = (undefined2 *)0x3;
    }
LAB_00aa7e16:
    if (puStack_14 != (undefined2 *)0x0 || puStack_24 <= puStack_2c) break;
    uVar4 = (uint)(iStack_58 << ((byte)uStack_54 & 0x1f)) >> (bVar2 & 0x1f);
    *puStack_2c = *(undefined2 *)(puVar14 + uVar4);
    iVar6 = *(byte *)((int)puVar14 + uVar4 * 4 + 2) + uStack_54;
    puStack_2c = (undefined2 *)((int)puStack_2c + (uint)*(byte *)((int)puStack_c + uVar4 * 4 + 3));
    puVar14 = puStack_c + ((uint)(iStack_58 << ((byte)iVar6 & 0x1f)) >> (bVar2 & 0x1f));
    *puStack_2c = *(undefined2 *)puVar14;
    uStack_54 = (uint)*(byte *)((int)puVar14 + 2) + iVar6;
    puStack_2c = (undefined2 *)((int)puStack_2c + (uint)*(byte *)((int)puVar14 + 3));
    puVar14 = puStack_c;
  } while( true );
  puStack_20 = puStack_18 + -1;
  puVar12 = puStack_2c;
  do {
    if (uStack_54 < 0x21) {
      if (piVar13 < piStack_48) {
        if (piVar13 == piStack_4c) {
          puStack_14 = (undefined2 *)(2 - (uStack_54 < 0x20));
          goto LAB_00aa7f00;
        }
        uVar4 = uStack_54 >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_4c;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_4c;
        }
        puStack_14 = (undefined2 *)(uint)bVar16;
        uStack_54 = uStack_54 + uVar4 * -8;
      }
      else {
        puStack_14 = (undefined2 *)0x0;
        uVar4 = uStack_54 >> 3;
        uStack_54 = uStack_54 & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_58 = *piVar13;
      piStack_50 = piVar13;
    }
    else {
      puStack_14 = (undefined2 *)0x3;
    }
LAB_00aa7f00:
    if (puStack_14 != (undefined2 *)0x0 || puStack_20 < puVar12) break;
    puVar1 = puVar14 + ((uint)(iStack_58 << ((byte)uStack_54 & 0x1f)) >> (bVar2 & 0x1f));
    *puVar12 = *(undefined2 *)puVar1;
    uStack_54 = uStack_54 + *(byte *)((int)puVar1 + 2);
    puVar12 = (undefined2 *)((int)puVar12 + (uint)*(byte *)((int)puVar1 + 3));
  } while( true );
  for (; puVar12 <= puStack_20;
      puVar12 = (undefined2 *)((int)puVar12 + (uint)*(byte *)((int)puVar1 + 3))) {
    puVar1 = puVar14 + ((uint)(iStack_58 << ((byte)uStack_54 & 0x1f)) >> (bVar2 & 0x1f));
    *puVar12 = *(undefined2 *)puVar1;
    uStack_54 = uStack_54 + *(byte *)((int)puVar1 + 2);
  }
  piVar13 = piStack_78;
  if (puVar12 < puStack_18) {
    FUN_00aa67c0(puVar12,&iStack_58,puVar14,uStack_28);
    piVar13 = piStack_78;
  }
  do {
    if (uStack_7c < 0x21) {
      if (piVar13 < piStack_70) {
        if (piVar13 == piStack_74) {
          puStack_18 = (undefined2 *)(2 - (uStack_7c < 0x20));
          goto LAB_00aa7fff;
        }
        uVar4 = uStack_7c >> 3;
        bVar16 = (int *)((int)piVar13 - uVar4) < piStack_74;
        if (bVar16) {
          uVar4 = (int)piVar13 - (int)piStack_74;
        }
        puStack_18 = (undefined2 *)(uint)bVar16;
        uStack_7c = uStack_7c + uVar4 * -8;
      }
      else {
        puStack_18 = (undefined2 *)0x0;
        uVar4 = uStack_7c >> 3;
        uStack_7c = uStack_7c & 7;
      }
      piVar13 = (int *)((int)piVar13 - uVar4);
      iStack_80 = *piVar13;
      piStack_78 = piVar13;
    }
    else {
      puStack_18 = (undefined2 *)0x3;
    }
LAB_00aa7fff:
    iVar6 = iStack_80;
    if (puStack_18 != (undefined2 *)0x0 || (undefined2 *)((int)puStack_30 + -3) <= puStack_10)
    break;
    uVar4 = (uint)(iStack_80 << ((byte)uStack_7c & 0x1f)) >> (bVar2 & 0x1f);
    *puStack_10 = *(undefined2 *)(puStack_c + uVar4);
    iVar6 = *(byte *)((int)puStack_c + uVar4 * 4 + 2) + uStack_7c;
    puStack_10 = (undefined2 *)((int)puStack_10 + (uint)*(byte *)((int)puStack_c + uVar4 * 4 + 3));
    puVar14 = puStack_c + ((uint)(iStack_80 << ((byte)iVar6 & 0x1f)) >> (bVar2 & 0x1f));
    *puStack_10 = *(undefined2 *)puVar14;
    uStack_7c = (uint)*(byte *)((int)puVar14 + 2) + iVar6;
    puStack_10 = (undefined2 *)((int)puStack_10 + (uint)*(byte *)((int)puVar14 + 3));
  } while( true );
LAB_00aa8080:
  if (uStack_7c < 0x21) {
    if (piVar13 < piStack_70) {
      if (piVar13 == piStack_74) {
        puStack_18 = (undefined2 *)(2 - (uStack_7c < 0x20));
        goto LAB_00aa80eb;
      }
      uVar4 = uStack_7c >> 3;
      bVar16 = (int *)((int)piVar13 - uVar4) < piStack_74;
      if (bVar16) {
        uVar4 = (int)piVar13 - (int)piStack_74;
      }
      puStack_18 = (undefined2 *)(uint)bVar16;
      uStack_7c = uStack_7c + uVar4 * -8;
    }
    else {
      puStack_18 = (undefined2 *)0x0;
      uVar4 = uStack_7c >> 3;
      uStack_7c = uStack_7c & 7;
    }
    piVar13 = (int *)((int)piVar13 - uVar4);
    iVar6 = *piVar13;
    iStack_80 = iVar6;
    piStack_78 = piVar13;
  }
  else {
    puStack_18 = (undefined2 *)0x3;
  }
LAB_00aa80eb:
  if (puStack_18 != (undefined2 *)0x0 || puStack_30 + -1 < puStack_10) {
    puVar12 = puStack_10;
    if (puStack_10 <= puStack_30 + -1) {
      do {
        puVar14 = puStack_c + ((uint)(iVar6 << ((byte)uStack_7c & 0x1f)) >> (bVar2 & 0x1f));
        *puVar12 = *(undefined2 *)puVar14;
        uStack_7c = uStack_7c + *(byte *)((int)puVar14 + 2);
        puVar12 = (undefined2 *)((int)puVar12 + (uint)*(byte *)((int)puVar14 + 3));
      } while (puVar12 <= puStack_30 + -1);
    }
    if (puVar12 < puStack_30) {
      FUN_00aa67c0(puVar12,&iStack_80,puStack_c,uStack_28);
    }
    FUN_00ab00d0(&iStack_80);
    FUN_00ab00d0(&iStack_58);
    FUN_00ab00d0(&iStack_6c);
    uVar17 = FUN_00ab00d0(&iStack_44);
    if (((uint)uVar17 & (uint)((ulonglong)uVar17 >> 0x20)) == 0) {
      return 0xffffffec;
    }
    return param_2;
  }
  puVar14 = puStack_c + ((uint)(iVar6 << ((byte)uStack_7c & 0x1f)) >> (bVar2 & 0x1f));
  *puStack_10 = *(undefined2 *)puVar14;
  uStack_7c = uStack_7c + *(byte *)((int)puVar14 + 2);
  puStack_10 = (undefined2 *)((int)puStack_10 + (uint)*(byte *)((int)puVar14 + 3));
  goto LAB_00aa8080;
}



/* FUNCTION 21975 ; VA 0x00aa81d0 ; FUN_00aa81d0 */

uint FUN_00aa81d0(int param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  byte *pbVar5;
  int iVar6;
  
  iVar4 = 0;
  iVar6 = 0;
  uVar2 = 0;
  iVar1 = 0;
  if (-1 < param_3) {
    if (1 < param_3 + 1) {
      pbVar5 = (byte *)(param_1 + 6);
      do {
        iVar6 = iVar6 + (uint)pbVar5[-4] * *(int *)(param_2 + iVar1 * 4);
        iVar3 = iVar1 * 4;
        iVar1 = iVar1 + 2;
        iVar4 = iVar4 + (uint)*pbVar5 * *(int *)(param_2 + 4 + iVar3);
        pbVar5 = pbVar5 + 8;
      } while (iVar1 <= param_3 + -1);
    }
    iVar3 = 0;
    if (iVar1 <= param_3) {
      iVar3 = (uint)*(byte *)(param_1 + 2 + iVar1 * 4) * *(int *)(param_2 + iVar1 * 4);
    }
    uVar2 = iVar3 + iVar4 + iVar6;
  }
  return uVar2 >> 3;
}



/* FUNCTION 21976 ; VA 0x00aa8250 ; FUN_00aa8250 */

void FUN_00aa8250(int param_1,int param_2,int param_3,uint param_4,int param_5,uint *param_6,
                 int param_7,int param_8)

{
  byte bVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint auStack_a0 [4];
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint *puStack_38;
  int iStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint *puStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 *puStack_8;
  
  uVar6 = 0;
  uStack_1c = 0;
  iStack_24 = param_8 - param_2;
  uStack_20 = param_8 - param_7;
  auStack_a0[0] = *param_6;
  auStack_a0[1] = param_6[1];
  auStack_a0[2] = param_6[2];
  auStack_a0[3] = param_6[3];
  uStack_90 = param_6[4];
  uStack_8c = param_6[5];
  uStack_88 = param_6[6];
  uStack_84 = param_6[7];
  uStack_70 = param_6[0xc];
  uStack_80 = param_6[8];
  uStack_7c = param_6[9];
  uStack_78 = param_6[10];
  uStack_74 = param_6[0xb];
  if (param_4 != 0) {
    do {
      uVar4 = (uint)*(byte *)(param_3 + 1 + uVar6 * 2);
      bVar1 = *(byte *)(param_3 + uVar6 * 2);
      iStack_18 = param_8 - uVar4;
      uStack_14 = (uint)bVar1;
      uStack_30 = auStack_a0[uVar4];
      puStack_38 = auStack_a0 + uVar4;
      iStack_34 = 1 << ((char)param_2 - (char)iStack_18 & 0x1fU);
      if ((uint)(param_2 - iStack_18) < uStack_20) {
        uVar4 = iStack_34 + uStack_30;
        uStack_c = CONCAT13(1,(int3)CONCAT22((short)iStack_18,(ushort)bVar1));
        if (uStack_30 < uVar4) {
          puVar9 = (undefined4 *)(param_1 + uStack_30 * 4);
          for (; iStack_34 != 0; iStack_34 = iStack_34 + -1) {
            *puVar9 = uStack_c;
            puVar9 = puVar9 + 1;
          }
        }
      }
      else {
        iVar7 = iStack_24 + iStack_18;
        if (iVar7 < 1) {
          iVar7 = 1;
        }
        iVar2 = *(int *)(param_5 + iVar7 * 4);
        iStack_10 = param_3 + iVar2 * 2;
        puVar9 = (undefined4 *)(param_1 + uStack_30 * 4);
        puStack_8 = puVar9;
        puVar5 = param_6 + iStack_18 * 0xd;
        auStack_6c[0] = *puVar5;
        auStack_6c[1] = puVar5[1];
        auStack_6c[2] = puVar5[2];
        auStack_6c[3] = puVar5[3];
        uStack_5c = puVar5[4];
        uStack_58 = puVar5[5];
        uStack_54 = puVar5[6];
        uStack_50 = puVar5[7];
        uStack_3c = puVar5[0xc];
        uStack_4c = puVar5[8];
        uStack_48 = puVar5[9];
        uStack_44 = puVar5[10];
        uStack_40 = puVar5[0xb];
        if (1 < iVar7) {
          uVar6 = auStack_6c[iVar7];
          param_7._0_3_ = CONCAT12((char)iStack_18,(ushort)bVar1);
          param_7 = CONCAT13(1,(undefined3)param_7);
          puVar8 = puVar9;
          if (uVar6 != 0) {
            for (; uVar6 != 0; uVar6 = uVar6 - 1) {
              *puVar8 = param_7;
              puVar8 = puVar8 + 1;
            }
          }
        }
        uStack_2c = param_4 - iVar2;
        puStack_8 = (undefined4 *)0x0;
        if (uStack_2c != 0) {
          param_7 = 0x2000000;
          do {
            bVar1 = *(byte *)(iStack_10 + 1 + (int)puStack_8 * 2);
            uVar6 = auStack_6c[bVar1];
            cVar3 = (char)param_8 - bVar1;
            puStack_28 = auStack_6c + bVar1;
            uVar4 = (1 << (((char)param_2 - cVar3) - (char)iStack_18 & 0x1fU)) + uVar6;
            param_7._0_3_ =
                 CONCAT12(cVar3 + (char)iStack_18,
                          (ushort)*(byte *)(iStack_10 + (int)puStack_8 * 2) * 0x100 +
                          (short)uStack_14);
            do {
              puVar9[uVar6] = param_7;
              uVar6 = uVar6 + 1;
            } while (uVar6 < uVar4);
            auStack_6c[bVar1] = uVar4;
            puStack_8 = (undefined4 *)((int)puStack_8 + 1);
          } while (puStack_8 < uStack_2c);
        }
        uVar4 = iStack_34 + uStack_30;
      }
      uVar6 = uStack_1c + 1;
      uStack_1c = uVar6;
      *puStack_38 = uVar4;
    } while (uVar6 < param_4);
  }
  return;
}



/* FUNCTION 21977 ; VA 0x00aa8440 ; FUN_00aa8440 */

uint FUN_00aa8440(int param_1,int param_2,uint param_3)

{
  byte *pbVar1;
  int iVar2;
  char *pcVar3;
  byte bVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  byte *pbVar9;
  uint uVar10;
  int aiStack_48 [14];
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  bVar4 = *(byte *)(param_1 + 7 + param_2 * 8);
  uStack_c = (uint)bVar4;
  if (param_3 < uStack_c) {
    iStack_10 = uStack_c - param_3;
    iVar8 = 0;
    iStack_8 = 1 << ((byte)iStack_10 & 0x1f);
    bVar5 = bVar4;
    uVar6 = uStack_c;
    while (param_3 < uVar6) {
      *(char *)(param_1 + 7 + param_2 * 8) = (char)param_3;
      param_2 = param_2 + -1;
      iVar8 = iVar8 + (iStack_8 - (1 << (bVar4 - bVar5 & 0x1f)));
      bVar5 = *(byte *)(param_1 + 7 + param_2 * 8);
      uVar6 = (uint)bVar5;
    }
    iVar2 = param_1 + 7 + param_2 * 8;
    bVar4 = *(byte *)(param_1 + 7 + param_2 * 8);
    while (bVar4 == param_3) {
      pbVar9 = (byte *)(iVar2 + -8);
      iVar2 = iVar2 + -8;
      param_2 = param_2 + -1;
      bVar4 = *pbVar9;
    }
    uVar6 = iVar8 >> ((byte)iStack_10 & 0x1f);
    FUN_0170d1f0(aiStack_48,0xf0,0x38);
    if (-1 < param_2) {
      pbVar9 = (byte *)(param_1 + 7 + param_2 * 8);
      uVar7 = param_3;
      iVar8 = param_2;
      do {
        uVar10 = (uint)*pbVar9;
        if (uVar10 < uVar7) {
          aiStack_48[param_3 - uVar10] = iVar8;
          uVar7 = uVar10;
        }
        pbVar9 = pbVar9 + -8;
        iVar8 = iVar8 + -1;
      } while (-1 < iVar8);
    }
    while (0 < (int)uVar6) {
      iVar8 = 0x1f;
      if (uVar6 != 0) {
        for (; uVar6 >> iVar8 == 0; iVar8 = iVar8 + -1) {
        }
      }
      uVar7 = iVar8 + 1;
      while ((1 < uVar7 &&
             ((aiStack_48[uVar7] == -0xf0f0f10 ||
              ((aiStack_48[uVar7 - 1] != -0xf0f0f10 &&
               ((uint)(*(int *)(param_1 + aiStack_48[uVar7 - 1] * 8) * 2) <
                *(uint *)(param_1 + aiStack_48[uVar7] * 8)))))))) {
        uVar7 = uVar7 - 1;
      }
      for (; (uVar7 < 0xd && (aiStack_48[uVar7] == -0xf0f0f10)); uVar7 = uVar7 + 1) {
      }
      uVar6 = uVar6 + (-1 << ((char)uVar7 - 1U & 0x1f));
      if (aiStack_48[uVar7 - 1] == -0xf0f0f10) {
        aiStack_48[uVar7 - 1] = aiStack_48[uVar7];
      }
      iVar8 = aiStack_48[uVar7];
      pcVar3 = (char *)(param_1 + 7 + iVar8 * 8);
      *pcVar3 = *pcVar3 + '\x01';
      if ((iVar8 == 0) ||
         (bVar4 = *(byte *)(param_1 + -1 + iVar8 * 8), aiStack_48[uVar7] = iVar8 + -1,
         (uint)bVar4 != param_3 - uVar7)) {
        aiStack_48[uVar7] = -0xf0f0f10;
      }
    }
    for (; uStack_c = param_3, (int)uVar6 < 0; uVar6 = uVar6 + 1) {
      if (aiStack_48[1] == -0xf0f0f10) {
        pbVar9 = (byte *)(param_2 * 8 + 7 + param_1);
        bVar4 = *pbVar9;
        while (bVar4 == param_3) {
          pbVar1 = pbVar9 + -8;
          pbVar9 = pbVar9 + -8;
          param_2 = param_2 + -1;
          bVar4 = *pbVar1;
        }
        pcVar3 = (char *)(param_1 + 0xf + param_2 * 8);
        *pcVar3 = *pcVar3 + -1;
        aiStack_48[1] = param_2;
      }
      else {
        pcVar3 = (char *)(param_1 + 0xf + aiStack_48[1] * 8);
        *pcVar3 = *pcVar3 + -1;
      }
      aiStack_48[1] = aiStack_48[1] + 1;
    }
  }
  return uStack_c;
}



/* FUNCTION 21978 ; VA 0x00aa8610 ; FUN_00aa8610 */

undefined4
FUN_00aa8610(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abda10(param_1,param_2,param_3,param_5,param_6);
  uVar1 = FUN_00aae260(param_1,param_2,param_3,param_4,param_5,param_6,0);
  return uVar1;
}



/* FUNCTION 21979 ; VA 0x00aa8660 ; FUN_00aa8660 */

undefined4
FUN_00aa8660(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uVar1;
  
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abdc80(param_1,param_2,param_3,param_5,param_6);
  uVar1 = FUN_00aae260(param_1,param_2,param_3,param_4,param_5,param_6,1);
  return uVar1;
}



/* FUNCTION 21980 ; VA 0x00aa86b0 ; FUN_00aa86b0 */

undefined4
FUN_00aa86b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            int param_6)

{
  undefined4 uVar1;
  
  if (param_6 == 5) {
    if ((uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4)) <= param_2) {
      FUN_00abda10(param_1,param_2,param_3,param_5,5);
      uVar1 = 5;
      goto LAB_00aa8729;
    }
  }
  else {
    if (param_6 - 6U < 2) {
      uVar1 = FUN_00aa8610();
      return uVar1;
    }
    if ((uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4)) <= param_2) {
      FUN_00abda10(param_1,param_2,param_3,param_5,4);
      uVar1 = 4;
LAB_00aa8729:
      uVar1 = FUN_00aae260(param_1,param_2,param_3,param_4,param_5,uVar1,0);
      return uVar1;
    }
  }
  return 0;
}



/* FUNCTION 21981 ; VA 0x00aa8740 ; FUN_00aa8740 */

undefined4
FUN_00aa8740(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            int param_6)

{
  undefined4 uVar1;
  
  if (param_6 == 5) {
    if ((uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4)) <= param_2) {
      FUN_00abdc80(param_1,param_2,param_3,param_5,5);
      uVar1 = 5;
      goto LAB_00aa87b9;
    }
  }
  else {
    if (param_6 - 6U < 2) {
      uVar1 = FUN_00aa8660();
      return uVar1;
    }
    if ((uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4)) <= param_2) {
      FUN_00abdc80(param_1,param_2,param_3,param_5,4);
      uVar1 = 4;
LAB_00aa87b9:
      uVar1 = FUN_00aae260(param_1,param_2,param_3,param_4,param_5,uVar1,1);
      return uVar1;
    }
  }
  return 0;
}



/* FUNCTION 21982 ; VA 0x00aa87d0 ; FUN_00aa87d0 */

undefined4
FUN_00aa87d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abda10(param_1,param_2,param_3,param_4,param_5);
  uVar1 = FUN_00aae540(param_1,param_2,param_3,param_4,param_5,0,param_6,param_7);
  return uVar1;
}



/* FUNCTION 21983 ; VA 0x00aa8820 ; FUN_00aa8820 */

undefined4
FUN_00aa8820(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abdc80(param_1,param_2,param_3,param_4,param_5);
  uVar1 = FUN_00aae540(param_1,param_2,param_3,param_4,param_5,1,param_6,param_7);
  return uVar1;
}



/* FUNCTION 21984 ; VA 0x00aa8870 ; FUN_00aa8870 */

undefined4
FUN_00aa8870(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  
  switch(param_5) {
  case 3:
    uVar1 = FUN_00aa87d0();
    return uVar1;
  case 5:
    uVar1 = FUN_00aa87d0();
    return uVar1;
  case 6:
  case 7:
    uVar1 = FUN_00aa87d0();
    return uVar1;
  }
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abda10(param_1,param_2,param_3,param_4,4);
  uVar1 = FUN_00aae540(param_1,param_2,param_3,param_4,4,0,param_6,param_7);
  return uVar1;
}



/* FUNCTION 21985 ; VA 0x00aa8910 ; FUN_00aa8910 */

undefined4
FUN_00aa8910(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  
  switch(param_5) {
  case 3:
    uVar1 = FUN_00aa8820();
    return uVar1;
  case 5:
    uVar1 = FUN_00aa8820();
    return uVar1;
  case 6:
  case 7:
    uVar1 = FUN_00aa8820();
    return uVar1;
  }
  if (param_2 < (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4))) {
    return 0;
  }
  FUN_00abdc80(param_1,param_2,param_3,param_4,4);
  uVar1 = FUN_00aae540(param_1,param_2,param_3,param_4,4,1,param_6,param_7);
  return uVar1;
}



/* FUNCTION 21986 ; VA 0x00aa89b0 ; FUN_00aa89b0 */

uint FUN_00aa89b0(int param_1,uint *param_2,uint *param_3,int *param_4,int param_5,uint param_6)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint *puVar11;
  uint uVar12;
  uint *puVar13;
  uint *puVar14;
  int iVar15;
  int iStack_18;
  uint uStack_8;
  
  iVar1 = *(int *)(param_1 + 4);
  if (param_6 == 5) {
    iVar2 = *(int *)(param_1 + 0x218);
    uVar7 = 1 << ((byte)*(undefined4 *)(param_1 + 0x94) & 0x1f);
    iVar4 = *(int *)(param_1 + 8);
    uVar3 = *(uint *)(param_1 + 0xc);
    param_6 = 3;
    uVar5 = *(uint *)(param_1 + 0x10);
    uVar12 = (int)param_2 - iVar1;
    iStack_18 = param_5;
    uVar10 = FUN_00abd7f0(param_1,param_2,5);
    if (0 < param_5 && uVar5 < uVar10) {
      do {
        if (uVar10 < uVar3) {
          if (*(uint *)(uVar10 + iVar4) == *param_2) {
            puVar14 = param_2 + 1;
            iVar15 = iVar4 + 4 + uVar10;
            puVar11 = (uint *)((int)puVar14 + ((uVar3 + iVar4) - iVar15));
            puVar13 = param_3;
            if (puVar11 < param_3) {
              puVar13 = puVar11;
            }
            iVar9 = FUN_00abcfb0(puVar14,iVar15,puVar13);
            if (iVar9 + iVar15 == uVar3 + iVar4) {
              iVar15 = FUN_00abcfb0((int)puVar14 + iVar9,uVar3 + iVar1,param_3);
              iVar9 = iVar9 + iVar15;
            }
            uVar8 = iVar9 + 4;
            goto LAB_00aa8e4a;
          }
        }
        else {
          puVar13 = (uint *)(iVar1 + uVar10);
          if (*(char *)((int)puVar13 + param_6) == *(char *)(param_6 + (int)param_2)) {
            puVar11 = param_2;
            if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa8da5:
              uVar8 = *puVar11 ^ *puVar13;
              if (uVar8 == 0) goto code_r0x00aa8dab;
              uVar6 = 0;
              if (uVar8 != 0) {
                for (; (uVar8 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                }
              }
              uVar8 = ((uVar6 >> 3) - (int)param_2) + (int)puVar11;
              goto LAB_00aa8e4a;
            }
LAB_00aa8db5:
            if ((puVar11 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar13 == *(short *)puVar11))
            {
              puVar11 = (uint *)((int)puVar11 + 2);
              puVar13 = (uint *)((int)puVar13 + 2);
            }
            if ((puVar11 < param_3) && (*(char *)puVar13 == *(char *)puVar11)) {
              puVar11 = (uint *)((int)puVar11 + 1);
            }
            uVar8 = (int)puVar11 - (int)param_2;
LAB_00aa8e4a:
            if ((param_6 < uVar8) &&
               (*param_4 = (uVar12 - uVar10) + 2, param_6 = uVar8,
               (uint *)(uVar8 + (int)param_2) == param_3)) {
              return uVar8;
            }
          }
        }
        if (uVar10 <= (-(uint)(uVar7 < uVar12) & uVar12 - uVar7)) {
          return param_6;
        }
        iStack_18 = iStack_18 + -1;
        uVar10 = *(uint *)(iVar2 + (uVar10 & uVar7 - 1) * 4);
      } while (0 < iStack_18 && uVar5 < uVar10);
    }
    return param_6;
  }
  iVar2 = *(int *)(param_1 + 0x218);
  uVar3 = *(uint *)(param_1 + 0xc);
  iVar4 = *(int *)(param_1 + 8);
  uVar5 = *(uint *)(param_1 + 0x10);
  uVar12 = 1 << ((byte)*(undefined4 *)(param_1 + 0x94) & 0x1f);
  uVar10 = (int)param_2 - iVar1;
  uStack_8 = 3;
  if (param_6 - 6 < 2) {
    iStack_18 = param_5;
    uVar7 = FUN_00abd7f0(param_1,param_2,6);
    if (0 < param_5 && uVar5 < uVar7) {
      do {
        if (uVar7 < uVar3) {
          if (*(uint *)(uVar7 + iVar4) == *param_2) {
            puVar14 = param_2 + 1;
            iVar15 = iVar4 + 4 + uVar7;
            puVar11 = (uint *)((int)puVar14 + ((iVar4 + uVar3) - iVar15));
            puVar13 = param_3;
            if (puVar11 < param_3) {
              puVar13 = puVar11;
            }
            iVar9 = FUN_00abcfb0(puVar14,iVar15,puVar13);
            if (iVar9 + iVar15 == iVar4 + uVar3) {
              iVar15 = FUN_00abcfb0((int)puVar14 + iVar9,iVar1 + uVar3,param_3);
              iVar9 = iVar9 + iVar15;
            }
            uVar8 = iVar9 + 4;
            goto LAB_00aa8b30;
          }
        }
        else {
          puVar13 = (uint *)(iVar1 + uVar7);
          if (*(char *)((int)puVar13 + uStack_8) == *(char *)(uStack_8 + (int)param_2)) {
            puVar11 = param_2;
            if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa8a80:
              uVar8 = *puVar11 ^ *puVar13;
              if (uVar8 == 0) goto code_r0x00aa8a86;
              uVar6 = 0;
              if (uVar8 != 0) {
                for (; (uVar8 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                }
              }
              uVar8 = ((uVar6 >> 3) - (int)param_2) + (int)puVar11;
              goto LAB_00aa8b30;
            }
LAB_00aa8a90:
            if ((puVar11 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar13 == *(short *)puVar11))
            {
              puVar11 = (uint *)((int)puVar11 + 2);
              puVar13 = (uint *)((int)puVar13 + 2);
            }
            if ((puVar11 < param_3) && (*(char *)puVar13 == *(char *)puVar11)) {
              puVar11 = (uint *)((int)puVar11 + 1);
            }
            uVar8 = (int)puVar11 - (int)param_2;
LAB_00aa8b30:
            if ((uStack_8 < uVar8) &&
               (*param_4 = (uVar10 - uVar7) + 2, uStack_8 = uVar8,
               (uint *)(uVar8 + (int)param_2) == param_3)) {
              return uVar8;
            }
          }
        }
        if (uVar7 <= (-(uint)(uVar12 < uVar10) & uVar10 - uVar12)) {
          return uStack_8;
        }
        iStack_18 = iStack_18 + -1;
        uVar7 = *(uint *)(iVar2 + (uVar7 & uVar12 - 1) * 4);
        if (iStack_18 < 1 || uVar7 <= uVar5) {
          return uStack_8;
        }
      } while( true );
    }
  }
  else {
    iStack_18 = param_5;
    uVar7 = FUN_00abd7f0(param_1,param_2,4);
    if (0 < param_5 && uVar5 < uVar7) {
      do {
        if (uVar7 < uVar3) {
          if (*(uint *)(uVar7 + iVar4) == *param_2) {
            puVar14 = param_2 + 1;
            iVar15 = iVar4 + 4 + uVar7;
            puVar11 = (uint *)((int)puVar14 + ((iVar4 + uVar3) - iVar15));
            puVar13 = param_3;
            if (puVar11 < param_3) {
              puVar13 = puVar11;
            }
            iVar9 = FUN_00abcfb0(puVar14,iVar15,puVar13);
            if (iVar9 + iVar15 == iVar4 + uVar3) {
              iVar15 = FUN_00abcfb0((int)puVar14 + iVar9,iVar1 + uVar3,param_3);
              iVar9 = iVar9 + iVar15;
            }
            uVar8 = iVar9 + 4;
            goto LAB_00aa8ca7;
          }
        }
        else {
          puVar13 = (uint *)(iVar1 + uVar7);
          if (*(char *)((int)puVar13 + uStack_8) == *(char *)(uStack_8 + (int)param_2)) {
            puVar11 = param_2;
            if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa8bf7:
              uVar8 = *puVar13 ^ *puVar11;
              if (uVar8 == 0) goto code_r0x00aa8bfd;
              uVar6 = 0;
              if (uVar8 != 0) {
                for (; (uVar8 >> uVar6 & 1) == 0; uVar6 = uVar6 + 1) {
                }
              }
              uVar8 = ((uVar6 >> 3) - (int)param_2) + (int)puVar11;
              goto LAB_00aa8ca7;
            }
LAB_00aa8c07:
            if ((puVar11 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar13 == *(short *)puVar11))
            {
              puVar11 = (uint *)((int)puVar11 + 2);
              puVar13 = (uint *)((int)puVar13 + 2);
            }
            if ((puVar11 < param_3) && (*(char *)puVar13 == *(char *)puVar11)) {
              puVar11 = (uint *)((int)puVar11 + 1);
            }
            uVar8 = (int)puVar11 - (int)param_2;
LAB_00aa8ca7:
            if ((uStack_8 < uVar8) &&
               (*param_4 = (uVar10 - uVar7) + 2, uStack_8 = uVar8,
               (uint *)(uVar8 + (int)param_2) == param_3)) {
              return uVar8;
            }
          }
        }
        if (uVar7 <= (-(uint)(uVar12 < uVar10) & uVar10 - uVar12)) {
          return uStack_8;
        }
        iStack_18 = iStack_18 + -1;
        uVar7 = *(uint *)(iVar2 + (uVar7 & uVar12 - 1) * 4);
      } while (0 < iStack_18 && uVar5 < uVar7);
    }
  }
  return uStack_8;
code_r0x00aa8dab:
  puVar11 = puVar11 + 1;
  puVar13 = puVar13 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar11) goto LAB_00aa8db5;
  goto LAB_00aa8da5;
code_r0x00aa8bfd:
  puVar11 = puVar11 + 1;
  puVar13 = puVar13 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar11) goto LAB_00aa8c07;
  goto LAB_00aa8bf7;
code_r0x00aa8a86:
  puVar11 = puVar11 + 1;
  puVar13 = puVar13 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar11) goto LAB_00aa8a90;
  goto LAB_00aa8a80;
}



/* FUNCTION 21987 ; VA 0x00aa8ea0 ; FUN_00aa8ea0 */

char * FUN_00aa8ea0(int param_1,uint *param_2,uint *param_3,int *param_4,int param_5,char *param_6)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  uint uVar9;
  uint *puVar10;
  char *pcVar11;
  char *pcVar12;
  int iStack_14;
  char *pcStack_c;
  char *pcStack_8;
  
  if (param_6 == (char *)0x5) {
    pcVar12 = (char *)0x3;
    iVar1 = *(int *)(param_1 + 0x218);
    uVar5 = 1 << ((byte)*(undefined4 *)(param_1 + 0x94) & 0x1f);
    uVar3 = *(uint *)(param_1 + 0x10);
    param_6 = (char *)0x3;
    iVar2 = *(int *)(param_1 + 4);
    uVar9 = (int)param_2 - iVar2;
    iStack_14 = param_5;
    uVar7 = FUN_00abd7f0(param_1,param_2,5);
    if (0 < param_5 && uVar3 < uVar7) {
      do {
        puVar10 = (uint *)(iVar2 + uVar7);
        if (*(char *)((int)puVar10 + (int)pcVar12) == pcVar12[(int)param_2]) {
          puVar8 = param_2;
          if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa9190:
            uVar6 = *puVar8 ^ *puVar10;
            if (uVar6 == 0) goto code_r0x00aa919a;
            uVar4 = 0;
            if (uVar6 != 0) {
              for (; (uVar6 >> uVar4 & 1) == 0; uVar4 = uVar4 + 1) {
              }
            }
            pcVar11 = (char *)(((uVar4 >> 3) - (int)param_2) + (int)puVar8);
            goto LAB_00aa91cb;
          }
LAB_00aa91a4:
          if ((puVar8 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar10 == *(short *)puVar8)) {
            puVar8 = (uint *)((int)puVar8 + 2);
            puVar10 = (uint *)((int)puVar10 + 2);
          }
          if ((puVar8 < param_3) && (*(char *)puVar10 == *(char *)puVar8)) {
            puVar8 = (uint *)((int)puVar8 + 1);
          }
          pcVar11 = (char *)((int)puVar8 - (int)param_2);
LAB_00aa91cb:
          pcVar12 = param_6;
          if ((param_6 < pcVar11) &&
             (*param_4 = (uVar9 - uVar7) + 2, pcVar12 = pcVar11, param_6 = pcVar11,
             (uint *)(pcVar11 + (int)param_2) == param_3)) {
            return pcVar11;
          }
        }
        if (uVar7 <= (-(uint)(uVar5 < uVar9) & uVar9 - uVar5)) {
          return pcVar12;
        }
        uVar7 = *(uint *)(iVar1 + (uVar7 & uVar5 - 1) * 4);
        iStack_14 = iStack_14 + -1;
      } while (0 < iStack_14 && uVar3 < uVar7);
    }
  }
  else {
    iVar1 = *(int *)(param_1 + 0x218);
    iVar2 = *(int *)(param_1 + 4);
    uVar3 = *(uint *)(param_1 + 0x10);
    uVar9 = 1 << ((byte)*(undefined4 *)(param_1 + 0x94) & 0x1f);
    uVar7 = (int)param_2 - iVar2;
    pcVar12 = (char *)0x3;
    if ((int)param_6 - 6U < 2) {
      pcStack_8 = (char *)0x3;
      pcStack_c = (char *)param_5;
      uVar5 = FUN_00abd7f0(param_1,param_2,6);
      if (0 < param_5 && uVar3 < uVar5) {
        do {
          puVar10 = (uint *)(iVar2 + uVar5);
          if (*(char *)((int)puVar10 + (int)pcVar12) == pcVar12[(int)param_2]) {
            puVar8 = param_2;
            if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa8f50:
              uVar6 = *puVar8 ^ *puVar10;
              if (uVar6 == 0) goto code_r0x00aa8f5a;
              uVar4 = 0;
              if (uVar6 != 0) {
                for (; (uVar6 >> uVar4 & 1) == 0; uVar4 = uVar4 + 1) {
                }
              }
              pcVar11 = (char *)(((uVar4 >> 3) - (int)param_2) + (int)puVar8);
              goto LAB_00aa8f8b;
            }
LAB_00aa8f64:
            if ((puVar8 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar10 == *(short *)puVar8)) {
              puVar8 = (uint *)((int)puVar8 + 2);
              puVar10 = (uint *)((int)puVar10 + 2);
            }
            if ((puVar8 < param_3) && (*(char *)puVar10 == *(char *)puVar8)) {
              puVar8 = (uint *)((int)puVar8 + 1);
            }
            pcVar11 = (char *)((int)puVar8 - (int)param_2);
LAB_00aa8f8b:
            pcVar12 = pcStack_8;
            if ((pcStack_8 < pcVar11) &&
               (*param_4 = (uVar7 - uVar5) + 2, pcVar12 = pcVar11, pcStack_8 = pcVar11,
               (uint *)(pcVar11 + (int)param_2) == param_3)) {
              return pcVar11;
            }
          }
          if (uVar5 <= (-(uint)(uVar9 < uVar7) & uVar7 - uVar9)) {
            return pcVar12;
          }
          uVar5 = *(uint *)(iVar1 + (uVar5 & uVar9 - 1) * 4);
          pcStack_c = (char *)((int)pcStack_c + -1);
          if ((int)pcStack_c < 1 || uVar5 <= uVar3) {
            return pcVar12;
          }
        } while( true );
      }
    }
    else {
      pcStack_c = (char *)0x3;
      pcStack_8 = (char *)param_5;
      uVar5 = FUN_00abd7f0(param_1,param_2,4);
      if (0 < param_5 && uVar3 < uVar5) {
        do {
          puVar10 = (uint *)(iVar2 + uVar5);
          if (*(char *)((int)puVar10 + (int)pcVar12) == pcVar12[(int)param_2]) {
            puVar8 = param_2;
            if (param_2 < (uint *)((int)param_3 + -3)) {
LAB_00aa9060:
              uVar6 = *puVar10 ^ *puVar8;
              if (uVar6 == 0) goto code_r0x00aa906a;
              uVar4 = 0;
              if (uVar6 != 0) {
                for (; (uVar6 >> uVar4 & 1) == 0; uVar4 = uVar4 + 1) {
                }
              }
              pcVar11 = (char *)(((uVar4 >> 3) - (int)param_2) + (int)puVar8);
              goto LAB_00aa909b;
            }
LAB_00aa9074:
            if ((puVar8 < (uint *)((int)param_3 - 1U)) && (*(short *)puVar10 == *(short *)puVar8)) {
              puVar8 = (uint *)((int)puVar8 + 2);
              puVar10 = (uint *)((int)puVar10 + 2);
            }
            if ((puVar8 < param_3) && (*(char *)puVar10 == *(char *)puVar8)) {
              puVar8 = (uint *)((int)puVar8 + 1);
            }
            pcVar11 = (char *)((int)puVar8 - (int)param_2);
LAB_00aa909b:
            pcVar12 = pcStack_c;
            if ((pcStack_c < pcVar11) &&
               (*param_4 = (uVar7 - uVar5) + 2, pcVar12 = pcVar11, pcStack_c = pcVar11,
               (uint *)(pcVar11 + (int)param_2) == param_3)) {
              return pcVar11;
            }
          }
          if (uVar5 <= (-(uint)(uVar9 < uVar7) & uVar7 - uVar9)) {
            return pcVar12;
          }
          uVar5 = *(uint *)(iVar1 + (uVar5 & uVar9 - 1) * 4);
          pcStack_8 = (char *)((int)pcStack_8 + -1);
          if ((int)pcStack_8 < 1 || uVar5 <= uVar3) {
            return pcVar12;
          }
        } while( true );
      }
    }
  }
  return pcVar12;
code_r0x00aa919a:
  puVar8 = puVar8 + 1;
  puVar10 = puVar10 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar8) goto LAB_00aa91a4;
  goto LAB_00aa9190;
code_r0x00aa906a:
  puVar8 = puVar8 + 1;
  puVar10 = puVar10 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar8) goto LAB_00aa9074;
  goto LAB_00aa9060;
code_r0x00aa8f5a:
  puVar8 = puVar8 + 1;
  puVar10 = puVar10 + 1;
  if ((uint *)((int)param_3 + -3) <= puVar8) goto LAB_00aa8f64;
  goto LAB_00aa8f50;
}



/* FUNCTION 21988 ; VA 0x00aa9240 ; FUN_00aa9240 */

void FUN_00aa9240(uint *param_1,uint param_2,uint param_3,uint param_4,uint param_5,
                 undefined8 param_6,uint param_7,uint param_8,int param_9,uint param_10)

{
  int iVar1;
  uint uVar2;
  
  if (((param_10 == 0) || (param_9 + (uint)(0xfffffffe < param_8) != 0)) || (1 < param_8 + 1)) {
    if (((param_8 == 0 && param_9 == 0) || (param_9 != 0)) || (0x1fffffff < param_8))
    goto LAB_00aa92c1;
  }
  else {
    param_8 = 0x201;
  }
  if (param_10 < 0x20000000) {
    if (param_8 + param_10 < 0x40) {
      if (6 < param_2) {
        param_2 = 6;
      }
    }
    else {
      uVar2 = (param_8 + param_10) - 1;
      iVar1 = 0x1f;
      if (uVar2 != 0) {
        for (; uVar2 >> iVar1 == 0; iVar1 = iVar1 + -1) {
        }
      }
      if (iVar1 + 1U < param_2) {
        param_2 = iVar1 + 1U;
      }
    }
  }
LAB_00aa92c1:
  if (param_2 < param_4) {
    param_4 = param_2;
  }
  uVar2 = param_3 - (5 < param_7);
  if (param_2 < uVar2) {
    param_3 = param_3 + (param_2 - uVar2);
  }
  if (param_2 < 10) {
    param_2 = 10;
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  *(undefined8 *)(param_1 + 4) = param_6;
  param_1[6] = param_7;
  return;
}



/* FUNCTION 21989 ; VA 0x00aa9320 ; FUN_00aa9320 */

void FUN_00aa9320(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25,undefined4 param_26,undefined4 param_27,undefined4 param_28,
                 undefined4 param_29,undefined8 param_30,undefined4 param_31,undefined8 param_32,
                 undefined4 param_33)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  param_1[5] = param_7;
  param_1[6] = param_8;
  param_1[7] = param_9;
  param_1[8] = param_10;
  param_1[9] = param_11;
  param_1[10] = param_12;
  param_1[0xb] = param_13;
  param_1[0xc] = param_14;
  param_1[0xd] = param_15;
  param_1[0xe] = param_16;
  param_1[0xf] = param_17;
  param_1[0x10] = param_18;
  param_1[0x11] = param_19;
  param_1[0x12] = param_20;
  param_1[0x13] = param_21;
  param_1[0x14] = param_22;
  param_1[0x15] = param_23;
  param_1[0x16] = param_24;
  param_1[0x17] = param_25;
  param_1[0xb] = 999;
  param_1[1] = param_26;
  param_1[2] = param_27;
  param_1[3] = param_28;
  param_1[4] = param_29;
  *(undefined8 *)(param_1 + 5) = param_30;
  param_1[7] = param_31;
  *(undefined8 *)(param_1 + 8) = param_32;
  param_1[10] = param_33;
  return;
}



/* FUNCTION 21990 ; VA 0x00aa9390 ; FUN_00aa9390 */

uint FUN_00aa9390(undefined *param_1,undefined4 param_2,undefined2 *param_3,undefined4 param_4,
                 undefined4 param_5,int param_6,uint param_7,undefined *param_8,int param_9,
                 undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_74 [108];
  undefined4 uStack_8;
  
  switch(param_5) {
  case 0:
    uVar3 = FUN_00ab0480(param_3,param_10,param_12,param_11,param_13,param_14);
    if (0xffffff88 < uVar3) {
      return uVar3;
    }
switchD_00aa93a6_caseD_3:
    return 0;
  case 1:
    *param_1 = *param_8;
    *param_3 = 0;
    param_3[1] = (ushort)(byte)param_7;
    *(undefined4 *)(param_3 + 2) = 0;
    *(undefined4 *)(param_3 + (param_7 & 0xff) * 4 + 6) = 0;
    *(undefined4 *)(param_3 + (param_7 & 0xff) * 4 + 4) = 0;
    return 1;
  case 2:
    uStack_8 = FUN_00ab14f0(param_4,param_9,param_7);
    puVar1 = (uint *)(param_6 + (uint)(byte)param_8[param_9 + -1] * 4);
    uVar3 = *puVar1;
    if (1 < uVar3) {
      param_9 = param_9 + -1;
      *puVar1 = uVar3 - 1;
    }
    uVar3 = FUN_00ab12e0(auStack_74,uStack_8,param_6,param_9,param_7);
    uVar2 = uStack_8;
    if (((uVar3 < 0xffffff89) &&
        (uVar4 = FUN_00ab17c0(param_1,param_2,auStack_74,param_7,uStack_8), uVar3 = uVar4,
        uVar4 < 0xffffff89)) &&
       (uVar3 = FUN_00ab0480(param_3,auStack_74,param_7,uVar2,param_13,param_14), uVar3 < 0xffffff89
       )) {
      uVar3 = uVar4;
    }
    return uVar3;
  case 3:
    goto switchD_00aa93a6_caseD_3;
  default:
    return 0xffffffff;
  }
}



/* FUNCTION 21991 ; VA 0x00aa94c0 ; FUN_00aa94c0 */

uint FUN_00aa94c0(undefined4 *param_1,undefined4 *param_2,uint param_3,uint param_4,uint param_5,
                 byte *param_6,int param_7,undefined4 param_8,int param_9)

{
  byte bVar1;
  uint uVar2;
  undefined auStack_70 [108];
  
  if (param_3 == 0) {
    *param_2 = param_8;
    return 0;
  }
  if (param_3 == 1) {
    if (param_7 == 0) {
      return 0xffffffb8;
    }
    bVar1 = *param_6;
    if (bVar1 <= param_4) {
      *param_1 = 0;
      *(undefined2 *)(param_1 + 1) = 0;
      *(undefined *)((int)param_1 + 7) = 0;
      *(byte *)((int)param_1 + 6) = bVar1;
      *param_2 = param_1;
      return 1;
    }
  }
  else if (param_3 == 3) {
    if (param_9 != 0) {
      return 0;
    }
  }
  else {
    uVar2 = FUN_00ab1560(auStack_70,&param_4,&param_3,param_6,param_7);
    if ((uVar2 < 0xffffff89) && (param_3 <= param_5)) {
      FUN_00ab0680(param_1,auStack_70,param_4,param_3);
      *param_2 = param_1;
      return uVar2;
    }
  }
  return 0xffffffec;
}



/* FUNCTION 21992 ; VA 0x00aa9590 ; FUN_00aa9590 */

undefined4 FUN_00aa9590(int param_1,uint param_2,uint param_3)

{
  uint uVar1;
  
  if (param_3 <= param_2) {
    uVar1 = 0;
    while (*(short *)(param_1 + uVar1 * 2) != 0) {
      uVar1 = uVar1 + 1;
      if (param_3 < uVar1) {
        return 0;
      }
    }
  }
  return 0xffffffe2;
}



/* FUNCTION 21993 ; VA 0x00aa95c0 ; FUN_00aa95c0 */

int FUN_00aa95c0(int param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  char *pcVar12;
  char *pcVar13;
  int iVar14;
  uint uVar15;
  int *piVar16;
  int iVar17;
  int iVar18;
  uint uVar19;
  int iVar20;
  int iVar21;
  char *pcVar22;
  byte bVar23;
  int *piVar24;
  char *pcVar25;
  int *piVar26;
  int *piVar27;
  int *piVar28;
  int *piVar29;
  undefined4 uVar30;
  int iStack_54;
  int iStack_28;
  int *piStack_20;
  int iStack_10;
  
  piStack_20 = param_2;
  iVar2 = *(int *)(param_1 + 0x210);
  iVar3 = *(int *)(param_1 + 4);
  iVar4 = *(int *)(param_1 + 0x218);
  uVar5 = *(undefined4 *)(param_1 + 0x94);
  iVar6 = *(int *)(param_1 + 8);
  uVar7 = *(uint *)(param_1 + 0x10);
  piVar11 = (int *)(uVar7 + iVar6);
  uVar8 = *(uint *)(param_1 + 0xc);
  piVar24 = (int *)(iVar3 + uVar8);
  pcVar12 = (char *)(uVar8 + iVar6);
  pcVar13 = (char *)(param_3 + (int)param_2);
  piVar1 = (int *)(pcVar13 + -8);
  iStack_10 = *(int *)(param_1 + 0x194);
  iStack_28 = *(int *)(param_1 + 0x198);
  if (param_2 < pcVar13 + -8) {
    bVar23 = 0x20 - (char)uVar5;
    iVar14 = param_4 + -5;
    piVar27 = param_2;
    do {
      iVar21 = iStack_10;
      switch(iVar14) {
      case 0:
        uVar30 = 0xbb000000;
        break;
      case 1:
        uVar30 = 0xbf9b0000;
        break;
      case 2:
        uVar30 = 0xbfa56300;
        break;
      case 3:
        uVar30 = 0xb7a56463;
        break;
      default:
        uVar15 = (uint)(*piVar27 * -0x61c8864f) >> (bVar23 & 0x1f);
        goto LAB_00aa96d9;
      }
      FUN_016f39b0(*piVar27,piVar27[1],uVar30,0xcf1bbcdc);
      uVar15 = FUN_016f4650();
LAB_00aa96d9:
      uVar9 = *(uint *)(iVar4 + uVar15 * 4);
      iVar20 = iVar3;
      if (uVar9 < uVar8) {
        iVar20 = iVar6;
      }
      piVar16 = (int *)(iVar20 + uVar9);
      FUN_016f39b0(*piVar27,piVar27[1],0xb7a56463,0xcf1bbcdc);
      iVar17 = FUN_016f4650();
      uVar10 = *(uint *)(iVar2 + iVar17 * 4);
      iVar20 = iVar3;
      if (uVar10 < uVar8) {
        iVar20 = iVar6;
      }
      piVar26 = (int *)(uVar10 + iVar20);
      iVar18 = (int)piVar27 - iVar3;
      uVar19 = (iVar18 - iStack_10) + 1;
      iVar20 = iVar3;
      if (uVar19 < uVar8) {
        iVar20 = iVar6;
      }
      *(int *)(iVar2 + iVar17 * 4) = iVar18;
      *(int *)(iVar4 + uVar15 * 4) = iVar18;
      if ((uVar7 < uVar19 && 2 < (uVar8 - uVar19) - 1) &&
         (piVar28 = (int *)((int)piVar27 + 1), *(int *)(iVar20 + uVar19) == *piVar28)) {
        iVar21 = (int)piVar27 + 5;
        pcVar22 = pcVar13;
        if (uVar19 < uVar8) {
          pcVar22 = pcVar12;
        }
        piVar16 = (int *)(iVar20 + uVar19) + 1;
        pcVar25 = pcVar13;
        if (pcVar22 + (iVar21 - (int)piVar16) < pcVar13) {
          pcVar25 = pcVar22 + (iVar21 - (int)piVar16);
        }
        iVar20 = FUN_00abcfb0(iVar21,piVar16,pcVar25);
        if ((char *)(iVar20 + (int)piVar16) == pcVar22) {
          iVar21 = FUN_00abcfb0(iVar21 + iVar20,piVar24,pcVar13);
          iVar20 = iVar20 + iVar21;
        }
        iVar20 = iVar20 + 4;
        uVar15 = (int)piVar28 - (int)piStack_20;
        piVar16 = *(int **)(param_1 + 0x17c);
        piVar26 = (int *)(uVar15 + (int)piVar16);
        do {
          *piVar16 = *piStack_20;
          piVar16[1] = piStack_20[1];
          piVar16 = piVar16 + 2;
          piStack_20 = piStack_20 + 2;
        } while (piVar16 < piVar26);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar15;
        if (0xffff < uVar15) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar15;
        **(undefined4 **)(param_1 + 0x174) = 1;
LAB_00aa9bd0:
        if (0xffff < iVar20 - 3U) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        param_2 = (int *)((int)piVar28 + iVar20);
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)(iVar20 - 3U);
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        piVar16 = param_2;
        piStack_20 = param_2;
        if (piVar1 < param_2) goto LAB_00aa9e0e;
        switch(iVar14) {
        case 0:
          uVar30 = 0xbb000000;
          break;
        case 1:
          uVar30 = 0xbf9b0000;
          break;
        case 2:
          uVar30 = 0xbfa56300;
          break;
        case 3:
          uVar30 = 0xb7a56463;
          break;
        default:
          uVar15 = (uint)(*(int *)((int)piVar27 + 2) * -0x61c8864f) >> (bVar23 & 0x1f);
          goto LAB_00aa9c7d;
        }
        FUN_016f39b0(*(undefined4 *)((int)piVar27 + 2),*(undefined4 *)((int)piVar27 + 6),uVar30,
                     0xcf1bbcdc);
        uVar15 = FUN_016f4650();
LAB_00aa9c7d:
        *(int *)(iVar4 + uVar15 * 4) = iVar18 + 2;
        FUN_016f39b0(*(undefined4 *)((int)piVar27 + 2),*(undefined4 *)((int)piVar27 + 6),0xb7a56463,
                     0xcf1bbcdc);
        iVar21 = FUN_016f4650();
        *(int *)(iVar2 + iVar21 * 4) = iVar18 + 2;
        switch(iVar14) {
        case 0:
          uVar30 = 0xbb000000;
          break;
        case 1:
          uVar30 = 0xbf9b0000;
          break;
        case 2:
          uVar30 = 0xbfa56300;
          break;
        case 3:
          uVar30 = 0xb7a56463;
          break;
        default:
          uVar15 = (uint)(*(int *)((int)param_2 + -2) * -0x61c8864f) >> (bVar23 & 0x1f);
          goto LAB_00aa9d0f;
        }
        FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),uVar30,
                     0xcf1bbcdc);
        uVar15 = FUN_016f4650();
LAB_00aa9d0f:
        iVar20 = (int)param_2 + (-2 - iVar3);
        *(int *)(iVar4 + uVar15 * 4) = iVar20;
        FUN_016f39b0(*(undefined4 *)((int)param_2 + -2),*(undefined4 *)((int)param_2 + 2),0xb7a56463
                     ,0xcf1bbcdc);
        iVar21 = FUN_016f4650();
        *(int *)(iVar2 + iVar21 * 4) = iVar20;
        do {
          iVar21 = iStack_28;
          iVar17 = (int)param_2 - iVar3;
          uVar15 = iVar17 - iStack_28;
          iVar20 = iVar6;
          if (uVar8 <= uVar15) {
            iVar20 = iVar3;
          }
          piVar16 = param_2;
          piStack_20 = param_2;
          if ((uVar15 <= uVar7 || (uVar8 - uVar15) - 1 < 3) ||
             (*(int *)(iVar20 + uVar15) != *param_2)) break;
          pcVar22 = pcVar13;
          if (uVar15 < uVar8) {
            pcVar22 = pcVar12;
          }
          iVar20 = FUN_00abd020(param_2 + 1,uVar15 + 4 + iVar20,pcVar13,pcVar22,piVar24);
          iStack_28 = iStack_10;
          iStack_10 = iVar21;
          FUN_00abd980(param_1 + 0x170,0,param_2,0,iVar20 + 1);
          iVar21 = FUN_00abd760(param_2,uVar5,param_4);
          *(int *)(iVar4 + iVar21 * 4) = iVar17;
          FUN_016f39b0(*param_2,param_2[1],0xb7a56463,0xcf1bbcdc);
          iVar21 = FUN_016f4650();
          param_2 = (int *)((int)param_2 + iVar20 + 4);
          *(int *)(iVar2 + iVar21 * 4) = iVar17;
          piVar16 = param_2;
          piStack_20 = param_2;
        } while (param_2 <= piVar1);
      }
      else {
        piVar28 = piVar27;
        if ((uVar7 < uVar10) && ((*piVar26 == *piVar27 && (piVar26[1] == piVar27[1])))) {
          piVar16 = piVar26 + 2;
          pcVar22 = pcVar13;
          piVar29 = piVar24;
          if (uVar10 < uVar8) {
            pcVar22 = pcVar12;
            piVar29 = piVar11;
          }
          pcVar25 = pcVar13;
          if (pcVar22 + ((int)(piVar27 + 2) - (int)piVar16) < pcVar13) {
            pcVar25 = pcVar22 + ((int)(piVar27 + 2) - (int)piVar16);
          }
          iVar20 = FUN_00abcfb0(piVar27 + 2,piVar16,pcVar25);
          if ((char *)(iVar20 + (int)piVar16) == pcVar22) {
            iVar17 = FUN_00abcfb0(iVar20 + 8 + (int)piVar27,piVar24,pcVar13);
            iVar20 = iVar20 + iVar17;
          }
          iVar20 = iVar20 + 8;
          iStack_10 = iVar18 - uVar10;
          if (piStack_20 < piVar27 && piVar29 < piVar26) {
            do {
              piVar26 = (int *)((int)piVar26 + -1);
              if (*(char *)((int)piVar28 - 1) != *(char *)piVar26) break;
              piVar28 = (int *)((int)piVar28 - 1);
              iVar20 = iVar20 + 1;
            } while (piStack_20 < piVar28 && piVar29 < piVar26);
          }
          piVar16 = *(int **)(param_1 + 0x17c);
          uVar15 = (int)piVar28 - (int)piStack_20;
          piVar26 = (int *)(uVar15 + (int)piVar16);
          do {
            *piVar16 = *piStack_20;
            piVar16[1] = piStack_20[1];
            piVar16 = piVar16 + 2;
            piStack_20 = piStack_20 + 2;
          } while (piVar16 < piVar26);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar15;
          if (0xffff < uVar15) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar15;
LAB_00aa9bc5:
          iStack_28 = iVar21;
          **(int **)(param_1 + 0x174) = iStack_10 + 3;
          goto LAB_00aa9bd0;
        }
        if ((uVar7 < uVar9) && (*piVar16 == *piVar27)) {
          piVar28 = (int *)((int)piVar27 + 1);
          FUN_016f39b0(*piVar28,*(undefined4 *)((int)piVar27 + 5),0xb7a56463,0xcf1bbcdc);
          iVar17 = FUN_016f4650();
          uVar15 = *(uint *)(iVar2 + iVar17 * 4);
          iVar20 = iVar3;
          if (uVar15 < uVar8) {
            iVar20 = iVar6;
          }
          piVar26 = (int *)(iVar20 + uVar15);
          *(int *)(iVar2 + iVar17 * 4) = iVar18 + 1;
          if (((uVar7 < uVar15) && (*piVar26 == *piVar28)) &&
             (piVar26[1] == *(int *)((int)piVar27 + 5))) {
            iVar17 = (int)piVar27 + 9;
            piVar16 = piVar24;
            pcVar22 = pcVar13;
            if (uVar15 < uVar8) {
              piVar16 = piVar11;
              pcVar22 = pcVar12;
            }
            piVar29 = piVar26 + 2;
            pcVar25 = pcVar13;
            if (pcVar22 + (iVar17 - (int)piVar29) < pcVar13) {
              pcVar25 = pcVar22 + (iVar17 - (int)piVar29);
            }
            iVar20 = FUN_00abcfb0(iVar17,piVar29,pcVar25);
            if ((char *)(iVar20 + (int)piVar29) == pcVar22) {
              iVar17 = FUN_00abcfb0(iVar17 + iVar20,piVar24,pcVar13);
              iVar20 = iVar20 + iVar17;
            }
            iVar20 = iVar20 + 8;
            iStack_54 = (iVar18 - uVar15) + 1;
            if (piStack_20 < piVar28 && piVar16 < piVar26) {
              do {
                piVar26 = (int *)((int)piVar26 + -1);
                if (*(char *)((int)piVar28 - 1) != *(char *)piVar26) break;
                piVar28 = (int *)((int)piVar28 - 1);
                iVar20 = iVar20 + 1;
              } while (piStack_20 < piVar28 && piVar16 < piVar26);
            }
          }
          else {
            piVar26 = piVar24;
            pcVar22 = pcVar13;
            if (uVar9 < uVar8) {
              piVar26 = piVar11;
              pcVar22 = pcVar12;
            }
            piVar28 = piVar16 + 1;
            pcVar25 = pcVar13;
            if (pcVar22 + (int)piVar27 + (4 - (int)piVar28) < pcVar13) {
              pcVar25 = pcVar22 + (int)piVar27 + (4 - (int)piVar28);
            }
            iVar20 = FUN_00abcfb0(piVar27 + 1,piVar28,pcVar25);
            if ((char *)(iVar20 + (int)piVar28) == pcVar22) {
              iVar17 = FUN_00abcfb0(iVar20 + 4 + (int)piVar27,piVar24,pcVar13);
              iVar20 = iVar20 + iVar17;
            }
            iVar20 = iVar20 + 4;
            iStack_54 = iVar18 - uVar9;
            piVar28 = piVar27;
            if (piStack_20 < piVar27 && piVar26 < piVar16) {
              do {
                piVar16 = (int *)((int)piVar16 + -1);
                if (*(char *)((int)piVar28 - 1) != *(char *)piVar16) break;
                piVar28 = (int *)((int)piVar28 - 1);
                iVar20 = iVar20 + 1;
              } while (piStack_20 < piVar28 && piVar26 < piVar16);
            }
          }
          iStack_10 = iStack_54;
          piVar16 = *(int **)(param_1 + 0x17c);
          uVar15 = (int)piVar28 - (int)piStack_20;
          piVar26 = (int *)(uVar15 + (int)piVar16);
          do {
            *piVar16 = *piStack_20;
            piVar16[1] = piStack_20[1];
            piVar16 = piVar16 + 2;
            piStack_20 = piStack_20 + 2;
          } while (piVar16 < piVar26);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar15;
          if (0xffff < uVar15) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar15;
          goto LAB_00aa9bc5;
        }
        piVar16 = (int *)((int)piVar27 + ((int)piVar27 - (int)param_2 >> 8) + 1);
      }
LAB_00aa9e0e:
      piVar27 = piVar16;
    } while (piVar16 < piVar1);
  }
  *(int *)(param_1 + 0x1a0) = iStack_10;
  *(int *)(param_1 + 0x1a4) = iStack_28;
  return (int)pcVar13 - (int)param_2;
}



/* FUNCTION 21994 ; VA 0x00aa9e80 ; FUN_00aa9e80 */

int FUN_00aa9e80(int param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  char *pcVar14;
  byte bVar15;
  int *piVar16;
  char *pcVar17;
  int iVar18;
  uint uVar19;
  char *pcVar20;
  int *piVar21;
  int *piVar22;
  int *piVar23;
  int *piVar24;
  undefined4 uVar25;
  uint uStack_48;
  int *piStack_2c;
  int iStack_24;
  int iStack_14;
  int iStack_10;
  
  iVar2 = *(int *)(param_1 + 0x210);
  iVar3 = *(int *)(param_1 + 8);
  iVar4 = *(int *)(param_1 + 4);
  uVar5 = *(undefined4 *)(param_1 + 0x98);
  uVar6 = *(uint *)(param_1 + 0x10);
  uVar7 = *(uint *)(param_1 + 0xc);
  piVar16 = (int *)(iVar4 + uVar7);
  pcVar17 = (char *)(param_3 + (int)param_2);
  pcVar9 = (char *)(uVar7 + iVar3);
  piStack_2c = param_2;
  piVar1 = (int *)(pcVar17 + -8);
  iStack_10 = *(int *)(param_1 + 0x194);
  iStack_24 = *(int *)(param_1 + 0x198);
  if (param_2 < pcVar17 + -8) {
    bVar15 = 0x20 - (char)uVar5;
    iVar10 = param_4 + -5;
    piVar23 = param_2;
    do {
      switch(iVar10) {
      case 0:
        uVar25 = 0xbb000000;
        break;
      case 1:
        uVar25 = 0xbf9b0000;
        break;
      case 2:
        uVar25 = 0xbfa56300;
        break;
      case 3:
        uVar25 = 0xb7a56463;
        break;
      default:
        uVar11 = (uint)(*piVar23 * -0x61c8864f) >> (bVar15 & 0x1f);
        goto LAB_00aa9f79;
      }
      FUN_016f39b0(*piVar23,piVar23[1],uVar25,0xcf1bbcdc);
      uVar11 = FUN_016f4650();
LAB_00aa9f79:
      uVar8 = *(uint *)(iVar2 + uVar11 * 4);
      iVar12 = iVar4;
      if (uVar8 < uVar7) {
        iVar12 = iVar3;
      }
      piVar22 = (int *)(iVar12 + uVar8);
      iVar18 = (int)piVar23 - iVar4;
      uVar19 = (iVar18 - iStack_10) + 1;
      iVar12 = iVar4;
      if (uVar19 < uVar7) {
        iVar12 = iVar3;
      }
      *(int *)(iVar2 + uVar11 * 4) = iVar18;
      if ((uVar6 < uVar19 && 2 < (uVar7 - uVar19) - 1) &&
         (piVar24 = (int *)((int)piVar23 + 1), *(int *)(iVar12 + uVar19) == *piVar24)) {
        iVar13 = (int)piVar23 + 5;
        piVar22 = (int *)(iVar12 + uVar19) + 1;
        pcVar14 = pcVar17;
        if (uVar19 < uVar7) {
          pcVar14 = pcVar9;
        }
        pcVar20 = pcVar17;
        if (pcVar14 + (iVar13 - (int)piVar22) < pcVar17) {
          pcVar20 = pcVar14 + (iVar13 - (int)piVar22);
        }
        iVar12 = FUN_00abcfb0(iVar13,piVar22,pcVar20);
        if ((char *)(iVar12 + (int)piVar22) == pcVar14) {
          iVar13 = FUN_00abcfb0(iVar13 + iVar12,piVar16,pcVar17);
          iVar12 = iVar12 + iVar13;
        }
        iStack_14 = iVar12 + 4;
        uStack_48 = iVar12 + 1;
        piVar21 = *(int **)(param_1 + 0x17c);
        uVar11 = (int)piVar24 - (int)piStack_2c;
        piVar22 = (int *)((int)piVar21 + uVar11);
        do {
          *piVar21 = *piStack_2c;
          piVar21[1] = piStack_2c[1];
          piVar21 = piVar21 + 2;
          piStack_2c = piStack_2c + 2;
        } while (piVar21 < piVar22);
        *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar11;
        if (0xffff < uVar11) {
          *(undefined4 *)(param_1 + 0x18c) = 1;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar11;
        **(undefined4 **)(param_1 + 0x174) = 1;
LAB_00aaa20a:
        if (0xffff < uStack_48) {
          *(undefined4 *)(param_1 + 0x18c) = 2;
          *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
        }
        piVar24 = (int *)((int)piVar24 + iStack_14);
        *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)uStack_48;
        *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
        param_2 = piVar24;
        piStack_2c = piVar24;
        if (piVar1 < piVar24) goto LAB_00aaa3d6;
        switch(iVar10) {
        case 0:
          uVar25 = 0xbb000000;
          break;
        case 1:
          uVar25 = 0xbf9b0000;
          break;
        case 2:
          uVar25 = 0xbfa56300;
          break;
        case 3:
          uVar25 = 0xb7a56463;
          break;
        default:
          uVar11 = (uint)(*(int *)((int)piVar23 + 2) * -0x61c8864f) >> (bVar15 & 0x1f);
          goto LAB_00aaa2b6;
        }
        FUN_016f39b0(*(undefined4 *)((int)piVar23 + 2),*(undefined4 *)((int)piVar23 + 6),uVar25,
                     0xcf1bbcdc);
        uVar11 = FUN_016f4650();
LAB_00aaa2b6:
        *(int *)(iVar2 + uVar11 * 4) = iVar18 + 2;
        switch(iVar10) {
        case 0:
          uVar25 = 0xbb000000;
          break;
        case 1:
          uVar25 = 0xbf9b0000;
          break;
        case 2:
          uVar25 = 0xbfa56300;
          break;
        case 3:
          uVar25 = 0xb7a56463;
          break;
        default:
          uVar11 = (uint)(*(int *)((int)piVar24 + -2) * -0x61c8864f) >> (bVar15 & 0x1f);
          goto LAB_00aaa31f;
        }
        FUN_016f39b0(*(undefined4 *)((int)piVar24 + -2),*(undefined4 *)((int)piVar24 + 2),uVar25,
                     0xcf1bbcdc);
        uVar11 = FUN_016f4650();
LAB_00aaa31f:
        *(int *)(iVar2 + uVar11 * 4) = (int)piVar24 + (-2 - iVar4);
        do {
          iVar12 = iStack_24;
          iVar13 = (int)piVar24 - iVar4;
          uVar11 = iVar13 - iStack_24;
          iVar18 = iVar3;
          if (uVar7 <= uVar11) {
            iVar18 = iVar4;
          }
          param_2 = piVar24;
          piStack_2c = piVar24;
          if ((uVar11 <= uVar6 || (uVar7 - uVar11) - 1 < 3) ||
             (*(int *)(iVar18 + uVar11) != *piVar24)) break;
          pcVar14 = pcVar17;
          if (uVar11 < uVar7) {
            pcVar14 = pcVar9;
          }
          iVar18 = FUN_00abd020(piVar24 + 1,(int *)(iVar18 + uVar11) + 1,pcVar17,pcVar14,piVar16);
          iStack_24 = iStack_10;
          iStack_10 = iVar12;
          FUN_00abd980(param_1 + 0x170,0,piVar24,0,iVar18 + 1);
          iVar12 = FUN_00abd760(piVar24,uVar5,param_4);
          piVar24 = (int *)((int)piVar24 + iVar18 + 4);
          *(int *)(iVar2 + iVar12 * 4) = iVar13;
          param_2 = piVar24;
          piStack_2c = piVar24;
        } while (piVar24 <= piVar1);
      }
      else {
        if ((uVar6 <= uVar8) && (*piVar22 == *piVar23)) {
          piVar24 = piVar22 + 1;
          pcVar14 = pcVar17;
          piVar21 = piVar16;
          if (uVar8 < uVar7) {
            pcVar14 = pcVar9;
            piVar21 = (int *)(uVar6 + iVar3);
          }
          pcVar20 = pcVar17;
          if (pcVar14 + ((int)(piVar23 + 1) - (int)piVar24) < pcVar17) {
            pcVar20 = pcVar14 + ((int)(piVar23 + 1) - (int)piVar24);
          }
          iStack_14 = FUN_00abcfb0(piVar23 + 1,piVar24,pcVar20);
          if ((char *)(iStack_14 + (int)piVar24) == pcVar14) {
            iVar12 = FUN_00abcfb0(iStack_14 + 4 + (int)piVar23,piVar16,pcVar17);
            iStack_14 = iStack_14 + iVar12;
          }
          iStack_14 = iStack_14 + 4;
          piVar24 = piVar23;
          if (piStack_2c < piVar23 && piVar21 < piVar22) {
            do {
              piVar22 = (int *)((int)piVar22 + -1);
              if (*(char *)((int)piVar24 + -1) != *(char *)piVar22) break;
              iStack_14 = iStack_14 + 1;
              piVar24 = (int *)((int)piVar24 + -1);
            } while (piStack_2c < piVar24 && piVar21 < piVar22);
          }
          uStack_48 = iStack_14 - 3;
          iStack_24 = iStack_10;
          piVar21 = *(int **)(param_1 + 0x17c);
          uVar11 = (int)piVar24 - (int)piStack_2c;
          piVar22 = (int *)((int)piVar21 + uVar11);
          do {
            *piVar21 = *piStack_2c;
            piVar21[1] = piStack_2c[1];
            piVar21 = piVar21 + 2;
            piStack_2c = piStack_2c + 2;
          } while (piVar21 < piVar22);
          *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar11;
          if (0xffff < uVar11) {
            *(undefined4 *)(param_1 + 0x18c) = 1;
            *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
          }
          *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar11;
          **(int **)(param_1 + 0x174) = (iVar18 - uVar8) + 3;
          iStack_10 = iVar18 - uVar8;
          goto LAB_00aaa20a;
        }
        piVar24 = (int *)((int)piVar23 + ((int)piVar23 - (int)param_2 >> 8) + 1);
      }
LAB_00aaa3d6:
      piVar23 = piVar24;
    } while (piVar24 < piVar1);
  }
  *(int *)(param_1 + 0x1a4) = iStack_24;
  *(int *)(param_1 + 0x1a0) = iStack_10;
  return (int)pcVar17 - (int)param_2;
}



/* FUNCTION 21995 ; VA 0x00aaa440 ; FUN_00aaa440 */

uint FUN_00aaa440(int param_1,undefined4 param_2,uint param_3,int param_4,uint param_5)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  code *pcVar5;
  
  uVar4 = param_4 - *(int *)(param_1 + 4);
  if (*(int *)(param_1 + 0xcc) == 0) {
    pcVar5 = (code *)(&PTR_FUN_01948a20)
                     [(-(uint)(*(uint *)(param_1 + 0x10) < *(uint *)(param_1 + 0xc)) & 9) +
                      *(int *)(param_1 + 0xa8)];
  }
  else {
    pcVar5 = FUN_00abc600;
    if (*(uint *)(param_1 + 0x10) < *(uint *)(param_1 + 0xc)) {
      pcVar5 = FUN_00abce00;
    }
  }
  if (param_5 < 7) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0x17c) = *(undefined4 *)(param_1 + 0x178);
  *(undefined4 *)(param_1 + 0x174) = *(undefined4 *)(param_1 + 0x170);
  *(undefined4 *)(param_1 + 0x18c) = 0;
  if (*(int *)(param_1 + 0x14) + 0x180U < uVar4) {
    uVar2 = (uVar4 - *(int *)(param_1 + 0x14)) - 0x180;
    if (0xc0 < uVar2) {
      uVar2 = 0xc0;
    }
    *(uint *)(param_1 + 0x14) = uVar4 - uVar2;
  }
  iVar3 = (*pcVar5)(param_1,param_4,param_5);
  FUN_0170c6f0(*(undefined4 *)(param_1 + 0x17c),(param_4 - iVar3) + param_5,iVar3);
  *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + iVar3;
  iVar3 = *(int *)(param_1 + 0x21c);
  uVar4 = FUN_00aab0d0((undefined4 *)(param_1 + 0x170),iVar3,param_1 + 0x90,param_2,param_3);
  if ((uVar4 == 0xffffffba) && (param_5 <= param_3)) {
    bVar1 = true;
  }
  else {
    bVar1 = false;
    if (0xffffff88 < uVar4) {
      return uVar4;
    }
  }
  if ((uVar4 < (param_5 - (param_5 >> 6)) - 2) && (!bVar1)) {
    *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x1a0);
    *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x1a4);
    *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a8);
    return uVar4;
  }
  *(undefined4 *)(iVar3 + 0x29d4) = 0;
  *(undefined4 *)(iVar3 + 0x29d8) = 0;
  *(undefined4 *)(iVar3 + 0x29dc) = 0;
  *(undefined4 *)(iVar3 + 0x29e0) = 0;
  return 0;
}



/* FUNCTION 21996 ; VA 0x00aaa5a0 ; FUN_00aaa5a0 */

void FUN_00aaa5a0(int param_1,byte *param_2,int param_3)

{
  int *piVar1;
  uint *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  code *pcVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  int iVar21;
  uint uVar22;
  byte *pbVar23;
  byte *pbVar24;
  byte *pbVar25;
  byte *pbVar26;
  byte *pbVar27;
  undefined4 *puVar28;
  uint uVar29;
  int iVar30;
  uint *puVar31;
  int iVar32;
  byte *pbVar33;
  byte *pbVar34;
  ulonglong uVar35;
  undefined4 uVar36;
  undefined4 uVar37;
  longlong lVar38;
  undefined8 uVar39;
  uint uStack_80;
  uint uStack_64;
  undefined8 uStack_54;
  uint *puStack_30;
  byte *pbStack_28;
  byte *pbStack_24;
  uint uStack_1c;
  int iStack_18;
  byte *pbStack_c;
  
  uVar4 = *(undefined4 *)(param_1 + 0x208);
  piVar1 = (int *)(param_1 + 0x200);
  uVar5 = *(undefined4 *)(param_1 + 0x20c);
  uVar13 = *(undefined4 *)(param_1 + 0xcc);
  iVar14 = *(int *)(param_1 + 0xd0);
  iVar15 = *(int *)(param_1 + 0xd4);
  uVar16 = *(uint *)(param_1 + 0xd8);
  uVar29 = *(uint *)(param_1 + 0xdc);
  iVar17 = iVar14 - iVar15;
  iVar6 = *(int *)(param_1 + 4);
  uVar18 = (1 << ((byte)uVar29 & 0x1f)) - 1;
  iVar7 = *(int *)(param_1 + 8);
  pbStack_24 = param_2;
  uVar22 = *(uint *)(param_1 + 0x10);
  uVar8 = *(uint *)(param_1 + 0xc);
  pbVar23 = (byte *)(iVar6 + uVar8);
  pbVar24 = param_2 + param_3;
  uVar19 = 8;
  if (8 < uVar16) {
    uVar19 = uVar16;
  }
  pbVar25 = pbVar24 + -uVar19;
  pbStack_28 = param_2;
  pcVar9 = (code *)(&PTR_FUN_01948a44)[*(int *)(param_1 + 0xa8)];
  uVar10 = *(undefined4 *)(param_1 + 0x194);
  *(undefined4 *)(param_1 + 0x1a0) = uVar10;
  uVar11 = *(undefined4 *)(param_1 + 0x198);
  *(undefined4 *)(param_1 + 0x1a4) = uVar11;
  uVar12 = *(undefined4 *)(param_1 + 0x19c);
  pbStack_c = (byte *)0x0;
  *(undefined4 *)(param_1 + 0x1a8) = uVar12;
  if (param_2 < pbVar25) {
    uStack_54 = 0;
    do {
      uStack_1c = 0;
      iStack_18 = 0;
      puStack_30 = (uint *)0x0;
      if (pbStack_24 == param_2) {
        uStack_54 = FUN_00aae9f0(pbStack_24,uVar16);
      }
      else {
        lVar38 = FUN_016f39b0(*pbStack_c + 10,0xfffffff5 < *pbStack_c,uVar4,uVar5);
        uVar39 = FUN_016f39b0(uStack_54 - lVar38,0xb7a56463,0xcf1bbcdc);
        uVar19 = (uint)uVar39 + (uint)pbStack_c[uVar16];
        uStack_54 = CONCAT44((int)((ulonglong)uVar39 >> 0x20) +
                             (uint)CARRY4((uint)uVar39,(uint)pbStack_c[uVar16]) +
                             (uint)(0xfffffff5 < uVar19),uVar19 + 10);
      }
      uStack_80 = (uint)uStack_54;
      if (uVar29 <= 0x20U - iVar17) {
        uStack_80 = (uint)(uStack_54 >> (ulonglong)((0x20 - uVar29) - iVar17));
      }
      pbStack_c = pbStack_24;
      if ((uVar18 & uStack_80) == uVar18) {
        if (iVar17 == 0) {
          iVar30 = 0;
        }
        else {
          iVar30 = (int)(uStack_54 >> (ulonglong)(0x40 - iVar17));
        }
        uStack_64 = 0;
        uVar35 = uStack_54 >> (ulonglong)(0x20U - iVar17);
        puVar31 = (uint *)(*piVar1 + (iVar30 << ((byte)iVar15 & 0x1f)) * 8);
        puVar2 = puVar31 + (1 << ((byte)iVar15 & 0x1f)) * 2;
        if (puVar31 < puVar2) {
          do {
            uVar19 = *puVar31;
            iVar30 = iVar6;
            if (uVar19 < uVar8) {
              iVar30 = iVar7;
            }
            pbVar33 = (byte *)(iVar30 + uVar19);
            pbVar27 = pbVar24;
            pbVar34 = pbVar23;
            if (uVar19 < uVar8) {
              pbVar27 = (byte *)(uVar8 + iVar7);
              pbVar34 = (byte *)(uVar22 + iVar7);
            }
            if ((puVar31[1] == (uint)uVar35) && (uVar22 < uVar19)) {
              pbVar26 = pbVar24;
              if (pbStack_24 + ((int)pbVar27 - (int)pbVar33) < pbVar24) {
                pbVar26 = pbStack_24 + ((int)pbVar27 - (int)pbVar33);
              }
              uVar19 = FUN_00abcfb0(pbStack_24,pbVar33,pbVar26);
              if (pbVar33 + uVar19 == pbVar27) {
                iVar30 = FUN_00abcfb0(pbStack_24 + uVar19,pbVar23,pbVar24);
                uVar19 = iVar30 + uVar19;
              }
              if (uVar16 <= uVar19) {
                iVar30 = 0;
                if (pbStack_28 < pbStack_24) {
                  iVar32 = (int)pbStack_24 - (int)pbVar33;
                  pbVar27 = pbStack_24;
                  do {
                    pbVar27 = pbVar27 + -1;
                    if ((pbVar33 <= pbVar34) || (pbVar33 = pbVar33 + -1, *pbVar27 != *pbVar33))
                    break;
                    iVar30 = iVar30 + 1;
                  } while (pbStack_28 < pbVar33 + iVar32);
                }
                if (uStack_64 < uVar19 + iVar30) {
                  uStack_64 = uVar19 + iVar30;
                  puStack_30 = puVar31;
                  uStack_1c = uVar19;
                  iStack_18 = iVar30;
                }
              }
            }
            puVar31 = puVar31 + 2;
          } while (puVar31 < puVar2);
          if (puStack_30 != (uint *)0x0) {
            iVar30 = ((int)pbStack_24 - iVar6) - *puStack_30;
            *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x1a0);
            *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x1a4);
            *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a8);
            uVar19 = (int)pbStack_28 - *(int *)(param_1 + 4);
            if (*(int *)(param_1 + 0x14) + 0x400U < uVar19) {
              uVar20 = (uVar19 - *(int *)(param_1 + 0x14)) - 0x400;
              if (0x200 < uVar20) {
                uVar20 = 0x200;
              }
              *(uint *)(param_1 + 0x14) = uVar19 - uVar20;
            }
            if (*(int *)(param_1 + 0xa8) == 1) {
              FUN_00abd420(param_1,pbStack_28,*(undefined4 *)(param_1 + 0xa0));
LAB_00aaa9ae:
              *(int *)(param_1 + 0x14) = (int)pbStack_28 - *(int *)(param_1 + 4);
            }
            else if (*(int *)(param_1 + 0xa8) == 2) {
              FUN_00abd300(param_1,pbStack_28,*(undefined4 *)(param_1 + 0xa0));
              goto LAB_00aaa9ae;
            }
            uVar19 = (*pcVar9)(param_1,pbStack_28,pbStack_24 + (-(int)pbStack_28 - iStack_18));
            *(byte **)(param_1 + 0x14) = pbStack_24 + (-iVar6 - iStack_18);
            *(undefined4 *)(param_1 + 0x1a8) = *(undefined4 *)(param_1 + 0x1a4);
            *(undefined4 *)(param_1 + 0x1a4) = *(undefined4 *)(param_1 + 0x1a0);
            *(int *)(param_1 + 0x1a0) = iVar30;
            puVar28 = *(undefined4 **)(param_1 + 0x17c);
            puVar3 = (undefined4 *)((int)puVar28 + uVar19);
            pbVar34 = pbStack_24 + (-uVar19 - iStack_18);
            do {
              *puVar28 = *(undefined4 *)pbVar34;
              puVar28[1] = *(undefined4 *)(pbVar34 + 4);
              puVar28 = puVar28 + 2;
              pbVar34 = pbVar34 + 8;
            } while (puVar28 < puVar3);
            *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + uVar19;
            if (0xffff < uVar19) {
              *(undefined4 *)(param_1 + 0x18c) = 1;
              *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
            }
            *(short *)(*(int *)(param_1 + 0x174) + 4) = (short)uVar19;
            uVar19 = (iStack_18 + uStack_1c) - 3;
            **(int **)(param_1 + 0x174) = iVar30 + 3;
            if (0xffff < uVar19) {
              *(undefined4 *)(param_1 + 0x18c) = 2;
              *(int *)(param_1 + 400) = *(int *)(param_1 + 0x174) - *(int *)(param_1 + 0x170) >> 3;
            }
            *(short *)(*(int *)(param_1 + 0x174) + 6) = (short)uVar19;
            *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x174) + 8;
            uVar36 = uVar13;
            iVar30 = iVar14;
            iVar32 = iVar15;
            uVar19 = uVar16;
            FUN_00aaea60(piVar1,uStack_54,iVar17,(int)pbStack_24 - iVar6,uVar13,iVar14,iVar15,uVar16
                         ,uVar29);
            pbStack_28 = pbStack_24 + ((iStack_18 + uStack_1c) - iStack_18);
            if (pbStack_28 < pbVar25) {
              uStack_54 = FUN_00aae930(piVar1,uStack_54,pbStack_24,pbStack_28,iVar6,iVar17,uVar36,
                                       iVar30,iVar32,uVar19,uVar29);
              pbStack_24 = pbStack_28;
              while( true ) {
                pbStack_c = pbStack_24 + -1;
                pbVar34 = pbStack_24 + -*(int *)(param_1 + 0x1a4);
                uVar19 = (int)pbVar34 - iVar6;
                if (uVar19 < uVar8) {
                  pbVar34 = (byte *)(iVar7 + uVar19);
                }
                pbStack_28 = pbStack_24;
                if ((uVar19 <= uVar22 || (uVar8 - uVar19) - 1 < 3) ||
                   (*(int *)pbVar34 != *(int *)pbStack_24)) break;
                pbVar27 = pbVar24;
                if (uVar19 < uVar8) {
                  pbVar27 = (byte *)(uVar8 + iVar7);
                }
                uVar37 = uVar13;
                iVar30 = iVar14;
                iVar32 = iVar15;
                uVar19 = uVar16;
                iVar21 = FUN_00abd020(pbStack_24 + 4,pbVar34 + 4,pbVar24,pbVar27,pbVar23);
                uVar36 = *(undefined4 *)(param_1 + 0x1a4);
                *(undefined4 *)(param_1 + 0x1a4) = *(undefined4 *)(param_1 + 0x1a0);
                *(undefined4 *)(param_1 + 0x1a0) = uVar36;
                FUN_00abd980((int *)(param_1 + 0x170),0,pbStack_24,0,iVar21 + 1);
                pbStack_28 = pbStack_24 + iVar21 + 4;
                if (pbVar25 <= pbStack_28) goto LAB_00aaac24;
                uStack_54 = FUN_00aae930(piVar1,uStack_54,pbStack_c,pbStack_28,iVar6,iVar17,uVar37,
                                         iVar30,iVar32,uVar19,uVar29);
                pbStack_24 = pbStack_28;
              }
              goto LAB_00aaac18;
            }
            break;
          }
        }
        FUN_00aaea60(piVar1,uStack_54,iVar17,(int)pbStack_24 - iVar6,uVar13,iVar14,iVar15,uVar16,
                     uVar29);
        pbStack_24 = pbStack_24 + 1;
      }
      else {
        pbStack_24 = pbStack_24 + 1;
      }
LAB_00aaac18:
    } while (pbStack_24 < pbVar25);
  }
LAB_00aaac24:
  *(undefined4 *)(param_1 + 0x194) = *(undefined4 *)(param_1 + 0x1a0);
  *(undefined4 *)(param_1 + 0x198) = *(undefined4 *)(param_1 + 0x1a4);
  *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a8);
  uVar29 = (int)pbStack_28 - *(int *)(param_1 + 4);
  if (*(int *)(param_1 + 0x14) + 0x400U < uVar29) {
    uVar22 = (uVar29 - *(int *)(param_1 + 0x14)) - 0x400;
    if (0x200 < uVar22) {
      uVar22 = 0x200;
    }
    *(uint *)(param_1 + 0x14) = uVar29 - uVar22;
  }
  if (*(int *)(param_1 + 0xa8) == 1) {
    FUN_00abd420(param_1,pbStack_28,*(undefined4 *)(param_1 + 0xa0));
  }
  else {
    if (*(int *)(param_1 + 0xa8) != 2) goto LAB_00aaac99;
    FUN_00abd300(param_1,pbStack_28,*(undefined4 *)(param_1 + 0xa0));
  }
  *(int *)(param_1 + 0x14) = (int)pbStack_28 - *(int *)(param_1 + 4);
LAB_00aaac99:
  (*pcVar9)(param_1,pbStack_28,(int)pbVar24 - (int)pbStack_28);
  *(int *)(param_1 + 0x14) = (int)pbVar24 - iVar6;
  *(undefined4 *)(param_1 + 0x194) = uVar10;
  *(undefined4 *)(param_1 + 0x198) = uVar11;
  *(undefined4 *)(param_1 + 0x19c) = uVar12;
  return;
}



/* FUNCTION 21997 ; VA 0x00aaace0 ; FUN_00aaace0 */

uint FUN_00aaace0(uint *param_1,int param_2,int param_3,uint param_4,uint param_5,int param_6,
                 undefined4 param_7)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  puVar2 = param_1;
  uVar6 = 0;
  if (param_1[9] == 0) {
    return 0xffffffc4;
  }
  if ((param_6 == 0) || (param_1[9] != 1)) {
    param_1 = (uint *)param_3;
  }
  else {
    uVar6 = FUN_00aafea0(param_2,param_3,param_1[0x23],param_1[0x24],param_1[0x25],param_1[0x26],
                         param_1[0x27],param_1[0x28],param_1[0x29],param_1[0x2a],param_1[0x2b],
                         param_1[0x2c],param_1[0x2d],param_1[0x2e],param_1[0x2f],param_1[0x30],
                         param_1[0x31],param_1[0x32],param_1[0x33],param_1[0x34],param_1[0x35],
                         param_1[0x36],param_1[0x37],param_1[0x38],param_1[0x39],param_1[0x3a],
                         param_1[0x3e] - 1,(param_1[0x3f] - 1) + (uint)(param_1[0x3e] != 0),
                         param_1[10]);
    if (0xffffff88 < uVar6) {
      return uVar6;
    }
    param_2 = param_2 + uVar6;
    param_1[9] = 2;
    param_1 = (uint *)(param_3 - uVar6);
  }
  if (param_4 != *puVar2) {
    uVar3 = puVar2[1];
    uVar4 = *puVar2 - uVar3;
    uVar5 = puVar2[3];
    puVar2[2] = uVar3;
    puVar2[3] = uVar4;
    puVar2[1] = (uVar3 - *puVar2) + param_4;
    puVar2[5] = uVar4;
    if (uVar4 - uVar5 < 8) {
      uVar5 = uVar4;
    }
    puVar2[4] = uVar5;
  }
  if (param_4 < puVar2[2] + puVar2[3] && puVar2[4] + puVar2[2] < param_5 + param_4) {
    uVar3 = (param_4 - puVar2[2]) + param_5;
    if ((int)puVar2[3] < (int)uVar3) {
      uVar3 = puVar2[3];
    }
    puVar2[4] = uVar3;
  }
  *puVar2 = param_4 + param_5;
  uVar3 = uVar6;
  if (param_5 != 0) {
    if (param_6 == 0) {
      uVar3 = FUN_00aaa440(puVar2,param_2,param_1,param_4,param_5);
    }
    else {
      uVar3 = FUN_00aab530(puVar2,param_2,param_1,param_4,param_5,param_7);
    }
    if (uVar3 < 0xffffff89) {
      puVar1 = puVar2 + 0x40;
      uVar5 = *puVar1;
      *puVar1 = *puVar1 + param_5;
      puVar2[0x41] = puVar2[0x41] + (uint)CARRY4(uVar5,param_5);
      return uVar3 + uVar6;
    }
  }
  return uVar3;
}



/* FUNCTION 21998 ; VA 0x00aaae70 ; FUN_00aaae70 */

int FUN_00aaae70(int param_1,int param_2,int *param_3,uint param_4,undefined *param_5,uint param_6)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  bool bVar7;
  int iStack_8;
  
  uVar2 = param_6;
  uVar3 = param_6 >> 6;
  bVar7 = param_6 < 0x4000;
  iStack_8 = *(int *)(param_1 + 0x29d4);
  param_6 = 2;
  iVar6 = (5 - (uint)(uVar2 < 0x400)) - (uint)bVar7;
  uVar4 = 0x3f;
  if (iStack_8 == 2) {
    uVar4 = 6;
  }
  if (uVar2 <= uVar4) {
    iVar6 = FUN_00aaf1f0(param_3,param_4,param_5,uVar2);
    return iVar6;
  }
  if (param_4 < iVar6 + 1U) {
    return -0x46;
  }
  uVar4 = (uint)(uVar2 < 0x100);
  if ((iStack_8 == 2) && (iVar6 == 3)) {
    uVar4 = 1;
  }
  uVar5 = FUN_00aa64e0(iVar6 + (int)param_3,param_4 - iVar6,param_5,uVar2,0xff,0xb,uVar4,
                       param_1 + 0x11d4,0x1800,param_1,&iStack_8,param_2 < 4 && uVar2 < 0x401);
  if (iStack_8 == 0) {
    *(undefined4 *)(param_1 + 0x29d4) = 1;
  }
  else {
    param_6 = 3;
  }
  if (uVar5 == 0 || (uVar2 - (uVar3 + 2) <= uVar5 || 0xffffff88 < uVar5)) {
    *(undefined4 *)(param_1 + 0x29d4) = 0;
    iVar6 = FUN_00aaf1f0(param_3,param_4,param_5,uVar2);
    return iVar6;
  }
  if (uVar5 != 1) {
    if (iVar6 == 3) {
      iVar1 = param_6 + ((uVar4 ^ 1) + (uVar5 * 0x400 + uVar2) * 4) * 4;
      *(short *)param_3 = (short)iVar1;
      *(char *)((int)param_3 + 2) = (char)((uint)iVar1 >> 0x10);
    }
    else {
      if (iVar6 == 4) {
        *param_3 = (uVar5 * 0x4000 + uVar2) * 0x10 + param_6 + 8;
        return uVar5 + 4;
      }
      if (iVar6 == 5) {
        *param_3 = (uVar5 * 0x40000 + uVar2) * 0x10 + param_6 + 0xc;
        *(char *)(param_3 + 1) = (char)(uVar5 >> 10);
        return uVar5 + 5;
      }
    }
    return uVar5 + iVar6;
  }
  *(undefined4 *)(param_1 + 0x29d4) = 0;
  iVar6 = (uint)(0xfff < uVar2) + (0x1f < uVar2) + 1;
  if (iVar6 == 1) {
    *(char *)param_3 = (char)uVar2 * '\b' + '\x01';
  }
  else {
    if (iVar6 == 2) {
      *(short *)param_3 = (short)(uVar2 << 4) + 5;
      *(undefined *)((int)param_3 + 2) = *param_5;
      return 3;
    }
    if (iVar6 == 3) {
      *param_3 = uVar2 * 0x10 + 0xd;
      *(undefined *)((int)param_3 + 3) = *param_5;
      return 4;
    }
  }
  *(undefined *)(iVar6 + (int)param_3) = *param_5;
  return iVar6 + 1;
}



/* FUNCTION 21999 ; VA 0x00aab0d0 ; FUN_00aab0d0 */

char * FUN_00aab0d0(int *param_1,int param_2,uint *param_3,int param_4,uint param_5)

{
  ushort uVar1;
  int iVar2;
  char cVar3;
  char cVar4;
  char *pcVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined *puVar9;
  ushort *puVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  char *pcVar14;
  undefined auStack_114 [212];
  uint uStack_40;
  char *pcStack_3c;
  char *pcStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  uStack_40 = (uint)(0x19 < *param_3);
  iStack_24 = param_2 + 0xcb0;
  iStack_28 = param_2 + 0x400;
  iStack_2c = param_2 + 0x704;
  iStack_20 = *param_1;
  iStack_10 = param_1[6];
  iStack_8 = param_1[4];
  iStack_14 = param_1[5];
  iVar8 = param_4 + param_5;
  uVar11 = param_1[1] - iStack_20 >> 3;
  uStack_18 = uVar11;
  pcVar5 = (char *)FUN_00aaae70(param_2,param_3[6],param_4,param_5,param_1[2],
                                param_1[3] - param_1[2]);
  if (pcVar5 < (char *)0xffffff89) {
    pcVar5 = pcVar5 + param_4;
    if (iVar8 - (int)pcVar5 < 4) {
      return (char *)0xffffffba;
    }
    if (uVar11 < 0x7f) {
      *pcVar5 = (char)uVar11;
      pcStack_3c = pcVar5 + 1;
    }
    else if (uVar11 < 0x7f00) {
      pcVar5[1] = (char)uVar11;
      *pcVar5 = (char)(uVar11 >> 8) + -0x80;
      pcStack_3c = pcVar5 + 2;
    }
    else {
      *pcVar5 = -1;
      *(short *)(pcVar5 + 1) = (short)uVar11 + -0x7f00;
      pcStack_3c = pcVar5 + 3;
    }
    if (uVar11 == 0) {
      return pcStack_3c + -param_4;
    }
    pcVar14 = pcStack_3c + 1;
    iVar13 = param_1[4];
    puVar9 = (undefined *)param_1[6];
    iStack_1c = param_1[5];
    iVar6 = param_1[1] - *param_1 >> 3;
    iStack_c = iVar6;
    if (iVar6 != 0) {
      puVar10 = (ushort *)(*param_1 + 6);
      iStack_30 = iVar13 - (int)puVar9;
      iStack_34 = iStack_1c - (int)puVar9;
      do {
        uVar11 = (uint)puVar10[-1];
        uVar1 = *puVar10;
        uVar12 = (uint)uVar1;
        if (uVar11 < 0x40) {
          cVar3 = (&DAT_01947908)[uVar11];
        }
        else {
          iVar2 = 0x1f;
          if (uVar11 != 0) {
            for (; puVar10[-1] >> iVar2 == 0; iVar2 = iVar2 + -1) {
            }
          }
          cVar3 = (char)iVar2 + '\x13';
        }
        puVar9[iStack_30] = cVar3;
        iVar2 = 0x1f;
        if (*(uint *)(puVar10 + -3) != 0) {
          for (; *(uint *)(puVar10 + -3) >> iVar2 == 0; iVar2 = iVar2 + -1) {
          }
        }
        *puVar9 = (char)iVar2;
        if (uVar12 < 0x80) {
          cVar3 = (&DAT_01947948)[uVar12];
        }
        else {
          iVar2 = 0x1f;
          if (uVar12 != 0) {
            for (; uVar1 >> iVar2 == 0; iVar2 = iVar2 + -1) {
            }
          }
          cVar3 = (char)iVar2 + '$';
        }
        iStack_c = 0;
        puVar10 = puVar10 + 4;
        puVar9[iStack_34] = cVar3;
        puVar9 = puVar9 + 1;
        iVar6 = iVar6 + -1;
        uVar11 = uStack_18;
      } while (iVar6 != 0);
    }
    iVar6 = param_1[7];
    if (iVar6 == 1) {
      *(undefined *)(iVar13 + param_1[8]) = 0x23;
      iVar6 = param_1[7];
    }
    if (iVar6 == 2) {
      *(undefined *)(iStack_1c + param_1[8]) = 0x34;
    }
    iVar13 = param_2 + 0x11d4;
    param_5 = 0x23;
    pcStack_38 = pcVar14;
    if (uVar11 < 0x5dc) {
      uVar12 = FUN_00ab0850(auStack_114,&param_5,iStack_8,uVar11);
    }
    else {
      uVar12 = FUN_00aa5b20(auStack_114,&param_5,iStack_8,uVar11,0,iVar13);
    }
    if ((uVar12 == uVar11) && (2 < uVar11)) {
      *(undefined4 *)(param_2 + 0x29e0) = 1;
      cVar3 = '\x01';
    }
    else if ((*(int *)(param_2 + 0x29e0) == 2) && (uVar11 < 1000)) {
      cVar3 = '\x03';
    }
    else if ((uVar11 < 0x40) || (uVar12 < uVar11 >> 5)) {
      *(undefined4 *)(param_2 + 0x29e0) = 2;
      cVar3 = '\0';
    }
    else {
      *(undefined4 *)(param_2 + 0x29e0) = 1;
      cVar3 = '\x02';
    }
    pcVar5 = (char *)FUN_00aa9390(pcVar14,iVar8 - (int)pcVar14,iStack_24,9,cVar3,auStack_114,param_5
                                  ,iStack_8,uVar11,&DAT_01947740,6,0x23,iVar13,0x1800);
    if (pcVar5 < (char *)0xffffff89) {
      pcVar14 = pcVar14 + (int)pcVar5;
      param_5 = 0x1f;
      uVar7 = FUN_00ab0810(auStack_114,&param_5,iStack_10,uVar11,iVar13);
      uVar12 = param_5;
      uStack_18 = FUN_00aafd30(param_2 + 0x29d8,uVar7,uVar11,5,param_5 < 0x1d);
      pcVar5 = (char *)FUN_00aa9390(pcVar14,iVar8 - (int)pcVar14,iStack_28,8,uStack_18,auStack_114,
                                    uVar12,iStack_10,uVar11,&DAT_0194785c,5,0x1c,param_2 + 0x11d4,
                                    0x1800);
      if (pcVar5 < (char *)0xffffff89) {
        pcVar14 = pcVar14 + (int)pcVar5;
        param_5 = 0x34;
        uVar12 = FUN_00ab0810(auStack_114,&param_5,iStack_14,uVar11,param_2 + 0x11d4);
        if ((uVar12 == uVar11) && (2 < uVar11)) {
          *(undefined4 *)(param_2 + 0x29dc) = 1;
          cVar4 = '\x01';
        }
        else if ((*(int *)(param_2 + 0x29dc) == 2) && (uVar11 < 1000)) {
          cVar4 = '\x03';
        }
        else if ((uVar11 < 0x40) || (uVar12 < uVar11 >> 5)) {
          *(undefined4 *)(param_2 + 0x29dc) = 2;
          cVar4 = '\0';
        }
        else {
          *(undefined4 *)(param_2 + 0x29dc) = 1;
          cVar4 = '\x02';
        }
        pcVar5 = (char *)FUN_00aa9390(pcVar14,iVar8 - (int)pcVar14,iStack_2c,9,cVar4,auStack_114,
                                      param_5,iStack_14,uVar11,&DAT_01947898,6,0x34,param_2 + 0x11d4
                                      ,0x1800);
        if (pcVar5 < (char *)0xffffff89) {
          pcVar14 = pcVar14 + (int)pcVar5;
          *pcStack_3c = ((cVar3 * '\x04' + (char)uStack_18) * '\x04' + cVar4) * '\x04';
          pcVar5 = (char *)FUN_00aad760(pcVar14,iVar8 - (int)pcVar14,iStack_2c,iStack_14,iStack_28,
                                        iStack_10,iStack_24,iStack_8,iStack_20,uVar11,uStack_40);
          if (pcVar5 < (char *)0xffffff89) {
            pcVar5 = pcVar14 + ((int)pcVar5 - param_4);
          }
        }
      }
    }
  }
  return pcVar5;
}


