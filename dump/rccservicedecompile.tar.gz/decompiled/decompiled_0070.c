/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 17500 ; VA 0x009682d0 ; FUN_009682d0 */

undefined * __thiscall FUN_009682d0(undefined *param_1,undefined *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *(undefined4 *)(param_1 + 8) = 0;
  uVar1 = *(uint *)(param_2 + 8);
  if (uVar1 != 0) {
    *(uint *)(param_1 + 8) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
    }
    else {
      uVar2 = *(undefined4 *)(param_2 + 0x14);
      uVar3 = *(undefined4 *)(param_2 + 0x18);
      uVar4 = *(undefined4 *)(param_2 + 0x1c);
      *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_2 + 0x10);
      *(undefined4 *)(param_1 + 0x14) = uVar2;
      *(undefined4 *)(param_1 + 0x18) = uVar3;
      *(undefined4 *)(param_1 + 0x1c) = uVar4;
      *(undefined8 *)(param_1 + 0x20) = *(undefined8 *)(param_2 + 0x20);
    }
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  uVar1 = *(uint *)(param_2 + 0x28);
  uStack_8 = 0;
  if (uVar1 != 0) {
    *(uint *)(param_1 + 0x28) = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = *(undefined4 *)(param_2 + 0x34);
      uVar3 = *(undefined4 *)(param_2 + 0x38);
      uVar4 = *(undefined4 *)(param_2 + 0x3c);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 0x30);
      *(undefined4 *)(param_1 + 0x34) = uVar2;
      *(undefined4 *)(param_1 + 0x38) = uVar3;
      *(undefined4 *)(param_1 + 0x3c) = uVar4;
      *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(param_2 + 0x40);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0x30,param_1 + 0x30,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17501 ; VA 0x009683a0 ; FUN_009683a0 */

undefined4 __thiscall
FUN_009683a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,ulonglong param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd968;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0x96840c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00969960(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x968489;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x9684b7;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17502 ; VA 0x009684d0 ; FUN_009684d0 */

undefined4 * __thiscall FUN_009684d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17503 ; VA 0x009685d0 ; FUN_009685d0 */

undefined4 __thiscall
FUN_009685d0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17,
            undefined4 param_18)

{
  int iVar1;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd9c0;
  pvStack_10 = ExceptionList;
  uStack_20 = param_18;
  uStack_8 = 2;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_40 = param_11;
    if ((param_11 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &param_13;
      uStack_50 = 0x96863f;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_13;
      uStack_34 = param_14;
      uStack_30 = param_15;
      uStack_2c = param_16;
      uStack_28 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_58,0);
    }
    else {
      uStack_58 = param_6;
      uStack_54 = param_7;
      uStack_50 = param_8;
      puStack_4c = param_9;
      uStack_48 = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00969db0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_20 = 0x9686d3;
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_20 = 2;
    uStack_28 = CONCAT44(&param_6,&param_6);
    uStack_2c = 0x9686f4;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    uStack_20 = 2;
    uStack_28 = CONCAT44(&param_13,&param_13);
    uStack_2c = 0x968722;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17504 ; VA 0x00968740 ; FUN_00968740 */

undefined4 * __thiscall FUN_00968740(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd9d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17505 ; VA 0x00968820 ; FUN_00968820 */

undefined4 __thiscall
FUN_00968820(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cda08;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_3c = param_12;
    if ((param_12 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_14;
      uStack_4c = 0x96888c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_14;
      uStack_30 = param_15;
      uStack_2c = param_16;
      puStack_28 = (undefined4 *)param_17;
      uStack_24 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_54,0);
    }
    else {
      uStack_54 = param_7;
      uStack_50 = param_8;
      uStack_4c = param_9;
      puStack_48 = param_10;
      uStack_44 = param_11;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_0096a340(param_2,param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_7;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x96890c;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_14;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x96893a;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17506 ; VA 0x00968950 ; FUN_00968950 */

undefined4 __thiscall
FUN_00968950(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 *param_13,ulonglong param_14,
            uint param_15,undefined4 param_16,undefined4 param_17,undefined4 param_18,
            undefined4 param_19,undefined4 param_20,undefined8 param_21)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cda50;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_44 = 0;
  ExceptionList = &pvStack_10;
  if (param_15 != 0) {
    uStack_44 = param_15;
    if ((param_15 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      puStack_50 = &param_17;
      uStack_54 = 0x9689bd;
      ExceptionList = &pvStack_10;
      (**(code **)(param_15 & 0xfffffffe))();
    }
    else {
      uStack_3c = param_17;
      uStack_38 = param_18;
      uStack_34 = param_19;
      puStack_30 = (undefined4 *)param_20;
      uStack_2c = param_21;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 5;
  if (param_8 != 0) {
    if ((param_8 & 1) == 0) {
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_5c,0);
    }
    else {
      uStack_5c = param_10;
      uStack_58 = param_11;
      uStack_54 = param_12;
      puStack_50 = param_13;
      uStack_4c = param_14;
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0096a620(param_2,param_3,param_4,param_5,param_6,param_7);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x968aa4,(undefined4)uStack_2c);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_2c = CONCAT44(0x968ab4,(undefined4)uStack_2c);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x968ac9,(undefined4)uStack_2c);
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_2c = CONCAT44(0x968adf,(undefined4)uStack_2c);
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_2c = CONCAT44(0x968aee,(undefined4)uStack_2c);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_10;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x968b0f;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_30 = &param_17;
    uStack_2c = CONCAT44(2,puStack_30);
    uStack_34 = 0x968b3d;
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17507 ; VA 0x00968b60 ; FUN_00968b60 */

int __thiscall FUN_00968b60(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cda70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  uVar2 = *(uint *)(param_2 + 0x18);
  uStack_8 = 0;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x18) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x20,param_1 + 0x20,0);
    }
    else {
      uVar3 = *(undefined4 *)(param_2 + 0x24);
      uVar4 = *(undefined4 *)(param_2 + 0x28);
      uVar5 = *(undefined4 *)(param_2 + 0x2c);
      *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
      *(undefined4 *)(param_1 + 0x24) = uVar3;
      *(undefined4 *)(param_1 + 0x28) = uVar4;
      *(undefined4 *)(param_1 + 0x2c) = uVar5;
      *(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_2 + 0x30);
    }
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  uVar2 = *(uint *)(param_2 + 0x38);
  uStack_8 = 1;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x38) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x40,param_1 + 0x40,0);
    }
    else {
      uVar3 = *(undefined4 *)(param_2 + 0x44);
      uVar4 = *(undefined4 *)(param_2 + 0x48);
      uVar5 = *(undefined4 *)(param_2 + 0x4c);
      *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_2 + 0x40);
      *(undefined4 *)(param_1 + 0x44) = uVar3;
      *(undefined4 *)(param_1 + 0x48) = uVar4;
      *(undefined4 *)(param_1 + 0x4c) = uVar5;
      *(undefined8 *)(param_1 + 0x50) = *(undefined8 *)(param_2 + 0x50);
    }
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  if (*(int *)(param_2 + 0x5c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x5c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x58);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_2 + 0x5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17508 ; VA 0x00968c50 ; FUN_00968c50 */

undefined4 __thiscall
FUN_00968c50(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  undefined uVar2;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 in_stack_00000064;
  int *in_stack_00000068;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cdab8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000068[2] = in_stack_00000068[2] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  uStack_7 = 0;
  if ((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if ((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  uStack_8 = 6;
  FUN_0054ef60(&param_4);
  uStack_8 = 3;
  FUN_0096a990(param_2,param_3);
  uStack_8 = 2;
  uVar2 = uStack_8;
  uStack_8 = 2;
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4)) {
      uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uStack_8 = 7;
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  _uStack_8 = CONCAT31(uStack_7,8);
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000068[2] + -1;
    in_stack_00000068[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000068 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17509 ; VA 0x00968e30 ; FUN_00968e30 */

undefined4 * __thiscall FUN_00968e30(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uVar2 = param_2[3];
  uVar3 = param_2[4];
  uVar4 = param_2[5];
  param_1[2] = param_2[2];
  param_1[3] = uVar2;
  param_1[4] = uVar3;
  param_1[5] = uVar4;
  uVar2 = param_2[7];
  uVar3 = param_2[8];
  uVar4 = param_2[9];
  param_1[6] = param_2[6];
  param_1[7] = uVar2;
  param_1[8] = uVar3;
  param_1[9] = uVar4;
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_2[0xd] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xd] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  if (param_2[0xf] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xf] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  return param_1;
}



/* FUNCTION 17510 ; VA 0x00968ee0 ; FUN_00968ee0 */

undefined4 __thiscall
FUN_00968ee0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            int *param_13,undefined4 param_14,int *param_15,undefined4 param_16,int *param_17,
            undefined4 param_18)

{
  int *piVar1;
  int iVar2;
  
  if (param_17 != (int *)0x0) {
    LOCK();
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    param_15[1] = param_15[1] + 1;
    UNLOCK();
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0096ad40(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13,param_14,param_15,param_16,param_17,param_18);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar2 = param_13[1] + -1;
    param_13[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_13)();
      LOCK();
      iVar2 = param_13[2] + -1;
      param_13[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_13 + 4))();
      }
    }
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    iVar2 = param_15[1] + -1;
    param_15[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_15)();
      LOCK();
      iVar2 = param_15[2] + -1;
      param_15[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_15 + 4))();
      }
    }
  }
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar2 = param_17[1] + -1;
    param_17[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_17)();
      LOCK();
      piVar1 = param_17 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17511 ; VA 0x00969050 ; FUN_00969050 */

int __thiscall FUN_00969050(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cdae0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (*(int *)(param_2 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (*(int *)(param_2 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x20) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_2 + 0x24);
  *(undefined4 *)(param_1 + 0x28) = 0;
  uVar2 = *(uint *)(param_2 + 0x28);
  uStack_8 = 0;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x28) = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x30,param_1 + 0x30,0);
    }
    else {
      uVar3 = *(undefined4 *)(param_2 + 0x34);
      uVar4 = *(undefined4 *)(param_2 + 0x38);
      uVar5 = *(undefined4 *)(param_2 + 0x3c);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 0x30);
      *(undefined4 *)(param_1 + 0x34) = uVar3;
      *(undefined4 *)(param_1 + 0x38) = uVar4;
      *(undefined4 *)(param_1 + 0x3c) = uVar5;
      *(undefined8 *)(param_1 + 0x40) = *(undefined8 *)(param_2 + 0x40);
    }
  }
  *(undefined4 *)(param_1 + 0x48) = 0;
  uVar2 = *(uint *)(param_2 + 0x48);
  uStack_8 = 1;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x48) = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = *(undefined4 *)(param_2 + 0x54);
      uVar4 = *(undefined4 *)(param_2 + 0x58);
      uVar5 = *(undefined4 *)(param_2 + 0x5c);
      *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_2 + 0x50);
      *(undefined4 *)(param_1 + 0x54) = uVar3;
      *(undefined4 *)(param_1 + 0x58) = uVar4;
      *(undefined4 *)(param_1 + 0x5c) = uVar5;
      *(undefined8 *)(param_1 + 0x60) = *(undefined8 *)(param_2 + 0x60);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x50,param_1 + 0x50,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17512 ; VA 0x00969180 ; FUN_00969180 */

undefined4 __thiscall
FUN_00969180(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined8 in_stack_0000004c;
  uint in_stack_00000054;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined8 in_stack_0000006c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdb38;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000054 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000054 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 5;
  if ((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 8;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 4;
  FUN_0096aeb0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17513 ; VA 0x009693c0 ; FUN_009693c0 */

undefined4 * __thiscall FUN_009693c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cdb58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  puVar1 = (undefined4 *)FUN_006a8fb0(0,0);
  *param_1 = puVar1;
  uStack_8 = 1;
  FUN_00962b90(*puVar1,*(undefined4 *)*param_2,(undefined4 *)*param_2,param_2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17514 ; VA 0x00969432 ; Catch_All@00969432 */

void Catch_All_00969432(void)

{
  thunk_FUN_00973910();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17515 ; VA 0x00969450 ; FUN_00969450 */

undefined4 __thiscall
FUN_00969450(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdb78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_4);
  if (0xf < in_stack_00000020) {
    uVar2 = in_stack_00000020 + 1;
    iVar1 = param_4;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_4 + -4);
      uVar2 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17516 ; VA 0x009694d0 ; FUN_009694d0 */

int __thiscall
FUN_009694d0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 8) = param_4;
  *(int **)(param_1 + 0xc) = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x10) = param_6;
  *(int **)(param_1 + 0x14) = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17517 ; VA 0x00969620 ; FUN_00969620 */

undefined4 * __thiscall
FUN_00969620(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            int *param_13)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  param_1[5] = param_7;
  param_1[6] = param_8;
  param_1[7] = param_9;
  param_1[8] = param_10;
  param_1[9] = param_11;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  param_1[10] = param_12;
  param_1[0xb] = param_13;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar2 = param_13[1] + -1;
    param_13[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_13)();
      LOCK();
      piVar1 = param_13 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_13 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17518 ; VA 0x00969750 ; FUN_00969750 */

undefined4 * __thiscall
FUN_00969750(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int *piVar1;
  int iVar2;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdbc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_3c = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  param_1[2] = 0;
  if (uStack_3c != 0) {
    param_1[2] = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_34;
      param_1[5] = uStack_30;
      param_1[6] = uStack_2c;
      param_1[7] = uStack_28;
      *(undefined8 *)(param_1 + 8) = uStack_24;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8._0_1_ = 6;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  param_1[10] = 0;
  if (param_11 != 0) {
    param_1[10] = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_13;
      param_1[0xd] = param_14;
      param_1[0xe] = param_15;
      param_1[0xf] = param_16;
      *(undefined8 *)(param_1 + 0x10) = param_17;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 9;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17519 ; VA 0x00969960 ; FUN_00969960 */

undefined * __thiscall
FUN_00969960(undefined *param_1,undefined4 param_2,undefined param_3,uint param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdc00;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_30,0);
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_3;
  uStack_8._0_1_ = 2;
  *(undefined4 *)(param_1 + 8) = 0;
  if (uStack_38 != 0) {
    *(uint *)(param_1 + 8) = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 0x10,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x10) = uStack_30;
      *(undefined4 *)(param_1 + 0x14) = uStack_2c;
      *(undefined4 *)(param_1 + 0x18) = uStack_28;
      *(undefined4 *)(param_1 + 0x1c) = uStack_24;
      *(undefined8 *)(param_1 + 0x20) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (param_11 != 0) {
    *(uint *)(param_1 + 0x28) = param_11;
    if ((param_11 & 1) == 0) {
      (**(code **)(param_11 & 0xfffffffe))(&param_13,param_1 + 0x30,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = param_13;
      *(undefined4 *)(param_1 + 0x34) = param_14;
      *(undefined4 *)(param_1 + 0x38) = param_15;
      *(undefined4 *)(param_1 + 0x3c) = param_16;
      *(undefined8 *)(param_1 + 0x40) = param_17;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  uStack_8 = 6;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_11 & 0xfffffffe))(&param_13,&param_13,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17520 ; VA 0x00969b00 ; FUN_00969b00 */

int __thiscall
FUN_00969b00(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 param_13,undefined8 param_14)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdc38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_009694d0(param_2,param_3,param_4,param_5,param_6,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (param_8 != 0) {
    *(uint *)(param_1 + 0x18) = param_8;
    if ((param_8 & 1) == 0) {
      (**(code **)(param_8 & 0xfffffffe))(&param_10,param_1 + 0x20,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x20) = param_10;
      *(undefined4 *)(param_1 + 0x24) = param_11;
      *(undefined4 *)(param_1 + 0x28) = param_12;
      *(undefined4 *)(param_1 + 0x2c) = param_13;
      *(undefined8 *)(param_1 + 0x30) = param_14;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_8 & 0xfffffffe))(&param_10,&param_10,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17521 ; VA 0x00969c90 ; FUN_00969c90 */

int __thiscall
FUN_00969c90(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,int *param_13,
            undefined4 param_14,int *param_15)

{
  int *piVar1;
  int iVar2;
  
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00969620(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13);
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  if (param_15 != (int *)0x0) {
    LOCK();
    param_15[1] = param_15[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x30) = param_14;
  *(int **)(param_1 + 0x34) = param_15;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar2 = param_13[1] + -1;
    param_13[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_13)();
      LOCK();
      iVar2 = param_13[2] + -1;
      param_13[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_13 + 4))();
      }
    }
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    iVar2 = param_15[1] + -1;
    param_15[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_15)();
      LOCK();
      piVar1 = param_15 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_15 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17522 ; VA 0x00969db0 ; FUN_00969db0 */

undefined4 __thiscall
FUN_00969db0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  int iVar1;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd9c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_11 != 0) {
    uStack_3c = param_11;
    if ((param_11 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_13;
      uStack_4c = 0x969e1c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_13;
      uStack_30 = param_14;
      uStack_2c = param_15;
      puStack_28 = (undefined4 *)param_16;
      uStack_24 = param_17;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      puStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00969750(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[2] + -1;
    param_3[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_24 = CONCAT44(0x969eb0,(undefined4)uStack_24);
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_6;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x969ed1;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_13;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x969eff;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17523 ; VA 0x00969f20 ; FUN_00969f20 */

int __thiscall FUN_00969f20(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  undefined uVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined auStack_6c [8];
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined4 *puStack_5c;
  undefined4 *puStack_58;
  uint uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 *apuStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdc90;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_50 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (in_stack_00000024 != 0) {
    uStack_50 = in_stack_00000024;
    if ((in_stack_00000024 & 1) == 0) {
      puStack_5c = &uStack_48;
      puStack_58 = (undefined4 *)0x0;
      puStack_60 = &stack0x0000002c;
      uStack_64 = 0x969f82;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    else {
      uStack_48 = in_stack_0000002c;
      uStack_44 = in_stack_00000030;
      uStack_40 = in_stack_00000034;
      uStack_3c = in_stack_00000038;
      uStack_38 = in_stack_0000003c;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_58 = &param_4;
  uStack_8._0_1_ = 3;
  puStack_5c = (undefined4 *)0x969f95;
  FUN_0054ef60();
  puStack_18 = auStack_6c;
  uStack_8._0_1_ = 5;
  FUN_0054ef60(apuStack_30);
  FUN_00969450(param_2,param_3);
  uStack_8._0_1_ = 6;
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (uStack_50 != 0) {
    *(uint *)(param_1 + 0x18) = uStack_50;
    if ((uStack_50 & 1) == 0) {
      puStack_58 = (undefined4 *)0x0;
      puStack_5c = (undefined4 *)(param_1 + 0x20);
      puStack_60 = &uStack_48;
      uStack_64 = 0x969ff5;
      (**(code **)(uStack_50 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x20) = uStack_48;
      *(undefined4 *)(param_1 + 0x24) = uStack_44;
      *(undefined4 *)(param_1 + 0x28) = uStack_40;
      *(undefined4 *)(param_1 + 0x2c) = uStack_3c;
      *(undefined8 *)(param_1 + 0x30) = uStack_38;
    }
  }
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_1c) {
    puStack_58 = (undefined4 *)(uStack_1c + 1);
    puVar2 = apuStack_30[0];
    if (0xfff < puStack_58) {
      puVar2 = (undefined4 *)apuStack_30[0][-1];
      puStack_58 = (undefined4 *)(uStack_1c + 0x24);
      if (0x1f < (uint)((int)apuStack_30[0] + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (undefined4 *)0x96a15e;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined4 *)0x96a030;
    puStack_5c = puVar2;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 7;
  if (((uStack_50 != 0) && ((uStack_50 & 1) == 0)) &&
     (*(code **)(uStack_50 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = &uStack_48;
    puStack_58 = (undefined4 *)0x2;
    uStack_64 = 0x96a058;
    puStack_5c = puStack_60;
    (**(code **)(uStack_50 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 8;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (in_stack_00000044 != 0) {
    *(uint *)(param_1 + 0x38) = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      puStack_58 = (undefined4 *)0x0;
      puStack_5c = (undefined4 *)(param_1 + 0x40);
      puStack_60 = &stack0x0000004c;
      uStack_64 = 0x96a0a0;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = in_stack_0000004c;
      *(undefined4 *)(param_1 + 0x44) = in_stack_00000050;
      *(undefined4 *)(param_1 + 0x48) = in_stack_00000054;
      *(undefined4 *)(param_1 + 0x4c) = in_stack_00000058;
      *(undefined8 *)(param_1 + 0x50) = in_stack_0000005c;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000020) {
    puStack_58 = (undefined4 *)(in_stack_00000020 + 1);
    uVar3 = param_4;
    if (0xfff < puStack_58) {
      uVar3 = *(uint *)(param_4 - 4);
      puStack_58 = (undefined4 *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (undefined4 *)&UNK_0096a163;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_60 = (undefined4 *)0x96a0db;
    puStack_5c = (undefined4 *)uVar3;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = &stack0x0000002c;
      puStack_58 = (undefined4 *)0x2;
      uStack_64 = 0x96a115;
      puStack_5c = puStack_60;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = &stack0x0000004c;
    puStack_58 = (undefined4 *)0x2;
    uStack_64 = 0x96a143;
    puStack_5c = puStack_60;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17524 ; VA 0x0096a170 ; FUN_0096a170 */

int __thiscall FUN_0096a170(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined auStack_58 [12];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 *puStack_44;
  uint auStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar4 = in_stack_00000028;
  uVar3 = in_stack_00000024;
  puStack_c = &LAB_017cdcd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_1c = in_stack_00000024;
  piStack_18 = in_stack_00000028;
  puStack_44 = &param_4;
  uStack_8 = 3;
  uStack_7 = 0;
  uStack_48 = 0x96a1c1;
  piStack_14 = (int *)param_1;
  FUN_0054ef60();
  piStack_14 = (int *)auStack_58;
  _uStack_8 = CONCAT31(uStack_7,5);
  FUN_0054ef60(auStack_34);
  FUN_00969450(param_2,param_3);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = uVar3;
  *(int **)(param_1 + 0x1c) = piVar4;
  if (0xf < uStack_20) {
    puStack_44 = (undefined4 *)(uStack_20 + 1);
    uVar5 = auStack_34[0];
    if (0xfff < puStack_44) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      puStack_44 = (undefined4 *)(uStack_20 + 0x24);
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)0x96a32e;
        FUN_017167a3();
      }
    }
    uStack_4c = 0x96a230;
    uStack_48 = uVar5;
    FUN_01674ea0();
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0x96a249;
      (**(code **)*piVar4)();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_44 = (undefined4 *)0x96a259;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x20) = in_stack_0000002c;
  *(int **)(param_1 + 0x24) = in_stack_00000030;
  if (0xf < in_stack_00000020) {
    puStack_44 = (undefined4 *)(in_stack_00000020 + 1);
    uVar5 = param_4;
    if (0xfff < puStack_44) {
      uVar5 = *(uint *)(param_4 - 4);
      puStack_44 = (undefined4 *)(in_stack_00000020 + 0x24);
      if (0x1f < (param_4 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_44 = (undefined4 *)&UNK_0096a333;
        FUN_017167a3();
      }
    }
    uStack_4c = 0x96a2af;
    uStack_48 = uVar5;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  piStack_14 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0x96a2de;
      (**(code **)*in_stack_00000028)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_44 = (undefined4 *)0x96a2ef;
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  piVar4 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_44 = (undefined4 *)0x96a305;
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_44 = (undefined4 *)0x96a314;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17525 ; VA 0x0096a340 ; FUN_0096a340 */

undefined4 * __thiscall
FUN_0096a340(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined8 param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdd00;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_5 != 0) {
    uStack_38 = param_5;
    if ((param_5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_30,0);
    }
    else {
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      uStack_20 = param_11;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = param_4;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[10] = 0;
  if (param_12 != 0) {
    param_1[10] = param_12;
    if ((param_12 & 1) == 0) {
      (**(code **)(param_12 & 0xfffffffe))(&param_14,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_14;
      param_1[0xd] = param_15;
      param_1[0xe] = param_16;
      param_1[0xf] = param_17;
      *(undefined8 *)(param_1 + 0x10) = param_18;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_5 & 0xfffffffe))(&param_7,&param_7,2);
  }
  uStack_8 = 6;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_12 & 0xfffffffe))(&param_14,&param_14,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17526 ; VA 0x0096a4e0 ; FUN_0096a4e0 */

undefined4 * __thiscall FUN_0096a4e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdd20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = 0;
  uVar2 = param_2[6];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[6] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 8,param_1 + 8,0);
    }
    else {
      uVar3 = param_2[9];
      uVar4 = param_2[10];
      uVar5 = param_2[0xb];
      param_1[8] = param_2[8];
      param_1[9] = uVar3;
      param_1[10] = uVar4;
      param_1[0xb] = uVar5;
      *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    }
  }
  param_1[0xe] = 0;
  uVar2 = param_2[0xe];
  uStack_8 = 1;
  if (uVar2 != 0) {
    param_1[0xe] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0x11];
      uVar4 = param_2[0x12];
      uVar5 = param_2[0x13];
      param_1[0x10] = param_2[0x10];
      param_1[0x11] = uVar3;
      param_1[0x12] = uVar4;
      param_1[0x13] = uVar5;
      *(undefined8 *)(param_1 + 0x14) = *(undefined8 *)(param_2 + 0x14);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x10,param_1 + 0x10,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17527 ; VA 0x0096a620 ; FUN_0096a620 */

int __thiscall
FUN_0096a620(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7,uint param_8,undefined4 param_9,undefined4 param_10,
            undefined4 param_11,undefined4 param_12,undefined4 *param_13,ulonglong param_14,
            uint param_15,undefined4 param_16,undefined4 param_17,undefined4 param_18,
            undefined4 param_19,undefined4 param_20,undefined8 param_21)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdd60;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  if (param_8 != 0) {
    if ((param_8 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_8 & 0xfffffffe))(&param_10,&uStack_38,0);
    }
    else {
      uStack_38 = param_10;
      uStack_34 = param_11;
      uStack_30 = param_12;
      puStack_2c = param_13;
      uStack_28 = param_14;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00969b00(param_2,param_3,param_4,param_5,param_6,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_15 != 0) {
    *(uint *)(param_1 + 0x38) = param_15;
    if ((param_15 & 1) == 0) {
      uStack_28 = (ulonglong)(param_1 + 0x40);
      puStack_2c = &param_17;
      uStack_30 = 0x96a74d;
      (**(code **)(param_15 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x40) = param_17;
      *(undefined4 *)(param_1 + 0x44) = param_18;
      *(undefined4 *)(param_1 + 0x48) = param_19;
      *(undefined4 *)(param_1 + 0x4c) = param_20;
      *(undefined8 *)(param_1 + 0x50) = param_21;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x96a767,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_28 = CONCAT44(0x96a778,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x96a78e,(undefined4)uStack_28);
      (**(code **)(*param_5 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0x96a7a5,(undefined4)uStack_28);
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0x96a7b7,(undefined4)uStack_28);
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_2c = &param_10;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x96a7d8;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &param_17;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0x96a806;
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17528 ; VA 0x0096a820 ; FUN_0096a820 */

int __thiscall
FUN_0096a820(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,int *param_13,
            undefined4 param_14,int *param_15,undefined4 param_16,int *param_17)

{
  int *piVar1;
  int iVar2;
  
  if (param_15 != (int *)0x0) {
    LOCK();
    param_15[1] = param_15[1] + 1;
    UNLOCK();
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00969c90(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13,param_14,param_15);
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  if (param_17 != (int *)0x0) {
    LOCK();
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x38) = param_16;
  *(int **)(param_1 + 0x3c) = param_17;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar2 = param_13[1] + -1;
    param_13[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_13)();
      LOCK();
      iVar2 = param_13[2] + -1;
      param_13[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_13 + 4))();
      }
    }
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    iVar2 = param_15[1] + -1;
    param_15[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_15)();
      LOCK();
      iVar2 = param_15[2] + -1;
      param_15[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_15 + 4))();
      }
    }
  }
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar2 = param_17[1] + -1;
    param_17[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_17)();
      LOCK();
      piVar1 = param_17 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17529 ; VA 0x0096a990 ; FUN_0096a990 */

int __thiscall FUN_0096a990(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  undefined uVar2;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined8 in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 in_stack_00000064;
  int *in_stack_00000068;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdda0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000044 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000044 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 4;
  if ((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 3;
  FUN_00969f20(param_2,param_3);
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    in_stack_00000068[2] = in_stack_00000068[2] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x58) = in_stack_00000064;
  *(int **)(param_1 + 0x5c) = in_stack_00000068;
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4)) {
      uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uStack_8._0_1_ = 6;
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_00000068[2] + -1;
    in_stack_00000068[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*in_stack_00000068 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17530 ; VA 0x0096ab70 ; FUN_0096ab70 */

int __thiscall FUN_0096ab70(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined8 in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdde8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 3;
  FUN_0096a170(param_2,param_3);
  uStack_8._0_1_ = 6;
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (in_stack_00000034 != 0) {
    *(uint *)(param_1 + 0x28) = in_stack_00000034;
    if ((in_stack_00000034 & 1) == 0) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x30) = in_stack_0000003c;
      *(undefined4 *)(param_1 + 0x34) = in_stack_00000040;
      *(undefined4 *)(param_1 + 0x38) = in_stack_00000044;
      *(undefined4 *)(param_1 + 0x3c) = in_stack_00000048;
      *(undefined8 *)(param_1 + 0x40) = in_stack_0000004c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 7;
  if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
     (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17531 ; VA 0x0096ad40 ; FUN_0096ad40 */

undefined4 __thiscall
FUN_0096ad40(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            int *param_13,undefined4 param_14,int *param_15,undefined4 param_16,int *param_17)

{
  int *piVar1;
  int iVar2;
  
  if (param_17 != (int *)0x0) {
    LOCK();
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    param_15[1] = param_15[1] + 1;
    UNLOCK();
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    param_13[1] = param_13[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0096a820(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,
               param_12,param_13,param_14,param_15,param_16,param_17);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_13 != (int *)0x0) {
    LOCK();
    iVar2 = param_13[1] + -1;
    param_13[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_13)();
      LOCK();
      iVar2 = param_13[2] + -1;
      param_13[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_13 + 4))();
      }
    }
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    iVar2 = param_15[1] + -1;
    param_15[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_15)();
      LOCK();
      iVar2 = param_15[2] + -1;
      param_15[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_15 + 4))();
      }
    }
  }
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar2 = param_17[1] + -1;
    param_17[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_17)();
      LOCK();
      piVar1 = param_17 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17532 ; VA 0x0096aeb0 ; FUN_0096aeb0 */

int __thiscall FUN_0096aeb0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined8 in_stack_0000004c;
  uint in_stack_00000054;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined8 in_stack_0000006c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cde48;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000034 != 0) && (ExceptionList = &pvStack_10, (in_stack_00000034 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(in_stack_00000034 & 0xfffffffe))();
  }
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 4;
  FUN_0096ab70(param_2,param_3);
  uStack_8._0_1_ = 8;
  *(undefined4 *)(param_1 + 0x48) = 0;
  if (in_stack_00000054 != 0) {
    *(uint *)(param_1 + 0x48) = in_stack_00000054;
    if ((in_stack_00000054 & 1) == 0) {
      (**(code **)(in_stack_00000054 & 0xfffffffe))();
    }
    else {
      *(undefined4 *)(param_1 + 0x50) = in_stack_0000005c;
      *(undefined4 *)(param_1 + 0x54) = in_stack_00000060;
      *(undefined4 *)(param_1 + 0x58) = in_stack_00000064;
      *(undefined4 *)(param_1 + 0x5c) = in_stack_00000068;
      *(undefined8 *)(param_1 + 0x60) = in_stack_0000006c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000020) {
    if ((0xfff < in_stack_00000020 + 1) && (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000030;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17533 ; VA 0x0096b0f0 ; FUN_0096b0f0 */

undefined4 * __thiscall FUN_0096b0f0(undefined4 *param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cde97;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  FUN_0054ef60(param_2 + 2);
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 0xc);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2 + 0x12);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(param_2 + 0x18);
  uStack_8._0_1_ = 3;
  FUN_009693c0(param_2 + 0x1e);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(param_2 + 0x20);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17534 ; VA 0x0096b1b0 ; FUN_0096b1b0 */

int __fastcall FUN_0096b1b0(int param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdedc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uStack_8 = 3;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  uVar1 = FUN_006a8fb0(0,0);
  *(undefined4 *)(param_1 + 0x78) = uVar1;
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0xf;
  *(undefined *)(param_1 + 0x80) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17535 ; VA 0x0096b280 ; FUN_0096b280 */

undefined4 * __thiscall FUN_0096b280(undefined4 *param_1,int param_2)

{
  int *piVar1;
  uint *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  uint in_stack_00000018;
  undefined4 uStack_b0;
  undefined4 *puStack_ac;
  undefined4 uStack_a0;
  uint *puStack_9c;
  uint *puStack_98;
  char *pcStack_94;
  undefined4 uStack_88;
  undefined4 uStack_84;
  int iStack_80;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  undefined auStack_58 [24];
  uint auStack_40 [2];
  uint auStack_38 [6];
  int iStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cdf65;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  pcStack_94 = (char *)0x1c;
  uStack_8 = 0;
  puStack_98 = (uint *)0x96b2b7;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  puVar4 = (undefined4 *)FUN_01674e20();
  uStack_8._0_1_ = 1;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puStack_98 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    pcStack_94 = (char *)0x8;
    *(undefined8 *)(puVar4 + 4) = 0;
    puVar4[6] = 0;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puStack_98 = (uint *)0x96b302;
    puVar5 = (undefined4 *)FUN_01674e20();
    *puVar4 = puVar5;
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 **)*puVar4 = puVar4;
    puVar4[5] = 0;
    puVar4[6] = 0;
    puStack_98 = puVar4;
  }
  pcStack_94 = (char *)in_stack_00000018;
  uStack_8._0_1_ = 0;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_9c = (uint *)0x96b346;
  FUN_00962d00();
  param_1[2] = 0;
  pcStack_94 = (char *)0x8;
  uStack_8._0_1_ = 3;
  puStack_98 = (uint *)0x96b358;
  iStack_20 = FUN_01674e20();
  uStack_8._0_1_ = 4;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (iStack_20 == 0) {
    uVar6 = 0;
    uStack_8._0_1_ = uVar3;
  }
  else {
    puStack_ac = &param_2;
    uStack_b0 = 0x96b37a;
    FUN_0054ef60();
    if (param_1[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_1[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_b0 = *param_1;
    puStack_ac = (undefined4 *)param_1[1];
    FUN_00964be0(&uStack_88);
    uStack_64 = uStack_88;
    puStack_1c = &uStack_60;
    if (iStack_80 != 0) {
      LOCK();
      *(int *)(iStack_80 + 4) = *(int *)(iStack_80 + 4) + 1;
      UNLOCK();
    }
    uStack_60 = uStack_84;
    iStack_5c = iStack_80;
    pcStack_94 = auStack_7c;
    uStack_8._0_1_ = 6;
    puStack_98 = (uint *)0x96b3f9;
    FUN_0054ef60();
    auStack_40[0] = 0;
    puStack_1c = &uStack_b0;
    if (iStack_5c != 0) {
      LOCK();
      *(int *)(iStack_5c + 4) = *(int *)(iStack_5c + 4) + 1;
      UNLOCK();
    }
    uStack_b0 = uStack_60;
    puStack_ac = (undefined4 *)iStack_5c;
    uStack_8._0_1_ = 8;
    FUN_0054ef60(auStack_58);
    uStack_8._0_1_ = 7;
    FUN_00963a20();
    pcStack_94 = (char *)0x96b45a;
    FUN_006511a0();
    pcStack_94 = (char *)0x96b462;
    FUN_006511a0();
    pcStack_94 = "rbx_abusereporter";
    puStack_98 = auStack_40;
    uStack_8._0_1_ = 9;
    uStack_14 = 1;
    puStack_9c = (uint *)0x96b47d;
    uVar6 = FUN_015196a0();
  }
  puVar2 = (uint *)param_1[2];
  param_1[2] = uVar6;
  if (puVar2 != (uint *)0x0) {
    pcStack_94 = (char *)0x96b492;
    FUN_01519bf0();
    pcStack_94 = (char *)0x8;
    puStack_9c = (uint *)0x96b49a;
    puStack_98 = puVar2;
    FUN_01674ea0();
  }
  uStack_8 = 3;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 0xb;
    if (((auStack_40[0] != 0) && ((auStack_40[0] & 1) == 0)) &&
       (*(code **)(auStack_40[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_9c = auStack_38;
      pcStack_94 = (char *)0x2;
      uStack_a0 = 0x96b4cb;
      puStack_98 = puStack_9c;
      (**(code **)(auStack_40[0] & 0xfffffffe))();
    }
  }
  if (0xf < in_stack_00000018) {
    pcStack_94 = (char *)(in_stack_00000018 + 1);
    iVar7 = param_2;
    if (0xfff < pcStack_94) {
      iVar7 = *(int *)(param_2 + -4);
      pcStack_94 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_94 = &UNK_0096b517;
        FUN_017167a3();
      }
    }
    puStack_9c = (uint *)0x96b4fb;
    puStack_98 = (uint *)iVar7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17536 ; VA 0x0096b520 ; FUN_0096b520 */

undefined * __thiscall
FUN_0096b520(undefined *param_1,char *param_2,undefined4 param_3,undefined4 param_4,int *param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cdfa9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  uStack_8 = 2;
  uStack_7 = 0;
  param_1[0x18] = 0;
  pcVar4 = param_2;
  do {
    cVar2 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
  *(undefined4 *)(param_1 + 0x30) = param_3;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x34) = param_4;
  *(int **)(param_1 + 0x38) = param_5;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x3c) = param_6;
  *(int **)(param_1 + 0x40) = param_7;
  _uStack_8 = CONCAT31(uStack_7,5);
  FUN_01531f50(param_1);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar3 = param_7[1] + -1;
    param_7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17537 ; VA 0x0096b650 ; FUN_0096b650 */

undefined * __thiscall
FUN_0096b650(undefined *param_1,char *param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cdff1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  uStack_8 = 1;
  uStack_7 = 0;
  param_1[0x18] = 0;
  pcVar4 = param_2;
  do {
    cVar2 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar4 - (int)(param_2 + 1));
  *(undefined4 *)(param_1 + 0x30) = param_3;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x34) = param_4;
  *(int **)(param_1 + 0x38) = param_5;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  _uStack_8 = CONCAT31(uStack_7,4);
  FUN_01531f50(param_1);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17538 ; VA 0x0096b750 ; FUN_0096b750 */

undefined4 * __fastcall FUN_0096b750(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  undefined **ppuVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_34 [3];
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce2dc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Players,class_RBX::ServiceInstance>::vftable;
  uVar4 = FUN_00961580();
  param_1[3] = uVar4;
  *param_1 = RBX::Players::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  puVar1 = param_1 + 0x26;
  uStack_8._0_1_ = 7;
  uStack_8._1_3_ = 0;
  *puVar1 = 0;
  param_1[0x27] = 0;
  puStack_14 = puVar1;
  uVar4 = FUN_00575b30();
  *puVar1 = uVar4;
  *(undefined2 *)(param_1 + 0x28) = 0x100;
  param_1[0x29] = 0x40a00000;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  puVar1 = param_1 + 0x2c;
  uStack_8._0_1_ = 10;
  *puVar1 = 0;
  param_1[0x2d] = 0;
  puStack_14 = puVar1;
  uVar4 = FUN_00970770(0,0);
  *puVar1 = uVar4;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_8._0_1_ = 0xc;
  puStack_14 = (undefined4 *)FUN_01674e20(0xc);
  uStack_8._0_1_ = 0xd;
  if (puStack_14 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00569460(&uStack_28);
  }
  uStack_8._0_1_ = 0xc;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  FUN_008aaf20(uVar4,puStack_18);
  uStack_8._0_1_ = 0xf;
  FUN_00577ac0();
  param_1[0x30] = 0;
  FUN_005e5ff0();
  param_1[0x39] = 0xc;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  uStack_8._0_1_ = 0x11;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = &DAT_01d6456c;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  FUN_016830f0(param_1 + 0x46);
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = &DAT_01d645a0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  FUN_016830f0(param_1 + 0x4e);
  param_1[0x50] = 0;
  puStack_1c = param_1 + 0x52;
  puVar1 = param_1 + 0x53;
  *puStack_1c = RBX::
                LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,struct_RBX::PlayerNameCache::ExpiringCacheEntry<__int64>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
                ::vftable;
  *puVar1 = 0;
  param_1[0x54] = 0;
  puStack_14 = puVar1;
  uVar4 = FUN_00970740(0,0);
  *puVar1 = uVar4;
  *(undefined *)(param_1 + 0x55) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar5;
  }
  param_1[0x56] = *ppuVar6;
  param_1[0x57] = 0;
  param_1[0x58] = 0x3f800000;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  uStack_8._0_1_ = 0x12;
  puVar1 = param_1 + 0x5d;
  param_1[0x5c] =
       RBX::
       LRUCache<__int64,struct_RBX::PlayerNameCache::ExpiringCacheEntry<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_boost::hash<__int64>_>
       ::vftable;
  *puVar1 = 0;
  param_1[0x5e] = 0;
  puStack_14 = puVar1;
  uVar4 = FUN_00970740(0,0);
  *puVar1 = uVar4;
  *(undefined *)(param_1 + 0x5f) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar5;
  }
  param_1[0x60] = *ppuVar6;
  param_1[0x61] = 0;
  param_1[0x62] = 0x3f800000;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  FUN_016dee4c(param_1 + 0x66,2);
  puVar3 = puStack_18;
  puStack_18[0x72] = 0;
  puStack_18[0x73] = 0;
  puStack_18[0x74] = 0;
  puStack_18[0x75] = 0;
  puStack_18[0x76] = 0;
  puStack_18[0x77] = 0;
  uStack_8._0_1_ = 0x15;
  puVar1 = puStack_18 + 0x79;
  puStack_18[0x78] =
       RBX::
       LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,struct_RBX::Players::ThumbnailRequestRecord,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
       ::vftable;
  *puVar1 = 0;
  puStack_18[0x7a] = 0;
  puStack_1c = puVar1;
  uVar4 = FUN_006a8fb0(0,0);
  *puVar1 = uVar4;
  *(undefined *)(puVar3 + 0x7b) = 0;
  puStack_14 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_14);
  ppuVar6 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar5;
  }
  puVar3[0x7c] = *ppuVar6;
  puVar3[0x7d] = 0;
  puVar3[0x7e] = 0x3f800000;
  puVar3[0x7f] = 0;
  puVar3[0x80] = 0;
  puVar3[0x81] = 0;
  uStack_8._0_1_ = 0x16;
  FUN_016827a0(puVar3 + 0x82);
  uVar2 = DAT_018ce300;
  *(undefined *)(puVar3 + 0x84) = 1;
  *(undefined8 *)(puVar3 + 0x86) = uVar2;
  puVar3[0x88] = 0;
  puVar3[0x89] = 0;
  puVar3[0x8a] = 0;
  puVar3[0x8b] = 0;
  *(undefined8 *)(puVar3 + 0x8c) = 0;
  *(undefined *)(puVar3 + 0x8e) = 1;
  puVar3[0x90] = 0;
  *(undefined8 *)(puVar3 + 0x92) = uVar2;
  puVar3[0x94] = 0;
  puVar3[0x96] = 0;
  puVar3[0x97] = 0;
  puVar3[0x98] = 0;
  puVar3[0x99] = 0;
  *(undefined *)(puVar3 + 0x9a) = 1;
  puVar3[0x9c] = 0;
  puVar3[0x9d] = 0;
  puVar3[0x9e] = 0;
  puVar3[0xa3] = 0;
  puVar3[0xa4] = 0xf;
  *(undefined *)(puVar3 + 0x9f) = 0;
  puVar3[0xa5] = 0;
  *(undefined *)(puVar3 + 0xa6) = 0;
  puVar3[0xa7] = 0;
  puVar3[0xa8] = 0;
  puVar3[0xa9] = 0;
  puVar3[0xaa] = 0;
  puVar3[0xab] = 0;
  puVar3[0xac] = 0;
  puVar3[0xad] = 0;
  puVar3[0xae] = 0;
  puVar3[0xaf] = 0;
  puVar3[0xb0] = 0;
  puVar3[0xb1] = 0;
  puVar3[0xb2] = 0;
  puVar3[0xb3] = 0;
  puVar3[0xb4] = 0;
  puVar3[0xb5] = 0;
  puVar3[0xb6] = 0;
  puVar3[0xb7] = 0;
  puVar3[0xb8] = 0;
  puVar3[0xb9] = 0;
  puVar3[0xba] = 0;
  puVar3[0xbb] = 0;
  puVar3[0xbc] = 0;
  puVar3[0xbd] = 0;
  puVar3[0xbe] = 0;
  puVar3[0xbf] = 0;
  puVar3[0xc0] = 0;
  puVar3[0xc1] = 0;
  puVar3[0xc2] = 0;
  puVar3[0xc3] = 0;
  puVar3[0xc4] = 0;
  puVar3[0xc5] = 0;
  puVar3[0xc6] = 0;
  puVar3[199] = 0;
  puVar3[200] = 0;
  puVar3[0xc9] = 0;
  puVar3[0xca] = 0;
  puVar3[0xcb] = 0;
  puVar3[0xcc] = 0;
  puVar1 = puVar3 + 0xcd;
  uStack_8._0_1_ = 0x35;
  *puVar1 = 0;
  puVar3[0xce] = 0;
  puStack_1c = puVar1;
  uVar4 = FUN_00575ab0();
  *puVar1 = uVar4;
  uStack_8._0_1_ = 0x36;
  *(undefined *)(puVar3 + 0x51) = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("Players",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
  FUN_008a6520(auStack_34);
  if (0xf < uStack_20) {
    uVar8 = uStack_20 + 1;
    uVar7 = auStack_34[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_34[0] - 4);
      uVar8 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 17539 ; VA 0x0096be70 ; FUN_0096be70 */

undefined8 * __fastcall FUN_0096be70(undefined8 *param_1)

{
  *param_1 = 0;
  *(undefined2 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0xf;
  *(undefined *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)((int)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0xf;
  *(undefined *)((int)param_1 + 0x24) = 0;
  *(undefined4 *)((int)param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 10) = 0xf;
  *(undefined *)((int)param_1 + 0x3c) = 0;
  return param_1;
}



/* FUNCTION 17540 ; VA 0x0096bec0 ; FUN_0096bec0 */

void __fastcall FUN_0096bec0(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 100);
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    ExceptionList = &pvStack_10;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x48);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  uVar3 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  uVar3 = *(uint *)(param_1 + 8);
  uStack_8 = 1;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17541 ; VA 0x0096bfc0 ; FUN_0096bfc0 */

void __fastcall FUN_0096bfc0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0096c002. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 17542 ; VA 0x0096c010 ; FUN_0096c010 */

void __fastcall FUN_0096c010(uint *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)param_1[9];
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *param_1;
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17543 ; VA 0x0096c080 ; FUN_0096c080 */

code * __fastcall FUN_0096c080(int *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = (code *)param_1[8];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 10,param_1 + 10,2);
      }
    }
    param_1[8] = 0;
  }
  piVar5 = (int *)param_1[7];
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    pcVar6 = (code *)FUN_01674ea0(iVar7,uVar8);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 17544 ; VA 0x0096c150 ; FUN_0096c150 */

void __fastcall FUN_0096c150(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  FUN_005c4ac0();
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 17545 ; VA 0x0096c1b0 ; FUN_0096c1b0 */

void __fastcall FUN_0096c1b0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 17546 ; VA 0x0096c220 ; FUN_0096c220 */

void __fastcall FUN_0096c220(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,struct_RBX::PlayerNameCache::ExpiringCacheEntry<__int64>,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
             ::vftable;
  FUN_00973790();
  if (param_1[5] != 0) {
    FUN_005d31b0(param_1[8] + param_1[4] * 4,0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0096cd30();
  FUN_00973790();
  FUN_01674ea0(param_1[1],0x38);
  return;
}



/* FUNCTION 17547 ; VA 0x0096c2a0 ; FUN_0096c2a0 */

void __fastcall FUN_0096c2a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,struct_RBX::Players::ThumbnailRequestRecord,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>
             ::vftable;
  FUN_00973810();
  if (param_1[5] != 0) {
    FUN_005d31b0(param_1[8] + param_1[4] * 4,0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0096cd30();
  FUN_00973810();
  FUN_01674ea0(param_1[1],0x40);
  return;
}



/* FUNCTION 17548 ; VA 0x0096c320 ; FUN_0096c320 */

void __fastcall FUN_0096c320(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<__int64,struct_RBX::PlayerNameCache::ExpiringCacheEntry<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_boost::hash<__int64>_>
             ::vftable;
  FUN_00973890();
  if (param_1[5] != 0) {
    puVar1 = (undefined4 *)(param_1[8] + param_1[4] * 4);
    puVar2 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar2;
      FUN_01674ea0(puVar2,0x18);
      param_1[5] = param_1[5] + -1;
      puVar2 = (undefined4 *)*puVar1;
    } while (puVar2 != (undefined4 *)0x0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0056d250();
  FUN_00973890();
  FUN_01674ea0(param_1[1],0x38);
  return;
}



/* FUNCTION 17549 ; VA 0x0096c3b0 ; FUN_0096c3b0 */

void __fastcall FUN_0096c3b0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0096c7c0();
  return;
}



/* FUNCTION 17550 ; VA 0x0096c410 ; FUN_0096c410 */

void __fastcall FUN_0096c410(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0096c850();
  return;
}



/* FUNCTION 17551 ; VA 0x0096c470 ; FUN_0096c470 */

void __fastcall FUN_0096c470(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x48) {
    FUN_0096ca80();
  }
  return;
}



/* FUNCTION 17552 ; VA 0x0096c4a0 ; FUN_0096c4a0 */

void __fastcall FUN_0096c4a0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x58) {
    FUN_0096d6c0();
  }
  return;
}



/* FUNCTION 17553 ; VA 0x0096c4d0 ; FUN_0096c4d0 */

void FUN_0096c4d0(void)

{
  FUN_0096ca80();
  return;
}



/* FUNCTION 17554 ; VA 0x0096c4e0 ; FUN_0096c4e0 */

void FUN_0096c4e0(void)

{
  FUN_0096cbb0();
  return;
}



/* FUNCTION 17555 ; VA 0x0096c4f0 ; FUN_0096c4f0 */

void __fastcall FUN_0096c4f0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 100);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *(uint *)(param_1 + 0x40);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x48,param_1 + 0x48,2);
      }
    }
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  FUN_008c3170();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17556 ; VA 0x0096c570 ; FUN_0096c570 */

void FUN_0096c570(void)

{
  FUN_008e9ba0();
  return;
}



/* FUNCTION 17557 ; VA 0x0096c580 ; FUN_0096c580 */

void __fastcall FUN_0096c580(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x50);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x58,param_1 + 0x58,2);
      }
    }
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  FUN_0096cca0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17558 ; VA 0x0096c5e0 ; FUN_0096c5e0 */

void FUN_0096c5e0(void)

{
  FUN_0096cc40();
  return;
}



/* FUNCTION 17559 ; VA 0x0096c5f0 ; FUN_0096c5f0 */

void __fastcall FUN_0096c5f0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_0096ce60();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x98);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 17560 ; VA 0x0096c6b0 ; thunk_FUN_0096ca80 */

void __fastcall thunk_FUN_0096ca80(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17561 ; VA 0x0096c6c0 ; thunk_FUN_008e9ba0 */

code * __fastcall thunk_FUN_008e9ba0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  pcVar4 = *(code **)(param_1 + 8);
  uStack_8 = 1;
  if (pcVar4 != (code *)0x0) {
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      if (pcVar4 != (code *)0x0) {
        pcVar4 = (code *)(*pcVar4)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 17562 ; VA 0x0096c6d0 ; thunk_FUN_0096cbb0 */

void __fastcall thunk_FUN_0096cbb0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_0096c9b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17563 ; VA 0x0096c6e0 ; FUN_0096c6e0 */

void __fastcall FUN_0096c6e0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x5c);
  ExceptionList = &pvStack_10;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    ExceptionList = &pvStack_10;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  FUN_008c3170();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17564 ; VA 0x0096c760 ; FUN_0096c760 */

void __fastcall FUN_0096c760(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x48);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x50,param_1 + 0x50,2);
      }
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  FUN_0096cca0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17565 ; VA 0x0096c7c0 ; FUN_0096c7c0 */

void __fastcall FUN_0096c7c0(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[7];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[2];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[6] = 0;
      piVar7[7] = 0xf;
      *(undefined *)(piVar7 + 2) = 0;
      FUN_01674ea0(piVar7,0x28);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x28);
  return;
}



/* FUNCTION 17566 ; VA 0x0096c850 ; FUN_0096c850 */

void __fastcall FUN_0096c850(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[9];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[4];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[8] = 0;
      piVar7[9] = 0xf;
      *(undefined *)(piVar7 + 4) = 0;
      FUN_01674ea0(piVar7,0x28);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x28);
  return;
}



/* FUNCTION 17567 ; VA 0x0096c8e0 ; FUN_0096c8e0 */

void __fastcall FUN_0096c8e0(undefined4 *param_1)

{
  FUN_00973910();
  FUN_01674ea0(*param_1,0x40);
  return;
}



/* FUNCTION 17568 ; VA 0x0096c900 ; FUN_0096c900 */

void __fastcall FUN_0096c900(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_0096d050();
      FUN_01674ea0(piVar3,0x4c);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x4c);
  return;
}



/* FUNCTION 17569 ; VA 0x0096c950 ; FUN_0096c950 */

void __fastcall FUN_0096c950(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00970ae0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17570 ; VA 0x0096c9b0 ; FUN_0096c9b0 */

void __fastcall FUN_0096c9b0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0096ca18. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 17571 ; VA 0x0096ca20 ; FUN_0096ca20 */

void __fastcall FUN_0096ca20(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0096ca73. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 17572 ; VA 0x0096ca80 ; FUN_0096ca80 */

void __fastcall FUN_0096ca80(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  uVar1 = *(uint *)(param_1 + 8);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17573 ; VA 0x0096cb10 ; FUN_0096cb10 */

void __fastcall FUN_0096cb10(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_0096c9b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17574 ; VA 0x0096cb70 ; FUN_0096cb70 */

void __fastcall FUN_0096cb70(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0056cac0();
  return;
}



/* FUNCTION 17575 ; VA 0x0096cbb0 ; FUN_0096cbb0 */

void __fastcall FUN_0096cbb0(int param_1)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = *(uint *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x40,param_1 + 0x40,2);
      }
    }
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  uVar1 = *(uint *)(param_1 + 0x18);
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  FUN_0096c9b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17576 ; VA 0x0096cc40 ; FUN_0096cc40 */

void __fastcall FUN_0096cc40(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x3c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0096ca20();
  return;
}



/* FUNCTION 17577 ; VA 0x0096cca0 ; FUN_0096cca0 */

void __fastcall FUN_0096cca0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar2 = *(uint *)(param_1 + 0x28);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x30,param_1 + 0x30,2);
      }
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  piVar3 = *(int **)(param_1 + 0x24);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0056cac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17578 ; VA 0x0096cd30 ; FUN_0096cd30 */

void __fastcall FUN_0096cd30(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_005d31b0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 17579 ; VA 0x0096cdb0 ; FUN_0096cdb0 */

void __fastcall FUN_0096cdb0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_0096e370(*param_1);
  }
  return;
}



/* FUNCTION 17580 ; VA 0x0096cdc0 ; FUN_0096cdc0 */

void __fastcall FUN_0096cdc0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0096c7c0();
  return;
}



/* FUNCTION 17581 ; VA 0x0096cdd0 ; FUN_0096cdd0 */

void __fastcall FUN_0096cdd0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_0096c850();
  return;
}



/* FUNCTION 17582 ; VA 0x0096cde0 ; FUN_0096cde0 */

void __fastcall FUN_0096cde0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00961b20(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 17583 ; VA 0x0096ce60 ; FUN_0096ce60 */

void __fastcall FUN_0096ce60(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x94);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x80);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096cfe1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x90) = 0;
  *(undefined4 *)(param_1 + 0x94) = 0xf;
  *(undefined *)(param_1 + 0x80) = 0;
  FUN_00973910();
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x78),0x40);
  uVar1 = *(uint *)(param_1 + 0x74);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x60);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096cfe1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0xf;
  *(undefined *)(param_1 + 0x60) = 0;
  uVar1 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x48);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096cfe1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  uVar1 = *(uint *)(param_1 + 0x44);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x30);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096cfe1;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0xf;
  *(undefined *)(param_1 + 0x30) = 0;
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0096cfe1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 17584 ; VA 0x0096cff0 ; FUN_0096cff0 */

void __fastcall FUN_0096cff0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00577a40();
  return;
}



/* FUNCTION 17585 ; VA 0x0096d050 ; FUN_0096d050 */

void __fastcall FUN_0096d050(int *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_1[0x10];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0xb];
  if (0xf < uVar3) {
    iVar4 = param_1[6];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_0096d129;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar3 = param_1[5];
  if (0xf < uVar3) {
    iVar4 = *param_1;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_0096d129:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 17586 ; VA 0x0096d130 ; FUN_0096d130 */

void __fastcall FUN_0096d130(int param_1)

{
  FUN_016dedfb(param_1 + 0x50);
  FUN_0096c320();
  FUN_0096c220();
  return;
}



/* FUNCTION 17587 ; VA 0x0096d150 ; FUN_0096d150 */

void __fastcall FUN_0096d150(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0xcd;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Players::vftable;
  param_1[0x30] = 0;
  iVar4 = *piVar1;
  uStack_8 = 0;
  FUN_00970ae0(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0xce] = 0;
  FUN_01674ea0(*piVar1,0x20);
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0xa5];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_005507b0();
  FUN_0096cde0();
  FUN_0096c2a0();
  piVar1 = (int *)param_1[0x76];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x73];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_016dedfb(param_1 + 0x66);
  FUN_0096c320();
  FUN_0096c220();
  piVar1 = (int *)param_1[0x3e];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_005e61c0();
  piVar1 = (int *)param_1[0x2f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0096c900();
  FUN_00611620();
  if (param_1[0x2a] != 0) {
    FUN_0096e370(param_1[0x2a]);
  }
  iVar4 = param_1[0x26];
  piVar1 = param_1 + 0x26;
  uStack_8 = 3;
  FUN_00576720(*(undefined4 *)(iVar4 + 4));
  *(int *)(*piVar1 + 4) = iVar4;
  *(int *)*piVar1 = iVar4;
  *(int *)(*piVar1 + 8) = iVar4;
  param_1[0x27] = 0;
  FUN_01674ea0(*piVar1,0x28);
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x23];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x21];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x1f];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x1d];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_005507b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17588 ; VA 0x0096d5e0 ; FUN_0096d5e0 */

void __fastcall FUN_0096d5e0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x3c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096d6af;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  uVar1 = *(uint *)(param_1 + 0x38);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x24);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0096d6af;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar1 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0096d6af:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  return;
}



/* FUNCTION 17589 ; VA 0x0096d6c0 ; FUN_0096d6c0 */

void __fastcall FUN_0096d6c0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[0xe];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    param_1[0xe] = 0;
  }
  uVar1 = param_1[6];
  uStack_8 = 1;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar1 & 0xfffffffe))(param_1 + 8,param_1 + 8,2);
      }
    }
    param_1[6] = 0;
  }
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17590 ; VA 0x0096d790 ; FUN_0096d790 */

uint * __thiscall FUN_0096d790(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint *puStack_8;
  
  puVar1 = (undefined4 *)*param_1;
  puVar6 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    uVar2 = param_2[1];
    puVar3 = (undefined4 *)puVar1[1];
    do {
      if (((int)uVar2 < (int)puVar3[5]) ||
         (((int)uVar2 <= (int)puVar3[5] && (*param_2 <= (uint)puVar3[4])))) {
        puVar4 = (undefined4 *)*puVar3;
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if (((puVar6 != puVar1) && ((int)puVar6[5] <= (int)uVar2)) &&
       (((int)puVar6[5] < (int)uVar2 || ((uint)puVar6[4] <= *param_2)))) {
      return puVar6 + 6;
    }
  }
  puStack_8 = param_2;
  iVar5 = FUN_009617c0(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_00962800(&param_2,puVar6,iVar5 + 0x10,iVar5);
  return param_2 + 6;
}



/* FUNCTION 17591 ; VA 0x0096d830 ; FUN_0096d830 */

int * __thiscall FUN_0096d830(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_10;
  undefined4 *puStack_c;
  int *piStack_8;
  
  piVar2 = param_2;
  FUN_0097be30(&param_2,param_2);
  if (param_2 == *(int **)(param_1 + 4)) {
    piStack_8 = piVar2;
    iVar1 = **(int **)(param_1 + 4);
    puStack_c = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00961720(iVar1,puStack_c,&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x6666665) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_c = uVar3;
    FUN_00962290(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    param_2 = piStack_10;
  }
  return param_2 + 8;
}



/* FUNCTION 17592 ; VA 0x0096d8c0 ; FUN_0096d8c0 */

int __thiscall FUN_0096d8c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined *puVar7;
  undefined *puVar8;
  int iVar9;
  uint auStack_114 [2];
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  int iStack_100;
  ulonglong uStack_fc;
  uint auStack_f4 [2];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined8 uStack_dc;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined auStack_cc [92];
  undefined4 uStack_70;
  int iStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  int iStack_38;
  int *piStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce310;
  pvStack_10 = ExceptionList;
  piStack_44 = &iStack_38;
  uStack_48 = 0x96d8e8;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  iStack_8 = 0;
  if (iStack_38 == 0) {
    piStack_44 = (int *)0x19368b8;
    uStack_48 = 3;
    uStack_4c = 0x96d902;
    iVar9 = FUN_0086f2f0();
  }
  else {
    puStack_20 = auStack_60;
    uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01ee2fea);
    uStack_64 = 0;
    puStack_1c = auStack_cc;
    uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01ee2fe9);
    puStack_24 = (undefined *)&uStack_d4;
    if (*(int *)(param_1 + 100) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 100) + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_d4 = *(undefined4 *)(param_1 + 0x60);
    uStack_d0 = *(undefined4 *)(param_1 + 100);
    puStack_28 = (undefined *)auStack_f4;
    puStack_2c = (undefined *)auStack_f4;
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    auStack_f4[0] = 0;
    uVar3 = *(uint *)(param_1 + 0x28);
    puVar4 = auStack_f4;
    puVar6 = &uStack_d4;
    puVar7 = auStack_60;
    puVar8 = auStack_cc;
    if (uVar3 != 0) {
      auStack_f4[0] = uVar3;
      if ((uVar3 & 1) == 0) {
        uStack_fc = ZEXT48(&uStack_ec);
        iStack_100 = param_1 + 0x30;
        uStack_104 = 0x96d99f;
        (**(code **)(uVar3 & 0xfffffffe))();
        puVar4 = (uint *)puStack_28;
        puVar6 = (undefined4 *)puStack_24;
        puVar7 = puStack_20;
        puVar8 = puStack_1c;
      }
      else {
        uStack_ec = *(undefined4 *)(param_1 + 0x30);
        uStack_e8 = *(undefined4 *)(param_1 + 0x34);
        uStack_e4 = *(undefined4 *)(param_1 + 0x38);
        uStack_e0 = *(undefined4 *)(param_1 + 0x3c);
        uStack_dc = *(undefined8 *)(param_1 + 0x40);
        puVar4 = auStack_f4;
        puVar6 = &uStack_d4;
        puVar7 = auStack_60;
        puVar8 = auStack_cc;
      }
    }
    puStack_1c = puVar8;
    puStack_20 = puVar7;
    puStack_24 = (undefined *)puVar6;
    puStack_28 = (undefined *)puVar4;
    puStack_2c = (undefined *)auStack_114;
    puStack_30 = (undefined *)auStack_114;
    iStack_8._0_1_ = 2;
    auStack_114[0] = 0;
    uVar3 = *(uint *)(param_1 + 8);
    puVar4 = auStack_114;
    puVar5 = auStack_114;
    if (uVar3 != 0) {
      auStack_114[0] = uVar3;
      if ((uVar3 & 1) == 0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,&uStack_10c,0);
        puVar4 = (uint *)puStack_30;
        puVar5 = (uint *)puStack_2c;
      }
      else {
        uStack_10c = *(undefined4 *)(param_1 + 0x10);
        uStack_108 = *(undefined4 *)(param_1 + 0x14);
        uStack_104 = *(undefined4 *)(param_1 + 0x18);
        iStack_100 = *(int *)(param_1 + 0x1c);
        uStack_fc = *(ulonglong *)(param_1 + 0x20);
        puVar4 = auStack_114;
        puVar5 = auStack_114;
      }
    }
    puStack_2c = (undefined *)puVar5;
    puStack_30 = (undefined *)puVar4;
    iStack_8._0_1_ = 3;
    FUN_0054ef60(param_1 + 0x48);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_009651b0(puStack_1c,FUN_009813d0,uStack_18,uStack_14);
    uStack_d0 = 0x96da21;
    FUN_00960a90();
    uStack_64 = param_3;
    uStack_68 = param_2;
    iStack_6c = iStack_38;
    uStack_70 = 0x96da2d;
    iVar9 = FUN_008ed3f0();
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_34 + 1;
    iVar2 = *piVar1;
    iVar9 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_44 = (int *)0x96da49;
      iVar9 = (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_44 = (int *)0x96da58;
        iVar9 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 17593 ; VA 0x0096da70 ; FUN_0096da70 */

int __thiscall FUN_0096da70(uint *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint *puVar4;
  int iVar5;
  char *pcVar6;
  undefined4 *puVar7;
  uint in_stack_00000018;
  uint auStack_e0 [2];
  uint uStack_d8;
  uint uStack_d4;
  uint uStack_d0;
  uint uStack_cc;
  undefined8 uStack_c8;
  undefined auStack_c0 [20];
  undefined4 uStack_ac;
  undefined auStack_a8 [56];
  undefined4 uStack_70;
  undefined auStack_6c [20];
  undefined4 uStack_58;
  char **ppcStack_54;
  char *pcStack_50;
  int *piStack_4c;
  char *apcStack_40 [5];
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce340;
  pvStack_10 = ExceptionList;
  piStack_4c = &iStack_28;
  uStack_8 = 0;
  pcStack_50 = (char *)0x96daa2;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490();
  uStack_8._0_1_ = 1;
  if (iStack_28 != 0) {
    piStack_4c = (int *)&param_2;
    if (0xf < in_stack_00000018) {
      piStack_4c = param_2;
    }
    ppcStack_54 = apcStack_40;
    pcStack_50 = "Players:GetCharacterAppearanceInfoAsync() failed because %s";
    uStack_58 = 0x96dacb;
    FUN_01675640();
    piStack_4c = (int *)0x1;
    puStack_18 = auStack_6c;
    uStack_8._0_1_ = 2;
    uStack_70 = 0;
    puStack_14 = auStack_a8;
    puStack_1c = auStack_c0;
    uStack_c8 = CONCAT44(apcStack_40,0x96daf3);
    FUN_0054ef60();
    puStack_20 = (undefined *)auStack_e0;
    uStack_8._0_1_ = 3;
    auStack_e0[0] = 0;
    uVar3 = *param_1;
    puVar4 = auStack_e0;
    if (uVar3 != 0) {
      auStack_e0[0] = uVar3;
      if ((uVar3 & 1) == 0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,&uStack_d8,0);
        puVar4 = (uint *)puStack_20;
      }
      else {
        uStack_d8 = param_1[2];
        uStack_d4 = param_1[3];
        uStack_d0 = param_1[4];
        uStack_cc = param_1[5];
        uStack_c8 = *(undefined8 *)(param_1 + 6);
        puVar4 = auStack_e0;
      }
    }
    puStack_20 = (undefined *)puVar4;
    uStack_8._0_1_ = 2;
    FUN_009645a0(puStack_14);
    uStack_ac = 0x96db51;
    FUN_0095fcd0();
    uStack_70 = 0x96db58;
    iVar5 = FUN_0090ca30();
    if (0xf < uStack_2c) {
      piStack_4c = (int *)(uStack_2c + 1);
      pcVar6 = apcStack_40[0];
      if (0xfff < piStack_4c) {
        pcVar6 = *(char **)(apcStack_40[0] + -4);
        piStack_4c = (int *)(uStack_2c + 0x24);
        if ((char *)0x1f < apcStack_40[0] + (-4 - (int)pcVar6)) {
                    /* WARNING: Subroutine does not return */
          piStack_4c = (int *)0x96dbf7;
          FUN_017167a3();
        }
      }
      ppcStack_54 = (char **)0x96db85;
      pcStack_50 = pcVar6;
      iVar5 = FUN_01674ea0();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_4c = (int *)0x96dba1;
      iVar5 = (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_4c = (int *)0x96dbb0;
        iVar5 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    piStack_4c = (int *)(in_stack_00000018 + 1);
    puVar7 = param_2;
    if (0xfff < piStack_4c) {
      puVar7 = (undefined4 *)param_2[-1];
      piStack_4c = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        piStack_4c = (int *)&UNK_0096dbfc;
        FUN_017167a3();
      }
    }
    ppcStack_54 = (char **)0x96dbdd;
    pcStack_50 = (char *)puVar7;
    iVar5 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17594 ; VA 0x0096dc00 ; FUN_0096dc00 */

void FUN_0096dc00(undefined4 param_1)

{
  char cVar1;
  char *pcVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char ****ppppcVar5;
  char ****ppppcVar6;
  uint uVar7;
  uint uVar8;
  char ***pppcStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce368;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_014ca230(auStack_18,param_1);
  pcVar2 = (char *)*puVar3;
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  FUN_005542c0("AbuseReportScreenshot-",0x16);
  uStack_8 = 0;
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  puVar3 = (undefined4 *)FUN_00554150(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
  pppcStack_60 = (char ***)*puVar3;
  uStack_5c = puVar3[1];
  uStack_58 = puVar3[2];
  uStack_54 = puVar3[3];
  uStack_50 = *(undefined8 *)(puVar3 + 4);
  puVar3[4] = 0;
  puVar3[5] = 0xf;
  *(undefined *)puVar3 = 0;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar8 = uStack_30;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(uStack_30 - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (uStack_30 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_20 = 0;
  ppppcVar6 = &pppcStack_60;
  if (0xf < uStack_50._4_4_) {
    ppppcVar6 = (char ****)pppcStack_60;
  }
  uStack_1c = 0xf;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  ppppcVar5 = ppppcVar6;
  do {
    cVar1 = *(char *)ppppcVar5;
    ppppcVar5 = (char ****)((int)ppppcVar5 + 1);
  } while (cVar1 != '\0');
  FUN_005542c0(ppppcVar6,(int)ppppcVar5 - (int)((int)ppppcVar6 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008783f0(auStack_48,1,0);
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar8 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  if (0xf < uStack_50._4_4_) {
    uVar8 = uStack_50._4_4_ + 1;
    ppppcVar6 = (char ****)pppcStack_60;
    if (0xfff < uVar8) {
      ppppcVar6 = (char ****)pppcStack_60[-1];
      uVar8 = uStack_50._4_4_ + 0x24;
      if ((char *)0x1f < (char *)((int)pppcStack_60 + (-4 - (int)ppppcVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar6,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17595 ; VA 0x0096ddb0 ; FUN_0096ddb0 */

int * FUN_0096ddb0(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce390;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_00587490(&iStack_2c);
  uStack_8 = 0;
  if (iStack_2c != 0) {
    piVar4 = (int *)FUN_00564080();
    iStack_24 = 0;
    piStack_20 = (int *)0x0;
    iVar3 = *piVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar3 != 0) {
      piVar5 = *(int **)(iVar3 + 0x1d8);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = *(int **)(iVar3 + 0x1d8);
      }
      iStack_24 = *(int *)(iVar3 + 0x1d4);
      *(undefined4 *)(iVar3 + 0x1d4) = 0;
      piStack_14 = *(int **)(iVar3 + 0x1d8);
      *(undefined4 *)(iVar3 + 0x1d8) = 0;
      piStack_20 = piVar5;
      iStack_18 = iStack_24;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar2 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar4 = (int *)(**(code **)(*piStack_14 + 4))();
          }
        }
      }
      *(undefined4 *)(iVar3 + 0x1dc) = 0;
      if (iStack_18 != 0) {
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        if (puStack_1c[1] != 0) {
          LOCK();
          piVar4 = (int *)(puStack_1c[1] + 8);
          *piVar4 = *piVar4 + 1;
          UNLOCK();
        }
        piVar4 = (int *)FUN_0098b780(*puStack_1c,puStack_1c[1],iStack_18,piVar5);
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar4 = (int *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_28 + 1;
    iVar3 = *piVar5;
    piVar4 = (int *)*piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piStack_28)();
      LOCK();
      piVar5 = piStack_28 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar4 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 17596 ; VA 0x0096df40 ; FUN_0096df40 */

void __thiscall FUN_0096df40(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ce3c0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uVar2 = *(uint *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if ((uVar2 != 0) && (ExceptionList = &pvStack_10, (uVar2 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar2 & 0xfffffffe))();
  }
  iStack_8._0_1_ = 1;
  uVar2 = *(uint *)(param_1 + 8);
  if ((uVar2 != 0) && ((uVar2 & 1) == 0)) {
    (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10);
  }
  if (*(int *)(param_1 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 4) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 3;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_009752f0();
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17597 ; VA 0x0096e090 ; FUN_0096e090 */

int * FUN_0096e090(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ce3e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_00587490(&iStack_2c);
  uStack_8 = 0;
  if (iStack_2c != 0) {
    piVar4 = (int *)FUN_00564080();
    iStack_24 = 0;
    piStack_20 = (int *)0x0;
    iVar3 = *piVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar3 != 0) {
      piVar5 = *(int **)(iVar3 + 0x1cc);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = *(int **)(iVar3 + 0x1cc);
      }
      iStack_24 = *(int *)(iVar3 + 0x1c8);
      *(undefined4 *)(iVar3 + 0x1c8) = 0;
      piStack_14 = *(int **)(iVar3 + 0x1cc);
      *(undefined4 *)(iVar3 + 0x1cc) = 0;
      piStack_20 = piVar5;
      iStack_18 = iStack_24;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar2 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            piVar4 = (int *)(**(code **)(*piStack_14 + 4))();
          }
        }
      }
      *(undefined4 *)(iVar3 + 0x1d0) = 0;
      if (iStack_18 != 0) {
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        if (puStack_1c[1] != 0) {
          LOCK();
          piVar4 = (int *)(puStack_1c[1] + 8);
          *piVar4 = *piVar4 + 1;
          UNLOCK();
        }
        piVar4 = (int *)FUN_0098bda0(*puStack_1c,puStack_1c[1],iStack_18,piVar5);
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *piVar1;
        piVar4 = (int *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            piVar4 = (int *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_28 + 1;
    iVar3 = *piVar5;
    piVar4 = (int *)*piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piStack_28)();
      LOCK();
      piVar5 = piStack_28 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piVar4 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 17598 ; VA 0x0096e220 ; FUN_0096e220 */

void __thiscall FUN_0096e220(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ce3c0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  uVar2 = *(uint *)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if ((uVar2 != 0) && (ExceptionList = &pvStack_10, (uVar2 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar2 & 0xfffffffe))();
  }
  iStack_8._0_1_ = 1;
  uVar2 = *(uint *)(param_1 + 8);
  if ((uVar2 != 0) && ((uVar2 & 1) == 0)) {
    (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x10);
  }
  if (*(int *)(param_1 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 4) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8._0_1_ = 3;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_009752f0();
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17599 ; VA 0x0096e370 ; FUN_0096e370 */

void FUN_0096e370(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 8);
    if (iVar2 != 0) {
      FUN_01519bf0();
      FUN_01674ea0(iVar2,8);
    }
    piVar3 = *(int **)(param_1 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[1] + -1;
      piVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(param_1,0xc);
  }
  return;
}



/* FUNCTION 17600 ; VA 0x0096e3d0 ; FUN_0096e3d0 */

/* WARNING: Removing unreachable block (ram,0x0096e43d) */
/* WARNING: Removing unreachable block (ram,0x0096e449) */
/* WARNING: Removing unreachable block (ram,0x0096e457) */

undefined4 __thiscall FUN_0096e3d0(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce400;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17601 ; VA 0x0096e490 ; FUN_0096e490 */

/* WARNING: Removing unreachable block (ram,0x0096e4fd) */
/* WARNING: Removing unreachable block (ram,0x0096e509) */
/* WARNING: Removing unreachable block (ram,0x0096e517) */

undefined4 __thiscall FUN_0096e490(uint *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce420;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar1);
  }
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17602 ; VA 0x0096e550 ; FUN_0096e550 */

uint FUN_0096e550(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = param_1[1];
  if (((int)uVar1 <= (int)param_2[1]) &&
     (((int)uVar1 < (int)param_2[1] || (uVar1 = *param_1, uVar1 < *param_2)))) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 17603 ; VA 0x0096e580 ; FUN_0096e580 */

void __thiscall FUN_0096e580(undefined4 *param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce458;
  pvStack_10 = ExceptionList;
  param_2 = auStack_40;
  pcVar1 = (code *)*param_1;
  uStack_8 = 2;
  auStack_40[0] = 0;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_40;
  if (in_stack_00000044 != 0) {
    auStack_40[0] = in_stack_00000044;
    if ((in_stack_00000044 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      puStack_4c = &stack0x0000004c;
      uStack_50 = 0x96e5f0;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
      puVar3 = param_2;
    }
    else {
      uStack_38 = in_stack_0000004c;
      uStack_34 = in_stack_00000050;
      uStack_30 = in_stack_00000054;
      uStack_2c = in_stack_00000058;
      uStack_28 = in_stack_0000005c;
      ExceptionList = &pvStack_10;
      puVar3 = auStack_40;
    }
  }
  param_2 = puVar3;
  uStack_8._0_1_ = 3;
  if (in_stack_00000024 != 0) {
    if ((in_stack_00000024 & 1) == 0) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_58,0);
    }
    else {
      uStack_58 = in_stack_0000002c;
      uStack_54 = in_stack_00000030;
      uStack_50 = in_stack_00000034;
      puStack_4c = in_stack_00000038;
      uStack_48 = in_stack_0000003c;
    }
  }
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_3);
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17604 ; VA 0x0096e710 ; FUN_0096e710 */

void __thiscall
FUN_0096e710(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000038;
  uint in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_00000054;
  undefined auStack_38 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce498;
  pvStack_10 = ExceptionList;
  pcVar1 = (code *)*param_1;
  param_2 = auStack_38;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60(&stack0x00000028);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar1)(param_3,param_4);
  if (0xf < in_stack_00000024) {
    uVar3 = in_stack_00000024 + 1;
    uVar4 = param_5;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(param_5 - 4);
      uVar3 = in_stack_00000024 + 0x24;
      if (0x1f < (param_5 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (0xf < in_stack_0000003c) {
    uVar3 = in_stack_0000003c + 1;
    uVar4 = in_stack_00000028;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(in_stack_00000028 - 4);
      uVar3 = in_stack_0000003c + 0x24;
      if (0x1f < (in_stack_00000028 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  in_stack_00000038 = 0;
  in_stack_0000003c = 0xf;
  in_stack_00000028 = in_stack_00000028 & 0xffffff00;
  if (0xf < in_stack_00000054) {
    uVar4 = in_stack_00000054 + 1;
    iVar2 = in_stack_00000040;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(in_stack_00000040 + -4);
      uVar4 = in_stack_00000054 + 0x24;
      if (0x1f < (in_stack_00000040 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17605 ; VA 0x0096e860 ; FUN_0096e860 */

/* WARNING: Removing unreachable block (ram,0x0096e8b2) */
/* WARNING: Removing unreachable block (ram,0x0096e8c2) */
/* WARNING: Removing unreachable block (ram,0x0096e8c8) */

void * __thiscall FUN_0096e860(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  int *in_stack_00000010;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce4c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (in_stack_00000010 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000010 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*in_stack_00000010)();
      LOCK();
      piVar1 = in_stack_00000010 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*in_stack_00000010 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 17606 ; VA 0x0096e93c ; Catch@0096e93c */

undefined * Catch_0096e93c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0096e94d;
}



/* FUNCTION 17607 ; VA 0x0096e960 ; FUN_0096e960 */

/* WARNING: Removing unreachable block (ram,0x0096e9b2) */
/* WARNING: Removing unreachable block (ram,0x0096e9c2) */
/* WARNING: Removing unreachable block (ram,0x0096e9c8) */

void __fastcall FUN_0096e960(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce4f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
  }
  FUN_0096ce60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17608 ; VA 0x0096ea19 ; Catch@0096ea19 */

undefined * Catch_0096ea19(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0096ea2a;
}



/* FUNCTION 17609 ; VA 0x0096ea40 ; FUN_0096ea40 */

/* WARNING: Removing unreachable block (ram,0x0096eb2a) */
/* WARNING: Removing unreachable block (ram,0x0096eb3a) */
/* WARNING: Removing unreachable block (ram,0x0096eb40) */

void __thiscall FUN_0096ea40(int *param_1,int param_2)

{
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce538;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) &&
       (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17610 ; VA 0x0096ebac ; Catch@0096ebac */

undefined * Catch_0096ebac(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_0096ebbd;
}



/* FUNCTION 17611 ; VA 0x0096ebe0 ; FUN_0096ebe0 */

/* WARNING: Removing unreachable block (ram,0x0096ec32) */
/* WARNING: Removing unreachable block (ram,0x0096ec42) */
/* WARNING: Removing unreachable block (ram,0x0096ec48) */

void * __thiscall
FUN_0096ebe0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce570;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 17612 ; VA 0x0096ecea ; Catch@0096ecea */

undefined * Catch_0096ecea(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0096ecfb;
}



/* FUNCTION 17613 ; VA 0x0096ed10 ; FUN_0096ed10 */

/* WARNING: Removing unreachable block (ram,0x0096ed62) */
/* WARNING: Removing unreachable block (ram,0x0096ed72) */
/* WARNING: Removing unreachable block (ram,0x0096ed78) */

void * __thiscall FUN_0096ed10(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce598;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 17614 ; VA 0x0096ede3 ; Catch@0096ede3 */

undefined * Catch_0096ede3(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_0096edf4;
}



/* FUNCTION 17615 ; VA 0x0096ee10 ; FUN_0096ee10 */

/* WARNING: Removing unreachable block (ram,0x0096eede) */
/* WARNING: Removing unreachable block (ram,0x0096eeee) */
/* WARNING: Removing unreachable block (ram,0x0096eef4) */

void * __thiscall
FUN_0096ee10(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  void *pvVar3;
  uint in_stack_00000024;
  int *in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ce5e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*param_1 == 0) {
    pvVar3 = ExceptionList;
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      piVar1 = param_4 + 1;
      iVar2 = *piVar1;
      pvVar3 = (void *)*piVar1;
      ExceptionList = &pvStack_10;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar1 = param_4 + 2;
        iVar2 = *piVar1;
        pvVar3 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pvVar3 = (void *)(**(code **)(*param_4 + 4))();
        }
      }
    }
    if (0xf < in_stack_00000024) {
      if ((0xfff < in_stack_00000024 + 1) && (0x1f < (param_5 - *(int *)(param_5 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      pvVar3 = (void *)FUN_01674ea0();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 5;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_01675290();
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar2 = param_4[1] + -1;
      param_4[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_4)();
        LOCK();
        iVar2 = param_4[2] + -1;
        param_4[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
    pvVar3 = (void *)FUN_005507b0();
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_0000002c + 1;
    iVar2 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*in_stack_0000002c)();
      LOCK();
      piVar1 = in_stack_0000002c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar3 = (void *)(**(code **)(*in_stack_0000002c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 17616 ; VA 0x0096efb7 ; Catch@0096efb7 */

undefined * Catch_0096efb7(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_0096efc8;
}



/* FUNCTION 17617 ; VA 0x0096efe0 ; FUN_0096efe0 */

int __thiscall FUN_0096efe0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 17618 ; VA 0x0096f040 ; FUN_0096f040 */

undefined4 __thiscall FUN_0096f040(undefined4 param_1,byte param_2)

{
  FUN_0096c150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 17619 ; VA 0x0096f070 ; FUN_0096f070 */

int __thiscall FUN_0096f070(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),1);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  FUN_005c4ac0();
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 17620 ; VA 0x0096f0e0 ; FUN_0096f0e0 */

int __thiscall FUN_0096f0e0(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 17621 ; VA 0x0096f140 ; FUN_0096f140 */

undefined4 __thiscall FUN_0096f140(undefined4 param_1,byte param_2)

{
  FUN_0096c1b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 17622 ; VA 0x0096f170 ; FUN_0096f170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0096f170(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AssetTypeVerification>::vftable;
  _DAT_01f19c38 = _DAT_01f19c38 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 17623 ; VA 0x0096f1a0 ; FUN_0096f1a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0096f1a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::HumanoidRigType>::vftable;
  _DAT_01ee3d80 = _DAT_01ee3d80 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 17624 ; VA 0x0096f1d0 ; FUN_0096f1d0 */

undefined4 * __thiscall FUN_0096f1d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Player*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 17625 ; VA 0x0096f200 ; FUN_0096f200 */

undefined4 __thiscall FUN_0096f200(undefined4 param_1,byte param_2)

{
  FUN_0096c220();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 17626 ; VA 0x0096f230 ; FUN_0096f230 */

undefined4 __thiscall FUN_0096f230(undefined4 param_1,byte param_2)

{
  FUN_0096c2a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 17627 ; VA 0x0096f260 ; FUN_0096f260 */

undefined4 __thiscall FUN_0096f260(undefined4 param_1,byte param_2)

{
  FUN_0096c320();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 17628 ; VA 0x0096f290 ; FUN_0096f290 */

int * __thiscall FUN_0096f290(int *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0096ca80();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 17629 ; VA 0x0096f330 ; FUN_0096f330 */

int * __thiscall FUN_0096f330(int *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0096d6c0();
        iVar2 = iVar2 + 0x58;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x58) * 0x58;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 17630 ; VA 0x0096f3d0 ; FUN_0096f3d0 */

undefined4 * __thiscall FUN_0096f3d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Player*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 17631 ; VA 0x0096f400 ; FUN_0096f400 */

undefined4 __thiscall FUN_0096f400(undefined4 param_1,byte param_2)

{
  FUN_0096d150();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x340);
  }
  return param_1;
}



/* FUNCTION 17632 ; VA 0x0096f430 ; FUN_0096f430 */

int __thiscall FUN_0096f430(int param_1,byte param_2)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x18);
  *(int *)(param_1 + 0x18) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_0096c5f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 17633 ; VA 0x0096f470 ; FUN_0096f470 */

int FUN_0096f470(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined *puVar9;
  undefined4 ***apppuStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined **appuStack_58 [4];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined ***pppuStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ceb98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_30);
  uStack_8._0_1_ = 1;
  if (iStack_30 != 0) {
    if (iStack_30 + 0xc == 0) {
      iStack_14 = 0;
    }
    else {
      piVar4 = (int *)FUN_00564080();
      iStack_14 = *piVar4;
      if (iStack_14 == 0) {
        FUN_0055e4a0(&iStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_008a5700(iStack_30 + 0xc);
        FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
        uVar5 = FUN_00560c40();
        piVar4 = (int *)FUN_008aa140(uVar5);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        *piVar4 = iStack_28;
        piVar2 = (int *)piVar4[1];
        piVar4[1] = (int)piStack_24;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        iStack_14 = iStack_28;
        uStack_8._0_1_ = 1;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar3 = piStack_24[1] + -1;
          piStack_24[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar3 = piStack_24[2] + -1;
            piStack_24[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
    }
    iVar1 = iStack_14 + 0x27c;
    iVar3 = iStack_14;
    if (2 < *(uint *)(iStack_14 + 0x28c)) {
      uStack_38 = 0;
      pppuStack_34 = (undefined ***)0xf;
      auStack_48[0] = 0;
      FUN_005542c0("AbuseReportScreenshot-StartUpload",0x21);
      uStack_8._0_1_ = 3;
      FUN_008783f0(auStack_48,1,0);
      uStack_8._0_1_ = 1;
      FUN_005507b0();
      FUN_00f57960(apppuStack_70,iVar1);
      uStack_8._0_1_ = 4;
      FUN_014c9d60(&iStack_20,0);
      uStack_8._0_1_ = 5;
      ppppuVar6 = apppuStack_70;
      if (0xf < uStack_5c) {
        ppppuVar6 = (undefined4 ****)apppuStack_70[0];
      }
      FUN_014cbbc0(ppppuVar6,uStack_60);
      *(undefined4 *)(iStack_20 + 0xb0) = 0;
      FUN_014cba60();
      FUN_014cb780(param_3,0);
      FUN_014cb890(0);
      puVar7 = &DAT_01d79f68;
      if (0xf < DAT_01d79f7c) {
        puVar7 = DAT_01d79f68;
      }
      puVar8 = &DAT_01d79d70;
      if (0xf < DAT_01d79d84) {
        puVar8 = DAT_01d79d70;
      }
      FUN_014cb8a0(puVar8,DAT_01d79d80,puVar7,DAT_01d79f78);
      pppuStack_34 = appuStack_58;
      appuStack_58[0] =
           std::
           _Func_impl_no_alloc<class_<lambda_685de64f4ae5e780cfdf8775129e7a85>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
           ::vftable;
      uStack_8._0_1_ = 6;
      FUN_014cb530(pppuStack_34);
      uStack_8._0_1_ = 5;
      if (pppuStack_34 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_34)[4])(pppuStack_34 != appuStack_58);
      }
      puVar9 = (undefined *)(iStack_14 + 0x27c);
      if (0xf < *(uint *)(iStack_14 + 0x290)) {
        puVar9 = *(undefined **)(iStack_14 + 0x27c);
      }
      *(undefined4 *)(iStack_14 + 0x28c) = 0;
      *puVar9 = 0;
      FUN_01679490();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar3 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      iVar3 = FUN_005507b0();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar4 = piStack_2c + 1;
    iVar1 = *piVar4;
    iVar3 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar4 = piStack_2c + 2;
      iVar1 = *piVar4;
      iVar3 = *piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar4 = param_2 + 2;
    iVar1 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17634 ; VA 0x0096f770 ; FUN_0096f770 */

undefined4 __thiscall
FUN_0096f770(TypeDescriptor *param_1,void *param_2,undefined4 param_3,TypeDescriptor *param_4,
            uint param_5)

{
  void *pvVar1;
  void *pvVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  void *pvVar7;
  undefined4 *puVar8;
  TypeDescriptor *pTVar9;
  uint uVar10;
  undefined auStack_33c [8];
  void *pvStack_334;
  void *pvStack_330;
  void *pvStack_32c;
  TypeDescriptor *pTStack_328;
  undefined4 **ppuStack_324;
  TypeDescriptor *pTStack_320;
  TypeDescriptor *pTStack_31c;
  void *pvStack_318;
  TypeDescriptor TStack_314;
  TypeDescriptor *pTStack_30c;
  TypeDescriptor *pTStack_308;
  TypeDescriptor *pTStack_304;
  TypeDescriptor *pTStack_300;
  TypeDescriptor *pTStack_2fc;
  undefined auStack_2d8 [64];
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined auStack_290 [64];
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined auStack_248 [64];
  TypeDescriptor aTStack_208 [5];
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined auStack_1d8 [64];
  undefined auStack_198 [8];
  void *pvStack_190;
  void *pvStack_18c;
  undefined **ppuStack_188;
  void *pvStack_184;
  TypeDescriptor aTStack_180 [3];
  void *pvStack_168;
  void *pvStack_164;
  undefined **ppuStack_160;
  undefined4 *puStack_158;
  void *pvStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined8 uStack_140;
  undefined2 uStack_138;
  undefined uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined auStack_128 [4];
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined uStack_11c;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined uStack_104;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined **ppuStack_e8;
  TypeDescriptor TStack_e0;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined auStack_c0 [64];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  TypeDescriptor aTStack_70 [2];
  int iStack_60;
  uint uStack_5c;
  int iStack_58;
  undefined *puStack_54;
  TypeDescriptor *pTStack_50;
  undefined *puStack_4c;
  TypeDescriptor TStack_44;
  TypeDescriptor TStack_3c;
  undefined4 uStack_34;
  TypeDescriptor TStack_30;
  TypeDescriptor *pTStack_28;
  char cStack_22;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017cecf6;
  pvStack_1c = ExceptionList;
  pvVar7 = param_2;
  pTStack_2fc = param_1;
  if (DAT_01d646e0 == '\0') {
    pTStack_300 = (TypeDescriptor *)0x96f992;
    ExceptionList = &pvStack_1c;
    iVar6 = FUN_005c8880();
    if (iVar6 != 0) {
      pTStack_2fc = (TypeDescriptor *)0x1;
      pTStack_304 = (TypeDescriptor *)0x96f9a5;
      pTStack_300 = param_1;
      cVar5 = FUN_0064a9e0();
      goto joined_r0x0096f9aa;
    }
  }
  else {
    pTStack_300 = (TypeDescriptor *)0x96f7b9;
    ExceptionList = &pvStack_1c;
    puStack_20 = &stack0xfffffffc;
    iVar6 = FUN_008f78c0();
    if (iVar6 != 0) {
      pTStack_300 = (TypeDescriptor *)(iVar6 + 0xc);
      pTStack_2fc = (TypeDescriptor *)0x1;
      pTStack_304 = (TypeDescriptor *)0x96f7cb;
      cVar5 = FUN_0064a9e0();
joined_r0x0096f9aa:
      if (cVar5 == '\0') {
        pvVar7 = param_1[0x1e].spare;
      }
    }
  }
  if (pvVar7 == (void *)0x0) {
    ExceptionList = pvStack_1c;
    return 0;
  }
  if (*(int *)((int)pvVar7 + 0xec) == 1) {
    ExceptionList = pvStack_1c;
    return 0;
  }
  pTStack_2fc = (TypeDescriptor *)0x0;
  pTStack_300 = (TypeDescriptor *)param_4[6].pVFTable;
  pTStack_304 = (TypeDescriptor *)param_4[7].pVFTable;
  pTStack_308 = (TypeDescriptor *)0x96f809;
  FUN_006ab380();
  pTStack_2fc = (TypeDescriptor *)0x1;
  uStack_14._0_1_ = 0;
  uStack_14._1_3_ = 0;
  pTStack_300 = (TypeDescriptor *)0x96f81d;
  FUN_006ab660();
  pTStack_300 = (TypeDescriptor *)0x96f823;
  pTStack_2fc = param_1;
  iVar6 = FUN_008f7870();
  if (iVar6 == 0) goto LAB_009701b5;
  pTStack_2fc = (TypeDescriptor *)0x96f835;
  pTStack_2fc = (TypeDescriptor *)FUN_008f87a0();
  uStack_78 = 0xffffffff;
  uStack_74 = 0;
  uStack_80 = 0xffffffff;
  uStack_7c = 0;
  TStack_3c.pVFTable = (void *)0x0;
  TStack_3c.spare = (void *)0x0;
  pTStack_50 = (TypeDescriptor *)0x0;
  puStack_4c = (undefined *)0x0;
  cVar5 = (char)param_5;
  uStack_14._0_1_ = 2;
  uStack_34 = pTStack_2fc;
  if (cVar5 == -0x75) {
LAB_0096f8cd:
    pvVar7 = TStack_3c.pVFTable;
    if (cVar5 == -0x74) {
      pTStack_300 = aTStack_208;
      pTStack_304 = &TStack_30;
      pTStack_308 = (TypeDescriptor *)0x96f8e2;
      pTStack_2fc = (TypeDescriptor *)uStack_34;
      puVar8 = (undefined4 *)FUN_00989ff0();
      uStack_80 = *puVar8;
      uStack_7c = puVar8[1];
      pTStack_2fc = (TypeDescriptor *)0x96f8f7;
      FUN_0097eeb0();
      pTStack_2fc = (TypeDescriptor *)&uStack_80;
      pTStack_300 = &TStack_30;
      pTStack_304 = (TypeDescriptor *)0x96f906;
      pTStack_2fc = (TypeDescriptor *)FUN_0097cf80();
      pTStack_300 = (TypeDescriptor *)0x96f90f;
      FUN_005587e0();
      pTStack_2fc = (TypeDescriptor *)0x96f917;
      FUN_00550b30();
      if (pTStack_50 == (TypeDescriptor *)0x0) goto LAB_009701a5;
    }
    pTStack_2fc = aTStack_70;
    pTStack_300 = (TypeDescriptor *)0x96f930;
    FUN_006acbd0();
    uStack_14._0_1_ = 3;
    if (pvVar7 == (void *)0x0) {
      if (cVar5 == -0x75) {
        pTVar9 = aTStack_70;
        if (0xf < uStack_5c) {
          pTVar9 = (TypeDescriptor *)aTStack_70[0].pVFTable;
        }
        pTStack_308 = (TypeDescriptor *)&pTStack_300;
        pTStack_304 = (TypeDescriptor *)0x0;
        pTStack_30c = (TypeDescriptor *)0x96f95a;
        FUN_0060dcd0();
        pTStack_304 = (TypeDescriptor *)0x3;
        pTStack_30c = (TypeDescriptor *)0x96f96b;
        pTStack_308 = pTVar9;
        FUN_0096b650();
        pTStack_2fc = (TypeDescriptor *)&uStack_c8;
        uStack_14._0_1_ = 4;
        pTStack_300 = (TypeDescriptor *)0x96f97d;
        FUN_00971830();
        pTStack_2fc = (TypeDescriptor *)0x96f988;
        FUN_0096d050();
      }
      else {
        pTStack_308 = (TypeDescriptor *)auStack_198;
        pTStack_2fc = (TypeDescriptor *)0x7c;
        pTVar9 = aTStack_70;
        if (0xf < uStack_5c) {
          pTVar9 = (TypeDescriptor *)aTStack_70[0].pVFTable;
        }
        pTStack_300 = (TypeDescriptor *)0x1;
        pTStack_304 = param_4;
        pTStack_30c = (TypeDescriptor *)0x96f9d6;
        pTStack_300 = (TypeDescriptor *)FUN_006b1620();
        uStack_14._0_1_ = 5;
        if ((void *)0xf < pTStack_300[2].spare) {
          pTStack_300 = (TypeDescriptor *)pTStack_300->pVFTable;
        }
        pTStack_304 = (TypeDescriptor *)0x19363dc;
        pTStack_308 = (TypeDescriptor *)&DAT_00000004;
        pTStack_30c = (TypeDescriptor *)0x96f9f3;
        pTStack_2fc = pTVar9;
        FUN_0086f2f0();
        pTStack_2fc = (TypeDescriptor *)0x96fa01;
        FUN_005507b0();
      }
    }
    else if (*(TypeDescriptor **)((int)pvVar7 + 0x34) == param_1) {
      pTStack_2fc = &TStack_3c;
      pTStack_300 = &TStack_30;
      pTStack_304 = (TypeDescriptor *)0x96fa1c;
      FUN_00966d50();
      pTStack_304 = (TypeDescriptor *)0x1;
      uStack_14._0_1_ = 6;
      pTStack_30c = (TypeDescriptor *)0x96fa28;
      pTStack_308 = param_1;
      cStack_21 = FUN_00971ce0();
      uVar10 = param_5 & 0xff;
      if (uVar10 == 0x87) {
        pTStack_304 = &TStack_30;
        pTVar9 = aTStack_70;
        if (0xf < uStack_5c) {
          pTVar9 = (TypeDescriptor *)aTStack_70[0].pVFTable;
        }
        pTStack_308 = (TypeDescriptor *)0x96fb94;
        FUN_00557fc0();
        pTStack_304 = (TypeDescriptor *)0x0;
        pTStack_30c = (TypeDescriptor *)0x96fba2;
        pTStack_308 = pTVar9;
        FUN_0096b650();
        uStack_14 = CONCAT31(uStack_14._1_3_,7);
LAB_0096fba6:
        if (cStack_21 == '\0') {
          pTStack_304 = (TypeDescriptor *)&param_1[0x1e].spare;
          pTStack_308 = (TypeDescriptor *)0x96fbbd;
          FUN_00557fc0();
          pTStack_304 = (TypeDescriptor *)0x96fbc8;
          cVar5 = FUN_009832d0();
          if (cVar5 != '\0') goto LAB_0096fbcc;
        }
        else {
LAB_0096fbcc:
          pTStack_2fc = (TypeDescriptor *)&uStack_c8;
          pTStack_300 = (TypeDescriptor *)0x96fbda;
          FUN_00971830();
        }
        uStack_14._0_1_ = 6;
        pTStack_2fc = (TypeDescriptor *)0x96fbe9;
        FUN_0096d050();
LAB_0096fbe9:
        if ((cStack_21 != '\0') && (iStack_60 != 0)) {
          cStack_22 = '\0';
          if (param_1 != (TypeDescriptor *)0x0) {
            pTStack_28 = (TypeDescriptor *)param_1[6].spare;
            pTVar9 = param_1;
            if ((pTStack_28 != (TypeDescriptor *)0x0) &&
               (pTVar9 = pTStack_28, pTStack_28[6].spare != (void *)0x0)) {
              pTStack_2fc = (TypeDescriptor *)0x96fc1b;
              pTVar9 = (TypeDescriptor *)FUN_005c8ac0();
            }
            pTStack_28 = pTVar9;
            if (pTStack_28 != (TypeDescriptor *)0x0) {
              pvVar7 = pTStack_28[1].spare;
              pTStack_2fc = (TypeDescriptor *)0x96fc31;
              iVar6 = FUN_008a8c30();
              if ((uint)*(ushort *)((int)pvVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                  (uint)*(ushort *)(iVar6 + 0x1da)) {
                pTStack_2fc = (TypeDescriptor *)0x96fc54;
                iVar6 = FUN_005f5170();
                if (iVar6 != 0) {
                  pTStack_2fc = (TypeDescriptor *)0x96fc5f;
                  cStack_22 = FUN_00585a40();
                }
              }
            }
          }
          pvVar7 = param_4->pVFTable;
          pvVar1 = param_4->spare;
          pvVar2 = param_4[1].pVFTable;
          pTVar9 = (TypeDescriptor *)param_4[1].spare;
          pvStack_190 = param_4[2].pVFTable;
          pvStack_18c = param_4[2].spare;
          ppuStack_188 = (undefined **)param_4[3].pVFTable;
          pvStack_184 = param_4[3].spare;
          pTStack_2fc = (TypeDescriptor *)(uint)DAT_01ee2fe9;
          pTStack_28 = (TypeDescriptor *)&pTStack_304;
          pTStack_304 = (TypeDescriptor *)0x0;
          pTStack_300 = (TypeDescriptor *)0x0;
          puStack_54 = (undefined *)&pTStack_30c;
          TStack_314.spare = &TStack_3c;
          TStack_314.pVFTable = (void *)0x96fcae;
          FUN_00557fc0();
          TStack_44.spare = &TStack_314;
          pTStack_328 = &TStack_314;
          uStack_14._0_1_ = 0xd;
          pvStack_318 = (void *)param_5;
          pTStack_31c = pTStack_50;
          pTStack_320 = (TypeDescriptor *)TStack_3c.pVFTable;
          ppuStack_324 = (undefined4 **)uStack_34;
          pvStack_32c = (void *)0x96fccc;
          FUN_00971d50();
          uStack_14._0_1_ = 0xe;
          ppuStack_324 = (undefined4 **)pvStack_190;
          pTStack_320 = (TypeDescriptor *)pvStack_18c;
          pTStack_31c = (TypeDescriptor *)ppuStack_188;
          pvStack_318 = pvStack_184;
          pvStack_334 = pvVar7;
          pvStack_330 = pvVar1;
          pvStack_32c = pvVar2;
          pTStack_328 = pTVar9;
          FUN_0060dcd0(auStack_33c,param_1);
          uStack_14._0_1_ = 6;
          FUN_00965570(&uStack_130,FUN_0098c4d0,0);
          uStack_1e0 = uStack_130;
          uStack_1dc = uStack_12c;
          pTStack_2fc = (TypeDescriptor *)auStack_128;
          pTStack_300 = (TypeDescriptor *)0x96fd37;
          FUN_00968e30();
          uStack_250 = uStack_1e0;
          uStack_24c = uStack_1dc;
          pTStack_2fc = (TypeDescriptor *)auStack_1d8;
          ppuStack_e8 = (undefined **)0x0;
          pTStack_300 = (TypeDescriptor *)0x96fd6b;
          FUN_00968e30();
          uStack_298 = uStack_250;
          uStack_294 = uStack_24c;
          pTStack_2fc = (TypeDescriptor *)auStack_248;
          pTStack_300 = (TypeDescriptor *)0x96fd95;
          FUN_00968e30();
          uStack_c8 = uStack_298;
          uStack_c4 = uStack_294;
          pTStack_2fc = (TypeDescriptor *)auStack_290;
          pTStack_300 = (TypeDescriptor *)0x96fdbf;
          FUN_00968e30();
          pTStack_2fc = (TypeDescriptor *)&uStack_c8;
          pTStack_300 = (TypeDescriptor *)0x96fdcb;
          cVar5 = FUN_00585a40();
          uVar4 = uStack_c4;
          uVar3 = uStack_c8;
          if (cVar5 == '\0') {
            pTStack_2fc = (TypeDescriptor *)auStack_c0;
            pTStack_300 = (TypeDescriptor *)0x96fe00;
            FUN_00968e30();
            pTStack_2fc = (TypeDescriptor *)0x48;
            uStack_14._0_1_ = 0x14;
            pTStack_300 = (TypeDescriptor *)0x96fe0b;
            TStack_e0.pVFTable = (void *)FUN_01674e20();
            if ((undefined4 *)TStack_e0.pVFTable == (undefined4 *)0x0) {
              TStack_e0.pVFTable = (undefined4 *)0x0;
            }
            else {
              pTStack_2fc = (TypeDescriptor *)auStack_2d8;
              *(undefined4 *)TStack_e0.pVFTable = uVar3;
              *(undefined4 *)((int)TStack_e0.pVFTable + 4) = uVar4;
              pTStack_300 = (TypeDescriptor *)0x96fe34;
              FUN_00968e30();
            }
            pTStack_2fc = (TypeDescriptor *)0x96fe49;
            FUN_0096cc40();
            pTStack_2fc = (TypeDescriptor *)0x96fe54;
            FUN_0096cc40();
            cStack_21 = '\x01';
          }
          else {
            pTStack_2fc = (TypeDescriptor *)0x96fe65;
            FUN_0096cc40();
            cStack_21 = '\0';
          }
          pTStack_2fc = (TypeDescriptor *)0x96fe74;
          FUN_0096cc40();
          ppuStack_e8 = &PTR_FUN_01936bb4;
          if (cStack_21 == '\0') {
            ppuStack_e8 = (undefined **)0x0;
          }
          pTStack_2fc = (TypeDescriptor *)0x96fe92;
          FUN_0096cc40();
          pTStack_2fc = (TypeDescriptor *)0x96fe9d;
          FUN_0096cc40();
          pTStack_2fc = (TypeDescriptor *)0x96fea8;
          FUN_0096cc40();
          pTStack_308 = param_1 + 0xb;
          pTStack_304 = (TypeDescriptor *)param_1[0xd].pVFTable;
          uStack_14._0_1_ = 0x15;
          if ((void *)0xf < param_1[0xd].spare) {
            pTStack_308 = (TypeDescriptor *)pTStack_308->pVFTable;
          }
          pTStack_2fc = (TypeDescriptor *)0x0;
          pTStack_300 = (TypeDescriptor *)&DAT_018bc9b8;
          pTStack_30c = (TypeDescriptor *)0x96fec8;
          cVar5 = FUN_0055c360();
          if ((cVar5 == '\0') && (cStack_22 == '\0')) {
            pTStack_300 = (TypeDescriptor *)0x96fee2;
            pTStack_2fc = param_1;
            iVar6 = FUN_008f7870();
            if (iVar6 != 0) {
              pTStack_2fc = (TypeDescriptor *)0x1;
              TStack_44.spare = aTStack_180;
              pTStack_320 = aTStack_70;
              ppuStack_324 = (undefined4 **)0x96ff0e;
              FUN_0054ef60();
              if (TStack_30.spare != (void *)0x0) {
                LOCK();
                *(int *)((int)TStack_30.spare + 4) = *(int *)((int)TStack_30.spare + 4) + 1;
                UNLOCK();
              }
              pvStack_168 = TStack_30.pVFTable;
              pvStack_164 = TStack_30.spare;
              uStack_14._0_1_ = 0x19;
              ppuStack_160 = (undefined **)0x0;
              if (ppuStack_e8 != (undefined **)0x0) {
                ppuStack_160 = ppuStack_e8;
                if (((uint)ppuStack_e8 & 1) == 0) {
                  ppuStack_324 = &puStack_158;
                  pTStack_320 = (TypeDescriptor *)0x0;
                  pTStack_328 = &TStack_e0;
                  pvStack_32c = (void *)0x96ff95;
                  (**(code **)((uint)ppuStack_e8 & 0xfffffffe))();
                }
                else {
                  puStack_158 = (undefined4 *)TStack_e0.pVFTable;
                  pvStack_154 = TStack_e0.spare;
                  uStack_150 = uStack_d8;
                  uStack_14c = uStack_d4;
                  uStack_148 = uStack_d0;
                }
              }
              pTStack_320 = aTStack_180;
              uStack_14._0_1_ = 0x1a;
              ppuStack_324 = (undefined4 **)0x96ffae;
              FUN_00967590();
              pTStack_320 = (TypeDescriptor *)auStack_c0;
              uStack_14._0_1_ = 0x1b;
              pTStack_31c = (TypeDescriptor *)0x0;
              ppuStack_324 = (undefined4 **)0x96ffca;
              FUN_00967590();
              pTStack_320 = (TypeDescriptor *)auStack_2d8;
              uStack_14._0_1_ = 0x1c;
              ppuStack_324 = (undefined4 **)0x96ffe0;
              FUN_00967590();
              pTStack_320 = (TypeDescriptor *)auStack_290;
              uStack_14._0_1_ = 0x1d;
              ppuStack_324 = (undefined4 **)0x96fff6;
              FUN_00967590();
              pTStack_320 = (TypeDescriptor *)auStack_1d8;
              uStack_14._0_1_ = 0x1e;
              ppuStack_324 = (undefined4 **)0x970006;
              cVar5 = FUN_00585a40();
              if (cVar5 == '\0') {
                pTStack_320 = (TypeDescriptor *)auStack_1d8;
                ppuStack_324 = (undefined4 **)0x97001f;
                FUN_00967590();
                pTStack_320 = (TypeDescriptor *)0x40;
                uStack_14._0_1_ = 0x1f;
                ppuStack_324 = (undefined4 **)0x97002a;
                TStack_44.spare = (void *)FUN_01674e20();
                uStack_14._0_1_ = 0x20;
                if ((TypeDescriptor *)TStack_44.spare == (TypeDescriptor *)0x0) {
                  TStack_314.pVFTable = (void *)0x0;
                }
                else {
                  pTStack_320 = (TypeDescriptor *)auStack_248;
                  ppuStack_324 = (undefined4 **)0x970046;
                  TStack_314.pVFTable = (void *)FUN_00967590();
                }
                pTStack_320 = (TypeDescriptor *)0x970058;
                FUN_0096c080();
                pTStack_320 = (TypeDescriptor *)0x970063;
                FUN_0096c080();
                cStack_22 = '\x01';
              }
              else {
                pTStack_320 = (TypeDescriptor *)0x970074;
                FUN_0096c080();
                cStack_22 = '\0';
              }
              pTStack_320 = (TypeDescriptor *)0x970083;
              FUN_0096c080();
              pTStack_31c = (TypeDescriptor *)&PTR_FUN_01936ca0;
              if (cStack_22 == '\0') {
                pTStack_31c = (TypeDescriptor *)0x0;
              }
              pTStack_320 = (TypeDescriptor *)0x97009d;
              FUN_0096c080();
              pTStack_320 = (TypeDescriptor *)0x9700a8;
              FUN_0096c080();
              uStack_14._0_1_ = 0x15;
              pTStack_320 = (TypeDescriptor *)0x9700b7;
              FUN_0096c080();
              pTStack_320 = (TypeDescriptor *)0x9700be;
              FUN_0090ca30();
            }
          }
          else {
            uStack_124 = 0;
            uStack_140 = 0;
            uStack_120 = 0xf;
            uStack_134 = 0;
            uStack_10c = 0;
            uStack_108 = 0xf;
            uStack_11c = 0;
            uStack_f4 = 0;
            uStack_f0 = 0xf;
            uStack_104 = 0;
            pTStack_2fc = (TypeDescriptor *)0x0;
            pTStack_300 = (TypeDescriptor *)&DAT_018bc9b8;
            uStack_14._0_1_ = 0x16;
            uStack_138 = 0;
            pTStack_304 = (TypeDescriptor *)0x97013e;
            FUN_005542c0();
            pTStack_2fc = aTStack_70;
            pTStack_300 = (TypeDescriptor *)0x97014d;
            FUN_00551230();
            pTStack_2fc = aTStack_70;
            pTStack_300 = (TypeDescriptor *)0x97015c;
            FUN_00551230();
            if (ppuStack_e8 == (undefined **)0x0) {
              pTStack_2fc = (TypeDescriptor *)0x9701df;
              pTStack_2fc = (TypeDescriptor *)FUN_0054fda0();
              uStack_14 = CONCAT31(uStack_14._1_3_,0x17);
                    /* WARNING: Subroutine does not return */
              pTStack_300 = (TypeDescriptor *)&UNK_009701e9;
              FUN_0054e5e0();
            }
            pTStack_2fc = (TypeDescriptor *)&uStack_140;
            pTStack_300 = &TStack_e0;
            pTStack_304 = (TypeDescriptor *)0x97017c;
            (**(code **)(((uint)ppuStack_e8 & 0xfffffffe) + 4))();
            pTStack_2fc = (TypeDescriptor *)0x97018a;
            FUN_0096d5e0();
          }
          pTStack_2fc = (TypeDescriptor *)0x970195;
          FUN_00550990();
        }
      }
      else {
        if (uVar10 == 0x88) {
          pTStack_304 = &TStack_30;
          pTVar9 = aTStack_70;
          if (0xf < uStack_5c) {
            pTVar9 = (TypeDescriptor *)aTStack_70[0].pVFTable;
          }
          pTStack_308 = (TypeDescriptor *)0x96fb67;
          FUN_00557fc0();
          pTStack_304 = (TypeDescriptor *)0x1;
          pTStack_30c = (TypeDescriptor *)0x96fb75;
          pTStack_308 = pTVar9;
          FUN_0096b650();
          uStack_14 = CONCAT31(uStack_14._1_3_,8);
          goto LAB_0096fba6;
        }
        pTStack_2fc = (TypeDescriptor *)(uVar10 - 0x8c);
        if (pTStack_2fc != (TypeDescriptor *)0x0) goto LAB_0096fbe9;
        pTStack_300 = &RBX::Player::RTTI_Type_Descriptor;
        pTStack_304 = &RBX::Instance::RTTI_Type_Descriptor;
        pTStack_30c = pTStack_50;
        uStack_14._0_1_ = 10;
        TStack_314.spare = (TypeDescriptor *)0x96fa70;
        pTStack_308 = pTStack_2fc;
        TStack_44.pVFTable = pTStack_2fc;
        TStack_44.spare = pTStack_2fc;
        iStack_58 = FUN_0170d75d();
        if (iStack_58 == 0) {
          iStack_58 = 0;
          puStack_54 = (undefined *)0x0;
        }
        else {
          if (puStack_4c != (undefined *)0x0) {
            LOCK();
            *(int *)(puStack_4c + 4) = *(int *)(puStack_4c + 4) + 1;
            UNLOCK();
          }
          puStack_54 = puStack_4c;
        }
        pTStack_2fc = (TypeDescriptor *)&iStack_58;
        uStack_14._0_1_ = 9;
        pTStack_300 = (TypeDescriptor *)0x96faaa;
        FUN_005587e0();
        pTStack_2fc = (TypeDescriptor *)0x96fab2;
        FUN_00550b30();
        if ((TypeDescriptor *)TStack_44.pVFTable != (TypeDescriptor *)0x0) {
          pTStack_304 = &TStack_44;
          pTVar9 = aTStack_70;
          if (0xf < uStack_5c) {
            pTVar9 = (TypeDescriptor *)aTStack_70[0].pVFTable;
          }
          pTStack_308 = (TypeDescriptor *)0x96fade;
          FUN_00557fc0();
          pTStack_30c = &TStack_30;
          TStack_314.spare = (void *)0x96faec;
          FUN_00557fc0();
          pTStack_30c = (TypeDescriptor *)0x2;
          TStack_314.pVFTable = (void *)0x96fafa;
          TStack_314.spare = pTVar9;
          FUN_0096b520();
          uStack_14 = CONCAT31(uStack_14._1_3_,0xb);
          if (cStack_21 == '\0') {
            pTStack_304 = (TypeDescriptor *)&param_1[0x1e].spare;
            pTStack_308 = (TypeDescriptor *)0x96fb15;
            FUN_00557fc0();
            pTStack_304 = (TypeDescriptor *)0x96fb20;
            cVar5 = FUN_009832d0();
            if (cVar5 != '\0') goto LAB_0096fb24;
          }
          else {
LAB_0096fb24:
            pTStack_2fc = (TypeDescriptor *)&uStack_c8;
            pTStack_300 = (TypeDescriptor *)0x96fb32;
            FUN_00971830();
          }
          pTStack_2fc = (TypeDescriptor *)0x96fb3d;
          FUN_0096d050();
          uStack_14._0_1_ = 6;
          pTStack_2fc = (TypeDescriptor *)0x96fb49;
          FUN_00550b30();
          goto LAB_0096fbe9;
        }
        pTStack_2fc = (TypeDescriptor *)0x96fac0;
        FUN_00550b30();
      }
      pTStack_2fc = (TypeDescriptor *)0x97019d;
      FUN_00550b30();
    }
    pTStack_2fc = (TypeDescriptor *)0x9701a5;
    FUN_005507b0();
  }
  else {
    pTStack_300 = aTStack_208;
    pTStack_304 = &TStack_30;
    pTStack_308 = (TypeDescriptor *)0x96f880;
    puVar8 = (undefined4 *)FUN_00989ff0();
    uStack_78 = *puVar8;
    uStack_74 = puVar8[1];
    pTStack_2fc = (TypeDescriptor *)0x96f895;
    FUN_0097eeb0();
    pTStack_2fc = (TypeDescriptor *)&uStack_78;
    pTStack_300 = &TStack_30;
    pTStack_304 = (TypeDescriptor *)0x96f8a4;
    pTStack_2fc = (TypeDescriptor *)FUN_0097cf80();
    pTStack_300 = (TypeDescriptor *)0x96f8ad;
    FUN_005587e0();
    pTStack_2fc = (TypeDescriptor *)0x96f8b5;
    FUN_00550b30();
    if ((param_2 == (void *)0x0) || (TStack_3c.pVFTable == param_2)) goto LAB_0096f8cd;
  }
LAB_009701a5:
  pTStack_2fc = (TypeDescriptor *)0x9701ad;
  FUN_00550b30();
  pTStack_2fc = (TypeDescriptor *)0x9701b5;
  FUN_00550b30();
LAB_009701b5:
  pTStack_2fc = (TypeDescriptor *)0x9701c0;
  FUN_00613200();
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 17635 ; VA 0x009701f0 ; FUN_009701f0 */

undefined4 __thiscall FUN_009701f0(int param_1,int param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  char *pcVar8;
  uint uVar9;
  char acStack_1c8 [44];
  int iStack_19c;
  undefined **ppuStack_198;
  undefined auStack_194 [72];
  undefined4 uStack_14c;
  undefined **appuStack_148 [18];
  undefined auStack_100 [12];
  int iStack_f4;
  int iStack_ec;
  int iStack_e8;
  int iStack_e0;
  int iStack_d8;
  int iStack_d4;
  int iStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 ***pppuStack_a8;
  undefined4 **ppuStack_a4;
  undefined4 **ppuStack_a0;
  undefined4 **ppuStack_9c;
  undefined8 uStack_98;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ced50;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_006ab380(*(undefined4 *)(param_4 + 0x38),*(undefined4 *)(param_4 + 0x30),0);
  uStack_8 = 0;
  FUN_006ab660(1);
  FUN_0096b1b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_b8 = 0;
  if (param_2 != 0) {
    uStack_b8 = FUN_00928340();
    FUN_0054ef60(param_2 + 0x470);
    uStack_14 = 1;
    FUN_005507b0();
    iStack_90 = iStack_38;
    uStack_8c = uStack_34;
    uStack_88 = uStack_30;
    uStack_84 = uStack_2c;
    FUN_00927ca0();
    FUN_005f7b20(0,acStack_1c8,0x30,0x7c);
    pcVar8 = acStack_1c8;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(acStack_1c8,(int)pcVar8 - (int)(acStack_1c8 + 1));
  }
  FUN_006ab860(&uStack_40,auStack_100);
  uStack_b0 = uStack_40;
  uStack_ac = uStack_3c;
  ppppuVar4 = (undefined4 ****)FUN_006acbd0(&iStack_38);
  if (&pppuStack_a8 != ppppuVar4) {
    FUN_005507b0();
    pppuStack_a8 = *ppppuVar4;
    ppuStack_a4 = ppppuVar4[1];
    ppuStack_a0 = ppppuVar4[2];
    ppuStack_9c = ppppuVar4[3];
    uStack_98 = *(undefined8 *)(ppppuVar4 + 4);
    ppppuVar4[4] = (undefined4 ***)0x0;
    ppppuVar4[5] = (undefined4 ***)0xf;
    *(undefined *)ppppuVar4 = 0;
  }
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    iVar6 = iStack_38;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iStack_38 + -4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (iStack_38 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  if ((DAT_01d646c8 != '\0') && (iStack_e8 != iStack_e0)) {
    puVar5 = (undefined4 *)FUN_006acbd0(&iStack_38);
    if (&uStack_58 != puVar5) {
      FUN_005507b0();
      uStack_58 = *puVar5;
      uStack_54 = puVar5[1];
      uStack_50 = puVar5[2];
      uStack_4c = puVar5[3];
      uStack_48 = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    FUN_005507b0();
  }
  iVar6 = FUN_008f7870(param_1);
  uVar9 = uStack_14;
  if (iVar6 != 0) {
    piVar3 = *(int **)(iVar6 + 0x43c);
    iStack_d4 = piVar3[1] - (int)piVar3;
    iStack_d8 = *piVar3 - (int)piVar3;
    FUN_0054ef60(iVar6 + 0x288);
    uVar9 = uStack_14 | 2;
    FUN_005507b0();
    iStack_d0 = iStack_38;
    uStack_cc = uStack_34;
    uStack_c8 = uStack_30;
    uStack_c4 = uStack_2c;
  }
  ppuStack_198 = &PTR_018be314;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_1c = (int *)(uVar9 | 4);
  appuStack_148[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_14c = 0x48;
  FUN_00554f20(auStack_194,0);
  uStack_8 = 4;
  *(undefined ***)(auStack_194 + (int)(ppuStack_198[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_19c + (int)ppuStack_198[1]) = ppuStack_198[1] + -0x50;
  FUN_005658e0(2);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00558890(&ppuStack_198,"AbuserID:");
  uVar7 = FUN_00872bd0(uStack_b0,uStack_ac,&DAT_018d1b9c);
  uVar7 = FUN_00558890(uVar7);
  ppppuVar4 = &pppuStack_a8;
  if (0xf < uStack_98._4_4_) {
    ppppuVar4 = (undefined4 ****)pppuStack_a8;
  }
  FUN_0055b3b0(uVar7,ppppuVar4,(undefined4)uStack_98);
  ppppuVar4 = (undefined4 ****)FUN_0058c400(&iStack_38);
  if (&pppuStack_a8 != ppppuVar4) {
    FUN_005507b0();
    pppuStack_a8 = *ppppuVar4;
    ppuStack_a4 = ppppuVar4[1];
    ppuStack_a0 = ppppuVar4[2];
    ppuStack_9c = ppppuVar4[3];
    uStack_98 = *(undefined8 *)(ppppuVar4 + 4);
    ppppuVar4[4] = (undefined4 ***)0x0;
    ppppuVar4[5] = (undefined4 ***)0xf;
    *(undefined *)ppppuVar4 = 0;
  }
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    iVar6 = iStack_38;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iStack_38 + -4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (iStack_38 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *(undefined ***)(auStack_194 + (int)(ppuStack_198[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_19c + (int)ppuStack_198[1]) = ppuStack_198[1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(auStack_194 + (int)(ppuStack_198[1] + -4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)&iStack_19c + (int)ppuStack_198[1]) = ppuStack_198[1] + -8;
  uStack_8._0_1_ = 6;
  appuStack_148[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_148);
  uStack_8._0_1_ = 1;
  FUN_0060dcd0(&uStack_20,param_2);
  piVar3 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (*(int *)(param_1 + 0xa8) != 0) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    FUN_00971600(&iStack_d8,uStack_20,piStack_1c,iStack_18 + 0xb0);
  }
  FUN_0096b0f0(&iStack_d8);
  FUN_0096e960();
  FUN_0098b460(&iStack_d8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0096ce60();
  if (iStack_f4 != 0) {
    uVar9 = iStack_ec - iStack_f4;
    iVar6 = iStack_f4;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iStack_f4 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iStack_f4 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17636 ; VA 0x00970740 ; FUN_00970740 */

void FUN_00970740(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x38);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 17637 ; VA 0x00970770 ; FUN_00970770 */

void FUN_00970770(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x4c);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 17638 ; VA 0x009707a0 ; FUN_009707a0 */

void __fastcall FUN_009707a0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x20);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 17639 ; VA 0x009707c0 ; FUN_009707c0 */

void __thiscall FUN_009707c0(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0096ca80();
        iVar2 = iVar2 + 0x48;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x48) * 0x48;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x48;
  param_1[2] = param_2 + param_4 * 0x48;
  return;
}



/* FUNCTION 17640 ; VA 0x00970850 ; FUN_00970850 */

void __thiscall FUN_00970850(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0096d6c0();
        iVar2 = iVar2 + 0x58;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x58) * 0x58;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x58 + param_2;
  param_1[2] = param_4 * 0x58 + param_2;
  return;
}



/* FUNCTION 17641 ; VA 0x009708e0 ; FUN_009708e0 */

void __fastcall FUN_009708e0(int param_1)

{
  FUN_00962110(param_1 + 8);
  return;
}



/* FUNCTION 17642 ; VA 0x009708f0 ; FUN_009708f0 */

void FUN_009708f0(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_685de64f4ae5e780cfdf8775129e7a85>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  return;
}



/* FUNCTION 17643 ; VA 0x00970900 ; FUN_00970900 */

void __thiscall FUN_00970900(undefined4 param_1,char param_2)

{
  FUN_008c3670();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x30);
  }
  return;
}



/* FUNCTION 17644 ; VA 0x00970930 ; FUN_00970930 */

void __fastcall FUN_00970930(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 != 0) {
    LOCK();
    iVar1 = *(int *)(iVar2 + 0x18);
    *(int *)(iVar2 + 0x18) = 0;
    UNLOCK();
    if (iVar1 != 0) {
      CloseHandle(iVar1);
    }
    FUN_0096c5f0();
    FUN_01674ea0(iVar2,0x1c);
  }
  return;
}



/* FUNCTION 17645 ; VA 0x00970960 ; FUN_00970960 */

void __fastcall FUN_00970960(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0096f290(1);
  }
  return;
}



/* FUNCTION 17646 ; VA 0x00970970 ; FUN_00970970 */

void __fastcall FUN_00970970(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0096f330(1);
  }
  return;
}



/* FUNCTION 17647 ; VA 0x00970980 ; FUN_00970980 */

void FUN_00970980(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_0096ca80();
      param_1 = param_1 + 0x48;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 17648 ; VA 0x009709b0 ; FUN_009709b0 */

void __thiscall FUN_009709b0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00961b20(param_2,param_3,param_1);
  return;
}



/* FUNCTION 17649 ; VA 0x009709d0 ; FUN_009709d0 */

void FUN_009709d0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_0096d6c0();
      param_1 = param_1 + 0x58;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 17650 ; VA 0x00970a00 ; FUN_00970a00 */

void FUN_00970a00(int param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x18);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00576720(*(undefined4 *)(iVar1 + 4));
  *(int *)(*(int *)(param_1 + 0x18) + 4) = iVar1;
  **(int **)(param_1 + 0x18) = iVar1;
  *(int *)(*(int *)(param_1 + 0x18) + 8) = iVar1;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x18),0x28);
  FUN_01674ea0(param_1,0x20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17651 ; VA 0x00970a80 ; FUN_00970a80 */

void __fastcall FUN_00970a80(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x2c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0096e490(*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c));
  return;
}



/* FUNCTION 17652 ; VA 0x00970ac0 ; FUN_00970ac0 */

void FUN_00970ac0(undefined4 *param_1,undefined4 param_2)

{
  FUN_0096dc00(*param_1,param_2);
  return;
}



/* FUNCTION 17653 ; VA 0x00970ae0 ; FUN_00970ae0 */

undefined4 __thiscall FUN_00970ae0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  cVar2 = *(char *)((int)param_2 + 0xd);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, cVar2 == '\0') {
    FUN_00970ae0(param_2[2]);
    piVar3 = (int *)*param_2;
    piVar1 = param_2 + 6;
    iVar4 = *piVar1;
    uStack_8 = 0;
    FUN_00576720(*(undefined4 *)(iVar4 + 4));
    uStack_8 = 0xffffffff;
    *(int *)(*piVar1 + 4) = iVar4;
    *(int *)*piVar1 = iVar4;
    *(int *)(*piVar1 + 8) = iVar4;
    param_2[7] = 0;
    FUN_01674ea0(*piVar1,0x28);
    FUN_01674ea0(param_2,0x20);
    ppvVar5 = (void **)ExceptionList;
    param_2 = piVar3;
    cVar2 = *(char *)((int)piVar3 + 0xd);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17654 ; VA 0x00970b90 ; FUN_00970b90 */

void FUN_00970b90(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x20);
  return;
}



/* FUNCTION 17655 ; VA 0x00970bb0 ; FUN_00970bb0 */

void FUN_00970bb0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x28);
  return;
}



/* FUNCTION 17656 ; VA 0x00970c10 ; FUN_00970c10 */

void FUN_00970c10(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 17657 ; VA 0x00970c70 ; FUN_00970c70 */

void FUN_00970c70(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  FUN_01674ea0(param_1,0x40);
  return;
}



/* FUNCTION 17658 ; VA 0x00970cd0 ; FUN_00970cd0 */

void FUN_00970cd0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x2c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x18);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 17659 ; VA 0x00970d30 ; FUN_00970d30 */

void __thiscall FUN_00970d30(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if ((int)&DAT_01af286b - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_00970f0c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00970d94;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00970d94:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00970f0c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_00970f0c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 17660 ; VA 0x00970f20 ; FUN_00970f20 */

undefined4 * __thiscall FUN_00970f20(int param_1,undefined4 *param_2)

{
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_1993c8f80a19440b3c1114da67410a4c>,void>::vftable
  ;
  param_2[2] = 0;
  FUN_005880d0(param_1 + 8);
  param_2[10] = 0;
  param_2[0xb] = 0;
  param_2[10] = *(undefined4 *)(param_1 + 0x28);
  param_2[0xb] = *(undefined4 *)(param_1 + 0x2c);
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  return param_2;
}



/* FUNCTION 17661 ; VA 0x00970f80 ; FUN_00970f80 */

void __thiscall FUN_00970f80(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ced60;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_008ee5b0(param_2);
  uStack_8 = 0;
  FUN_00971200(*param_1,param_1[1],uVar3);
  FUN_009707c0(uVar3,(iVar1 - iVar2) / 0x48,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17662 ; VA 0x00970ffc ; Catch_All@00970ffc */

void Catch_All_00970ffc(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_008f20b0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17663 ; VA 0x00971020 ; FUN_00971020 */

void __thiscall FUN_00971020(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ced70;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[1];
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_006181a0(param_2);
  uStack_8 = 0;
  FUN_00971300(*param_1,param_1[1],uVar3);
  FUN_00970850(uVar3,(iVar1 - iVar2) / 0x58,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17664 ; VA 0x0097109c ; Catch_All@0097109c */

void Catch_All_0097109c(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + 8);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0061a4a0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17665 ; VA 0x009710c0 ; FUN_009710c0 */

TypeDescriptor * FUN_009710c0(void)

{
  return &<lambda_1993c8f80a19440b3c1114da67410a4c>::RTTI_Type_Descriptor;
}



/* FUNCTION 17666 ; VA 0x009710d0 ; FUN_009710d0 */

TypeDescriptor * FUN_009710d0(void)

{
  return &<lambda_685de64f4ae5e780cfdf8775129e7a85>::RTTI_Type_Descriptor;
}



/* FUNCTION 17667 ; VA 0x009710e0 ; thunk_FUN_00973910 */

void __fastcall thunk_FUN_00973910(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_00651cc0();
      FUN_01674ea0(piVar2,0x40);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 17668 ; VA 0x009710f0 ; FUN_009710f0 */

undefined4 * FUN_009710f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ced93;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      *param_3 = *param_1;
      param_3[1] = param_1[1];
      param_3[2] = 0;
      FUN_005880d0(param_1 + 2);
      uStack_8 = 1;
      param_3[10] = 0;
      FUN_005880d0(param_1 + 10);
      param_3 = param_3 + 0x12;
      param_1 = param_1 + 0x12;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 17669 ; VA 0x00971190 ; FUN_00971190 */

int __thiscall FUN_00971190(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ceda8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_00965bb0(param_1,param_4,param_2);
      param_4 = param_4 + 0x58;
      param_2 = param_2 + 0x58;
    } while (param_2 != param_3);
  }
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 17670 ; VA 0x00971200 ; FUN_00971200 */

void FUN_00971200(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cedd3;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xc;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = puVar6[-0xc];
      param_3[1] = puVar6[-0xb];
      param_3[2] = 0;
      uVar2 = puVar6[-10];
      if (uVar2 != 0) {
        param_3[2] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar6 + -8,param_3 + 4,0);
        }
        else {
          uVar3 = puVar6[-7];
          uVar4 = puVar6[-6];
          uVar5 = puVar6[-5];
          param_3[4] = puVar6[-8];
          param_3[5] = uVar3;
          param_3[6] = uVar4;
          param_3[7] = uVar5;
          uVar3 = puVar6[-3];
          param_3[8] = puVar6[-4];
          param_3[9] = uVar3;
        }
      }
      param_3[10] = 0;
      uVar2 = puVar6[-2];
      iStack_8._0_1_ = 1;
      if (uVar2 != 0) {
        param_3[10] = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar6,param_3 + 0xc,0);
        }
        else {
          uVar3 = puVar6[1];
          uVar4 = puVar6[2];
          uVar5 = puVar6[3];
          param_3[0xc] = *puVar6;
          param_3[0xd] = uVar3;
          param_3[0xe] = uVar4;
          param_3[0xf] = uVar5;
          uVar3 = puVar6[5];
          param_3[0x10] = puVar6[4];
          param_3[0x11] = uVar3;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_3 = param_3 + 0x12;
      puVar1 = puVar6 + 6;
      puVar6 = puVar6 + 0x12;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17671 ; VA 0x00971300 ; FUN_00971300 */

void FUN_00971300(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cedfb;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar6 = param_1 + 0x10;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_0054ef60(puVar6 + -0x10);
      *(undefined4 *)(param_3 + 0x18) = 0;
      uVar2 = puVar6[-10];
      uStack_8 = 1;
      if (uVar2 != 0) {
        *(uint *)(param_3 + 0x18) = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar6 + -8,param_3 + 0x20,0);
        }
        else {
          uVar3 = puVar6[-7];
          uVar4 = puVar6[-6];
          uVar5 = puVar6[-5];
          *(undefined4 *)(param_3 + 0x20) = puVar6[-8];
          *(undefined4 *)(param_3 + 0x24) = uVar3;
          *(undefined4 *)(param_3 + 0x28) = uVar4;
          *(undefined4 *)(param_3 + 0x2c) = uVar5;
          uVar3 = puVar6[-3];
          *(undefined4 *)(param_3 + 0x30) = puVar6[-4];
          *(undefined4 *)(param_3 + 0x34) = uVar3;
        }
      }
      *(undefined4 *)(param_3 + 0x38) = 0;
      uVar2 = puVar6[-2];
      uStack_8 = 2;
      if (uVar2 != 0) {
        *(uint *)(param_3 + 0x38) = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar6,param_3 + 0x40,0);
        }
        else {
          uVar3 = puVar6[1];
          uVar4 = puVar6[2];
          uVar5 = puVar6[3];
          *(undefined4 *)(param_3 + 0x40) = *puVar6;
          *(undefined4 *)(param_3 + 0x44) = uVar3;
          *(undefined4 *)(param_3 + 0x48) = uVar4;
          *(undefined4 *)(param_3 + 0x4c) = uVar5;
          uVar3 = puVar6[5];
          *(undefined4 *)(param_3 + 0x50) = puVar6[4];
          *(undefined4 *)(param_3 + 0x54) = uVar3;
        }
      }
      param_3 = param_3 + 0x58;
      puVar1 = puVar6 + 6;
      puVar6 = puVar6 + 0x16;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17672 ; VA 0x00971400 ; FUN_00971400 */

void __thiscall FUN_00971400(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  FUN_00651cc0();
  FUN_01674ea0(param_2,0x40);
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  return;
}



/* FUNCTION 17673 ; VA 0x00971440 ; FUN_00971440 */

void __thiscall FUN_00971440(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  return;
}



/* FUNCTION 17674 ; VA 0x00971460 ; FUN_00971460 */

void __thiscall FUN_00971460(int param_1,int param_2)

{
  double dVar1;
  short sVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dStack_1c;
  double dStack_14;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(char *)(param_1 + 0x210) == '\0') {
    FUN_016827a0(&uStack_c);
    dStack_1c = (double)CONCAT44(uStack_8,uStack_c) - *(double *)(param_1 + 0x208);
    *(undefined4 *)(param_1 + 0x208) = uStack_c;
    *(undefined4 *)(param_1 + 0x20c) = uStack_8;
    dStack_14 = dStack_1c;
    sVar2 = FUN_017265ed(&dStack_1c);
    if (sVar2 < 1) {
      dVar1 = *(double *)(param_1 + 0x218);
      dVar3 = DAT_018c0d60 - dVar1;
      dVar4 = dStack_14;
      if (*(char *)(param_1 + 0x238) == '\0') {
        dVar4 = *(double *)(param_1 + 0x228) * dVar3 + dVar1 * dStack_14;
      }
      *(double *)(param_1 + 0x220) = dStack_14;
      *(undefined *)(param_1 + 0x238) = 0;
      *(double *)(param_1 + 0x228) = dVar4;
      *(double *)(param_1 + 0x230) =
           (dStack_14 - dVar4) * (dStack_14 - dVar4) * dVar1 + *(double *)(param_1 + 0x230) * dVar3;
    }
  }
  else {
    FUN_016827a0(&uStack_c);
    *(undefined4 *)(param_1 + 0x208) = uStack_c;
    *(undefined4 *)(param_1 + 0x20c) = uStack_8;
    *(undefined *)(param_1 + 0x210) = 0;
  }
  dStack_1c = (double)param_2;
  sVar2 = FUN_017265ed(&dStack_1c);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x248);
    dVar5 = DAT_018c0d60 - dVar1;
    dVar3 = (double)param_2;
    dVar4 = dVar3;
    if (*(char *)(param_1 + 0x268) == '\0') {
      dVar4 = *(double *)(param_1 + 600) * dVar5 + dVar3 * dVar1;
    }
    *(int *)(param_1 + 0x250) = param_2;
    *(double *)(param_1 + 600) = dVar4;
    *(undefined *)(param_1 + 0x268) = 0;
    *(double *)(param_1 + 0x260) =
         (dVar3 - dVar4) * (dVar3 - dVar4) * dVar1 + *(double *)(param_1 + 0x260) * dVar5;
  }
  return;
}



/* FUNCTION 17675 ; VA 0x00971600 ; FUN_00971600 */

int FUN_00971600(undefined4 param_1,undefined4 param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  code *apcStack_34 [2];
  undefined4 uStack_2c;
  int *piStack_28;
  uint *puStack_1c;
  char cStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uVar5 = DAT_01ee2fe9;
  puStack_c = &LAB_017cee30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar3 = (undefined4 *)*param_4;
  puVar4 = (undefined4 *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00964d10(apcStack_34,FUN_009719e0,param_1,param_2,param_3,uVar5);
  piVar1 = piStack_28;
  for (; puVar4 != puVar3; puVar4 = (undefined4 *)*puVar4) {
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    uStack_8._1_3_ = (uint3)(uStack_8 >> 8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    piStack_28 = piVar1;
    (*apcStack_34[0])(uStack_2c,piVar1,puVar4 + 2);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar1 = piStack_28;
  }
  uStack_2c = 0;
  piStack_28 = (int *)0x0;
  uStack_8 = uStack_8 & 0xffffff00;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar7 = piVar1[1] + -1;
    piVar1[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar7 = piVar1[2] + -1;
      piVar1[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  cStack_18 = '\0';
  puStack_1c = (uint *)(*piStack_14 + 0x14);
  FUN_00587410();
  iVar7 = *piStack_14;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar8 = *(uint *)(iVar7 + 8);
  if (uVar8 <= *(int *)(iVar7 + 0x10) + 1U) {
    FUN_00970d30(1);
    uVar8 = *(uint *)(iVar7 + 8);
  }
  uVar8 = uVar8 - 1 & *(uint *)(iVar7 + 0xc);
  *(uint *)(iVar7 + 0xc) = uVar8;
  iVar2 = (*(int *)(iVar7 + 8) - 1U & *(int *)(iVar7 + 0x10) + uVar8) * 4;
  if (*(int *)(*(int *)(iVar7 + 4) + iVar2) == 0) {
    uVar6 = FUN_01674e20(0x98);
    *(undefined4 *)(iVar2 + *(int *)(iVar7 + 4)) = uVar6;
  }
  FUN_0096b0f0(param_1);
  *(int *)(iVar7 + 0x10) = *(int *)(iVar7 + 0x10) + 1;
  uStack_8._0_1_ = 4;
  if (cStack_18 != '\0') {
    LOCK();
    uVar8 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar8 & 0x40000000) == 0) && (-0x80000000 < (int)uVar8)) {
      LOCK();
      uVar8 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar8 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  uStack_8 = (uint)uStack_8._1_3_ << 8;
  iVar7 = FUN_0151a5b0();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17676 ; VA 0x00971830 ; FUN_00971830 */

void __thiscall FUN_00971830(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  char cVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017970b0;
  pvStack_10 = ExceptionList;
  iVar8 = **(int **)(param_1 + 0xb0);
  puVar3 = *(undefined4 **)(iVar8 + 4);
  ExceptionList = &pvStack_10;
  uVar6 = FUN_00961860(iVar8,puVar3,param_2);
  if (*(int *)(param_1 + 0xb4) == 0x35e50d6) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + 1;
  *(undefined4 *)(iVar8 + 4) = uVar6;
  *puVar3 = uVar6;
  while( true ) {
    uVar4 = *(uint *)(param_1 + 0xb4);
    iVar8 = DAT_01ea8528;
    if (DAT_01ea8528 == 0) {
      piVar7 = (int *)FUN_00910d90();
      cStack_14 = '\0';
      iVar8 = *piVar7;
      puStack_18 = (uint *)(iVar8 + 0x94);
      FUN_00587410();
      uStack_8 = 0;
      if (DAT_01ea8528 == 0) {
        FUN_0055e190(auStack_20);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_008a65e0(iVar8,0);
        piVar7 = piStack_1c;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar8 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar7 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
      }
      iVar8 = DAT_01ea8528;
      uStack_8 = 2;
      if (cStack_14 != '\0') {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 + 0x80000000;
        UNLOCK();
        if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
          LOCK();
          uVar2 = *puStack_18;
          *puStack_18 = *puStack_18 | 0x40000000;
          UNLOCK();
          if ((uVar2 >> 0x1e & 1) == 0) {
            uVar6 = FUN_00554e40();
            SetEvent(uVar6);
          }
        }
      }
      uStack_8 = 0xffffffff;
    }
    if (uVar4 <= *(uint *)(iVar8 + 0x58)) break;
    piVar7 = *(int **)(*(int *)(param_1 + 0xb0) + 4);
    *(int *)piVar7[1] = *piVar7;
    *(int *)(*piVar7 + 4) = piVar7[1];
    *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + -1;
    FUN_0096d050();
    FUN_01674ea0(piVar7,0x4c);
  }
  if ((*(int *)(param_1 + 0xf4) != 0) && (cVar5 = FUN_009281e0(), cVar5 != '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_005e6780(param_2);
  FUN_00989e30(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17677 ; VA 0x009719e0 ; FUN_009719e0 */

int __thiscall FUN_009719e0(int param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined8 uStack_50;
  undefined auStack_48 [48];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cee58;
  pvStack_10 = ExceptionList;
  uVar3 = *(uint *)(param_1 + 0x7c);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_0058bf10();
  if (uVar3 < *(uint *)(iVar5 + 0x5c)) {
    if (param_2 != 0) {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      iVar5 = FUN_009832d0(param_2,param_3);
      if ((char)iVar5 == '\0') goto LAB_00971ac8;
    }
    if (*(int *)(param_4 + 0x34) == 0) {
      uStack_18 = 0;
      uStack_50 = 0;
    }
    else {
      uStack_50 = FUN_00928340();
    }
    FUN_00980350(auStack_48);
    uStack_8._0_1_ = 1;
    FUN_0054ef60(param_4);
    iVar5 = *(int *)(param_1 + 0x78);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    puVar4 = *(undefined4 **)(iVar5 + 4);
    uVar6 = FUN_00961680(iVar5,puVar4,&uStack_50);
    if (*(int *)(param_1 + 0x7c) == 0x3fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 0x7c) = *(int *)(param_1 + 0x7c) + 1;
    *(undefined4 *)(iVar5 + 4) = uVar6;
    *puVar4 = uVar6;
    iVar5 = FUN_00651cc0();
  }
LAB_00971ac8:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17678 ; VA 0x00971b10 ; FUN_00971b10 */

int FUN_00971b10(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cee90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puVar4 = &param_3;
  if (0xf < in_stack_00000020) {
    puVar4 = param_3;
  }
  uStack_11 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_0055c2d0(puVar4,in_stack_0000001c,&DAT_018ceea4,3);
  uStack_11 = iVar5 == 0;
  FUN_00965c50(&piStack_1c);
  uStack_8._0_1_ = 2;
  FUN_00db5830(&uStack_11);
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  pcVar3 = *(code **)(*piStack_1c + 0x38);
  FUN_005542c0("IsR15",5);
  uStack_8._0_1_ = 3;
  (*pcVar3)(auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar7 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  iVar5 = FUN_008a65e0(param_1,0);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar7 = in_stack_00000020 + 1;
    puVar4 = param_3;
    if (0xfff < uVar7) {
      puVar4 = (undefined4 *)param_3[-1];
      uVar7 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(puVar4,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17679 ; VA 0x00971ca0 ; FUN_00971ca0 */

bool FUN_00971ca0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00913630();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00971cd2;
  }
  param_1 = 0;
LAB_00971cd2:
  return param_1 != 0;
}



/* FUNCTION 17680 ; VA 0x00971ce0 ; FUN_00971ce0 */

bool FUN_00971ce0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  
  if (DAT_01d646e8 == '\0') {
    iVar2 = FUN_005c8880(param_1);
    if ((iVar2 != 0) && (cVar1 = FUN_0068a900(param_1,param_2), cVar1 == '\0')) {
      return true;
    }
  }
  else {
    iVar2 = FUN_008f78c0();
    if (iVar2 != 0) {
      if (((char)param_2 == '\0') && (*(int *)(iVar2 + 0x4a0) == 2)) {
        return true;
      }
      cVar1 = FUN_0068a900(iVar2 + 0xc,param_2);
      return cVar1 == '\0';
    }
  }
  return false;
}



/* FUNCTION 17681 ; VA 0x00971d50 ; FUN_00971d50 */

int * FUN_00971d50(int *param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017ceed8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x34);
  uStack_8 = 1;
  puStack_18 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2[1] = 1;
    puVar2[2] = 1;
    *puVar2 = std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
    FUN_006ab530();
  }
  *param_1 = (int)(puVar2 + 3);
  param_1[1] = (int)puVar2;
  uStack_8 = 0;
  uStack_14 = 3;
  FUN_006ad5e0(&param_5,1);
  iVar1 = param_3;
  if (param_3 != 0) {
    if (DAT_01eea9ac != '\0') {
      uVar3 = FUN_009c93d0(aiStack_30,4);
      uStack_8 = 2;
      FUN_01677760(DAT_01eea9ac,"senderGUID: %s",uVar3);
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_1c) {
        uVar5 = uStack_1c + 1;
        iVar4 = aiStack_30[0];
        if (0xfff < uVar5) {
          iVar4 = *(int *)(aiStack_30[0] + -4);
          uVar5 = uStack_1c + 0x24;
          if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
    }
    FUN_006ad220(*param_1,param_2,iVar1 + 0x18);
    param_5 = *(undefined4 *)(iVar1 + 0x1c);
    FUN_006a5c10(&param_5,&param_3,4);
    FUN_006ad5e0(&param_3,4);
  }
  iVar1 = param_4;
  if (param_4 != 0) {
    if (DAT_01eea9ac != '\0') {
      uVar3 = FUN_009c93d0(aiStack_30,4);
      uStack_8 = 3;
      FUN_01677760(DAT_01eea9ac,"senderGUID: %s",uVar3);
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_1c) {
        uVar5 = uStack_1c + 1;
        iVar4 = aiStack_30[0];
        if (0xfff < uVar5) {
          iVar4 = *(int *)(aiStack_30[0] + -4);
          uVar5 = uStack_1c + 0x24;
          if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
    }
    FUN_006ad220(*param_1,param_2,iVar1 + 0x18);
    param_5 = *(undefined4 *)(iVar1 + 0x1c);
    FUN_006a5c10(&param_5,&param_3,4);
    FUN_006ad5e0(&param_3,4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17682 ; VA 0x00971f60 ; FUN_00971f60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00971f60(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  float fVar3;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined8 uStack_14;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_44 = _DAT_018e3fb0;
  uStack_40 = _UNK_018e3fb4;
  uStack_3c = _UNK_018e3fb8;
  uStack_38 = _UNK_018e3fbc;
  uStack_34 = _DAT_018e3fb0;
  uStack_30 = _UNK_018e3fb4;
  uStack_2c = _UNK_018e3fb8;
  uStack_28 = _UNK_018e3fbc;
  uStack_24 = _DAT_018e3fb0;
  uStack_20 = _UNK_018e3fb4;
  uStack_1c = _UNK_018e3fb8;
  uStack_18 = _UNK_018e3fbc;
  if (*(int *)(param_1 + 0xf4) != 0) {
    iVar2 = FUN_00927e40(&uStack_44);
    if (iVar2 != 0) {
      uStack_14 = CONCAT44(uStack_1c,uStack_20);
      uStack_c = uStack_18;
      *(undefined *)(param_2 + 0x20) = 1;
      uStack_8 = *(undefined4 *)(*(int *)(param_1 + 0xf4) + 0x188);
      *(undefined4 *)(param_2 + 8) = uStack_20;
      *(undefined4 *)(param_2 + 0xc) = uStack_1c;
      *(undefined4 *)(param_2 + 0x10) = uStack_18;
      *(undefined4 *)(param_2 + 0x14) = uStack_8;
      fVar3 = *(float *)(*(int *)(param_1 + 0xf4) + 0x18c) - (float)DAT_01ee2fac;
      if (fVar3 <= 0.0) {
        fVar3 = 0.0;
      }
      *(float *)(param_2 + 0x18) = fVar3;
      *(undefined4 *)(param_2 + 0x1c) = 0;
      if ((*(char *)(param_2 + 0x21) == '\0') &&
         (piVar1 = *(int **)(*(int *)(param_1 + 0xf4) + 100), piVar1 != (int *)0x0)) {
        iVar2 = (**(code **)(*piVar1 + 0xa8))();
        if ((iVar2 != 0) && (*(int *)(iVar2 + 0xa8) != 0)) {
          iVar2 = FUN_00c155c0();
          if (iVar2 != 0) {
            *(int *)(param_2 + 0x1c) = iVar2;
          }
        }
      }
      return;
    }
  }
  *(undefined *)(param_2 + 0x20) = 0;
  return;
}



/* FUNCTION 17683 ; VA 0x00972060 ; FUN_00972060 */

void FUN_00972060(undefined4 param_1,code *param_2,undefined4 param_3,uint param_4,uint *param_5,
                 uint *param_6)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef08;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee2fe9);
  auStack_6c[0] = 0;
  uVar1 = *param_6;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_6 + 2;
      uStack_7c = 0x9720d7;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_6[2];
      uStack_60 = param_6[3];
      uStack_5c = param_6[4];
      uStack_58 = param_6[5];
      uStack_54 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_5;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_a8 = param_5[2];
      uStack_a4 = param_5[3];
      uStack_a0 = param_5[4];
      uStack_9c = param_5[5];
      uStack_98 = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00960800();
  uStack_8._0_1_ = 2;
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0x9721bc;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_a8 = param_4;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_a8 = 0x9721e3;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17684 ; VA 0x00972200 ; FUN_00972200 */

void FUN_00972200(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7e50;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee2fe9);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0x972285;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_008dbe80();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x972367;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0x972387);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17685 ; VA 0x009723a0 ; FUN_009723a0 */

void FUN_009723a0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef30;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee2fe9);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0x972425;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_009602e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x972507;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0x972527);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17686 ; VA 0x00972540 ; FUN_00972540 */

void FUN_00972540(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef48;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee2fe9);
  uVar2 = *param_6;
  uVar3 = *param_5;
  uStack_48 = 0;
  uVar4 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_48 = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0x9725ca;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar4 = *param_7;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_7 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_7[2];
      uStack_ac = param_7[3];
      uStack_a8 = param_7[4];
      uStack_a4 = param_7[5];
      uStack_a0 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00966b00);
  uStack_98 = 0x97263e;
  FUN_00960740();
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_78 = *param_4;
  uStack_74 = param_4[1];
  uStack_8 = 0xffffffff;
  uStack_7c = 0x97267b;
  uStack_70 = uVar3;
  uStack_6c = uVar2;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17687 ; VA 0x00972690 ; FUN_00972690 */

void FUN_00972690(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef70;
  pvStack_10 = ExceptionList;
  pcStack_18 = param_2;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ee2fe9);
  uVar1 = *param_6;
  uVar2 = *param_5;
  uStack_14 = *param_4;
  uVar3 = param_4[1];
  auStack_70[0] = 0;
  uVar4 = *param_8;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_70;
  puVar6 = auStack_70;
  if (uVar4 != 0) {
    auStack_70[0] = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_8 + 2;
      uStack_80 = 0x972725;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
      puVar5 = (uint *)puStack_20;
      puVar6 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_8[2];
      uStack_64 = param_8[3];
      uStack_60 = param_8[4];
      uStack_5c = param_8[5];
      uStack_58 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
      puVar5 = auStack_70;
      puVar6 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar6;
  puStack_20 = (undefined *)puVar5;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar4 = *param_7;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_7 + 2);
    }
    else {
      uStack_ac = param_7[2];
      uStack_a8 = param_7[3];
      uStack_a4 = param_7[4];
      uStack_a0 = param_7[5];
      uStack_9c = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960050();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0x972807;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uVar2,uVar3);
  uStack_a0 = uStack_14;
  uStack_a4 = 0x97282d;
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17688 ; VA 0x00972840 ; FUN_00972840 */

void __thiscall FUN_00972840(undefined4 param_1,int param_2,uint param_3,undefined4 param_4)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  uint *puVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined8 uStack_28;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef88;
  pvStack_10 = ExceptionList;
  uStack_14 = param_1;
  if (DAT_01d64710 == '\0') {
    if (DAT_01d65a50 == '\0') {
      ExceptionList = &pvStack_10;
      uVar2 = FUN_005e6850(param_4,0,0);
      uVar5 = param_1;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_005cf8d0(-(uint)(param_2 != 0) & param_2 + 0xcU);
      if ((DAT_01ee5c3c < 10000) && ((iVar3 == 0 || (*(char *)(iVar3 + 0xee) == '\0')))) {
        uVar2 = FUN_005e6850(param_4,0,0);
        uVar5 = uStack_14;
      }
      else {
        FUN_005ea8b0(&uStack_28,param_4,0,0,0);
        uVar5 = uStack_14;
        uVar2 = uStack_28._4_1_;
      }
    }
    goto LAB_009729cf;
  }
  ExceptionList = &pvStack_10;
  FUN_0097c020(&iStack_20,param_3,param_1);
  uStack_8 = 0;
  if (DAT_01d65a50 == '\0') {
    if (iStack_20 == 0) {
      uStack_28 = 0;
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_00928340();
    }
LAB_0097293b:
    uVar2 = FUN_005e6850(param_4,uVar6);
  }
  else {
    iVar3 = FUN_005cf8d0(-(uint)(param_2 != 0) & param_2 + 0xcU);
    if ((DAT_01ee5c3c < 10000) && ((iVar3 == 0 || (*(char *)(iVar3 + 0xee) == '\0')))) {
      if (iStack_20 == 0) {
        uStack_28 = 0;
        uVar6 = 0;
      }
      else {
        uVar6 = FUN_00928340();
      }
      goto LAB_0097293b;
    }
    if (iStack_20 == 0) {
      uStack_28 = 0;
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_00928340();
    }
    FUN_005ea8b0(&uStack_28,param_4,uVar6,0);
    uVar2 = uStack_28._4_1_;
  }
  uStack_8 = 0xffffffff;
  uVar5 = uStack_14;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      uVar5 = uStack_14;
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
        uVar5 = uStack_14;
      }
    }
  }
LAB_009729cf:
  if ((char)param_4 == '\0') {
    puVar4 = &uStack_18;
    uStack_14 = 0;
    uStack_18 = param_3;
  }
  else {
    puVar4 = (uint *)&uStack_28;
    uStack_28 = (ulonglong)param_3;
  }
  FUN_0098a470(uVar5,uVar2,puVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17689 ; VA 0x00972a50 ; FUN_00972a50 */

void FUN_00972a50(void)

{
  int iVar1;
  
  iVar1 = FUN_00562e40();
  if (iVar1 != 0) {
    FUN_0064b390(1000);
  }
  return;
}



/* FUNCTION 17690 ; VA 0x00972a70 ; FUN_00972a70 */

uint FUN_00972a70(uint param_1,int *param_2)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  code *pcStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0099be20();
    param_1 = (uint)*(ushort *)(iVar5 + 0x1da);
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <= param_1) {
      uStack_20 = uStack_14;
      pcStack_28 = FUN_00983720;
      uStack_24 = 0;
      FUN_00915d30(&uStack_14,&pcStack_28);
      param_1 = uStack_14;
      if (uStack_14 != 0) {
        piVar1 = (int *)(uStack_14 + 4);
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          param_1 = FUN_01674ea0(uStack_14);
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_2 + 1);
    uVar3 = *puVar2;
    param_1 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      param_1 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        param_1 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17691 ; VA 0x00972b50 ; FUN_00972b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00972b50(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  uint uVar13;
  uint in_stack_00000018;
  undefined auStack_6c [68];
  int *piStack_28;
  int iStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cefb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_00972d80(&param_2);
  if (*(int *)(*(int *)(param_1 + 0xf4) + 0xec) == 1) goto LAB_00972d2a;
  if (*(int *)(param_1 + 0xc0) != 0) {
    FUN_00607880(&piStack_28);
    uStack_8 = 1;
    auStack_14[0] = 0x87;
    FUN_006ad5e0(auStack_14,1);
    iVar10 = FUN_008f7870(param_1);
    if (iVar10 == 0) {
      FUN_00550b30();
      goto LAB_00972d2a;
    }
    uStack_1c = FUN_008f87a0();
    uStack_18 = FUN_0097eeb0();
    if (*(int *)(param_1 + 0xf8) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xf8) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0098daf0(piStack_28,uStack_1c,uStack_18,*(undefined4 *)(param_1 + 0xf4),
                 *(undefined4 *)(param_1 + 0xf8));
    FUN_006ae570(&param_2);
    uVar11 = (**(code **)(*piStack_28 + 8))();
    FUN_00971460(uVar11);
    uVar8 = uRam01ee2fe4;
    uVar7 = uRam01ee2fe0;
    uVar6 = uRam01ee2fdc;
    uVar5 = _DAT_01ee2fd8;
    uVar4 = uRam01ee2fd4;
    uVar3 = uRam01ee2fd0;
    uVar2 = uRam01ee2fcc;
    uVar11 = _DAT_01ee2fc8;
    if (iStack_24 != 0) {
      LOCK();
      *(int *)(iStack_24 + 4) = *(int *)(iStack_24 + 4) + 1;
      UNLOCK();
    }
    FUN_006afb30(piStack_28,iStack_24,1,2,2,uVar11,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,1,0);
    uStack_8 = 0;
    FUN_00550b30();
  }
  puVar12 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar12 = param_2;
  }
  if (*(int *)(param_1 + 0xf8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0xf8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0096b650(puVar12,0,*(undefined4 *)(param_1 + 0xf4),*(undefined4 *)(param_1 + 0xf8));
  uStack_8 = 2;
  if (*(int *)(param_1 + 0xf4) == 0) {
LAB_00972d08:
    FUN_005e6780(auStack_6c);
    FUN_00989e30(auStack_6c);
  }
  else {
    cVar9 = FUN_009281e0();
    if (cVar9 == '\0') goto LAB_00972d08;
  }
  FUN_0096d050();
LAB_00972d2a:
  if (0xf < in_stack_00000018) {
    uVar13 = in_stack_00000018 + 1;
    puVar12 = param_2;
    if (0xfff < uVar13) {
      puVar12 = (undefined4 *)param_2[-1];
      uVar13 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar12))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar12,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17692 ; VA 0x00972bee ; FUN_00972bee */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00972bee(void)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined4 in_EAX;
  undefined4 uVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -0x14) = in_EAX;
  if (*(int *)(unaff_ESI + 0xf8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_ESI + 0xf8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0098daf0();
  FUN_006ae570(unaff_EBP + 8);
  uVar11 = (**(code **)(*unaff_EDI + 8))();
  FUN_00971460(uVar11);
  uVar9 = uRam01ee2fe4;
  uVar8 = uRam01ee2fe0;
  uVar7 = uRam01ee2fdc;
  uVar6 = _DAT_01ee2fd8;
  uVar5 = uRam01ee2fd4;
  uVar4 = uRam01ee2fd0;
  uVar3 = uRam01ee2fcc;
  uVar11 = _DAT_01ee2fc8;
  iVar13 = *(int *)(unaff_EBP + -0x20);
  if (iVar13 != 0) {
    LOCK();
    *(int *)(iVar13 + 4) = *(int *)(iVar13 + 4) + 1;
    UNLOCK();
  }
  FUN_006afb30(unaff_EDI,iVar13,1,2,2,uVar11,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,1,0);
  *(undefined *)(unaff_EBP + -4) = 0;
  FUN_00550b30();
  iVar13 = unaff_EBP + 8;
  if (0xf < *(uint *)(unaff_EBP + 0x1c)) {
    iVar13 = *(int *)(unaff_EBP + 8);
  }
  if (*(int *)(unaff_ESI + 0xf8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(unaff_ESI + 0xf8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0096b650(iVar13,0,*(undefined4 *)(unaff_ESI + 0xf4),*(undefined4 *)(unaff_ESI + 0xf8));
  iVar13 = *(int *)(unaff_ESI + 0xf4);
  *(undefined *)(unaff_EBP + -4) = 2;
  if (iVar13 != 0) {
    cVar10 = FUN_009281e0();
    if (cVar10 != '\0') goto LAB_00972d22;
  }
  FUN_005e6780(unaff_EBP + -0x68);
  FUN_00989e30(unaff_EBP + -0x68);
LAB_00972d22:
  FUN_0096d050();
  uVar2 = *(uint *)(unaff_EBP + 0x1c);
  if (0xf < uVar2) {
    iVar13 = *(int *)(unaff_EBP + 8);
    uVar14 = uVar2 + 1;
    iVar12 = iVar13;
    if (0xfff < uVar14) {
      iVar12 = *(int *)(iVar13 + -4);
      uVar14 = uVar2 + 0x24;
      if (0x1f < (iVar13 - iVar12) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar12,uVar14);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 17693 ; VA 0x00972d80 ; FUN_00972d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00972d80(int param_1,int *param_2)

{
  uint uVar1;
  char cVar2;
  byte bVar3;
  int *piVar4;
  uint uVar5;
  bool bVar6;
  char *pcVar7;
  undefined auStack_10 [12];
  
  if (*(int *)(param_1 + 0xf4) == 0) {
    pcVar7 = "No local Player to chat from";
  }
  else {
    cVar2 = (**(code **)(*DAT_0211e964 + 0xc))(*(int *)(param_1 + 0xf4));
    if (cVar2 == '\0') {
      return;
    }
    uVar1 = param_2[4];
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    if ((uVar1 < 4) || (piVar4 = (int *)FUN_0170db20(param_2,0x2f,uVar1 - 3), piVar4 == (int *)0x0))
    {
LAB_00972e39:
      pcVar7 = "SuperSafe chat is on";
    }
    else {
      do {
        if (*piVar4 == _DAT_01936390) {
LAB_00972e09:
          uVar5 = 0;
        }
        else {
          bVar3 = (byte)*piVar4;
          bVar6 = bVar3 < DAT_01936390;
          if (bVar3 == DAT_01936390) {
            bVar6 = *(byte *)((int)piVar4 + 1) < DAT_01936391;
            if (*(byte *)((int)piVar4 + 1) == DAT_01936391) {
              bVar6 = *(byte *)((int)piVar4 + 2) < DAT_01936392;
              if (*(byte *)((int)piVar4 + 2) == DAT_01936392) {
                bVar6 = *(byte *)((int)piVar4 + 3) < DAT_01936393;
                if (*(byte *)((int)piVar4 + 3) == DAT_01936393) goto LAB_00972e09;
              }
            }
          }
          uVar5 = -(uint)bVar6 | 1;
        }
        if (uVar5 == 0) {
          if (piVar4 == param_2) {
            return;
          }
          goto LAB_00972e39;
        }
        piVar4 = (int *)FUN_0170db20((int)piVar4 + 1,0x2f,
                                     (int)param_2 + ((uVar1 - 3) - ((int)piVar4 + 1)));
      } while (piVar4 != (int *)0x0);
      pcVar7 = "SuperSafe chat is on";
    }
  }
  FUN_00550130(pcVar7);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 17694 ; VA 0x00972e70 ; FUN_00972e70 */

void __thiscall FUN_00972e70(int param_1,int param_2)

{
  uint *****pppppuVar1;
  int *piVar2;
  uint ***pppuVar3;
  int *piVar4;
  uint *puVar5;
  uint ***pppuVar6;
  int *piVar7;
  char cVar8;
  uint *****pppppuVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined4 *****pppppuVar12;
  uint *****pppppuVar13;
  uint ****ppppuVar14;
  int iVar15;
  uint ****ppppuVar16;
  uint uVar17;
  uint uVar18;
  uint *****pppppuVar19;
  uint ****ppppuVar20;
  uint *****pppppuVar21;
  double dVar22;
  double dVar23;
  undefined8 uVar24;
  uint ***pppuStack_c8;
  uint ****ppppuStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  uint ***pppuStack_a8;
  uint ***pppuStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint ****ppppuStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  uint ***pppuStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  uint ****ppppuStack_68;
  uint uStack_64;
  uint uStack_60;
  int iStack_5c;
  undefined4 ****appppuStack_58 [4];
  int iStack_48;
  uint uStack_44;
  int iStack_40;
  uint ***pppuStack_3c;
  uint ***pppuStack_38;
  uint ***pppuStack_34;
  int iStack_30;
  uint ****ppppuStack_2c;
  uint ****ppppuStack_28;
  int iStack_24;
  uint uStack_20;
  uint ****ppppuStack_1c;
  uint ****ppppuStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ceff9;
  pvStack_10 = ExceptionList;
  iStack_5c = 0;
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  uVar24 = FUN_00928340();
  pppuStack_3c = (uint ***)((ulonglong)uVar24 >> 0x20);
  pppuStack_38 = (uint ***)uVar24;
  iStack_5c = param_2 + 0x1b4;
  FUN_0054ef60(iStack_5c);
  uStack_20 = 1;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  FUN_00927ca0();
  pppuStack_34 = (uint ***)FUN_005f7790();
  FUN_01682800(&uStack_64);
  pppppuVar13 = *(uint ******)(param_1 + 0x270);
  iStack_40 = param_1 + 0x270;
  dVar22 = (double)CONCAT44(uStack_60,uStack_64);
  uStack_14 = 0;
  pppppuVar19 = *(uint ******)(param_1 + 0x274);
  iStack_30 = 0;
  ppppuStack_2c = (uint ****)pppppuVar19;
  if (pppppuVar13 != pppppuVar19) {
    do {
      if ((double)(DAT_01ee2fb8 * 1000) < (dVar22 - *(double *)(pppppuVar13 + 10)) * DAT_018c0d70)
      break;
      pppppuVar13 = pppppuVar13 + 0xe;
    } while (pppppuVar13 != pppppuVar19);
    if (pppppuVar13 != pppppuVar19) {
      ppppuStack_28 = (uint ****)(pppppuVar13 + 0xe);
      ppppuStack_18 = (uint ****)pppppuVar13;
      if ((uint *****)ppppuStack_28 != pppppuVar19) {
        pppppuVar9 = pppppuVar13 + 1;
        pppppuVar21 = pppppuVar13 + 0xf;
        dVar23 = DAT_018c0d70;
        do {
          if ((dVar22 - *(double *)(pppppuVar21 + 9)) * dVar23 <= (double)(DAT_01ee2fb8 * 1000)) {
            *pppppuVar13 = (uint ****)*ppppuStack_28;
            if (pppppuVar9 != pppppuVar21) {
              if ((uint ****)0xf < pppppuVar9[5]) {
                ppppuVar20 = *pppppuVar9;
                ppppuVar16 = (uint ****)((int)pppppuVar9[5] + 1);
                ppppuVar14 = ppppuVar20;
                if ((uint ****)0xfff < ppppuVar16) {
                  ppppuVar14 = (uint ****)ppppuVar20[-1];
                  ppppuVar16 = pppppuVar9[5] + 9;
                  if (0x1f < (uint)((int)ppppuVar20 + (-4 - (int)ppppuVar14))) goto LAB_0097377a;
                }
                FUN_01674ea0(ppppuVar14,ppppuVar16);
                pppppuVar13 = (uint *****)ppppuStack_18;
                pppppuVar19 = (uint *****)ppppuStack_2c;
                dVar23 = DAT_018c0d70;
              }
              pppppuVar9[4] = (uint ****)0x0;
              pppppuVar9[5] = (uint ****)0xf;
              *(undefined *)pppppuVar9 = 0;
              ppppuVar20 = pppppuVar21[1];
              ppppuVar14 = pppppuVar21[2];
              ppppuVar16 = pppppuVar21[3];
              *pppppuVar9 = *pppppuVar21;
              pppppuVar9[1] = ppppuVar20;
              pppppuVar9[2] = ppppuVar14;
              pppppuVar9[3] = ppppuVar16;
              *(undefined8 *)(pppppuVar9 + 4) = *(undefined8 *)(pppppuVar21 + 4);
              pppppuVar21[4] = (uint ****)0x0;
              pppppuVar21[5] = (uint ****)0xf;
              *(undefined *)pppppuVar21 = 0;
            }
            pppppuVar13 = pppppuVar13 + 0xe;
            pppppuVar9[7] = pppppuVar21[7];
            pppppuVar9[8] = pppppuVar21[8];
            pppppuVar9[9] = pppppuVar21[9];
            pppppuVar9[10] = pppppuVar21[10];
            pppppuVar9[0xb] = pppppuVar21[0xb];
            pppppuVar9 = pppppuVar9 + 0xe;
            dVar22 = (double)CONCAT44(uStack_60,uStack_64);
            ppppuStack_18 = (uint ****)pppppuVar13;
          }
          pppppuVar21 = pppppuVar21 + 0xe;
          ppppuStack_28 = ppppuStack_28 + 0xe;
        } while ((uint *****)ppppuStack_28 != pppppuVar19);
      }
      if (pppppuVar13 != pppppuVar19) {
        pppppuVar9 = *(uint ******)(iStack_40 + 4);
        ppppuStack_1c = (uint ****)pppppuVar9;
        if (pppppuVar19 != pppppuVar9) {
          pppppuVar9 = pppppuVar13 + 1;
          pppppuVar21 = pppppuVar19 + 1;
          do {
            *pppppuVar13 = *pppppuVar19;
            if (pppppuVar9 != pppppuVar21) {
              if ((uint ****)0xf < pppppuVar9[5]) {
                ppppuVar20 = *pppppuVar9;
                ppppuVar16 = (uint ****)((int)pppppuVar9[5] + 1);
                ppppuVar14 = ppppuVar20;
                if ((uint ****)0xfff < ppppuVar16) {
                  ppppuVar14 = (uint ****)ppppuVar20[-1];
                  ppppuVar16 = pppppuVar9[5] + 9;
                  if (0x1f < (uint)((int)ppppuVar20 + (-4 - (int)ppppuVar14))) goto LAB_0097377a;
                }
                FUN_01674ea0(ppppuVar14,ppppuVar16);
                pppppuVar13 = (uint *****)ppppuStack_18;
                pppppuVar19 = (uint *****)ppppuStack_2c;
              }
              pppppuVar9[4] = (uint ****)0x0;
              pppppuVar9[5] = (uint ****)0xf;
              *(undefined *)pppppuVar9 = 0;
              ppppuVar20 = pppppuVar21[1];
              ppppuVar14 = pppppuVar21[2];
              ppppuVar16 = pppppuVar21[3];
              *pppppuVar9 = *pppppuVar21;
              pppppuVar9[1] = ppppuVar20;
              pppppuVar9[2] = ppppuVar14;
              pppppuVar9[3] = ppppuVar16;
              *(undefined8 *)(pppppuVar9 + 4) = *(undefined8 *)(pppppuVar21 + 4);
              pppppuVar21[4] = (uint ****)0x0;
              pppppuVar21[5] = (uint ****)0xf;
              *(undefined *)pppppuVar21 = 0;
            }
            pppppuVar19 = pppppuVar19 + 0xe;
            pppppuVar9[7] = pppppuVar21[7];
            pppppuVar13 = pppppuVar13 + 0xe;
            pppppuVar9[8] = pppppuVar21[8];
            pppppuVar9[9] = pppppuVar21[9];
            pppppuVar9[10] = pppppuVar21[10];
            pppppuVar1 = pppppuVar21 + 0xb;
            pppppuVar21 = pppppuVar21 + 0xe;
            pppppuVar9[0xb] = *pppppuVar1;
            pppppuVar9 = pppppuVar9 + 0xe;
            ppppuStack_2c = (uint ****)pppppuVar19;
            ppppuStack_18 = (uint ****)pppppuVar13;
          } while (pppppuVar19 != (uint *****)ppppuStack_1c);
          pppppuVar9 = *(uint ******)(iStack_40 + 4);
        }
        iVar10 = iStack_40;
        FUN_00961b20(pppppuVar13,pppppuVar9,iStack_40);
        *(uint *****)(iVar10 + 4) = ppppuStack_18;
      }
    }
  }
  ppppuStack_18 = *(uint *****)(iStack_24 + 0xbc);
  if ((uint *****)ppppuStack_18 != (uint *****)0x0) {
    LOCK();
    ((uint *****)ppppuStack_18)[1] = (uint ****)((int)((uint *****)ppppuStack_18)[1] + 1);
    UNLOCK();
    ppppuStack_18 = *(uint *****)(iStack_24 + 0xbc);
  }
  puVar11 = *(undefined4 **)(iStack_24 + 0xb8);
  uStack_8._0_1_ = 1;
  if (puVar11 != (undefined4 *)0x0) {
    ppppuStack_2c = (uint ****)*puVar11;
    ppppuStack_68 = (uint ****)puVar11[1];
    if ((uint *****)ppppuStack_2c != (uint *****)puVar11[1]) {
      do {
        if (((uint ****)*ppppuStack_2c == (uint ****)0x0) ||
           (pppuVar3 = (uint ***)(*ppppuStack_2c)[3], iVar10 = FUN_00913630(),
           (uint)*(ushort *)(iVar10 + 0x1da) <
           (uint)*(ushort *)(pppuVar3 + 0x76) - (uint)*(ushort *)(iVar10 + 0x1d8))) {
          piStack_6c = (int *)0x0;
          puVar11 = &uStack_70;
          ppppuStack_28 = (uint ****)0x0;
          uVar17 = 0xc;
        }
        else {
          pppuStack_74 = ppppuStack_2c[1];
          ppppuStack_28 = (uint ****)*ppppuStack_2c;
          if ((uint ****)pppuStack_74 != (uint ****)0x0) {
            LOCK();
            ((uint ****)pppuStack_74)[1] = (uint ***)((int)((uint ****)pppuStack_74)[1] + 1);
            UNLOCK();
            pppuStack_74 = ppppuStack_2c[1];
          }
          uVar17 = 10;
          puVar11 = &uStack_78;
        }
        uStack_20 = uStack_20 | uVar17;
        piVar4 = (int *)puVar11[1];
        *puVar11 = 0;
        puVar11[1] = 0;
        piVar7 = piStack_6c;
        if (((uStack_20 & 4) != 0) && (uStack_20 = uStack_20 & 0xfffffffb, piStack_6c != (int *)0x0)
           ) {
          LOCK();
          iVar10 = piStack_6c[1] + -1;
          piStack_6c[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_6c)();
            LOCK();
            piVar2 = piVar7 + 2;
            iVar10 = *piVar2 + -1;
            *piVar2 = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        pppuVar3 = pppuStack_74;
        if (((uStack_20 & 2) != 0) &&
           (uStack_20 = uStack_20 & 0xfffffffd, (uint ****)pppuStack_74 != (uint ****)0x0)) {
          LOCK();
          pppuVar6 = (uint ***)((int)pppuStack_74[1] + -1);
          pppuStack_74[1] = (uint **)pppuVar6;
          UNLOCK();
          if (pppuVar6 == (uint ***)0x0) {
            (*(code *)**pppuStack_74)();
            LOCK();
            ppppuVar20 = (uint ****)(pppuVar3 + 2);
            pppuVar6 = (uint ***)((int)*ppppuVar20 + -1);
            *ppppuVar20 = pppuVar6;
            UNLOCK();
            if (pppuVar6 == (uint ***)0x0) {
              (*(code *)(*pppuVar3)[1])();
            }
          }
        }
        ppppuVar20 = ppppuStack_28;
        uStack_8._0_1_ = 2;
        if ((uint *****)ppppuStack_28 != (uint *****)0x0) {
          FUN_00927ca0();
          ppppuStack_1c = (uint ****)FUN_005f7790();
          FUN_0054ef60(ppppuVar20 + 0x6d);
          uStack_20 = uStack_20 | 0x10;
          uVar17 = 0;
          if (ppppuStack_1c == (uint ****)pppuStack_34) {
            uVar17 = 1;
          }
          else if ((((uint)ppppuStack_1c ^ (uint)pppuStack_34) & 0xffffff) == 0) {
            uVar17 = 2;
          }
          ppppuStack_1c = ppppuStack_90;
          uStack_14 = uVar17;
          if (iStack_48 != 0) {
            pppppuVar13 = &ppppuStack_90;
            if (0xf < uStack_7c) {
              pppppuVar13 = (uint *****)ppppuStack_90;
            }
            pppppuVar12 = appppuStack_58;
            if (0xf < uStack_44) {
              pppppuVar12 = (undefined4 *****)appppuStack_58[0];
            }
            cVar8 = FUN_0055c360(pppppuVar12,iStack_48,pppppuVar13,uStack_80);
            if (cVar8 != '\0') {
              uVar17 = uVar17 | 4;
              uStack_14 = uVar17;
            }
          }
          if (0xf < uStack_7c) {
            uVar18 = uStack_7c + 1;
            pppppuVar13 = (uint *****)ppppuStack_1c;
            if (0xfff < uVar18) {
              pppppuVar13 = (uint *****)ppppuStack_1c[-1];
              uVar18 = uStack_7c + 0x24;
              if (0x1f < (uint)((int)ppppuStack_1c + (-4 - (int)pppppuVar13))) goto LAB_0097377a;
            }
            FUN_01674ea0(pppppuVar13,uVar18);
          }
          if (uVar17 != 0) {
            uVar24 = FUN_00928340(0);
            iStack_30 = FUN_009800f0(uVar17,pppuStack_38,pppuStack_3c,uVar24);
            if (piVar4 != (int *)0x0) {
              LOCK();
              iVar10 = piVar4[1] + -1;
              piVar4[1] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)*piVar4)();
                LOCK();
                iVar10 = piVar4[2] + -1;
                piVar4[2] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            break;
          }
        }
        uStack_8._0_1_ = 1;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar10 = piVar4[1] + -1;
          piVar4[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar10 = piVar4[2] + -1;
            piVar4[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        ppppuStack_2c = ppppuStack_2c + 2;
      } while (ppppuStack_2c != ppppuStack_68);
    }
  }
  ppppuVar20 = ppppuStack_18;
  uStack_8._0_1_ = 0;
  if ((uint *****)ppppuStack_18 != (uint *****)0x0) {
    LOCK();
    ppppuVar14 = (uint ****)((int)ppppuStack_18[1] - 1);
    ppppuStack_18[1] = (uint ***)ppppuVar14;
    UNLOCK();
    if (ppppuVar14 == (uint ****)0x0) {
      (*(code *)**ppppuStack_18)();
      LOCK();
      pppppuVar13 = (uint *****)(ppppuVar20 + 2);
      ppppuVar14 = *pppppuVar13;
      *pppppuVar13 = (uint ****)((int)*pppppuVar13 - 1);
      UNLOCK();
      if (ppppuVar14 == (uint ****)0x1) {
        (*(code *)(*ppppuVar20)[1])();
      }
    }
  }
  uVar17 = uStack_14;
  pppppuVar13 = *(uint ******)(iStack_24 + 0x274);
  pppppuVar19 = pppppuVar13;
  pppppuVar9 = pppppuVar13;
  ppppuStack_1c = (uint ****)pppppuVar13;
  if (uStack_14 == 0) {
    pppppuVar21 = *(uint ******)(iStack_24 + 0x270);
    if (pppppuVar21 != pppppuVar13) {
      do {
        uStack_14 = 0;
        if (*pppppuVar21 == (uint ****)pppuStack_34) {
          uStack_14 = 1;
        }
        else if ((((uint)*pppppuVar21 ^ (uint)pppuStack_34) & 0xffffff) == 0) {
          uStack_14 = 2;
        }
        if (iStack_48 != 0) {
          pppppuVar19 = pppppuVar21 + 1;
          if ((uint ****)0xf < pppppuVar21[6]) {
            pppppuVar19 = (uint *****)*pppppuVar19;
          }
          pppppuVar12 = appppuStack_58;
          if (0xf < uStack_44) {
            pppppuVar12 = (undefined4 *****)appppuStack_58[0];
          }
          cVar8 = FUN_0055c360(pppppuVar12,iStack_48,pppppuVar19,pppppuVar21[5]);
          pppppuVar19 = (uint *****)ppppuStack_1c;
          if (cVar8 != '\0') {
            uStack_14 = uStack_14 | 4;
          }
        }
        pppppuVar9 = pppppuVar21;
      } while ((uStack_14 == 0) &&
              (pppppuVar21 = pppppuVar21 + 0xe, pppppuVar9 = pppppuVar13, pppppuVar21 != pppppuVar19
              ));
    }
LAB_009734ad:
    uVar17 = uStack_14;
    pppuVar3 = pppuStack_34;
    if (pppppuVar9 == pppppuVar19) {
      if ((uint)(((int)pppppuVar19 - *(int *)(iStack_24 + 0x270)) / 0x38) < 0x100) {
        uStack_b4 = 0xf00000000;
        ppppuStack_c4 = (uint ****)((uint)ppppuStack_c4 & 0xffffff00);
        pppuStack_a8 = pppuStack_38;
        pppuStack_a4 = pppuStack_3c;
        uStack_a0 = uStack_64;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        pppuStack_c8 = pppuStack_34;
        uStack_9c = uStack_60;
        uStack_98 = 1;
        FUN_0054ef60(iStack_5c);
        ppppuStack_c4 = ppppuStack_90;
        uStack_c0 = uStack_8c;
        uStack_bc = uStack_88;
        uStack_b8 = uStack_84;
        uStack_b4._4_4_ = uStack_7c;
        puVar5 = *(uint **)(iStack_40 + 4);
        if (*(uint **)(iStack_40 + 8) == puVar5) {
          FUN_00961b90(puVar5,&pppuStack_c8);
        }
        else {
          *puVar5 = (uint)pppuVar3;
          FUN_0054ef60(&ppppuStack_c4);
          puVar5[8] = (uint)pppuStack_a8;
          puVar5[9] = (uint)pppuStack_a4;
          puVar5[10] = uStack_a0;
          puVar5[0xb] = uStack_9c;
          puVar5[0xc] = uStack_98;
          *(int *)(iStack_24 + 0x274) = *(int *)(iStack_24 + 0x274) + 0x38;
        }
        uStack_8._0_1_ = 0;
        if (0xf < uStack_b4._4_4_) {
          uVar17 = uStack_b4._4_4_ + 1;
          pppppuVar13 = (uint *****)ppppuStack_c4;
          if (0xfff < uVar17) {
            pppppuVar13 = (uint *****)ppppuStack_c4[-1];
            uVar17 = uStack_b4._4_4_ + 0x24;
            if (0x1f < (uint)((int)ppppuStack_c4 + (-4 - (int)pppppuVar13))) {
LAB_0097377a:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pppppuVar13,uVar17);
        }
      }
    }
    else {
      ppppuVar20 = pppppuVar9[8];
      ppppuVar14 = pppppuVar9[9];
      if (((ppppuVar20 == (uint ****)pppuStack_38) && (ppppuVar14 == (uint ****)pppuStack_3c)) &&
         (*pppppuVar9 == (uint ****)pppuStack_34)) {
        pppppuVar13 = pppppuVar9 + 1;
        pppppuVar12 = appppuStack_58;
        if (0xf < uStack_44) {
          pppppuVar12 = (undefined4 *****)appppuStack_58[0];
        }
        if ((uint ****)0xf < pppppuVar9[6]) {
          pppppuVar13 = (uint *****)*pppppuVar13;
        }
        cVar8 = FUN_0055c360(pppppuVar13,pppppuVar9[5],pppppuVar12,iStack_48);
        if (cVar8 != '\0') goto LAB_00973738;
        ppppuVar14 = pppppuVar9[9];
        ppppuVar20 = pppppuVar9[8];
      }
      pppppuVar9[0xc] = (uint ****)((int)pppppuVar9[0xc] + 1);
      iStack_30 = FUN_009800f0(uVar17,pppuStack_38,pppuStack_3c,ppppuVar20,ppppuVar14,
                               pppppuVar9[0xc]);
      if (iStack_30 != 0) {
        FUN_0098ad10(uVar17);
      }
      FUN_009774b0(iStack_24,param_2,appppuStack_58,pppppuVar9[8],pppppuVar9[9],iStack_30,uVar17);
    }
    iVar10 = FUN_0065b150(param_2);
    if (iVar10 == 0) goto LAB_00973738;
    FUN_0066c930(1);
    iVar10 = iStack_30;
  }
  else {
    if (iStack_30 == 0) goto LAB_009734ad;
    FUN_0098ad10(uStack_14);
    iVar10 = iStack_30;
    FUN_009774b0(iStack_24,param_2,appppuStack_58,pppuStack_38,pppuStack_3c,iStack_30,uVar17);
    iVar15 = FUN_0065b150(param_2);
    if (iVar15 == 0) goto LAB_00973738;
    if ((DAT_01d5ac68 != '\0') || (DAT_01d5ac70 != '\0')) {
      FUN_0066cb30(1,iVar10 == 1);
      goto LAB_00973738;
    }
    FUN_0066c930(1);
  }
  if (iVar10 == 1) {
    FUN_0066c940(1);
  }
LAB_00973738:
  if (0xf < uStack_44) {
    uVar17 = uStack_44 + 1;
    pppppuVar12 = (undefined4 *****)appppuStack_58[0];
    if (0xfff < uVar17) {
      pppppuVar12 = (undefined4 *****)appppuStack_58[0][-1];
      uVar17 = uStack_44 + 0x24;
      if (0x1f < (uint)((int)appppuStack_58[0] + (-4 - (int)pppppuVar12))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar12,uVar17);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17695 ; VA 0x00973790 ; FUN_00973790 */

void __fastcall FUN_00973790(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[7];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0x38);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 17696 ; VA 0x00973810 ; FUN_00973810 */

void __fastcall FUN_00973810(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[7];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0x40);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 17697 ; VA 0x00973890 ; FUN_00973890 */

void __fastcall FUN_00973890(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      uVar2 = piVar6[0xb];
      piVar1 = (int *)*piVar6;
      if (0xf < uVar2) {
        iVar3 = piVar6[6];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[10] = 0;
      piVar6[0xb] = 0xf;
      *(undefined *)(piVar6 + 6) = 0;
      FUN_01674ea0(piVar6,0x38);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 17698 ; VA 0x00973910 ; FUN_00973910 */

void __fastcall FUN_00973910(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_00651cc0();
      FUN_01674ea0(piVar2,0x40);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 17699 ; VA 0x00973950 ; FUN_00973950 */

void FUN_00973950(void)

{
  FUN_0068a900();
  return;
}



/* FUNCTION 17700 ; VA 0x00973960 ; FUN_00973960 */

undefined4 * __thiscall
FUN_00973960(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf041;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00979f80;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17701 ; VA 0x00973b10 ; FUN_00973b10 */

undefined4 * __thiscall
FUN_00973b10(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089f8b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17702 ; VA 0x00973cb0 ; FUN_00973cb0 */

undefined4 * __thiscall
FUN_00973cb0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf081;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0097a390;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17703 ; VA 0x00973e50 ; FUN_00973e50 */

undefined4 * __thiscall
FUN_00973e50(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf0c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0097a130;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17704 ; VA 0x00974000 ; FUN_00974000 */

undefined4 * __thiscall
FUN_00974000(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf101;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0097a5f0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17705 ; VA 0x009741a0 ; FUN_009741a0 */

undefined4 * __thiscall
FUN_009741a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0097a290;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17706 ; VA 0x00974350 ; FUN_00974350 */

undefined4 * __thiscall
FUN_00974350(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf181;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_008f4680;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17707 ; VA 0x00974500 ; FUN_00974500 */

void FUN_00974500(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_0098cfc0();
    *param_2 = uVar3;
    iVar4 = FUN_0098d0e0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 17708 ; VA 0x00974560 ; FUN_00974560 */

void FUN_00974560(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_0098d050();
    *param_2 = uVar3;
    iVar4 = FUN_0098d150();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 17709 ; VA 0x009745c0 ; FUN_009745c0 */

void FUN_009745c0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0098cfc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17710 ; VA 0x00974600 ; FUN_00974600 */

void FUN_00974600(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0098d050();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17711 ; VA 0x00974640 ; FUN_00974640 */

void __thiscall
FUN_00974640(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 *param_11,ulonglong param_12,uint param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined8 param_19)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  char cVar5;
  undefined auStack_a4 [8];
  undefined4 uStack_9c;
  int *piStack_98;
  undefined4 *puStack_94;
  undefined4 uStack_90;
  uint auStack_8c [2];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  ulonglong uStack_74;
  uint auStack_6c [2];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined auStack_4c [8];
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  char *pcStack_38;
  undefined auStack_2c [12];
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf1c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (DAT_01d64730 == '\0') {
    pcStack_38 = (char *)0x974674;
    ExceptionList = &pvStack_10;
    puStack_3c = (undefined4 *)FUN_01255560();
    pcStack_38 = (char *)0x5;
    puStack_40 = (undefined4 *)0x97467c;
    cVar5 = FUN_01255580();
    if (cVar5 == '\0') {
      puStack_3c = (undefined4 *)auStack_2c;
      pcStack_38 = "CreateHumanoidModelFromDescription is not yet enabled";
      puStack_40 = (undefined4 *)0x97482c;
      FUN_016756b0();
      puStack_3c = (undefined4 *)auStack_2c;
      pcStack_38 = "";
                    /* WARNING: Subroutine does not return */
      puStack_40 = (undefined4 *)&UNK_0097483d;
      FUN_0170c2a8();
    }
  }
  puStack_14 = auStack_4c;
  puStack_3c = (undefined4 *)0x0;
  pcStack_38 = (char *)0xf;
  uStack_54 = 0x2201935d18;
  auStack_4c[0] = 0;
  uStack_58 = 0x9746ac;
  FUN_005542c0();
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  uStack_8._0_1_ = 3;
  auStack_6c[0] = 0;
  puVar3 = auStack_6c;
  if (param_13 != 0) {
    auStack_6c[0] = param_13;
    if ((param_13 & 1) == 0) {
      uStack_74 = ZEXT48(&uStack_64);
      puStack_78 = &param_15;
      uStack_7c = 0x9746f4;
      (**(code **)(param_13 & 0xfffffffe))();
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_15;
      uStack_60 = param_16;
      uStack_5c = param_17;
      uStack_58 = param_18;
      uStack_54 = param_19;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)auStack_8c;
  puStack_20 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 4;
  auStack_8c[0] = 0;
  puVar3 = auStack_8c;
  puVar4 = auStack_8c;
  if (param_6 != 0) {
    auStack_8c[0] = param_6;
    if ((param_6 & 1) == 0) {
      puStack_94 = &uStack_84;
      uStack_90 = 0;
      piStack_98 = &param_8;
      uStack_9c = 0x97473f;
      (**(code **)(param_6 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_84 = param_8;
      uStack_80 = param_9;
      uStack_7c = param_10;
      puStack_78 = param_11;
      uStack_74 = param_12;
      puVar3 = auStack_8c;
      puVar4 = auStack_8c;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_90 = param_5;
  puStack_94 = (undefined4 *)param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_9c = param_2;
  piStack_98 = param_3;
  uStack_8._0_1_ = 6;
  FUN_0060dcd0(auStack_a4,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00974840();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      pcStack_38 = (char *)0x9747ab;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcStack_38 = (char *)0x9747ba;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_40 = &param_8;
    pcStack_38 = (char *)0x2;
    uStack_44 = 0x9747db;
    puStack_3c = puStack_40;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_40 = &param_15;
    pcStack_38 = (char *)0x2;
    uStack_44 = 0x974809;
    puStack_3c = puStack_40;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17712 ; VA 0x00974840 ; FUN_00974840 */

void FUN_00974840(undefined4 param_1,int *param_2,int param_3,int *param_4,int param_5,
                 undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined8 param_13,
                 int *param_14)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *in_stack_0000005c;
  uint in_stack_00000070;
  undefined auStack_150 [16];
  undefined4 uStack_140;
  int iStack_13c;
  int *piStack_138;
  int iStack_134;
  undefined4 uStack_130;
  int *piStack_12c;
  undefined4 auStack_128 [6];
  undefined4 uStack_110;
  int **ppiStack_10c;
  char *pcStack_108;
  undefined4 *puStack_104;
  int *piStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 *puStack_f4;
  undefined4 *puStack_f0;
  uint *puStack_ec;
  int aiStack_e0 [9];
  int *piStack_bc;
  int aiStack_b8 [9];
  int *piStack_94;
  int aiStack_90 [9];
  int *piStack_6c;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf274;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  if (param_3 == 0) {
LAB_009748b9:
    piStack_1c = (int *)0x0;
    piVar5 = &iStack_20;
    iStack_24 = 0;
    puVar7 = (undefined4 *)&DAT_00000006;
  }
  else {
    iVar1 = *(int *)(param_3 + 0xc);
    puStack_ec = (uint *)0x97487d;
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00e2c3f0();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_009748b9;
    iStack_24 = param_3;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    piStack_34 = param_4;
    puVar7 = (undefined4 *)&DAT_00000005;
    piVar5 = &iStack_38;
  }
  iStack_40 = iStack_24;
  piVar2 = (int *)piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  piStack_3c = piVar2;
  if ((((uint)puVar7 & 2) != 0) &&
     (puStack_18 = (undefined4 *)((uint)puVar7 & 0xfffffffd), puVar7 = puStack_18,
     piStack_1c != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_ec = (uint *)0x974907;
      (**(code **)*piStack_1c)();
      LOCK();
      iVar1 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar1;
      UNLOCK();
      puVar7 = puStack_18;
      if (iVar1 == 0) {
        puStack_ec = (uint *)0x974918;
        (**(code **)(*piStack_1c + 4))();
        puVar7 = puStack_18;
      }
    }
  }
  if ((((uint)puVar7 & 1) != 0) && (piStack_34 != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_34[1] + -1;
    piStack_34[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_ec = (uint *)0x974934;
      (**(code **)*piStack_34)();
      LOCK();
      iVar1 = piStack_34[2] + -1;
      piStack_34[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puStack_ec = (uint *)0x974945;
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iStack_24 == 0) {
    puStack_104 = &stack0x0000005c;
    if (0xf < in_stack_00000070) {
      puStack_104 = in_stack_0000005c;
    }
    pcStack_108 = "Players:%s() got invalid humanoidDescription";
LAB_00974991:
    ppiStack_10c = &piStack_100;
    uStack_110 = 0x974997;
    FUN_01675640();
    puStack_104 = (undefined4 *)0x9749a2;
    FUN_005e65e0();
  }
  else {
    puStack_ec = (uint *)param_1;
    puStack_f0 = (undefined4 *)0x97496f;
    iStack_30 = FUN_008f7870();
    if (iStack_30 == 0) {
      puStack_104 = &stack0x0000005c;
      if (0xf < in_stack_00000070) {
        puStack_104 = in_stack_0000005c;
      }
      pcStack_108 = "Players:%s() could not complete";
      goto LAB_00974991;
    }
    puStack_18 = (undefined4 *)CONCAT31(puStack_18._1_3_,param_5 == 1);
    if (iStack_30 == -0xc) {
      puStack_f0 = (undefined4 *)0x0;
    }
    else {
      puStack_ec = (uint *)0x9749bf;
      puStack_f0 = (undefined4 *)FUN_005c2760();
    }
    puStack_ec = puStack_18;
    puStack_f4 = &uStack_2c;
    uStack_f8 = 0x9749d0;
    FUN_00e2f260();
    uStack_f8 = uStack_2c;
    uStack_8._0_1_ = 6;
    uStack_fc = 0x9749dc;
    uStack_fc = FUN_009ba880();
    piStack_100 = &iStack_20;
    puStack_104 = (undefined4 *)0x9749e6;
    FUN_0060dcd0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    if (iStack_20 != 0) {
      if (iStack_30 != -0xc) {
        puStack_ec = (uint *)0x974a6c;
        puStack_18 = (undefined4 *)FUN_0063f510();
        if (puStack_18 != (undefined4 *)0x0) {
          puStack_ec = (uint *)iStack_20;
          puStack_f0 = (undefined4 *)0x974a7d;
          cVar3 = FUN_00bb4380();
          if (cVar3 == '\0') {
            puStack_ec = (uint *)iStack_20;
            puStack_f0 = (undefined4 *)0x974a8c;
            FUN_00bb3720();
          }
        }
      }
      if (DAT_01d64730 != '\0') {
        *(undefined *)(iStack_20 + 0x291) = 1;
      }
      auStack_68[0] = 0;
      if (param_7 != 0) {
        auStack_68[0] = param_7;
        if ((param_7 & 1) == 0) {
          puStack_f0 = &uStack_60;
          puStack_ec = (uint *)0x0;
          puStack_f4 = &param_9;
          uStack_f8 = 0x974ad9;
          (**(code **)(param_7 & 0xfffffffe))();
        }
        else {
          uStack_60 = param_9;
          uStack_5c = param_10;
          uStack_58 = param_11;
          uStack_54 = param_12;
          uStack_50 = param_13;
        }
      }
      if (iStack_28 != 0) {
        LOCK();
        *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
        UNLOCK();
      }
      uStack_48 = uStack_2c;
      iStack_44 = iStack_28;
      piStack_bc = (int *)0x0;
      puStack_ec = auStack_68;
      uStack_8._0_1_ = 9;
      puStack_f0 = (undefined4 *)0x974b18;
      piStack_bc = (int *)FUN_009621e0();
      puStack_ec = (uint *)0x974b29;
      FUN_008c3670();
      piStack_34 = (int *)&pcStack_108;
      uStack_8._0_1_ = 10;
      ppiStack_10c = &param_14;
      uStack_110 = 0x974b3e;
      FUN_0054f510();
      puStack_18 = auStack_128;
      piStack_14 = aiStack_b8;
      piStack_94 = (int *)0x0;
      uStack_8._0_1_ = 0xc;
      puVar7 = auStack_128;
      if (piStack_bc != (int *)0x0) {
        piStack_12c = aiStack_b8;
        uStack_130 = 0x974b70;
        piStack_94 = (int *)(**(code **)*piStack_bc)();
        puVar7 = puStack_18;
      }
      puStack_18 = puVar7;
      piStack_14 = aiStack_90;
      piStack_6c = (int *)0x0;
      uStack_8._0_1_ = 0xe;
      if (piStack_94 != (int *)0x0) {
        piStack_12c = aiStack_90;
        uStack_130 = 0x974b9f;
        piStack_6c = (int *)(**(code **)*piStack_94)();
      }
      piStack_14 = (int *)auStack_150;
      *puStack_18 = 0;
      piStack_12c = (int *)0x0;
      uStack_8._0_1_ = 0x10;
      if (piStack_6c != (int *)0x0) {
        uVar6 = (**(code **)*piStack_6c)(auStack_150);
        *(undefined4 *)((int)piStack_14 + 0x24) = uVar6;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      FUN_00728c80();
      if (piStack_6c != (int *)0x0) {
        piStack_12c = (int *)CONCAT31((int3)((uint)aiStack_90 >> 8),piStack_6c != aiStack_90);
        uStack_130 = 0x974bfc;
        (**(code **)(*piStack_6c + 0x10))();
        piStack_6c = (int *)0x0;
      }
      uStack_8._0_1_ = 0xb;
      if (piStack_94 != (int *)0x0) {
        piStack_12c = (int *)CONCAT31((int3)((uint)aiStack_b8 >> 8),piStack_94 != aiStack_b8);
        uStack_130 = 0x974c24;
        (**(code **)(*piStack_94 + 0x10))();
        piStack_94 = (int *)0x0;
      }
      piStack_12c = (int *)param_6;
      uStack_130 = 0;
      iStack_134 = iStack_30;
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
      }
      iStack_13c = iStack_24;
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      uStack_140 = 0x974c64;
      piStack_138 = piVar2;
      FUN_009a7640();
      if (piStack_bc != (int *)0x0) {
        puStack_ec = (uint *)CONCAT31((int3)((uint)aiStack_e0 >> 8),piStack_bc != aiStack_e0);
        puStack_f0 = (undefined4 *)0x974c81;
        (**(code **)(*piStack_bc + 0x10))();
      }
      puStack_ec = (uint *)0x974c89;
      FUN_00550b30();
      puStack_ec = (uint *)0x974c91;
      FUN_00550b30();
      puStack_ec = (uint *)0x974c99;
      FUN_00550b30();
      goto LAB_00974c99;
    }
    puStack_104 = &stack0x0000005c;
    if (0xf < in_stack_00000070) {
      puStack_104 = in_stack_0000005c;
    }
    ppiStack_10c = &piStack_100;
    pcStack_108 = "Players:%s() could not load character";
    uStack_110 = 0x974a10;
    FUN_01675640();
    puStack_104 = (undefined4 *)0x974a1b;
    FUN_005e65e0();
    puStack_ec = (uint *)0x974a23;
    FUN_00550b30();
    puStack_ec = (uint *)0x974a2b;
    FUN_00550b30();
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_ec = (uint *)0x974a46;
      (**(code **)*piVar2)();
      LOCK();
      iVar1 = piVar2[2] + -1;
      piVar2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puStack_ec = (uint *)0x974a5a;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
LAB_00974c99:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_ec = (uint *)0x974caf;
      (**(code **)*param_2)();
      LOCK();
      iVar1 = param_2[2] + -1;
      param_2[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puStack_ec = (uint *)0x974cbf;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_ec = (uint *)0x974cd5;
      (**(code **)*param_4)();
      LOCK();
      piVar5 = param_4 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        puStack_ec = (uint *)0x974ce4;
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x11;
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &param_9;
    puStack_ec = (uint *)0x2;
    uStack_f8 = 0x974d05;
    puStack_f0 = puStack_f4;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  if (param_14 != (int *)0x0) {
    if ((((uint)param_14 & 1) == 0) && (*(code **)((uint)param_14 & 0xfffffffe) != (code *)0x0)) {
      puStack_f4 = (undefined4 *)&stack0x00000044;
      puStack_ec = (uint *)0x2;
      uStack_f8 = 0x974d30;
      puStack_f0 = puStack_f4;
      (**(code **)((uint)param_14 & 0xfffffffe))();
    }
    param_14 = (int *)0x0;
  }
  if (0xf < in_stack_00000070) {
    puStack_ec = (uint *)(in_stack_00000070 + 1);
    puVar7 = in_stack_0000005c;
    if (0xfff < puStack_ec) {
      puVar7 = (undefined4 *)in_stack_0000005c[-1];
      puStack_ec = (uint *)(in_stack_00000070 + 0x24);
      if (0x1f < (uint)((int)in_stack_0000005c + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        puStack_ec = (uint *)&UNK_00974d7f;
        FUN_017167a3();
      }
    }
    puStack_f4 = (undefined4 *)0x974d67;
    puStack_f0 = puVar7;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17713 ; VA 0x00974d80 ; FUN_00974d80 */

void FUN_00974d80(int param_1,int param_2,uint param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 uint param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  char **ppcVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char **ppcVar5;
  char cVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  undefined auStack_294 [16];
  undefined4 uStack_284;
  undefined4 *puStack_280;
  undefined4 *puStack_27c;
  undefined4 *puStack_278;
  undefined4 auStack_274 [4];
  undefined4 uStack_264;
  undefined4 *puStack_260;
  undefined4 *puStack_25c;
  undefined4 *puStack_258;
  char *pcStack_254;
  undefined4 uStack_250;
  undefined uStack_24c;
  undefined4 uStack_244;
  undefined4 *puStack_240;
  undefined4 *puStack_23c;
  char *pcStack_238;
  undefined auStack_22c [72];
  undefined auStack_1e4 [72];
  undefined auStack_19c [72];
  undefined auStack_154 [72];
  undefined auStack_10c [72];
  undefined4 uStack_c4;
  int *piStack_c0;
  uint uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  uint uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  int *piStack_78;
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined *puStack_34;
  undefined auStack_30 [4];
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf36d;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d64730 == '\0') {
    pcStack_238 = (char *)0x974db7;
    ExceptionList = &pvStack_10;
    puStack_23c = (undefined4 *)FUN_01255560();
    pcStack_238 = (char *)0x5;
    puStack_240 = (undefined4 *)0x974dbf;
    cVar6 = FUN_01255580();
    if (cVar6 == '\0') {
      puStack_23c = (undefined4 *)auStack_30;
      pcStack_238 = "CreateCharacterModelFromUserId is not yet enabled";
      puStack_240 = (undefined4 *)0x9752d0;
      FUN_016756b0();
      puStack_23c = (undefined4 *)auStack_30;
      pcStack_238 = "";
                    /* WARNING: Subroutine does not return */
      puStack_240 = (undefined4 *)&UNK_009752e1;
      FUN_0170c2a8();
    }
  }
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_250 = 0x35;
    puStack_23c = (undefined4 *)0x0;
    pcStack_238 = (char *)0xf;
    pcStack_254 = "Players:CreateHumanoidFromUserId() got invalid userId";
    uStack_24c = 0;
    puStack_258 = (undefined4 *)0x974dfa;
    FUN_005542c0();
    uStack_250 = 0x974e02;
    FUN_005e65e0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
       (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_240 = &param_5;
      pcStack_238 = (char *)0x2;
      uStack_244 = 0x974e23;
      puStack_23c = puStack_240;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    uStack_8 = 3;
  }
  else {
    puStack_23c = (undefined4 *)0x974e3f;
    iStack_24 = FUN_00965f10();
    if (iStack_24 != 0) {
      puStack_23c = &uStack_2c;
      puStack_240 = (undefined4 *)0x974e57;
      FUN_0060e0c0();
      puStack_1c = &uStack_7c;
      puStack_34 = (undefined *)&pcStack_254;
      puStack_18 = &pcStack_254;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[2] = piStack_28[2] + 1;
        UNLOCK();
      }
      uStack_7c = uStack_2c;
      piStack_78 = piStack_28;
      uStack_8._0_1_ = 5;
      uStack_74 = 0;
      ppcVar2 = &pcStack_254;
      ppcVar5 = &pcStack_254;
      if (param_3 != 0) {
        uStack_74 = param_3;
        if ((param_3 & 1) == 0) {
          puStack_25c = &uStack_6c;
          puStack_258 = (undefined4 *)0x0;
          puStack_260 = &param_5;
          uStack_264 = 0x974ec6;
          (**(code **)(param_3 & 0xfffffffe))();
          ppcVar2 = (char **)puStack_34;
          ppcVar5 = (char **)puStack_18;
        }
        else {
          uStack_6c = param_5;
          uStack_68 = param_6;
          uStack_64 = param_7;
          uStack_60 = param_8;
          uStack_5c = param_9;
          ppcVar2 = &pcStack_254;
          ppcVar5 = &pcStack_254;
        }
      }
      puStack_18 = ppcVar5;
      puStack_34 = (undefined *)ppcVar2;
      uStack_8._0_1_ = 6;
      uStack_54 = 0;
      if (param_10 != 0) {
        uStack_54 = param_10;
        if ((param_10 & 1) == 0) {
          puStack_25c = &uStack_4c;
          puStack_258 = (undefined4 *)0x0;
          puStack_260 = &param_12;
          uStack_264 = 0x974f07;
          (**(code **)(param_10 & 0xfffffffe))();
        }
        else {
          uStack_4c = param_12;
          uStack_48 = param_13;
          uStack_44 = param_14;
          uStack_40 = param_15;
          uStack_3c = param_16;
        }
      }
      puStack_258 = &uStack_7c;
      uStack_8._0_1_ = 7;
      puStack_25c = (undefined4 *)0x974f1d;
      FUN_00967650();
      uStack_8._0_1_ = 8;
      *puStack_18 = 0;
      puStack_258 = (undefined4 *)auStack_22c;
      puStack_25c = (undefined4 *)0x974f3c;
      FUN_00967650();
      puStack_258 = (undefined4 *)auStack_1e4;
      uStack_8._0_1_ = 9;
      puStack_25c = (undefined4 *)0x974f52;
      FUN_00967650();
      puStack_258 = (undefined4 *)auStack_19c;
      uStack_8._0_1_ = 10;
      puStack_25c = (undefined4 *)0x974f68;
      FUN_00967650();
      puStack_258 = (undefined4 *)auStack_10c;
      uStack_8._0_1_ = 0xb;
      puStack_25c = (undefined4 *)0x974f78;
      cVar6 = FUN_00585a40();
      if (cVar6 == '\0') {
        puStack_258 = (undefined4 *)auStack_10c;
        puStack_25c = (undefined4 *)0x974f91;
        FUN_00967650();
        puStack_258 = (undefined4 *)0x48;
        uStack_8._0_1_ = 0xc;
        puStack_25c = (undefined4 *)0x974f9c;
        puStack_1c = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0xd;
        if (puStack_1c == (undefined4 *)0x0) {
          uVar7 = 0;
        }
        else {
          puStack_258 = (undefined4 *)auStack_154;
          puStack_25c = (undefined4 *)0x974fb8;
          uVar7 = FUN_00967650();
        }
        puStack_18[2] = uVar7;
        puStack_258 = (undefined4 *)0x974fcd;
        FUN_008e9ba0();
        puStack_258 = (undefined4 *)0x974fd8;
        FUN_008e9ba0();
        cStack_11 = '\x01';
      }
      else {
        puStack_258 = (undefined4 *)0x974fe9;
        FUN_008e9ba0();
        cStack_11 = '\0';
      }
      puStack_258 = (undefined4 *)0x974ff8;
      FUN_008e9ba0();
      ppuVar8 = &PTR_FUN_01936c74;
      if (cStack_11 == '\0') {
        ppuVar8 = (undefined **)0x0;
      }
      *puStack_18 = ppuVar8;
      puStack_258 = (undefined4 *)0x975015;
      FUN_008e9ba0();
      puStack_258 = (undefined4 *)0x975020;
      FUN_008e9ba0();
      puStack_258 = (undefined4 *)0x975028;
      FUN_008e9ba0();
      puStack_1c = auStack_274;
      puStack_18 = auStack_274;
      puStack_20 = &uStack_c4;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[2] = piStack_28[2] + 1;
        UNLOCK();
      }
      uStack_c4 = uStack_2c;
      piStack_c0 = piStack_28;
      uStack_8._0_1_ = 0xf;
      uStack_bc = 0;
      puVar3 = auStack_274;
      puVar4 = auStack_274;
      if (param_3 != 0) {
        uStack_bc = param_3;
        if ((param_3 & 1) == 0) {
          puStack_27c = &uStack_b4;
          puStack_278 = (undefined4 *)0x0;
          puStack_280 = &param_5;
          uStack_284 = 0x9750af;
          (**(code **)(param_3 & 0xfffffffe))();
          puVar3 = puStack_1c;
          puVar4 = puStack_18;
        }
        else {
          uStack_b4 = param_5;
          uStack_b0 = param_6;
          uStack_ac = param_7;
          uStack_a8 = param_8;
          uStack_a4 = param_9;
          puVar3 = auStack_274;
          puVar4 = auStack_274;
        }
      }
      puStack_18 = puVar4;
      puStack_1c = puVar3;
      uStack_8._0_1_ = 0x10;
      uStack_9c = 0;
      if (param_10 != 0) {
        uStack_9c = param_10;
        if ((param_10 & 1) == 0) {
          puStack_27c = &uStack_94;
          puStack_278 = (undefined4 *)0x0;
          puStack_280 = &param_12;
          uStack_284 = 0x9750fc;
          (**(code **)(param_10 & 0xfffffffe))();
        }
        else {
          uStack_94 = param_12;
          uStack_90 = param_13;
          uStack_8c = param_14;
          uStack_88 = param_15;
          uStack_84 = param_16;
        }
      }
      puStack_278 = &uStack_c4;
      uStack_8._0_1_ = 0x11;
      puStack_27c = (undefined4 *)0x975115;
      FUN_00967650();
      puVar3 = puStack_18;
      puStack_278 = (undefined4 *)auStack_154;
      uStack_8._0_1_ = 0x12;
      *puStack_18 = 0;
      puStack_27c = (undefined4 *)0x975134;
      FUN_00967650();
      puStack_278 = (undefined4 *)auStack_19c;
      uStack_8._0_1_ = 0x13;
      puStack_27c = (undefined4 *)0x97514a;
      FUN_00967650();
      puStack_278 = (undefined4 *)auStack_1e4;
      uStack_8._0_1_ = 0x14;
      puStack_27c = (undefined4 *)0x975160;
      FUN_00967650();
      puStack_278 = (undefined4 *)auStack_10c;
      uStack_8._0_1_ = 0x15;
      puStack_27c = (undefined4 *)0x975170;
      cVar6 = FUN_00585a40();
      if (cVar6 == '\0') {
        puStack_278 = (undefined4 *)auStack_10c;
        puStack_27c = (undefined4 *)0x975189;
        FUN_00967650();
        puStack_278 = (undefined4 *)0x48;
        uStack_8._0_1_ = 0x16;
        puStack_27c = (undefined4 *)0x975194;
        puStack_20 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0x17;
        if (puStack_20 == (undefined4 *)0x0) {
          uVar7 = 0;
        }
        else {
          puStack_278 = (undefined4 *)auStack_22c;
          puStack_27c = (undefined4 *)0x9751b0;
          uVar7 = FUN_00967650();
        }
        puVar3[2] = uVar7;
        puStack_278 = (undefined4 *)0x9751c2;
        FUN_008e9ba0();
        puStack_278 = (undefined4 *)0x9751cd;
        FUN_008e9ba0();
        cStack_11 = '\x01';
      }
      else {
        puStack_278 = (undefined4 *)0x9751de;
        FUN_008e9ba0();
        cStack_11 = '\0';
      }
      puStack_278 = (undefined4 *)0x9751ed;
      FUN_008e9ba0();
      ppuVar8 = &PTR_FUN_01936c6c;
      if (cStack_11 == '\0') {
        ppuVar8 = (undefined **)0x0;
      }
      *puVar3 = ppuVar8;
      puStack_278 = (undefined4 *)0x975207;
      FUN_008e9ba0();
      puStack_278 = (undefined4 *)0x975212;
      FUN_008e9ba0();
      puStack_278 = (undefined4 *)0x97521d;
      FUN_008e9ba0();
      puStack_278 = (undefined4 *)0x7;
      puStack_27c = (undefined4 *)0x0;
      uStack_8._0_1_ = 0x18;
      FUN_00f53dc0(auStack_294,param_1,param_2,0,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00bcb620();
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_28[2] + -1;
        piStack_28[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pcStack_238 = (char *)0x97525e;
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    if (((param_3 != 0) && ((param_3 & 1) == 0)) &&
       (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_240 = &param_5;
      pcStack_238 = (char *)0x2;
      uStack_244 = 0x97527f;
      puStack_23c = puStack_240;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    uStack_8 = 0x1a;
  }
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_240 = &param_12;
    pcStack_238 = (char *)0x2;
    uStack_244 = 0x9752ad;
    puStack_23c = puStack_240;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17714 ; VA 0x009752f0 ; FUN_009752f0 */

void FUN_009752f0(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  bool bVar9;
  int in_stack_00000014;
  uint in_stack_00000018;
  char in_stack_0000001c;
  int *in_stack_00000024;
  uint in_stack_00000028;
  uint in_stack_00000048;
  undefined auStack_16c [24];
  undefined4 uStack_154;
  undefined4 *puStack_150;
  undefined auStack_14c [16];
  undefined4 uStack_13c;
  undefined *puStack_138;
  char *pcStack_134;
  int *piStack_130;
  undefined auStack_12c [8];
  undefined4 uStack_124;
  undefined4 *puStack_120;
  int *piStack_11c;
  int *piStack_118;
  int iStack_108;
  int iStack_104;
  undefined4 auStack_100 [50];
  undefined auStack_38 [8];
  undefined *puStack_30;
  undefined *puStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf3db;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_118 = &iStack_28;
  piStack_11c = (int *)0x975324;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 4;
  if (iStack_28 == 0) {
    piStack_130 = (int *)0x3a;
    piStack_11c = (int *)0x0;
    piStack_118 = (int *)0xf;
    pcStack_134 = "Players:CreateHumanoidModelFromUserId() could not complete";
    auStack_12c[0] = 0;
    puStack_138 = (undefined *)0x975353;
    FUN_005542c0();
    piStack_130 = (int *)0x97535b;
    FUN_005e65e0();
  }
  else {
    piStack_118 = (int *)0x975365;
    iStack_108 = FUN_00888530();
    iStack_104 = 0;
    uStack_8._0_1_ = 5;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (in_stack_0000001c != '\0') {
      piStack_118 = (int *)0x0;
      piStack_11c = &iStack_108;
      puStack_120 = &param_1;
      uStack_124 = 0x975395;
      cVar5 = FUN_0098ef90();
      iVar3 = iStack_108;
      uVar4 = (undefined)uStack_8;
      if (cVar5 != '\0') {
        cStack_11 = '\x01';
        piStack_118 = (int *)0x9753af;
        iVar6 = FUN_008881d0();
        if (iVar3 != iVar6) {
          piStack_118 = (int *)0x18c072c;
                    /* WARNING: Subroutine does not return */
          piStack_11c = (int *)0x975636;
          FUN_016757c0();
        }
        puVar7 = auStack_100;
        uStack_20 = 0;
        if (iStack_104 == 0) {
          puVar7 = (undefined4 *)0x0;
        }
        iStack_1c = 0;
        iStack_1c = puVar7[1];
        if (iStack_1c != 0) {
          LOCK();
          *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
          UNLOCK();
          iStack_1c = puVar7[1];
        }
        uStack_20 = *puVar7;
        piStack_118 = (int *)&cStack_11;
        uStack_8._0_1_ = 7;
        piStack_11c = &uStack_20;
        puStack_120 = (undefined4 *)0x9753f5;
        FUN_00f8d2b0();
        bVar9 = cStack_11 != '\0';
        puStack_2c = auStack_12c;
        piStack_130 = (int *)0x1d;
        piStack_11c = (int *)0x0;
        piStack_118 = (int *)0xf;
        pcStack_134 = "CreateHumanoidModelFromUserId";
        auStack_12c[0] = 0;
        puStack_138 = (undefined *)0x975422;
        FUN_005542c0();
        puStack_30 = auStack_14c;
        uStack_8._0_1_ = 8;
        puStack_150 = &stack0x00000048;
        uStack_154 = 0x975437;
        FUN_0054f510();
        puStack_18 = auStack_16c;
        uStack_8._0_1_ = 9;
        FUN_0054f510(&stack0x00000028);
        uStack_8._0_1_ = 10;
        puVar7 = (undefined4 *)FUN_00e2ef10(auStack_38,&uStack_20,bVar9,3);
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        *puVar7 = 0;
        puVar7[1] = 0;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        uStack_8._0_1_ = 0xc;
        FUN_00974840(iStack_28,piStack_24,uVar1,uVar2);
        piStack_118 = (int *)0x9754c5;
        FUN_00550b30();
        piStack_118 = (int *)0x9754cd;
        FUN_00550b30();
        uStack_8._0_1_ = 0xd;
        if (iStack_104 != 0) {
          piStack_118 = auStack_100;
          piStack_11c = (int *)0x9754e7;
          (**(code **)(iStack_104 + 8))();
        }
        piStack_118 = (int *)0x9754f2;
        FUN_00550b30();
        goto LAB_0097556b;
      }
    }
    uStack_8._0_1_ = uVar4;
    if (in_stack_00000014 == 0) {
      piStack_130 = (int *)"of an unknown error.";
    }
    else {
      piStack_130 = (int *)&param_1;
      if (0xf < in_stack_00000018) {
        piStack_130 = param_1;
      }
    }
    puStack_138 = auStack_12c;
    pcStack_134 = "Players:CreateHumanoidModelFromUserId() failed because %s";
    uStack_13c = 0x97551d;
    FUN_01675640();
    piStack_130 = (int *)0x975528;
    FUN_005e65e0();
    uStack_8._0_1_ = 6;
    if (iStack_104 != 0) {
      piStack_118 = auStack_100;
      piStack_11c = (int *)0x975542;
      (**(code **)(iStack_104 + 8))();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_24[1] + -1;
    piStack_24[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      piStack_118 = (int *)0x97555b;
      (**(code **)*piStack_24)();
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        piStack_118 = (int *)0x97556b;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
LAB_0097556b:
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000018) {
    piStack_118 = (int *)(in_stack_00000018 + 1);
    piVar8 = param_1;
    if (0xfff < piStack_118) {
      piVar8 = (int *)param_1[-1];
      piStack_118 = (int *)(in_stack_00000018 + 0x24);
      if ((char *)0x1f < (char *)((int)param_1 + (-4 - (int)piVar8))) {
                    /* WARNING: Subroutine does not return */
        piStack_118 = (int *)&UNK_0097563b;
        FUN_017167a3();
      }
    }
    puStack_120 = (undefined4 *)0x9755a0;
    piStack_11c = piVar8;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (int *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar8 = in_stack_00000024 + 2;
    iVar3 = *piVar8;
    *piVar8 = *piVar8 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      piStack_118 = (int *)0x9755c9;
      (**(code **)(*in_stack_00000024 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (in_stack_00000028 != 0) {
    if (((in_stack_00000028 & 1) == 0) &&
       (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
      puStack_120 = (undefined4 *)&stack0x00000030;
      piStack_118 = (int *)0x2;
      uStack_124 = 0x9755ea;
      piStack_11c = puStack_120;
      (**(code **)(in_stack_00000028 & 0xfffffffe))();
    }
    in_stack_00000028 = 0;
  }
  uStack_8 = 0xf;
  if (((in_stack_00000048 != 0) && ((in_stack_00000048 & 1) == 0)) &&
     (*(code **)(in_stack_00000048 & 0xfffffffe) != (code *)0x0)) {
    puStack_120 = (undefined4 *)&stack0x00000050;
    piStack_118 = (int *)0x2;
    uStack_124 = 0x975618;
    piStack_11c = puStack_120;
    (**(code **)(in_stack_00000048 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17715 ; VA 0x00975640 ; FUN_00975640 */

int * __thiscall FUN_00975640(int *param_1,int *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int *piVar11;
  undefined4 *puVar12;
  undefined **ppuVar13;
  undefined4 in_stack_ffffff78;
  undefined4 *in_stack_ffffff7c;
  uint in_stack_ffffff80;
  undefined4 in_stack_ffffff84;
  undefined4 uVar14;
  undefined ***pppuVar15;
  undefined1 *puVar16;
  undefined4 uVar17;
  uint uVar18;
  undefined ***pppuStack_70;
  undefined ***pppuStack_6c;
  undefined ***apppuStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  undefined auStack_48 [4];
  undefined *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [8];
  code *pcStack_28;
  undefined **ppuStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf468;
  pvStack_10 = ExceptionList;
  piStack_1c = param_1;
  if (param_1[0x3d] != 0) {
    pppuStack_6c = (undefined ***)0x193603c;
    pppuStack_70 = (undefined ***)0x975fc2;
    ExceptionList = &pvStack_10;
    FUN_00550130();
    pppuStack_6c = (undefined ***)&DAT_01c17198;
    pppuStack_70 = &ppuStack_24;
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8();
  }
  pppuStack_6c = (undefined ***)&iStack_14;
  auStack_48[0] = 0;
  pppuStack_70 = (undefined ***)&boost::lock_error::vftable_meta_ptr;
  iStack_14 = 0xb;
  uVar14 = 0x97568b;
  ExceptionList = &pvStack_10;
  ppuVar5 = (undefined **)FUN_00563d40(&DAT_018be100);
  ppuVar13 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar13 = ppuVar5;
  }
  puStack_44 = *ppuVar13;
  uStack_40 = 0;
  uStack_3c = 0x3f800000;
  uStack_38 = 0;
  uStack_34 = 0;
  pppuStack_6c = (undefined ***)0x6;
  pppuStack_70 = (undefined ***)0x18c5d60;
  uStack_8 = 0;
  uStack_50 = 0;
  uStack_4c = 0xf;
  apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
  FUN_005542c0();
  pppuStack_6c = (undefined ***)apppuStack_60;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pppuStack_70 = (undefined ***)0x9756f2;
  iVar6 = FUN_005c4c00();
  pppuStack_6c = (undefined ***)0x9756f9;
  uVar7 = FUN_0088da50();
  *(undefined4 *)(iVar6 + 0x18) = uVar7;
  pppuStack_6c = (undefined ***)0x975701;
  iStack_14 = FUN_005c9e80();
  iVar8 = *(int *)(iVar6 + 0x1c);
  if (iVar8 == iStack_14) {
    *(undefined4 *)(iVar6 + 0x20) = *param_3;
    *(undefined4 *)(iVar6 + 0x24) = param_3[1];
  }
  else {
    if (iVar8 != 0) {
      pppuStack_6c = (undefined ***)(iVar6 + 0x20);
      pppuStack_70 = (undefined ***)0x975728;
      (**(code **)(iVar8 + 8))();
      *(undefined4 *)(iVar6 + 0x1c) = 0;
    }
    *(undefined4 *)(iVar6 + 0x20) = *param_3;
    *(undefined4 *)(iVar6 + 0x24) = param_3[1];
    *(int *)(iVar6 + 0x1c) = iStack_14;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_4c) {
    pppuStack_6c = (undefined ***)(uStack_4c + 1);
    pppuVar15 = apppuStack_60[0];
    if (0xfff < pppuStack_6c) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      pppuStack_6c = (undefined ***)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_6c = (undefined ***)0x975fd5;
        FUN_017167a3();
      }
    }
    pppuStack_70 = pppuVar15;
    FUN_01674ea0();
  }
  pppuStack_6c = (undefined ***)0x8;
  pppuStack_70 = (undefined ***)0x18ced1c;
  uStack_50 = 0;
  uStack_4c = 0xf;
  apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
  FUN_005542c0();
  pppuStack_6c = (undefined ***)apppuStack_60;
  uStack_8._0_1_ = 2;
  pppuStack_70 = (undefined ***)0x9757af;
  iVar8 = FUN_005c4c00();
  pppuStack_6c = (undefined ***)0x9757b6;
  uVar7 = FUN_0088cb40();
  pppuStack_6c = (undefined ***)(param_3 + 3);
  *(undefined4 *)(iVar8 + 0x18) = uVar7;
  pppuStack_70 = (undefined ***)0x9757c5;
  FUN_005c17a0();
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    pppuStack_6c = (undefined ***)(uStack_4c + 1);
    pppuVar15 = apppuStack_60[0];
    if (0xfff < pppuStack_6c) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      pppuStack_6c = (undefined ***)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_6c = (undefined ***)0x975fda;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppuStack_70 = pppuVar15;
    FUN_01674ea0();
  }
  pppuStack_6c = (undefined ***)0xb;
  pppuStack_70 = (undefined ***)0x18ced28;
  uStack_50 = 0;
  uStack_4c = 0xf;
  apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
  FUN_005542c0();
  pppuStack_6c = (undefined ***)apppuStack_60;
  uStack_8._0_1_ = 3;
  pppuStack_70 = (undefined ***)0x97582e;
  iVar8 = FUN_005c4c00();
  pppuStack_6c = (undefined ***)0x975835;
  uVar7 = FUN_0088cb40();
  pppuStack_6c = (undefined ***)(param_3 + 9);
  *(undefined4 *)(iVar8 + 0x18) = uVar7;
  pppuStack_70 = (undefined ***)0x975844;
  FUN_005c17a0();
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    pppuStack_6c = (undefined ***)(uStack_4c + 1);
    pppuVar15 = apppuStack_60[0];
    if (0xfff < pppuStack_6c) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      pppuStack_6c = (undefined ***)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_6c = (undefined ***)0x975fdf;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    pppuStack_70 = pppuVar15;
    FUN_01674ea0();
  }
  pppuStack_6c = (undefined ***)0xe;
  pppuStack_70 = (undefined ***)0x18ced0c;
  uStack_50 = 0;
  uStack_4c = 0xf;
  apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
  FUN_005542c0();
  pppuStack_6c = (undefined ***)apppuStack_60;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  pppuStack_70 = (undefined ***)0x9758ad;
  iVar6 = FUN_005c4c00();
  pppuStack_6c = (undefined ***)0x9758b4;
  uVar7 = FUN_0088daf0();
  *(undefined4 *)(iVar6 + 0x18) = uVar7;
  pppuStack_6c = (undefined ***)0x9758bc;
  iVar9 = FUN_005c9ef0();
  iVar8 = *(int *)(iVar6 + 0x1c);
  if (iVar8 == iVar9) {
    *(undefined *)(iVar6 + 0x20) = param_4._0_1_;
  }
  else {
    if (iVar8 != 0) {
      pppuStack_6c = (undefined ***)(iVar6 + 0x20);
      pppuStack_70 = (undefined ***)0x9758da;
      (**(code **)(iVar8 + 8))();
    }
    *(undefined *)(iVar6 + 0x20) = param_4._0_1_;
    *(int *)(iVar6 + 0x1c) = iVar9;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_4c) {
    pppuStack_6c = (undefined ***)(uStack_4c + 1);
    pppuVar15 = apppuStack_60[0];
    if (0xfff < pppuStack_6c) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      pppuStack_6c = (undefined ***)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_6c = (undefined ***)0x975fe4;
        FUN_017167a3();
      }
    }
    pppuStack_70 = pppuVar15;
    FUN_01674ea0();
  }
  pppuStack_6c = (undefined ***)0x975923;
  uVar7 = FUN_00ad5b20();
  pppuStack_6c = (undefined ***)0xb;
  pppuStack_70 = (undefined ***)0x18cee60;
  uStack_50 = 0;
  uStack_4c = 0xf;
  apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
  uVar17 = 0x975946;
  FUN_005542c0();
  pppuStack_6c = (undefined ***)apppuStack_60;
  uStack_8._0_1_ = 5;
  pppuStack_70 = (undefined ***)0x975956;
  iVar8 = FUN_005c4c00();
  pppuStack_6c = (undefined ***)0x97595d;
  uVar10 = FUN_0088cb40();
  *(undefined4 *)(iVar8 + 0x18) = uVar10;
  pppuStack_70 = (undefined ***)0x975969;
  pppuStack_6c = (undefined ***)uVar7;
  FUN_005c17a0();
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    pppuStack_6c = (undefined ***)(uStack_4c + 1);
    pppuVar15 = apppuStack_60[0];
    if (0xfff < pppuStack_6c) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      pppuStack_6c = (undefined ***)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_6c = (undefined ***)0x975fe9;
        uStack_8._0_1_ = uVar3;
        FUN_017167a3();
      }
    }
    uVar17 = 0x97599e;
    pppuStack_70 = pppuVar15;
    FUN_01674ea0();
  }
  piVar2 = piStack_1c;
  pppuStack_6c = (undefined ***)piStack_1c;
  pppuStack_70 = (undefined ***)0x9759aa;
  iVar8 = FUN_00671ce0();
  if (iVar8 != 0) {
    pppuStack_70 = (undefined ***)0x0;
    pppuStack_6c = (undefined ***)0xf;
    in_stack_ffffff80 = in_stack_ffffff80 & 0xffffff00;
    FUN_005542c0("Players::createLocalPlayer",0x1a);
    in_stack_ffffff7c = param_3 + 0x16;
    in_stack_ffffff78 = 0x9759e7;
    FUN_00a4c770(in_stack_ffffff7c,in_stack_ffffff80,in_stack_ffffff84,uVar14,uVar17);
    pppuStack_6c = (undefined ***)auStack_30;
    pppuStack_70 = (undefined ***)0x9759f2;
    uVar14 = FUN_00a434b0();
    pppuStack_6c = (undefined ***)0x8;
    pppuStack_70 = (undefined ***)0x18ced7c;
    uStack_8._0_1_ = 6;
    uStack_50 = 0;
    uStack_4c = 0xf;
    apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
    FUN_005542c0();
    pppuStack_70 = (undefined ***)apppuStack_60;
    uStack_8._0_1_ = 7;
    pppuStack_6c = (undefined ***)uVar14;
    FUN_005c4c00();
    pppuStack_70 = (undefined ***)0x975a32;
    FUN_00632ce0();
    pppuStack_6c = (undefined ***)0x975a3a;
    FUN_005507b0();
    uStack_8._0_1_ = 0;
    pppuStack_6c = (undefined ***)0x975a46;
    FUN_005507b0();
  }
  if ((DAT_01d646c0 != '\0') || (DAT_01d646d0 != '\0')) {
    pppuStack_6c = (undefined ***)0xe;
    pppuStack_70 = (undefined ***)0x18c5d94;
    uStack_50 = 0;
    uStack_4c = 0xf;
    apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
    FUN_005542c0();
    pppuStack_6c = (undefined ***)apppuStack_60;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    pppuStack_70 = (undefined ***)0x975a8d;
    iVar8 = FUN_005c4c00();
    pppuStack_6c = (undefined ***)0x975a94;
    uVar14 = thunk_FUN_005f32d0();
    *(undefined4 *)(iVar8 + 0x18) = uVar14;
    pppuStack_6c = (undefined ***)0x975a9c;
    param_4 = (undefined4 *)FUN_005f3850();
    puVar12 = *(undefined4 **)(iVar8 + 0x1c);
    if (puVar12 == param_4) {
      *(undefined4 *)(iVar8 + 0x20) = param_3[0xf];
    }
    else {
      if (puVar12 != (undefined4 *)0x0) {
        pppuStack_6c = (undefined ***)(iVar8 + 0x20);
        pppuStack_70 = (undefined ***)0x975abe;
        (*(code *)puVar12[2])();
        *(undefined4 *)(iVar8 + 0x1c) = 0;
      }
      *(undefined4 *)(iVar8 + 0x20) = param_3[0xf];
      *(undefined4 **)(iVar8 + 0x1c) = param_4;
    }
    uStack_8._0_1_ = 0;
    pppuStack_6c = (undefined ***)0x975ae3;
    FUN_005507b0();
  }
  uVar14 = 0x975af2;
  FUN_006369a0(&pppuStack_70,auStack_48);
  pppuVar15 = (undefined ***)0x975b00;
  piVar11 = (int *)FUN_00976100(&piStack_20);
  iVar8 = *piVar11;
  iVar6 = piVar11[1];
  *piVar11 = 0;
  piVar11[1] = 0;
  piVar2[0x3d] = iVar8;
  piVar11 = (int *)piVar2[0x3e];
  piVar2[0x3e] = iVar6;
  if (piVar11 != (int *)0x0) {
    LOCK();
    iVar8 = piVar11[1] + -1;
    piVar11[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      pppuStack_6c = (undefined ***)0x975b38;
      (**(code **)*piVar11)();
      LOCK();
      iVar8 = piVar11[2] + -1;
      piVar11[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        pppuStack_6c = (undefined ***)0x975b49;
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  piVar11 = piStack_1c;
  iVar8 = -1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar6 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pppuStack_6c = (undefined ***)0x975b60;
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar11 + 2;
      iVar6 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        pppuStack_6c = (undefined ***)0x975b71;
        iVar8 = (**(code **)(*piVar11 + 4))();
      }
    }
  }
  pppuStack_6c = (undefined ***)CONCAT31((int3)((uint)iVar8 >> 8),*(undefined *)(param_3 + 2));
  pppuStack_70 = (undefined ***)0x975b83;
  FUN_00934c50();
  DAT_01f6ea18 = *param_3;
  DAT_01f6ea1c = param_3[1];
  pppuStack_6c = (undefined ***)apppuStack_60;
  pppuStack_70 = (undefined ***)0x975b9b;
  pppuStack_6c = (undefined ***)FUN_01530500();
  pppuStack_70 = (undefined ***)piVar2[0x3d];
  uStack_8._0_1_ = 9;
  uVar18 = 0x975bb4;
  (**(code **)(*DAT_0211e99c + 0x10))();
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    uVar18 = uStack_4c + 1;
    pppuVar15 = apppuStack_60[0];
    if (0xfff < uVar18) {
      pppuVar15 = (undefined ***)apppuStack_60[0][-1];
      uVar18 = uStack_4c + 0x24;
      if (0x1f < (uint)((int)apppuStack_60[0] + (-4 - (int)pppuVar15))) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar14 = 0x975be9;
    FUN_01674ea0(pppuVar15,uVar18);
  }
  if (DAT_01d64720 == '\0') {
    FUN_00f90710(0,*param_3,param_3[1]);
    FUN_008a65e0(piVar2,0);
    FUN_008a4940(PTR_DAT_02120610);
    iVar8 = FUN_005eef10(piVar2);
    if (iVar8 == 0) {
      iVar8 = FUN_0064e920(piVar2);
      if (iVar8 != 0) {
        cVar4 = *(int *)(iVar8 + 0x124) == 2;
        goto LAB_00975dec;
      }
LAB_00975df0:
      puVar12 = (undefined4 *)FUN_00966060(auStack_18);
      piStack_20 = (int *)*puVar12;
      piStack_1c = (int *)puVar12[1];
      *puVar12 = 0;
      puVar12[1] = 0;
      uStack_8._0_1_ = 0xd;
      FUN_00550b30();
      FUN_008a65e0(piVar2[0x3d],0);
      uStack_8._0_1_ = 0;
      FUN_00550b30();
    }
    else {
      cVar4 = FUN_0068ba60();
LAB_00975dec:
      if (cVar4 == '\0') goto LAB_00975df0;
    }
    if ((((DAT_01d6420c == '\0') && (cVar4 = FUN_0091dda0(), cVar4 != '\0')) &&
        (cVar4 = FUN_00971ce0(piVar2,1), cVar4 != '\0')) &&
       (cVar4 = FUN_0097c970(piVar2,1), cVar4 != '\0')) {
      uStack_50 = 0;
      uStack_4c = 0xf;
      apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 0xe;
      goto LAB_00975e9c;
    }
  }
  else {
    FUN_01255470(9,0,0,0);
    FUN_01255490(in_stack_ffffff78,in_stack_ffffff7c,in_stack_ffffff80,uVar14,pppuVar15,uVar18);
    param_4 = param_3 + 0x28;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (DAT_01d646f8 == '\0') {
      param_4 = param_3 + 0x22;
    }
    puVar12 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar12 = (undefined4 *)*param_4;
    }
    uVar10 = 0;
    puVar16 = &DAT_018bc9b8;
    uVar14 = param_4[4];
    uVar7 = 0x975c49;
    cVar4 = FUN_0055c360(puVar12,uVar14,&DAT_018bc9b8,0);
    if (cVar4 == '\0') {
      FUN_0054ef60(param_4);
      FUN_00934090(in_stack_ffffff78,uVar7,puVar12,uVar14,puVar16,uVar10);
    }
    uStack_8._0_1_ = 0;
    FUN_01255500();
    FUN_00f90710(0,*param_3,param_3[1]);
    FUN_008a65e0(piVar2,0);
    FUN_008a4940(PTR_DAT_02120610);
    iVar8 = FUN_005eef10(piVar2);
    if (iVar8 == 0) {
      iVar8 = FUN_0064e920(piVar2);
      if (iVar8 != 0) {
        cVar4 = *(int *)(iVar8 + 0x124) == 2;
        goto LAB_00975cd0;
      }
LAB_00975cd4:
      puVar12 = (undefined4 *)FUN_00966060(auStack_18);
      piStack_20 = (int *)*puVar12;
      piStack_1c = (int *)puVar12[1];
      *puVar12 = 0;
      puVar12[1] = 0;
      uStack_8._0_1_ = 0xb;
      FUN_00550b30();
      FUN_008a65e0(piVar2[0x3d],0);
      uStack_8._0_1_ = 0;
      FUN_00550b30();
    }
    else {
      cVar4 = FUN_0068ba60();
LAB_00975cd0:
      if (cVar4 == '\0') goto LAB_00975cd4;
    }
    if (((DAT_01d6420c == '\0') && (cVar4 = FUN_0091dda0(), cVar4 != '\0')) &&
       ((cVar4 = FUN_00971ce0(piVar2,1), cVar4 != '\0' &&
        (cVar4 = FUN_0097c970(piVar2,1), cVar4 != '\0')))) {
      uStack_50 = 0;
      uStack_4c = 0xf;
      apppuStack_60[0] = (undefined ***)((uint)apppuStack_60[0] & 0xffffff00);
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 0xc;
LAB_00975e9c:
      uVar14 = FUN_005c8880(piVar2);
      FUN_009223e0(uVar14,apppuStack_60);
      uStack_8._0_1_ = 0;
      FUN_005507b0();
    }
  }
  if (DAT_01d646e0 == '\0') {
    iVar8 = FUN_005c8880(piVar2);
    if (iVar8 == 0) goto LAB_00975f6a;
    cVar4 = FUN_0064a9e0(piVar2,1);
  }
  else {
    iVar8 = FUN_008f78c0();
    if (iVar8 == 0) goto LAB_00975f6a;
    cVar4 = FUN_0064a9e0(iVar8 + 0xc,1);
  }
  if ((cVar4 == '\0') && (DAT_01d64688 != '\0')) {
    piStack_20 = piVar2;
    ppuStack_24 = (undefined **)0x0;
    pcStack_28 = FUN_00983600;
    FUN_006eccd0();
    FUN_00965af0(&param_4,&pcStack_28);
    if (param_4 != (undefined4 *)0x0) {
      piVar11 = param_4 + 1;
      LOCK();
      iVar8 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        FUN_01674ea0(param_4);
      }
    }
  }
LAB_00975f6a:
  iVar8 = piVar2[0x3e];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar8 != 0) {
    LOCK();
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
    UNLOCK();
    iVar8 = piVar2[0x3e];
  }
  *param_2 = piVar2[0x3d];
  param_2[1] = iVar8;
  FUN_0056d080();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17716 ; VA 0x00975ff0 ; FUN_00975ff0 */

undefined4 FUN_00975ff0(undefined4 param_1)

{
  undefined8 uStack_c8;
  undefined uStack_c0;
  undefined uStack_bc;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf48b;
  pvStack_10 = ExceptionList;
  uStack_c0 = 1;
  uStack_c8 = 0;
  uStack_ac = 0;
  uStack_a8 = 0xf;
  uStack_bc = 0;
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_a4 = 0;
  uStack_8c = 0;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = 0;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00975640(param_1,&uStack_c8,0);
  FUN_00637b80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17717 ; VA 0x00976100 ; FUN_00976100 */

int * __thiscall FUN_00976100(int *param_1,int *param_2,int *****param_3,int *****param_4)

{
  undefined uVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *****pppppiVar6;
  uint uVar7;
  int ****ppppiVar8;
  int *****pppppiVar9;
  undefined8 uVar10;
  char *in_stack_fffffdfc;
  uint in_stack_fffffe00;
  undefined4 uVar11;
  undefined4 uVar12;
  int *****pppppiVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  char *pcStack_1ec;
  int ****ppppiStack_1e8;
  int ****ppppiStack_1e4;
  int ****ppppiStack_1e0;
  undefined auStack_1dc [8];
  int ****ppppiStack_1d4;
  undefined auStack_1c8 [24];
  undefined auStack_1b0 [48];
  int ****appppiStack_180 [5];
  uint uStack_16c;
  undefined4 auStack_168 [5];
  uint uStack_154;
  int ***apppiStack_150 [4];
  undefined4 uStack_140;
  uint uStack_13c;
  int ***apppiStack_138 [4];
  undefined4 uStack_128;
  uint uStack_124;
  int ****appppiStack_120 [4];
  undefined4 uStack_110;
  uint uStack_10c;
  int ***apppiStack_108 [4];
  undefined4 uStack_f8;
  uint uStack_f4;
  int ***apppiStack_f0 [4];
  undefined4 uStack_e0;
  uint uStack_dc;
  uint auStack_d8 [4];
  undefined4 uStack_c8;
  uint uStack_c4;
  undefined auStack_c0 [4];
  int *piStack_bc;
  undefined auStack_b8 [4];
  int *piStack_b4;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int ****appppiStack_a4 [4];
  int iStack_94;
  uint uStack_90;
  undefined4 ****ppppuStack_8c;
  undefined4 ***pppuStack_88;
  undefined4 ***pppuStack_84;
  undefined4 ***pppuStack_80;
  undefined8 uStack_7c;
  undefined4 ****ppppuStack_74;
  undefined4 ***pppuStack_70;
  undefined4 ***pppuStack_6c;
  undefined4 ***pppuStack_68;
  undefined8 uStack_64;
  undefined4 ****appppuStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int ****appppiStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_18;
  undefined4 ****ppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf55e;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_40 = 1;
  pcStack_1ec = (char *)0x0;
  uVar14 = 0;
  uVar12 = 9;
  uVar11 = 0x976159;
  FUN_01255470(9,0,0);
  pcStack_1ec = (char *)0x976164;
  FUN_01255490();
  ppppiStack_1d4 = (int ****)auStack_b8;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  auStack_1dc._4_4_ = 0x976174;
  piVar3 = (int *)FUN_009164e0();
  iStack_a8 = *piVar3;
  iStack_ac = piVar3[1];
  *piVar3 = 0;
  piVar3[1] = 0;
  *param_2 = iStack_a8;
  piStack_18 = (int *)param_2[1];
  param_2[1] = iStack_ac;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppppiStack_1d4 = (int ****)0x9761b2;
      (**(code **)*piStack_18)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppppiStack_1d4 = (int ****)0x9761c4;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = piStack_b4;
  if (piStack_b4 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_b4[1] + -1;
    piStack_b4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      ppppiStack_1d4 = (int ****)0x9761df;
      (**(code **)*piStack_b4)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppppiStack_1d4 = (int ****)0x9761f1;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piStack_18 = (int *)*param_2;
  ppppiStack_1d4 = (int ****)0x0;
  auStack_1dc._4_4_ = 0;
  auStack_1dc._0_4_ = "UserId";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e4 = (int ****)param_3;
  ppppiStack_1e0 = (int ****)param_4;
  ppppiStack_1e8 = (int ****)0x97622e;
  join_0x00000008_0x00000000_ = FUN_0097f060();
  auStack_1dc._0_4_ = 0x976238;
  FUN_00934ca0();
  if (DAT_01d646f8 == '\0') {
    ppppiStack_1d4 = (int ****)0x18cee14;
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    auStack_1dc._0_4_ = param_3;
    auStack_1dc._4_4_ = param_4;
    ppppiStack_1e0 = (int ****)0x976321;
    cVar2 = FUN_0097ac70();
    if (cVar2 != '\0') {
      piStack_18 = (int *)*param_2;
      ppppuStack_14 = &ppppiStack_1e8;
      uVar15 = 0;
      pcStack_1ec = (char *)0xf;
      in_stack_fffffe00 = in_stack_fffffe00 & 0xffffff00;
      FUN_005542c0("Player",6);
      in_stack_fffffdfc = "AlternateName";
      if (param_4 != (int *****)0x0) {
        LOCK();
        param_4[1] = (int ****)((int)param_4[1] + 1);
        UNLOCK();
      }
      FUN_0097f2b0(ppppuStack_14,param_3,param_4,"AlternateName",in_stack_fffffe00,uVar11,uVar12,
                   uVar14,uVar15);
      goto LAB_0097638c;
    }
  }
  else {
    ppppiStack_1d4 = (int ****)0x18cee04;
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    auStack_1dc._0_4_ = param_3;
    auStack_1dc._4_4_ = param_4;
    ppppiStack_1e0 = (int ****)0x976279;
    cVar2 = FUN_0097ac70();
    if (cVar2 != '\0') {
      ppppuStack_14 = (undefined4 ****)*param_2;
      piStack_18 = (int *)&ppppiStack_1e8;
      uVar15 = 0;
      pcStack_1ec = (char *)0xf;
      in_stack_fffffe00 = in_stack_fffffe00 & 0xffffff00;
      FUN_005542c0("Player",6);
      in_stack_fffffdfc = "PlatformName";
      if (param_4 != (int *****)0x0) {
        LOCK();
        param_4[1] = (int ****)((int)param_4[1] + 1);
        UNLOCK();
      }
      FUN_0097f2b0(piStack_18,param_3,param_4,"PlatformName",in_stack_fffffe00,uVar11,uVar12,uVar14,
                   uVar15);
LAB_0097638c:
      pcStack_1ec = (char *)0x976391;
      FUN_00934090();
    }
  }
  pcStack_1ec = (char *)0x6;
  auStack_1dc._4_4_ = 0;
  ppppiStack_1d4 = (int ****)0xf;
  ppppiStack_1e8 = (int ****)((uint)ppppiStack_1e8 & 0xffffff00);
  FUN_005542c0("Player");
  pcStack_1ec = "UserName";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  FUN_0097f2b0(appppiStack_3c,param_3,param_4);
  uStack_8._0_1_ = 3;
  if (iStack_2c == 0) {
    ppppiStack_1d4 = (int ****)0x6;
    auStack_1dc._4_4_ = "Player";
    auStack_1dc._0_4_ = (int *****)0x976404;
    FUN_005542c0();
  }
  ppppiStack_1d4 = (int ****)appppiStack_3c;
  auStack_1dc._4_4_ = 0x97640f;
  (**(code **)(*(int *)*param_2 + 0x38))();
  if (DAT_01d64700 == '\0') {
    auStack_1dc._0_4_ = (int *****)0x0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    FUN_0097f2b0(appppiStack_a4,param_3,param_4,"DisplayName");
    uStack_8._0_1_ = 4;
    if (iStack_94 == 0) {
      auStack_1dc._4_4_ = iStack_2c;
      auStack_1dc._0_4_ = appppiStack_3c;
      if (0xf < uStack_28) {
        auStack_1dc._0_4_ = appppiStack_3c[0];
      }
      ppppiStack_1e0 = (int ****)0x9764be;
      FUN_005542c0();
    }
    FUN_0054ef60(appppiStack_a4);
    FUN_00933860();
    uStack_8._0_1_ = 3;
    if (0xf < uStack_90) {
      auStack_1dc._4_4_ = uStack_90 + 1;
      pppppiVar6 = (int *****)appppiStack_a4[0];
      if (0xfff < (uint)auStack_1dc._4_4_) {
        pppppiVar6 = (int *****)appppiStack_a4[0][-1];
        auStack_1dc._4_4_ = uStack_90 + 0x24;
        if (0x1f < (uint)((int)appppiStack_a4[0] + (-4 - (int)pppppiVar6))) {
                    /* WARNING: Subroutine does not return */
          auStack_1dc._4_4_ = 0x97743a;
          FUN_017167a3();
        }
      }
      ppppiStack_1e0 = (int ****)0x976513;
      auStack_1dc._0_4_ = pppppiVar6;
      FUN_01674ea0();
    }
    iStack_94 = 0;
    uStack_90 = 0xf;
    appppiStack_a4[0] = (int ****)((uint)appppiStack_a4[0] & 0xffffff00);
  }
  else {
    FUN_00558ce0(&pcStack_1ec,appppiStack_3c,&DAT_01936074);
    FUN_00933860();
  }
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_28) {
    auStack_1dc._4_4_ = uStack_28 + 1;
    pppppiVar6 = (int *****)appppiStack_3c[0];
    if (0xfff < (uint)auStack_1dc._4_4_) {
      pppppiVar6 = (int *****)appppiStack_3c[0][-1];
      auStack_1dc._4_4_ = uStack_28 + 0x24;
      if (0x1f < (uint)((int)appppiStack_3c[0] + (-4 - (int)pppppiVar6))) {
                    /* WARNING: Subroutine does not return */
        auStack_1dc._4_4_ = 0x97743f;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    ppppiStack_1e0 = (int ****)0x976566;
    auStack_1dc._0_4_ = pppppiVar6;
    FUN_01674ea0();
  }
  iStack_2c = 0;
  uStack_28 = 0xf;
  appppiStack_3c[0] = (int ****)((uint)appppiStack_3c[0] & 0xffffff00);
  uStack_8._0_1_ = 1;
  auStack_1dc._4_4_ = 0x97658a;
  FUN_01255500();
  auStack_1dc._4_4_ = 0;
  auStack_1dc._0_4_ = "AccountAge";
  ppppuStack_14 = (undefined4 ****)*param_2;
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e4 = (int ****)param_3;
  ppppiStack_1e0 = (int ****)param_4;
  ppppiStack_1e8 = (int ****)0x9765c8;
  auStack_1dc._4_4_ = FUN_0097f190();
  auStack_1dc._0_4_ = 0x9765d1;
  FUN_00932340();
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._0_4_ = 0;
  auStack_1dc._4_4_ = 0xf;
  pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  auStack_1dc._4_4_ = FUN_0097f2b0(auStack_d8,param_3,param_4,"CountryRegionCode");
  uStack_8._0_1_ = 5;
  auStack_1dc._0_4_ = 0x976640;
  FUN_009332d0();
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_c4) {
    auStack_1dc._4_4_ = uStack_c4 + 1;
    uVar7 = auStack_d8[0];
    if (0xfff < (uint)auStack_1dc._4_4_) {
      uVar7 = *(uint *)(auStack_d8[0] - 4);
      auStack_1dc._4_4_ = uStack_c4 + 0x24;
      if (0x1f < (auStack_d8[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        auStack_1dc._4_4_ = 0x977444;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    ppppiStack_1e0 = (int ****)0x97667b;
    auStack_1dc._0_4_ = uVar7;
    FUN_01674ea0();
  }
  ppppuStack_14 = (undefined4 ****)*param_2;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  auStack_d8[0] = auStack_d8[0] & 0xffffff00;
  auStack_1dc._0_4_ = 0;
  auStack_1dc._4_4_ = 0xf;
  pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  pppppiVar6 = (int *****)apppiStack_f0;
  uVar11 = 0x9766fb;
  pppppiVar13 = param_3;
  auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,"UserAgentStr");
  uStack_8._0_1_ = 6;
  auStack_1dc._0_4_ = 0x976708;
  FUN_00934c70();
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_dc) {
    auStack_1dc._4_4_ = uStack_dc + 1;
    ppppiVar8 = (int ****)apppiStack_f0[0];
    if (0xfff < (uint)auStack_1dc._4_4_) {
      ppppiVar8 = (int ****)apppiStack_f0[0][-1];
      auStack_1dc._4_4_ = uStack_dc + 0x24;
      if (0x1f < (uint)((int)apppiStack_f0[0] + (-4 - (int)ppppiVar8))) {
                    /* WARNING: Subroutine does not return */
        auStack_1dc._4_4_ = 0x977449;
        uStack_8._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    ppppiStack_1e0 = (int ****)0x976743;
    auStack_1dc._0_4_ = ppppiVar8;
    FUN_01674ea0();
  }
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._4_4_ = 0;
  auStack_1dc._0_4_ = "IsTeleportedIn";
  uStack_e0 = 0;
  uStack_dc = 0xf;
  apppiStack_f0[0] = (int ***)((uint)apppiStack_f0[0] & 0xffffff00);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e4 = (int ****)param_3;
  ppppiStack_1e0 = (int ****)param_4;
  ppppiStack_1e8 = (int ****)0x97679c;
  auStack_1dc._4_4_ = FUN_0097ef40();
  auStack_1dc._0_4_ = 0x9767a5;
  FUN_00934c20();
  if (param_1 != (int *)0x0) {
    piStack_18 = (int *)param_1[0xd];
    piVar3 = param_1;
    if ((piStack_18 != (int *)0x0) && (piVar3 = piStack_18, piStack_18[0xd] != 0)) {
      auStack_1dc._4_4_ = 0x9767c3;
      piVar3 = (int *)FUN_005c8ac0();
    }
    piStack_18 = piVar3;
    if (piStack_18 != (int *)0x0) {
      iVar5 = piStack_18[3];
      auStack_1dc._4_4_ = 0x9767dd;
      iVar4 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        auStack_1dc._4_4_ = &LAB_00605b60;
        auStack_1dc._0_4_ = &DAT_01ead2e4;
        ppppiStack_1e0 = (int ****)0x97680d;
        FUN_005789c0();
        auStack_1dc._4_4_ = 0x976815;
        auStack_1dc._4_4_ = FUN_00606020();
        auStack_1dc._0_4_ = 0x976820;
        piStack_18 = (int *)FUN_008aa140();
        if (*piStack_18 == 0) {
          auStack_1dc._4_4_ = 0x976831;
          auStack_1dc._4_4_ = FUN_00ac1050();
          auStack_1dc._0_4_ = auStack_c0;
          ppppiStack_1e0 = (int ****)0x976840;
          piVar3 = (int *)FUN_008a9ba0();
          iStack_20 = *piVar3;
          iStack_b0 = piVar3[1];
          *piVar3 = 0;
          piVar3[1] = 0;
          *piStack_18 = iStack_20;
          piVar3 = (int *)piStack_18[1];
          piStack_18[1] = iStack_b0;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar5 = piVar3[1] + -1;
            piVar3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              auStack_1dc._4_4_ = 0x97687a;
              (**(code **)*piVar3)();
              LOCK();
              iVar5 = piVar3[2] + -1;
              piVar3[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                auStack_1dc._4_4_ = 0x97688b;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          if (piStack_bc != (int *)0x0) {
            LOCK();
            iVar5 = piStack_bc[1] + -1;
            piStack_bc[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              auStack_1dc._4_4_ = 0x9768a8;
              (**(code **)*piStack_bc)();
              LOCK();
              iVar5 = piStack_bc[2] + -1;
              piStack_bc[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                auStack_1dc._4_4_ = 0x9768b9;
                (**(code **)(*piStack_bc + 4))();
              }
            }
          }
        }
        ppppuStack_14 = (undefined4 ****)*piStack_18;
        if (ppppuStack_14 != (undefined4 ****)0x0) {
          auStack_1dc._0_4_ = 0;
          auStack_1dc._4_4_ = 0xf;
          pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
          FUN_005542c0(&DAT_018bc9b8,0);
          if (param_4 != (int *****)0x0) {
            LOCK();
            param_4[1] = (int ****)((int)param_4[1] + 1);
            UNLOCK();
          }
          pppppiVar6 = (int *****)apppiStack_108;
          uVar11 = 0x976926;
          pppppiVar13 = param_3;
          auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,"RawJoinData");
          auStack_1dc._0_4_ = param_2;
          uStack_8._0_1_ = 7;
          ppppiStack_1e0 = (int ****)0x976937;
          FUN_00ad8c60();
          uStack_8._0_1_ = 1;
          uVar1 = (undefined)uStack_8;
          uStack_8._0_1_ = 1;
          if (0xf < uStack_f4) {
            auStack_1dc._4_4_ = uStack_f4 + 1;
            ppppiVar8 = (int ****)apppiStack_108[0];
            if (0xfff < (uint)auStack_1dc._4_4_) {
              ppppiVar8 = (int ****)apppiStack_108[0][-1];
              auStack_1dc._4_4_ = uStack_f4 + 0x24;
              if (0x1f < (uint)((int)apppiStack_108[0] + (-4 - (int)ppppiVar8))) {
                    /* WARNING: Subroutine does not return */
                auStack_1dc._4_4_ = 0x97744e;
                uStack_8._0_1_ = uVar1;
                FUN_017167a3();
              }
            }
            ppppiStack_1e0 = (int ****)0x976972;
            auStack_1dc._0_4_ = ppppiVar8;
            FUN_01674ea0();
          }
          uStack_f8 = 0;
          uStack_f4 = 0xf;
          apppiStack_108[0] = (int ***)((uint)apppiStack_108[0] & 0xffffff00);
        }
      }
    }
  }
  auStack_1dc._4_4_ = "LocaleId";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e0 = (int ****)param_3;
  auStack_1dc._0_4_ = param_4;
  ppppiStack_1e4 = (int ****)0x9769c9;
  cVar2 = FUN_0097ac70();
  if (cVar2 == '\0') {
    if (DAT_01d64668 == '\0') goto LAB_00976aae;
    if (DAT_01d646e8 == '\0') {
      auStack_1dc._0_4_ = 0x976a6d;
      auStack_1dc._4_4_ = param_1;
      iVar5 = FUN_005c8880();
      if (iVar5 == 0) goto LAB_00976aae;
      auStack_1dc._4_4_ = 1;
      ppppiStack_1e0 = (int ****)0x976a7c;
      auStack_1dc._0_4_ = param_1;
      cVar2 = FUN_0068a900();
    }
    else {
      auStack_1dc._0_4_ = 0x976a48;
      auStack_1dc._4_4_ = param_1;
      iVar5 = FUN_008f78c0();
      if (iVar5 == 0) goto LAB_00976aae;
      auStack_1dc._0_4_ = iVar5 + 0xc;
      auStack_1dc._4_4_ = 1;
      ppppiStack_1e0 = (int ****)0x976a5a;
      cVar2 = FUN_0068a900();
    }
    if (cVar2 != '\0') goto LAB_00976aae;
    auStack_1dc._0_4_ = (int *****)0x0;
    auStack_1dc._4_4_ = (char *)0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    pppppiVar13 = (int *****)0x976aa7;
    FUN_005542c0("virtual",7);
  }
  else {
    ppppuStack_14 = (undefined4 ****)&pcStack_1ec;
    uVar12 = 0;
    uVar14 = 0xf;
    in_stack_fffffdfc = (char *)((uint)in_stack_fffffdfc & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    FUN_0097f2b0(ppppuStack_14,param_3,param_4,"LocaleId",in_stack_fffffdfc,uVar11,pppppiVar6,
                 pppppiVar13,uVar12,uVar14);
  }
  FUN_00933bf0();
LAB_00976aae:
  auStack_1dc._4_4_ = "LocaleIdInternal";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e0 = (int ****)param_3;
  auStack_1dc._0_4_ = param_4;
  ppppiStack_1e4 = (int ****)0x976ae2;
  cVar2 = FUN_0097ac70();
  if (cVar2 != '\0') {
    ppppuStack_14 = (undefined4 ****)*param_2;
    auStack_1dc._0_4_ = 0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    pppppiVar6 = appppiStack_120;
    uVar11 = 0x976b4f;
    pppppiVar13 = param_3;
    auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,"LocaleIdInternal");
    uStack_8._0_1_ = 8;
    auStack_1dc._0_4_ = (int *****)0x976b5c;
    FUN_00933d30();
    uStack_8._0_1_ = 1;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_10c) {
      auStack_1dc._4_4_ = uStack_10c + 1;
      pppppiVar9 = (int *****)appppiStack_120[0];
      if ((char *)0xfff < (uint)auStack_1dc._4_4_) {
        pppppiVar9 = (int *****)appppiStack_120[0][-1];
        auStack_1dc._4_4_ = uStack_10c + 0x24;
        if (0x1f < (uint)((int)appppiStack_120[0] + (-4 - (int)pppppiVar9))) {
                    /* WARNING: Subroutine does not return */
          auStack_1dc._4_4_ = 0x977453;
          uStack_8._0_1_ = uVar1;
          FUN_017167a3();
        }
      }
      ppppiStack_1e0 = (int ****)0x976b97;
      auStack_1dc._0_4_ = pppppiVar9;
      FUN_01674ea0();
    }
    uStack_110 = 0;
    uStack_10c = 0xf;
    appppiStack_120[0] = (int ****)((uint)appppiStack_120[0] & 0xffffff00);
  }
  piStack_18 = (int *)*param_2;
  ppppuStack_14 = (undefined4 ****)&pcStack_1ec;
  uVar12 = 0;
  uVar14 = 0xf;
  uVar7 = (uint)in_stack_fffffdfc & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  FUN_0097f2b0(ppppuStack_14,param_3,param_4,"OsPlatform",uVar7,uVar11,pppppiVar6,pppppiVar13,uVar12
               ,uVar14);
  FUN_00934020();
  auStack_1dc._4_4_ = "Locale2Id";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e0 = (int ****)param_3;
  auStack_1dc._0_4_ = param_4;
  ppppiStack_1e4 = (int ****)0x976c63;
  ppppuStack_14 = (undefined4 ****)auStack_1dc._4_4_;
  cVar2 = FUN_0097ac70();
  if (cVar2 != '\0') {
    piStack_18 = (int *)*param_2;
    auStack_1dc._0_4_ = 0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    pppppiVar6 = (int *****)apppiStack_138;
    uVar11 = 0x976ccb;
    pppppiVar13 = param_3;
    auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,ppppuStack_14);
    uStack_8._0_1_ = 9;
    auStack_1dc._0_4_ = 0x976cd8;
    FUN_009331c0();
    uStack_8._0_1_ = 1;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_124) {
      auStack_1dc._4_4_ = uStack_124 + 1;
      ppppiVar8 = (int ****)apppiStack_138[0];
      if (0xfff < (uint)auStack_1dc._4_4_) {
        ppppiVar8 = (int ****)apppiStack_138[0][-1];
        auStack_1dc._4_4_ = uStack_124 + 0x24;
        if (0x1f < (uint)((int)apppiStack_138[0] + (-4 - (int)ppppiVar8))) {
                    /* WARNING: Subroutine does not return */
          auStack_1dc._4_4_ = 0x977458;
          uStack_8._0_1_ = uVar1;
          FUN_017167a3();
        }
      }
      ppppiStack_1e0 = (int ****)0x976d13;
      auStack_1dc._0_4_ = ppppiVar8;
      FUN_01674ea0();
    }
    uStack_128 = 0;
    uStack_124 = 0xf;
    apppiStack_138[0] = (int ***)((uint)apppiStack_138[0] & 0xffffff00);
  }
  auStack_1dc._4_4_ = "Locale2IdRef";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e0 = (int ****)param_3;
  auStack_1dc._0_4_ = param_4;
  ppppiStack_1e4 = (int ****)0x976d73;
  ppppuStack_14 = (undefined4 ****)auStack_1dc._4_4_;
  cVar2 = FUN_0097ac70();
  if (cVar2 != '\0') {
    piStack_18 = (int *)*param_2;
    auStack_1dc._0_4_ = 0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    pppppiVar6 = (int *****)apppiStack_150;
    uVar11 = 0x976ddb;
    pppppiVar13 = param_3;
    auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,ppppuStack_14);
    uStack_8._0_1_ = 10;
    auStack_1dc._0_4_ = 0x976de8;
    FUN_00933160();
    uStack_8._0_1_ = 1;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_13c) {
      auStack_1dc._4_4_ = uStack_13c + 1;
      ppppiVar8 = (int ****)apppiStack_150[0];
      if (0xfff < (uint)auStack_1dc._4_4_) {
        ppppiVar8 = (int ****)apppiStack_150[0][-1];
        auStack_1dc._4_4_ = uStack_13c + 0x24;
        if (0x1f < (uint)((int)apppiStack_150[0] + (-4 - (int)ppppiVar8))) {
                    /* WARNING: Subroutine does not return */
          auStack_1dc._4_4_ = 0x97745d;
          uStack_8._0_1_ = uVar1;
          FUN_017167a3();
        }
      }
      ppppiStack_1e0 = (int ****)0x976e23;
      auStack_1dc._0_4_ = ppppiVar8;
      FUN_01674ea0();
    }
    uStack_140 = 0;
    uStack_13c = 0xf;
    apppiStack_150[0] = (int ***)((uint)apppiStack_150[0] & 0xffffff00);
  }
  auStack_1dc._4_4_ = "Locale2Info";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e0 = (int ****)param_3;
  auStack_1dc._0_4_ = param_4;
  ppppiStack_1e4 = (int ****)0x976e83;
  ppppuStack_14 = (undefined4 ****)auStack_1dc._4_4_;
  cVar2 = FUN_0097ac70();
  if (cVar2 != '\0') {
    piStack_18 = (int *)*param_2;
    auStack_1dc._0_4_ = 0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    pppppiVar6 = appppiStack_180;
    uVar11 = 0x976eeb;
    pppppiVar13 = param_3;
    auStack_1dc._4_4_ = FUN_0097f2b0(pppppiVar6,param_3,param_4,ppppuStack_14);
    uStack_8._0_1_ = 0xb;
    auStack_1dc._0_4_ = (int *****)0x976ef8;
    FUN_00933100();
    uStack_8._0_1_ = 1;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_16c) {
      auStack_1dc._4_4_ = uStack_16c + 1;
      pppppiVar9 = (int *****)appppiStack_180[0];
      if ((char *)0xfff < (uint)auStack_1dc._4_4_) {
        pppppiVar9 = (int *****)appppiStack_180[0][-1];
        auStack_1dc._4_4_ = uStack_16c + 0x24;
        if (0x1f < (uint)((int)appppiStack_180[0] + (-4 - (int)pppppiVar9))) {
                    /* WARNING: Subroutine does not return */
          auStack_1dc._4_4_ = 0x977462;
          uStack_8._0_1_ = uVar1;
          FUN_017167a3();
        }
      }
      ppppiStack_1e0 = (int ****)0x976f33;
      auStack_1dc._0_4_ = pppppiVar9;
      FUN_01674ea0();
    }
  }
  piStack_18 = (int *)*param_2;
  ppppuStack_14 = (undefined4 ****)&pcStack_1ec;
  uVar12 = 0;
  uVar14 = 0xf;
  uVar7 = uVar7 & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  FUN_0097f2b0(ppppuStack_14,param_3,param_4,"VrDevice",uVar7,uVar11,pppppiVar6,pppppiVar13,uVar12,
               uVar14);
  FUN_00934d30();
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._4_4_ = 1;
  auStack_1dc._0_4_ = "SuperSafeChat";
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e4 = (int ****)param_3;
  ppppiStack_1e0 = (int ****)param_4;
  ppppiStack_1e8 = (int ****)0x976fdd;
  auStack_1dc._4_4_ = FUN_0097ef40();
  auStack_1dc._0_4_ = 0x976fe6;
  FUN_00934910();
  uStack_7c = 0xf00000000;
  ppppuStack_8c = (undefined4 ****)((uint)ppppuStack_8c & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  auStack_1dc._0_4_ = 0;
  auStack_1dc._4_4_ = 0xf;
  pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
  FUN_005542c0(&DAT_0192ff80,4);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppuStack_14 = (undefined4 ****)FUN_0097f2b0(auStack_168,param_3,param_4,"MembershipType");
  if (&ppppuStack_8c != (undefined4 *****)ppppuStack_14) {
    auStack_1dc._4_4_ = 0x97706e;
    FUN_005507b0();
    ppppuStack_8c = (undefined4 ****)*ppppuStack_14;
    pppuStack_88 = ppppuStack_14[1];
    pppuStack_84 = ppppuStack_14[2];
    pppuStack_80 = ppppuStack_14[3];
    uStack_7c = *(undefined8 *)(ppppuStack_14 + 4);
    ppppuStack_14[4] = (undefined4 ****)0x0;
    ppppuStack_14[5] = (undefined4 ****)0xf;
    *(undefined *)ppppuStack_14 = 0;
  }
  if (0xf < uStack_154) {
    auStack_1dc._4_4_ = uStack_154 + 1;
    auStack_1dc._0_4_ = auStack_168[0];
    ppppiStack_1e0 = (int ****)0x9770b4;
    FUN_00554a20();
  }
  auStack_1dc._4_4_ = 0x9770b9;
  FUN_005f32d0();
  auStack_1dc._4_4_ = &uStack_44;
  auStack_1dc._0_4_ = &ppppuStack_8c;
  if (0xf < uStack_7c._4_4_) {
    auStack_1dc._0_4_ = ppppuStack_8c;
  }
  ppppiStack_1e0 = (int ****)0x9770d6;
  FUN_009cb180();
  auStack_1dc._4_4_ = uStack_44;
  auStack_1dc._0_4_ = 0x9770e0;
  FUN_00933eb0();
  uStack_64 = 0xf00000000;
  ppppuStack_74 = (undefined4 ****)((uint)ppppuStack_74 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  auStack_1dc._0_4_ = 0;
  auStack_1dc._4_4_ = 0xf;
  pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
  FUN_005542c0("NoOne",5);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppuStack_14 = (undefined4 ****)FUN_0097f2b0(auStack_1b0,param_3,param_4,"GameChatType");
  if (&ppppuStack_74 != (undefined4 *****)ppppuStack_14) {
    auStack_1dc._4_4_ = 0x977162;
    FUN_005507b0();
    ppppuStack_74 = (undefined4 ****)*ppppuStack_14;
    pppuStack_70 = ppppuStack_14[1];
    pppuStack_6c = ppppuStack_14[2];
    pppuStack_68 = ppppuStack_14[3];
    uStack_64 = *(undefined8 *)(ppppuStack_14 + 4);
    ppppuStack_14[4] = (undefined4 ****)0x0;
    ppppuStack_14[5] = (undefined4 ****)0xf;
    *(undefined *)ppppuStack_14 = 0;
  }
  auStack_1dc._4_4_ = 0x977192;
  FUN_005507b0();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaaa74) {
    auStack_1dc._4_4_ = &DAT_01eaaa74;
    auStack_1dc._0_4_ = 0x97746c;
    FUN_016f3809();
    if (DAT_01eaaa74 == -1) {
      uStack_8._0_1_ = 0xe;
      auStack_1dc._4_4_ = 0x97748a;
      FUN_00918850();
      auStack_1dc._4_4_ = &LAB_0187c080;
      auStack_1dc._0_4_ = 0x977494;
      FUN_016f3654();
      auStack_1dc._0_4_ = &DAT_01eaaa74;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      ppppiStack_1e0 = (int ****)0x9774a2;
      FUN_016f37bf();
    }
  }
  auStack_1dc._4_4_ = &uStack_24;
  auStack_1dc._0_4_ = &ppppuStack_74;
  if (0xf < uStack_64._4_4_) {
    auStack_1dc._0_4_ = ppppuStack_74;
  }
  ppppiStack_1e0 = (int ****)0x9771cc;
  FUN_009cb180();
  auStack_1dc._4_4_ = uStack_24;
  auStack_1dc._0_4_ = 0x9771d6;
  FUN_009330e0();
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._4_4_ = 0;
  if (DAT_01d64708 == '\0') {
    auStack_1dc._0_4_ = "CharacterAppearanceId";
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    ppppiStack_1e4 = (int ****)param_3;
    ppppiStack_1e0 = (int ****)param_4;
    ppppiStack_1e8 = (int ****)0x977258;
    iVar5 = FUN_0097f190();
    auStack_1dc = (undefined  [8])(longlong)iVar5;
  }
  else {
    auStack_1dc._0_4_ = 0;
    ppppiStack_1e0 = (int ****)0x18cee24;
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    ppppiStack_1e8 = (int ****)param_3;
    ppppiStack_1e4 = (int ****)param_4;
    pcStack_1ec = (char *)0x97721c;
    auStack_1dc = (undefined  [8])FUN_0097f060();
  }
  ppppiStack_1e0 = (int ****)0x977263;
  FUN_00932ed0();
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._0_4_ = 0;
  auStack_1dc._4_4_ = 0xf;
  pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
  FUN_005542c0(&DAT_018bc9b8,0);
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  auStack_1dc._4_4_ = FUN_0097f2b0(auStack_1c8,param_3,param_4,"CharacterAppearance");
  uStack_8._0_1_ = 0xf;
  auStack_1dc._0_4_ = 0x9772d2;
  FUN_00932e60();
  uStack_8._0_1_ = 0xd;
  auStack_1dc._4_4_ = 0x9772e1;
  FUN_005507b0();
  ppppuStack_14 = (undefined4 ****)*param_2;
  auStack_1dc._4_4_ = 0;
  auStack_1dc._0_4_ = (undefined4 *****)0x0;
  ppppiStack_1e0 = (int ****)0x18cee50;
  if (param_4 != (int *****)0x0) {
    LOCK();
    param_4[1] = (int ****)((int)param_4[1] + 1);
    UNLOCK();
  }
  ppppiStack_1e8 = (int ****)param_3;
  ppppiStack_1e4 = (int ****)param_4;
  pcStack_1ec = (char *)0x97731e;
  uVar10 = FUN_0097f060();
  *(undefined8 *)((int)ppppuStack_14 + 0x2f8) = uVar10;
  if (DAT_01d64728 != '\0') {
    auStack_1dc._0_4_ = (undefined4 *****)0x0;
    auStack_1dc._4_4_ = 0xf;
    pcStack_1ec = (char *)((uint)pcStack_1ec & 0xffffff00);
    FUN_005542c0(&DAT_018bc9b8,0);
    if (param_4 != (int *****)0x0) {
      LOCK();
      param_4[1] = (int ****)((int)param_4[1] + 1);
      UNLOCK();
    }
    FUN_0097f2b0(appppuStack_5c,param_3,param_4,"DebugGameId");
    uStack_8._0_1_ = 0x10;
    if (iStack_4c != 0) {
      auStack_1dc._4_4_ = iStack_4c;
      auStack_1dc._0_4_ = appppuStack_5c;
      if (0xf < uStack_48) {
        auStack_1dc._0_4_ = appppuStack_5c[0];
      }
      ppppiStack_1e0 = (int ****)0x9773b6;
      FUN_005542c0();
      auStack_1dc._0_4_ = (undefined4 *****)0x9773bc;
      auStack_1dc._4_4_ = param_1;
      iVar5 = FUN_008f7870();
      if ((undefined4 *****)(iVar5 + 0x288) != appppuStack_5c) {
        auStack_1dc._4_4_ = iStack_4c;
        auStack_1dc._0_4_ = appppuStack_5c;
        if (0xf < uStack_48) {
          auStack_1dc._0_4_ = appppuStack_5c[0];
        }
        ppppiStack_1e0 = (int ****)0x9773dd;
        FUN_005542c0();
      }
    }
    auStack_1dc._4_4_ = 0x9773e5;
    FUN_005507b0();
  }
  auStack_1dc._4_4_ = 0x9773ed;
  FUN_005507b0();
  auStack_1dc._4_4_ = 0x9773f8;
  FUN_005507b0();
  if (param_4 != (int *****)0x0) {
    LOCK();
    ppppiVar8 = (int ****)((int)param_4[1] + -1);
    param_4[1] = ppppiVar8;
    UNLOCK();
    if (ppppiVar8 == (int ****)0x0) {
      auStack_1dc._4_4_ = 0x97740f;
      (*(code *)**param_4)();
      LOCK();
      pppppiVar6 = param_4 + 2;
      ppppiVar8 = *pppppiVar6;
      *pppppiVar6 = (int ****)((int)*pppppiVar6 + -1);
      UNLOCK();
      if (ppppiVar8 == (int ****)0x1) {
        auStack_1dc._4_4_ = 0x977421;
        (*(code *)(*param_4)[1])();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17718 ; VA 0x009774b0 ; FUN_009774b0 */

void FUN_009774b0(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6,undefined4 param_7)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined *puVar5;
  undefined8 uVar6;
  undefined auStack_48 [24];
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar2 = param_1;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf598;
  pvStack_10 = ExceptionList;
  if (((*(char *)(param_1 + 0xa0) == '\0') && (param_6 != 0)) && (0 < DAT_01ee2fc0)) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    iStack_8 = 0;
    param_1 = CONCAT31(param_1._1_3_,(char)(param_6 >> 1)) & 0xffffff01;
    uStack_18 = CONCAT31(uStack_18._1_3_,(char)param_6) & 0xffffff01;
    uStack_14 = CONCAT31(uStack_14._1_3_,(char)(param_6 >> 2)) & 0xffffff01;
    FUN_0151fa60("joinStatus",param_7);
    FUN_0151fcf0("multipleJoins",param_1);
    FUN_0151fcf0("similarUserId",uStack_14);
    FUN_0151fcf0("equalUuid",uStack_18);
    uVar3 = FUN_00927ca0(0,0);
    uVar3 = FUN_006b1620(auStack_48,uVar3);
    iStack_8._0_1_ = 1;
    FUN_0151f950(&DAT_019366f4,uVar3);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
    FUN_0151f950(&DAT_019366f8,param_3);
    if (DAT_01d646d8 == '\0') {
      FUN_0151fbb0("originalUserId",param_4,param_5);
    }
    uVar6 = FUN_00928340();
    FUN_0151fbb0("currentUserId",uVar6);
    FUN_0151f9c0("playerCount",(*(int **)(iVar2 + 0xb8))[1] - **(int **)(iVar2 + 0xb8) >> 3);
    FUN_0151f9c0("maxPlayers",*(undefined4 *)(iVar2 + 0xe4));
    iVar1 = DAT_01ee2fc0;
    if (DAT_01d646d8 == '\0') {
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("SuspiciousJoins",0xf);
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      FUN_01520d20(auStack_30,iVar1,0);
    }
    else {
      piVar4 = (int *)FUN_0065b150(param_2);
      if (piVar4 == (int *)0x0) {
        puVar5 = &DAT_018d743c;
      }
      else {
        uVar3 = (**(code **)(*piVar4 + 0x214))();
        puVar5 = (undefined *)FUN_005f2c00(uVar3);
      }
      FUN_0054eff0(puVar5);
      iStack_8._0_1_ = 2;
      FUN_0151f950("platform",auStack_48);
      iVar1 = DAT_01ee2fc0;
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0("SuspiciousJoins2",0x10);
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      FUN_01520d20(auStack_30,iVar1,0);
      FUN_005507b0();
    }
    FUN_005507b0();
    *(undefined *)(iVar2 + 0xa0) = 1;
    FUN_0151f7f0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17719 ; VA 0x00977710 ; FUN_00977710 */

undefined4 * __thiscall FUN_00977710(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  longlong lVar8;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [12];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf5d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870(param_1);
  if (*(int *)(iVar4 + 0x4a0) != 2) {
    FUN_00550130("createServerPlayer should only be called from the server side!");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00976100(&piStack_30,*param_3,param_3[1]);
  uStack_8 = 0;
  lVar8 = FUN_00928340();
  if (lVar8 == 0) {
LAB_009777e8:
    piVar5 = (int *)piStack_30[10];
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar3 = FUN_0055c360(piVar5,*piVar1,"Player",6);
    if (cVar3 != '\0') {
      FUN_01255470(9,0,0,0);
      FUN_01255490();
      uStack_8._0_1_ = 1;
      iVar4 = *piStack_30;
      *(int *)(param_1 + 0xec) = *(int *)(param_1 + 0xec) + 1;
      pcVar2 = *(code **)(iVar4 + 0x38);
      uVar6 = FUN_01675640(auStack_28,"Player%d",*(undefined4 *)(param_1 + 0xec));
      uStack_8._0_1_ = 2;
      (*pcVar2)(uVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
      lVar8 = FUN_00928340();
      if (lVar8 == 0) {
        *(int *)(param_1 + 0xf0) = *(int *)(param_1 + 0xf0) + -1;
        FUN_00934ca0(*(int *)(param_1 + 0xf0),*(int *)(param_1 + 0xf0) >> 0x1f);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      FUN_01255500();
    }
  }
  else if (DAT_01d646e0 == '\0') {
    iVar4 = FUN_005c8880(param_1);
    if (iVar4 != 0) {
      cVar3 = FUN_0064a9e0(param_1,1);
      goto joined_r0x009777e2;
    }
  }
  else {
    iVar4 = FUN_008f78c0();
    if (iVar4 != 0) {
      cVar3 = FUN_0064a9e0(iVar4 + 0xc,1);
joined_r0x009777e2:
      if (cVar3 == '\0') goto LAB_009777e8;
    }
  }
  iVar4 = FUN_005eef10(param_1);
  if (iVar4 == 0) {
    iVar4 = FUN_0064e920(param_1);
    if (iVar4 != 0) {
      cVar3 = *(int *)(iVar4 + 0x124) == 2;
      goto LAB_009778c9;
    }
  }
  else {
    cVar3 = FUN_0068ba60();
LAB_009778c9:
    if (cVar3 != '\0') goto LAB_00977956;
  }
  puVar7 = (undefined4 *)FUN_00966060(auStack_40);
  uStack_18 = *puVar7;
  piVar1 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  uStack_8._0_1_ = 3;
  piStack_14 = piVar1;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  FUN_008a65e0(piStack_30,0);
  uStack_8 = (uint)uStack_8._1_3_ << 8;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
LAB_00977956:
  FUN_00915f80(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_008a65e0(piStack_30,0);
  piVar1 = piStack_30;
  piStack_30 = (int *)0x0;
  *param_2 = piVar1;
  param_2[1] = piStack_2c;
  piStack_2c = (int *)0x0;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar4 = piStack_34[2] + -1;
      piStack_34[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
    piVar1 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar5 = piVar1 + 2;
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17720 ; VA 0x00977a10 ; FUN_00977a10 */

undefined4 * __thiscall FUN_00977a10(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  longlong lVar8;
  undefined auStack_48 [8];
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [12];
  undefined auStack_2c [4];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf620;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870(param_1);
  if (*(int *)(iVar4 + 0x4a0) != 2) {
    FUN_00550130("createServerPlayer should only be called from the server side!");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8 = 0;
  cVar3 = FUN_0098f070(param_3,&uStack_20,0);
  if (cVar3 == '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    piVar1 = piStack_1c;
    goto joined_r0x00977ca0;
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
  }
  FUN_00976100(&piStack_18,uStack_20,piStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  lVar8 = FUN_00928340();
  if ((lVar8 == 0) || (cVar3 = FUN_0097c970(param_1,1), cVar3 != '\0')) {
    piVar5 = (int *)piStack_18[10];
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar3 = FUN_0055c360(piVar5,*piVar1,"Player",6);
    if (cVar3 != '\0') {
      FUN_01255470(9,0,0,0);
      FUN_01255490();
      uStack_8._0_1_ = 2;
      iVar4 = *piStack_18;
      *(int *)(param_1 + 0xec) = *(int *)(param_1 + 0xec) + 1;
      pcVar2 = *(code **)(iVar4 + 0x38);
      uVar6 = FUN_01675640(auStack_38,"Player%d",*(undefined4 *)(param_1 + 0xec));
      uStack_8._0_1_ = 3;
      (*pcVar2)(uVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      lVar8 = FUN_00928340();
      if (lVar8 == 0) {
        *(int *)(param_1 + 0xf0) = *(int *)(param_1 + 0xf0) + -1;
        FUN_00934ca0(*(int *)(param_1 + 0xf0),*(int *)(param_1 + 0xf0) >> 0x1f);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_01255500();
    }
  }
  iVar4 = FUN_005eef10(param_1);
  if (iVar4 == 0) {
    iVar4 = FUN_0064e920(param_1);
    if (iVar4 != 0) {
      cVar3 = *(int *)(iVar4 + 0x124) == 2;
      goto LAB_00977bc7;
    }
LAB_00977bcb:
    puVar7 = (undefined4 *)FUN_00966060(auStack_48);
    uStack_28 = *puVar7;
    uStack_24 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    uStack_8._0_1_ = 4;
    FUN_00550b30();
    FUN_008a65e0(piStack_18,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  else {
    cVar3 = FUN_0068ba60();
LAB_00977bc7:
    if (cVar3 == '\0') goto LAB_00977bcb;
  }
  FUN_00915f80(auStack_40);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a65e0(piStack_18,0);
  piVar1 = piStack_18;
  piStack_18 = (int *)0x0;
  *param_2 = piVar1;
  param_2[1] = piStack_14;
  piStack_14 = (int *)0x0;
  piVar1 = piStack_1c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    piVar5 = piStack_14;
    piVar1 = piStack_1c;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        piVar1 = piStack_1c;
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
          piVar1 = piStack_1c;
        }
      }
    }
  }
joined_r0x00977ca0:
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_1c = piVar1;
      (**(code **)*piVar1)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17721 ; VA 0x00977d00 ; FUN_00977d00 */

void FUN_00977d00(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x4c;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 17722 ; VA 0x00977d40 ; FUN_00977d40 */

void __thiscall FUN_00977d40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar2);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_0088cb40();
    iStack_288 = 0;
    FUN_0054ef60(iVar2);
    iStack_288 = FUN_005c9d30();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17723 ; VA 0x00978080 ; FUN_00978080 */

void __thiscall
FUN_00978080(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf757;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088da50();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_ec = thunk_FUN_005f32d0();
    iStack_e8 = 0;
    uStack_e4 = *puVar5;
    iStack_e8 = FUN_005f3850();
    puVar5 = &uStack_ec;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar3 = thunk_FUN_005f32d0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x50);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    uStack_28c = FUN_0088daf0();
    iStack_288 = 0;
    auStack_284[0] = *puVar2;
    iStack_288 = FUN_005c9ef0();
    puVar5 = &uStack_28c;
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x100) != 0) && (uStack_8 = 0x13, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17724 ; VA 0x00978590 ; FUN_00978590 */

void __thiscall FUN_00978590(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088da50();
    iStack_e8 = 0;
    uStack_e4 = *puVar3;
    uStack_e0 = puVar3[1];
    iStack_e8 = FUN_005c9e80();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = thunk_FUN_005f3510();
    iStack_e8 = 0;
    uStack_e4 = *puVar3;
    iStack_e8 = FUN_005f39a0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = thunk_FUN_005f3510();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_28c = thunk_FUN_005f3480();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005f3930();
    puVar3 = &uStack_28c;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = thunk_FUN_005f3480();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17725 ; VA 0x009788b0 ; FUN_009788b0 */

void __thiscall FUN_009788b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cdc0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar4;
    uStack_e0 = puVar4[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = thunk_FUN_0098d050();
    iStack_e8 = 0;
    uStack_e4 = *puVar4;
    iStack_e8 = FUN_0098d150();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_0098d050();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = thunk_FUN_0098cfc0();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_0098d0e0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_0098cfc0();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17726 ; VA 0x00978bf0 ; FUN_00978bf0 */

void FUN_00978bf0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  longlong lVar7;
  undefined uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  uVar6 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005d6c30();
  if (iVar3 != 0) {
    do {
      piVar1 = *(int **)(**(int **)(param_1 + 0x2c) + uVar6 * 8);
      if ((((piVar1 != (int *)0x0) &&
           (iVar3 = piVar1[3], iVar4 = FUN_005ee170(),
           (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
           (uint)*(ushort *)(iVar4 + 0x1da))) &&
          (iVar3 = (**(code **)(*piVar1 + 0xb4))(), iVar3 != 0)) &&
         (lVar7 = FUN_00928340(), lVar7 == CONCAT44(param_3,param_2))) {
        if (DAT_01ee420a != '\0') {
          FUN_016774b0();
        }
        if (DAT_01d646e0 == '\0') {
          iVar3 = FUN_005c8880();
          if (iVar3 != 0) {
            cVar2 = FUN_0064a9e0();
            goto joined_r0x00978cee;
          }
        }
        else {
          iVar3 = FUN_008f78c0();
          if (iVar3 != 0) {
            cVar2 = FUN_0064a9e0();
joined_r0x00978cee:
            if (cVar2 == '\0') {
              FUN_005542c0("Player service requests player disconnect",0x29);
              uStack_8 = 0;
              uVar8 = 0;
              FUN_005542c0("server",6);
              uStack_8 = 0xffffffff;
              FUN_0062db20(uVar8);
            }
          }
        }
        FUN_0062b370();
      }
      uVar6 = uVar6 + 1;
      uVar5 = FUN_005d6c30();
    } while (uVar6 < uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17727 ; VA 0x00978d80 ; FUN_00978d80 */

void __thiscall FUN_00978d80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_00562e40(), iVar2 != 0)) {
      FUN_00978bf0(iVar2,param_2,param_3,param_4);
    }
  }
  return;
}



/* FUNCTION 17728 ; VA 0x00978df0 ; FUN_00978df0 */

void FUN_00978df0(void)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_40;
  int *piStack_3c;
  int iStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cf788;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  piStack_1c = (int *)0x0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_008a86c0();
  piStack_40 = (int *)0x0;
  piStack_1c = piVar4;
  piStack_3c = (int *)0x0;
  piVar8 = (int *)*piVar4;
  iStack_8 = 0;
  piVar9 = (int *)*piVar8;
  uVar5 = piVar8[1] - (int)piVar9 >> 3;
  if (uVar5 != 0) {
    if (0x1fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00777ed0(uVar5);
    piVar8 = (int *)*piVar4;
    piVar9 = (int *)*piVar8;
  }
  if (piVar9 != (int *)piVar8[1]) {
    do {
      if (*piVar9 == 0) {
LAB_00978eac:
        bVar2 = true;
        piStack_20 = (int *)0x0;
        puVar7 = &uStack_24;
        iStack_14 = 0;
      }
      else {
        iVar1 = *(int *)(*piVar9 + 0xc);
        iVar6 = FUN_00913630();
        if ((uint)*(ushort *)(iVar6 + 0x1da) <
            (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) goto LAB_00978eac;
        piStack_28 = (int *)piVar9[1];
        iStack_14 = *piVar9;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          piStack_28[1] = piStack_28[1] + 1;
          UNLOCK();
          piStack_28 = (int *)piVar9[1];
        }
        bVar3 = true;
        puVar7 = &uStack_2c;
      }
      piVar8 = (int *)puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      iStack_34 = iStack_14;
      piStack_30 = piVar8;
      if (bVar2) {
        bVar2 = false;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_20[1] + -1;
          piStack_20[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar1 = piStack_20[2] + -1;
            piStack_20[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
      }
      if (bVar3) {
        bVar3 = false;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_28[1] + -1;
          piStack_28[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            iVar1 = piStack_28[2] + -1;
            piStack_28[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piStack_28 + 4))();
            }
          }
        }
      }
      iStack_8._0_1_ = 1;
      if (iStack_14 != 0) {
        if (piStack_3c == (int *)0x0) {
          FUN_00603260(0,&iStack_34);
          piVar8 = piStack_30;
        }
        else {
          *piStack_3c = 0;
          piStack_3c[1] = 0;
          if (piVar8 != (int *)0x0) {
            LOCK();
            piVar8[1] = piVar8[1] + 1;
            UNLOCK();
          }
          *piStack_3c = iStack_14;
          piStack_3c[1] = (int)piVar8;
          piStack_3c = piStack_3c + 2;
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar1 = piVar8[1] + -1;
        piVar8[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar1 = piVar8[2] + -1;
          piVar8[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piVar9 = piVar9 + 2;
    } while (piVar9 != *(int **)(*piStack_1c + 4));
  }
  if (piStack_3c != (int *)0x0) {
    do {
      piVar8 = (int *)piStack_40[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = (int *)piStack_40[1];
      }
      iStack_34 = *piStack_40;
      iStack_8._0_1_ = 2;
      piStack_30 = piVar8;
      if (iStack_34 != 0) {
        *(undefined *)(iStack_34 + 0x4cb) = 1;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar8[1] = piVar8[1] + 1;
          UNLOCK();
        }
        FUN_0089be10(iStack_34,piVar8);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar1 = piVar8[1] + -1;
        piVar8[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar1 = piVar8[2] + -1;
          piVar8[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      piStack_40 = piStack_40 + 2;
    } while (piStack_40 != piStack_3c);
  }
  FUN_016795b0();
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17729 ; VA 0x00979080 ; FUN_00979080 */

void FUN_00979080(byte *param_1,int *param_2,undefined4 param_3,int *param_4,undefined4 *param_5,
                 int *param_6,uint param_7,undefined4 param_8,int param_9,undefined4 param_10,
                 undefined4 param_11,undefined4 *param_12,undefined4 *param_13,undefined4 param_14,
                 uint param_15,undefined4 param_16,undefined4 param_17,undefined4 param_18,
                 undefined4 param_19,undefined *param_20,undefined *param_21,undefined4 param_22)

{
  int *piVar1;
  uint *puVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined **ppuVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  uint uVar11;
  int *piVar12;
  code *pcStack_2c4;
  int *piStack_2c0;
  int iStack_2bc;
  code *pcStack_2b8;
  int iStack_2b4;
  int iStack_2b0;
  int iStack_2ac;
  uint uStack_2a8;
  uint uStack_2a4;
  undefined4 *puStack_2a0;
  int *piStack_29c;
  int *piStack_298;
  int *piStack_294;
  uint auStack_290 [2];
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 *puStack_27c;
  undefined4 *puStack_278;
  undefined4 uStack_274;
  uint auStack_270 [2];
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined *puStack_25c;
  undefined *puStack_258;
  undefined4 *puStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  byte *pbStack_248;
  int *piStack_244;
  int *piStack_240;
  undefined8 uStack_23c;
  undefined8 uStack_234;
  undefined4 ***pppuStack_22c;
  undefined4 ***pppuStack_228;
  code *apcStack_21c [2];
  undefined auStack_214 [72];
  uint uStack_1cc;
  undefined auStack_1c4 [24];
  code *pcStack_1ac;
  undefined auStack_1a4 [72];
  uint uStack_15c;
  undefined auStack_154 [24];
  code *pcStack_13c;
  undefined auStack_134 [72];
  uint uStack_ec;
  undefined auStack_e4 [24];
  undefined *puStack_cc;
  undefined *puStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined *puStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  int *piStack_7c;
  int iStack_78;
  int *piStack_74;
  undefined4 *puStack_70;
  undefined4 *puStack_6c;
  int *piStack_68;
  int iStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined4 uStack_54;
  int iStack_50;
  undefined4 ***apppuStack_4c [3];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  int iStack_34;
  int *piStack_30;
  uint uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf847;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pppuStack_228 = (undefined4 ***)&iStack_78;
  pppuStack_22c = (undefined4 ***)0x9790b3;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iStack_78 == 0) {
    piStack_240 = (int *)0x36;
    pppuStack_22c = (undefined4 ***)0x0;
    pppuStack_228 = (undefined4 ***)0xf;
    piStack_244 = (int *)0x19359e4;
    uStack_23c = uStack_23c & 0xffffffffffffff00;
    pbStack_248 = (byte *)0x979b5d;
    FUN_005542c0();
    piStack_240 = (int *)0x979b65;
    FUN_005e65e0();
LAB_00979b65:
    if (piStack_74 == (int *)0x0) goto LAB_00979b8b;
    LOCK();
    iVar6 = piStack_74[1] + -1;
    piStack_74[1] = iVar6;
    UNLOCK();
    if (iVar6 != 0) goto LAB_00979b8b;
    pppuStack_228 = (undefined4 ***)0x979b7b;
    (**(code **)*piStack_74)();
    LOCK();
    iVar6 = piStack_74[2] + -1;
    piStack_74[2] = iVar6;
    UNLOCK();
    if (iVar6 != 0) goto LAB_00979b8b;
    iVar6 = *piStack_74;
  }
  else {
    uStack_88 = 0xffffffff;
    iStack_64 = 0;
    iStack_60 = 0;
    uStack_5c = 0;
    puStack_58 = (undefined4 *)0x0;
    uStack_54 = 0;
    iStack_50 = 0;
    pppuStack_228 = (undefined4 ***)&uStack_88;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pppuStack_22c = (undefined4 ***)&iStack_64;
    uStack_234 = 0x100000001;
    if (piStack_74 != (int *)0x0) {
      LOCK();
      piStack_74[2] = piStack_74[2] + 1;
      UNLOCK();
    }
    piStack_240 = (int *)iStack_78;
    uStack_23c = ZEXT48(piStack_74);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    pbStack_248 = param_1;
    piStack_244 = param_2;
    uStack_24c = 0x979144;
    FUN_00f7b7f0();
    pbVar10 = param_1;
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    pppuStack_228 = (undefined4 ***)0x6;
    pppuStack_22c = (undefined4 ***)0x19359c8;
    uStack_234 = CONCAT44(0x97916b,(undefined4)uStack_234);
    FUN_005542c0();
    pbVar10 = pbVar10 + *pbVar10 + 1;
    pppuStack_228 = apppuStack_4c;
    pppuStack_22c = (undefined4 ***)0x97917e;
    uVar4 = FUN_005702d0();
    pppuStack_228 = (undefined4 ***)(-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
    pppuStack_22c = apppuStack_4c;
    uStack_234 = CONCAT44(uVar4,&piStack_14);
    uStack_23c = CONCAT44(0x979198,(undefined4)uStack_23c);
    FUN_00562fc0();
    if (0xf < uStack_38) {
      pppuStack_228 = (undefined4 ***)(uStack_38 + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_4c[0];
      if (0xfff < pppuStack_228) {
        ppppuVar7 = (undefined4 ****)apppuStack_4c[0][-1];
        pppuStack_228 = (undefined4 ***)(uStack_38 + 0x24);
        if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_228 = (undefined4 ***)0x979c55;
          FUN_017167a3();
        }
      }
      uStack_234 = CONCAT44(0x9791c9,(undefined4)uStack_234);
      pppuStack_22c = ppppuVar7;
      FUN_01674ea0();
    }
    piVar12 = piStack_14;
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    if (piStack_14 != (int *)0x0) {
      iVar6 = piStack_14[8];
      pppuStack_228 = (undefined4 ***)0x9791f1;
      iVar5 = FUN_00888530();
      if (iVar6 != iVar5) {
        iVar6 = piVar12[8];
        pppuStack_228 = (undefined4 ***)0x979201;
        iVar5 = FUN_008881d0();
        if (iVar6 == iVar5) {
          iVar6 = piVar12[8];
          pppuStack_228 = (undefined4 ***)0x979211;
          iVar5 = FUN_008881d0();
          if (iVar6 != iVar5) {
            pppuStack_228 = (undefined4 ***)0x18c072c;
                    /* WARNING: Subroutine does not return */
            pppuStack_22c = (undefined4 ***)0x979c5f;
            FUN_016757c0();
          }
          pppuStack_228 = (undefined4 ***)(piVar12 + 10);
          if (piVar12[9] == 0) {
            pppuStack_228 = (undefined4 ***)0x0;
          }
          pppuStack_22c = (undefined4 ***)0x97922d;
          FUN_00557fc0();
          pppuStack_228 = (undefined4 ***)&param_5;
          pppuStack_22c = (undefined4 ***)0x979239;
          FUN_00557fc0();
          pppuStack_228 = (undefined4 ***)&piStack_14;
          uStack_8 = CONCAT31(uStack_8._1_3_,8);
          pppuStack_22c = (undefined4 ***)&uStack_18;
          piStack_28 = (int *)&DAT_3f800000;
          uStack_24 = 0x3f800000;
          uStack_18 = 0x3f800000;
          uStack_234 = CONCAT44(&uStack_24,&piStack_28);
          piStack_14 = (int *)&DAT_3f800000;
          uStack_23c = CONCAT44(&puStack_6c,0x979272);
          FUN_00f8c670();
          if (DAT_01d641ec == '\0') {
            pppuStack_228 = (undefined4 ***)uStack_18;
            uStack_38 = 0x3f800000;
            uStack_234 = CONCAT44(piStack_28,uStack_24);
            pppuStack_22c = (undefined4 ***)&DAT_3f800000;
            uStack_23c = CONCAT44(iStack_34,0x979323);
            FUN_009afbf0();
          }
          else {
            pppuStack_228 = (undefined4 ***)&uStack_2c;
            piStack_1c = (int *)0x0;
            pppuStack_22c = (undefined4 ***)&piStack_1c;
            uStack_2c = 0;
            uStack_234 = CONCAT44(&puStack_6c,0x97929d);
            FUN_00f8ca70();
            pppuStack_228 = (undefined4 ***)uStack_2c;
            pppuStack_22c = (undefined4 ***)piStack_1c;
            uStack_38 = 0x3f800000;
            piStack_240 = (int *)iStack_34;
            uStack_23c = CONCAT44(piStack_28,uStack_24);
            uStack_234 = CONCAT44(uStack_18,0x3f800000);
            piStack_244 = (int *)0x9792e8;
            FUN_009afcd0();
          }
          piVar12 = piStack_30;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_30[1] + -1;
            piStack_30[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              pppuStack_228 = (undefined4 ***)0x97933f;
              (**(code **)*piStack_30)();
              LOCK();
              piVar1 = piVar12 + 2;
              iVar6 = *piVar1 + -1;
              *piVar1 = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                pppuStack_228 = (undefined4 ***)0x97934f;
                (**(code **)(*piVar12 + 4))();
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          if (piStack_68 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_68[1] + -1;
            piStack_68[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              pppuStack_228 = (undefined4 ***)0x979369;
              (**(code **)*piStack_68)();
              LOCK();
              iVar6 = piStack_68[2] + -1;
              piStack_68[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                pppuStack_228 = (undefined4 ***)0x979379;
                (**(code **)(*piStack_68 + 4))();
              }
            }
          }
        }
      }
    }
    pbVar10 = param_1;
    pppuStack_228 = (undefined4 ***)0x12;
    pppuStack_22c = (undefined4 ***)0x19359d0;
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    uStack_234 = CONCAT44(0x97939d,(undefined4)uStack_234);
    FUN_005542c0();
    pbVar10 = pbVar10 + *pbVar10 + 1;
    pppuStack_228 = apppuStack_4c;
    pppuStack_22c = (undefined4 ***)0x9793b0;
    uVar4 = FUN_005702d0();
    pppuStack_228 = (undefined4 ***)(-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
    pppuStack_22c = apppuStack_4c;
    uStack_234 = CONCAT44(uVar4,&piStack_14);
    uStack_23c = CONCAT44(0x9793ca,(undefined4)uStack_23c);
    FUN_00562fc0();
    if (0xf < uStack_38) {
      pppuStack_228 = (undefined4 ***)(uStack_38 + 1);
      ppppuVar7 = (undefined4 ****)apppuStack_4c[0];
      if (0xfff < pppuStack_228) {
        ppppuVar7 = (undefined4 ****)apppuStack_4c[0][-1];
        pppuStack_228 = (undefined4 ***)(uStack_38 + 0x24);
        if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_228 = (undefined4 ***)0x979c64;
          FUN_017167a3();
        }
      }
      uStack_234 = CONCAT44(0x9793fb,(undefined4)uStack_234);
      pppuStack_22c = ppppuVar7;
      FUN_01674ea0();
    }
    uStack_3c = 0;
    uStack_38 = 0xf;
    apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
    if (piStack_14 != (int *)0x0) {
      iVar6 = piStack_14[8];
      piVar12 = piStack_14 + 8;
      pppuStack_228 = (undefined4 ***)0x979422;
      iVar5 = FUN_00888530();
      if (iVar6 != iVar5) {
        iVar6 = *piVar12;
        pppuStack_228 = (undefined4 ***)0x97942d;
        iVar5 = FUN_0088cb40();
        if (iVar6 == iVar5) {
          piStack_240 = (int *)0x97943d;
          piStack_240 = (int *)FUN_0055d610();
          piStack_244 = (int *)0x979445;
          FUN_0054ef60();
          pbStack_248 = (byte *)&param_5;
          uStack_24c = 0x979453;
          FUN_00557fc0();
          pbStack_248 = (byte *)0x979458;
          FUN_00971b10();
        }
      }
    }
    piVar12 = param_6;
    puVar9 = param_5;
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    puStack_6c = param_5;
    piStack_68 = param_6;
    pppuStack_228 = (undefined4 ***)&uStack_84;
    uStack_8._0_1_ = 9;
    pppuStack_22c = (undefined4 ***)&uStack_a0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_234 = CONCAT44(&uStack_ac,&uStack_b8);
    uStack_c4 = 0;
    uStack_c0 = 0;
    uStack_23c = CONCAT44(&uStack_c4,&uStack_40);
    piStack_240 = (int *)&param_1;
    uStack_bc = 0;
    uStack_b8 = 0;
    uStack_b4 = 0;
    uStack_b0 = 0;
    uStack_ac = 0;
    uStack_a8 = 0;
    uStack_a4 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    uStack_98 = 0;
    uStack_84 = 0;
    piStack_80 = (int *)0x0;
    piStack_7c = (int *)0x0;
    piStack_244 = (int *)0x979545;
    cVar3 = FUN_00f8bb20();
    if (cVar3 != '\0') {
      pppuStack_228 = (undefined4 ***)&uStack_84;
      pppuStack_22c = (undefined4 ***)&uStack_a0;
      uStack_234 = CONCAT44(&uStack_ac,&uStack_b8);
      uStack_23c = CONCAT44(&uStack_c4,&uStack_40);
      piStack_240 = &iStack_34;
      piStack_244 = (int *)0x979579;
      FUN_00a6ba00();
      pppuStack_228 = (undefined4 ***)0x0;
      pppuStack_22c = (undefined4 ***)puVar9;
      uStack_8._0_1_ = 10;
      uStack_234 = CONCAT44(0x97958b,(undefined4)uStack_234);
      FUN_008a65e0();
      piStack_14 = piStack_30;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_30[1] + -1;
        piStack_30[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          pppuStack_228 = (undefined4 ***)0x9795a5;
          (**(code **)*piStack_30)();
          LOCK();
          iVar6 = piStack_14[2] + -1;
          piStack_14[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            pppuStack_228 = (undefined4 ***)0x9795b6;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    uStack_8._0_1_ = 6;
    if (piVar12 != (int *)0x0) {
      LOCK();
      iVar6 = piVar12[1] + -1;
      piVar12[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pppuStack_228 = (undefined4 ***)0x9795d2;
        (**(code **)*piVar12)();
        LOCK();
        iVar6 = piVar12[2] + -1;
        piVar12[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          pppuStack_228 = (undefined4 ***)0x9795e2;
          (**(code **)(*piVar12 + 4))();
        }
      }
    }
    if (iStack_64 != iStack_60) {
      pppuStack_228 = (undefined4 ***)0x10;
      pppuStack_22c = (undefined4 ***)0x9796b8;
      piStack_28 = (int *)FUN_01674e20();
      if (piStack_28 == (int *)0x0) {
        piStack_28 = (int *)0x0;
      }
      else {
        piStack_28[1] = 1;
        piStack_28[2] = 1;
        *piStack_28 = (int)std::_Ref_count_obj<int>::vftable;
        if (piStack_28 + 3 != (int *)0x0) {
          piStack_28[3] = 0;
        }
      }
      piStack_80 = piStack_28 + 3;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      uStack_18 = 0;
      *piStack_80 = (iStack_60 - iStack_64) / 0x18;
      iVar6 = iStack_60 - iStack_64 >> 0x1f;
      piVar12 = piStack_28;
      piStack_7c = piStack_28;
      if ((iStack_60 - iStack_64) / 0x18 + iVar6 != iVar6) {
        iStack_20 = iStack_78 + 0xc;
        piStack_14 = (int *)0x0;
        do {
          piVar1 = piStack_14;
          if (iStack_20 == 0) {
            uStack_24 = 0;
          }
          else {
            pppuStack_228 = (undefined4 ***)0x97974d;
            uStack_24 = FUN_005c2760();
          }
          pppuStack_228 = (undefined4 ***)0x97975e;
          uVar4 = FUN_008ccd70();
          pppuStack_228 = (undefined4 ***)0x1;
          pppuStack_22c = (undefined4 ***)0x3;
          uStack_234 = CONCAT44(uVar4,(undefined4)uStack_234);
          puStack_70 = &uStack_250;
          uStack_8c = CONCAT31(uStack_8c._1_3_,DAT_01ee2fea);
          piStack_1c = (int *)auStack_270;
          puStack_c8 = (undefined *)auStack_270;
          uStack_90 = CONCAT31(uStack_90._1_3_,DAT_01ee2fe9);
          puStack_94 = (undefined *)(iStack_64 + (int)piVar1);
          auStack_270[0] = 0;
          puVar2 = auStack_270;
          puVar9 = &uStack_250;
          if (param_15 != 0) {
            auStack_270[0] = param_15;
            if ((param_15 & 1) == 0) {
              uStack_274 = 0;
              puStack_278 = &uStack_268;
              puStack_27c = &param_17;
              uStack_280 = 0x9797d7;
              (**(code **)(param_15 & 0xfffffffe))();
              puVar2 = (uint *)puStack_c8;
              puVar9 = puStack_70;
            }
            else {
              uStack_268 = param_17;
              uStack_264 = param_18;
              uStack_260 = param_19;
              puStack_25c = param_20;
              puStack_258 = param_21;
              puStack_254 = (undefined4 *)param_22;
              puVar2 = auStack_270;
              puVar9 = &uStack_250;
            }
          }
          puStack_70 = puVar9;
          puStack_c8 = (undefined *)puVar2;
          puStack_cc = (undefined *)auStack_290;
          piStack_1c = (int *)auStack_290;
          uStack_8._0_1_ = 0xc;
          auStack_290[0] = 0;
          puVar2 = auStack_290;
          if (param_7 != 0) {
            auStack_290[0] = param_7;
            if ((param_7 & 1) == 0) {
              piStack_294 = (int *)0x0;
              piStack_298 = &iStack_288;
              piStack_29c = &param_9;
              puStack_2a0 = (undefined4 *)0x979827;
              (**(code **)(param_7 & 0xfffffffe))();
              puVar2 = (uint *)puStack_cc;
            }
            else {
              iStack_288 = param_9;
              uStack_284 = param_10;
              uStack_280 = param_11;
              puStack_27c = param_12;
              puStack_278 = param_13;
              uStack_274 = param_14;
              puVar2 = auStack_290;
            }
          }
          puStack_cc = (undefined *)puVar2;
          piStack_68 = (int *)&piStack_298;
          if (piVar12 != (int *)0x0) {
            LOCK();
            piVar12[1] = piVar12[1] + 1;
            UNLOCK();
          }
          piStack_298 = piVar12 + 3;
          piStack_30 = (int *)&puStack_2a0;
          if (param_6 != (int *)0x0) {
            LOCK();
            param_6[1] = param_6[1] + 1;
            UNLOCK();
          }
          puStack_2a0 = param_5;
          piStack_29c = param_6;
          piStack_1c = (int *)(iStack_64 + (int)piVar1);
          uStack_8._0_1_ = 0xf;
          uStack_2a8 = 0;
          uStack_2a4 = 0;
          uStack_2c = piStack_1c[4];
          if (0xf < (uint)piStack_1c[5]) {
            piStack_1c = (int *)*piStack_1c;
          }
          piStack_294 = piVar12;
          if (uStack_2c < 0x10) {
            pcStack_2b8 = (code *)*piStack_1c;
            iStack_2b4 = piStack_1c[1];
            iStack_2b0 = piStack_1c[2];
            iStack_2ac = piStack_1c[3];
            uStack_2a4 = 0xf;
            piStack_68 = (int *)&piStack_298;
            piStack_30 = (int *)&puStack_2a0;
          }
          else {
            uVar11 = uStack_2c | 0xf;
            if (0x7fffffff < uVar11) {
              uVar11 = 0x7fffffff;
            }
            iStack_2bc = uVar11 + 1;
            piStack_2c0 = (int *)0x9798df;
            pcStack_2c4 = (code *)FUN_00554060();
            iStack_2bc = uStack_2c + 1;
            piStack_2c0 = piStack_1c;
            pcStack_2b8 = pcStack_2c4;
            FUN_0170c6f0();
            piVar12 = piStack_28;
            uStack_2a4 = uVar11;
          }
          iStack_2bc = uStack_8c;
          uStack_8._0_1_ = 0xb;
          piStack_2c0 = (int *)uStack_90;
          pcStack_2c4 = FUN_00979c70;
          uStack_2a8 = uStack_2c;
          FUN_00965860(apcStack_21c);
          pcStack_1ac = apcStack_21c[0];
          puStack_254 = (undefined4 *)auStack_214;
          uStack_8._0_1_ = 0x10;
          puStack_258 = (undefined *)0x979944;
          FUN_00969050();
          puVar9 = puStack_70;
          pcStack_13c = pcStack_1ac;
          puStack_254 = (undefined4 *)auStack_1a4;
          uStack_8._0_1_ = 0x11;
          *puStack_70 = 0;
          puStack_258 = (undefined *)0x97996f;
          FUN_00969050();
          puStack_254 = puVar9 + 2;
          uStack_8._0_1_ = 0x12;
          piStack_30 = (int *)&pcStack_2c4;
          pcStack_2c4 = pcStack_13c;
          FUN_00969050(auStack_134);
          cVar3 = FUN_00964400();
          ppuVar8 = &PTR_FUN_01936c44;
          if (cVar3 == '\0') {
            ppuVar8 = (undefined **)0x0;
          }
          *puVar9 = ppuVar8;
          uStack_8._0_1_ = 0x13;
          if (uStack_ec != 0) {
            if (((uStack_ec & 1) == 0) && (*(code **)(uStack_ec & 0xfffffffe) != (code *)0x0)) {
              puStack_25c = auStack_e4;
              puStack_254 = (undefined4 *)0x2;
              uStack_260 = 0x9799d5;
              puStack_258 = puStack_25c;
              (**(code **)(uStack_ec & 0xfffffffe))();
            }
            uStack_ec = 0;
          }
          puStack_254 = (undefined4 *)0x9799ed;
          FUN_0096cca0();
          uStack_8._0_1_ = 0x14;
          if (uStack_15c != 0) {
            if (((uStack_15c & 1) == 0) && (*(code **)(uStack_15c & 0xfffffffe) != (code *)0x0)) {
              puStack_25c = auStack_154;
              puStack_254 = (undefined4 *)0x2;
              uStack_260 = 0x979a14;
              puStack_258 = puStack_25c;
              (**(code **)(uStack_15c & 0xfffffffe))();
            }
            uStack_15c = 0;
          }
          puStack_254 = (undefined4 *)0x979a2c;
          FUN_0096cca0();
          uStack_8._0_1_ = 0x15;
          if (uStack_1cc != 0) {
            if (((uStack_1cc & 1) == 0) && (*(code **)(uStack_1cc & 0xfffffffe) != (code *)0x0)) {
              puStack_25c = auStack_1c4;
              puStack_254 = (undefined4 *)0x2;
              uStack_260 = 0x979a53;
              puStack_258 = puStack_25c;
              (**(code **)(uStack_1cc & 0xfffffffe))();
            }
            uStack_1cc = 0;
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          puStack_254 = (undefined4 *)0x979a6f;
          FUN_0096cca0();
          puStack_254 = (undefined4 *)0x428c0000;
          puStack_258 = puStack_94;
          puStack_25c = (undefined *)0x979a85;
          FUN_008d0b40();
          uStack_18 = uStack_18 + 1;
          piStack_14 = piStack_14 + 6;
        } while (uStack_18 < (uint)((iStack_60 - iStack_64) / 0x18));
      }
      if (piVar12 != (int *)0x0) {
        LOCK();
        iVar6 = piVar12[1] + -1;
        piVar12[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          pppuStack_228 = (undefined4 ***)0x979aca;
          (**(code **)*piVar12)();
          LOCK();
          iVar6 = piVar12[2] + -1;
          piVar12[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            pppuStack_228 = (undefined4 ***)0x979ada;
            (**(code **)(*piVar12 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (puStack_58 != (undefined4 *)0x0) {
        pppuStack_228 = (undefined4 ***)((iStack_50 - (int)puStack_58 >> 2) * 4);
        puVar9 = puStack_58;
        if (0xfff < pppuStack_228) {
          puVar9 = (undefined4 *)puStack_58[-1];
          pppuStack_228 = (undefined4 ***)((int)pppuStack_228 + 0x23);
          if (0x1f < (uint)((int)puStack_58 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_228 = (undefined4 ***)&UNK_00979c6e;
            FUN_017167a3();
          }
        }
        uStack_234 = CONCAT44(0x979b19,(undefined4)uStack_234);
        pppuStack_22c = (undefined4 ***)puVar9;
        FUN_01674ea0();
        puStack_58 = (undefined4 *)0x0;
        uStack_54 = 0;
        iStack_50 = 0;
      }
      pppuStack_228 = (undefined4 ***)0x979b39;
      FUN_00577a40();
      goto LAB_00979b65;
    }
    if (param_6 != (int *)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    pppuStack_22c = (undefined4 ***)param_5;
    pppuStack_228 = (undefined4 ***)param_6;
    uStack_234 = CONCAT44(0x97961e,(undefined4)uStack_234);
    FUN_0096e490();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (puStack_58 != (undefined4 *)0x0) {
      pppuStack_228 = (undefined4 ***)((iStack_50 - (int)puStack_58 >> 2) * 4);
      puVar9 = puStack_58;
      if (0xfff < pppuStack_228) {
        puVar9 = (undefined4 *)puStack_58[-1];
        pppuStack_228 = (undefined4 ***)((int)pppuStack_228 + 0x23);
        if (0x1f < (uint)((int)puStack_58 + (-4 - (int)puVar9))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_228 = (undefined4 ***)0x979c69;
          FUN_017167a3();
        }
      }
      uStack_234 = CONCAT44(0x97965d,(undefined4)uStack_234);
      pppuStack_22c = (undefined4 ***)puVar9;
      FUN_01674ea0();
      puStack_58 = (undefined4 *)0x0;
      uStack_54 = 0;
      iStack_50 = 0;
    }
    pppuStack_228 = (undefined4 ***)0x97967d;
    FUN_00577a40();
    if (piStack_74 == (int *)0x0) goto LAB_00979b8b;
    LOCK();
    iVar6 = piStack_74[1] + -1;
    piStack_74[1] = iVar6;
    UNLOCK();
    if (iVar6 != 0) goto LAB_00979b8b;
    pppuStack_228 = (undefined4 ***)0x97969b;
    (**(code **)*piStack_74)();
    LOCK();
    iVar6 = piStack_74[2] + -1;
    piStack_74[2] = iVar6;
    UNLOCK();
    if (iVar6 != 0) goto LAB_00979b8b;
    iVar6 = *piStack_74;
  }
  pppuStack_228 = (undefined4 ***)0x979b8b;
  (**(code **)(iVar6 + 4))();
LAB_00979b8b:
  piVar12 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar6 = param_2[1] + -1;
    param_2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pppuStack_228 = (undefined4 ***)0x979ba4;
      (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pppuStack_228 = (undefined4 ***)0x979bb4;
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar6 = param_4[2] + -1;
    param_4[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pppuStack_228 = (undefined4 ***)0x979bc9;
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar12 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar6 = param_6[1] + -1;
    param_6[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      pppuStack_228 = (undefined4 ***)0x979bdf;
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        pppuStack_228 = (undefined4 ***)0x979bee;
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  if (param_7 != 0) {
    if (((param_7 & 1) == 0) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0)) {
      pppuStack_22c = (undefined4 ***)&param_9;
      pppuStack_228 = (undefined4 ***)0x2;
      uStack_234 = CONCAT44(pppuStack_22c,0x979c0f);
      (**(code **)(param_7 & 0xfffffffe))();
    }
    param_7 = 0;
  }
  uStack_8 = 0x17;
  if (((param_15 != 0) && ((param_15 & 1) == 0)) &&
     (*(code **)(param_15 & 0xfffffffe) != (code *)0x0)) {
    pppuStack_22c = (undefined4 ***)&param_17;
    pppuStack_228 = (undefined4 ***)0x2;
    uStack_234 = CONCAT44(pppuStack_22c,0x979c3d);
    (**(code **)(param_15 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17730 ; VA 0x00979c70 ; FUN_00979c70 */

void FUN_00979c70(undefined4 param_1,undefined4 *param_2,int *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  undefined *puVar7;
  int iVar8;
  uint uVar9;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  int *in_stack_0000002c;
  int *in_stack_00000030;
  int *in_stack_00000034;
  uint in_stack_00000038;
  uint in_stack_00000058;
  code *pcStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = in_stack_00000034;
  uVar6 = DAT_01ee2fe9;
  puStack_c = &LAB_017cf898;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffcc;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar7 = &stack0xffffffcc;
  if (in_stack_00000030 != (int *)0x0) {
    puVar3 = (undefined4 *)param_2[1];
    param_2 = (undefined4 *)*param_2;
    ExceptionList = &pvStack_10;
    if (in_stack_0000002c != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
      UNLOCK();
    }
    FUN_009158f0(&pcStack_28,FUN_0098c690,in_stack_00000028,in_stack_0000002c,uVar6);
    uStack_8._0_1_ = 7;
    for (; piVar1 = piStack_20, param_2 != puVar3; param_2 = param_2 + 2) {
      if (param_2[1] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar4 = *param_2;
      uVar5 = param_2[1];
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
      }
      (*pcStack_28)(uStack_24,piStack_20,uVar4,uVar5);
    }
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar8 = piVar1[1] + -1;
      piVar1[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar8 = piVar1[2] + -1;
        piVar1[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    *in_stack_00000030 = *in_stack_00000030 + -1;
    if (*in_stack_00000030 == 0) {
      in_stack_00000034 = (int *)0x0;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar8 = piVar2[1] + -1;
        piVar2[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar8 = piVar2[2] + -1;
          piVar2[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      if (in_stack_0000002c != (int *)0x0) {
        LOCK();
        in_stack_0000002c[1] = in_stack_0000002c[1] + 1;
        UNLOCK();
      }
      FUN_0096e490(in_stack_00000028,in_stack_0000002c);
    }
    uStack_8 = 5;
    puVar7 = puStack_14;
  }
  puStack_14 = puVar7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar8 = param_3[1] + -1;
    param_3[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar8 = param_3[2] + -1;
      param_3[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000024) {
    uVar9 = in_stack_00000024 + 1;
    iVar8 = param_4;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(param_4 + -4);
      uVar9 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  if (in_stack_0000002c != (int *)0x0) {
    LOCK();
    iVar8 = in_stack_0000002c[1] + -1;
    in_stack_0000002c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*in_stack_0000002c)();
      LOCK();
      iVar8 = in_stack_0000002c[2] + -1;
      in_stack_0000002c[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*in_stack_0000002c + 4))();
      }
    }
  }
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar8 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar2 = in_stack_00000034 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*in_stack_00000034 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))(&stack0x00000040,&stack0x00000040,2);
  }
  uStack_8 = 10;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))(&stack0x00000060,&stack0x00000060,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17731 ; VA 0x00979e05 ; Catch@00979e05 */

undefined * Catch_00979e05(void)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_EBP;
  undefined auStack_18 [20];
  undefined4 uStack_4;
  
  uStack_4 = 0x979e0d;
  FUN_0058a2b0();
  uStack_4 = 0x979e15;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  iVar2 = unaff_EBP + 0x14;
  if (0xf < *(uint *)(unaff_EBP + 0x28)) {
    iVar2 = *(int *)(unaff_EBP + 0x14);
  }
  FUN_01675640(auStack_18,
               "Players:GetCharacterAppearanceAsync() Error loading character appearance %s: %s",
               iVar2,uVar1);
  FUN_005e65e0();
  return &DAT_00979e43;
}



/* FUNCTION 17732 ; VA 0x00979f80 ; FUN_00979f80 */

void FUN_00979f80(int param_1,uint param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf8f4;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_2);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&stack0x00000020);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar6 = param_2;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar6 = in_stack_00000034 + 1;
    iVar4 = in_stack_00000020;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(in_stack_00000020 + -4);
      uVar6 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17733 ; VA 0x0097a130 ; FUN_0097a130 */

void FUN_0097a130(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa13c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = thunk_FUN_0086f380();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_0086f410();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_3);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17734 ; VA 0x0097a290 ; FUN_0097a290 */

void FUN_0097a290(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088da50();
  uStack_e8 = param_2;
  uStack_ec = 0;
  uStack_e4 = param_3;
  uStack_ec = FUN_005c9e80();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17735 ; VA 0x0097a390 ; FUN_0097a390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_0097a390(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf94f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_4;
  piStack_1b4 = param_5;
  uStack_1bc = FUN_006309e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_f0 = thunk_FUN_00bfa7a0();
  uStack_e8 = param_6;
  puStack_ec = (undefined *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee227c) {
    FUN_016f3809(&DAT_01ee227c);
    if (DAT_01ee227c == -1) {
      _DAT_01ee2270 = FUN_005c65e0;
      _DAT_01ee2274 = FUN_005c65e0;
      _DAT_01ee2278 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee227c);
    }
  }
  puStack_ec = &DAT_01ee2270;
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17736 ; VA 0x0097a5f0 ; FUN_0097a5f0 */

int FUN_0097a5f0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf9c2;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  pcVar4 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar5;
  uStack_360 = thunk_FUN_005f33f0();
  uStack_35c = 0;
  uStack_358 = param_2;
  uStack_35c = FUN_005f38c0();
  uStack_8._0_1_ = 4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_3;
  piStack_284 = param_4;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 5;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_5);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_f0 = FUN_0088cdc0();
  uStack_ec = 0;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  uStack_e8 = in_stack_0000002c;
  piStack_e4 = in_stack_00000030;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 7;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,pcVar4);
  uStack_8._0_1_ = 8;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 9;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  iVar6 = FUN_01675290(uVar5);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar3 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar6 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    uVar8 = in_stack_00000028 + 1;
    uVar7 = param_5;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_5 - 4);
      uVar8 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  piVar1 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000030 + 1;
    iVar3 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar6 = (**(code **)*in_stack_00000030)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar6 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 17737 ; VA 0x0097a860 ; FUN_0097a860 */

void FUN_0097a860(int param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("AbuseReportScreenshot-MenuClosed",0x20);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (*(int *)(*(int *)(param_1 + 0x18) + 0x28c) != 0) {
    FUN_006eccd0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17738 ; VA 0x0097a930 ; FUN_0097a930 */

void FUN_0097a930(int param_1)

{
  (**(code **)(param_1 + 0x18))(*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c));
  return;
}



/* FUNCTION 17739 ; VA 0x0097a950 ; FUN_0097a950 */

int FUN_0097a950(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf9d8;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 0x28);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[2] = piVar6[2] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x28);
  }
  uVar3 = *(undefined4 *)(param_1 + 0x24);
  pcVar4 = *(code **)(param_1 + 0x18);
  uStack_8 = 0;
  piVar1 = piVar6 + 2;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,piVar6,param_2,param_3,param_4);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)(*piVar6 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17740 ; VA 0x0097a9f0 ; FUN_0097a9f0 */

void FUN_0097a9f0(int param_1,int param_2)

{
  undefined uVar1;
  char cVar2;
  char *pcVar3;
  char *pcVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint in_stack_0000001c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  pcVar3 = *(char **)(param_1 + 0x30);
  uVar1 = *(undefined *)(param_1 + 0x38);
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar4 = pcVar3;
  do {
    cVar2 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar3,(int)pcVar4 - (int)(pcVar3 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (**(code **)(param_1 + 0x18))
            (*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c),auStack_28,&param_2,
             uVar1);
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    iVar5 = param_2;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(param_2 + -4);
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17741 ; VA 0x0097aaf0 ; FUN_0097aaf0 */

void FUN_0097aaf0(int param_1,uint param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  int in_stack_00000038;
  uint in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfa18;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uVar1 = *(undefined4 *)(param_1 + 0x28);
  uVar2 = *(undefined4 *)(param_1 + 0x2c);
  uVar3 = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60(&stack0x00000020);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0096e710(uVar3,uVar1,uVar2);
  if (0xf < in_stack_0000001c) {
    if (0xfff < in_stack_0000001c + 1) {
      if (0x1f < (param_2 - *(int *)(param_2 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    if (0xfff < in_stack_00000034 + 1) {
      if (0x1f < (in_stack_00000020 - *(int *)(in_stack_00000020 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (0xf < in_stack_0000004c) {
    if (0xfff < in_stack_0000004c + 1) {
      if (0x1f < (in_stack_00000038 - *(int *)(in_stack_00000038 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17742 ; VA 0x0097ac50 ; FUN_0097ac50 */

int FUN_0097ac50(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0097ac6a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar3 = (**(code **)(*piVar2 + 4))();
      return iVar3;
    }
  }
  return param_1;
}



/* FUNCTION 17743 ; VA 0x0097ac70 ; FUN_0097ac70 */

bool FUN_0097ac70(byte *param_1,int *param_2,char *param_3)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfa38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar5 = param_3;
  do {
    cVar2 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_3,(int)pcVar5 - (int)(param_3 + 1));
  bVar3 = *param_1;
  uVar6 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_3,uVar6,auStack_28,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  bVar9 = param_3 != (char *)0x0;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return bVar9;
}



/* FUNCTION 17744 ; VA 0x0097ad70 ; FUN_0097ad70 */

void __thiscall FUN_0097ad70(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00972200(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17745 ; VA 0x0097ae30 ; FUN_0097ae30 */

void __thiscall FUN_0097ae30(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  undefined4 uVar1;
  uint in_stack_0000002c;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_3;
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  param_3 = FUN_0097cb00(param_3,param_1 + 0x48);
  uStack_14 = FUN_0097cd30(uVar1,param_1 + 0x44);
  uStack_1c = FUN_009269c0(uVar1,param_1 + 0x40);
  FUN_00972690(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_1c,
               &uStack_14,&param_3,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17746 ; VA 0x0097af10 ; FUN_0097af10 */

void __thiscall FUN_0097af10(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_009723a0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17747 ; VA 0x0097afd0 ; FUN_0097afd0 */

void __thiscall FUN_0097afd0(int param_1,undefined4 param_2,code *param_3,uint param_4)

{
  int *piVar1;
  code *pcVar2;
  code *pcVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint in_stack_0000002c;
  undefined4 uVar9;
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar3 = param_3;
  puStack_c = &LAB_017cfaa9;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (*(code *)**(undefined4 **)param_3)();
  if (uVar5 < 3) {
LAB_0097b0d4:
    if (*(undefined4 **)(param_1 + 0x48) == (undefined4 *)0x0) {
      uVar9 = 3;
      goto LAB_0097b404;
    }
    uStack_18 = **(undefined4 **)(param_1 + 0x48);
  }
  else {
    param_3 = *(code **)(*(int *)pcVar3 + 0x38);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee334c)
       && (FUN_016f3809(&DAT_01ee334c), DAT_01ee334c == -1)) {
      uStack_8._0_1_ = 2;
      FUN_00e2cce0();
      FUN_016f3654(&LAB_01885bd0);
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01ee334c);
    }
    cVar4 = (*param_3)(3,&DAT_01ee32e8,&uStack_18);
    if (cVar4 == '\0') {
      uStack_fc = FUN_00888530();
      iStack_f8 = 0;
      uStack_8._0_1_ = 3;
      cVar4 = (**(code **)(*(int *)pcVar3 + 4))(3,&uStack_fc);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 5;
        if (iStack_f8 != 0) {
          (**(code **)(iStack_f8 + 8))(auStack_f4);
        }
        uStack_8._0_1_ = 1;
        goto LAB_0097b0d4;
      }
      puVar7 = (undefined4 *)FUN_00e2c9d0();
      uStack_18 = *puVar7;
      uStack_8._0_1_ = 4;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      uStack_8._0_1_ = 1;
    }
  }
  uVar5 = (*(code *)**(undefined4 **)pcVar3)();
  if (uVar5 < 2) {
LAB_0097b1b5:
    if (*(undefined4 **)(iStack_14 + 0x44) == (undefined4 *)0x0) {
      uVar9 = 2;
      goto LAB_0097b404;
    }
    param_3 = (code *)**(undefined4 **)(iStack_14 + 0x44);
  }
  else {
    pcVar2 = *(code **)(*(int *)pcVar3 + 0x38);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33b4)
       && (FUN_016f3809(&DAT_01ee33b4), DAT_01ee33b4 == -1)) {
      uStack_8._0_1_ = 6;
      FUN_009a0d40();
      FUN_016f3654(&LAB_01885bf0);
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01ee33b4);
    }
    cVar4 = (*pcVar2)(2,&DAT_01ee3350,&param_3);
    if (cVar4 == '\0') {
      uStack_fc = FUN_00888530();
      iStack_f8 = 0;
      uStack_8._0_1_ = 7;
      cVar4 = (**(code **)(*(int *)pcVar3 + 4))(2,&uStack_fc);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 9;
        if (iStack_f8 != 0) {
          (**(code **)(iStack_f8 + 8))(auStack_f4);
        }
        uStack_8._0_1_ = 1;
        goto LAB_0097b1b5;
      }
      puVar7 = (undefined4 *)FUN_0099e970();
      pcVar2 = (code *)*puVar7;
      uStack_8._0_1_ = 8;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      uStack_8._0_1_ = 1;
      param_3 = pcVar2;
    }
  }
  iVar6 = (*(code *)**(undefined4 **)pcVar3)();
  if (iVar6 != 0) {
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8._0_1_ = 10;
    uStack_fc = FUN_00888530();
    iStack_f8 = 0;
    uStack_8._0_1_ = 0xb;
    cVar4 = (**(code **)(*(int *)pcVar3 + 4))(1,&uStack_fc);
    if (cVar4 != '\0') {
      puVar7 = (undefined4 *)FUN_0088a3d0();
      piVar8 = (int *)puVar7[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = (int *)puVar7[1];
      }
      uStack_2c = *puVar7;
      uStack_8._0_1_ = 0xc;
      piStack_28 = piVar8;
      if (iStack_f8 != 0) {
        (**(code **)(iStack_f8 + 8))(auStack_f4);
      }
      FUN_00550b30();
      goto LAB_0097b2af;
    }
    uStack_8._0_1_ = 0xd;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  puVar7 = *(undefined4 **)(iStack_14 + 0x40);
  if (puVar7 == (undefined4 *)0x0) {
    uVar9 = 1;
LAB_0097b404:
    FUN_016756b0(auStack_24,"Argument %d missing or nil",uVar9);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  piVar8 = (int *)puVar7[1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar7[1];
  }
  uStack_2c = *puVar7;
  piStack_28 = piVar8;
LAB_0097b2af:
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_00972540(param_2,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
               &uStack_2c,&param_3,&uStack_18,&param_4,&stack0x0000002c);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar6 = piVar8[1] + -1;
    piVar8[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17748 ; VA 0x0097b430 ; FUN_0097b430 */

void __thiscall
FUN_0097b430(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0x97b476;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee2fe9);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0x97b4d8;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_00966b00);
  uStack_b8 = 0x97b547;
  FUN_00960740();
  uStack_14._0_1_ = 1;
  uStack_94 = 0x97b557;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0x97b578;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0x97b5a6;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 17749 ; VA 0x0097b5c0 ; FUN_0097b5c0 */

void __thiscall FUN_0097b5c0(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint in_stack_0000002c;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bf41b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8._0_1_ = 2;
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*param_3 + 4))(1,&uStack_110);
    if (cVar2 != '\0') {
      uVar4 = FUN_008898b0();
      FUN_0054ef60(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      FUN_005507b0();
      goto LAB_0097b6ba;
    }
    uStack_8._0_1_ = 5;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(param_1 + 0x40));
LAB_0097b6ba:
  uStack_8._0_1_ = 6;
  FUN_00972060(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),aiStack_40,
               &param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar5 = uStack_2c + 1;
    iVar3 = aiStack_40[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_40[0] + -4);
      uVar5 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar3) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}


