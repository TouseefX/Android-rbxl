/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 13750 ; VA 0x008887b0 ; FUN_008887b0 */

undefined4 * __thiscall
FUN_008887b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined param_5,undefined param_6,undefined param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00554ed0();
  uStack_20 = uStack_20 & 0xffffff00;
  *param_1 = RBX::Reflection::Descriptor::vftable;
  uVar2 = FUN_0086e3d0(param_2);
  *(ulonglong *)(param_1 + 2) = (ulonglong)uStack_20;
  param_1[1] = uVar2;
  param_1[4] = 0;
  param_1[5] = uVar1;
  uStack_8 = 0;
  *param_1 = RBX::Reflection::Type::vftable;
  uVar1 = FUN_0086e3d0(param_3);
  param_1[6] = uVar1;
  param_1[7] = param_4;
  *(undefined *)(param_1 + 8) = param_6;
  *(undefined *)((int)param_1 + 0x21) = param_5;
  *(undefined *)((int)param_1 + 0x22) = param_7;
  FUN_00888bf0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13751 ; VA 0x00888860 ; FUN_00888860 */

undefined4 * __thiscall
FUN_00888860(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined param_4,
            undefined param_5,undefined param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00554ed0();
  uStack_20 = uStack_20 & 0xffffff00;
  *param_1 = RBX::Reflection::Descriptor::vftable;
  uVar2 = FUN_0086e3d0(param_2);
  *(ulonglong *)(param_1 + 2) = (ulonglong)uStack_20;
  param_1[1] = uVar2;
  param_1[4] = 0;
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = param_3;
  *(undefined *)(param_1 + 8) = param_5;
  *(undefined *)((int)param_1 + 0x21) = param_4;
  uStack_8 = 0;
  *param_1 = RBX::Reflection::Type::vftable;
  *(undefined *)((int)param_1 + 0x22) = param_6;
  FUN_00888bf0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13752 ; VA 0x00888900 ; FUN_00888900 */

void __fastcall FUN_00888900(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::Descriptor::vftable;
  return;
}



/* FUNCTION 13753 ; VA 0x00888910 ; FUN_00888910 */

void FUN_00888910(void)

{
  FUN_00688830();
  return;
}



/* FUNCTION 13754 ; VA 0x00888920 ; FUN_00888920 */

uint FUN_00888920(char *param_1)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  
  pcVar4 = param_1;
  pcVar1 = param_1 + 1;
  do {
    cVar2 = *param_1;
    param_1 = param_1 + 1;
  } while (cVar2 != '\0');
  iVar3 = (int)param_1 - (int)pcVar1;
  uVar5 = 0;
  param_1 = (char *)0x0;
  if (pcVar4 + iVar3 < pcVar4) {
    iVar3 = 0;
  }
  if (iVar3 != 0) {
    do {
      cVar2 = *pcVar4;
      pcVar4 = pcVar4 + 1;
      param_1 = (char *)((int)param_1 + 1);
      uVar5 = uVar5 ^ cVar2 + -0x61c88647 + uVar5 * 0x40 + (uVar5 >> 2);
    } while (param_1 != (char *)iVar3);
  }
  return uVar5;
}



/* FUNCTION 13755 ; VA 0x00888980 ; FUN_00888980 */

undefined4 * __thiscall FUN_00888980(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::Descriptor::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 13756 ; VA 0x008889b0 ; FUN_008889b0 */

undefined4 * __thiscall FUN_008889b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::Descriptor::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 13757 ; VA 0x008889e0 ; FUN_008889e0 */

int * __thiscall FUN_008889e0(undefined4 param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba2d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != param_3) {
    piVar3 = param_2 + 3;
    ExceptionList = &pvStack_10;
    do {
      *param_4 = piVar3[-3];
      param_4[1] = piVar3[-2];
      param_4[2] = piVar3[-1];
      param_4[3] = 0;
      puVar2 = (undefined4 *)*piVar3;
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)*puVar2)(piVar3 + 1,param_4 + 4);
        puVar2 = (undefined4 *)*piVar3;
      }
      param_4[3] = (int)puVar2;
      param_4 = param_4 + 0x36;
      piVar1 = piVar3 + 0x33;
      piVar3 = piVar3 + 0x36;
    } while (piVar1 != param_3);
  }
  uStack_8 = 1;
  FUN_00687590(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 13758 ; VA 0x00888aa0 ; FUN_00888aa0 */

void FUN_00888aa0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2fb;
  pvStack_10 = ExceptionList;
  uStack_e8 = param_1;
  uStack_e4 = param_2;
  ExceptionList = &pvStack_10;
  uStack_e0 = thunk_FUN_00888530();
  iStack_dc = 0;
  uStack_8 = 0;
  FUN_00888c90(&uStack_e8);
  uStack_8 = 1;
  if (iStack_dc != 0) {
    (**(code **)(iStack_dc + 8))(auStack_d8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13759 ; VA 0x00888b30 ; FUN_00888b30 */

void FUN_00888b30(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2fb;
  pvStack_10 = ExceptionList;
  uStack_e8 = param_1;
  uStack_e4 = param_2;
  uStack_e0 = *param_3;
  puVar1 = (undefined4 *)param_3[1];
  puStack_dc = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  if (puVar1 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    (*(code *)*puVar1)(param_3 + 2,auStack_d8);
    puVar1 = (undefined4 *)param_3[1];
  }
  uStack_8 = 0;
  puStack_dc = puVar1;
  FUN_00888c90(&uStack_e8);
  uStack_8 = 1;
  if (puStack_dc != (undefined4 *)0x0) {
    (*(code *)puStack_dc[2])(auStack_d8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13760 ; VA 0x00888bf0 ; FUN_00888bf0 */

void __fastcall FUN_00888bf0(undefined4 param_1)

{
  undefined4 uStack_8;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede838) {
    uStack_8 = param_1;
    FUN_016f3809(&DAT_01ede838);
    if (DAT_01ede838 == -1) {
      FUN_016f3654(&LAB_018808a0);
      FUN_016f37bf(&DAT_01ede838);
    }
  }
  DAT_01ede828 = &DAT_01ede82c;
  if (DAT_01ede834 != DAT_01ede830) {
    *DAT_01ede830 = param_1;
    DAT_01ede830 = DAT_01ede830 + 1;
    return;
  }
  uStack_8 = param_1;
  FUN_006030d0(DAT_01ede830,&uStack_8);
  return;
}



/* FUNCTION 13761 ; VA 0x00888c80 ; FUN_00888c80 */

undefined4 FUN_00888c80(void)

{
  return DAT_01ede828;
}



/* FUNCTION 13762 ; VA 0x00888c90 ; FUN_00888c90 */

void __thiscall FUN_00888c90(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    puVar1[2] = param_2[2];
    puVar1[3] = 0;
    puVar2 = (undefined4 *)param_2[3];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_2 + 4,puVar1 + 4);
      puVar2 = (undefined4 *)param_2[3];
    }
    puVar1[3] = puVar2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xd8;
    return;
  }
  FUN_008877e0(puVar1,param_2);
  return;
}



/* FUNCTION 13763 ; VA 0x00888d00 ; FUN_00888d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00888d00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8) {
    FUN_016f3809(&DAT_01ead3c8);
    if (DAT_01ead3c8 == -1) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
  }
  puVar2 = (undefined4 *)*param_1;
  if ((code **)puVar2 == &DAT_01ead3bc) {
    uVar3 = *param_2;
    uVar4 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[1] = uVar3;
    piVar5 = (int *)param_1[2];
    param_1[2] = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = &DAT_01ead3bc;
  return param_1;
}



/* FUNCTION 13764 ; VA 0x00888e20 ; FUN_00888e20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00888e20(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded64) {
    FUN_016f3809(&DAT_01eded64);
    if (DAT_01eded64 == -1) {
      _DAT_01eded58 = FUN_0057bbb0;
      _DAT_01eded5c = FUN_005880a0;
      _DAT_01eded60 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01eded64);
    }
  }
  puVar2 = (undefined *)*param_1;
  if (puVar2 == &DAT_01eded58) {
    uVar3 = *param_2;
    uVar4 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[1] = uVar3;
    piVar5 = (int *)param_1[2];
    param_1[2] = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = &DAT_01eded58;
  return param_1;
}



/* FUNCTION 13765 ; VA 0x00888f40 ; FUN_00888f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00888f40(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead288) {
    FUN_016f3809(&DAT_01ead288);
    if (DAT_01ead288 == -1) {
      DAT_01ead27c = FUN_0057bbb0;
      _DAT_01ead280 = FUN_005880a0;
      DAT_01ead284 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead288);
    }
  }
  puVar2 = (undefined4 *)*param_1;
  if ((code **)puVar2 == &DAT_01ead27c) {
    uVar3 = *param_2;
    uVar4 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[1] = uVar3;
    piVar5 = (int *)param_1[2];
    param_1[2] = uVar4;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[1] + -1;
      piVar5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = *param_2;
  param_1[2] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  *param_1 = &DAT_01ead27c;
  return param_1;
}



/* FUNCTION 13766 ; VA 0x00889060 ; FUN_00889060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00889060(undefined4 *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded94) {
    FUN_016f3809(&DAT_01eded94);
    if (DAT_01eded94 == -1) {
      _DAT_01eded88 = FUN_005c65e0;
      _DAT_01eded8c = FUN_005c65e0;
      _DAT_01eded90 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eded94);
    }
  }
  puVar1 = (undefined *)*param_1;
  if (puVar1 == &DAT_01eded88) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (puVar1 != (undefined *)0x0) {
    (**(code **)(puVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = &DAT_01eded88;
  return param_1;
}



/* FUNCTION 13767 ; VA 0x00889110 ; FUN_00889110 */

undefined4 *
FUN_00889110(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_4;
  param_1[2] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 13768 ; VA 0x008891f0 ; FUN_008891f0 */

int * __fastcall FUN_008891f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088d870();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13769 ; VA 0x00889220 ; FUN_00889220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00889220(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  double *pdVar6;
  float *pfVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  float fVar11;
  double dVar12;
  int *piStack_8;
  
  iVar5 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0088da50();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088da50();
    if (iVar5 != iVar2) goto LAB_00889492;
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar5 = *piVar3;
    iVar4 = FUN_005c9cc0();
    iVar2 = param_1[1];
    if (iVar2 == iVar4) {
      param_1[2] = iVar5;
    }
    else {
      if (iVar2 != 0) {
        (**(code **)(iVar2 + 8))(param_1 + 2);
      }
      param_1[2] = iVar5;
      param_1[1] = iVar4;
    }
    iVar5 = FUN_0088c8c0();
    *param_1 = iVar5;
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088ca00();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088ca00();
    if (iVar5 != iVar2) goto LAB_00889492;
    pdVar6 = (double *)(param_1 + 2);
    if (param_1[1] == 0) {
      pdVar6 = (double *)0x0;
    }
    dVar12 = *pdVar6;
    if (dVar12 < _PTR_018c6f48) {
      dVar12 = dVar12 - _PTR_018cf0f8;
    }
    else {
      dVar12 = dVar12 + _PTR_018cf0f8;
    }
    iVar2 = FUN_005c9cc0();
    iVar5 = param_1[1];
    if (iVar5 == iVar2) {
      param_1[2] = (int)dVar12;
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(param_1 + 2);
      }
      param_1[2] = (int)dVar12;
      param_1[1] = iVar2;
    }
    iVar5 = FUN_0088c8c0();
    *param_1 = iVar5;
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088c960();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088c960();
    if (iVar5 != iVar2) goto LAB_00889492;
    pfVar7 = (float *)(param_1 + 2);
    if (param_1[1] == 0) {
      pfVar7 = (float *)0x0;
    }
    fVar11 = *pfVar7;
    if (fVar11 < DAT_018ce2f0) {
      fVar11 = fVar11 - DAT_018ce2f4;
    }
    else {
      fVar11 = fVar11 + DAT_018ce2f4;
    }
    iVar2 = FUN_005c9cc0();
    iVar5 = param_1[1];
    if (iVar5 == iVar2) {
      param_1[2] = (int)fVar11;
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(param_1 + 2);
      }
      param_1[2] = (int)fVar11;
      param_1[1] = iVar2;
    }
    iVar5 = FUN_0088c8c0();
    *param_1 = iVar5;
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088daf0();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088daf0();
    if (iVar5 != iVar2) goto LAB_00889492;
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = *(char *)piVar3;
    iVar2 = FUN_005c9cc0();
    iVar5 = param_1[1];
    if (iVar5 == iVar2) {
      param_1[2] = (uint)(cVar1 != '\0');
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(param_1 + 2);
      }
      param_1[2] = (uint)(cVar1 != '\0');
      param_1[1] = iVar2;
    }
    iVar5 = FUN_0088c8c0();
    *param_1 = iVar5;
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088c8c0();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 != iVar2) {
LAB_0088946d:
    thunk_FUN_0088c8c0();
    uVar9 = FUN_005543f0();
    uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar10,uVar9);
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    piVar8 = piVar3;
    if (param_1[1] == 0) {
      piVar8 = (int *)0x0;
    }
    cVar1 = FUN_009ee5c0(piVar8,&piStack_8);
    if (cVar1 == '\0') goto LAB_0088946d;
    iVar2 = FUN_005c9cc0();
    iVar5 = param_1[1];
    if (iVar5 == iVar2) {
      *piVar3 = (int)piStack_8;
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(piVar3);
      }
      param_1[2] = (int)piStack_8;
      param_1[1] = iVar2;
    }
    iVar5 = FUN_0088c8c0();
    *param_1 = iVar5;
    iVar2 = FUN_0088c8c0();
    if (iVar5 == iVar2) {
      if (param_1[1] == 0) {
        piVar3 = (int *)0x0;
      }
      return piVar3;
    }
  }
LAB_00889492:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13770 ; VA 0x008894a0 ; FUN_008894a0 */

float * __fastcall FUN_008894a0(float *param_1)

{
  char cVar1;
  float fVar2;
  float *pfVar3;
  double *pdVar4;
  float fVar5;
  char *pcVar6;
  float fVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  float *pfVar10;
  double in_XMM0_Qa;
  float *pfStack_8;
  
  fVar7 = *param_1;
  pfStack_8 = param_1;
  fVar2 = (float)FUN_0088ca00();
  pfVar10 = (float *)*param_1;
  pfStack_8 = pfVar10;
  if (fVar7 == fVar2) {
    pfVar3 = (float *)FUN_0088ca00();
    if (pfVar10 != pfVar3) goto LAB_00889689;
    pdVar4 = (double *)(param_1 + 2);
    if (param_1[1] == 0.0) {
      pdVar4 = (double *)0x0;
    }
    pfStack_8 = (float *)(float)*pdVar4;
    fVar2 = (float)FUN_00630820();
    fVar7 = param_1[1];
    if (fVar7 == fVar2) {
      param_1[2] = (float)pfStack_8;
    }
    else {
      if (fVar7 != 0.0) {
        (**(code **)((int)fVar7 + 8))(param_1 + 2);
      }
      param_1[2] = (float)pfStack_8;
      param_1[1] = fVar2;
    }
LAB_008895ad:
    fVar7 = (float)FUN_0088c960();
    *param_1 = fVar7;
  }
  else {
    pfVar10 = (float *)FUN_0088c8c0();
    fVar7 = *param_1;
    if (pfStack_8 == pfVar10) {
      fVar2 = (float)FUN_0088c8c0();
      if (fVar7 != fVar2) goto LAB_00889689;
      pfVar10 = param_1 + 2;
      if (param_1[1] == 0.0) {
        pfVar10 = (float *)0x0;
      }
      fVar7 = *pfVar10;
LAB_0088959c:
      pfStack_8 = (float *)(float)(int)fVar7;
LAB_0088959f:
      FUN_006843b0(&pfStack_8);
      goto LAB_008895ad;
    }
    fVar5 = (float)FUN_0088da50();
    fVar2 = *param_1;
    if (fVar7 == fVar5) {
      fVar7 = (float)FUN_0088da50();
      if (fVar2 != fVar7) goto LAB_00889689;
      FUN_016f4020();
      pfStack_8 = (float *)(float)in_XMM0_Qa;
      goto LAB_0088959f;
    }
    fVar7 = (float)FUN_0088daf0();
    if (fVar2 == fVar7) {
      pcVar6 = (char *)FUN_00605c60();
      fVar7 = (float)(uint)(*pcVar6 != '\0');
      goto LAB_0088959c;
    }
  }
  fVar7 = *param_1;
  fVar2 = (float)FUN_0088c960();
  if (fVar7 == fVar2) {
    pfVar10 = param_1 + 2;
    if (param_1[1] == 0.0) {
      pfVar10 = (float *)0x0;
    }
    if (pfVar10 != (float *)0x0) {
      return pfVar10;
    }
  }
  fVar7 = *param_1;
  fVar2 = (float)FUN_0088cb40();
  if (fVar7 != fVar2) {
LAB_00889664:
    thunk_FUN_0088c960();
    uVar8 = FUN_005543f0();
    uVar9 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar9,uVar8);
  }
  fVar7 = *param_1;
  fVar2 = (float)FUN_0088cb40();
  if (fVar7 == fVar2) {
    pfVar10 = param_1 + 2;
    pfVar3 = pfVar10;
    if (param_1[1] == 0.0) {
      pfVar3 = (float *)0x0;
    }
    cVar1 = FUN_009ee6c0(pfVar3,&pfStack_8);
    if (cVar1 == '\0') goto LAB_00889664;
    fVar2 = (float)FUN_00630820();
    fVar7 = param_1[1];
    if (fVar7 == fVar2) {
      *pfVar10 = (float)pfStack_8;
    }
    else {
      if (fVar7 != 0.0) {
        (**(code **)((int)fVar7 + 8))(pfVar10);
      }
      param_1[2] = (float)pfStack_8;
      param_1[1] = fVar2;
    }
    fVar7 = (float)FUN_0088c960();
    *param_1 = fVar7;
    fVar2 = (float)FUN_0088c960();
    if (fVar7 == fVar2) {
      if (param_1[1] == 0.0) {
        pfVar10 = (float *)0x0;
      }
      return pfVar10;
    }
  }
LAB_00889689:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13771 ; VA 0x008896a0 ; FUN_008896a0 */

double * __fastcall FUN_008896a0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  float *pfVar6;
  double *pdVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  double *pdVar10;
  double in_XMM0_Qa;
  undefined8 uStack_c;
  
  iVar3 = *param_1;
  iVar2 = FUN_0088c8c0();
  iVar5 = *param_1;
  uStack_c = (double)CONCAT44(iVar5,(undefined4)uStack_c);
  if (iVar3 == iVar2) {
    iVar3 = FUN_0088c8c0();
    if (iVar5 != iVar3) goto LAB_0088988d;
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    uStack_c = (double)*piVar4;
LAB_008896e2:
    iVar5 = FUN_00630890();
    iVar3 = param_1[1];
    if (iVar3 == iVar5) {
      *(double *)(param_1 + 2) = uStack_c;
    }
    else {
      if (iVar3 != 0) {
        (**(code **)(iVar3 + 8))(param_1 + 2);
      }
      *(double *)(param_1 + 2) = uStack_c;
      param_1[1] = iVar5;
    }
LAB_008897b1:
    iVar3 = FUN_0088ca00();
    *param_1 = iVar3;
  }
  else {
    iVar5 = FUN_0088da50();
    iVar3 = *param_1;
    if (uStack_c._4_4_ == iVar5) {
      iVar5 = FUN_0088da50();
      if (iVar3 != iVar5) goto LAB_0088988d;
      FUN_016f4020();
      uStack_c = in_XMM0_Qa;
      goto LAB_008896e2;
    }
    iVar2 = FUN_0088daf0();
    iVar5 = *param_1;
    if (iVar3 == iVar2) {
      iVar3 = FUN_0088daf0();
      if (iVar5 != iVar3) goto LAB_0088988d;
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      uStack_c = (double)(*(char *)piVar4 != '\0');
LAB_008897a3:
      FUN_0063d480(&uStack_c);
      goto LAB_008897b1;
    }
    iVar3 = FUN_0088c960();
    if (iVar5 == iVar3) {
      pfVar6 = (float *)FUN_00605b70();
      uStack_c = (double)*pfVar6;
      goto LAB_008897a3;
    }
  }
  iVar3 = *param_1;
  iVar5 = FUN_0088ca00();
  if (iVar3 == iVar5) {
    pdVar10 = (double *)(param_1 + 2);
    if (param_1[1] == 0) {
      pdVar10 = (double *)0x0;
    }
    if (pdVar10 != (double *)0x0) {
      return pdVar10;
    }
  }
  iVar3 = *param_1;
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
LAB_00889868:
    thunk_FUN_0088ca00();
    uVar8 = FUN_005543f0();
    uVar9 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar9,uVar8);
  }
  iVar3 = *param_1;
  iVar5 = FUN_0088cb40();
  if (iVar3 == iVar5) {
    pdVar10 = (double *)(param_1 + 2);
    pdVar7 = pdVar10;
    if (param_1[1] == 0) {
      pdVar7 = (double *)0x0;
    }
    cVar1 = FUN_009ee7a0(pdVar7,&uStack_c);
    if (cVar1 == '\0') goto LAB_00889868;
    iVar5 = FUN_00630890();
    iVar3 = param_1[1];
    if (iVar3 == iVar5) {
      *pdVar10 = uStack_c;
    }
    else {
      if (iVar3 != 0) {
        (**(code **)(iVar3 + 8))(pdVar10);
      }
      *(double *)(param_1 + 2) = uStack_c;
      param_1[1] = iVar5;
    }
    iVar3 = FUN_0088ca00();
    *param_1 = iVar3;
    iVar5 = FUN_0088ca00();
    if (iVar3 == iVar5) {
      if (param_1[1] == 0) {
        pdVar10 = (double *)0x0;
      }
      return pdVar10;
    }
  }
LAB_0088988d:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13772 ; VA 0x008898a0 ; thunk_FUN_0088beb0 */

int * __fastcall thunk_FUN_0088beb0(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba498;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088caa0();
  if (iVar5 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar4;
    }
  }
  iVar5 = *param_1;
  iVar3 = FUN_0088cb40();
  if (iVar5 == iVar3) {
    iStack_34 = 0;
    iStack_30 = 0;
    iStack_2c = 0;
    iStack_28 = 0;
    uStack_8 = 1;
    iStack_24 = FUN_0086e640();
    iStack_20 = FUN_0086e640();
    uStack_1c = uStack_1c & 0xffffff00;
    iStack_18 = 0;
    iVar5 = *param_1;
    uStack_8 = 2;
    iVar3 = FUN_0088cb40();
    if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    cVar2 = FUN_00585a40(piVar4,&iStack_38);
    if (cVar2 != '\0') {
      iStack_14 = FUN_008903d0();
      iVar5 = param_1[1];
      if (iVar5 == iStack_14) {
        param_1[2] = iStack_38;
        if (iStack_30 != 0) {
          LOCK();
          *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
          UNLOCK();
        }
        param_1[3] = iStack_34;
        piVar4 = (int *)param_1[4];
        param_1[4] = iStack_30;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar5 = piVar4[1] + -1;
          piVar4[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar5 = piVar4[2] + -1;
            piVar4[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (iStack_28 != 0) {
          LOCK();
          *(int *)(iStack_28 + 8) = *(int *)(iStack_28 + 8) + 1;
          UNLOCK();
        }
        param_1[5] = iStack_2c;
        piVar4 = (int *)param_1[6];
        param_1[6] = iStack_28;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
        param_1[7] = iStack_24;
        param_1[8] = iStack_20;
        param_1[9] = uStack_1c;
        param_1[10] = iStack_18;
      }
      else {
        if (iVar5 != 0) {
          (**(code **)(iVar5 + 8))(param_1 + 2);
          param_1[1] = 0;
        }
        FUN_0088dd80(&iStack_38);
        param_1[1] = iStack_14;
      }
      iVar5 = FUN_0088caa0();
      *param_1 = iVar5;
      iVar3 = FUN_0088caa0();
      if (iVar5 == iVar3) {
        piVar4 = param_1 + 2;
        if (param_1[1] == 0) {
          piVar4 = (int *)0x0;
        }
        FUN_0087dc70();
        ExceptionList = pvStack_10;
        return piVar4;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_0087dc70();
  }
  thunk_FUN_0088caa0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13773 ; VA 0x008898b0 ; FUN_008898b0 */

void __fastcall FUN_008898b0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  uint *puVar6;
  int ***pppiVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  bool bVar11;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int **appiStack_28 [3];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba388;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088daf0();
  iVar8 = *param_1;
  if (iVar3 == iVar2) {
    iVar3 = FUN_0088daf0();
    if (iVar8 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    uVar5 = FUN_009ee570(auStack_40,piVar4);
    uStack_8 = 0;
    FUN_00632c30(uVar5);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar10 = uStack_2c + 1;
      uVar9 = auStack_40[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_40[0] - 4);
        uVar10 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
      iVar3 = FUN_0088cb40();
      *param_1 = iVar3;
      goto LAB_00889cf2;
    }
  }
  else {
    iVar2 = FUN_0088c8c0();
    iVar3 = *param_1;
    if (iVar8 == iVar2) {
      iVar8 = FUN_0088c8c0();
      if (iVar3 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      puVar6 = (uint *)FUN_009ee270(auStack_40,piVar4);
      uStack_8 = 1;
    }
    else {
      iVar2 = FUN_0088da50();
      iVar8 = *param_1;
      if (iVar3 == iVar2) {
        iVar3 = FUN_0088da50();
        if (iVar8 != iVar3) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        piVar4 = param_1 + 2;
        if (param_1[1] == 0) {
          piVar4 = (int *)0x0;
        }
        puVar6 = (uint *)FUN_009ee550(auStack_40,piVar4);
        uStack_8 = 2;
      }
      else {
        iVar3 = FUN_0088c960();
        if (iVar8 == iVar3) {
          uVar5 = FUN_00605b70();
          puVar6 = (uint *)FUN_009ee330(auStack_40,uVar5);
          uStack_8 = 3;
        }
        else {
          iVar3 = *param_1;
          iVar8 = FUN_0088ca00();
          if (iVar3 == iVar8) {
            uVar5 = FUN_00605ba0();
            puVar6 = (uint *)FUN_009ee440(auStack_40,uVar5);
            uStack_8 = 4;
          }
          else {
            iVar3 = *param_1;
            iVar8 = FUN_0088d870();
            if (iVar3 == iVar8) {
              uVar5 = FUN_008891f0();
              puVar6 = (uint *)FUN_00d86ac0(auStack_40,uVar5);
              uStack_8 = 5;
            }
            else {
              iVar3 = *param_1;
              iVar8 = FUN_00b00260();
              if (iVar3 == iVar8) {
                FUN_0068f2a0();
                uVar5 = FUN_0060efa0();
                cVar1 = FUN_0087dd70(uVar5);
                uStack_30 = 0;
                uStack_2c = 0xf;
                auStack_40[0] = auStack_40[0] & 0xffffff00;
                if (cVar1 == '\0') {
                  FUN_005542c0(&DAT_018d743c,1);
                  uStack_8 = 7;
                }
                else {
                  FUN_005542c0("Identity",8);
                  uStack_8 = 6;
                }
              }
              else {
                iVar3 = *param_1;
                iVar2 = FUN_00d89a00();
                iVar8 = *param_1;
                if (iVar3 == iVar2) {
                  iVar3 = FUN_00d89a00();
                  if (iVar8 != iVar3) {
                    /* WARNING: Subroutine does not return */
                    FUN_016757c0("Variant cast failed");
                  }
                  piVar4 = param_1 + 2;
                  if (param_1[1] == 0) {
                    piVar4 = (int *)0x0;
                  }
                  puVar6 = (uint *)FUN_00d89d00(auStack_40,piVar4);
                  uStack_8 = 8;
                  goto LAB_00889c1e;
                }
                iVar2 = FUN_00d88470();
                iVar3 = *param_1;
                if (iVar8 == iVar2) {
                  iVar8 = FUN_00d88470();
                  if (iVar3 != iVar8) {
                    /* WARNING: Subroutine does not return */
                    FUN_016757c0("Variant cast failed");
                  }
                  piVar4 = param_1 + 7;
                  if (param_1[1] == 0) {
                    piVar4 = (int *)&DAT_00000014;
                  }
                  if (*piVar4 == 0) {
                    bVar11 = true;
                  }
                  else {
                    bVar11 = *(int *)(*piVar4 + 8) == 0;
                  }
                  uStack_30 = 0;
                  uStack_2c = 0xf;
                  auStack_40[0] = auStack_40[0] & 0xffffff00;
                  if (bVar11) {
                    FUN_005542c0(&DAT_018e3e8c,3);
                    uStack_8 = 9;
                  }
                  else {
                    FUN_005542c0("function",8);
                    uStack_8 = 10;
                  }
                }
                else {
                  iVar8 = FUN_0088cdc0();
                  if (iVar3 == iVar8) {
                    piVar4 = (int *)FUN_00605c00();
                    if (*piVar4 != 0) {
                      iVar3 = FUN_0088cdc0();
                      piVar4 = *(int **)(iVar3 + 4);
                      if (0xf < (uint)piVar4[5]) {
                        piVar4 = (int *)*piVar4;
                      }
                      puVar6 = (uint *)FUN_0054eff0(piVar4);
                      uStack_8 = 0xb;
                      goto LAB_00889c1e;
                    }
                    uStack_30 = 0;
                    uStack_2c = 0xf;
                    auStack_40[0] = auStack_40[0] & 0xffffff00;
                    FUN_005542c0(&DAT_018e3e8c,3);
                    uStack_8 = 0xc;
                  }
                  else {
                    iVar3 = *param_1;
                    iVar8 = FUN_008882f0();
                    if (iVar3 != iVar8) {
                      piVar4 = (int *)*param_1;
                      if (*(char *)((int)piVar4 + 0x22) == '\0') {
                        piVar4 = (int *)0x0;
                      }
                      if (piVar4 != (int *)0x0) {
                        iVar3 = (**(code **)(*piVar4 + 8))(param_1);
                        if (iVar3 != 0) {
                          uStack_18 = 0;
                          uStack_14 = 0xf;
                          appiStack_28[0] = (int **)((uint)appiStack_28[0] & 0xffffff00);
                          uStack_8 = 0xe;
                          cVar1 = FUN_009cb330(appiStack_28);
                          if (cVar1 != '\0') {
                            iVar8 = FUN_005c9d30();
                            iVar3 = param_1[1];
                            if (iVar3 == iVar8) {
                              if ((int ***)(param_1 + 2) != appiStack_28) {
                                pppiVar7 = appiStack_28;
                                if (0xf < uStack_14) {
                                  pppiVar7 = (int ***)appiStack_28[0];
                                }
                                FUN_005542c0(pppiVar7,uStack_18);
                              }
                            }
                            else {
                              if (iVar3 != 0) {
                                (**(code **)(iVar3 + 8))(param_1 + 2);
                                param_1[1] = 0;
                              }
                              FUN_0054ef60(appiStack_28);
                              param_1[1] = iVar8;
                            }
                            iVar3 = FUN_0088cb40();
                            *param_1 = iVar3;
                          }
                          uStack_8 = 0xffffffff;
                          FUN_005507b0();
                        }
                      }
                      goto LAB_00889cf2;
                    }
                    uStack_30 = 0;
                    uStack_2c = 0xf;
                    auStack_40[0] = auStack_40[0] & 0xffffff00;
                    FUN_005542c0(&DAT_018bf820,2);
                    uStack_8 = 0xd;
                  }
                }
              }
              puVar6 = auStack_40;
            }
          }
        }
      }
    }
LAB_00889c1e:
    FUN_00632c30(puVar6);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  iVar3 = FUN_0088cb40();
  *param_1 = iVar3;
LAB_00889cf2:
  iVar3 = *param_1;
  iVar8 = FUN_0088cb40();
  if (iVar3 == iVar8) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  FUN_00550130("Unable to cast value to std::string");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 13774 ; VA 0x00889d70 ; FUN_00889d70 */

int * __fastcall FUN_00889d70(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba3c7;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  iVar3 = FUN_0088cbe0();
  piVar6 = param_1 + 1;
  if (iVar5 == iVar3) {
    piVar4 = param_1 + 2;
    if (*piVar6 == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar4;
    }
  }
  iVar5 = *param_1;
  piStack_18 = piVar6;
  iVar3 = FUN_00888530();
  if (iVar5 != iVar3) {
    piVar4 = (int *)FUN_01674e20(0x18);
    uStack_8 = 1;
    piStack_20 = piVar4;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4[1] = 1;
      piVar4[2] = 1;
      *piVar4 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
      FUN_00569550(1,&uStack_11);
    }
    piVar2 = (int *)piVar4[3];
    uStack_8 = 2;
    piVar1 = piVar2 + 1;
    *piVar2 = *piStack_1c;
    if (piVar6 != piVar1) {
      if (*piVar1 != 0) {
        (**(code **)(*piVar1 + 8))(piVar2 + 2);
        *piVar1 = 0;
      }
      if ((undefined4 *)*piVar6 != (undefined4 *)0x0) {
        (**(code **)*piVar6)(param_1 + 2,piVar2 + 2);
        *piVar1 = *piVar6;
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
    }
    piStack_24 = piVar4 + 3;
    uStack_8._0_1_ = 3;
    piStack_20 = piVar4;
    FUN_00888d00(&piStack_24);
    piVar6 = piStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    iVar5 = FUN_0088cbe0();
    *piStack_1c = iVar5;
    iVar3 = FUN_0088cbe0();
    if (iVar5 == iVar3) {
      piVar6 = piStack_18 + 1;
      if (*piStack_18 == 0) {
        piVar6 = (int *)0x0;
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return piVar6;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0x0;
  uStack_8 = 0;
  FUN_00888d00(&piStack_24);
  piVar4 = piStack_20;
  uStack_8 = 0xffffffff;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    piVar6 = piStack_18;
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar6 = piVar4 + 2;
      iVar5 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      piVar6 = piStack_18;
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
        piVar6 = piStack_18;
      }
    }
  }
  iVar5 = FUN_0088cbe0();
  *param_1 = iVar5;
  iVar3 = FUN_0088cbe0();
  if (iVar5 == iVar3) {
    piVar4 = piVar6 + 1;
    if (*piVar6 == 0) {
      piVar4 = (int *)0x0;
    }
    ExceptionList = pvStack_10;
    return piVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13775 ; VA 0x00889fa0 ; FUN_00889fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00889fa0(int *param_1)

{
  code *pcVar1;
  code **ppcVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  code *pcVar7;
  int *piVar8;
  int *piVar9;
  int aiStack_11c [2];
  undefined auStack_114 [184];
  undefined4 uStack_5c;
  code **ppcStack_58;
  code *pcStack_54;
  undefined *puStack_50;
  code *pcStack_4c;
  code *pcStack_48;
  code *pcStack_38;
  code *pcStack_34;
  int *piStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  code *pcStack_20;
  int *piStack_1c;
  code *pcStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba400;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  pcStack_48 = (code *)0x889fca;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  iVar4 = FUN_0088cc80();
  if (((iVar6 != iVar4) || (param_1[1] == 0)) || (piVar9 = param_1 + 2, piVar9 == (int *)0x0)) {
    iVar6 = *param_1;
    pcStack_48 = (code *)0x889fe6;
    iVar4 = FUN_008882f0();
    if (((iVar6 != iVar4) || (param_1[1] == 0)) || (param_1 + 2 == (int *)0x0)) {
      pcStack_48 = (code *)0x191ce8c;
                    /* WARNING: Subroutine does not return */
      pcStack_4c = (code *)0x88a25d;
      FUN_016757c0();
    }
    pcStack_48 = (code *)0x18;
    pcStack_4c = (code *)0x88a00a;
    pcStack_18 = (code *)FUN_01674e20();
    if (pcStack_18 == (code *)0x0) {
      pcVar7 = (code *)0x0;
    }
    else {
      *(int *)(pcStack_18 + 4) = 1;
      *(int *)(pcStack_18 + 8) = 1;
      *(undefined ***)pcStack_18 =
           std::
           _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
           ::vftable;
      *(int *)(pcStack_18 + 0xc) = 0;
      *(int *)(pcStack_18 + 0x10) = 0;
      *(int *)(pcStack_18 + 0x14) = 0;
      pcVar7 = pcStack_18;
    }
    pcStack_4c = pcVar7 + 0xc;
    ppcStack_58 = &pcStack_38;
    piVar8 = (int *)param_1[2];
    puStack_14 = (undefined *)CONCAT31(puStack_14._1_3_,DAT_01ede83c);
    uStack_8 = 0;
    piVar9 = (int *)piVar8[1];
    piVar8 = (int *)*piVar8;
    if (pcVar7 != (code *)0x0) {
      LOCK();
      *(int *)(pcVar7 + 4) = *(int *)(pcVar7 + 4) + 1;
      UNLOCK();
    }
    puStack_50 = puStack_14;
    pcStack_54 = FUN_0088df80;
    uStack_5c = 0x88a092;
    pcStack_48 = pcVar7;
    pcStack_2c = pcStack_4c;
    pcStack_28 = pcVar7;
    FUN_00889110();
    if (piVar8 != piVar9) {
      piVar8 = piVar8 + 1;
      do {
        pcStack_20 = (code *)&pcStack_4c;
        pcStack_18 = pcStack_38;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          piStack_30[1] = piStack_30[1] + 1;
          UNLOCK();
        }
        pcStack_4c = pcStack_34;
        pcStack_48 = (code *)piStack_30;
        puStack_14 = (undefined *)aiStack_11c;
        uStack_8._0_1_ = 2;
        aiStack_11c[0] = piVar8[-1];
        aiStack_11c[1] = 0;
        puVar5 = (undefined4 *)*piVar8;
        ppcVar2 = &pcStack_4c;
        piVar3 = aiStack_11c;
        if (puVar5 != (undefined4 *)0x0) {
          (*(code *)*puVar5)(piVar8 + 1,auStack_114);
          puVar5 = (undefined4 *)*piVar8;
          ppcVar2 = (code **)pcStack_20;
          piVar3 = (int *)puStack_14;
        }
        puStack_14 = (undefined *)piVar3;
        pcStack_20 = (code *)ppcVar2;
        *(undefined4 **)(puStack_14 + 4) = puVar5;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        (*pcStack_18)();
        piVar3 = piVar8 + 0x33;
        piVar8 = piVar8 + 0x34;
      } while (piVar3 != piVar9);
    }
    piVar9 = piStack_30;
    pcStack_34 = (code *)0x0;
    piStack_30 = (int *)0x0;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar6 = piVar9[1] + -1;
      piVar9[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pcStack_48 = (code *)0x88a14e;
        (**(code **)*piVar9)();
        LOCK();
        iVar6 = piVar9[2] + -1;
        piVar9[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          pcStack_48 = (code *)0x88a15e;
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    if (pcVar7 != (code *)0x0) {
      LOCK();
      *(int *)(pcVar7 + 4) = *(int *)(pcVar7 + 4) + 1;
      UNLOCK();
    }
    pcStack_24 = pcVar7 + 0xc;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    pcStack_20 = pcVar7;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded74) {
      pcStack_48 = (code *)&DAT_01eded74;
      pcStack_4c = (code *)0x88a267;
      FUN_016f3809();
      if (DAT_01eded74 == -1) {
        pcStack_48 = (code *)&DAT_01eded74;
        DAT_01eded68 = FUN_0057bbb0;
        _DAT_01eded6c = FUN_005880a0;
        DAT_01eded70 = FUN_0057d5e0;
        pcStack_4c = (code *)0x88a29f;
        FUN_016f37bf();
      }
    }
    piVar8 = piStack_1c;
    puVar5 = (undefined4 *)piStack_1c[1];
    if ((code **)puVar5 == &DAT_01eded68) {
      piStack_1c[2] = (int)(pcVar7 + 0xc);
      piVar9 = (int *)piStack_1c[3];
      piStack_1c[3] = (int)pcVar7;
      piStack_1c = piVar9;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar6 = piVar9[1] + -1;
        piVar9[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          pcStack_48 = (code *)0x88a1c3;
          (**(code **)*piVar9)();
          LOCK();
          iVar6 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            pcStack_48 = (code *)0x88a1d4;
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    else {
      if (puVar5 != (undefined4 *)0x0) {
        pcStack_48 = (code *)(piStack_1c + 2);
        pcStack_4c = (code *)0x88a1e3;
        (*(code *)puVar5[2])();
      }
      piVar8[3] = (int)pcVar7;
      piVar8[2] = (int)(pcVar7 + 0xc);
      piVar8[1] = (int)&DAT_01eded68;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    pcStack_48 = (code *)0x88a1ff;
    iVar6 = FUN_0088cc80();
    *piVar8 = iVar6;
    pcStack_48 = (code *)0x88a208;
    iVar4 = FUN_0088cc80();
    if (iVar6 != iVar4) {
      pcStack_48 = (code *)0x18c072c;
                    /* WARNING: Subroutine does not return */
      pcStack_4c = (code *)&UNK_0088a2b1;
      FUN_016757c0();
    }
    piVar9 = piVar8 + 2;
    if (piVar8[1] == 0) {
      piVar9 = (int *)0x0;
    }
    if (pcVar7 != (code *)0x0) {
      LOCK();
      iVar6 = *(int *)(pcVar7 + 4) + -1;
      *(int *)(pcVar7 + 4) = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pcStack_48 = (code *)0x88a231;
        (*(code *)**(undefined4 **)pcVar7)();
        LOCK();
        pcVar1 = pcVar7 + 8;
        iVar6 = *(int *)pcVar1;
        *(int *)pcVar1 = *(int *)pcVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          pcStack_48 = (code *)0x88a240;
          (**(code **)(*(int *)pcVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar9;
}



/* FUNCTION 13776 ; VA 0x0088a2c0 ; FUN_0088a2c0 */

void __fastcall FUN_0088a2c0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba420;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00888530();
  if (iVar3 == iVar2) {
    iStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = 0;
  }
  else {
    iVar3 = *param_1;
    iVar2 = FUN_0088cdc0();
    if (iVar3 != iVar2) goto LAB_0088a388;
    iVar3 = *param_1;
    iVar2 = FUN_0088cdc0();
    if (iVar3 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    piStack_14 = (int *)piVar4[1];
    iStack_18 = *piVar4;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)piVar4[1];
    }
    uStack_8 = 1;
  }
  FUN_00888e20(&iStack_18);
  piVar4 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iVar3 = FUN_0088cd20();
  *param_1 = iVar3;
LAB_0088a388:
  iVar3 = *param_1;
  iVar2 = FUN_0088cd20();
  if (iVar3 == iVar2) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast value to Object");
}



/* FUNCTION 13777 ; VA 0x0088a3d0 ; FUN_0088a3d0 */

void __fastcall FUN_0088a3d0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba440;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00888530();
  if (iVar3 == iVar2) {
    iStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = 0;
  }
  else {
    iVar3 = *param_1;
    iVar2 = FUN_0088cd20();
    if (iVar3 != iVar2) goto LAB_0088a4c9;
    iVar3 = *param_1;
    iVar2 = FUN_0088cd20();
    if (iVar3 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 1;
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_18 = FUN_0170d75d(*piVar4,0,&RBX::Reflection::DescribedBase::RTTI_Type_Descriptor,
                             &RBX::Instance::RTTI_Type_Descriptor,0);
    if (iStack_18 == 0) {
      iStack_18 = 0;
      piStack_14 = (int *)0x0;
    }
    else {
      piStack_14 = (int *)piVar4[1];
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
        piStack_14 = (int *)piVar4[1];
      }
    }
    uStack_8 = 2;
  }
  FUN_00888f40(&iStack_18);
  piVar4 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  iVar3 = FUN_0088cdc0();
  *param_1 = iVar3;
LAB_0088a4c9:
  iVar3 = *param_1;
  iVar2 = FUN_0088cdc0();
  if (iVar3 == iVar2) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast value to Object");
}



/* FUNCTION 13778 ; VA 0x0088a510 ; FUN_0088a510 */

int * __fastcall FUN_0088a510(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0088ce60();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088a5cb:
    thunk_FUN_0088ce60();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  FUN_0054d840(0);
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00aa5590(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_0088a5cb;
    iVar2 = FUN_00630a50();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = (int)piStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = (int)piStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088ce60();
    *param_1 = iVar4;
    iVar2 = FUN_0088ce60();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13779 ; VA 0x0088a600 ; thunk_FUN_0088c0c0 */

int * __fastcall thunk_FUN_0088c0c0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int ****ppppiVar3;
  int ****ppppiVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int ***pppiStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  int ***pppiStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int ***pppiStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cf00();
  if (iVar5 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar5 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar5 != iVar1) {
    thunk_FUN_0088cf00();
    uVar6 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
  }
  uStack_30 = 0xf00000000;
  pppiStack_40 = (int ***)((uint)pppiStack_40 & 0xffffff00);
  iVar5 = *param_1;
  uStack_8 = 0;
  iVar1 = FUN_0088cb40();
  if (iVar5 == iVar1) {
    ppppiVar4 = (int ****)(param_1 + 2);
    ppppiVar3 = ppppiVar4;
    if (param_1[1] == 0) {
      ppppiVar3 = (int ****)0x0;
    }
    FUN_0054ef60(ppppiVar3);
    pppiStack_28 = pppiStack_58;
    uStack_24 = uStack_54;
    uStack_20 = uStack_50;
    uStack_1c = uStack_4c;
    uStack_18 = CONCAT44(uStack_44,uStack_48);
    FUN_005507b0();
    pppiStack_40 = pppiStack_28;
    uStack_3c = uStack_24;
    uStack_38 = uStack_20;
    uStack_34 = uStack_1c;
    uStack_30 = uStack_18;
    iVar1 = FUN_00630ac0();
    iVar5 = param_1[1];
    uStack_18._4_4_ = iVar1;
    if (iVar5 == iVar1) {
      if (ppppiVar4 != &pppiStack_40) {
        ppppiVar4 = &pppiStack_40;
        if (0xf < uStack_44) {
          ppppiVar4 = (int ****)pppiStack_58;
        }
        FUN_005542c0(ppppiVar4,uStack_48);
      }
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(ppppiVar4);
        param_1[1] = 0;
      }
      FUN_0054ef60(&pppiStack_40);
      param_1[1] = uStack_18._4_4_;
    }
    iVar5 = FUN_0088cf00();
    *param_1 = iVar5;
    iVar1 = FUN_0088cf00();
    if (iVar5 == iVar1) {
      piVar2 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar2 = (int *)0x0;
      }
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return piVar2;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13780 ; VA 0x0088a610 ; FUN_0088a610 */

int * __fastcall FUN_0088a610(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0088cfa0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088a6c8:
    thunk_FUN_0088cfa0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  piStack_8 = (int *)0xc2;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d86d60(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_0088a6c8;
    iVar2 = FUN_00630b30();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = (int)piStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = (int)piStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088cfa0();
    *param_1 = iVar4;
    iVar2 = FUN_0088cfa0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13781 ; VA 0x0088a700 ; FUN_0088a700 */

int * __fastcall FUN_0088a700(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d050();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088a7ea:
    thunk_FUN_0088d050();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_10 = 0;
  iStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d86d90(piVar3,&iStack_10);
    if (cVar1 == '\0') goto LAB_0088a7ea;
    iVar2 = FUN_005c9e10();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_10;
      param_1[3] = iStack_c;
      param_1[4] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      *(ulonglong *)(param_1 + 2) = CONCAT44(iStack_c,iStack_10);
      param_1[4] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d050();
    *param_1 = iVar4;
    iVar2 = FUN_0088d050();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13782 ; VA 0x0088a820 ; FUN_0088a820 */

int * __fastcall FUN_0088a820(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uStack_8;
  
  iVar4 = *param_1;
  uStack_8 = param_1;
  iVar2 = FUN_0088d0f0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088a8eb:
    thunk_FUN_0088d0f0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  uStack_8 = (int *)((uint)uStack_8 & 0xff000000);
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d87110(piVar3,&uStack_8);
    if (cVar1 == '\0') goto LAB_0088a8eb;
    iVar2 = FUN_00630ba0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *(undefined2 *)piVar7 = (undefined2)uStack_8;
      *(undefined *)((int)param_1 + 10) = uStack_8._2_1_;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      *(undefined2 *)(param_1 + 2) = (undefined2)uStack_8;
      *(undefined *)((int)param_1 + 10) = uStack_8._2_1_;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d0f0();
    *param_1 = iVar4;
    iVar2 = FUN_0088d0f0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13783 ; VA 0x0088a920 ; FUN_0088a920 */

int **** __fastcall FUN_0088a920(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int ****ppppiVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  int ****ppppiVar9;
  int aiStack_40 [5];
  uint uStack_2c;
  int ***apppiStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba468;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    uStack_8 = 0;
    FUN_009cbbb0(aiStack_40);
    uStack_8 = 1;
    FUN_00602590(aiStack_40);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      iVar4 = aiStack_40[0];
      if (0xfff < uVar8) {
        iVar4 = *(int *)(aiStack_40[0] + -4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar8);
    }
    iVar4 = FUN_0088d190();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088d190();
  if (iVar4 == iVar2) {
    ppppiVar9 = (int ****)(param_1 + 2);
    if (param_1[1] == 0) {
      ppppiVar9 = (int ****)0x0;
    }
    if (ppppiVar9 != (int ****)0x0) {
      ExceptionList = pvStack_10;
      return ppppiVar9;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    apppiStack_28[0] = (int ***)((uint)apppiStack_28[0] & 0xffffff00);
    iVar4 = *param_1;
    uStack_8 = 2;
    iVar2 = FUN_0088cb40();
    if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    ppppiVar9 = (int ****)(param_1 + 2);
    ppppiVar5 = ppppiVar9;
    if (param_1[1] == 0) {
      ppppiVar5 = (int ****)0x0;
    }
    cVar1 = FUN_00c33b80(ppppiVar5,apppiStack_28);
    if (cVar1 != '\0') {
      iVar2 = FUN_00630cf0();
      iVar4 = param_1[1];
      if (iVar4 == iVar2) {
        if (ppppiVar9 != apppiStack_28) {
          ppppiVar5 = apppiStack_28;
          if (0xf < uStack_14) {
            ppppiVar5 = (int ****)apppiStack_28[0];
          }
          FUN_005542c0(ppppiVar5,uStack_18);
        }
      }
      else {
        if (iVar4 != 0) {
          (**(code **)(iVar4 + 8))(ppppiVar9);
          param_1[1] = 0;
        }
        FUN_0054ef60(apppiStack_28);
        param_1[1] = iVar2;
      }
      iVar4 = FUN_0088d190();
      *param_1 = iVar4;
      iVar2 = FUN_0088d190();
      if (iVar4 == iVar2) {
        iVar4 = param_1[1];
        FUN_005507b0();
        if (iVar4 == 0) {
          ppppiVar9 = (int ****)0x0;
        }
        ExceptionList = pvStack_10;
        return ppppiVar9;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  thunk_FUN_0088d190();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13784 ; VA 0x0088ab30 ; FUN_0088ab30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_0088ab30(int *param_1)

{
  undefined *puVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar5 = *param_1;
  iVar3 = FUN_00b00260();
  if (iVar5 == iVar3) {
    piVar8 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar8 = (int *)0x0;
    }
    if (piVar8 != (int *)0x0) {
      return piVar8;
    }
  }
  iVar5 = *param_1;
  iVar3 = FUN_0088cb40();
  if (iVar5 != iVar3) {
LAB_0088ac37:
    thunk_FUN_00b00260();
    uVar6 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
  }
  FUN_0060efa0();
  iVar5 = *param_1;
  iVar3 = FUN_0088cb40();
  if (iVar5 == iVar3) {
    piVar8 = param_1 + 2;
    piVar4 = piVar8;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    cVar2 = FUN_00585a40(piVar4,&iStack_34);
    if (cVar2 == '\0') goto LAB_0088ac37;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3d8)
       && (FUN_016f3809(&DAT_01ead3d8), DAT_01ead3d8 == -1)) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
    puVar1 = (undefined *)param_1[1];
    if (puVar1 == &DAT_01ead3cc) {
      *piVar8 = iStack_34;
      param_1[3] = iStack_30;
      param_1[4] = iStack_2c;
      param_1[5] = iStack_28;
      param_1[6] = iStack_24;
      param_1[7] = iStack_20;
      param_1[8] = iStack_1c;
      param_1[9] = iStack_18;
      param_1[10] = iStack_14;
      param_1[0xb] = iStack_10;
      param_1[0xc] = iStack_c;
      param_1[0xd] = iStack_8;
    }
    else {
      if (puVar1 != (undefined *)0x0) {
        (**(code **)(puVar1 + 8))(piVar8);
      }
      param_1[2] = iStack_34;
      param_1[3] = iStack_30;
      param_1[4] = iStack_2c;
      param_1[5] = iStack_28;
      param_1[6] = iStack_24;
      param_1[7] = iStack_20;
      param_1[8] = iStack_1c;
      param_1[9] = iStack_18;
      param_1[10] = iStack_14;
      param_1[0xb] = iStack_10;
      param_1[0xc] = iStack_c;
      param_1[0xd] = iStack_8;
      param_1[1] = (int)&DAT_01ead3cc;
    }
    iVar5 = FUN_00b00260();
    *param_1 = iVar5;
    iVar3 = FUN_00b00260();
    if (iVar5 == iVar3) {
      if (param_1[1] == 0) {
        piVar8 = (int *)0x0;
      }
      return piVar8;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13785 ; VA 0x0088acc0 ; FUN_0088acc0 */

int * __fastcall FUN_0088acc0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0088d230();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088ad7b:
    thunk_FUN_0088d230();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  FUN_0054d840(0);
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00a92430(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_0088ad7b;
    iVar2 = FUN_00630e40();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = (int)piStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = (int)piStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d230();
    *param_1 = iVar4;
    iVar2 = FUN_0088d230();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13786 ; VA 0x0088adb0 ; FUN_0088adb0 */

uint * __fastcall FUN_0088adb0(int *param_1)

{
  char cVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint *puVar7;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d2d0();
  if (iVar4 == iVar2) {
    puVar7 = (uint *)(param_1 + 2);
    if (param_1[1] == 0) {
      puVar7 = (uint *)0x0;
    }
    if (puVar7 != (uint *)0x0) {
      return puVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088ae8d:
    thunk_FUN_0088d2d0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  uStack_1c = uStack_1c & 0xffffff00;
  iStack_18 = 0;
  iStack_14 = 0;
  iStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    puVar7 = (uint *)(param_1 + 2);
    puVar3 = puVar7;
    if (param_1[1] == 0) {
      puVar3 = (uint *)0x0;
    }
    cVar1 = FUN_00585a40(puVar3,&uStack_1c);
    if (cVar1 == '\0') goto LAB_0088ae8d;
    iVar2 = FUN_00631070();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *puVar7 = uStack_1c;
      param_1[3] = iStack_18;
      param_1[4] = iStack_14;
      param_1[5] = iStack_10;
      *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_8,uStack_c);
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(puVar7);
      }
      param_1[2] = uStack_1c;
      param_1[3] = iStack_18;
      param_1[4] = iStack_14;
      param_1[5] = iStack_10;
      *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_8,uStack_c);
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d2d0();
    *param_1 = iVar4;
    iVar2 = FUN_0088d2d0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        puVar7 = (uint *)0x0;
      }
      return puVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13787 ; VA 0x0088aec0 ; FUN_0088aec0 */

int * __fastcall FUN_0088aec0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d370();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088afa0:
    thunk_FUN_0088d370();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  iStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d874b0(piVar3,&iStack_1c);
    if (cVar1 == '\0') goto LAB_0088afa0;
    iVar2 = FUN_00631150();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_1c;
      param_1[3] = iStack_18;
      param_1[4] = iStack_14;
      param_1[5] = iStack_10;
      *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_8,uStack_c);
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_1c;
      param_1[3] = iStack_18;
      param_1[4] = iStack_14;
      param_1[5] = iStack_10;
      *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_8,uStack_c);
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d370();
    *param_1 = iVar4;
    iVar2 = FUN_0088d370();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13788 ; VA 0x0088afd0 ; FUN_0088afd0 */

int * __fastcall FUN_0088afd0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d410();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b0b0:
    thunk_FUN_0088d410();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_14 = 0;
  iStack_10 = 0;
  iStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d87600(piVar3,&iStack_14);
    if (cVar1 == '\0') goto LAB_0088b0b0;
    iVar2 = FUN_006311c0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_14;
      param_1[3] = iStack_10;
      param_1[4] = iStack_c;
      param_1[5] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_14;
      param_1[3] = iStack_10;
      param_1[4] = iStack_c;
      param_1[5] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d410();
    *param_1 = iVar4;
    iVar2 = FUN_0088d410();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13789 ; VA 0x0088b0e0 ; FUN_0088b0e0 */

int * __fastcall FUN_0088b0e0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  undefined8 uStack_10;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_00a73110();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b1e3:
    thunk_FUN_00a73110();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  FUN_00a73410();
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00585a40(piVar3,&iStack_40);
    if (cVar1 == '\0') goto LAB_0088b1e3;
    iVar2 = FUN_00631230();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_40;
      param_1[3] = iStack_3c;
      param_1[4] = iStack_38;
      param_1[5] = iStack_34;
      param_1[6] = iStack_30;
      param_1[7] = iStack_2c;
      param_1[8] = iStack_28;
      param_1[9] = iStack_24;
      param_1[10] = iStack_20;
      param_1[0xb] = iStack_1c;
      param_1[0xc] = iStack_18;
      param_1[0xd] = iStack_14;
      *(undefined8 *)(param_1 + 0xe) = uStack_10;
      param_1[0x10] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_40;
      param_1[3] = iStack_3c;
      param_1[4] = iStack_38;
      param_1[5] = iStack_34;
      param_1[6] = iStack_30;
      param_1[7] = iStack_2c;
      param_1[8] = iStack_28;
      param_1[9] = iStack_24;
      param_1[10] = iStack_20;
      param_1[0xb] = iStack_1c;
      param_1[0xc] = iStack_18;
      param_1[0xd] = iStack_14;
      *(undefined8 *)(param_1 + 0xe) = uStack_10;
      param_1[0x10] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_00a73110();
    *param_1 = iVar4;
    iVar2 = FUN_00a73110();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13790 ; VA 0x0088b220 ; FUN_0088b220 */

int * __fastcall FUN_0088b220(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_00b33940();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b2f2:
    thunk_FUN_00b33940();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  uStack_10 = 0;
  uStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00585a40(piVar3,&uStack_10);
    if (cVar1 == '\0') goto LAB_0088b2f2;
    iVar2 = FUN_006312a0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *(ulonglong *)piVar7 = CONCAT44(uStack_c,uStack_10);
      param_1[4] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      *(ulonglong *)(param_1 + 2) = CONCAT44(uStack_c,uStack_10);
      param_1[4] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_00b33940();
    *param_1 = iVar4;
    iVar2 = FUN_00b33940();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13791 ; VA 0x0088b330 ; FUN_0088b330 */

void __fastcall FUN_0088b330(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d4b0();
  if (((iVar1 == iVar2) && (param_1[1] != 0)) && (param_1 != (int *)0xfffffff8)) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    FUN_00a33c70();
    iVar1 = *param_1;
    uStack_8 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_0056e380();
  }
  thunk_FUN_0088d4b0();
  uVar3 = FUN_005543f0();
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar4,uVar3);
}



/* FUNCTION 13792 ; VA 0x0088b3e0 ; FUN_0088b3e0 */

void __fastcall FUN_0088b3e0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar1 = *param_1;
  iVar2 = FUN_0088d550();
  if (((iVar1 == iVar2) && (param_1[1] != 0)) && (param_1 != (int *)0xfffffff8)) {
    return;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    iVar1 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_0088d550();
  uVar3 = FUN_005543f0();
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar4,uVar3);
}



/* FUNCTION 13793 ; VA 0x0088b450 ; FUN_0088b450 */

int * __fastcall FUN_0088b450(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d5f0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b53b:
    thunk_FUN_0088d5f0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_14 = 0;
  iStack_10 = 0;
  iStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00da8420(piVar3,&iStack_14);
    if (cVar1 == '\0') goto LAB_0088b53b;
    iVar2 = FUN_006313f0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_14;
      param_1[3] = iStack_10;
      param_1[4] = iStack_c;
      param_1[5] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_14;
      param_1[3] = iStack_10;
      param_1[4] = iStack_c;
      param_1[5] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d5f0();
    *param_1 = iVar4;
    iVar2 = FUN_0088d5f0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13794 ; VA 0x0088b570 ; FUN_0088b570 */

int * __fastcall FUN_0088b570(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d690();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b641:
    thunk_FUN_0088d690();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00da8610(piVar3,&iStack_c);
    if (cVar1 == '\0') goto LAB_0088b641;
    iVar2 = FUN_00631460();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_c;
      param_1[3] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_c;
      param_1[3] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d690();
    *param_1 = iVar4;
    iVar2 = FUN_0088d690();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13795 ; VA 0x0088b680 ; FUN_0088b680 */

int * __fastcall FUN_0088b680(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d730();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b75d:
    thunk_FUN_0088d730();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d877d0(piVar3,&iStack_c);
    if (cVar1 == '\0') goto LAB_0088b75d;
    iVar2 = FUN_006314d0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_c;
      param_1[3] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_c;
      param_1[3] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d730();
    *param_1 = iVar4;
    iVar2 = FUN_0088d730();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13796 ; VA 0x0088b790 ; FUN_0088b790 */

int * __fastcall FUN_0088b790(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar4 = *param_1;
  piStack_8 = param_1;
  iVar2 = FUN_0088d7d0();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b846:
    thunk_FUN_0088d7d0();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  piStack_8 = (int *)0x0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d878c0(piVar3,&piStack_8);
    if (cVar1 == '\0') goto LAB_0088b846;
    iVar2 = FUN_00631540();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = (int)piStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = (int)piStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d7d0();
    *param_1 = iVar4;
    iVar2 = FUN_0088d7d0();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13797 ; VA 0x0088b880 ; FUN_0088b880 */

int * __fastcall FUN_0088b880(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d870();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088b95c:
    thunk_FUN_0088d870();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  uStack_10 = 0;
  uStack_c = 0;
  iStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d879b0(piVar3,&uStack_10);
    if (cVar1 == '\0') goto LAB_0088b95c;
    iVar2 = FUN_006315b0();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *(ulonglong *)piVar7 = CONCAT44(uStack_c,uStack_10);
      param_1[4] = iStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      *(ulonglong *)(param_1 + 2) = CONCAT44(uStack_c,uStack_10);
      param_1[4] = iStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d870();
    *param_1 = iVar4;
    iVar2 = FUN_0088d870();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13798 ; VA 0x0088b990 ; FUN_0088b990 */

int * __fastcall FUN_0088b990(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_c;
  undefined2 uStack_8;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088d910();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
    if (piVar7 != (int *)0x0) {
      return piVar7;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088ba5c:
    thunk_FUN_0088d910();
    uVar5 = FUN_005543f0();
    uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
  }
  iVar4 = *param_1;
  iStack_c = 0;
  uStack_8 = 0;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar7 = param_1 + 2;
    piVar3 = piVar7;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    cVar1 = FUN_00d87ae0(piVar3,&iStack_c);
    if (cVar1 == '\0') goto LAB_0088ba5c;
    iVar2 = FUN_00631620();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *piVar7 = iStack_c;
      *(undefined2 *)(param_1 + 3) = uStack_8;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))(piVar7);
      }
      param_1[2] = iStack_c;
      *(undefined2 *)(param_1 + 3) = uStack_8;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088d910();
    *param_1 = iVar4;
    iVar2 = FUN_0088d910();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13799 ; VA 0x0088ba90 ; thunk_FUN_0088c260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall thunk_FUN_0088c260(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  char ****ppppcVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  char ***apppcStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [7];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4ee;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_00890320();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      FUN_0054ef60(piVar3);
      iStack_8 = 0;
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      cVar1 = FUN_017256a7((int)*(char *)ppppcVar4);
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      *(char *)ppppcVar4 = cVar1;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54
          ) && (FUN_016f3809(&DAT_01eded54), DAT_01eded54 == -1)) {
        iStack_8._0_1_ = 1;
        FUN_009ca470("NormalId");
        iStack_8._0_1_ = 2;
        _DAT_01edecf0 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
        FUN_009caf20(&DAT_01d62b48,6);
        FUN_016f3654(&LAB_01880900);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01eded54);
      }
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      cStack_11 = FUN_009cb180(ppppcVar4,auStack_18);
      iStack_8 = 0xffffffff;
      if (0xf < uStack_1c) {
        uVar8 = uStack_1c + 1;
        ppppcVar4 = (char ****)apppcStack_30[0];
        if (0xfff < uVar8) {
          ppppcVar4 = (char ****)apppcStack_30[0][-1];
          uVar8 = uStack_1c + 0x24;
          if ((char *)0x1f < (char *)((int)apppcStack_30[0] + (-4 - (int)ppppcVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppcVar4,uVar8);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppcStack_30[0] = (char ***)((uint)apppcStack_30[0] & 0xffffff00);
      if (cStack_11 != '\0') {
        FUN_00889060(auStack_18);
        iVar5 = thunk_FUN_00890320();
        *param_1 = iVar5;
        iVar2 = thunk_FUN_00890320();
        if (iVar5 == iVar2) {
          piVar3 = param_1 + 2;
          if (param_1[1] == 0) {
            piVar3 = (int *)0x0;
          }
          ExceptionList = pvStack_10;
          return piVar3;
        }
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
    }
  }
  thunk_FUN_00890320();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13800 ; VA 0x0088baa0 ; FUN_0088baa0 */

int * __fastcall FUN_0088baa0(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  undefined8 uStack_c;
  
  iVar4 = *param_1;
  iVar2 = FUN_0088c8c0();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088c8c0();
    if (iVar4 != iVar2) goto LAB_0088bcad;
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_c._0_4_ = *piVar3;
    uStack_c._4_4_ = (int)(uint)uStack_c >> 0x1f;
    FUN_00632eb0();
    iVar4 = FUN_0088da50();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088ca00();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088ca00();
    if (iVar4 != iVar2) goto LAB_0088bcad;
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_c = FUN_0172858a(*(undefined8 *)piVar3);
    FUN_00632eb0();
    iVar4 = FUN_0088da50();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088c960();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088c960();
    if (iVar4 != iVar2) goto LAB_0088bcad;
    uVar8 = FUN_017285e9();
    uStack_c = uVar8;
    FUN_00632eb0();
    iVar4 = FUN_0088da50();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088daf0();
  if (iVar4 == iVar2) {
    iVar4 = *param_1;
    iVar2 = FUN_0088daf0();
    if (iVar4 != iVar2) goto LAB_0088bcad;
    uStack_c._4_4_ = 0;
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    uStack_c._0_4_ = (uint)(*(char *)piVar3 != '\0');
    FUN_00632eb0();
    iVar4 = FUN_0088da50();
    *param_1 = iVar4;
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088da50();
  if (iVar4 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      return piVar3;
    }
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 != iVar2) {
LAB_0088bc88:
    thunk_FUN_0088da50();
    uVar6 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
  }
  iVar4 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar4 == iVar2) {
    piVar3 = param_1 + 2;
    piVar5 = piVar3;
    if (param_1[1] == 0) {
      piVar5 = (int *)0x0;
    }
    cVar1 = FUN_009ee890(piVar5,&uStack_c);
    if (cVar1 == '\0') goto LAB_0088bc88;
    iVar2 = FUN_005c9e80();
    iVar4 = param_1[1];
    if (iVar4 == iVar2) {
      *(undefined8 *)piVar3 = uStack_c;
    }
    else {
      if (iVar4 != 0) {
        (**(code **)(iVar4 + 8))();
      }
      *(undefined8 *)(param_1 + 2) = uStack_c;
      param_1[1] = iVar2;
    }
    iVar4 = FUN_0088da50();
    *param_1 = iVar4;
    iVar2 = FUN_0088da50();
    if (iVar4 == iVar2) {
      if (param_1[1] == 0) {
        piVar3 = (int *)0x0;
      }
      return piVar3;
    }
  }
LAB_0088bcad:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 13801 ; VA 0x0088bcc0 ; FUN_0088bcc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_0088bcc0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  float *pfVar5;
  double *pdVar6;
  int iVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined uStack_5;
  
  iVar3 = *param_1;
  iVar2 = FUN_0088c8c0();
  iVar7 = *param_1;
  if (iVar3 == iVar2) {
    iVar3 = FUN_0088c8c0();
    if (iVar7 != iVar3) goto LAB_0088be99;
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar3 = *piVar4;
    iVar2 = FUN_005c9ef0();
    iVar7 = param_1[1];
    if (iVar7 == iVar2) {
      *(bool *)(param_1 + 2) = iVar3 != 0;
    }
    else {
      if (iVar7 != 0) {
        (**(code **)(iVar7 + 8))(param_1 + 2);
      }
      *(bool *)(param_1 + 2) = iVar3 != 0;
      param_1[1] = iVar2;
    }
LAB_0088bdcd:
    iVar3 = FUN_0088daf0();
    *param_1 = iVar3;
  }
  else {
    iVar2 = FUN_0088da50();
    iVar3 = *param_1;
    if (iVar7 == iVar2) {
      iVar7 = FUN_0088da50();
      if (iVar3 != iVar7) goto LAB_0088be99;
      piVar4 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar4 = (int *)0x0;
      }
      if (*piVar4 == 0 && piVar4[1] == 0) {
LAB_0088bdbc:
        uStack_5 = 0;
      }
      else {
        uStack_5 = 1;
      }
LAB_0088bdc1:
      FUN_005e5200(&uStack_5);
      goto LAB_0088bdcd;
    }
    iVar2 = FUN_0088c960();
    iVar7 = *param_1;
    if (iVar3 == iVar2) {
      iVar3 = FUN_0088c960();
      if (iVar7 != iVar3) goto LAB_0088be99;
      pfVar5 = (float *)(param_1 + 2);
      if (param_1[1] == 0) {
        pfVar5 = (float *)0x0;
      }
      if ((NAN(*pfVar5) || NAN(DAT_018ce2f0)) == (*pfVar5 == DAT_018ce2f0)) {
        uStack_5 = 1;
      }
      else {
        uStack_5 = 0;
      }
      goto LAB_0088bdc1;
    }
    iVar3 = FUN_0088ca00();
    if (iVar7 == iVar3) {
      pdVar6 = (double *)FUN_00605ba0();
      if ((NAN(*pdVar6) || NAN(_PTR_018c6f48)) != (*pdVar6 == _PTR_018c6f48)) goto LAB_0088bdbc;
      uStack_5 = 1;
      goto LAB_0088bdc1;
    }
  }
  iVar3 = *param_1;
  iVar7 = FUN_0088daf0();
  if (iVar3 == iVar7) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      return piVar4;
    }
  }
  iVar3 = *param_1;
  iVar7 = FUN_0088cb40();
  if (iVar3 == iVar7) {
    iVar3 = *param_1;
    iVar7 = FUN_0088cb40();
    if (iVar3 == iVar7) {
      piVar4 = param_1 + 2;
      piVar8 = piVar4;
      if (param_1[1] == 0) {
        piVar8 = (int *)0x0;
      }
      cVar1 = FUN_009ee8e0(piVar8,&uStack_5);
      if (cVar1 == '\0') goto LAB_0088be74;
      iVar7 = FUN_005c9ef0();
      iVar3 = param_1[1];
      if (iVar3 == iVar7) {
        *(undefined *)piVar4 = uStack_5;
      }
      else {
        if (iVar3 != 0) {
          (**(code **)(iVar3 + 8))(piVar4);
        }
        *(undefined *)(param_1 + 2) = uStack_5;
        param_1[1] = iVar7;
      }
      iVar3 = FUN_0088daf0();
      *param_1 = iVar3;
      iVar7 = FUN_0088daf0();
      if (iVar3 == iVar7) {
        if (param_1[1] == 0) {
          piVar4 = (int *)0x0;
        }
        return piVar4;
      }
    }
LAB_0088be99:
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
LAB_0088be74:
  thunk_FUN_0088daf0();
  uVar9 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar9);
}



/* FUNCTION 13802 ; VA 0x0088beb0 ; FUN_0088beb0 */

int * __fastcall FUN_0088beb0(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba498;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088caa0();
  if (iVar5 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar4;
    }
  }
  iVar5 = *param_1;
  iVar3 = FUN_0088cb40();
  if (iVar5 == iVar3) {
    iStack_34 = 0;
    iStack_30 = 0;
    iStack_2c = 0;
    iStack_28 = 0;
    uStack_8 = 1;
    iStack_24 = FUN_0086e640();
    iStack_20 = FUN_0086e640();
    uStack_1c = uStack_1c & 0xffffff00;
    iStack_18 = 0;
    iVar5 = *param_1;
    uStack_8 = 2;
    iVar3 = FUN_0088cb40();
    if (iVar5 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    cVar2 = FUN_00585a40(piVar4,&iStack_38);
    if (cVar2 != '\0') {
      iStack_14 = FUN_008903d0();
      iVar5 = param_1[1];
      if (iVar5 == iStack_14) {
        param_1[2] = iStack_38;
        if (iStack_30 != 0) {
          LOCK();
          *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
          UNLOCK();
        }
        param_1[3] = iStack_34;
        piVar4 = (int *)param_1[4];
        param_1[4] = iStack_30;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar5 = piVar4[1] + -1;
          piVar4[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar5 = piVar4[2] + -1;
            piVar4[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (iStack_28 != 0) {
          LOCK();
          *(int *)(iStack_28 + 8) = *(int *)(iStack_28 + 8) + 1;
          UNLOCK();
        }
        param_1[5] = iStack_2c;
        piVar4 = (int *)param_1[6];
        param_1[6] = iStack_28;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
        param_1[7] = iStack_24;
        param_1[8] = iStack_20;
        param_1[9] = uStack_1c;
        param_1[10] = iStack_18;
      }
      else {
        if (iVar5 != 0) {
          (**(code **)(iVar5 + 8))(param_1 + 2);
          param_1[1] = 0;
        }
        FUN_0088dd80(&iStack_38);
        param_1[1] = iStack_14;
      }
      iVar5 = FUN_0088caa0();
      *param_1 = iVar5;
      iVar3 = FUN_0088caa0();
      if (iVar5 == iVar3) {
        piVar4 = param_1 + 2;
        if (param_1[1] == 0) {
          piVar4 = (int *)0x0;
        }
        FUN_0087dc70();
        ExceptionList = pvStack_10;
        return piVar4;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_0087dc70();
  }
  thunk_FUN_0088caa0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13803 ; VA 0x0088c0c0 ; FUN_0088c0c0 */

int * __fastcall FUN_0088c0c0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int ****ppppiVar3;
  int ****ppppiVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int ***pppiStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  int ***pppiStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int ***pppiStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cf00();
  if (iVar5 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar5 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar5 != iVar1) {
    thunk_FUN_0088cf00();
    uVar6 = FUN_005543f0();
    uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
  }
  uStack_30 = 0xf00000000;
  pppiStack_40 = (int ***)((uint)pppiStack_40 & 0xffffff00);
  iVar5 = *param_1;
  uStack_8 = 0;
  iVar1 = FUN_0088cb40();
  if (iVar5 == iVar1) {
    ppppiVar4 = (int ****)(param_1 + 2);
    ppppiVar3 = ppppiVar4;
    if (param_1[1] == 0) {
      ppppiVar3 = (int ****)0x0;
    }
    FUN_0054ef60(ppppiVar3);
    pppiStack_28 = pppiStack_58;
    uStack_24 = uStack_54;
    uStack_20 = uStack_50;
    uStack_1c = uStack_4c;
    uStack_18 = CONCAT44(uStack_44,uStack_48);
    FUN_005507b0();
    pppiStack_40 = pppiStack_28;
    uStack_3c = uStack_24;
    uStack_38 = uStack_20;
    uStack_34 = uStack_1c;
    uStack_30 = uStack_18;
    iVar1 = FUN_00630ac0();
    iVar5 = param_1[1];
    uStack_18._4_4_ = iVar1;
    if (iVar5 == iVar1) {
      if (ppppiVar4 != &pppiStack_40) {
        ppppiVar4 = &pppiStack_40;
        if (0xf < uStack_44) {
          ppppiVar4 = (int ****)pppiStack_58;
        }
        FUN_005542c0(ppppiVar4,uStack_48);
      }
    }
    else {
      if (iVar5 != 0) {
        (**(code **)(iVar5 + 8))(ppppiVar4);
        param_1[1] = 0;
      }
      FUN_0054ef60(&pppiStack_40);
      param_1[1] = uStack_18._4_4_;
    }
    iVar5 = FUN_0088cf00();
    *param_1 = iVar5;
    iVar1 = FUN_0088cf00();
    if (iVar5 == iVar1) {
      piVar2 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar2 = (int *)0x0;
      }
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return piVar2;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13804 ; VA 0x0088c260 ; FUN_0088c260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_0088c260(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  char ****ppppcVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  char ***apppcStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [7];
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4ee;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_00890320();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      FUN_0054ef60(piVar3);
      iStack_8 = 0;
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      cVar1 = FUN_017256a7((int)*(char *)ppppcVar4);
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      *(char *)ppppcVar4 = cVar1;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54
          ) && (FUN_016f3809(&DAT_01eded54), DAT_01eded54 == -1)) {
        iStack_8._0_1_ = 1;
        FUN_009ca470("NormalId");
        iStack_8._0_1_ = 2;
        _DAT_01edecf0 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
        FUN_009caf20(&DAT_01d62b48,6);
        FUN_016f3654(&LAB_01880900);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_016f37bf(&DAT_01eded54);
      }
      ppppcVar4 = apppcStack_30;
      if (0xf < uStack_1c) {
        ppppcVar4 = (char ****)apppcStack_30[0];
      }
      cStack_11 = FUN_009cb180(ppppcVar4,auStack_18);
      iStack_8 = 0xffffffff;
      if (0xf < uStack_1c) {
        uVar8 = uStack_1c + 1;
        ppppcVar4 = (char ****)apppcStack_30[0];
        if (0xfff < uVar8) {
          ppppcVar4 = (char ****)apppcStack_30[0][-1];
          uVar8 = uStack_1c + 0x24;
          if ((char *)0x1f < (char *)((int)apppcStack_30[0] + (-4 - (int)ppppcVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppcVar4,uVar8);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppcStack_30[0] = (char ***)((uint)apppcStack_30[0] & 0xffffff00);
      if (cStack_11 != '\0') {
        FUN_00889060(auStack_18);
        iVar5 = thunk_FUN_00890320();
        *param_1 = iVar5;
        iVar2 = thunk_FUN_00890320();
        if (iVar5 == iVar2) {
          piVar3 = param_1 + 2;
          if (param_1[1] == 0) {
            piVar3 = (int *)0x0;
          }
          ExceptionList = pvStack_10;
          return piVar3;
        }
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
    }
  }
  thunk_FUN_00890320();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13805 ; VA 0x0088c480 ; FUN_0088c480 */

char * FUN_0088c480(char *param_1,char *param_2,undefined4 param_3,int *param_4,uint *param_5)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  byte bVar6;
  char *pcVar7;
  byte bStack_8;
  
  iVar3 = DAT_01d62b18;
  if (param_1 != param_2) {
    do {
      while (iVar2 = (int)*param_1, DAT_01d62b40 == iVar2) {
        iVar2 = 0x3e;
LAB_0088c54a:
        param_1 = param_1 + 1;
        if (param_1 == param_2) goto LAB_0088c52d;
        while (iVar4 = (int)*param_1, DAT_01d62b40 != iVar4) {
          if (DAT_01d62b44 == iVar4) {
            iVar4 = 0x3f;
            goto LAB_0088c5d6;
          }
          if ((iVar4 < DAT_01d62a48) || (DAT_01d62aac < iVar4)) {
            if ((DAT_01d62ab0 <= iVar4) && (iVar4 <= DAT_01d62b14)) {
              iVar4 = (iVar4 - DAT_01d62ab0) + 0x1a;
              goto LAB_0088c59a;
            }
            if ((iVar3 <= iVar4) && (iVar4 <= DAT_01d62b3c)) {
              iVar4 = (iVar4 - iVar3) + 0x34;
              goto LAB_0088c59a;
            }
            if (iVar4 == 0x3d) goto LAB_0088c511;
          }
          else {
            iVar4 = iVar4 - DAT_01d62a48;
LAB_0088c59a:
            if (iVar4 != -2) {
              if (iVar4 != -1) goto LAB_0088c5d6;
              goto LAB_0088c511;
            }
          }
          param_1 = param_1 + 1;
          if (param_1 == param_2) {
            *param_5 = *param_5 | 3;
            return param_1;
          }
        }
        iVar4 = 0x3e;
LAB_0088c5d6:
        param_1 = param_1 + 1;
        bStack_8 = (byte)(iVar4 >> 4);
        bStack_8 = bStack_8 & 3;
        bStack_8 = bStack_8 | (char)iVar2 << 2;
        if (param_1 == param_2) goto LAB_0088c52d;
        while (iVar2 = (int)*param_1, DAT_01d62b40 != iVar2) {
          if (DAT_01d62b44 == iVar2) {
            iVar2 = 0x3f;
            goto LAB_0088c685;
          }
          if ((iVar2 < DAT_01d62a48) || (DAT_01d62aac < iVar2)) {
            if ((DAT_01d62ab0 <= iVar2) && (iVar2 <= DAT_01d62b14)) {
              iVar2 = (iVar2 - DAT_01d62ab0) + 0x1a;
              goto LAB_0088c647;
            }
            if ((iVar3 <= iVar2) && (iVar2 <= DAT_01d62b3c)) {
              iVar2 = (iVar2 - iVar3) + 0x34;
              goto LAB_0088c647;
            }
            if (iVar2 == 0x3d) goto LAB_0088c870;
          }
          else {
            iVar2 = iVar2 - DAT_01d62a48;
LAB_0088c647:
            if (iVar2 != -2) {
              if (iVar2 == -1) {
LAB_0088c870:
                pcVar7 = param_1 + 1;
                if (pcVar7 != param_2) {
                  iVar3 = FUN_00577c50((int)*pcVar7);
                  if (iVar3 == -1) {
                    pcVar7 = param_1 + 2;
                  }
                  FUN_0056ec80(bStack_8);
                  return pcVar7;
                }
                *param_5 = *param_5 | 1;
                FUN_0056ec80(bStack_8);
                return pcVar7;
              }
              goto LAB_0088c685;
            }
          }
          param_1 = param_1 + 1;
          if (param_1 == param_2) {
            *param_5 = *param_5 | 3;
            return param_1;
          }
        }
        iVar2 = 0x3e;
LAB_0088c685:
        bVar5 = (byte)(iVar2 >> 2) & 0xf | (char)iVar4 << 4;
joined_r0x0088c69d:
        do {
          param_1 = param_1 + 1;
          if (param_1 == param_2) {
            *param_5 = *param_5 | 1;
            return param_1;
          }
          iVar4 = (int)*param_1;
          if (DAT_01d62b40 == iVar4) {
            iVar4 = 0x3e;
            goto LAB_0088c762;
          }
          if (DAT_01d62b44 == iVar4) {
            iVar4 = 0x3f;
            goto LAB_0088c762;
          }
          if ((iVar4 < DAT_01d62a48) || (DAT_01d62aac < iVar4)) {
            if ((iVar4 < DAT_01d62ab0) || (DAT_01d62b14 < iVar4)) {
              if ((iVar4 < iVar3) || (DAT_01d62b3c < iVar4)) {
                if (iVar4 == 0x3d) goto LAB_0088c712;
                goto joined_r0x0088c69d;
              }
              iVar4 = (iVar4 - iVar3) + 0x34;
            }
            else {
              iVar4 = (iVar4 - DAT_01d62ab0) + 0x1a;
            }
          }
          else {
            iVar4 = iVar4 - DAT_01d62a48;
          }
        } while (iVar4 == -2);
        if (iVar4 == -1) {
LAB_0088c712:
          FUN_0056ec80(bStack_8);
          FUN_0056ec80(bVar5);
          return param_1 + 1;
        }
LAB_0088c762:
        bVar6 = (byte)iVar4 & 0x3f | (char)iVar2 << 6;
        if (param_4 != (int *)0x0) {
          if (*(int *)param_4[8] != 0) {
            iVar3 = *(int *)param_4[0xc];
            if (0 < iVar3) {
              *(int *)param_4[0xc] = iVar3 + -1;
              pbVar1 = *(byte **)param_4[8];
              *(byte **)param_4[8] = pbVar1 + 1;
              *pbVar1 = bStack_8;
              iVar3 = DAT_01d62b18;
              goto LAB_0088c7bc;
            }
          }
          (**(code **)(*param_4 + 0xc))(bStack_8);
          iVar3 = DAT_01d62b18;
        }
LAB_0088c7bc:
        if (param_4 != (int *)0x0) {
          if (*(int *)param_4[8] != 0) {
            iVar3 = *(int *)param_4[0xc];
            if (0 < iVar3) {
              *(int *)param_4[0xc] = iVar3 + -1;
              pbVar1 = *(byte **)param_4[8];
              *(byte **)param_4[8] = pbVar1 + 1;
              *pbVar1 = bVar5;
              iVar3 = DAT_01d62b18;
              goto LAB_0088c80e;
            }
          }
          (**(code **)(*param_4 + 0xc))(bVar5);
          iVar3 = DAT_01d62b18;
        }
LAB_0088c80e:
        if (param_4 != (int *)0x0) {
          if (*(int *)param_4[8] != 0) {
            iVar3 = *(int *)param_4[0xc];
            if (0 < iVar3) {
              *(int *)param_4[0xc] = iVar3 + -1;
              pbVar1 = *(byte **)param_4[8];
              *(byte **)param_4[8] = pbVar1 + 1;
              *pbVar1 = bVar6;
              iVar3 = DAT_01d62b18;
              goto LAB_0088c85a;
            }
          }
          (**(code **)(*param_4 + 0xc))(bVar6);
          iVar3 = DAT_01d62b18;
        }
LAB_0088c85a:
        param_1 = param_1 + 1;
        if (param_1 == param_2) {
          return param_1;
        }
      }
      if (DAT_01d62b44 == iVar2) {
        iVar2 = 0x3f;
        goto LAB_0088c54a;
      }
      if ((iVar2 < DAT_01d62a48) || (DAT_01d62aac < iVar2)) {
        if ((DAT_01d62ab0 <= iVar2) && (iVar2 <= DAT_01d62b14)) {
          iVar2 = (iVar2 - DAT_01d62ab0) + 0x1a;
          goto LAB_0088c503;
        }
        if ((iVar3 <= iVar2) && (iVar2 <= DAT_01d62b3c)) {
          iVar2 = (iVar2 - iVar3) + 0x34;
          goto LAB_0088c503;
        }
        if (iVar2 == 0x3d) goto LAB_0088c511;
      }
      else {
        iVar2 = iVar2 - DAT_01d62a48;
LAB_0088c503:
        if ((-1 < iVar2) || (iVar2 != -2)) {
          if (iVar2 == -1) {
LAB_0088c511:
            *param_5 = *param_5 | 2;
            return param_1;
          }
          goto LAB_0088c54a;
        }
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
LAB_0088c52d:
    *param_5 = *param_5 | 3;
  }
  return param_1;
}



/* FUNCTION 13806 ; VA 0x0088c8c0 ; FUN_0088c8c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088c8c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba50c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede8dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede8dc);
    if (DAT_01ede8dc == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cd9c,2,1,0,0);
      _DAT_01ede8b8 = RBX::Reflection::TType<int>::vftable;
      FUN_016f3654(&LAB_01880920);
      FUN_016f37bf(&DAT_01ede8dc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede8b8;
}



/* FUNCTION 13807 ; VA 0x0088c960 ; FUN_0088c960 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088c960(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba52c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede954) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede954);
    if (DAT_01ede954 == -1) {
      uStack_8 = 0;
      FUN_00888860("float",4,1,1,0);
      _DAT_01ede930 = RBX::Reflection::TType<float>::vftable;
      FUN_016f3654(&LAB_01880930);
      FUN_016f37bf(&DAT_01ede954);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede930;
}



/* FUNCTION 13808 ; VA 0x0088ca00 ; FUN_0088ca00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088ca00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba54c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede97c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede97c);
    if (DAT_01ede97c == -1) {
      uStack_8 = 0;
      FUN_00888860("double",5,1,1,0);
      _DAT_01ede958 = RBX::Reflection::TType<double>::vftable;
      FUN_016f3654(&LAB_01880940);
      FUN_016f37bf(&DAT_01ede97c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede958;
}



/* FUNCTION 13809 ; VA 0x0088caa0 ; FUN_0088caa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088caa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba56c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeae4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeae4);
    if (DAT_01edeae4 == -1) {
      uStack_8 = 0;
      FUN_00888860("EventInstance",0x35,0,0,0);
      _DAT_01edeac0 = RBX::Reflection::TType<struct_RBX::Lua::EventInstance>::vftable;
      FUN_016f3654(&LAB_01880950);
      FUN_016f37bf(&DAT_01edeae4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeac0;
}



/* FUNCTION 13810 ; VA 0x0088cb40 ; FUN_0088cb40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cb40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba58c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9cc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9cc);
    if (DAT_01ede9cc == -1) {
      uStack_8 = 0;
      FUN_00888860("string",6,0,0,0);
      _DAT_01ede9a8 =
           RBX::Reflection::
           TType<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880960);
      FUN_016f37bf(&DAT_01ede9cc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede9a8;
}



/* FUNCTION 13811 ; VA 0x0088cbe0 ; FUN_0088cbe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cbe0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba5ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea6c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea6c);
    if (DAT_01edea6c == -1) {
      uStack_8 = 0;
      FUN_00888860("Tuple",0x22,0,0,0);
      _DAT_01edea48 =
           RBX::Reflection::TType<class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>::
           vftable;
      FUN_016f3654(&LAB_01880970);
      FUN_016f37bf(&DAT_01edea6c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea48;
}



/* FUNCTION 13812 ; VA 0x0088cc80 ; FUN_0088cc80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cc80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba5cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede8b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede8b4);
    if (DAT_01ede8b4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Objects",9,0,0,0);
      _DAT_01ede890 =
           RBX::Reflection::
           TType<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880980);
      FUN_016f37bf(&DAT_01ede8b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede890;
}



/* FUNCTION 13813 ; VA 0x0088cd20 ; FUN_0088cd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cd20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba5ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede864) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede864);
    if (DAT_01ede864 == -1) {
      uStack_8 = 0;
      FUN_00888860("Object",0x31,0,0,0);
      _DAT_01ede840 =
           RBX::Reflection::TType<class_std::shared_ptr<class_RBX::Reflection::DescribedBase>_>::
           vftable;
      FUN_016f3654(&LAB_01880990);
      FUN_016f37bf(&DAT_01ede864);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede840;
}



/* FUNCTION 13814 ; VA 0x0088cdc0 ; FUN_0088cdc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cdc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba60c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede88c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede88c);
    if (DAT_01ede88c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cd78,8,0,0,0);
      _DAT_01ede868 = RBX::Reflection::TType<class_std::shared_ptr<class_RBX::Instance>_>::vftable;
      FUN_016f3654(&LAB_018809a0);
      FUN_016f37bf(&DAT_01ede88c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede868;
}



/* FUNCTION 13815 ; VA 0x0088ce60 ; FUN_0088ce60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088ce60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba62c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebd4);
    if (DAT_01edebd4 == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf58,0x16,0,0,0);
      _DAT_01edebb0 = RBX::Reflection::TType<class_RBX::Axes>::vftable;
      FUN_016f3654(&LAB_018809b0);
      FUN_016f37bf(&DAT_01edebd4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edebb0;
}



/* FUNCTION 13816 ; VA 0x0088cf00 ; FUN_0088cf00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cf00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba64c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edecc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edecc4);
    if (DAT_01edecc4 == -1) {
      uStack_8 = 0;
      FUN_00888860("BinaryString",0x1e,0,0,0);
      _DAT_01edeca0 = RBX::Reflection::TType<class_RBX::BinaryString>::vftable;
      FUN_016f3654(&LAB_018809c0);
      FUN_016f37bf(&DAT_01edecc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeca0;
}



/* FUNCTION 13817 ; VA 0x0088cfa0 ; FUN_0088cfa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088cfa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba66c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec74);
    if (DAT_01edec74 == -1) {
      uStack_8 = 0;
      FUN_008887b0("BrickColor",&DAT_0191cd9c,0x1c,0,0,0);
      _DAT_01edec50 = RBX::Reflection::TType<class_RBX::BrickColor>::vftable;
      FUN_016f3654(&LAB_018809d0);
      FUN_016f37bf(&DAT_01edec74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec50;
}



/* FUNCTION 13818 ; VA 0x0088d050 ; FUN_0088d050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba68c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebfc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebfc);
    if (DAT_01edebfc == -1) {
      uStack_8 = 0;
      FUN_00888860("Color3",0x11,0,0,0);
      _DAT_01edebd8 = RBX::Reflection::TType<class_G3D::Color3>::vftable;
      FUN_016f3654(&LAB_018809e0);
      FUN_016f37bf(&DAT_01edebfc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edebd8;
}



/* FUNCTION 13819 ; VA 0x0088d0f0 ; FUN_0088d0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d0f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec24) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec24);
    if (DAT_01edec24 == -1) {
      uStack_8 = 0;
      FUN_00888860("Color3uint8",0x12,0,0,0);
      _DAT_01edec00 = RBX::Reflection::TType<class_G3D::Color3uint8>::vftable;
      FUN_016f3654(&LAB_018809f0);
      FUN_016f37bf(&DAT_01edec24);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec00;
}



/* FUNCTION 13820 ; VA 0x0088d190 ; FUN_0088d190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d190(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9a4);
    if (DAT_01ede9a4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Content",0x30,0,0,0);
      _DAT_01ede980 = RBX::Reflection::TType<class_RBX::ContentId>::vftable;
      FUN_016f3654(&LAB_01880a00);
      FUN_016f37bf(&DAT_01ede9a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede980;
}



/* FUNCTION 13821 ; VA 0x0088d230 ; FUN_0088d230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba6ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edebac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edebac);
    if (DAT_01edebac == -1) {
      uStack_8 = 0;
      FUN_00888860("Faces",0x15,0,0,0);
      _DAT_01edeb88 = RBX::Reflection::TType<class_RBX::Faces>::vftable;
      FUN_016f3654(&LAB_01880a10);
      FUN_016f37bf(&DAT_01edebac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb88;
}



/* FUNCTION 13822 ; VA 0x0088d2d0 ; FUN_0088d2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d2d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba70c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb0c);
    if (DAT_01edeb0c == -1) {
      uStack_8 = 0;
      FUN_00888860("PhysicalProperties",0x1b,0,0,0);
      _DAT_01edeae8 = RBX::Reflection::TType<class_RBX::PhysicalProperties>::vftable;
      FUN_016f3654(&LAB_01880a20);
      FUN_016f37bf(&DAT_01edeb0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeae8;
}



/* FUNCTION 13823 ; VA 0x0088d370 ; FUN_0088d370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d370(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba72c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec4c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec4c);
    if (DAT_01edec4c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf8c,10,0,0,0);
      _DAT_01edec28 = RBX::Reflection::TType<class_RBX::RbxRay>::vftable;
      FUN_016f3654(&LAB_01880a30);
      FUN_016f37bf(&DAT_01edec4c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec28;
}



/* FUNCTION 13824 ; VA 0x0088d410 ; FUN_0088d410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d410(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba74c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb34);
    if (DAT_01edeb34 == -1) {
      uStack_8 = 0;
      FUN_00888860("Rect2D",0xf,0,0,0);
      _DAT_01edeb10 = RBX::Reflection::TType<class_G3D::Rect2D>::vftable;
      FUN_016f3654(&LAB_01880a40);
      FUN_016f37bf(&DAT_01edeb34);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb10;
}



/* FUNCTION 13825 ; VA 0x0088d4b0 ; FUN_0088d4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d4b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba76c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edecec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edecec);
    if (DAT_01edecec == -1) {
      uStack_8 = 0;
      FUN_00888860("SharedString",0x3b,0,0,0);
      _DAT_01edecc8 = RBX::Reflection::TType<class_RBX::SharedString>::vftable;
      FUN_016f3654(&LAB_01880a50);
      FUN_016f37bf(&DAT_01edecec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edecc8;
}



/* FUNCTION 13826 ; VA 0x0088d550 ; FUN_0088d550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d550(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba78c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edec9c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edec9c);
    if (DAT_01edec9c == -1) {
      uStack_8 = 0;
      FUN_00888860("SystemAddress",0x1d,0,0,0);
      _DAT_01edec78 = RBX::Reflection::TType<class_RBX::SystemAddress>::vftable;
      FUN_016f3654(&LAB_01880a60);
      FUN_016f37bf(&DAT_01edec9c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edec78;
}



/* FUNCTION 13827 ; VA 0x0088d5f0 ; FUN_0088d5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d5f0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb84);
    if (DAT_01edeb84 == -1) {
      uStack_8 = 0;
      FUN_00888860("UDim2",0x14,0,0,0);
      _DAT_01edeb60 = RBX::Reflection::TType<class_RBX::UDim2>::vftable;
      FUN_016f3654(&LAB_01880a70);
      FUN_016f37bf(&DAT_01edeb84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb60;
}



/* FUNCTION 13828 ; VA 0x0088d690 ; FUN_0088d690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d690(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeb5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeb5c);
    if (DAT_01edeb5c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cf28,0x13,0,0,0);
      _DAT_01edeb38 = RBX::Reflection::TType<class_RBX::UDim>::vftable;
      FUN_016f3654(&LAB_01880a80);
      FUN_016f37bf(&DAT_01edeb5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeb38;
}



/* FUNCTION 13829 ; VA 0x0088d730 ; FUN_0088d730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d730(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba7ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea1c);
    if (DAT_01edea1c == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector2",0xb,0,0,0);
      _DAT_01ede9f8 = RBX::Reflection::TType<class_G3D::Vector2>::vftable;
      FUN_016f3654(&LAB_01880a90);
      FUN_016f37bf(&DAT_01edea1c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede9f8;
}



/* FUNCTION 13830 ; VA 0x0088d7d0 ; FUN_0088d7d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d7d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba80c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea94) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea94);
    if (DAT_01edea94 == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector2int16",0xd,0,0,0);
      _DAT_01edea70 = RBX::Reflection::TType<class_G3D::Vector2int16>::vftable;
      FUN_016f3654(&LAB_01880aa0);
      FUN_016f37bf(&DAT_01edea94);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea70;
}



/* FUNCTION 13831 ; VA 0x0088d870 ; FUN_0088d870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d870(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba82c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede9f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede9f4);
    if (DAT_01ede9f4 == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector3",0xc,0,0,0);
      _DAT_01ede9d0 = RBX::Reflection::TType<class_G3D::Vector3>::vftable;
      FUN_016f3654(&LAB_01880ab0);
      FUN_016f37bf(&DAT_01ede9f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede9d0;
}



/* FUNCTION 13832 ; VA 0x0088d910 ; FUN_0088d910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d910(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba84c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeabc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeabc);
    if (DAT_01edeabc == -1) {
      uStack_8 = 0;
      FUN_00888860("Vector3int16",0xe,0,0,0);
      _DAT_01edea98 = RBX::Reflection::TType<class_G3D::Vector3int16>::vftable;
      FUN_016f3654(&LAB_01880ac0);
      FUN_016f37bf(&DAT_01edeabc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea98;
}



/* FUNCTION 13833 ; VA 0x0088d9b0 ; FUN_0088d9b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088d9b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba86c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edea44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edea44);
    if (DAT_01edea44 == -1) {
      uStack_8 = 0;
      FUN_00888860("Connection",0x2f,0,0,0);
      _DAT_01edea20 = RBX::Reflection::TType<class_rbx::signals::connection>::vftable;
      FUN_016f3654(&LAB_01880ad0);
      FUN_016f37bf(&DAT_01edea44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edea20;
}



/* FUNCTION 13834 ; VA 0x0088da50 ; FUN_0088da50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088da50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba88c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede904) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede904);
    if (DAT_01ede904 == -1) {
      uStack_8 = 0;
      FUN_00888860("int64",3,1,0,0);
      _DAT_01ede8e0 = RBX::Reflection::TType<__int64>::vftable;
      FUN_016f3654(&LAB_01880ae0);
      FUN_016f37bf(&DAT_01ede904);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede8e0;
}



/* FUNCTION 13835 ; VA 0x0088daf0 ; FUN_0088daf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0088daf0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba8ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede92c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede92c);
    if (DAT_01ede92c == -1) {
      uStack_8 = 0;
      FUN_00888860(&DAT_0191cdb8,1,1,0,0);
      _DAT_01ede908 = RBX::Reflection::TType<bool>::vftable;
      FUN_016f3654(&LAB_01880af0);
      FUN_016f37bf(&DAT_01ede92c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede908;
}



/* FUNCTION 13836 ; VA 0x0088db90 ; FUN_0088db90 */

void FUN_0088db90(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ac59f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    FUN_00569550(*param_2,&uStack_11);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13837 ; VA 0x0088dc10 ; FUN_0088dc10 */

void __thiscall FUN_0088dc10(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
              ::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 13838 ; VA 0x0088dc70 ; thunk_FUN_0088caa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_0088caa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba56c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edeae4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edeae4);
    if (DAT_01edeae4 == -1) {
      uStack_8 = 0;
      FUN_00888860("EventInstance",0x35,0,0,0);
      _DAT_01edeac0 = RBX::Reflection::TType<struct_RBX::Lua::EventInstance>::vftable;
      FUN_016f3654(&LAB_01880950);
      FUN_016f37bf(&DAT_01edeae4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edeac0;
}



/* FUNCTION 13839 ; VA 0x0088dca0 ; thunk_FUN_00890320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00890320(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baa16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eded54);
    if (DAT_01eded54 == -1) {
      uStack_8 = 0;
      FUN_009ca470("NormalId");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edecf0 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
      FUN_009caf20(&DAT_01d62b48,6);
      FUN_016f3654(&LAB_01880900);
      FUN_016f37bf(&DAT_01eded54);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edecf0;
}



/* FUNCTION 13840 ; VA 0x0088dcb0 ; FUN_0088dcb0 */

undefined4 * __fastcall FUN_0088dcb0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("NormalId");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
  FUN_009caf20(&DAT_01d62b48,6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13841 ; VA 0x0088dd10 ; FUN_0088dd10 */

undefined4 * __thiscall FUN_0088dd10(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_2[3] = 0;
  param_2[4] = 0;
  uVar1 = param_2[6];
  uVar2 = param_2[7];
  uVar3 = param_2[8];
  param_1[5] = param_2[5];
  param_1[6] = uVar1;
  param_1[7] = uVar2;
  param_1[8] = uVar3;
  return param_1;
}



/* FUNCTION 13842 ; VA 0x0088dd80 ; FUN_0088dd80 */

undefined4 * __thiscall FUN_0088dd80(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  uVar4 = param_2[8];
  param_1[5] = param_2[5];
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  param_1[8] = uVar4;
  return param_1;
}



/* FUNCTION 13843 ; VA 0x0088ddf0 ; FUN_0088ddf0 */

undefined4 * __thiscall FUN_0088ddf0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = param_2[1];
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
    UNLOCK();
    iVar2 = param_2[1];
  }
  *param_1 = *param_2;
  piVar1 = (int *)param_1[1];
  param_1[1] = iVar2;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 13844 ; VA 0x0088de30 ; FUN_0088de30 */

undefined4 * __thiscall FUN_0088de30(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  *param_1 = *param_2;
  iVar6 = param_2[2];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = param_2[2];
  }
  param_1[1] = param_2[1];
  piVar2 = (int *)param_1[2];
  param_1[2] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = param_2[4];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
    UNLOCK();
    iVar6 = param_2[4];
  }
  param_1[3] = param_2[3];
  piVar2 = (int *)param_1[4];
  param_1[4] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = param_2[6];
  uVar4 = param_2[7];
  uVar5 = param_2[8];
  param_1[5] = param_2[5];
  param_1[6] = uVar3;
  param_1[7] = uVar4;
  param_1[8] = uVar5;
  return param_1;
}



/* FUNCTION 13845 ; VA 0x0088ded0 ; FUN_0088ded0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0088ded0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
  _DAT_01f0e7c0 = _DAT_01f0e7c0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 13846 ; VA 0x0088df00 ; FUN_0088df00 */

int * __thiscall FUN_0088df00(int *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 13847 ; VA 0x0088df80 ; FUN_0088df80 */

int FUN_0088df80(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int in_stack_000000d4;
  int *in_stack_000000d8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = in_stack_000000d4;
  puStack_c = &LAB_017ba8d3;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_0088a3d0();
  puVar4 = *(undefined4 **)(iVar3 + 4);
  if (*(undefined4 **)(iVar3 + 8) == puVar4) {
    FUN_005c1970(puVar4,puVar5);
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar4 = *puVar5;
    puVar4[1] = puVar5[1];
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 8;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_2 != 0) {
    param_2 = (**(code **)(param_2 + 8))(&stack0x0000000c);
  }
  piVar1 = in_stack_000000d8;
  if (in_stack_000000d8 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_000000d8 + 1;
    iVar3 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_2 = (**(code **)*in_stack_000000d8)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        param_2 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13848 ; VA 0x0088e040 ; FUN_0088e040 */

undefined4 FUN_0088e040(int param_1)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede5c0);
    if (iVar2 != 0) {
      iVar2 = FUN_0087cde0(DAT_01ede5c4);
      if (iVar2 != 0) {
        iVar2 = FUN_0087cde0(DAT_01ede5c8);
        if (iVar2 != 0) {
          FUN_0087cf20(param_1);
          FUN_0087cf20(param_1 + 4);
          FUN_0087cf20(param_1 + 8);
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 13849 ; VA 0x0088e0d0 ; FUN_0088e0d0 */

uint FUN_0088e0d0(undefined2 *param_1)

{
  uint uVar1;
  undefined2 auStack_10 [2];
  undefined2 auStack_c [2];
  undefined2 auStack_8 [2];
  
  uVar1 = FUN_0087d4d0();
  if ((char)uVar1 == '\0') {
    uVar1 = FUN_0087cde0(DAT_01ede5c0);
    if (uVar1 != 0) {
      uVar1 = FUN_0087cde0(DAT_01ede5c4);
      if (uVar1 != 0) {
        uVar1 = FUN_0087cde0(DAT_01ede5c8);
        if (uVar1 != 0) {
          FUN_0087ce60(auStack_8);
          FUN_0087ce60(auStack_c);
          FUN_0087ce60(auStack_10);
          *param_1 = auStack_8[0];
          param_1[1] = auStack_c[0];
          param_1[2] = auStack_10[0];
          return CONCAT31((uint3)(byte)((ushort)auStack_10[0] >> 8),1);
        }
      }
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 13850 ; VA 0x0088e180 ; FUN_0088e180 */

void FUN_0088e180(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = FUN_00882b10(DAT_01ede5c0);
  iVar3 = FUN_00882b10(DAT_01ede5c4);
  iVar4 = FUN_00882b10(DAT_01ede5c8);
  uVar1 = *param_2;
  FUN_0087ccc0();
  *(undefined4 *)(iVar2 + 0x18) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  uVar1 = param_2[1];
  FUN_0087ccc0();
  *(undefined4 *)(iVar3 + 0x18) = uVar1;
  *(undefined4 *)(iVar3 + 0x14) = 7;
  uVar1 = param_2[2];
  FUN_0087ccc0();
  *(undefined4 *)(iVar4 + 0x18) = uVar1;
  *(undefined4 *)(iVar4 + 0x14) = 7;
  return;
}



/* FUNCTION 13851 ; VA 0x0088e230 ; FUN_0088e230 */

void FUN_0088e230(undefined4 param_1,short *param_2)

{
  short sVar1;
  short sVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar4 = FUN_00882b10(DAT_01ede5c0);
  iVar5 = FUN_00882b10(DAT_01ede5c4);
  iVar6 = FUN_00882b10(DAT_01ede5c8);
  sVar1 = param_2[2];
  sVar2 = *param_2;
  sVar3 = param_2[1];
  FUN_0087ccc0();
  *(int *)(iVar4 + 0x18) = (int)sVar2;
  *(undefined4 *)(iVar4 + 0x14) = 5;
  FUN_0087ccc0();
  *(int *)(iVar5 + 0x18) = (int)sVar3;
  *(undefined4 *)(iVar5 + 0x14) = 5;
  FUN_0087ccc0();
  *(int *)(iVar6 + 0x18) = (int)sVar1;
  *(undefined4 *)(iVar6 + 0x14) = 5;
  return;
}



/* FUNCTION 13852 ; VA 0x0088e2d0 ; FUN_0088e2d0 */

void __fastcall FUN_0088e2d0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  piVar1 = (int *)(param_1 + 0xc);
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_005596d0(*(int *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10),piVar1);
    iVar2 = *piVar1;
    uVar4 = *(int *)(param_1 + 0x14) - iVar2 & 0xfffffff8;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    *piVar1 = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 13853 ; VA 0x0088e340 ; FUN_0088e340 */

void FUN_0088e340(undefined4 param_1)

{
  FUN_0088dd80(param_1);
  return;
}



/* FUNCTION 13854 ; VA 0x0088e350 ; FUN_0088e350 */

void FUN_0088e350(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = thunk_FUN_00890320();
    *param_2 = uVar2;
    FUN_00889060(auStack_8);
  }
  return;
}



/* FUNCTION 13855 ; VA 0x0088e380 ; FUN_0088e380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined FUN_0088e380(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined uVar2;
  char *****pppppcVar3;
  uint uVar4;
  char ****appppcStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba8fe;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x10) == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1);
  iStack_8 = 0;
  pppppcVar3 = appppcStack_28;
  if (0xf < uStack_14) {
    pppppcVar3 = (char *****)appppcStack_28[0];
  }
  cVar1 = FUN_017256a7((int)*(char *)pppppcVar3);
  pppppcVar3 = appppcStack_28;
  if (0xf < uStack_14) {
    pppppcVar3 = (char *****)appppcStack_28[0];
  }
  *(char *)pppppcVar3 = cVar1;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54) {
    FUN_016f3809(&DAT_01eded54);
    if (DAT_01eded54 == -1) {
      iStack_8._0_1_ = 1;
      FUN_009ca470("NormalId");
      iStack_8._0_1_ = 2;
      _DAT_01edecf0 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
      FUN_009caf20(&DAT_01d62b48,6);
      FUN_016f3654(&LAB_01880900);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f37bf(&DAT_01eded54);
    }
  }
  pppppcVar3 = appppcStack_28;
  if (0xf < uStack_14) {
    pppppcVar3 = (char *****)appppcStack_28[0];
  }
  uVar2 = FUN_009cb180(pppppcVar3,param_2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    pppppcVar3 = (char *****)appppcStack_28[0];
    if (0xfff < uVar4) {
      pppppcVar3 = (char *****)appppcStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if ((char *)0x1f < (char *)((int)appppcStack_28[0] + (-4 - (int)pppppcVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppcVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 13856 ; VA 0x0088e4e0 ; FUN_0088e4e0 */

void FUN_0088e4e0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00890320();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13857 ; VA 0x0088e520 ; FUN_0088e520 */

void FUN_0088e520(int param_1,int param_2,int *param_3)

{
  int iVar1;
  uint uVar2;
  int iStack_d4;
  undefined4 auStack_9c [26];
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017985bb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0;
  uStack_14 = 0;
  FUN_0088c480(param_1,param_2 + param_1,uStack_1c,
               *(undefined4 *)((int)auStack_9c + *(int *)(iStack_d4 + 4)),&uStack_14);
  FUN_0058c420(&iStack_34);
  if (param_3 == &iStack_34) {
    if (0xf < uStack_20) {
      uVar2 = uStack_20 + 1;
      iVar1 = iStack_34;
      if (0xfff < uVar2) {
        iVar1 = *(int *)(iStack_34 + -4);
        uVar2 = uStack_20 + 0x24;
        if (0x1f < (iStack_34 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar1,uVar2);
    }
  }
  else {
    FUN_005507b0();
    *param_3 = iStack_34;
    param_3[1] = iStack_30;
    param_3[2] = iStack_2c;
    param_3[3] = iStack_28;
    *(ulonglong *)(param_3 + 4) = CONCAT44(uStack_20,uStack_24);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13858 ; VA 0x0088e610 ; FUN_0088e610 */

bool __fastcall FUN_0088e610(int param_1)

{
  if (*(int *)(param_1 + 0x14) != 0) {
    return *(int *)(*(int *)(param_1 + 0x14) + 8) == 0;
  }
  return true;
}



/* FUNCTION 13859 ; VA 0x0088e630 ; FUN_0088e630 */

undefined4 FUN_0088e630(void)

{
  return 4;
}



/* FUNCTION 13860 ; VA 0x0088e640 ; FUN_0088e640 */

undefined4 FUN_0088e640(void)

{
  return 8;
}



/* FUNCTION 13861 ; VA 0x0088e650 ; FUN_0088e650 */

int __thiscall FUN_0088e650(int param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  int aiStack_1c [4];
  int iStack_c;
  uint uStack_8;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_1c,param_2);
  if (0xf < uStack_8) {
    uVar2 = uStack_8 + 1;
    iVar1 = aiStack_1c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_1c[0] + -4);
      uVar2 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return iStack_c + 0x18;
}



/* FUNCTION 13862 ; VA 0x0088e6b0 ; FUN_0088e6b0 */

undefined4 FUN_0088e6b0(void)

{
  return 0xc;
}



/* FUNCTION 13863 ; VA 0x0088e6c0 ; FUN_0088e6c0 */

undefined4 FUN_0088e6c0(void)

{
  return 3;
}



/* FUNCTION 13864 ; VA 0x0088e6d0 ; FUN_0088e6d0 */

undefined4 FUN_0088e6d0(void)

{
  return 0x18;
}



/* FUNCTION 13865 ; VA 0x0088e6e0 ; FUN_0088e6e0 */

undefined4 FUN_0088e6e0(void)

{
  return 0x10;
}



/* FUNCTION 13866 ; VA 0x0088e6f0 ; FUN_0088e6f0 */

undefined4 FUN_0088e6f0(void)

{
  return 6;
}



/* FUNCTION 13867 ; VA 0x0088e700 ; FUN_0088e700 */

undefined4 __thiscall FUN_0088e700(int param_1,undefined4 param_2,undefined4 param_3)

{
  param_3 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_3);
  FUN_009ee270(param_2,&param_3);
  return param_2;
}



/* FUNCTION 13868 ; VA 0x0088e730 ; FUN_0088e730 */

undefined4 __thiscall FUN_0088e730(int param_1,undefined4 param_2,float param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_3);
  param_3 = (float)fVar1;
  FUN_009ee330(param_2,&param_3);
  return param_2;
}



/* FUNCTION 13869 ; VA 0x0088e760 ; FUN_0088e760 */

undefined4 __thiscall FUN_0088e760(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  double dStack_10;
  code *pcStack_8;
  
  pcStack_8 = *(code **)(**(int **)(param_1 + 0x34) + 0xc);
  fVar1 = (float10)(*pcStack_8)(param_3);
  dStack_10 = (double)fVar1;
  FUN_009ee440(param_2,&dStack_10);
  return param_2;
}



/* FUNCTION 13870 ; VA 0x0088e7a0 ; FUN_0088e7a0 */

undefined4 __thiscall FUN_0088e7a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2,param_3);
  return param_2;
}



/* FUNCTION 13871 ; VA 0x0088e7c0 ; FUN_0088e7c0 */

undefined4 __thiscall FUN_0088e7c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_3,param_3);
  FUN_00aa5450(param_2,&param_3);
  return param_2;
}



/* FUNCTION 13872 ; VA 0x0088e7f0 ; FUN_0088e7f0 */

undefined4 __thiscall FUN_0088e7f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_3);
  uStack_8 = 0;
  FUN_0054ef60(aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13873 ; VA 0x0088e880 ; FUN_0088e880 */

undefined * __thiscall FUN_0088e880(int *param_1,undefined *param_2)

{
  (**(code **)(*param_1 + 0x2c))();
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_2;
}



/* FUNCTION 13874 ; VA 0x0088e8c0 ; FUN_0088e8c0 */

undefined4 __thiscall FUN_0088e8c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_10 [12];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_3);
  FUN_00d85d20(param_2,auStack_10);
  return param_2;
}



/* FUNCTION 13875 ; VA 0x0088e8f0 ; FUN_0088e8f0 */

undefined4 __thiscall FUN_0088e8f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))((int)&param_3 + 1,param_3);
  FUN_00d85da0(param_2,(int)&param_3 + 1);
  return param_2;
}



/* FUNCTION 13876 ; VA 0x0088e920 ; FUN_0088e920 */

undefined4 __thiscall FUN_0088e920(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_3);
  uStack_8 = 0;
  FUN_00d85e10(param_2,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13877 ; VA 0x0088e9b0 ; FUN_0088e9b0 */

undefined4 __thiscall FUN_0088e9b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_3,param_3);
  FUN_00a922c0(param_2,&param_3);
  return param_2;
}



/* FUNCTION 13878 ; VA 0x0088e9e0 ; FUN_0088e9e0 */

undefined4 __thiscall FUN_0088e9e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [24];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_3);
  FUN_00d85f30(param_2,auStack_1c);
  return param_2;
}



/* FUNCTION 13879 ; VA 0x0088ea10 ; FUN_0088ea10 */

undefined4 __thiscall FUN_0088ea10(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [24];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_3);
  FUN_00d861e0(param_2,auStack_1c);
  return param_2;
}



/* FUNCTION 13880 ; VA 0x0088ea40 ; FUN_0088ea40 */

undefined4 __thiscall FUN_0088ea40(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_14 [16];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_14,param_3);
  FUN_00d864e0(param_2,auStack_14);
  return param_2;
}



/* FUNCTION 13881 ; VA 0x0088ea70 ; FUN_0088ea70 */

undefined4 __thiscall FUN_0088ea70(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_10 [12];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_3);
  FUN_00d86840(param_2,auStack_10);
  return param_2;
}



/* FUNCTION 13882 ; VA 0x0088eaa0 ; FUN_0088eaa0 */

undefined * FUN_0088eaa0(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  return param_1;
}



/* FUNCTION 13883 ; VA 0x0088ead0 ; FUN_0088ead0 */

undefined4 __thiscall FUN_0088ead0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_14 [16];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_14,param_3);
  FUN_00da8050(param_2,auStack_14);
  return param_2;
}



/* FUNCTION 13884 ; VA 0x0088eb00 ; FUN_0088eb00 */

undefined4 __thiscall FUN_0088eb00(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_3);
  FUN_00da8350(param_2,auStack_c);
  return param_2;
}



/* FUNCTION 13885 ; VA 0x0088eb30 ; FUN_0088eb30 */

undefined4 __thiscall FUN_0088eb30(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_3);
  FUN_00d86910(param_2,auStack_c);
  return param_2;
}



/* FUNCTION 13886 ; VA 0x0088eb60 ; FUN_0088eb60 */

undefined4 __thiscall FUN_0088eb60(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_10 [12];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_3);
  FUN_00d86ac0(param_2,auStack_10);
  return param_2;
}



/* FUNCTION 13887 ; VA 0x0088eb90 ; FUN_0088eb90 */

undefined4 __thiscall FUN_0088eb90(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_a [6];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_a,param_3);
  FUN_00d86c00(param_2,auStack_a);
  return param_2;
}



/* FUNCTION 13888 ; VA 0x0088ebc0 ; FUN_0088ebc0 */

undefined4 __thiscall FUN_0088ebc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 uStack_c;
  
  uStack_c = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_3);
  FUN_009ee550(param_2,&uStack_c);
  return param_2;
}



/* FUNCTION 13889 ; VA 0x0088ec00 ; FUN_0088ec00 */

undefined4 __thiscall FUN_0088ec00(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_3);
  param_3 = CONCAT13(uVar1,(undefined3)param_3);
  FUN_009ee570(param_2,(int)&param_3 + 3);
  return param_2;
}



/* FUNCTION 13890 ; VA 0x0088ec30 ; FUN_0088ec30 */

void FUN_0088ec30(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00890320();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13891 ; VA 0x0088ec70 ; FUN_0088ec70 */

void FUN_0088ec70(undefined4 param_1)

{
  FUN_0088dd10(param_1);
  return;
}



/* FUNCTION 13892 ; VA 0x0088ec80 ; FUN_0088ec80 */

void __thiscall FUN_0088ec80(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087ce60(&stack0x00000008);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&stack0x00000008);
    }
  }
  return;
}



/* FUNCTION 13893 ; VA 0x0088ecc0 ; FUN_0088ecc0 */

void __thiscall FUN_0088ecc0(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087cf20(&stack0x00000008);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&stack0x00000008);
    }
  }
  return;
}



/* FUNCTION 13894 ; VA 0x0088ed00 ; FUN_0088ed00 */

void __thiscall FUN_0088ed00(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087cf80(auStack_c);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_c);
    }
  }
  return;
}



/* FUNCTION 13895 ; VA 0x0088ed40 ; FUN_0088ed40 */

void __thiscall FUN_0088ed40(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8 = 0;
    cVar1 = FUN_0087d060(auStack_28);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_28);
    }
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13896 ; VA 0x0088edf0 ; FUN_0088edf0 */

void __thiscall FUN_0088edf0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede634);
    if (iVar2 != 0) {
      FUN_0087ce60(&param_3);
      uVar3 = FUN_0054d840(param_3);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar3);
    }
  }
  return;
}



/* FUNCTION 13897 ; VA 0x0088ee40 ; FUN_0088ee40 */

void FUN_0088ee40(undefined4 param_1,int param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  undefined **ppuStack_fc;
  undefined auStack_f8 [52];
  undefined4 auStack_c4 [5];
  undefined4 uStack_b0;
  undefined **ppuStack_ac;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba9aa;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  iVar1 = *(int *)(param_2 + 0x10);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d4b0();
  if (iVar1 == *(int *)(iVar3 + 4)) {
    iStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    uStack_8 = 0;
    FUN_00a33c70();
    uStack_8._0_1_ = 1;
    cVar2 = FUN_0087d060(apppuStack_2c);
    if ((cVar2 == '\0') ||
       (cVar2 = (**(code **)(*param_3 + 0x10))(apppuStack_2c,&param_2), cVar2 == '\0')) {
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Could not get referenced shared string for md5 \'%s\'",uVar4);
    }
    uVar4 = FUN_00a33fa0();
    FUN_0054ef60(uVar4);
    uStack_64 = uStack_44;
    uStack_44 = uStack_44 & 0xffffff00;
    uStack_60 = uStack_40;
    uStack_5c = uStack_3c;
    uStack_58 = uStack_38;
    uStack_34 = 0;
    uStack_30 = 0xf;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    (**(code **)(**(int **)(iStack_14 + 0x34) + 0x10))(param_1,&uStack_64);
    FUN_005507b0();
    FUN_0056cd30();
  }
  else {
    cVar2 = FUN_0087d4d0();
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    iStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    uStack_8 = 3;
    cVar2 = FUN_0087d060(apppuStack_2c);
    if (cVar2 != '\0') {
      ppuStack_fc = &PTR_018be314;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_48 = 1;
      ppuStack_ac = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
      uStack_b0 = 0x48;
      FUN_00554f20(auStack_f8,0);
      uStack_8 = 6;
      *(undefined ***)(auStack_f8 + (int)(ppuStack_fc[1] + -4)) =
           std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>
           ::vftable;
      *(undefined **)(auStack_f8 + (int)(ppuStack_fc[1] + -8)) = ppuStack_fc[1] + -0x50;
      FUN_005658e0(2);
      ppppuVar5 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
      }
      uStack_4c = uStack_4c & 0xffffff00;
      uStack_8._0_1_ = 7;
      param_3 = (int *)0x0;
      ppppuVar6 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_00563150(&param_2,ppppuVar6,iStack_1c + (int)ppppuVar5,uStack_4c,
                   *(undefined4 *)((int)auStack_c4 + (int)ppuStack_fc[1]),&param_3);
      FUN_0058c420(&uStack_44);
      uStack_64 = uStack_44;
      uStack_44 = uStack_44 & 0xffffff00;
      uStack_60 = uStack_40;
      uStack_5c = uStack_3c;
      uStack_58 = uStack_38;
      uStack_34 = 0;
      uStack_30 = 0xf;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      (**(code **)(**(int **)(iStack_14 + 0x34) + 0x10))(param_1,&uStack_64);
      FUN_005507b0();
      FUN_00570540();
    }
  }
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13898 ; VA 0x0088f0c0 ; FUN_0088f0c0 */

void __thiscall FUN_0088f0c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087ce60(&param_3);
    if (cVar1 != '\0') {
      uVar2 = FUN_00c95dd0(param_3);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar2);
    }
  }
  return;
}



/* FUNCTION 13899 ; VA 0x0088f110 ; FUN_0088f110 */

void __thiscall FUN_0088f110(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087cec0(&param_3);
    if (cVar1 != '\0') {
      uVar2 = FUN_0115e950(&uStack_14,param_3);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar2);
      return;
    }
    iStack_8 = FUN_0087cde0(DAT_01ede5f0);
    iVar3 = FUN_0087cde0(DAT_01ede5f4);
    iVar4 = FUN_0087cde0(DAT_01ede5f8);
    if (((iStack_8 != 0) && (iVar3 != 0)) && (iVar4 != 0)) {
      uStack_14 = 0;
      uStack_10 = 0;
      uStack_c = 0;
      FUN_0087cf20(&uStack_14);
      FUN_0087cf20(&uStack_10);
      FUN_0087cf20(&uStack_c);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_14);
    }
  }
  return;
}



/* FUNCTION 13900 ; VA 0x0088f1f0 ; FUN_0088f1f0 */

void __thiscall FUN_0088f1f0(int param_1,undefined4 param_2,uint param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iStack_8;
  
  iStack_8 = param_1;
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087cec0(&iStack_8);
    if (cVar1 != '\0') {
      param_3 = CONCAT13((char)iStack_8,
                         CONCAT12((char)((uint)iStack_8 >> 8),
                                  CONCAT11((char)((uint)iStack_8 >> 0x10),(undefined)param_3)));
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,(int)&param_3 + 1);
      return;
    }
    param_3 = FUN_0087cde0(DAT_01ede5f0);
    iVar2 = FUN_0087cde0(DAT_01ede5f4);
    iVar3 = FUN_0087cde0(DAT_01ede5f8);
    if (((param_3 != 0) && (iVar2 != 0)) && (iVar3 != 0)) {
      param_3 = param_3 & 0xff000000;
      FUN_0087ce40(&param_3);
      FUN_0087ce40((int)&param_3 + 1);
      FUN_0087ce40((int)&param_3 + 2);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&param_3);
    }
  }
  return;
}



/* FUNCTION 13901 ; VA 0x0088f2d0 ; FUN_0088f2d0 */

void __thiscall FUN_0088f2d0(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8 = 0;
    cVar1 = FUN_0087d0d0(auStack_28);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_28);
    }
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13902 ; VA 0x0088f380 ; FUN_0088f380 */

void __thiscall FUN_0088f380(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede630);
    if (iVar2 != 0) {
      FUN_0087ce60(&param_3);
      uVar3 = FUN_0054d840(param_3);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar3);
    }
  }
  return;
}



/* FUNCTION 13903 ; VA 0x0088f3d0 ; FUN_0088f3d0 */

void __thiscall FUN_0088f3d0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  char cStack0000000b;
  undefined auStack_34 [4];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int iStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iStack_1c = param_1;
  cStack0000000b = FUN_0087d4d0();
  if (cStack0000000b == '\0') {
    iVar1 = FUN_0087cde0(DAT_01ede660);
    if (iVar1 != 0) {
      FUN_0087d410(&stack0x0000000b);
    }
    if (cStack0000000b != '\0') {
      fStack_14 = (float)FUN_0087cde0(DAT_01ede664);
      iVar1 = FUN_0087cde0(DAT_01ede668);
      iVar2 = FUN_0087cde0(DAT_01ede66c);
      fStack_18 = (float)FUN_0087cde0(DAT_01ede670);
      iVar3 = FUN_0087cde0(DAT_01ede674);
      if (fStack_14 == 0.0) {
        fStack_8 = DAT_018ce2f8;
      }
      else {
        FUN_0087cf20(&fStack_14);
        fStack_8 = fStack_14;
      }
      if (iVar1 == 0) {
        fStack_10 = 0.0;
      }
      else {
        FUN_0087cf20(&fStack_14);
        fStack_10 = fStack_14;
      }
      fStack_c = 0.0;
      if (iVar2 != 0) {
        FUN_0087cf20(&fStack_14);
        fStack_c = fStack_14;
      }
      if (fStack_18 == 0.0) {
        fStack_14 = DAT_018ce2f8;
      }
      else {
        FUN_0087cf20(&fStack_18);
        fStack_14 = fStack_18;
      }
      fVar5 = DAT_018ce2f8;
      if (iVar3 != 0) {
        FUN_0087cf20(&fStack_18);
        fVar5 = fStack_18;
      }
      fVar4 = DAT_018daf54;
      if (DAT_018daf54 <= fStack_8) {
        fVar4 = fStack_8;
      }
      fVar6 = 0.0;
      if (0.0 <= fVar5) {
        fVar6 = fVar5;
      }
      auStack_34[0] = 1;
      fStack_30 = DAT_018ce320;
      if (fVar4 <= DAT_018ce320) {
        fStack_30 = fVar4;
      }
      fVar5 = 0.0;
      if (0.0 <= fStack_10) {
        fVar5 = fStack_10;
      }
      fVar4 = 0.0;
      if (0.0 <= fStack_c) {
        fVar4 = fStack_c;
      }
      fStack_2c = DAT_018ce2f8;
      if (fVar4 <= DAT_018ce2f8) {
        fStack_2c = fVar4;
      }
      fStack_28 = DAT_018daf58;
      if (fVar5 <= DAT_018daf58) {
        fStack_28 = fVar5;
      }
      fVar5 = 0.0;
      if (0.0 <= fStack_14) {
        fVar5 = fStack_14;
      }
      fStack_24 = DAT_018ce320;
      if (fVar5 <= DAT_018ce320) {
        fStack_24 = fVar5;
      }
      fStack_20 = DAT_018ce320;
      if (fVar6 <= DAT_018ce320) {
        fStack_20 = fVar6;
      }
      (**(code **)(**(int **)(iStack_1c + 0x34) + 0x10))(param_2,auStack_34);
      return;
    }
    auStack_34[0] = 0;
    fStack_30 = 0.0;
    fStack_2c = 0.0;
    fStack_28 = 0.0;
    fStack_24 = 0.0;
    fStack_20 = 0.0;
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_34);
  }
  return;
}



/* FUNCTION 13904 ; VA 0x0088f5f0 ; FUN_0088f5f0 */

void __thiscall FUN_0088f5f0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede638);
    iVar3 = FUN_0087cde0(DAT_01ede63c);
    if ((iVar2 != 0) && (iVar3 != 0)) {
      uStack_c = 0;
      uStack_8 = 0;
      uStack_1c = 0;
      uStack_18 = 0;
      uStack_14 = 0;
      uStack_10 = 0;
      cVar1 = FUN_0088e040(&uStack_1c,iVar2);
      if ((cVar1 != '\0') && (cVar1 = FUN_0088e040(&uStack_10,iVar3), cVar1 != '\0')) {
        (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_1c);
      }
    }
  }
  return;
}



/* FUNCTION 13905 ; VA 0x0088f680 ; FUN_0088f680 */

void FUN_0088f680(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede640);
    iVar3 = FUN_0087cde0(DAT_01ede644);
    if ((iVar2 != 0) && (iVar3 != 0)) {
      uStack_18 = 0;
      uStack_14 = 0;
      uStack_10 = 0;
      uStack_c = 0;
      iVar2 = FUN_0087cde0(DAT_01ede5c0);
      iVar3 = FUN_0087cde0(DAT_01ede5c4);
      if ((iVar2 != 0) && (iVar3 != 0)) {
        FUN_0087cf20(&uStack_18);
        FUN_0087cf20(&uStack_14);
        iVar2 = FUN_0087cde0(DAT_01ede5c0);
        iVar3 = FUN_0087cde0(DAT_01ede5c4);
        if ((iVar2 != 0) && (iVar3 != 0)) {
          FUN_0087cf20(&uStack_10);
          FUN_0087cf20(&uStack_c);
          uVar4 = FUN_006ae8d0(auStack_28,&uStack_18,&uStack_10);
          (**(code **)(**(int **)(iStack_8 + 0x34) + 0x10))(param_1,uVar4);
        }
      }
    }
  }
  return;
}



/* FUNCTION 13906 ; VA 0x0088f790 ; FUN_0088f790 */

void __thiscall FUN_0088f790(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined4 uStack_1a;
  undefined2 uStack_16;
  undefined4 uStack_14;
  undefined2 uStack_10;
  undefined4 uStack_c;
  undefined2 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede640);
    iVar3 = FUN_0087cde0(DAT_01ede644);
    if ((iVar2 != 0) && (iVar3 != 0)) {
      uStack_c = 0;
      uStack_8 = 0;
      uStack_14 = 0;
      uStack_10 = 0;
      cVar1 = FUN_0088e0d0(&uStack_c,iVar2);
      if ((cVar1 != '\0') && (cVar1 = FUN_0088e0d0(&uStack_14,iVar3), cVar1 != '\0')) {
        uStack_20 = uStack_c;
        uStack_1c = uStack_8;
        uStack_1a = uStack_14;
        uStack_16 = uStack_10;
        (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_20);
      }
    }
  }
  return;
}



/* FUNCTION 13907 ; VA 0x0088f840 ; FUN_0088f840 */

void FUN_0088f840(undefined4 param_1,int param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  int iStack_104;
  undefined4 auStack_cc [26];
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  uint uStack_4c;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba9f3;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)(param_2 + 0x10);
  iVar1 = *piVar5;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088d4b0();
  if (iVar1 != *(int *)(iVar3 + 4)) {
    iVar1 = *piVar5;
    iVar3 = FUN_0088cf00();
    if (iVar1 != *(int *)(iVar3 + 4)) {
      FUN_0054db20();
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Cannot convert from %s to SharedString",uVar4);
    }
    iStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    uStack_8 = 2;
    FUN_0087d060(apppuStack_2c);
    iVar1 = iStack_1c;
    uStack_34 = 0xf00000000;
    uStack_44 = uStack_44 & 0xffffff00;
    ppppuVar6 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
    }
    uStack_8._0_1_ = 3;
    FUN_00565940(3,1);
    uStack_4c = uStack_4c & 0xffffff00;
    uStack_8._0_1_ = 4;
    param_3 = (int *)0x0;
    FUN_0088c480(ppppuVar6,(int)ppppuVar6 + iVar1,uStack_4c,
                 *(undefined4 *)((int)auStack_cc + *(int *)(iStack_104 + 4)),&param_3);
    FUN_0058c420(&uStack_64);
    FUN_005507b0();
    uStack_8._0_1_ = 3;
    uStack_44 = uStack_64;
    uStack_40 = uStack_60;
    uStack_3c = uStack_5c;
    uStack_38 = uStack_58;
    uStack_34 = uStack_54;
    FUN_005705c0();
    uVar4 = FUN_00a33be0(&uStack_44);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    (**(code **)(**(int **)(iStack_14 + 0x34) + 0x10))(param_1,uVar4);
    FUN_0056cd30();
    FUN_005507b0();
LAB_0088f8e7:
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  uStack_8 = 0;
  FUN_00a33c70();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar2 = FUN_0087d060(apppuStack_2c);
  if (cVar2 != '\0') {
    cVar2 = (**(code **)(*param_3 + 0x10))(apppuStack_2c,&param_2);
    if (cVar2 != '\0') {
      (**(code **)(**(int **)(iStack_14 + 0x34) + 0x10))(param_1,&param_2);
      FUN_0056cd30();
      goto LAB_0088f8e7;
    }
  }
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Could not get referenced shared string for md5 \'%s\'",uVar4);
}



/* FUNCTION 13908 ; VA 0x0088fa40 ; FUN_0088fa40 */

void __thiscall FUN_0088fa40(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede620);
    iVar3 = FUN_0087cde0(DAT_01ede624);
    iVar4 = FUN_0087cde0(DAT_01ede628);
    iVar5 = FUN_0087cde0(DAT_01ede62c);
    if ((((iVar2 != 0) && (iVar3 != 0)) && (iVar4 != 0)) && (iVar5 != 0)) {
      FUN_0087cf20(&uStack_14);
      FUN_0087ce60(&uStack_10);
      FUN_0087cf20(&uStack_c);
      FUN_0087ce60(&uStack_8);
      uVar6 = FUN_00da7df0(uStack_14,uStack_10,uStack_c,uStack_8);
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar6);
    }
  }
  return;
}



/* FUNCTION 13909 ; VA 0x0088fb20 ; FUN_0088fb20 */

void __thiscall FUN_0088fb20(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    iVar2 = FUN_0087cde0(DAT_01ede618);
    iVar3 = FUN_0087cde0(DAT_01ede61c);
    if ((iVar2 != 0) && (iVar3 != 0)) {
      FUN_0087cf20(&param_3);
      FUN_0087ce60(&uStack_8);
      uStack_10 = param_3;
      uStack_c = uStack_8;
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_10);
    }
  }
  return;
}



/* FUNCTION 13910 ; VA 0x0088fba0 ; FUN_0088fba0 */

void __thiscall FUN_0088fba0(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (((cVar1 == '\0') && (iVar2 = FUN_0087cde0(DAT_01ede5c0), iVar2 != 0)) &&
     (iVar2 = FUN_0087cde0(DAT_01ede5c4), iVar2 != 0)) {
    uStack_c = 0;
    uStack_8 = 0;
    FUN_0087cf20(&uStack_c);
    FUN_0087cf20(&uStack_8);
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_c);
  }
  return;
}



/* FUNCTION 13911 ; VA 0x0088fc20 ; FUN_0088fc20 */

void __thiscall FUN_0088fc20(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_0088e040(&uStack_10,param_3);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_10);
  }
  return;
}



/* FUNCTION 13912 ; VA 0x0088fc70 ; FUN_0088fc70 */

void FUN_0088fc70(undefined4 param_1,undefined2 param_2)

{
  char cVar1;
  int iVar2;
  undefined2 uStack_16;
  undefined2 uStack_14;
  undefined2 uStack_12;
  int iStack_10;
  undefined2 auStack_c [2];
  undefined2 auStack_8 [2];
  
  cVar1 = FUN_0087d4d0();
  if ((((cVar1 == '\0') && (iVar2 = FUN_0087cde0(DAT_01ede5c0), iVar2 != 0)) &&
      (iVar2 = FUN_0087cde0(DAT_01ede5c4), iVar2 != 0)) &&
     (iVar2 = FUN_0087cde0(DAT_01ede5c8), iVar2 != 0)) {
    FUN_0087ce60(&param_2);
    FUN_0087ce60(auStack_8);
    FUN_0087ce60(auStack_c);
    uStack_16 = param_2;
    uStack_14 = auStack_8[0];
    uStack_12 = auStack_c[0];
    (**(code **)(**(int **)(iStack_10 + 0x34) + 0x10))(param_1,&uStack_16);
  }
  return;
}



/* FUNCTION 13913 ; VA 0x0088fd20 ; FUN_0088fd20 */

void __thiscall FUN_0088fd20(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087d3a0(auStack_c);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_c);
    }
  }
  return;
}



/* FUNCTION 13914 ; VA 0x0088fd60 ; FUN_0088fd60 */

void __thiscall FUN_0088fd60(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_0087d410(&stack0x0000000b);
    if (cVar1 != '\0') {
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&stack0x0000000b);
    }
  }
  return;
}



/* FUNCTION 13915 ; VA 0x0088fda0 ; FUN_0088fda0 */

undefined4 __thiscall FUN_0088fda0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  cVar1 = FUN_009ee5c0(param_3,&iStack_8);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&iStack_8);
    return 1;
  }
  return 0;
}



/* FUNCTION 13916 ; VA 0x0088fde0 ; FUN_0088fde0 */

undefined4 __thiscall FUN_0088fde0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  cVar1 = FUN_009ee6c0(param_3,&iStack_8);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&iStack_8);
    return 1;
  }
  return 0;
}



/* FUNCTION 13917 ; VA 0x0088fe20 ; FUN_0088fe20 */

undefined4 __thiscall FUN_0088fe20(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_009ee7a0(param_3,auStack_c);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_c);
    return 1;
  }
  return 0;
}



/* FUNCTION 13918 ; VA 0x0088fe60 ; FUN_0088fe60 */

undefined4 __thiscall FUN_0088fe60(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,param_3);
  return 1;
}



/* FUNCTION 13919 ; VA 0x0088fe80 ; FUN_0088fe80 */

undefined4 __thiscall FUN_0088fe80(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_0054d840(0);
  cVar1 = FUN_00aa5590(param_3,&iStack_8);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&iStack_8);
    return 1;
  }
  return 0;
}



/* FUNCTION 13920 ; VA 0x0088fed0 ; FUN_0088fed0 */

undefined4 __thiscall FUN_0088fed0(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_3);
  uStack_40 = uStack_28;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_3c = uStack_24;
  uStack_38 = uStack_20;
  uStack_34 = uStack_1c;
  uStack_2c = uStack_14;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_40);
  if (0xf < uStack_2c) {
    uVar2 = uStack_2c + 1;
    uVar1 = uStack_40;
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(uStack_40 - 4);
      uVar2 = uStack_2c + 0x24;
      if (0x1f < (uStack_40 - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 13921 ; VA 0x0088ff80 ; FUN_0088ff80 */

uint __fastcall FUN_0088ff80(int *param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x2c))();
  return uVar1 & 0xffffff00;
}



/* FUNCTION 13922 ; VA 0x0088ff90 ; FUN_0088ff90 */

undefined4 __thiscall FUN_0088ff90(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_00d86d90(param_3,&uStack_10);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_10);
    return 1;
  }
  return 0;
}



/* FUNCTION 13923 ; VA 0x0088fff0 ; FUN_0088fff0 */

undefined4 __thiscall FUN_0088fff0(uint param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  uint uStack_8;
  
  uStack_8 = param_1 & 0xff000000;
  cVar1 = FUN_00d87110(param_3,&uStack_8);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_8);
    return 1;
  }
  return 0;
}



/* FUNCTION 13924 ; VA 0x00890040 ; FUN_00890040 */

bool __thiscall FUN_00890040(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba938;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00c33b80(param_3,auStack_28);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_28);
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return cVar1 != '\0';
}



/* FUNCTION 13925 ; VA 0x008900f0 ; FUN_008900f0 */

undefined4 __thiscall FUN_008900f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  cVar1 = FUN_00d874b0(param_3,&uStack_1c);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_1c);
    return 1;
  }
  return 0;
}



/* FUNCTION 13926 ; VA 0x00890150 ; FUN_00890150 */

undefined4 __thiscall FUN_00890150(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_00585a40(param_3,&uStack_10);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_10);
    return 1;
  }
  return 0;
}



/* FUNCTION 13927 ; VA 0x008901a0 ; FUN_008901a0 */

undefined4 __thiscall FUN_008901a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_00d877d0(param_3,&uStack_c);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_c);
    return 1;
  }
  return 0;
}



/* FUNCTION 13928 ; VA 0x008901f0 ; FUN_008901f0 */

undefined4 __thiscall FUN_008901f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_00d879b0(param_3,&uStack_10);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_10);
    return 1;
  }
  return 0;
}



/* FUNCTION 13929 ; VA 0x00890250 ; FUN_00890250 */

undefined4 __thiscall FUN_00890250(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_c;
  undefined2 uStack_8;
  
  uStack_c = 0;
  uStack_8 = 0;
  cVar1 = FUN_00d87ae0(param_3,&uStack_c);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_c);
    return 1;
  }
  return 0;
}



/* FUNCTION 13930 ; VA 0x008902a0 ; FUN_008902a0 */

undefined4 __thiscall FUN_008902a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_009ee890(param_3,auStack_c);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_c);
    return 1;
  }
  return 0;
}



/* FUNCTION 13931 ; VA 0x008902e0 ; FUN_008902e0 */

undefined4 __thiscall FUN_008902e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  cVar1 = FUN_009ee8e0(param_3,(int)&uStack_8 + 3);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,(int)&uStack_8 + 3);
    return 1;
  }
  return 0;
}



/* FUNCTION 13932 ; VA 0x00890320 ; FUN_00890320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00890320(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baa16;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eded54);
    if (DAT_01eded54 == -1) {
      uStack_8 = 0;
      FUN_009ca470("NormalId");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01edecf0 = RBX::Reflection::EnumDesc<enum_RBX::NormalId>::vftable;
      FUN_009caf20(&DAT_01d62b48,6);
      FUN_016f3654(&LAB_01880900);
      FUN_016f37bf(&DAT_01eded54);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edecf0;
}



/* FUNCTION 13933 ; VA 0x008903d0 ; FUN_008903d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008903d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded84) {
    FUN_016f3809(&DAT_01eded84);
    if (DAT_01eded84 == -1) {
      _DAT_01eded78 = FUN_0088e340;
      _DAT_01eded7c = FUN_0088ec70;
      _DAT_01eded80 = FUN_0087ef80;
      FUN_016f37bf(&DAT_01eded84);
    }
  }
  return &DAT_01eded78;
}



/* FUNCTION 13934 ; VA 0x00890440 ; FUN_00890440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00890440(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded94) {
    FUN_016f3809(&DAT_01eded94);
    if (DAT_01eded94 == -1) {
      _DAT_01eded88 = FUN_005c65e0;
      _DAT_01eded8c = FUN_005c65e0;
      _DAT_01eded90 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eded94);
    }
  }
  return &DAT_01eded88;
}



/* FUNCTION 13935 ; VA 0x008904b0 ; FUN_008904b0 */

void __thiscall FUN_008904b0(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  FUN_0087ccc0();
  *(undefined4 *)(param_3 + 0x18) = uVar1;
  *(undefined4 *)(param_3 + 0x14) = 5;
  return;
}



/* FUNCTION 13936 ; VA 0x008904e0 ; FUN_008904e0 */

void __thiscall FUN_008904e0(int param_1,undefined4 param_2,int param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  FUN_0087ccc0();
  *(float *)(param_3 + 0x18) = (float)fVar1;
  *(undefined4 *)(param_3 + 0x14) = 7;
  return;
}



/* FUNCTION 13937 ; VA 0x00890520 ; FUN_00890520 */

void __thiscall FUN_00890520(int param_1,undefined4 param_2,int param_3)

{
  float10 fVar1;
  
  fVar1 = (float10)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  FUN_0087ccc0();
  *(double *)(param_3 + 0x18) = (double)fVar1;
  *(undefined4 *)(param_3 + 0x14) = 9;
  return;
}



/* FUNCTION 13938 ; VA 0x00890560 ; FUN_00890560 */

void __thiscall FUN_00890560(int param_1,undefined4 param_2)

{
  undefined *puStack00000008;
  undefined *puVar1;
  undefined auStack_20 [24];
  
  puStack00000008 = auStack_20;
  puVar1 = auStack_20;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_20,param_2);
  FUN_00885f30(puVar1,param_2);
  return;
}



/* FUNCTION 13939 ; VA 0x00890590 ; FUN_00890590 */

void __thiscall FUN_00890590(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = FUN_00882b10(DAT_01ede634);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_3,param_2);
  uVar1 = param_3;
  FUN_0087ccc0();
  *(undefined4 *)(iVar2 + 0x18) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = 5;
  return;
}



/* FUNCTION 13940 ; VA 0x008905e0 ; FUN_008905e0 */

void __thiscall FUN_008905e0(int param_1,undefined4 param_2)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_100;
  undefined4 auStack_c8 [26];
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint uStack_48;
  undefined4 ***apppuStack_40 [4];
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baa3b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(apppuStack_40,param_2);
  uStack_18 = 0xf00000000;
  uStack_28 = uStack_28 & 0xffffff00;
  ppppuVar1 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar1 = (undefined4 ****)apppuStack_40[0];
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_00565940(3,1);
  uStack_48 = uStack_48 & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar5 = *(undefined4 *)((int)auStack_c8 + *(int *)(iStack_100 + 4));
  iVar4 = iStack_30 + (int)ppppuVar1;
  uVar3 = uStack_48;
  FUN_008825f0(ppppuVar1,iVar4,uStack_48,uVar5,&param_2,param_2);
  uVar6 = 0x890687;
  FUN_0058c420(&uStack_60);
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_28 = uStack_60;
  uStack_24 = uStack_5c;
  uStack_20 = uStack_58;
  uStack_1c = uStack_54;
  uStack_18 = uStack_50;
  uVar7 = 0x8906b0;
  FUN_005705c0();
  FUN_0054ef60(&uStack_28);
  FUN_00885f30(ppppuVar1,iVar4,uVar3,uVar5,uVar6,uVar7);
  if (0xf < uStack_18._4_4_) {
    uVar2 = uStack_18._4_4_ + 1;
    uVar3 = uStack_28;
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(uStack_28 - 4);
      uVar2 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uStack_28 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar3) {
      ppppuVar1 = (undefined4 ****)apppuStack_40[0][-1];
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13941 ; VA 0x00890750 ; FUN_00890750 */

void __thiscall FUN_00890750(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_3;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_3,param_2);
  iVar2 = param_3;
  FUN_0087ccc0();
  *(int *)(iVar1 + 0x18) = iVar2;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  return;
}



/* FUNCTION 13942 ; VA 0x00890790 ; FUN_00890790 */

void __thiscall FUN_00890790(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_10,param_2);
  iVar1 = FUN_00882b10(DAT_01ede5f0);
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_10;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  iVar1 = FUN_00882b10(DAT_01ede5f4);
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_c;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  iVar1 = FUN_00882b10(DAT_01ede5f8);
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_8;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  return;
}



/* FUNCTION 13943 ; VA 0x00890850 ; FUN_00890850 */

void __thiscall FUN_00890850(int param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  iVar3 = param_3;
  uVar4 = param_2 & 0xff;
  uVar1 = param_2 >> 8;
  uVar2 = param_2 >> 0x10;
  FUN_0087ccc0();
  *(uint *)(iVar3 + 0x18) = ((uVar4 + 0xff00) * 0x100 + (uVar1 & 0xff)) * 0x100 + (uVar2 & 0xff);
  *(undefined4 *)(iVar3 + 0x14) = 6;
  return;
}



/* FUNCTION 13944 ; VA 0x008908a0 ; FUN_008908a0 */

void __thiscall FUN_008908a0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baa67;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar1 == 0) {
    iVar1 = 0;
  }
  else {
    FUN_0054ef60(aiStack_28);
  }
  *(int *)(param_3 + 0x18) = iVar1;
  *(undefined4 *)(param_3 + 0x14) = 3;
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13945 ; VA 0x00890960 ; FUN_00890960 */

void __thiscall FUN_00890960(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = FUN_00882b10(DAT_01ede630);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_3,param_2);
  uVar1 = param_3;
  FUN_0087ccc0();
  *(undefined4 *)(iVar2 + 0x18) = uVar1;
  *(undefined4 *)(iVar2 + 0x14) = 5;
  return;
}



/* FUNCTION 13946 ; VA 0x008909b0 ; FUN_008909b0 */

void __thiscall FUN_008909b0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char acStack_20 [4];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(acStack_20,param_2);
  iVar1 = FUN_00882b10(DAT_01ede660);
  FUN_0087ccc0();
  *(char *)(iVar1 + 0x18) = acStack_20[0];
  *(undefined4 *)(iVar1 + 0x14) = 4;
  if (acStack_20[0] != '\0') {
    iVar1 = FUN_00882b10(DAT_01ede664);
    iVar2 = FUN_00882b10(DAT_01ede668);
    iVar3 = FUN_00882b10(DAT_01ede66c);
    iVar4 = FUN_00882b10(DAT_01ede670);
    iStack_8 = FUN_00882b10(DAT_01ede674);
    FUN_0087ccc0();
    *(undefined4 *)(iVar1 + 0x18) = uStack_1c;
    *(undefined4 *)(iVar1 + 0x14) = 7;
    FUN_0087ccc0();
    *(undefined4 *)(iVar2 + 0x18) = uStack_14;
    *(undefined4 *)(iVar2 + 0x14) = 7;
    FUN_0087ccc0();
    *(undefined4 *)(iVar3 + 0x18) = uStack_18;
    *(undefined4 *)(iVar3 + 0x14) = 7;
    FUN_0087ccc0();
    iVar1 = iStack_8;
    *(undefined4 *)(iVar4 + 0x18) = uStack_10;
    *(undefined4 *)(iVar4 + 0x14) = 7;
    FUN_0087ccc0();
    *(undefined4 *)(iVar1 + 0x18) = uStack_c;
    *(undefined4 *)(iVar1 + 0x14) = 7;
  }
  return;
}



/* FUNCTION 13947 ; VA 0x00890b10 ; FUN_00890b10 */

void __thiscall FUN_00890b10(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_1c [12];
  undefined auStack_10 [12];
  
  uVar1 = FUN_00882b10(DAT_01ede638);
  uVar2 = FUN_00882b10(DAT_01ede63c);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_2);
  FUN_0088e180(uVar1,auStack_1c);
  FUN_0088e180(uVar2,auStack_10);
  return;
}



/* FUNCTION 13948 ; VA 0x00890b70 ; FUN_00890b70 */

void __thiscall FUN_00890b70(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_00882b10(DAT_01ede640);
  uStack_8 = FUN_00882b10(DAT_01ede644);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_18,param_2);
  iVar1 = FUN_00882b10(DAT_01ede5c0);
  iVar2 = FUN_00882b10(DAT_01ede5c4);
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_18;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  FUN_0087ccc0();
  *(undefined4 *)(iVar2 + 0x18) = uStack_14;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  iVar1 = FUN_00882b10(DAT_01ede5c0);
  iVar2 = FUN_00882b10(DAT_01ede5c4);
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_10;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  FUN_0087ccc0();
  *(undefined4 *)(iVar2 + 0x18) = uStack_c;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  return;
}



/* FUNCTION 13949 ; VA 0x00890c80 ; FUN_00890c80 */

void __thiscall FUN_00890c80(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_10 [6];
  undefined auStack_a [6];
  
  uVar1 = FUN_00882b10(DAT_01ede640);
  uVar2 = FUN_00882b10(DAT_01ede644);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  FUN_0088e230(uVar1,auStack_10);
  FUN_0088e230(uVar2,auStack_a);
  return;
}



/* FUNCTION 13950 ; VA 0x00890ce0 ; FUN_00890ce0 */

/* WARNING: Removing unreachable block (ram,0x00890d88) */
/* WARNING: Removing unreachable block (ram,0x00890d96) */
/* WARNING: Removing unreachable block (ram,0x00890dc0) */
/* WARNING: Removing unreachable block (ram,0x00890da6) */

void __thiscall FUN_00890ce0(int param_1,undefined4 param_2)

{
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017baa90;
  pvStack_10 = ExceptionList;
  uStack_28 = uStack_28 & 0xffffff00;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  iStack_8._0_1_ = 1;
  FUN_00a33e40();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0056cd30();
  FUN_00885f30(uStack_28,uStack_24,uStack_20,uStack_1c,0xf00000000);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13951 ; VA 0x00890dd0 ; FUN_00890dd0 */

void __thiscall FUN_00890dd0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar2 = FUN_00882b10(DAT_01ede620);
  iStack_8 = FUN_00882b10(DAT_01ede624);
  iStack_c = FUN_00882b10(DAT_01ede628);
  iStack_10 = FUN_00882b10(DAT_01ede62c);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_20,param_2);
  FUN_0087ccc0();
  iVar1 = iStack_8;
  *(undefined4 *)(iVar2 + 0x18) = uStack_20;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  FUN_0087ccc0();
  iVar2 = iStack_c;
  *(undefined4 *)(iVar1 + 0x18) = uStack_1c;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  FUN_0087ccc0();
  iVar1 = iStack_10;
  *(undefined4 *)(iVar2 + 0x18) = uStack_18;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_14;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  return;
}



/* FUNCTION 13952 ; VA 0x00890eb0 ; FUN_00890eb0 */

void __thiscall FUN_00890eb0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar2 = FUN_00882b10(DAT_01ede618);
  iStack_8 = FUN_00882b10(DAT_01ede61c);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_10,param_2);
  FUN_0087ccc0();
  iVar1 = iStack_8;
  *(undefined4 *)(iVar2 + 0x18) = uStack_10;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_c;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  return;
}



/* FUNCTION 13953 ; VA 0x00890f30 ; FUN_00890f30 */

void __thiscall FUN_00890f30(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  iVar2 = FUN_00882b10(DAT_01ede5c0);
  iStack_8 = FUN_00882b10(DAT_01ede5c4);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&uStack_10,param_2);
  FUN_0087ccc0();
  iVar1 = iStack_8;
  *(undefined4 *)(iVar2 + 0x18) = uStack_10;
  *(undefined4 *)(iVar2 + 0x14) = 7;
  FUN_0087ccc0();
  *(undefined4 *)(iVar1 + 0x18) = uStack_c;
  *(undefined4 *)(iVar1 + 0x14) = 7;
  return;
}



/* FUNCTION 13954 ; VA 0x00890fc0 ; FUN_00890fc0 */

void __thiscall FUN_00890fc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_10 [12];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_10,param_2);
  FUN_0088e180(param_3,auStack_10);
  return;
}



/* FUNCTION 13955 ; VA 0x00891000 ; FUN_00891000 */

void __thiscall FUN_00891000(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  short sStack_10;
  short sStack_e;
  short sStack_c;
  int iStack_8;
  
  iVar1 = FUN_00882b10(DAT_01ede5c0);
  iVar2 = FUN_00882b10(DAT_01ede5c4);
  iStack_8 = FUN_00882b10(DAT_01ede5c8);
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&sStack_10,param_2);
  FUN_0087ccc0();
  *(int *)(iVar1 + 0x18) = (int)sStack_10;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  FUN_0087ccc0();
  iVar1 = iStack_8;
  *(int *)(iVar2 + 0x18) = (int)sStack_e;
  *(undefined4 *)(iVar2 + 0x14) = 5;
  FUN_0087ccc0();
  *(int *)(iVar1 + 0x18) = (int)sStack_c;
  *(undefined4 *)(iVar1 + 0x14) = 5;
  return;
}



/* FUNCTION 13956 ; VA 0x008910a0 ; FUN_008910a0 */

void __thiscall FUN_008910a0(int param_1,undefined4 param_2,int param_3)

{
  undefined8 uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  FUN_0087ccc0();
  *(undefined8 *)(param_3 + 0x18) = uVar1;
  *(undefined4 *)(param_3 + 0x14) = 10;
  return;
}



/* FUNCTION 13957 ; VA 0x008910e0 ; FUN_008910e0 */

void __thiscall FUN_008910e0(int param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  
  uVar1 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  FUN_0087ccc0();
  *(undefined *)(param_3 + 0x18) = uVar1;
  *(undefined4 *)(param_3 + 0x14) = 4;
  return;
}



/* FUNCTION 13958 ; VA 0x00891110 ; FUN_00891110 */

undefined4 FUN_00891110(undefined4 param_1,undefined4 *param_2,int param_3)

{
  bool bVar1;
  bool bVar2;
  char ******ppppppcVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  char ******ppppppcVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_17c [120];
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  int aiStack_d4 [5];
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  undefined8 uStack_90;
  char *****apppppcStack_88 [4];
  int iStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bab44;
  pvStack_10 = ExceptionList;
  uStack_a4 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = 10;
    puVar7 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar7 = (undefined4 *)FUN_0151d700(auStack_bc,param_2,*puVar7);
    uStack_8._0_1_ = 0xb;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    uVar6 = FUN_01675640(auStack_58,"applicationName=%s",puVar7);
    uStack_8._0_1_ = 0xc;
    FUN_0054eff0("/v1/settings/application");
    uStack_8._0_1_ = 0xd;
    uVar8 = FUN_0151f070(auStack_70,"clientsettingscdn");
    uStack_8._0_1_ = 0xe;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 0xf;
    FUN_0151bcc0(auStack_17c,auStack_40,uVar8,auStack_28,uVar6,aiStack_d4);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      uVar10 = auStack_40[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    if (0xf < uStack_5c) {
      uVar11 = uStack_5c + 1;
      uVar10 = auStack_70[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_70[0] - 4);
        uVar11 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    if (0xf < uStack_14) {
      uVar11 = uStack_14 + 1;
      uVar10 = auStack_28[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_28[0] - 4);
        uVar11 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (0xf < uStack_44) {
      uVar11 = uStack_44 + 1;
      uVar10 = auStack_58[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_58[0] - 4);
        uVar11 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    if (0xf < uStack_a8) {
      uVar11 = uStack_a8 + 1;
      uVar10 = auStack_bc[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_bc[0] - 4);
        uVar11 = uStack_a8 + 0x24;
        if (0x1f < (auStack_bc[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_ac = 0;
    uStack_a8 = 0xf;
    auStack_bc[0] = auStack_bc[0] & 0xffffff00;
    if (uStack_c0 < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar10 = uStack_c0 + 1;
    iVar4 = aiStack_d4[0];
    if (0xfff < uVar10) {
      iVar4 = *(int *)(aiStack_d4[0] + -4);
      uVar10 = uStack_c0 + 0x24;
      if (0x1f < (aiStack_d4[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(param_3);
    uStack_8 = 0;
    if (iStack_78 != 0) {
      ppppppcVar9 = apppppcStack_88;
      if (0xf < uStack_74) {
        ppppppcVar9 = (char ******)apppppcStack_88[0];
      }
      ppppppcVar3 = apppppcStack_88;
      if (0xf < uStack_74) {
        ppppppcVar3 = (char ******)apppppcStack_88[0];
      }
      for (; ppppppcVar3 != (char ******)((int)ppppppcVar9 + iStack_78);
          ppppppcVar3 = (char ******)((int)ppppppcVar3 + 1)) {
        iVar4 = FUN_0171dc29((int)*(char *)ppppppcVar3);
        if (iVar4 == 0) {
          if (0xf < (uint)param_2[5]) {
            param_2 = (undefined4 *)*param_2;
          }
          piVar5 = (int *)FUN_01675640(auStack_ec,"/v2/settings/application/%s/bucket/%s",param_2,
                                       param_3);
          bVar2 = false;
          bVar1 = true;
          goto LAB_008911c5;
        }
      }
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    piVar5 = (int *)FUN_01675640(auStack_104,"/v2/settings/application/%s",param_2);
    bVar2 = true;
    bVar1 = false;
LAB_008911c5:
    iStack_a0 = *piVar5;
    iStack_9c = piVar5[1];
    iStack_98 = piVar5[2];
    iStack_94 = piVar5[3];
    uStack_90 = *(undefined8 *)(piVar5 + 4);
    piVar5[4] = 0;
    piVar5[5] = 0xf;
    *(undefined *)piVar5 = 0;
    uStack_8 = 2;
    if (bVar1) {
      FUN_005507b0();
    }
    if (bVar2) {
      FUN_005507b0();
    }
    uStack_8._0_1_ = 4;
    if (0xf < uStack_74) {
      uVar10 = uStack_74 + 1;
      ppppppcVar9 = (char ******)apppppcStack_88[0];
      if (0xfff < uVar10) {
        ppppppcVar9 = (char ******)apppppcStack_88[0][-1];
        uVar10 = uStack_74 + 0x24;
        if ((char *)0x1f < (char *)((int)apppppcStack_88[0] + (-4 - (int)ppppppcVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppppcVar9,uVar10);
    }
    iStack_78 = 0;
    uStack_74 = 0xf;
    apppppcStack_88[0] = (char *****)((uint)apppppcStack_88[0] & 0xffffff00);
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 5;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 6;
    uVar6 = FUN_0151f070(auStack_70,"clientsettingscdn");
    uStack_8._0_1_ = 7;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 8;
    FUN_0151bcc0(auStack_17c,auStack_58,uVar6,&iStack_a0,auStack_28,auStack_40);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    if (0xf < uStack_44) {
      uVar11 = uStack_44 + 1;
      uVar10 = auStack_58[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_58[0] - 4);
        uVar11 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    if (0xf < uStack_5c) {
      uVar11 = uStack_5c + 1;
      uVar10 = auStack_70[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_70[0] - 4);
        uVar11 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    if (0xf < uStack_14) {
      uVar11 = uStack_14 + 1;
      uVar10 = auStack_28[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_28[0] - 4);
        uVar11 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      uVar10 = auStack_40[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    if (uStack_90._4_4_ < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar10 = uStack_90._4_4_ + 1;
    iVar4 = iStack_a0;
    if (0xfff < uVar10) {
      iVar4 = *(int *)(iStack_a0 + -4);
      uVar10 = uStack_90._4_4_ + 0x24;
      if (0x1f < (iStack_a0 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(iVar4,uVar10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13959 ; VA 0x00891760 ; FUN_00891760 */

undefined4 FUN_00891760(undefined4 param_1,undefined4 *param_2,int param_3)

{
  bool bVar1;
  bool bVar2;
  char ******ppppppcVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  char ******ppppppcVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_17c [120];
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  int aiStack_d4 [5];
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  undefined8 uStack_90;
  char *****apppppcStack_88 [4];
  int iStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bab44;
  pvStack_10 = ExceptionList;
  uStack_a4 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8 = 10;
    puVar7 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    puVar7 = (undefined4 *)FUN_0151d700(auStack_bc,param_2,*puVar7);
    uStack_8._0_1_ = 0xb;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    uVar6 = FUN_01675640(auStack_58,"applicationName=%s",puVar7);
    uStack_8._0_1_ = 0xc;
    FUN_0054eff0("/v1/settings/application");
    uStack_8._0_1_ = 0xd;
    uVar8 = FUN_0151ec10(auStack_70);
    uStack_8._0_1_ = 0xe;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 0xf;
    FUN_0151bcc0(auStack_17c,auStack_40,uVar8,auStack_28,uVar6,aiStack_d4);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      uVar10 = auStack_40[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    if (0xf < uStack_5c) {
      uVar11 = uStack_5c + 1;
      uVar10 = auStack_70[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_70[0] - 4);
        uVar11 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    if (0xf < uStack_14) {
      uVar11 = uStack_14 + 1;
      uVar10 = auStack_28[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_28[0] - 4);
        uVar11 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (0xf < uStack_44) {
      uVar11 = uStack_44 + 1;
      uVar10 = auStack_58[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_58[0] - 4);
        uVar11 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    if (0xf < uStack_a8) {
      uVar11 = uStack_a8 + 1;
      uVar10 = auStack_bc[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_bc[0] - 4);
        uVar11 = uStack_a8 + 0x24;
        if (0x1f < (auStack_bc[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_ac = 0;
    uStack_a8 = 0xf;
    auStack_bc[0] = auStack_bc[0] & 0xffffff00;
    if (uStack_c0 < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar10 = uStack_c0 + 1;
    iVar4 = aiStack_d4[0];
    if (0xfff < uVar10) {
      iVar4 = *(int *)(aiStack_d4[0] + -4);
      uVar10 = uStack_c0 + 0x24;
      if (0x1f < (aiStack_d4[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054eff0(param_3);
    uStack_8 = 0;
    if (iStack_78 != 0) {
      ppppppcVar9 = apppppcStack_88;
      if (0xf < uStack_74) {
        ppppppcVar9 = (char ******)apppppcStack_88[0];
      }
      ppppppcVar3 = apppppcStack_88;
      if (0xf < uStack_74) {
        ppppppcVar3 = (char ******)apppppcStack_88[0];
      }
      for (; ppppppcVar3 != (char ******)((int)ppppppcVar9 + iStack_78);
          ppppppcVar3 = (char ******)((int)ppppppcVar3 + 1)) {
        iVar4 = FUN_0171dc29((int)*(char *)ppppppcVar3);
        if (iVar4 == 0) {
          if (0xf < (uint)param_2[5]) {
            param_2 = (undefined4 *)*param_2;
          }
          piVar5 = (int *)FUN_01675640(auStack_ec,"/v2/settings/application/%s/bucket/%s",param_2,
                                       param_3);
          bVar2 = false;
          bVar1 = true;
          goto LAB_00891815;
        }
      }
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    piVar5 = (int *)FUN_01675640(auStack_104,"/v2/settings/application/%s",param_2);
    bVar2 = true;
    bVar1 = false;
LAB_00891815:
    iStack_a0 = *piVar5;
    iStack_9c = piVar5[1];
    iStack_98 = piVar5[2];
    iStack_94 = piVar5[3];
    uStack_90 = *(undefined8 *)(piVar5 + 4);
    piVar5[4] = 0;
    piVar5[5] = 0xf;
    *(undefined *)piVar5 = 0;
    uStack_8 = 2;
    if (bVar1) {
      FUN_005507b0();
    }
    if (bVar2) {
      FUN_005507b0();
    }
    uStack_8._0_1_ = 4;
    if (0xf < uStack_74) {
      uVar10 = uStack_74 + 1;
      ppppppcVar9 = (char ******)apppppcStack_88[0];
      if (0xfff < uVar10) {
        ppppppcVar9 = (char ******)apppppcStack_88[0][-1];
        uVar10 = uStack_74 + 0x24;
        if ((char *)0x1f < (char *)((int)apppppcStack_88[0] + (-4 - (int)ppppppcVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppppcVar9,uVar10);
    }
    iStack_78 = 0;
    uStack_74 = 0xf;
    apppppcStack_88[0] = (char *****)((uint)apppppcStack_88[0] & 0xffffff00);
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 5;
    FUN_0054eff0(&DAT_018bc9b8);
    uStack_8._0_1_ = 6;
    uVar6 = FUN_0151ec10(auStack_70);
    uStack_8._0_1_ = 7;
    FUN_0054eff0("https");
    uStack_8._0_1_ = 8;
    FUN_0151bcc0(auStack_17c,auStack_58,uVar6,&iStack_a0,auStack_28,auStack_40);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_0151bb70(param_1);
    FUN_0056d9d0();
    if (0xf < uStack_44) {
      uVar11 = uStack_44 + 1;
      uVar10 = auStack_58[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_58[0] - 4);
        uVar11 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    if (0xf < uStack_5c) {
      uVar11 = uStack_5c + 1;
      uVar10 = auStack_70[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_70[0] - 4);
        uVar11 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    if (0xf < uStack_14) {
      uVar11 = uStack_14 + 1;
      uVar10 = auStack_28[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_28[0] - 4);
        uVar11 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (0xf < uStack_2c) {
      uVar11 = uStack_2c + 1;
      uVar10 = auStack_40[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        uVar11 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    if (uStack_90._4_4_ < 0x10) {
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar10 = uStack_90._4_4_ + 1;
    iVar4 = iStack_a0;
    if (0xfff < uVar10) {
      iVar4 = *(int *)(iStack_a0 + -4);
      uVar10 = uStack_90._4_4_ + 0x24;
      if (0x1f < (iStack_a0 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(iVar4,uVar10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13960 ; VA 0x00891da0 ; FUN_00891da0 */

void FUN_00891da0(void)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int aiStack_100c [1012];
  undefined4 uStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  FUN_016f40d0();
  uStack_14 = 0x891db6;
  iVar1 = GetProcessHeap();
  uStack_14 = 4;
  puStack_18 = &stack0xfffffff8;
  uStack_1c = 0;
  piStack_24 = (int *)0x891dce;
  iStack_20 = iVar1;
  HeapSetInformation();
  piStack_24 = aiStack_100c;
  uStack_28 = 0x400;
  uStack_2c = 0x891de0;
  uVar2 = GetProcessHeaps();
  uVar3 = 0;
  if (uVar2 != 0) {
    do {
      iStack_38 = aiStack_100c[uVar3];
      if (iStack_38 != iVar1) {
        uStack_2c = 4;
        puStack_30 = &stack0xfffffff8;
        uStack_34 = 0;
        uStack_3c = 0x891e11;
        HeapSetInformation();
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar2);
  }
  return;
}



/* FUNCTION 13961 ; VA 0x00891e20 ; FUN_00891e20 */

undefined4 __thiscall FUN_00891e20(undefined4 param_1,code *param_2)

{
  (*param_2)();
  return param_1;
}



/* FUNCTION 13962 ; VA 0x00891e30 ; FUN_00891e30 */

undefined4 * __fastcall FUN_00891e30(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017babb4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00554ed0();
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_00888700("<<<ROOT>>>",uStack_28,0,uVar1);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::ClassDescriptor::vftable;
  FUN_00892390(0);
  uStack_8._0_1_ = 1;
  FUN_00892390(0);
  uStack_8._0_1_ = 2;
  FUN_00892390(0);
  uStack_8._0_1_ = 3;
  FUN_00892390(0);
  uStack_8._0_1_ = 4;
  FUN_00892390(0);
  param_1[0x74] = 0;
  param_1[0x75] = param_1[0x75] & 0xffffffed | 0xd;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  uStack_8._0_1_ = 6;
  FUN_00806e90();
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00893cc0(param_1 + 6,0);
  FUN_00893cc0(param_1 + 0x1c,1);
  FUN_00893cc0(param_1 + 0x32,2);
  FUN_00893cc0(param_1 + 0x48,3);
  FUN_00893cc0(param_1 + 0x5e,4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13963 ; VA 0x00891fc0 ; FUN_00891fc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_00891fc0(undefined4 *param_1,int param_2,undefined4 param_3,uint param_4,undefined8 param_5,
            undefined4 param_6,int param_7,undefined4 param_8,int param_9)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bac24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00554ed0();
  FUN_00888700(param_3,param_5,param_6,uVar3);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::ClassDescriptor::vftable;
  FUN_00892390(param_2 + 0x18);
  uStack_8._0_1_ = 1;
  FUN_00892390(param_2 + 0x70);
  uStack_8._0_1_ = 2;
  FUN_00892390(param_2 + 200);
  uStack_8._0_1_ = 3;
  FUN_00892390(param_2 + 0x120);
  uStack_8._0_1_ = 4;
  FUN_00892390(param_2 + 0x178);
  param_1[0x74] = param_8;
  param_1[0x75] =
       ((param_7 >> 4 & 1U | (param_4 & 0xff) * 2) * 2 | param_7 >> 3 & 1U) << 2 | param_7 >> 1 & 3U
       | param_1[0x75] & 0xffffffe0;
  if (param_9 == 0) {
    param_9 = *(int *)(param_2 + 0x1dc);
  }
  param_1[0x77] = param_9;
  param_1[0x78] = param_2;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  uStack_8._0_1_ = 6;
  FUN_00806e90();
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00893cc0(param_1 + 6,0);
  FUN_00893cc0(param_1 + 0x1c,1);
  FUN_00893cc0(param_1 + 0x32,2);
  FUN_00893cc0(param_1 + 0x48,3);
  FUN_00893cc0(param_1 + 0x5e,4);
  _DAT_01ededa0 = _DAT_01ededa0 + 1;
  iVar5 = *(int *)(param_2 + 0x1e4);
  iVar6 = *(int *)(param_2 + 0x1e8) - iVar5 >> 2;
  while (iVar1 = iVar6, 0 < iVar1) {
    iVar6 = iVar1 >> 1;
    cVar2 = FUN_00892930(*(undefined4 *)(iVar5 + iVar6 * 4),param_1);
    if (cVar2 != '\0') {
      iVar5 = iVar5 + iVar6 * 4 + 4;
      iVar6 = iVar1 + (-1 - iVar6);
    }
  }
  FUN_00892fc0();
  FUN_005789c0(&DAT_01edefc4,&LAB_00892fb0);
  iVar5 = FUN_00893c60();
  iVar5 = *(int *)(iVar5 + 4);
  FUN_005789c0(&DAT_01edefc4,&LAB_00892fb0);
  piVar4 = (int *)FUN_00893c60();
  iVar6 = *piVar4;
  iVar5 = iVar5 - iVar6 >> 2;
  while (iVar1 = iVar5, 0 < iVar1) {
    iVar5 = iVar1 >> 1;
    cVar2 = FUN_00892930(*(undefined4 *)(iVar6 + iVar5 * 4),param_1);
    if (cVar2 != '\0') {
      iVar6 = iVar6 + iVar5 * 4 + 4;
      iVar5 = iVar1 + (-1 - iVar5);
    }
  }
  FUN_005789c0(&DAT_01edefc4,&LAB_00892fb0);
  FUN_00893c60();
  FUN_00892fc0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13964 ; VA 0x008922b0 ; FUN_008922b0 */

undefined4 * __fastcall FUN_008922b0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bac4e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = 0;
  *param_1 = RBX::Reflection::DescribedBase::vftable;
  param_1[4] = 0;
  uStack_8 = 2;
  uVar1 = FUN_008939f0();
  param_1[3] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13965 ; VA 0x00892310 ; FUN_00892310 */

undefined4 * __thiscall
FUN_00892310(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888700(param_3,param_5,param_6,param_8);
  uStack_8 = 0;
  *param_1 = RBX::Reflection::MemberDescriptor::vftable;
  uVar1 = FUN_0086e3d0(param_4);
  param_1[6] = uVar1;
  param_1[7] = param_2;
  param_1[8] = param_7;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13966 ; VA 0x00892390 ; FUN_00892390 */

undefined4 * __thiscall FUN_00892390(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  char cVar3;
  code *pcStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bac89;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  pcStack_20 = (code *)&DAT_018bc9b8;
  puStack_1c = (undefined4 *)0x0;
  puStack_18 = param_1;
  FUN_0060e8c0(0,&pcStack_20,&uStack_11);
  iVar2 = (int)param_2;
  param_1[6] = 0;
  param_1[7] = &DAT_018bc9b8;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = param_2;
  param_1[0xe] = 0;
  pcStack_20 = FUN_00553510;
  puStack_1c = param_1;
  cVar3 = FUN_00585a40(&pcStack_20);
  if (cVar3 == '\0') {
    param_1[0x10] = pcStack_20;
    param_1[0x11] = puStack_1c;
    param_1[0xe] = &DAT_0191d175;
  }
  else {
    param_1[0xe] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iVar2 != 0) {
    FUN_008933a0(iVar2);
    puVar1 = *(undefined4 **)(iVar2 + 0x28);
    if (*(undefined4 **)(iVar2 + 0x2c) != puVar1) {
      *puVar1 = param_1;
      *(int *)(iVar2 + 0x28) = *(int *)(iVar2 + 0x28) + 4;
      ExceptionList = pvStack_10;
      return param_1;
    }
    param_2 = param_1;
    FUN_006030d0(puVar1,&param_2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13967 ; VA 0x008924b0 ; thunk_FUN_008925c0 */

void __fastcall thunk_FUN_008925c0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[0xe];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    param_1[0xe] = 0;
  }
  iVar1 = param_1[9];
  if (iVar1 != 0) {
    uVar3 = param_1[0xb] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008926f2;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[9] = 0;
    param_1[10] = 0;
    param_1[0xb] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008926f2;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_008926f2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13968 ; VA 0x008924c0 ; FUN_008924c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_008924c0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::Reflection::ClassDescriptor::vftable;
  _DAT_01ededa0 = _DAT_01ededa0 + -1;
  FUN_00617ad0();
  iVar1 = param_1[0x79];
  if (iVar1 != 0) {
    uVar3 = param_1[0x7b] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x79] = 0;
    param_1[0x7a] = 0;
    param_1[0x7b] = 0;
  }
  FUN_008925c0();
  FUN_008925c0();
  FUN_008925c0();
  FUN_008925c0();
  FUN_008925c0();
  FUN_00888900();
  return;
}



/* FUNCTION 13969 ; VA 0x00892570 ; FUN_00892570 */

int __fastcall FUN_00892570(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  *param_1 = RBX::Reflection::DescribedBase::vftable;
  iVar4 = FUN_005c4ac0();
  piVar3 = (int *)param_1[2];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piVar3 + 4))();
    }
  }
  *param_1 = RBX::Reflection::EventSource::vftable;
  return iVar4;
}



/* FUNCTION 13970 ; VA 0x008925a0 ; FUN_008925a0 */

void __fastcall FUN_008925a0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::EventSource::vftable;
  return;
}



/* FUNCTION 13971 ; VA 0x008925b0 ; FUN_008925b0 */

void __fastcall FUN_008925b0(undefined4 *param_1)

{
  *param_1 = RBX::Reflection::MemberDescriptor::vftable;
  FUN_00888900();
  return;
}



/* FUNCTION 13972 ; VA 0x008925c0 ; FUN_008925c0 */

void __fastcall FUN_008925c0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[0xe];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    ExceptionList = &pvStack_10;
    if ((uVar3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    param_1[0xe] = 0;
  }
  iVar1 = param_1[9];
  if (iVar1 != 0) {
    uVar3 = param_1[0xb] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008926f2;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[9] = 0;
    param_1[10] = 0;
    param_1[0xb] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008926f2;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_008926f2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13973 ; VA 0x00892700 ; FUN_00892700 */

bool __thiscall FUN_00892700(int param_1,int param_2)

{
  return param_1 == param_2;
}



/* FUNCTION 13974 ; VA 0x00892710 ; FUN_00892710 */

bool __thiscall FUN_00892710(int param_1,int param_2)

{
  return param_1 != param_2;
}



/* FUNCTION 13975 ; VA 0x00892720 ; FUN_00892720 */

uint __thiscall FUN_00892720(byte *param_1,byte *param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint in_EAX;
  uint uVar4;
  bool bVar5;
  
  if (param_1 == param_2) {
    return in_EAX & 0xffffff00;
  }
  uVar1 = *(uint *)(param_2 + 0x10);
  if (0xf < *(uint *)(param_2 + 0x14)) {
    param_2 = *(byte **)param_2;
  }
  uVar2 = *(uint *)(param_1 + 0x10);
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(byte **)param_1;
  }
  uVar4 = uVar2;
  if (uVar1 < uVar2) {
    uVar4 = uVar1;
  }
  while (uVar3 = uVar4 - 4, 3 < uVar4) {
    if (*(int *)param_1 != *(int *)param_2) goto LAB_0089276b;
    param_1 = param_1 + 4;
    param_2 = param_2 + 4;
    uVar4 = uVar3;
  }
  if (uVar3 != 0xfffffffc) {
LAB_0089276b:
    bVar5 = *param_1 < *param_2;
    if ((*param_1 != *param_2) ||
       ((uVar3 != 0xfffffffd &&
        ((bVar5 = param_1[1] < param_2[1], param_1[1] != param_2[1] ||
         ((uVar3 != 0xfffffffe &&
          ((bVar5 = param_1[2] < param_2[2], param_1[2] != param_2[2] ||
           ((uVar3 != 0xffffffff && (bVar5 = param_1[3] < param_2[3], param_1[3] != param_2[3]))))))
         )))))) {
      uVar4 = -(uint)bVar5 | 1;
      goto LAB_008927a1;
    }
  }
  uVar4 = 0;
LAB_008927a1:
  if (uVar4 == 0) {
    if (uVar2 < uVar1) {
      return 1;
    }
    uVar4 = 0;
  }
  return uVar4 >> 0x1f;
}



/* FUNCTION 13976 ; VA 0x008927d0 ; FUN_008927d0 */

void __thiscall FUN_008927d0(uint *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 13977 ; VA 0x00892830 ; FUN_00892830 */

undefined4 __thiscall FUN_00892830(undefined4 param_1,byte param_2)

{
  FUN_008924c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x208);
  }
  return param_1;
}



/* FUNCTION 13978 ; VA 0x00892860 ; FUN_00892860 */

undefined4 * __thiscall FUN_00892860(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = RBX::Reflection::DescribedBase::vftable;
  FUN_005c4ac0();
  piVar1 = (int *)param_1[2];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  *param_1 = RBX::Reflection::EventSource::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 13979 ; VA 0x008928b0 ; FUN_008928b0 */

undefined4 * __thiscall FUN_008928b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EventSource::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 13980 ; VA 0x008928e0 ; FUN_008928e0 */

undefined4 * __thiscall FUN_008928e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::MemberDescriptor::vftable;
  FUN_00888900();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 13981 ; VA 0x00892910 ; FUN_00892910 */

void FUN_00892910(void)

{
  FUN_005789c0(&DAT_01edefc4,&LAB_00892fb0);
  FUN_00893c60();
  return;
}



/* FUNCTION 13982 ; VA 0x00892930 ; FUN_00892930 */

void FUN_00892930(undefined4 param_1,int param_2)

{
  FUN_00892720(*(undefined4 *)(param_2 + 4));
  return;
}



/* FUNCTION 13983 ; VA 0x00892950 ; FUN_00892950 */

void __thiscall FUN_00892950(int *param_1,int *param_2)

{
  int *piVar1;
  void **ppvVar2;
  char cVar3;
  undefined4 *puVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar9 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baca8;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puVar4 = (undefined4 *)param_1[1];
  puVar7 = (undefined4 *)*param_1;
  iVar8 = (int)puVar4 - (int)puVar7 >> 2;
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  piStack_20 = param_1;
  if (0 < iVar8) {
    do {
      ExceptionList = ppvVar2;
      puStack_14 = (undefined4 *)(iVar8 >> 1);
      puStack_1c = puVar7 + (int)puStack_14;
      cVar3 = FUN_00892930(*puStack_1c,piVar9);
      if (cVar3 != '\0') {
        puVar7 = puStack_1c + 1;
        puStack_14 = (undefined4 *)(iVar8 + (-1 - (int)puStack_14));
      }
      iVar8 = (int)puStack_14;
      ppvVar2 = (void **)ExceptionList;
    } while (0 < (int)puStack_14);
    puVar4 = (undefined4 *)piStack_20[1];
    puStack_14 = puVar7;
  }
  piVar1 = piStack_20;
  if (puVar7 == puVar4) {
    FUN_00892fc0(&piStack_20,puVar7,&param_2);
    piVar9 = param_2;
    param_2 = (int *)param_2[1];
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    if ((uint)((piVar1[4] - piVar1[3] >> 3) * 3) >> 2 <= (uint)piVar1[6]) {
      FUN_00893680();
    }
    iVar8 = FUN_00893040(&param_2);
    *(int **)(iVar8 + 4) = piVar9;
    if (piVar1[0xe] == 0) {
      uVar6 = FUN_0054fda0();
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar6);
    }
    pcVar5 = *(code **)((piVar1[0xe] & 0xfffffffeU) + 4);
    piVar10 = piVar1 + 0x10;
    piVar11 = piVar9;
  }
  else {
    piVar10 = (int *)*puVar7;
    if (piVar10 == piVar9) {
      ExceptionList = pvStack_10;
      return;
    }
    if (piVar10[1] != piVar9[1]) {
      FUN_00892fc0(&piStack_20,puVar7,&param_2);
      piVar9 = param_2;
      param_2 = (int *)param_2[1];
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      if ((uint)((piVar1[4] - piVar1[3] >> 3) * 3) >> 2 <= (uint)piVar1[6]) {
        FUN_00893680();
      }
      iVar8 = FUN_00893040(&param_2);
      *(int **)(iVar8 + 4) = piVar9;
      FUN_008927d0(piVar9);
      goto LAB_00892afc;
    }
    *puVar7 = piVar9;
    param_2 = (int *)piVar9[1];
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    piStack_18 = piVar10;
    if ((uint)((piStack_20[4] - piStack_20[3] >> 3) * 3) >> 2 <= (uint)piStack_20[6]) {
      FUN_00893680();
    }
    iVar8 = FUN_00893040(&param_2);
    *(int **)(iVar8 + 4) = piVar9;
    FUN_008927d0(piVar9);
    pcVar5 = DAT_01eded9c;
    piVar10 = piVar9;
    piVar11 = piStack_18;
    if (DAT_01eded9c == (code *)0x0) goto LAB_00892afc;
  }
  (*pcVar5)(piVar10,piVar11);
LAB_00892afc:
  iVar8 = piVar1[9];
  if (iVar8 != piVar1[10]) {
    do {
      FUN_00892b40(piVar9,piStack_18);
      iVar8 = iVar8 + 4;
    } while (iVar8 != piVar1[10]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13984 ; VA 0x00892b40 ; FUN_00892b40 */

void __thiscall FUN_00892b40(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  void **ppvVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar8 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ab188;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)param_1[1];
  piStack_14 = (int *)*param_1;
  iVar7 = (int)piVar4 - (int)piStack_14 >> 2;
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  piStack_1c = param_1;
  if (0 < iVar7) {
    do {
      iVar6 = iVar7 >> 1;
      piStack_18 = piStack_14 + iVar6;
      cVar3 = FUN_00892930(*piStack_18,iVar8);
      if (cVar3 != '\0') {
        piStack_14 = piStack_18 + 1;
        iVar6 = iVar7 + (-1 - iVar6);
      }
      iVar7 = iVar6;
    } while (0 < iVar6);
    piVar4 = (int *)piStack_1c[1];
    ppvVar2 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar2;
  piVar1 = piStack_1c;
  if (piStack_14 == piVar4) {
    FUN_00892fc0(&piStack_1c,piStack_14,&param_2);
    iVar8 = (int)param_2;
    param_2 = *(int **)((int)param_2 + 4);
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    if ((uint)((piVar1[4] - piVar1[3] >> 3) * 3) >> 2 <= (uint)piVar1[6]) {
      FUN_00893680();
    }
    iVar7 = FUN_00893040(&param_2);
    *(int *)(iVar7 + 4) = iVar8;
    if (piVar1[0xe] == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    (**(code **)((piVar1[0xe] & 0xfffffffeU) + 4))(piVar1 + 0x10,iVar8);
  }
  else {
    if (*piStack_14 == param_3) {
      *piStack_14 = iVar8;
    }
    else {
      if (*(int *)(*piStack_14 + 4) == *(int *)(iVar8 + 4)) {
        if (DAT_01eded9c == (code *)0x0) {
          ExceptionList = pvStack_10;
          return;
        }
        (*DAT_01eded9c)(iVar8,param_3);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00892fc0(&piStack_1c,piStack_14,&param_2);
      iVar8 = (int)param_2;
    }
    param_2 = *(int **)(iVar8 + 4);
    if (0xf < (uint)param_2[5]) {
      param_2 = (int *)*param_2;
    }
    if ((uint)((piVar1[4] - piVar1[3] >> 3) * 3) >> 2 <= (uint)piVar1[6]) {
      FUN_00893680();
    }
    iVar7 = FUN_00893040(&param_2);
    *(int *)(iVar7 + 4) = iVar8;
    FUN_008927d0(iVar8);
  }
  iVar7 = piVar1[9];
  if (iVar7 == piVar1[10]) {
    ExceptionList = pvStack_10;
    return;
  }
  do {
    FUN_00892b40(iVar8,param_3);
    iVar7 = iVar7 + 4;
  } while (iVar7 != piVar1[10]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13985 ; VA 0x00892d00 ; FUN_00892d00 */

void FUN_00892d00(void)

{
  DAT_01eded98 = 1;
  FUN_008939f0();
  FUN_00892f30(1);
  return;
}



/* FUNCTION 13986 ; VA 0x00892d20 ; FUN_00892d20 */

undefined4 __thiscall FUN_00892d20(int param_1,byte *param_2)

{
  byte bVar1;
  byte *pbVar2;
  uint uVar3;
  uint uVar4;
  byte *pbVar5;
  byte *pbVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  bool bVar10;
  uint uStack_c;
  
  if (*(int *)(param_1 + 0xc) != *(int *)(param_1 + 0x10)) {
    pbVar5 = *(byte **)(param_1 + 0x1c);
    pbVar2 = param_2;
    do {
      bVar1 = *pbVar2;
      bVar10 = bVar1 < *pbVar5;
      if (bVar1 != *pbVar5) {
LAB_00892d62:
        uVar3 = -(uint)bVar10 | 1;
        goto LAB_00892d67;
      }
      if (bVar1 == 0) break;
      bVar1 = pbVar2[1];
      bVar10 = bVar1 < pbVar5[1];
      if (bVar1 != pbVar5[1]) goto LAB_00892d62;
      pbVar2 = pbVar2 + 2;
      pbVar5 = pbVar5 + 2;
    } while (bVar1 != 0);
    uVar3 = 0;
LAB_00892d67:
    if (uVar3 != 0) {
      uVar7 = (*(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc) >> 3) - 1;
      uVar3 = FUN_00888920(param_2);
      uStack_c = 0;
      do {
        uVar3 = uVar3 & uVar7;
        pbVar5 = *(byte **)(*(int *)(param_1 + 0xc) + uVar3 * 8);
        iVar8 = *(int *)(param_1 + 0xc) + uVar3 * 8;
        pbVar2 = pbVar5;
        pbVar6 = param_2;
        do {
          bVar1 = *pbVar2;
          bVar10 = bVar1 < *pbVar6;
          if (bVar1 != *pbVar6) {
LAB_00892dc2:
            uVar4 = -(uint)bVar10 | 1;
            goto LAB_00892dc7;
          }
          if (bVar1 == 0) break;
          bVar1 = pbVar2[1];
          bVar10 = bVar1 < pbVar6[1];
          if (bVar1 != pbVar6[1]) goto LAB_00892dc2;
          pbVar2 = pbVar2 + 2;
          pbVar6 = pbVar6 + 2;
        } while (bVar1 != 0);
        uVar4 = 0;
LAB_00892dc7:
        if (uVar4 == 0) goto LAB_00892e11;
        pbVar2 = *(byte **)(param_1 + 0x1c);
        do {
          bVar1 = *pbVar5;
          bVar10 = bVar1 < *pbVar2;
          if (bVar1 != *pbVar2) {
LAB_00892df1:
            uVar4 = -(uint)bVar10 | 1;
            goto LAB_00892df6;
          }
          if (bVar1 == 0) break;
          bVar1 = pbVar5[1];
          bVar10 = bVar1 < pbVar2[1];
          if (bVar1 != pbVar2[1]) goto LAB_00892df1;
          pbVar5 = pbVar5 + 2;
          pbVar2 = pbVar2 + 2;
        } while (bVar1 != 0);
        uVar4 = 0;
LAB_00892df6:
        if (uVar4 == 0) break;
        uVar3 = uVar3 + 1 + uStack_c;
        uStack_c = uStack_c + 1;
      } while (uStack_c <= uVar7);
    }
  }
  iVar8 = 0;
LAB_00892e11:
  puVar9 = (undefined4 *)(-(uint)(iVar8 != 0) & iVar8 + 4U);
  if (puVar9 != (undefined4 *)0x0) {
    return *puVar9;
  }
  return 0;
}



/* FUNCTION 13987 ; VA 0x00892e40 ; FUN_00892e40 */

undefined4 FUN_00892e40(uint param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  piVar2 = (int *)FUN_00892e90();
  if (piVar2 == (int *)0x0) {
    return 0;
  }
  puVar1 = (undefined4 *)*piVar2;
  puVar3 = puVar1;
  puVar5 = (undefined4 *)puVar1[1];
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      puVar4 = puVar5;
      if ((uint)puVar4[4] < param_1) {
        puVar5 = (undefined4 *)puVar4[2];
        puVar4 = puVar3;
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((uint)puVar4[4] <= param_1)) goto LAB_00892e7f;
  }
  puVar4 = puVar1;
LAB_00892e7f:
  if (puVar4 == puVar1) {
    return 0;
  }
  return puVar4[5];
}



/* FUNCTION 13988 ; VA 0x00892e90 ; FUN_00892e90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00892e90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baccc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edefdc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edefdc);
    if (DAT_01edefdc == -1) {
      uStack_8 = 0;
      _DAT_01edefd0 = FUN_00601dc0();
      DAT_01edefd8 = &DAT_01edefcc;
      DAT_01edefcc = &DAT_01edefd0;
      FUN_016f3654(&LAB_01880b00);
      FUN_016f37bf(&DAT_01edefdc);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01edefcc;
}



/* FUNCTION 13989 ; VA 0x00892f30 ; FUN_00892f30 */

int __thiscall FUN_00892f30(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  iVar1 = param_2 + 1;
  *(short *)(param_1 + 0x1d8) = (short)param_2;
  uVar2 = (*(uint *)(param_1 + 0x1e8) - *(uint *)(param_1 + 0x1e4)) + 3 >> 2;
  uVar3 = 0;
  if (*(uint *)(param_1 + 0x1e8) < *(uint *)(param_1 + 0x1e4)) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    do {
      iVar1 = FUN_00892f30(iVar1);
      uVar3 = uVar3 + 1;
    } while (uVar3 != uVar2);
    param_2._0_2_ = *(short *)(param_1 + 0x1d8);
  }
  *(short *)(param_1 + 0x1da) = ((short)iVar1 - (short)param_2) + -1;
  return iVar1;
}



/* FUNCTION 13990 ; VA 0x00892fc0 ; FUN_00892fc0 */

undefined4 * __thiscall
FUN_00892fc0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) == puVar1) {
    uVar3 = FUN_006030d0(param_3,param_4);
    *param_2 = uVar3;
    return param_2;
  }
  uVar3 = *param_4;
  if (param_3 == puVar1) {
    *puVar1 = uVar3;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    *param_2 = param_3;
    return param_2;
  }
  *puVar1 = puVar1[-1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
  FUN_0055b6b0((int)&param_4 + 3,&param_4,&param_4);
  iVar2 = (int)puVar1 + (-4 - (int)param_3);
  FUN_0170cc70((int)puVar1 - iVar2,param_3,iVar2);
  *param_3 = uVar3;
  *param_2 = param_3;
  return param_2;
}



/* FUNCTION 13991 ; VA 0x00893040 ; FUN_00893040 */

undefined4 * __thiscall FUN_00893040(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  undefined4 *puVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  byte *pbVar8;
  uint uVar9;
  bool bVar10;
  
  puVar3 = param_2;
  uVar9 = (param_1[1] - *param_1 >> 3) - 1;
  uVar4 = FUN_00888920(*param_2);
  param_2 = (undefined4 *)0x0;
  do {
    uVar4 = uVar4 & uVar9;
    pbVar8 = *(byte **)(*param_1 + uVar4 * 8);
    puVar1 = (undefined4 *)(*param_1 + uVar4 * 8);
    pbVar5 = pbVar8;
    pbVar7 = (byte *)param_1[4];
    do {
      bVar2 = *pbVar5;
      bVar10 = bVar2 < *pbVar7;
      if (bVar2 != *pbVar7) {
LAB_008930c0:
        uVar6 = -(uint)bVar10 | 1;
        goto LAB_008930c5;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar5[1];
      bVar10 = bVar2 < pbVar7[1];
      if (bVar2 != pbVar7[1]) goto LAB_008930c0;
      pbVar5 = pbVar5 + 2;
      pbVar7 = pbVar7 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_008930c5:
    pbVar5 = (byte *)*puVar3;
    if (uVar6 == 0) {
      *puVar1 = (byte *)*puVar3;
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    do {
      bVar2 = *pbVar8;
      bVar10 = bVar2 < *pbVar5;
      if (bVar2 != *pbVar5) {
LAB_008930f0:
        uVar6 = -(uint)bVar10 | 1;
        goto LAB_008930f5;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar8[1];
      bVar10 = bVar2 < pbVar5[1];
      if (bVar2 != pbVar5[1]) goto LAB_008930f0;
      pbVar8 = pbVar8 + 2;
      pbVar5 = pbVar5 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_008930f5:
    if (uVar6 == 0) {
      return puVar1;
    }
    uVar4 = uVar4 + 1 + (int)param_2;
    param_2 = (undefined4 *)((int)param_2 + 1);
    if (uVar9 < param_2) {
      return (undefined4 *)0x0;
    }
  } while( true );
}



/* FUNCTION 13992 ; VA 0x00893140 ; FUN_00893140 */

void FUN_00893140(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_2);
  return;
}



/* FUNCTION 13993 ; VA 0x00893160 ; FUN_00893160 */

void FUN_00893160(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_2,param_1[3]);
  return;
}



/* FUNCTION 13994 ; VA 0x00893180 ; FUN_00893180 */

undefined4 __thiscall FUN_00893180(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  while( true ) {
    if (iVar1 == param_2) {
      return 1;
    }
    param_1 = *(int *)(param_1 + 0x1e0);
    if (param_1 == 0) break;
    iVar1 = *(int *)(param_1 + 4);
  }
  return 0;
}



/* FUNCTION 13995 ; VA 0x008931b0 ; FUN_008931b0 */

uint __thiscall FUN_008931b0(int param_1,byte *param_2)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  byte *pbVar5;
  byte *pbVar6;
  bool bVar7;
  
  do {
    pbVar5 = *(byte **)(param_1 + 4);
    pbVar6 = param_2;
    do {
      bVar1 = *pbVar6;
      pbVar6 = pbVar6 + 1;
    } while (bVar1 != 0);
    uVar2 = *(uint *)(pbVar5 + 0x10);
    if (0xf < *(uint *)(pbVar5 + 0x14)) {
      pbVar5 = *(byte **)pbVar5;
    }
    pbVar4 = param_2;
    if (uVar2 == (int)pbVar6 - (int)(param_2 + 1)) {
      while (uVar3 = uVar2 - 4, 3 < uVar2) {
        if (*(int *)pbVar5 != *(int *)pbVar4) goto LAB_008931fd;
        pbVar5 = pbVar5 + 4;
        pbVar4 = pbVar4 + 4;
        uVar2 = uVar3;
      }
      if (uVar3 == 0xfffffffc) {
LAB_00893231:
        pbVar5 = (byte *)0x0;
      }
      else {
LAB_008931fd:
        bVar7 = *pbVar5 < *pbVar4;
        if ((*pbVar5 == *pbVar4) &&
           ((uVar3 == 0xfffffffd ||
            ((bVar7 = pbVar5[1] < pbVar4[1], pbVar5[1] == pbVar4[1] &&
             ((uVar3 == 0xfffffffe ||
              ((bVar7 = pbVar5[2] < pbVar4[2], pbVar5[2] == pbVar4[2] &&
               ((uVar3 == 0xffffffff || (bVar7 = pbVar5[3] < pbVar4[3], pbVar5[3] == pbVar4[3]))))))
             )))))) goto LAB_00893231;
        pbVar5 = (byte *)(-(uint)bVar7 | 1);
      }
      if (pbVar5 == (byte *)0x0) {
        return 1;
      }
    }
    param_1 = *(int *)(param_1 + 0x1e0);
    if (param_1 == 0) {
      return (uint)pbVar5 & 0xffffff00;
    }
  } while( true );
}



/* FUNCTION 13996 ; VA 0x00893260 ; FUN_00893260 */

undefined2 __thiscall FUN_00893260(int param_1,int param_2)

{
  ushort uVar1;
  
  uVar1 = *(ushort *)(*(int *)(param_1 + 0x1c) + 0x1da);
  return CONCAT11((char)(uVar1 >> 8),
                  (uint)*(ushort *)(param_2 + 0x1d8) -
                  (uint)*(ushort *)(*(int *)(param_1 + 0x1c) + 0x1d8) <= (uint)uVar1);
}



/* FUNCTION 13997 ; VA 0x00893290 ; FUN_00893290 */

undefined2 __thiscall FUN_00893290(int param_1,int param_2)

{
  ushort uVar1;
  
  uVar1 = *(ushort *)(*(int *)(param_1 + 0x1c) + 0x1da);
  return CONCAT11((char)(uVar1 >> 8),
                  (uint)*(ushort *)(*(int *)(param_2 + 0xc) + 0x1d8) -
                  (uint)*(ushort *)(*(int *)(param_1 + 0x1c) + 0x1d8) <= (uint)uVar1);
}



/* FUNCTION 13998 ; VA 0x008932c0 ; FUN_008932c0 */

void FUN_008932c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da2dcc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::Reflection::MemberDescriptorContainerBase,class_RBX::Reflection::MemberDescriptor*>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::Reflection::MemberDescriptorContainerBase*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 13999 ; VA 0x00893330 ; FUN_00893330 */

void FUN_00893330(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da2eb4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::Reflection::ClassDescriptor,class_RBX::Reflection::MemberDescriptor*,enum_RBX::Reflection::ClassDescriptor::DescriptorType>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::Reflection::ClassDescriptor*>,struct_boost::arg<1>,class_boost::_bi::value<enum_RBX::Reflection::ClassDescriptor::DescriptorType>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}


