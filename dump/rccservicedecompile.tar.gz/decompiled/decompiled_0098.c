/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 24500 ; VA 0x00b62280 ; FUN_00b62280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b62280(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe9c) {
    FUN_016f3809(&DAT_01eefe9c);
    if (DAT_01eefe9c == -1) {
      _DAT_01eefe90 = FUN_005c65e0;
      _DAT_01eefe94 = FUN_005c65e0;
      _DAT_01eefe98 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eefe9c);
    }
  }
  return &DAT_01eefe90;
}



/* FUNCTION 24501 ; VA 0x00b62330 ; FUN_00b62330 */

void FUN_00b62330(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_38 [24];
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5279;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00913630();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      FUN_008a2380(auStack_38);
      uStack_8 = 0;
      uStack_14 = 1;
      uVar3 = FUN_005543f0();
      FUN_016756b0(auStack_20,"Invalid parent for PlayerGui. PlayerGui cannot be parented to %s .",
                   uVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24502 ; VA 0x00b623e0 ; FUN_00b623e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b623e0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5000;
  pvStack_10 = ExceptionList;
  if (DAT_01eefea0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef00b8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef00b8);
      if (DAT_01ef00b8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ServerScriptService",1,uStack_20,0,0,9,0,0);
        _DAT_01ef00b0 = RBX::Creator<class_RBX::ServerScriptService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eefea8,&DAT_01ef00b0);
        FUN_016f3654(FUN_0188e4c0);
        FUN_016f37bf(&DAT_01ef00b8);
      }
    }
    DAT_01eefea0 = &DAT_01eefea8;
  }
  ExceptionList = pvStack_10;
  return DAT_01eefea0;
}



/* FUNCTION 24503 ; VA 0x00b624e0 ; FUN_00b624e0 */

void FUN_00b624e0(void)

{
  int iVar1;
  
  if (DAT_01ef00bc == 0) {
    iVar1 = FUN_00b623e0();
    DAT_01ef00bc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24504 ; VA 0x00b62500 ; FUN_00b62500 */

undefined4 * __fastcall FUN_00b62500(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5028;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ServerScriptService,class_RBX::ServiceInstance>::
             vftable;
  uVar1 = FUN_00b623e0();
  param_1[3] = uVar1;
  param_1[0x16] = RBX::IScriptFilter::vftable;
  uStack_8 = 1;
  *param_1 = RBX::ServerScriptService::vftable;
  param_1[0x16] = RBX::ServerScriptService::vftable;
  *(undefined *)(param_1 + 0x17) = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_00551260("ServerScriptService");
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24505 ; VA 0x00b625e0 ; FUN_00b625e0 */

void __fastcall FUN_00b625e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ServerScriptService>::vftable;
  uVar1 = FUN_00b623e0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24506 ; VA 0x00b62620 ; FUN_00b62620 */

undefined4 __thiscall FUN_00b62620(undefined4 param_1,byte param_2)

{
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 24507 ; VA 0x00b62650 ; FUN_00b62650 */

uint FUN_00b62650(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b9e640();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b73ae0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar1 = *(int *)(param_1 + 0xc);
        iVar2 = FUN_00b739e0();
        in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
        if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
        goto LAB_00b62683;
      }
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_009ec190();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (in_EAX < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))
      goto LAB_00b626f4;
    }
LAB_00b62683:
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
LAB_00b626f4:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 24508 ; VA 0x00b62700 ; FUN_00b62700 */

bool __thiscall FUN_00b62700(int *param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_1 + 0x6c))(param_2);
  return cVar1 == '\0';
}



/* FUNCTION 24509 ; VA 0x00b62720 ; FUN_00b62720 */

undefined4 * FUN_00b62720(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_006737f0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24510 ; VA 0x00b62790 ; FUN_00b62790 */

uint FUN_00b62790(void)

{
  int iVar1;
  
  iVar1 = FUN_00b623e0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24511 ; VA 0x00b627b0 ; FUN_00b627b0 */

uint FUN_00b627b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b623e0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24512 ; VA 0x00b627d0 ; FUN_00b627d0 */

uint __thiscall FUN_00b627d0(int param_1,int param_2)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  int iVar3;
  
  if (param_2 != 0) {
    if (*(int *)(param_2 + 0x34) != param_1 + -0x58) {
      in_EAX = FUN_008a3680(*(int *)(param_2 + 0x34));
      if ((char)in_EAX == '\0') goto LAB_00b6285b;
    }
    in_EAX = FUN_00971ce0(param_2,0);
    if ((char)in_EAX != '\0') {
      iVar1 = *(int *)(param_2 + 0xc);
      iVar2 = FUN_00b73ae0();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      iVar3 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
        iVar3 = param_2;
      }
      if (iVar3 != 0) {
        iVar1 = *(int *)(param_2 + 0xc);
        iVar2 = FUN_00b739e0();
        in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
        iVar3 = 0;
        if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
          iVar3 = param_2;
        }
        if (iVar3 == 0) {
          return CONCAT31((uint3)(byte)(*(ushort *)(iVar2 + 0x1da) >> 8),1);
        }
      }
    }
  }
LAB_00b6285b:
  return in_EAX & 0xffffff00;
}



/* FUNCTION 24513 ; VA 0x00b62870 ; FUN_00b62870 */

void __thiscall FUN_00b62870(int param_1,char param_2)

{
  char cVar1;
  
  cVar1 = *(char *)(param_1 + 0x5c);
  *(char *)(param_1 + 0x5c) = param_2;
  if (param_2 != cVar1) {
    cVar1 = FUN_00983210(param_1);
    if (cVar1 != '\0') {
      FUN_008a4940(&DAT_0212ca3c);
    }
  }
  return;
}



/* FUNCTION 24514 ; VA 0x00b628b0 ; FUN_00b628b0 */

int * __thiscall
FUN_00b628b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f508b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b629b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TerrainRegion,class_G3D::Vector3int16>::
              GetSetImpl<class_G3D::Vector3int16_(__thiscall_RBX::TerrainRegion::*)(void)const_,void_(__thiscall_RBX::TerrainRegion::*)(class_G3D::Vector3int16_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d910();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3int16>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::TerrainRegion,class_G3D::Vector3int16>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::TerrainRegion,class_G3D::Vector3int16>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24515 ; VA 0x00b629b0 ; FUN_00b629b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b629b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f50c0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef00c4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef02d8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef02d8);
      if (DAT_01ef02d8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TerrainRegion",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef02d0 = RBX::Creator<class_RBX::TerrainRegion>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef00c8,&DAT_01ef02d0);
        FUN_016f3654(FUN_0188e5f0);
        FUN_016f37bf(&DAT_01ef02d8);
      }
    }
    DAT_01ef00c4 = &DAT_01ef00c8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef00c4;
}



/* FUNCTION 24516 ; VA 0x00b62ab0 ; FUN_00b62ab0 */

undefined4 * FUN_00b62ab0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f512a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b629b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a650("TerrainRegion");
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::TerrainRegion,class_RBX::Instance>::vftable;
    uVar4 = FUN_00b629b0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::TerrainRegion::vftable;
    puVar3[0x15] = 0;
    uStack_8._0_1_ = 5;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    iVar1 = FUN_01674e20(0x28);
    uStack_8._0_1_ = 6;
    if (iVar1 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00a6dc70();
    }
    iVar1 = puVar3[0x15];
    puVar3[0x15] = uVar4;
    if (iVar1 != 0) {
      FUN_00a6de50();
      FUN_01674ea0(iVar1,0x28);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00af08e0(puVar3,param_1);
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24517 ; VA 0x00b62be0 ; FUN_00b62be0 */

void __thiscall FUN_00b62be0(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if ((((*param_4 == piVar2[2]) && (param_4[1] == piVar2[3])) && (param_4[2] == piVar2[4]))
             && (((param_4[3] == piVar2[5] && (param_4[4] == piVar2[6])) &&
                 (param_4[5] == piVar2[7])))) break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 24518 ; VA 0x00b62c90 ; FUN_00b62c90 */

void __thiscall FUN_00b62c90(byte *param_1,int param_2,uint param_3,undefined4 *param_4,int param_5)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  undefined4 *puVar14;
  
  iVar11 = param_3;
  iVar8 = FUN_00a6ce70(param_3);
  uVar13 = iVar8 + 0x9e3779b9;
  iVar8 = FUN_00a6ce70(iVar11 + 0xc);
  uVar13 = uVar13 * 0x40 + (uVar13 >> 2) + iVar8 + -0x61c88647 ^ uVar13;
  FUN_00b62be0(&param_3,uVar13,iVar11,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  puVar14 = param_4;
  if (param_3 == 0) {
    iVar11 = *(int *)(param_2 + 4);
    if (iVar11 == 0) {
      *(undefined2 *)(param_2 + 8) = 0;
      puVar9 = (undefined4 *)FUN_01674e20(0x20);
      *(undefined4 **)(param_2 + 4) = puVar9;
      *puVar9 = 0;
      puVar9[1] = 0;
      puVar9[2] = 0;
      puVar9[3] = 0;
      puVar9[4] = 0;
      puVar9[5] = 0;
      *(undefined8 *)(puVar9 + 6) = 0;
      iVar11 = *(int *)(param_2 + 4);
      *(undefined *)(param_2 + 8) = 1;
    }
    else if (*(char *)(param_2 + 9) != '\0') {
      *(undefined *)(param_2 + 9) = 0;
    }
    uVar5 = puVar14[1];
    uVar6 = puVar14[2];
    uVar7 = puVar14[3];
    *(undefined4 *)(iVar11 + 8) = *puVar14;
    *(undefined4 *)(iVar11 + 0xc) = uVar5;
    *(undefined4 *)(iVar11 + 0x10) = uVar6;
    *(undefined4 *)(iVar11 + 0x14) = uVar7;
    *(undefined8 *)(iVar11 + 0x18) = *(undefined8 *)(puVar14 + 4);
    *(undefined *)(param_2 + 9) = 1;
    uVar10 = *(uint *)(param_1 + 8);
    if (*(uint *)(param_1 + 0x10) < uVar10 + 1) {
      param_3 = (param_5 - (int)param_4) / 0x18;
      uVar1 = param_3 + uVar10;
      if (*(int *)(param_1 + 0x14) == 0) {
        uVar10 = FUN_005d6bb0(uVar1);
        if (uVar10 <= *(uint *)(param_1 + 4)) {
          uVar10 = *(uint *)(param_1 + 4);
        }
        FUN_00780ee0(uVar10);
      }
      else if (*(uint *)(param_1 + 0x10) < uVar1) {
        uVar12 = uVar10 >> 1;
        if ((uVar10 >> 1) + uVar10 <= uVar1) {
          uVar12 = param_3;
        }
        iVar11 = FUN_005d6bb0(uVar12 + uVar10);
        if (iVar11 != *(int *)(param_1 + 4)) {
          FUN_00780ee0(iVar11);
          puVar14 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
          puVar9 = (undefined4 *)*puVar14;
          while (puVar9 != (undefined4 *)0x0) {
            piVar2 = (int *)(*(int *)(param_1 + 0x14) +
                            ((uint)puVar9[1] % *(uint *)(param_1 + 4)) * 4);
            if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar9[1] % *(uint *)(param_1 + 4)) * 4)
                == 0) {
              *piVar2 = (int)puVar14;
              puVar14 = puVar9;
            }
            else {
              *puVar14 = *puVar9;
              *puVar9 = *(undefined4 *)*piVar2;
              *(undefined4 **)*piVar2 = puVar9;
            }
            puVar9 = (undefined4 *)*puVar14;
          }
        }
      }
    }
    piVar4 = *(int **)(param_2 + 4);
    *(undefined4 *)(param_2 + 4) = 0;
    piVar4[1] = uVar13;
    uVar13 = uVar13 % *(uint *)(param_1 + 4);
    puVar14 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar13 * 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar13 * 4);
    if (puVar14 == (undefined4 *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *piVar2 = (int)piVar3;
      *piVar4 = *piVar3;
      *piVar3 = (int)piVar4;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      return;
    }
    *piVar4 = *puVar14;
    *(int **)*piVar2 = piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  }
  return;
}



/* FUNCTION 24519 ; VA 0x00b62e70 ; FUN_00b62e70 */

undefined4 * __thiscall FUN_00b62e70(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f516a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a650("TerrainRegion");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::TerrainRegion,class_RBX::Instance>::vftable;
  uVar1 = FUN_00b629b0();
  param_1[3] = uVar1;
  *param_1 = RBX::TerrainRegion::vftable;
  param_1[0x15] = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  param_1[0x16] = *param_3;
  *(undefined2 *)(param_1 + 0x17) = *(undefined2 *)(param_3 + 1);
  *(undefined4 *)((int)param_1 + 0x5e) = *(undefined4 *)((int)param_3 + 6);
  *(undefined2 *)((int)param_1 + 0x62) = *(undefined2 *)((int)param_3 + 10);
  iVar2 = FUN_01674e20(0x28);
  uStack_8._0_1_ = 3;
  if (iVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00a6dc70();
  }
  iVar2 = param_1[0x15];
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[0x15] = uVar1;
  if (iVar2 != 0) {
    FUN_00a6de50();
    FUN_01674ea0(iVar2,0x28);
    uVar1 = param_1[0x15];
  }
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00b631b0(uVar1,param_2,param_3,&uStack_20,0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24520 ; VA 0x00b62f70 ; FUN_00b62f70 */

void __fastcall FUN_00b62f70(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::TerrainRegion>::vftable;
  uVar1 = FUN_00b629b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24521 ; VA 0x00b62fb0 ; FUN_00b62fb0 */

void __fastcall FUN_00b62fb0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00a6de50();
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 24522 ; VA 0x00b62fd0 ; FUN_00b62fd0 */

undefined4 * __thiscall FUN_00b62fd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 24523 ; VA 0x00b63000 ; FUN_00b63000 */

undefined4 * __thiscall FUN_00b63000(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3int16>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 24524 ; VA 0x00b63030 ; FUN_00b63030 */

undefined4 * __thiscall FUN_00b63030(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 24525 ; VA 0x00b63060 ; FUN_00b63060 */

undefined4 * __thiscall FUN_00b63060(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3int16>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24526 ; VA 0x00b63090 ; FUN_00b63090 */

undefined4 * __thiscall FUN_00b63090(undefined4 *param_1,byte param_2)

{
  int iVar1;
  
  *param_1 = RBX::TerrainRegion::vftable;
  iVar1 = param_1[0x15];
  if (iVar1 != 0) {
    FUN_00a6de50();
    FUN_01674ea0(iVar1,0x28);
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24527 ; VA 0x00b630e0 ; FUN_00b630e0 */

void FUN_00b630e0(void)

{
  undefined auStack_10 [12];
  
  FUN_00550130("TerrainRegion is already smooth!");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 24528 ; VA 0x00b63110 ; FUN_00b63110 */

void __thiscall FUN_00b63110(int param_1,undefined4 param_2,short *param_3,undefined4 param_4)

{
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined2 uStack_c;
  undefined4 uStack_a;
  undefined2 uStack_6;
  
  iStack_1c = (int)*param_3 - (int)*(short *)(param_1 + 0x58);
  iStack_18 = (int)param_3[1] - (int)*(short *)(param_1 + 0x5a);
  iStack_14 = (int)param_3[2] - (int)*(short *)(param_1 + 0x5c);
  uStack_10 = *(undefined4 *)(param_1 + 0x58);
  uStack_c = *(undefined2 *)(param_1 + 0x5c);
  uStack_a = *(undefined4 *)(param_1 + 0x5e);
  uStack_6 = *(undefined2 *)(param_1 + 0x62);
  FUN_00b631b0(param_2,*(undefined4 *)(param_1 + 0x54),&uStack_10,&iStack_1c,param_4);
  return;
}



/* FUNCTION 24529 ; VA 0x00b63180 ; FUN_00b63180 */

void __thiscall FUN_00b63180(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_a [6];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_a,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_a);
  return;
}



/* FUNCTION 24530 ; VA 0x00b631b0 ; FUN_00b631b0 */

void FUN_00b631b0(int param_1,undefined4 param_2,short *param_3,int *param_4,char param_5)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  char *pcVar9;
  int *piVar10;
  int iVar11;
  int iVar12;
  undefined auStack_c8 [24];
  undefined auStack_b0 [12];
  undefined auStack_a4 [12];
  undefined auStack_98 [20];
  int *piStack_84;
  undefined8 uStack_80;
  int iStack_78;
  undefined8 uStack_74;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int *piStack_5c;
  int *piStack_58;
  int iStack_50;
  int iStack_4c;
  int aiStack_44 [3];
  int *piStack_38;
  int iStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5243;
  pvStack_10 = ExceptionList;
  iStack_50 = param_3[3] + 1;
  iStack_6c = param_3[5] + 1;
  iStack_4c = param_3[4] + 1;
  piStack_5c = (int *)(int)*param_3;
  piStack_58 = (int *)(int)param_3[1];
  iStack_78 = (int)param_3[2];
  uStack_80 = CONCAT44(piStack_58,piStack_5c);
  uStack_74 = CONCAT44(iStack_4c,iStack_50);
  ExceptionList = &pvStack_10;
  FUN_00a70f70(&iStack_50,&uStack_80);
  iVar12 = iStack_4c;
  iVar5 = iStack_50;
  iStack_8 = 0;
  if ((param_5 != '\0') && (*(int *)(param_1 + 8) != 0)) {
    uStack_2c = (int *)((uint)uStack_2c & 0xffffff00);
    uVar8 = (iStack_4c - iStack_50) / 0x18 + 1;
    if (uVar8 < 0xb) {
      uVar8 = 0xb;
    }
    iStack_28 = FUN_00588320(uVar8);
    iStack_24 = 0;
    iStack_20 = 0x3f800000;
    iStack_1c = 0;
    piStack_18 = (int *)0x0;
    if (iVar5 != iVar12) {
      piStack_38 = &iStack_28;
      iStack_34 = 0;
      piStack_30 = (int *)((uint)piStack_30 & 0xffff0000);
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      FUN_00b62c90(&piStack_38,iVar5,iVar5,iVar12);
      while (iVar5 = iVar5 + 0x18, iVar5 != iVar12) {
        FUN_00b62c90(&piStack_38,iVar5,iVar5,iVar12);
      }
      if (iStack_34 != 0) {
        FUN_01674ea0(iStack_34,0x20);
      }
    }
    piVar6 = param_4;
    iStack_8._0_1_ = 3;
    uVar3 = FUN_00a716f0(auStack_c8,param_4);
    FUN_00a70f70(&piStack_5c,uVar3);
    iStack_8._0_1_ = 4;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 4;
    piStack_14 = piStack_58;
    if (piStack_5c != piStack_58) {
      piVar10 = piStack_5c + 2;
      do {
        iStack_34 = -piVar6[1];
        piStack_30 = (int *)-piVar6[2];
        piStack_38 = (int *)-*piVar6;
        FUN_00a716f0(auStack_b0,&piStack_38);
        uVar4 = (uint)uStack_2c & 0xff;
        iVar5 = FUN_00a6ce70(auStack_b0);
        uVar8 = iVar5 + 0x9e3779b9;
        iVar5 = FUN_00a6ce70(auStack_a4);
        FUN_00b62be0(&param_3,(uVar8 >> 2) + uVar8 * 0x40 + iVar5 + -0x61c88647 ^ uVar8,auStack_b0,
                     -(uint)((int)&uStack_2c + uVar4 + 1 != 0) & (int)&uStack_2c + uVar4 + 2);
        if (param_3 == (short *)0x0) {
          FUN_00a6dbd0(piVar10[1] - piVar10[-2],piVar10[2] - piVar10[-1],piVar10[3] - *piVar10);
          iStack_8._0_1_ = 5;
          FUN_00a72960(piVar10 + -2,auStack_98,0);
          piVar6 = piStack_84;
          iStack_8._0_1_ = 4;
          if (piStack_84 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_84[1] + -1;
            piStack_84[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_84)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        piVar1 = piVar10 + 4;
        piVar10 = piVar10 + 6;
        piVar6 = param_4;
        uVar2 = (undefined)iStack_8;
      } while (piVar1 != piStack_14);
    }
    iStack_8._0_1_ = uVar2;
    FUN_00612d60();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_006f8c50();
  }
  param_3 = (short *)iStack_50;
  iStack_68 = iStack_4c;
  iVar5 = iStack_50;
  if (iStack_50 != iStack_4c) {
    do {
      param_3 = (short *)iVar5;
      FUN_00a716f0(auStack_98,param_4);
      FUN_00a71760(aiStack_44,iVar5,0,1);
      iStack_8._0_1_ = 6;
      if ((param_5 == '\0') && (*(int *)(param_1 + 8) != 0)) {
        FUN_00a71760(&uStack_2c,auStack_98,0,1);
        iStack_8._0_1_ = 7;
        if (iStack_1c != 0) {
          iVar11 = 0;
          piStack_14 = uStack_2c;
          iStack_64 = iStack_28;
          iStack_60 = iStack_24;
          iVar12 = iStack_24;
          iVar7 = iStack_28;
          iVar5 = (int)param_3;
          if (0 < iStack_28) {
            do {
              iVar5 = 0;
              if (0 < iVar12) {
                do {
                  if (iStack_34 == 0) {
                    FUN_00a6e270();
                  }
                  pcVar9 = (char *)(iStack_34 +
                                   (aiStack_44[0] * iVar5 + (int)piStack_38 * iVar11) * 2);
                  if (0 < (int)piStack_14) {
                    iVar12 = (iStack_1c + (iStack_20 * iVar11 + (int)uStack_2c * iVar5) * 2) -
                             (int)pcVar9;
                    piVar6 = piStack_14;
                    do {
                      if (*pcVar9 == '\0') {
                        *(undefined2 *)pcVar9 = *(undefined2 *)(pcVar9 + iVar12);
                      }
                      pcVar9 = pcVar9 + 2;
                      piVar6 = (int *)((int)piVar6 + -1);
                    } while (piVar6 != (int *)0x0);
                  }
                  iVar5 = iVar5 + 1;
                  iVar12 = iStack_60;
                  iVar7 = iStack_64;
                } while (iVar5 < iStack_60);
              }
              iVar11 = iVar11 + 1;
              iVar5 = (int)param_3;
            } while (iVar11 < iVar7);
          }
        }
        piVar6 = piStack_18;
        iStack_8._0_1_ = 6;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar12 = piStack_18[1] + -1;
          piStack_18[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar10 = piVar6 + 2;
            iVar12 = *piVar10 + -1;
            *piVar10 = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
      FUN_00a72960(auStack_98,aiStack_44,0);
      piVar6 = piStack_30;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_30[1] + -1;
        piStack_30[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)*piStack_30)();
          LOCK();
          piVar10 = piVar6 + 2;
          iVar12 = *piVar10 + -1;
          *piVar10 = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      iVar5 = iVar5 + 0x18;
      param_3 = (short *)iVar5;
    } while (iVar5 != iStack_68);
  }
  FUN_00612d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24531 ; VA 0x00b63600 ; FUN_00b63600 */

undefined4 * FUN_00b63600(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b62ab0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24532 ; VA 0x00b63670 ; FUN_00b63670 */

undefined __fastcall FUN_00b63670(int param_1)

{
  uint *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined uVar7;
  bool bVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbVar2 = (byte *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  pbVar3 = (byte *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = (uint *)(pbVar3 + 0x10);
  if (0xf < *(uint *)(pbVar3 + 0x14)) {
    pbVar3 = *(byte **)pbVar3;
  }
  uVar4 = *(uint *)(pbVar2 + 0x10);
  if (0xf < *(uint *)(pbVar2 + 0x14)) {
    pbVar2 = *(byte **)pbVar2;
  }
  if (uVar4 == *puVar1) {
    while (uVar6 = uVar4 - 4, 3 < uVar4) {
      if (*(int *)pbVar2 != *(int *)pbVar3) goto LAB_00b636ee;
      pbVar2 = pbVar2 + 4;
      pbVar3 = pbVar3 + 4;
      uVar4 = uVar6;
    }
    if (uVar6 == 0xfffffffc) {
LAB_00b63722:
      uVar4 = 0;
    }
    else {
LAB_00b636ee:
      bVar8 = *pbVar2 < *pbVar3;
      if ((*pbVar2 == *pbVar3) &&
         ((uVar6 == 0xfffffffd ||
          ((bVar8 = pbVar2[1] < pbVar3[1], pbVar2[1] == pbVar3[1] &&
           ((uVar6 == 0xfffffffe ||
            ((bVar8 = pbVar2[2] < pbVar3[2], pbVar2[2] == pbVar3[2] &&
             ((uVar6 == 0xffffffff || (bVar8 = pbVar2[3] < pbVar3[3], pbVar2[3] == pbVar3[3]))))))))
          )))) goto LAB_00b63722;
      uVar4 = -(uint)bVar8 | 1;
    }
    if (uVar4 == 0) {
      uVar7 = 1;
      goto LAB_00b6372e;
    }
  }
  uVar7 = 0;
LAB_00b6372e:
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 24533 ; VA 0x00b637c0 ; FUN_00b637c0 */

undefined4 __fastcall FUN_00b637c0(int param_1)

{
  short *psVar1;
  short *psVar2;
  undefined auStack_10 [6];
  undefined auStack_a [6];
  
  psVar1 = (short *)(**(code **)(param_1 + 8))(auStack_a);
  psVar2 = (short *)(**(code **)(param_1 + 8))(auStack_10);
  if (((*psVar1 == *psVar2) && (psVar1[1] == psVar2[1])) && (psVar1[2] == psVar2[2])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 24534 ; VA 0x00b63820 ; FUN_00b63820 */

void FUN_00b63820(void)

{
  int iVar1;
  
  if (DAT_01ef02dc == 0) {
    iVar1 = FUN_00b629b0();
    DAT_01ef02dc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24535 ; VA 0x00b63840 ; FUN_00b63840 */

void __thiscall FUN_00b63840(int param_1,undefined4 *param_2)

{
  undefined2 uVar1;
  
  uVar1 = *(undefined2 *)(param_1 + 0x62);
  *param_2 = *(undefined4 *)(param_1 + 0x5e);
  *(undefined2 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 24536 ; VA 0x00b63860 ; FUN_00b63860 */

void __thiscall FUN_00b63860(int param_1,undefined4 *param_2)

{
  undefined2 uVar1;
  
  uVar1 = *(undefined2 *)(param_1 + 0x5c);
  *param_2 = *(undefined4 *)(param_1 + 0x58);
  *(undefined2 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 24537 ; VA 0x00b63880 ; FUN_00b63880 */

undefined4 * FUN_00b63880(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a72130(auStack_28);
  FUN_0054ef60(auStack_28);
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = uStack_40;
  param_1[1] = uStack_3c;
  param_1[2] = uStack_38;
  param_1[3] = uStack_34;
  *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_2c,uStack_30);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24538 ; VA 0x00b63950 ; FUN_00b63950 */

float * __thiscall FUN_00b63950(int param_1,float *param_2)

{
  short sVar1;
  short sVar2;
  short sVar3;
  short sVar4;
  
  sVar1 = *(short *)(param_1 + 0x60);
  sVar2 = *(short *)(param_1 + 0x5a);
  sVar3 = *(short *)(param_1 + 0x62);
  *param_2 = (float)(((int)*(short *)(param_1 + 0x5e) - (int)*(short *)(param_1 + 0x58)) + 1);
  sVar4 = *(short *)(param_1 + 0x5c);
  param_2[1] = (float)(((int)sVar1 - (int)sVar2) + 1);
  param_2[2] = (float)(((int)sVar3 - (int)sVar4) + 1);
  return param_2;
}



/* FUNCTION 24539 ; VA 0x00b639b0 ; FUN_00b639b0 */

undefined4 * __thiscall FUN_00b639b0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined auStack_a [6];
  
  puVar1 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_a);
  *param_2 = *puVar1;
  *(undefined2 *)(param_2 + 1) = *(undefined2 *)(puVar1 + 1);
  return param_2;
}



/* FUNCTION 24540 ; VA 0x00b639e0 ; FUN_00b639e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b639e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_a [6];
  
  puVar3 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_a,param_2);
  uVar4 = FUN_0088d910();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead3e8) {
    FUN_016f3809(&DAT_01ead3e8);
    if (DAT_01ead3e8 == -1) {
      _DAT_01ead3dc = FUN_0061a030;
      _DAT_01ead3e0 = FUN_0061a030;
      DAT_01ead3e4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3e8);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ead3dc) {
    param_3[2] = *puVar3;
    *(undefined2 *)(param_3 + 3) = *(undefined2 *)(puVar3 + 1);
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  param_3[2] = *puVar3;
  *(undefined2 *)(param_3 + 3) = *(undefined2 *)(puVar3 + 1);
  param_3[1] = &DAT_01ead3dc;
  return;
}



/* FUNCTION 24541 ; VA 0x00b63ac0 ; FUN_00b63ac0 */

uint FUN_00b63ac0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b629b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24542 ; VA 0x00b63ae0 ; FUN_00b63ae0 */

uint FUN_00b63ae0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b629b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24543 ; VA 0x00b63b10 ; FUN_00b63b10 */

void __thiscall FUN_00b63b10(int param_1,short *param_2)

{
  if (((*(short *)(param_1 + 0x5e) == *param_2) && (*(short *)(param_1 + 0x60) == param_2[1])) &&
     (*(short *)(param_1 + 0x62) == param_2[2])) {
    return;
  }
  *(undefined4 *)(param_1 + 0x5e) = *(undefined4 *)param_2;
  *(short *)(param_1 + 0x62) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 24544 ; VA 0x00b63b60 ; FUN_00b63b60 */

void __thiscall FUN_00b63b60(int param_1,short *param_2)

{
  if (((*(short *)(param_1 + 0x58) == *param_2) && (*(short *)(param_1 + 0x5a) == param_2[1])) &&
     (*(short *)(param_1 + 0x5c) == param_2[2])) {
    return;
  }
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)param_2;
  *(short *)(param_1 + 0x5c) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 24545 ; VA 0x00b63bb0 ; FUN_00b63bb0 */

void __thiscall FUN_00b63bb0(int param_1,int param_2)

{
  if (*(int *)(param_2 + 0x10) != 0) {
    FUN_00ff1ae0(*(undefined4 *)(param_1 + 0x54),param_2);
  }
  return;
}



/* FUNCTION 24546 ; VA 0x00b63bd0 ; FUN_00b63bd0 */

void FUN_00b63bd0(int param_1)

{
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00a6f260();
    return;
  }
  return;
}



/* FUNCTION 24547 ; VA 0x00b63bf0 ; FUN_00b63bf0 */

void __thiscall FUN_00b63bf0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 8))(param_3);
  return;
}



/* FUNCTION 24548 ; VA 0x00b63c10 ; FUN_00b63c10 */

void __thiscall FUN_00b63c10(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined auStack_e4 [200];
  code *pcStack_1c;
  int iStack_16;
  undefined2 uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5bb;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_1c = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d910();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d910();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_16 = *piVar4;
    uStack_12 = *(undefined2 *)(piVar4 + 1);
  }
  else {
    puVar3 = (undefined4 *)param_3[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(param_3 + 2,auStack_e4);
      puVar3 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar4 = (int *)FUN_0088b990();
    iStack_16 = *piVar4;
    uStack_12 = *(undefined2 *)(piVar4 + 1);
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_1c)(param_2,&iStack_16);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24549 ; VA 0x00b63d20 ; FUN_00b63d20 */

int * __thiscall
FUN_00b63d20(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f35eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b63e30();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_const&_(__thiscall_RBX::ModelInstance::*)(void)const_,void_(__thiscall_RBX::ModelInstance::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::ModelInstance,class_G3D::CoordinateFrame>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::ModelInstance,class_G3D::CoordinateFrame>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24550 ; VA 0x00b63e30 ; FUN_00b63e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b63e30(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5270;
  pvStack_10 = ExceptionList;
  if (DAT_01ef031c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0530) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef0530);
      if (DAT_01ef0530 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e70350();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Model",0,uStack_20,0,0,0x1b,0,&DAT_01ef02e8);
        _DAT_01ef0528 = RBX::Creator<class_RBX::ModelInstance>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef0320,&DAT_01ef0528);
        FUN_016f3654(FUN_0188e8a0);
        FUN_016f37bf(&DAT_01ef0530);
      }
    }
    DAT_01ef031c = &DAT_01ef0320;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef031c;
}



/* FUNCTION 24551 ; VA 0x00b63f30 ; FUN_00b63f30 */

void FUN_00b63f30(void)

{
  int iVar1;
  
  if (DAT_01ef0534 == 0) {
    iVar1 = FUN_00b63e30();
    DAT_01ef0534 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24552 ; VA 0x00b63f50 ; FUN_00b63f50 */

void FUN_00b63f50(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5288;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00b64033:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00b63ffe;
      }
      else {
LAB_00b63ffe:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018c5f98,"ModelLoD","ModelEnabled",0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00b64033;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00b64033;
      if (iStack_60 != 0) goto LAB_00b640ad;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00b640ad:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 24553 ; VA 0x00b640bd ; Catch_All@00b640bd */

void Catch_All_00b640bd(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24554 ; VA 0x00b640e0 ; FUN_00b640e0 */

void * __thiscall FUN_00b640e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 uVar6;
  void *pvVar7;
  int *piVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar9 = *(undefined4 **)(param_1 + 0x2c);
  pvVar7 = ExceptionList;
  if (puVar9 != (undefined4 *)0x0) {
    piVar8 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(param_1 + 0x30);
      puVar9 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar9[1];
    puVar9 = (undefined4 *)*puVar9;
    uStack_8 = 0;
    pvVar7 = pvStack_10;
    for (; puVar9 != puVar3; puVar9 = puVar9 + 2) {
      uVar4 = param_2[2];
      pcVar5 = (code *)*param_2;
      uVar6 = param_2[1];
      if (puVar9[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar9[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar5)(*puVar9,puVar9[1],uVar6,uVar4);
      pvVar7 = (void *)FUN_00b640e0(param_2);
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar1 = piVar8 + 1;
      iVar2 = *piVar1;
      pvVar7 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar7 = (void *)(**(code **)*piVar8)();
        LOCK();
        piVar1 = piVar8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar7 = (void *)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 24555 ; VA 0x00b641c0 ; FUN_00b641c0 */

void * __thiscall FUN_00b641c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  void *pvVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar11 = *(undefined4 **)(param_1 + 0x2c);
  pvVar9 = ExceptionList;
  if (puVar11 != (undefined4 *)0x0) {
    piVar10 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar10 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
      piVar10 = *(int **)(param_1 + 0x30);
      puVar11 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar11[1];
    puVar11 = (undefined4 *)*puVar11;
    uStack_8 = 0;
    pvVar9 = pvStack_10;
    for (; puVar11 != puVar3; puVar11 = puVar11 + 2) {
      uVar4 = param_2[4];
      pcVar5 = (code *)*param_2;
      uVar6 = param_2[3];
      uVar7 = param_2[2];
      uVar8 = param_2[1];
      if (puVar11[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar11[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar5)(*puVar11,puVar11[1],uVar8,uVar7,uVar6,uVar4);
      pvVar9 = (void *)FUN_00b641c0(param_2);
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar1 = piVar10 + 1;
      iVar2 = *piVar1;
      pvVar9 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar9 = (void *)(**(code **)*piVar10)();
        LOCK();
        piVar1 = piVar10 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar9 = (void *)(**(code **)(*piVar10 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar9;
}



/* FUNCTION 24556 ; VA 0x00b642b0 ; FUN_00b642b0 */

undefined4 * __thiscall
FUN_00b642b0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f52eb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00b63e30();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(class_G3D::Vector3),1>::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined8 *)param_1[0x11];
  if (puVar1 == (undefined8 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088d870();
    iStack_e4 = 0;
    uStack_e0 = *puVar1;
    uStack_d8 = *(undefined4 *)(puVar1 + 1);
    iStack_e4 = FUN_006315b0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088d870();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24557 ; VA 0x00b64440 ; FUN_00b64440 */

undefined4 *
FUN_00b64440(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_1c = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb970(uVar1,param_3,param_4,uStack_1c,param_6);
  puStack_14[0xe] = param_1;
  puStack_14[0xf] = param_2;
  *puStack_14 = RBX::Reflection::
                EventDesc<class_RBX::ModelInstance,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::ModelInstance::*>
                ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  if (puStack_14 + 10 != &uStack_20) {
    FUN_0068a760();
    puStack_14[10] = 0;
    puStack_14[0xb] = 0;
    puStack_14[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  puStack_14[0x10] = param_8;
  puStack_14[0x11] = param_7;
  *puStack_14 = RBX::Reflection::
                RemoteEventDesc<class_RBX::ModelInstance,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::ModelInstance::*>
                ::vftable;
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 24558 ; VA 0x00b64520 ; FUN_00b64520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b64520(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5385;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_01955d40;
    param_1[0x1e] = &DAT_01955d48;
    param_1[0x52] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  FUN_00e70430("Model",0);
  *param_1 = RBX::DescribedCreatable<class_RBX::ModelInstance,class_RBX::PVInstance>::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::DescribedCreatable<class_RBX::ModelInstance,class_RBX::PVInstance>::vftable;
  uVar1 = FUN_00b63e30();
  param_1[3] = uVar1;
  param_1[0x16] = RBX::IAdornable::vftable;
  param_1[0x17] = 0xffffffff;
  param_1[0x18] = 0xffffffff;
  param_1[0x19] = 0xffffffff;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1e] + 4) + 0x78 + (int)param_1) = RBX::CameraSubject::vftable;
  LOCK();
  _DAT_01ef0310 = _DAT_01ef0310 + 1;
  UNLOCK();
  *param_1 = RBX::ModelInstance::vftable;
  param_1[0x16] = RBX::ModelInstance::vftable;
  param_1[0x1d] = RBX::ModelInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::ModelInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xf4;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0x3f800000;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0x3f800000;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0x3f800000;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0x7f7fffff;
  param_1[0x34] = 0x7f7fffff;
  param_1[0x35] = 0x7f7fffff;
  param_1[0x36] = 0xff7fffff;
  param_1[0x37] = 0xff7fffff;
  param_1[0x38] = 0xff7fffff;
  param_1[0x39] = 0x3f800000;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0x3f800000;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0x3f800000;
  uStack_8 = 9;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  FUN_00a33c70();
  param_1[0x49] = 0;
  *(undefined2 *)(param_1 + 0x4a) = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  *(undefined *)(param_1 + 0x50) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24559 ; VA 0x00b64830 ; FUN_00b64830 */

undefined4 * __thiscall
FUN_00b64830(undefined4 *param_1,undefined4 param_2,undefined8 *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  *param_1 = param_2;
  *(undefined8 *)(param_1 + 1) = *param_3;
  param_1[3] = *(undefined4 *)(param_3 + 1);
  param_1[4] = param_4;
  param_1[5] = param_5;
  param_1[6] = param_6;
  param_1[7] = param_7;
  param_1[0xd] = 0;
  param_1[0xc] = 0;
  param_1[0xb] = 0;
  param_1[10] = 0;
  param_1[9] = 0;
  param_1[8] = 0;
  uVar1 = param_8[1];
  uVar2 = param_8[2];
  uVar3 = param_8[3];
  param_1[0xe] = *param_8;
  param_1[0xf] = uVar1;
  param_1[0x10] = uVar2;
  param_1[0x11] = uVar3;
  uVar1 = param_8[5];
  uVar2 = param_8[6];
  uVar3 = param_8[7];
  param_1[0x12] = param_8[4];
  param_1[0x13] = uVar1;
  param_1[0x14] = uVar2;
  param_1[0x15] = uVar3;
  uVar1 = param_8[9];
  uVar2 = param_8[10];
  uVar3 = param_8[0xb];
  param_1[0x16] = param_8[8];
  param_1[0x17] = uVar1;
  param_1[0x18] = uVar2;
  param_1[0x19] = uVar3;
  return param_1;
}



/* FUNCTION 24560 ; VA 0x00b648a0 ; FUN_00b648a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b648a0(void)

{
  LOCK();
  _DAT_01ef0310 = _DAT_01ef0310 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 24561 ; VA 0x00b648b0 ; FUN_00b648b0 */

void __fastcall FUN_00b648b0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ModelInstance>::vftable;
  uVar1 = FUN_00b63e30(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24562 ; VA 0x00b648f0 ; FUN_00b648f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00b648f0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  *param_1 = RBX::ModelInstance::vftable;
  param_1[0x16] = RBX::ModelInstance::vftable;
  param_1[0x1d] = RBX::ModelInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::ModelInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xf4;
  piVar2 = (int *)param_1[0x4f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_1[0x4b];
  if (iVar3 != 0) {
    uVar5 = param_1[0x4d] - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x4b] = 0;
    param_1[0x4c] = 0;
    param_1[0x4d] = 0;
  }
  FUN_0056cd30();
  piVar2 = (int *)param_1[0x26];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  LOCK();
  _DAT_01ef0310 = _DAT_01ef0310 + -1;
  UNLOCK();
  param_1[0x1d] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x1e] + 4) + 0x78 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_00e704a0();
  return;
}



/* FUNCTION 24563 ; VA 0x00b64a40 ; FUN_00b64a40 */

int __thiscall FUN_00b64a40(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x30);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 24564 ; VA 0x00b64a80 ; FUN_00b64a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b64a80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ModelLevelOfDetail>::vftable;
  _DAT_01ef0538 = _DAT_01ef0538 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24565 ; VA 0x00b64ab0 ; FUN_00b64ab0 */

undefined4 * __thiscall FUN_00b64ab0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::ModelLevelOfDetail>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24566 ; VA 0x00b64ae0 ; FUN_00b64ae0 */

undefined4 * __thiscall FUN_00b64ae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::ModelLevelOfDetail>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24567 ; VA 0x00b64b10 ; FUN_00b64b10 */

void * FUN_00b64b10(int *param_1,int *param_2,float *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      puVar5 = (undefined4 *)FUN_00b077e0();
      uStack_40 = *puVar5;
      uStack_3c = puVar5[1];
      uStack_38 = puVar5[2];
      uStack_34 = puVar5[3];
      uStack_30 = puVar5[4];
      uStack_2c = puVar5[5];
      uStack_28 = puVar5[6];
      uStack_24 = puVar5[7];
      uStack_20 = puVar5[8];
      fStack_1c = *param_3 + (float)puVar5[9];
      fStack_18 = param_3[1] + (float)puVar5[10];
      fStack_14 = param_3[2] + (float)puVar5[0xb];
      pvVar4 = (void *)(**(code **)(*param_1 + 0x108))(&uStack_40);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24568 ; VA 0x00b64c00 ; FUN_00b64c00 */

void * __thiscall FUN_00b64c00(code *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  pcStack_14 = param_1;
  if (param_2 != (int *)0x0) {
    iVar2 = param_2[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      if (param_2 != (int *)0x0) {
        iVar2 = param_2[3];
        iVar3 = FUN_00b63e30();
        pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
        if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4)
        {
          pcStack_14 = FUN_00b64c00;
          pvVar4 = (void *)FUN_008ad320(&pcStack_14);
        }
      }
    }
    else {
      pvVar4 = (void *)(**(code **)(*param_2 + 0x134))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24569 ; VA 0x00b64cd0 ; FUN_00b64cd0 */

void FUN_00b64cd0(void)

{
  code *pcStack_8;
  
  pcStack_8 = FUN_00b64c00;
  FUN_008ad320(&pcStack_8);
  return;
}



/* FUNCTION 24570 ; VA 0x00b64cf0 ; FUN_00b64cf0 */

float * __thiscall FUN_00b64cf0(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined auStack_10 [12];
  
  FUN_00b64df0(auStack_10);
  (*(code *)**(undefined4 **)(param_1 + 0x54 + *(int *)(*(int *)(param_1 + 0x54) + 4)))(param_2);
  fVar3 = (*(float *)(param_1 + 0xd8) + *(float *)(param_1 + 0xcc)) * DAT_018ce2f4;
  fVar2 = (*(float *)(param_1 + 0xd0) + *(float *)(param_1 + 0xdc)) * DAT_018ce2f4;
  fVar1 = (*(float *)(param_1 + 0xd4) + *(float *)(param_1 + 0xe0)) * DAT_018ce2f4;
  *(ulonglong *)(param_2 + 9) =
       CONCAT44(param_2[3] * fVar3 + param_2[4] * fVar2 + param_2[5] * fVar1 + param_2[10],
                param_2[1] * fVar2 + fVar3 * *param_2 + param_2[2] * fVar1 + param_2[9]);
  param_2[0xb] = param_2[6] * fVar3 + param_2[7] * fVar2 + param_2[8] * fVar1 + param_2[0xb];
  return param_2;
}



/* FUNCTION 24571 ; VA 0x00b64df0 ; FUN_00b64df0 */

void __thiscall FUN_00b64df0(int param_1,float *param_2)

{
  undefined4 *puVar1;
  undefined auStack_58 [48];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  code *pcStack_10;
  undefined4 *puStack_c;
  undefined *puStack_8;
  
  if (*(char *)(param_1 + 0x129) == '\0') {
    (*(code *)**(undefined4 **)(param_1 + 0x54 + *(int *)(*(int *)(param_1 + 0x54) + 4)))
              (auStack_58);
    puVar1 = (undefined4 *)FUN_006e0af0();
    puStack_8 = auStack_58;
    pcStack_10 = FUN_00b67320;
    uStack_28 = *puVar1;
    uStack_24 = puVar1[1];
    uStack_20 = puVar1[2];
    uStack_1c = puVar1[3];
    uStack_18 = *(undefined8 *)(puVar1 + 4);
    puStack_c = &uStack_28;
    FUN_00b640e0(&pcStack_10);
    *(undefined *)(param_1 + 0x129) = 1;
    *(undefined4 *)(param_1 + 0xcc) = uStack_28;
    *(undefined4 *)(param_1 + 0xd0) = uStack_24;
    *(undefined4 *)(param_1 + 0xd4) = uStack_20;
    *(undefined4 *)(param_1 + 0xd8) = uStack_1c;
    *(undefined8 *)(param_1 + 0xdc) = uStack_18;
  }
  *param_2 = *(float *)(param_1 + 0xd8) - *(float *)(param_1 + 0xcc);
  param_2[1] = *(float *)(param_1 + 0xdc) - *(float *)(param_1 + 0xd0);
  param_2[2] = *(float *)(param_1 + 0xe0) - *(float *)(param_1 + 0xd4);
  return;
}



/* FUNCTION 24572 ; VA 0x00b64eb0 ; FUN_00b64eb0 */

void __fastcall FUN_00b64eb0(int param_1)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  
  if (*(int *)(param_1 + 0x124) == 1) {
    iVar4 = FUN_008f7870(param_1);
    if ((iVar4 != 0) && (*(char *)(iVar4 + 0x1de) != '\0')) {
      iVar4 = *(int *)(iVar4 + 0x4a0);
      cVar3 = FUN_00983210(param_1);
      if ((cVar3 == '\0') || (iVar4 != 2)) {
        bVar1 = false;
      }
      else {
        bVar1 = true;
      }
      if ((cVar3 == '\0') && (iVar4 == 3)) {
        bVar2 = true;
      }
      else {
        bVar2 = false;
      }
      if ((bVar1) || (bVar2)) {
        piVar5 = (int *)FUN_00a33c70();
        iVar4 = *piVar5;
        LOCK();
        piVar5 = (int *)(iVar4 + 0x28);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
        *(int *)(param_1 + 0x120) = iVar4;
        FUN_0056cd30();
        FUN_0056cd30();
        FUN_005e6780(param_1);
      }
    }
  }
  return;
}



/* FUNCTION 24573 ; VA 0x00b64f60 ; FUN_00b64f60 */

float * FUN_00b64f60(float *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *pfVar4;
  code *pcStack_c;
  float *pfStack_8;
  
  pfVar4 = (float *)FUN_00732f90();
  pcStack_c = FUN_00b674d0;
  pfStack_8 = param_1;
  fVar1 = pfVar4[1];
  fVar2 = pfVar4[2];
  fVar3 = pfVar4[3];
  *param_1 = *pfVar4;
  param_1[1] = fVar1;
  param_1[2] = fVar2;
  param_1[3] = fVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(pfVar4 + 4);
  FUN_00917910(&pcStack_c);
  pfVar4 = (float *)FUN_00732f90();
  if (((((NAN(*param_1) || NAN(*pfVar4)) != (*param_1 == *pfVar4)) &&
       ((NAN(param_1[1]) || NAN(pfVar4[1])) != (param_1[1] == pfVar4[1]))) &&
      ((NAN(param_1[2]) || NAN(pfVar4[2])) != (param_1[2] == pfVar4[2]))) &&
     ((((NAN(param_1[3]) || NAN(pfVar4[3])) != (param_1[3] == pfVar4[3]) &&
       ((NAN(param_1[4]) || NAN(pfVar4[4])) != (param_1[4] == pfVar4[4]))) &&
      ((NAN(param_1[5]) || NAN(pfVar4[5])) != (param_1[5] == pfVar4[5]))))) {
    pfVar4 = (float *)FUN_006e0af0();
    fVar1 = pfVar4[1];
    fVar2 = pfVar4[2];
    fVar3 = pfVar4[3];
    *param_1 = *pfVar4;
    param_1[1] = fVar1;
    param_1[2] = fVar2;
    param_1[3] = fVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(pfVar4 + 4);
  }
  return param_1;
}



/* FUNCTION 24574 ; VA 0x00b65020 ; FUN_00b65020 */

undefined4 __thiscall FUN_00b65020(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined auStack_40 [48];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  if ((piVar1 == (int *)0x0) || (piVar1[1] - *piVar1 >> 3 == 0)) {
    uVar2 = (*(code *)**(undefined4 **)(param_1 + 0x54 + *(int *)(*(int *)(param_1 + 0x54) + 4)))
                      (auStack_40);
    uStack_10 = 0;
    uStack_c = 0;
    uStack_8 = 0;
    puVar3 = (undefined4 *)FUN_0115ee70(uVar2);
    uVar5 = *puVar3;
    uVar6 = puVar3[1];
    uVar7 = puVar3[2];
    puVar3 = &uStack_10;
  }
  else {
    uVar2 = FUN_00b64cf0(auStack_40);
    puVar3 = (undefined4 *)FUN_00b64df0(&uStack_10);
    puVar4 = (undefined4 *)FUN_0115ee70(uVar2);
    uVar5 = *puVar4;
    uVar6 = puVar4[1];
    uVar7 = puVar4[2];
  }
  FUN_00b64830(1,puVar3,uVar5,uVar6,uVar7,0x3f800000,uVar2);
  return param_2;
}



/* FUNCTION 24575 ; VA 0x00b650e0 ; FUN_00b650e0 */

undefined4 * __thiscall
FUN_00b650e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8241;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00923110;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24576 ; VA 0x00b652a0 ; FUN_00b652a0 */

void FUN_00b652a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b671d0();
    *param_2 = uVar3;
    iVar4 = FUN_00b67280();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24577 ; VA 0x00b65300 ; FUN_00b65300 */

void FUN_00b65300(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b671d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24578 ; VA 0x00b65340 ; FUN_00b65340 */

undefined4 * FUN_00b65340(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00942ec0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24579 ; VA 0x00b653b0 ; FUN_00b653b0 */

void __thiscall FUN_00b653b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined auStack_2c [12];
  undefined8 uStack_20;
  
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  uVar1 = (*(code *)uStack_20)(auStack_2c);
  FUN_009d5a70(param_3,uVar1);
  return;
}



/* FUNCTION 24580 ; VA 0x00b65410 ; FUN_00b65410 */

undefined4 FUN_00b65410(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uStack_128;
  int iStack_124;
  undefined auStack_120 [200];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f560b;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300(param_2);
  if (iVar4 - param_3 < 1) {
LAB_00b65546:
    puVar5 = *(undefined4 **)(iStack_24 + 0x44);
    if (puVar5 == (undefined4 *)0x0) {
      FUN_016756b0(&uStack_44,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(&uStack_44,&DAT_01c17198);
    }
  }
  else {
    FUN_0060efa0();
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + 1,DAT_01ede6d4);
    if (puVar5 == (undefined4 *)0x0) {
      if (0 < iVar4 - param_3) {
        uStack_128 = FUN_00888530();
        iStack_124 = 0;
        uStack_14 = 0;
        cVar3 = FUN_009d1bf0(param_2,param_3 + 1,&uStack_128,1);
        if (cVar3 != '\0') {
          puVar5 = (undefined4 *)FUN_0088ab30();
          uStack_48 = *puVar5;
          uStack_44 = puVar5[1];
          uStack_40 = puVar5[2];
          uStack_3c = puVar5[3];
          uStack_38._0_4_ = (code *)puVar5[4];
          uStack_38._4_4_ = puVar5[5];
          uStack_30 = puVar5[6];
          uStack_2c = puVar5[7];
          uStack_58 = puVar5[8];
          uStack_54 = puVar5[9];
          uStack_50 = puVar5[10];
          uStack_4c = puVar5[0xb];
          uStack_14 = 1;
          if (iStack_124 != 0) {
            (**(code **)(iStack_124 + 8))(auStack_120);
          }
          uStack_14 = 0xffffffff;
          uVar6 = uStack_48;
          uVar7 = uStack_44;
          uVar8 = uStack_40;
          uVar9 = uStack_3c;
          uVar10 = (code *)uStack_38;
          uVar11 = uStack_30;
          uVar12 = uStack_2c;
          uVar13 = uStack_58;
          uVar14 = uStack_54;
          uVar15 = uStack_50;
          uVar16 = uStack_4c;
          goto LAB_00b6555b;
        }
        uStack_14 = 2;
        if (iStack_124 != 0) {
          (**(code **)(iStack_124 + 8))(auStack_120);
        }
        uStack_14 = 0xffffffff;
      }
      goto LAB_00b65546;
    }
  }
  uVar13 = puVar5[8];
  uVar14 = puVar5[9];
  uVar15 = puVar5[10];
  uVar16 = puVar5[0xb];
  uVar10 = puVar5[4];
  uStack_38._4_4_ = puVar5[5];
  uVar11 = puVar5[6];
  uVar12 = puVar5[7];
  uVar6 = *puVar5;
  uVar7 = puVar5[1];
  uVar8 = puVar5[2];
  uVar9 = puVar5[3];
LAB_00b6555b:
  uStack_38._0_4_ = (code *)*(undefined8 *)(iStack_24 + 0x38);
  uVar1 = uStack_38._4_4_;
  pcVar2 = (code *)uStack_38;
  uStack_38 = *(undefined8 *)(iStack_24 + 0x38);
  (*pcVar2)(uVar6,uVar7,uVar8,uVar9,uVar10,uVar1,uVar11,uVar12,uVar13,uVar14,uVar15,uVar16);
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 24581 ; VA 0x00b655d0 ; FUN_00b655d0 */

void FUN_00b655d0(void)

{
  FUN_006eccd0();
  return;
}



/* FUNCTION 24582 ; VA 0x00b65600 ; FUN_00b65600 */

int FUN_00b65600(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((param_1 != 0) && (iVar8 = *(int *)(param_1 + 0x34), iVar8 != 0)) {
    while( true ) {
      iVar3 = *(int *)(iVar8 + 0xc);
      iVar2 = FUN_00b63e30();
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar7 = iVar8;
      }
      if (iVar7 != 0) break;
      iVar3 = *(int *)(iVar8 + 0xc);
      iVar2 = FUN_00d400b0();
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar7 = iVar8;
      }
      if (iVar7 != 0) {
        return 0;
      }
      iVar8 = *(int *)(iVar8 + 0x34);
      if (iVar8 == 0) {
        return 0;
      }
    }
    iVar8 = *(int *)(iVar7 + 0x34);
    iVar3 = iVar7;
    if ((iVar8 != 0) && (iVar3 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
      iVar3 = FUN_005c8ac0();
    }
    if ((iVar3 != 0) &&
       (iVar8 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
      uVar4 = FUN_00560f40();
      piVar5 = (int *)FUN_008aa140(uVar4);
      if (*piVar5 == 0) {
        uVar4 = FUN_008aa950();
        piVar6 = (int *)FUN_008a9ba0(auStack_c,uVar4);
        iVar8 = *piVar6;
        iVar3 = piVar6[1];
        *piVar6 = 0;
        piVar6[1] = 0;
        *piVar5 = iVar8;
        piVar6 = (int *)piVar5[1];
        piVar5[1] = iVar3;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar8 = piVar6[1] + -1;
          piVar6[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar8 = piVar6[2] + -1;
            piVar6[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_8[1] + -1;
          piStack_8[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar6 = piStack_8 + 2;
            iVar8 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      if ((*piVar5 != 0) && (cVar1 = FUN_00620ec0(*piVar5), cVar1 != '\0')) {
        return iVar7;
      }
    }
  }
  return 0;
}



/* FUNCTION 24583 ; VA 0x00b65790 ; FUN_00b65790 */

void FUN_00b65790(int *param_1)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  undefined auStack_128 [48];
  undefined auStack_f8 [12];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f563e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
  }
  puStack_1c = puVar1 + 3;
  uStack_8 = 0;
  puStack_18 = puVar1;
  puVar2 = (undefined8 *)FUN_00b64cf0(auStack_128);
  uStack_ec = FUN_00b00260();
  iStack_e8 = 0;
  uStack_e4 = *puVar2;
  uStack_dc = *(undefined4 *)(puVar2 + 1);
  uStack_d8 = *(undefined4 *)((int)puVar2 + 0xc);
  uStack_d4 = *(undefined4 *)(puVar2 + 2);
  uStack_d0 = *(undefined4 *)((int)puVar2 + 0x14);
  uStack_cc = *(undefined4 *)(puVar2 + 3);
  uStack_c8 = *(undefined4 *)((int)puVar2 + 0x1c);
  uStack_c4 = *(undefined4 *)(puVar2 + 4);
  uStack_c0 = *(undefined4 *)((int)puVar2 + 0x24);
  uStack_bc = *(undefined4 *)(puVar2 + 5);
  uStack_b8 = *(undefined4 *)((int)puVar2 + 0x2c);
  iStack_e8 = FUN_00630d60();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (puVar1[5] == puVar1[4]) {
    FUN_005ca4f0(puVar1[4],&uStack_ec);
  }
  else {
    FUN_005caaf0(puVar1 + 3);
    puVar1[4] = puVar1[4] + 0xd0;
  }
  uStack_8._0_1_ = 2;
  if (iStack_e8 != 0) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  uStack_8._0_1_ = 0;
  puVar2 = (undefined8 *)FUN_00b64df0(auStack_f8);
  uStack_ec = FUN_0088d870();
  iStack_e8 = 0;
  uStack_e4 = *puVar2;
  uStack_dc = *(undefined4 *)(puVar2 + 1);
  iStack_e8 = FUN_006315b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (puVar1[5] == puVar1[4]) {
    FUN_005ca4f0(puVar1[4],&uStack_ec);
  }
  else {
    FUN_005caaf0(puVar1 + 3);
    puVar1[4] = puVar1[4] + 0xd0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_e8 != 0) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  param_1[1] = (int)puVar1;
  *param_1 = (int)(puVar1 + 3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24584 ; VA 0x00b65960 ; FUN_00b65960 */

void __thiscall FUN_00b65960(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_00f28040(param_1 + -0x74,param_2);
  iVar1 = FUN_009ba880(param_1 + -0x74);
  if (iVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00b65987. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(int *)(iVar1 + 0x134) + 0xc))();
    return;
  }
  return;
}



/* FUNCTION 24585 ; VA 0x00b65990 ; FUN_00b65990 */

undefined4 __fastcall FUN_00b65990(int param_1)

{
  return *(undefined4 *)(param_1 + 0x138);
}



/* FUNCTION 24586 ; VA 0x00b659b0 ; FUN_00b659b0 */

undefined4 * __thiscall FUN_00b659b0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined auStack_48 [36];
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  (**(code **)(*(int *)(param_1 + -0x148) + 0xa8))();
  iStack_1c = param_1 + -0xb4;
  piVar7 = (int *)FUN_00587490(auStack_24);
  piVar1 = piStack_20;
  iStack_18 = *piVar7;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_20[1] + -1;
    piStack_20[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar7 = piVar1 + 2;
      iVar8 = *piVar7 + -1;
      *piVar7 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (iStack_18 != 0) {
    FUN_00587490(auStack_24);
    uStack_8 = 0;
    iVar8 = FUN_00b077e0();
    uStack_8 = 0xffffffff;
    uVar6 = *(undefined8 *)(iVar8 + 0x24);
    uVar2 = *(undefined4 *)(iVar8 + 0x2c);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_20[1] + -1;
      piStack_20[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    puVar9 = (undefined4 *)FUN_01160c20(auStack_48,iStack_14 + -0xac);
    uVar3 = puVar9[1];
    uVar4 = puVar9[2];
    uVar5 = puVar9[3];
    *param_2 = *puVar9;
    param_2[1] = uVar3;
    param_2[2] = uVar4;
    param_2[3] = uVar5;
    uVar3 = puVar9[5];
    uVar4 = puVar9[6];
    uVar5 = puVar9[7];
    param_2[4] = puVar9[4];
    param_2[5] = uVar3;
    param_2[6] = uVar4;
    param_2[7] = uVar5;
    param_2[8] = puVar9[8];
    *(undefined8 *)(param_2 + 9) = uVar6;
    param_2[0xb] = uVar2;
    ExceptionList = pvStack_10;
    return param_2;
  }
  if (*(int *)(iStack_14 + -0xb8) != 0) {
    puVar9 = (undefined4 *)FUN_00b077e0();
    uVar2 = puVar9[1];
    uVar3 = puVar9[2];
    uVar4 = puVar9[3];
    *param_2 = *puVar9;
    param_2[1] = uVar2;
    param_2[2] = uVar3;
    param_2[3] = uVar4;
    uVar2 = puVar9[5];
    uVar3 = puVar9[6];
    uVar4 = puVar9[7];
    param_2[4] = puVar9[4];
    param_2[5] = uVar2;
    param_2[6] = uVar3;
    param_2[7] = uVar4;
    uVar2 = puVar9[9];
    uVar3 = puVar9[10];
    uVar4 = puVar9[0xb];
    param_2[8] = puVar9[8];
    param_2[9] = uVar2;
    param_2[10] = uVar3;
    param_2[0xb] = uVar4;
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_0060efa0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24587 ; VA 0x00b65b40 ; FUN_00b65b40 */

int __fastcall FUN_00b65b40(int param_1)

{
  return param_1 + 0xe4;
}



/* FUNCTION 24588 ; VA 0x00b65b50 ; FUN_00b65b50 */

int __fastcall FUN_00b65b50(int param_1)

{
  return param_1 + 0x114;
}



/* FUNCTION 24589 ; VA 0x00b65b60 ; FUN_00b65b60 */

void __thiscall FUN_00b65b60(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [8];
  
  if ((DAT_01d6c85c != '\0') && (iVar5 = FUN_008f7870(param_1), iVar5 != 0)) {
    if (*(int *)(param_1 + 0x138) == 0) {
      puVar6 = (undefined4 *)FUN_00d09100(auStack_c,param_1);
      uVar2 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(param_1 + 0x138) = uVar2;
      piVar4 = *(int **)(param_1 + 0x13c);
      *(undefined4 *)(param_1 + 0x13c) = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      FUN_00550b30();
    }
    iVar5 = *(int *)(param_1 + 0x13c);
    *param_2 = 0;
    param_2[1] = 0;
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(param_1 + 0x13c);
    }
    *param_2 = *(undefined4 *)(param_1 + 0x138);
    param_2[1] = iVar5;
    return;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return;
}



/* FUNCTION 24590 ; VA 0x00b65c40 ; FUN_00b65c40 */

undefined4 * FUN_00b65c40(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined auStack_10 [4];
  undefined auStack_c [4];
  int *piStack_8;
  
  piVar6 = (int *)FUN_00587490(auStack_c);
  iVar1 = *piVar6;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar6 = piStack_8 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (iVar1 == 0) {
    FUN_00550130(
                "Model:GetPrimaryCFrame() failed because no PrimaryPart has been set, or the PrimaryPart no longer exists. Please set Model.PrimaryPart before using this."
                );
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  puVar7 = (undefined4 *)FUN_00b077e0();
  uVar3 = puVar7[1];
  uVar4 = puVar7[2];
  uVar5 = puVar7[3];
  *param_1 = *puVar7;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  uVar3 = puVar7[5];
  uVar4 = puVar7[6];
  uVar5 = puVar7[7];
  param_1[4] = puVar7[4];
  param_1[5] = uVar3;
  param_1[6] = uVar4;
  param_1[7] = uVar5;
  uVar3 = puVar7[9];
  uVar4 = puVar7[10];
  uVar5 = puVar7[0xb];
  param_1[8] = puVar7[8];
  param_1[9] = uVar3;
  param_1[10] = uVar4;
  param_1[0xb] = uVar5;
  return param_1;
}



/* FUNCTION 24591 ; VA 0x00b65cd0 ; FUN_00b65cd0 */

int __fastcall FUN_00b65cd0(int param_1)

{
  int iVar1;
  undefined **ppuVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  code *pcStack_28;
  int *piStack_24;
  undefined **ppuStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5658;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined4 *)(param_1 + 0x94);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  piVar4 = (int *)FUN_00587490(&piStack_24);
  ppuVar2 = ppuStack_20;
  puStack_1c = (undefined *)*piVar4;
  if (ppuStack_20 != (undefined **)0x0) {
    LOCK();
    iVar5 = (int)ppuStack_20[1] + -1;
    ppuStack_20[1] = (undefined *)iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*ppuStack_20)();
      LOCK();
      piVar4 = (int *)(ppuVar2 + 2);
      iVar5 = *piVar4 + -1;
      *piVar4 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)((int)*ppuVar2 + 4))();
      }
    }
  }
  if (puStack_1c != (undefined *)0x0) {
    piVar4 = (int *)FUN_00587490(&piStack_24);
    if (iStack_14 == *(int *)(*piVar4 + 0x34)) {
      cVar3 = '\x01';
    }
    else if (*(int *)(*piVar4 + 0x34) == 0) {
      cVar3 = '\0';
    }
    else {
      cVar3 = FUN_00620ec0(iStack_14);
    }
    ppuVar2 = ppuStack_20;
    uStack_8 = 0xffffffff;
    if (ppuStack_20 != (undefined **)0x0) {
      LOCK();
      iVar5 = (int)ppuStack_20[1] + -1;
      ppuStack_20[1] = (undefined *)iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*ppuStack_20)();
        LOCK();
        piVar4 = (int *)(ppuVar2 + 2);
        iVar5 = *piVar4 + -1;
        *piVar4 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)((int)*ppuVar2 + 4))();
        }
      }
    }
    if (cVar3 == '\0') {
      *puStack_18 = 0;
      piVar4 = (int *)puStack_18[1];
      puStack_18[1] = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  piVar4 = (int *)FUN_00587490(&piStack_24);
  ppuVar2 = ppuStack_20;
  puStack_1c = (undefined *)*piVar4;
  if (ppuStack_20 != (undefined **)0x0) {
    LOCK();
    iVar5 = (int)ppuStack_20[1] + -1;
    ppuStack_20[1] = (undefined *)iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*ppuStack_20)();
      LOCK();
      piVar4 = (int *)(ppuVar2 + 2);
      iVar5 = *piVar4 + -1;
      *piVar4 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)((int)*ppuVar2 + 4))();
      }
    }
  }
  if (puStack_1c != (undefined *)0x0) {
    *(undefined4 *)(iStack_14 + 0x90) = 0;
    piVar4 = (int *)FUN_00587490(&piStack_24);
    iVar5 = *piVar4;
    if (ppuStack_20 != (undefined **)0x0) {
      LOCK();
      iVar1 = (int)ppuStack_20[1] + -1;
      ppuStack_20[1] = (undefined *)iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*ppuStack_20)();
        LOCK();
        piVar4 = (int *)(ppuStack_20 + 2);
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)((int)*ppuStack_20 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar5;
  }
  iVar5 = *(int *)(iStack_14 + 0x90);
  piVar4 = (int *)(iStack_14 + 0x90);
  if (iVar5 == 0) {
    *piVar4 = 0;
    ppuStack_20 = &puStack_1c;
    puStack_1c = &DAT_bf800000;
    pcStack_28 = FUN_00b67600;
    piStack_24 = piVar4;
    FUN_00b640e0(&pcStack_28);
    iVar5 = *piVar4;
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24592 ; VA 0x00b65ea0 ; FUN_00b65ea0 */

undefined4 FUN_00b65ea0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 24593 ; VA 0x00b65f00 ; FUN_00b65f00 */

int FUN_00b65f00(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b63e30();
      iVar3 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar3 = param_1;
      }
      if ((iVar3 != 0) && (*(int *)(iVar3 + 0x124) == 1)) {
        iVar4 = iVar3;
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return iVar4;
}



/* FUNCTION 24594 ; VA 0x00b65f60 ; FUN_00b65f60 */

int __fastcall FUN_00b65f60(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_0170d75d(*(undefined4 *)(param_1 + 0x34),0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::PVInstance::RTTI_Type_Descriptor,0);
  while (iVar1 = iVar2, iVar1 != 0) {
    iVar2 = FUN_0170d75d(*(undefined4 *)(iVar1 + 0x34),0,&RBX::Instance::RTTI_Type_Descriptor,
                         &RBX::PVInstance::RTTI_Type_Descriptor,0);
    param_1 = iVar1;
  }
  return param_1;
}



/* FUNCTION 24595 ; VA 0x00b65fb0 ; FUN_00b65fb0 */

void __thiscall FUN_00b65fb0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00b671d0();
  *param_3 = uVar3;
  iVar4 = FUN_00b67280();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 24596 ; VA 0x00b66010 ; FUN_00b66010 */

bool FUN_00b66010(void)

{
  int iVar1;
  
  iVar1 = FUN_00a33fa0();
  return *(int *)(iVar1 + 0x10) != 0;
}



/* FUNCTION 24597 ; VA 0x00b66030 ; FUN_00b66030 */

uint FUN_00b66030(void)

{
  int iVar1;
  
  iVar1 = FUN_00b63e30();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24598 ; VA 0x00b66050 ; FUN_00b66050 */

bool __fastcall FUN_00b66050(int param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*(int *)(param_1 + -0x58) + 0xa8))();
  return iVar1 != 0;
}



/* FUNCTION 24599 ; VA 0x00b66070 ; FUN_00b66070 */

uint FUN_00b66070(void)

{
  int iVar1;
  
  iVar1 = FUN_00b63e30();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24600 ; VA 0x00b66090 ; FUN_00b66090 */

void FUN_00b66090(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b671d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24601 ; VA 0x00b660d0 ; FUN_00b660d0 */

void * __thiscall FUN_00b660d0(code *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  pcStack_14 = param_1;
  if (param_2 != (int *)0x0) {
    iVar2 = param_2[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if (pvVar4 < (void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      if (param_2 != (int *)0x0) {
        iVar2 = param_2[3];
        iVar3 = FUN_00b63e30();
        pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
        if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4)
        {
          pcStack_14 = FUN_00b660d0;
          pvVar4 = (void *)FUN_008ad320(&pcStack_14);
        }
      }
    }
    else {
      pvVar4 = (void *)(**(code **)(*param_2 + 300))(1);
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24602 ; VA 0x00b661a0 ; FUN_00b661a0 */

void FUN_00b661a0(void)

{
  code *pcStack_8;
  
  pcStack_8 = FUN_00b660d0;
  FUN_008ad320(&pcStack_8);
  return;
}



/* FUNCTION 24603 ; VA 0x00b661c0 ; FUN_00b661c0 */

void __thiscall FUN_00b661c0(int param_1,undefined4 param_2)

{
  int *piVar1;
  uint uVar2;
  
  for (uVar2 = 0;
      (piVar1 = *(int **)(param_1 + -0x48), piVar1 != (int *)0x0 &&
      (uVar2 < (uint)(piVar1[1] - *piVar1 >> 3))); uVar2 = uVar2 + 1) {
    piVar1 = (int *)FUN_0170d75d(*(undefined4 *)(*piVar1 + uVar2 * 8),0,
                                 &RBX::Instance::RTTI_Type_Descriptor,
                                 &RBX::CameraSubject::RTTI_Type_Descriptor,0);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 8))(param_2);
    }
  }
  return;
}



/* FUNCTION 24604 ; VA 0x00b66220 ; FUN_00b66220 */

void __thiscall FUN_00b66220(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = param_2;
  iVar3 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IModelModifier::RTTI_Type_Descriptor,0);
  if (iVar3 != 0) {
    puVar1 = *(undefined4 **)(param_1 + 0x130);
    if (*(undefined4 **)(param_1 + 0x134) != puVar1) {
      *puVar1 = uVar2;
      *(int *)(param_1 + 0x130) = *(int *)(param_1 + 0x130) + 4;
      FUN_00b64eb0();
      FUN_00b66980();
      return;
    }
    FUN_006030d0(puVar1,&param_2);
  }
  FUN_00b64eb0();
  FUN_00b66980();
  return;
}



/* FUNCTION 24605 ; VA 0x00b66290 ; FUN_00b66290 */

void __thiscall FUN_00b66290(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  *(undefined *)(param_1 + 0x129) = 0;
  iVar1 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00aff8c0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_2;
  }
  if (iVar3 != 0) {
    FUN_00b64eb0();
  }
  FUN_008a40d0(param_2,param_3);
  return;
}



/* FUNCTION 24606 ; VA 0x00b662f0 ; FUN_00b662f0 */

void __thiscall FUN_00b662f0(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::IModelModifier::RTTI_Type_Descriptor,0);
  if (iVar1 != 0) {
    for (piVar2 = *(int **)(param_1 + 300);
        (piVar2 != *(int **)(param_1 + 0x130) && (*piVar2 != param_2)); piVar2 = piVar2 + 1) {
    }
    FUN_0170cc70(piVar2,piVar2 + 1,(int)*(int **)(param_1 + 0x130) - (int)(piVar2 + 1));
    *(int *)(param_1 + 0x130) = *(int *)(param_1 + 0x130) + -4;
  }
  FUN_00b64eb0();
  FUN_00b66980();
  return;
}



/* FUNCTION 24607 ; VA 0x00b66360 ; FUN_00b66360 */

void __thiscall FUN_00b66360(int param_1,undefined4 param_2)

{
  FUN_008a4130(param_2);
  *(undefined4 *)(param_1 + 0x90) = 0;
  FUN_0115b050();
  return;
}



/* FUNCTION 24608 ; VA 0x00b66390 ; FUN_00b66390 */

void __thiscall FUN_00b66390(int param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  int iStack_8;
  
  piVar5 = (int *)FUN_00587490(auStack_14);
  iStack_c = *piVar5;
  iStack_8 = *param_2;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_10[1] + -1;
    piStack_10[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      piVar5 = piStack_10 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
  }
  if (iStack_c == iStack_8) {
    FUN_00b67030(0);
    puVar6 = (undefined4 *)FUN_0060efa0();
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *(undefined4 *)(param_1 + 0x9c) = *puVar6;
    *(undefined4 *)(param_1 + 0xa0) = uVar2;
    *(undefined4 *)(param_1 + 0xa4) = uVar3;
    *(undefined4 *)(param_1 + 0xa8) = uVar4;
    uVar2 = puVar6[5];
    uVar3 = puVar6[6];
    uVar4 = puVar6[7];
    *(undefined4 *)(param_1 + 0xac) = puVar6[4];
    *(undefined4 *)(param_1 + 0xb0) = uVar2;
    *(undefined4 *)(param_1 + 0xb4) = uVar3;
    *(undefined4 *)(param_1 + 0xb8) = uVar4;
    uVar2 = puVar6[9];
    uVar3 = puVar6[10];
    uVar4 = puVar6[0xb];
    *(undefined4 *)(param_1 + 0xbc) = puVar6[8];
    *(undefined4 *)(param_1 + 0xc0) = uVar2;
    *(undefined4 *)(param_1 + 0xc4) = uVar3;
    *(undefined4 *)(param_1 + 200) = uVar4;
  }
  *(undefined4 *)(param_1 + 0x90) = 0;
  FUN_0115b050();
  FUN_008a41c0(param_2);
  return;
}



/* FUNCTION 24609 ; VA 0x00b66440 ; FUN_00b66440 */

void __thiscall FUN_00b66440(int param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  if (param_2 == &DAT_0212d228) {
    if (*(char *)(param_1 + 0x140) == '\x01') goto LAB_00b66484;
    *(undefined *)(param_1 + 0x140) = 1;
  }
  else {
    if ((param_2 != &DAT_0212d270) || (*(char *)(param_1 + 0x140) == '\0')) goto LAB_00b66484;
    *(undefined *)(param_1 + 0x140) = 0;
  }
  FUN_006eccd0();
LAB_00b66484:
  FUN_009cba80(param_2,param_3,param_4);
  return;
}



/* FUNCTION 24610 ; VA 0x00b664a0 ; FUN_00b664a0 */

void __thiscall FUN_00b664a0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  if ((DAT_01ef02e4 != '\0') &&
     ((iVar1 = FUN_0170d75d(*(undefined4 *)(param_1 + -0x24),0,&RBX::Instance::RTTI_Type_Descriptor,
                            &RBX::PVInstance::RTTI_Type_Descriptor,0), iVar1 == 0 ||
      (iVar1 = *(int *)(param_1 + -0x24), iVar2 = FUN_00b65f60(), iVar2 == iVar1)))) {
    FUN_00e70680(param_2);
  }
  return;
}



/* FUNCTION 24611 ; VA 0x00b664f0 ; FUN_00b664f0 */

void __thiscall FUN_00b664f0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined auStack_110 [104];
  undefined auStack_a8 [104];
  undefined auStack_40 [48];
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar2 = (**(code **)*param_1)();
  if (cVar2 != '\0') {
    piVar1 = (int *)param_1[-0xb];
    if ((piVar1 == (int *)0x0) || (piVar1[1] - *piVar1 >> 3 == 0)) {
      uVar3 = (*(code *)**(undefined4 **)((int)param_1 + *(int *)(param_1[-1] + 4) + -4))
                        (auStack_40);
      uStack_10 = 0;
      uStack_c = 0;
      uStack_8 = 0;
      puVar4 = (undefined4 *)FUN_0115ee70(uVar3);
      uVar8 = *puVar4;
      uVar7 = puVar4[1];
      uVar9 = puVar4[2];
      puVar4 = &uStack_10;
    }
    else {
      uVar3 = FUN_00b64cf0(auStack_40);
      puVar4 = (undefined4 *)FUN_00b64df0(&uStack_10);
      puVar5 = (undefined4 *)FUN_0115ee70(uVar3);
      uVar8 = *puVar5;
      uVar7 = puVar5[1];
      uVar9 = puVar5[2];
    }
    FUN_00b64830(1,puVar4,uVar8,uVar7,uVar9,0x3f800000,uVar3);
    if (param_3 == 0) {
      iVar6 = FUN_00b65ea0();
      uVar8 = DAT_01d67114;
      if (iVar6 != 0) {
        FUN_00b65ea0();
        uVar7 = FUN_00b08170(auStack_110);
        FUN_0114df50(uVar7,param_2,&DAT_01ef02ec,uVar8);
      }
    }
    FUN_0114df80(auStack_a8,param_2,param_3,0x3d4ccccd);
  }
  return;
}



/* FUNCTION 24612 ; VA 0x00b66630 ; FUN_00b66630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b66630(void)

{
  undefined4 *puVar1;
  undefined auStack_ac [48];
  undefined auStack_7c [36];
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  code *pcStack_10;
  undefined4 *puStack_c;
  undefined8 *puStack_8;
  
  FUN_00b64cf0(auStack_7c);
  uStack_1c = uStack_58;
  uStack_4c = _DAT_018e3fb0;
  uStack_48 = _UNK_018e3fb4;
  uStack_44 = _UNK_018e3fb8;
  uStack_40 = _UNK_018e3fbc;
  uStack_14 = uStack_50;
  uStack_3c = _DAT_018e3fb0;
  uStack_38 = _UNK_018e3fb4;
  uStack_34 = _UNK_018e3fb8;
  uStack_30 = _UNK_018e3fbc;
  uStack_2c = _DAT_018e3fb0;
  uStack_28 = _UNK_018e3fb4;
  uStack_24 = _UNK_018e3fb8;
  uStack_20 = _UNK_018e3fbc;
  puVar1 = (undefined4 *)FUN_0071fcc0(auStack_ac);
  puStack_8 = &uStack_1c;
  pcStack_10 = FUN_00b666d0;
  uStack_4c = *puVar1;
  uStack_48 = puVar1[1];
  uStack_44 = puVar1[2];
  uStack_40 = puVar1[3];
  uStack_3c = puVar1[4];
  uStack_38 = puVar1[5];
  uStack_34 = puVar1[6];
  uStack_30 = puVar1[7];
  uStack_2c = puVar1[8];
  puStack_c = &uStack_4c;
  FUN_00b640e0(&pcStack_10);
  FUN_00b66980();
  return;
}



/* FUNCTION 24613 ; VA 0x00b666d0 ; FUN_00b666d0 */

void * FUN_00b666d0(int *param_1,int *param_2,undefined4 param_3,float *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      puVar5 = (undefined4 *)FUN_00b077e0();
      uStack_40 = *puVar5;
      uStack_3c = puVar5[1];
      uStack_38 = puVar5[2];
      uStack_34 = puVar5[3];
      uStack_30 = puVar5[4];
      uStack_2c = puVar5[5];
      uStack_28 = puVar5[6];
      uStack_24 = puVar5[7];
      uStack_20 = puVar5[8];
      fStack_1c = (float)puVar5[9] - *param_4;
      fStack_18 = (float)puVar5[10] - param_4[1];
      fStack_14 = (float)puVar5[0xb] - param_4[2];
      puVar5 = (undefined4 *)FUN_0071f260(auStack_70,&uStack_40);
      uStack_40 = *puVar5;
      uStack_3c = puVar5[1];
      uStack_38 = puVar5[2];
      uStack_34 = puVar5[3];
      uStack_30 = puVar5[4];
      uStack_2c = puVar5[5];
      uStack_28 = puVar5[6];
      uStack_24 = puVar5[7];
      uStack_20 = puVar5[8];
      fStack_1c = *param_4 + (float)puVar5[9];
      fStack_18 = param_4[1] + (float)puVar5[10];
      fStack_14 = param_4[2] + (float)puVar5[0xb];
      pvVar4 = (void *)(**(code **)(*param_1 + 0x108))(&uStack_40);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24614 ; VA 0x00b66810 ; FUN_00b66810 */

void * FUN_00b66810(int *param_1,int *param_2,undefined4 param_3,float *param_4,float *param_5,
                   int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  void *pvVar5;
  undefined4 *puVar6;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00aff8c0();
    pvVar5 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
    if (((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= pvVar5) &&
       (param_1 != param_6)) {
      puVar6 = (undefined4 *)FUN_00b077e0();
      uStack_40 = *puVar6;
      uStack_3c = puVar6[1];
      uStack_38 = puVar6[2];
      uStack_34 = puVar6[3];
      uStack_30 = puVar6[4];
      uStack_2c = puVar6[5];
      uStack_28 = puVar6[6];
      uStack_24 = puVar6[7];
      uStack_20 = puVar6[8];
      fStack_1c = (*param_4 + (float)puVar6[9]) - *param_5;
      fStack_18 = (param_4[1] + (float)puVar6[10]) - param_5[1];
      fStack_14 = (param_4[2] + (float)puVar6[0xb]) - param_5[2];
      puVar6 = (undefined4 *)FUN_0071f260(auStack_70,&uStack_40);
      uStack_40 = *puVar6;
      uStack_3c = puVar6[1];
      uStack_38 = puVar6[2];
      uStack_34 = puVar6[3];
      uStack_30 = puVar6[4];
      uStack_2c = puVar6[5];
      uStack_28 = puVar6[6];
      uStack_24 = puVar6[7];
      uStack_20 = puVar6[8];
      fStack_1c = *param_5 + (float)puVar6[9];
      fStack_18 = (float)puVar6[10] + param_5[1];
      fStack_14 = param_5[2] + (float)puVar6[0xb];
      cVar3 = FUN_01162520();
      if (cVar3 == '\0') {
        FUN_01162820();
      }
      pvVar5 = (void *)(**(code **)(*param_1 + 0x108))(&uStack_40);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar5 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar5 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 24615 ; VA 0x00b66980 ; FUN_00b66980 */

void __fastcall FUN_00b66980(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0x34);
  *(undefined *)(param_1 + 0x129) = 0;
  for (; iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x34)) {
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      *(undefined *)(iVar1 + 0x129) = 0;
    }
  }
  return;
}



/* FUNCTION 24616 ; VA 0x00b669d0 ; FUN_00b669d0 */

void __fastcall FUN_00b669d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined auStack_84 [48];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  (**(code **)(*param_1 + 0xa8))();
  piStack_1c = param_1 + 0x25;
  piVar4 = (int *)FUN_00587490(auStack_24);
  piVar6 = piStack_20;
  iStack_18 = *piVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[1] + -1;
    piStack_20[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar4 = piVar6 + 2;
      iVar1 = *piVar4 + -1;
      *piVar4 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_14;
  if (iStack_18 == 0) {
    if (piStack_14[0x24] == 0) {
      puVar5 = (undefined4 *)FUN_0060efa0();
    }
    else {
      puVar5 = (undefined4 *)FUN_00b077e0();
    }
    uStack_54 = *puVar5;
    uStack_50 = puVar5[1];
    uStack_4c = puVar5[2];
    uStack_48 = puVar5[3];
    uStack_44 = puVar5[4];
    uStack_40 = puVar5[5];
    uStack_3c = puVar5[6];
    uStack_38 = puVar5[7];
    uStack_34 = puVar5[8];
    uStack_30 = puVar5[9];
    uStack_2c = puVar5[10];
    uStack_28 = puVar5[0xb];
  }
  else {
    FUN_00587490(auStack_24);
    uStack_8 = 0;
    puVar5 = (undefined4 *)FUN_00b077e0();
    uStack_8 = 0xffffffff;
    uStack_54 = *puVar5;
    uStack_50 = puVar5[1];
    uStack_4c = puVar5[2];
    uStack_48 = puVar5[3];
    uStack_44 = puVar5[4];
    uStack_40 = puVar5[5];
    uStack_3c = puVar5[6];
    uStack_38 = puVar5[7];
    uStack_34 = puVar5[8];
    uStack_30 = puVar5[9];
    uStack_2c = puVar5[10];
    uStack_28 = puVar5[0xb];
    piVar6 = piStack_14;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar6 = piStack_20 + 2;
        iVar1 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        piVar6 = piStack_14;
        if (iVar1 == 1) {
          (**(code **)(*piStack_20 + 4))();
          piVar6 = piStack_14;
        }
      }
    }
  }
  piVar4 = (int *)FUN_0071fcc0(auStack_84);
  iVar1 = piVar4[1];
  iVar2 = piVar4[2];
  iVar3 = piVar4[3];
  piVar6[0x27] = *piVar4;
  piVar6[0x28] = iVar1;
  piVar6[0x29] = iVar2;
  piVar6[0x2a] = iVar3;
  iVar1 = piVar4[5];
  iVar2 = piVar4[6];
  iVar3 = piVar4[7];
  piVar6[0x2b] = piVar4[4];
  piVar6[0x2c] = iVar1;
  piVar6[0x2d] = iVar2;
  piVar6[0x2e] = iVar3;
  piVar6[0x2f] = piVar4[8];
  FUN_00b66980();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24617 ; VA 0x00b66b20 ; FUN_00b66b20 */

void __thiscall FUN_00b66b20(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_64 [48];
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x124) != param_2) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x124) = param_2;
    if (param_2 == 1) {
      uVar1 = FUN_00b64cf0(auStack_64);
      FUN_00b66c40(uVar1);
      uVar1 = FUN_00b64df0(auStack_1c);
      FUN_00b66d00(uVar1);
      iVar2 = FUN_008f7870(param_1);
      if (iVar2 != 0) {
        FUN_005e6780(param_1);
      }
      FUN_00b63f50(&DAT_01ef0314,&param_2);
    }
    else {
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8 = 0;
      FUN_00a34170(auStack_34);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_008a4940(&DAT_0212ccf0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24618 ; VA 0x00b66c10 ; FUN_00b66c10 */

void __thiscall FUN_00b66c10(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0x9c) = *param_2;
  *(undefined4 *)(param_1 + 0xa0) = uVar1;
  *(undefined4 *)(param_1 + 0xa4) = uVar2;
  *(undefined4 *)(param_1 + 0xa8) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0xac) = param_2[4];
  *(undefined4 *)(param_1 + 0xb0) = uVar1;
  *(undefined4 *)(param_1 + 0xb4) = uVar2;
  *(undefined4 *)(param_1 + 0xb8) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0xbc) = param_2[8];
  *(undefined4 *)(param_1 + 0xc0) = uVar1;
  *(undefined4 *)(param_1 + 0xc4) = uVar2;
  *(undefined4 *)(param_1 + 200) = uVar3;
  return;
}



/* FUNCTION 24619 ; VA 0x00b66c40 ; FUN_00b66c40 */

void __thiscall FUN_00b66c40(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  
  if (((((NAN((float)param_2[9]) || NAN(*(float *)(param_1 + 0x108))) !=
         ((float)param_2[9] == *(float *)(param_1 + 0x108))) &&
       ((NAN((float)param_2[10]) || NAN(*(float *)(param_1 + 0x10c))) !=
        ((float)param_2[10] == *(float *)(param_1 + 0x10c)))) &&
      ((NAN((float)param_2[0xb]) || NAN(*(float *)(param_1 + 0x110))) !=
       ((float)param_2[0xb] == *(float *)(param_1 + 0x110)))) &&
     (cVar4 = FUN_01160ab0((undefined4 *)(param_1 + 0xe4)), cVar4 != '\0')) {
    return;
  }
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0xe4) = *param_2;
  *(undefined4 *)(param_1 + 0xe8) = uVar1;
  *(undefined4 *)(param_1 + 0xec) = uVar2;
  *(undefined4 *)(param_1 + 0xf0) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0xf4) = param_2[4];
  *(undefined4 *)(param_1 + 0xf8) = uVar1;
  *(undefined4 *)(param_1 + 0xfc) = uVar2;
  *(undefined4 *)(param_1 + 0x100) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0x104) = param_2[8];
  *(undefined4 *)(param_1 + 0x108) = uVar1;
  *(undefined4 *)(param_1 + 0x10c) = uVar2;
  *(undefined4 *)(param_1 + 0x110) = uVar3;
  FUN_008a4940(&DAT_0212cc48);
  return;
}



/* FUNCTION 24620 ; VA 0x00b66cc0 ; FUN_00b66cc0 */

void __thiscall FUN_00b66cc0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *(int *)(param_1 + 0x120) = iVar2;
  FUN_0056cd30();
  FUN_008a4940(&DAT_0212ccb8);
  return;
}



/* FUNCTION 24621 ; VA 0x00b66d00 ; FUN_00b66d00 */

void __thiscall FUN_00b66d00(int param_1,float *param_2)

{
  if ((((NAN(*(float *)(param_1 + 0x114)) || NAN(*param_2)) !=
        (*(float *)(param_1 + 0x114) == *param_2)) &&
      ((NAN(*(float *)(param_1 + 0x118)) || NAN(param_2[1])) !=
       (*(float *)(param_1 + 0x118) == param_2[1]))) &&
     ((NAN(*(float *)(param_1 + 0x11c)) || NAN(param_2[2])) !=
      (*(float *)(param_1 + 0x11c) == param_2[2]))) {
    return;
  }
  *(undefined8 *)(param_1 + 0x114) = *(undefined8 *)param_2;
  *(float *)(param_1 + 0x11c) = param_2[2];
  FUN_008a4940();
  return;
}



/* FUNCTION 24622 ; VA 0x00b66d70 ; FUN_00b66d70 */

void __thiscall FUN_00b66d70(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (*(char *)(param_1 + 0x128) != '\0') {
    uVar2 = FUN_01255560();
    cVar1 = FUN_01255580(uVar2,4);
    if (cVar1 == '\0') {
      FUN_01255600(4,"set a Character\'s name");
    }
  }
  FUN_008a6520(param_2);
  return;
}



/* FUNCTION 24623 ; VA 0x00b66dc0 ; FUN_00b66dc0 */

int FUN_00b66dc0(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  float in_stack_00000028;
  float in_stack_0000002c;
  float in_stack_00000030;
  undefined auStack_110 [36];
  undefined auStack_ec [16];
  code *pcStack_dc;
  undefined4 *puStack_d8;
  undefined8 *puStack_d4;
  undefined4 *puStack_d0;
  int *piStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  float fStack_6c;
  undefined auStack_68 [12];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 *puStack_20;
  undefined8 *puStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_00587490(auStack_2c);
  piStack_14 = (int *)*puVar6;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_28[1] + -1;
    piStack_28[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar7 = piStack_28[2] + -1;
      piStack_28[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    puVar6 = (undefined4 *)FUN_00b077e0();
    uStack_5c = *puVar6;
    uStack_58 = puVar6[1];
    uStack_54 = puVar6[2];
    uStack_50 = puVar6[3];
    uStack_4c = puVar6[4];
    uStack_48 = puVar6[5];
    uStack_44 = puVar6[6];
    uStack_40 = puVar6[7];
    uStack_3c = puVar6[8];
    fStack_38 = (float)puVar6[9];
    fStack_34 = (float)puVar6[10];
    fStack_30 = (float)puVar6[0xb];
    cVar5 = FUN_01162520();
    if (cVar5 == '\0') {
      FUN_01162820();
    }
    if (((((NAN(fStack_38) || NAN(in_stack_00000028)) != (fStack_38 == in_stack_00000028)) &&
         ((NAN(fStack_34) || NAN(in_stack_0000002c)) != (fStack_34 == in_stack_0000002c))) &&
        ((NAN(fStack_30) || NAN(in_stack_00000030)) != (fStack_30 == in_stack_00000030))) &&
       (iVar7 = FUN_01160ab0(&stack0x00000004), (char)iVar7 != '\0')) {
      ExceptionList = pvStack_10;
      return iVar7;
    }
    FUN_0060efa0();
    fStack_6c = in_stack_00000030 - fStack_30;
    uStack_74 = CONCAT44(in_stack_0000002c - fStack_34,in_stack_00000028 - fStack_38);
    piStack_14 = (int *)fStack_6c;
    uVar8 = FUN_011630b0(auStack_ec);
    puVar6 = (undefined4 *)FUN_01160c20(auStack_110,uVar8);
    uStack_c8 = *puVar6;
    uStack_c4 = puVar6[1];
    uStack_c0 = puVar6[2];
    uStack_bc = puVar6[3];
    uStack_b8 = puVar6[4];
    uStack_b4 = puVar6[5];
    uStack_b0 = puVar6[6];
    uStack_ac = puVar6[7];
    uStack_a8 = puVar6[8];
    uStack_9c = 0;
    puStack_d8 = &uStack_c8;
    puStack_d4 = &uStack_74;
    puStack_d0 = &stack0x00000028;
    pcStack_dc = FUN_00b66810;
    uStack_a4 = 0;
    piStack_cc = piVar4;
    uStack_98 = uStack_c8;
    uStack_94 = uStack_c4;
    uStack_90 = uStack_c0;
    uStack_8c = uStack_bc;
    uStack_88 = uStack_b8;
    uStack_84 = uStack_b4;
    uStack_80 = uStack_b0;
    uStack_7c = uStack_ac;
    uStack_78 = uStack_a8;
    puStack_20 = puStack_d8;
    puStack_1c = puStack_d4;
    puStack_18 = puStack_d0;
    piStack_14 = piVar4;
    FUN_00b641c0(&pcStack_dc);
    puVar6 = (undefined4 *)FUN_0060dcd0(&puStack_18,piVar4,&uStack_c8,&uStack_74,&stack0x00000028,0)
    ;
    uStack_8 = 0;
    uVar8 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    iVar7 = FUN_00b66810(uVar8,uVar3);
    piVar4 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar7 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar7;
  }
  FUN_00550130(
              "Model:SetPrimaryCFrame() failed because no PrimaryPart has been set, or the PrimaryPart no longer exists. Please set Model.PrimaryPart before using this."
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_68,&DAT_01c17198);
}



/* FUNCTION 24624 ; VA 0x00b67030 ; FUN_00b67030 */

void __thiscall FUN_00b67030(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  int iStack_8;
  
  piVar2 = (int *)FUN_00587490(auStack_10);
  piVar1 = piStack_c;
  iStack_8 = *piVar2;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_c[1] + -1;
    piStack_c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2 + -1;
      *piVar2 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_2 != iStack_8) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_10,param_2);
    iVar4 = puVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x94) = *puVar3;
    piVar1 = *(int **)(param_1 + 0x98);
    *(int *)(param_1 + 0x98) = iVar4;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_c[1] + -1;
      piStack_c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piStack_c + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_c + 4))();
        }
      }
    }
    FUN_00b66980();
    FUN_008a4940(&DAT_0212cd68);
  }
  return;
}



/* FUNCTION 24625 ; VA 0x00b67110 ; FUN_00b67110 */

void __thiscall FUN_00b67110(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00b671d0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24626 ; VA 0x00b67160 ; FUN_00b67160 */

undefined4 __fastcall FUN_00b67160(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (DAT_01ef02e4 == '\0') {
    return 0;
  }
  iVar1 = FUN_0170d75d(*(undefined4 *)(param_1 + -0x24),0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::PVInstance::RTTI_Type_Descriptor,0);
  if ((iVar1 != 0) && (iVar1 = *(int *)(param_1 + -0x24), iVar2 = FUN_00b65f60(), iVar2 != iVar1)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 24627 ; VA 0x00b671b0 ; FUN_00b671b0 */

void __fastcall FUN_00b671b0(int param_1)

{
  byte bVar1;
  
  bVar1 = *(byte *)(param_1 + 0x43) & 1;
  if (*(byte *)(param_1 + 0x140) != bVar1) {
    *(byte *)(param_1 + 0x140) = bVar1;
    FUN_006eccd0();
    return;
  }
  return;
}



/* FUNCTION 24628 ; VA 0x00b671d0 ; FUN_00b671d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b671d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5686;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef05a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef05a4);
    if (DAT_01ef05a4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ModelLevelOfDetail");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef0540 = RBX::Reflection::EnumDesc<enum_RBX::ModelLevelOfDetail>::vftable;
      FUN_009caf20(&DAT_01d67118,3);
      FUN_016f3654(&LAB_0188e880);
      FUN_016f37bf(&DAT_01ef05a4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef0540;
}



/* FUNCTION 24629 ; VA 0x00b67280 ; FUN_00b67280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b67280(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef05b4) {
    FUN_016f3809(&DAT_01ef05b4);
    if (DAT_01ef05b4 == -1) {
      _DAT_01ef05a8 = FUN_005c65e0;
      _DAT_01ef05ac = FUN_005c65e0;
      _DAT_01ef05b0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef05b4);
    }
  }
  return &DAT_01ef05a8;
}



/* FUNCTION 24630 ; VA 0x00b672f0 ; FUN_00b672f0 */

void FUN_00b672f0(void)

{
  code *pcStack_c;
  undefined *puStack_8;
  
  puStack_8 = &stack0x00000004;
  pcStack_c = FUN_00b64b10;
  FUN_00917910(&pcStack_c);
  return;
}



/* FUNCTION 24631 ; VA 0x00b67320 ; FUN_00b67320 */

void * FUN_00b67320(int param_1,int *param_2,float *param_3,undefined4 param_4)

{
  float *pfVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvVar5;
  undefined4 uVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  void *pvStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00aff8c0();
    pvVar5 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= pvVar5) {
      pvStack_14 = (void *)((uint)(*(float *)(*(int *)(*(int *)(param_1 + 0xa8) + 0x1ac) + 0xc) *
                                  DAT_018ce2f4) ^ DAT_018c4ea0);
      uVar6 = FUN_00c157b0();
      FUN_00c9eef0(&fStack_28,uVar6,param_4);
      fVar9 = param_3[2];
      if (fStack_20 <= param_3[2]) {
        fVar9 = fStack_20;
      }
      fVar8 = param_3[1];
      if (fStack_24 <= param_3[1]) {
        fVar8 = fStack_24;
      }
      fVar7 = *param_3;
      if (fStack_28 <= *param_3) {
        fVar7 = fStack_28;
      }
      *(ulonglong *)param_3 = CONCAT44(fVar8,fVar7);
      param_3[2] = fVar9;
      pvVar5 = (void *)param_3[5];
      if (param_3[5] <= (float)pvStack_14) {
        pvVar5 = pvStack_14;
      }
      fVar9 = param_3[4];
      if (param_3[4] <= fStack_18) {
        fVar9 = fStack_18;
      }
      fVar8 = param_3[3];
      if (param_3[3] <= fStack_1c) {
        fVar8 = fStack_1c;
      }
      *(ulonglong *)(param_3 + 3) = CONCAT44(fVar9,fVar8);
      param_3[5] = (float)pvVar5;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    pfVar1 = (float *)(param_2 + 1);
    fVar9 = *pfVar1;
    pvVar5 = (void *)*pfVar1;
    *pfVar1 = (float)((int)fVar9 + -1);
    UNLOCK();
    if ((float)((int)fVar9 + -1) == 0.0) {
      pvVar5 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar2 = param_2 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pvVar5 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 24632 ; VA 0x00b674d0 ; FUN_00b674d0 */

void * FUN_00b674d0(int *param_1,int *param_2,float *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  float *pfVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  undefined auStack_34 [32];
  void *pvStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      pfVar5 = (float *)(**(code **)(*param_1 + 0xa4))(auStack_34);
      fVar8 = param_3[2];
      if (pfVar5[2] <= param_3[2]) {
        fVar8 = pfVar5[2];
      }
      fVar7 = param_3[1];
      if (pfVar5[1] <= param_3[1]) {
        fVar7 = pfVar5[1];
      }
      fVar6 = *param_3;
      if (*pfVar5 <= *param_3) {
        fVar6 = *pfVar5;
      }
      *(ulonglong *)param_3 = CONCAT44(fVar7,fVar6);
      param_3[2] = fVar8;
      pvVar4 = (void *)param_3[5];
      if (param_3[5] <= pfVar5[5]) {
        pvVar4 = (void *)pfVar5[5];
      }
      fVar8 = param_3[4];
      if (param_3[4] <= pfVar5[4]) {
        fVar8 = pfVar5[4];
      }
      fVar7 = param_3[3];
      if (param_3[3] <= pfVar5[3]) {
        fVar7 = pfVar5[3];
      }
      *(ulonglong *)(param_3 + 3) = CONCAT44(fVar8,fVar7);
      param_3[5] = (float)pvVar4;
      pvStack_14 = pvVar4;
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    pfVar5 = (float *)(param_2 + 1);
    fVar8 = *pfVar5;
    pvVar4 = (void *)*pfVar5;
    *pfVar5 = (float)((int)fVar8 + -1);
    UNLOCK();
    if ((float)((int)fVar8 + -1) == 0.0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 24633 ; VA 0x00b67600 ; FUN_00b67600 */

int * FUN_00b67600(int param_1,int *param_2,int *param_3,float *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  float fVar6;
  float afStack_34 [2];
  float fStack_2c;
  float fStack_28;
  float fStack_20;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar4 = (int *)ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    piVar4 = (int *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= piVar4) {
      fStack_20 = *(float *)(*(int *)(*(int *)(param_1 + 0xa8) + 0x1ac) + 0xc) * DAT_018ce2f4;
      uStack_14 = (uint)fStack_20 ^ DAT_018c4ea0;
      uVar5 = FUN_00c157b0();
      piVar4 = (int *)FUN_00c9f550(afStack_34,uVar5);
      fVar6 = (fStack_20 - fStack_2c) * (fStack_28 - afStack_34[0]);
      if (*param_4 <= fVar6 && fVar6 != *param_4) {
        *param_4 = fVar6;
        *param_3 = param_1;
        piVar4 = param_3;
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar4 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 24634 ; VA 0x00b67740 ; FUN_00b67740 */

undefined4 * __thiscall
FUN_00b67740(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f56a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_2c,&param_4);
      uStack_6c = 0xb677a4;
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_54 = 0;
  if (uStack_34 != 0) {
    uStack_54 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      puStack_60 = (undefined4 *)0x0;
      uStack_68 = CONCAT44(&uStack_4c,&uStack_2c);
      uStack_6c = 0xb677ed;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    else {
      uStack_4c = uStack_2c;
      uStack_48 = uStack_28;
      uStack_44 = uStack_24;
      uStack_40 = uStack_20;
      uStack_3c = uStack_1c;
    }
  }
  puStack_60 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_80;
  auStack_80[0] = 0;
  puVar1 = auStack_80;
  if (uStack_54 != 0) {
    auStack_80[0] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_78,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      uStack_70 = uStack_44;
      uStack_6c = uStack_40;
      uStack_68 = uStack_3c;
      puVar1 = auStack_80;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_01957348;
  cVar2 = FUN_00b680f0();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_6c = 0xb67876;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_60 = (undefined4 *)0x2;
      uStack_68 = CONCAT44(&uStack_2c,&uStack_2c);
      uStack_6c = 0xb678a5;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_60 = (undefined4 *)0x2;
    uStack_68 = CONCAT44(&param_4,&param_4);
    uStack_6c = 0xb678d3;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24635 ; VA 0x00b678f0 ; FUN_00b678f0 */

undefined4 * __thiscall FUN_00b678f0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01957350;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 24636 ; VA 0x00b67a20 ; FUN_00b67a20 */

undefined4 * __thiscall
FUN_00b67a20(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined auStack_74 [4];
  int *piStack_70;
  int *piStack_68;
  undefined auStack_44 [4];
  int *piStack_40;
  int *piStack_38;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f56d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b693a0(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00b693a0(auStack_74);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b693a0(auStack_44);
  ppuVar5 = &PTR_FUN_01957340;
  cVar4 = FUN_00b68300();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  FUN_0056d080();
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_38[1] + -1;
    piStack_38[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar3 = piStack_38[2] + -1;
      piStack_38[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_40[2] + -1;
    piStack_40[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_40 + 4))();
    }
  }
  FUN_0056d080();
  if (piStack_68 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_68[1] + -1;
    piStack_68[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_68)();
      LOCK();
      iVar3 = piStack_68[2] + -1;
      piStack_68[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
  }
  if (piStack_70 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_70[2] + -1;
    piStack_70[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_70 + 4))();
    }
  }
  FUN_0056d080();
  piVar2 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24637 ; VA 0x00b67b80 ; FUN_00b67b80 */

undefined4 * __thiscall FUN_00b67b80(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_008881d0();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  uVar1 = FUN_005ea820();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 24638 ; VA 0x00b67be0 ; FUN_00b67be0 */

undefined4 * __thiscall FUN_00b67be0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  
  uVar3 = FUN_008881d0();
  *param_1 = uVar3;
  iVar4 = FUN_005ea820();
  iVar5 = param_1[1];
  if (iVar5 == iVar4) {
    iVar5 = param_2[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = param_2[1];
    }
    param_1[2] = *param_2;
    piVar2 = (int *)param_1[3];
    param_1[3] = iVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
      return param_1;
    }
  }
  else {
    if (iVar5 != 0) {
      (**(code **)(iVar5 + 8))(param_1 + 2);
      param_1[1] = 0;
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar2 = (int *)(param_2[1] + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    param_1[2] = *param_2;
    param_1[3] = param_2[1];
    param_1[1] = iVar4;
  }
  return param_1;
}



/* FUNCTION 24639 ; VA 0x00b67c90 ; FUN_00b67c90 */

int * __thiscall FUN_00b67c90(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b73610();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24640 ; VA 0x00b67ce0 ; FUN_00b67ce0 */

int * __thiscall FUN_00b67ce0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b73680();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24641 ; VA 0x00b67d30 ; FUN_00b67d30 */

int * __thiscall FUN_00b67d30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b736f0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 24642 ; VA 0x00b67d80 ; FUN_00b67d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b67d80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5710;
  pvStack_10 = ExceptionList;
  if (DAT_01ef068c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef08a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef08a0);
      if (DAT_01ef08a0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"AnalyticsService",1,uStack_20,0,0,0x1b,0,0);
        _DAT_01ef0898 = RBX::Creator<class_RBX::AnalyticsService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef0690,&DAT_01ef0898);
        FUN_016f3654(FUN_0188f900);
        FUN_016f37bf(&DAT_01ef08a0);
      }
    }
    DAT_01ef068c = &DAT_01ef0690;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef068c;
}



/* FUNCTION 24643 ; VA 0x00b67e80 ; FUN_00b67e80 */

void FUN_00b67e80(void)

{
  int iVar1;
  
  if (DAT_01ef08a4 == 0) {
    iVar1 = FUN_00b67d80();
    DAT_01ef08a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24644 ; VA 0x00b67ea0 ; FUN_00b67ea0 */

int FUN_00b67ea0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  
  iVar3 = FUN_006d3cd0(param_1,param_2);
  puVar2 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar3 + 8) = 0;
  *(undefined4 *)(iVar3 + 0xc) = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + 8) = *puVar2;
  *(undefined4 *)(iVar3 + 0xc) = puVar2[1];
  *(undefined8 *)(iVar3 + 0x10) = 0;
  return iVar3;
}



/* FUNCTION 24645 ; VA 0x00b67ef0 ; FUN_00b67ef0 */

void __thiscall FUN_00b67ef0(float *param_1,float *param_2,uint *param_3,float *param_4)

{
  uint uVar1;
  float fVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  undefined auStack_1c [4];
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5720;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_3;
  fVar5 = param_1[1];
  puStack_14 = &stack0xffffffd0;
  uStack_18 = (uint)param_1[6] &
              (((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
               uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193;
  fVar4 = *(float *)((int)param_1[3] + uStack_18 * 8);
  if (fVar4 != fVar5) {
    fVar5 = **(float **)((int)param_1[3] + 4 + uStack_18 * 8);
  }
  do {
    if (fVar5 == fVar4) {
      fVar4 = *param_4;
      ExceptionList = &pvStack_10;
      if (fVar5 != fVar4) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = fVar4;
        **(float **)((int)fVar4 + 4) = fVar5;
        **(undefined4 **)((int)fVar5 + 4) = param_4;
        fVar2 = *(float *)((int)fVar5 + 4);
        *(undefined4 *)((int)fVar5 + 4) = *(undefined4 *)((int)fVar4 + 4);
        *(float *)((int)fVar4 + 4) = param_4[1];
        param_4[1] = fVar2;
      }
      fVar4 = param_1[3];
      fVar2 = *(float *)((int)fVar4 + uStack_18 * 8);
      if (fVar2 == param_1[1]) {
        *(float **)((int)fVar4 + uStack_18 * 8) = param_4;
        *(float **)((int)param_1[3] + 4 + uStack_18 * 8) = param_4;
      }
      else if (fVar2 == fVar5) {
        *(float **)((int)fVar4 + uStack_18 * 8) = param_4;
      }
      else {
        pfVar3 = (float *)**(undefined4 **)((int)fVar4 + 4 + uStack_18 * 8);
        *(float **)((int)fVar4 + 4 + uStack_18 * 8) = pfVar3;
        if (pfVar3 != param_4) {
          *(undefined4 *)((int)param_1[3] + 4 + uStack_18 * 8) =
               *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uStack_18 * 8) + 4);
        }
      }
      fVar4 = param_1[7];
      uStack_8 = 2;
      fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)])
              / (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
      if (*param_1 <= fVar5 && fVar5 != *param_1) {
        if ((uint)fVar4 < 0x200) {
          fVar4 = (float)((int)fVar4 << 3);
        }
        else if ((uint)fVar4 < 0x1fffffff) {
          fVar4 = (float)((int)fVar4 * 2);
        }
        FUN_005cb500(fVar4);
        pfVar3 = (float *)param_1[1];
        if ((float *)*pfVar3 != pfVar3) {
          fVar4 = pfVar3[1];
          do {
            fVar5 = *(float *)param_1[1];
            FUN_00b67ef0(auStack_1c,(int)fVar5 + 8,fVar5);
          } while (fVar5 != fVar4);
        }
      }
      *param_2 = (float)param_4;
      *(undefined *)(param_2 + 1) = 1;
      ExceptionList = pvStack_10;
      return;
    }
    fVar5 = *(float *)((int)fVar5 + 4);
  } while (uVar1 != *(uint *)((int)fVar5 + 8));
  ExceptionList = &pvStack_10;
  puStack_14 = &stack0xffffffd0;
  FUN_00b6b190(param_4);
  *param_2 = fVar5;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24646 ; VA 0x00b680c8 ; Catch_All@00b680c8 */

void Catch_All_00b680c8(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_00b68c20(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24647 ; VA 0x00b680f0 ; FUN_00b680f0 */

undefined FUN_00b680f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 *param_8)

{
  char cVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 *apuStack_34 [2];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5757;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  apuStack_34[0] = (undefined4 *)0x0;
  puStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != (undefined4 *)0x0) {
    apuStack_34[0] = param_1;
    if (((uint)param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&uStack_2c,0);
    }
    else {
      uStack_2c = param_3;
      uStack_28 = param_4;
      uStack_24 = param_5;
      uStack_20 = param_6;
      uStack_1c = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_14 = param_1;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(apuStack_34);
  if (cVar1 == '\0') {
    puStack_54 = (undefined4 *)0x0;
    if (apuStack_34[0] != (undefined4 *)0x0) {
      puStack_54 = apuStack_34[0];
      if (((uint)apuStack_34[0] & 1) == 0) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_4c,0);
      }
      else {
        uStack_4c = uStack_2c;
        uStack_48 = uStack_28;
        uStack_44 = uStack_24;
        uStack_40 = uStack_20;
        uStack_3c = uStack_1c;
      }
    }
    uStack_8._0_1_ = 2;
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      if (puStack_54 != (undefined4 *)0x0) {
        *puVar2 = puStack_54;
        if (((uint)puStack_54 & 1) == 0) {
          (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,puVar2 + 2,0);
        }
        else {
          puVar2[2] = uStack_4c;
          puVar2[3] = uStack_48;
          puVar2[4] = uStack_44;
          puVar2[5] = uStack_40;
          *(undefined8 *)(puVar2 + 6) = uStack_3c;
        }
      }
    }
    *param_8 = puVar2;
    uStack_8._0_1_ = 4;
    if (((puStack_54 != (undefined4 *)0x0) && (((uint)puStack_54 & 1) == 0)) &&
       (*(code **)((uint)puStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)puStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (apuStack_34[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_34[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_34[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_34[0] & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
        puStack_14 = param_1;
      }
      apuStack_34[0] = (undefined4 *)0x0;
    }
    uVar3 = 0;
    param_1 = puStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != (undefined4 *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (*(code **)((uint)param_1 & 0xfffffffe) != (code *)0x0)) {
    param_8._3_1_ = uVar3;
    (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_8._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 24648 ; VA 0x00b68300 ; FUN_00b68300 */

undefined FUN_00b68300(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined uVar6;
  undefined4 *in_stack_00000034;
  undefined auStack_74 [48];
  undefined auStack_44 [4];
  int *piStack_40;
  int *piStack_38;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5797;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b693a0(&param_1);
  uStack_8._0_1_ = 1;
  cVar4 = FUN_00585a40(auStack_74);
  if (cVar4 == '\0') {
    FUN_00b693a0(auStack_74);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x30);
    uStack_8._0_1_ = 3;
    if (iStack_14 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00b693a0(auStack_44);
    }
    *in_stack_00000034 = uVar5;
    FUN_0056d080();
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_38[1] + -1;
      piStack_38[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar3 = piStack_38[2] + -1;
        piStack_38[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_40[2] + -1;
      piStack_40[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    FUN_00b69c80();
    uVar6 = 1;
  }
  else {
    FUN_00b69c80();
    uVar6 = 0;
  }
  FUN_0056d080();
  piVar2 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 24649 ; VA 0x00b68440 ; FUN_00b68440 */

undefined4 *
FUN_00b68440(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int param_8)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000034;
  int aiStack_5c [5];
  uint uStack_48;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f57d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_8);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(aiStack_44);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_2c);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_30) {
    uVar3 = uStack_30 + 1;
    iVar2 = aiStack_44[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      uVar3 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_7;
  FUN_0054ef60(aiStack_5c);
  if (0xf < uStack_48) {
    uVar3 = uStack_48 + 1;
    iVar2 = aiStack_5c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_5c[0] + -4);
      uVar3 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_00000034) {
    uVar3 = in_stack_00000034 + 1;
    iVar2 = param_8;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_8 + -4);
      uVar3 = in_stack_00000034 + 0x24;
      if (0x1f < (param_8 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24650 ; VA 0x00b685c0 ; FUN_00b685c0 */

undefined4 *
FUN_00b685c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,int param_9)

{
  undefined4 *puVar1;
  uint in_stack_00000038;
  int iStack_2c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f57f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  puVar1 = (undefined4 *)FUN_00b69960(param_4,param_5,param_6,param_7);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = *puVar1;
  param_1[3] = puVar1[1];
  FUN_0054ef60();
  if (0xf < uStack_18) {
    if (0xfff < uStack_18 + 1) {
      if (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000038) {
    if (0xfff < in_stack_00000038 + 1) {
      if (0x1f < (param_9 - *(int *)(param_9 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24651 ; VA 0x00b686d0 ; FUN_00b686d0 */

undefined4
FUN_00b686d0(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 param_6,undefined4 *param_7,int param_8,
            undefined4 *param_9,undefined4 *param_10)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_28c [188];
  undefined4 uStack_1d0;
  undefined4 *puStack_1cc;
  undefined *puStack_1c8;
  undefined4 uStack_1c4;
  undefined4 *puStack_1c0;
  undefined auStack_1bc [188];
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  undefined *puStack_f8;
  undefined4 uStack_f4;
  undefined4 *puStack_f0;
  undefined auStack_ec [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5818;
  pvStack_10 = ExceptionList;
  param_1 = *param_7;
  uStack_f4 = *param_10;
  puStack_f0 = (undefined4 *)0x0;
  puVar2 = (undefined4 *)param_10[1];
  ExceptionList = &pvStack_10;
  if (puVar2 != (undefined4 *)0x0) {
    puStack_f8 = auStack_ec;
    puStack_fc = param_10 + 2;
    uStack_100 = 0xb68731;
    ExceptionList = &pvStack_10;
    (*(code *)*puVar2)();
    puVar2 = (undefined4 *)param_10[1];
  }
  uStack_8 = 0;
  uStack_1c4 = *param_9;
  puStack_1c0 = (undefined4 *)0x0;
  puVar3 = (undefined4 *)param_9[1];
  puStack_f0 = puVar2;
  if (puVar3 != (undefined4 *)0x0) {
    puStack_1c8 = auStack_1bc;
    puStack_1cc = param_9 + 2;
    uStack_1d0 = 0xb68770;
    (*(code *)*puVar3)();
    puVar3 = (undefined4 *)param_9[1];
  }
  uStack_8._0_1_ = 1;
  puStack_1c0 = puVar3;
  if (*(undefined4 **)(param_8 + 4) != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)(param_8 + 4))(param_8 + 8,auStack_28c);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_6);
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*param_2)(*param_5,param_5[1]);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24652 ; VA 0x00b68820 ; FUN_00b68820 */

undefined4
FUN_00b68820(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 *param_9,undefined4 param_10,undefined4 *param_11,undefined4 *param_12)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_1f8 [20];
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1d0;
  undefined4 *puStack_1cc;
  undefined *puStack_1c8;
  undefined4 uStack_1c4;
  undefined4 *puStack_1c0;
  undefined auStack_1bc [188];
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  undefined *puStack_f8;
  undefined4 uStack_f4;
  undefined4 *puStack_f0;
  undefined auStack_ec [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5850;
  pvStack_10 = ExceptionList;
  param_1 = (undefined *)*param_9;
  uStack_f4 = *param_12;
  puStack_f0 = (undefined4 *)0x0;
  puVar2 = (undefined4 *)param_12[1];
  ExceptionList = &pvStack_10;
  if (puVar2 != (undefined4 *)0x0) {
    puStack_f8 = auStack_ec;
    puStack_fc = param_12 + 2;
    uStack_100 = 0xb68889;
    ExceptionList = &pvStack_10;
    (*(code *)*puVar2)();
    puVar2 = (undefined4 *)param_12[1];
  }
  uStack_8 = 0;
  uStack_1c4 = *param_11;
  puStack_1c0 = (undefined4 *)0x0;
  puVar3 = (undefined4 *)param_11[1];
  puStack_f0 = puVar2;
  if (puVar3 != (undefined4 *)0x0) {
    puStack_1c8 = auStack_1bc;
    puStack_1cc = param_11 + 2;
    uStack_1d0 = 0xb688c8;
    (*(code *)*puVar3)();
    puVar3 = (undefined4 *)param_11[1];
  }
  uStack_8._0_1_ = 1;
  uStack_1e0 = param_10;
  uStack_1e4 = 0xb688e5;
  puStack_1c0 = puVar3;
  FUN_0054ef60();
  uStack_1e0 = param_1;
  uStack_8._0_1_ = 2;
  param_1 = auStack_1f8;
  FUN_0054ef60(param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_6);
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*param_2)(*param_5,param_5[1]);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24653 ; VA 0x00b68960 ; FUN_00b68960 */

undefined4 * __thiscall FUN_00b68960(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00a40b10;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24654 ; VA 0x00b68a20 ; FUN_00b68a20 */

undefined4 * __thiscall FUN_00b68a20(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5898;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_00b6d080;
    puVar2[3] = FUN_00b6d1b0;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar2[6] = *param_3;
    puVar2[7] = param_3[1];
    puVar2[8] = param_3[2];
    puVar2[9] = param_3[3];
    FUN_0054ef60(param_3 + 4);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24655 ; VA 0x00b68b20 ; FUN_00b68b20 */

undefined4 * __thiscall FUN_00b68b20(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5898;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar2 = (undefined4 *)FUN_01674e20(0x40);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_00b6d100;
    puVar2[3] = FUN_00b6d1b0;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar2[6] = *param_3;
    puVar2[7] = param_3[1];
    puVar2[8] = param_3[2];
    puVar2[9] = param_3[3];
    FUN_0054ef60(param_3 + 4);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24656 ; VA 0x00b68c20 ; FUN_00b68c20 */

undefined4 FUN_00b68c20(undefined4 param_1,undefined4 param_2)

{
  FUN_00b6d300(param_1,param_2);
  return param_1;
}



/* FUNCTION 24657 ; VA 0x00b68c40 ; FUN_00b68c40 */

int * FUN_00b68c40(int *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f58ca;
  pvStack_10 = ExceptionList;
  uStack_2c = 0x140;
  piStack_30 = (int *)0xb68c68;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20();
  uStack_8 = 0;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count_obj<class_RBX::AnalyticsServiceJob>::vftable;
    uStack_2c = 4;
    uVar1 = *param_2;
    uVar5 = FUN_008f7870(uVar1);
    FUN_005c4330(&uStack_34,uVar5);
    FUN_00a360a0("AnalyticsServiceJob",1,0);
    piStack_30 = piVar4 + 0x4e;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar4[4] = (int)RBX::AnalyticsServiceJob::vftable;
    uStack_34 = 0xb68cd6;
    uStack_2c = uVar1;
    FUN_0060e0c0();
  }
  piVar2 = piVar4 + 4;
  *param_1 = (int)piVar2;
  param_1[1] = (int)piVar4;
  if ((piVar2 != (int *)0x0) && ((piVar4[7] == 0 || (*(int *)(piVar4[7] + 4) == 0)))) {
    piVar6 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar6 = (int *)param_1[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
      }
    }
    piVar4[6] = (int)piVar2;
    piVar2 = (int *)piVar4[7];
    piVar4[7] = (int)piVar6;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        uStack_2c = 0xb68d2d;
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar3 = piVar6[1] + -1;
      piVar6[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        uStack_2c = 0xb68d40;
        (**(code **)*piVar6)();
        LOCK();
        piVar4 = piVar6 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          uStack_2c = 0xb68d4f;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24658 ; VA 0x00b68d70 ; thunk_FUN_00b73400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b73400(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6c66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef09f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef09f4);
    if (DAT_01ef09f4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsEconomyAction");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef0990 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsEconomyAction>::vftable;
      FUN_009caf20(&DAT_01d675cc,3);
      FUN_016f3654(&LAB_0188f8a0);
      FUN_016f37bf(&DAT_01ef09f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef0990;
}



/* FUNCTION 24659 ; VA 0x00b68d80 ; thunk_FUN_00b734b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b734b0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6c86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0924) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef0924);
    if (DAT_01ef0924 == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsLogLevel");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef08c0 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsLogLevel>::vftable;
      FUN_009caf20(&DAT_01d6760c,6);
      FUN_016f3654(&LAB_0188f8c0);
      FUN_016f37bf(&DAT_01ef0924);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef08c0;
}



/* FUNCTION 24660 ; VA 0x00b68d90 ; thunk_FUN_00b73560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b73560(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6ca6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef098c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef098c);
    if (DAT_01ef098c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AnalyticsProgressionStatus");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef0928 =
           RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsProgressionStatus>::
           vftable;
      FUN_009caf20(&DAT_01d675e4,5);
      FUN_016f3654(&LAB_0188f8e0);
      FUN_016f37bf(&DAT_01ef098c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef0928;
}



/* FUNCTION 24661 ; VA 0x00b68da0 ; FUN_00b68da0 */

undefined4 FUN_00b68da0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b68f1d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b68f1d;
  }
  iVar2 = FUN_00b73400();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b68ec8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b73400();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b67c90(&param_3);
      iVar4 = FUN_00b73400();
      iStack_ec = iVar4;
      iVar5 = FUN_00b73400();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b68ec8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b73400();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 24662 ; VA 0x00b68fa0 ; FUN_00b68fa0 */

undefined4 FUN_00b68fa0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b6911d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b6911d;
  }
  iVar2 = FUN_00b734b0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b690c8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b734b0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b67ce0(&param_3);
      iVar4 = FUN_00b734b0();
      iStack_ec = iVar4;
      iVar5 = FUN_00b734b0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b690c8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b734b0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 24663 ; VA 0x00b691a0 ; FUN_00b691a0 */

undefined4 FUN_00b691a0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b6931d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b6931d;
  }
  iVar2 = FUN_00b73560();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b692c8;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b73560();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b67d30(&param_3);
      iVar4 = FUN_00b73560();
      iStack_ec = iVar4;
      iVar5 = FUN_00b73560();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b692c8:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b73560();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 24664 ; VA 0x00b693a0 ; FUN_00b693a0 */

undefined4 * __thiscall FUN_00b693a0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f58f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  uStack_8 = 1;
  FUN_005c4580(param_2 + 5);
  param_1[0xb] = param_2[0xb];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24665 ; VA 0x00b69450 ; FUN_00b69450 */

undefined4 * __thiscall
FUN_00b69450(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 *param_14)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 in_stack_00000100;
  undefined4 *in_stack_00000104;
  undefined4 *in_stack_000001d0;
  undefined8 in_stack_000001d4;
  undefined4 in_stack_000001dc;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5992;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b67d80();
  FUN_009cb790(uVar1,param_4,in_stack_000001d0,in_stack_000001d4,in_stack_000001dc);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::AnalyticsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::AnalyticsService::AnalyticsEconomyAction,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,class_RBX::Reflection::Variant),8>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  uStack_8._0_1_ = 7;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 8;
  in_stack_000001d0 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000100;
    puVar2[1] = 0;
    if (in_stack_00000104 != (undefined4 *)0x0) {
      (*(code *)*in_stack_00000104)();
    }
    puVar2[1] = in_stack_00000104;
  }
  param_1[0x16] = puVar2;
  uStack_8._0_1_ = 9;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 10;
  in_stack_000001d0 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_13;
    puVar2[1] = 0;
    if (param_14 != (undefined4 *)0x0) {
      (*(code *)*param_14)();
    }
    puVar2[1] = param_14;
  }
  param_1[0x17] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_00b6bcc0(param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12);
  uStack_8 = 0xc;
  if (in_stack_00000104 != (undefined4 *)0x0) {
    (*(code *)in_stack_00000104[2])(&stack0x00000108);
  }
  uStack_8 = 0xd;
  if (param_14 != (undefined4 *)0x0) {
    (*(code *)param_14[2])(&stack0x00000038);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24666 ; VA 0x00b69600 ; FUN_00b69600 */

undefined4 * __thiscall
FUN_00b69600(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 *param_12)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 in_stack_000000f8;
  undefined4 *in_stack_000000fc;
  undefined4 in_stack_000001c8;
  undefined4 *in_stack_000001cc;
  undefined4 in_stack_00000298;
  undefined8 in_stack_0000029c;
  undefined4 in_stack_000002a4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5a31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b67d80();
  FUN_009cb790(uVar1,param_4,in_stack_00000298,in_stack_0000029c,in_stack_000002a4);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::AnalyticsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::AnalyticsService::AnalyticsProgressionStatus,class_RBX::Reflection::Variant,class_RBX::Reflection::Variant,class_RBX::Reflection::Variant),6>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 5;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_000001c8;
    puVar2[1] = 0;
    if (in_stack_000001cc != (undefined4 *)0x0) {
      (*(code *)*in_stack_000001cc)();
    }
    puVar2[1] = in_stack_000001cc;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 6;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_000000f8;
    puVar2[1] = 0;
    if (in_stack_000000fc != (undefined4 *)0x0) {
      (*(code *)*in_stack_000000fc)();
    }
    puVar2[1] = in_stack_000000fc;
  }
  param_1[0x14] = puVar2;
  uStack_8._0_1_ = 8;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 9;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_11;
    puVar2[1] = 0;
    if (param_12 != (undefined4 *)0x0) {
      (*(code *)*param_12)();
    }
    puVar2[1] = param_12;
  }
  param_1[0x15] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_00b6c4d0(param_5,param_6,param_7,param_8,param_9,param_10);
  FUN_00b6a190();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24667 ; VA 0x00b697c0 ; FUN_00b697c0 */

undefined4 * __thiscall
FUN_00b697c0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 *param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 in_stack_000000f4;
  undefined4 *in_stack_000000f8;
  undefined4 *in_stack_000001c4;
  undefined8 in_stack_000001c8;
  undefined4 in_stack_000001d0;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5ab1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b67d80();
  FUN_009cb790(uVar1,param_4,in_stack_000001c4,in_stack_000001c8,in_stack_000001d0);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::AnalyticsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AnalyticsService::AnalyticsLogLevel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,class_RBX::Reflection::Variant),5>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 5;
  in_stack_000001c4 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_000000f4;
    puVar2[1] = 0;
    if (in_stack_000000f8 != (undefined4 *)0x0) {
      (*(code *)*in_stack_000000f8)();
    }
    puVar2[1] = in_stack_000000f8;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 6;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 7;
  in_stack_000001c4 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = param_10;
    puVar2[1] = 0;
    if (param_11 != (undefined4 *)0x0) {
      (*(code *)*param_11)();
    }
    puVar2[1] = param_11;
  }
  param_1[0x14] = puVar2;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_00b6cae0(param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 9;
  if (in_stack_000000f8 != (undefined4 *)0x0) {
    (*(code *)in_stack_000000f8[2])(&stack0x000000fc);
  }
  uStack_8 = 10;
  if (param_11 != (undefined4 *)0x0) {
    (*(code *)param_11[2])(&stack0x0000002c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24668 ; VA 0x00b69960 ; FUN_00b69960 */

undefined4 * __thiscall FUN_00b69960(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 in_stack_00000014;
  int in_stack_00000018;
  uint in_stack_0000002c;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5ad0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&stack0x00000018);
  *param_1 = param_2;
  param_1[1] = in_stack_00000014;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(aiStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    iVar1 = aiStack_2c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_2c[0] + -4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  if (0xf < in_stack_0000002c) {
    uVar2 = in_stack_0000002c + 1;
    iVar1 = in_stack_00000018;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(in_stack_00000018 + -4);
      uVar2 = in_stack_0000002c + 0x24;
      if (0x1f < (in_stack_00000018 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24669 ; VA 0x00b69a30 ; FUN_00b69a30 */

undefined4 * __fastcall FUN_00b69a30(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5bd6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::AnalyticsService,class_RBX::ServiceInstance>::
             vftable;
  uVar2 = FUN_00b67d80();
  param_1[3] = uVar2;
  *param_1 = RBX::AnalyticsService::vftable;
  uStack_8 = 1;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  *(undefined *)(param_1 + 0x2a) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x2b] = uVar2;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0x3f800000;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  uStack_8._0_1_ = 0x10;
  FUN_016830f0(param_1 + 0x34);
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  puVar1 = param_1 + 0x3e;
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined *)(param_1 + 0x3a) = 0;
  param_1[0x3b] = 0;
  *(undefined8 *)(param_1 + 0x3c) = 0;
  *puVar1 = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  puStack_18 = puVar1;
  uVar2 = FUN_006d3cd0(0,0);
  param_1[0x3f] = uVar2;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  uStack_8._0_1_ = 0x12;
  *puVar1 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 0x13;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("AnalyticsService",0x10);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  FUN_008a6520(auStack_30);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    uVar3 = auStack_30[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_30[0] - 4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24670 ; VA 0x00b69c80 ; FUN_00b69c80 */

int __fastcall FUN_00b69c80(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_0056d080();
  piVar3 = *(int **)(param_1 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00b69cca. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 24671 ; VA 0x00b69ce0 ; FUN_00b69ce0 */

void __fastcall FUN_00b69ce0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x48);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24672 ; VA 0x00b69d90 ; FUN_00b69d90 */

void __fastcall FUN_00b69d90(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x5c);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar1,0xd0);
  }
  iVar1 = *(int *)(param_1 + 0x58);
  if (iVar1 != 0) {
    uStack_8 = 1;
    if (*(int *)(iVar1 + 4) != 0) {
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24673 ; VA 0x00b69ea0 ; FUN_00b69ea0 */

void __fastcall FUN_00b69ea0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar1,0xd0);
  }
  iVar1 = *(int *)(param_1 + 0x50);
  if (iVar1 != 0) {
    uStack_8 = 1;
    if (*(int *)(iVar1 + 4) != 0) {
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar1,0xd0);
  }
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 != 0) {
    uStack_8 = 2;
    if (*(int *)(iVar1 + 4) != 0) {
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  FUN_005c4ac0();
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24674 ; VA 0x00b69fd0 ; FUN_00b69fd0 */

void __fastcall FUN_00b69fd0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x50);
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar1 + 4) != 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar1,0xd0);
  }
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 != 0) {
    uStack_8 = 1;
    if (*(int *)(iVar1 + 4) != 0) {
      (**(code **)(*(int *)(iVar1 + 4) + 8))(iVar1 + 8);
    }
    FUN_01674ea0(iVar1,0xd0);
  }
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24675 ; VA 0x00b6a0c0 ; FUN_00b6a0c0 */

void __fastcall FUN_00b6a0c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::AnalyticsService>::vftable;
  uVar1 = FUN_00b67d80(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24676 ; VA 0x00b6a100 ; FUN_00b6a100 */

void __fastcall FUN_00b6a100(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00b6b5d0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x18);
  return;
}



/* FUNCTION 24677 ; VA 0x00b6a170 ; FUN_00b6a170 */

void __fastcall FUN_00b6a170(undefined4 *param_1)

{
  FUN_00b6b5d0();
  FUN_01674ea0(*param_1,0x18);
  return;
}



/* FUNCTION 24678 ; VA 0x00b6a190 ; FUN_00b6a190 */

void __fastcall FUN_00b6a190(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x1a4) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 0x1a4) + 8))(param_1 + 0x1a8);
  }
  uStack_8 = 1;
  if (*(int *)(param_1 + 0xd4) != 0) {
    (**(code **)(*(int *)(param_1 + 0xd4) + 8))(param_1 + 0xd8);
  }
  uStack_8 = 2;
  if (*(int *)(param_1 + 4) != 0) {
    (**(code **)(*(int *)(param_1 + 4) + 8))(param_1 + 8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24679 ; VA 0x00b6a220 ; FUN_00b6a220 */

void __fastcall FUN_00b6a220(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00b6b5d0();
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x18);
  return;
}



/* FUNCTION 24680 ; VA 0x00b6a230 ; FUN_00b6a230 */

void __fastcall FUN_00b6a230(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5be0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::AnalyticsService::vftable;
  FUN_00b6a100();
  FUN_0056d3e0();
  FUN_005d1280();
  uVar3 = param_1[0x29];
  if (0xf < uVar3) {
    iVar4 = param_1[0x24];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x28] = 0;
  param_1[0x29] = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0x23];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = param_1[0x22];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = param_1[0x21];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = param_1[0x20];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar4 = param_1[0x1f];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 5;
  FUN_01679490();
  iVar4 = param_1[0x1e];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 6;
  FUN_01679490();
  iVar4 = param_1[0x1d];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 7;
  FUN_01679490();
  iVar4 = param_1[0x1c];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 8;
  FUN_01679490();
  iVar4 = param_1[0x1b];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 9;
  FUN_01679490();
  iVar4 = param_1[0x1a];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x19];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x17];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24681 ; VA 0x00b6a530 ; FUN_00b6a530 */

int * __thiscall FUN_00b6a530(int param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  int *piVar9;
  int *piStack_10;
  uint *puStack_c;
  int iStack_8;
  
  uVar1 = *param_2;
  piVar2 = *(int **)(param_1 + 4);
  uVar8 = *(uint *)(param_1 + 0x18) &
          (((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193) * 0x1000193 ^
           uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193;
  piVar3 = *(int **)(*(int *)(param_1 + 0xc) + uVar8 * 8);
  piVar7 = piVar3;
  while( true ) {
    piVar9 = piVar2;
    if (piVar3 != piVar2) {
      piVar9 = (int *)**(undefined4 **)(*(int *)(param_1 + 0xc) + uVar8 * 8 + 4);
    }
    if (piVar7 == piVar9) goto LAB_00b6a5af;
    if (piVar7[2] == uVar1) break;
    piVar7 = (int *)*piVar7;
  }
  if (piVar7 == piVar2) {
LAB_00b6a5af:
    iVar4 = *piVar2;
    puStack_c = param_2;
    puVar5 = *(undefined4 **)(iVar4 + 4);
    iStack_8 = param_1;
    uVar6 = FUN_00b67ea0(iVar4,puVar5,&DAT_018bdeda,&puStack_c,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar4 + 4) = uVar6;
    *puVar5 = uVar6;
    FUN_00b67ef0(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    piVar7 = piStack_10;
  }
  return piVar7 + 4;
}



/* FUNCTION 24682 ; VA 0x00b6a620 ; FUN_00b6a620 */

int __thiscall FUN_00b6a620(int param_1,byte *param_2,int *param_3)

{
  byte bVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  char *pcVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  bool bVar14;
  undefined4 uVar15;
  undefined4 **ppuVar16;
  undefined4 uStack_21c;
  int iStack_218;
  undefined4 *puStack_214;
  undefined4 *puStack_210;
  int iStack_14c;
  int iStack_148;
  undefined4 *puStack_144;
  undefined4 *puStack_140;
  undefined auStack_7c [4];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  byte *pbStack_64;
  int iStack_60;
  int *piStack_5c;
  int iStack_58;
  undefined4 *puStack_54;
  undefined4 *puStack_50;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  char cStack_19;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5cd9;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffdd8;
  puStack_50 = (undefined4 *)0x0;
  puStack_18 = (undefined4 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_58 = param_1;
  iVar4 = FUN_00587490(&iStack_60);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_60 == 0) goto LAB_00b6af35;
  uStack_8._0_1_ = 2;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018d8974,4);
  uStack_8._0_1_ = 3;
  FUN_0091d440(auStack_4c);
  uVar5 = FUN_00563690(auStack_34);
  uStack_8._0_1_ = 4;
  FUN_005c4c00(&DAT_01d673c4);
  FUN_00632ce0(uVar5);
  uStack_8._0_1_ = 3;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_20) {
    uVar12 = uStack_20 + 1;
    uVar11 = auStack_34[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_34[0] - 4);
      uVar12 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar11) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_38) {
    uVar12 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar12 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("IsPublicDomain",0xe);
  bVar1 = *param_2;
  uVar5 = FUN_005702d0(auStack_4c);
  FUN_00562fc0(&puStack_18,uVar5,auStack_4c,
               -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
  bVar14 = puStack_18 != (undefined4 *)0x0;
  if (0xf < uStack_38) {
    uVar12 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar12 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  if (bVar14) {
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("IsPublicDomain",0xe);
    uStack_8._0_1_ = 5;
    piVar6 = (int *)FUN_0091d440(auStack_34);
    iVar4 = *piVar6;
    iVar7 = FUN_0088daf0();
    if (iVar4 == iVar7) {
      iVar4 = *piVar6;
      iVar7 = FUN_0088daf0();
      if (iVar4 != iVar7) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar8 = piVar6 + 2;
      if (piVar6[1] == 0) {
        piVar8 = (int *)0x0;
      }
      cVar3 = *(char *)piVar8;
    }
    else {
      iStack_14c = *piVar6;
      iStack_148 = 0;
      if ((undefined4 *)piVar6[1] != (undefined4 *)0x0) {
        (**(code **)piVar6[1])(piVar6 + 2,&puStack_144);
      }
      iStack_148 = piVar6[1];
      uStack_8._0_1_ = 6;
      pcVar9 = (char *)FUN_0088bcc0();
      cVar3 = *pcVar9;
      uStack_8._0_1_ = 7;
      if (iStack_148 != 0) {
        (**(code **)(iStack_148 + 8))(&puStack_144);
      }
    }
    uStack_8._0_1_ = 2;
    FUN_005507b0();
    if (cVar3 == '\x01') {
      iVar4 = FUN_005c4c00(&DAT_01d673f4);
      uVar5 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      FUN_005c17a0(&DAT_01d6740c);
      puStack_18 = (undefined4 *)0x0;
      FUN_005c4c00(&DAT_01d673dc);
      FUN_005c1740(&puStack_18);
    }
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("PriceInRobux",0xc);
  bVar1 = *param_2;
  uVar5 = FUN_005702d0(auStack_4c);
  FUN_00562fc0(&puStack_18,uVar5,auStack_4c,
               -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
  bVar14 = puStack_18 != (undefined4 *)0x0;
  if (0xf < uStack_38) {
    uVar12 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar12 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  if (bVar14) {
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("PriceInRobux",0xc);
    uStack_8._0_1_ = 8;
    piVar6 = (int *)FUN_0091d440(auStack_34);
    uStack_8._0_1_ = 2;
    cVar3 = *(char *)(*piVar6 + 0x21);
    FUN_005507b0();
    if (cVar3 != '\0') {
      iVar4 = FUN_005c4c00(&DAT_01d673f4);
      uVar5 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      FUN_005c17a0(&DAT_01d67424);
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
      FUN_005542c0("PriceInRobux",0xc);
      uStack_8._0_1_ = 9;
      FUN_0091d440(auStack_34);
      puStack_18 = (undefined4 *)FUN_00563070();
      FUN_005c4c00(&DAT_01d673dc);
      FUN_005c1740(&puStack_18);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
    }
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  FUN_005542c0("PriceInTickets",0xe);
  bVar1 = *param_2;
  uVar5 = FUN_005702d0(auStack_4c);
  ppuVar16 = &puStack_18;
  uVar15 = 0xb6aaa9;
  FUN_00562fc0(ppuVar16,uVar5,auStack_4c,
               -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
  bVar14 = puStack_18 != (undefined4 *)0x0;
  if (0xf < uStack_38) {
    uVar12 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar12 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar5 = 0xb6aae1;
    FUN_01674ea0(uVar11,uVar12);
  }
  if (bVar14) {
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    uVar5 = 0xb6ab10;
    FUN_005542c0("PriceInTickets",0xe);
    uStack_8._0_1_ = 10;
    piVar6 = (int *)FUN_0091d440(auStack_34);
    uStack_8._0_1_ = 2;
    cVar3 = *(char *)(*piVar6 + 0x21);
    FUN_005507b0();
    if (cVar3 != '\0') {
      iVar4 = FUN_005c4c00(&DAT_01d673f4);
      uVar5 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar5;
      FUN_005c17a0(&DAT_01d6743c);
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
      uVar5 = 0xb6ab7f;
      FUN_005542c0("PriceInTickets",0xe);
      uStack_8._0_1_ = 0xb;
      FUN_0091d440(auStack_34);
      puStack_18 = (undefined4 *)FUN_00563070();
      FUN_005c4c00(&DAT_01d673dc);
      FUN_005c1740(&puStack_18);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
    }
  }
  puVar13 = puStack_50;
  if (*(int *)(iStack_58 + 0x2c) == 0) {
    pbStack_64 = param_2;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    FUN_005542c0("ProductType",0xb);
    bVar1 = *param_2;
    uStack_8._0_1_ = 0xc;
    puStack_18 = (undefined4 *)0x1;
    uVar5 = FUN_005702d0(auStack_4c);
    ppuVar16 = &puStack_50;
    uVar15 = 0xb6ac28;
    FUN_00562fc0(ppuVar16,uVar5,auStack_4c,
                 -(uint)(param_2 + bVar1 + 1 != (byte *)0x0) & (uint)(param_2 + bVar1 + 1 + 1));
    puVar13 = (undefined4 *)0x1;
    if (puStack_50 == (undefined4 *)0x0) goto LAB_00b6ac80;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    uVar5 = 0xb6ac52;
    FUN_005542c0("ProductType",0xb);
    uStack_8._0_1_ = 0xd;
    uStack_8._1_3_ = 0;
    puVar13 = (undefined4 *)0x3;
    puStack_18 = (undefined4 *)0x3;
    piVar6 = (int *)FUN_0091d440(auStack_34);
    iVar4 = *piVar6;
    iVar7 = FUN_0088cb40();
    if (iVar4 != iVar7) goto LAB_00b6ac80;
    cStack_19 = '\x01';
  }
  else {
LAB_00b6ac80:
    cStack_19 = '\0';
  }
  if (((uint)puVar13 & 2) != 0) {
    puVar13 = (undefined4 *)((uint)puVar13 & 0xfffffffd);
    FUN_005507b0();
  }
  uStack_8 = 2;
  if (((uint)puVar13 & 1) != 0) {
    FUN_005507b0();
  }
  if (cStack_19 != '\0') {
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("ProductType",0xb);
    uStack_8._0_1_ = 0xe;
    FUN_0091d440(auStack_34);
    FUN_00563690(auStack_4c);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    FUN_005507b0();
    uVar5 = 0xb6ad0a;
    cVar3 = FUN_00558b30(auStack_4c,&DAT_01d67544);
    if (cVar3 != '\0') {
      iVar4 = FUN_005c4c00(&DAT_01d67394);
      uVar10 = FUN_0088cb40();
      *(undefined4 *)(iVar4 + 0x18) = uVar10;
      FUN_005c17a0(&DAT_01d67544);
    }
    FUN_005507b0();
  }
  auStack_7c[0] = 0;
  uStack_78 = FUN_00588320(0xb);
  uStack_74 = 0;
  uStack_70 = 0x3f800000;
  uStack_6c = 0;
  uStack_68 = 0;
  piVar6 = (int *)(iStack_58 + 8);
  uStack_8._0_1_ = 0x11;
  FUN_00b6e320(piVar6,auStack_7c,0,uVar15,ppuVar16,uVar5,0,0xf);
  puVar13 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8._0_1_ = 0x12;
  if (puVar13 == (undefined4 *)0x0) {
    puVar13 = (undefined4 *)0x0;
  }
  else {
    puVar13[1] = 1;
    puVar13[2] = 1;
    *puVar13 = std::
               _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
               ::vftable;
    puStack_50 = puVar13;
    FUN_005c4580(param_1 + 0x14);
  }
  uStack_8._0_1_ = 0x13;
  puStack_54 = puVar13 + 3;
  puStack_50 = puVar13;
  iStack_14c = FUN_008881d0();
  iStack_148 = 0;
  puStack_54 = (undefined4 *)0x0;
  puStack_50 = (undefined4 *)0x0;
  puStack_144 = puVar13 + 3;
  puStack_140 = puVar13;
  iStack_148 = FUN_005ea820();
  uStack_8._0_1_ = 0x14;
  FUN_005c4c00(&DAT_01d67514);
  FUN_00947a40(&iStack_14c);
  uStack_8._0_1_ = 0x15;
  if (iStack_148 != 0) {
    (**(code **)(iStack_148 + 8))(&puStack_144);
  }
  uStack_8._0_1_ = 0x11;
  uVar5 = *(undefined4 *)(iStack_58 + 0x10);
  iVar4 = FUN_005c4c00(&DAT_01d674b4);
  uVar15 = FUN_0088cb40();
  *(undefined4 *)(iVar4 + 0x18) = uVar15;
  FUN_005c17a0(uVar5);
  puVar13 = (undefined4 *)FUN_01674e20(0x24);
  uStack_8._0_1_ = 0x16;
  if (puVar13 == (undefined4 *)0x0) {
    puVar13 = (undefined4 *)0x0;
  }
  else {
    puVar13[1] = 1;
    puVar13[2] = 1;
    *puVar13 = std::
               _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
               ::vftable;
    puStack_50 = puVar13;
    FUN_005c4580(auStack_7c);
  }
  uStack_8._0_1_ = 0x17;
  puStack_54 = puVar13 + 3;
  puStack_50 = puVar13;
  uStack_21c = FUN_008881d0();
  iStack_218 = 0;
  puStack_214 = puVar13 + 3;
  puStack_210 = puVar13;
  iStack_218 = FUN_005ea820();
  uStack_8._0_1_ = 0x19;
  (**(code **)(**(int **)(iStack_60 + 0x58) + 0x10))
            (*(undefined4 *)(*piVar6 + 0x28),*(undefined4 *)(iStack_58 + 0x10),&uStack_21c);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
  if (iStack_218 != 0) {
    (**(code **)(iStack_218 + 8))(&puStack_214);
  }
  iVar4 = FUN_0056d080();
LAB_00b6af35:
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piVar6 = piStack_5c + 1;
    iVar7 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar6 = piStack_5c + 2;
      iVar7 = *piVar6;
      iVar4 = *piVar6;
      *piVar6 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar7 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 24683 ; VA 0x00b6af96 ; Catch@00b6af96 */

undefined4 Catch_00b6af96(void)

{
  int iVar1;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x20) = 0;
  *(undefined4 *)(unaff_EBP + -0x1c) = 0xf;
  *(undefined *)(unaff_EBP + -0x30) = 0;
  FUN_005542c0("AnalyticsService.ParseProductInfoError",0x26);
  *(undefined *)(unaff_EBP + -4) = 0x1c;
  iVar1 = FUN_005d1470(unaff_EBP + -0x30);
  *(int *)(iVar1 + 0x18) = *(int *)(iVar1 + 0x18) + 1;
  FUN_005507b0();
  return 0xb6af35;
}



/* FUNCTION 24684 ; VA 0x00b6b010 ; FUN_00b6b010 */

undefined4 __thiscall FUN_00b6b010(undefined4 param_1,byte param_2)

{
  FUN_00b69ce0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 24685 ; VA 0x00b6b040 ; FUN_00b6b040 */

undefined4 __thiscall FUN_00b6b040(undefined4 param_1,byte param_2)

{
  FUN_00b69d90();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 24686 ; VA 0x00b6b070 ; FUN_00b6b070 */

undefined4 __thiscall FUN_00b6b070(undefined4 param_1,byte param_2)

{
  FUN_00b69ea0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 24687 ; VA 0x00b6b0a0 ; FUN_00b6b0a0 */

undefined4 __thiscall FUN_00b6b0a0(undefined4 param_1,byte param_2)

{
  FUN_00b69fd0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 24688 ; VA 0x00b6b0d0 ; FUN_00b6b0d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b6b0d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsEconomyAction>::vftable;
  _DAT_01ef08a8 = _DAT_01ef08a8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24689 ; VA 0x00b6b100 ; FUN_00b6b100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b6b100(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsLogLevel>::vftable;
  _DAT_01ef08b8 = _DAT_01ef08b8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24690 ; VA 0x00b6b130 ; FUN_00b6b130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b6b130(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::AnalyticsService::AnalyticsProgressionStatus>::
             vftable;
  _DAT_01ef08b0 = _DAT_01ef08b0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 24691 ; VA 0x00b6b160 ; FUN_00b6b160 */

undefined4 __thiscall FUN_00b6b160(undefined4 param_1,byte param_2)

{
  FUN_00b6a230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x118);
  }
  return param_1;
}



/* FUNCTION 24692 ; VA 0x00b6b190 ; FUN_00b6b190 */

void __thiscall FUN_00b6b190(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar2 = (int *)param_2[3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_2,0x18);
  return;
}



/* FUNCTION 24693 ; VA 0x00b6b1f0 ; FUN_00b6b1f0 */

int * __thiscall FUN_00b6b1f0(int param_1,int *param_2,undefined4 param_3,int *param_4,char param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f5f60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562c90(&iStack_18,&param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    if (param_5 != '\0') {
      pcVar5 = "AnalyticsService: player must be a Player object.";
LAB_00b6b23c:
      FUN_0086f2f0(3,pcVar5);
    }
  }
  else {
    if (param_1 == 0) {
LAB_00b6b2de:
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(param_1 + 0x34);
      if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
        param_1 = FUN_005c8ac0();
      }
      if ((param_1 == 0) ||
         (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar3 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) goto LAB_00b6b2de;
      iVar4 = FUN_005cf750();
    }
    if (*(int *)(iStack_18 + 0x34) == iVar4) {
      *param_2 = iStack_18;
      param_2[1] = (int)piStack_14;
      piVar2 = param_4;
      goto joined_r0x00b6b30c;
    }
    if (param_5 != '\0') {
      pcVar5 = "AnalyticsService: player must be a child of \'Players\'.";
      goto LAB_00b6b23c;
    }
  }
  param_2[1] = 0;
  *param_2 = 0;
  piVar2 = param_4;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      piVar2 = param_4;
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
        piVar2 = param_4;
      }
    }
  }
joined_r0x00b6b30c:
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      param_4 = piVar2;
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24694 ; VA 0x00b6b350 ; FUN_00b6b350 */

undefined4 __thiscall FUN_00b6b350(int param_1,undefined4 *param_2,undefined4 param_3)

{
  uint uVar1;
  undefined *puVar2;
  char cVar3;
  byte *pbVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  bool bVar9;
  char *pcVar10;
  undefined auStack_34 [16];
  uint uStack_24;
  undefined4 uStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5f78;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  if (*(int *)(param_1 + 0x58) == 0) {
    return 0;
  }
  iStack_18 = param_1;
  if (*(int *)(*(int *)(param_1 + 0x58) + 0x10) == 2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffc0;
    FUN_0086f2f0(3,"AnalyticsService: The ApiKey is invalid.");
    ExceptionList = pvStack_10;
    return 0;
  }
  if (DAT_01d67574 == '\0') {
    uVar1 = param_2[4];
    if (uVar1 == 0) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffc0;
      FUN_0086f2f0(3,"AnalyticsService: The event category is empty.");
      ExceptionList = pvStack_10;
      return 0;
    }
    if (DAT_01d67148 < uVar1) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffc0;
      FUN_0086f2f0(3,"AnalyticsService: The event category is too long.");
      ExceptionList = pvStack_10;
      return 0;
    }
    uVar5 = param_2[5];
    puVar8 = param_2;
    if (0xf < uVar5) {
      puVar8 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffc0;
    if (uVar1 != 0) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170db20(puVar8,0x2c,uVar1);
      if ((iVar6 != 0) && (iVar6 - (int)puVar8 != -1)) goto LAB_00b6b52f;
      uVar5 = param_2[5];
      puVar2 = puStack_14;
    }
    puStack_14 = puVar2;
    puVar8 = param_2;
    if (0xf < uVar5) {
      puVar8 = (undefined4 *)*param_2;
    }
    if (uVar1 != 0) {
      iVar6 = FUN_0170db20(puVar8,0x22,uVar1);
      if ((iVar6 != 0) && (iVar6 - (int)puVar8 != -1)) {
LAB_00b6b52f:
        FUN_0086f2f0(3,"AnalyticsService: \',\', \'\"\' and \'\\r\\n\' are not allowed in category."
                    );
        ExceptionList = pvStack_10;
        return 0;
      }
      uVar5 = param_2[5];
    }
    if (0xf < uVar5) {
      param_2 = (undefined4 *)*param_2;
    }
    param_1 = iStack_18;
    if (1 < uVar1) {
      pbVar4 = (byte *)FUN_0170db20(param_2,0xd,uVar1 - 1);
      param_1 = iStack_18;
      while (iStack_18 = param_1, pbVar4 != (byte *)0x0) {
        bVar9 = *pbVar4 < 0xd;
        if ((*pbVar4 == 0xd) && (bVar9 = pbVar4[1] < 10, pbVar4[1] == 10)) {
          uVar5 = 0;
        }
        else {
          uVar5 = -(uint)bVar9 | 1;
        }
        if (uVar5 == 0) {
          if ((int)pbVar4 - (int)param_2 != -1) goto LAB_00b6b52f;
          break;
        }
        pbVar4 = (byte *)FUN_0170db20(pbVar4 + 1,0xd,
                                      (int)param_2 + ((uVar1 - 1) - (int)(pbVar4 + 1)));
        param_1 = iStack_18;
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffc0;
    cVar3 = FUN_00b708c0(param_2);
    if (cVar3 == '\0') {
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      FUN_0086f2f0(3,"AnalyticsService: Invalid event name [%s].",param_2);
      ExceptionList = pvStack_10;
      return 0;
    }
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = 0;
  uStack_8 = 1;
  cVar3 = FUN_0098fc00(param_3,auStack_34,1);
  if (cVar3 == '\0') {
    pcVar10 = "AnalyticsService can only accept valid UTF-8 characters.";
  }
  else {
    uStack_8 = 0;
    if (DAT_01d67140 < uStack_24) {
      pcVar10 = "AnalyticsService: The event value you fired is too long.";
    }
    else {
      iVar6 = *(uint *)(param_1 + 0xd8) - uStack_24;
      iVar7 = *(int *)(param_1 + 0xdc) - (uint)(*(uint *)(param_1 + 0xd8) < uStack_24);
      if ((0 < iVar7) || ((-1 < iVar7 && (iVar6 != 0)))) {
        *(int *)(param_1 + 0xdc) = iVar7;
        *(int *)(param_1 + 0xd8) = iVar6;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      pcVar10 = "AnalyticsService: You have sent too many data.";
    }
  }
  FUN_0086f2f0(3,pcVar10);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24695 ; VA 0x00b6b5a4 ; Catch@00b6b5a4 */

undefined4 Catch_00b6b5a4(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(3,"AnalyticsService failed in serializing event value. Error:[%s]",uVar1);
  return 0xb6b50b;
}



/* FUNCTION 24696 ; VA 0x00b6b5d0 ; FUN_00b6b5d0 */

void __fastcall FUN_00b6b5d0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = (int *)*param_1;
  piVar4 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar4 != (int *)*param_1) {
    do {
      piVar1 = (int *)piVar4[3];
      piVar2 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x18);
      piVar4 = piVar2;
    } while (piVar2 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 24697 ; VA 0x00b6b640 ; FUN_00b6b640 */

void FUN_00b6b640(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b73400();
    *param_2 = uVar3;
    iVar4 = FUN_00b73610();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24698 ; VA 0x00b6b6a0 ; FUN_00b6b6a0 */

void FUN_00b6b6a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b734b0();
    *param_2 = uVar3;
    iVar4 = FUN_00b73680();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24699 ; VA 0x00b6b700 ; FUN_00b6b700 */

void FUN_00b6b700(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b73560();
    *param_2 = uVar3;
    iVar4 = FUN_00b736f0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 24700 ; VA 0x00b6b760 ; FUN_00b6b760 */

void FUN_00b6b760(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b73400();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24701 ; VA 0x00b6b7a0 ; FUN_00b6b7a0 */

void FUN_00b6b7a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b734b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24702 ; VA 0x00b6b7e0 ; FUN_00b6b7e0 */

void FUN_00b6b7e0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b73560();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24703 ; VA 0x00b6b820 ; FUN_00b6b820 */

undefined4 * FUN_00b6b820(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671280(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24704 ; VA 0x00b6b890 ; FUN_00b6b890 */

undefined4 * __fastcall FUN_00b6b890(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  code *pcVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined1 *puStack_44;
  uint *puStack_40;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0060dcd0(&puStack_44,param_1);
  puVar7 = (undefined4 *)FUN_01005d00(auStack_18,1);
  uVar3 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *(undefined4 *)(param_1 + 0x58) = uVar3;
  piVar5 = *(int **)(param_1 + 0x5c);
  *(undefined4 *)(param_1 + 0x5c) = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    puVar7 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_40 = (uint *)0xb6b8fe;
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      puVar7 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_40 = (uint *)0xb6b90e;
        puVar7 = (undefined4 *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar2 = *piVar5;
    puVar7 = (undefined4 *)*piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_40 = (uint *)0xb6b924;
      puVar7 = (undefined4 *)(**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_40 = (uint *)0xb6b933;
        puVar7 = (undefined4 *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (*(int **)(param_1 + 0x58) != (int *)0x0) {
    puStack_40 = (uint *)0x0;
    puStack_44 = &DAT_018bc9b8;
    uStack_20 = 0;
    pcVar6 = *(code **)(**(int **)(param_1 + 0x58) + 4);
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0();
    puStack_40 = auStack_30;
    uStack_8 = 0;
    puStack_44 = (undefined1 *)0xb6b96f;
    puVar7 = (undefined4 *)(*pcVar6)();
    if (0xf < uStack_1c) {
      puStack_44 = (undefined1 *)(uStack_1c + 1);
      uVar8 = auStack_30[0];
      if ((undefined1 *)0xfff < puStack_44) {
        uVar8 = *(uint *)(auStack_30[0] - 4);
        puStack_44 = (undefined1 *)(uStack_1c + 0x24);
        if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_44 = &UNK_00b6b9b5;
          FUN_017167a3();
        }
      }
      puVar7 = (undefined4 *)FUN_01674ea0(uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return puVar7;
}



/* FUNCTION 24705 ; VA 0x00b6b9c0 ; FUN_00b6b9c0 */

void __thiscall FUN_00b6b9c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1ec8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = *puVar4;
    puStack_288 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_284);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
    puStack_288 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24706 ; VA 0x00b6bcc0 ; FUN_00b6bcc0 */

void __thiscall
FUN_00b6bcc0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f617d;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    puStack_e8 = (undefined4 *)0x0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar1);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_00b73400();
    puStack_e8 = (undefined4 *)0x0;
    auStack_e4[0] = *puVar4;
    puStack_e8 = (undefined4 *)FUN_00b73610();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00b73400();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar1);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    puStack_e8 = (undefined4 *)0x0;
    auStack_e4[0] = *puVar4;
    puStack_e8 = (undefined4 *)FUN_005c9cc0();
    puVar4 = &uStack_ec;
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x100) != 0) {
    uVar6 = uVar6 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x54);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0x15;
    uVar6 = uVar6 | 0x800;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar1);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 0x14;
    uVar6 = uVar6 | 0x400;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x800) != 0) {
    uVar6 = uVar6 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x400) != 0) {
    uVar6 = uVar6 & 0xfffffbff;
    uStack_8 = 0x17;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x58);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0x19;
    uVar6 = uVar6 | 0x2000;
  }
  else {
    uStack_ec = *puVar4;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_e4);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_ec;
    uStack_8 = 0x18;
    uVar6 = uVar6 | 0x1000;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_8);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x2000) != 0) {
    uVar6 = uVar6 & 0xffffdfff;
    uStack_8 = 0x1a;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x1000) != 0) {
    uVar6 = uVar6 & 0xffffefff;
    uStack_8 = 0x1b;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x5c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0x1d;
    uVar6 = uVar6 | 0x8000;
  }
  else {
    uStack_28c = *puVar4;
    puStack_288 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_284);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_28c;
    uStack_8 = 0x1c;
    uVar6 = uVar6 | 0x4000;
    puStack_288 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_9);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x8000) != 0) {
    uVar6 = uVar6 & 0xffff7fff;
    uStack_8 = 0x1e;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x4000) != 0) && (uStack_8 = 0x1f, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24707 ; VA 0x00b6c4d0 ; FUN_00b6c4d0 */

void __thiscall
FUN_00b6c4d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f62f9;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    puStack_e8 = (undefined4 *)0x0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar1);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_00b73560();
    puStack_e8 = (undefined4 *)0x0;
    auStack_e4[0] = *puVar4;
    puStack_e8 = (undefined4 *)FUN_00b736f0();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00b73560();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_ec = *puVar4;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_e4);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_ec;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    uStack_ec = *puVar4;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_e4);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_ec;
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x100) != 0) {
    uVar6 = uVar6 & 0xfffffeff;
    uStack_8 = 0x13;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x54);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0x15;
    uVar6 = uVar6 | 0x800;
  }
  else {
    uStack_28c = *puVar4;
    puStack_288 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_284);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_28c;
    uStack_8 = 0x14;
    uVar6 = uVar6 | 0x400;
    puStack_288 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x800) != 0) {
    uVar6 = uVar6 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x400) != 0) && (uStack_8 = 0x17, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24708 ; VA 0x00b6cae0 ; FUN_00b6cae0 */

void __thiscall
FUN_00b6cae0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6437;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    puStack_e8 = (undefined4 *)0x0;
    puStack_18 = &uStack_ec;
    uVar6 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar6;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_00b734b0();
    puStack_e8 = (undefined4 *)0x0;
    auStack_e4[0] = *puVar4;
    puStack_e8 = (undefined4 *)FUN_00b73680();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00b734b0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x48);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_ec = FUN_0088cb40();
    puStack_e8 = (undefined4 *)0x0;
    FUN_0054ef60(iVar1);
    puStack_e8 = (undefined4 *)FUN_005c9d30();
    puVar4 = &uStack_ec;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x10) != 0) {
    uVar6 = uVar6 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 0xd;
    uVar6 = uVar6 | 0x80;
  }
  else {
    uStack_ec = *puVar4;
    puStack_e8 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_e4);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_ec;
    uStack_8 = 0xc;
    uVar6 = uVar6 | 0x40;
    puStack_e8 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar6 < '\0') {
    uVar6 = uVar6 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 0x40) != 0) {
    uVar6 = uVar6 & 0xffffffbf;
    uStack_8 = 0xf;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 0x11;
    uVar6 = uVar6 | 0x200;
  }
  else {
    uStack_28c = *puVar4;
    puStack_288 = (undefined4 *)0x0;
    puVar5 = (undefined4 *)puVar4[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(puVar4 + 2,auStack_284);
      puVar5 = (undefined4 *)puVar4[1];
    }
    puVar4 = &uStack_28c;
    uStack_8 = 0x10;
    uVar6 = uVar6 | 0x100;
    puStack_288 = puVar5;
  }
  uStack_14 = uVar6;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar6 & 0x200) != 0) {
    uVar6 = uVar6 & 0xfffffdff;
    uStack_8 = 0x12;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x100) != 0) && (uStack_8 = 0x13, puStack_288 != (undefined4 *)0x0)) {
    (*(code *)puStack_288[2])(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24709 ; VA 0x00b6cfe0 ; FUN_00b6cfe0 */

int FUN_00b6cfe0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6460;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))(&param_2,&param_4);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 24710 ; VA 0x00b6d080 ; FUN_00b6d080 */

int FUN_00b6d080(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))
                    (&param_2,param_4,param_5,*(undefined4 *)(param_1 + 0x24),param_1 + 0x28);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 24711 ; VA 0x00b6d100 ; FUN_00b6d100 */

int FUN_00b6d100(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))
                    (&param_2,param_4,param_5,param_6,*(undefined4 *)(param_1 + 0x24),param_1 + 0x28
                    );
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 24712 ; VA 0x00b6d180 ; FUN_00b6d180 */

void FUN_00b6d180(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  (**(code **)(param_1 + 0x18))
            (param_2,param_3,param_4,param_5,param_6,*(undefined4 *)(param_1 + 0x24),param_1 + 0x28)
  ;
  return;
}



/* FUNCTION 24713 ; VA 0x00b6d1b0 ; FUN_00b6d1b0 */

void FUN_00b6d1b0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  return;
}



/* FUNCTION 24714 ; VA 0x00b6d210 ; FUN_00b6d210 */

void FUN_00b6d210(undefined4 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_005d1470(param_1);
  *(int *)(iVar1 + 0x18) = *(int *)(iVar1 + 0x18) + param_2;
  return;
}



/* FUNCTION 24715 ; VA 0x00b6d230 ; FUN_00b6d230 */

void __thiscall FUN_00b6d230(int param_1,undefined4 param_2,undefined8 param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6478;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_18 = param_3;
  piVar1 = *(int **)(param_1 + 0xc4);
  uStack_8 = 0;
  if (*(int **)(param_1 + 200) != piVar1) {
    *piVar1 = iStack_30;
    piVar1[1] = iStack_2c;
    piVar1[2] = iStack_28;
    piVar1[3] = iStack_24;
    *(ulonglong *)(piVar1 + 4) = CONCAT44(uStack_1c,uStack_20);
    *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 0x20;
    *(undefined8 *)(piVar1 + 6) = param_3;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00603540(piVar1,&iStack_30);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar2 = iStack_30;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iStack_30 + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (iStack_30 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24716 ; VA 0x00b6d300 ; FUN_00b6d300 */

undefined4 __thiscall FUN_00b6d300(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  uVar2 = param_3[2];
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((uVar2 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar2 >> 8 & 0xff) * 0x1000193 ^
           uVar2 >> 0x10 & 0xff) * 0x1000193 ^ uVar2 >> 0x18) * 0x1000193) * 8;
  puVar3 = *(undefined4 **)(*(int *)(param_1 + 0xc) + iVar1);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((undefined4 *)puVar4[1] == param_3) {
    if (puVar3 == param_3) {
      *puVar4 = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) = *(undefined4 *)(param_1 + 4);
    }
    else {
      puVar4[1] = param_3[1];
    }
  }
  else if (puVar3 == param_3) {
    *puVar4 = *param_3;
  }
  FUN_00b6d5d0(param_2,param_3);
  return param_2;
}



/* FUNCTION 24717 ; VA 0x00b6d3a0 ; FUN_00b6d3a0 */

int __thiscall FUN_00b6d3a0(int param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  piVar2 = *(int **)(param_1 + 4);
  uVar7 = *(uint *)(param_1 + 0x18) &
          ((((uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar1 >> 8 & 0xff) * 0x1000193 ^
           uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193;
  iVar3 = *(int *)(param_1 + 0xc);
  piVar4 = *(int **)(iVar3 + uVar7 * 8);
  iVar10 = uVar7 * 8 + 4;
  piVar8 = piVar4;
  while( true ) {
    piVar5 = piVar2;
    if (piVar4 != piVar2) {
      piVar5 = (int *)**(undefined4 **)(iVar3 + iVar10);
    }
    if (piVar8 == piVar5) goto LAB_00b6d48a;
    piVar5 = piVar8;
    if (piVar8[2] == uVar1) break;
    piVar8 = (int *)*piVar8;
  }
  while( true ) {
    piVar6 = piVar2;
    if (piVar4 != piVar2) {
      piVar6 = (int *)**(undefined4 **)(iVar3 + iVar10);
    }
    if ((piVar5 == piVar6) || (uVar1 != piVar5[2])) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar8 == piVar5) {
LAB_00b6d48a:
    piVar8 = piVar2;
    piVar5 = piVar2;
  }
  iVar10 = 0;
  for (piVar4 = piVar8; piVar4 != piVar5; piVar4 = (int *)*piVar4) {
    iVar10 = iVar10 + 1;
  }
  if ((piVar8 == (int *)*piVar2) && (piVar5 == piVar2)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00b6b5d0();
    FUN_005cb500(8);
  }
  else {
    ExceptionList = &pvStack_10;
    if (piVar8 != piVar5) {
      do {
        piVar2 = (int *)*piVar8;
        uVar1 = piVar8[2];
        iVar3 = (((((uVar1 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ uVar1 >> 8 & 0xff) * 0x1000193 ^
                  uVar1 >> 0x10 & 0xff) * 0x1000193 ^ uVar1 >> 0x18) * 0x1000193 &
                *(uint *)(param_1 + 0x18)) * 8;
        puVar9 = (undefined4 *)(iVar3 + *(int *)(param_1 + 0xc));
        if ((int *)puVar9[1] == piVar8) {
          if ((int *)*puVar9 == piVar8) {
            *puVar9 = *(undefined4 *)(param_1 + 4);
            *(undefined4 *)(iVar3 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
          }
          else {
            puVar9[1] = piVar8[1];
          }
        }
        else if ((int *)*puVar9 == piVar8) {
          *puVar9 = piVar2;
        }
        *(int *)piVar8[1] = *piVar8;
        *(int *)(*piVar8 + 4) = piVar8[1];
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        piVar4 = (int *)piVar8[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar3 = piVar4[1] + -1;
          piVar4[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar3 = piVar4[2] + -1;
            piVar4[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        FUN_01674ea0(piVar8,0x18);
        piVar8 = piVar2;
      } while (piVar2 != piVar5);
      ExceptionList = pvStack_10;
      return iVar10;
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 24718 ; VA 0x00b6d5d0 ; FUN_00b6d5d0 */

void __thiscall FUN_00b6d5d0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *param_3;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  piVar3 = (int *)param_3[3];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_01674ea0(param_3,0x18);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 24719 ; VA 0x00b6d640 ; FUN_00b6d640 */

undefined4 FUN_00b6d640(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined auStack_fc [4];
  int iStack_f8;
  undefined auStack_f4 [200];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f64a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_2);
  uVar2 = FUN_009d1540(auStack_fc,param_2,param_3,2,iVar1 - param_3,iStack_14 + 0x44);
  iStack_8 = 0;
  uVar3 = FUN_009d09d0(auStack_2c,param_2,param_3,1,iVar1 - param_3,iStack_14 + 0x40);
  iStack_8._0_1_ = 1;
  (**(code **)(iStack_14 + 0x38))(uVar3,uVar2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  iStack_8 = 2;
  if (iStack_f8 != 0) {
    (**(code **)(iStack_f8 + 8))(auStack_f4);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24720 ; VA 0x00b6d750 ; FUN_00b6d750 */

undefined4 FUN_00b6d750(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uStack_208;
  undefined4 *puStack_204;
  undefined auStack_200 [120];
  undefined4 uStack_188;
  undefined *puStack_184;
  undefined4 uStack_180;
  int iStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  int iStack_170;
  uint *puStack_16c;
  undefined4 uStack_168;
  int iStack_164;
  undefined4 uStack_160;
  int iStack_15c;
  int iStack_158;
  undefined *puStack_154;
  undefined4 uStack_150;
  int iStack_14c;
  undefined4 uStack_148;
  int iStack_144;
  int iStack_140;
  undefined4 uStack_13c;
  undefined auStack_12c [4];
  int iStack_128;
  undefined auStack_124 [200];
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined auStack_44 [4];
  int *piStack_40;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  uint uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f64d3;
  pvStack_1c = ExceptionList;
  uStack_13c = param_2;
  iStack_140 = 0xb6d78f;
  ExceptionList = &pvStack_1c;
  iVar4 = FUN_01256300();
  puStack_154 = auStack_12c;
  iStack_140 = iStack_24 + 0x48;
  iVar4 = iVar4 - param_3;
  uStack_148 = 3;
  iStack_14c = param_3;
  uStack_150 = param_2;
  iStack_158 = 0xb6d7b0;
  iStack_144 = iVar4;
  puStack_28 = (undefined4 *)FUN_009d1540();
  puStack_16c = auStack_5c;
  iStack_158 = iStack_24 + 0x44;
  uStack_14 = 0;
  uStack_160 = 2;
  iStack_164 = param_3;
  uStack_168 = param_2;
  iStack_170 = 0xb6d7d1;
  iStack_15c = iVar4;
  uStack_30 = FUN_009d09d0();
  puStack_184 = auStack_44;
  iStack_170 = iStack_24 + 0x40;
  uStack_14._0_1_ = 1;
  uStack_178 = 1;
  iStack_17c = param_3;
  uStack_180 = param_2;
  uStack_188 = 0xb6d7ef;
  iStack_174 = iVar4;
  puVar5 = (undefined4 *)FUN_009d1340();
  puStack_3c = (undefined *)&uStack_208;
  puStack_2c = (undefined *)&uStack_208;
  uStack_14._0_1_ = 2;
  pcStack_38 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  uStack_208 = *puStack_28;
  puStack_204 = (undefined4 *)0x0;
  puVar6 = (undefined4 *)puStack_28[1];
  puVar2 = &uStack_208;
  puVar3 = &uStack_208;
  if (puVar6 != (undefined4 *)0x0) {
    (*(code *)*puVar6)(puStack_28 + 2,auStack_200);
    puVar6 = (undefined4 *)puStack_28[1];
    puVar2 = (undefined4 *)puStack_3c;
    puVar3 = (undefined4 *)puStack_2c;
  }
  puStack_2c = (undefined *)puVar3;
  puStack_3c = (undefined *)puVar2;
  uStack_14._0_1_ = 3;
  puStack_204 = puVar6;
  FUN_0054ef60(uStack_30);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  (*pcStack_38)(*puVar5,puVar5[1]);
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_40[1] + -1;
    piStack_40[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar1 = piStack_40 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  uStack_14 = uStack_14 & 0xffffff00;
  if (0xf < uStack_48) {
    uVar8 = uStack_48 + 1;
    uVar7 = auStack_5c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_5c[0] - 4);
      uVar8 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  uStack_14 = 4;
  if (iStack_128 != 0) {
    (**(code **)(iStack_128 + 8))(auStack_124);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 24721 ; VA 0x00b6d940 ; FUN_00b6d940 */

undefined4 FUN_00b6d940(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_220 [4];
  int iStack_21c;
  undefined auStack_218 [200];
  undefined auStack_150 [4];
  int iStack_14c;
  undefined auStack_148 [200];
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6516;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  uStack_1c = FUN_009d1540(auStack_220,param_2,param_3,8,iVar4,iStack_14 + 0x5c);
  uStack_8 = 0;
  uStack_20 = FUN_009d1540(auStack_150,param_2,param_3,7,iVar4,iStack_14 + 0x58);
  uStack_8._0_1_ = 1;
  uStack_24 = FUN_009d09d0(auStack_80,param_2,param_3,6,iVar4,iStack_14 + 0x54);
  uStack_8._0_1_ = 2;
  uStack_28 = FUN_009d05b0(param_2,param_3,5,iVar4,iStack_14 + 0x50);
  uStack_2c = FUN_009d09d0(auStack_68,param_2,param_3,4,iVar4,iStack_14 + 0x4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (2 < iVar4) {
    uVar5 = FUN_00b73400();
    cVar3 = FUN_009d1e20(uVar5,param_2,param_3 + 3,&uStack_18);
    if (cVar3 != '\0') goto LAB_00b6da4b;
  }
  uStack_18 = FUN_00b68da0(param_2,param_3,3,iVar4,iStack_14 + 0x48);
LAB_00b6da4b:
  uStack_30 = uStack_18;
  uVar5 = FUN_009d09d0(auStack_50,param_2,param_3,2,iVar4,iStack_14 + 0x44);
  uStack_8._0_1_ = 4;
  uVar6 = FUN_009d1340(auStack_38,param_2,param_3,1,iVar4,iStack_14 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uVar5 = FUN_00b68820(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
                       param_2,uVar6,uVar5,&uStack_30,uStack_2c,&uStack_28,uStack_24,uStack_20,
                       uStack_1c,0);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 3;
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar7 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_54) {
    uVar8 = uStack_54 + 1;
    uVar7 = auStack_68[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_68[0] - 4);
      uVar8 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_6c) {
    uVar8 = uStack_6c + 1;
    uVar7 = auStack_80[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_80[0] - 4);
      uVar8 = uStack_6c + 0x24;
      if (0x1f < (auStack_80[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_70 = 0;
  uStack_6c = 0xf;
  auStack_80[0] = auStack_80[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (iStack_14c != 0) {
    (**(code **)(iStack_14c + 8))(auStack_148);
  }
  uStack_8 = 7;
  if (iStack_21c != 0) {
    (**(code **)(iStack_21c + 8))(auStack_218);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 24722 ; VA 0x00b6dc20 ; FUN_00b6dc20 */

undefined4 FUN_00b6dc20(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_2b8 [4];
  int iStack_2b4;
  undefined auStack_2b0 [200];
  undefined auStack_1e8 [4];
  int iStack_1e4;
  undefined auStack_1e0 [200];
  undefined auStack_118 [4];
  int iStack_114;
  undefined auStack_110 [200];
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6551;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  uStack_1c = FUN_009d1540(auStack_2b8,param_2,param_3,6,iVar3,iStack_14 + 0x54);
  uStack_8 = 0;
  uStack_20 = FUN_009d1540(auStack_1e8,param_2,param_3,5,iVar3,iStack_14 + 0x50);
  uStack_8._0_1_ = 1;
  uStack_24 = FUN_009d1540(auStack_118,param_2,param_3,4,iVar3,iStack_14 + 0x4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (2 < iVar3) {
    uVar4 = FUN_00b73560();
    cVar2 = FUN_009d1e20(uVar4,param_2,param_3 + 3,&uStack_18);
    if (cVar2 != '\0') goto LAB_00b6dcf7;
  }
  uStack_18 = FUN_00b691a0(param_2,param_3,3,iVar3,iStack_14 + 0x48);
LAB_00b6dcf7:
  uStack_28 = uStack_18;
  uVar4 = FUN_009d09d0(auStack_48,param_2,param_3,2,iVar3,iStack_14 + 0x44);
  uStack_8._0_1_ = 3;
  uVar5 = FUN_009d1340(auStack_30,param_2,param_3,1,iVar3,iStack_14 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uVar4 = FUN_00b686d0(param_1,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
                       param_2,uVar5,uVar4,&uStack_28,uStack_24,uStack_20,uStack_1c,0);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_8._0_1_ = 5;
  if (iStack_114 != 0) {
    (**(code **)(iStack_114 + 8))(auStack_110);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (iStack_1e4 != 0) {
    (**(code **)(iStack_1e4 + 8))(auStack_1e0);
  }
  uStack_8 = 7;
  if (iStack_2b4 != 0) {
    (**(code **)(iStack_2b4 + 8))(auStack_2b0);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 24723 ; VA 0x00b6de50 ; FUN_00b6de50 */

undefined4 FUN_00b6de50(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uStack_3b8;
  undefined4 *puStack_3b4;
  undefined auStack_3b0 [188];
  undefined4 uStack_2f4;
  undefined4 *puStack_2f0;
  undefined *puStack_2ec;
  undefined4 uStack_2e8;
  undefined4 *puStack_2e4;
  undefined auStack_2e0 [120];
  undefined4 uStack_268;
  uint *puStack_264;
  undefined4 uStack_260;
  int iStack_25c;
  undefined4 uStack_258;
  int iStack_254;
  int iStack_250;
  undefined *puStack_24c;
  undefined4 uStack_248;
  int iStack_244;
  undefined4 uStack_240;
  int iStack_23c;
  int iStack_238;
  undefined *puStack_234;
  undefined *puStack_230;
  int iStack_22c;
  int iStack_228;
  int iStack_224;
  int iStack_220;
  undefined4 *puStack_21c;
  undefined auStack_20c [4];
  int iStack_208;
  undefined auStack_204 [200];
  undefined auStack_13c [4];
  int iStack_138;
  undefined auStack_134 [200];
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [4];
  int *piStack_50;
  undefined *puStack_4c;
  code *pcStack_48;
  undefined4 *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017f6596;
  pvStack_1c = ExceptionList;
  puStack_21c = (undefined4 *)param_2;
  iStack_220 = 0xb6de90;
  ExceptionList = &pvStack_1c;
  iVar5 = FUN_01256300();
  iStack_220 = iStack_24 + 0x50;
  iVar5 = iVar5 - param_3;
  iStack_228 = 5;
  iStack_22c = param_3;
  puStack_234 = auStack_20c;
  puStack_230 = (undefined *)param_2;
  iStack_238 = 0xb6deaf;
  iStack_224 = iVar5;
  puStack_2c = (undefined4 *)FUN_009d1540();
  puStack_24c = auStack_13c;
  iStack_238 = iStack_24 + 0x4c;
  uStack_14 = 0;
  uStack_240 = 4;
  iStack_244 = param_3;
  uStack_248 = param_2;
  iStack_250 = 0xb6ded4;
  iStack_23c = iVar5;
  puStack_30 = (undefined4 *)FUN_009d1540();
  puStack_264 = auStack_6c;
  iStack_250 = iStack_24 + 0x48;
  uStack_14._0_1_ = 1;
  uStack_258 = 3;
  iStack_25c = param_3;
  uStack_260 = param_2;
  uStack_268 = 0xb6def2;
  iStack_254 = iVar5;
  uStack_3c = FUN_009d09d0();
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  if (1 < iVar5) {
    puStack_21c = (undefined4 *)0xb6df06;
    iStack_228 = FUN_00b734b0();
    puStack_21c = &uStack_38;
    iStack_220 = param_3 + 2;
    iStack_224 = param_2;
    iStack_22c = 0xb6df18;
    cVar4 = FUN_009d1e20();
    if (cVar4 != '\0') goto LAB_00b6df3a;
  }
  puStack_21c = (undefined4 *)(iStack_24 + 0x44);
  iStack_224 = 2;
  iStack_228 = param_3;
  iStack_22c = param_2;
  puStack_230 = (undefined *)0xb6df37;
  iStack_220 = iVar5;
  uStack_38 = FUN_00b68fa0();
LAB_00b6df3a:
  puStack_21c = (undefined4 *)(iStack_24 + 0x40);
  iStack_224 = 1;
  iStack_228 = param_3;
  puStack_230 = auStack_54;
  iStack_22c = param_2;
  puStack_234 = (undefined *)0xb6df54;
  iStack_220 = iVar5;
  uStack_28 = uStack_38;
  puStack_40 = (undefined4 *)FUN_009d1340();
  puVar7 = puStack_2c;
  puStack_4c = (undefined *)&uStack_2e8;
  puStack_34 = (undefined *)&uStack_2e8;
  uStack_14._0_1_ = 3;
  pcStack_48 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  uStack_2e8 = *puStack_2c;
  puStack_2e4 = (undefined4 *)0x0;
  puVar6 = (undefined4 *)puStack_2c[1];
  puVar2 = &uStack_2e8;
  if (puVar6 != (undefined4 *)0x0) {
    puStack_2ec = auStack_2e0;
    puStack_2f0 = puStack_2c + 2;
    uStack_2f4 = 0xb6df9c;
    (*(code *)*puVar6)();
    puVar6 = (undefined4 *)puVar7[1];
    puVar2 = (undefined4 *)puStack_4c;
  }
  puStack_4c = (undefined *)puVar2;
  puVar2 = puStack_30;
  puStack_34 = (undefined *)&uStack_3b8;
  puStack_2c = &uStack_3b8;
  uStack_14._0_1_ = 4;
  uStack_3b8 = *puStack_30;
  puStack_3b4 = (undefined4 *)0x0;
  puVar7 = (undefined4 *)puStack_30[1];
  puStack_2e4 = puVar6;
  puVar6 = &uStack_3b8;
  puVar3 = &uStack_3b8;
  if (puVar7 != (undefined4 *)0x0) {
    (*(code *)*puVar7)(puStack_30 + 2,auStack_3b0);
    puVar7 = (undefined4 *)puVar2[1];
    puVar6 = (undefined4 *)puStack_34;
    puVar3 = puStack_2c;
  }
  puStack_2c = puVar3;
  puStack_34 = (undefined *)puVar6;
  uStack_14._0_1_ = 5;
  puStack_3b4 = puVar7;
  FUN_0054ef60(uStack_3c);
  if (puStack_40[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_40[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  (*pcStack_48)(*puStack_40,puStack_40[1],uStack_28);
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_50[1] + -1;
    piStack_50[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piStack_50 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  uStack_14._0_1_ = 1;
  if (0xf < uStack_58) {
    uVar9 = uStack_58 + 1;
    uVar8 = auStack_6c[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_6c[0] - 4);
      uVar9 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  uStack_14 = CONCAT31(uStack_14._1_3_,6);
  if (iStack_138 != 0) {
    (**(code **)(iStack_138 + 8))(auStack_134);
  }
  uStack_14 = 7;
  if (iStack_208 != 0) {
    (**(code **)(iStack_208 + 8))(auStack_204);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 24724 ; VA 0x00b6e100 ; FUN_00b6e100 */

void __thiscall FUN_00b6e100(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  longlong lVar9;
  uint in_stack_0000001c;
  uint *puVar10;
  int *piVar11;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_1b [3];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f65b0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005c4c00(&DAT_01d674b4);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(iVar1 + 0x18) = uVar2;
  FUN_005c17a0(&param_3);
  iVar1 = FUN_005c4c00(&DAT_01d674cc);
  uVar2 = FUN_0088cb40();
  *(undefined4 *)(iVar1 + 0x18) = uVar2;
  FUN_005c17a0(&DAT_01d674fc);
  lVar9 = FUN_01682de0();
  if ((lVar9 < 0x100000000) && (lVar9 < 0)) {
    iVar1 = FUN_0055c3d0(auStack_1b,-(int)lVar9,
                         -((int)((ulonglong)lVar9 >> 0x20) + (uint)((int)lVar9 != 0)));
    *(undefined *)(iVar1 + -1) = 0x2d;
    puVar3 = (undefined *)(iVar1 + -1);
  }
  else {
    puVar3 = (undefined *)FUN_0055c3d0(auStack_1b,lVar9);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (puVar3 != auStack_1b) {
    FUN_005542c0(puVar3,(int)auStack_1b - (int)puVar3);
  }
  puVar10 = auStack_48;
  iStack_8._0_1_ = 1;
  FUN_005c4c00(&DAT_01d67364);
  FUN_00632ce0(puVar10);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar8 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 != 0) {
    iStack_18 = *(int *)(iVar1 + 0x440);
    piVar11 = &iStack_18;
    iStack_14 = *(undefined4 *)(iVar1 + 0x444);
    FUN_005c4c00(&DAT_01d672d4);
    FUN_00632bc0(piVar11);
    piVar11 = *(int **)(iVar1 + 0x43c);
    iStack_18 = *piVar11 - (int)piVar11;
    iStack_14 = piVar11[1] - (int)piVar11;
    piVar11 = &iStack_18;
    FUN_005c4c00(&DAT_01d672ec);
    FUN_00632bc0(piVar11);
    uVar2 = *(undefined4 *)(iVar1 + 0x450);
    iVar4 = FUN_005c4c00(&DAT_01d67304);
    uVar5 = FUN_0088c8c0();
    *(undefined4 *)(iVar4 + 0x18) = uVar5;
    iVar6 = FUN_005c9cc0();
    iVar1 = *(int *)(iVar4 + 0x1c);
    if (iVar1 == iVar6) {
      *(undefined4 *)(iVar4 + 0x20) = uVar2;
    }
    else {
      if (iVar1 != 0) {
        (**(code **)(iVar1 + 8))(iVar4 + 0x20);
      }
      *(undefined4 *)(iVar4 + 0x20) = uVar2;
      *(int *)(iVar4 + 0x1c) = iVar6;
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar8 = in_stack_0000001c + 1;
    iVar1 = param_3;
    if (0xfff < uVar8) {
      iVar1 = *(int *)(param_3 + -4);
      uVar8 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24725 ; VA 0x00b6e320 ; FUN_00b6e320 */

void FUN_00b6e320(int *param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined8 *puVar5;
  int *piVar6;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f65d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  FUN_00b6e100(param_2);
  iVar2 = FUN_005c4c00(&DAT_01d674cc);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  FUN_005c17a0(&DAT_01d674e4);
  uStack_18 = FUN_00928340();
  puVar5 = &uStack_18;
  FUN_005c4c00(&DAT_01d6731c);
  FUN_00632bc0(puVar5);
  FUN_0054ef60(*param_1 + 0x458);
  piVar6 = aiStack_30;
  uStack_8._0_1_ = 1;
  FUN_005c4c00(&DAT_01d67334);
  FUN_00632ce0(piVar6);
  uStack_8._0_1_ = 0;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  FUN_0054ef60(*param_1 + 0x470);
  piVar6 = aiStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005c4c00(&DAT_01d6737c);
  FUN_00632ce0(piVar6);
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    iVar2 = param_3;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(param_3 + -4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24726 ; VA 0x00b6e4c0 ; FUN_00b6e4c0 */

int __thiscall FUN_00b6e4c0(undefined4 *param_1,byte *param_2,uint param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  int iVar5;
  char acStack_104 [256];
  
  pbVar4 = param_2;
  do {
    bVar1 = *pbVar4;
    pbVar4 = pbVar4 + 1;
  } while (bVar1 != 0);
  uVar2 = param_1[4];
  iVar5 = (int)pbVar4 - (int)(param_2 + 1);
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if ((iVar5 != 0) && (param_3 < uVar2)) {
    FUN_0170d1f0(acStack_104,0,0x100);
    iVar3 = 0;
    if (param_2 + iVar5 < param_2) {
      iVar5 = 0;
    }
    if (iVar5 != 0) {
      do {
        bVar1 = *param_2;
        param_2 = param_2 + 1;
        iVar3 = iVar3 + 1;
        acStack_104[bVar1] = '\x01';
      } while (iVar3 != iVar5);
    }
    for (pbVar4 = (byte *)(param_3 + (int)param_1); pbVar4 < (byte *)(uVar2 + (int)param_1);
        pbVar4 = pbVar4 + 1) {
      if (acStack_104[*pbVar4] != '\0') {
        return (int)pbVar4 - (int)param_1;
      }
    }
  }
  return -1;
}



/* FUNCTION 24727 ; VA 0x00b6e570 ; FUN_00b6e570 */

void __thiscall FUN_00b6e570(int param_1,undefined4 param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  int in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000028;
  undefined *puVar11;
  int iStack_110;
  undefined auStack_10c [208];
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int aiStack_24 [2];
  undefined4 auStack_1c [3];
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017f6633;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FireCustomEvent",0xf);
  uStack_8._0_1_ = 3;
  cVar3 = FUN_00b73760(auStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    uVar10 = auStack_3c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_3c[0] - 4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  if (cVar3 == '\0') goto LAB_00b6e7c9;
  cVar4 = FUN_00b70910(&param_4);
  uVar10 = in_stack_00000020;
  if ((bool)DAT_01d675bc == (cVar3 == '\0')) {
    if (cVar4 == '\0') {
      FUN_0086f2f0(3,"AnalyticsService: eventCategory is invalid.");
      goto LAB_00b6e7c9;
    }
  }
  else {
    if (cVar4 == '\0') {
LAB_00b6e64f:
      puVar6 = &param_4;
      if (0xf < uVar10) {
        puVar6 = param_4;
      }
      FUN_0086f2f0(3,"AnalyticsService:FireCustomEvent Invalid event name [%s].",puVar6);
      goto LAB_00b6e7c9;
    }
    puVar6 = &param_4;
    if (0xf < in_stack_00000020) {
      puVar6 = param_4;
    }
    if (in_stack_0000001c != 0) {
      puVar5 = (undefined4 *)FUN_0170db20(puVar6,0x5f,in_stack_0000001c);
      if ((puVar5 != (undefined4 *)0x0) && (puVar5 == puVar6)) goto LAB_00b6e64f;
    }
  }
  cVar3 = FUN_00b707f0(&stack0x00000024);
  if (cVar3 != '\0') {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_00b6b1f0(aiStack_24,param_2,param_3,0);
    uStack_8._0_1_ = 4;
    FUN_00888650(auStack_1c);
    puVar11 = &stack0x00000024;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_005c4c00(&DAT_01d67514);
    FUN_0056ee80(puVar11);
    iVar7 = FUN_005c4c00(&DAT_01d674b4);
    uVar8 = FUN_0088cb40();
    *(undefined4 *)(iVar7 + 0x18) = uVar8;
    FUN_005c17a0(&param_4);
    if (aiStack_24[0] == 0) {
      FUN_0054ef60(&param_4);
      FUN_00b6e100(auStack_1c[0]);
    }
    else {
      FUN_0054ef60(&param_4);
      FUN_00b6e320(aiStack_24,auStack_1c[0]);
    }
    if (*(int **)(param_1 + 0x58) != (int *)0x0) {
      pcVar2 = *(code **)(**(int **)(param_1 + 0x58) + 0xc);
      uVar8 = FUN_00557fc0(auStack_1c);
      uStack_8._0_1_ = 6;
      FUN_005c15a0(uVar8);
      uStack_8._0_1_ = 7;
      FUN_0054ef60(&param_4);
      (*pcVar2)();
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      if (iStack_110 != 0) {
        (**(code **)(iStack_110 + 8))(auStack_10c);
      }
      FUN_00550b30();
    }
    FUN_00550b30();
    FUN_00550b30();
  }
LAB_00b6e7c9:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar7 = param_3[1] + -1;
    param_3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < in_stack_00000020) {
    uVar10 = in_stack_00000020 + 1;
    puVar6 = param_4;
    if (0xfff < uVar10) {
      puVar6 = (undefined4 *)param_4[-1];
      uVar10 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_4 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar10);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = (undefined4 *)((uint)param_4 & 0xffffff00);
  uStack_8 = 9;
  if (in_stack_00000028 != 0) {
    (**(code **)(in_stack_00000028 + 8))(&stack0x0000002c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24728 ; VA 0x00b6e870 ; FUN_00b6e870 */

void __thiscall FUN_00b6e870(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iStack_114;
  undefined auStack_110 [200];
  undefined auStack_48 [4];
  int *piStack_44;
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f666b;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0xe8) == '\0') {
    ExceptionList = &pvStack_10;
    cVar3 = FUN_00973950(param_1,1);
    if (cVar3 != '\0') {
      FUN_0086f2f0(3,"AnalyticsService can only be executed by game server.");
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("AnalyticsService.FireEvent",0x1a);
    uStack_8 = 0;
    iVar4 = FUN_005d1470(auStack_28);
    uStack_8 = 0xffffffff;
    *(int *)(iVar4 + 0x18) = *(int *)(iVar4 + 0x18) + 1;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    cVar3 = FUN_00b6b350(param_2,param_3);
    if (cVar3 == '\0') {
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      FUN_005542c0("AnalyticsService.FireEventFailure",0x21);
      uStack_8 = 1;
      iVar4 = FUN_005d1470(auStack_28);
      *(int *)(iVar4 + 0x18) = *(int *)(iVar4 + 0x18) + 1;
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    auStack_40[0] = 0;
    uStack_3c = FUN_00588320(0xb);
    uStack_38 = 0;
    uStack_34 = 0x3f800000;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_8 = 2;
    FUN_0054ef60(param_2);
    FUN_00b6e100(auStack_40);
    FUN_005c4c00(&DAT_01d67514);
    FUN_0056ee80(param_3);
    uVar5 = FUN_00ac3970(auStack_48,auStack_40);
    uStack_8._0_1_ = 3;
    FUN_00b67b80(uVar5);
    uStack_8._0_1_ = 5;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_44[1] + -1;
      piStack_44[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar1 = piStack_44 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
    pcVar2 = *(code **)(**(int **)(param_1 + 0x58) + 0xc);
    FUN_0054ef60(param_2);
    (*pcVar2)();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (iStack_114 != 0) {
      (**(code **)(iStack_114 + 8))(auStack_110);
    }
    FUN_0056d080();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24729 ; VA 0x00b6eac0 ; FUN_00b6eac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b6eac0(undefined4 param_1,int *param_2,uint param_3)

{
  code *pcVar1;
  char *pcVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_00000038;
  uint in_stack_0000003c;
  undefined4 in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_00000054;
  uint in_stack_00000058;
  int in_stack_00000060;
  int in_stack_00000130;
  undefined uVar13;
  undefined4 uVar14;
  int *piVar15;
  undefined4 uVar16;
  undefined *puVar17;
  uint *puVar18;
  undefined4 uVar19;
  undefined auStack_4c [12];
  int iStack_40;
  int iStack_3c;
  int *piStack_38;
  uint auStack_34 [2];
  char cStack_29;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f671e;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FireInGameEconomy",0x11);
  uStack_8._0_1_ = 6;
  cVar3 = FUN_00b73760(auStack_28);
  cStack_29 = cVar3 == '\0';
  uStack_8._0_1_ = 5;
  uVar13 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_14) {
    uVar12 = uStack_14 + 1;
    uVar11 = auStack_28[0];
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(auStack_28[0] - 4);
      uVar12 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar11) - 4) {
        uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  if (cStack_29 == '\0') {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piVar15 = &iStack_3c;
    uVar14 = 0xb6eba0;
    FUN_00b6b1f0(piVar15,param_1,param_2,1);
    uStack_8._0_1_ = 7;
    if (iStack_3c != 0) {
      cVar3 = FUN_00b70910(&stack0x00000028);
      if (((cVar3 == '\0') || (cVar3 = FUN_00b70910(&param_3), cVar3 == '\0')) ||
         (cVar3 = FUN_00b70910(&stack0x00000044), cVar3 == '\0')) {
        FUN_0086f2f0(3,"AnalyticsService: Invalid string parameters.");
      }
      else {
        cVar3 = FUN_00b70af0(&stack0x0000005c);
        if ((cVar3 != '\0') && (cVar3 = FUN_00b707f0(&stack0x0000012c), cVar3 != '\0')) {
          FUN_00888650(auStack_4c);
          uStack_8._0_1_ = 8;
          uVar13 = (undefined)uStack_8;
          uStack_8._0_1_ = 8;
          uVar12 = ((((in_stack_00000024 & 0xff ^ 0x811c9dc5) * 0x1000193 ^
                     in_stack_00000024 >> 8 & 0xff) * 0x1000193 ^ in_stack_00000024 >> 0x10 & 0xff)
                    * 0x1000193 ^ in_stack_00000024 >> 0x18) * 0x1000193 & _DAT_01ef0640;
          iVar5 = uVar12 * 8;
          puVar4 = *(undefined4 **)(iVar5 + DAT_01ef0634);
          uVar11 = iVar5 + 4;
          while( true ) {
            puVar9 = DAT_01ef062c;
            if (*(undefined4 **)(DAT_01ef0634 + uVar12 * 8) != DAT_01ef062c) {
              puVar9 = (undefined4 *)**(undefined4 **)(DAT_01ef0634 + uVar11);
            }
            if (puVar4 == puVar9) goto LAB_00b6f215;
            if (puVar4[2] == in_stack_00000024) break;
            puVar4 = (undefined4 *)*puVar4;
          }
          if (puVar4 == DAT_01ef062c) {
LAB_00b6f215:
            in_stack_00000024 = uVar11;
            uStack_8._0_1_ = uVar13;
            FUN_016ddcf9("invalid unordered_map<K, T> key");
            goto LAB_00b6f21f;
          }
          uStack_18 = 0;
          puVar4 = puVar4 + 3;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "economyAction";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          in_stack_00000024 = uVar11;
          FUN_005542c0(&DAT_01956758,pcVar10 + -0x1956758);
          uStack_8._0_1_ = 9;
          FUN_005c4c00(auStack_28);
          FUN_005c16d0(puVar4);
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          iVar5 = FUN_005c4c00(&DAT_01d673c4);
          uVar6 = FUN_0088cb40();
          *(undefined4 *)(iVar5 + 0x18) = uVar6;
          FUN_005c17a0(&param_3);
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "itemCategory";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_01956748,pcVar10 + -0x1956748);
          uStack_8._0_1_ = 10;
          iVar5 = FUN_005c4c00(auStack_28);
          uVar6 = FUN_0088cb40();
          *(undefined4 *)(iVar5 + 0x18) = uVar6;
          FUN_005c17a0(&stack0x00000028);
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "amount";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_01956768,pcVar10 + -0x1956768);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          iVar7 = FUN_005c4c00(auStack_28);
          uVar6 = FUN_0088c8c0();
          *(undefined4 *)(iVar7 + 0x18) = uVar6;
          iVar8 = FUN_005c9cc0();
          iVar5 = *(int *)(iVar7 + 0x1c);
          if (iVar5 == iVar8) {
            *(undefined4 *)(iVar7 + 0x20) = in_stack_00000040;
          }
          else {
            if (iVar5 != 0) {
              (**(code **)(iVar5 + 8))(iVar7 + 0x20);
            }
            *(undefined4 *)(iVar7 + 0x20) = in_stack_00000040;
            *(int *)(iVar7 + 0x1c) = iVar8;
          }
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "currency";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_01956770,pcVar10 + -0x1956770);
          uStack_8._0_1_ = 0xc;
          iVar5 = FUN_005c4c00(auStack_28);
          uVar6 = FUN_0088cb40();
          *(undefined4 *)(iVar5 + 0x18) = uVar6;
          FUN_005c17a0(&stack0x00000044);
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "location";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_0195673c,pcVar10 + -0x195673c);
          puVar17 = &stack0x0000005c;
          uStack_8._0_1_ = 0xd;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(puVar17);
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "customData";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_0195677c,pcVar10 + -0x195677c);
          puVar17 = &stack0x0000012c;
          uStack_8._0_1_ = 0xe;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(puVar17);
          uStack_8._0_1_ = 8;
          FUN_005507b0();
          FUN_00888650(auStack_34);
          puVar17 = auStack_4c;
          uStack_8._0_1_ = 0xf;
          FUN_005c4c00(&DAT_01d67514);
          FUN_00b67be0(puVar17);
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar2 = "_FireInGameEconomyEvent";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_019566f8,pcVar10 + -0x19566f8);
          puVar18 = auStack_28;
          uStack_8._0_1_ = 0x10;
          uVar6 = 0xb6ef9b;
          FUN_005c4c00(&DAT_01d674b4);
          FUN_00632ce0(puVar18);
          uStack_8._0_1_ = 0xf;
          FUN_005507b0();
          uVar16 = 0;
          uVar19 = 0xf;
          uVar13 = 0;
          pcVar2 = "_FireInGameEconomyEvent";
          do {
            pcVar10 = pcVar2;
            pcVar2 = pcVar10 + 1;
          } while (*pcVar10 != '\0');
          FUN_005542c0(&DAT_019566f8,pcVar10 + -0x19566f8);
          FUN_00b6e320(&iStack_3c,auStack_34[0],uVar13,uVar14,piVar15,uVar6,uVar16,uVar19);
          if (*(int **)(iStack_40 + 0x58) != (int *)0x0) {
            pcVar1 = *(code **)(**(int **)(iStack_40 + 0x58) + 0xc);
            uVar14 = FUN_00557fc0(auStack_34);
            uStack_8._0_1_ = 0x11;
            FUN_005c15a0(uVar14);
            uStack_8._0_1_ = 0x12;
            auStack_34[0] = auStack_34[0] & 0xffffff00;
            pcVar2 = "_FireInGameEconomyEvent";
            do {
              pcVar10 = pcVar2;
              pcVar2 = pcVar10 + 1;
            } while (*pcVar10 != '\0');
            FUN_005542c0(&DAT_019566f8,pcVar10 + -0x19566f8);
            (*pcVar1)(auStack_34[0]);
            FUN_0056e5b0();
            FUN_00550b30();
          }
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          goto LAB_00b6f0c3;
        }
      }
    }
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_38[1] + -1;
      piStack_38[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar5 = piStack_38[2] + -1;
        piStack_38[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
LAB_00b6f0c3:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar5 = param_2[1] + -1;
    param_2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar15 = param_2 + 2;
      iVar5 = *piVar15;
      *piVar15 = *piVar15 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_00000020) {
    uVar12 = in_stack_00000020 + 1;
    uVar11 = param_3;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(param_3 - 4);
      uVar12 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar11) - 4) {
LAB_00b6f21f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar13 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_0000003c) {
    uVar12 = in_stack_0000003c + 1;
    uVar11 = in_stack_00000028;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(in_stack_00000028 - 4);
      uVar12 = in_stack_0000003c + 0x24;
      if (0x1f < (in_stack_00000028 - uVar11) - 4) {
        uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  in_stack_00000038 = 0;
  in_stack_0000003c = 0xf;
  in_stack_00000028 = in_stack_00000028 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar13 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000058) {
    uVar12 = in_stack_00000058 + 1;
    uVar11 = in_stack_00000044;
    if (0xfff < uVar12) {
      uVar11 = *(uint *)(in_stack_00000044 - 4);
      uVar12 = in_stack_00000058 + 0x24;
      if (0x1f < (in_stack_00000044 - uVar11) - 4) {
        uStack_8._0_1_ = uVar13;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar12);
  }
  in_stack_00000054 = 0;
  in_stack_00000058 = 0xf;
  in_stack_00000044 = in_stack_00000044 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  if (in_stack_00000060 != 0) {
    (**(code **)(in_stack_00000060 + 8))(&stack0x00000064);
  }
  uStack_8 = 0x14;
  if (in_stack_00000130 != 0) {
    (**(code **)(in_stack_00000130 + 8))(&stack0x00000134);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24730 ; VA 0x00b6f230 ; FUN_00b6f230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b6f230(undefined4 param_1,int *param_2,uint param_3,uint param_4)

{
  byte bVar1;
  undefined4 ***pppuVar2;
  char *pcVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  code *pcVar8;
  undefined4 ****ppppuVar9;
  int *piVar10;
  int iVar11;
  undefined4 uVar12;
  int iVar13;
  int *piVar14;
  char *pcVar15;
  uint uVar16;
  uint uVar17;
  byte *pbVar18;
  byte *pbVar19;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  int in_stack_0000002c;
  int in_stack_000000fc;
  undefined uVar20;
  undefined4 uVar21;
  undefined *puVar22;
  undefined4 uVar23;
  undefined4 uStack_160;
  int iStack_15c;
  undefined auStack_158 [200];
  int aiStack_90 [2];
  undefined auStack_88 [4];
  int *piStack_84;
  undefined4 ***pppuStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined auStack_68 [12];
  int iStack_5c;
  byte *pbStack_58;
  int *piStack_54;
  uint uStack_50;
  int *piStack_4c;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 ***pppuStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  code *pcStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f67ff;
  pvStack_10 = ExceptionList;
  pcStack_18 = (code *)0x0;
  uStack_8 = 3;
  uStack_20._0_4_ = 0;
  uStack_20._4_4_ = 0xf;
  pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0("FireLogEvent",0xc);
  uStack_8._0_1_ = 4;
  cVar4 = FUN_00b73760(&pppuStack_30);
  cStack_11 = cVar4 == '\0';
  uStack_8._0_1_ = 3;
  uVar20 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_20._4_4_) {
    uVar16 = uStack_20._4_4_ + 1;
    ppppuVar9 = (undefined4 ****)pppuStack_30;
    if (0xfff < uVar16) {
      ppppuVar9 = (undefined4 ****)pppuStack_30[-1];
      uVar16 = uStack_20._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_30 + (-4 - (int)ppppuVar9))) {
        uStack_8._0_1_ = uVar20;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar16);
  }
  uVar5 = DAT_01d671bc;
  if (cStack_11 != '\0') goto LAB_00b6f36b;
  uStack_160 = FUN_0088cb40();
  iStack_15c = 0;
  FUN_0054ef60(&param_4);
  iStack_15c = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  cVar4 = FUN_00b70990(&uStack_160,uVar5,&DAT_019567d8);
  cStack_11 = cVar4 == '\0';
  uStack_8._0_1_ = 6;
  if (iStack_15c != 0) {
    (**(code **)(iStack_15c + 8))(auStack_158);
  }
  uStack_8._0_1_ = 3;
  if (cStack_11 != '\0') {
    FUN_0086f2f0(3,"AnalyticsService: Invalid string parameters.");
    goto LAB_00b6f36b;
  }
  FUN_00636000(&pbStack_58);
  uStack_8._0_1_ = 7;
  FUN_00888650(auStack_88);
  uStack_8._0_1_ = 8;
  uStack_20 = 0xf00000000;
  pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
  pcVar3 = "errorCode";
  do {
    pcVar15 = pcVar3;
    pcVar3 = pcVar15 + 1;
  } while (*pcVar15 != '\0');
  FUN_005542c0(&DAT_019567b4,pcVar15 + -0x19567b4);
  pbVar18 = pbStack_58 + *pbStack_58 + 1;
  uVar5 = FUN_005702d0(&pppuStack_30);
  pbVar19 = pbStack_58;
  FUN_00562fc0(&piStack_4c,uVar5,&pppuStack_30,-(uint)(pbVar18 != (byte *)0x0) & (uint)(pbVar18 + 1)
              );
  FUN_005507b0();
  if (piStack_4c == (int *)0x0) {
LAB_00b6f572:
    uStack_20._0_4_ = 0;
    uStack_20._4_4_ = 0xf;
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
    pcVar3 = "stackTrace";
    do {
      pcVar15 = pcVar3;
      pcVar3 = pcVar15 + 1;
    } while (*pcVar15 != '\0');
    FUN_005542c0(&DAT_019567c0,pcVar15 + -0x19567c0);
    bVar1 = *pbVar19;
    uVar5 = FUN_005702d0(&pppuStack_30);
    FUN_00562fc0(&pcStack_18,uVar5,&pppuStack_30,
                 -(uint)(pbVar19 + bVar1 + 1 != (byte *)0x0) & (uint)(pbVar19 + bVar1 + 1 + 1));
    FUN_005507b0();
    if (pcStack_18 != (code *)0x0) {
      uStack_20 = 0xf00000000;
      pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
      pcVar3 = "stackTrace";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567c0,pcVar15 + -0x19567c0);
      uStack_8._0_1_ = 0xb;
      pcVar8 = (code *)FUN_0091d440(&pppuStack_30);
      uStack_8._0_1_ = 8;
      pcStack_18 = pcVar8;
      FUN_005507b0();
      iVar11 = *(int *)pcVar8;
      iVar7 = FUN_0088cb40();
      if (iVar11 == iVar7) {
        FUN_00563690(&pppuStack_80);
        pppuVar2 = pppuStack_80;
        uStack_8._0_1_ = 0xc;
        if (DAT_01d671c4 < uStack_70) {
          uVar16 = DAT_01d671c4;
          if (uStack_70 < DAT_01d671c4) {
            uVar16 = uStack_70;
          }
          ppppuVar9 = &pppuStack_80;
          if (0xf < uStack_6c) {
            ppppuVar9 = (undefined4 ****)pppuStack_80;
          }
          uStack_20._0_4_ = 0;
          uStack_20._4_4_ = 0xf;
          pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
          FUN_005542c0(ppppuVar9,uVar16);
        }
        else {
          pppuStack_80 = (undefined4 ***)((uint)pppuStack_80 & 0xffffff00);
          pppuStack_30 = pppuVar2;
          uStack_2c = uStack_7c;
          uStack_28 = uStack_78;
          uStack_24 = uStack_74;
          uStack_20._0_4_ = uStack_70;
          uStack_20._4_4_ = uStack_6c;
          uStack_70 = 0;
          uStack_6c = 0xf;
        }
        FUN_005507b0();
      }
      else {
        FUN_0086f2f0(3,"AnalyticsService: %s value is not a string.",&DAT_019567c0);
        uStack_20._0_4_ = 0;
        uStack_20._4_4_ = 0xf;
        pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
        FUN_005542c0(&DAT_018bc9b8,0);
      }
      uStack_8._0_1_ = 0xd;
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "stackTrace";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567c0,pcVar15 + -0x19567c0);
      ppppuVar9 = &pppuStack_30;
      uStack_8._0_1_ = 0xe;
      FUN_005c4c00(auStack_48);
      FUN_00632ce0(ppppuVar9);
      FUN_005507b0();
      uStack_8._0_1_ = 8;
      FUN_005507b0();
    }
    cVar4 = FUN_00b707f0(&stack0x000000f8);
    if (cVar4 != '\0') {
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      piVar6 = aiStack_90;
      uVar5 = 0xb6f803;
      FUN_00b6b1f0(piVar6,param_1,param_2,0);
      uStack_8._0_1_ = 0xf;
      FUN_00888650(auStack_68);
      uStack_8._0_1_ = 0x10;
      uVar20 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x10;
      iVar11 = (((((param_3 & 0xff ^ 0x811c9dc5) * 0x1000193 ^ param_3 >> 8 & 0xff) * 0x1000193 ^
                 param_3 >> 0x10 & 0xff) * 0x1000193 ^ param_3 >> 0x18) * 0x1000193 & _DAT_01ef0680)
               * 8;
      piVar10 = *(int **)(iVar11 + DAT_01ef0674);
      pcStack_18 = (code *)(iVar11 + 4);
      piStack_4c = *(int **)(DAT_01ef0674 + iVar11);
      while( true ) {
        piVar14 = DAT_01ef066c;
        if (piStack_4c != DAT_01ef066c) {
          piVar14 = (int *)**(undefined4 **)(pcStack_18 + DAT_01ef0674);
        }
        if (piVar10 == piVar14) goto LAB_00b6fcef;
        if (piVar10[2] == param_3) break;
        piVar10 = (int *)*piVar10;
      }
      if (piVar10 == DAT_01ef066c) {
LAB_00b6fcef:
        uStack_8._0_1_ = uVar20;
        FUN_016ddcf9("invalid unordered_map<K, T> key");
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
      }
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "logLevel";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567cc,pcVar15 + -0x19567cc);
      uStack_8._0_1_ = 0x11;
      iVar11 = FUN_005c4c00(auStack_48);
      uVar12 = FUN_0088cb40();
      *(undefined4 *)(iVar11 + 0x18) = uVar12;
      FUN_005c17a0(piVar10 + 3);
      uStack_8._0_1_ = 0x10;
      FUN_005507b0();
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "message";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567d8,pcVar15 + -0x19567d8);
      uStack_8._0_1_ = 0x12;
      iVar11 = FUN_005c4c00(auStack_48);
      uVar12 = FUN_0088cb40();
      *(undefined4 *)(iVar11 + 0x18) = uVar12;
      FUN_005c17a0(&param_4);
      uStack_8._0_1_ = 0x10;
      FUN_005507b0();
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "debugInfo";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567e0,pcVar15 + -0x19567e0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      iVar7 = FUN_005c4c00(auStack_48);
      uVar12 = FUN_008881d0();
      *(undefined4 *)(iVar7 + 0x18) = uVar12;
      iVar13 = FUN_0058c000();
      iVar11 = *(int *)(iVar7 + 0x1c);
      if (iVar11 == iVar13) {
        if (piStack_54 != (int *)0x0) {
          LOCK();
          piStack_54[1] = piStack_54[1] + 1;
          UNLOCK();
        }
        *(byte **)(iVar7 + 0x20) = pbStack_58;
        piVar10 = *(int **)(iVar7 + 0x24);
        *(int **)(iVar7 + 0x24) = piStack_54;
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar11 = piVar10[1] + -1;
          piVar10[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)*piVar10)();
            LOCK();
            iVar11 = piVar10[2] + -1;
            piVar10[2] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              (**(code **)(*piVar10 + 4))();
            }
          }
        }
      }
      else {
        if (iVar11 != 0) {
          (**(code **)(iVar11 + 8))(iVar7 + 0x20);
          *(undefined4 *)(iVar7 + 0x1c) = 0;
        }
        *(undefined4 *)(iVar7 + 0x20) = 0;
        *(undefined4 *)(iVar7 + 0x24) = 0;
        if (piStack_54 != (int *)0x0) {
          LOCK();
          piStack_54[1] = piStack_54[1] + 1;
          UNLOCK();
        }
        *(byte **)(iVar7 + 0x20) = pbStack_58;
        *(int **)(iVar7 + 0x24) = piStack_54;
        *(int *)(iVar7 + 0x1c) = iVar13;
      }
      uStack_8._0_1_ = 0x10;
      FUN_005507b0();
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "customData";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_0195677c,pcVar15 + -0x195677c);
      puVar22 = &stack0x000000f8;
      uStack_8._0_1_ = 0x14;
      FUN_005c4c00(auStack_48);
      FUN_0056ee80(puVar22);
      uStack_8._0_1_ = 0x10;
      FUN_005507b0();
      FUN_00888650(&uStack_50);
      puVar22 = auStack_68;
      uStack_8._0_1_ = 0x15;
      FUN_005c4c00(&DAT_01d67514);
      FUN_00b67be0(puVar22);
      uStack_38 = 0;
      uStack_34 = 0xf;
      auStack_48[0] = 0;
      pcVar3 = "_FireLogEvent";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_0195672c,pcVar15 + -0x195672c);
      puVar22 = auStack_48;
      uStack_8._0_1_ = 0x16;
      uVar12 = 0xb6faf3;
      FUN_005c4c00(&DAT_01d674b4);
      FUN_00632ce0(puVar22);
      uStack_8._0_1_ = 0x15;
      FUN_005507b0();
      uVar21 = 0;
      uVar23 = 0xf;
      uVar20 = 0;
      pcVar3 = "_FireLogEvent";
      if (aiStack_90[0] == 0) {
        do {
          pcVar15 = pcVar3;
          pcVar3 = pcVar15 + 1;
        } while (*pcVar15 != '\0');
        FUN_005542c0(&DAT_0195672c,pcVar15 + -0x195672c);
        FUN_00b6e100(uStack_50,uVar20,uVar5,piVar6,uVar12,uVar21,uVar23);
        uVar16 = uStack_50;
      }
      else {
        do {
          pcVar15 = pcVar3;
          pcVar3 = pcVar15 + 1;
        } while (*pcVar15 != '\0');
        FUN_005542c0(&DAT_0195672c,pcVar15 + -0x195672c);
        FUN_00b6e320(aiStack_90,uStack_50,uVar20,uVar5,piVar6,uVar12,uVar21,uVar23);
        uVar16 = uStack_50;
      }
      if (*(int **)(iStack_5c + 0x58) != (int *)0x0) {
        pcStack_18 = *(code **)(**(int **)(iStack_5c + 0x58) + 0xc);
        uVar5 = FUN_00557fc0(&uStack_50);
        uStack_8._0_1_ = 0x17;
        FUN_005c15a0(uVar5);
        uStack_8._0_1_ = 0x18;
        uVar16 = uVar16 & 0xffffff00;
        pcVar3 = "_FireLogEvent";
        do {
          pcVar15 = pcVar3;
          pcVar3 = pcVar15 + 1;
        } while (*pcVar15 != '\0');
        FUN_005542c0(&DAT_0195672c,pcVar15 + -0x195672c);
        (*pcStack_18)(uVar16);
        FUN_0056e5b0();
        FUN_00550b30();
      }
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
      goto LAB_00b6f36b;
    }
  }
  else {
    uStack_20._0_4_ = 0;
    uStack_20._4_4_ = 0xf;
    pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
    pcVar3 = "errorCode";
    do {
      pcVar15 = pcVar3;
      pcVar3 = pcVar15 + 1;
    } while (*pcVar15 != '\0');
    FUN_005542c0(&DAT_019567b4,pcVar15 + -0x19567b4);
    uStack_8._0_1_ = 9;
    piVar6 = (int *)FUN_0091d440(&pppuStack_30);
    uStack_8._0_1_ = 8;
    piStack_4c = piVar6;
    FUN_005507b0();
    iVar11 = *piVar6;
    iVar7 = FUN_0088cb40();
    piVar6 = piStack_4c;
    if (iVar11 == iVar7) {
      uVar5 = FUN_00563690(auStack_48);
      pcStack_18 = (code *)0x1;
      cVar4 = FUN_00b70910(uVar5);
      cStack_11 = '\0';
      if (cVar4 == '\0') goto LAB_00b6f4e8;
    }
    else {
LAB_00b6f4e8:
      cStack_11 = '\x01';
    }
    if (((uint)pcStack_18 & 1) != 0) {
      FUN_005507b0();
    }
    if (cStack_11 == '\0') {
      uStack_70 = 0;
      uStack_6c = 0xf;
      pppuStack_80 = (undefined4 ***)((uint)pppuStack_80 & 0xffffff00);
      pcVar3 = "errorCode";
      do {
        pcVar15 = pcVar3;
        pcVar3 = pcVar15 + 1;
      } while (*pcVar15 != '\0');
      FUN_005542c0(&DAT_019567b4,pcVar15 + -0x19567b4);
      uStack_8._0_1_ = 10;
      FUN_005c4c00(&pppuStack_80);
      FUN_0056ee80(piVar6);
      uStack_8._0_1_ = 8;
      FUN_005507b0();
      pbVar19 = pbStack_58;
      goto LAB_00b6f572;
    }
    FUN_0086f2f0(3,"AnalyticsService: Invalid errorCode parameters.");
  }
  if (piStack_84 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_84[1] + -1;
    piStack_84[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_84)();
      LOCK();
      iVar11 = piStack_84[2] + -1;
      piStack_84[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piStack_84 + 4))();
      }
    }
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_54[1] + -1;
    piStack_54[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      iVar11 = piStack_54[2] + -1;
      piStack_54[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
LAB_00b6f36b:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar11 = param_2[1] + -1;
    param_2[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar11 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  uVar20 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000024) {
    uVar17 = in_stack_00000024 + 1;
    uVar16 = param_4;
    if (0xfff < uVar17) {
      uVar16 = *(uint *)(param_4 - 4);
      uVar17 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - uVar16) - 4) {
        uStack_8._0_1_ = uVar20;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar16,uVar17);
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  if (in_stack_0000002c != 0) {
    (**(code **)(in_stack_0000002c + 8))(&stack0x00000030);
  }
  uStack_8 = 0x1a;
  if (in_stack_000000fc != 0) {
    (**(code **)(in_stack_000000fc + 8))(&stack0x00000100);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24731 ; VA 0x00b6fd00 ; FUN_00b6fd00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b6fd00(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  char *pcVar8;
  char *pcVar9;
  uint uVar10;
  uint uVar11;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  char *in_stack_00000024;
  int in_stack_0000002c;
  int in_stack_000000fc;
  int in_stack_000001cc;
  undefined uVar12;
  undefined4 uVar13;
  int *piVar14;
  undefined4 uVar15;
  undefined *puVar16;
  uint *puVar17;
  undefined4 uVar18;
  int iStack_40;
  int *piStack_3c;
  undefined auStack_38 [8];
  uint uStack_30;
  undefined4 *puStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f68a1;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FirePlayerProgressionEvent",0x1a);
  uStack_8._0_1_ = 5;
  cVar3 = FUN_00b73760(auStack_28);
  uStack_8._0_1_ = 4;
  uVar12 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_14) {
    uVar11 = uStack_14 + 1;
    uVar10 = auStack_28[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_28[0] - 4);
      uVar11 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar10) - 4) {
        uStack_8._0_1_ = uVar12;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  if (cVar3 != '\0') {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piVar14 = &iStack_40;
    uVar13 = 0xb6fdda;
    FUN_00b6b1f0(piVar14,param_2,param_3,1);
    uStack_8._0_1_ = 6;
    if (iStack_40 != 0) {
      cVar3 = FUN_00b70910(&param_4);
      if (cVar3 == '\0') {
        FUN_0086f2f0(3,"AnalyticsService: Invalid string parameters.");
      }
      else {
        cVar3 = FUN_00b70af0(&stack0x00000028);
        if (((cVar3 != '\0') && (cVar3 = FUN_00b71040(&stack0x000000f8), cVar3 != '\0')) &&
           (cVar3 = FUN_00b707f0(&stack0x000001c8), cVar3 != '\0')) {
          FUN_00888650(auStack_38);
          uStack_8._0_1_ = 7;
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar1 = "category";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_0195679c,pcVar9 + -0x195679c);
          uStack_8._0_1_ = 8;
          iVar4 = FUN_005c4c00(auStack_28);
          uVar5 = FUN_0088cb40();
          *(undefined4 *)(iVar4 + 0x18) = uVar5;
          FUN_005c17a0(&param_4);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar1 = "location";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_0195673c,pcVar9 + -0x195673c);
          puVar16 = &stack0x00000028;
          uStack_8._0_1_ = 9;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(puVar16);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar1 = "statistics";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_019567a8,pcVar9 + -0x19567a8);
          puVar16 = &stack0x000000f8;
          uStack_8._0_1_ = 10;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(puVar16);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          iVar4 = ((((((uint)in_stack_00000024 & 0xff ^ 0x811c9dc5) * 0x1000193 ^
                     (uint)in_stack_00000024 >> 8 & 0xff) * 0x1000193 ^
                    (uint)in_stack_00000024 >> 0x10 & 0xff) * 0x1000193 ^
                   (uint)in_stack_00000024 >> 0x18) * 0x1000193 & _DAT_01ef0660) * 8;
          puStack_2c = *(undefined4 **)(iVar4 + DAT_01ef0654);
          pcVar1 = (char *)(iVar4 + 4);
          puVar6 = puStack_2c;
          while( true ) {
            puVar7 = DAT_01ef064c;
            if (puStack_2c != DAT_01ef064c) {
              puVar7 = (undefined4 *)**(undefined4 **)(pcVar1 + DAT_01ef0654);
            }
            if (puVar6 == puVar7) goto LAB_00b70346;
            if ((char *)puVar6[2] == in_stack_00000024) break;
            puVar6 = (undefined4 *)*puVar6;
          }
          if (puVar6 == DAT_01ef064c) {
LAB_00b70346:
            in_stack_00000024 = pcVar1;
            FUN_016ddcf9("invalid unordered_map<K, T> key");
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
          }
          uStack_18 = 0;
          puVar6 = puVar6 + 3;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar9 = "progressionStatus";
          do {
            pcVar8 = pcVar9;
            pcVar9 = pcVar8 + 1;
          } while (*pcVar8 != '\0');
          in_stack_00000024 = pcVar1;
          FUN_005542c0(&DAT_01956788,pcVar8 + -0x1956788);
          uStack_8._0_1_ = 0xb;
          FUN_005c4c00(auStack_28);
          FUN_005c16d0(puVar6);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar1 = "customData";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_0195677c,pcVar9 + -0x195677c);
          puVar16 = &stack0x000001c8;
          uStack_8._0_1_ = 0xc;
          FUN_005c4c00(auStack_28);
          FUN_0056ee80(puVar16);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          FUN_00888650(&uStack_30);
          puVar16 = auStack_38;
          uStack_8._0_1_ = 0xd;
          FUN_005c4c00(&DAT_01d67514);
          FUN_00b67be0(puVar16);
          uStack_18 = 0;
          uStack_14 = 0xf;
          auStack_28[0] = auStack_28[0] & 0xffffff00;
          pcVar1 = "_FirePlayerProgressionEvent";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_01956710,pcVar9 + -0x1956710);
          puVar17 = auStack_28;
          uStack_8._0_1_ = 0xe;
          uVar5 = 0xb701bb;
          FUN_005c4c00(&DAT_01d674b4);
          FUN_00632ce0(puVar17);
          uStack_8._0_1_ = 0xd;
          FUN_005507b0();
          uVar15 = 0;
          uVar18 = 0xf;
          uVar12 = 0;
          pcVar1 = "_FirePlayerProgressionEvent";
          do {
            pcVar9 = pcVar1;
            pcVar1 = pcVar9 + 1;
          } while (*pcVar9 != '\0');
          FUN_005542c0(&DAT_01956710,pcVar9 + -0x1956710);
          FUN_00b6e320(&iStack_40,uStack_30,uVar12,uVar13,piVar14,uVar5,uVar15,uVar18);
          if (*(int **)(param_1 + 0x58) != (int *)0x0) {
            pcVar2 = *(code **)(**(int **)(param_1 + 0x58) + 0xc);
            uVar13 = FUN_00557fc0(&uStack_30);
            uStack_8._0_1_ = 0xf;
            FUN_005c15a0(uVar13);
            uStack_8._0_1_ = 0x10;
            uStack_30 = uStack_30 & 0xffffff00;
            in_stack_00000024 = "FirePlayerProgressionEvent";
            pcVar1 = "_FirePlayerProgressionEvent";
            do {
              pcVar9 = pcVar1;
              pcVar1 = pcVar9 + 1;
            } while (*pcVar9 != '\0');
            FUN_005542c0(&DAT_01956710,pcVar9 + -0x1956710);
            (*pcVar2)(uStack_30);
            FUN_0056e5b0();
            FUN_00550b30();
          }
          FUN_00550b30();
          FUN_00550b30();
          FUN_00550b30();
          goto LAB_00b6fe2d;
        }
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        iVar4 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
  }
LAB_00b6fe2d:
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar14 = param_3 + 2;
      iVar4 = *piVar14;
      *piVar14 = *piVar14 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  uVar12 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000020) {
    uVar11 = in_stack_00000020 + 1;
    uVar10 = param_4;
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(param_4 - 4);
      uVar11 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - uVar10) - 4) {
        uStack_8._0_1_ = uVar12;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uStack_8._0_1_ = 0x11;
  if (in_stack_0000002c != 0) {
    (**(code **)(in_stack_0000002c + 8))(&stack0x00000030);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  if (in_stack_000000fc != 0) {
    (**(code **)(in_stack_000000fc + 8))(&stack0x00000100);
  }
  uStack_8 = 0x13;
  if (in_stack_000001cc != 0) {
    (**(code **)(in_stack_000001cc + 8))(&stack0x000001d0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24732 ; VA 0x00b70360 ; FUN_00b70360 */

undefined4 __thiscall FUN_00b70360(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x90);
  return param_2;
}



/* FUNCTION 24733 ; VA 0x00b70380 ; FUN_00b70380 */

void FUN_00b70380(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined8 param_10)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint auStack_90 [2];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f68c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_34 = (undefined4 *)0xb703ac;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870();
  if (iVar3 != 0) {
    uStack_30 = 0xb703bf;
    iStack_14 = FUN_00b15250();
    if (iStack_14 != 0) {
      puStack_18 = auStack_4c;
      piStack_54 = (int *)auStack_24;
      uStack_58 = 0xb703dc;
      puVar4 = (undefined4 *)FUN_0060e0c0();
      piVar1 = (int *)puVar4[1];
      uStack_58 = *puVar4;
      uStack_50 = 0;
      *puVar4 = 0;
      puVar4[1] = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[2] = piVar1[2] + 1;
        UNLOCK();
      }
      uStack_5c = 0xb70419;
      piStack_54 = piVar1;
      FUN_00b678f0();
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          uStack_50 = 0xb70430;
          (**(code **)(*piVar1 + 4))();
        }
      }
      uStack_8._0_1_ = 2;
      uStack_70 = 0;
      puStack_1c = (undefined *)auStack_90;
      auStack_90[0] = 0;
      puVar2 = auStack_90;
      if (param_4 != 0) {
        auStack_90[0] = param_4;
        if ((param_4 & 1) == 0) {
          (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_88,0);
          puVar2 = (uint *)puStack_1c;
        }
        else {
          uStack_88 = param_6;
          uStack_84 = param_7;
          uStack_80 = param_8;
          uStack_7c = param_9;
          uStack_78 = param_10;
          puVar2 = auStack_90;
        }
      }
      puStack_1c = (undefined *)puVar2;
      FUN_00b67740();
      uStack_70 = param_3;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_78 = CONCAT44(param_2,param_1);
      uStack_7c = 0xb7049b;
      FUN_00b265e0();
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          uStack_30 = 0xb704af;
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  uStack_8 = 3;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_38 = &param_6;
    uStack_30 = 2;
    uStack_3c = 0xb704d3;
    puStack_34 = puStack_38;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24734 ; VA 0x00b70500 ; FUN_00b70500 */

/* WARNING: Removing unreachable block (ram,0x00b705b3) */
/* WARNING: Removing unreachable block (ram,0x00b705bc) */
/* WARNING: Removing unreachable block (ram,0x00b705ca) */

int FUN_00b70500(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f6900;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uVar4 = *puVar3;
  uStack_8 = 2;
  uStack_7 = 0;
  if (uVar4 == 0) {
    uVar6 = FUN_0054fda0();
    _uStack_8 = CONCAT31(uStack_7,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar6);
  }
  iVar5 = (**(code **)((uVar4 & 0xfffffffe) + 4))(puVar3 + 2,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 24735 ; VA 0x00b70600 ; FUN_00b70600 */

int FUN_00b70600(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint in_stack_0000001c;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f6928;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8._0_1_ = 1;
  if (iStack_18 != 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("AnalyticsService.GetProductInfoError",0x24);
    uStack_8._0_1_ = 2;
    iVar3 = FUN_005d1470(auStack_30);
    *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 1;
    if (0xf < uStack_1c) {
      uVar4 = uStack_1c + 1;
      uVar5 = auStack_30[0];
      if (0xfff < uVar4) {
        uVar5 = *(uint *)(auStack_30[0] - 4);
        uVar4 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar3 = FUN_01674ea0(uVar5,uVar4);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 24736 ; VA 0x00b70720 ; FUN_00b70720 */

/* WARNING: Removing unreachable block (ram,0x00b7077d) */
/* WARNING: Removing unreachable block (ram,0x00b70789) */
/* WARNING: Removing unreachable block (ram,0x00b70797) */

undefined4 FUN_00b70720(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1328;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b6a620(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 24737 ; VA 0x00b707b0 ; FUN_00b707b0 */

uint FUN_00b707b0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b67d80();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24738 ; VA 0x00b707d0 ; FUN_00b707d0 */

uint FUN_00b707d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b67d80();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24739 ; VA 0x00b707f0 ; FUN_00b707f0 */

undefined FUN_00b707f0(undefined4 param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined uVar4;
  uint auStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0098fc00(param_1,auStack_28,1);
  if (cVar1 == '\0') {
    FUN_0086f2f0(3,"AnalyticsService can only accept valid UTF-8 characters.");
    uVar4 = 0;
  }
  else if (DAT_01d67190 < uStack_18) {
    FUN_0086f2f0(3,"AnalyticsService: customData too long.");
    uVar4 = 0;
  }
  else {
    uVar4 = 1;
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 24740 ; VA 0x00b708c0 ; FUN_00b708c0 */

undefined4 FUN_00b708c0(undefined4 *param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  
  cVar2 = FUN_00b70910(param_1);
  if (cVar2 == '\0') {
    return 0;
  }
  piVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (((*piVar1 != 0) &&
      (puVar3 = (undefined4 *)FUN_0170db20(param_1,0x5f,*piVar1), puVar3 != (undefined4 *)0x0)) &&
     (puVar3 == param_1)) {
    return 0;
  }
  return 1;
}



/* FUNCTION 24741 ; VA 0x00b70910 ; FUN_00b70910 */

uint FUN_00b70910(undefined4 *param_1)

{
  int iVar1;
  uint uVar2;
  char *pcVar3;
  undefined4 *puVar4;
  char acStack_c [8];
  
  uVar2 = param_1[4];
  if ((uVar2 != 0) && (uVar2 <= DAT_01d67168)) {
    builtin_strncpy(acStack_c,",\"\'\r\n",5);
    pcVar3 = acStack_c;
    do {
      puVar4 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar4 = (undefined4 *)*param_1;
      }
      if (uVar2 != 0) {
        iVar1 = FUN_0170db20(puVar4,(int)*pcVar3,uVar2);
        if ((iVar1 != 0) && (uVar2 = iVar1 - (int)puVar4, uVar2 != 0xffffffff)) break;
        uVar2 = param_1[4];
      }
      pcVar3 = pcVar3 + 1;
      if (pcVar3 == acStack_c + 5) {
        return CONCAT31((int3)(uVar2 >> 8),1);
      }
    } while( true );
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 24742 ; VA 0x00b70990 ; FUN_00b70990 */

undefined FUN_00b70990(int *param_1,uint param_2,undefined4 param_3)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  byte ****ppppbVar4;
  uint uVar5;
  int iVar6;
  undefined uVar7;
  byte ****ppppbVar8;
  char acStack_128 [256];
  byte ***apppbStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar6 != iVar2) {
    FUN_0086f2f0(3,"AnalyticsService: %s is not a string.",param_3);
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00563690(apppbStack_28);
  uStack_8 = 0;
  if (param_2 < uStack_18) {
    FUN_0086f2f0(3,"AnalyticsService: %s shouldn\'t be longer than %d.",param_3,param_2);
    uVar7 = 0;
  }
  else {
    ppppbVar8 = apppbStack_28;
    if (0xf < uStack_14) {
      ppppbVar8 = (byte ****)apppbStack_28[0];
    }
    if (uStack_18 != 0) {
      FUN_0170d1f0(acStack_128,0,0x100);
      pbVar3 = &DAT_01956cb0;
      iVar6 = 4;
      do {
        bVar1 = *pbVar3;
        pbVar3 = pbVar3 + 1;
        acStack_128[bVar1] = '\x01';
        iVar6 = iVar6 + -1;
      } while (iVar6 != 0);
      for (ppppbVar4 = ppppbVar8; ppppbVar4 < (byte ****)((int)ppppbVar8 + uStack_18);
          ppppbVar4 = (byte ****)((int)ppppbVar4 + 1)) {
        if (acStack_128[*(byte *)ppppbVar4] != '\0') {
          if ((int)ppppbVar4 - (int)ppppbVar8 != -1) {
            FUN_0086f2f0(3,
                         "AnalyticsService: \',\', \'\"\' and \'\\r\\n\' are not allowed in string parameters."
                        );
            uVar7 = 0;
            goto LAB_00b70a84;
          }
          break;
        }
      }
    }
    uVar7 = 1;
  }
LAB_00b70a84:
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppbVar8 = (byte ****)apppbStack_28[0];
    if (0xfff < uVar5) {
      ppppbVar8 = (byte ****)apppbStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if ((byte *)0x1f < (byte *)((int)apppbStack_28[0] + (-4 - (int)ppppbVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppbVar8,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 24743 ; VA 0x00b70af0 ; FUN_00b70af0 */

undefined FUN_00b70af0(int *param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d675ac != '\0') {
    iVar1 = *param_1;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00888530();
    if (iVar1 == iVar3) {
      ExceptionList = pvStack_10;
      return 1;
    }
    iVar1 = *param_1;
    iVar3 = FUN_008882f0();
    if (iVar1 == iVar3) {
      FUN_00636130(&piStack_18);
      if (*piStack_18 == piStack_18[1]) {
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 1;
      }
      FUN_00550b30();
    }
  }
  iVar1 = *param_1;
  iVar3 = FUN_008881d0();
  if (iVar1 != iVar3) {
    FUN_0086f2f0(3,"AnalyticsService: %s isn\'t a dictionary.",&DAT_0195673c);
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00636000(&piStack_18);
  uStack_8 = 0;
  if (DAT_01d671ac < (uint)piStack_18[2]) {
    FUN_0086f2f0(3,"AnalyticsService: %s size is limit to %d.",&DAT_0195673c,DAT_01d671ac);
    uVar4 = 0;
  }
  else {
    if (piStack_18[2] == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(piStack_18[5] + piStack_18[1] * 4);
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      piVar6 = puVar5 + 2;
      cVar2 = FUN_00b70910(piVar6);
      if (cVar2 == '\0') {
        if (0xf < (uint)puVar5[7]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_0086f2f0(3,"AnalyticsService: %s has an invalid Key: %s.",&DAT_0195673c,piVar6);
LAB_00b70c73:
        uVar4 = 0;
        goto LAB_00b70c1b;
      }
      if (0xf < (uint)puVar5[7]) {
        piVar6 = (int *)*piVar6;
      }
      cVar2 = FUN_00b70990(puVar5 + 8,DAT_01d671a4,piVar6);
      if (cVar2 == '\0') goto LAB_00b70c73;
    }
    uVar4 = 1;
  }
LAB_00b70c1b:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piStack_14 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 24744 ; VA 0x00b70c80 ; FUN_00b70c80 */

undefined4 FUN_00b70c80(undefined4 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  int iVar9;
  undefined auStack_130 [200];
  undefined auStack_68 [24];
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [8];
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f696b;
  pvStack_10 = ExceptionList;
  pbVar8 = (byte *)*param_1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("teleportType",0xc);
  pbVar8 = pbVar8 + *pbVar8 + 1;
  uVar1 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_1,uVar1,auStack_28,-(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if ((param_1 == (undefined4 *)0x0) ||
     (iVar9 = param_1[8], iVar2 = thunk_FUN_00adb880(), iVar9 != iVar2)) {
    ExceptionList = pvStack_10;
    return 0;
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("teleportType",0xc);
  uStack_8 = 0;
  piVar3 = (int *)FUN_0091d440(auStack_28);
  iVar9 = *piVar3;
  iVar2 = thunk_FUN_00adb880();
  if (iVar9 == iVar2) {
    iVar9 = *piVar3;
    iVar2 = thunk_FUN_00adb880();
    if (iVar9 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = piVar3 + 2;
    if (piVar3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar9 = *piVar4;
  }
  else {
    puVar5 = (undefined4 *)piVar3[1];
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)*puVar5)(piVar3 + 2,auStack_130);
      puVar5 = (undefined4 *)piVar3[1];
    }
    uStack_8._0_1_ = 1;
    piVar3 = (int *)FUN_00ac3040();
    iVar9 = *piVar3;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (puVar5 != (undefined4 *)0x0) {
      (*(code *)puVar5[2])(auStack_130);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  if (iVar9 != 0) {
    if (iVar9 == 2) {
      ExceptionList = pvStack_10;
      return 0;
    }
    if (iVar9 != 1) {
      ExceptionList = pvStack_10;
      return 0;
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("joinData",8);
    FUN_00580040(&param_1,auStack_28);
    FUN_005507b0();
    if ((param_1 != (undefined4 *)0x0) &&
       (iVar9 = param_1[8], iVar2 = FUN_0088cb40(), iVar9 == iVar2)) {
      FUN_00563690(auStack_68);
      uStack_8 = 3;
      puStack_2c = (undefined4 *)FUN_01674e20(0x24);
      param_1 = puStack_2c;
      if (puStack_2c == (undefined4 *)0x0) {
        puStack_2c = (undefined4 *)0x0;
      }
      else {
        puStack_2c[1] = 1;
        puStack_2c[2] = 1;
        *puStack_2c = std::
                      _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
                      ::vftable;
        *(undefined *)(puStack_2c + 3) = 0;
        uVar1 = FUN_00588320(0xb);
        puStack_2c[4] = uVar1;
        puStack_2c[5] = 0;
        puStack_2c[6] = 0x3f800000;
        puStack_2c[7] = 0;
        puStack_2c[8] = 0;
      }
      puStack_30 = puStack_2c + 3;
      uStack_8._0_1_ = 4;
      FUN_0098f070(auStack_68,&puStack_30,0);
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      FUN_005542c0("userData",8);
      FUN_00580040(&param_1,auStack_28);
      FUN_005507b0();
      if ((param_1 != (undefined4 *)0x0) &&
         (iVar9 = param_1[8], iVar2 = FUN_008881d0(), iVar9 == iVar2)) {
        FUN_00636000(auStack_38);
        uStack_8._0_1_ = 5;
        uStack_40 = 0;
        uStack_3c = 0xf;
        auStack_50[0] = 0;
        FUN_005542c0("Members",7);
        FUN_00580040(&param_1,auStack_50);
        FUN_005507b0();
        if ((param_1 != (undefined4 *)0x0) &&
           (iVar9 = param_1[8], iVar2 = FUN_008882f0(), iVar9 == iVar2)) {
          FUN_00550b30();
          FUN_00550b30();
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return 0;
        }
        FUN_00550b30();
      }
      FUN_00550b30();
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 24745 ; VA 0x00b71040 ; FUN_00b71040 */

undefined FUN_00b71040(int *param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d675ac != '\0') {
    iVar1 = *param_1;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00888530();
    if (iVar1 == iVar3) {
      ExceptionList = pvStack_10;
      return 1;
    }
    iVar1 = *param_1;
    iVar3 = FUN_008882f0();
    if (iVar1 == iVar3) {
      FUN_00636130(&piStack_18);
      if (*piStack_18 == piStack_18[1]) {
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 1;
      }
      FUN_00550b30();
    }
  }
  iVar1 = *param_1;
  iVar3 = FUN_008881d0();
  if (iVar1 != iVar3) {
    FUN_0086f2f0(3,"AnalyticsService: %s isn\'t a dictionary.",&DAT_019567a8);
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00636000(&piStack_18);
  uStack_8 = 0;
  if (DAT_01d671b4 < (uint)piStack_18[2]) {
    FUN_0086f2f0(3,"AnalyticsService: %s size is limit to %d.",&DAT_019567a8,DAT_01d671b4);
    uVar4 = 0;
  }
  else {
    if (piStack_18[2] == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = *(undefined4 **)(piStack_18[5] + piStack_18[1] * 4);
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      piVar6 = puVar5 + 2;
      cVar2 = FUN_00b70910(piVar6);
      if (cVar2 == '\0') {
        if (0xf < (uint)puVar5[7]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_0086f2f0(3,"AnalyticsService: %s has an invalid Key: %s.",&DAT_019567a8,piVar6);
        uVar4 = 0;
        goto LAB_00b71155;
      }
      if (*(char *)(puVar5[8] + 0x21) == '\0') {
        if (0xf < (uint)puVar5[7]) {
          piVar6 = (int *)*piVar6;
        }
        FUN_0086f2f0(3,"AnalyticsService: the value in %s should be a number, key: %s",&DAT_019567a8
                     ,piVar6);
        uVar4 = 0;
        goto LAB_00b71155;
      }
    }
    uVar4 = 1;
  }
LAB_00b71155:
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piStack_14 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 24746 ; VA 0x00b711e0 ; FUN_00b711e0 */

void FUN_00b711e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b73400();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24747 ; VA 0x00b71220 ; FUN_00b71220 */

void FUN_00b71220(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b734b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24748 ; VA 0x00b71260 ; FUN_00b71260 */

void FUN_00b71260(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b73560();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24749 ; VA 0x00b712a0 ; FUN_00b712a0 */

void FUN_00b712a0(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x20);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_005e5f00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1de9334);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_085b9040da1dea372cb61b00ae9b40af>::RTTI_Type_Descriptor;
  return;
}


