/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 12750 ; VA 0x00838a70 ; FUN_00838a70 */

undefined __fastcall FUN_00838a70(int param_1)

{
  return *(undefined *)(param_1 + 0x59);
}



/* FUNCTION 12751 ; VA 0x00838a80 ; FUN_00838a80 */

void FUN_00838a80(float *param_1,int param_2,int param_3)

{
  int iVar1;
  float fVar2;
  
  iVar1 = param_2 % 3;
  fVar2 = (float)((param_2 / 3) * -2 + 1);
  *param_1 = *(float *)(param_3 + iVar1 * 4) * fVar2;
  param_1[1] = *(float *)(param_3 + 0xc + iVar1 * 4) * fVar2;
  param_1[2] = *(float *)(param_3 + 0x18 + iVar1 * 4) * fVar2;
  return;
}



/* FUNCTION 12752 ; VA 0x00838ae0 ; FUN_00838ae0 */

void __fastcall FUN_00838ae0(int param_1)

{
  if (*(char *)(param_1 + 0xc1) == '\0') {
    *(undefined *)(param_1 + 0xc1) = 1;
    if (param_1 == 0x38) {
      param_1 = 0;
    }
    FUN_007c8ce0(param_1);
  }
  return;
}



/* FUNCTION 12753 ; VA 0x00838b10 ; FUN_00838b10 */

int __thiscall FUN_00838b10(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b71f8;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    iVar3 = (**(code **)(*(int *)(param_1 + 0x38) + 8))();
    ExceptionList = pvStack_10;
    return iVar3;
  }
  param_2 = param_2 + -5;
  if (param_2 == 0) {
    piVar4 = *(int **)(param_1 + 0x60);
    ExceptionList = &pvStack_10;
    if (piVar4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0x60);
    }
    uStack_18 = *(undefined4 *)(param_1 + 0x5c);
    uStack_8 = 0;
    piStack_14 = piVar4;
    cVar2 = FUN_011584d0(uStack_18);
    if (cVar2 == '\0') {
      param_2 = (**(code **)(*(int *)(param_1 + 0x38) + 4))();
    }
    else {
      (**(code **)(*(int *)(param_1 + 0x38) + 0x40))();
      param_2 = FUN_00836d10(&uStack_18);
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar3 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12754 ; VA 0x00838be0 ; FUN_00838be0 */

void __thiscall FUN_00838be0(int param_1,undefined *param_2)

{
  if (param_2 == &DAT_01eed1b0) {
    (**(code **)(*(int *)(param_1 + 0x38) + 8))();
  }
  return;
}



/* FUNCTION 12755 ; VA 0x00838c10 ; FUN_00838c10 */

void __thiscall FUN_00838c10(int param_1,char param_2)

{
  int iVar1;
  
  iVar1 = param_1 + 0x38;
  if (param_2 != '\0') {
    if (param_1 == 0) {
      iVar1 = 0;
    }
    FUN_007c7a50(iVar1,4);
    return;
  }
  if (param_1 == 0) {
    iVar1 = 0;
  }
  FUN_007c7840(iVar1,4);
  return;
}



/* FUNCTION 12756 ; VA 0x00838c50 ; FUN_00838c50 */

void __thiscall FUN_00838c50(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *param_1;
  *param_1 = param_2;
  if (iVar1 != 0) {
    FUN_01674ea0(*(undefined4 *)(iVar1 + 0x10));
    FUN_01674ea0(*(undefined4 *)(iVar1 + 0xc));
    FUN_01674ea0(*(undefined4 *)(iVar1 + 8));
    FUN_01674ea0(*(undefined4 *)(iVar1 + 4));
    FUN_01674ea0(iVar1,0x14);
  }
  return;
}



/* FUNCTION 12757 ; VA 0x00838c90 ; FUN_00838c90 */

void FUN_00838c90(int *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  uVar1 = param_3;
  iVar2 = FUN_01674e20(param_3 * param_3);
  FUN_0170d1f0(iVar2,0,param_3 * param_3);
  if (param_2 != 0) {
    uVar3 = param_2;
    if (param_3 < param_2) {
      uVar3 = param_3;
    }
    if (uVar3 != 0) {
      iVar4 = (param_3 + 1) * (param_3 - uVar3 >> 1) + iVar2;
      iVar5 = (param_2 + 1) * (param_2 - uVar3 >> 1) + *param_1;
      param_3 = uVar3;
      do {
        FUN_0170c6f0(iVar4,iVar5,uVar3);
        iVar5 = iVar5 + param_2;
        iVar4 = iVar4 + uVar1;
        param_3 = param_3 - 1;
      } while (param_3 != 0);
    }
  }
  iVar4 = *param_1;
  *param_1 = iVar2;
  FUN_01674ea0(iVar4);
  return;
}



/* FUNCTION 12758 ; VA 0x00838d30 ; FUN_00838d30 */

int __fastcall FUN_00838d30(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_011590c0();
  *(undefined4 *)(param_1 + 0x1c) = 0;
  piVar3 = *(int **)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x20) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  piVar3 = *(int **)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00838da4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 12759 ; VA 0x00838db0 ; FUN_00838db0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00838db0(int param_1)

{
  float fVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  float *pfVar7;
  undefined8 *puVar8;
  int iVar9;
  int iVar10;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  float fStack_40;
  undefined auStack_3c [12];
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined8 uStack_20;
  int iStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  char cStack_5;
  
  if (*(int *)(param_1 + 0x24) != 0) {
    fStack_30 = *(float *)(param_1 + -0x20);
    fStack_2c = *(float *)(param_1 + -0x1c);
    fStack_28 = *(float *)(param_1 + -0x18);
    fStack_24 = *(float *)(param_1 + -0x14);
    uStack_20 = *(undefined8 *)(param_1 + -0x10);
    if (*(int *)(param_1 + 0x1c) == 0) {
      puVar5 = (undefined4 *)FUN_0060efa0();
    }
    else {
      puVar3 = (undefined4 *)FUN_00b077e0();
      uStack_cc = *puVar3;
      uStack_c8 = puVar3[1];
      uStack_c4 = puVar3[2];
      uStack_c0 = puVar3[3];
      uStack_bc = puVar3[4];
      uStack_b8 = puVar3[5];
      uStack_b4 = puVar3[6];
      uStack_b0 = puVar3[7];
      puVar5 = &uStack_cc;
      uStack_ac = puVar3[8];
      uStack_a8 = puVar3[9];
      uStack_a4 = puVar3[10];
      uStack_a0 = puVar3[0xb];
    }
    cStack_5 = '\0';
    uStack_9c = *puVar5;
    uStack_98 = puVar5[1];
    uStack_94 = puVar5[2];
    uStack_90 = puVar5[3];
    uStack_8c = puVar5[4];
    uStack_88 = puVar5[5];
    uStack_84 = puVar5[6];
    uStack_80 = puVar5[7];
    uStack_7c = puVar5[8];
    uStack_78 = puVar5[9];
    uStack_74 = puVar5[10];
    uStack_70 = puVar5[0xb];
    iStack_18 = *(int *)(*(int *)(param_1 + 0x24) + 0x34);
    if ((iStack_18 != 0) &&
       (iVar9 = *(int *)(iStack_18 + 0xc), iVar4 = FUN_00d6bbd0(),
       (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      puVar5 = (undefined4 *)FUN_00d6c6c0(&uStack_cc);
      cStack_5 = '\x01';
      uStack_9c = *puVar5;
      uStack_98 = puVar5[1];
      uStack_94 = puVar5[2];
      uStack_90 = puVar5[3];
      uStack_8c = puVar5[4];
      uStack_88 = puVar5[5];
      uStack_84 = puVar5[6];
      uStack_80 = puVar5[7];
      uStack_7c = puVar5[8];
      uStack_78 = puVar5[9];
      uStack_74 = puVar5[10];
      uStack_70 = puVar5[0xb];
    }
    if ((*(char *)(param_1 + 0xc1) != '\0') || (cVar2 = FUN_01163470(&uStack_9c), cVar2 == '\0')) {
      *(undefined4 *)(param_1 + 0x34) = uStack_9c;
      *(undefined4 *)(param_1 + 0x38) = uStack_98;
      *(undefined4 *)(param_1 + 0x3c) = uStack_94;
      *(undefined4 *)(param_1 + 0x40) = uStack_90;
      *(undefined4 *)(param_1 + 0x44) = uStack_8c;
      *(undefined4 *)(param_1 + 0x48) = uStack_88;
      *(undefined4 *)(param_1 + 0x4c) = uStack_84;
      *(undefined4 *)(param_1 + 0x50) = uStack_80;
      *(undefined4 *)(param_1 + 0x54) = uStack_7c;
      *(undefined4 *)(param_1 + 0x58) = uStack_78;
      *(undefined4 *)(param_1 + 0x5c) = uStack_74;
      *(undefined4 *)(param_1 + 0x60) = uStack_70;
      if (*(int *)(param_1 + 0x1c) == 0) {
        uStack_44 = 0xff7fffff;
        uStack_54 = _DAT_018c4eb0;
        uStack_50 = _UNK_018c4eb4;
        uStack_4c = _UNK_018c4eb8;
        uStack_48 = _UNK_018c4ebc;
        fStack_40 = -3.4028235e+38;
        FUN_008411b0(&uStack_54,*(undefined4 *)(*(int *)(*(int *)(param_1 + -0x30) + 0x4e4) + 0x24))
        ;
      }
      else {
        iVar9 = *(int *)(param_1 + 0x24);
        *(undefined8 *)(param_1 + 100) = *(undefined8 *)(param_1 + 0x58);
        *(undefined8 *)(param_1 + 0x70) = 0;
        *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x60);
        fStack_c = 0.0;
        *(undefined4 *)(param_1 + 0x78) = 0;
        *(undefined4 *)(param_1 + 0x7c) = 0;
        *(undefined4 *)(param_1 + 0x80) = 0;
        *(undefined4 *)(param_1 + 0x84) = 0;
        *(undefined4 *)(param_1 + 0x88) = 0;
        *(undefined4 *)(param_1 + 0x8c) = 0;
        *(undefined4 *)(param_1 + 0x90) = 0;
        *(undefined4 *)(param_1 + 0x94) = 0;
        *(undefined4 *)(param_1 + 0x98) = 0;
        iVar4 = *(int *)(iVar9 + 0xc);
        iVar6 = FUN_00d41530();
        iVar10 = 0;
        if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar10 = iVar9;
        }
        if (iVar10 == 0) {
          iVar9 = FUN_00836580();
          if (iVar9 != 0) {
            puVar8 = (undefined8 *)
                     FUN_00838a80(auStack_3c,*(undefined4 *)(iVar9 + 0x74),param_1 + 0x34);
            *(undefined8 *)(param_1 + 0x70) = *puVar8;
            *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(puVar8 + 1);
          }
        }
        else {
          uStack_4c = 0;
          uStack_48 = 0;
          uStack_44 = 0;
          fStack_40 = 0.0;
          pfVar7 = (float *)FUN_00b082f0(auStack_3c);
          fStack_14 = *pfVar7 * DAT_018ce2f4;
          fStack_10 = pfVar7[1] * DAT_018ce2f4;
          fStack_c = pfVar7[2] * DAT_018ce2f4;
          FUN_008386f0(*(undefined4 *)(iVar10 + 0x74),param_1 + 0x34,&fStack_14,&uStack_4c,
                       param_1 + 0x7c,param_1 + 0x8c);
          if (cStack_5 == '\0') {
            pfVar7 = (float *)FUN_011658d0(auStack_3c);
            fStack_c = pfVar7[2] * fStack_40 + *(float *)(param_1 + 0x60);
            *(ulonglong *)(param_1 + 100) =
                 CONCAT44(pfVar7[1] * fStack_40 + *(float *)(param_1 + 0x5c),
                          *pfVar7 * fStack_40 + *(float *)(param_1 + 0x58));
            *(float *)(param_1 + 0x6c) = fStack_c;
          }
          else {
            *(undefined4 *)(param_1 + 0x88) = 0;
            *(undefined4 *)(param_1 + 0x98) = 0;
          }
          puVar8 = (undefined8 *)FUN_011658d0(auStack_3c);
          *(undefined8 *)(param_1 + 0x70) = *puVar8;
          *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(puVar8 + 1);
        }
        FUN_00837840(&uStack_b4,param_1 + 100,param_1 + 0x70,param_1 + 0x7c,param_1 + 0x8c,
                     *(undefined4 *)(param_1 + 0x24));
        FUN_008411b0(&uStack_b4,*(undefined4 *)(*(int *)(*(int *)(param_1 + -0x30) + 0x4e4) + 0x24))
        ;
      }
      if (((fStack_30 <= fStack_24) && (fStack_2c <= (float)uStack_20)) &&
         (fStack_28 <= uStack_20._4_4_)) {
        FUN_007c7670(&fStack_30);
      }
      fVar1 = *(float *)(param_1 + -0x20);
      if (((fVar1 < *(float *)(param_1 + -0x14) || fVar1 == *(float *)(param_1 + -0x14)) &&
          (*(float *)(param_1 + -0x1c) < *(float *)(param_1 + -0x10) ||
           *(float *)(param_1 + -0x1c) == *(float *)(param_1 + -0x10))) &&
         (*(float *)(param_1 + -0x18) < *(float *)(param_1 + -0xc) ||
          *(float *)(param_1 + -0x18) == *(float *)(param_1 + -0xc))) {
        FUN_007c7670((float *)(param_1 + -0x20));
      }
    }
  }
  return;
}



/* FUNCTION 12760 ; VA 0x00839150 ; FUN_00839150 */

void __fastcall FUN_00839150(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  float10 fVar8;
  float fVar9;
  int iStack_10;
  int iStack_c;
  
  if (param_1[3] == param_1[4]) {
    if ((((float)param_1[-8] < (float)param_1[-5] || (float)param_1[-8] == (float)param_1[-5]) &&
        ((float)param_1[-7] < (float)param_1[-4] || (float)param_1[-7] == (float)param_1[-4])) &&
       ((float)param_1[-6] < (float)param_1[-3] || (float)param_1[-6] == (float)param_1[-3])) {
      FUN_007c7670(param_1 + -8);
    }
    if (param_1 == (int *)0x38) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  (**(code **)(*param_1 + 0x44))();
  iVar6 = param_1[9];
  if ((iVar6 == 0) || (*(char *)(iVar6 + 0x58) == '\0')) {
    param_1[0x27] = 0;
  }
  else {
    iVar3 = *(int *)(iVar6 + 100);
    iStack_10 = (int)*(undefined8 *)(iVar6 + 0x5c);
    iStack_c = (int)((ulonglong)*(undefined8 *)(iVar6 + 0x5c) >> 0x20);
    param_1[0x28] = iStack_10;
    param_1[0x29] = iStack_c;
    param_1[0x2a] = iVar3;
    param_1[0x2b] = *(int *)(iVar6 + 0x68);
    iVar3 = *(int *)(iVar6 + 0xc);
    iVar2 = FUN_00d41530();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar5 = iVar6;
    }
    if (iVar5 == 0) {
      iVar3 = FUN_00836580();
      if (iVar3 == 0) {
        iVar3 = FUN_00836550();
        if (iVar3 == 0) {
          iVar6 = param_1[9];
          param_1[0x27] = 0;
        }
        else {
          iVar6 = param_1[9];
          param_1[0x27] = 1;
          param_1[0x2c] = *(int *)(iVar3 + 0x6c);
          param_1[0x2d] = 0;
          param_1[0x2f] = 0x3b83126f;
        }
      }
      else {
        iVar6 = param_1[9];
        param_1[0x27] = 2;
        param_1[0x2c] = *(int *)(iVar3 + 0x6c);
        param_1[0x2d] = *(int *)(iVar3 + 0x70);
        param_1[0x2f] = 0x3be56042;
      }
    }
    else {
      iVar6 = param_1[9];
      param_1[0x27] = 3;
      param_1[0x2c] = *(int *)(iVar5 + 0x6c);
      param_1[0x2d] = *(int *)(iVar5 + 0x70);
      param_1[0x2f] = 0;
    }
  }
  if ((iVar6 == 0) || (*(char *)(iVar6 + 0x59) == '\0')) {
    *(undefined *)(param_1 + 0x30) = 0;
    iVar6 = param_1[0xb];
    param_1[0xb] = 0;
    if (iVar6 != 0) {
      FUN_01674ea0();
      FUN_01674ea0(*(undefined4 *)(iVar6 + 0xc));
      FUN_01674ea0(*(undefined4 *)(iVar6 + 8));
      FUN_01674ea0(*(undefined4 *)(iVar6 + 4));
      FUN_01674ea0(iVar6,0x14);
    }
    puVar4 = (undefined4 *)param_1[0xc];
    param_1[0xc] = 0;
    if (puVar4 != (undefined4 *)0x0) {
      (**(code **)*puVar4)();
    }
  }
  else {
    *(undefined *)(param_1 + 0x30) = 1;
    if (param_1[0xb] == 0) {
      puVar4 = (undefined4 *)FUN_01674e20();
      if (puVar4 != (undefined4 *)0x0) {
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4[2] = 0;
        puVar4[3] = 0;
        puVar4[4] = 0;
      }
      FUN_00838c50();
      iVar6 = param_1[9];
    }
    iVar3 = *(int *)(iVar6 + 0xc);
    iVar2 = FUN_00d41330();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar5 = iVar6;
    }
    if (iVar5 == 0) {
      iVar3 = *(int *)(iVar6 + 0xc);
      iVar2 = FUN_00d41430();
      iVar5 = 0;
      if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        iVar5 = iVar6;
      }
      if (iVar5 == 0) {
        iVar3 = *(int *)(iVar6 + 0xc);
        iVar2 = FUN_00d41530();
        iVar5 = 0;
        if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
            (uint)*(ushort *)(iVar2 + 0x1da)) {
          iVar5 = iVar6;
        }
        if (iVar5 == 0) {
          fVar9 = 0.0;
        }
        else {
          fVar9 = *(float *)(iVar5 + 0x6c);
        }
      }
      else {
        fVar9 = *(float *)(iVar5 + 0x6c);
      }
    }
    else {
      fVar9 = *(float *)(iVar5 + 0x6c);
    }
    fVar8 = (float10)FUN_01725160((double)(fVar9 * DAT_018e1340));
    uVar7 = (int)fVar8 * 2 + 1;
    if (0x1f < uVar7) {
      uVar7 = 0x1f;
    }
    uVar1 = *(uint *)param_1[0xb];
    if (uVar7 != uVar1) {
      FUN_00838c90((uint *)param_1[0xb] + 1,uVar1,uVar7);
      FUN_00838c90((undefined4 *)param_1[0xb] + 2,*(undefined4 *)param_1[0xb],uVar7);
      FUN_00838c90((undefined4 *)param_1[0xb] + 3,*(undefined4 *)param_1[0xb],uVar7);
      FUN_00838c90((undefined4 *)param_1[0xb] + 4,*(undefined4 *)param_1[0xb],uVar7);
      *(uint *)param_1[0xb] = uVar7;
      *(undefined *)((int)param_1 + 0xc1) = 0;
      return;
    }
  }
  *(undefined *)((int)param_1 + 0xc1) = 0;
  return;
}



/* FUNCTION 12761 ; VA 0x008394f0 ; FUN_008394f0 */

int * __thiscall
FUN_008394f0(int *param_1,int param_2,undefined4 param_3,float param_4,float param_5)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  undefined8 *puVar6;
  float *pfVar7;
  float *pfVar8;
  int iVar9;
  int iVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined auStack_60 [64];
  undefined auStack_20 [12];
  int *piStack_14;
  undefined auStack_10 [8];
  float fStack_8;
  
  *param_1 = param_2;
  piStack_14 = param_1;
  FUN_01165ab0();
  FUN_01165ab0();
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  iVar9 = 6;
  do {
    FUN_0060f2c0();
    iVar9 = iVar9 + -1;
  } while (iVar9 != 0);
  param_1[0x3c] = (int)param_5;
  param_1[0x3b] = (int)param_4;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_5 = param_5 * DAT_018fde90;
  iVar9 = *(int *)(param_2 + 0x60);
  iVar4 = *(int *)(param_2 + 100);
  iVar1 = *(int *)(param_2 + 0x68);
  param_1[1] = *(int *)(param_2 + 0x5c);
  param_1[2] = iVar9;
  param_1[3] = iVar4;
  param_1[4] = iVar1;
  iVar9 = *(int *)(param_2 + 0x70);
  iVar4 = *(int *)(param_2 + 0x74);
  iVar1 = *(int *)(param_2 + 0x78);
  param_1[5] = *(int *)(param_2 + 0x6c);
  param_1[6] = iVar9;
  param_1[7] = iVar4;
  param_1[8] = iVar1;
  iVar9 = *(int *)(param_2 + 0x80);
  iVar4 = *(int *)(param_2 + 0x84);
  iVar1 = *(int *)(param_2 + 0x88);
  param_1[9] = *(int *)(param_2 + 0x7c);
  param_1[10] = iVar9;
  param_1[0xb] = iVar4;
  param_1[0xc] = iVar1;
  iVar9 = *(int *)(param_2 + 0x90);
  iVar4 = *(int *)(param_2 + 0x94);
  iVar1 = *(int *)(param_2 + 0x98);
  param_1[0xd] = *(int *)(param_2 + 0x8c);
  param_1[0xe] = iVar9;
  param_1[0xf] = iVar4;
  param_1[0x10] = iVar1;
  param_1[4] = (int)(param_4 * DAT_018fde90 + (float)param_1[4]);
  fVar11 = param_4 * DAT_018f997c;
  param_1[8] = (int)((float)param_1[8] - param_5);
  param_1[1] = (int)(fVar11 * (float)param_1[1]);
  param_1[6] = (int)(fVar11 * (float)param_1[6]);
  FUN_01165f50(2,param_3);
  piVar2 = (int *)FUN_01165af0(auStack_60,param_2 + 0x1c);
  iVar10 = 0;
  iVar9 = piVar2[1];
  iVar4 = piVar2[2];
  iVar1 = piVar2[3];
  param_1[0x11] = *piVar2;
  param_1[0x12] = iVar9;
  param_1[0x13] = iVar4;
  param_1[0x14] = iVar1;
  iVar9 = piVar2[5];
  iVar4 = piVar2[6];
  iVar1 = piVar2[7];
  param_1[0x15] = piVar2[4];
  param_1[0x16] = iVar9;
  param_1[0x17] = iVar4;
  param_1[0x18] = iVar1;
  iVar9 = piVar2[9];
  iVar4 = piVar2[10];
  iVar1 = piVar2[0xb];
  param_1[0x19] = piVar2[8];
  param_1[0x1a] = iVar9;
  param_1[0x1b] = iVar4;
  param_1[0x1c] = iVar1;
  iVar9 = piVar2[0xd];
  iVar4 = piVar2[0xe];
  iVar1 = piVar2[0xf];
  param_1[0x1d] = piVar2[0xc];
  param_1[0x1e] = iVar9;
  param_1[0x1f] = iVar4;
  param_1[0x20] = iVar1;
  piVar2 = param_1 + 0x23;
  do {
    piVar3 = (int *)FUN_007ccac0(iVar10);
    iVar10 = iVar10 + 1;
    iVar9 = piVar3[1];
    iVar4 = piVar3[2];
    iVar1 = piVar3[3];
    *piVar2 = *piVar3;
    piVar2[1] = iVar9;
    piVar2[2] = iVar4;
    piVar2[3] = iVar1;
    piVar2 = piVar2 + 4;
  } while (iVar10 < 6);
  iVar9 = FUN_007ccac0(3);
  iVar4 = FUN_007ccac0(2);
  piVar2 = piStack_14;
  piStack_14[0x21] = (int)((*(float *)(iVar9 + 0xc) + *(float *)(iVar4 + 0xc)) * DAT_018f993c);
  iVar9 = FUN_007ccac0(5);
  iVar4 = FUN_007ccac0(4);
  piVar2[0x22] = (int)((*(float *)(iVar4 + 0xc) + *(float *)(iVar9 + 0xc)) * DAT_018f993c);
  if (DAT_018ce2f8 <= param_4) {
    piVar2[0x32] = (int)((float)piVar2[0x32] - (float)piVar2[0x21] * DAT_018fde90);
    piVar2[0x36] = (int)((float)piVar2[0x36] - (float)piVar2[0x22] * DAT_018fde90);
    FUN_007ccaa0(2);
    puVar6 = (undefined8 *)FUN_011658d0(auStack_20);
    *(undefined8 *)(piVar2 + 0x3d) = *puVar6;
    piVar2[0x3f] = *(int *)(puVar6 + 1);
    FUN_007ccaa0(3);
    puVar6 = (undefined8 *)FUN_011658d0(auStack_20);
    *(undefined8 *)(piVar2 + 0x40) = *puVar6;
    piVar2[0x42] = *(int *)(puVar6 + 1);
    FUN_007ccaa0(6);
    pfVar7 = (float *)FUN_011658d0(auStack_20);
    FUN_007ccaa0(2);
    pfVar8 = (float *)FUN_011658d0(auStack_10);
    fStack_8 = (pfVar7[2] - pfVar8[2]) * DAT_018f993c;
    *(ulonglong *)(piVar2 + 0x43) =
         CONCAT44((pfVar7[1] - pfVar8[1]) * DAT_018f993c,(*pfVar7 - *pfVar8) * DAT_018f993c);
    piVar2[0x45] = (int)fStack_8;
    FUN_007ccaa0(0);
    pfVar7 = (float *)FUN_011658d0(auStack_20);
    FUN_007ccaa0(2);
    pfVar8 = (float *)FUN_011658d0(auStack_10);
    fVar13 = (*pfVar7 - *pfVar8) * DAT_018f993c;
    fVar12 = (pfVar7[1] - pfVar8[1]) * DAT_018f993c;
    fVar11 = (pfVar7[2] - pfVar8[2]) * DAT_018f993c;
  }
  else {
    FUN_007cc9d0();
    FUN_007cdc00(param_2 + 0x1c,piVar2 + 1);
    iVar9 = 0;
    piVar3 = piVar2 + 0x23;
    do {
      piVar5 = (int *)FUN_007ccac0(iVar9);
      iVar9 = iVar9 + 1;
      iVar4 = piVar5[1];
      iVar1 = piVar5[2];
      iVar10 = piVar5[3];
      *piVar3 = *piVar5;
      piVar3[1] = iVar4;
      piVar3[2] = iVar1;
      piVar3[3] = iVar10;
      piVar3 = piVar3 + 4;
    } while (iVar9 < 6);
    FUN_007ccaa0(2);
    puVar6 = (undefined8 *)FUN_011658d0(auStack_10);
    *(undefined8 *)(piVar2 + 0x3d) = *puVar6;
    piVar2[0x3f] = *(int *)(puVar6 + 1);
    FUN_007ccaa0(3);
    puVar6 = (undefined8 *)FUN_011658d0(auStack_10);
    *(undefined8 *)(piVar2 + 0x40) = *puVar6;
    piVar2[0x42] = *(int *)(puVar6 + 1);
    FUN_007ccaa0(6);
    pfVar7 = (float *)FUN_011658d0(auStack_10);
    FUN_007ccaa0(2);
    pfVar8 = (float *)FUN_011658d0(auStack_20);
    fStack_8 = pfVar7[2] - pfVar8[2];
    *(ulonglong *)(piVar2 + 0x43) = CONCAT44(pfVar7[1] - pfVar8[1],*pfVar7 - *pfVar8);
    piVar2[0x45] = (int)fStack_8;
    FUN_007ccaa0(0);
    pfVar7 = (float *)FUN_011658d0(auStack_20);
    FUN_007ccaa0(2);
    pfVar8 = (float *)FUN_011658d0(auStack_10);
    fVar13 = *pfVar7 - *pfVar8;
    fVar12 = pfVar7[1] - pfVar8[1];
    fVar11 = pfVar7[2] - pfVar8[2];
  }
  *(ulonglong *)(piVar2 + 0x46) = CONCAT44(fVar12,fVar13);
  piVar2[0x48] = (int)fVar11;
  return piVar2;
}



/* FUNCTION 12762 ; VA 0x008399e0 ; FUN_008399e0 */

undefined4 * __thiscall FUN_008399e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  return param_1;
}



/* FUNCTION 12763 ; VA 0x00839a00 ; FUN_00839a00 */

void __thiscall FUN_00839a00(uint *param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  *param_1 = (param_2 >> 3) + 0x9e3779b9 + (uVar1 >> 2) + param_2 + uVar1 * 0x40 ^ uVar1;
  uVar1 = *(uint *)(param_2 + 0x34);
  if (*(uint *)(param_2 + 0x34) <= param_1[1]) {
    uVar1 = param_1[1];
  }
  param_1[1] = uVar1;
  param_1[2] = param_1[2] + 1;
  return;
}



/* FUNCTION 12764 ; VA 0x00839a50 ; FUN_00839a50 */

undefined4 FUN_00839a50(int param_1,int param_2,float param_3)

{
  float fVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  
  if (((*(int *)(param_1 + 0x1d4) == *(int *)(param_2 + 0x1d4)) &&
      (fVar4 = *(float *)(param_1 + 0x21c) - *(float *)(param_2 + 0x21c),
      fVar3 = *(float *)(param_1 + 0x218) - *(float *)(param_2 + 0x218),
      fVar1 = *(float *)(param_1 + 0x220) - *(float *)(param_2 + 0x220),
      fVar4 * fVar4 + fVar3 * fVar3 + fVar1 * fVar1 <= param_3 * param_3)) &&
     ((*(int *)(param_1 + 0x1d4) != 2 ||
      ((dVar2 = (double)(*(float *)(param_1 + 0x230) - *(float *)(param_2 + 0x230)),
       (float)(double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & DAT_018c0da0._4_4_,
                               SUB84(dVar2,0) & (uint)DAT_018c0da0) <= DAT_018daf54 &&
       (DAT_01919030 <=
        *(float *)(param_2 + 0x238) * *(float *)(param_1 + 0x238) +
        *(float *)(param_1 + 0x234) * *(float *)(param_2 + 0x234) +
        *(float *)(param_2 + 0x23c) * *(float *)(param_1 + 0x23c))))))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 12765 ; VA 0x00839b40 ; FUN_00839b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00839b40(undefined4 param_1,uint *param_2,int param_3,int param_4)

{
  undefined4 *puVar1;
  uint *puVar2;
  float10 fVar3;
  undefined auStack_d4 [64];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  uint uStack_8;
  
  puVar1 = (undefined4 *)FUN_01165df0();
  uStack_8 = 0;
  uStack_54 = *puVar1;
  uStack_50 = puVar1[1];
  uStack_4c = puVar1[2];
  uStack_48 = puVar1[3];
  uStack_44 = puVar1[4];
  uStack_40 = puVar1[5];
  uStack_3c = puVar1[6];
  uStack_38 = puVar1[7];
  uStack_34 = puVar1[8];
  uStack_30 = puVar1[9];
  uStack_2c = puVar1[10];
  uStack_28 = puVar1[0xb];
  uStack_24 = puVar1[0xc];
  uStack_20 = puVar1[0xd];
  uStack_1c = puVar1[0xe];
  uStack_18 = puVar1[0xf];
  fStack_14 = *(float *)(&DAT_01918fa8 + param_3 * 0xc) * *(float *)(&DAT_01918fec + param_3 * 0xc)
              - *(float *)(&DAT_01918fa4 + param_3 * 0xc) *
                *(float *)(&DAT_01918ff0 + param_3 * 0xc);
  fStack_10 = *(float *)(&DAT_01918fa0 + param_3 * 0xc) * *(float *)(&DAT_01918ff0 + param_3 * 0xc)
              - *(float *)(&DAT_01918fe8 + param_3 * 0xc) *
                *(float *)(&DAT_01918fa8 + param_3 * 0xc);
  fStack_c = *(float *)(&DAT_01918fe8 + param_3 * 0xc) * *(float *)(&DAT_01918fa4 + param_3 * 0xc) -
             *(float *)(&DAT_01918fa0 + param_3 * 0xc) * *(float *)(&DAT_01918fec + param_3 * 0xc);
  FUN_01165f50(0,&fStack_14);
  fStack_14 = *(float *)(&DAT_01918fe8 + param_3 * 0xc);
  fStack_10 = *(float *)(&DAT_01918fec + param_3 * 0xc);
  fStack_c = *(float *)(&DAT_01918ff0 + param_3 * 0xc);
  uStack_8 = 0;
  FUN_01165f50(1,&fStack_14);
  fStack_14 = *(float *)(&DAT_01918fa0 + param_3 * 0xc);
  fStack_10 = *(float *)(&DAT_01918fa4 + param_3 * 0xc);
  fStack_c = *(float *)(&DAT_01918fa8 + param_3 * 0xc);
  uStack_8 = 0;
  FUN_01165f50(2,&fStack_14);
  uStack_94 = uStack_54;
  uStack_90 = uStack_50;
  uStack_8c = uStack_4c;
  uStack_88 = uStack_48;
  uStack_84 = uStack_44;
  uStack_80 = uStack_40;
  uStack_7c = uStack_3c;
  uStack_78 = uStack_38;
  uStack_74 = uStack_34;
  uStack_70 = uStack_30;
  uStack_6c = uStack_2c;
  uStack_68 = uStack_28;
  uStack_64 = uStack_24;
  uStack_60 = uStack_20;
  uStack_5c = uStack_1c;
  uStack_58 = uStack_18;
  if (param_4 != 0) {
    puVar1 = (undefined4 *)FUN_01165af0(auStack_d4,param_4);
    uStack_94 = *puVar1;
    uStack_90 = puVar1[1];
    uStack_8c = puVar1[2];
    uStack_88 = puVar1[3];
    uStack_84 = puVar1[4];
    uStack_80 = puVar1[5];
    uStack_7c = puVar1[6];
    uStack_78 = puVar1[7];
    uStack_74 = puVar1[8];
    uStack_70 = puVar1[9];
    uStack_6c = puVar1[10];
    uStack_68 = puVar1[0xb];
    uStack_64 = puVar1[0xc];
    uStack_60 = puVar1[0xd];
    uStack_5c = puVar1[0xe];
    uStack_58 = puVar1[0xf];
    fVar3 = (float10)FUN_01165d90();
    if ((float)fVar3 < 0.0) {
      puVar2 = (uint *)FUN_01165f10(0);
      fStack_14 = (float)(*puVar2 ^ DAT_018c4ea0);
      fStack_10 = (float)(puVar2[1] ^ _UNK_018c4ea4);
      fStack_c = (float)(puVar2[2] ^ _UNK_018c4ea8);
      uStack_8 = puVar2[3] ^ _UNK_018c4eac;
      FUN_01165f50(0,&fStack_14);
    }
  }
  fStack_10 = (float)(*param_2 ^ DAT_018c4ea0);
  fStack_c = (float)(param_2[1] ^ DAT_018c4ea0);
  uStack_8 = param_2[2] ^ DAT_018c4ea0;
  FUN_01165980(&DAT_01d71e5c,&fStack_10);
  FUN_01165af0(param_1,auStack_d4);
  return param_1;
}



/* FUNCTION 12766 ; VA 0x00839d90 ; FUN_00839d90 */

void FUN_00839d90(undefined4 *param_1,int param_2)

{
  *param_1 = *(undefined4 *)(&DAT_01918f88 + param_2 * 4);
  param_1[1] = *(undefined4 *)(&DAT_01918f8c + param_2 * 4);
  return;
}



/* FUNCTION 12767 ; VA 0x00839db0 ; FUN_00839db0 */

void __fastcall FUN_00839db0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  return;
}



/* FUNCTION 12768 ; VA 0x00839dc0 ; FUN_00839dc0 */

undefined4 FUN_00839dc0(undefined4 param_1,float *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined auStack_30 [8];
  float fStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined auStack_10 [12];
  
  if (((*param_2 <= param_2[3]) && (param_2[1] <= param_2[4])) && (param_2[2] <= param_2[5])) {
    iVar2 = 0;
    do {
      puVar1 = (undefined4 *)FUN_00c9f1c0(auStack_10,iVar2);
      uStack_20 = *puVar1;
      uStack_1c = puVar1[1];
      uStack_18 = puVar1[2];
      uStack_14 = 0x3f800000;
      FUN_01165b90(auStack_30,&uStack_20);
      if ((fStack_28 < 0.0) || (DAT_018ce2f8 < fStack_28)) {
        return 1;
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < 8);
  }
  return 0;
}



/* FUNCTION 12769 ; VA 0x00839e70 ; FUN_00839e70 */

uint __thiscall FUN_00839e70(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (((uVar1 == *param_2) && (uVar1 = param_1[2], uVar1 == param_2[2])) &&
     (uVar1 = param_1[1], param_2[1] <= uVar1)) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 12770 ; VA 0x00839ea0 ; FUN_00839ea0 */

void FUN_00839ea0(float *param_1,float *param_2,float *param_3,float param_4)

{
  double dVar1;
  double dVar2;
  int iVar3;
  int iVar4;
  float fVar5;
  double dVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  
  iVar3 = FUN_00835a70();
  dVar1 = (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)];
  iVar4 = FUN_00835a70(0x40);
  dVar2 = (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)];
  fVar11 = (param_3[1] + param_3[4]) * DAT_018ce2f4;
  fVar8 = (param_3[3] + *param_3) * DAT_018ce2f4;
  fVar9 = fVar11 - param_3[4];
  fVar5 = (param_3[2] + param_3[5]) * DAT_018ce2f4;
  fVar10 = fVar8 - param_3[3];
  fVar7 = fVar5 - param_3[5];
  fVar8 = (fVar11 - param_2[1]) * param_2[5] + (fVar8 - *param_2) * param_2[4] +
          (fVar5 - param_2[2]) * param_2[6];
  fVar5 = DAT_018c45c4;
  if (0.0 < fVar8) {
    dVar6 = (double)(fVar9 * fVar9 + fVar10 * fVar10 + fVar7 * fVar7);
    FUN_017267a0();
    fVar5 = ((float)dVar6 * DAT_01901d3c) / fVar8;
  }
  fVar7 = (float)((double)iVar4 + dVar2);
  if ((float)((double)iVar4 + dVar2) <= fVar5) {
    fVar7 = fVar5;
  }
  if (fVar7 <= param_4) {
    param_4 = fVar7;
  }
  fVar5 = DAT_018ce2f8;
  if ((*param_1 - param_4 <= 0.0) && (fVar5 = 0.0, *param_1 - param_4 < 0.0)) {
    fVar5 = DAT_018f7864;
  }
  fVar5 = fVar5 * DAT_01919034;
  *param_1 = param_4;
  FUN_01725160((double)((fVar5 + param_4) / (float)((double)iVar3 + dVar1)));
  FUN_016f3cd0();
  return;
}



/* FUNCTION 12771 ; VA 0x0083a060 ; FUN_0083a060 */

void FUN_0083a060(float *param_1,float *param_2,undefined4 param_3,undefined4 param_4,float param_5)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  float10 fVar4;
  float fVar5;
  float fVar6;
  undefined auStack_64 [12];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [12];
  undefined auStack_38 [8];
  undefined8 uStack_30;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar1 = FUN_00835a70(0x20);
  fStack_24 = (float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]);
  iVar1 = FUN_00835a70(0x40);
  fStack_14 = 0.0;
  iVar3 = 0;
  fStack_c = 0.0;
  fStack_10 = 0.0;
  fStack_8 = 0.0;
  fStack_28 = (float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]);
  do {
    fStack_20 = fStack_8;
    fStack_1c = fStack_8;
    fStack_18 = fStack_8;
    puVar2 = (undefined4 *)FUN_00c9f1c0(auStack_44,iVar3);
    uStack_54 = *puVar2;
    uStack_50 = puVar2[1];
    uStack_4c = puVar2[2];
    uStack_48 = 0x3f800000;
    FUN_01165b90(auStack_64,&uStack_54);
    FUN_01126580(auStack_38);
    FUN_01163100(&uStack_30,uStack_58);
    if (uStack_30._4_4_ <= fStack_c) {
      fStack_c = uStack_30._4_4_;
      fStack_1c = fStack_20;
      fStack_8 = fStack_18;
    }
    if ((float)uStack_30 <= fStack_10) {
      fStack_10 = (float)uStack_30;
      fStack_8 = fStack_1c;
    }
    if (fStack_8 <= uStack_30._4_4_) {
      fStack_8 = uStack_30._4_4_;
    }
    if (fStack_14 <= (float)uStack_30) {
      fStack_14 = (float)uStack_30;
    }
    iVar3 = iVar3 + 1;
  } while (iVar3 < 8);
  fVar6 = (fStack_8 - fStack_c) * (fStack_14 - fStack_10) * DAT_01919038;
  fVar5 = fStack_28;
  if (fStack_28 <= fVar6) {
    fVar5 = fVar6;
  }
  *param_2 = fVar6;
  if (fVar5 <= param_5) {
    param_5 = fVar5;
  }
  fVar5 = DAT_018ce2f8;
  if ((*param_1 - param_5 <= 0.0) && (fVar5 = DAT_018f7864, 0.0 <= *param_1 - param_5)) {
    fVar5 = 0.0;
  }
  fVar5 = fVar5 * DAT_018e3f8c;
  *param_1 = param_5;
  uStack_30 = (double)((fVar5 + param_5) / fStack_24);
  fStack_20 = fStack_8;
  fStack_1c = fStack_8;
  fStack_18 = fStack_8;
  fVar4 = (float10)FUN_01725160(uStack_30);
  uStack_30 = (double)fVar4;
  FUN_016f3cd0();
  return;
}



/* FUNCTION 12772 ; VA 0x0083a2a0 ; FUN_0083a2a0 */

undefined4 FUN_0083a2a0(undefined4 param_1,undefined4 param_2,uint *param_3,float *param_4)

{
  float fVar1;
  undefined4 *puVar2;
  float *pfVar3;
  int iVar4;
  undefined8 *puVar5;
  uint uVar6;
  uint uVar7;
  float fVar8;
  undefined auStack_16c [64];
  undefined8 uStack_12c;
  undefined4 auStack_124 [22];
  float fStack_cc;
  float fStack_c8;
  float afStack_c4 [4];
  float fStack_b4;
  float fStack_b0;
  float fStack_a8;
  float fStack_9c;
  float fStack_98;
  float fStack_8c;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [8];
  undefined4 uStack_4c;
  undefined auStack_48 [12];
  float fStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  uint uStack_18;
  float fStack_8;
  
  uStack_30 = (ulonglong)*param_3;
  uStack_20 = (ulonglong)param_3[2];
  uVar6 = param_3[1];
  uStack_18 = param_3[3];
  FUN_01165e00(auStack_16c);
  iVar4 = 8;
  uStack_6c = CONCAT44(uVar6,(int)uStack_30);
  uStack_4c = 0;
  fStack_8 = 1.0;
  uStack_64 = 0;
  uStack_60 = (undefined4)uStack_20;
  uStack_5c = uStack_18;
  uStack_58 = 0x3f800000;
  do {
    FUN_00569440();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  iVar4 = 0;
  puVar5 = &uStack_12c;
  do {
    puVar2 = (undefined4 *)FUN_00c9f1c0(auStack_54,iVar4);
    uStack_38 = *puVar2;
    uStack_34 = puVar2[1];
    uStack_30 = CONCAT44(0x3f800000,puVar2[2]);
    FUN_01165b90(auStack_48,&uStack_38);
    pfVar3 = (float *)FUN_011658d0(&uStack_24);
    fVar8 = DAT_018ce2f8 / fStack_3c;
    iVar4 = iVar4 + 1;
    fVar1 = pfVar3[2];
    *puVar5 = CONCAT44(pfVar3[1] * fVar8,*pfVar3 * fVar8);
    fStack_8 = fVar1 * fVar8;
    *(float *)(puVar5 + 1) = fVar1 * fVar8;
    puVar5 = (undefined8 *)((int)puVar5 + 0xc);
  } while (iVar4 < 8);
  iVar4 = 8;
  do {
    FUN_00569440();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  iVar4 = 0;
  do {
    uStack_28 = *(undefined4 *)((int)&uStack_12c + iVar4);
    uStack_24 = *(undefined4 *)((int)auStack_124 + iVar4 + -4);
    uStack_20 = CONCAT44(0x3f800000,*(undefined4 *)((int)auStack_124 + iVar4));
    FUN_01165b90(auStack_48,&uStack_28);
    pfVar3 = (float *)FUN_011658d0(auStack_54);
    fVar8 = DAT_018ce2f8 / fStack_3c;
    fVar1 = pfVar3[2];
    *(ulonglong *)((int)&fStack_cc + iVar4) = CONCAT44(pfVar3[1] * fVar8,*pfVar3 * fVar8);
    fStack_8 = fVar1 * fVar8;
    *(float *)((int)afStack_c4 + iVar4) = fVar1 * fVar8;
    iVar4 = iVar4 + 0xc;
  } while (iVar4 < 0x60);
  uVar6 = (uint)DAT_018c0da0;
  uVar7 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  if (((((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_cc - afStack_c4[1]) >> 0x20) &
                                 uVar7,SUB84((double)(fStack_cc - afStack_c4[1]),0) & uVar6) <
         DAT_018fd178) &&
       ((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_cc - fStack_b4) >> 0x20) & uVar7,
                                SUB84((double)(fStack_cc - fStack_b4),0) & uVar6) < DAT_018fd178))
      && ((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_cc - fStack_a8) >> 0x20) & uVar7
                                  ,SUB84((double)(fStack_cc - fStack_a8),0) & uVar6) < DAT_018fd178)
      ) && ((((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_c8 - afStack_c4[2]) >> 0x20)
                                      & uVar7,SUB84((double)(fStack_c8 - afStack_c4[2]),0) & uVar6)
              < DAT_018fd178 &&
             ((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_c8 - fStack_98) >> 0x20) &
                                      uVar7,SUB84((double)(fStack_c8 - fStack_98),0) & uVar6) <
              DAT_018fd178)) &&
            ((float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_c8 - fStack_8c) >> 0x20) &
                                     uVar7,SUB84((double)(fStack_c8 - fStack_8c),0) & uVar6) <
             DAT_018fd178)))) {
    *param_4 = fStack_cc;
    param_4[1] = fStack_c8;
    param_4[2] = fStack_9c;
    param_4[3] = fStack_b0;
    return 1;
  }
  *param_4 = 0.0;
  param_4[1] = 0.0;
  param_4[2] = 0.0;
  param_4[3] = 0.0;
  return 0;
}



/* FUNCTION 12773 ; VA 0x0083a5c0 ; FUN_0083a5c0 */

float * FUN_0083a5c0(float *param_1,float *param_2,int param_3,int param_4,int param_5,int param_6)

{
  double dVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  
  fVar5 = DAT_018ce2f4;
  dVar1 = (double)(&DAT_018c0d90)[-(param_5 >> 0x1f)];
  fVar6 = param_2[2] * DAT_018ce2f4 + DAT_018ce2f4;
  dVar2 = (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
  *param_1 = (*param_2 * DAT_018ce2f4 + DAT_018ce2f4) * (float)((double)param_5 + dVar1) +
             (float)((double)param_3 + dVar2);
  dVar3 = (double)(&DAT_018c0d90)[-(param_6 >> 0x1f)];
  dVar4 = (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)];
  param_1[1] = (param_2[1] * fVar5 + fVar5) * (float)((double)param_6 + dVar3) +
               (float)((double)param_4 + dVar4);
  param_1[2] = fVar6 * (float)((double)param_5 + dVar1) + (float)((double)param_3 + dVar2);
  param_1[3] = fVar6 * (float)((double)param_6 + dVar3) + (float)((double)param_4 + dVar4);
  return param_1;
}



/* FUNCTION 12774 ; VA 0x0083a6a0 ; FUN_0083a6a0 */

undefined4 * __fastcall FUN_0083a6a0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = 0;
  param_1[1] = 0xffffffff;
  param_1[2] = 0;
  FUN_007cc9d0();
  param_1[0x94] = 0;
  FUN_005502b0();
  uVar1 = FUN_00556df0();
  param_1[0x98] = uVar1;
  param_1[0x9c] = 0xffffffff;
  param_1[0x9d] = 0xffffffff;
  return param_1;
}



/* FUNCTION 12775 ; VA 0x0083a700 ; FUN_0083a700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0083a700(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b7231;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Shadows::ShadowObjectBase::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  iVar6 = 6;
  uStack_8 = 2;
  do {
    FUN_01165ab0();
    iVar4 = _tls_index;
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  param_1[0x75] = param_2;
  pvVar5 = ThreadLocalStoragePointer;
  param_1[0x73] = 0x7f7fffff;
  param_1[0x74] = 0;
  *(undefined *)(param_1 + 0x76) = 0;
  iVar6 = *(int *)((int)pvVar5 + iVar4 * 4);
  param_1[0x77] = 0;
  param_1[0x78] = &DAT_bf800000;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0xffffffff;
  *param_1 = RBX::Graphics::Shadows::ShadowObject::vftable;
  if (*(int *)(iVar6 + 0x34) < DAT_01eaf0a8) {
    FUN_016f3809(&DAT_01eaf0a8);
    if (DAT_01eaf0a8 == -1) {
      _DAT_01eaf09c = 0;
      _DAT_01eaf090 = 0;
      _DAT_01eaf098 = 0;
      DAT_01eaf0a0._4_4_ = 0;
      DAT_01eaf0a0._0_4_ = _DAT_01eaf09c;
      FUN_016f37bf(&DAT_01eaf0a8);
    }
  }
  uVar3 = _DAT_01eaf09c;
  uVar2 = _DAT_01eaf098;
  uVar1 = DAT_01eaf090_4;
  param_1[0x7f] = _DAT_01eaf090;
  param_1[0x80] = uVar1;
  param_1[0x81] = uVar2;
  param_1[0x82] = uVar3;
  *(ulonglong *)(param_1 + 0x83) = CONCAT44(DAT_01eaf0a0._4_4_,(undefined4)DAT_01eaf0a0);
  param_1[0x85] = 0;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12776 ; VA 0x0083a940 ; FUN_0083a940 */

undefined4 * __thiscall FUN_0083a940(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b7231;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Shadows::ShadowObjectBase::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  iVar1 = 6;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uStack_8 = 2;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  do {
    FUN_01165ab0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  param_1[0x75] = param_2;
  param_1[0x74] = 0;
  *(undefined *)(param_1 + 0x76) = 0;
  param_1[0x77] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x73] = 0x7f7fffff;
  param_1[0x78] = &DAT_bf800000;
  param_1[0x7e] = 0xffffffff;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12777 ; VA 0x0083aa70 ; FUN_0083aa70 */

void __fastcall FUN_0083aa70(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x278) * 0x278;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12778 ; VA 0x0083aae0 ; FUN_0083aae0 */

void __fastcall FUN_0083aae0(undefined4 *param_1)

{
  *param_1 = RBX::Graphics::Shadows::ShadowObject::vftable;
  FUN_0083aaf0();
  return;
}



/* FUNCTION 12779 ; VA 0x0083aaf0 ; FUN_0083aaf0 */

void __fastcall FUN_0083aaf0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::Graphics::Shadows::ShadowObjectBase::vftable;
  iVar1 = param_1[8];
  if (iVar1 != 0) {
    uVar3 = param_1[10] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[8] = 0;
    param_1[9] = 0;
    param_1[10] = 0;
  }
  FUN_0083aa70();
  FUN_0083aa70();
  return;
}



/* FUNCTION 12780 ; VA 0x0083ab60 ; FUN_0083ab60 */

undefined4 * __thiscall FUN_0083ab60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::Shadows::ShadowObject::vftable;
  FUN_0083aaf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x22c);
  }
  return param_1;
}



/* FUNCTION 12781 ; VA 0x0083ab90 ; FUN_0083ab90 */

undefined4 __thiscall FUN_0083ab90(undefined4 param_1,byte param_2)

{
  FUN_0083aaf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1fc);
  }
  return param_1;
}



/* FUNCTION 12782 ; VA 0x0083abc0 ; FUN_0083abc0 */

void __thiscall FUN_0083abc0(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = (undefined4 *)(param_2 + 0x2c);
  puVar3 = (undefined4 *)(param_1 + 0x2c);
  for (iVar1 = 0x68; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  return;
}



/* FUNCTION 12783 ; VA 0x0083abe0 ; FUN_0083abe0 */

undefined4 FUN_0083abe0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7264;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xd4) == 1) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0x230);
    uStack_8 = 1;
    if (iVar1 != 0) {
      uVar2 = FUN_008659e0(param_1);
      ExceptionList = pvStack_10;
      return uVar2;
    }
  }
  else if (*(int *)(param_1 + 0xd4) - 2U < 2) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0x244);
    uStack_8 = 0;
    if (iVar1 != 0) {
      uVar2 = FUN_00866460(param_1);
      ExceptionList = pvStack_10;
      return uVar2;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 12784 ; VA 0x0083ac90 ; FUN_0083ac90 */

undefined4 * FUN_0083ac90(undefined4 *param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  FUN_0083a6a0();
  *param_1 = 2;
  puVar2 = (undefined4 *)(param_2 + 0xc);
  puVar3 = param_1 + 3;
  for (iVar1 = 0x91; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar3 = *puVar2;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 1;
  }
  *(undefined8 *)(param_1 + 0x95) = *(undefined8 *)(param_2 + 0x254);
  param_1[0x97] = *(undefined4 *)(param_2 + 0x25c);
  param_1[0x94] = *(undefined4 *)(param_2 + 0x250);
  param_1[0x9c] = *(undefined4 *)(param_2 + 0x270);
  param_1[0x9d] = *(undefined4 *)(param_2 + 0x274);
  param_1[0x98] = *(undefined4 *)(param_2 + 0x260);
  param_1[1] = *(undefined4 *)(param_2 + 4);
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[0x99] = 0;
  param_1[0x9a] = 0;
  return param_1;
}



/* FUNCTION 12785 ; VA 0x0083ad30 ; FUN_0083ad30 */

int FUN_0083ad30(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0083ac90(param_1,param_2);
  *(undefined4 *)(param_1 + 8) = param_3;
  return param_1;
}



/* FUNCTION 12786 ; VA 0x0083ad60 ; FUN_0083ad60 */

undefined4 *
FUN_0083ad60(undefined4 *param_1,undefined8 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 *param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  
  FUN_0083a6a0();
  *param_1 = 1;
  puVar3 = param_1 + 3;
  for (iVar2 = 0x91; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = *param_3;
    param_3 = param_3 + 1;
    puVar3 = puVar3 + 1;
  }
  *(undefined8 *)(param_1 + 0x95) = *param_2;
  param_1[0x97] = *(undefined4 *)(param_2 + 1);
  param_1[0x9c] = param_10;
  param_1[0x9d] = param_11;
  uVar1 = *param_7;
  param_1[0x99] = param_5;
  param_1[2] = param_8;
  param_1[0x9a] = param_6;
  param_1[0x98] = uVar1;
  param_1[1] = param_9;
  param_1[0x94] = param_4;
  return param_1;
}



/* FUNCTION 12787 ; VA 0x0083adf0 ; FUN_0083adf0 */

undefined4 * FUN_0083adf0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_27c [632];
  
  FUN_0083a6a0();
  puVar1 = (undefined4 *)FUN_0083ac90(auStack_27c,param_2);
  puVar3 = param_1;
  for (iVar2 = 0x9e; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = *puVar1;
    puVar1 = puVar1 + 1;
    puVar3 = puVar3 + 1;
  }
  *param_1 = 0;
  FUN_00839db0();
  param_1[1] = 0xffffffff;
  param_1[2] = 0;
  return param_1;
}



/* FUNCTION 12788 ; VA 0x0083ae50 ; FUN_0083ae50 */

void FUN_0083ae50(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x278;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 12789 ; VA 0x0083ae90 ; FUN_0083ae90 */

undefined4 *
FUN_0083ae90(undefined4 *param_1,undefined4 *param_2,int param_3,int param_4,int param_5)

{
  float fVar1;
  undefined4 *puVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  undefined auStack_c4 [64];
  undefined auStack_84 [64];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  fVar1 = DAT_018ce2f8;
  puVar2 = param_1;
  for (iVar3 = 0x91; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar2 = *param_2;
    param_2 = param_2 + 1;
    puVar2 = puVar2 + 1;
  }
  uStack_44 = param_1[0x17];
  uStack_40 = param_1[0x18];
  uStack_3c = param_1[0x19];
  uStack_38 = param_1[0x1a];
  uStack_34 = param_1[0x1b];
  uStack_30 = param_1[0x1c];
  uStack_2c = param_1[0x1d];
  uStack_28 = param_1[0x1e];
  uStack_24 = param_1[0x1f];
  uStack_20 = param_1[0x20];
  uStack_1c = param_1[0x21];
  uStack_18 = param_1[0x22];
  uStack_14 = param_1[0x23];
  uStack_10 = param_1[0x24];
  uStack_c = param_1[0x25];
  uStack_8 = param_1[0x26];
  fVar4 = (float)((double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)]) /
          (float)((double)param_5 + (double)(&DAT_018c0d90)[-(param_5 >> 0x1f)]);
  fVar5 = (float)((double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)]) /
          (float)((double)param_4 + (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)]);
  FUN_007a0390(auStack_84,fVar1 - (fVar5 + fVar5),fVar1 - (fVar4 + fVar4),0x3f800000);
  puVar2 = (undefined4 *)FUN_01165af0(auStack_c4,&uStack_44);
  uStack_44 = *puVar2;
  uStack_40 = puVar2[1];
  uStack_3c = puVar2[2];
  uStack_38 = puVar2[3];
  uStack_34 = puVar2[4];
  uStack_30 = puVar2[5];
  uStack_2c = puVar2[6];
  uStack_28 = puVar2[7];
  uStack_24 = puVar2[8];
  uStack_20 = puVar2[9];
  uStack_1c = puVar2[10];
  uStack_18 = puVar2[0xb];
  uStack_14 = puVar2[0xc];
  uStack_10 = puVar2[0xd];
  uStack_c = puVar2[0xe];
  uStack_8 = puVar2[0xf];
  FUN_007cd560(&uStack_44,0);
  return param_1;
}



/* FUNCTION 12790 ; VA 0x0083afb0 ; FUN_0083afb0 */

undefined4 *
FUN_0083afb0(undefined4 *param_1,undefined4 *param_2,int param_3,int param_4,int param_5,
            float param_6)

{
  undefined4 *puVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  undefined auStack_d4 [64];
  undefined auStack_94 [64];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  float fStack_c;
  uint uStack_8;
  
  puVar1 = param_1;
  for (iVar2 = 0x91; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar1 = *param_2;
    param_2 = param_2 + 1;
    puVar1 = puVar1 + 1;
  }
  uStack_54 = param_1[0x17];
  uStack_50 = param_1[0x18];
  uStack_4c = param_1[0x19];
  uStack_48 = param_1[0x1a];
  uStack_44 = param_1[0x1b];
  uStack_40 = param_1[0x1c];
  uStack_3c = param_1[0x1d];
  uStack_38 = param_1[0x1e];
  uStack_34 = param_1[0x1f];
  uStack_30 = param_1[0x20];
  uStack_2c = param_1[0x21];
  uStack_28 = param_1[0x22];
  uStack_24 = param_1[0x23];
  uStack_20 = param_1[0x24];
  uStack_1c = param_1[0x25];
  uStack_18 = param_1[0x26];
  iVar2 = FUN_01165f10(2);
  uStack_14 = 0;
  uStack_10 = 0;
  fVar4 = (float)((uint)(*(float *)(iVar2 + 0xc) / *(float *)(iVar2 + 8)) ^ DAT_018c4ea0);
  param_6 = fVar4 + param_6;
  fStack_c = DAT_018ce2f8 / ((DAT_018ce2f8 / *(float *)(iVar2 + 8) + fVar4) - param_6);
  uStack_8 = (uint)(param_6 * fStack_c) ^ DAT_018c4ea0;
  FUN_01165f50(2,&uStack_14);
  fVar4 = (float)((double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)]) /
          (float)((double)param_5 + (double)(&DAT_018c0d90)[-(param_5 >> 0x1f)]);
  fVar3 = (float)((double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)]) /
          (float)((double)param_4 + (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)]);
  FUN_007a0390(auStack_94,DAT_018ce2f8 - (fVar3 + fVar3),DAT_018ce2f8 - (fVar4 + fVar4),0x3f800000);
  puVar1 = (undefined4 *)FUN_01165af0(auStack_d4,&uStack_54);
  uStack_54 = *puVar1;
  uStack_50 = puVar1[1];
  uStack_4c = puVar1[2];
  uStack_48 = puVar1[3];
  uStack_44 = puVar1[4];
  uStack_40 = puVar1[5];
  uStack_3c = puVar1[6];
  uStack_38 = puVar1[7];
  uStack_34 = puVar1[8];
  uStack_30 = puVar1[9];
  uStack_2c = puVar1[10];
  uStack_28 = puVar1[0xb];
  uStack_24 = puVar1[0xc];
  uStack_20 = puVar1[0xd];
  uStack_1c = puVar1[0xe];
  uStack_18 = puVar1[0xf];
  FUN_007cd560(&uStack_54,0);
  return param_1;
}



/* FUNCTION 12791 ; VA 0x0083b140 ; FUN_0083b140 */

undefined * FUN_0083b140(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b727c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb44a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb44a8);
    if (DAT_01eb44a8 == -1) {
      uStack_8 = 0;
      FUN_0083a6a0();
      FUN_016f37bf(&DAT_01eb44a8);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eb4230;
}



/* FUNCTION 12792 ; VA 0x0083b1c0 ; FUN_0083b1c0 */

undefined4 __thiscall
FUN_0083b1c0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            uint param_6)

{
  FUN_008399e0(param_3,*(undefined4 *)(param_1 + 0x1d0));
  if (param_5 < param_6) {
    do {
      FUN_00839a00(*(undefined4 *)(*param_4 + param_5 * 4));
      param_5 = param_5 + 1;
    } while (param_5 < param_6);
  }
  return param_2;
}



/* FUNCTION 12793 ; VA 0x0083b200 ; FUN_0083b200 */

void __thiscall FUN_0083b200(int param_1,int param_2)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 4) != 0) {
    piVar1 = (int *)(*(int *)(param_1 + 4) + 0x1dc);
    *piVar1 = *piVar1 + -1;
  }
  if (param_2 != 0) {
    *(int *)(param_2 + 0x1dc) = *(int *)(param_2 + 0x1dc) + 1;
  }
  *(int *)(param_1 + 4) = param_2;
  return;
}



/* FUNCTION 12794 ; VA 0x0083b230 ; FUN_0083b230 */

void __thiscall FUN_0083b230(int param_1,float param_2,float param_3)

{
  float fVar1;
  
  param_2 = *(float *)(param_1 + 0x1e4) - param_2;
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  *(float *)(param_1 + 0x1e4) = fVar1;
  *(float *)(param_1 + 0x1e8) = DAT_018ce2f8 - fVar1 / param_3;
  return;
}



/* FUNCTION 12795 ; VA 0x0083b270 ; FUN_0083b270 */

void __thiscall FUN_0083b270(int param_1,int param_2,undefined4 *param_3)

{
  *(undefined4 *)(param_2 * 0x278 + 0x260 + *(int *)(param_1 + 0x14)) = *param_3;
  return;
}



/* FUNCTION 12796 ; VA 0x0083b290 ; FUN_0083b290 */

void __thiscall FUN_0083b290(int param_1,int param_2,int *param_3,int param_4,int param_5)

{
  undefined4 *puVar1;
  double dVar2;
  double dVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_150 [64];
  undefined auStack_110 [64];
  undefined auStack_d0 [128];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  undefined4 uStack_8;
  
  fStack_10 = 0.5;
  iVar4 = *(int *)(param_1 + 0x14);
  fStack_c = 0.5;
  uStack_8 = 0;
  FUN_01165980(&DAT_01d71e5c,&fStack_10);
  uVar6 = FUN_007a0390(auStack_110,0x3f000000,0xbf000000,0x3f800000);
  FUN_01165af0(auStack_150,uVar6);
  FUN_01165af0(auStack_d0,iVar4 + param_2 * 0x278 + 0xe8);
  uStack_8 = 0;
  iVar4 = param_3[2];
  dVar2 = (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)];
  dVar3 = (double)(&DAT_018c0d90)[-(param_5 >> 0x1f)];
  fStack_10 = (float)*param_3 / (float)((double)param_4 + dVar2);
  iVar5 = param_3[3];
  fStack_c = (float)param_3[1] / (float)((double)param_5 + dVar3);
  FUN_01165980(&DAT_01d71e5c,&fStack_10);
  uVar6 = FUN_007a0390(auStack_150,(float)iVar4 / (float)((double)param_4 + dVar2),
                       (float)iVar5 / (float)((double)param_5 + dVar3),0x3f800000);
  FUN_01165af0(auStack_110,uVar6);
  FUN_01165af0(&uStack_50,auStack_d0);
  param_2 = param_2 * 0x40;
  puVar1 = (undefined4 *)(param_2 + 0x4c + param_1);
  *puVar1 = uStack_50;
  puVar1[1] = uStack_4c;
  puVar1[2] = uStack_48;
  puVar1[3] = uStack_44;
  puVar1 = (undefined4 *)(param_2 + 0x5c + param_1);
  *puVar1 = uStack_40;
  puVar1[1] = uStack_3c;
  puVar1[2] = uStack_38;
  puVar1[3] = uStack_34;
  puVar1 = (undefined4 *)(param_2 + 0x6c + param_1);
  *puVar1 = uStack_30;
  puVar1[1] = uStack_2c;
  puVar1[2] = uStack_28;
  puVar1[3] = uStack_24;
  puVar1 = (undefined4 *)(param_2 + 0x7c + param_1);
  *puVar1 = uStack_20;
  puVar1[1] = uStack_1c;
  puVar1[2] = uStack_18;
  puVar1[3] = uStack_14;
  return;
}



/* FUNCTION 12797 ; VA 0x0083b450 ; FUN_0083b450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0083b450(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  float10 fVar4;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  float fStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  float fStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  
  iVar2 = param_2 * 0x278 + *(int *)(param_1 + 0x14);
  iVar1 = *(int *)(param_3 + 8) / 2;
  uStack_24 = _DAT_018f99a0;
  uStack_20 = _UNK_018f99a4;
  uStack_1c = _UNK_018f99a8;
  uStack_18 = _UNK_018f99ac;
  FUN_01165b90(&fStack_14,&uStack_24);
  fVar3 = (float10)FUN_017268ab((float)iVar1 * fStack_14);
  fVar4 = (float10)FUN_017268ab((float)iVar1 * fStack_10);
  uStack_64 = *(undefined4 *)(iVar2 + 0x68);
  uStack_60 = *(undefined4 *)(iVar2 + 0x6c);
  uStack_5c = *(undefined4 *)(iVar2 + 0x70);
  uStack_54 = *(undefined4 *)(iVar2 + 0x78);
  uStack_50 = *(undefined4 *)(iVar2 + 0x7c);
  uStack_4c = *(undefined4 *)(iVar2 + 0x80);
  uStack_44 = *(undefined4 *)(iVar2 + 0x88);
  uStack_40 = *(undefined4 *)(iVar2 + 0x8c);
  uStack_3c = *(undefined4 *)(iVar2 + 0x90);
  uStack_38 = *(undefined4 *)(iVar2 + 0x94);
  uStack_34 = *(undefined4 *)(iVar2 + 0x98);
  uStack_30 = *(undefined4 *)(iVar2 + 0x9c);
  uStack_2c = *(undefined4 *)(iVar2 + 0xa0);
  uStack_28 = *(undefined4 *)(iVar2 + 0xa4);
  fStack_58 = (float)(fVar3 / (float10)iVar1) - fStack_14;
  fStack_48 = (float)(fVar4 / (float10)iVar1) - fStack_10;
  FUN_007cd560(&uStack_64,0);
  return;
}



/* FUNCTION 12798 ; VA 0x0083b530 ; FUN_0083b530 */

undefined4 __thiscall
FUN_0083b530(int param_1,undefined4 param_2,int param_3,undefined4 param_4,undefined4 param_5,
            undefined4 *param_6)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  *param_6 = 0;
  iVar2 = param_3 * 0x278 + *(int *)(param_1 + 0x14);
  uVar3 = *(uint *)(iVar2 + 0x264);
  uVar1 = *(uint *)(iVar2 + 0x268);
  if (uVar1 == uVar3) {
    return 0;
  }
  if (uVar3 < uVar1) {
    do {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x20) + uVar3 * 4) + 4))(param_2,iVar2 + 0xc,5);
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar1);
  }
  return 1;
}



/* FUNCTION 12799 ; VA 0x0083b5a0 ; FUN_0083b5a0 */

void __fastcall FUN_0083b5a0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  
  piVar9 = *(int **)(param_1 + 0x14);
  iVar7 = *(int *)(param_1 + 0x18) - (int)piVar9;
  uVar5 = 0;
  iVar4 = iVar7 >> 0x1f;
  iVar7 = iVar7 / 0x278 + iVar4;
  uVar6 = iVar7 - iVar4;
  uVar8 = 0;
  if (iVar7 != iVar4) {
    do {
      uVar8 = uVar5;
      if (*piVar9 != 0) break;
      uVar5 = uVar5 + 1;
      piVar9 = piVar9 + 0x9e;
      uVar8 = 0;
    } while (uVar5 < uVar6);
  }
  iVar4 = *(int *)(param_1 + 0x14);
  iVar7 = uVar8 * 0x278;
  fVar11 = *(float *)(iVar7 + 0x90 + iVar4);
  fVar12 = DAT_018ce2f8;
  if (uVar6 < 2) {
    fVar12 = 0.0;
  }
  fVar10 = DAT_018ce2f8;
  if (DAT_01d6104c != '\0') {
    fVar10 = *(float *)(param_1 + 0x1e8);
  }
  fVar11 = DAT_018ce2f8 /
           (((*(float *)(iVar7 + 0x94 + iVar4) / fVar11) * fVar11) / (fVar11 + DAT_018ce2f8));
  *(float *)(param_1 + 0x40) = fVar10;
  uVar1 = *(undefined4 *)(iVar7 + 0xc + iVar4);
  uVar2 = *(undefined4 *)(iVar7 + 0x10 + iVar4);
  uVar3 = *(undefined4 *)(iVar7 + 0x14 + iVar4);
  *(float *)(param_1 + 0x3c) = fVar11;
  *(undefined4 *)(param_1 + 0x2c) = uVar1;
  *(undefined4 *)(param_1 + 0x30) = uVar2;
  *(undefined4 *)(param_1 + 0x34) = uVar3;
  *(float *)(param_1 + 0x38) = fVar12;
  return;
}



/* FUNCTION 12800 ; VA 0x0083b680 ; FUN_0083b680 */

int __thiscall FUN_0083b680(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  int iVar14;
  undefined4 *puVar15;
  
  iVar1 = ((int)param_2 - *param_1) / 0x5c;
  iVar5 = (param_1[1] - *param_1) / 0x5c;
  if (iVar5 == 0x2c8590b) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = iVar5 + 1;
  uVar9 = (param_1[2] - *param_1) / 0x5c;
  uVar3 = uVar2;
  if ((uVar9 <= 0x2c8590b - (uVar9 >> 1)) && (uVar3 = (uVar9 >> 1) + uVar9, uVar3 < uVar2)) {
    uVar3 = uVar2;
  }
  uVar9 = uVar3 * 0x5c;
  if (uVar3 < 0x2c8590c) {
    if (0xfff < uVar9) goto LAB_0083b724;
    if (uVar9 == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = (undefined4 *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_0083b724:
    uVar4 = uVar9 + 0x23;
    if (uVar4 <= uVar9) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_0083b856;
    puVar6 = (undefined4 *)(iVar5 + 0x23U & 0xffffffe0);
    puVar6[-1] = iVar5;
  }
  puVar13 = puVar6 + iVar1 * 0x17;
  puVar12 = puVar13;
  for (iVar5 = 0x17; iVar5 != 0; iVar5 = iVar5 + -1) {
    *puVar12 = *param_3;
    param_3 = param_3 + 1;
    puVar12 = puVar12 + 1;
  }
  puVar12 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar11 = puVar6;
  if (param_2 == puVar12) {
    while (puVar8 != puVar12) {
      puVar7 = puVar8 + 0x17;
      puVar10 = puVar11 + 0x17;
      puVar13 = puVar8;
      puVar15 = puVar11;
      for (iVar5 = 0x17; puVar8 = puVar7, puVar11 = puVar10, iVar5 != 0; iVar5 = iVar5 + -1) {
        *puVar15 = *puVar13;
        puVar13 = puVar13 + 1;
        puVar15 = puVar15 + 1;
      }
    }
  }
  else {
    if (puVar8 != param_2) {
      do {
        puVar15 = puVar8 + 0x17;
        puVar12 = puVar11;
        for (iVar5 = 0x17; iVar5 != 0; iVar5 = iVar5 + -1) {
          *puVar12 = *puVar8;
          puVar8 = puVar8 + 1;
          puVar12 = puVar12 + 1;
        }
        puVar8 = puVar15;
        puVar11 = puVar11 + 0x17;
      } while (puVar15 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        puVar13 = puVar13 + 0x17;
        puVar11 = param_2 + 0x17;
        puVar8 = puVar13;
        for (iVar5 = 0x17; iVar5 != 0; iVar5 = iVar5 + -1) {
          *puVar8 = *param_2;
          param_2 = param_2 + 1;
          puVar8 = puVar8 + 1;
        }
        param_2 = puVar11;
      } while (puVar11 != puVar12);
    }
  }
  iVar5 = *param_1;
  if (iVar5 != 0) {
    uVar9 = ((param_1[2] - iVar5) / 0x5c) * 0x5c;
    iVar14 = iVar5;
    if (0xfff < uVar9) {
      iVar14 = *(int *)(iVar5 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar5 - iVar14) - 4U) {
LAB_0083b856:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,uVar9);
  }
  *param_1 = (int)puVar6;
  param_1[1] = (int)(puVar6 + uVar2 * 0x17);
  param_1[2] = (int)(puVar6 + uVar3 * 0x17);
  return *param_1 + iVar1 * 0x5c;
}



/* FUNCTION 12801 ; VA 0x0083b870 ; FUN_0083b870 */

int __thiscall FUN_0083b870(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  
  iVar6 = *param_1;
  iVar2 = (int)param_2 - iVar6 >> 3;
  iVar3 = param_1[1] - iVar6 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar7 = param_1[2] - iVar6 >> 3;
  uVar4 = uVar1;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar1)) {
    uVar4 = uVar1;
  }
  uVar7 = uVar4 * 8;
  if (uVar4 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_0083b8e7;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0083b8e7:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_0083ba02;
    puVar10 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar6;
  }
  puVar10[iVar2 * 2] = *param_3;
  puVar10[iVar2 * 2 + 1] = 0xffffffff;
  puVar11 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  puVar9 = puVar10;
  if (param_2 == puVar11) {
    for (; puVar8 != puVar11; puVar8 = puVar8 + 2) {
      *puVar9 = *puVar8;
      puVar9[1] = puVar8[1];
      puVar9 = puVar9 + 2;
    }
  }
  else {
    if (puVar8 != param_2) {
      do {
        *puVar9 = *puVar8;
        puVar11 = puVar8 + 1;
        puVar8 = puVar8 + 2;
        puVar9[1] = *puVar11;
        puVar9 = puVar9 + 2;
      } while (puVar8 != param_2);
      puVar11 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar11) {
      puVar8 = puVar10 + iVar2 * 2 + 2;
      do {
        *puVar8 = *param_2;
        puVar9 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar8[1] = *puVar9;
        puVar8 = puVar8 + 2;
      } while (param_2 != puVar11);
    }
  }
  iVar6 = *param_1;
  if (iVar6 != 0) {
    uVar7 = param_1[2] - iVar6 & 0xfffffff8;
    iVar3 = iVar6;
    if (0xfff < uVar7) {
      iVar3 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar3) - 4U) {
LAB_0083ba02:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + uVar1 * 2);
  param_1[2] = (int)(puVar10 + uVar4 * 2);
  return *param_1 + iVar2 * 8;
}



/* FUNCTION 12802 ; VA 0x0083ba10 ; FUN_0083ba10 */

void FUN_0083ba10(uint *param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = *param_2;
  if (*param_1 < uVar2) {
    uVar1 = param_2[1];
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    *param_1 = uVar2;
    param_1[1] = uVar1;
    uVar2 = *param_2;
  }
  if (uVar2 < *param_3) {
    uVar2 = *param_3;
    *param_3 = *param_2;
    uVar1 = param_3[1];
    param_3[1] = param_2[1];
    *param_2 = uVar2;
    param_2[1] = uVar1;
    if (*param_1 < uVar2) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *param_1 = uVar2;
      param_1[1] = uVar1;
    }
  }
  return;
}



/* FUNCTION 12803 ; VA 0x0083ba70 ; FUN_0083ba70 */

void FUN_0083ba70(undefined4 *param_1,uint *param_2,uint *param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puStack_10;
  uint *puStack_c;
  uint *puStack_8;
  
  puVar5 = param_3 + -2;
  puStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar3 = (int)puVar5 - (int)param_2 >> 3;
  if (iVar3 < 0x29) {
    FUN_0083ba10(param_2,puStack_8,puVar5,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_0083ba10(param_2,param_2 + iVar3 * 2,param_2 + iVar3 * 4,param_4);
    FUN_0083ba10(puStack_8 + iVar3 * -2,puStack_8,puStack_8 + iVar3 * 2,param_4);
    FUN_0083ba10(puVar5 + iVar3 * -4,puVar5 + iVar3 * -2,puVar5,param_4);
    FUN_0083ba10(param_2 + iVar3 * 2,puStack_8,puVar5 + iVar3 * -2,param_4);
  }
  puVar5 = puStack_8 + 2;
  for (; ((param_2 < puStack_8 &&
          (uVar1 = *puStack_8, uVar2 = puStack_8[-2], uVar1 > uVar2 || uVar2 == uVar1)) &&
         (uVar1 <= uVar2)); puStack_8 = puStack_8 + -2) {
  }
  puVar8 = puVar5;
  puStack_10 = puVar5;
  puStack_c = puVar5;
  puVar7 = puStack_8;
  if (puVar5 < param_3) {
    uVar1 = *puStack_8;
    do {
      uVar2 = *puVar5;
      puVar8 = puVar5;
      puStack_10 = puVar5;
      puStack_c = puVar5;
      if ((uVar2 >= uVar1 && uVar2 != uVar1) || (uVar2 < uVar1)) break;
      puVar5 = puVar5 + 2;
      puVar8 = puVar5;
      puStack_10 = puVar5;
      puStack_c = puVar5;
    } while (puVar5 < param_3);
  }
joined_r0x0083bb62:
  do {
    puVar6 = puStack_8;
    if (param_3 <= puVar5) {
joined_r0x0083bb9f:
      for (; puVar9 = puVar8, param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
        puVar4 = puVar6 + -2;
        puVar8 = puVar7;
        if (*puVar4 <= *puVar7) {
          puVar5 = puStack_10;
          puVar9 = puStack_c;
          if (*puVar4 < *puVar7) break;
          puVar8 = puVar7 + -2;
          if (puVar8 != puVar4) {
            uVar1 = *puVar8;
            uVar2 = puVar7[-1];
            *puVar8 = *puVar4;
            puVar7[-1] = puVar6[-1];
            *puVar4 = uVar1;
            puVar6[-1] = uVar2;
          }
        }
        puVar5 = puStack_10;
        puVar7 = puVar8;
        puVar8 = puStack_c;
        puVar6 = puVar4;
      }
      if (puStack_8 == param_2) {
        if (puVar5 == param_3) {
          param_1[1] = puVar9;
          *param_1 = puVar7;
          return;
        }
        if (puVar9 != puVar5) {
          uVar1 = *puVar7;
          uVar2 = puVar7[1];
          *puVar7 = *puVar9;
          puVar7[1] = puVar9[1];
          *puVar9 = uVar1;
          puVar9[1] = uVar2;
        }
        uVar1 = *puVar7;
        uVar2 = puVar7[1];
        *puVar7 = *puVar5;
        puVar7[1] = puVar5[1];
        puVar5[1] = uVar2;
        *puVar5 = uVar1;
        puVar5 = puVar5 + 2;
        puVar8 = puVar9 + 2;
        puStack_10 = puVar5;
        puStack_c = puVar9 + 2;
        puVar7 = puVar7 + 2;
      }
      else {
        puVar6 = puStack_8 + -2;
        if (puVar5 == param_3) {
          puVar4 = puVar7 + -2;
          if (puVar6 != puVar4) {
            uVar1 = *puVar6;
            uVar2 = puStack_8[-1];
            *puVar6 = *puVar4;
            puStack_8[-1] = puVar7[-1];
            *puVar4 = uVar1;
            puVar7[-1] = uVar2;
            puVar5 = puStack_10;
          }
          puVar8 = puVar9 + -2;
          uVar1 = *puVar4;
          uVar2 = puVar7[-1];
          *puVar4 = puVar9[-2];
          puVar7[-1] = puVar9[-1];
          puVar9[-1] = uVar2;
          *puVar8 = uVar1;
          puStack_c = puVar8;
          puStack_8 = puVar6;
          puVar7 = puVar4;
        }
        else {
          uVar1 = *puVar5;
          uVar2 = puVar5[1];
          *puVar5 = *puVar6;
          puVar5[1] = puStack_8[-1];
          puVar5 = puVar5 + 2;
          puStack_8[-1] = uVar2;
          *puVar6 = uVar1;
          puVar8 = puVar9;
          puStack_10 = puVar5;
          puStack_8 = puVar6;
        }
      }
      goto joined_r0x0083bb62;
    }
    if (*puVar7 <= *puVar5) {
      puStack_c = puVar8;
      puStack_10 = puVar5;
      if (*puVar7 < *puVar5) goto joined_r0x0083bb9f;
      if (puVar8 != puVar5) {
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = *puVar5;
        puVar8[1] = puVar5[1];
        puVar5[1] = uVar2;
        *puVar5 = uVar1;
      }
      puVar8 = puVar8 + 2;
    }
    puVar5 = puVar5 + 2;
    puStack_10 = puVar5;
    puStack_c = puVar8;
  } while( true );
}



/* FUNCTION 12804 ; VA 0x0083bcc0 ; FUN_0083bcc0 */

void FUN_0083bcc0(int param_1,int param_2,uint param_3,uint *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar2 = param_2;
  iVar4 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar4 = (2 - (uint)(*(uint *)(param_1 + 8 + iVar2 * 0x10) <
                         *(uint *)(param_1 + 0x10 + iVar2 * 0x10))) + iVar2 * 2;
      *(undefined4 *)(param_1 + iVar2 * 8) = *(undefined4 *)(param_1 + iVar4 * 8);
      *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + 4 + iVar4 * 8);
      iVar2 = iVar4;
    } while (iVar4 < iVar3);
  }
  if ((iVar4 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar4 = param_3 - 1;
  }
  while (param_2 < iVar4) {
    iVar2 = iVar4 + -1 >> 1;
    uVar1 = *(uint *)(param_1 + iVar2 * 8);
    if (uVar1 <= *param_4) break;
    *(uint *)(param_1 + iVar4 * 8) = uVar1;
    *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar2 * 8);
    iVar4 = iVar2;
  }
  *(uint *)(param_1 + iVar4 * 8) = *param_4;
  *(uint *)(param_1 + 4 + iVar4 * 8) = param_4[1];
  return;
}



/* FUNCTION 12805 ; VA 0x0083bd60 ; FUN_0083bd60 */

void __thiscall FUN_0083bd60(uint *param_1,uint param_2)

{
  void **ppvVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7290;
  pvStack_10 = ExceptionList;
  uVar4 = param_1[1];
  uVar5 = (int)(uVar4 - *param_1) / 0x278;
  uStack_20 = (int)(param_1[2] - *param_1) / 0x278;
  if (param_2 <= uStack_20) {
    if (uVar5 < param_2) {
      ppvVar1 = &pvStack_10;
      for (iVar3 = param_2 - uVar5; ExceptionList = ppvVar1, iVar3 != 0; iVar3 = iVar3 + -1) {
        FUN_0083a6a0();
        uVar4 = uVar4 + 0x278;
        ppvVar1 = (void **)ExceptionList;
      }
      param_1[1] = uVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 != uVar5) {
      param_1[1] = param_2 * 0x278 + *param_1;
    }
    return;
  }
  if (0x67b23a < param_2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x67b23a - (uStack_20 >> 1) < uStack_20) {
    uStack_20 = param_2;
  }
  else {
    uStack_20 = (uStack_20 >> 1) + uStack_20;
    if (uStack_20 < param_2) {
      uStack_20 = param_2;
    }
  }
  uVar4 = uStack_20 * 0x278;
  if (uStack_20 < 0x67b23b) {
    if (0xfff < uVar4) goto LAB_0083be0f;
    if (uVar4 == 0) {
      uVar4 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar4 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_0083be0f:
    uVar2 = uVar4 + 0x23;
    if (uVar2 <= uVar4) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0083bf80;
    uVar4 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar3;
  }
  uStack_8 = 0;
  for (iVar3 = param_2 - uVar5; iVar3 != 0; iVar3 = iVar3 + -1) {
    FUN_0083a6a0();
  }
  puVar9 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  if (puVar8 != puVar9) {
    puVar6 = puVar8;
    do {
      puVar7 = puVar6 + 0x9e;
      puVar10 = (undefined4 *)((int)puVar6 + (uVar4 - (int)puVar8));
      for (iVar3 = 0x9e; iVar3 != 0; iVar3 = iVar3 + -1) {
        *puVar10 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar10 = puVar10 + 1;
      }
      puVar6 = puVar7;
    } while (puVar7 != puVar9);
    puVar8 = (undefined4 *)*param_1;
  }
  if (puVar8 != (undefined4 *)0x0) {
    uVar5 = ((int)(param_1[2] - (int)puVar8) / 0x278) * 0x278;
    puVar9 = puVar8;
    if (0xfff < uVar5) {
      puVar9 = (undefined4 *)puVar8[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)puVar8 + (-4 - (int)puVar9))) {
LAB_0083bf80:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar9,uVar5);
  }
  *param_1 = uVar4;
  param_1[1] = param_2 * 0x278 + uVar4;
  param_1[2] = uStack_20 * 0x278 + uVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12806 ; VA 0x0083bf85 ; Catch_All@0083bf85 */

void Catch_All_0083bf85(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x24);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0083ae50(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12807 ; VA 0x0083bfb0 ; FUN_0083bfb0 */

void FUN_0083bfb0(uint *param_1,uint *param_2,int param_3,undefined4 param_4)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  int iVar8;
  uint *puVar9;
  uint *puStack_1c;
  uint *puStack_18;
  uint uStack_14;
  uint *puStack_10;
  uint uStack_c;
  uint uStack_8;
  
  iVar3 = (int)param_2 - (int)param_1;
  puVar6 = param_2;
  puVar7 = param_1;
  iVar8 = param_3;
  do {
    iVar3 = iVar3 >> 3;
    if (iVar3 < 0x21) {
LAB_0083c037:
      if (((1 < iVar3) && (puVar7 != puVar6)) && (puVar5 = puVar7 + 2, puVar5 != puVar6)) {
        do {
          uVar4 = *puVar5;
          uStack_c = puVar5[1];
          if (*puVar7 < uVar4) {
            FUN_0055b6b0((int)&param_1 + 3,&puStack_18,&puStack_18);
            FUN_0170cc70((int)puVar5 + (8 - ((int)puVar5 - (int)puVar7)),puVar7,
                         (int)puVar5 - (int)puVar7);
            *puVar7 = uVar4;
            puVar7[1] = uStack_c;
          }
          else {
            uVar2 = puVar5[-2];
            puVar1 = puVar5 + -2;
            puVar6 = puVar5;
            while (puVar9 = puVar1, uVar2 < uVar4) {
              *puVar6 = *puVar9;
              puVar6[1] = puVar9[1];
              puVar1 = puVar9 + -2;
              puVar6 = puVar9;
              uVar2 = puVar9[-2];
            }
            *puVar6 = uVar4;
            puVar6[1] = uStack_c;
          }
          puVar5 = puVar5 + 2;
        } while (puVar5 != param_2);
      }
      return;
    }
    if (iVar8 < 1) {
      if (0x20 < iVar3) {
        uVar4 = (int)puVar6 - (int)puVar7 >> 3;
        puVar6 = (uint *)((int)puVar6 - (int)puVar7 >> 4);
        if (0 < (int)puVar6) {
          param_1 = (uint *)((int)(uVar4 - 1) >> 1);
          puVar5 = puVar7 + (int)puVar6 * 2;
          do {
            uStack_c = puVar5[-2];
            puVar6 = (uint *)((int)puVar6 + -1);
            uStack_14 = puVar5[-1];
            puVar1 = puVar6;
            while ((int)puVar1 < (int)param_1) {
              puVar9 = (uint *)((2 - (uint)(puVar7[(int)puVar1 * 4 + 2] <
                                           puVar7[(int)puVar1 * 4 + 4])) + (int)puVar1 * 2);
              puVar7[(int)puVar1 * 2] = puVar7[(int)puVar9 * 2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[(int)puVar9 * 2 + 1];
              puVar1 = puVar9;
            }
            if ((puVar1 == param_1) && ((uVar4 & 1) == 0)) {
              puVar7[(int)puVar1 * 2] = puVar7[uVar4 * 2 + -2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[uVar4 * 2 + -1];
              puVar1 = (uint *)(uVar4 - 1);
            }
            while (((int)puVar6 < (int)puVar1 &&
                   (puVar9 = (uint *)((int)puVar1 + -1 >> 1), uStack_c < puVar7[(int)puVar9 * 2])))
            {
              puVar7[(int)puVar1 * 2] = puVar7[(int)puVar9 * 2];
              puVar7[(int)puVar1 * 2 + 1] = puVar7[(int)puVar9 * 2 + 1];
              puVar1 = puVar9;
            }
            puVar7[(int)puVar1 * 2] = uStack_c;
            puVar7[(int)puVar1 * 2 + 1] = uStack_14;
            puVar5 = puVar5 + -2;
            puStack_10 = puVar6;
          } while (0 < (int)puVar6);
        }
        if ((int)uVar4 < 2) {
          return;
        }
        puVar6 = param_2 + -2;
        uStack_8 = uVar4;
        do {
          if (1 < (int)uVar4) {
            puStack_1c = (uint *)*puVar6;
            puStack_18 = (uint *)puVar6[1];
            *puVar6 = *puVar7;
            puVar6[1] = puVar7[1];
            FUN_0083bcc0(puVar7,0,(int)puVar6 - (int)puVar7 >> 3,&puStack_1c,param_4);
          }
          puVar6 = puVar6 + -2;
          uVar4 = (int)puVar6 + (8 - (int)puVar7) >> 3;
        } while (1 < (int)uVar4);
        return;
      }
      goto LAB_0083c037;
    }
    FUN_0083ba70(&puStack_1c,puVar7,puVar6,param_4);
    iVar8 = (iVar8 >> 1) + (iVar8 >> 2);
    if ((int)((int)puStack_1c - (int)puVar7 & 0xfffffff8U) <
        (int)((int)puVar6 - (int)puStack_18 & 0xfffffff8U)) {
      FUN_0083bfb0(puVar7,puStack_1c,iVar8,param_4);
      puVar7 = puStack_18;
    }
    else {
      FUN_0083bfb0(puStack_18,puVar6,iVar8,param_4);
      param_2 = puStack_1c;
      puVar6 = puStack_1c;
    }
    iVar3 = (int)puVar6 - (int)puVar7;
  } while( true );
}



/* FUNCTION 12808 ; VA 0x0083c210 ; FUN_0083c210 */

int __fastcall FUN_0083c210(int param_1)

{
  int iVar1;
  
  iVar1 = 0x40;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  do {
    FUN_0083a6a0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  iVar1 = 0x40;
  do {
    FUN_0083a6a0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  *(undefined4 *)(param_1 + 0x13c18) = 0;
  *(undefined4 *)(param_1 + 0x13c1c) = 0;
  *(undefined4 *)(param_1 + 0x13c20) = 0;
  *(undefined4 *)(param_1 + 0x13c24) = 0;
  *(undefined4 *)(param_1 + 0x13c34) = 0;
  *(undefined4 *)(param_1 + 0x13c38) = 0;
  *(undefined4 *)(param_1 + 0x13c3c) = 0;
  *(undefined4 *)(param_1 + 0x13c40) = 0;
  *(undefined4 *)(param_1 + 0x13c28) = 0;
  *(undefined4 *)(param_1 + 0x13c2c) = 0;
  *(undefined4 *)(param_1 + 0x13c30) = 0;
  *(undefined4 *)(param_1 + 0x13c44) = 0;
  *(undefined4 *)(param_1 + 0x13c48) = 0;
  *(undefined4 *)(param_1 + 0x13c4c) = 0;
  return param_1;
}



/* FUNCTION 12809 ; VA 0x0083c2f0 ; FUN_0083c2f0 */

undefined8 * __fastcall FUN_0083c2f0(undefined8 *param_1)

{
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  param_1[2] = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  return param_1;
}



/* FUNCTION 12810 ; VA 0x0083c350 ; FUN_0083c350 */

undefined4 * __fastcall FUN_0083c350(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b72d2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0083a940(3);
  *param_1 = RBX::Graphics::Shadows::ShadowObjectDirectional::vftable;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_016f4053(param_1 + 0x82,0x13c50,4,FUN_0083c210,FUN_0083ca80);
  param_1[0x13cd2] = 0;
  param_1[0x13cd3] = 0;
  param_1[0x13cd4] = 0;
  param_1[0x13cd5] = 0;
  iVar1 = 4;
  param_1[0x13cd6] = 0;
  param_1[0x13cd7] = 0;
  param_1[0x13cd8] = 0;
  *(undefined *)(param_1 + 0x13cd9) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  do {
    FUN_0060f2c0();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  if (0x277 < (param_1[6] - param_1[5]) - 0x9e0) {
    FUN_0083bd60(4,param_1 + 5);
  }
  if (0x277 < (param_1[3] - param_1[2]) - 0x9e0) {
    FUN_0083bd60(4,param_1 + 2);
  }
  param_1[0x13cda] = 0;
  param_1[0x13cdb] = 0;
  param_1[0x13cdc] = 0;
  param_1[0x13cdd] = 0;
  param_1[0x13cde] = 0;
  param_1[0x13cdf] = 0;
  param_1[0x13ce0] = 0;
  param_1[0x13ce1] = 0;
  param_1[0x13ce2] = 0;
  param_1[0x13ce3] = 0;
  param_1[0x13ce4] = 0;
  param_1[0x13ce5] = 0;
  param_1[0x13ce6] = 0;
  param_1[0x13ce7] = 0;
  param_1[0x13ce8] = 0;
  param_1[0x13ce9] = 0;
  param_1[0x73] = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12811 ; VA 0x0083c4b0 ; FUN_0083c4b0 */

int __thiscall FUN_0083c4b0(int param_1,int *param_2,int param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  float *pfVar7;
  undefined8 *puVar8;
  int *piVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  uint uVar14;
  uint uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined auStack_34 [20];
  float fStack_20;
  int iStack_18;
  int iStack_14;
  
  iStack_18 = param_1;
  FUN_007cc9d0();
  iStack_14 = 6;
  iVar1 = *param_2;
  uVar2 = *(undefined4 *)(iVar1 + 0x20);
  uVar3 = *(undefined4 *)(iVar1 + 0x24);
  uVar4 = *(undefined4 *)(iVar1 + 0x28);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(iVar1 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = uVar2;
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  *(undefined4 *)(param_1 + 0x28) = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x30);
  uVar3 = *(undefined4 *)(iVar1 + 0x34);
  uVar4 = *(undefined4 *)(iVar1 + 0x38);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(iVar1 + 0x2c);
  *(undefined4 *)(param_1 + 0x30) = uVar2;
  *(undefined4 *)(param_1 + 0x34) = uVar3;
  *(undefined4 *)(param_1 + 0x38) = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x40);
  uVar3 = *(undefined4 *)(iVar1 + 0x44);
  uVar4 = *(undefined4 *)(iVar1 + 0x48);
  *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(iVar1 + 0x3c);
  *(undefined4 *)(param_1 + 0x40) = uVar2;
  *(undefined4 *)(param_1 + 0x44) = uVar3;
  *(undefined4 *)(param_1 + 0x48) = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x50);
  uVar3 = *(undefined4 *)(iVar1 + 0x54);
  uVar4 = *(undefined4 *)(iVar1 + 0x58);
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(iVar1 + 0x4c);
  *(undefined4 *)(param_1 + 0x50) = uVar2;
  *(undefined4 *)(param_1 + 0x54) = uVar3;
  *(undefined4 *)(param_1 + 0x58) = uVar4;
  iVar1 = param_2[2];
  iVar5 = param_2[3];
  iVar6 = param_2[4];
  *(int *)(param_1 + 0x5c) = param_2[1];
  *(int *)(param_1 + 0x60) = iVar1;
  *(int *)(param_1 + 100) = iVar5;
  *(int *)(param_1 + 0x68) = iVar6;
  iVar1 = param_2[6];
  iVar5 = param_2[7];
  iVar6 = param_2[8];
  *(int *)(param_1 + 0x6c) = param_2[5];
  *(int *)(param_1 + 0x70) = iVar1;
  *(int *)(param_1 + 0x74) = iVar5;
  *(int *)(param_1 + 0x78) = iVar6;
  iVar1 = param_2[10];
  iVar5 = param_2[0xb];
  iVar6 = param_2[0xc];
  *(int *)(param_1 + 0x7c) = param_2[9];
  *(int *)(param_1 + 0x80) = iVar1;
  *(int *)(param_1 + 0x84) = iVar5;
  *(int *)(param_1 + 0x88) = iVar6;
  iVar1 = param_2[0xe];
  iVar5 = param_2[0xf];
  iVar6 = param_2[0x10];
  *(int *)(param_1 + 0x8c) = param_2[0xd];
  *(int *)(param_1 + 0x90) = iVar1;
  *(int *)(param_1 + 0x94) = iVar5;
  *(int *)(param_1 + 0x98) = iVar6;
  *(float *)(param_1 + 0x68) =
       (float)(param_3 * -2) * (float)param_2[0x3b] + *(float *)(param_1 + 0x68);
  *(float *)(param_1 + 0x78) =
       (float)(param_4 * 2) * (float)param_2[0x3c] + *(float *)(param_1 + 0x78);
  iVar1 = param_2[0x12];
  iVar5 = param_2[0x13];
  iVar6 = param_2[0x14];
  *(int *)(param_1 + 0xdc) = param_2[0x11];
  *(int *)(param_1 + 0xe0) = iVar1;
  *(int *)(param_1 + 0xe4) = iVar5;
  *(int *)(param_1 + 0xe8) = iVar6;
  iVar1 = param_2[0x16];
  iVar5 = param_2[0x17];
  iVar6 = param_2[0x18];
  *(int *)(param_1 + 0xec) = param_2[0x15];
  *(int *)(param_1 + 0xf0) = iVar1;
  *(int *)(param_1 + 0xf4) = iVar5;
  *(int *)(param_1 + 0xf8) = iVar6;
  iVar1 = param_2[0x1a];
  iVar5 = param_2[0x1b];
  iVar6 = param_2[0x1c];
  *(int *)(param_1 + 0xfc) = param_2[0x19];
  *(int *)(param_1 + 0x100) = iVar1;
  *(int *)(param_1 + 0x104) = iVar5;
  *(int *)(param_1 + 0x108) = iVar6;
  iVar1 = param_2[0x1e];
  iVar5 = param_2[0x1f];
  iVar6 = param_2[0x20];
  *(int *)(param_1 + 0x10c) = param_2[0x1d];
  *(int *)(param_1 + 0x110) = iVar1;
  *(int *)(param_1 + 0x114) = iVar5;
  *(int *)(param_1 + 0x118) = iVar6;
  *(float *)(param_1 + 0xe8) =
       (float)(param_3 * -2) * (float)param_2[0x3b] + *(float *)(param_1 + 0xe8);
  *(float *)(param_1 + 0xf8) =
       (float)(param_4 * 2) * (float)param_2[0x3c] + *(float *)(param_1 + 0xf8);
  piVar9 = param_2 + 0x23;
  puVar8 = (undefined8 *)(param_1 + 300);
  do {
    iVar1 = piVar9[1];
    iVar5 = piVar9[2];
    iVar6 = piVar9[3];
    *(int *)(puVar8 + -2) = *piVar9;
    *(int *)((int)puVar8 + -0xc) = iVar1;
    *(int *)(puVar8 + -1) = iVar5;
    *(int *)((int)puVar8 + -4) = iVar6;
    pfVar7 = (float *)FUN_011658d0(auStack_34);
    piVar9 = piVar9 + 4;
    iStack_14 = iStack_14 + -1;
    uVar14 = (uint)DAT_018c0da0;
    uVar15 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    fVar19 = pfVar7[2];
    *puVar8 = CONCAT44((float)(double)CONCAT44((uint)((ulonglong)(double)pfVar7[1] >> 0x20) & uVar15
                                               ,SUB84((double)pfVar7[1],0) & uVar14),
                       (float)(double)CONCAT44((uint)((ulonglong)(double)*pfVar7 >> 0x20) & uVar15,
                                               SUB84((double)*pfVar7,0) & uVar14));
    fStack_20 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar19 >> 0x20) & uVar15,
                                        SUB84((double)fVar19,0) & uVar14);
    *(float *)(puVar8 + 1) = fStack_20;
    puVar8 = (undefined8 *)((int)puVar8 + 0x1c);
  } while (iStack_14 != 0);
  fVar12 = (float)param_3;
  fVar16 = (float)param_4;
  *(float *)(iStack_18 + 0x160) = *(float *)(iStack_18 + 0x160) - fVar12 * (float)param_2[0x21];
  *(float *)(iStack_18 + 0x17c) = fVar12 * (float)param_2[0x21] + *(float *)(iStack_18 + 0x17c);
  *(float *)(iStack_18 + 0x198) = (float)param_2[0x22] * fVar16 + *(float *)(iStack_18 + 0x198);
  *(float *)(iStack_18 + 0x1b4) = *(float *)(iStack_18 + 0x1b4) - (float)param_2[0x22] * fVar16;
  fVar19 = (float)param_2[0x3b];
  fVar20 = (float)param_2[0x43] * fVar12 * fVar19;
  fVar18 = (float)param_2[0x44] * fVar12 * fVar19;
  fVar19 = (float)param_2[0x45] * fVar12 * fVar19;
  fVar12 = (float)param_2[0x3c];
  fVar11 = fVar16 * (float)param_2[0x46] * fVar12;
  fVar13 = (float)param_2[0x47] * fVar16 * fVar12;
  fVar12 = (float)param_2[0x48] * fVar16 * fVar12;
  fVar17 = (float)param_2[0x3f] + fVar19 + fVar12;
  fVar10 = (float)param_2[0x3d] + fVar20 + fVar11;
  fVar21 = (float)param_2[0x3e] + fVar18 + fVar13;
  fVar11 = fVar20 + (float)param_2[0x40] + fVar11;
  fVar12 = (float)param_2[0x42] + fVar19 + fVar12;
  fVar13 = (float)param_2[0x41] + fVar18 + fVar13;
  *(float *)(iStack_18 + 0x1e4) = fVar10;
  *(float *)(iStack_18 + 0x1e8) = fVar21;
  *(float *)(iStack_18 + 0x1ec) = fVar17;
  *(undefined4 *)(iStack_18 + 0x1f0) = 0x3f800000;
  *(float *)(iStack_18 + 500) = fVar11;
  *(float *)(iStack_18 + 0x1f8) = fVar13;
  *(float *)(iStack_18 + 0x1fc) = fVar12;
  *(undefined4 *)(iStack_18 + 0x200) = 0x3f800000;
  fVar19 = (float)param_2[0x47];
  fVar16 = (float)param_2[0x48];
  *(float *)(iStack_18 + 0x1c4) = fVar10 + (float)param_2[0x46];
  *(float *)(iStack_18 + 0x1c8) = fVar19 + fVar21;
  *(float *)(iStack_18 + 0x1cc) = fVar16 + fVar17;
  *(undefined4 *)(iStack_18 + 0x1d0) = 0x3f800000;
  fVar19 = (float)param_2[0x47];
  fVar16 = (float)param_2[0x48];
  *(float *)(iStack_18 + 0x1d4) = fVar11 + (float)param_2[0x46];
  *(float *)(iStack_18 + 0x1d8) = fVar19 + fVar13;
  *(float *)(iStack_18 + 0x1dc) = fVar16 + fVar12;
  *(undefined4 *)(iStack_18 + 0x1e0) = 0x3f800000;
  fVar19 = (float)param_2[0x44];
  fVar16 = (float)param_2[0x45];
  *(float *)(iStack_18 + 0x224) = (float)param_2[0x43] + fVar10;
  *(float *)(iStack_18 + 0x228) = fVar19 + fVar21;
  *(float *)(iStack_18 + 0x22c) = fVar16 + fVar17;
  *(undefined4 *)(iStack_18 + 0x230) = 0x3f800000;
  fVar19 = (float)param_2[0x44];
  fVar16 = (float)param_2[0x45];
  *(float *)(iStack_18 + 0x234) = fVar11 + (float)param_2[0x43];
  *(float *)(iStack_18 + 0x238) = fVar19 + fVar13;
  *(float *)(iStack_18 + 0x23c) = fVar16 + fVar12;
  *(undefined4 *)(iStack_18 + 0x240) = 0x3f800000;
  fVar19 = (float)param_2[0x44];
  fVar16 = (float)param_2[0x47];
  fVar18 = (float)param_2[0x45];
  fVar20 = (float)param_2[0x48];
  *(float *)(iStack_18 + 0x204) = fVar10 + (float)param_2[0x43] + (float)param_2[0x46];
  *(float *)(iStack_18 + 0x208) = fVar19 + fVar21 + fVar16;
  *(float *)(iStack_18 + 0x20c) = fVar18 + fVar17 + fVar20;
  *(undefined4 *)(iStack_18 + 0x210) = 0x3f800000;
  fVar19 = (float)param_2[0x44];
  fVar16 = (float)param_2[0x47];
  fVar18 = (float)param_2[0x45];
  fVar20 = (float)param_2[0x48];
  *(float *)(iStack_18 + 0x214) = (float)param_2[0x43] + fVar11 + (float)param_2[0x46];
  *(float *)(iStack_18 + 0x218) = fVar19 + fVar13 + fVar16;
  *(float *)(iStack_18 + 0x21c) = fVar18 + fVar12 + fVar20;
  *(undefined4 *)(iStack_18 + 0x220) = 0x3f800000;
  return iStack_18;
}



/* FUNCTION 12812 ; VA 0x0083c9d0 ; FUN_0083c9d0 */

void __fastcall FUN_0083c9d0(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016f32d1(param_1,0x13c50,4,FUN_0083ca80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12813 ; VA 0x0083ca10 ; FUN_0083ca10 */

void __fastcall FUN_0083ca10(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x5c) * 0x5c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12814 ; VA 0x0083ca80 ; FUN_0083ca80 */

void __fastcall FUN_0083ca80(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x13c28);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x13c30) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x13c28) = 0;
    *(undefined4 *)(param_1 + 0x13c2c) = 0;
    *(undefined4 *)(param_1 + 0x13c30) = 0;
  }
  return;
}



/* FUNCTION 12815 ; VA 0x0083caf0 ; FUN_0083caf0 */

undefined4 * __thiscall FUN_0083caf0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Shadows::ShadowObjectDirectional::vftable;
  iVar1 = param_1[0x13cd2];
  if (iVar1 != 0) {
    uVar3 = (param_1[0x13cd4] - iVar1 >> 3) * 8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x13cd2] = 0;
    param_1[0x13cd3] = 0;
    param_1[0x13cd4] = 0;
  }
  uStack_8 = 0;
  FUN_016f32d1(param_1 + 0x82,0x13c50,4,FUN_0083ca80);
  FUN_0083ca10();
  FUN_0083aaf0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4f3a8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12816 ; VA 0x0083cbe0 ; FUN_0083cbe0 */

void __thiscall FUN_0083cbe0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x278) * 0x278;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x278 + param_2;
  param_1[2] = param_4 * 0x278 + param_2;
  return;
}



/* FUNCTION 12817 ; VA 0x0083cc60 ; FUN_0083cc60 */

uint FUN_0083cc60(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x278;
  if (param_1 < 0x67b23b) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 12818 ; VA 0x0083ccd0 ; FUN_0083ccd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0083ccd0(undefined4 param_1,undefined8 *param_2,float *param_3)

{
  undefined4 *puVar1;
  float *pfVar2;
  double dVar3;
  undefined auStack_c4 [36];
  undefined auStack_a0 [36];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  float fStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  undefined4 uStack_10;
  uint uStack_c;
  undefined4 uStack_8;
  
  uStack_10 = 0;
  dVar3 = (double)param_3[1];
  if (DAT_01901f3c <=
      (float)(double)CONCAT44((uint)((ulonglong)dVar3 >> 0x20) & DAT_018c0da0._4_4_,
                              SUB84(dVar3,0) & (uint)DAT_018c0da0)) {
    uStack_c = 0;
    uStack_8 = 0x3f800000;
  }
  else {
    uStack_c = 0x3f800000;
    uStack_8 = 0;
  }
  uStack_4c = _DAT_018e3fb0;
  uStack_48 = _UNK_018e3fb4;
  uStack_44 = _UNK_018e3fb8;
  uStack_40 = _UNK_018e3fbc;
  uStack_2c = 0x3f800000;
  fStack_20 = *(float *)(param_2 + 1);
  uStack_3c = _DAT_018e3fb0;
  uStack_38 = _UNK_018e3fb4;
  uStack_34 = _UNK_018e3fb8;
  uStack_30 = _UNK_018e3fbc;
  uStack_28 = *param_2;
  fStack_1c = (float)uStack_28 + *param_3;
  fStack_18 = *(float *)((int)param_2 + 4) + param_3[1];
  fStack_14 = *(float *)(param_2 + 1) + param_3[2];
  FUN_01163c80(&fStack_1c,(ulonglong)uStack_c << 0x20,uStack_8);
  uStack_7c = _DAT_018e3fb0;
  uStack_78 = _UNK_018e3fb4;
  uStack_74 = _UNK_018e3fb8;
  uStack_70 = _UNK_018e3fbc;
  uStack_6c = _DAT_018e3fb0;
  uStack_68 = _UNK_018e3fb4;
  uStack_64 = _UNK_018e3fb8;
  uStack_60 = _UNK_018e3fbc;
  uStack_5c = _DAT_018e3fb0;
  uStack_58 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
  fStack_50 = (float)_UNK_018e3fbc;
  puVar1 = (undefined4 *)FUN_011630b0(auStack_a0);
  uStack_7c = *puVar1;
  uStack_78 = puVar1[1];
  uStack_74 = puVar1[2];
  uStack_70 = puVar1[3];
  uStack_6c = puVar1[4];
  uStack_68 = puVar1[5];
  uStack_64 = puVar1[6];
  uStack_60 = puVar1[7];
  uStack_5c = puVar1[8];
  pfVar2 = (float *)FUN_01160de0(auStack_c4);
  uStack_58 = CONCAT44(pfVar2[4] * uStack_28._4_4_ + pfVar2[3] * (float)uStack_28 +
                       pfVar2[5] * fStack_20,
                       pfVar2[1] * uStack_28._4_4_ + *pfVar2 * (float)uStack_28 +
                       pfVar2[2] * fStack_20);
  fStack_50 = pfVar2[7] * uStack_28._4_4_ + pfVar2[6] * (float)uStack_28 + pfVar2[8] * fStack_20;
  fStack_14 = fStack_50;
  FUN_011640a0(param_1);
  return param_1;
}



/* FUNCTION 12819 ; VA 0x0083ce90 ; FUN_0083ce90 */

int FUN_0083ce90(int param_1,int param_2,int param_3)

{
  undefined8 *puVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  float *pfVar12;
  undefined4 *puVar13;
  int iVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  double dVar19;
  double dVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  uint uStack_1b8;
  uint uStack_1a0;
  uint uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  uint uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  uint uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  float fStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  float fStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  float fStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined auStack_13c [12];
  float fStack_130;
  undefined auStack_12c [12];
  float fStack_120;
  undefined auStack_11c [12];
  float fStack_110;
  undefined auStack_10c [12];
  float fStack_100;
  float fStack_f4;
  undefined auStack_f0 [12];
  undefined auStack_e4 [12];
  undefined auStack_d8 [12];
  undefined auStack_cc [12];
  undefined auStack_c0 [16];
  undefined auStack_b0 [64];
  undefined auStack_70 [64];
  undefined auStack_30 [44];
  
  FUN_01165e00(auStack_b0);
  FUN_01165e00(auStack_70);
  iVar14 = 4;
  fVar2 = *(float *)(param_3 + 500);
  do {
    FUN_0083c2f0();
    iVar14 = iVar14 + -1;
  } while (iVar14 != 0);
  uStack_1b8 = 0;
  do {
    FUN_00839d90(&uStack_1a0,uStack_1b8);
    uStack_190 = uStack_1a0 ^ DAT_018c4ea0;
    uStack_198 = 0;
    uStack_194 = 0;
    uStack_18c = 0x3f800000;
    FUN_01165b90(auStack_13c,&uStack_198);
    iVar14 = FUN_011658d0(auStack_f0);
    fVar15 = DAT_018ce2f8 / fStack_130;
    uStack_188 = 0;
    uStack_184 = 0;
    uStack_17c = 0x3f800000;
    fVar18 = *(float *)(iVar14 + 8);
    uStack_180 = uStack_19c ^ DAT_018c4ea0;
    FUN_01165b90(auStack_12c,&uStack_188);
    iVar14 = FUN_011658d0(auStack_e4);
    fVar16 = DAT_018ce2f8 / fStack_120;
    uStack_178 = 0x3f800000;
    uStack_174 = 0x3f800000;
    uStack_16c = 0x3f800000;
    fVar21 = *(float *)(iVar14 + 8);
    fStack_170 = fVar15 * fVar18;
    FUN_01165b90(auStack_11c,&uStack_178);
    pfVar12 = (float *)FUN_011658d0(auStack_d8);
    fVar17 = DAT_018ce2f8 / fStack_110;
    uStack_168 = 0x3f800000;
    uStack_164 = 0x3f800000;
    uStack_15c = 0x3f800000;
    fVar18 = *pfVar12;
    fVar15 = pfVar12[1];
    fVar3 = pfVar12[2];
    fStack_160 = fVar16 * fVar21;
    FUN_01165b90(auStack_10c,&uStack_168);
    pfVar12 = (float *)FUN_011658d0(auStack_cc);
    fVar21 = DAT_018ce2f8 / fStack_100;
    fVar24 = (float)(uStack_19c ^ DAT_018c4ea0);
    fVar23 = 0.0 - fVar21 * *pfVar12;
    fVar22 = 0.0 - pfVar12[1] * fVar21;
    fVar16 = fVar24 - pfVar12[2] * fVar21;
    fVar18 = 0.0 - fVar18 * fVar17;
    fVar15 = 0.0 - fVar17 * fVar15;
    fVar21 = fVar24 - fVar3 * fVar17;
    dVar19 = (double)(fVar22 * fVar22 + fVar23 * fVar23 + fVar16 * fVar16);
    FUN_017267a0();
    dVar20 = (double)(fVar15 * fVar15 + fVar18 * fVar18 + fVar21 * fVar21);
    FUN_017267a0();
    uStack_158 = 0;
    puVar1 = (undefined8 *)(param_1 + uStack_1b8 * 0x24);
    uStack_154 = 0;
    uStack_14c = 0x3f800000;
    fVar18 = (float)dVar19;
    if ((float)dVar19 <= (float)dVar20) {
      fVar18 = (float)dVar20;
    }
    fStack_150 = fVar24;
    FUN_01165b90(auStack_c0,&uStack_158);
    FUN_011658d0(&uStack_148);
    *puVar1 = uStack_148;
    *(undefined4 *)(puVar1 + 1) = uStack_140;
    *(float *)((int)puVar1 + 0xc) = fVar18;
    *(undefined4 *)(puVar1 + 4) = 0;
    if (uStack_1b8 == 0) {
      fVar18 = fVar18 - fVar2;
      fStack_f4 = *(float *)(param_2 + 0x30) * fVar18 + *(float *)(param_2 + 0x20);
      *puVar1 = CONCAT44(*(float *)(param_2 + 0x2c) * fVar18 + *(float *)(param_2 + 0x1c),
                         *(float *)(param_2 + 0x28) * fVar18 + *(float *)(param_2 + 0x18));
      *(float *)(puVar1 + 1) = fStack_f4;
    }
    else {
      puVar13 = (undefined4 *)FUN_0083e5b0(auStack_30,param_3,puVar1);
      uVar5 = puVar13[1];
      uVar6 = puVar13[2];
      uVar7 = puVar13[3];
      uVar4 = puVar13[8];
      uVar8 = puVar13[4];
      uVar9 = puVar13[5];
      uVar10 = puVar13[6];
      uVar11 = puVar13[7];
      *(undefined4 *)puVar1 = *puVar13;
      *(undefined4 *)((int)puVar1 + 4) = uVar5;
      *(undefined4 *)(puVar1 + 1) = uVar6;
      *(undefined4 *)((int)puVar1 + 0xc) = uVar7;
      *(undefined4 *)(puVar1 + 2) = uVar8;
      *(undefined4 *)((int)puVar1 + 0x14) = uVar9;
      *(undefined4 *)(puVar1 + 3) = uVar10;
      *(undefined4 *)((int)puVar1 + 0x1c) = uVar11;
      *(undefined4 *)(puVar1 + 4) = uVar4;
    }
    uStack_1b8 = uStack_1b8 + 1;
  } while (uStack_1b8 < 4);
  return param_1;
}



/* FUNCTION 12820 ; VA 0x0083d2e0 ; FUN_0083d2e0 */

uint FUN_0083d2e0(uint param_1,int param_2,int param_3,int *param_4,char param_5)

{
  int iVar1;
  uint uVar2;
  float *pfVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  
  iVar1 = param_1;
  param_1 = 3;
  uVar5 = *(uint *)(iVar1 + 0x14);
  uVar8 = uVar5 / 7;
  uVar7 = *(uint *)(iVar1 + 0x10);
  if (uVar5 == 0) {
    uVar8 = 1;
  }
  uVar6 = 0;
  uVar5 = 0;
  puVar4 = (undefined4 *)(param_3 + 0x20);
  do {
    if ((float *)(param_2 + 0x10) != (float *)(param_2 + 0x58)) {
      pfVar3 = (float *)(param_2 + 0x10);
      do {
        if ((float)puVar4[-5] * (float)puVar4[-5] <
            (pfVar3[1] - (float)puVar4[-7]) * (pfVar3[1] - (float)puVar4[-7]) +
            (*pfVar3 - (float)puVar4[-8]) * (*pfVar3 - (float)puVar4[-8]) +
            (pfVar3[2] - (float)puVar4[-6]) * (pfVar3[2] - (float)puVar4[-6])) goto LAB_0083d3a0;
        pfVar3 = pfVar3 + 3;
      } while (pfVar3 != (float *)(param_2 + 0x58));
    }
    uVar2 = uVar5;
    if (uVar5 < 3) break;
LAB_0083d3a0:
    if (uVar5 < 4) {
      if ((*(int *)(uVar6 + *param_4) == 2) &&
         ((*(int *)(&DAT_01919088 + uVar5 * 4 + (uVar7 + (uVar8 - uVar7 / 0xc) * 0xc) * 0x10) == 0
          || (param_5 != '\0')))) {
        *puVar4 = 2;
      }
    }
    else {
      *puVar4 = 1;
    }
    uVar6 = uVar6 + 0x278;
    uVar5 = uVar5 + 1;
    puVar4 = puVar4 + 9;
    uVar2 = param_1;
  } while (uVar6 < 0x9e0);
  param_1 = uVar2;
  uVar5 = param_1 + 1;
  if (3 < uVar5) {
    return uVar5;
  }
  piVar9 = (int *)(param_3 + (uVar5 + (param_1 + 2) * 8) * 4);
  uVar7 = uVar5;
  do {
    if (*piVar9 == 0) {
      uVar8 = 0;
      *piVar9 = 1;
      if (param_1 != 0) {
        uVar8 = uVar7 % param_1;
      }
      *(undefined4 *)(param_3 + 0x20 + uVar8 * 0x24) = 0;
    }
    uVar7 = uVar7 + 1;
    piVar9 = piVar9 + 9;
  } while (uVar7 < 4);
  return uVar5;
}



/* FUNCTION 12821 ; VA 0x0083d450 ; FUN_0083d450 */

void FUN_0083d450(float *param_1,undefined4 *param_2,float *param_3,float param_4,float *param_5,
                 undefined4 *param_6)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  float *pfVar10;
  float fVar11;
  float fVar12;
  uint uVar13;
  float fVar14;
  uint uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  
  fVar14 = *param_1;
  fVar17 = param_1[1];
  fVar19 = param_1[2];
  fVar22 = (param_3[3] + *param_3) * DAT_018ce2f4;
  fVar1 = param_1[4];
  fVar2 = param_1[5];
  fVar3 = param_1[6];
  fVar4 = param_1[8];
  fVar5 = param_1[9];
  fVar6 = param_1[10];
  fVar23 = (param_3[4] + param_3[1]) * DAT_018ce2f4;
  fVar18 = (param_3[3] - *param_3) * DAT_018ce2f4;
  fVar16 = (param_3[4] - param_3[1]) * DAT_018ce2f4;
  fVar24 = (param_3[5] + param_3[2]) * DAT_018ce2f4;
  fVar20 = (param_3[5] - param_3[2]) * DAT_018ce2f4;
  pfVar10 = (float *)FUN_01165f10(0);
  fVar11 = pfVar10[1] * fVar23 + *pfVar10 * fVar22 + pfVar10[2] * fVar24 + pfVar10[3];
  pfVar10 = (float *)FUN_01165f10(1);
  fVar12 = pfVar10[1] * fVar23 + fVar22 * *pfVar10 + pfVar10[2] * fVar24 + pfVar10[3];
  pfVar10 = (float *)FUN_01165f10(2);
  uVar13 = (uint)DAT_018c0da0;
  uVar15 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
  fVar21 = (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar17 * fVar16) >> 0x20) & uVar15,
                                   SUB84((double)(fVar17 * fVar16),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar14 * fVar18) >> 0x20) & uVar15,
                                   SUB84((double)(fVar14 * fVar18),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar19 * fVar20) >> 0x20) & uVar15,
                                   SUB84((double)(fVar19 * fVar20),0) & uVar13);
  fVar19 = (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar2 * fVar16) >> 0x20) & uVar15,
                                   SUB84((double)(fVar2 * fVar16),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar1 * fVar18) >> 0x20) & uVar15,
                                   SUB84((double)(fVar1 * fVar18),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar3 * fVar20) >> 0x20) & uVar15,
                                   SUB84((double)(fVar3 * fVar20),0) & uVar13);
  fVar17 = (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar5 * fVar16) >> 0x20) & uVar15,
                                   SUB84((double)(fVar5 * fVar16),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar4 * fVar18) >> 0x20) & uVar15,
                                   SUB84((double)(fVar4 * fVar18),0) & uVar13) +
           (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar6 * fVar20) >> 0x20) & uVar15,
                                   SUB84((double)(fVar6 * fVar20),0) & uVar13) +
           param_4 * DAT_018ce2f4;
  fVar14 = (pfVar10[1] * fVar23 + *pfVar10 * fVar22 + pfVar10[2] * fVar24 + pfVar10[3]) -
           param_4 * DAT_018ce2f4;
  *param_5 = fVar11 - fVar21;
  param_5[1] = fVar12 - fVar19;
  param_5[2] = fVar14 - fVar17;
  param_5[3] = fVar21 + fVar11;
  *(ulonglong *)(param_5 + 4) = CONCAT44(fVar17 + fVar14,fVar19 + fVar12);
  uVar7 = param_2[1];
  uVar8 = param_2[2];
  uVar9 = param_2[3];
  *param_6 = *param_2;
  param_6[1] = uVar7;
  param_6[2] = uVar8;
  param_6[3] = uVar9;
  uVar7 = param_2[5];
  uVar8 = param_2[6];
  uVar9 = param_2[7];
  param_6[4] = param_2[4];
  param_6[5] = uVar7;
  param_6[6] = uVar8;
  param_6[7] = uVar9;
  uVar7 = param_2[9];
  uVar8 = param_2[10];
  uVar9 = param_2[0xb];
  param_6[8] = param_2[8];
  param_6[9] = uVar7;
  param_6[10] = uVar8;
  param_6[0xb] = uVar9;
  uVar7 = param_2[0xd];
  uVar8 = param_2[0xe];
  uVar9 = param_2[0xf];
  param_6[0xc] = param_2[0xc];
  param_6[0xd] = uVar7;
  param_6[0xe] = uVar8;
  param_6[0xf] = uVar9;
  return;
}



/* FUNCTION 12822 ; VA 0x0083d730 ; FUN_0083d730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0083d730(int param_1,int param_2)

{
  undefined uVar1;
  char cVar2;
  float *pfVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  float fVar7;
  float10 fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  int *in_stack_00000018;
  float *in_stack_0000001c;
  char in_stack_00000020;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  float fStack_fc;
  float fStack_f8;
  float fStack_f4;
  float fStack_f0;
  undefined4 auStack_ec [4];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  undefined8 uStack_9c;
  float fStack_94;
  undefined8 uStack_90;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined auStack_68 [4];
  ulonglong uStack_64;
  float fStack_5c;
  float fStack_58;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float *pfStack_30;
  undefined8 uStack_2c;
  float *pfStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7348;
  pvStack_10 = ExceptionList;
  fVar9 = *(float *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  fStack_20 = fVar9;
  if ((*(int *)((int)fVar9 + 0x34) < DAT_01eb44b8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb44b8), DAT_01eb44b8 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("ShadowMap","getPotentialShadowCasters",0xffffffff);
    DAT_01eb44b4 = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb44b0 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb44b8);
  }
  uStack_4c = DAT_01eb44b0;
  uStack_78 = DAT_01eb44b0;
  uStack_48 = DAT_01eb44b4;
  uStack_74 = DAT_01eb44b4;
  uStack_70 = FUN_0152d930(DAT_01eb44b0,DAT_01eb44b4);
  uStack_8 = 1;
  if (*(int *)((int)fVar9 + 0x34) < DAT_01eb44c8) {
    FUN_016f3809(&DAT_01eb44c8);
    if (DAT_01eb44c8 == -1) {
      uStack_8._0_1_ = 2;
      uVar13 = FUN_0152dab0("ShadowMap","Spatial culling",0xffffffff);
      DAT_01eb44c4 = (float *)((ulonglong)uVar13 >> 0x20);
      DAT_01eb44c0 = (float)uVar13;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb44c8);
    }
  }
  fStack_1c = DAT_01eb44c0;
  fStack_34 = DAT_01eb44c0;
  pfStack_14 = DAT_01eb44c4;
  pfStack_30 = DAT_01eb44c4;
  uVar13 = FUN_0152d930(DAT_01eb44c0,DAT_01eb44c4);
  uStack_8._0_1_ = 3;
  uStack_2c = uVar13;
  FUN_00817260(in_stack_0000001c,param_1,4);
  uStack_8._0_1_ = 4;
  FUN_0152dda0(fStack_1c,pfStack_14,uVar13);
  fVar9 = fStack_20;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (in_stack_00000020 == '\0') {
    fStack_1c = 0.0;
    pfStack_24 = (float *)*in_stack_0000001c;
    fStack_44 = (float)((uint)((int)in_stack_0000001c[1] + (3 - (int)pfStack_24)) >> 2);
    if ((float *)in_stack_0000001c[1] < pfStack_24) {
      fStack_44 = 0.0;
    }
    if (fStack_44 != 0.0) {
      pfStack_14 = (float *)(param_1 + 0x1c);
      uStack_8._0_1_ = uVar1;
      do {
        fVar7 = fStack_1c;
        fVar9 = *pfStack_24;
        FUN_01165e00(&uStack_14c);
        FUN_01165ab0();
        fStack_ac = _DAT_018c4eb0;
        fStack_a8 = _UNK_018c4eb4;
        fStack_a4 = _UNK_018c4eb8;
        fStack_a0 = _UNK_018c4ebc;
        fVar12 = (*(float *)((int)fVar9 + 0x28) + *(float *)((int)fVar9 + 0x1c)) * DAT_018ce2f4;
        fVar10 = (*(float *)((int)fVar9 + 0x24) + *(float *)((int)fVar9 + 0x18)) * DAT_018ce2f4;
        uStack_9c = 0xff7fffffff7fffff;
        fStack_fc = *pfStack_14;
        fStack_f8 = pfStack_14[1];
        fStack_f4 = pfStack_14[2];
        fStack_f0 = pfStack_14[3];
        fStack_10c = pfStack_14[4];
        fStack_108 = pfStack_14[5];
        fStack_104 = pfStack_14[6];
        fStack_100 = pfStack_14[7];
        fStack_18 = (*(float *)((int)fVar9 + 0x2c) + *(float *)((int)fVar9 + 0x20)) * DAT_018ce2f4;
        fStack_88 = pfStack_14[8];
        fStack_84 = pfStack_14[9];
        fStack_80 = pfStack_14[10];
        fStack_7c = pfStack_14[0xb];
        fStack_40 = (*(float *)((int)fVar9 + 0x24) - *(float *)((int)fVar9 + 0x18)) * DAT_018ce2f4;
        fStack_3c = (*(float *)((int)fVar9 + 0x28) - *(float *)((int)fVar9 + 0x1c)) * DAT_018ce2f4;
        fStack_20 = (*(float *)((int)fVar9 + 0x2c) - *(float *)((int)fVar9 + 0x20)) * DAT_018ce2f4;
        fStack_94 = fVar9;
        pfVar3 = (float *)FUN_01165f10(0);
        uStack_64 = (ulonglong)
                    (uint)(pfVar3[1] * fVar12 + *pfVar3 * fVar10 + pfVar3[2] * fStack_18 + pfVar3[3]
                          );
        pfVar3 = (float *)FUN_01165f10(1);
        fStack_38 = pfVar3[1] * fVar12 + fVar10 * *pfVar3 + pfVar3[2] * fStack_18 + pfVar3[3];
        pfVar3 = (float *)FUN_01165f10(2);
        fStack_ac = (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_f4 * fStack_20) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_f4 * fStack_20),0) &
                                            (uint)DAT_018c0da0) +
                    (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_f8 * fStack_3c) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_f8 * fStack_3c),0) &
                                            (uint)DAT_018c0da0) +
                    (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_fc * fStack_40) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_fc * fStack_40),0) &
                                            (uint)DAT_018c0da0);
        fStack_a8 = (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_104 * fStack_20) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_104 * fStack_20),0) &
                                            (uint)DAT_018c0da0) +
                    (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_108 * fStack_3c) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_108 * fStack_3c),0) &
                                            (uint)DAT_018c0da0) +
                    (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_10c * fStack_40) >>
                                                  0x20) & DAT_018c0da0._4_4_,
                                            SUB84((double)(fStack_10c * fStack_40),0) &
                                            (uint)DAT_018c0da0);
        fVar9 = fStack_a8 + fStack_38;
        fStack_a0 = (float)uStack_64 + fStack_ac;
        fVar11 = (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_80 * fStack_20) >> 0x20)
                                         & DAT_018c0da0._4_4_,
                                         SUB84((double)(fStack_80 * fStack_20),0) &
                                         (uint)DAT_018c0da0) +
                 (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_84 * fStack_3c) >> 0x20)
                                         & DAT_018c0da0._4_4_,
                                         SUB84((double)(fStack_84 * fStack_3c),0) &
                                         (uint)DAT_018c0da0) +
                 (float)(double)CONCAT44((uint)((ulonglong)(double)(fStack_88 * fStack_40) >> 0x20)
                                         & DAT_018c0da0._4_4_,
                                         SUB84((double)(fStack_88 * fStack_40),0) &
                                         (uint)DAT_018c0da0) + DAT_018ce324;
        fStack_a8 = fStack_38 - fStack_a8;
        uStack_54._4_4_ =
             (pfVar3[1] * fVar12 + *pfVar3 * fVar10 + pfVar3[2] * fStack_18 + pfVar3[3]) -
             DAT_018ce324;
        uStack_2c._4_4_ = fVar11 + uStack_54._4_4_;
        fStack_ac = (float)uStack_64 - fStack_ac;
        uStack_54._4_4_ = uStack_54._4_4_ - fVar11;
        uStack_90 = CONCAT44(fStack_a8,fStack_ac);
        fStack_84 = fStack_a0;
        fStack_80 = fVar9;
        fStack_88 = uStack_54._4_4_;
        fStack_7c = uStack_2c._4_4_;
        fStack_a4 = uStack_54._4_4_;
        puVar6 = (undefined4 *)in_stack_00000018[1];
        uStack_9c = CONCAT44(uStack_2c._4_4_,fVar9);
        auStack_ec[0] = uStack_14c;
        auStack_ec[1] = uStack_148;
        auStack_ec[2] = uStack_144;
        auStack_ec[3] = uStack_140;
        uStack_dc = uStack_13c;
        uStack_d8 = uStack_138;
        uStack_d4 = uStack_134;
        uStack_d0 = uStack_130;
        uStack_cc = uStack_12c;
        uStack_c8 = uStack_128;
        uStack_c4 = uStack_124;
        uStack_c0 = uStack_120;
        uStack_bc = uStack_11c;
        uStack_b8 = uStack_118;
        uStack_b4 = uStack_114;
        uStack_b0 = uStack_110;
        if ((undefined4 *)in_stack_00000018[2] == puVar6) {
          FUN_0083b680(puVar6,auStack_ec);
        }
        else {
          puVar5 = auStack_ec;
          for (iVar4 = 0x17; iVar4 != 0; iVar4 = iVar4 + -1) {
            *puVar6 = *puVar5;
            puVar5 = puVar5 + 1;
            puVar6 = puVar6 + 1;
          }
          in_stack_00000018[1] = in_stack_00000018[1] + 0x5c;
          fVar7 = fStack_1c;
        }
        fStack_1c = (float)((int)fVar7 + 1);
        pfStack_24 = pfStack_24 + 1;
      } while (fStack_1c != fStack_44);
    }
  }
  else {
    if (*(int *)((int)fStack_20 + 0x34) < DAT_01eb44d8) {
      uStack_8._0_1_ = uVar1;
      FUN_016f3809(&DAT_01eb44d8);
      if (DAT_01eb44d8 == -1) {
        uStack_8._0_1_ = 5;
        uVar13 = FUN_0152dab0("ShadowMap","Precise culling",0xffffffff);
        DAT_01eb44d4 = (float)((ulonglong)uVar13 >> 0x20);
        DAT_01eb44d0 = (float)uVar13;
        uStack_8._0_1_ = 1;
        FUN_016f37bf(&DAT_01eb44d8);
      }
    }
    fStack_40 = DAT_01eb44d0;
    fStack_5c = DAT_01eb44d0;
    fStack_3c = DAT_01eb44d4;
    fStack_58 = DAT_01eb44d4;
    uStack_54 = FUN_0152d930(DAT_01eb44d0,DAT_01eb44d4);
    uStack_8._0_1_ = 6;
    FUN_01165e00(&uStack_14c);
    uStack_2c._4_4_ = 1.0;
    fStack_34 = *(float *)(param_2 + 0x18);
    pfStack_30 = *(float **)(param_2 + 0x1c);
    uStack_2c._0_4_ = *(undefined4 *)(param_2 + 0x20);
    FUN_01165b90(&fStack_88,&fStack_34);
    FUN_011658d0(auStack_68);
    if (3 < (uint)((*(int **)(param_2 + 0x25c))[1] - **(int **)(param_2 + 0x25c))) {
      if (*(int *)((int)fVar9 + 0x34) < DAT_01eb44e8) {
        FUN_016f3809(&DAT_01eb44e8);
        if (DAT_01eb44e8 == -1) {
          uStack_8._0_1_ = 7;
          uVar13 = FUN_0152dab0("ShadowMap","Perform culling",0xffffffff);
          DAT_01eb44e4 = (float *)((ulonglong)uVar13 >> 0x20);
          DAT_01eb44e0 = (float)uVar13;
          uStack_8._0_1_ = 6;
          FUN_016f37bf(&DAT_01eb44e8);
        }
      }
      fStack_38 = DAT_01eb44e0;
      fStack_34 = DAT_01eb44e0;
      pfStack_24 = DAT_01eb44e4;
      pfStack_30 = DAT_01eb44e4;
      uStack_2c = FUN_0152d930(DAT_01eb44e0,DAT_01eb44e4);
      pfStack_14 = (float *)0x0;
      uStack_8._0_1_ = 8;
      fStack_18 = 0.0;
      pfVar3 = (float *)*in_stack_0000001c;
      fStack_1c = (float)(((int)in_stack_0000001c[1] - (int)pfVar3) + 3U >> 2);
      if ((float *)in_stack_0000001c[1] < pfVar3) {
        fStack_1c = 0.0;
      }
      if (fStack_1c != 0.0) {
        do {
          fVar9 = *pfVar3;
          FUN_01165ab0();
          uStack_9c = 0xff7fffffff7fffff;
          fStack_ac = _DAT_018c4eb0;
          fStack_a8 = _UNK_018c4eb4;
          fStack_a4 = _UNK_018c4eb8;
          fStack_a0 = _UNK_018c4ebc;
          fStack_94 = fVar9;
          FUN_0083d450(param_1 + 0x1c,&uStack_14c,(int)fVar9 + 0x18,0x44fa0000,&fStack_ac,auStack_ec
                      );
          fVar8 = (float10)FUN_00c9ed90(auStack_68);
          pfStack_14 = (float *)(float)fVar8;
          if ((float)pfStack_14 <= *(float *)(param_2 + 0xc) * *(float *)(param_2 + 0xc)) {
            cVar2 = FUN_007ccfb0(&fStack_ac,auStack_ec);
            if (cVar2 != '\0') {
              puVar6 = (undefined4 *)in_stack_00000018[1];
              if ((undefined4 *)in_stack_00000018[2] == puVar6) {
                FUN_0083b680(puVar6,auStack_ec);
              }
              else {
                puVar5 = auStack_ec;
                for (iVar4 = 0x17; iVar4 != 0; iVar4 = iVar4 + -1) {
                  *puVar6 = *puVar5;
                  puVar5 = puVar5 + 1;
                  puVar6 = puVar6 + 1;
                }
                in_stack_00000018[1] = in_stack_00000018[1] + 0x5c;
              }
            }
          }
          fStack_18 = (float)((int)fStack_18 + 1);
          pfVar3 = pfVar3 + 1;
          fVar9 = fStack_20;
        } while (fStack_18 != fStack_1c);
      }
      if (*(int *)((int)fVar9 + 0x34) < DAT_01eb44f8) {
        FUN_016f3809(&DAT_01eb44f8);
        if (DAT_01eb44f8 == -1) {
          uStack_8._0_1_ = 9;
          uVar13 = FUN_0152da50("ShadowMap");
          DAT_01eb44f4 = (undefined4)((ulonglong)uVar13 >> 0x20);
          DAT_01eb44f0 = (undefined4)uVar13;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb44f8);
        }
      }
      FUN_0152d760(DAT_01eb44f0,DAT_01eb44f4,"Objects before: %d",
                   (int)in_stack_0000001c[1] - (int)*in_stack_0000001c >> 2);
      if (*(int *)((int)fVar9 + 0x34) < DAT_01eb4508) {
        FUN_016f3809(&DAT_01eb4508);
        if (DAT_01eb4508 == -1) {
          uStack_8._0_1_ = 10;
          uVar13 = FUN_0152da50("ShadowMap");
          DAT_01eb4504 = (undefined4)((ulonglong)uVar13 >> 0x20);
          DAT_01eb4500 = (undefined4)uVar13;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb4508);
        }
      }
      FUN_0152d760(DAT_01eb4500,DAT_01eb4504,"Objects after: %d",
                   (in_stack_00000018[1] - *in_stack_00000018) / 0x5c);
      uStack_8._0_1_ = 0xb;
      FUN_0152dda0(fStack_38,pfStack_24,uStack_2c);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    FUN_0152dda0(fStack_40,fStack_3c,uStack_54);
  }
  in_stack_0000001c[1] = *in_stack_0000001c;
  uStack_8 = 0xd;
  FUN_0152dda0(uStack_4c,uStack_48,uStack_70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12823 ; VA 0x0083e0d0 ; FUN_0083e0d0 */

void FUN_0083e0d0(undefined4 param_1,float *param_2,int *param_3,int param_4,char param_5)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  float10 fVar6;
  undefined4 auStack_90 [25];
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  
  uStack_1c = 0;
  iStack_18 = *param_3;
  iVar1 = param_3[1] - iStack_18 >> 0x1f;
  if ((param_3[1] - iStack_18) / 0x5c + iVar1 != iVar1) {
    iStack_14 = 0;
    do {
      puVar4 = (undefined4 *)(iStack_14 + 0x58 + iStack_18);
      iVar1 = FUN_007ccae0(*(int *)(iStack_14 + 0x58 + iStack_18) + 0x18);
      if (iVar1 != 0) {
        if (param_5 == '\0') {
          puVar3 = *(undefined4 **)(param_4 + 4);
          if (*(undefined4 **)(param_4 + 8) == puVar3) {
LAB_0083e2a1:
            FUN_0083b870(puVar3,puVar4);
          }
          else {
            *puVar3 = *puVar4;
            puVar3[1] = 0xffffffff;
            *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 8;
          }
        }
        else {
          iVar5 = 0;
          iVar1 = 0;
          fStack_20 = (float)(iStack_14 + 0x40 + iStack_18);
          do {
            FUN_00c9f1c0(&fStack_2c,iVar1);
            if (param_2[3] <=
                (param_2[1] - fStack_28) * (param_2[1] - fStack_28) +
                (*param_2 - fStack_2c) * (*param_2 - fStack_2c) +
                (param_2[2] - fStack_24) * (param_2[2] - fStack_24)) break;
            iVar1 = iVar1 + 1;
            iVar5 = iVar5 + 1;
          } while (iVar1 < 8);
          if (iVar5 == 8) {
            puVar4 = *(undefined4 **)(param_4 + 4);
            if (*(undefined4 **)(param_4 + 8) == puVar4) {
              FUN_0083b870(puVar4,iStack_14 + 0x58 + iStack_18);
            }
            else {
              *puVar4 = *(undefined4 *)(iStack_18 + 0x58 + iStack_14);
              puVar4[1] = 0xffffffff;
              *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 8;
            }
            iVar1 = param_3[1];
            uVar2 = (iVar1 - *param_3) / 0x5c - 1;
            if (uStack_1c != uVar2) {
              puVar4 = (undefined4 *)(uVar2 * 0x5c + *param_3);
              puVar3 = auStack_90;
              for (iVar1 = 0x17; iVar1 != 0; iVar1 = iVar1 + -1) {
                *puVar3 = *puVar4;
                puVar4 = puVar4 + 1;
                puVar3 = puVar3 + 1;
              }
              puVar4 = auStack_90;
              puVar3 = (undefined4 *)(iStack_14 + *param_3);
              for (iVar1 = 0x17; iVar1 != 0; iVar1 = iVar1 + -1) {
                *puVar3 = *puVar4;
                puVar4 = puVar4 + 1;
                puVar3 = puVar3 + 1;
              }
              iVar1 = param_3[1];
            }
            uStack_1c = uStack_1c - 1;
            param_3[1] = iVar1 + -0x5c;
            iStack_14 = iStack_14 + -0x5c;
          }
          else {
            fVar6 = (float10)FUN_00c9ed90(param_2);
            fStack_20 = (float)fVar6;
            if (fStack_20 < param_2[3] || fStack_20 == param_2[3]) {
              puVar3 = *(undefined4 **)(param_4 + 4);
              if (*(undefined4 **)(param_4 + 8) == puVar3) {
                puVar4 = (undefined4 *)(iStack_14 + 0x58 + iStack_18);
                goto LAB_0083e2a1;
              }
              *puVar3 = *(undefined4 *)(iStack_18 + 0x58 + iStack_14);
              puVar3[1] = 0xffffffff;
              *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 8;
            }
          }
        }
      }
      iStack_14 = iStack_14 + 0x5c;
      uStack_1c = uStack_1c + 1;
      iStack_18 = *param_3;
    } while (uStack_1c < (uint)((param_3[1] - iStack_18) / 0x5c));
  }
  return;
}



/* FUNCTION 12824 ; VA 0x0083e2f0 ; FUN_0083e2f0 */

int __thiscall FUN_0083e2f0(int param_1,int param_2,int param_3)

{
  return param_3 * 0x278 + 0xa020 + param_2 * 0x13c50 + param_1;
}



/* FUNCTION 12825 ; VA 0x0083e310 ; FUN_0083e310 */

byte FUN_0083e310(int param_1)

{
  return -(param_1 != 0) & 0x40;
}



/* FUNCTION 12826 ; VA 0x0083e330 ; FUN_0083e330 */

undefined4 FUN_0083e330(undefined4 param_1,float param_2,float param_3,float param_4,float param_5)

{
  float fVar1;
  
  fVar1 = DAT_018ce2f8 / (param_5 - param_4);
  FUN_01165a00(DAT_018ce2f8 / param_2,0,0,0,0,DAT_018ce2f8 / param_3,0,0,0,0,fVar1,
               (uint)(fVar1 * param_4) ^ DAT_018c4ea0,0,0,0,0x3f800000);
  return param_1;
}



/* FUNCTION 12827 ; VA 0x0083e3f0 ; FUN_0083e3f0 */

undefined8 __thiscall FUN_0083e3f0(int param_1,uint param_2,uint param_3,int param_4,float param_5)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_c;
  uint uStack_8;
  
  if ((param_3 + 7 < 0xf) && (param_4 + 7U < 0xf)) {
    uStack_1c = 0;
    uStack_20 = 0;
    param_1 = param_2 * 0x13c50 + 0x208 + param_1;
    uStack_8 = 0;
    uStack_18 = 0;
    uStack_c = 0;
    do {
      uVar1 = uStack_18 + param_4;
      param_2 = 0;
      uVar8 = param_3;
      do {
        if ((((-1 < (int)uVar8) && (uVar8 < 8)) && (-1 < (int)uVar1)) && (uVar1 < 8)) {
          uVar6 = uVar8 + uVar1 * 8;
          uVar2 = param_2 + uStack_18 * 8;
          iVar4 = uVar2 * 0x278;
          uVar7 = 1 << (uVar6 & 0x1f);
          uVar5 = 0;
          if (0x1f < uVar6) {
            uVar5 = uVar7;
          }
          uVar7 = uVar7 ^ uVar5;
          if (0x3f < uVar6) {
            uVar5 = uVar7;
          }
          uStack_1c = uStack_8;
          uStack_20 = uStack_c;
          if ((((*(int *)(iVar4 + 0x9e18 + param_1) == 1) &&
               (*(int *)(uVar6 * 0x278 + 0x18 + param_1) != 0)) &&
              (((float)(double)CONCAT44((uint)((ulonglong)(double)param_5 >> 0x20) &
                                        DAT_018c0da0._4_4_,
                                        SUB84((double)param_5,0) & (uint)DAT_018c0da0) <=
                DAT_018f76ac ||
               ((uVar7 & *(uint *)(param_1 + 0x13c20)) == 0 &&
                (uVar5 & *(uint *)(param_1 + 0x13c24)) == 0)))) &&
             (cVar3 = FUN_00839e70(iVar4 + 0xa06c + param_1), cVar3 != '\0')) {
            *(undefined4 *)(iVar4 + 0x9e18 + param_1) = 2;
            uVar6 = 1 << (uVar2 & 0x1f);
            uVar7 = 0;
            if (0x1f < uVar2) {
              uVar7 = uVar6;
            }
            uVar6 = uVar6 ^ uVar7;
            if (0x3f < uVar2) {
              uVar7 = uVar6;
            }
            uStack_c = uStack_c | uVar6;
            uStack_8 = uStack_8 | uVar7;
            uStack_1c = uStack_8;
            uStack_20 = uStack_c;
          }
        }
        param_2 = param_2 + 1;
        uVar8 = uVar8 + 1;
      } while (param_2 < 8);
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < 8);
    return CONCAT44(uStack_1c,uStack_20);
  }
  return 0;
}



/* FUNCTION 12828 ; VA 0x0083e5b0 ; FUN_0083e5b0 */

float * FUN_0083e5b0(float *param_1,int param_2,float *param_3)

{
  uint uVar1;
  float10 fVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  double dVar9;
  double dVar10;
  double dVar11;
  double dVar12;
  double dVar13;
  double dVar14;
  double adStack_260 [36];
  double dStack_140;
  float fStack_118;
  float fStack_114;
  float fStack_110;
  float fStack_108;
  float fStack_104;
  float fStack_100;
  undefined8 uStack_f8;
  double dStack_f0;
  double dStack_e8;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  double dStack_7c;
  double dStack_74;
  double dStack_6c;
  double dStack_64;
  double dStack_5c;
  double dStack_54;
  double dStack_4c;
  double dStack_24;
  double dStack_1c;
  double dStack_14;
  double dStack_c;
  
  adStack_260[0x20] = 0.0;
  uStack_c8 = 0;
  uStack_c4 = 0;
  FUN_0083ccd0(&fStack_118,&uStack_c8,param_2 + 0x4f354);
  dStack_1c = (double)param_3[1];
  dStack_54 = (double)*param_3;
  dStack_24 = (double)param_3[2];
  dStack_14 = (double)param_3[3] * DAT_018dbcc8;
  dStack_5c = ((double)fStack_114 * dStack_1c + (double)fStack_118 * dStack_54 +
              (double)fStack_110 * dStack_24) / dStack_14;
  fVar2 = (float10)FUN_01725280(dStack_5c);
  dStack_c = (double)fVar2;
  adStack_260[0] = dStack_c * dStack_14;
  dStack_74 = ((double)fStack_104 * dStack_1c + (double)fStack_108 * dStack_54 +
              (double)fStack_100 * dStack_24) / dStack_14;
  dStack_6c = adStack_260[0];
  fVar2 = (float10)FUN_01725280(dStack_74);
  dStack_c = (double)fVar2;
  adStack_260[1] = dStack_c * dStack_14;
  dStack_7c = ((double)uStack_f8._4_4_ * dStack_1c + (double)(float)uStack_f8 * dStack_54 +
              (double)dStack_f0._0_4_ * dStack_24) / dStack_14;
  dStack_64 = adStack_260[1];
  fVar2 = (float10)FUN_01725280(dStack_7c);
  dStack_c = (double)fVar2;
  adStack_260[2] = dStack_c * dStack_14;
  dStack_4c = adStack_260[2];
  fVar2 = (float10)FUN_01725160(dStack_5c);
  dStack_c = (double)fVar2;
  adStack_260[4] = dStack_c * dStack_14;
  adStack_260[8] = dStack_6c;
  adStack_260[5] = dStack_64;
  adStack_260[6] = dStack_4c;
  dStack_5c = adStack_260[4];
  fVar2 = (float10)FUN_01725160(dStack_74);
  dStack_c = (double)fVar2;
  adStack_260[9] = dStack_c * dStack_14;
  adStack_260[10] = dStack_4c;
  adStack_260[0x10] = dStack_6c;
  adStack_260[0xc] = dStack_5c;
  adStack_260[0xe] = dStack_4c;
  adStack_260[0x11] = dStack_64;
  adStack_260[0xd] = adStack_260[9];
  dStack_74 = adStack_260[9];
  fVar2 = (float10)FUN_01725160(dStack_7c);
  dStack_c = (double)fVar2;
  adStack_260[0x12] = dStack_c * dStack_14;
  adStack_260[0x15] = dStack_64;
  adStack_260[0x18] = dStack_6c;
  adStack_260[0x14] = dStack_5c;
  adStack_260[0x19] = dStack_74;
  adStack_260[0x1c] = dStack_5c;
  adStack_260[0x1d] = dStack_74;
  adStack_260[0x16] = adStack_260[0x12];
  adStack_260[0x1a] = adStack_260[0x12];
  adStack_260[0x1e] = adStack_260[0x12];
  dStack_140 = adStack_260[0x12];
  FUN_01165e00();
  dVar3 = (double)fStack_a4;
  dVar11 = dStack_6c * (double)fStack_bc + dStack_64 * (double)fStack_b8;
  dVar8 = dStack_4c * (double)fStack_b4;
  uStack_f8 = dVar11 + dVar8;
  dVar4 = dStack_6c * (double)fStack_ac + dStack_64 * (double)fStack_a8;
  dStack_f0 = dVar3 * dStack_4c + dVar4;
  dStack_e8 = dStack_64 * (double)fStack_98 + dStack_6c * (double)fStack_9c +
              dStack_4c * (double)fStack_94;
  dVar13 = uStack_f8 - dStack_54;
  dVar9 = dStack_f0 - dStack_1c;
  dVar5 = dStack_e8 - dStack_24;
  dVar14 = dVar13 * dVar13 + dVar9 * dVar9 + dVar5 * dVar5;
  dVar5 = dStack_5c * (double)fStack_bc + dStack_64 * (double)fStack_b8 + dVar8;
  dVar12 = dStack_4c * (double)fStack_a4;
  adStack_260[0x21] = dStack_64 * (double)fStack_98;
  dVar6 = dStack_5c * (double)fStack_ac + dStack_64 * (double)fStack_a8 + dVar12;
  dVar7 = dVar6 - dStack_1c;
  dStack_4c = dStack_4c * (double)fStack_94;
  dVar9 = dStack_5c * (double)fStack_9c + adStack_260[0x21] + dStack_4c;
  dVar10 = dVar5 - dStack_54;
  dVar13 = dVar9 - dStack_24;
  dVar13 = dVar10 * dVar10 + dVar7 * dVar7 + dVar13 * dVar13;
  dStack_14 = dVar14;
  if (dVar13 < dVar14) {
    uStack_f8 = dVar5;
    dStack_f0 = dVar6;
    dStack_e8 = dVar9;
    dStack_14 = dVar13;
  }
  uVar1 = (uint)(dVar13 < dVar14);
  dVar7 = dStack_74 * (double)fStack_b8 + dStack_6c * (double)fStack_bc + dVar8;
  dVar10 = dVar7 - dStack_54;
  dVar13 = dStack_74 * (double)fStack_a8 + dStack_6c * (double)fStack_ac + dVar12;
  dVar6 = dVar13 - dStack_1c;
  dVar5 = dStack_6c * (double)fStack_9c + dStack_74 * (double)fStack_98 + dStack_4c;
  dVar9 = dVar5 - dStack_24;
  dVar9 = dVar10 * dVar10 + dVar6 * dVar6 + dVar9 * dVar9;
  if (dVar9 < dStack_14) {
    uVar1 = 2;
    uStack_f8 = dVar7;
    dStack_f0 = dVar13;
    dStack_e8 = dVar5;
    dStack_14 = dVar9;
  }
  dVar8 = dStack_74 * (double)fStack_b8 + dStack_5c * (double)fStack_bc + dVar8;
  dVar12 = dStack_74 * (double)fStack_a8 + dStack_5c * (double)fStack_ac + dVar12;
  dStack_4c = dStack_74 * (double)fStack_98 + dStack_5c * (double)fStack_9c + dStack_4c;
  dVar13 = dVar8 - dStack_54;
  dVar5 = dVar12 - dStack_1c;
  dVar9 = dStack_4c - dStack_24;
  dVar5 = dVar13 * dVar13 + dVar5 * dVar5 + dVar9 * dVar9;
  if (dVar5 < dStack_14) {
    uVar1 = 3;
    uStack_f8 = dVar8;
    dStack_f0 = dVar12;
    dStack_e8 = dStack_4c;
    dStack_14 = dVar5;
  }
  dVar11 = dStack_140 * (double)fStack_b4 + dVar11;
  dVar4 = dStack_140 * (double)fStack_a4 + dVar4;
  dVar9 = dVar11 - dStack_54;
  dVar5 = dVar4 - dStack_1c;
  dVar13 = dStack_6c * (double)fStack_9c + adStack_260[0x21] + dStack_140 * (double)fStack_94;
  dVar12 = dVar13 - dStack_24;
  dVar5 = dVar9 * dVar9 + dVar5 * dVar5 + dVar12 * dVar12;
  if (dVar5 < dStack_14) {
    uVar1 = 4;
    dStack_14 = dVar5;
    uStack_f8 = dVar11;
    dStack_f0 = dVar4;
    dStack_e8 = dVar13;
  }
  dVar13 = dStack_64 * (double)fStack_b8 + (double)fStack_bc * dStack_5c +
           dStack_140 * (double)fStack_b4;
  dVar12 = dVar13 - dStack_54;
  dVar5 = dStack_64 * (double)fStack_a8 + (double)fStack_ac * dStack_5c + dStack_140 * dVar3;
  dVar9 = dVar5 - dStack_1c;
  dVar4 = dStack_64 * (double)fStack_98 + (double)fStack_9c * dStack_5c +
          dStack_140 * (double)fStack_94;
  dVar6 = dVar4 - dStack_24;
  dVar9 = dVar12 * dVar12 + dVar9 * dVar9 + dVar6 * dVar6;
  if (dVar9 < dStack_14) {
    uVar1 = 5;
    dStack_14 = dVar9;
    uStack_f8 = dVar13;
    dStack_f0 = dVar5;
    dStack_e8 = dVar4;
  }
  dVar4 = dStack_6c * (double)fStack_bc + dStack_74 * (double)fStack_b8 +
          dStack_140 * (double)fStack_b4;
  dVar13 = dStack_6c * (double)fStack_ac + dStack_74 * (double)fStack_a8 +
           dStack_140 * (double)fStack_a4;
  dVar12 = dVar13 - dStack_1c;
  dVar6 = dVar4 - dStack_54;
  dVar5 = dStack_74 * (double)fStack_98 + dStack_6c * (double)fStack_9c +
          dStack_140 * (double)fStack_94;
  dVar9 = dVar5 - dStack_24;
  dVar9 = dVar6 * dVar6 + dVar12 * dVar12 + dVar9 * dVar9;
  if (dVar9 < dStack_14) {
    uVar1 = 6;
    dStack_14 = dVar9;
    uStack_f8 = dVar4;
    dStack_f0 = dVar13;
    dStack_e8 = dVar5;
  }
  dVar5 = dStack_5c * (double)fStack_bc + dStack_74 * (double)fStack_b8 +
          dStack_140 * (double)fStack_b4;
  dStack_54 = dVar5 - dStack_54;
  dVar3 = dStack_5c * (double)fStack_ac + dStack_74 * (double)fStack_a8 + dStack_140 * dVar3;
  dStack_1c = dVar3 - dStack_1c;
  dVar9 = dStack_74 * (double)fStack_98 + dStack_5c * (double)fStack_9c +
          dStack_140 * (double)fStack_94;
  dStack_24 = dVar9 - dStack_24;
  if (dStack_54 * dStack_54 + dStack_1c * dStack_1c + dStack_24 * dStack_24 < dStack_14) {
    uVar1 = 7;
    uStack_f8 = dVar5;
    dStack_f0 = dVar3;
    dStack_e8 = dVar9;
  }
  param_1[3] = 0.0;
  param_1[5] = 0.0;
  param_1[6] = 0.0;
  *(ulonglong *)(param_1 + 4) = CONCAT44(SUB84(adStack_260[0x20],0),SUB84(adStack_260[0x20],0));
  param_1[6] = 0.0;
  param_1[7] = 0.0;
  *param_1 = (float)uStack_f8;
  param_1[1] = (float)dStack_f0;
  param_1[2] = (float)dStack_e8;
  dVar3 = adStack_260[uVar1 * 4];
  param_1[3] = param_3[3];
  param_1[4] = (float)dVar3;
  param_1[5] = (float)adStack_260[uVar1 * 4 + 1];
  param_1[6] = (float)adStack_260[uVar1 * 4 + 2];
  param_1[7] = param_3[3];
  param_1[8] = param_3[8];
  return param_1;
}



/* FUNCTION 12829 ; VA 0x0083f1a0 ; FUN_0083f1a0 */

void __thiscall FUN_0083f1a0(undefined8 *param_1,float *param_2,float param_3)

{
  float *pfVar1;
  int iVar2;
  float fVar3;
  double dVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  ulonglong auStack_60 [2];
  undefined8 *puStack_4c;
  ulonglong uStack_48;
  float fStack_40;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  
  *param_1 = *(undefined8 *)param_2;
  *(float *)(param_1 + 1) = param_2[2];
  *(float *)((int)param_1 + 0xc) = param_3;
  *(undefined4 *)(param_1 + 0xb) = 0x7f7fffff;
  fStack_40 = param_2[6] * param_3 + param_2[2];
  param_1[2] = CONCAT44(param_2[5] * param_3 + param_2[1],param_2[4] * param_3 + *param_2);
  *(float *)(param_1 + 3) = fStack_40;
  fVar3 = *(float *)((int)param_1 + 0x14);
  if (*(float *)(param_1 + 0xb) <= *(float *)((int)param_1 + 0x14)) {
    fVar3 = *(float *)(param_1 + 0xb);
  }
  *(float *)(param_1 + 0xb) = fVar3;
  fVar3 = param_2[2];
  *(undefined8 *)((int)param_1 + 0x1c) = *(undefined8 *)param_2;
  *(float *)((int)param_1 + 0x24) = fVar3;
  fVar3 = *(float *)(param_1 + 4);
  if (*(float *)(param_1 + 0xb) <= *(float *)(param_1 + 4)) {
    fVar3 = *(float *)(param_1 + 0xb);
  }
  *(float *)(param_1 + 0xb) = fVar3;
  iVar2 = 4;
  puStack_4c = param_1;
  do {
    FUN_00569440();
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  FUN_007ccaa0(1);
  pfVar1 = (float *)FUN_011658d0(&uStack_48);
  fVar3 = pfVar1[1] - param_2[1];
  fVar6 = *pfVar1 - *param_2;
  fVar5 = pfVar1[2] - param_2[2];
  auStack_60[0] = (ulonglong)(uint)fVar6;
  dVar4 = (double)(fVar3 * fVar3 + fVar6 * fVar6 + fVar5 * fVar5);
  FUN_017267a0();
  fStack_40 = DAT_018ce2f8 / (float)dVar4;
  fStack_38 = (float)auStack_60[0] * fStack_40;
  fStack_34 = fVar3 * fStack_40;
  fStack_40 = fVar5 * fStack_40;
  fStack_30 = fStack_40;
  FUN_007ccaa0(3);
  pfVar1 = (float *)FUN_011658d0(&uStack_48);
  fVar3 = pfVar1[1] - param_2[1];
  fVar6 = *pfVar1 - *param_2;
  fVar5 = pfVar1[2] - param_2[2];
  auStack_60[0] = (ulonglong)(uint)fVar6;
  dVar4 = (double)(fVar3 * fVar3 + fVar6 * fVar6 + fVar5 * fVar5);
  FUN_017267a0();
  fStack_40 = DAT_018ce2f8 / (float)dVar4;
  fStack_2c = (float)auStack_60[0] * fStack_40;
  fStack_28 = fVar3 * fStack_40;
  fStack_40 = fVar5 * fStack_40;
  fStack_24 = fStack_40;
  FUN_007ccaa0(5);
  pfVar1 = (float *)FUN_011658d0(&uStack_48);
  fVar3 = pfVar1[1] - param_2[1];
  fVar6 = *pfVar1 - *param_2;
  fVar5 = pfVar1[2] - param_2[2];
  auStack_60[0] = (ulonglong)(uint)fVar6;
  dVar4 = (double)(fVar3 * fVar3 + fVar6 * fVar6 + fVar5 * fVar5);
  FUN_017267a0();
  fStack_40 = DAT_018ce2f8 / (float)dVar4;
  fStack_20 = (float)auStack_60[0] * fStack_40;
  fStack_1c = fVar3 * fStack_40;
  fStack_40 = fVar5 * fStack_40;
  fStack_18 = fStack_40;
  FUN_007ccaa0(7);
  pfVar1 = (float *)FUN_011658d0(auStack_60);
  uStack_48 = (ulonglong)(uint)*param_2;
  fVar7 = *pfVar1 - *param_2;
  fVar5 = pfVar1[1] - param_2[1];
  fVar3 = pfVar1[2] - param_2[2];
  auStack_60[0] = CONCAT44(auStack_60[0]._4_4_,fVar3);
  dVar4 = (double)(fVar5 * fVar5 + fVar7 * fVar7 + fVar3 * fVar3);
  FUN_017267a0();
  fVar6 = DAT_018ce2f8 / (float)dVar4;
  fVar3 = param_2[2];
  puStack_4c[5] = CONCAT44(param_2[1] + fStack_34 * param_3,(float)uStack_48 + fStack_38 * param_3);
  *(float *)(puStack_4c + 6) = fVar3 + fStack_30 * param_3;
  fVar3 = *(float *)((int)puStack_4c + 0x2c);
  if (*(float *)(puStack_4c + 0xb) <= *(float *)((int)puStack_4c + 0x2c)) {
    fVar3 = *(float *)(puStack_4c + 0xb);
  }
  *(float *)(puStack_4c + 0xb) = fVar3;
  fVar3 = param_2[2];
  *(ulonglong *)((int)puStack_4c + 0x34) =
       CONCAT44(fStack_28 * param_3 + param_2[1],fStack_2c * param_3 + *param_2);
  *(float *)((int)puStack_4c + 0x3c) = fStack_24 * param_3 + fVar3;
  fVar3 = *(float *)(puStack_4c + 7);
  if (*(float *)(puStack_4c + 0xb) <= *(float *)(puStack_4c + 7)) {
    fVar3 = *(float *)(puStack_4c + 0xb);
  }
  *(float *)(puStack_4c + 0xb) = fVar3;
  fVar3 = param_2[2];
  puStack_4c[8] = CONCAT44(fStack_1c * param_3 + param_2[1],fStack_20 * param_3 + *param_2);
  *(float *)(puStack_4c + 9) = fStack_18 * param_3 + fVar3;
  fVar3 = *(float *)((int)puStack_4c + 0x44);
  if (*(float *)(puStack_4c + 0xb) <= *(float *)((int)puStack_4c + 0x44)) {
    fVar3 = *(float *)(puStack_4c + 0xb);
  }
  *(float *)(puStack_4c + 0xb) = fVar3;
  fVar3 = param_2[2];
  *(ulonglong *)((int)puStack_4c + 0x4c) =
       CONCAT44(fVar5 * fVar6 * param_3 + param_2[1],param_3 * fVar7 * fVar6 + *param_2);
  *(float *)((int)puStack_4c + 0x54) = (float)auStack_60[0] * fVar6 * param_3 + fVar3;
  if (*(float *)(puStack_4c + 10) < *(float *)(puStack_4c + 0xb)) {
    *(float *)(puStack_4c + 0xb) = *(float *)(puStack_4c + 10);
    return;
  }
  *(float *)(puStack_4c + 0xb) = *(float *)(puStack_4c + 0xb);
  return;
}



/* FUNCTION 12830 ; VA 0x0083f6a0 ; FUN_0083f6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0083f6a0(int param_1,undefined8 *param_2,int param_3)

{
  float fVar1;
  undefined8 uVar3;
  bool bVar4;
  float fVar5;
  double dVar6;
  float fVar7;
  float fStack_10;
  float fStack_c;
  float fVar2;
  
  if (*(int *)(param_1 + 0x1d0) != param_3) {
    fVar5 = DAT_018fe4b0;
    if (*(float *)(param_2 + 2) <= DAT_018fe4b0) {
      fVar5 = *(float *)(param_2 + 2);
    }
    fVar1 = *(float *)(param_1 + 0x4f360);
    fVar2 = *(float *)(param_1 + 0x4f360);
    *(float *)(param_1 + 0x4f360) = fVar5;
    uVar3 = *param_2;
    fVar7 = *(float *)(param_2 + 1);
    fStack_10 = (float)uVar3;
    fStack_c = (float)((ulonglong)uVar3 >> 0x20);
    bVar4 = *(float *)(param_1 + 0x4f358) * fStack_c + *(float *)(param_1 + 0x4f354) * fStack_10 +
            *(float *)(param_1 + 0x4f35c) * fVar7 < DAT_01919484;
    if (bVar4) {
      *(undefined8 *)(param_1 + 0x4f354) = uVar3;
      *(float *)(param_1 + 0x4f35c) = fVar7;
    }
    fVar7 = *(float *)((int)param_2 + 0xc);
    dVar6 = (double)(*(float *)(param_1 + 0x1e0) - fVar7);
    if (DAT_018f784c <
        (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & DAT_018c0da0._4_4_,
                                SUB84(dVar6,0) & (uint)DAT_018c0da0)) {
      *(float *)(param_1 + 0x1e0) = fVar7;
      fVar7 = fVar7 * _DAT_01919488;
      *(undefined *)(param_1 + 0x1d8) = 1;
      *(int *)(param_1 + 0x1d0) = param_3;
      *(float *)(param_1 + 500) = fVar7 + DAT_018fde58;
      return;
    }
    if (bVar4 || fVar2 <= fVar5 && fVar5 != fVar1) {
      *(undefined *)(param_1 + 0x1d8) = 1;
      *(int *)(param_1 + 0x1d0) = param_3;
    }
  }
  return;
}



/* FUNCTION 12831 ; VA 0x0083f7d0 ; FUN_0083f7d0 */

bool __thiscall
FUN_0083f7d0(int param_1,undefined4 param_2,int param_3,uint param_4,uint param_5,int *param_6)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar3 = param_3 * 0x278 + *(int *)(param_1 + 0x14);
  uVar5 = *(uint *)(iVar3 + 0x264);
  uVar2 = *(uint *)(iVar3 + 0x268);
  if (uVar2 == uVar5) {
    *param_6 = 0;
    return false;
  }
  cVar1 = *(char *)(param_1 + 0x4f364);
  iVar4 = 0;
  param_3 = 0;
  iVar6 = 0;
  for (; uVar5 < uVar2; uVar5 = uVar5 + 1) {
    if (((*(uint *)(*(int *)(param_1 + 0x4f348) + 4 + uVar5 * 8) & ~param_5) == 0) &&
       ((*(uint *)(*(int *)(param_1 + 0x4f348) + uVar5 * 8) & ~param_4) == 0)) {
      iVar6 = iVar6 + 1;
    }
    else {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x20) + uVar5 * 4) + 4))
                (param_2,iVar3 + 0xc,(cVar1 == '\0') + '\x04');
      iVar4 = param_3 + 1;
      param_3 = iVar4;
    }
  }
  *param_6 = iVar6;
  return iVar4 != 0;
}



/* FUNCTION 12832 ; VA 0x0083f8a0 ; FUN_0083f8a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0083f8a0(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  uint *puVar3;
  float fVar4;
  float fVar5;
  bool bVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int *piVar10;
  char cVar11;
  char cVar12;
  undefined4 *puVar13;
  float *pfVar14;
  undefined8 *puVar15;
  int extraout_ECX;
  int iVar16;
  int iVar17;
  bool bVar18;
  float *pfVar19;
  uint uVar20;
  undefined4 *puVar21;
  float *pfVar22;
  float10 fVar23;
  float fVar24;
  float fVar25;
  double dVar26;
  uint uVar27;
  uint uVar28;
  undefined8 uVar29;
  float afStack_1608 [146];
  undefined auStack_13c0 [296];
  undefined auStack_1298 [48];
  undefined auStack_1268 [584];
  undefined4 auStack_1020 [146];
  undefined auStack_dd8 [48];
  undefined4 auStack_da8 [146];
  undefined auStack_b60 [144];
  undefined auStack_ad0 [152];
  undefined4 auStack_a38 [146];
  undefined4 auStack_7f0 [7];
  undefined auStack_7d4 [64];
  float fStack_794;
  undefined4 uStack_790;
  undefined4 uStack_78c;
  float fStack_788;
  undefined4 uStack_784;
  float fStack_780;
  undefined4 uStack_77c;
  float fStack_778;
  undefined4 uStack_774;
  undefined4 uStack_770;
  undefined4 uStack_76c;
  undefined4 uStack_768;
  undefined4 uStack_764;
  undefined4 uStack_760;
  undefined4 uStack_75c;
  undefined4 uStack_758;
  undefined4 auStack_5a8 [13];
  undefined8 auStack_574 [72];
  undefined auStack_330 [64];
  undefined auStack_2f0 [64];
  undefined auStack_2b0 [16];
  undefined8 uStack_2a0;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined8 uStack_230;
  float afStack_228 [6];
  int aiStack_210 [3];
  float fStack_204;
  float fStack_200;
  int iStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  float fStack_1e0;
  float fStack_1dc;
  int iStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  float fStack_1bc;
  float fStack_1b8;
  int iStack_1a4;
  float fStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  float fStack_194;
  undefined4 uStack_190;
  float fStack_18c;
  undefined4 uStack_188;
  float fStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined8 uStack_160;
  undefined4 uStack_158;
  float fStack_154;
  undefined4 uStack_150;
  float fStack_14c;
  float fStack_148;
  undefined4 uStack_144;
  float *pfStack_140;
  float fStack_13c;
  undefined8 uStack_138;
  undefined4 *puStack_130;
  undefined4 uStack_12c;
  undefined8 uStack_128;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  float fStack_114;
  float fStack_110;
  undefined8 uStack_10c;
  float fStack_104;
  int iStack_100;
  float afStack_fc [2];
  float fStack_f4;
  uint uStack_f0;
  uint uStack_ec;
  float *pfStack_e8;
  float fStack_e4;
  undefined8 uStack_e0;
  int *piStack_d8;
  int *piStack_d4;
  undefined *puStack_d0;
  undefined4 *puStack_cc;
  float *pfStack_c8;
  undefined4 *puStack_c4;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  float fStack_b0;
  float fStack_ac;
  float *pfStack_a8;
  float *pfStack_a4;
  float fStack_a0;
  float fStack_9c;
  uint uStack_98;
  int iStack_94;
  uint uStack_90;
  float *pfStack_8c;
  uint uStack_88;
  uint uStack_84;
  undefined8 uStack_80;
  uint uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  float fStack_68;
  float fStack_64;
  float *pfStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined8 *puStack_48;
  uint uStack_44;
  int *piStack_40;
  float *pfStack_3c;
  float *pfStack_38;
  float *pfStack_34;
  undefined8 uStack_30;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b73d3;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  FUN_016f40d0();
  piStack_d8 = (int *)(extraout_ECX + 8);
  piStack_d4 = (int *)(extraout_ECX + 0x14);
  if (piStack_d8 != piStack_d4) {
    iVar16 = *piStack_d8;
    *piStack_d8 = *piStack_d4;
    *piStack_d4 = iVar16;
    uVar2 = *(undefined4 *)(extraout_ECX + 0xc);
    *(undefined4 *)(extraout_ECX + 0xc) = *(undefined4 *)(extraout_ECX + 0x18);
    *(undefined4 *)(extraout_ECX + 0x18) = uVar2;
    uVar2 = *(undefined4 *)(extraout_ECX + 0x10);
    *(undefined4 *)(extraout_ECX + 0x10) = *(undefined4 *)(extraout_ECX + 0x1c);
    *(undefined4 *)(extraout_ECX + 0x1c) = uVar2;
  }
  pfStack_60 = (float *)(extraout_ECX + 0x1fc);
  *(undefined4 *)(extraout_ECX + 0x200) = *(undefined4 *)(extraout_ECX + 0x1fc);
  uStack_58._0_4_ = (float *)(extraout_ECX + 0x20);
  *(undefined4 *)(extraout_ECX + 0x24) = *(undefined4 *)(extraout_ECX + 0x20);
  uStack_30 = (double)CONCAT44(extraout_ECX,param_1);
  *(undefined4 *)(extraout_ECX + 0x4f34c) = *(undefined4 *)(extraout_ECX + 0x4f348);
  pfStack_34 = (float *)auStack_ad0;
  pfStack_38 = (float *)0x83f950;
  puVar13 = (undefined4 *)FUN_0083ce90();
  fStack_64 = 0.0;
  puVar15 = &uStack_230;
  for (iVar16 = 0x24; iVar16 != 0; iVar16 = iVar16 + -1) {
    *(undefined4 *)puVar15 = *puVar13;
    puVar13 = puVar13 + 1;
    puVar15 = (undefined8 *)((int)puVar15 + 4);
  }
  uStack_298 = 0;
  uStack_2a0 = 0;
  uStack_294 = 0;
  iVar16 = 6;
  do {
    uStack_30 = (double)CONCAT44(0x83f99f,(float *)uStack_30);
    FUN_00569440();
    pfVar19 = pfStack_34;
    iVar16 = iVar16 + -1;
  } while (iVar16 != 0);
  uStack_30 = (double)CONCAT44(*(undefined4 *)((int)pfStack_34 + 0x4f360),param_1 + 6);
  pfStack_34 = (float *)0x83f9ca;
  FUN_0083f1a0();
  uStack_30 = (double)(ulonglong)
                      CONCAT14(*(undefined *)((int)param_1 + 0x26e),(undefined *)((int)pfVar19 + 8))
  ;
  pfStack_34 = (float *)&uStack_230;
  pfStack_38 = (float *)&uStack_2a0;
  pfStack_3c = (float *)param_1;
  piStack_40 = (int *)0x83f9ea;
  uStack_74 = FUN_0083d2e0();
  if (aiStack_210[0] == 0) {
    fStack_64 = afStack_228[1] - *(float *)((int)pfVar19 + 500);
    uStack_70 = (undefined4)uStack_230;
    uStack_6c = uStack_230._4_4_;
    fStack_68 = afStack_228[0];
    *(undefined4 *)((int)pfVar19 + 0x4f368) = (undefined4)uStack_230;
    *(undefined4 *)((int)pfVar19 + 0x4f36c) = uStack_230._4_4_;
    *(float *)((int)pfVar19 + 0x4f370) = afStack_228[0];
    *(float *)((int)pfVar19 + 0x4f374) = fStack_64;
    *(float *)((int)pfVar19 + 0x4f374) =
         *(float *)((int)pfVar19 + 0x4f374) * *(float *)((int)pfVar19 + 0x4f374);
  }
  if (iStack_1ec == 0) {
    fStack_64 = fStack_200 - *(float *)((int)pfVar19 + 500);
    uStack_70 = aiStack_210[1];
    uStack_6c = aiStack_210[2];
    fStack_68 = fStack_204;
    *(int *)((int)pfVar19 + 0x4f378) = aiStack_210[1];
    *(int *)((int)pfVar19 + 0x4f37c) = aiStack_210[2];
    *(float *)((int)pfVar19 + 0x4f380) = fStack_204;
    *(float *)((int)pfVar19 + 0x4f384) = fStack_64;
    *(float *)((int)pfVar19 + 0x4f384) =
         *(float *)((int)pfVar19 + 0x4f384) * *(float *)((int)pfVar19 + 0x4f384);
  }
  if (iStack_1c8 == 0) {
    fStack_64 = fStack_1dc - *(float *)((int)pfVar19 + 500);
    uStack_70 = uStack_1e8;
    uStack_6c = uStack_1e4;
    fStack_68 = fStack_1e0;
    *(undefined4 *)((int)pfVar19 + 0x4f388) = uStack_1e8;
    *(undefined4 *)((int)pfVar19 + 0x4f38c) = uStack_1e4;
    *(float *)((int)pfVar19 + 0x4f390) = fStack_1e0;
    *(float *)((int)pfVar19 + 0x4f394) = fStack_64;
    *(float *)((int)pfVar19 + 0x4f394) =
         *(float *)((int)pfVar19 + 0x4f394) * *(float *)((int)pfVar19 + 0x4f394);
  }
  if (iStack_1a4 == 0) {
    fStack_64 = fStack_1b8 - *(float *)((int)pfVar19 + 500);
    uStack_70 = uStack_1c4;
    uStack_6c = uStack_1c0;
    fStack_68 = fStack_1bc;
    *(undefined4 *)((int)pfVar19 + 0x4f398) = uStack_1c4;
    *(undefined4 *)((int)pfVar19 + 0x4f39c) = uStack_1c0;
    *(float *)((int)pfVar19 + 0x4f3a0) = fStack_1bc;
    *(float *)((int)pfVar19 + 0x4f3a4) = fStack_64;
    *(float *)((int)pfVar19 + 0x4f3a4) =
         *(float *)((int)pfVar19 + 0x4f3a4) * *(float *)((int)pfVar19 + 0x4f3a4);
  }
  uStack_44 = 0;
  if (uStack_74 != 0) {
    uVar20 = 0;
    puStack_4c = (undefined4 *)0x0;
    piStack_40 = aiStack_210;
    puStack_48 = (undefined8 *)uStack_74;
    do {
      if (*piStack_40 != 0) {
        uStack_44 = uStack_44 + 1;
        uStack_30 = (double)CONCAT44(*(int *)((int)pfVar19 + 8) + (int)puStack_4c,auStack_5a8);
        if (*piStack_40 == 2) {
          pfStack_34 = (float *)0x83fbd0;
          puVar13 = (undefined4 *)FUN_0083ac90();
        }
        else {
          pfStack_34 = (float *)0x83fbd7;
          puVar13 = (undefined4 *)FUN_0083adf0();
        }
        pfVar19 = pfStack_34;
        puVar21 = (float *)uStack_30;
        for (iVar16 = 0x9e; iVar16 != 0; iVar16 = iVar16 + -1) {
          *puVar21 = *puVar13;
          puVar13 = puVar13 + 1;
          puVar21 = puVar21 + 1;
        }
        uVar20 = (uint)uStack_30._4_4_;
        *(undefined4 *)((int)pfStack_34 + (int)uStack_30._4_4_ + 0x13e20) =
             *(undefined4 *)((int)pfStack_34 + (int)uStack_30._4_4_ + 0x13e28);
        *(undefined4 *)((int)pfStack_34 + (int)uStack_30._4_4_ + 0x13e24) =
             *(undefined4 *)((int)pfStack_34 + (int)uStack_30._4_4_ + 0x13e2c);
        uStack_30 = (double)CONCAT44(0x9e00,(undefined *)
                                            ((int)pfStack_34 + (int)uStack_30._4_4_ + 0x220));
        pfStack_34 = (float *)((int)pfStack_34 + uVar20 + 0xa020);
        pfStack_38 = (float *)0x83fc24;
        FUN_0170c6f0();
        *(undefined4 *)((int)pfVar19 + uVar20 + 0x208) = 0;
      }
      piStack_40 = piStack_40 + 9;
      uVar20 = uVar20 + 0x13c50;
      uStack_30 = (double)((ulonglong)uVar20 << 0x20);
      puStack_48 = (undefined8 *)((int)puStack_48 - 1);
      puStack_4c = (undefined4 *)((int)puStack_4c + 0x278);
    } while (puStack_48 != (undefined8 *)0x0);
  }
  if (uStack_44 != uStack_74) {
    fStack_64 = 0.0;
    bVar18 = false;
    bVar6 = false;
    uStack_b8 = 0;
    fStack_b0 = 0.0;
    fStack_ac = 0.0;
    if (uStack_74 != 0) {
      pfVar22 = afStack_228 + 1;
      uStack_30 = (double)CONCAT44(uStack_30._4_4_,uStack_74);
      uVar20 = uStack_74;
      do {
        if (pfVar22[5] == 0.0) {
          pfVar14 = (float *)pfVar22[-3];
          fVar24 = pfVar22[-1];
          if (bVar18) {
            uStack_c0._4_4_ = *pfVar22;
            uStack_30 = (double)CONCAT44(&pfStack_c8,0x83fd37);
            pfStack_c8 = pfVar14;
            puStack_c4 = (undefined4 *)pfVar22[-2];
            uStack_c0._0_4_ = (undefined8 *)fVar24;
            FUN_01166b40();
            uVar20 = (uint)(float *)uStack_30;
            bVar18 = bVar6;
          }
          else {
            pfStack_e8 = pfVar14;
            fStack_e4 = pfVar22[-2];
            uStack_b8 = *(undefined8 *)(pfVar22 + -3);
            uStack_e0._0_4_ = fVar24;
            fStack_b0 = fVar24;
            fStack_ac = *pfVar22;
            bVar6 = true;
            bVar18 = true;
          }
        }
        pfVar22 = pfVar22 + 9;
        uVar20 = uVar20 - 1;
        uStack_30 = (double)CONCAT44(uStack_30._4_4_,uVar20);
      } while (uVar20 != 0);
    }
    uStack_30 = (double)CONCAT44((undefined *)((int)pfVar19 + 0x4f354),&uStack_b8);
    pfStack_34 = &fStack_1a0;
    pfStack_38 = (float *)0x83fd66;
    FUN_0083ccd0();
    pfStack_3c = (float *)auStack_2f0;
    uStack_30 = (double)CONCAT44((uint)fStack_ac ^ DAT_018c4ea0,fStack_ac + DAT_01919494);
    pfStack_34 = (float *)fStack_ac;
    pfStack_38 = (float *)fStack_ac;
    piStack_40 = (int *)0x83fda6;
    FUN_0083e330();
    uStack_30 = (double)CONCAT44(0x83fdb4,(float *)uStack_30);
    FUN_007cc9d0();
    uStack_30 = (double)CONCAT44(&fStack_1a0,0x83fdc6);
    FUN_007cdb40();
    uStack_30 = (double)ZEXT48(auStack_2f0);
    pfStack_34 = (float *)0x83fdda;
    FUN_007cd560();
    uStack_30 = (double)CONCAT44(0x83fddf,(float *)uStack_30);
    iVar16 = FUN_007a8ef0();
    uStack_30 = (double)CONCAT44(iVar16 + 0x12,iVar16 + 0x12);
    pfStack_34 = (float *)0x9;
    pfStack_38 = (float *)auStack_1020;
    pfStack_3c = afStack_1608;
    piStack_40 = (int *)0x83fdf9;
    FUN_0083ae90();
    puStack_cc = (undefined4 *)CONCAT31(puStack_cc._1_3_,*(undefined *)(param_1 + 0xa6));
    cVar1 = *(char *)((int)param_1 + 0x299);
    cVar11 = *(char *)((int)param_1 + 0x29a);
    *(bool *)((int)pfVar19 + 0x4f364) = cVar11 != '\0';
    if (cVar11 == '\0') {
      fStack_9c = 0.0;
    }
    else {
      fStack_9c = DAT_01919494 - _DAT_01d62258;
    }
    iStack_100 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iStack_100 + 0x34) < DAT_01eb4518) {
      uStack_30 = 2.0360002567440484e-299;
      FUN_016f3809();
      if (DAT_01eb4518 == -1) {
        uStack_30 = -NAN;
        pfStack_34 = (float *)0x18fe230;
        uStack_14 = 0;
        pfStack_38 = (float *)0x840dfd;
        uVar29 = FUN_0152dab0();
        DAT_01eb4514 = (undefined4 *)((ulonglong)uVar29 >> 0x20);
        DAT_01eb4510 = (float *)uVar29;
        pfStack_38 = (float *)&DAT_01eb4518;
        uStack_14 = 0xffffffff;
        pfStack_3c = (float *)0x840e19;
        FUN_016f37bf();
      }
    }
    pfVar19 = DAT_01eb4510;
    uStack_30._0_4_ = DAT_01eb4510;
    uStack_30._4_4_ = (float *)DAT_01eb4514;
    pfStack_c8 = DAT_01eb4510;
    uStack_58._4_4_ = DAT_01eb4514;
    puStack_c4 = DAT_01eb4514;
    pfStack_34 = (float *)0x83fe98;
    uVar29 = FUN_0152d930();
    pfStack_34 = (float *)puStack_cc;
    piStack_40 = (int *)&uStack_2a0;
    uStack_14 = 1;
    pfStack_38 = (float *)uStack_58;
    pfStack_3c = pfStack_60;
    uStack_44 = uStack_74;
    puStack_48 = &uStack_230;
    puStack_4c = param_1;
    uStack_50 = afStack_1608;
    uStack_58._4_4_ = (undefined4 *)0x83fedb;
    uStack_c0 = uVar29;
    FUN_0083d730();
    uStack_14 = 2;
    pfStack_60 = pfVar19;
    fStack_64 = 1.2121903e-38;
    uStack_5c = (int)((ulonglong)uVar29 >> 0x20);
    uStack_58 = uVar29;
    FUN_0152dda0();
    uStack_14 = 0xffffffff;
    if (*pfStack_60 != pfStack_60[1]) {
      uStack_30 = (double)(ZEXT48(uStack_30._4_4_) << 0x20);
      uStack_5c = 0;
      pfVar19 = pfStack_34;
      if (uStack_74 != 0) {
        do {
          uVar20 = uStack_5c;
          pfStack_3c = pfVar19 + uStack_5c * 0x4f14 + 0x82;
          uStack_58._0_4_ = (float *)((int)pfVar19[5] + uStack_5c * 0x278);
          iStack_94 = (int)pfVar19[2] + uStack_5c * 0x278;
          puVar15 = (undefined8 *)((int)&uStack_230 + uStack_5c * 0x24);
          puStack_48 = puVar15;
          if (aiStack_210[uStack_5c * 9] == 0) {
            uStack_30 = (double)CONCAT44(uStack_5c,0x83ffd4);
            uStack_58._4_4_ = (undefined4 *)FUN_007a8e00();
            fVar24 = afStack_228[uVar20 * 9 + 1];
            uStack_144 = 0x3f800000;
            uStack_150 = *(undefined4 *)puVar15;
            uStack_30 = (double)CONCAT44(&uStack_150,(float *)uStack_30);
            fStack_14c = afStack_228[uVar20 * 9 + -1];
            fStack_148 = afStack_228[uVar20 * 9];
            uStack_30 = (double)CONCAT44(&uStack_150,auStack_2b0);
            pfStack_34 = (float *)0x840031;
            FUN_01165b90();
            uStack_30 = (double)CONCAT44(&uStack_6c,0x84003c);
            FUN_011658d0();
            uStack_160 = CONCAT44(fStack_68,uStack_6c);
            fStack_154 = fVar24 * fVar24;
            uStack_158 = fStack_64;
            uVar27 = (uint)afStack_228[uVar20 * 9 + 1] ^ DAT_018c4ea0;
            pfStack_34 = (float *)auStack_2f0;
            uStack_30 = (double)CONCAT44(pfVar19 + 0x13cd5,puVar15);
            pfStack_38 = (float *)0x8400a7;
            FUN_0083ccd0();
            pfStack_3c = (float *)auStack_330;
            uStack_30 = (double)CONCAT44(uVar27,uVar27);
            pfStack_38 = (float *)afStack_228[uVar20 * 9 + 1];
            piStack_40 = (int *)0x8400d9;
            pfStack_34 = pfStack_38;
            FUN_0083e330();
            uStack_30 = (double)CONCAT44(0x8400e7,(float *)uStack_30);
            FUN_007cc9d0();
            uStack_30 = (double)CONCAT44(auStack_2f0,0x8400f9);
            FUN_007cdb40();
            uStack_30 = (double)ZEXT48(auStack_330);
            pfStack_34 = (float *)0x84010d;
            FUN_007cd560();
            uStack_30 = (double)CONCAT44(uStack_5c,0x840115);
            iVar16 = FUN_007a8e00();
            puStack_d0 = (undefined *)(iVar16 + 0x12);
            uStack_30 = (double)CONCAT44(fStack_9c,puStack_d0);
            pfStack_3c = (float *)auStack_7f0;
            pfStack_38 = (float *)0x9;
            piStack_40 = (int *)auStack_1268;
            uStack_44 = 0x840142;
            pfStack_34 = (float *)puStack_d0;
            FUN_0083afb0();
            if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                DAT_01eb4528) {
              uStack_30 = 2.0360184845491201e-299;
              FUN_016f3809();
              if (DAT_01eb4528 == -1) {
                uStack_30 = -NAN;
                pfStack_34 = (float *)0x18fe230;
                uStack_14 = 3;
                pfStack_38 = (float *)0x840e53;
                uVar29 = FUN_0152dab0();
                DAT_01eb4524 = (undefined4)((ulonglong)uVar29 >> 0x20);
                DAT_01eb4520 = (undefined4 *)uVar29;
                pfStack_38 = (float *)&DAT_01eb4528;
                uStack_14 = 0xffffffff;
                pfStack_3c = (float *)0x840e6f;
                FUN_016f37bf();
              }
            }
            puStack_4c = DAT_01eb4520;
            puStack_130 = DAT_01eb4520;
            uStack_30 = (double)CONCAT44(DAT_01eb4524,DAT_01eb4520);
            uStack_12c = DAT_01eb4524;
            pfStack_34 = (float *)0x840189;
            uVar29 = FUN_0152d930();
            pfVar22 = pfStack_3c;
            uStack_14 = 4;
            uStack_128 = uVar29;
            if (cVar1 == '\0') {
              iVar16 = (int)pfVar19[0x80];
              for (iVar17 = (int)pfVar19[0x7f]; uStack_30 = (double)uStack_128, iVar17 != iVar16;
                  iVar17 = iVar17 + 0x5c) {
                puVar13 = (undefined4 *)pfVar22[0x4f0b];
                if ((undefined4 *)pfVar22[0x4f0c] == puVar13) {
                  uStack_30 = (double)CONCAT44(iVar17 + 0x58,puVar13);
                  pfStack_34 = (float *)0x840223;
                  FUN_0083b870();
                }
                else {
                  *puVar13 = *(undefined4 *)(iVar17 + 0x58);
                  puVar13[1] = 0xffffffff;
                  pfVar22[0x4f0b] = (float)((int)pfVar22[0x4f0b] + 8);
                }
              }
            }
            else {
              uStack_30 = (double)CONCAT44(puStack_cc,pfStack_3c + 0x4f0a);
              pfStack_34 = pfVar19 + 0x7f;
              pfStack_38 = (float *)&uStack_160;
              pfStack_3c = (float *)auStack_1268;
              piStack_40 = (int *)0x8401ce;
              FUN_0083e0d0();
              uStack_30 = (double)uStack_128;
            }
            uStack_128._4_4_ = (undefined4)((ulonglong)uStack_30 >> 0x20);
            uStack_14 = 5;
            pfStack_34 = (float *)uStack_128._4_4_;
            pfStack_38 = (float *)puStack_4c;
            pfStack_3c = (float *)0x840249;
            uStack_128 = uStack_30;
            FUN_0152dda0();
            uStack_14 = 0xffffffff;
            if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                DAT_01eb4538) {
              uStack_30 = 2.0360367123541918e-299;
              FUN_016f3809();
              if (DAT_01eb4538 == -1) {
                uStack_30 = -NAN;
                pfStack_34 = (float *)0x18fe230;
                uStack_14 = 6;
                pfStack_38 = (float *)0x840ea9;
                uVar29 = FUN_0152dab0();
                DAT_01eb4534 = (undefined4 *)((ulonglong)uVar29 >> 0x20);
                DAT_01eb4530 = (float *)uVar29;
                pfStack_38 = (float *)&DAT_01eb4538;
                uStack_14 = 0xffffffff;
                pfStack_3c = (float *)0x840ec5;
                FUN_016f37bf();
              }
            }
            puVar13 = DAT_01eb4534;
            uStack_30._0_4_ = DAT_01eb4530;
            uStack_30._4_4_ = DAT_01eb4530;
            pfStack_c8 = DAT_01eb4530;
            puStack_c4 = DAT_01eb4534;
            pfStack_34 = (float *)0x840298;
            uVar29 = FUN_0152d930();
            pfStack_34 = (float *)uStack_80._4_4_;
            uStack_14 = 7;
            piStack_40 = *(int **)((int)pfStack_3c + 0x13c28);
            pfStack_3c = *(float **)((int)pfStack_3c + 0x13c2c);
            pfStack_38 = (float *)((int)pfStack_3c - (int)piStack_40 >> 3);
            uStack_44 = 0x8402ce;
            uStack_c0 = uVar29;
            FUN_0083bfb0();
            puStack_48 = (undefined8 *)uStack_c0;
            uStack_14 = 8;
            puStack_4c = puVar13;
            uStack_50 = uStack_30._4_4_;
            uStack_58._4_4_ = (undefined4 *)0x8402e7;
            uStack_44 = (int)((ulonglong)uVar29 >> 0x20);
            FUN_0152dda0();
            uStack_14 = 0xffffffff;
            uStack_80 = (double)((float)param_1[0x1d] / DAT_018f784c);
            pfStack_34 = (float *)0x840314;
            uStack_30 = uStack_80;
            fVar23 = (float10)FUN_01725280();
            fVar24 = (float)fVar23 * DAT_018f784c;
            uStack_80 = (double)((float)param_1[0x22] / DAT_018f784c);
            pfStack_34 = (float *)0x840350;
            uStack_30 = uStack_80;
            fVar23 = (float10)FUN_01725280();
            pfVar19 = pfStack_34;
            uStack_80 = (double)fVar23;
            fVar25 = (float)fVar23 * DAT_018f784c;
            if (NAN(fVar24) != (fVar24 == 0.0)) {
              fVar24 = 0.0;
            }
            if (NAN(fVar25) != (fVar25 == 0.0)) {
              fVar25 = 0.0;
            }
            uStack_30 = (double)CONCAT44(*(undefined4 *)((int)pfStack_34 + 0x1d0),
                                         (int)fVar24 + 0x9e3779b9U ^
                                         ((int)fVar24 + 0x9e3779b9U >> 2) + (int)fVar25 +
                                         (int)fVar24 * 0x40 + 0x2c15e7f9);
            pfStack_34 = (float *)0x8403c8;
            FUN_008399e0();
            fStack_f4 = fStack_110;
            uStack_30 = 4.24826611981667e-314;
            pfVar14 = (float *)FUN_01165f10();
            uStack_30 = (double)CONCAT44(*(undefined4 *)(iStack_94 + 0x260),0x84040d);
            uVar20 = FUN_008363a0();
            pfVar22 = pfStack_3c;
            fVar24 = DAT_018fd178;
            uVar27 = (uint)DAT_018c0da0;
            uVar28 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
            fStack_104 = *(float *)(puStack_48 + 1);
            uVar29 = *puStack_48;
            uStack_10c._0_4_ = (float)uVar29;
            if (((DAT_018fd178 <
                  (float)(double)CONCAT44((uint)((ulonglong)
                                                 (double)(pfStack_3c[0x4f11] - (float)uStack_10c) >>
                                                0x20) & uVar28,
                                          SUB84((double)(pfStack_3c[0x4f11] - (float)uStack_10c),0)
                                          & uVar27)) ||
                (uStack_10c._4_4_ = (float)((ulonglong)uVar29 >> 0x20),
                DAT_018fd178 <
                (float)(double)CONCAT44((uint)((ulonglong)
                                               (double)(pfStack_3c[0x4f12] - uStack_10c._4_4_) >>
                                              0x20) & uVar28,
                                        SUB84((double)(pfStack_3c[0x4f12] - uStack_10c._4_4_),0) &
                                        uVar27))) ||
               (DAT_018fd178 <
                (float)(double)CONCAT44((uint)((ulonglong)(double)(pfStack_3c[0x4f13] - fStack_104)
                                              >> 0x20) & uVar28,
                                        SUB84((double)(pfStack_3c[0x4f13] - fStack_104),0) & uVar27)
               )) {
              fVar25 = *(float *)(puStack_48 + 1);
              *(undefined8 *)(pfStack_3c + 0x4f11) = *puStack_48;
              pfStack_3c[0x4f13] = fVar25;
              uVar20 = 0;
            }
            fVar25 = pfVar14[1];
            fVar4 = pfVar14[2];
            fVar5 = pfVar14[3];
            dVar26 = (double)(pfStack_3c[0x4f0d] - *pfVar14);
            if (((fVar24 < (float)(double)CONCAT44((uint)((ulonglong)dVar26 >> 0x20) & uVar28,
                                                   SUB84(dVar26,0) & uVar27)) ||
                (dVar26 = (double)(pfStack_3c[0x4f0e] - fVar25),
                fVar24 < (float)(double)CONCAT44((uint)((ulonglong)dVar26 >> 0x20) & uVar28,
                                                 SUB84(dVar26,0) & uVar27))) ||
               ((dVar26 = (double)(pfStack_3c[0x4f0f] - fVar4),
                fVar24 < (float)(double)CONCAT44((uint)((ulonglong)dVar26 >> 0x20) & uVar28,
                                                 SUB84(dVar26,0) & uVar27) ||
                (dVar26 = (double)(pfStack_3c[0x4f10] - fVar5),
                fVar24 < (float)(double)CONCAT44((uint)((ulonglong)dVar26 >> 0x20) & uVar28,
                                                 SUB84(dVar26,0) & uVar27))))) {
              pfStack_3c[0x4f0d] = *pfVar14;
              pfStack_3c[0x4f0e] = fVar25;
              pfStack_3c[0x4f0f] = fVar4;
              pfStack_3c[0x4f10] = fVar5;
              bVar6 = true;
            }
            else {
              bVar6 = false;
            }
            uStack_44 = 0;
            if (!bVar6) {
              uStack_44 = uVar20 & 0xff;
            }
            piStack_40 = (int *)0x0;
            *pfStack_3c = pfStack_3c[3] - *(float *)(puStack_48 + 3);
            fVar24 = *(float *)((int)puStack_48 + 0x14);
            fVar25 = *(float *)(puStack_48 + 3);
            fVar4 = *(float *)((int)puStack_48 + 0x1c);
            pfStack_3c[1] = *(float *)(puStack_48 + 2);
            pfStack_3c[2] = fVar24;
            pfStack_3c[3] = fVar25;
            pfStack_3c[4] = fVar4;
            uStack_80 = (double)CONCAT44(*(int *)((int)pfVar19 + 0x24) -
                                         *(int *)((int)pfVar19 + 0x20) >> 2,(undefined4)uStack_80);
            uStack_10c = uVar29;
            if (uStack_5c == 0) {
              if (*(int *)(iStack_100 + 0x34) < DAT_01eb4558) {
                uStack_30 = 2.0360731679643352e-299;
                FUN_016f3809();
                if (DAT_01eb4558 == -1) {
                  uStack_30 = -NAN;
                  pfStack_34 = (float *)0x18fe230;
                  uStack_14 = 0xc;
                  pfStack_38 = (float *)0x840f55;
                  uVar29 = FUN_0152dab0();
                  DAT_01eb4554 = (float)((ulonglong)uVar29 >> 0x20);
                  DAT_01eb4550 = (float *)uVar29;
                  pfStack_38 = (float *)&DAT_01eb4558;
                  uStack_14 = 0xffffffff;
                  pfStack_3c = (float *)0x840f71;
                  FUN_016f37bf();
                }
              }
              uStack_30 = (double)CONCAT44(DAT_01eb4554,DAT_01eb4550);
              pfStack_a8 = DAT_01eb4550;
              pfStack_e8 = DAT_01eb4550;
              fStack_a0 = DAT_01eb4554;
              fStack_e4 = DAT_01eb4554;
              pfStack_34 = (float *)0x840ba0;
              uVar29 = FUN_0152d930();
              pfStack_a4 = (float *)pfVar22[0x4f0b];
              pfVar22 = (float *)pfVar22[0x4f0a];
              uStack_14 = 0xd;
              uStack_e0 = uVar29;
              if (pfVar22 != pfStack_a4) {
                do {
                  puVar13 = *(undefined4 **)((int)pfVar19 + 0x4f34c);
                  uStack_120 = 0xffffffff;
                  uStack_11c = 0xffffffff;
                  if (*(undefined4 **)((int)pfVar19 + 0x4f350) == puVar13) {
                    uStack_30 = (double)CONCAT44(&uStack_120,puVar13);
                    pfStack_34 = (float *)0x840c1b;
                    FUN_00805800();
                  }
                  else {
                    *puVar13 = 0xffffffff;
                    puVar13[1] = 0xffffffff;
                    *(int *)((int)pfVar19 + 0x4f34c) = *(int *)((int)pfVar19 + 0x4f34c) + 8;
                  }
                  pfVar14 = *(float **)((int)pfVar19 + 0x24);
                  if (*(float **)((int)pfVar19 + 0x28) == pfVar14) {
                    uStack_30 = (double)CONCAT44(pfVar22,pfVar14);
                    pfStack_34 = (float *)0x840c37;
                    FUN_006030d0();
                  }
                  else {
                    *pfVar14 = *pfVar22;
                    *(int *)((int)pfVar19 + 0x24) = *(int *)((int)pfVar19 + 0x24) + 4;
                  }
                  uStack_30 = (double)CONCAT44(*pfVar22,0x840c44);
                  FUN_00839a00();
                  pfVar22 = pfVar22 + 2;
                } while (pfVar22 != pfStack_a4);
              }
              iVar16 = iStack_94;
              uStack_30 = (double)CONCAT44(afStack_fc,0x840c67);
              cVar11 = FUN_00839e70();
              if ((cVar11 == '\0') || ((char)uStack_44 == '\0')) {
                piStack_40 = (int *)0x1;
              }
              uStack_14 = 0xe;
              uStack_30 = (double)uStack_e0;
              pfStack_34 = (float *)fStack_a0;
              pfStack_38 = pfStack_a8;
              pfStack_3c = (float *)0x840c9c;
              FUN_0152dda0();
            }
            else {
              if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                  DAT_01eb4548) {
                uStack_30 = 2.0360549401592635e-299;
                FUN_016f3809();
                if (DAT_01eb4548 == -1) {
                  uStack_30 = -NAN;
                  pfStack_34 = (float *)0x18fe230;
                  uStack_14 = 9;
                  pfStack_38 = (float *)0x840eff;
                  uVar29 = FUN_0152dab0();
                  DAT_01eb4544 = (float)((ulonglong)uVar29 >> 0x20);
                  DAT_01eb4540 = (float *)uVar29;
                  pfStack_38 = (float *)&DAT_01eb4548;
                  uStack_14 = 0xffffffff;
                  pfStack_3c = (float *)0x840f1b;
                  FUN_016f37bf();
                }
              }
              uStack_30 = (double)CONCAT44(DAT_01eb4544,DAT_01eb4540);
              pfStack_a4 = DAT_01eb4540;
              pfStack_140 = DAT_01eb4540;
              fStack_a0 = DAT_01eb4544;
              fStack_13c = DAT_01eb4544;
              pfStack_34 = (float *)0x8405d2;
              uVar29 = FUN_0152d930();
              pfStack_8c = pfVar22 + 0x2786;
              uStack_14 = 10;
              pfStack_60 = pfVar22 + 6;
              pfStack_38 = pfVar22 + 0x4f06;
              piStack_40 = (int *)0x840602;
              pfStack_3c = pfStack_8c;
              pfStack_34 = pfStack_60;
              uStack_138 = uVar29;
              FUN_016e012d();
              pfVar22[0x4f08] = pfVar22[0x4f06];
              fVar24 = DAT_01919490;
              pfVar22[0x4f09] = pfVar22[0x4f07];
              pfVar22[0x4f06] = 0.0;
              pfVar22[0x4f07] = 0.0;
              uStack_30 = 0.007812501848093234;
              pfStack_34 = (float *)0x2;
              fVar24 = fVar24 / (float)((double)(int)puStack_d0 +
                                       (double)(&DAT_018c0d90)[-((int)puStack_d0 >> 0x1f)]);
              fVar24 = DAT_018ce2f8 - (fVar24 + fVar24);
              pfStack_38 = (float *)0x84068c;
              pfStack_34 = (float *)FUN_01165f10();
              pfStack_38 = (float *)auStack_7f0;
              pfStack_3c = (float *)0x84069f;
              FUN_008394f0();
              uStack_30 = (double)CONCAT44(fVar24,fVar24);
              pfStack_34 = (float *)0x2;
              pfStack_38 = (float *)0x8406bf;
              pfStack_34 = (float *)FUN_01165f10();
              pfStack_38 = (float *)auStack_7f0;
              pfStack_3c = (float *)0x8406d2;
              FUN_008394f0();
              pfStack_38 = (float *)0x0;
              uStack_90 = 0;
              do {
                uStack_30 = (double)((ulonglong)uStack_30 & 0xffffffff);
                uVar20 = uStack_90 * 8;
                puStack_48 = (undefined8 *)0x0;
                puStack_4c = (undefined4 *)0x0;
                do {
                  puVar15 = puStack_48;
                  uStack_f0 = 1 << (uVar20 & 0x1f);
                  uStack_ec = 0;
                  if (0x1f < uVar20) {
                    uStack_ec = uStack_f0;
                  }
                  uStack_f0 = uStack_f0 ^ uStack_ec;
                  if (0x3f < uVar20) {
                    uStack_ec = uStack_f0;
                  }
                  uStack_30 = (double)CONCAT44(0x840729,(float *)uStack_30);
                  uStack_88 = uStack_ec;
                  uStack_84 = uStack_f0;
                  FUN_007cc9d0();
                  uStack_30 = (double)CONCAT44(0x840734,(float *)uStack_30);
                  FUN_007cc9d0();
                  if (DAT_01d61044 == '\0') {
                    uStack_180 = uStack_774;
                    uStack_17c = uStack_770;
                    uStack_178 = uStack_76c;
                    uStack_174 = uStack_768;
                    uStack_30 = (double)CONCAT44(&fStack_1a0,auStack_7d4);
                    uStack_170 = uStack_764;
                    uStack_16c = uStack_760;
                    uStack_168 = uStack_75c;
                    uStack_164 = uStack_758;
                    uStack_19c = uStack_790;
                    uStack_198 = uStack_78c;
                    fStack_194 = (DAT_018fde90 - (float)(int)puStack_4c) + fStack_788;
                    uStack_190 = uStack_784;
                    uStack_188 = uStack_77c;
                    fStack_1a0 = fStack_794 * _DAT_0191948c;
                    fStack_184 = fStack_778 - (DAT_018fde90 - (float)(int)&fStack_1a0);
                    fStack_18c = fStack_780 * _DAT_0191948c;
                    pfStack_34 = (float *)0x84080a;
                    FUN_007cdc00();
                    uStack_30 = (double)CONCAT44(fStack_9c,puStack_d0);
                    pfStack_34 = (float *)puStack_d0;
                    pfStack_38 = (float *)0x9;
                    pfStack_3c = (float *)auStack_a38;
                    piStack_40 = (int *)auStack_574;
                    uStack_44 = 0x840835;
                    puVar15 = (undefined8 *)FUN_0083afb0();
                  }
                  else {
                    pfStack_34 = (float *)auStack_b60;
                    uStack_30 = (double)CONCAT44(uStack_90,puVar15);
                    pfStack_38 = (float *)0x840852;
                    FUN_0083c4b0();
                    uStack_30 = (double)CONCAT44(uStack_90,puStack_48);
                    puVar15 = auStack_574;
                    puVar13 = auStack_a38;
                    for (iVar16 = 0x91; iVar16 != 0; iVar16 = iVar16 + -1) {
                      *puVar13 = *(undefined4 *)puVar15;
                      puVar15 = (undefined8 *)((int)puVar15 + 4);
                      puVar13 = puVar13 + 1;
                    }
                    pfStack_34 = (float *)auStack_13c0;
                    pfStack_38 = (float *)0x84087d;
                    FUN_0083c4b0();
                    puVar15 = auStack_574;
                  }
                  uVar9 = uStack_294;
                  uVar8 = uStack_298;
                  uVar2 = (undefined4)uStack_2a0;
                  uVar7 = uStack_2a0._4_4_;
                  puVar13 = auStack_da8;
                  for (iVar16 = 0x91; iVar16 != 0; iVar16 = iVar16 + -1) {
                    *puVar13 = *(undefined4 *)puVar15;
                    puVar15 = (undefined8 *)((int)puVar15 + 4);
                    puVar13 = puVar13 + 1;
                  }
                  uStack_240 = uVar2;
                  uStack_23c = uVar7;
                  uStack_238 = uVar8;
                  uStack_234 = uVar9;
                  uStack_30 = (double)CONCAT44(&uStack_240,0x8408b0);
                  cVar11 = FUN_007ccf30();
                  if (cVar11 == '\0') {
LAB_008408b4:
                    uStack_30 = (double)CONCAT44((int)pfStack_60 + (int)pfStack_38,auStack_5a8);
                    pfStack_34 = (float *)0x8408c7;
                    puVar13 = (undefined4 *)FUN_0083adf0();
LAB_00840adb:
                    puVar21 = (undefined4 *)((int)pfStack_8c + (int)pfStack_38);
                  }
                  else {
                    uStack_30 = (double)CONCAT44(auStack_da8,0x8408de);
                    cVar11 = FUN_007ccbf0();
                    if (cVar11 == '\0') goto LAB_008408b4;
                    fStack_ac = fStack_110;
                    pfStack_a8 = (float *)pfStack_3c[0x4f0b];
                    pfVar19 = (float *)pfStack_3c[0x4f0a];
                    uStack_b8 = CONCAT44(uStack_118,(undefined4)uStack_b8);
                    fStack_b0 = fStack_114;
                    uStack_98 = uStack_98 & 0xffffff00;
                    if (pfVar19 != pfStack_a8) {
                      do {
                        fVar24 = *pfVar19;
                        uStack_30 = (double)CONCAT44((int)fVar24 + 0x18,0x840933);
                        cVar11 = FUN_007ccd20();
                        if (cVar11 != '\0') {
                          if ((char)uStack_98 == '\0') {
                            uStack_30 = (double)CONCAT44((int)fVar24 + 0x18,auStack_a38);
                            pfStack_34 = (float *)0x840951;
                            cVar11 = FUN_00839dc0();
                            uStack_98 = uStack_98 & 0xff;
                            if (cVar11 != '\0') {
                              uStack_98 = 1;
                            }
                          }
                          pfVar22 = pfStack_34;
                          fVar24 = pfVar19[1];
                          if ((int)fVar24 < 0) {
                            pfVar19[1] = (float)(*(int *)((int)pfStack_34 + 0x24) -
                                                 *(int *)((int)pfStack_34 + 0x20) >> 2);
                            puVar3 = *(uint **)((int)pfStack_34 + 0x4f34c);
                            if (*(uint **)((int)pfStack_34 + 0x4f350) == puVar3) {
                              uStack_30 = (double)CONCAT44(&uStack_f0,puVar3);
                              pfStack_34 = (float *)0x8409af;
                              FUN_00805800();
                              uStack_88 = uStack_ec;
                              uStack_84 = uStack_f0;
                            }
                            else {
                              *puVar3 = uStack_84;
                              puVar3[1] = uStack_88;
                              *(int *)((int)pfStack_34 + 0x4f34c) =
                                   *(int *)((int)pfStack_34 + 0x4f34c) + 8;
                            }
                            pfVar14 = *(float **)((int)pfVar22 + 0x24);
                            if (*(float **)((int)pfVar22 + 0x28) == pfVar14) {
                              uStack_30 = (double)CONCAT44(pfVar19,pfVar14);
                              pfStack_34 = (float *)0x8409dd;
                              FUN_006030d0();
                            }
                            else {
                              *pfVar14 = *pfVar19;
                              *(int *)((int)pfVar22 + 0x24) = *(int *)((int)pfVar22 + 0x24) + 4;
                            }
                          }
                          else {
                            iVar16 = *(int *)((int)pfStack_34 + 0x4f348);
                            *(uint *)(iVar16 + (int)fVar24 * 8) =
                                 *(uint *)(iVar16 + (int)fVar24 * 8) | uStack_84;
                            *(uint *)(iVar16 + 4 + (int)fVar24 * 8) =
                                 *(uint *)(iVar16 + 4 + (int)fVar24 * 8) | uStack_88;
                          }
                          uStack_30 = (double)CONCAT44(*pfVar19,0x840a09);
                          FUN_00839a00();
                          uStack_30 = (double)CONCAT44(*pfVar19,0x840a16);
                          FUN_00839a00();
                        }
                        pfVar19 = pfVar19 + 2;
                      } while (pfVar19 != pfStack_a8);
                      if ((char)uStack_98 != '\0') {
                        pfStack_3c[0x4f06] = (float)((uint)pfStack_3c[0x4f06] | uStack_84);
                        pfStack_3c[0x4f07] = (float)((uint)pfStack_3c[0x4f07] | uStack_88);
                      }
                    }
                    iVar16 = (int)pfStack_60 + (int)pfStack_38;
                    uStack_50 = (float *)(CONCAT13((char)uStack_44,(undefined3)uStack_50) ^
                                         0x1000000);
                    uStack_30 = (double)CONCAT44((int)&uStack_b8 + 4,0x840a63);
                    cVar12 = FUN_00839e70();
                    pfVar19 = pfStack_34;
                    cVar11 = uStack_50._3_1_;
                    if (cVar12 == '\0') {
                      cVar11 = '\x01';
                    }
                    if (cVar11 == '\0') {
                      uStack_30 = (double)CONCAT44(iVar16,auStack_5a8);
                      pfStack_34 = (float *)0x840adb;
                      puVar13 = (undefined4 *)FUN_0083ac90();
                      goto LAB_00840adb;
                    }
                    uStack_30 = -NAN;
                    pfStack_34 = (float *)uStack_58._4_4_;
                    puStack_48 = *(undefined8 **)((int)pfVar19 + 500);
                    pfStack_38 = (float *)0x0;
                    pfStack_3c = (float *)(iStack_94 + 0x260);
                    piStack_40 = (int *)0x0;
                    uStack_44 = 0;
                    puStack_4c = auStack_a38;
                    uStack_50 = (float *)((int)&uStack_b8 + 4);
                    uStack_58._4_4_ = auStack_5a8;
                    uStack_58._0_4_ = (float *)0x840ac0;
                    puVar13 = (undefined4 *)FUN_0083ad60();
                    puVar21 = (undefined4 *)((int)pfStack_8c + (int)pfStack_38);
                    piStack_40 = (int *)((int)piStack_40 + 1);
                  }
                  for (iVar16 = 0x9e; iVar16 != 0; iVar16 = iVar16 + -1) {
                    *puVar21 = *puVar13;
                    puVar13 = puVar13 + 1;
                    puVar21 = puVar21 + 1;
                  }
                  puStack_4c = (undefined4 *)((int)puStack_4c + 2);
                  puStack_48 = (undefined8 *)((int)puStack_48 + 1);
                  uVar20 = uVar20 + 1;
                  pfStack_38 = (float *)((int)pfStack_38 + 0x278);
                } while (puStack_4c < &DAT_00000010);
                uStack_90 = uStack_90 + 1;
              } while (uStack_90 < 8);
              uStack_14 = 0xb;
              pfStack_34 = (float *)fStack_a0;
              pfStack_38 = pfStack_a4;
              pfStack_3c = (float *)0x840b51;
              uStack_30 = (double)uStack_138;
              FUN_0152dda0();
              pfVar19 = pfStack_34;
              iVar16 = iStack_94;
            }
            uStack_14 = 0xffffffff;
            pfStack_3c[0x4f0b] = pfStack_3c[0x4f0a];
            if ((int)piStack_40 < 1) {
              uStack_30 = (double)CONCAT44(iVar16,auStack_5a8);
              pfStack_34 = (float *)0x840d1e;
              puVar13 = (undefined4 *)FUN_0083ac90();
            }
            else {
              puStack_48 = *(undefined8 **)((int)pfVar19 + 500);
              uStack_30 = (double)(ulonglong)(uStack_5c + 1);
              pfStack_34 = (float *)uStack_58._4_4_;
              pfStack_38 = (float *)0x0;
              pfStack_3c = (float *)(iVar16 + 0x260);
              uStack_44 = uStack_80._4_4_;
              puStack_4c = auStack_7f0;
              uStack_50 = afStack_fc;
              uStack_58._4_4_ = auStack_5a8;
              uStack_58._0_4_ = (float *)0x840d0c;
              piStack_40 = (int *)(*(int *)((int)pfVar19 + 0x24) - *(int *)((int)pfVar19 + 0x20) >>
                                  2);
              puVar13 = (undefined4 *)FUN_0083ad60();
            }
            for (iVar16 = 0x9e; pfVar19 = pfStack_34, iVar16 != 0; iVar16 = iVar16 + -1) {
              *(float *)uStack_58 = (float)*puVar13;
              puVar13 = puVar13 + 1;
              uStack_58._0_4_ = (float *)uStack_58 + 1;
            }
          }
          uStack_5c = uStack_5c + 1;
        } while (uStack_5c < uStack_74);
      }
      if (3 < uStack_74) {
        ExceptionList = pvStack_1c;
        return (float *)uStack_30;
      }
      uStack_58._0_4_ = (float *)(uStack_74 * 0x278);
      uStack_58._4_4_ = (undefined4 *)(4 - uStack_74);
      do {
        uStack_30 = (double)CONCAT44(*piStack_d8 + (int)(float *)uStack_58,auStack_dd8);
        pfStack_34 = (float *)0x840d78;
        puVar13 = (undefined4 *)FUN_0083adf0();
        piVar10 = piStack_d4;
        puVar21 = auStack_5a8;
        for (iVar16 = 0x9e; iVar16 != 0; iVar16 = iVar16 + -1) {
          *puVar21 = *puVar13;
          puVar13 = puVar13 + 1;
          puVar21 = puVar21 + 1;
        }
        puVar21 = (undefined4 *)(*piVar10 + (int)(float *)uStack_58);
        uStack_58._0_4_ = (float *)((int)(float *)uStack_58 + 0x278);
        uStack_58._4_4_ = (undefined4 *)((int)uStack_58._4_4_ + -1);
        puVar13 = auStack_5a8;
        for (iVar16 = 0x9e; iVar16 != 0; iVar16 = iVar16 + -1) {
          *puVar21 = *puVar13;
          puVar13 = puVar13 + 1;
          puVar21 = puVar21 + 1;
        }
      } while (uStack_58._4_4_ != (undefined4 *)0x0);
      ExceptionList = pvStack_1c;
      return (float *)uStack_30;
    }
    uVar20 = 0;
    do {
      uStack_30 = (double)CONCAT44(*piStack_d8 + uVar20,auStack_1298);
      pfStack_34 = (float *)0x83ff27;
      puVar13 = (undefined4 *)FUN_0083adf0();
      piVar10 = piStack_d4;
      iVar16 = (int)(float *)uStack_30;
      puVar21 = auStack_5a8;
      for (iVar17 = 0x9e; iVar17 != 0; iVar17 = iVar17 + -1) {
        *puVar21 = *puVar13;
        puVar13 = puVar13 + 1;
        puVar21 = puVar21 + 1;
      }
      uVar20 = iVar16 + 0x278;
      uStack_30 = (double)CONCAT44(uStack_30._4_4_,uVar20);
      puVar13 = auStack_5a8;
      puVar21 = (undefined4 *)(*piVar10 + iVar16);
      for (iVar17 = 0x9e; iVar17 != 0; iVar17 = iVar17 + -1) {
        *puVar21 = *puVar13;
        puVar13 = puVar13 + 1;
        puVar21 = puVar21 + 1;
      }
    } while (uVar20 < 0x9e0);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 12833 ; VA 0x0083f8d6 ; FUN_0083f8d6 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __fastcall FUN_0083f8d6(int param_1)

{
  int *piVar1;
  uint *puVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 *puVar5;
  float *pfVar6;
  undefined4 uVar7;
  float fVar8;
  float fVar9;
  undefined4 uVar10;
  bool bVar11;
  void *pvVar12;
  char cVar13;
  char cVar14;
  undefined4 *puVar15;
  int iVar16;
  undefined4 uVar17;
  float *pfVar18;
  int iVar19;
  int iVar20;
  uint uVar21;
  int iVar22;
  uint uVar23;
  uint uVar24;
  int unaff_EBX;
  int unaff_EBP;
  undefined4 *puVar25;
  float10 fVar26;
  float fVar27;
  double dVar28;
  float fVar29;
  undefined8 uVar30;
  
  *(int *)(unaff_EBP + -0x24) = param_1;
  puVar15 = (undefined4 *)(param_1 + 8);
  puVar25 = (undefined4 *)(param_1 + 0x14);
  *(undefined4 **)(unaff_EBP + -200) = puVar15;
  *(undefined4 **)(unaff_EBP + -0xc4) = puVar25;
  if (puVar15 != puVar25) {
    uVar17 = *puVar15;
    *puVar15 = *puVar25;
    *puVar25 = uVar17;
    uVar17 = *(undefined4 *)(param_1 + 0xc);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_1 + 0x18);
    *(undefined4 *)(param_1 + 0x18) = uVar17;
    uVar17 = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_1 + 0x1c);
    *(undefined4 *)(param_1 + 0x1c) = uVar17;
  }
  *(undefined4 *)(param_1 + 0x200) = *(undefined4 *)(param_1 + 0x1fc);
  uVar17 = *(undefined4 *)(param_1 + 0x20);
  *(int *)(unaff_EBP + -0x50) = param_1 + 0x1fc;
  *(undefined4 *)(param_1 + 0x24) = uVar17;
  uVar17 = *(undefined4 *)(unaff_EBX + 8);
  *(undefined4 *)(param_1 + 0x4f34c) = *(undefined4 *)(param_1 + 0x4f348);
  *(int *)(unaff_EBP + -0x48) = param_1 + 0x20;
  puVar15 = (undefined4 *)FUN_0083ce90(unaff_EBP + -0xac0,uVar17,param_1);
  *(undefined4 *)(unaff_EBP + -0x54) = 0;
  uVar17 = *(undefined4 *)(unaff_EBP + -0x54);
  puVar25 = (undefined4 *)(unaff_EBP + -0x220);
  for (iVar19 = 0x24; iVar19 != 0; iVar19 = iVar19 + -1) {
    *puVar25 = *puVar15;
    puVar15 = puVar15 + 1;
    puVar25 = puVar25 + 1;
  }
  *(undefined4 *)(unaff_EBP + -0x288) = uVar17;
  *(undefined8 *)(unaff_EBP + -0x290) = 0;
  *(undefined4 *)(unaff_EBP + -0x284) = 0;
  iVar19 = 6;
  do {
    FUN_00569440();
    iVar19 = iVar19 + -1;
  } while (iVar19 != 0);
  iVar20 = *(int *)(unaff_EBP + -0x24);
  iVar19 = *(int *)(unaff_EBX + 8);
  FUN_0083f1a0(iVar19 + 0x18,*(undefined4 *)(iVar20 + 0x4f360));
  iVar19 = FUN_0083d2e0(iVar19,unaff_EBP + -0x290,unaff_EBP + -0x220,iVar20 + 8,
                        *(undefined *)(iVar19 + 0x26e));
  *(int *)(unaff_EBP + -100) = iVar19;
  if (*(int *)(unaff_EBP + -0x200) == 0) {
    fVar29 = *(float *)(iVar20 + 500);
    *(undefined4 *)(unaff_EBP + -0x60) = *(undefined4 *)(unaff_EBP + -0x220);
    *(undefined4 *)(unaff_EBP + -0x5c) = *(undefined4 *)(unaff_EBP + -0x21c);
    *(undefined4 *)(unaff_EBP + -0x58) = *(undefined4 *)(unaff_EBP + -0x218);
    *(float *)(unaff_EBP + -0x54) = *(float *)(unaff_EBP + -0x214) - fVar29;
    uVar17 = *(undefined4 *)(unaff_EBP + -0x5c);
    uVar7 = *(undefined4 *)(unaff_EBP + -0x58);
    uVar10 = *(undefined4 *)(unaff_EBP + -0x54);
    *(undefined4 *)(iVar20 + 0x4f368) = *(undefined4 *)(unaff_EBP + -0x60);
    *(undefined4 *)(iVar20 + 0x4f36c) = uVar17;
    *(undefined4 *)(iVar20 + 0x4f370) = uVar7;
    *(undefined4 *)(iVar20 + 0x4f374) = uVar10;
    *(float *)(iVar20 + 0x4f374) = *(float *)(iVar20 + 0x4f374) * *(float *)(iVar20 + 0x4f374);
  }
  if (*(int *)(unaff_EBP + -0x1dc) == 0) {
    fVar29 = *(float *)(iVar20 + 500);
    *(undefined4 *)(unaff_EBP + -0x60) = *(undefined4 *)(unaff_EBP + -0x1fc);
    *(undefined4 *)(unaff_EBP + -0x5c) = *(undefined4 *)(unaff_EBP + -0x1f8);
    *(undefined4 *)(unaff_EBP + -0x58) = *(undefined4 *)(unaff_EBP + -500);
    *(float *)(unaff_EBP + -0x54) = *(float *)(unaff_EBP + -0x1f0) - fVar29;
    uVar17 = *(undefined4 *)(unaff_EBP + -0x5c);
    uVar7 = *(undefined4 *)(unaff_EBP + -0x58);
    uVar10 = *(undefined4 *)(unaff_EBP + -0x54);
    *(undefined4 *)(iVar20 + 0x4f378) = *(undefined4 *)(unaff_EBP + -0x60);
    *(undefined4 *)(iVar20 + 0x4f37c) = uVar17;
    *(undefined4 *)(iVar20 + 0x4f380) = uVar7;
    *(undefined4 *)(iVar20 + 0x4f384) = uVar10;
    *(float *)(iVar20 + 0x4f384) = *(float *)(iVar20 + 0x4f384) * *(float *)(iVar20 + 0x4f384);
  }
  if (*(int *)(unaff_EBP + -0x1b8) == 0) {
    fVar29 = *(float *)(iVar20 + 500);
    *(undefined4 *)(unaff_EBP + -0x60) = *(undefined4 *)(unaff_EBP + -0x1d8);
    *(undefined4 *)(unaff_EBP + -0x5c) = *(undefined4 *)(unaff_EBP + -0x1d4);
    *(undefined4 *)(unaff_EBP + -0x58) = *(undefined4 *)(unaff_EBP + -0x1d0);
    *(float *)(unaff_EBP + -0x54) = *(float *)(unaff_EBP + -0x1cc) - fVar29;
    uVar17 = *(undefined4 *)(unaff_EBP + -0x5c);
    uVar7 = *(undefined4 *)(unaff_EBP + -0x58);
    uVar10 = *(undefined4 *)(unaff_EBP + -0x54);
    *(undefined4 *)(iVar20 + 0x4f388) = *(undefined4 *)(unaff_EBP + -0x60);
    *(undefined4 *)(iVar20 + 0x4f38c) = uVar17;
    *(undefined4 *)(iVar20 + 0x4f390) = uVar7;
    *(undefined4 *)(iVar20 + 0x4f394) = uVar10;
    *(float *)(iVar20 + 0x4f394) = *(float *)(iVar20 + 0x4f394) * *(float *)(iVar20 + 0x4f394);
  }
  if (*(int *)(unaff_EBP + -0x194) == 0) {
    fVar29 = *(float *)(iVar20 + 500);
    *(undefined4 *)(unaff_EBP + -0x60) = *(undefined4 *)(unaff_EBP + -0x1b4);
    *(undefined4 *)(unaff_EBP + -0x5c) = *(undefined4 *)(unaff_EBP + -0x1b0);
    *(undefined4 *)(unaff_EBP + -0x58) = *(undefined4 *)(unaff_EBP + -0x1ac);
    *(float *)(unaff_EBP + -0x54) = *(float *)(unaff_EBP + -0x1a8) - fVar29;
    uVar17 = *(undefined4 *)(unaff_EBP + -0x5c);
    uVar7 = *(undefined4 *)(unaff_EBP + -0x58);
    uVar10 = *(undefined4 *)(unaff_EBP + -0x54);
    *(undefined4 *)(iVar20 + 0x4f398) = *(undefined4 *)(unaff_EBP + -0x60);
    *(undefined4 *)(iVar20 + 0x4f39c) = uVar17;
    *(undefined4 *)(iVar20 + 0x4f3a0) = uVar7;
    *(undefined4 *)(iVar20 + 0x4f3a4) = uVar10;
    *(float *)(iVar20 + 0x4f3a4) = *(float *)(iVar20 + 0x4f3a4) * *(float *)(iVar20 + 0x4f3a4);
  }
  iVar16 = 0;
  *(undefined4 *)(unaff_EBP + -0x34) = 0;
  if (iVar19 != 0) {
    iVar16 = 0;
    *(int *)(unaff_EBP + -0x38) = iVar19;
    iVar19 = 0;
    *(undefined4 *)(unaff_EBP + -0x3c) = 0;
    *(undefined4 *)(unaff_EBP + -0x1c) = 0;
    *(int *)(unaff_EBP + -0x30) = unaff_EBP + -0x200;
    do {
      iVar4 = *(int *)(iVar20 + 8);
      *(int *)(unaff_EBP + -0x20) = *(int *)(iVar20 + 0x14) + iVar16;
      iVar22 = **(int **)(unaff_EBP + -0x30);
      if (iVar22 != 0) {
        *(int *)(unaff_EBP + -0x34) = *(int *)(unaff_EBP + -0x34) + 1;
        if (iVar22 == 2) {
          puVar15 = (undefined4 *)FUN_0083ac90();
        }
        else {
          puVar15 = (undefined4 *)FUN_0083adf0(unaff_EBP + -0x598,iVar4 + iVar16);
        }
        puVar25 = *(undefined4 **)(unaff_EBP + -0x20);
        for (iVar19 = 0x9e; iVar19 != 0; iVar19 = iVar19 + -1) {
          *puVar25 = *puVar15;
          puVar15 = puVar15 + 1;
          puVar25 = puVar25 + 1;
        }
        iVar20 = *(int *)(unaff_EBP + -0x24);
        iVar19 = *(int *)(unaff_EBP + -0x1c);
        *(undefined4 *)(iVar19 + 0x13e20 + iVar20) = *(undefined4 *)(iVar19 + 0x13e28 + iVar20);
        *(undefined4 *)(iVar19 + 0x13e24 + iVar20) = *(undefined4 *)(iVar19 + 0x13e2c + iVar20);
        FUN_0170c6f0(iVar20 + 0xa020 + iVar19);
        iVar16 = *(int *)(unaff_EBP + -0x3c);
        *(undefined4 *)(iVar19 + 0x208 + iVar20) = 0;
      }
      *(int *)(unaff_EBP + -0x30) = *(int *)(unaff_EBP + -0x30) + 0x24;
      iVar19 = iVar19 + 0x13c50;
      iVar16 = iVar16 + 0x278;
      *(int *)(unaff_EBP + -0x1c) = iVar19;
      piVar1 = (int *)(unaff_EBP + -0x38);
      *piVar1 = *piVar1 + -1;
      *(int *)(unaff_EBP + -0x3c) = iVar16;
    } while (*piVar1 != 0);
    iVar16 = *(int *)(unaff_EBP + -0x34);
    iVar19 = *(int *)(unaff_EBP + -100);
  }
  if (iVar16 != iVar19) {
    *(undefined4 *)(unaff_EBP + -0x54) = 0;
    cVar13 = '\0';
    *(undefined *)(unaff_EBP + -0x15) = 0;
    *(undefined8 *)(unaff_EBP + -0xa8) = 0;
    *(undefined4 *)(unaff_EBP + -0xa0) = *(undefined4 *)(unaff_EBP + -0x54);
    *(undefined4 *)(unaff_EBP + -0x9c) = 0;
    if (iVar19 != 0) {
      puVar15 = (undefined4 *)(unaff_EBP + -0x214);
      *(int *)(unaff_EBP + -0x20) = iVar19;
      do {
        if (puVar15[5] == 0) {
          uVar7 = puVar15[-3];
          uVar10 = puVar15[-2];
          uVar17 = puVar15[-1];
          if (cVar13 == '\0') {
            *(undefined4 *)(unaff_EBP + -0xd8) = uVar7;
            *(undefined4 *)(unaff_EBP + -0xd4) = uVar10;
            cVar13 = '\x01';
            *(undefined4 *)(unaff_EBP + -0xa8) = *(undefined4 *)(unaff_EBP + -0xd8);
            *(undefined4 *)(unaff_EBP + -0xa4) = *(undefined4 *)(unaff_EBP + -0xd4);
            *(undefined4 *)(unaff_EBP + -0xd0) = uVar17;
            *(undefined4 *)(unaff_EBP + -0xa0) = *(undefined4 *)(unaff_EBP + -0xd0);
            *(undefined4 *)(unaff_EBP + -0x9c) = *puVar15;
            *(undefined *)(unaff_EBP + -0x15) = 1;
          }
          else {
            uVar3 = *puVar15;
            *(undefined4 *)(unaff_EBP + -0xb0) = uVar17;
            *(undefined4 *)(unaff_EBP + -0xb8) = uVar7;
            *(undefined4 *)(unaff_EBP + -0xb4) = uVar10;
            *(undefined4 *)(unaff_EBP + -0xac) = uVar3;
            FUN_01166b40();
            iVar19 = *(int *)(unaff_EBP + -0x20);
            cVar13 = *(char *)(unaff_EBP + -0x15);
          }
        }
        puVar15 = puVar15 + 9;
        iVar19 = iVar19 + -1;
        *(int *)(unaff_EBP + -0x20) = iVar19;
      } while (iVar19 != 0);
    }
    FUN_0083ccd0(unaff_EBP + -400,unaff_EBP + -0xa8,iVar20 + 0x4f354);
    fVar29 = *(float *)(unaff_EBP + -0x9c);
    FUN_0083e330(unaff_EBP + -0x2e0,fVar29,fVar29,fVar29 + DAT_01919494,(uint)fVar29 ^ DAT_018c4ea0)
    ;
    FUN_007cc9d0();
    FUN_007cdb40();
    FUN_007cd560(unaff_EBP + -0x2e0,0);
    iVar19 = FUN_007a8ef0();
    FUN_0083ae90(unaff_EBP + -0x15f8,unaff_EBP + -0x1010,9,iVar19 + 0x12,iVar19 + 0x12);
    iVar19 = *(int *)(unaff_EBX + 8);
    *(undefined *)(unaff_EBP + -0xbc) = *(undefined *)(iVar19 + 0x298);
    cVar13 = *(char *)(iVar19 + 0x29a);
    *(undefined *)(unaff_EBP + -0x15) = *(undefined *)(iVar19 + 0x299);
    *(bool *)(iVar20 + 0x4f364) = cVar13 != '\0';
    if (cVar13 == '\0') {
      *(undefined4 *)(unaff_EBP + -0x8c) = 0;
    }
    else {
      *(float *)(unaff_EBP + -0x8c) = DAT_01919494 - _DAT_01d62258;
    }
    iVar20 = DAT_01eb4518;
    iVar19 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    *(int *)(unaff_EBP + -0xf0) = iVar19;
    if ((*(int *)(iVar19 + 0x34) < iVar20) && (FUN_016f3809(), DAT_01eb4518 == -1)) {
      *(undefined4 *)(unaff_EBP + -4) = 0;
      uVar30 = FUN_0152dab0("Shadows","Get shadow casters",0xffffffff);
      DAT_01eb4514 = (undefined4)((ulonglong)uVar30 >> 0x20);
      DAT_01eb4510 = (undefined4)uVar30;
      *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
      FUN_016f37bf(&DAT_01eb4518);
    }
    uVar7 = DAT_01eb4514;
    uVar17 = DAT_01eb4510;
    *(undefined4 *)(unaff_EBP + -0x14) = DAT_01eb4510;
    *(undefined4 *)(unaff_EBP + -0xb8) = uVar17;
    *(undefined4 *)(unaff_EBP + -0x44) = uVar7;
    *(undefined4 *)(unaff_EBP + -0xb4) = uVar7;
    uVar30 = FUN_0152d930(uVar17,uVar7);
    *(undefined8 *)(unaff_EBP + -0xb0) = uVar30;
    *(undefined4 *)(unaff_EBP + -4) = 1;
    FUN_0083d730(unaff_EBP + -0x15f8,*(undefined4 *)(unaff_EBX + 8),unaff_EBP + -0x220,
                 *(undefined4 *)(unaff_EBP + -100),unaff_EBP + -0x290,
                 *(undefined4 *)(unaff_EBP + -0x50),*(undefined4 *)(unaff_EBP + -0x48),
                 *(undefined4 *)(unaff_EBP + -0xbc));
    *(undefined4 *)(unaff_EBP + -4) = 2;
    FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x44),uVar30);
    *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
    if (**(int **)(unaff_EBP + -0x50) != (*(int **)(unaff_EBP + -0x50))[1]) {
      uVar23 = 0;
      *(undefined4 *)(unaff_EBP + -0x20) = 0;
      *(undefined4 *)(unaff_EBP + -0x4c) = 0;
      if (*(int *)(unaff_EBP + -100) != 0) {
        iVar19 = *(int *)(unaff_EBP + -0x24);
        do {
          iVar20 = *(int *)(iVar19 + 0x14);
          iVar16 = *(int *)(iVar19 + 8);
          *(uint *)(unaff_EBP + -0x2c) = uVar23 * 0x13c50 + iVar19 + 0x208;
          *(uint *)(unaff_EBP + -0x48) = iVar20 + uVar23 * 0x278;
          *(uint *)(unaff_EBP + -0x84) = iVar16 + uVar23 * 0x278;
          iVar20 = *(int *)(unaff_EBP + -0x200 + uVar23 * 0x24);
          puVar15 = (undefined4 *)(unaff_EBP + -0x220 + uVar23 * 0x24);
          *(undefined4 **)(unaff_EBP + -0x38) = puVar15;
          if (iVar20 == 0) {
            uVar17 = FUN_007a8e00();
            fVar29 = (float)puVar15[3];
            *(undefined4 *)(unaff_EBP + -0x44) = uVar17;
            *(undefined4 *)(unaff_EBP + -0x134) = 0x3f800000;
            *(float *)(unaff_EBP + -0x14) = fVar29 * fVar29;
            *(undefined4 *)(unaff_EBP + -0x140) = *puVar15;
            *(undefined4 *)(unaff_EBP + -0x13c) = puVar15[1];
            *(undefined4 *)(unaff_EBP + -0x138) = puVar15[2];
            FUN_01165b90(unaff_EBP + -0x2a0,unaff_EBP + -0x140);
            FUN_011658d0();
            cVar13 = *(char *)(iVar19 + 0x4f364);
            *(undefined8 *)(unaff_EBP + -0x150) = *(undefined8 *)(unaff_EBP + -0x5c);
            *(undefined4 *)(unaff_EBP + -0x144) = *(undefined4 *)(unaff_EBP + -0x14);
            fVar29 = (float)puVar15[3];
            *(undefined4 *)(unaff_EBP + -0x148) = *(undefined4 *)(unaff_EBP + -0x54);
            *(uint *)(unaff_EBP + -0x14) = (uint)fVar29 ^ DAT_018c4ea0;
            fVar27 = DAT_01919494;
            if (cVar13 != '\0') {
              fVar27 = _DAT_01d62258;
            }
            *(float *)(unaff_EBP + -0x1c) = fVar29 + fVar27;
            FUN_0083ccd0(unaff_EBP + -0x2e0,puVar15,iVar19 + 0x4f354);
            FUN_0083e330(unaff_EBP + -800,puVar15[3],puVar15[3],*(undefined4 *)(unaff_EBP + -0x1c),
                         *(undefined4 *)(unaff_EBP + -0x14));
            FUN_007cc9d0();
            FUN_007cdb40();
            FUN_007cd560(unaff_EBP + -800,0);
            iVar20 = FUN_007a8e00();
            iVar20 = iVar20 + 0x12;
            *(int *)(unaff_EBP + -0xc0) = iVar20;
            FUN_0083afb0(unaff_EBP + -0x1258,unaff_EBP + -0x7e0,9,iVar20,iVar20,
                         *(undefined4 *)(unaff_EBP + -0x8c));
            if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                 DAT_01eb4528) && (FUN_016f3809(), DAT_01eb4528 == -1)) {
              *(undefined4 *)(unaff_EBP + -4) = 3;
              uVar30 = FUN_0152dab0("Shadows","Filter cascade casters",0xffffffff);
              DAT_01eb4524 = (undefined4)((ulonglong)uVar30 >> 0x20);
              DAT_01eb4520 = (undefined4)uVar30;
              *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
              FUN_016f37bf(&DAT_01eb4528);
            }
            uVar7 = DAT_01eb4524;
            uVar17 = DAT_01eb4520;
            *(undefined4 *)(unaff_EBP + -0x3c) = DAT_01eb4520;
            *(undefined4 *)(unaff_EBP + -0x120) = uVar17;
            *(undefined4 *)(unaff_EBP + -0x1c) = uVar7;
            *(undefined4 *)(unaff_EBP + -0x11c) = uVar7;
            uVar30 = FUN_0152d930(uVar17,uVar7);
            *(undefined8 *)(unaff_EBP + -0x118) = uVar30;
            *(undefined4 *)(unaff_EBP + -4) = 4;
            if (*(char *)(unaff_EBP + -0x15) == '\0') {
              iVar20 = *(int *)(iVar19 + 0x200);
              iVar19 = *(int *)(iVar19 + 0x1fc);
              *(int *)(unaff_EBP + -0x14) = iVar20;
              if (iVar19 != iVar20) {
                iVar20 = *(int *)(unaff_EBP + -0x2c);
                do {
                  puVar15 = *(undefined4 **)(iVar20 + 0x13c2c);
                  if (*(undefined4 **)(iVar20 + 0x13c30) == puVar15) {
                    FUN_0083b870(puVar15,iVar19 + 0x58);
                  }
                  else {
                    *puVar15 = *(undefined4 *)(iVar19 + 0x58);
                    puVar15[1] = 0xffffffff;
                    *(int *)(iVar20 + 0x13c2c) = *(int *)(iVar20 + 0x13c2c) + 8;
                  }
                  iVar19 = iVar19 + 0x5c;
                } while (iVar19 != *(int *)(unaff_EBP + -0x14));
              }
            }
            else {
              FUN_0083e0d0(unaff_EBP + -0x1258,unaff_EBP + -0x150,iVar19 + 0x1fc,
                           *(int *)(unaff_EBP + -0x2c) + 0x13c28,*(undefined4 *)(unaff_EBP + -0xbc))
              ;
            }
            *(undefined4 *)(unaff_EBP + -4) = 5;
            FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x3c),*(undefined4 *)(unaff_EBP + -0x1c),
                         *(undefined4 *)(unaff_EBP + -0x118),*(undefined4 *)(unaff_EBP + -0x114));
            pvVar12 = ThreadLocalStoragePointer;
            iVar20 = _tls_index;
            iVar19 = DAT_01eb4538;
            *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
            if ((*(int *)(*(int *)((int)pvVar12 + iVar20 * 4) + 0x34) < iVar19) &&
               (FUN_016f3809(), DAT_01eb4538 == -1)) {
              *(undefined4 *)(unaff_EBP + -4) = 6;
              uVar30 = FUN_0152dab0("Shadows","Sort cascade casters",0xffffffff);
              DAT_01eb4534 = (undefined4)((ulonglong)uVar30 >> 0x20);
              DAT_01eb4530 = (undefined4)uVar30;
              *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
              FUN_016f37bf(&DAT_01eb4538);
            }
            uVar7 = DAT_01eb4534;
            uVar17 = DAT_01eb4530;
            *(undefined4 *)(unaff_EBP + -0x1c) = DAT_01eb4530;
            *(undefined4 *)(unaff_EBP + -0xb8) = uVar17;
            *(undefined4 *)(unaff_EBP + -0x14) = uVar7;
            *(undefined4 *)(unaff_EBP + -0xb4) = uVar7;
            uVar30 = FUN_0152d930(uVar17,uVar7);
            *(undefined8 *)(unaff_EBP + -0xb0) = uVar30;
            *(undefined4 *)(unaff_EBP + -4) = 7;
            iVar19 = *(int *)(*(int *)(unaff_EBP + -0x2c) + 0x13c28);
            iVar20 = *(int *)(*(int *)(unaff_EBP + -0x2c) + 0x13c2c);
            FUN_0083bfb0(iVar19,iVar20,iVar20 - iVar19 >> 3,*(undefined4 *)(unaff_EBP + -0x6c));
            *(undefined4 *)(unaff_EBP + -4) = 8;
            FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x14),
                         *(undefined4 *)(unaff_EBP + -0xb0),(int)((ulonglong)uVar30 >> 0x20));
            iVar19 = *(int *)(unaff_EBX + 8);
            *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
            *(double *)(unaff_EBP + -0x70) = (double)(*(float *)(iVar19 + 0x74) / DAT_018f784c);
            fVar26 = (float10)FUN_01725280(*(undefined8 *)(unaff_EBP + -0x70));
            *(double *)(unaff_EBP + -0x70) = (double)fVar26;
            *(float *)(unaff_EBP + -0x14) = (float)*(double *)(unaff_EBP + -0x70) * DAT_018f784c;
            *(double *)(unaff_EBP + -0x70) = (double)(*(float *)(iVar19 + 0x88) / DAT_018f784c);
            fVar26 = (float10)FUN_01725280(*(undefined8 *)(unaff_EBP + -0x70));
            fVar29 = *(float *)(unaff_EBP + -0x14);
            *(double *)(unaff_EBP + -0x70) = (double)fVar26;
            fVar27 = (float)*(double *)(unaff_EBP + -0x70) * DAT_018f784c;
            if (NAN(fVar29) == (fVar29 == 0.0)) {
              *(float *)(unaff_EBP + -0x14) = fVar29;
              iVar19 = *(int *)(unaff_EBP + -0x14);
            }
            else {
              iVar19 = 0;
            }
            if (NAN(fVar27) == (fVar27 == 0.0)) {
              *(float *)(unaff_EBP + -0x14) = fVar27;
              iVar20 = *(int *)(unaff_EBP + -0x14);
            }
            else {
              iVar20 = 0;
            }
            iVar16 = *(int *)(unaff_EBP + -0x24);
            FUN_008399e0(iVar19 + 0x9e3779b9U ^
                         (iVar19 + 0x9e3779b9U >> 2) + iVar20 + iVar19 * 0x40 + 0x2c15e7f9,
                         *(undefined4 *)(iVar16 + 0x1d0));
            *(undefined8 *)(unaff_EBP + -0xec) = *(undefined8 *)(unaff_EBP + -0x108);
            *(undefined4 *)(unaff_EBP + -0xe4) = *(undefined4 *)(unaff_EBP + -0x100);
            pfVar18 = (float *)FUN_01165f10();
            uVar23 = FUN_008363a0();
            fVar29 = DAT_018fd178;
            puVar5 = *(undefined8 **)(unaff_EBP + -0x38);
            uVar21 = (uint)DAT_018c0da0;
            uVar24 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
            uVar30 = *puVar5;
            *(undefined4 *)(unaff_EBP + -0xf4) = *(undefined4 *)(puVar5 + 1);
            iVar19 = *(int *)(unaff_EBP + -0x2c);
            *(undefined8 *)(unaff_EBP + -0xfc) = uVar30;
            dVar28 = (double)(*(float *)(iVar19 + 0x13c44) - *(float *)(unaff_EBP + -0xfc));
            if (((fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                   SUB84(dVar28,0) & uVar21)) ||
                (dVar28 = (double)(*(float *)(iVar19 + 0x13c48) - *(float *)(unaff_EBP + -0xf8)),
                fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                 SUB84(dVar28,0) & uVar21))) ||
               (dVar28 = (double)(*(float *)(iVar19 + 0x13c4c) - *(float *)(unaff_EBP + -0xf4)),
               fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                SUB84(dVar28,0) & uVar21))) {
              uVar17 = *(undefined4 *)(puVar5 + 1);
              *(undefined8 *)(iVar19 + 0x13c44) = *puVar5;
              *(undefined4 *)(iVar19 + 0x13c4c) = uVar17;
              uVar23 = 0;
            }
            fVar27 = pfVar18[1];
            fVar8 = pfVar18[2];
            fVar9 = pfVar18[3];
            pfVar6 = *(float **)(unaff_EBP + -0x2c);
            dVar28 = (double)(pfVar6[0x4f0d] - *pfVar18);
            if (((fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                   SUB84(dVar28,0) & uVar21)) ||
                (dVar28 = (double)(pfVar6[0x4f0e] - fVar27),
                fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                 SUB84(dVar28,0) & uVar21))) ||
               ((dVar28 = (double)(pfVar6[0x4f0f] - fVar8),
                fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                 SUB84(dVar28,0) & uVar21) ||
                (dVar28 = (double)(pfVar6[0x4f10] - fVar9),
                fVar29 < (float)(double)CONCAT44((uint)((ulonglong)dVar28 >> 0x20) & uVar24,
                                                 SUB84(dVar28,0) & uVar21))))) {
              pfVar6[0x4f0d] = *pfVar18;
              pfVar6[0x4f0e] = fVar27;
              pfVar6[0x4f0f] = fVar8;
              pfVar6[0x4f10] = fVar9;
              bVar11 = true;
            }
            else {
              bVar11 = false;
            }
            fVar29 = pfVar6[3];
            fVar27 = *(float *)(puVar5 + 3);
            *(undefined4 *)(unaff_EBP + -0x34) = 0;
            uVar21 = *(uint *)(unaff_EBP + -0x34);
            if (!bVar11) {
              uVar21 = uVar23 & 0xff;
            }
            *(undefined4 *)(unaff_EBP + -0x30) = 0;
            *pfVar6 = fVar29 - fVar27;
            fVar29 = *(float *)(puVar5 + 2);
            fVar27 = *(float *)((int)puVar5 + 0x14);
            fVar8 = *(float *)(puVar5 + 3);
            fVar9 = *(float *)((int)puVar5 + 0x1c);
            *(uint *)(unaff_EBP + -0x34) = uVar21;
            pfVar6[1] = fVar29;
            pfVar6[2] = fVar27;
            pfVar6[3] = fVar8;
            pfVar6[4] = fVar9;
            *(int *)(unaff_EBP + -0x6c) = *(int *)(iVar16 + 0x24) - *(int *)(iVar16 + 0x20) >> 2;
            if (*(int *)(unaff_EBP + -0x4c) == 0) {
              if ((*(int *)(*(int *)(unaff_EBP + -0xf0) + 0x34) < DAT_01eb4558) &&
                 (FUN_016f3809(), DAT_01eb4558 == -1)) {
                *(undefined4 *)(unaff_EBP + -4) = 0xc;
                uVar30 = FUN_0152dab0("Shadows","Fill casters");
                DAT_01eb4554 = (undefined4)((ulonglong)uVar30 >> 0x20);
                DAT_01eb4550 = (undefined4)uVar30;
                *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
                FUN_016f37bf(&DAT_01eb4558);
              }
              uVar7 = DAT_01eb4554;
              uVar17 = DAT_01eb4550;
              *(undefined4 *)(unaff_EBP + -0x98) = DAT_01eb4550;
              *(undefined4 *)(unaff_EBP + -0xd8) = uVar17;
              *(undefined4 *)(unaff_EBP + -0x90) = uVar7;
              *(undefined4 *)(unaff_EBP + -0xd4) = uVar7;
              uVar30 = FUN_0152d930(uVar17);
              *(undefined8 *)(unaff_EBP + -0xd0) = uVar30;
              puVar15 = (undefined4 *)pfVar6[0x4f0b];
              puVar25 = (undefined4 *)pfVar6[0x4f0a];
              *(undefined4 *)(unaff_EBP + -4) = 0xd;
              *(undefined4 **)(unaff_EBP + -0x94) = puVar15;
              if (puVar25 != puVar15) {
                do {
                  puVar15 = *(undefined4 **)(iVar16 + 0x4f34c);
                  *(undefined4 *)(unaff_EBP + -0x110) = 0xffffffff;
                  *(undefined4 *)(unaff_EBP + -0x10c) = 0xffffffff;
                  if (*(undefined4 **)(iVar16 + 0x4f350) == puVar15) {
                    FUN_00805800(puVar15,unaff_EBP + -0x110);
                  }
                  else {
                    *puVar15 = 0xffffffff;
                    puVar15[1] = 0xffffffff;
                    *(int *)(iVar16 + 0x4f34c) = *(int *)(iVar16 + 0x4f34c) + 8;
                  }
                  puVar15 = *(undefined4 **)(iVar16 + 0x24);
                  if (*(undefined4 **)(iVar16 + 0x28) == puVar15) {
                    FUN_006030d0(puVar15,puVar25);
                  }
                  else {
                    *puVar15 = *puVar25;
                    *(int *)(iVar16 + 0x24) = *(int *)(iVar16 + 0x24) + 4;
                  }
                  FUN_00839a00();
                  puVar25 = puVar25 + 2;
                } while (puVar25 != *(undefined4 **)(unaff_EBP + -0x94));
              }
              iVar19 = *(int *)(unaff_EBP + -0x84);
              cVar13 = FUN_00839e70();
              if ((cVar13 == '\0') || (*(char *)(unaff_EBP + -0x34) == '\0')) {
                *(undefined4 *)(unaff_EBP + -0x30) = 1;
              }
              *(undefined4 *)(unaff_EBP + -4) = 0xe;
              FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x98),*(undefined4 *)(unaff_EBP + -0x90),
                           *(undefined4 *)(unaff_EBP + -0xd0));
            }
            else {
              if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
                   DAT_01eb4548) && (FUN_016f3809(), DAT_01eb4548 == -1)) {
                *(undefined4 *)(unaff_EBP + -4) = 9;
                uVar30 = FUN_0152dab0("Shadows","Fill tiled casters");
                DAT_01eb4544 = (undefined4)((ulonglong)uVar30 >> 0x20);
                DAT_01eb4540 = (undefined4)uVar30;
                *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
                FUN_016f37bf(&DAT_01eb4548);
              }
              uVar7 = DAT_01eb4544;
              uVar17 = DAT_01eb4540;
              *(undefined4 *)(unaff_EBP + -0x94) = DAT_01eb4540;
              *(undefined4 *)(unaff_EBP + -0x130) = uVar17;
              *(undefined4 *)(unaff_EBP + -0x90) = uVar7;
              *(undefined4 *)(unaff_EBP + -300) = uVar7;
              uVar30 = FUN_0152d930(uVar17);
              *(undefined8 *)(unaff_EBP + -0x128) = uVar30;
              *(undefined4 *)(unaff_EBP + -4) = 10;
              *(float **)(unaff_EBP + -0x7c) = pfVar6 + 0x2786;
              *(float **)(unaff_EBP + -0x50) = pfVar6 + 6;
              FUN_016e012d(pfVar6 + 0x2786,pfVar6 + 0x4f06,pfVar6 + 6);
              pfVar6[0x4f08] = pfVar6[0x4f06];
              fVar29 = DAT_01919490;
              pfVar6[0x4f09] = pfVar6[0x4f07];
              iVar19 = *(int *)(unaff_EBP + -0xc0);
              pfVar6[0x4f06] = 0.0;
              pfVar6[0x4f07] = 0.0;
              uVar30 = 0x3f8000003f800000;
              fVar29 = fVar29 / (float)((double)iVar19 + (double)(&DAT_018c0d90)[-(iVar19 >> 0x1f)])
              ;
              *(float *)(unaff_EBP + -0x14) = DAT_018ce2f8 - (fVar29 + fVar29);
              uVar17 = FUN_01165f10(2);
              FUN_008394f0(unaff_EBP + -0x7e0,uVar17,uVar30);
              uVar30 = CONCAT44(*(undefined4 *)(unaff_EBP + -0x14),
                                *(undefined4 *)(unaff_EBP + -0x14));
              uVar17 = FUN_01165f10(2);
              FUN_008394f0(unaff_EBP + -0x7e0,uVar17,uVar30);
              uVar23 = 0;
              iVar19 = 0;
              *(undefined4 *)(unaff_EBP + -0x80) = 0;
              *(undefined4 *)(unaff_EBP + -0x1c) = 0;
              do {
                iVar20 = 0;
                *(int *)(unaff_EBP + -0x28) = iVar19;
                uVar23 = uVar23 * 8;
                *(undefined4 *)(unaff_EBP + -0x38) = 0;
                *(undefined4 *)(unaff_EBP + -0x3c) = 0;
                *(uint *)(unaff_EBP + -0x14) = uVar23;
                do {
                  uVar21 = 1 << (uVar23 & 0x1f);
                  uVar24 = 0;
                  if (0x1f < uVar23) {
                    uVar24 = uVar21;
                  }
                  uVar21 = uVar21 ^ uVar24;
                  *(uint *)(unaff_EBP + -0x74) = uVar21;
                  if (0x3f < uVar23) {
                    uVar24 = uVar21;
                  }
                  *(uint *)(unaff_EBP + -0xe0) = uVar21;
                  *(uint *)(unaff_EBP + -0x78) = uVar24;
                  *(uint *)(unaff_EBP + -0xdc) = uVar24;
                  FUN_007cc9d0();
                  FUN_007cc9d0();
                  fVar29 = DAT_018fde90;
                  if (DAT_01d61044 == '\0') {
                    *(undefined4 *)(unaff_EBP + -0x170) = *(undefined4 *)(unaff_EBP + -0x764);
                    *(undefined4 *)(unaff_EBP + -0x16c) = *(undefined4 *)(unaff_EBP + -0x760);
                    *(undefined4 *)(unaff_EBP + -0x168) = *(undefined4 *)(unaff_EBP + -0x75c);
                    *(undefined4 *)(unaff_EBP + -0x164) = *(undefined4 *)(unaff_EBP + -0x758);
                    *(undefined4 *)(unaff_EBP + -0x160) = *(undefined4 *)(unaff_EBP + -0x754);
                    *(undefined4 *)(unaff_EBP + -0x15c) = *(undefined4 *)(unaff_EBP + -0x750);
                    *(undefined4 *)(unaff_EBP + -0x158) = *(undefined4 *)(unaff_EBP + -0x74c);
                    *(undefined4 *)(unaff_EBP + -0x154) = *(undefined4 *)(unaff_EBP + -0x748);
                    *(undefined4 *)(unaff_EBP + -400) = *(undefined4 *)(unaff_EBP + -0x784);
                    *(undefined4 *)(unaff_EBP + -0x18c) = *(undefined4 *)(unaff_EBP + -0x780);
                    *(undefined4 *)(unaff_EBP + -0x188) = *(undefined4 *)(unaff_EBP + -0x77c);
                    *(float *)(unaff_EBP + -0x184) = *(float *)(unaff_EBP + -0x778);
                    *(undefined4 *)(unaff_EBP + -0x180) = *(undefined4 *)(unaff_EBP + -0x774);
                    *(undefined4 *)(unaff_EBP + -0x17c) = *(undefined4 *)(unaff_EBP + -0x770);
                    *(undefined4 *)(unaff_EBP + -0x178) = *(undefined4 *)(unaff_EBP + -0x76c);
                    *(float *)(unaff_EBP + -0x174) = *(float *)(unaff_EBP + -0x768);
                    *(float *)(unaff_EBP + -0x184) =
                         (fVar29 - (float)*(int *)(unaff_EBP + -0x3c)) +
                         *(float *)(unaff_EBP + -0x778);
                    fVar27 = DAT_018fde90 - (float)*(int *)(unaff_EBP + -0x1c);
                    *(float *)(unaff_EBP + -400) = *(float *)(unaff_EBP + -400) * _DAT_0191948c;
                    fVar29 = *(float *)(unaff_EBP + -0x17c) * _DAT_0191948c;
                    *(float *)(unaff_EBP + -0x174) = *(float *)(unaff_EBP + -0x768) - fVar27;
                    *(float *)(unaff_EBP + -0x17c) = fVar29;
                    FUN_007cdc00(unaff_EBP + -0x7c4,unaff_EBP + -400);
                    puVar15 = (undefined4 *)
                              FUN_0083afb0(unaff_EBP + -0x564,unaff_EBP + -0xa28,9,
                                           *(undefined4 *)(unaff_EBP + -0xc0),
                                           *(undefined4 *)(unaff_EBP + -0xc0));
                  }
                  else {
                    FUN_0083c4b0(unaff_EBP + -0xb50,iVar20,*(undefined4 *)(unaff_EBP + -0x80));
                    uVar17 = *(undefined4 *)(unaff_EBP + -0x80);
                    uVar7 = *(undefined4 *)(unaff_EBP + -0x38);
                    puVar15 = (undefined4 *)(unaff_EBP + -0x564);
                    puVar25 = (undefined4 *)(unaff_EBP + -0xa28);
                    for (iVar19 = 0x91; iVar19 != 0; iVar19 = iVar19 + -1) {
                      *puVar25 = *puVar15;
                      puVar15 = puVar15 + 1;
                      puVar25 = puVar25 + 1;
                    }
                    FUN_0083c4b0(unaff_EBP + -0x13b0,uVar7,uVar17);
                    puVar15 = (undefined4 *)(unaff_EBP + -0x564);
                  }
                  uVar17 = *(undefined4 *)(unaff_EBP + -0x290);
                  uVar7 = *(undefined4 *)(unaff_EBP + -0x28c);
                  uVar10 = *(undefined4 *)(unaff_EBP + -0x288);
                  uVar3 = *(undefined4 *)(unaff_EBP + -0x284);
                  puVar25 = (undefined4 *)(unaff_EBP + -0xd98);
                  for (iVar19 = 0x91; iVar19 != 0; iVar19 = iVar19 + -1) {
                    *puVar25 = *puVar15;
                    puVar15 = puVar15 + 1;
                    puVar25 = puVar25 + 1;
                  }
                  *(undefined4 *)(unaff_EBP + -0x230) = uVar17;
                  *(undefined4 *)(unaff_EBP + -0x22c) = uVar7;
                  *(undefined4 *)(unaff_EBP + -0x228) = uVar10;
                  *(undefined4 *)(unaff_EBP + -0x224) = uVar3;
                  cVar13 = FUN_007ccf30();
                  if ((cVar13 == '\0') || (cVar13 = FUN_007ccbf0(), cVar13 == '\0')) {
                    puVar15 = (undefined4 *)FUN_0083adf0();
LAB_00840adb:
                    puVar25 = (undefined4 *)
                              (*(int *)(unaff_EBP + -0x7c) + *(int *)(unaff_EBP + -0x28));
                  }
                  else {
                    *(undefined4 *)(unaff_EBP + -0x9c) = *(undefined4 *)(unaff_EBP + -0x100);
                    puVar15 = *(undefined4 **)(*(int *)(unaff_EBP + -0x2c) + 0x13c2c);
                    puVar25 = *(undefined4 **)(*(int *)(unaff_EBP + -0x2c) + 0x13c28);
                    *(undefined4 *)(unaff_EBP + -0xa4) = *(undefined4 *)(unaff_EBP + -0x108);
                    *(undefined4 *)(unaff_EBP + -0xa0) = *(undefined4 *)(unaff_EBP + -0x104);
                    *(undefined *)(unaff_EBP + -0x88) = 0;
                    *(undefined4 **)(unaff_EBP + -0x98) = puVar15;
                    if (puVar25 != puVar15) {
                      do {
                        cVar13 = FUN_007ccd20();
                        if (cVar13 != '\0') {
                          if (*(char *)(unaff_EBP + -0x88) == '\0') {
                            cVar13 = FUN_00839dc0(unaff_EBP + -0xa28);
                            uVar23 = *(uint *)(unaff_EBP + -0x88) & 0xff;
                            if (cVar13 != '\0') {
                              uVar23 = 1;
                            }
                            *(uint *)(unaff_EBP + -0x88) = uVar23;
                          }
                          iVar19 = puVar25[1];
                          if (iVar19 < 0) {
                            iVar19 = *(int *)(unaff_EBP + -0x24);
                            puVar25[1] = *(int *)(iVar19 + 0x24) - *(int *)(iVar19 + 0x20) >> 2;
                            puVar15 = *(undefined4 **)(iVar19 + 0x4f34c);
                            if (*(undefined4 **)(iVar19 + 0x4f350) == puVar15) {
                              FUN_00805800(puVar15,unaff_EBP + -0xe0);
                              *(undefined4 *)(unaff_EBP + -0x78) =
                                   *(undefined4 *)(unaff_EBP + -0xdc);
                              *(undefined4 *)(unaff_EBP + -0x74) =
                                   *(undefined4 *)(unaff_EBP + -0xe0);
                            }
                            else {
                              *puVar15 = *(undefined4 *)(unaff_EBP + -0x74);
                              puVar15[1] = *(undefined4 *)(unaff_EBP + -0x78);
                              *(int *)(iVar19 + 0x4f34c) = *(int *)(iVar19 + 0x4f34c) + 8;
                            }
                            puVar15 = *(undefined4 **)(iVar19 + 0x24);
                            if (*(undefined4 **)(iVar19 + 0x28) == puVar15) {
                              FUN_006030d0(puVar15,puVar25);
                            }
                            else {
                              *puVar15 = *puVar25;
                              *(int *)(iVar19 + 0x24) = *(int *)(iVar19 + 0x24) + 4;
                            }
                          }
                          else {
                            iVar20 = *(int *)(*(int *)(unaff_EBP + -0x24) + 0x4f348);
                            uVar23 = *(uint *)(unaff_EBP + -0x78);
                            *(uint *)(iVar20 + iVar19 * 8) =
                                 *(uint *)(iVar20 + iVar19 * 8) | *(uint *)(unaff_EBP + -0x74);
                            *(uint *)(iVar20 + 4 + iVar19 * 8) =
                                 *(uint *)(iVar20 + 4 + iVar19 * 8) | uVar23;
                          }
                          FUN_00839a00();
                          FUN_00839a00();
                        }
                        puVar25 = puVar25 + 2;
                      } while (puVar25 != *(undefined4 **)(unaff_EBP + -0x98));
                      if (*(char *)(unaff_EBP + -0x88) != '\0') {
                        iVar19 = *(int *)(unaff_EBP + -0x2c);
                        puVar2 = (uint *)(iVar19 + 0x13c18);
                        *puVar2 = *puVar2 | *(uint *)(unaff_EBP + -0x74);
                        puVar2 = (uint *)(iVar19 + 0x13c1c);
                        *puVar2 = *puVar2 | *(uint *)(unaff_EBP + -0x78);
                      }
                    }
                    *(byte *)(unaff_EBP + -0x3d) = *(byte *)(unaff_EBP + -0x34) ^ 1;
                    cVar14 = FUN_00839e70();
                    cVar13 = *(char *)(unaff_EBP + -0x3d);
                    if (cVar14 == '\0') {
                      cVar13 = '\x01';
                    }
                    if (cVar13 == '\0') {
                      puVar15 = (undefined4 *)FUN_0083ac90();
                      goto LAB_00840adb;
                    }
                    puVar15 = (undefined4 *)
                              FUN_0083ad60(unaff_EBP + -0x598,unaff_EBP + -0xa4,unaff_EBP + -0xa28,
                                           *(undefined4 *)(*(int *)(unaff_EBP + -0x24) + 500),0,0,
                                           *(int *)(unaff_EBP + -0x84) + 0x260,0,
                                           *(undefined4 *)(unaff_EBP + -0x44));
                    puVar25 = (undefined4 *)
                              (*(int *)(unaff_EBP + -0x7c) + *(int *)(unaff_EBP + -0x28));
                    *(int *)(unaff_EBP + -0x30) = *(int *)(unaff_EBP + -0x30) + 1;
                  }
                  iVar19 = *(int *)(unaff_EBP + -0x3c);
                  for (iVar20 = 0x9e; iVar20 != 0; iVar20 = iVar20 + -1) {
                    *puVar25 = *puVar15;
                    puVar15 = puVar15 + 1;
                    puVar25 = puVar25 + 1;
                  }
                  uVar21 = iVar19 + 2;
                  iVar20 = *(int *)(unaff_EBP + -0x38) + 1;
                  uVar23 = *(int *)(unaff_EBP + -0x14) + 1;
                  iVar19 = *(int *)(unaff_EBP + -0x28) + 0x278;
                  *(int *)(unaff_EBP + -0x38) = iVar20;
                  *(uint *)(unaff_EBP + -0x14) = uVar23;
                  *(int *)(unaff_EBP + -0x28) = iVar19;
                  *(uint *)(unaff_EBP + -0x3c) = uVar21;
                } while (uVar21 < 0x10);
                *(int *)(unaff_EBP + -0x1c) = *(int *)(unaff_EBP + -0x1c) + 2;
                uVar23 = *(int *)(unaff_EBP + -0x80) + 1;
                *(uint *)(unaff_EBP + -0x80) = uVar23;
              } while (uVar23 < 8);
              *(undefined4 *)(unaff_EBP + -4) = 0xb;
              FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x94),*(undefined4 *)(unaff_EBP + -0x90),
                           *(undefined4 *)(unaff_EBP + -0x128));
              iVar16 = *(int *)(unaff_EBP + -0x24);
              iVar19 = *(int *)(unaff_EBP + -0x84);
            }
            *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
            *(undefined4 *)(*(int *)(unaff_EBP + -0x2c) + 0x13c2c) =
                 *(undefined4 *)(*(int *)(unaff_EBP + -0x2c) + 0x13c28);
            iVar20 = *(int *)(iVar16 + 0x24);
            iVar4 = *(int *)(iVar16 + 0x20);
            if (*(int *)(unaff_EBP + -0x30) < 1) {
              puVar15 = (undefined4 *)FUN_0083ac90(unaff_EBP + -0x598);
            }
            else {
              uVar17 = *(undefined4 *)(iVar16 + 500);
              *(int *)(unaff_EBP + -0x20) = *(int *)(unaff_EBP + -0x20) + 1;
              puVar15 = (undefined4 *)
                        FUN_0083ad60(unaff_EBP + -0x598,unaff_EBP + -0xec,unaff_EBP + -0x7e0,uVar17,
                                     *(undefined4 *)(unaff_EBP + -0x6c),iVar20 - iVar4 >> 2,
                                     iVar19 + 0x260,0,*(undefined4 *)(unaff_EBP + -0x44),
                                     *(undefined4 *)(unaff_EBP + -0x4c));
            }
            puVar25 = *(undefined4 **)(unaff_EBP + -0x48);
            for (iVar19 = 0x9e; iVar19 != 0; iVar19 = iVar19 + -1) {
              *puVar25 = *puVar15;
              puVar15 = puVar15 + 1;
              puVar25 = puVar25 + 1;
            }
            uVar23 = *(uint *)(unaff_EBP + -0x4c);
            iVar19 = *(int *)(unaff_EBP + -0x24);
          }
          uVar23 = uVar23 + 1;
          *(uint *)(unaff_EBP + -0x4c) = uVar23;
        } while (uVar23 < *(uint *)(unaff_EBP + -100));
      }
      uVar23 = *(uint *)(unaff_EBP + -100);
      if (uVar23 < 4) {
        iVar19 = uVar23 * 0x278;
        *(uint *)(unaff_EBP + -0x44) = 4 - uVar23;
        *(int *)(unaff_EBP + -0x48) = iVar19;
        do {
          puVar15 = (undefined4 *)
                    FUN_0083adf0(unaff_EBP + -0xdc8,**(int **)(unaff_EBP + -200) + iVar19);
          iVar20 = *(int *)(unaff_EBP + -0x48);
          piVar1 = *(int **)(unaff_EBP + -0xc4);
          puVar25 = (undefined4 *)(unaff_EBP + -0x598);
          for (iVar19 = 0x9e; iVar19 != 0; iVar19 = iVar19 + -1) {
            *puVar25 = *puVar15;
            puVar15 = puVar15 + 1;
            puVar25 = puVar25 + 1;
          }
          iVar4 = *piVar1;
          iVar19 = iVar20 + 0x278;
          piVar1 = (int *)(unaff_EBP + -0x44);
          *piVar1 = *piVar1 + -1;
          iVar16 = *piVar1;
          puVar15 = (undefined4 *)(unaff_EBP + -0x598);
          puVar25 = (undefined4 *)(iVar4 + iVar20);
          for (iVar22 = 0x9e; iVar22 != 0; iVar22 = iVar22 + -1) {
            *puVar25 = *puVar15;
            puVar15 = puVar15 + 1;
            puVar25 = puVar25 + 1;
          }
          *(int *)(unaff_EBP + -0x48) = iVar19;
        } while (iVar16 != 0);
      }
      uVar17 = *(undefined4 *)(unaff_EBP + -0x20);
      goto LAB_00840db6;
    }
    uVar23 = 0;
    *(undefined4 *)(unaff_EBP + -0x20) = 0;
    do {
      puVar15 = (undefined4 *)
                FUN_0083adf0(unaff_EBP + -0x1288,**(int **)(unaff_EBP + -200) + uVar23);
      iVar19 = *(int *)(unaff_EBP + -0x20);
      piVar1 = *(int **)(unaff_EBP + -0xc4);
      puVar25 = (undefined4 *)(unaff_EBP + -0x598);
      for (iVar20 = 0x9e; iVar20 != 0; iVar20 = iVar20 + -1) {
        *puVar25 = *puVar15;
        puVar15 = puVar15 + 1;
        puVar25 = puVar25 + 1;
      }
      iVar20 = *piVar1;
      uVar23 = iVar19 + 0x278;
      *(uint *)(unaff_EBP + -0x20) = uVar23;
      puVar15 = (undefined4 *)(unaff_EBP + -0x598);
      puVar25 = (undefined4 *)(iVar20 + iVar19);
      for (iVar16 = 0x9e; iVar16 != 0; iVar16 = iVar16 + -1) {
        *puVar25 = *puVar15;
        puVar15 = puVar15 + 1;
        puVar25 = puVar25 + 1;
      }
    } while (uVar23 < 0x9e0);
  }
  uVar17 = 0;
LAB_00840db6:
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return uVar17;
}



/* FUNCTION 12834 ; VA 0x00840f80 ; FUN_00840f80 */

void __thiscall FUN_00840f80(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x4f36c);
  uVar2 = *(undefined4 *)(param_1 + 0x4f370);
  uVar3 = *(undefined4 *)(param_1 + 0x4f374);
  *(undefined4 *)(param_2 + 0x290) = *(undefined4 *)(param_1 + 0x4f368);
  *(undefined4 *)(param_2 + 0x294) = uVar1;
  *(undefined4 *)(param_2 + 0x298) = uVar2;
  *(undefined4 *)(param_2 + 0x29c) = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x4f37c);
  uVar2 = *(undefined4 *)(param_1 + 0x4f380);
  uVar3 = *(undefined4 *)(param_1 + 0x4f384);
  *(undefined4 *)(param_2 + 0x2a0) = *(undefined4 *)(param_1 + 0x4f378);
  *(undefined4 *)(param_2 + 0x2a4) = uVar1;
  *(undefined4 *)(param_2 + 0x2a8) = uVar2;
  *(undefined4 *)(param_2 + 0x2ac) = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x4f38c);
  uVar2 = *(undefined4 *)(param_1 + 0x4f390);
  uVar3 = *(undefined4 *)(param_1 + 0x4f394);
  *(undefined4 *)(param_2 + 0x2b0) = *(undefined4 *)(param_1 + 0x4f388);
  *(undefined4 *)(param_2 + 0x2b4) = uVar1;
  *(undefined4 *)(param_2 + 0x2b8) = uVar2;
  *(undefined4 *)(param_2 + 700) = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x4f39c);
  uVar2 = *(undefined4 *)(param_1 + 0x4f3a0);
  uVar3 = *(undefined4 *)(param_1 + 0x4f3a4);
  *(undefined4 *)(param_2 + 0x2c0) = *(undefined4 *)(param_1 + 0x4f398);
  *(undefined4 *)(param_2 + 0x2c4) = uVar1;
  *(undefined4 *)(param_2 + 0x2c8) = uVar2;
  *(undefined4 *)(param_2 + 0x2cc) = uVar3;
  return;
}



/* FUNCTION 12835 ; VA 0x00840fd0 ; FUN_00840fd0 */

void __fastcall FUN_00840fd0(int param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x3c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x4f354);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x4f358);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x4f35c);
  *(undefined4 *)(param_1 + 0x38) = 0;
  return;
}



/* FUNCTION 12836 ; VA 0x00841020 ; FUN_00841020 */

undefined4 * __thiscall FUN_00841020(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  param_1[2] = param_2;
  param_1[3] = param_3;
  *param_1 = RBX::Graphics::CullableSceneNode::vftable;
  param_1[1] = 0;
  param_1[4] = 1;
  param_1[5] = 0;
  param_1[6] = 0x7f7fffff;
  param_1[7] = 0x7f7fffff;
  param_1[8] = 0x7f7fffff;
  param_1[9] = 0xff7fffff;
  param_1[10] = 0xff7fffff;
  param_1[0xb] = 0xff7fffff;
  param_1[0xc] = 0xffffffff;
  param_1[0xd] = 0;
  return param_1;
}



/* FUNCTION 12837 ; VA 0x00841090 ; FUN_00841090 */

void __fastcall FUN_00841090(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::CullableSceneNode::vftable;
  FUN_00816e60(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12838 ; VA 0x008410d0 ; FUN_008410d0 */

undefined4 * __thiscall FUN_008410d0(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::CullableSceneNode::vftable;
  uStack_8 = 0;
  FUN_00816e60(param_1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12839 ; VA 0x00841130 ; FUN_00841130 */

bool __fastcall FUN_00841130(int param_1)

{
  float10 fVar1;
  
  if (DAT_01d60f68 != '\0') {
    return false;
  }
  if (((*(float *)(param_1 + 0x18) < *(float *)(param_1 + 0x24) ||
        *(float *)(param_1 + 0x18) == *(float *)(param_1 + 0x24)) &&
      (*(float *)(param_1 + 0x1c) < *(float *)(param_1 + 0x28) ||
       *(float *)(param_1 + 0x1c) == *(float *)(param_1 + 0x28))) &&
     (*(float *)(param_1 + 0x20) < *(float *)(param_1 + 0x2c) ||
      *(float *)(param_1 + 0x20) == *(float *)(param_1 + 0x2c))) {
    FUN_01155a30(*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14),1);
    fVar1 = (float10)FUN_00cb93b0();
    return (float)fVar1 < *(float *)(param_1 + 0x14);
  }
  return true;
}



/* FUNCTION 12840 ; VA 0x008411b0 ; FUN_008411b0 */

void __thiscall FUN_008411b0(int param_1,float *param_2,int param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = param_2[1];
  fVar2 = param_2[2];
  fVar3 = param_2[3];
  *(float *)(param_1 + 0x18) = *param_2;
  *(float *)(param_1 + 0x1c) = fVar1;
  *(float *)(param_1 + 0x20) = fVar2;
  *(float *)(param_1 + 0x24) = fVar3;
  *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(param_2 + 4);
  if (param_3 != *(int *)(param_1 + 4)) {
    *(int *)(param_1 + 0x34) = param_3;
  }
  if (((*param_2 <= param_2[3]) && (param_2[1] <= param_2[4])) && (param_2[2] <= param_2[5])) {
    FUN_00816ee0(param_1);
    return;
  }
  FUN_00816e60(param_1);
  return;
}



/* FUNCTION 12841 ; VA 0x00841220 ; FUN_00841220 */

undefined4 * __thiscall
FUN_00841220(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 param_6,undefined param_7,undefined4 param_8)

{
  int *piVar1;
  
  param_1[1] = param_2;
  param_1[2] = param_6;
  *(undefined *)(param_1 + 3) = param_7;
  *param_1 = RBX::Graphics::RenderEntity::vftable;
  param_1[4] = param_8;
  param_1[5] = 0;
  param_1[6] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[5] = *param_3;
  param_1[6] = param_3[1];
  param_1[7] = param_3[2];
  param_1[8] = param_3[3];
  param_1[9] = param_3[4];
  param_1[10] = param_3[5];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xb] = *param_4;
  param_1[0xc] = param_4[1];
  param_1[0xd] = param_4[2];
  param_1[0xe] = param_4[3];
  param_1[0xf] = param_4[4];
  param_1[0x10] = param_4[5];
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x11] = *param_5;
  param_1[0x12] = param_5[1];
  return param_1;
}



/* FUNCTION 12842 ; VA 0x00841300 ; FUN_00841300 */

undefined4 * __thiscall FUN_00841300(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00841020(param_2,param_3);
  *param_1 = RBX::Graphics::RenderNode::vftable;
  param_1[0x11] = 0x3f800000;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0x3f800000;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0x3f800000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  return param_1;
}



/* FUNCTION 12843 ; VA 0x00841390 ; FUN_00841390 */

void __fastcall FUN_00841390(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Graphics::RenderEntity::vftable;
  piVar2 = (int *)param_1[0x12];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007f6360();
  return;
}



/* FUNCTION 12844 ; VA 0x00841420 ; FUN_00841420 */

void __fastcall FUN_00841420(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = 0;
  *param_1 = RBX::Graphics::RenderNode::vftable;
  iVar2 = param_1[0xe];
  if (param_1[0xf] - iVar2 >> 2 != 0) {
    do {
      puVar1 = *(undefined4 **)(iVar2 + uVar4 * 4);
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
      uVar4 = uVar4 + 1;
      iVar2 = param_1[0xe];
    } while (uVar4 < (uint)(param_1[0xf] - iVar2 >> 2));
  }
  if (iVar2 != 0) {
    uVar4 = param_1[0x10] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0xe] = 0;
    param_1[0xf] = 0;
    param_1[0x10] = 0;
  }
  FUN_00841090();
  return;
}



/* FUNCTION 12845 ; VA 0x008414c0 ; FUN_008414c0 */

undefined4 * __thiscall FUN_008414c0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Graphics::RenderEntity::vftable;
  piVar2 = (int *)param_1[0x12];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[6];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007f6360();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 12846 ; VA 0x00841570 ; FUN_00841570 */

undefined4 * __thiscall FUN_00841570(undefined4 *param_1,byte param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = 0;
  *param_1 = RBX::Graphics::RenderNode::vftable;
  iVar2 = param_1[0xe];
  if (param_1[0xf] - iVar2 >> 2 != 0) {
    do {
      puVar1 = *(undefined4 **)(iVar2 + uVar4 * 4);
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
      uVar4 = uVar4 + 1;
      iVar2 = param_1[0xe];
    } while (uVar4 < (uint)(param_1[0xf] - iVar2 >> 2));
  }
  if (iVar2 != 0) {
    uVar4 = param_1[0x10] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0xe] = 0;
    param_1[0xf] = 0;
    param_1[0x10] = 0;
  }
  FUN_00841090();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x74);
  }
  return param_1;
}



/* FUNCTION 12847 ; VA 0x00841620 ; FUN_00841620 */

void __thiscall FUN_00841620(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x3c);
  if (*(undefined4 **)(param_1 + 0x40) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 12848 ; VA 0x00841650 ; FUN_00841650 */

float10 FUN_00841650(float *param_1,float *param_2,float param_3)

{
  char cVar1;
  
  param_3 = (param_2[1] - param_1[1]) * param_1[5] + (*param_2 - *param_1) * param_1[4] +
            (param_2[2] - param_1[2]) * param_1[6] + param_3;
  cVar1 = FUN_00c94350(param_3);
  if (cVar1 != '\0') {
    return (float10)0.0;
  }
  return (float10)param_3;
}



/* FUNCTION 12849 ; VA 0x008416d0 ; FUN_008416d0 */

void FUN_008416d0(undefined4 param_1,float *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar1 = (undefined4 *)FUN_0115ee70();
  uStack_8 = FUN_0078af00();
  if (((*param_2 < param_2[3] || *param_2 == param_2[3]) &&
      (param_2[1] < param_2[4] || param_2[1] == param_2[4])) &&
     (param_2[2] < param_2[5] || param_2[2] == param_2[5])) {
    puVar2 = &DAT_019194d4;
    do {
      FUN_00c9f1c0(&uStack_20,puVar2[-1]);
      FUN_00c9f1c0(&uStack_14,*puVar2);
      uStack_30 = *puVar1;
      uStack_2c = puVar1[1];
      uStack_28 = puVar1[2];
      uStack_24 = 0x3f800000;
      FUN_007f92d0(uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,&uStack_30);
      puVar2 = puVar2 + 2;
    } while ((int)puVar2 < 0x1919534);
  }
  return;
}



/* FUNCTION 12850 ; VA 0x008417d0 ; FUN_008417d0 */

void FUN_008417d0(undefined4 param_1,float *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = FUN_0078af00();
  if (((*param_2 < param_2[3] || *param_2 == param_2[3]) &&
      (param_2[1] < param_2[4] || param_2[1] == param_2[4])) &&
     (param_2[2] < param_2[5] || param_2[2] == param_2[5])) {
    puVar1 = &DAT_019194d4;
    do {
      FUN_00c9f1c0(&uStack_20,puVar1[-1]);
      FUN_00c9f1c0(&uStack_14,*puVar1);
      uStack_30 = *param_3;
      uStack_2c = param_3[1];
      uStack_28 = param_3[2];
      uStack_24 = 0x3f800000;
      FUN_007f92d0(uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,&uStack_30);
      puVar1 = puVar1 + 2;
    } while ((int)puVar1 < 0x1919534);
  }
  return;
}



/* FUNCTION 12851 ; VA 0x008418d0 ; FUN_008418d0 */

uint FUN_008418d0(uint param_1)

{
  uint uVar1;
  
  uVar1 = (param_1 >> 0x17 & 0xff) - 0x82;
  return (int)-uVar1 >> 0x1f & ~((int)param_1 >> 0x1f) & uVar1;
}



/* FUNCTION 12852 ; VA 0x00841900 ; FUN_00841900 */

float10 __fastcall FUN_00841900(int param_1)

{
  int iVar1;
  float fVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  iVar1 = *(int *)(param_1 + 4);
  fVar5 = *(float *)(iVar1 + 0x28) - *(float *)(iVar1 + 0x1c);
  fVar7 = *(float *)(iVar1 + 0x24) - *(float *)(iVar1 + 0x18);
  fVar6 = *(float *)(iVar1 + 0x2c) - *(float *)(iVar1 + 0x20);
  fVar4 = *(float *)(iVar1 + 0x6c) -
          (*(float *)(iVar1 + 0x1c) + *(float *)(iVar1 + 0x28)) * DAT_018ce2f4;
  fVar8 = *(float *)(iVar1 + 0x68) -
          (*(float *)(iVar1 + 0x18) + *(float *)(iVar1 + 0x24)) * DAT_018ce2f4;
  fVar2 = *(float *)(iVar1 + 0x70) -
          (*(float *)(iVar1 + 0x20) + *(float *)(iVar1 + 0x2c)) * DAT_018ce2f4;
  dVar3 = (double)(fVar5 * fVar5 + fVar7 * fVar7 + fVar6 * fVar6);
  FUN_017267a0();
  fVar5 = (float)dVar3 * DAT_018ce2f4;
  dVar3 = (double)(fVar4 * fVar4 + fVar8 * fVar8 + fVar2 * fVar2);
  FUN_017267a0();
  return (float10)(fVar5 + (float)dVar3);
}



/* FUNCTION 12853 ; VA 0x00841a20 ; FUN_00841a20 */

float10 __thiscall FUN_00841a20(int param_1,float *param_2)

{
  int iVar1;
  char cVar2;
  float fVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  fVar3 = (*(float *)(iVar1 + 0x6c) - param_2[1]) * param_2[5] +
          (*(float *)(iVar1 + 0x68) - *param_2) * param_2[4] +
          (*(float *)(iVar1 + 0x70) - param_2[2]) * param_2[6] + 0.0;
  cVar2 = FUN_00c94350(fVar3);
  if (cVar2 != '\0') {
    return (float10)0.0;
  }
  return (float10)fVar3;
}



/* FUNCTION 12854 ; VA 0x00841aa0 ; FUN_00841aa0 */

void __thiscall FUN_00841aa0(int param_1,int param_2)

{
  int *piVar1;
  
  for (piVar1 = *(int **)(param_1 + 0x38);
      (piVar1 != *(int **)(param_1 + 0x3c) && (*piVar1 != param_2)); piVar1 = piVar1 + 1) {
  }
  FUN_0170cc70(piVar1,piVar1 + 1,(int)*(int **)(param_1 + 0x3c) - (int)(piVar1 + 1));
  *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + -4;
  return;
}



/* FUNCTION 12855 ; VA 0x00841ae0 ; FUN_00841ae0 */

void __thiscall
FUN_00841ae0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5,
            float param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined4 uVar5;
  int iVar6;
  float10 fVar7;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  float fStack_10;
  float fStack_c;
  undefined4 uStack_8;
  
  if ((param_5 == 4) || (bVar4 = false, param_5 == 5)) {
    bVar4 = true;
  }
  uVar5 = FUN_0078e450(param_6);
  iVar6 = FUN_0078e270(param_4,param_5,uVar5);
  if (iVar6 != 0) {
    piVar1 = param_1 + 2;
    if (((DAT_01d60f60 == '\0') || (*piVar1 != 0)) && (*piVar1 != 9)) {
      param_6 = 0.0;
    }
    else {
      fVar7 = (float10)(**(code **)(*param_1 + 0xc))(param_3);
      param_6 = (float)fVar7;
    }
    fStack_c = 0.0;
    if ((DAT_01d60f98 != '\0') && (*piVar1 == 9)) {
      fVar7 = (float10)(**(code **)(*param_1 + 0x10))();
      fStack_c = (float)fVar7;
    }
    piStack_14 = param_1 + 0xb;
    if (!bVar4) {
      piStack_14 = param_1 + 5;
    }
    fStack_10 = param_6;
    uStack_8 = 0;
    iVar2 = param_2 + *piVar1 * 0xc;
    puVar3 = *(undefined4 **)(iVar2 + 4);
    if (*(undefined4 **)(iVar2 + 8) != puVar3) {
      *puVar3 = param_1;
      puVar3[1] = iVar6;
      puVar3[2] = piStack_14;
      puVar3[3] = param_6;
      *(ulonglong *)(puVar3 + 4) = (ulonglong)(uint)fStack_c;
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 0x18;
      *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | param_1[4];
      return;
    }
    piStack_1c = param_1;
    iStack_18 = iVar6;
    FUN_006c6730(puVar3,&piStack_1c);
    *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | param_1[4];
  }
  return;
}



/* FUNCTION 12856 ; VA 0x00841c10 ; FUN_00841c10 */

void __thiscall FUN_00841c10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  undefined4 *puVar4;
  sbyte sVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  float10 fVar10;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  float fStack_c;
  float fStack_8;
  
  cVar3 = FUN_00841130();
  if (cVar3 == '\0') {
    cVar3 = FUN_01156450();
    if ((cVar3 == '\0') || (cVar3 = FUN_00795ec0(), cVar3 == '\0')) {
      uVar7 = 1;
    }
    else {
      uVar7 = 0;
    }
    fStack_c = *(float *)(param_1 + 0x14);
    fVar10 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4));
    fStack_8 = (float)fVar10;
    bVar2 = fStack_c < fStack_8;
    fStack_c = (float)2;
    if (bVar2) {
      fStack_c = (float)uVar7;
    }
    uVar8 = 0;
    sVar5 = SUB41(fStack_c,0);
    iVar6 = *(int *)(param_1 + 0x38);
    if (*(int *)(param_1 + 0x3c) - iVar6 >> 2 != 0) {
      do {
        piVar1 = *(int **)(iVar6 + uVar8 * 4);
        if ((*(byte *)(piVar1 + 3) & (byte)(1 << sVar5)) != 0) {
          (**(code **)(*piVar1 + 8))
                    (param_2,param_3,fStack_c,param_4,*(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4)
                    );
        }
        uVar8 = uVar8 + 1;
        iVar6 = *(int *)(param_1 + 0x38);
      } while (uVar8 < (uint)(*(int *)(param_1 + 0x3c) - iVar6 >> 2));
    }
    if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
      puVar4 = (undefined4 *)FUN_0115ee70();
      FUN_0078af00();
      if (((*(float *)(param_1 + 0x18) < *(float *)(param_1 + 0x24) ||
            *(float *)(param_1 + 0x18) == *(float *)(param_1 + 0x24)) &&
          (*(float *)(param_1 + 0x1c) < *(float *)(param_1 + 0x28) ||
           *(float *)(param_1 + 0x1c) == *(float *)(param_1 + 0x28))) &&
         (*(float *)(param_1 + 0x20) < *(float *)(param_1 + 0x2c) ||
          *(float *)(param_1 + 0x20) == *(float *)(param_1 + 0x2c))) {
        puVar9 = &DAT_019194d4;
        do {
          FUN_00c9f1c0(&uStack_24,puVar9[-1]);
          FUN_00c9f1c0(&uStack_18,*puVar9);
          uStack_34 = *puVar4;
          uStack_30 = puVar4[1];
          uStack_2c = puVar4[2];
          uStack_28 = 0x3f800000;
          FUN_007f92d0(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,&uStack_34);
          puVar9 = puVar9 + 2;
        } while ((int)puVar9 < 0x1919534);
      }
    }
  }
  return;
}



/* FUNCTION 12857 ; VA 0x00841df0 ; FUN_00841df0 */

int FUN_00841df0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b73e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d10(param_1,param_2);
  uStack_8 = 0;
  FUN_00746f10(iVar1 + 8);
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x20) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 12858 ; VA 0x00841e76 ; Catch_All@00841e76 */

void Catch_All_00841e76(void)

{
  int unaff_EBP;
  
  FUN_00781060(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12859 ; VA 0x00841e90 ; FUN_00841e90 */

int FUN_00841e90(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b73f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00845db0();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  puVar1 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar2 + 0x10) = *puVar1;
  *(undefined4 *)(iVar2 + 0x14) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  *(undefined4 *)(iVar2 + 0x28) = 0;
  *(undefined4 *)(iVar2 + 0x2c) = 0;
  *(undefined4 *)(iVar2 + 0x30) = 0;
  *(undefined4 *)(iVar2 + 0x34) = 0;
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  uStack_8 = 1;
  *(undefined4 *)(iVar2 + 0x30) = 0;
  *(undefined4 *)(iVar2 + 0x34) = 0;
  uVar3 = FUN_00616d10(0,0);
  *(undefined4 *)(iVar2 + 0x30) = uVar3;
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 12860 ; VA 0x00841f31 ; Catch_All@00841f31 */

void Catch_All_00841f31(void)

{
  int unaff_EBP;
  
  FUN_00846030(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12861 ; VA 0x00841f50 ; FUN_00841f50 */

void FUN_00841f50(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 3;
    do {
      piVar1 = (int *)piVar3[2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = (int *)piVar3[-2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = piVar3 + 6;
      piVar3 = piVar3 + 9;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 12862 ; VA 0x00841fc0 ; FUN_00841fc0 */

void FUN_00841fc0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    piVar5 = param_1 + 8;
    do {
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = *piVar5 - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00842076;
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      iVar2 = piVar5[-7];
      if (iVar2 != 0) {
        uVar4 = piVar5[-5] - iVar2 & 0xfffffff0;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00842076:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-7] = 0;
        piVar5[-6] = 0;
        piVar5[-5] = 0;
      }
      piVar1 = piVar5 + 2;
      piVar5 = piVar5 + 10;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 12863 ; VA 0x00842080 ; FUN_00842080 */

void FUN_00842080(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uStack_8 = 0;
      FUN_01679490();
      iVar3 = *param_1;
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12864 ; VA 0x00842100 ; FUN_00842100 */

int __thiscall FUN_00842100(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 *puStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_5;
  
  iVar3 = *param_1;
  iStack_10 = (param_2 - iVar3) / 0x14;
  iVar1 = (param_1[1] - iVar3) / 0x14;
  if (iVar1 == 0xccccccc) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar1 + 1;
  uVar2 = (param_1[2] - iVar3) / 0x14;
  uVar6 = uVar4;
  if ((uVar2 <= 0xccccccc - (uVar2 >> 1)) && (uVar6 = (uVar2 >> 1) + uVar2, uVar6 < uVar4)) {
    uVar6 = uVar4;
  }
  iStack_c = FUN_00618130(uVar6);
  iVar3 = iStack_10 * 0x14;
  puStack_14 = (undefined4 *)(iStack_c + iVar3);
  *puStack_14 = 0;
  puStack_14[1] = 0;
  puStack_14[2] = 0;
  puStack_14[3] = 0;
  puStack_14[4] = 0;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iStack_c,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0(&uStack_5,&iStack_10,&iStack_10);
    FUN_0170cc70(iStack_c,*param_1,param_2 - *param_1);
    puVar5 = puStack_14 + 5;
    FUN_0055b6b0(&uStack_5,&puStack_14,&puStack_14);
    FUN_0170cc70(puVar5,param_2,param_1[1] - param_2);
  }
  FUN_00845dd0(iStack_c,uVar4,uVar6);
  return *param_1 + iVar3;
}



/* FUNCTION 12865 ; VA 0x00842250 ; FUN_00842250 */

int __thiscall FUN_00842250(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x3c;
  if (iVar1 == 0x4444444) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x3c;
  uVar7 = uVar5;
  if ((uVar2 <= 0x4444444 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x3c;
  if (uVar7 < 0x4444445) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_008422f3;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008422f3:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00842413;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  iVar4 = ((int)(param_2 - uVar8) / 0x3c) * 0x3c;
  iVar3 = iVar4 + uVar7;
  FUN_00843f80(param_1,iVar3,param_3);
  uVar2 = param_1[1];
  uVar8 = *param_1;
  uVar6 = uVar7;
  if (param_2 != uVar2) {
    FUN_00843ec0(uVar8,param_2,uVar7,param_1);
    uVar2 = param_1[1];
    uVar8 = param_2;
    uVar6 = iVar3 + 0x3c;
  }
  FUN_00843ec0(uVar8,uVar2,uVar6,param_1);
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar2 = param_1[1];
    if (uVar8 != uVar2) {
      do {
        FUN_0056b650();
        uVar8 = uVar8 + 0x3c;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x3c) * 0x3c;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_00842413:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + (iVar1 + 1) * 0x3c;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar4;
}



/* FUNCTION 12866 ; VA 0x00842420 ; FUN_00842420 */

int __thiscall FUN_00842420(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  
  iVar1 = *param_1;
  iVar5 = param_1[1] - iVar1 >> 5;
  if (iVar5 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar5 + 1;
  uVar11 = param_1[2] - iVar1 >> 5;
  uVar7 = uVar6;
  if ((uVar11 <= 0x7ffffff - (uVar11 >> 1)) && (uVar7 = (uVar11 >> 1) + uVar11, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  puVar8 = (undefined4 *)FUN_00577f40(uVar7);
  uVar11 = (int)param_2 - iVar1 & 0xffffffe0;
  puVar9 = (undefined4 *)((int)puVar8 + uVar11);
  uVar2 = param_3[1];
  uVar3 = param_3[2];
  uVar4 = param_3[3];
  *puVar9 = *param_3;
  puVar9[1] = uVar2;
  puVar9[2] = uVar3;
  puVar9[3] = uVar4;
  uVar2 = param_3[5];
  uVar3 = param_3[6];
  uVar4 = param_3[7];
  puVar9[4] = param_3[4];
  puVar9[5] = uVar2;
  puVar9[6] = uVar3;
  puVar9[7] = uVar4;
  puVar13 = (undefined4 *)param_1[1];
  puVar10 = (undefined4 *)*param_1;
  puVar12 = puVar8;
  if (param_2 == puVar13) {
    for (; puVar10 != puVar13; puVar10 = puVar10 + 8) {
      uVar2 = puVar10[1];
      uVar3 = puVar10[2];
      uVar4 = puVar10[3];
      *puVar12 = *puVar10;
      puVar12[1] = uVar2;
      puVar12[2] = uVar3;
      puVar12[3] = uVar4;
      uVar2 = puVar10[5];
      uVar3 = puVar10[6];
      uVar4 = puVar10[7];
      puVar12[4] = puVar10[4];
      puVar12[5] = uVar2;
      puVar12[6] = uVar3;
      puVar12[7] = uVar4;
      puVar12 = puVar12 + 8;
    }
  }
  else {
    if (puVar10 != param_2) {
      do {
        uVar2 = puVar10[1];
        uVar3 = puVar10[2];
        uVar4 = puVar10[3];
        *puVar12 = *puVar10;
        puVar12[1] = uVar2;
        puVar12[2] = uVar3;
        puVar12[3] = uVar4;
        puVar13 = puVar10 + 4;
        uVar2 = puVar10[5];
        uVar3 = puVar10[6];
        uVar4 = puVar10[7];
        puVar10 = puVar10 + 8;
        puVar12[4] = *puVar13;
        puVar12[5] = uVar2;
        puVar12[6] = uVar3;
        puVar12[7] = uVar4;
        puVar12 = puVar12 + 8;
      } while (puVar10 != param_2);
      puVar13 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar13) {
      do {
        uVar2 = param_2[1];
        uVar3 = param_2[2];
        uVar4 = param_2[3];
        puVar9[8] = *param_2;
        puVar9[9] = uVar2;
        puVar9[10] = uVar3;
        puVar9[0xb] = uVar4;
        puVar10 = param_2 + 4;
        uVar2 = param_2[5];
        uVar3 = param_2[6];
        uVar4 = param_2[7];
        param_2 = param_2 + 8;
        puVar9[0xc] = *puVar10;
        puVar9[0xd] = uVar2;
        puVar9[0xe] = uVar3;
        puVar9[0xf] = uVar4;
        puVar9 = puVar9 + 8;
      } while (param_2 != puVar13);
    }
  }
  FUN_007fdb40(puVar8,uVar6,uVar7);
  return *param_1 + uVar11;
}



/* FUNCTION 12867 ; VA 0x00842540 ; FUN_00842540 */

int __thiscall FUN_00842540(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  iVar7 = *param_1;
  iVar6 = (param_1[1] - iVar7) / 0x30;
  if (iVar6 == 0x5555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar6 + 1;
  uVar2 = (param_1[2] - iVar7) / 0x30;
  uVar9 = uVar8;
  if ((uVar2 <= 0x5555555 - (uVar2 >> 1)) && (uVar9 = (uVar2 >> 1) + uVar2, uVar9 < uVar8)) {
    uVar9 = uVar8;
  }
  iVar6 = FUN_00847730(uVar9);
  iVar7 = ((param_2 - iVar7) / 0x30) * 0x30;
  puVar1 = (undefined4 *)(iVar7 + iVar6);
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar3 = param_3[5];
  uVar4 = param_3[6];
  uVar5 = param_3[7];
  puVar1[4] = param_3[4];
  puVar1[5] = uVar3;
  puVar1[6] = uVar4;
  puVar1[7] = uVar5;
  uVar3 = param_3[9];
  uVar4 = param_3[10];
  uVar5 = param_3[0xb];
  puVar1[8] = param_3[8];
  puVar1[9] = uVar3;
  puVar1[10] = uVar4;
  puVar1[0xb] = uVar5;
  if (param_2 == param_1[1]) {
    FUN_008462f0(*param_1,param_1[1],iVar6);
  }
  else {
    FUN_008462b0(*param_1,param_2,iVar6);
    FUN_008462b0(param_2,param_1[1],puVar1 + 0xc);
  }
  FUN_00845e50(iVar6,uVar8,uVar9);
  return *param_1 + iVar7;
}



/* FUNCTION 12868 ; VA 0x00842650 ; FUN_00842650 */

void __thiscall
FUN_00842650(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x4924922 < (uint)param_1[1]) {
    FUN_00845f60(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00842702:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00842702;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 12869 ; VA 0x008427b0 ; FUN_008427b0 */

undefined4 * __thiscall
FUN_008427b0(undefined4 *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b7410;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_00842650(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piStack_20 = (int *)*param_1;
  if (param_3 == (int *)*piStack_20) {
    if ((*param_4 < (uint)param_3[4]) ||
       ((ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 <= (uint)param_3[4] &&
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, (int)param_4[1] < param_3[5])))
       ) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00842650(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piStack_20) {
    iVar1 = piStack_20[2];
    if ((*(uint *)(iVar1 + 0x10) < *param_4) ||
       ((ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) <= *param_4 &&
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(int *)(iVar1 + 0x14) < (int)param_4[1])))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_00842650(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    if ((*param_4 < (uint)param_3[4]) ||
       ((ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 <= (uint)param_3[4] &&
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, (int)param_4[1] < param_3[5])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_00845c00(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00842650(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00842650(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_00845c00(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      FUN_00551320();
      piVar4 = piStack_18;
      if ((piStack_18 == piStack_20) ||
         (cVar3 = FUN_00845c00(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00842650(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00842650(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_00842a00(auStack_24,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12870 ; VA 0x008429e7 ; Catch_All@008429e7 */

void Catch_All_008429e7(void)

{
  int unaff_EBP;
  
  FUN_00845f60(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12871 ; VA 0x00842a00 ; FUN_00842a00 */

void __thiscall
FUN_00842a00(int *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_4;
  puStack_c = &LAB_017b7420;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)*param_1;
  cVar4 = '\x01';
  uStack_8 = 0;
  if (*(char *)((int)puVar5[1] + 0xd) == '\0') {
    uVar1 = *param_4;
    puVar6 = (undefined4 *)puVar5[1];
    do {
      puVar5 = puVar6;
      uVar2 = puVar5[4];
      if (param_3 == '\0') {
        if ((uVar1 < uVar2) || ((uVar1 <= uVar2 && ((int)param_4[1] < (int)puVar5[5])))) {
          cVar4 = '\x01';
          goto LAB_00842a87;
        }
        cVar4 = '\0';
LAB_00842a7d:
        puVar6 = (undefined4 *)puVar5[2];
      }
      else {
        if ((uVar2 < uVar1) || ((uVar2 <= uVar1 && ((int)puVar5[5] < (int)param_4[1])))) {
          cVar4 = '\0';
        }
        else {
          cVar4 = '\x01';
        }
        if (cVar4 == '\0') goto LAB_00842a7d;
LAB_00842a87:
        puVar6 = (undefined4 *)*puVar5;
      }
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = puVar5;
  if (cVar4 != '\0') {
    if (puVar5 == *(undefined4 **)*param_1) {
      cVar4 = '\x01';
      ExceptionList = &pvStack_10;
      goto LAB_00842aa8;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  puVar6 = _param_3;
  if ((*puVar3 <= (uint)_param_3[4]) &&
     ((*puVar3 < (uint)_param_3[4] || ((int)puVar3[1] <= (int)_param_3[5])))) {
    FUN_00845f60(param_5);
    *param_2 = puVar6;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00842aa8:
  puVar5 = (undefined4 *)FUN_00842650(&param_3,cVar4,puVar5,puVar3,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12872 ; VA 0x00842b1f ; Catch_All@00842b1f */

void Catch_All_00842b1f(void)

{
  int unaff_EBP;
  
  FUN_00845f60(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12873 ; VA 0x00842b40 ; FUN_00842b40 */

void FUN_00842b40(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *param_2;
  if ((((byte)*(undefined4 *)(*param_1 + 0xc) & 0x14) < ((byte)*(undefined4 *)(iVar2 + 0xc) & 0x14))
     && (param_2 != param_1)) {
    *param_2 = *param_1;
    *param_1 = iVar2;
    iVar2 = param_2[1];
    param_2[1] = param_1[1];
    param_1[1] = iVar2;
    iVar2 = *param_2;
  }
  iVar1 = *param_3;
  if (((byte)*(undefined4 *)(iVar2 + 0xc) & 0x14) < ((byte)*(undefined4 *)(iVar1 + 0xc) & 0x14)) {
    if (param_3 != param_2) {
      *param_3 = iVar2;
      *param_2 = iVar1;
      iVar2 = param_3[1];
      param_3[1] = param_2[1];
      param_2[1] = iVar2;
      iVar2 = *param_2;
    }
    if ((((byte)*(undefined4 *)(*param_1 + 0xc) & 0x14) <
         ((byte)*(undefined4 *)(iVar2 + 0xc) & 0x14)) && (param_2 != param_1)) {
      *param_2 = *param_1;
      *param_1 = iVar2;
      iVar2 = param_2[1];
      param_2[1] = param_1[1];
      param_1[1] = iVar2;
    }
  }
  return;
}



/* FUNCTION 12874 ; VA 0x00842be0 ; FUN_00842be0 */

void FUN_00842be0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar3 = FUN_00b06f80();
  uVar4 = FUN_00b06f80();
  if (uVar3 < uVar4) {
    uVar1 = *param_2;
    uVar2 = param_2[1];
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    *param_1 = uVar1;
    param_1[1] = uVar2;
  }
  uVar3 = FUN_00b06f80();
  uVar4 = FUN_00b06f80();
  if (uVar4 < uVar3) {
    uVar1 = *param_3;
    uVar2 = param_3[1];
    *param_3 = *param_2;
    param_3[1] = param_2[1];
    *param_2 = uVar1;
    param_2[1] = uVar2;
    uVar3 = FUN_00b06f80();
    uVar4 = FUN_00b06f80();
    if (uVar3 < uVar4) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *param_1 = uVar1;
      param_1[1] = uVar2;
    }
  }
  return;
}



/* FUNCTION 12875 ; VA 0x00842c70 ; FUN_00842c70 */

void FUN_00842c70(uint *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piStack_8;
  
  piVar3 = param_3 + -2;
  piVar8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar1 = (int)piVar3 - (int)param_2 >> 3;
  if (iVar1 < 0x29) {
    FUN_00842b40(param_2,piVar8,piVar3,param_4);
  }
  else {
    iVar1 = iVar1 + 1 >> 3;
    FUN_00842b40(param_2,param_2 + iVar1 * 2,param_2 + iVar1 * 4,param_4);
    FUN_00842b40(piVar8 + iVar1 * -2,piVar8,piVar8 + iVar1 * 2,param_4);
    FUN_00842b40(piVar3 + iVar1 * -4,piVar3 + iVar1 * -2,piVar3,param_4);
    FUN_00842b40(param_2 + iVar1 * 2,piVar8,piVar3 + iVar1 * -2,param_4);
  }
  piVar3 = piVar8 + 2;
  while (((param_2 < piVar8 &&
          (uVar4 = *(uint *)(piVar8[-2] + 0xc) & 0x14, uVar2 = *(uint *)(*piVar8 + 0xc) & 0x14,
          uVar4 <= uVar2)) && (uVar2 <= uVar4))) {
    piVar8 = piVar8 + -2;
  }
  piVar7 = piVar3;
  piStack_8 = piVar3;
  param_4 = piVar8;
  if (piVar3 < param_3) {
    uVar2 = *(uint *)(*piVar8 + 0xc) & 0x14;
    do {
      uVar4 = *(uint *)(*piVar3 + 0xc) & 0x14;
      piVar7 = piVar3;
      piStack_8 = piVar3;
      if ((uVar2 < uVar4) || (uVar4 < uVar2)) break;
      piVar3 = piVar3 + 2;
      piVar7 = piVar3;
      piStack_8 = piVar3;
    } while (piVar3 < param_3);
  }
joined_r0x00842d82:
  do {
    piVar6 = piVar8;
    piVar9 = piVar7;
    piVar8 = param_4;
    if (param_3 <= piVar3) {
joined_r0x00842dc6:
      for (; param_2 < param_4; param_4 = param_4 + -2) {
        piVar5 = piVar8 + -2;
        uVar2 = *(uint *)(*piVar5 + 0xc) & 0x14;
        uVar4 = *(uint *)(*piVar6 + 0xc) & 0x14;
        piVar7 = piVar6;
        piVar3 = piStack_8;
        if (uVar2 <= uVar4) {
          if (uVar2 < uVar4) break;
          piVar7 = piVar6 + -2;
          if (piVar7 != piVar5) {
            iVar1 = *piVar7;
            *piVar7 = *piVar5;
            *piVar5 = iVar1;
            iVar1 = piVar6[-1];
            piVar6[-1] = piVar8[-1];
            piVar8[-1] = iVar1;
          }
        }
        piVar6 = piVar7;
        piVar8 = piVar5;
      }
      if (param_4 == param_2) {
        if (piVar3 == param_3) {
          param_1[1] = (uint)piVar9;
          *param_1 = (uint)piVar6;
          return;
        }
        if ((piVar9 != piVar3) && (piVar6 != piVar9)) {
          iVar1 = *piVar6;
          *piVar6 = *piVar9;
          *piVar9 = iVar1;
          iVar1 = piVar6[1];
          piVar6[1] = piVar9[1];
          piVar9[1] = iVar1;
        }
        if (piVar6 != piVar3) {
          iVar1 = *piVar6;
          *piVar6 = *piVar3;
          *piVar3 = iVar1;
          iVar1 = piVar6[1];
          piVar6[1] = piVar3[1];
          piVar3[1] = iVar1;
        }
        piVar3 = piVar3 + 2;
        piVar7 = piVar9 + 2;
        piStack_8 = piVar3;
        piVar8 = piVar6 + 2;
      }
      else {
        piVar5 = param_4 + -2;
        if (piVar3 == param_3) {
          piVar8 = piVar6 + -2;
          if (piVar5 != piVar8) {
            iVar1 = *piVar5;
            *piVar5 = *piVar8;
            *piVar8 = iVar1;
            iVar1 = param_4[-1];
            param_4[-1] = piVar6[-1];
            piVar6[-1] = iVar1;
          }
          piVar7 = piVar9 + -2;
          param_4 = piVar5;
          if (piVar8 != piVar7) {
            iVar1 = *piVar8;
            *piVar8 = *piVar7;
            *piVar7 = iVar1;
            iVar1 = piVar6[-1];
            piVar6[-1] = piVar9[-1];
            piVar9[-1] = iVar1;
          }
        }
        else {
          if (piVar3 != piVar5) {
            iVar1 = *piVar3;
            *piVar3 = *piVar5;
            *piVar5 = iVar1;
            iVar1 = piVar3[1];
            piVar3[1] = param_4[-1];
            param_4[-1] = iVar1;
          }
          piVar3 = piVar3 + 2;
          piVar7 = piVar9;
          piStack_8 = piVar3;
          param_4 = piVar5;
          piVar8 = piVar6;
        }
      }
      goto joined_r0x00842d82;
    }
    uVar2 = *(uint *)(*piVar6 + 0xc) & 0x14;
    uVar4 = *(uint *)(*piVar3 + 0xc) & 0x14;
    if (uVar2 <= uVar4) {
      piStack_8 = piVar3;
      if (uVar2 < uVar4) goto joined_r0x00842dc6;
      if (piVar9 != piVar3) {
        iVar1 = *piVar9;
        *piVar9 = *piVar3;
        *piVar3 = iVar1;
        iVar1 = piVar9[1];
        piVar9[1] = piVar3[1];
        piVar3[1] = iVar1;
      }
      piVar9 = piVar9 + 2;
    }
    piVar3 = piVar3 + 2;
    piVar7 = piVar9;
    piStack_8 = piVar3;
    piVar8 = piVar6;
  } while( true );
}



/* FUNCTION 12876 ; VA 0x00842f10 ; FUN_00842f10 */

void FUN_00842f10(uint *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  puVar9 = param_3 + -2;
  puStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  iVar3 = (int)puVar9 - (int)param_2 >> 3;
  if (iVar3 < 0x29) {
    FUN_00842be0(param_2,puStack_8,puVar9,param_4);
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    FUN_00842be0(param_2,param_2 + iVar3 * 2,param_2 + iVar3 * 4,param_4);
    FUN_00842be0(puStack_8 + iVar3 * -2,puStack_8,puStack_8 + iVar3 * 2,param_4);
    FUN_00842be0(puVar9 + iVar3 * -4,puVar9 + iVar3 * -2,puVar9,param_4);
    FUN_00842be0(param_2 + iVar3 * 2,puStack_8,puVar9 + iVar3 * -2,param_4);
  }
  puVar9 = puStack_8 + 2;
  if (param_2 < puStack_8) {
    while( true ) {
      uVar4 = FUN_00b06f80();
      uVar5 = FUN_00b06f80();
      if (uVar5 < uVar4) break;
      uVar4 = FUN_00b06f80();
      uVar5 = FUN_00b06f80();
      if ((uVar4 < uVar5) || (puStack_8 = puStack_8 + -2, puStack_8 <= param_2)) break;
    }
  }
  param_4 = puVar9;
  puStack_c = puVar9;
  puVar6 = puStack_8;
  if (puVar9 < param_3) {
    while( true ) {
      uVar4 = FUN_00b06f80();
      uVar5 = FUN_00b06f80();
      param_4 = puVar9;
      puStack_c = puVar9;
      if (uVar4 < uVar5) break;
      uVar4 = FUN_00b06f80();
      uVar5 = FUN_00b06f80();
      if ((uVar5 < uVar4) ||
         (puVar9 = puVar9 + 2, param_4 = puVar9, puStack_c = puVar9, param_3 <= puVar9)) break;
    }
  }
joined_r0x00843047:
  do {
    puVar10 = puStack_8;
    if (param_3 <= puVar9) {
joined_r0x008430ac:
      for (; param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
        puVar8 = puVar10 + -2;
        uVar4 = FUN_00b06f80();
        uVar5 = FUN_00b06f80();
        puVar7 = puVar6;
        puVar9 = puStack_c;
        if (uVar4 <= uVar5) {
          uVar4 = FUN_00b06f80();
          uVar5 = FUN_00b06f80();
          if (uVar4 < uVar5) break;
          puVar7 = puVar6 + -2;
          if (puVar7 != puVar8) {
            uVar1 = *puVar7;
            uVar2 = puVar6[-1];
            *puVar7 = *puVar8;
            puVar6[-1] = puVar10[-1];
            *puVar8 = uVar1;
            puVar10[-1] = uVar2;
          }
        }
        puVar6 = puVar7;
        puVar10 = puVar8;
      }
      if (puStack_8 == param_2) {
        if (puVar9 == param_3) {
          *param_1 = (uint)puVar6;
          param_1[1] = (uint)param_4;
          return;
        }
        if (param_4 != puVar9) {
          uVar1 = *puVar6;
          uVar2 = puVar6[1];
          *puVar6 = *param_4;
          puVar6[1] = param_4[1];
          *param_4 = uVar1;
          param_4[1] = uVar2;
        }
        uVar1 = *puVar6;
        uVar2 = puVar6[1];
        *puVar6 = *puVar9;
        puVar6[1] = puVar9[1];
        *puVar9 = uVar1;
        puVar9[1] = uVar2;
        puVar9 = puVar9 + 2;
        param_4 = param_4 + 2;
        puStack_c = puVar9;
        puVar6 = puVar6 + 2;
      }
      else {
        puVar10 = puStack_8 + -2;
        if (puVar9 == param_3) {
          puVar7 = puVar6 + -2;
          if (puVar10 != puVar7) {
            uVar1 = *puVar10;
            uVar2 = puStack_8[-1];
            *puVar10 = *puVar7;
            puStack_8[-1] = puVar6[-1];
            *puVar7 = uVar1;
            puVar6[-1] = uVar2;
          }
          uVar1 = *puVar7;
          puVar8 = param_4 + -2;
          uVar2 = puVar6[-1];
          *puVar7 = *puVar8;
          puVar6[-1] = param_4[-1];
          *puVar8 = uVar1;
          param_4[-1] = uVar2;
          param_4 = puVar8;
          puStack_8 = puVar10;
          puVar6 = puVar7;
        }
        else {
          uVar1 = *puVar9;
          uVar2 = puVar9[1];
          *puVar9 = *puVar10;
          puVar9[1] = puStack_8[-1];
          puVar9 = puVar9 + 2;
          *puVar10 = uVar1;
          puStack_8[-1] = uVar2;
          puStack_c = puVar9;
          puStack_8 = puVar10;
        }
      }
      goto joined_r0x00843047;
    }
    uVar4 = FUN_00b06f80();
    uVar5 = FUN_00b06f80();
    if (uVar5 <= uVar4) {
      uVar4 = FUN_00b06f80();
      uVar5 = FUN_00b06f80();
      puStack_c = puVar9;
      if (uVar5 < uVar4) goto joined_r0x008430ac;
      if (param_4 != puVar9) {
        uVar1 = *param_4;
        uVar2 = param_4[1];
        *param_4 = *puVar9;
        param_4[1] = puVar9[1];
        *puVar9 = uVar1;
        puVar9[1] = uVar2;
      }
      param_4 = param_4 + 2;
    }
    puVar9 = puVar9 + 2;
    puStack_c = puVar9;
  } while( true );
}



/* FUNCTION 12877 ; VA 0x008431f0 ; FUN_008431f0 */

void FUN_008431f0(int param_1,int param_2,uint param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar1 = param_2;
  iVar2 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar2 = (2 - (uint)(((byte)*(undefined4 *)(*(int *)(param_1 + 8 + iVar1 * 0x10) + 0xc) & 0x14)
                         < ((byte)*(undefined4 *)(*(int *)(param_1 + 0x10 + iVar1 * 0x10) + 0xc) &
                           0x14))) + iVar1 * 2;
      *(undefined4 *)(param_1 + iVar1 * 8) = *(undefined4 *)(param_1 + iVar2 * 8);
      *(undefined4 *)(param_1 + 4 + iVar1 * 8) = *(undefined4 *)(param_1 + 4 + iVar2 * 8);
      iVar1 = iVar2;
    } while (iVar2 < iVar3);
  }
  if ((iVar2 == iVar3) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar2 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar2 = param_3 - 1;
  }
  while (param_2 < iVar2) {
    iVar3 = iVar2 + -1 >> 1;
    iVar1 = *(int *)(param_1 + iVar3 * 8);
    if (((byte)*(undefined4 *)(iVar1 + 0xc) & 0x14) <=
        ((byte)*(undefined4 *)(*param_4 + 0xc) & 0x14)) break;
    *(int *)(param_1 + iVar2 * 8) = iVar1;
    *(undefined4 *)(param_1 + 4 + iVar2 * 8) = *(undefined4 *)(param_1 + 4 + iVar3 * 8);
    iVar2 = iVar3;
  }
  *(int *)(param_1 + iVar2 * 8) = *param_4;
  *(int *)(param_1 + 4 + iVar2 * 8) = param_4[1];
  return;
}



/* FUNCTION 12878 ; VA 0x008432c0 ; FUN_008432c0 */

void FUN_008432c0(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  
  iVar2 = (int)(param_3 - 1) >> 1;
  iVar5 = param_2;
  iVar6 = param_2;
  if (param_2 < iVar2) {
    do {
      iVar6 = iVar5 * 2 + 2;
      uVar3 = FUN_00b06f80();
      uVar4 = FUN_00b06f80();
      if (uVar4 < uVar3) {
        iVar6 = iVar5 * 2 + 1;
      }
      *(undefined4 *)(param_1 + iVar5 * 8) = *(undefined4 *)(param_1 + iVar6 * 8);
      *(undefined4 *)(param_1 + 4 + iVar5 * 8) = *(undefined4 *)(param_1 + 4 + iVar6 * 8);
      iVar5 = iVar6;
    } while (iVar6 < iVar2);
  }
  if ((iVar6 == iVar2) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar6 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar6 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar6 = param_3 - 1;
  }
  while (param_2 < iVar6) {
    iVar5 = iVar6 + -1 >> 1;
    puVar1 = (undefined4 *)(param_1 + iVar5 * 8);
    uVar3 = FUN_00b06f80();
    uVar4 = FUN_00b06f80();
    if (uVar3 <= uVar4) break;
    *(undefined4 *)(param_1 + iVar6 * 8) = *puVar1;
    *(undefined4 *)(param_1 + 4 + iVar6 * 8) = puVar1[1];
    iVar6 = iVar5;
  }
  *(undefined4 *)(param_1 + iVar6 * 8) = *param_4;
  *(undefined4 *)(param_1 + 4 + iVar6 * 8) = param_4[1];
  return;
}



/* FUNCTION 12879 ; VA 0x008433b0 ; FUN_008433b0 */

void __thiscall FUN_008433b0(uint *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  
  uVar7 = (int)(param_1[1] - *param_1) / 0x2c;
  uVar8 = (int)(param_1[2] - *param_1) / 0x2c;
  if (param_2 <= uVar8) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = param_2 * 0x2c + *param_1;
      }
      return;
    }
    uVar7 = FUN_00845950(param_1[1],param_2 - uVar7);
    param_1[1] = uVar7;
    return;
  }
  if (0x5d1745d < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar11 = param_2;
  if ((uVar8 <= 0x5d1745d - (uVar8 >> 1)) && (uVar11 = (uVar8 >> 1) + uVar8, uVar11 < param_2)) {
    uVar11 = param_2;
  }
  uVar8 = uVar11 * 0x2c;
  if (uVar11 < 0x5d1745e) {
    uVar11 = uVar8;
    if (0xfff < uVar8) goto LAB_0084343c;
    if (uVar8 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_0084343c:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_0084355f;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  FUN_00845950(uVar7 * 0x2c + uVar11,param_2 - uVar7);
  puVar9 = (undefined4 *)*param_1;
  puVar10 = (undefined4 *)param_1[1];
  if (puVar9 != puVar10) {
    iVar6 = uVar11 - (int)puVar9;
    do {
      uVar2 = puVar9[1];
      uVar3 = puVar9[2];
      uVar4 = puVar9[3];
      puVar1 = (undefined4 *)(iVar6 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[5];
      uVar3 = puVar9[6];
      uVar4 = puVar9[7];
      puVar1 = (undefined4 *)(iVar6 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(iVar6 + 0x20 + (int)puVar9) = *(undefined8 *)(puVar9 + 8);
      *(undefined4 *)(iVar6 + 0x28 + (int)puVar9) = puVar9[10];
      puVar9 = puVar9 + 0xb;
    } while (puVar9 != puVar10);
    puVar9 = (undefined4 *)*param_1;
  }
  if (puVar9 != (undefined4 *)0x0) {
    uVar7 = ((int)(param_1[2] - (int)puVar9) / 0x2c) * 0x2c;
    puVar10 = puVar9;
    if (0xfff < uVar7) {
      puVar10 = (undefined4 *)puVar9[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puVar9 + (-4 - (int)puVar10))) {
LAB_0084355f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar7);
  }
  *param_1 = uVar11;
  param_1[1] = param_2 * 0x2c + uVar11;
  param_1[2] = uVar8 + uVar11;
  return;
}



/* FUNCTION 12880 ; VA 0x00843570 ; FUN_00843570 */

void __thiscall FUN_00843570(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  uVar4 = param_2;
  uVar2 = (param_1[1] - *param_1) / 0x30;
  uVar3 = (param_1[2] - *param_1) / 0x30;
  if (param_2 <= uVar3) {
    if (param_2 <= uVar2) {
      if (param_2 != uVar2) {
        param_1[1] = param_2 * 0x30 + *param_1;
      }
      return;
    }
    iVar5 = FUN_008459b0(param_1[1],param_2 - uVar2);
    param_1[1] = iVar5;
    return;
  }
  if (0x5555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar3 <= 0x5555555 - (uVar3 >> 1)) && (uVar1 = (uVar3 >> 1) + uVar3, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar5 = FUN_00847730(param_2);
  FUN_008459b0(uVar2 * 0x30 + iVar5,uVar4 - uVar2);
  FUN_008462f0(*param_1,param_1[1],iVar5);
  FUN_00845e50(iVar5,uVar4,param_2);
  return;
}



/* FUNCTION 12881 ; VA 0x00843670 ; FUN_00843670 */

void __thiscall FUN_00843670(int *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  puVar10 = (undefined4 *)param_1[1];
  iVar4 = *param_1;
  uVar1 = (int)puVar10 - iVar4 >> 3;
  uVar7 = param_1[2] - iVar4 >> 3;
  if (param_2 <= uVar7) {
    if (uVar1 < param_2) {
      for (iVar4 = param_2 - uVar1; iVar4 != 0; iVar4 = iVar4 + -1) {
        *puVar10 = 0;
        puVar10[1] = 0;
        puVar10 = puVar10 + 2;
      }
      FUN_005596d0(puVar10,puVar10,param_3);
      param_1[1] = (int)puVar10;
      return;
    }
    if (param_2 != uVar1) {
      iVar4 = iVar4 + param_2 * 8;
      FUN_005596d0(iVar4,puVar10,param_1);
      param_1[1] = iVar4;
    }
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = param_2;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar2 = (uVar7 >> 1) + uVar7, uVar2 < param_2)) {
    uVar2 = param_2;
  }
  uVar7 = uVar2 * 8;
  if (uVar2 < 0x20000000) {
    if (0xfff < uVar7) goto LAB_008436e2;
    if (uVar7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_008436e2:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_0084385d;
    puVar10 = (undefined4 *)(iVar4 + 0x23U & 0xffffffe0);
    puVar10[-1] = iVar4;
  }
  puVar5 = puVar10 + uVar1 * 2;
  for (iVar4 = param_2 - uVar1; iVar4 != 0; iVar4 = iVar4 + -1) {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5 = puVar5 + 2;
  }
  FUN_005596d0(puVar5,puVar5,param_3);
  puVar5 = (undefined4 *)param_1[1];
  puVar9 = puVar10;
  for (puVar8 = (undefined4 *)*param_1; puVar8 != puVar5; puVar8 = puVar8 + 2) {
    *puVar9 = 0;
    puVar9[1] = 0;
    *puVar9 = *puVar8;
    puVar9[1] = puVar8[1];
    puVar9 = puVar9 + 2;
    *puVar8 = 0;
    puVar8[1] = 0;
  }
  FUN_005596d0(puVar9,puVar9,param_1);
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    iVar4 = *param_1;
    uVar1 = param_1[2] - iVar4 & 0xfffffff8;
    iVar6 = iVar4;
    if (0xfff < uVar1) {
      iVar6 = *(int *)(iVar4 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar4 - iVar6) - 4U) {
LAB_0084385d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar1);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)(puVar10 + param_2 * 2);
  param_1[2] = (int)(puVar10 + uVar2 * 2);
  return;
}



/* FUNCTION 12882 ; VA 0x00843870 ; FUN_00843870 */

void __thiscall FUN_00843870(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b7430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Motion::Skeleton>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12883 ; VA 0x008438de ; Catch_All@008438de */

void Catch_All_008438de(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00845d60(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12884 ; VA 0x00843900 ; FUN_00843900 */

void FUN_00843900(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  bool bVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2 - (int)param_1;
  piVar7 = param_2;
  piVar10 = param_1;
  do {
    iVar4 = iVar4 >> 3;
    if (iVar4 < 0x21) {
LAB_0084398d:
      if ((1 < iVar4) && (piVar3 = piVar10, piVar10 != piVar7)) {
        while (piVar7 = piVar3 + 2, piVar7 != param_2) {
          iVar4 = *piVar7;
          iVar9 = piVar3[3];
          uVar6 = *(uint *)(iVar4 + 0xc) & 0x14;
          if ((*(uint *)(*piVar10 + 0xc) & 0x14) < uVar6) {
            piVar11 = piVar3 + 1;
            piVar12 = piVar3 + 4;
            piVar3 = piVar7;
            while (piVar3 != piVar10) {
              piVar12[-2] = piVar11[-1];
              piVar12[-1] = *piVar11;
              piVar3 = piVar11 + -1;
              piVar11 = piVar11 + -2;
              piVar12 = piVar12 + -2;
            }
            *piVar10 = iVar4;
            piVar10[1] = iVar9;
            piVar3 = piVar7;
          }
          else {
            iVar5 = *piVar3;
            piVar11 = piVar7;
            piVar12 = piVar7;
            if ((*(uint *)(iVar5 + 0xc) & 0x14) < uVar6) {
              do {
                piVar12 = piVar3;
                *piVar11 = iVar5;
                piVar11[1] = piVar12[1];
                iVar5 = piVar12[-2];
                piVar3 = piVar12 + -2;
                piVar10 = param_1;
                piVar11 = piVar12;
              } while (((byte)*(undefined4 *)(iVar5 + 0xc) & 0x14) <
                       ((byte)*(undefined4 *)(iVar4 + 0xc) & 0x14));
            }
            *piVar12 = iVar4;
            piVar12[1] = iVar9;
            piVar3 = piVar7;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar4) {
        iVar4 = (int)piVar7 - (int)piVar10;
        uVar6 = iVar4 >> 3;
        iVar9 = iVar4 >> 4;
        if (0 < iVar9) {
          iVar5 = (int)(uVar6 - 1) >> 1;
          piVar7 = piVar10 + iVar9 * 2;
          do {
            iStack_10 = piVar7[-2];
            piStack_18 = piVar7 + -2;
            iVar9 = iVar9 + -1;
            iStack_14 = piVar7[-1];
            iVar1 = iVar9;
            while (iVar1 < iVar5) {
              iVar8 = (2 - (uint)(((byte)*(undefined4 *)(piVar10[iVar1 * 4 + 2] + 0xc) & 0x14) <
                                 ((byte)*(undefined4 *)(piVar10[iVar1 * 4 + 4] + 0xc) & 0x14))) +
                      iVar1 * 2;
              piVar10[iVar1 * 2] = piVar10[iVar8 * 2];
              piVar10[iVar1 * 2 + 1] = piVar10[iVar8 * 2 + 1];
              iVar1 = iVar8;
            }
            if ((iVar1 == iVar5) && ((uVar6 & 1) == 0)) {
              piVar10[iVar1 * 2] = piVar10[uVar6 * 2 + -2];
              piVar10[iVar1 * 2 + 1] = piVar10[uVar6 * 2 + -1];
              iVar1 = uVar6 - 1;
            }
            while (iVar9 < iVar1) {
              iVar8 = iVar1 + -1 >> 1;
              if (((byte)*(undefined4 *)(piVar10[iVar8 * 2] + 0xc) & 0x14) <=
                  ((byte)*(undefined4 *)(iStack_10 + 0xc) & 0x14)) break;
              piVar10[iVar1 * 2] = piVar10[iVar8 * 2];
              piVar10[iVar1 * 2 + 1] = piVar10[iVar8 * 2 + 1];
              iVar1 = iVar8;
            }
            piVar10[iVar1 * 2] = iStack_10;
            piVar10[iVar1 * 2 + 1] = iStack_14;
            piVar7 = piStack_18;
            iStack_8 = iVar9;
          } while (0 < iVar9);
        }
        uStack_c = uVar6;
        if ((int)uVar6 < 2) {
          return;
        }
        do {
          piVar7 = param_2 + -2;
          bVar2 = 1 < (int)uVar6;
          uVar6 = iVar4 + -8 >> 3;
          if (bVar2) {
            piStack_20 = (int *)*piVar7;
            piStack_1c = (int *)param_2[-1];
            *piVar7 = *piVar10;
            *(int *)(iVar4 + -4 + (int)piVar10) = piVar10[1];
            FUN_008431f0(piVar10,0,uVar6,&piStack_20,param_4);
          }
          param_2 = piVar7;
          iVar4 = iVar4 + -8;
        } while (1 < (int)uVar6);
        return;
      }
      goto LAB_0084398d;
    }
    FUN_00842c70(&piStack_20,piVar10,piVar7,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)piStack_20 - (int)piVar10 & 0xfffffff8U) <
        (int)((int)piVar7 - (int)piStack_1c & 0xfffffff8U)) {
      FUN_00843900(piVar10,piStack_20,param_3,param_4);
      param_1 = piStack_1c;
      piVar10 = piStack_1c;
    }
    else {
      FUN_00843900(piStack_1c,piVar7,param_3,param_4);
      param_2 = piStack_20;
      piVar7 = piStack_20;
    }
    iVar4 = (int)piVar7 - (int)piVar10;
  } while( true );
}



/* FUNCTION 12885 ; VA 0x00843bd0 ; FUN_00843bd0 */

void FUN_00843bd0(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 *puStack_10;
  undefined4 *puStack_c;
  uint uStack_8;
  
  iVar1 = (int)param_2 - (int)param_1;
  puVar6 = param_1;
  puVar5 = puStack_c;
  do {
    iVar1 = iVar1 >> 3;
    if (iVar1 < 0x21) {
LAB_00843c60:
      if ((1 < iVar1) && (puStack_10 = puVar6, puVar6 != param_2)) {
        while (puVar5 = puStack_10 + 2, puVar5 != param_2) {
          uStack_14 = puStack_10[3];
          uStack_8 = *puVar5;
          puStack_10 = puVar5;
          puStack_c = puVar5;
          uVar2 = FUN_00b06f80();
          uVar3 = FUN_00b06f80();
          if (uVar2 < uVar3) {
            FUN_0170cc70((int)puVar5 + (8 - ((int)puVar5 - (int)puVar6)),puVar6,
                         (int)puVar5 - (int)puVar6);
            *puVar6 = uStack_8;
            puVar6[1] = uStack_14;
            puStack_10 = puVar5;
          }
          else {
            uVar2 = FUN_00b06f80();
            uVar3 = FUN_00b06f80();
            puVar7 = puStack_c;
            puVar4 = puStack_c;
            if (uVar2 < uVar3) {
              do {
                puVar4 = puVar5 + -2;
                *puVar7 = *puVar4;
                puVar7[1] = puVar5[-1];
                uVar2 = FUN_00b06f80();
                uVar3 = FUN_00b06f80();
                puVar6 = param_1;
                puVar7 = puVar4;
                puVar5 = puVar4;
              } while (uVar2 < uVar3);
            }
            puStack_c = puVar4;
            *puStack_c = uStack_8;
            puStack_c[1] = uStack_14;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar1) {
        uStack_8 = (int)param_2 - (int)puVar6 >> 3;
        puStack_c = (undefined4 *)((int)param_2 - (int)puVar6 >> 4);
        if (0 < (int)puStack_c) {
          puVar7 = (undefined4 *)((int)(uStack_8 - 1) >> 1);
          puStack_1c = puVar6 + (int)puStack_c * 2;
          puStack_10 = puVar7;
          do {
            uStack_14 = puStack_1c[-2];
            puVar5 = puStack_1c + -2;
            iVar1 = (int)puStack_c + -1;
            uStack_18 = puStack_1c[-1];
            param_1 = (undefined4 *)iVar1;
            puStack_1c = puVar5;
            puStack_c = (undefined4 *)iVar1;
            if (iVar1 < (int)puVar7) {
              do {
                param_1 = (undefined4 *)(iVar1 * 2 + 2);
                uVar2 = FUN_00b06f80();
                uVar3 = FUN_00b06f80();
                if (uVar3 < uVar2) {
                  param_1 = (undefined4 *)(iVar1 * 2 + 1);
                }
                puVar6[iVar1 * 2] = puVar6[(int)param_1 * 2];
                puVar6[iVar1 * 2 + 1] = puVar6[(int)param_1 * 2 + 1];
                iVar1 = (int)param_1;
                puVar7 = puStack_10;
              } while ((int)param_1 < (int)puStack_10);
            }
            if ((param_1 == puVar7) && ((uStack_8 & 1) == 0)) {
              puVar6[(int)param_1 * 2] = puVar6[uStack_8 * 2 + -2];
              puVar6[(int)param_1 * 2 + 1] = puVar6[uStack_8 * 2 + -1];
              param_1 = (undefined4 *)(uStack_8 - 1);
            }
            if ((int)puStack_c < (int)param_1) {
              do {
                iVar1 = (int)param_1 + -1 >> 1;
                uVar2 = FUN_00b06f80();
                uVar3 = FUN_00b06f80();
                puVar7 = puStack_10;
                if (uVar2 <= uVar3) break;
                puVar6[(int)param_1 * 2] = puVar6[iVar1 * 2];
                puVar6[(int)param_1 * 2 + 1] = puVar6[iVar1 * 2 + 1];
                param_1 = (undefined4 *)iVar1;
              } while ((int)puStack_c < iVar1);
            }
            puVar6[(int)param_1 * 2] = uStack_14;
            puVar6[(int)param_1 * 2 + 1] = uStack_18;
            puVar5 = puStack_c;
          } while (0 < (int)puStack_c);
        }
        puStack_c = puVar5;
        if ((int)uStack_8 < 2) {
          return;
        }
        param_2 = param_2 + -2;
        do {
          if (1 < (int)uStack_8) {
            puStack_20 = (undefined4 *)*param_2;
            puStack_1c = (undefined4 *)param_2[1];
            *param_2 = *puVar6;
            param_2[1] = puVar6[1];
            FUN_008432c0(puVar6,0,(int)param_2 - (int)puVar6 >> 3,&puStack_20,param_4);
          }
          param_2 = param_2 + -2;
          uStack_8 = (int)param_2 + (8 - (int)puVar6) >> 3;
        } while (1 < (int)uStack_8);
        return;
      }
      goto LAB_00843c60;
    }
    puStack_c = puVar5;
    FUN_00842f10(&puStack_20,puVar6,param_2,param_4);
    puVar5 = puStack_1c;
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_20 - (int)puVar6 & 0xfffffff8U) <
        (int)((int)param_2 - (int)puStack_1c & 0xfffffff8U)) {
      FUN_00843bd0(puVar6,puStack_20,param_3,param_4);
      param_1 = puVar5;
      puVar6 = puVar5;
    }
    else {
      FUN_00843bd0(puStack_1c,param_2,param_3,param_4);
      param_2 = puStack_20;
    }
    iVar1 = (int)param_2 - (int)puVar6;
    puVar5 = puStack_c;
  } while( true );
}



/* FUNCTION 12886 ; VA 0x00843ec0 ; FUN_00843ec0 */

undefined4 * FUN_00843ec0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  puVar8 = param_3;
  if (param_1 != param_2) {
    puVar6 = param_1 + 10;
    puVar7 = param_3 + 0xb;
    do {
      puVar1 = puVar6 + 0xf;
      *puVar8 = puVar6[-10];
      puVar8 = puVar8 + 0xf;
      puVar7[-10] = puVar6[-9];
      puVar7[-9] = puVar6[-8];
      puVar7[-8] = puVar6[-7];
      puVar7[-7] = puVar6[-6];
      uVar3 = puVar6[-4];
      uVar4 = puVar6[-3];
      uVar5 = puVar6[-2];
      puVar7[-6] = puVar6[-5];
      puVar7[-5] = uVar3;
      puVar7[-4] = uVar4;
      puVar7[-3] = uVar5;
      puVar7[-2] = 0;
      *(undefined4 *)((int)param_3 + (-0x3c - (int)param_1) + (int)puVar1) = 0;
      puVar7[-2] = puVar6[-1];
      *(undefined4 *)((int)param_3 + (-0x3c - (int)param_1) + (int)puVar1) = *puVar6;
      puVar6[-1] = 0;
      *puVar6 = 0;
      *puVar7 = 0;
      puVar7[1] = 0;
      *puVar7 = puVar6[1];
      puVar7[1] = puVar6[2];
      puVar6[1] = 0;
      puVar6[2] = 0;
      puVar7[2] = puVar6[3];
      *(undefined *)(puVar7 + 3) = *(undefined *)(puVar6 + 4);
      puVar2 = puVar6 + 5;
      puVar6 = puVar1;
      puVar7 = puVar7 + 0xf;
    } while (puVar2 != param_2);
  }
  return puVar8;
}



/* FUNCTION 12887 ; VA 0x00843f80 ; FUN_00843f80 */

void FUN_00843f80(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  param_2[3] = param_3[3];
  param_2[4] = param_3[4];
  uVar2 = param_3[6];
  uVar3 = param_3[7];
  uVar4 = param_3[8];
  param_2[5] = param_3[5];
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  param_2[8] = uVar4;
  param_2[9] = 0;
  param_2[10] = 0;
  if (param_3[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[9] = param_3[9];
  param_2[10] = param_3[10];
  param_2[0xb] = 0;
  param_2[0xc] = 0;
  if (param_3[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[0xb] = param_3[0xb];
  param_2[0xc] = param_3[0xc];
  param_2[0xd] = param_3[0xd];
  *(undefined *)(param_2 + 0xe) = *(undefined *)(param_3 + 0xe);
  return;
}



/* FUNCTION 12888 ; VA 0x00844010 ; FUN_00844010 */

int __fastcall FUN_00844010(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  iVar1 = *param_1;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  uVar3 = FUN_00841df0(iVar1,puVar2);
  if (param_1[1] != 0x71c71c6) {
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    return *(int *)(*param_1 + 4) + 8;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 12889 ; VA 0x00844060 ; FUN_00844060 */

int FUN_00844060(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d01590();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 12890 ; VA 0x008440a0 ; FUN_008440a0 */

int __fastcall FUN_008440a0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00d01590(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 12891 ; VA 0x00844100 ; FUN_00844100 */

undefined4 __thiscall
FUN_00844100(int param_1,int *param_2,int *param_3,int *param_4,int *param_5,undefined4 *param_6,
            int *param_7,int *param_8,int *param_9,int *param_10,int *param_11,int *param_12,
            int *param_13,int param_14,int param_15,int param_16,int param_17,int param_18,
            int param_19)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  undefined8 uVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7454;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar4 = &stack0xffffffb0;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4838) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4838), puVar4 = puStack_14,
     DAT_01eb4838 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","create",0xffffffff);
    DAT_01eb4834 = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eb4830 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb4838);
    puVar4 = puStack_14;
  }
  puStack_14 = puVar4;
  uStack_20 = DAT_01eb4830;
  uStack_2c = DAT_01eb4830;
  uStack_1c = DAT_01eb4834;
  uStack_28 = DAT_01eb4834;
  uVar9 = FUN_0152d930(DAT_01eb4830,DAT_01eb4834);
  uStack_8 = 2;
  if (param_14 != 0) {
    piVar5 = (int *)(**(code **)(**(int **)(*(int *)(param_1 + 4) + 0x3c) + 0x3c))
                              (auStack_34,0,param_14 * 0x2c,0x2c,0);
    iVar11 = *piVar5;
    iVar8 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *param_2 = iVar11;
    piVar5 = (int *)param_2[1];
    param_2[1] = iVar8;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar11 = piVar5[1] + -1;
      piVar5[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar11 = piVar5[2] + -1;
        piVar5[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_30[1] + -1;
      piStack_30[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar11 = *piVar1 + -1;
        *piVar1 = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  uVar13 = 0;
  uVar12 = 2;
  iVar11 = param_18 * 2;
  uVar10 = 1;
  puVar6 = (undefined4 *)
           (**(code **)(**(int **)(*(int *)(param_1 + 4) + 0x3c) + 0x3c))(auStack_34,1,iVar11,2,0);
  uVar7 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *param_6 = uVar7;
  piVar5 = (int *)param_6[1];
  param_6[1] = uVar2;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar8 = piVar5[1] + -1;
    piVar5[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar8 = piVar5[2] + -1;
      piVar5[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_30[1] + -1;
    piStack_30[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if ((param_16 != 0) && (param_19 != 0)) {
    uVar7 = (**(code **)(**(int **)(*(int *)(iStack_18 + 4) + 0x3c) + 0x3c))
                      (auStack_34,0,param_16 * 0x18,0x18,0);
    FUN_005587e0(uVar7);
    piVar5 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uVar7 = (**(code **)(**(int **)(*(int *)(iStack_18 + 4) + 0x3c) + 0x3c))
                      (auStack_34,1,param_19 * 2,2,0);
    FUN_005587e0(uVar7);
    piVar5 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if (param_15 != 0) {
    piVar5 = (int *)(**(code **)(**(int **)(*(int *)(iStack_18 + 4) + 0x3c) + 0x3c))
                              (auStack_34,0,param_15 * 0x34,0x34,0);
    iVar8 = *piVar5;
    iVar3 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *param_3 = iVar8;
    piVar5 = (int *)param_3[1];
    param_3[1] = iVar3;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar8 = piVar5[1] + -1;
      piVar5[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar8 = piVar5[2] + -1;
        piVar5[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  if ((param_17 != 0) && (param_19 != 0)) {
    uVar7 = (**(code **)(**(int **)(*(int *)(iStack_18 + 4) + 0x3c) + 0x3c))
                      (auStack_34,0,param_17 << 5,0x20,0);
    FUN_005587e0(uVar7);
    piVar5 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar8 = *piVar1 + -1;
        *piVar1 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uVar7 = (**(code **)(**(int **)(*(int *)(iStack_18 + 4) + 0x3c) + 0x3c))
                      (auStack_34,1,param_19 * 2,2,0);
    FUN_005587e0(uVar7);
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_30[1] + -1;
      piStack_30[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar5 = piStack_30 + 2;
        iVar8 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  uStack_8 = 1;
  if ((int *)*param_2 != (int *)0x0) {
    iVar8 = (**(code **)(*(int *)*param_2 + 0x10))();
    *param_8 = iVar8;
  }
  iVar8 = (**(code **)(*(int *)*param_6 + 0x10))();
  *param_12 = iVar8;
  if ((int *)*param_4 != (int *)0x0) {
    iVar8 = (**(code **)(*(int *)*param_4 + 0x10))();
    *param_10 = iVar8;
  }
  if ((int *)*param_3 != (int *)0x0) {
    iVar8 = (**(code **)(*(int *)*param_3 + 0x10))();
    *param_9 = iVar8;
  }
  if ((int *)*param_5 != (int *)0x0) {
    iVar8 = (**(code **)(*(int *)*param_5 + 0x10))();
    *param_11 = iVar8;
  }
  if ((int *)*param_7 != (int *)0x0) {
    iVar8 = (**(code **)(*(int *)*param_7 + 0x10))();
    *param_13 = iVar8;
  }
  if (((int *)*param_2 == (int *)0x0) || (*param_8 != 0)) {
    if (((((*param_3 == 0) || (*param_9 != 0)) && (*param_12 != 0)) &&
        (((*param_4 == 0 || (*param_10 != 0)) && ((*param_7 == 0 || (*param_13 != 0)))))) &&
       (((*param_3 == 0 || (*param_9 != 0)) && ((*param_5 == 0 || (*param_11 != 0)))))) {
      uStack_8 = 6;
      FUN_0152dda0(uStack_20,uStack_1c,uVar9);
      ExceptionList = pvStack_10;
      return 1;
    }
    if (*param_8 != 0) {
      (**(code **)(*(int *)*param_2 + 0x14))();
    }
  }
  if (*param_10 != 0) {
    (**(code **)(*(int *)*param_4 + 0x14))();
  }
  if ((int *)*param_3 != (int *)0x0) {
    (**(code **)(*(int *)*param_3 + 0x14))();
  }
  if ((int *)*param_5 != (int *)0x0) {
    (**(code **)(*(int *)*param_5 + 0x14))();
  }
  if (*param_12 != 0) {
    (**(code **)(*(int *)*param_6 + 0x14))();
  }
  if (*param_13 != 0) {
    (**(code **)(*(int *)*param_7 + 0x14))();
  }
  if (DAT_01f6dcc0 != '\0') {
    FUN_01677490(DAT_01f6dcc0,"Error locking part geometry buffers: %d vertices, %d indices",
                 param_14 + param_15,param_18,0);
  }
  FUN_0086f2f0(3,"Failed to lock %d kB VRAM for part render data",
               ((uint)(param_14 * 0x2c) >> 10) + ((uint)(param_15 * 0x34) >> 10));
  uStack_8 = 5;
  FUN_0152dda0(uStack_20,uStack_1c,uVar9);
  uVar7 = FUN_008446dc(uVar10,iVar11,uVar12,uVar13);
  return uVar7;
}



/* FUNCTION 12892 ; VA 0x00844651 ; Catch@00844651 */

undefined * Catch_00844651(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x20);
  if (DAT_01f6dcc0 != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating part geometry buffers: %s",uVar2);
    if (DAT_01f6dcc0 != '\0') {
      FUN_01677490(DAT_01f6dcc0,"Geometry: %d vertices, %d indices",
                   *(undefined4 *)(unaff_EBP + 0x38),*(undefined4 *)(unaff_EBP + 0x48),0);
    }
  }
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_0086f2f0(3,"Failed to allocate %d kB VRAM for part render data: %s",
               (uint)(*(int *)(unaff_EBP + 0x38) * 0x2c) >> 10,uVar2);
  return &DAT_008446c1;
}



/* FUNCTION 12893 ; VA 0x008446dc ; FUN_008446dc */

undefined FUN_008446dc(void)

{
  int unaff_EBP;
  
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 0;
}



/* FUNCTION 12894 ; VA 0x00844750 ; FUN_00844750 */

undefined4 * __thiscall
FUN_00844750(undefined4 *param_1,int param_2,int param_3,int param_4,uint param_5,char param_6,
            undefined4 param_7)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b74b1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0xffffffff;
  param_1[1] = param_2;
  FUN_01154090(param_3);
  param_1[0x38] = param_4;
  param_1[0x39] = 0;
  param_1[0x3a] = param_7;
  uStack_8 = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  uVar1 = FUN_00845d90();
  param_1[0x3c] = uVar1;
  uStack_8._0_1_ = 1;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  uVar1 = FUN_00845d90();
  param_1[0x3e] = uVar1;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((DAT_01d622b0 == '\0') && (DAT_01d622a8 != '\0')) && (param_3 != 0)) {
    FUN_0097bf90(param_3);
  }
  if ((uint)((int)(param_1[0x42] - param_1[0x40]) >> 5) < param_5) {
    if (0x7ffffff < param_5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00846050(param_5);
  }
  if ((uint)((int)(param_1[0x45] - param_1[0x43]) / 0x14) < param_5) {
    if (0xccccccc < param_5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_008460a0(param_5);
  }
  if ((uint)((int)(param_1[0x48] - param_1[0x46]) / 0x30) < param_5) {
    if (0x5555555 < param_5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00846110(param_5);
  }
  if ((param_6 == '\0') && (iVar2 = *(int *)(*(int *)(param_2 + 0x520) + 0x20), iVar2 != 0)) {
    param_1[0x39] = iVar2;
  }
  else {
    param_1[0x39] = 1;
  }
  iVar2 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  *(undefined *)(param_1 + 0x3b) = *(undefined *)(iVar2 + 0x38);
  if (param_4 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00d71a00();
  }
  param_1[0x4a] = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12895 ; VA 0x00844980 ; FUN_00844980 */

undefined4 * __thiscall
FUN_00844980(undefined4 *param_1,undefined4 param_2,int param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  short *psVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b751c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00841300(param_2,(param_3 != 0) * '\x02' + '\x04');
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  *param_1 = RBX::Graphics::FastCluster_NEW::vftable;
  param_1[0x1d] = RBX::Graphics::FastCluster_NEW::vftable;
  param_1[0x25] = 0xffffffff;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = param_3;
  param_1[0x33] = param_4;
  param_1[0x34] = 0;
  *(char *)(param_1 + 0x35) = (char)param_5;
  *(undefined4 *)((int)param_1 + 0xd5) = 0;
  *(undefined *)((int)param_1 + 0xd9) = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  uStack_8 = 6;
  if (param_4 != (int *)0x0) {
    iVar3 = (**(code **)(*param_4 + 0x14))();
    if (iVar3 != 0) {
      uVar2 = 1;
      goto LAB_00844b16;
    }
  }
  uVar2 = 0;
LAB_00844b16:
  *(undefined *)(param_1 + 0x36) = uVar2;
  if (param_3 == 0) {
    psVar4 = (short *)(**(code **)(*param_4 + 4))(param_5);
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: create (grid %dx%dx%d, flags %d)",param_1,
                   (int)*psVar4,(int)psVar4[1],(int)psVar4[2],psVar4[3]);
    }
  }
  else {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,"FastCluster[%p]: create (humanoid %p)",param_1,param_3,0);
    }
    if (DAT_01d622b0 != '\0') {
      iVar3 = FUN_0097bf90(param_3);
      if (iVar3 != 0) {
        *(bool *)((int)param_1 + 0xd7) = *(int *)(param_3 + 0x34) == iVar3;
      }
    }
  }
  if ((char)param_5 == '\0') {
    FUN_007c7840(param_1 + 0x1d,2);
  }
  if (param_1[0x32] == 0) {
    iVar3 = (uint)(*(char *)(param_1 + 0x35) != '\0') * 8 + 0x60;
  }
  else {
    iVar3 = 0x70;
  }
  piVar1 = (int *)(*(int *)(param_1[2] + 0x524) + iVar3);
  *piVar1 = *piVar1 + 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12896 ; VA 0x00844c00 ; FUN_00844c00 */

undefined4 * __thiscall FUN_00844c00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  return param_1;
}



/* FUNCTION 12897 ; VA 0x00844c60 ; FUN_00844c60 */

void __fastcall FUN_00844c60(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  piVar4 = (int *)*param_1;
  piVar6 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar4 = (int *)*param_1;
  if (piVar6 != piVar4) {
    do {
      iVar1 = piVar6[6];
      piVar2 = (int *)*piVar6;
      if (iVar1 != 0) {
        uVar5 = piVar6[8] - iVar1 & 0xfffffffc;
        iVar3 = iVar1;
        if (0xfff < uVar5) {
          iVar3 = *(int *)(iVar1 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar5);
        piVar6[6] = 0;
        piVar6[7] = 0;
        piVar6[8] = 0;
      }
      FUN_00844d90();
      if ((undefined4 *)piVar6[2] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar6[2])(1);
      }
      FUN_01674ea0(piVar6,0x24);
      piVar4 = (int *)*param_1;
      piVar6 = piVar2;
    } while (piVar2 != piVar4);
  }
  FUN_01674ea0(piVar4,0x24);
  return;
}



/* FUNCTION 12898 ; VA 0x00844d10 ; FUN_00844d10 */

void __fastcall FUN_00844d10(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00845fb0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12899 ; VA 0x00844d70 ; FUN_00844d70 */

void __fastcall FUN_00844d70(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_00845070();
    FUN_01674ea0(iVar1,0x44);
  }
  return;
}



/* FUNCTION 12900 ; VA 0x00844d90 ; FUN_00844d90 */

void __fastcall FUN_00844d90(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056b650();
        iVar2 = iVar2 + 0x3c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x3c) * 0x3c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12901 ; VA 0x00844e20 ; FUN_00844e20 */

void __fastcall FUN_00844e20(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 0x14);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        piVar1 = *(int **)(iVar4 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0x24;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x24) * 0x24;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12902 ; VA 0x00844ee0 ; thunk_FUN_00846180 */

void __fastcall thunk_FUN_00846180(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0x20);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar3 = *piVar4 - iVar1 & 0xfffffffc;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008462a6;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar1 = piVar4[-7];
        if (iVar1 != 0) {
          uVar3 = piVar4[-5] - iVar1 & 0xfffffff0;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008462a6;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-7] = 0;
          piVar4[-6] = 0;
          piVar4[-5] = 0;
        }
        iVar5 = iVar5 + 0x28;
        piVar4 = piVar4 + 10;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar5) / 0x28) * 0x28;
    iVar6 = iVar5;
    if (0xfff < uVar3) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_008462a6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12903 ; VA 0x00844ef0 ; FUN_00844ef0 */

void FUN_00844ef0(void)

{
  thunk_FUN_007c4590();
  return;
}



/* FUNCTION 12904 ; VA 0x00844f00 ; FUN_00844f00 */

void FUN_00844f00(void)

{
  FUN_0056b650();
  return;
}



/* FUNCTION 12905 ; VA 0x00844f10 ; FUN_00844f10 */

void __fastcall FUN_00844f10(undefined4 *param_1)

{
  param_1[0x1d] = RBX::Graphics::FastCluster::vftable;
  *param_1 = RBX::Graphics::FastCluster::vftable;
  FUN_01158110();
  FUN_00841420();
  return;
}



/* FUNCTION 12906 ; VA 0x00844f30 ; FUN_00844f30 */

void __fastcall FUN_00844f30(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00764680();
  FUN_007c27b0();
  FUN_00617bc0();
  iVar2 = *(int *)(param_1 + 0x100);
  if (iVar2 != 0) {
    uVar4 = *(int *)(param_1 + 0x108) - iVar2 & 0xffffffe0;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    *(undefined4 *)(param_1 + 0x100) = 0;
    *(undefined4 *)(param_1 + 0x104) = 0;
    *(undefined4 *)(param_1 + 0x108) = 0;
  }
  iVar2 = *(int *)(param_1 + 0xf8);
  piVar1 = (int *)(param_1 + 0xf8);
  uStack_8 = 0;
  FUN_00845fb0(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  FUN_01674ea0(*piVar1,0x38);
  iVar2 = *(int *)(param_1 + 0xf0);
  piVar1 = (int *)(param_1 + 0xf0);
  uStack_8 = 1;
  FUN_00845fb0(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  FUN_01674ea0(*piVar1,0x38);
  FUN_00777180();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12907 ; VA 0x00845070 ; FUN_00845070 */

void __fastcall FUN_00845070(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017949a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x40);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x3c);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 2;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x38);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x34);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x30);
  if (iVar4 != 0) {
    FUN_00845420();
    FUN_01674ea0(iVar4,0x9c);
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    FUN_00845a30(*(int *)(param_1 + 0x2c));
  }
  iVar4 = *(int *)(param_1 + 0x28);
  if (iVar4 != 0) {
    FUN_007c27b0();
    FUN_01674ea0(iVar4,0xc);
  }
  if (*(int *)(param_1 + 0x24) != 0) {
    FUN_00845ae0(*(int *)(param_1 + 0x24));
  }
  piVar1 = *(int **)(param_1 + 0x20);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_007c27b0();
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12908 ; VA 0x008451f0 ; FUN_008451f0 */

void __fastcall FUN_008451f0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar1 = param_1 + 0x1d;
  ExceptionList = &pvStack_10;
  *puVar1 = RBX::Graphics::FastCluster_NEW::vftable;
  *param_1 = RBX::Graphics::FastCluster_NEW::vftable;
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: unbind (%d parts, %d own connections)",param_1,
                 (int)(param_1[0x2a] - param_1[0x29]) >> 3,(int)(param_1[0x21] - param_1[0x20]) >> 2
                );
  }
  FUN_011590c0();
  if (param_1[0x32] == 0) {
    iVar4 = (uint)(*(char *)(param_1 + 0x35) != '\0') * 8 + 100;
  }
  else {
    iVar4 = 0x74;
  }
  piVar2 = (int *)(iVar4 + *(int *)(param_1[2] + 0x524));
  *piVar2 = *piVar2 - ((int)(param_1[0x2a] - param_1[0x29]) >> 3);
  iVar4 = param_1[0x29];
  uVar6 = 0;
  if (param_1[0x2a] - iVar4 >> 3 != 0) {
    do {
      (**(code **)(**(int **)(iVar4 + 4 + uVar6 * 8) + 0x40))();
      puVar3 = *(undefined4 **)(iVar4 + 4 + uVar6 * 8);
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)(1);
      }
      uVar6 = uVar6 + 1;
      iVar4 = param_1[0x29];
    } while (uVar6 < (uint)(param_1[0x2a] - iVar4 >> 3));
  }
  param_1[0x27] = param_1[0x26];
  param_1[0x2a] = param_1[0x29];
  param_1[0x2d] = param_1[0x2c];
  iVar4 = param_1[0x34];
  param_1[0x34] = 0;
  if (iVar4 != 0) {
    FUN_00845070();
    FUN_01674ea0(iVar4,0x44);
  }
  param_1[0x30] = param_1[0x2f];
  if (param_1[0x32] == 0) {
    iVar4 = (uint)(*(char *)(param_1 + 0x35) != '\0') * 8 + 0x60;
  }
  else {
    iVar4 = 0x70;
  }
  piVar2 = (int *)(iVar4 + *(int *)(param_1[2] + 0x524));
  *piVar2 = *piVar2 + -1;
  FUN_007c78a0(puVar1,2);
  FUN_007b2650();
  FUN_0073e270();
  iVar4 = param_1[0x34];
  if (iVar4 != 0) {
    FUN_00845070();
    FUN_01674ea0(iVar4,0x44);
  }
  FUN_007c27b0();
  FUN_007c27b0();
  iVar4 = param_1[0x29];
  if (iVar4 != 0) {
    uVar6 = param_1[0x2b] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
    param_1[0x2b] = 0;
  }
  FUN_0072e310();
  *param_1 = RBX::Graphics::FastCluster::vftable;
  *puVar1 = RBX::Graphics::FastCluster::vftable;
  FUN_01158110();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12909 ; VA 0x00845420 ; FUN_00845420 */

void __fastcall FUN_00845420(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00844e20();
  iVar2 = *(int *)(param_1 + 0x88);
  uStack_8 = 0;
  if (iVar2 != 0) {
    uVar3 = *(uint *)(param_1 + 0x84);
    do {
      uVar3 = (uVar3 + 1) % *(uint *)(param_1 + 0x80);
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    *(undefined4 *)(param_1 + 0x88) = 0;
    *(uint *)(param_1 + 0x84) = uVar3;
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x8c));
  iVar2 = *(int *)(param_1 + 0x78);
  uStack_8 = 1;
  if (iVar2 != 0) {
    uVar3 = *(uint *)(param_1 + 0x74);
    do {
      uVar3 = (uVar3 + 1) % *(uint *)(param_1 + 0x70);
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(uint *)(param_1 + 0x74) = uVar3;
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x7c));
  iVar2 = *(int *)(param_1 + 0x68);
  uStack_8 = 2;
  if (iVar2 != 0) {
    uVar3 = *(uint *)(param_1 + 100);
    do {
      uVar3 = (uVar3 + 1) % *(uint *)(param_1 + 0x60);
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    *(undefined4 *)(param_1 + 0x68) = 0;
    *(uint *)(param_1 + 100) = uVar3;
  }
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x6c));
  iVar2 = *(int *)(param_1 + 0x54);
  if (iVar2 != 0) {
    uVar3 = *(int *)(param_1 + 0x5c) - iVar2 & 0xfffffffc;
    iVar1 = iVar2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(iVar2 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar2 - iVar1) - 4U) goto LAB_00845685;
    }
    FUN_01674ea0(iVar1,uVar3);
    *(undefined4 *)(param_1 + 0x54) = 0;
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x3c);
  if (iVar2 != 0) {
    uVar3 = *(int *)(param_1 + 0x44) - iVar2 & 0xfffffff8;
    iVar1 = iVar2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(iVar2 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar2 - iVar1) - 4U) goto LAB_00845685;
    }
    FUN_01674ea0(iVar1,uVar3);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x30);
  if (iVar2 != 0) {
    uVar3 = *(int *)(param_1 + 0x38) - iVar2 & 0xfffffffc;
    iVar1 = iVar2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(iVar2 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar2 - iVar1) - 4U) goto LAB_00845685;
    }
    FUN_01674ea0(iVar1,uVar3);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if (iVar2 != 0) {
    uVar3 = *(int *)(param_1 + 0x2c) - iVar2 & 0xfffffffc;
    iVar1 = iVar2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(iVar2 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar2 - iVar1) - 4U) goto LAB_00845685;
    }
    FUN_01674ea0(iVar1,uVar3);
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != 0) {
    uVar3 = *(int *)(param_1 + 0x20) - iVar2 & 0xfffffffc;
    iVar1 = iVar2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(iVar2 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar2 - iVar1) - 4U) {
LAB_00845685:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00846180();
  FUN_00844e20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12910 ; VA 0x00845690 ; FUN_00845690 */

void __fastcall FUN_00845690(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar2 = *(int **)(param_1 + 0xa0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0x98);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_00844e20();
  iVar3 = *(int *)(param_1 + 0x7c);
  if (iVar3 != 0) {
    uVar5 = *(int *)(param_1 + 0x84) - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00845803;
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x7c) = 0;
    *(undefined4 *)(param_1 + 0x80) = 0;
    *(undefined4 *)(param_1 + 0x84) = 0;
  }
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  thunk_FUN_00577a40();
  iVar3 = *(int *)(param_1 + 0x34);
  if (iVar3 != 0) {
    uVar5 = *(int *)(param_1 + 0x3c) - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00845803;
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
    *(undefined4 *)(param_1 + 0x3c) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x28);
  if (iVar3 != 0) {
    uVar5 = *(int *)(param_1 + 0x30) - iVar3 & 0xfffffffc;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00845803:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
  }
  FUN_005e6280();
  FUN_005e6280();
  FUN_00777020();
  FUN_016790b0();
  return;
}



/* FUNCTION 12911 ; VA 0x00845810 ; thunk_FUN_007c27b0 */

void __fastcall thunk_FUN_007c27b0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12912 ; VA 0x00845820 ; FUN_00845820 */

void __fastcall FUN_00845820(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  FUN_007c27b0();
  iVar1 = *(int *)(param_1 + 0x30);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x38) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  return;
}



/* FUNCTION 12913 ; VA 0x008458b0 ; FUN_008458b0 */

uint * __thiscall FUN_008458b0(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint *puStack_8;
  
  puVar1 = (undefined4 *)*param_1;
  puVar6 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    uVar2 = *param_2;
    puVar3 = (undefined4 *)puVar1[1];
    do {
      if (((uint)puVar3[4] < uVar2) ||
         (((uint)puVar3[4] <= uVar2 && ((int)puVar3[5] < (int)param_2[1])))) {
        puVar4 = (undefined4 *)puVar3[2];
      }
      else {
        puVar4 = (undefined4 *)*puVar3;
        puVar6 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if (puVar6 != puVar1) {
      if (((uint)puVar6[4] <= uVar2) &&
         (((uint)puVar6[4] < uVar2 || ((int)puVar6[5] <= (int)param_2[1])))) {
        return puVar6 + 6;
      }
    }
  }
  puStack_8 = param_2;
  iVar5 = FUN_00841e90(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_008427b0(&param_2,puVar6,iVar5 + 0x10,iVar5);
  return param_2 + 6;
}



/* FUNCTION 12914 ; VA 0x00845950 ; FUN_00845950 */

int FUN_00845950(int param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = (undefined4 *)(param_1 + 0x1c);
    do {
      FUN_0170d1f0(param_1,0,0x2c);
      puVar1[-5] = 0x7f7fffff;
      puVar1[-4] = 0x7f7fffff;
      puVar1[-3] = 0x7f7fffff;
      param_1 = param_1 + 0x2c;
      puVar1[-2] = 0xff7fffff;
      puVar1[-1] = 0xff7fffff;
      *puVar1 = 0xff7fffff;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0xb;
    } while (param_2 != 0);
  }
  return param_1;
}



/* FUNCTION 12915 ; VA 0x008459b0 ; FUN_008459b0 */

void FUN_008459b0(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 0xb;
    do {
      *param_1 = 0x3f800000;
      puVar1[-10] = 0;
      param_1 = param_1 + 0xc;
      puVar1[-9] = 0;
      puVar1[-8] = 0;
      puVar1[-7] = 0x3f800000;
      puVar1[-6] = 0;
      puVar1[-5] = 0;
      puVar1[-4] = 0;
      puVar1[-3] = 0x3f800000;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0xc;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 12916 ; VA 0x00845a30 ; FUN_00845a30 */

void FUN_00845a30(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1 != 0) {
    FUN_007c27b0();
    FUN_007c27b0();
    FUN_007c27b0();
    FUN_007c27b0();
    FUN_007c27b0();
    FUN_007c27b0();
    iVar1 = *(int *)(param_1 + 0x30);
    if (iVar1 != 0) {
      uVar3 = *(int *)(param_1 + 0x38) - iVar1 & 0xfffffffc;
      iVar2 = iVar1;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iVar1 + -4);
        uVar3 = uVar3 + 0x23;
        if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
      *(undefined4 *)(param_1 + 0x30) = 0;
      *(undefined4 *)(param_1 + 0x34) = 0;
      *(undefined4 *)(param_1 + 0x38) = 0;
    }
    FUN_01674ea0(param_1,0x90);
  }
  return;
}



/* FUNCTION 12917 ; VA 0x00845ae0 ; FUN_00845ae0 */

void FUN_00845ae0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    piVar5 = *(int **)(param_1 + 0x24);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[2] + -1;
      ExceptionList = &pvStack_10;
      piVar5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = *(int **)(param_1 + 0x14);
    if (piVar5 != (int *)0x0) {
      piVar6 = *(int **)(param_1 + 0x18);
      if (piVar5 != piVar6) {
        do {
          uStack_8 = 0;
          FUN_01679490();
          iVar3 = *piVar5;
          if (iVar3 != 0) {
            piVar1 = (int *)(iVar3 + 4);
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              FUN_01674ea0(iVar3);
            }
          }
          piVar5 = piVar5 + 1;
          uStack_8 = 0xffffffff;
        } while (piVar5 != piVar6);
        piVar5 = *(int **)(param_1 + 0x14);
      }
      uVar4 = *(int *)(param_1 + 0x1c) - (int)piVar5 & 0xfffffffc;
      piVar6 = piVar5;
      if (0xfff < uVar4) {
        piVar6 = (int *)piVar5[-1];
        uVar4 = uVar4 + 0x23;
        if (0x1f < (uint)((int)piVar5 + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar6,uVar4);
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined4 *)(param_1 + 0x18) = 0;
      *(undefined4 *)(param_1 + 0x1c) = 0;
    }
    FUN_016790b0();
    FUN_016790b0();
    FUN_016790b0();
    FUN_016790b0();
    FUN_016790b0();
    FUN_01674ea0(param_1,0x2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12918 ; VA 0x00845c00 ; FUN_00845c00 */

undefined4 FUN_00845c00(uint *param_1,uint *param_2)

{
  if ((*param_2 <= *param_1) && ((*param_2 < *param_1 || ((int)param_2[1] <= (int)param_1[1])))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 12919 ; VA 0x00845c25 ; FUN_00845c25 */

void FUN_00845c25(void)

{
  FUN_00845c40();
  return;
}



/* FUNCTION 12920 ; VA 0x00845c2d ; FUN_00845c2d */

void FUN_00845c2d(void)

{
  FUN_00845d30();
  return;
}



/* FUNCTION 12921 ; VA 0x00845c40 ; FUN_00845c40 */

undefined4 * __thiscall FUN_00845c40(undefined4 *param_1,byte param_2)

{
  param_1[0x1d] = RBX::Graphics::FastCluster::vftable;
  *param_1 = RBX::Graphics::FastCluster::vftable;
  FUN_01158110();
  FUN_00841420();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 12922 ; VA 0x00845c80 ; FUN_00845c80 */

undefined4 __thiscall FUN_00845c80(undefined4 param_1,byte param_2)

{
  FUN_01158110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 12923 ; VA 0x00845cb0 ; FUN_00845cb0 */

undefined4 * __thiscall FUN_00845cb0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::Graphics::FastClusterEntity_NEW::vftable;
  iVar1 = param_1[0x13];
  if (iVar1 != 0) {
    uVar3 = param_1[0x15] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  FUN_00841390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x74);
  }
  return param_1;
}



/* FUNCTION 12924 ; VA 0x00845d30 ; FUN_00845d30 */

undefined4 __thiscall FUN_00845d30(undefined4 param_1,byte param_2)

{
  FUN_008451f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf4);
  }
  return param_1;
}



/* FUNCTION 12925 ; VA 0x00845d60 ; FUN_00845d60 */

undefined4 __thiscall FUN_00845d60(undefined4 param_1,byte param_2)

{
  FUN_00845690();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xac);
  }
  return param_1;
}



/* FUNCTION 12926 ; VA 0x00845d90 ; FUN_00845d90 */

void FUN_00845d90(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x38);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 12927 ; VA 0x00845db0 ; FUN_00845db0 */

void __fastcall FUN_00845db0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x38);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 12928 ; VA 0x00845dd0 ; FUN_00845dd0 */

void __thiscall FUN_00845dd0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x14) * 0x14;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x14;
  param_1[2] = param_2 + param_4 * 0x14;
  return;
}



/* FUNCTION 12929 ; VA 0x00845e50 ; FUN_00845e50 */

void __thiscall FUN_00845e50(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x30 + param_2;
  param_1[2] = param_4 * 0x30 + param_2;
  return;
}



/* FUNCTION 12930 ; VA 0x00845ed0 ; FUN_00845ed0 */

void __fastcall FUN_00845ed0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_00845690();
    FUN_01674ea0(iVar1,0xac);
  }
  return;
}



/* FUNCTION 12931 ; VA 0x00845ef0 ; FUN_00845ef0 */

void FUN_00845ef0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 3;
    do {
      piVar1 = (int *)piVar3[2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = (int *)piVar3[-2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      piVar1 = piVar3 + 6;
      piVar3 = piVar3 + 9;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 12932 ; VA 0x00845f60 ; FUN_00845f60 */

void FUN_00845f60(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_00844c60();
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 12933 ; VA 0x00845fb0 ; FUN_00845fb0 */

undefined4 __thiscall FUN_00845fb0(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_00845fb0(param_2[2]);
    piVar2 = (int *)*param_2;
    FUN_00844c60();
    piVar3 = (int *)param_2[7];
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(param_2,0x38);
    param_2 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return param_1;
}



/* FUNCTION 12934 ; VA 0x00846030 ; FUN_00846030 */

void FUN_00846030(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 12935 ; VA 0x00846050 ; FUN_00846050 */

void __thiscall FUN_00846050(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_00577f40(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar5 = puVar9[5];
      uVar6 = puVar9[6];
      uVar7 = puVar9[7];
      puVar1 = (undefined4 *)(iVar10 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      puVar9 = puVar9 + 8;
    } while (puVar9 != puVar4);
  }
  FUN_007fdb40(iVar8,iVar2 - iVar3 >> 5,param_2);
  return;
}



/* FUNCTION 12936 ; VA 0x008460a0 ; FUN_008460a0 */

void __thiscall FUN_008460a0(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_14 [4];
  int iStack_10;
  int *piStack_c;
  undefined uStack_5;
  
  iStack_10 = (param_1[1] - *param_1) / 0x14;
  piStack_c = param_1;
  uVar2 = FUN_00618130(param_2);
  iVar1 = *param_1;
  FUN_0055b6b0(&uStack_5,auStack_14,auStack_14);
  FUN_0170cc70(uVar2,iVar1,piStack_c[1] - iVar1);
  FUN_00845dd0(uVar2,iStack_10,param_2);
  return;
}



/* FUNCTION 12937 ; VA 0x00846110 ; FUN_00846110 */

void __thiscall FUN_00846110(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_00847730(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar5 = puVar9[5];
      uVar6 = puVar9[6];
      uVar7 = puVar9[7];
      puVar1 = (undefined4 *)(iVar10 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar5 = puVar9[9];
      uVar6 = puVar9[10];
      uVar7 = puVar9[0xb];
      puVar1 = (undefined4 *)(iVar10 + 0x20 + (int)puVar9);
      *puVar1 = puVar9[8];
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      puVar9 = puVar9 + 0xc;
    } while (puVar9 != puVar4);
  }
  FUN_00845e50(iVar8,(iVar2 - iVar3) / 0x30,param_2);
  return;
}



/* FUNCTION 12938 ; VA 0x00846180 ; FUN_00846180 */

void __fastcall FUN_00846180(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0x20);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar3 = *piVar4 - iVar1 & 0xfffffffc;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008462a6;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar1 = piVar4[-7];
        if (iVar1 != 0) {
          uVar3 = piVar4[-5] - iVar1 & 0xfffffff0;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_008462a6;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-7] = 0;
          piVar4[-6] = 0;
          piVar4[-5] = 0;
        }
        iVar5 = iVar5 + 0x28;
        piVar4 = piVar4 + 10;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar5) / 0x28) * 0x28;
    iVar6 = iVar5;
    if (0xfff < uVar3) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_008462a6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12939 ; VA 0x008462b0 ; FUN_008462b0 */

void FUN_008462b0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      *param_3 = *param_1;
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      param_3[4] = param_1[4];
      param_3[5] = uVar2;
      param_3[6] = uVar3;
      param_3[7] = uVar4;
      puVar1 = param_1 + 8;
      uVar2 = param_1[9];
      uVar3 = param_1[10];
      uVar4 = param_1[0xb];
      param_1 = param_1 + 0xc;
      param_3[8] = *puVar1;
      param_3[9] = uVar2;
      param_3[10] = uVar3;
      param_3[0xb] = uVar4;
      param_3 = param_3 + 0xc;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12940 ; VA 0x008462f0 ; FUN_008462f0 */

void FUN_008462f0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      puVar1 = (undefined4 *)(param_3 + (int)param_1);
      *puVar1 = *param_1;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      puVar1 = (undefined4 *)(param_3 + 0x10 + (int)param_1);
      *puVar1 = param_1[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[9];
      uVar3 = param_1[10];
      uVar4 = param_1[0xb];
      puVar1 = (undefined4 *)(param_3 + 0x20 + (int)param_1);
      *puVar1 = param_1[8];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      param_1 = param_1 + 0xc;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12941 ; VA 0x00846330 ; FUN_00846330 */

int __thiscall
FUN_00846330(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5,int param_6,
            uint param_7,int param_8,undefined4 param_9,undefined4 param_10)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  bool bVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 *puVar12;
  int iVar13;
  bool bVar14;
  undefined auStack_ec [76];
  int iStack_a0;
  int iStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_6c;
  undefined uStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int *piStack_50;
  uint uStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int iStack_30;
  int aiStack_2c [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b754b;
  pvStack_10 = ExceptionList;
  iStack_18 = param_1 + 8;
  if (*(int *)(param_1 + 8) == 0) {
    iStack_18 = 0;
  }
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar5 = FUN_00761230(&iStack_54,param_3,param_6,iStack_18,param_7);
  uStack_8 = 0;
  if (iStack_54 == 0) goto LAB_008468c2;
  if ((param_7 & 0x400) != 0) {
    uStack_4c = uStack_4c | 8;
  }
  if ((param_7 & 0x1000) != 0) {
    uStack_4c = uStack_4c | 0x10;
  }
  if ((uStack_4c & 0x10) == 0) {
    iStack_64 = iStack_54;
    iStack_60 = param_8;
    piVar6 = (int *)FUN_008458b0(&iStack_64);
  }
  else {
    iStack_5c = iStack_54;
    iStack_58 = param_8;
    piVar6 = (int *)FUN_008458b0(&iStack_5c);
  }
  piStack_1c = piVar6;
  if (*piVar6 == 0) {
    if (piStack_50 != (int *)0x0) {
      LOCK();
      piStack_50[1] = piStack_50[1] + 1;
      UNLOCK();
    }
    *piVar6 = iStack_54;
    piVar1 = (int *)piVar6[1];
    piVar6[1] = (int)piStack_50;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar5 = piVar1[1] + -1;
      piVar1[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piVar6[2] = param_8;
    piVar6[3] = uStack_4c;
    piVar6[4] = iStack_48;
    *(bool *)(piVar6 + 5) = param_6 != 0;
  }
  if (((param_7 & 0x20) == 0) &&
     ((iStack_18 == 0 || (cVar3 = FUN_01154e00(param_3), cVar3 == '\0')))) {
    uVar10 = 0;
  }
  else {
    uVar10 = 1;
  }
  FUN_007484a0(aiStack_2c,param_3,iStack_18,uVar10,param_10,*(undefined4 *)(iStack_14 + 0xe8));
  param_7 = param_7 >> 0xc;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iStack_30 = 0;
  iStack_18 = 0;
  if ((param_7 & 1) == 0) {
LAB_00846518:
    if ((param_8 == 9) || (param_8 == 8)) {
      if (piVar6[7] == 0) {
        iVar5 = 0;
      }
      else {
        iVar5 = *(int *)(*(int *)(piVar6[6] + 4) + 0x10);
        if (*(int *)(*(int *)(piVar6[6] + 4) + 0xc) == iVar5) {
          iVar5 = 0;
        }
        else {
          iVar5 = *(int *)(iVar5 + -0x3c);
        }
      }
      if (param_3 == iVar5) goto LAB_00846549;
      bVar14 = true;
    }
    else {
LAB_00846549:
      bVar14 = false;
    }
    piVar1 = piVar6 + 6;
    if (((piVar6[7] == 0) || (bVar14)) ||
       ((DAT_01d622a0 == '\0' &&
        ((uVar8 = (**(code **)(**(int **)(*(int *)(*piVar1 + 4) + 8) + 0x14))(), 0x7fff < uVar8 ||
         (0x7fff < *(uint *)(*(int *)(*(int *)(*piVar1 + 4) + 8) + 0x44))))))) {
LAB_0084660e:
      FUN_00844010();
    }
    else {
      iVar5 = *(int *)(*piVar1 + 4);
      bVar14 = false;
      if ((param_7 & 1) == 0) {
        bVar14 = *(int *)(*(int *)(iVar5 + 8) + 0x44) != 0;
        iStack_34 = *(int *)(iVar5 + 0x1c);
        if (((uint)(iStack_34 - *(int *)(iVar5 + 0x18) >> 2) < *(uint *)(iStack_14 + 0xe4)) ||
           (*(int *)(iStack_34 + -4) == *(int *)(param_2 * 0x20 + *(int *)(iStack_14 + 0x100))))
        goto LAB_00846604;
        bVar4 = true;
      }
      else {
        iVar5 = (**(code **)(**(int **)(iVar5 + 8) + 0x14))();
        if (iVar5 != 0) {
          bVar14 = true;
        }
LAB_00846604:
        bVar4 = false;
      }
      if ((bVar14) || (bVar4)) goto LAB_0084660e;
    }
    if ((param_7 & 1) == 0) {
      FUN_0073dcf0(*(undefined4 *)(iStack_14 + 4),param_3,param_6,piVar6[3],0xffffffff,6);
      if ((DAT_01d622a0 != '\0') &&
         (cVar3 = (**(code **)(**(int **)(*(int *)(*piVar1 + 4) + 8) + 0xc))
                            (param_3,param_6,param_4,auStack_ec,aiStack_2c,0), cVar3 == '\0')) {
        FUN_00844010();
        (**(code **)(**(int **)(*(int *)(*piVar1 + 4) + 8) + 8))
                  (param_3,param_6,param_4,auStack_ec,aiStack_2c,0);
      }
      iVar5 = *(int *)(*piVar1 + 4);
      if (DAT_01d622a0 == '\0') {
        (**(code **)(**(int **)(iVar5 + 8) + 8))(param_3,param_6,param_4,auStack_ec,aiStack_2c,0);
      }
      puVar12 = *(undefined4 **)(iVar5 + 0x1c);
      if ((*(undefined4 **)(iVar5 + 0x18) == puVar12) ||
         (puVar12[-1] != *(int *)(param_2 * 0x20 + *(int *)(iStack_14 + 0x100)))) {
        puVar9 = (undefined4 *)(param_2 * 0x20 + *(int *)(iStack_14 + 0x100));
        if (*(undefined4 **)(iVar5 + 0x20) == puVar12) {
          FUN_00595d30(puVar12,puVar9);
        }
        else {
          *puVar12 = *puVar9;
          *(int *)(iVar5 + 0x1c) = *(int *)(iVar5 + 0x1c) + 4;
        }
        puVar12 = *(undefined4 **)(iVar5 + 0x1c);
      }
      iStack_a0 = param_3;
      iStack_9c = param_6;
      uStack_98 = param_4;
      iStack_94 = param_2;
      uStack_8c = uStack_44;
      uStack_88 = uStack_40;
      uStack_84 = uStack_3c;
      uStack_80 = uStack_38;
      iStack_90 = ((int)puVar12 - *(int *)(iVar5 + 0x18) >> 2) + -1;
      FUN_00844c00(aiStack_2c);
      uStack_6c = 0xffffffff;
      uStack_68 = 6;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (*(int *)(iVar5 + 0x14) == *(int *)(iVar5 + 0x10)) {
        FUN_00842250(*(int *)(iVar5 + 0x10),&iStack_a0);
        FUN_0056b650();
      }
      else {
        FUN_00843f80(iVar5 + 0xc);
        *(int *)(iVar5 + 0x10) = *(int *)(iVar5 + 0x10) + 0x3c;
        FUN_0056b650();
      }
    }
    else if (aiStack_2c[0] != 0) {
      bVar14 = false;
      if ((((iStack_30 != 0) && (*(int *)(iStack_30 + 0x17c) == 0)) &&
          (iVar5 = FUN_00b08820(), iVar5 == 0)) && (bVar14 = false, (uStack_4c & 2) == 0)) {
        bVar14 = true;
      }
      if (param_6 == 0) {
        if (!bVar14) {
          FUN_00846b70(aiStack_2c[0] + 0x24,aiStack_2c,aiStack_2c[0] + 100,0,param_3,0,param_4,
                       piVar6,iStack_18,param_2,param_5,&iStack_54,6);
          goto LAB_008468b7;
        }
        iVar5 = 0;
      }
      else {
        iVar5 = *(int *)(param_6 + 0x70);
      }
      if (param_6 == 0) {
        iVar7 = 6;
      }
      else {
        iVar7 = *(int *)(param_6 + 0x70) + 1;
      }
      if (iVar5 < iVar7) {
        iVar13 = iVar5 * 0xc;
        do {
          iVar11 = *(int *)(aiStack_2c[0] + 0x15c + iVar13) -
                   *(int *)(aiStack_2c[0] + 0x158 + iVar13);
          iVar2 = iVar11 >> 0x1f;
          if (iVar11 / 0x48 + iVar2 != iVar2) {
            FUN_00846b70(aiStack_2c[0] + 0x158 + iVar13,aiStack_2c,aiStack_2c[0] + 0x1a0 + iVar13,0,
                         param_3,param_6,param_4,piStack_1c,iStack_18,param_2,param_5,&iStack_54,
                         iVar5);
          }
          iVar5 = iVar5 + 1;
          iVar13 = iVar13 + 0xc;
        } while (iVar5 < iVar7);
      }
    }
  }
  else {
    iVar5 = *(int *)(param_3 + 0xc);
    iVar7 = FUN_00cfb1a0();
    iStack_30 = 0;
    if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
        (uint)*(ushort *)(iVar7 + 0x1da)) {
      iStack_30 = param_3;
    }
    piVar6 = piStack_1c;
    if ((DAT_01d622c0 != '\0') ||
       ((iStack_18 = *(int *)(iStack_30 + 0xac), iStack_18 != 0 &&
        (*(char *)(iStack_18 + 0x60) != '\0')))) goto LAB_00846518;
  }
LAB_008468b7:
  iVar5 = FUN_0056b650();
LAB_008468c2:
  if (piStack_50 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_50 + 1;
    iVar7 = *piVar6;
    iVar5 = *piVar6;
    *piVar6 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar5 = (**(code **)*piStack_50)();
      LOCK();
      piVar6 = piStack_50 + 2;
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar5 = (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 12942 ; VA 0x00846900 ; FUN_00846900 */

void __thiscall FUN_00846900(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b757f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eb4564 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: addPart %p (part count was %d)",param_1,*param_2,
                 *(int *)(param_1 + 0xa8) - *(int *)(param_1 + 0xa4) >> 3);
    if (DAT_01eb4564 != '\0') {
      puVar3 = (undefined4 *)FUN_008a2380(auStack_34);
      uStack_8 = 0;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_01677650(DAT_01eb4564,"FastCluster part: %s",puVar3);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_20) {
        uVar7 = uStack_20 + 1;
        uVar6 = auStack_34[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_34[0] - 4);
          uVar7 = uStack_20 + 0x24;
          if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
    }
  }
  iVar5 = *param_2;
  iStack_1c = iVar5;
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 1;
  puStack_14 = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    if (*(int **)(param_1 + 0xcc) == (int *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = (**(code **)(**(int **)(param_1 + 0xcc) + 0x14))();
    }
    *puVar3 = RBX::GfxBinding::vftable;
    puVar3[1] = 0;
    puVar3[2] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[1] = *param_2;
    puVar3[2] = param_2[1];
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    *puVar3 = RBX::Graphics::FastClusterBinding_NEW::vftable;
    puVar3[6] = param_1;
    puVar3[7] = uVar4;
    puVar3[8] = 0;
    puVar3[9] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (((DAT_01d6c85c != '\0') && (iVar2 = *param_2, iVar2 != 0)) &&
       ((*(byte *)(iVar2 + 0xb4) & 0x40) != 0)) {
      uVar4 = FUN_00b65600(iVar2);
      puVar3[8] = uVar4;
      uVar4 = FUN_008440a0();
      puVar3[9] = uVar4;
    }
    FUN_01158150(param_2);
    *(int *)(*param_2 + 0xb0) = param_1 + 0x74;
    puStack_18 = puVar3;
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: bound part %p to binding %p (%d connections)",
                   param_1,*param_2,puVar3,(int)(puVar3[4] - puVar3[3]) >> 2,0);
    }
  }
  piVar1 = *(int **)(param_1 + 0xa8);
  uStack_8 = 0xffffffff;
  if (*(int **)(param_1 + 0xac) == piVar1) {
    FUN_00805800(piVar1,&iStack_1c);
  }
  else {
    *piVar1 = iVar5;
    piVar1[1] = (int)puStack_18;
    *(int *)(param_1 + 0xa8) = *(int *)(param_1 + 0xa8) + 8;
  }
  if (*(int *)(param_1 + 200) == 0) {
    iVar5 = (uint)(*(char *)(param_1 + 0xd4) != '\0') * 8 + 100;
  }
  else {
    iVar5 = 0x74;
  }
  piVar1 = (int *)(*(int *)(*(int *)(param_1 + 8) + 0x524) + iVar5);
  *piVar1 = *piVar1 + 1;
  *(undefined *)(param_1 + 0xd6) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12943 ; VA 0x00846b70 ; FUN_00846b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00846b70(undefined4 *param_1,int *param_2,int *param_3,int *param_4,int param_5,int *param_6,
            undefined4 param_7,undefined4 param_8,int param_9,undefined4 param_10,int param_11,
            undefined4 param_12,int param_13,undefined param_14)

{
  ushort uVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  char *pcVar9;
  float *pfVar10;
  uint *puVar11;
  uint uVar12;
  int *piVar13;
  float fVar14;
  float fVar15;
  int *piStack_2a4;
  int **ppiStack_2a0;
  undefined auStack_294 [36];
  undefined auStack_270 [36];
  undefined auStack_24c [76];
  int aiStack_200 [9];
  int aiStack_1dc [11];
  float fStack_1b0;
  float fStack_1a4;
  float fStack_198;
  float fStack_18c;
  int *piStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  int iStack_17c;
  int iStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  int iStack_164;
  int iStack_160;
  int iStack_15c;
  int iStack_158;
  int *piStack_154;
  undefined uStack_150;
  int iStack_14c;
  int iStack_148;
  int iStack_144;
  int iStack_140;
  int iStack_13c;
  int iStack_138;
  int iStack_134;
  int iStack_130;
  int iStack_12c;
  undefined8 uStack_128;
  float fStack_120;
  int iStack_11c;
  int iStack_118;
  int iStack_114;
  int iStack_110;
  int iStack_10c;
  int iStack_108;
  int iStack_104;
  int iStack_100;
  int iStack_fc;
  float fStack_f8;
  int *piStack_f4;
  float fStack_f0;
  int iStack_ec;
  int iStack_e8;
  int iStack_e4;
  int iStack_e0;
  int iStack_dc;
  int iStack_d8;
  int iStack_d4;
  int iStack_d0;
  int iStack_cc;
  float fStack_c8;
  int *piStack_c4;
  float fStack_c0;
  int iStack_bc;
  int iStack_b8;
  int iStack_b4;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  undefined8 uStack_98;
  float fStack_90;
  undefined4 uStack_8c;
  int iStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  undefined4 *puStack_38;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b759b;
  pvStack_10 = ExceptionList;
  ppiStack_2a0 = (int **)0x0;
  piStack_2a4 = (int *)0x0;
  ExceptionList = &pvStack_10;
  puStack_38 = param_1;
  FUN_0074b260(&fStack_44,param_6);
  fVar14 = fStack_40;
  if (fStack_40 <= fStack_44) {
    fVar14 = fStack_44;
  }
  fVar15 = fStack_3c;
  if (fStack_3c <= fVar14) {
    fVar15 = fVar14;
  }
  ppiStack_2a0 = *(int ***)(param_11 * 0x20 + 4 + param_1[0x40]);
  fStack_84 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar15 >> 0x20) & DAT_018c0da0._4_4_
                                      ,SUB84((double)fVar15,0) & (uint)DAT_018c0da0);
  piStack_2a4 = param_6;
  FUN_0084a0c0(&fStack_80);
  piStack_1c = (int *)0x0;
  piVar13 = (int *)((param_2[1] - *param_2) / 0x48);
  ppiStack_2a0 = (int **)*param_3;
  piStack_2a4 = (int *)0x846c20;
  piStack_20 = piVar13;
  cVar4 = FUN_01151c00();
  if (cVar4 != '\0') {
    iVar7 = *param_4;
    iVar5 = (param_4[1] - iVar7 >> 2) + -2;
    if (iVar5 < param_5) {
      param_5 = iVar5;
    }
    puVar11 = (uint *)*param_2;
    uVar8 = *puVar11;
    while (uVar8 < *(uint *)(iVar7 + param_5 * 4)) {
      piStack_1c = (int *)((int)piStack_1c + 1);
      puVar11 = puVar11 + 0x12;
      uVar8 = *puVar11;
    }
    piStack_20 = piStack_1c;
    if ((int)piStack_1c < (int)piVar13) {
      puVar11 = (uint *)(*param_2 + (int)piStack_1c * 0x48);
      do {
        param_1 = puStack_38;
        if (*(uint *)(iVar7 + 4 + param_5 * 4) <= *puVar11) break;
        piStack_20 = (int *)((int)piStack_20 + 1);
        puVar11 = puVar11 + 0x12;
      } while ((int)piStack_20 < (int)piVar13);
    }
  }
  puVar11 = (uint *)(param_9 + 0x18);
  if ((int)piStack_1c < (int)piStack_20) {
    iStack_50 = (int)piStack_1c * 0x48;
    do {
      iStack_34 = *param_2 + iStack_50;
      piVar13 = (int *)*puVar11;
      piVar2 = (int *)piVar13[1];
      piVar6 = (int *)(*(int *)(iStack_34 + 0x10) + (piVar2[7] - piVar2[6] >> 2));
      if ((int *)param_1[0x39] < piVar6) {
        piStack_2a4 = piVar13;
        ppiStack_2a0 = (int **)piVar2;
        iVar7 = FUN_00841df0();
        if (*(int *)(param_9 + 0x1c) == 0x71c71c6) goto LAB_0084771e;
        *(int *)(param_9 + 0x1c) = *(int *)(param_9 + 0x1c) + 1;
        piVar13[1] = iVar7;
        *piVar2 = iVar7;
        piVar6 = piVar13;
      }
      ppiStack_2a0 = (int **)CONCAT31((int3)((uint)piVar6 >> 8),param_14);
      piStack_2a4 = piStack_1c;
      uStack_8c = ppiStack_2a0;
      FUN_0073dcf0(param_1[1],param_6,param_7,*(undefined4 *)(param_9 + 0xc));
      if (DAT_01d622a0 != '\0') {
        ppiStack_2a0 = (int **)0x0;
        piStack_2a4 = param_3;
        cVar4 = (**(code **)(**(int **)(*(int *)(*puVar11 + 4) + 8) + 0xc))
                          (param_6,param_7,param_8,auStack_24c);
        if (cVar4 == '\0') {
          piVar13 = (int *)*puVar11;
          piVar2 = (int *)piVar13[1];
          piStack_2a4 = piVar13;
          ppiStack_2a0 = (int **)piVar2;
          iVar7 = FUN_00841df0();
          if (*(int *)(param_9 + 0x1c) == 0x71c71c6) {
LAB_0084771e:
            ppiStack_2a0 = (int **)0x18c0fdc;
                    /* WARNING: Subroutine does not return */
            piStack_2a4 = (int *)&UNK_00847728;
            FUN_016ddcd9();
          }
          ppiStack_2a0 = (int **)0x0;
          *(int *)(param_9 + 0x1c) = *(int *)(param_9 + 0x1c) + 1;
          piVar13[1] = iVar7;
          *piVar2 = iVar7;
          piStack_2a4 = param_3;
          (**(code **)(**(int **)(*(int *)(*puVar11 + 4) + 8) + 8))
                    (param_6,param_7,param_8,auStack_24c);
        }
      }
      iVar7 = *(int *)(*puVar11 + 4);
      iStack_88 = iVar7;
      if (DAT_01d622a0 == '\0') {
        ppiStack_2a0 = (int **)0x0;
        piStack_2a4 = param_3;
        (**(code **)(**(int **)(iVar7 + 8) + 8))(param_6,param_7,param_8,auStack_24c);
      }
      puVar3 = puStack_38;
      uStack_4c = 0;
      iStack_30 = *(int *)(*param_3 + 0x3c);
      uVar8 = *(uint *)(iStack_34 + 0x10);
      iVar5 = *(int *)(*param_3 + 0x30);
      if (uVar8 != 0) {
        iStack_48 = iVar7 + 0x18;
        uVar12 = 0;
        do {
          uVar8 = (uint)*(ushort *)(iStack_34 + 0x14 + uVar12 * 2);
          iStack_24 = uVar8 * 0xf;
          piStack_18 = (int *)(*(int *)(iVar5 + uVar8 * 0x3c) + iStack_30);
          if (DAT_01d622c0 == '\0') {
            ppiStack_2a0 = (int **)puVar3[0x44];
            if ((int **)puVar3[0x45] == ppiStack_2a0) {
              piStack_2a4 = (int *)0x846f6d;
              FUN_00842100();
            }
            else {
              *ppiStack_2a0 = (int *)0x0;
              ppiStack_2a0[1] = (int *)0x0;
              ppiStack_2a0[2] = (int *)0x0;
              ppiStack_2a0[3] = (int *)0x0;
              ppiStack_2a0[4] = (int *)0x0;
              puVar3[0x44] = puVar3[0x44] + 0x14;
            }
            iVar7 = puVar3[0x44];
            pcStack_14 = (char *)(iVar7 + -0x14);
            *(int *)(iVar7 + -0x10) = param_11;
            *(undefined4 *)(iVar7 + -0xc) = param_12;
            piStack_2a4 = (int *)0x846f91;
            ppiStack_2a0 = (int **)piStack_18;
            iVar7 = FUN_0085e790();
            *(int *)(pcStack_14 + 0xc) = iVar7;
            if (iVar7 == -1) {
              pcStack_14[0xc] = -1;
              pcStack_14[0xd] = -1;
              pcStack_14[0xe] = -1;
              pcStack_14[0xf] = '\x7f';
              *(undefined4 *)(pcStack_14 + 0x10) = *puVar3;
              uVar1 = *(ushort *)(iVar5 + 4 + iStack_24 * 4);
              while (uVar1 != 0xffff) {
                uVar8 = (uint)uVar1;
                ppiStack_2a0 = (int **)(*(int *)(iVar5 + uVar8 * 0x3c) + iStack_30);
                piStack_2a4 = (int *)0x846fe0;
                iVar7 = FUN_0085e790();
                if (iVar7 != -1) {
                  *(int *)(pcStack_14 + 0xc) = iVar7;
                  ppiStack_2a0 = (int **)(iVar5 + uVar8 * 0x3c + 0xc);
                  piStack_2a4 = &iStack_ec;
                  FUN_01151b50();
                  ppiStack_2a0 = (int **)&iStack_ec;
                  fStack_c8 = fStack_c8 * fStack_44;
                  piStack_c4 = (int *)((float)piStack_c4 * fStack_40);
                  fStack_c0 = fStack_c0 * fStack_3c;
                  piStack_2a4 = aiStack_1dc;
                  fStack_18c = fStack_64 * (float)piStack_c4 + fStack_68 * fStack_c8 +
                               fStack_60 * fStack_c0 + fStack_54;
                  piStack_18 = (int *)(fStack_74 * fStack_c8 + fStack_70 * (float)piStack_c4 +
                                       fStack_6c * fStack_c0 + fStack_58);
                  uStack_2c = (ulonglong)
                              (uint)(fStack_80 * fStack_c8 + fStack_7c * (float)piStack_c4 +
                                     fStack_78 * fStack_c0 + fStack_5c);
                  piVar13 = (int *)FUN_01160c20();
                  fStack_c8 = (float)uStack_2c;
                  iStack_ec = *piVar13;
                  iStack_e8 = piVar13[1];
                  iStack_e4 = piVar13[2];
                  iStack_e0 = piVar13[3];
                  iStack_dc = piVar13[4];
                  iStack_d8 = piVar13[5];
                  iStack_d4 = piVar13[6];
                  iStack_d0 = piVar13[7];
                  iStack_cc = piVar13[8];
                  ppiStack_2a0 = (int **)aiStack_1dc;
                  piStack_c4 = piStack_18;
                  fStack_c0 = fStack_18c;
                  iStack_bc = _DAT_018e3fb0;
                  iStack_b8 = _UNK_018e3fb4;
                  iStack_b4 = _UNK_018e3fb8;
                  iStack_b0 = _UNK_018e3fbc;
                  iStack_ac = _DAT_018e3fb0;
                  iStack_a8 = _UNK_018e3fb4;
                  iStack_a4 = _UNK_018e3fb8;
                  iStack_a0 = _UNK_018e3fbc;
                  iStack_9c = _DAT_018e3fb0;
                  uStack_98 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
                  fStack_90 = (float)_UNK_018e3fbc;
                  piStack_2a4 = (int *)0x84718b;
                  piVar13 = (int *)FUN_011630b0();
                  iStack_bc = *piVar13;
                  iStack_b8 = piVar13[1];
                  iStack_b4 = piVar13[2];
                  iStack_b0 = piVar13[3];
                  iStack_ac = piVar13[4];
                  iStack_a8 = piVar13[5];
                  iStack_a4 = piVar13[6];
                  iStack_a0 = piVar13[7];
                  iStack_9c = piVar13[8];
                  ppiStack_2a0 = (int **)aiStack_200;
                  piStack_2a4 = (int *)0x8471bb;
                  pfVar10 = (float *)FUN_01160de0();
                  fVar15 = pfVar10[3] * fStack_c8;
                  fVar14 = pfVar10[6] * fStack_c8;
                  fStack_c8 = pfVar10[1] * (float)piStack_c4 + fStack_c8 * *pfVar10 +
                              pfVar10[2] * fStack_c0;
                  fVar15 = fVar15 + pfVar10[4] * (float)piStack_c4 + pfVar10[5] * fStack_c0;
                  uStack_98 = CONCAT44(fVar15,fStack_c8);
                  fStack_198 = fVar14 + pfVar10[7] * (float)piStack_c4 + pfVar10[8] * fStack_c0;
                  iStack_ec = iStack_bc;
                  iStack_e8 = iStack_b8;
                  iStack_e4 = iStack_b4;
                  iStack_e0 = iStack_b0;
                  piStack_2a4 = (int *)puVar3[0x47];
                  iStack_dc = iStack_ac;
                  iStack_d8 = iStack_a8;
                  iStack_d4 = iStack_a4;
                  iStack_d0 = iStack_a0;
                  iStack_cc = iStack_9c;
                  piStack_c4 = (int *)fVar15;
                  fStack_c0 = fStack_198;
                  fStack_90 = fStack_198;
                  if ((int *)puVar3[0x48] == piStack_2a4) {
                    ppiStack_2a0 = (int **)&iStack_ec;
                    FUN_00842540();
                  }
                  else {
                    *piStack_2a4 = iStack_bc;
                    piStack_2a4[1] = iStack_b8;
                    piStack_2a4[2] = iStack_b4;
                    piStack_2a4[3] = iStack_b0;
                    piStack_2a4[4] = iStack_ac;
                    piStack_2a4[5] = iStack_a8;
                    piStack_2a4[6] = iStack_a4;
                    piStack_2a4[7] = iStack_a0;
                    piStack_2a4[8] = iStack_9c;
                    piStack_2a4[9] = (int)fStack_c8;
                    piStack_2a4[10] = (int)fVar15;
                    piStack_2a4[0xb] = (int)fStack_198;
                    puVar3[0x47] = puVar3[0x47] + 0x30;
                  }
                  *(int *)(pcStack_14 + 0x10) = (int)(puVar3[0x47] - puVar3[0x46]) / 0x30 + -1;
                  break;
                }
                uVar1 = *(ushort *)(iVar5 + 4 + uVar8 * 0x3c);
              }
            }
            else {
              ppiStack_2a0 = (int **)(iVar5 + (iStack_24 + 3) * 4);
              piStack_2a4 = &iStack_11c;
              FUN_01151b50();
              ppiStack_2a0 = (int **)&iStack_11c;
              fStack_f8 = fStack_f8 * fStack_44;
              piStack_f4 = (int *)((float)piStack_f4 * fStack_40);
              fStack_f0 = fStack_f0 * fStack_3c;
              piStack_2a4 = aiStack_200;
              fStack_1a4 = (float)piStack_f4 * fStack_64 + fStack_f8 * fStack_68 +
                           fStack_f0 * fStack_60 + fStack_54;
              piStack_18 = (int *)(fStack_70 * (float)piStack_f4 + fStack_74 * fStack_f8 +
                                   fStack_6c * fStack_f0 + fStack_58);
              uStack_2c = (ulonglong)
                          (uint)(fStack_7c * (float)piStack_f4 + fStack_80 * fStack_f8 +
                                 fStack_78 * fStack_f0 + fStack_5c);
              piVar13 = (int *)FUN_01160c20();
              fStack_f8 = (float)uStack_2c;
              uStack_98 = CONCAT44(piStack_18,fStack_f8);
              iStack_11c = *piVar13;
              iStack_118 = piVar13[1];
              iStack_114 = piVar13[2];
              iStack_110 = piVar13[3];
              iStack_10c = piVar13[4];
              iStack_108 = piVar13[5];
              iStack_104 = piVar13[6];
              iStack_100 = piVar13[7];
              iStack_fc = piVar13[8];
              fStack_90 = fStack_1a4;
              ppiStack_2a0 = (int **)auStack_270;
              piStack_f4 = piStack_18;
              fStack_f0 = fStack_1a4;
              iStack_14c = _DAT_018e3fb0;
              iStack_148 = _UNK_018e3fb4;
              iStack_144 = _UNK_018e3fb8;
              iStack_140 = _UNK_018e3fbc;
              iStack_13c = _DAT_018e3fb0;
              iStack_138 = _UNK_018e3fb4;
              iStack_134 = _UNK_018e3fb8;
              iStack_130 = _UNK_018e3fbc;
              iStack_12c = _DAT_018e3fb0;
              uStack_128 = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
              fStack_120 = (float)_UNK_018e3fbc;
              piStack_2a4 = (int *)0x847457;
              iStack_9c = iStack_fc;
              piVar13 = (int *)FUN_011630b0();
              iStack_14c = *piVar13;
              iStack_148 = piVar13[1];
              iStack_144 = piVar13[2];
              iStack_140 = piVar13[3];
              iStack_13c = piVar13[4];
              iStack_138 = piVar13[5];
              iStack_134 = piVar13[6];
              iStack_130 = piVar13[7];
              iStack_12c = piVar13[8];
              ppiStack_2a0 = (int **)auStack_294;
              piStack_2a4 = (int *)0x847487;
              pfVar10 = (float *)FUN_01160de0();
              piStack_2a4 = (int *)puVar3[0x47];
              fVar14 = pfVar10[7] * (float)piStack_f4;
              fVar15 = pfVar10[1] * (float)piStack_f4 + *pfVar10 * fStack_f8 +
                       pfVar10[2] * fStack_f0;
              piStack_f4 = (int *)(pfVar10[4] * (float)piStack_f4 + pfVar10[3] * fStack_f8 +
                                  pfVar10[5] * fStack_f0);
              uStack_128 = CONCAT44(piStack_f4,fVar15);
              fStack_1b0 = fVar14 + pfVar10[6] * fStack_f8 + pfVar10[8] * fStack_f0;
              iStack_11c = iStack_14c;
              iStack_118 = iStack_148;
              iStack_114 = iStack_144;
              iStack_110 = iStack_140;
              iStack_10c = iStack_13c;
              iStack_108 = iStack_138;
              iStack_104 = iStack_134;
              iStack_100 = iStack_130;
              iStack_fc = iStack_12c;
              fStack_120 = fStack_1b0;
              fStack_f8 = fVar15;
              fStack_f0 = fStack_1b0;
              if ((int *)puVar3[0x48] == piStack_2a4) {
                ppiStack_2a0 = (int **)&iStack_11c;
                FUN_00842540();
              }
              else {
                *piStack_2a4 = iStack_14c;
                piStack_2a4[1] = iStack_148;
                piStack_2a4[2] = iStack_144;
                piStack_2a4[3] = iStack_140;
                piStack_2a4[4] = iStack_13c;
                piStack_2a4[5] = iStack_138;
                piStack_2a4[6] = iStack_134;
                piStack_2a4[7] = iStack_130;
                piStack_2a4[8] = iStack_12c;
                piStack_2a4[9] = (int)fVar15;
                piStack_2a4[10] = (int)piStack_f4;
                piStack_2a4[0xb] = (int)fStack_1b0;
                puVar3[0x47] = puVar3[0x47] + 0x30;
              }
              *(int *)(pcStack_14 + 0x10) = (int)(puVar3[0x47] - puVar3[0x46]) / 0x30 + -1;
            }
            ppiStack_2a0 = (int **)(puVar3 + 0x4a);
            *(undefined4 *)pcStack_14 = puVar3[0x4a];
            piStack_2a4 = *(int **)(iStack_48 + 4);
            if (*(int **)(iStack_48 + 8) == piStack_2a4) {
              FUN_00595d30();
            }
            else {
              **(undefined4 **)(iStack_48 + 4) = *ppiStack_2a0;
              *(int *)(iStack_48 + 4) = *(int *)(iStack_48 + 4) + 4;
            }
            puVar3[0x4a] = puVar3[0x4a] + 1;
          }
          else {
            uStack_2c = CONCAT44(&piStack_2a4,(undefined4)uStack_2c);
            if (piStack_18 == (int *)0x0) {
              ppiStack_2a0 = (int **)0x0;
            }
            else {
              pcStack_14 = (char *)((int)piStack_18 + 1);
              piVar13 = piStack_18;
              do {
                cVar4 = *(char *)piVar13;
                piVar13 = (int *)((int)piVar13 + 1);
              } while (cVar4 != '\0');
              ppiStack_2a0 = (int **)((int)piVar13 - (int)pcStack_14);
            }
            piStack_2a4 = piStack_18;
            piStack_18 = (int *)puVar3[0x38];
            pcVar9 = (char *)FUN_00d714e0();
            if (pcVar9 == (char *)0xffffffff) {
              pcStack_14 = (char *)0xffffffff;
              for (uVar1 = *(ushort *)(iVar5 + 4 + iStack_24 * 4); uVar1 != 0xffff;
                  uVar1 = *(ushort *)(iVar5 + 4 + (uint)uVar1 * 0x3c)) {
                pcStack_14 = (char *)puVar3[0x38];
                uStack_2c = CONCAT44(&piStack_2a4,(undefined4)uStack_2c);
                piStack_2a4 = (int *)(*(int *)(iVar5 + (uint)uVar1 * 0x3c) + iStack_30);
                if (piStack_2a4 == (int *)0x0) {
                  ppiStack_2a0 = (int **)0x0;
                }
                else {
                  piStack_18 = (int *)((int)piStack_2a4 + 1);
                  piVar13 = piStack_2a4;
                  do {
                    cVar4 = *(char *)piVar13;
                    piVar13 = (int *)((int)piVar13 + 1);
                  } while (cVar4 != '\0');
                  ppiStack_2a0 = (int **)((int)piVar13 - (int)piStack_18);
                }
                pcVar9 = (char *)FUN_00d714e0();
                if (pcVar9 != (char *)0xffffffff) goto LAB_00846f18;
              }
              ppiStack_2a0 = (int **)param_6;
              piStack_2a4 = (int *)0x846f15;
              pcVar9 = (char *)FUN_00d71570();
            }
LAB_00846f18:
            piStack_2a4 = *(int **)(iStack_48 + 4);
            pcStack_14 = pcVar9;
            if (*(int **)(iStack_48 + 8) == piStack_2a4) {
              ppiStack_2a0 = (int **)&pcStack_14;
              FUN_00595d30();
            }
            else {
              *piStack_2a4 = (int)pcVar9;
              *(int *)(iStack_48 + 4) = *(int *)(iStack_48 + 4) + 4;
            }
          }
          fVar14 = *(float *)(iVar5 + 8 + iStack_24 * 4) * fStack_84;
          if ((float)puVar3[0x49] <= fVar14 && fVar14 != (float)puVar3[0x49]) {
            puVar3[0x49] = fVar14;
          }
          uStack_4c = uStack_4c + 1;
          uVar12 = uStack_4c & 0xffff;
          uVar8 = *(uint *)(iStack_34 + 0x10);
          iVar7 = iStack_88;
        } while (uVar12 < uVar8);
      }
      piVar13 = piStack_1c;
      piStack_188 = param_6;
      uStack_184 = param_7;
      uStack_180 = param_8;
      iStack_17c = param_11;
      iStack_178 = (*(int *)(iVar7 + 0x1c) - *(int *)(iVar7 + 0x18) >> 2) - uVar8;
      iStack_160 = param_3[1];
      uStack_174 = *(undefined4 *)(param_13 + 0x10);
      uStack_170 = *(undefined4 *)(param_13 + 0x14);
      uStack_16c = *(undefined4 *)(param_13 + 0x18);
      uStack_168 = *(undefined4 *)(param_13 + 0x1c);
      if (iStack_160 != 0) {
        LOCK();
        *(int *)(iStack_160 + 4) = *(int *)(iStack_160 + 4) + 1;
        UNLOCK();
        iStack_160 = param_3[1];
      }
      iStack_164 = *param_3;
      iStack_158 = param_3[3];
      if (iStack_158 != 0) {
        LOCK();
        *(int *)(iStack_158 + 4) = *(int *)(iStack_158 + 4) + 1;
        UNLOCK();
        iStack_158 = param_3[3];
      }
      iStack_15c = param_3[2];
      piStack_154 = piStack_1c;
      uStack_150 = (undefined)uStack_8c;
      piStack_2a4 = *(int **)(iVar7 + 0x10);
      ppiStack_2a0 = &piStack_188;
      uStack_8 = 0;
      if (*(int **)(iVar7 + 0x14) == piStack_2a4) {
        FUN_00842250();
      }
      else {
        FUN_00843f80(iVar7 + 0xc);
        *(int *)(iVar7 + 0x10) = *(int *)(iVar7 + 0x10) + 0x3c;
      }
      uStack_8 = 0xffffffff;
      ppiStack_2a0 = (int **)0x8476ef;
      FUN_0056b650();
      piStack_1c = (int *)((int)piVar13 + 1);
      iStack_50 = iStack_50 + 0x48;
      param_1 = puStack_38;
    } while ((int)piStack_1c < (int)piStack_20);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12944 ; VA 0x00847730 ; FUN_00847730 */

uint FUN_00847730(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x30;
  if (param_1 < 0x5555556) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 12945 ; VA 0x008477a0 ; FUN_008477a0 */

void __fastcall FUN_008477a0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b75c2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x44);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x44);
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
    puVar3[9] = 0;
    puVar3[10] = 0;
    puVar3[0xb] = 0;
    puVar3[0xc] = 0;
    puVar3[0xd] = 0;
    puVar3[0xe] = 0;
    puVar3[0xf] = 0;
    puVar3[0x10] = 0;
  }
  iVar2 = *(int *)(param_1 + 0xd0);
  *(undefined4 **)(param_1 + 0xd0) = puVar3;
  if (iVar2 != 0) {
    FUN_00845070();
    FUN_01674ea0(iVar2,0x44);
    puVar3 = *(undefined4 **)(param_1 + 0xd0);
  }
  puVar3[6] = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0xac);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0xac);
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[6] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
    puVar3[9] = 0;
    puVar3[10] = 0;
    puVar3[0xb] = 0;
    puVar3[0xc] = 0;
    puVar3[0xd] = 0;
    puVar3[0xe] = 0;
    puVar3[0xf] = 0;
    puVar3[0x10] = 0;
    puVar3[0x11] = 0;
    puVar3[0x12] = 0;
    puVar3[0x13] = 0;
    puVar3[0x14] = 0;
    puVar3[0x15] = 0;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0;
    puVar3[0x1e] = 0;
    puVar3[0x1f] = 0;
    puVar3[0x20] = 0;
    puVar3[0x21] = 0;
    puVar3[0x22] = 0;
    puVar3[0x23] = 0;
    puVar3[0x24] = 0;
    puVar3[0x25] = 0;
    puVar3[0x26] = 0;
    puVar3[0x27] = 0;
    puVar3[0x28] = 0;
    puVar3[0x29] = 0xffffffff;
    *(undefined2 *)(puVar3 + 0x2a) = 0x101;
    *(undefined *)((int)puVar3 + 0xaa) = 0;
  }
  iVar2 = *(int *)(param_1 + 0xd0);
  FUN_00843870(puVar3,0);
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  piVar6 = *(int **)(iVar2 + 0x20);
  *(undefined4 *)(iVar2 + 0x20) = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  puVar3 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0xd0) + 0x28);
  *(undefined4 **)(*(int *)(param_1 + 0xd0) + 0x28) = puVar3;
  if (iVar2 != 0) {
    FUN_007c27b0();
    FUN_01674ea0(iVar2,0xc);
  }
  puVar3 = (undefined4 *)FUN_01674e20(0x90);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0170d1f0(puVar3,0,0x90);
    puVar3[0xc] = 0;
    puVar3[0xd] = 0;
    puVar3[0xe] = 0;
    puVar3[0x12] = 0;
    puVar3[0x13] = 0;
    puVar3[0x14] = 0;
    puVar3[0x15] = 0;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    puVar3[0x1c] = 0;
    puVar3[0x1d] = 0;
    *puVar3 = 0x3f800000;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0x3f800000;
    puVar3[5] = 0;
    puVar3[6] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0x3f800000;
    puVar3[0x1e] = 0;
    puVar3[0x1f] = 0;
    puVar3[0x20] = 0;
    puVar3[9] = 0;
    puVar3[10] = 0;
    puVar3[0xb] = 0;
    puVar3[0x21] = 0;
    puVar3[0x22] = 0;
    puVar3[0x23] = 0;
  }
  piVar6 = (int *)(*(int *)(param_1 + 0xd0) + 0x2c);
  iVar2 = *piVar6;
  *piVar6 = (int)puVar3;
  if (iVar2 != 0) {
    FUN_00845a30(iVar2);
  }
  iVar2 = *(int *)(param_1 + 0xd0);
  iVar4 = FUN_01674e20(0x9c);
  uStack_8 = 0;
  if (iVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_00d6e8d0();
  }
  iVar4 = *(int *)(iVar2 + 0x30);
  *(undefined4 *)(iVar2 + 0x30) = uVar5;
  if (iVar4 != 0) {
    FUN_00845420();
    FUN_01674ea0(iVar4,0x9c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12946 ; VA 0x00847c40 ; FUN_00847c40 */

int __fastcall FUN_00847c40(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  iVar7 = *(int *)(param_1 + 8);
  puVar3 = *(undefined4 **)(param_1 + 0xa8);
  uStack_14 = *(undefined4 *)(iVar7 + 0x4e4);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (puVar8 = *(undefined4 **)(param_1 + 0xa4); ExceptionList = ppvVar5, puVar8 != puVar3;
      puVar8 = puVar8 + 2) {
    uVar6 = FUN_0060dcd0(auStack_1c,*puVar8);
    uStack_8 = 0;
    iVar7 = FUN_007c8e00(uVar6);
    piVar4 = piStack_18;
    uStack_8 = 0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar7 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ppvVar5 = (void **)ExceptionList;
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 12947 ; VA 0x00847cf0 ; FUN_00847cf0 */

void __fastcall FUN_00847cf0(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7654;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0084ac80(param_1 + 0xa4);
  iVar5 = FUN_00d6eb80(uVar4,*(undefined4 *)(*(int *)(param_1 + 0xd0) + 0x1c),
                       *(undefined4 *)(*(int *)(param_1 + 0xd0) + 0x30),0x3f);
  iVar2 = *(int *)(param_1 + 0xd0);
  if (iVar5 != 0) {
    FUN_00d71ce0();
    ExceptionList = pvStack_10;
    return;
  }
  if (*(int *)(iVar2 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x20) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar6 = FUN_00d74a70(*(undefined4 *)(iVar2 + 0x1c),*(undefined4 *)(iVar2 + 0x20),0x1f);
  iVar5 = *(int *)(iVar2 + 0x24);
  *(int *)(iVar2 + 0x24) = iVar6;
  if (iVar5 != 0) {
    FUN_00845ae0(iVar5);
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0xd0) + 0x24);
  iStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  puStack_18 = (undefined4 *)FUN_01674e20(0x1c);
  if (puStack_18 == (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 1;
    puStack_18[2] = FUN_008487d0;
    puStack_18[3] = _guard_check_icall;
    puStack_18[4] = 0;
    puStack_18[5] = iVar2 + 0x10;
    puStack_18[6] = param_1;
  }
  FUN_016797d0(puStack_18);
  if (puStack_18 != (undefined4 *)0x0) {
    LOCK();
    puStack_18[1] = puStack_18[1] + 1;
    UNLOCK();
  }
  uStack_14 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(uVar4);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  cVar3 = FUN_01679300(&puStack_18);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  uStack_14 = 0;
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0xd0) + 0x24);
  iStack_8 = 3;
  uVar4 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 4;
  puVar7 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_008487a0;
    puVar7[3] = _guard_check_icall;
    puVar7[4] = 0;
    puVar7[5] = iVar2 + 8;
    puVar7[6] = param_1;
  }
  FUN_016797d0(puVar7);
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_14 = 2;
  iStack_8._0_1_ = 5;
  puStack_18 = puVar7;
  FUN_01675290(uVar4);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  cVar3 = FUN_01679300(&puStack_18);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  uStack_14 = 0;
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0xd0) + 0x24);
  iStack_8 = 6;
  uVar4 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 7;
  puVar7 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_008487d0;
    puVar7[3] = _guard_check_icall;
    puVar7[4] = 0;
    puVar7[5] = iVar2 + 0xc;
    puVar7[6] = param_1;
  }
  FUN_016797d0(puVar7);
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_14 = 4;
  iStack_8._0_1_ = 8;
  puStack_18 = puVar7;
  FUN_01675290(uVar4);
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  cVar3 = FUN_01679300(&puStack_18);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  uStack_14 = 0;
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  uVar4 = *(undefined4 *)(*(int *)(param_1 + 0xd0) + 0x24);
  iStack_8 = 9;
  uVar8 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 10;
  puVar7 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_008487a0;
    puVar7[3] = _guard_check_icall;
    puVar7[4] = 0;
    puVar7[5] = uVar4;
    puVar7[6] = param_1;
  }
  FUN_016797d0(puVar7);
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_14 = 8;
  iStack_8._0_1_ = 0xb;
  puStack_18 = puVar7;
  FUN_01675290(uVar8);
  iStack_8 = CONCAT31(iStack_8._1_3_,9);
  cVar3 = FUN_01679300(&puStack_18);
  if (cVar3 != '\0') {
    FUN_01679490();
    FUN_016791c0(&puStack_18);
  }
  if (puStack_18 != (undefined4 *)0x0) {
    piVar1 = puStack_18 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puStack_18);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12948 ; VA 0x00848170 ; FUN_00848170 */

void __fastcall FUN_00848170(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 *puVar6;
  char cVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7668;
  pvStack_10 = ExceptionList;
  puVar9 = *(undefined4 **)(param_1 + 0xa4);
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  ppvVar5 = &pvStack_10;
  if (*(int *)(param_1 + 0xa8) - (int)puVar9 >> 3 != 0) {
    do {
      uVar10 = uStack_18;
      cVar7 = FUN_011584c0();
      if (cVar7 == '\0') {
        if (DAT_01eb4564 != '\0') {
          FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p is no longer in workspace",param_1,
                       puVar9[uVar10 * 2],0);
        }
        if ((undefined4 *)puVar9[uVar10 * 2 + 1] != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)puVar9[uVar10 * 2 + 1])(1);
        }
        puVar9[uVar10 * 2 + 1] = 0;
      }
      else {
        cStack_11 = '\0';
        iVar8 = FUN_007c7390(puVar9[uVar10 * 2]);
        cVar7 = cStack_11;
        if (((DAT_01d6c85c != '\0') && (*(int *)(puVar9[uStack_18 * 2 + 1] + 0x24) != 0)) &&
           ((*(byte *)(puVar9[uStack_18 * 2] + 0xb4) & 0x40) == 0)) {
          if (DAT_01eb4564 != '\0') {
            FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p wrap component changed",param_1,
                         puVar9[uStack_18 * 2],0);
          }
          cVar7 = '\x01';
        }
        uVar10 = uStack_18;
        if (*(int *)(param_1 + 200) == iVar8) {
          if (cVar7 == '\0') goto LAB_0084830f;
        }
        else if (DAT_01eb4564 != '\0') {
          FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: part %p changed humanoid from %p to %p",
                       param_1,puVar9[uStack_18 * 2],iVar8,*(int *)(param_1 + 200),0);
        }
        FUN_0060dcd0(auStack_20,puVar9[uVar10 * 2]);
        uStack_8 = 0;
        (**(code **)(*(int *)puVar9[uVar10 * 2 + 1] + 0x40))();
        if ((undefined4 *)puVar9[uVar10 * 2 + 1] != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)puVar9[uVar10 * 2 + 1])(1);
        }
        puVar9[uVar10 * 2 + 1] = 0;
        FUN_007c8e00(auStack_20);
        piVar4 = piStack_1c;
        uStack_8 = 0xffffffff;
        uVar10 = uStack_18;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar8 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            uVar10 = uStack_18;
            if (iVar8 == 0) {
              (**(code **)(*piVar4 + 4))();
              uVar10 = uStack_18;
            }
          }
        }
      }
LAB_0084830f:
      if (puVar9[uVar10 * 2 + 1] == 0) {
        iVar8 = FUN_0084a3d0();
        *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + -1;
        *(undefined *)(param_1 + 0xd6) = 1;
      }
      uStack_18 = uVar10 + 1;
      puVar9 = *(undefined4 **)(param_1 + 0xa4);
      ppvVar5 = (void **)ExceptionList;
    } while (uStack_18 < (uint)(*(int *)(param_1 + 0xa8) - (int)puVar9 >> 3));
  }
  ExceptionList = ppvVar5;
  puVar2 = *(undefined4 **)(param_1 + 0xa8);
  if (puVar9 != puVar2) {
    do {
      if (puVar9[1] == 0) break;
      puVar9 = puVar9 + 2;
    } while (puVar9 != puVar2);
    puVar6 = puVar9;
    if (puVar9 != puVar2) {
      while (puVar3 = puVar6, puVar6 = puVar3 + 2, puVar6 != puVar2) {
        if (puVar3[3] != 0) {
          *puVar9 = *puVar6;
          puVar9[1] = puVar3[3];
          puVar9 = puVar9 + 2;
        }
      }
      if (puVar9 != puVar2) {
        iVar8 = *(int *)(param_1 + 0xa8) - (int)puVar2;
        FUN_0170cc70(puVar9,puVar2,iVar8);
        *(int *)(param_1 + 0xa8) = iVar8 + (int)puVar9;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12949 ; VA 0x008483c0 ; FUN_008483c0 */

void __fastcall FUN_008483c0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  char cVar5;
  undefined uVar6;
  short *psVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 uVar11;
  short sVar12;
  uint uVar13;
  undefined4 *puVar14;
  char *pcVar15;
  int iVar16;
  undefined auStack_38 [8];
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7688;
  pvStack_10 = ExceptionList;
  if (param_1[0x33] != 0) {
    ExceptionList = &pvStack_10;
    psVar7 = (short *)(**(code **)(*param_1 + 0x28))();
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: checking cluster (spatial index %dx%dx%d-%u)",
                   param_1,(int)*psVar7,(int)psVar7[1],(int)psVar7[2],psVar7[3]);
    }
    iVar10 = param_1[0x29];
    cStack_11 = '\0';
    uStack_1c = *(undefined4 *)(param_1[2] + 0x4e4);
    uStack_18 = 0;
    if (param_1[0x2a] - iVar10 >> 3 != 0) {
      do {
        cVar5 = FUN_011584c0();
        if (cVar5 != '\0') {
          uVar6 = FUN_007c7420(*(undefined4 *)(iVar10 + uStack_18 * 8));
          uStack_20 = CONCAT31(uStack_20._1_3_,uVar6);
          uStack_28 = 0;
          uStack_24 = 0;
          puVar8 = (undefined4 *)
                   (**(code **)(*(int *)param_1[0x33] + 8))
                             (auStack_38,*(undefined4 *)(iVar10 + uStack_18 * 8),uStack_20);
          uStack_28 = *puVar8;
          uVar11 = puVar8[1];
          uStack_24._2_2_ = (ushort)((uint)uVar11 >> 0x10);
          uStack_24 = uVar11;
          if (psVar7[3] == uStack_24._2_2_) {
            uStack_24._0_2_ = (short)uVar11;
            sVar12 = psVar7[2] - (short)uStack_24;
            uStack_28._2_2_ = (short)((uint)uStack_28 >> 0x10);
            if ((((DAT_01d622d0 <= (short)(*psVar7 - (short)uStack_28)) &&
                 ((short)(*psVar7 - (short)uStack_28) <= DAT_01d622d8)) &&
                (DAT_01d622d2 <= (short)(psVar7[1] - uStack_28._2_2_))) &&
               ((((short)(psVar7[1] - uStack_28._2_2_) <= DAT_01d622da && (DAT_01d622d4 <= sVar12))
                && (sVar12 <= DAT_01d622dc)))) goto LAB_00848610;
          }
          if (cStack_11 == '\0') {
            FUN_007c5500(&uStack_28);
            (**(code **)(*param_1 + 0x18))();
          }
          cVar5 = FUN_007c5500(psVar7);
          if (cVar5 == '\0') {
            if (param_1[0x33] != 0) {
              uVar11 = (**(code **)(*param_1 + 0x20))();
              FUN_007c8b40(param_1 + 0x1d,uVar11);
            }
            break;
          }
          uVar13 = (uint)(ushort)psVar7[3];
          if (psVar7[3] == uStack_24._2_2_) {
            if (DAT_01eb4564 != '\0') {
              iVar16 = (int)psVar7[2];
              uVar9 = (uint)psVar7[1];
              uVar13 = (uint)*psVar7;
              uVar11 = *(undefined4 *)(iVar10 + uStack_18 * 8);
              pcVar15 = "FastCluster[%p]: part %p changed spatial index to %dx%dx%d";
              goto LAB_0084856d;
            }
          }
          else if (DAT_01eb4564 != '\0') {
            iVar16 = 0;
            uVar9 = (uint)uStack_24._2_2_;
            uVar11 = *(undefined4 *)(iVar10 + uStack_18 * 8);
            pcVar15 = "FastCluster[%p]: part %p changed FW status from %d to %d";
LAB_0084856d:
            FUN_016773b0(DAT_01eb4564,pcVar15,param_1,uVar11,uVar13,uVar9,iVar16);
          }
          FUN_0060dcd0(auStack_30,*(undefined4 *)(iVar10 + uStack_18 * 8));
          uStack_8 = 0;
          (**(code **)(**(int **)(iVar10 + 4 + uStack_18 * 8) + 0x40))();
          puVar8 = *(undefined4 **)(iVar10 + 4 + uStack_18 * 8);
          if (puVar8 != (undefined4 *)0x0) {
            (**(code **)*puVar8)(1);
          }
          *(undefined4 *)(iVar10 + 4 + uStack_18 * 8) = 0;
          FUN_007c8e00(auStack_30);
          iVar10 = FUN_0084a3d0();
          piVar3 = piStack_2c;
          cStack_11 = '\x01';
          uStack_8 = 0xffffffff;
          *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + -1;
          *(undefined *)((int)param_1 + 0xd6) = 1;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar10 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
LAB_00848610:
        iVar10 = param_1[0x29];
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < (uint)(param_1[0x2a] - iVar10 >> 3));
      if (cStack_11 != '\0') {
        puVar8 = (undefined4 *)param_1[0x2a];
        puVar14 = (undefined4 *)param_1[0x29];
        if (puVar14 != puVar8) {
          do {
            if (puVar14[1] == 0) break;
            puVar14 = puVar14 + 2;
          } while (puVar14 != puVar8);
          puVar4 = puVar14;
          if (puVar14 != puVar8) {
            while (puVar2 = puVar4, puVar4 = puVar2 + 2, puVar4 != puVar8) {
              if (puVar2[3] != 0) {
                *puVar14 = *puVar4;
                puVar14[1] = puVar2[3];
                puVar14 = puVar14 + 2;
              }
            }
            if (puVar14 != puVar8) {
              iVar10 = param_1[0x2a];
              FUN_0170cc70(puVar14,puVar8,iVar10 - (int)puVar8);
              param_1[0x2a] = (iVar10 - (int)puVar8) + (int)puVar14;
            }
          }
        }
        (**(code **)(*(int *)param_1[0x33] + 0xc))(param_1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12950 ; VA 0x008486e0 ; FUN_008486e0 */

undefined4 __thiscall
FUN_008486e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b76c4;
  pvStack_10 = ExceptionList;
  if ((DAT_01d6c7cc == '\0') || (DAT_01d6c7d4 == '\0')) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0xe0,param_1);
    uStack_8 = 1;
    if (iVar1 != 0) {
      uVar2 = FUN_00868d60(param_2,param_3,param_4,param_5,param_6);
      ExceptionList = pvStack_10;
      return uVar2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0xf4,param_1);
    uStack_8 = 0;
    if (iVar1 != 0) {
      uVar2 = FUN_00844980(param_2,param_3,param_4,param_5,param_6);
      ExceptionList = pvStack_10;
      return uVar2;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 12951 ; VA 0x008487a0 ; FUN_008487a0 */

void FUN_008487a0(int param_1)

{
  FUN_00d71ce0();
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  FUN_00d75820();
  return;
}



/* FUNCTION 12952 ; VA 0x008487d0 ; FUN_008487d0 */

void FUN_008487d0(int param_1)

{
  FUN_00d71cf0();
                    /* WARNING: Could not recover jumptable at 0x008487e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  return;
}



/* FUNCTION 12953 ; VA 0x008487f0 ; FUN_008487f0 */

int FUN_008487f0(int *param_1)

{
  undefined4 *puVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int **ppiVar6;
  int *piVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  int *piVar12;
  int *piVar13;
  undefined8 uVar14;
  int *piStack_17c;
  undefined auStack_168 [4];
  int *piStack_164;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined8 uStack_140;
  undefined auStack_138 [4];
  int *piStack_134;
  undefined auStack_130 [4];
  int *piStack_12c;
  undefined auStack_128 [4];
  int *piStack_124;
  undefined4 *puStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined8 uStack_114;
  int iStack_10c;
  int *piStack_108;
  int iStack_104;
  int iStack_100;
  int iStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined8 uStack_ec;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  uint uStack_dc;
  undefined4 *puStack_d8;
  int iStack_d4;
  int *piStack_d0;
  int *piStack_cc;
  int *piStack_c8;
  int *piStack_c4;
  int iStack_c0;
  int *piStack_bc;
  int *piStack_b8;
  int *piStack_b4;
  int *piStack_b0;
  int *piStack_ac;
  int *piStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  int *piStack_98;
  int *piStack_94;
  int iStack_90;
  int iStack_8c;
  int *piStack_88;
  int *piStack_84;
  int iStack_80;
  int *piStack_7c;
  int *piStack_78;
  int iStack_74;
  int *piStack_70;
  int iStack_6c;
  int iStack_68;
  int *piStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7796;
  pvStack_10 = ExceptionList;
  iStack_90 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iStack_90 + 0x34) < DAT_01eb4590) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4590), DAT_01eb4590 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Render","finalize",0xffffffff);
    DAT_01eb458c = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eb4588 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb4590);
  }
  uStack_e4 = DAT_01eb4588;
  uStack_e0 = DAT_01eb458c;
  uStack_11c = DAT_01eb4588;
  uStack_118 = DAT_01eb458c;
  uStack_114 = FUN_0152d930(DAT_01eb4588,DAT_01eb458c);
  iStack_6c = 0;
  iStack_80 = 0;
  piStack_7c = (int *)0x0;
  piStack_48 = (int *)0x0;
  piStack_78 = (int *)0x0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_18 = *(int **)(iStack_24 + 0xf0);
  piStack_1c = (int *)*piStack_18;
  if (piStack_1c != piStack_18) {
    do {
      puVar10 = (undefined4 *)piStack_1c[0xc];
      piStack_3c = piStack_1c + 6;
      for (puVar1 = (undefined4 *)*puVar10; puVar1 != puVar10; puVar1 = (undefined4 *)*puVar1) {
        if (puVar1[3] != puVar1[4]) {
          iVar4 = (**(code **)(*(int *)puVar1[2] + 0x14))();
          if (iVar4 != 0) {
            iVar4 = (**(code **)(*(int *)puVar1[2] + 0x18))();
            if (iVar4 != 0) {
              piStack_4c = puVar1 + 2;
              piStack_50 = piStack_3c;
              if (piStack_48 == piStack_7c) {
                FUN_00559ce0(piStack_7c,&piStack_50);
                piStack_48 = piStack_78;
              }
              else {
                *piStack_7c = (int)piStack_3c;
                piStack_7c[1] = (int)piStack_4c;
                piStack_7c = piStack_7c + 2;
              }
            }
          }
        }
      }
      FUN_00551320();
    } while (piStack_1c != piStack_18);
    iStack_6c = iStack_80;
  }
  piStack_18 = *(int **)(iStack_24 + 0xf8);
  piStack_1c = (int *)*piStack_18;
  iStack_80 = iStack_6c;
  if (piStack_1c != piStack_18) {
    do {
      puVar10 = (undefined4 *)piStack_1c[0xc];
      piStack_3c = piStack_1c + 6;
      for (puVar1 = (undefined4 *)*puVar10; puVar1 != puVar10; puVar1 = (undefined4 *)*puVar1) {
        if ((puVar1[3] != puVar1[4]) && (((int *)puVar1[2])[0x11] != 0)) {
          iVar4 = (**(code **)(*(int *)puVar1[2] + 0x18))();
          if (iVar4 != 0) {
            piStack_4c = puVar1 + 2;
            piStack_50 = piStack_3c;
            if (piStack_48 == piStack_7c) {
              FUN_00559ce0(piStack_7c,&piStack_50);
              piStack_48 = piStack_78;
            }
            else {
              *piStack_7c = (int)piStack_3c;
              piStack_7c[1] = (int)piStack_4c;
              piStack_7c = piStack_7c + 2;
            }
          }
        }
      }
      FUN_00551320();
    } while (piStack_1c != piStack_18);
    iStack_6c = iStack_80;
  }
  iVar4 = iStack_6c;
  piStack_64 = (int *)((int)piStack_7c - iStack_6c >> 3);
  iStack_80 = iStack_6c;
  FUN_00843900(iStack_6c,piStack_7c,piStack_64,param_1);
  iStack_68 = 0;
  iStack_44 = 0;
  iStack_2c = 0;
  iStack_28 = 0;
  piStack_1c = (int *)0x0;
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  if (piStack_64 != (int *)0x0) {
    puVar10 = (undefined4 *)(iVar4 + 4);
    puStack_d8 = puVar10;
    do {
      piVar13 = (int *)*puVar10;
      iVar4 = (**(code **)(*(int *)*piVar13 + 0x14))();
      iStack_68 = iStack_68 + iVar4;
      iStack_44 = iStack_44 + ((int *)*piVar13)[0x11];
      iVar4 = (**(code **)(*(int *)*piVar13 + 0x18))();
      iStack_2c = iStack_2c + iVar4;
      iVar4 = (**(code **)(*(int *)*piVar13 + 0x1c))();
      iStack_28 = iStack_28 + iVar4;
      piVar12 = (int *)((int)piStack_1c + ((int *)*piVar13)[0x12]);
      piStack_1c = piVar12;
      iVar4 = (**(code **)(*(int *)*piVar13 + 0x20))();
      puVar10 = puVar10 + 2;
      iVar4 = iStack_38 + iVar4;
      piStack_34 = (int *)((int)piStack_34 + 1);
      iStack_38 = iVar4;
    } while (piStack_34 < piStack_64);
    if (((iStack_68 != 0) || (iStack_44 != 0)) && (iStack_2c != 0)) {
      piStack_d0 = (int *)0x0;
      piStack_cc = (int *)0x0;
      piStack_c8 = (int *)0x0;
      piStack_c4 = (int *)0x0;
      piStack_50 = (int *)0x0;
      piStack_4c = (int *)0x0;
      piStack_bc = (int *)0x0;
      piStack_b8 = (int *)0x0;
      piStack_b4 = (int *)0x0;
      piStack_b0 = (int *)0x0;
      piStack_98 = (int *)0x0;
      piStack_94 = (int *)0x0;
      uStack_8._0_1_ = 9;
      piStack_34 = (int *)0x0;
      iStack_38 = 0;
      iStack_d4 = 0;
      iStack_9c = 0;
      piStack_1c = (int *)0x0;
      iStack_c0 = 0;
      cVar3 = FUN_00844100(&piStack_d0,&piStack_c8,&piStack_50,&piStack_bc,&piStack_b4,&piStack_98,
                           &piStack_34,&iStack_38,&iStack_d4,&iStack_9c,&piStack_1c,&iStack_c0,
                           iStack_68,iStack_44,iStack_28,piVar12,iStack_2c,iVar4);
      if (cVar3 == '\0') {
        param_1 = (int *)0x0;
      }
      else {
        iStack_8c = 0;
        piStack_88 = (int *)0x0;
        iStack_74 = 0;
        piStack_70 = (int *)0x0;
        uStack_8._0_1_ = 0xc;
        iStack_54 = 0;
        iStack_58 = 0;
        iStack_5c = 0;
        iStack_60 = 0;
        iStack_28 = 0;
        iStack_2c = 0;
        cStack_11 = '\0';
        piStack_3c = (int *)0x0;
        if (piStack_64 != (int *)0x0) {
          do {
            iStack_40 = *(int *)(iStack_6c + (int)piStack_3c * 8);
            piVar13 = (int *)puStack_d8[(int)piStack_3c * 2];
            piStack_84 = piVar13;
            uVar11 = *(uint *)(iStack_40 + 0xc) >> 4;
            uStack_30 = uVar11 & 0xffffff01;
            uStack_dc = CONCAT31(uStack_dc._1_3_,(char)uVar11) & 0xffffff01;
            if ((uVar11 & 1) == 0) {
              (**(code **)(*(int *)*piVar13 + 0x14))();
              (**(code **)(*(int *)*piVar13 + 0x1c))();
            }
            if ((iStack_8c == 0) || (cStack_11 != (char)uStack_30)) {
              ppiVar6 = &piStack_c8;
              if ((char)uStack_30 == '\0') {
                ppiVar6 = &piStack_d0;
              }
              uVar5 = FUN_0084a400(0,uStack_dc);
              piVar12 = (int *)FUN_0147c0e0(auStack_128,uVar5,ppiVar6,&piStack_b4);
              piVar13 = piStack_88;
              iStack_8c = *piVar12;
              piStack_88 = (int *)piVar12[1];
              *piVar12 = 0;
              piVar12[1] = 0;
              if (piVar13 != (int *)0x0) {
                LOCK();
                iVar4 = piVar13[1] + -1;
                piVar13[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piVar13)();
                  LOCK();
                  iVar4 = piVar13[2] + -1;
                  piVar13[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar13 + 4))();
                  }
                }
              }
              piVar13 = piStack_124;
              if (piStack_124 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_124[1] + -1;
                piStack_124[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piStack_124)();
                  LOCK();
                  piVar12 = piVar13 + 2;
                  iVar4 = *piVar12 + -1;
                  *piVar12 = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar13 + 4))();
                  }
                }
              }
            }
            cVar3 = (char)uStack_30;
            piStack_ac = (int *)0x0;
            piStack_a8 = (int *)0x0;
            ppiVar6 = &piStack_bc;
            if (cVar3 == '\0') {
              ppiVar6 = &piStack_50;
            }
            piStack_a8 = ppiVar6[1];
            if (piStack_a8 != (int *)0x0) {
              LOCK();
              piStack_a8[1] = piStack_a8[1] + 1;
              UNLOCK();
            }
            piStack_ac = *ppiVar6;
            uStack_8._0_1_ = 0xd;
            uVar2 = (undefined)uStack_8;
            uStack_8._0_1_ = 0xd;
            if (((iStack_74 == 0) || (cStack_11 != cVar3)) &&
               ((piStack_ac != (int *)0x0 && (piStack_98 != (int *)0x0)))) {
              piStack_18 = *(int **)(*(int *)(iStack_24 + 4) + 0x3c);
              piVar13 = (int *)((uStack_30 & 0xff) * 8 + 0x564 + *(int *)(iStack_24 + 4));
              piStack_20 = piVar13;
              if (*piVar13 == 0) {
                if (cVar3 == '\0') {
                  if (*(int *)(iStack_90 + 0x34) < DAT_01eb45e0) {
                    uStack_8._0_1_ = uVar2;
                    FUN_016f3809(&DAT_01eb45e0);
                    if (DAT_01eb45e0 == -1) {
                      FUN_0147c5c0(0,0,2,0,0);
                      FUN_0147c5c0(0,0xc,6,2,0);
                      FUN_0147c5c0(0,0x10,1,3,0);
                      FUN_016f37bf(&DAT_01eb45e0);
                    }
                  }
                  piVar12 = (int *)FUN_0147c1b0(auStack_130,&DAT_01eb45a4,3,0x18);
                  iVar4 = *piVar12;
                  iVar9 = piVar12[1];
                  *piVar12 = 0;
                  piVar12[1] = 0;
                  *piVar13 = iVar4;
                  piVar13 = (int *)piVar13[1];
                  piStack_20[1] = iVar9;
                  piVar12 = piStack_12c;
                  if (piVar13 != (int *)0x0) {
                    LOCK();
                    iVar4 = piVar13[1] + -1;
                    piVar13[1] = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)*piVar13)();
                      LOCK();
                      iVar4 = piVar13[2] + -1;
                      piVar13[2] = iVar4;
                      UNLOCK();
                      piVar12 = piStack_12c;
                      if (iVar4 == 0) {
                        (**(code **)(*piVar13 + 4))();
                        piVar12 = piStack_12c;
                      }
                    }
                  }
                }
                else {
                  if (*(int *)(iStack_90 + 0x34) < DAT_01eb464c) {
                    uStack_8._0_1_ = uVar2;
                    FUN_016f3809(&DAT_01eb464c);
                    if (DAT_01eb464c == -1) {
                      FUN_0147c5c0(0,0,2,0,0);
                      FUN_0147c5c0(0,0xc,6,2,0);
                      FUN_0147c5c0(0,0x10,1,3,0);
                      FUN_0147c5c0(0,0x18,6,3,1);
                      FUN_0147c5c0(0,0x1c,6,3,2);
                      FUN_016f37bf(&DAT_01eb464c);
                    }
                  }
                  piVar12 = (int *)FUN_0147c1b0(auStack_138,&DAT_01eb45e8,5,0x20);
                  iVar4 = *piVar12;
                  iVar9 = piVar12[1];
                  *piVar12 = 0;
                  piVar12[1] = 0;
                  *piVar13 = iVar4;
                  piVar13 = (int *)piVar13[1];
                  piStack_20[1] = iVar9;
                  piVar12 = piStack_134;
                  if (piVar13 != (int *)0x0) {
                    LOCK();
                    iVar4 = piVar13[1] + -1;
                    piVar13[1] = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)*piVar13)();
                      LOCK();
                      iVar4 = piVar13[2] + -1;
                      piVar13[2] = iVar4;
                      UNLOCK();
                      piVar12 = piStack_134;
                      if (iVar4 == 0) {
                        (**(code **)(*piVar13 + 4))();
                        piVar12 = piStack_134;
                      }
                    }
                  }
                }
                if (piVar12 != (int *)0x0) {
                  LOCK();
                  iVar4 = piVar12[1] + -1;
                  piVar12[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)*piVar12)();
                    LOCK();
                    iVar4 = piVar12[2] + -1;
                    piVar12[2] = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piVar12 + 4))();
                    }
                  }
                }
              }
              piVar7 = (int *)FUN_0147c0e0(&uStack_ec,piStack_20,&piStack_ac,&piStack_98);
              piVar12 = piStack_70;
              iStack_74 = *piVar7;
              piVar13 = (int *)piVar7[1];
              *piVar7 = 0;
              piVar7[1] = 0;
              if (piStack_70 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_70[1] + -1;
                piStack_70[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  puVar10 = (undefined4 *)*piStack_70;
                  piStack_70 = piVar13;
                  (*(code *)*puVar10)();
                  LOCK();
                  piVar13 = piVar12 + 2;
                  iVar4 = *piVar13 + -1;
                  *piVar13 = iVar4;
                  UNLOCK();
                  piVar13 = piStack_70;
                  if (iVar4 == 0) {
                    (**(code **)(*piVar12 + 4))();
                    piVar13 = piStack_70;
                  }
                }
              }
              piStack_70 = piVar13;
              piVar13 = uStack_ec._4_4_;
              if (uStack_ec._4_4_ != (int *)0x0) {
                LOCK();
                iVar4 = uStack_ec._4_4_[1] + -1;
                uStack_ec._4_4_[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*uStack_ec._4_4_)();
                  LOCK();
                  piVar12 = piVar13 + 2;
                  iVar4 = *piVar12 + -1;
                  *piVar12 = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar13 + 4))();
                  }
                }
              }
            }
            cStack_11 = (char)uStack_30;
            if (cStack_11 == '\0') {
              iStack_a4 = 0;
              piStack_20 = (int *)0x0;
              piStack_18 = piStack_34 + iStack_54 * 0xb;
              iStack_a0 = iStack_d4 + iStack_60 * 0x18;
            }
            else {
              piStack_18 = (int *)0x0;
              iStack_a0 = 0;
              iStack_a4 = iStack_58 * 0x34 + iStack_38;
              piStack_20 = (int *)(iStack_28 * 0x20 + iStack_9c);
            }
            uVar5 = FUN_00849fb0();
            uVar8 = (**(code **)(*param_1 + 0x20))();
            piVar13 = piStack_84;
            FUN_008498e0(&uStack_150,iStack_40,piStack_84,piStack_18,iStack_a4,iStack_a0,piStack_20,
                         (int)piStack_1c + iStack_5c * 2,iStack_c0 + iStack_2c * 2,0,0,uVar8,uVar5);
            uVar5 = (**(code **)(*(int *)*piVar13 + 0x18))();
            iVar4 = iStack_54;
            if ((char)uStack_30 != '\0') {
              iVar4 = iStack_58;
            }
            FUN_0147c720(&iStack_8c,0,iStack_5c,iVar4,uVar5);
            uStack_8._0_1_ = 0xe;
            FUN_0147c770();
            uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
            if (iStack_74 != 0) {
              iVar4 = (**(code **)(*(int *)*piVar13 + 0x20))();
              if (iVar4 != 0) {
                uVar5 = (**(code **)(*(int *)*piVar13 + 0x20))();
                iVar4 = iStack_60;
                if ((char)uStack_30 != '\0') {
                  iVar4 = iStack_28;
                }
                piStack_18 = (int *)FUN_0147c720(&iStack_74,0,iStack_2c,iVar4,uVar5);
                piVar12 = piStack_108;
                iStack_10c = *piStack_18;
                piVar13 = (int *)piStack_18[1];
                *piStack_18 = 0;
                piStack_18[1] = 0;
                if (piStack_108 != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_108[1] + -1;
                  piStack_108[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    puVar10 = (undefined4 *)*piStack_108;
                    piStack_108 = piVar13;
                    (*(code *)*puVar10)();
                    LOCK();
                    piVar13 = piVar12 + 2;
                    iVar4 = *piVar13 + -1;
                    *piVar13 = iVar4;
                    UNLOCK();
                    piVar13 = piStack_108;
                    if (iVar4 == 0) {
                      (**(code **)(*piVar12 + 4))();
                      piVar13 = piStack_108;
                    }
                  }
                }
                piStack_108 = piVar13;
                iStack_104 = piStack_18[2];
                iStack_100 = piStack_18[3];
                iStack_fc = piStack_18[4];
                iStack_f8 = piStack_18[5];
                if (piStack_17c != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_17c[1] + -1;
                  piStack_17c[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)*piStack_17c)();
                    LOCK();
                    iVar4 = piStack_17c[2] + -1;
                    piStack_17c[2] = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piStack_17c + 4))();
                    }
                  }
                }
              }
            }
            iVar4 = *(int *)(iStack_40 + 8);
            if (iVar4 == 0) {
              piStack_20 = (int *)iVar4;
              iVar9 = (**(code **)(*param_1 + 0x1c))();
              if (iVar9 != 0) {
                iVar4 = 3;
              }
            }
            piStack_20 = (int *)iVar4;
            if (*(int *)(iStack_40 + 8) == 9) {
              iVar9 = (**(code **)(*param_1 + 0x1c))();
              piStack_20 = (int *)iVar4;
              if (iVar9 != 0) {
                piStack_20 = (int *)0xa;
              }
            }
            piStack_18 = DAT_018f998c;
            if (*(char *)(iStack_40 + 0x14) == '\0') {
              piStack_18 = (int *)0x0;
            }
            puVar10 = (undefined4 *)FUN_01674e20(0x74);
            uStack_8._0_1_ = 0x10;
            puStack_120 = puVar10;
            if (puVar10 == (undefined4 *)0x0) {
              puVar10 = (undefined4 *)0x0;
            }
            else {
              FUN_00841220(param_1,auStack_168,&iStack_10c,iStack_40,piStack_20,0xff,
                           *(undefined4 *)(iStack_40 + 0x10));
              uStack_8._0_1_ = 0x11;
              *puVar10 = RBX::Graphics::FastClusterEntity_NEW::vftable;
              FUN_00650440(piStack_84 + 4);
              uVar5 = DAT_018c45d0;
              puVar10[0x16] = 0x7f7fffff;
              puVar10[0x17] = 0x7f7fffff;
              puVar10[0x18] = 0x7f7fffff;
              puVar10[0x19] = uVar5;
              puVar10[0x1a] = uVar5;
              puVar10[0x1b] = uVar5;
              puVar10[0x1c] = piStack_18;
              if (DAT_01d622b8 != '\0') {
                puVar10[0x16] = uStack_150;
                puVar10[0x17] = uStack_14c;
                puVar10[0x18] = uStack_148;
                puVar10[0x19] = uStack_144;
                *(undefined8 *)(puVar10 + 0x1a) = uStack_140;
              }
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
            FUN_00841620(puVar10);
            piVar13 = piStack_84;
            iVar4 = (**(code **)(*(int *)*piStack_84 + 0x14))();
            iStack_54 = iStack_54 + iVar4;
            iStack_58 = iStack_58 + ((int *)*piVar13)[0x11];
            iVar4 = (**(code **)(*(int *)*piVar13 + 0x18))();
            iStack_5c = iStack_5c + iVar4;
            iVar4 = (**(code **)(*(int *)*piVar13 + 0x1c))();
            iStack_60 = iStack_60 + iVar4;
            iStack_28 = iStack_28 + ((int *)*piVar13)[0x12];
            iVar4 = (**(code **)(*(int *)*piVar13 + 0x20))();
            piVar13 = piStack_108;
            iStack_2c = iStack_2c + iVar4;
            if (piStack_108 != (int *)0x0) {
              LOCK();
              iVar4 = piStack_108[1] + -1;
              piStack_108[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_108)();
                LOCK();
                piVar12 = piVar13 + 2;
                iVar4 = *piVar12 + -1;
                *piVar12 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar13 + 4))();
                }
              }
            }
            piVar13 = piStack_164;
            if (piStack_164 != (int *)0x0) {
              LOCK();
              iVar4 = piStack_164[1] + -1;
              piStack_164[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_164)();
                LOCK();
                piVar12 = piVar13 + 2;
                iVar4 = *piVar12 + -1;
                *piVar12 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar13 + 4))();
                }
              }
            }
            piVar13 = piStack_a8;
            uStack_8._0_1_ = 0xc;
            if (piStack_a8 != (int *)0x0) {
              LOCK();
              iVar4 = piStack_a8[1] + -1;
              piStack_a8[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_a8)();
                LOCK();
                piVar12 = piVar13 + 2;
                iVar4 = *piVar12 + -1;
                *piVar12 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar13 + 4))();
                }
              }
            }
            piStack_3c = (int *)((int)piStack_3c + 1);
          } while (piStack_3c < piStack_64);
        }
        if (((piStack_34 != (int *)0x0) ||
            (uStack_ec = CONCAT44(uStack_ec._4_4_,(undefined4)uStack_ec), iStack_38 != 0)) &&
           (uStack_ec = CONCAT44(uStack_ec._4_4_,(undefined4)uStack_ec), piStack_1c != (int *)0x0))
        {
          if (*(int *)(iStack_90 + 0x34) < DAT_01eb45a0) {
            FUN_016f3809(&DAT_01eb45a0);
            if (DAT_01eb45a0 == -1) {
              uStack_8._0_1_ = 0x12;
              uVar14 = FUN_0152dab0("Render","upload",0xffffffff);
              DAT_01eb459c = (undefined4)((ulonglong)uVar14 >> 0x20);
              DAT_01eb4598 = (undefined4)uVar14;
              uStack_8._0_1_ = 0xc;
              FUN_016f37bf(&DAT_01eb45a0);
            }
          }
          uVar8 = DAT_01eb459c;
          uVar5 = DAT_01eb4598;
          uStack_f4 = DAT_01eb4598;
          uStack_f0 = DAT_01eb459c;
          uStack_ec = FUN_0152d930(DAT_01eb4598,DAT_01eb459c);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
          if (piStack_d0 != (int *)0x0) {
            (**(code **)(*piStack_d0 + 0x14))();
          }
          if (piStack_c8 != (int *)0x0) {
            (**(code **)(*piStack_c8 + 0x14))();
          }
          (**(code **)(*piStack_b4 + 0x14))();
          if (piStack_50 != (int *)0x0) {
            (**(code **)(*piStack_50 + 0x14))();
          }
          if (piStack_bc != (int *)0x0) {
            (**(code **)(*piStack_bc + 0x14))();
          }
          if (piStack_98 != (int *)0x0) {
            (**(code **)(*piStack_98 + 0x14))();
          }
          uStack_8._0_1_ = 0x14;
          FUN_0152dda0(uVar5,uVar8,uStack_ec);
        }
        piVar13 = piStack_70;
        param_1 = (int *)(iStack_68 + iStack_44);
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_70[1] + -1;
          piStack_70[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            piVar12 = piVar13 + 2;
            iVar4 = *piVar12 + -1;
            *piVar12 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar13 + 4))();
            }
          }
        }
        piVar13 = piStack_88;
        if (piStack_88 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_88[1] + -1;
          piStack_88[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_88)();
            LOCK();
            piVar12 = piVar13 + 2;
            iVar4 = *piVar12 + -1;
            *piVar12 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar13 + 4))();
            }
          }
        }
      }
      piVar13 = piStack_94;
      if (piStack_94 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_94[1] + -1;
        piStack_94[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_94)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12 + -1;
          *piVar12 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      piVar13 = piStack_b0;
      if (piStack_b0 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_b0[1] + -1;
        piStack_b0[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_b0)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12 + -1;
          *piVar12 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      piVar13 = piStack_b8;
      if (piStack_b8 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_b8[1] + -1;
        piStack_b8[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_b8)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12 + -1;
          *piVar12 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      piVar13 = piStack_4c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12 + -1;
          *piVar12 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      piVar13 = piStack_c4;
      if (piStack_c4 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_c4[1] + -1;
        piStack_c4[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_c4)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12 + -1;
          *piVar12 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      piVar13 = piStack_cc;
      if (piStack_cc != (int *)0x0) {
        LOCK();
        iVar4 = piStack_cc[1] + -1;
        piStack_cc[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_cc)();
          LOCK();
          piVar12 = piVar13 + 2;
          iVar4 = *piVar12;
          *piVar12 = *piVar12 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      goto LAB_00849527;
    }
  }
  param_1 = (int *)0x0;
LAB_00849527:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_6c != 0) {
    uVar11 = ((int)piStack_48 - iStack_6c >> 3) * 8;
    iVar4 = iStack_6c;
    if (0xfff < uVar11) {
      iVar4 = *(int *)(iStack_6c + -4);
      uVar11 = uVar11 + 0x23;
      if (0x1f < (iStack_6c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar11);
  }
  uStack_8 = 0x15;
  FUN_0152dda0(uStack_e4,uStack_e0,uStack_114);
  ExceptionList = pvStack_10;
  return (int)param_1;
}



/* FUNCTION 12954 ; VA 0x00849750 ; FUN_00849750 */

void __fastcall FUN_00849750(int param_1)

{
  undefined4 uVar1;
  
  if ((*(char *)(param_1 + 0x65) != '\0') && (*(int *)(param_1 + 0x58) != 0)) {
    uVar1 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
    FUN_007c8b40(param_1,uVar1);
  }
  return;
}



/* FUNCTION 12955 ; VA 0x00849780 ; FUN_00849780 */

undefined __thiscall FUN_00849780(float *param_1,float *param_2)

{
  float10 fVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  uint uVar5;
  uint uVar6;
  
  dVar2 = (double)((param_1[1] - param_2[1]) * (param_1[1] - param_2[1]) +
                   (*param_1 - *param_2) * (*param_1 - *param_2) +
                  (param_1[2] - param_2[2]) * (param_1[2] - param_2[2]));
  if (NAN(dVar2) == (dVar2 == 0.0)) {
    uVar5 = (uint)DAT_018c0da0;
    uVar6 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    dVar3 = (double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar6,SUB84(dVar2,0) & uVar5) +
            DAT_018c0d60;
    fVar1 = (float10)FUN_01160810();
    dVar4 = DAT_018f76b0;
    if ((NAN(dVar3) || NAN((double)fVar1)) == (dVar3 == (double)fVar1)) {
      dVar4 = dVar3 * DAT_018f76b0;
    }
    if (dVar4 < (double)CONCAT44((uint)((ulonglong)(dVar2 - 0.0) >> 0x20) & uVar6,
                                 SUB84(dVar2 - 0.0,0) & uVar5)) {
      return 0;
    }
  }
  dVar2 = (double)((param_1[4] - param_2[4]) * (param_1[4] - param_2[4]) +
                   (param_1[3] - param_2[3]) * (param_1[3] - param_2[3]) +
                  (param_1[5] - param_2[5]) * (param_1[5] - param_2[5]));
  if (NAN(dVar2) == (dVar2 == 0.0)) {
    uVar5 = (uint)DAT_018c0da0;
    uVar6 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    dVar3 = (double)CONCAT44((uint)((ulonglong)dVar2 >> 0x20) & uVar6,SUB84(dVar2,0) & uVar5) +
            DAT_018c0d60;
    fVar1 = (float10)FUN_01160810();
    dVar4 = DAT_018f76b0;
    if ((NAN(dVar3) || NAN((double)fVar1)) == (dVar3 == (double)fVar1)) {
      dVar4 = dVar3 * DAT_018f76b0;
    }
    if (dVar4 < (double)CONCAT44((uint)((ulonglong)(dVar2 - 0.0) >> 0x20) & uVar6,
                                 SUB84(dVar2 - 0.0,0) & uVar5)) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 12956 ; VA 0x008498e0 ; FUN_008498e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall
FUN_008498e0(int param_1,undefined8 *param_2,int param_3,int param_4,uint param_5,float param_6,
            float param_7,float param_8,float param_9,float param_10,undefined4 param_11,
            int param_12,undefined4 param_13,int *param_14)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  float fVar10;
  undefined8 uVar11;
  undefined auStack_178 [76];
  undefined4 auStack_12c [12];
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  float fStack_c4;
  float fStack_b8;
  float fStack_ac;
  float fStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  undefined8 uStack_5c;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  int iStack_40;
  float fStack_3c;
  float fStack_38;
  int iStack_34;
  undefined8 uStack_30;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b77bc;
  pvStack_10 = ExceptionList;
  iStack_40 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_34 = param_1;
  if ((*(int *)(iStack_40 + 0x34) < DAT_01eb47d8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb47d8), DAT_01eb47d8 == -1)) {
    uStack_8 = 0;
    uVar11 = FUN_0152dab0("Render","generateBatchGeometry",0xffffffff);
    DAT_01eb47d4 = (undefined4)((ulonglong)uVar11 >> 0x20);
    DAT_01eb47d0 = (undefined4)uVar11;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb47d8);
  }
  uStack_4c = DAT_01eb47d0;
  uStack_48 = DAT_01eb47d4;
  uStack_6c = DAT_01eb47d0;
  uStack_68 = DAT_01eb47d4;
  uStack_64 = FUN_0152d930(DAT_01eb47d0,DAT_01eb47d4);
  uStack_8 = 1;
  FUN_00746ec0(&piStack_14,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12);
  piVar1 = piStack_14;
  piStack_44 = (int *)(param_1 + 8);
  param_5 = 0;
  if (*piStack_44 == 0) {
    piStack_44 = (int *)0x0;
  }
  param_10 = DAT_018c45c4;
  iVar7 = *(int *)(param_4 + 4);
  iVar6 = *(int *)(param_4 + 8) - iVar7;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_8 = DAT_018c45c4;
  uStack_30 = CONCAT44(DAT_018c45c4,DAT_018c45c4);
  fStack_38 = DAT_018c45c4;
  fStack_28 = DAT_018c45c4;
  param_7 = DAT_018c45d0;
  iVar8 = iVar6 >> 0x1f;
  param_9 = DAT_018c45d0;
  uStack_24 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
  fStack_3c = DAT_018c45d0;
  fStack_1c = DAT_018c45d0;
  if (iVar6 / 0x3c + iVar8 != iVar8) {
    uStack_5c = uStack_30;
    param_12 = 0;
    uStack_54 = uStack_24;
    do {
      iVar8 = *(int *)(param_12 + 0xc + iVar7) * 0x20 + *(int *)(iStack_34 + 0x100);
      if ((DAT_01d622c0 == '\0') || (iStack_18 = *(int *)(iStack_34 + 0xe0), iStack_18 == 0)) {
        iStack_18 = *(int *)(iVar8 + 4);
        if (*(int *)(param_12 + iVar7) == iStack_18) {
          if (*(int *)(iStack_40 + 0x34) < DAT_01eb47c8) {
            FUN_016f3809(&DAT_01eb47c8);
            if (DAT_01eb47c8 == -1) {
              FUN_0060efa0();
              FUN_016f37bf(&DAT_01eb47c8);
            }
          }
          uStack_9c = _DAT_01eb4798;
          uStack_98 = uRam01eb479c;
          uStack_94 = uRam01eb47a0;
          uStack_90 = uRam01eb47a4;
          uStack_8c = _DAT_01eb47a8;
          uStack_88 = uRam01eb47ac;
          fStack_84 = fRam01eb47b0;
          fStack_80 = fRam01eb47b4;
          fStack_7c = _DAT_01eb47b8;
          fStack_78 = fRam01eb47bc;
          fStack_74 = fRam01eb47c0;
          fStack_70 = fRam01eb47c4;
LAB_00849b17:
        }
        else {
          if (iStack_18 == 0) {
            puVar5 = (undefined4 *)FUN_00b077e0();
            uStack_9c = *puVar5;
            uStack_98 = puVar5[1];
            uStack_94 = puVar5[2];
            uStack_90 = puVar5[3];
            uStack_8c = puVar5[4];
            uStack_88 = puVar5[5];
            fStack_84 = (float)puVar5[6];
            fStack_80 = (float)puVar5[7];
            fStack_7c = (float)puVar5[8];
            fStack_78 = (float)puVar5[9];
            fStack_74 = (float)puVar5[10];
            fStack_70 = (float)puVar5[0xb];
            goto LAB_00849b17;
          }
          uVar4 = FUN_00b077e0();
          FUN_00b077e0();
          FUN_007213c0(&uStack_9c,uVar4);
        }
        puVar5 = &uStack_9c;
      }
      else {
        iVar3 = FUN_00d71570(*(undefined4 *)(param_12 + iVar7));
        iVar6 = *param_14;
        FUN_00926d50();
        FUN_007213c0(auStack_12c,iVar3 * 0x30 + iVar6);
        puVar5 = auStack_12c;
      }
      uStack_fc = *puVar5;
      uStack_f8 = puVar5[1];
      uStack_f4 = puVar5[2];
      uStack_f0 = puVar5[3];
      uStack_ec = puVar5[4];
      uStack_e8 = puVar5[5];
      uStack_e4 = puVar5[6];
      uStack_e0 = puVar5[7];
      uStack_dc = puVar5[8];
      uStack_d8 = puVar5[9];
      uStack_d4 = puVar5[10];
      uStack_d0 = puVar5[0xb];
      FUN_0073dae0(*(undefined4 *)(iStack_34 + 4),*(undefined4 *)(param_12 + iVar7),
                   *(undefined4 *)(param_12 + 4 + iVar7),&uStack_fc,*(undefined4 *)(param_3 + 0xc),
                   param_12 + 0x14 + iVar7,*(undefined4 *)(param_12 + 0x10 + iVar7),
                   *(undefined4 *)(param_12 + 0x34 + iVar7),*(undefined *)(param_12 + 0x38 + iVar7))
      ;
      (**(code **)(*piVar1 + 4))();
      (**(code **)(*piVar1 + 8))
                (*(undefined4 *)(param_12 + iVar7),*(undefined4 *)(param_12 + 4 + iVar7),
                 *(undefined4 *)(param_12 + 8 + iVar7),auStack_178,param_12 + 0x24 + iVar7,
                 piStack_44);
      cVar2 = (**(code **)(*piVar1 + 0x24))();
      if (cVar2 != '\0') {
        (**(code **)(*piVar1 + 0x28))(&fStack_84);
        fStack_a0 = *(float *)(iVar8 + 0x10);
        if (fStack_7c <= *(float *)(iVar8 + 0x10)) {
          fStack_a0 = fStack_7c;
        }
        fVar9 = *(float *)(iVar8 + 0xc);
        if (fStack_80 <= *(float *)(iVar8 + 0xc)) {
          fVar9 = fStack_80;
        }
        fVar10 = *(float *)(iVar8 + 8);
        if (fStack_84 <= *(float *)(iVar8 + 8)) {
          fVar10 = fStack_84;
        }
        *(ulonglong *)(iVar8 + 8) = CONCAT44(fVar9,fVar10);
        *(float *)(iVar8 + 0x10) = fStack_a0;
        param_6 = *(float *)(iVar8 + 0x1c);
        if (param_6 <= fStack_70) {
          param_6 = fStack_70;
        }
        fVar9 = *(float *)(iVar8 + 0x18);
        if (*(float *)(iVar8 + 0x18) <= fStack_74) {
          fVar9 = fStack_74;
        }
        fVar10 = *(float *)(iVar8 + 0x14);
        if (*(float *)(iVar8 + 0x14) <= fStack_78) {
          fVar10 = fStack_78;
        }
        fStack_ac = param_6;
        *(ulonglong *)(iVar8 + 0x14) = CONCAT44(fVar9,fVar10);
        *(float *)(iVar8 + 0x1c) = param_6;
        if (fStack_7c <= fStack_38) {
          fStack_38 = fStack_7c;
        }
        fVar9 = fStack_80;
        if (param_10 < fStack_80) {
          fVar9 = param_10;
        }
        if (fStack_84 <= param_8) {
          param_8 = fStack_84;
        }
        fStack_b8 = fStack_38;
        uStack_5c = CONCAT44(fVar9,param_8);
        if (fStack_3c <= fStack_70) {
          fStack_3c = fStack_70;
        }
        fVar10 = fStack_74;
        if (fStack_74 < param_9) {
          fVar10 = param_9;
        }
        if (param_7 <= fStack_78) {
          param_7 = fStack_78;
        }
        uStack_54 = CONCAT44(fVar10,param_7);
        fStack_c4 = fStack_3c;
        param_9 = fVar10;
        param_10 = fVar9;
        uStack_30 = uStack_5c;
        fStack_28 = fStack_38;
        uStack_24 = uStack_54;
        fStack_1c = fStack_3c;
      }
      param_5 = param_5 + 1;
      param_12 = param_12 + 0x3c;
      iVar7 = *(int *)(param_4 + 4);
    } while (param_5 < (uint)((*(int *)(param_4 + 8) - iVar7) / 0x3c));
    if (param_8 <= param_7) {
      *(undefined8 *)((int)param_2 + 0xc) = uStack_54;
      *param_2 = uStack_5c;
      *(float *)((int)param_2 + 0x14) = fStack_1c;
      *(float *)(param_2 + 1) = fStack_28;
      goto LAB_00849ddf;
    }
  }
  *(undefined4 *)param_2 = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 4) = 0x7f7fffff;
  *(undefined4 *)(param_2 + 1) = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 0xc) = 0xff7fffff;
  *(undefined4 *)(param_2 + 2) = 0xff7fffff;
  *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
LAB_00849ddf:
  if (piStack_14 != (int *)0x0) {
    (**(code **)*piStack_14)(1);
  }
  uStack_8 = 3;
  FUN_0152dda0(uStack_4c,uStack_48,uStack_64);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12957 ; VA 0x00849eb0 ; FUN_00849eb0 */

undefined4 * __thiscall FUN_00849eb0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  undefined4 *puStack_8;
  
  iStack_c = param_1;
  FUN_00843670(*(int *)(param_1 + 0xa8) - *(int *)(param_1 + 0xa4) >> 3,param_2);
  iVar7 = 0;
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0xa8) - *(int *)(param_1 + 0xa4) >> 3);
  puStack_8 = puVar6;
  if (0 < (int)puVar6) {
    do {
      puVar6 = (undefined4 *)
               FUN_0060dcd0(auStack_14,*(undefined4 *)(*(int *)(param_1 + 0xa4) + iVar7 * 8));
      uVar3 = puVar6[1];
      uVar4 = *puVar6;
      puVar8 = (undefined4 *)(*param_2 + iVar7 * 8);
      *puVar6 = 0;
      puVar6[1] = 0;
      *puVar8 = uVar4;
      piVar5 = (int *)puVar8[1];
      puVar8[1] = uVar3;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar2 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1;
          puVar6 = (undefined4 *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_10;
      if (piStack_10 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_10 + 1;
        iVar2 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_10)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1;
          puVar6 = (undefined4 *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      iVar7 = iVar7 + 1;
      param_1 = iStack_c;
    } while (iVar7 < (int)puStack_8);
  }
  return puVar6;
}



/* FUNCTION 12958 ; VA 0x00849fa0 ; FUN_00849fa0 */

undefined4 __fastcall FUN_00849fa0(int param_1)

{
  return *(undefined4 *)(param_1 + 200);
}



/* FUNCTION 12959 ; VA 0x00849fb0 ; FUN_00849fb0 */

undefined4 __fastcall FUN_00849fb0(int param_1)

{
  if (*(int *)(param_1 + 0xd0) != 0) {
    return *(undefined4 *)(*(int *)(param_1 + 0xd0) + 0x28);
  }
  return 0;
}



/* FUNCTION 12960 ; VA 0x00849fd0 ; FUN_00849fd0 */

int __fastcall FUN_00849fd0(int param_1)

{
  return *(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 3;
}



/* FUNCTION 12961 ; VA 0x00849fe0 ; FUN_00849fe0 */

int __fastcall FUN_00849fe0(int param_1)

{
  uint uVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  
  iVar6 = 0;
  uVar7 = 0;
  uVar4 = (*(uint *)(param_1 + 0x3c) - *(uint *)(param_1 + 0x38)) + 3 >> 2;
  if (*(uint *)(param_1 + 0x3c) < *(uint *)(param_1 + 0x38)) {
    uVar4 = 0;
  }
  if (uVar4 != 0) {
    do {
      uVar1 = FUN_0078e270(0,0,0);
      if (uVar1 != 0) {
        uVar2 = FUN_006f59f0();
        piVar3 = (int *)FUN_0078e320(uVar2);
        if (*piVar3 == 0) {
          iVar5 = 0;
        }
        else {
          iVar5 = *(int *)(*piVar3 + 8);
        }
        uVar1 = (uint)(iVar5 == 1);
      }
      uVar7 = uVar7 + 1;
      iVar6 = iVar6 + uVar1;
    } while (uVar7 != uVar4);
  }
  return iVar6;
}



/* FUNCTION 12962 ; VA 0x0084a060 ; FUN_0084a060 */

float10 __fastcall FUN_0084a060(int param_1)

{
  float fVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  
  fVar4 = *(float *)(param_1 + 0x68) - *(float *)(param_1 + 0x5c);
  fVar3 = *(float *)(param_1 + 100) - *(float *)(param_1 + 0x58);
  fVar1 = *(float *)(param_1 + 0x6c) - *(float *)(param_1 + 0x60);
  dVar2 = (double)(fVar4 * fVar4 + fVar3 * fVar3 + fVar1 * fVar1);
  FUN_017267a0();
  return (float10)((float)dVar2 * DAT_018ce2f4);
}



/* FUNCTION 12963 ; VA 0x0084a0c0 ; FUN_0084a0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_0084a0c0(undefined4 *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  if (param_2 == param_3) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb47c8) {
      FUN_016f3809(&DAT_01eb47c8);
      if (DAT_01eb47c8 == -1) {
        FUN_0060efa0();
        FUN_016f37bf(&DAT_01eb47c8);
      }
    }
    uVar3 = uRam01eb47a4;
    uVar2 = uRam01eb47a0;
    uVar1 = uRam01eb479c;
    *param_1 = _DAT_01eb4798;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    uVar3 = uRam01eb47b4;
    uVar2 = uRam01eb47b0;
    uVar1 = uRam01eb47ac;
    param_1[4] = _DAT_01eb47a8;
    param_1[5] = uVar1;
    param_1[6] = uVar2;
    param_1[7] = uVar3;
    uVar3 = uRam01eb47c4;
    uVar2 = uRam01eb47c0;
    uVar1 = uRam01eb47bc;
    param_1[8] = _DAT_01eb47b8;
    param_1[9] = uVar1;
    param_1[10] = uVar2;
    param_1[0xb] = uVar3;
    return param_1;
  }
  puVar4 = (undefined4 *)FUN_00b077e0();
  if (param_3 != 0) {
    FUN_00b077e0();
    FUN_007213c0(param_1,puVar4);
    return param_1;
  }
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return param_1;
}



/* FUNCTION 12964 ; VA 0x0084a190 ; FUN_0084a190 */

void __thiscall FUN_0084a190(int param_1,int *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_34 [48];
  
  if ((((*(char *)(param_1 + 0xd5) == '\0') &&
       (iVar1 = *(int *)(*(int *)(*(int *)(param_1 + 0xa4) + param_2[1] * 8) + 0xac), iVar1 != 0))
      && (*(char *)(iVar1 + 0x60) != '\0')) && (param_2[4] != *(int *)(param_1 + 0x94))) {
    puVar5 = (undefined4 *)
             FUN_0071f260(auStack_34,param_2[4] * 0x30 + *(int *)(*(int *)(param_1 + 0xd0) + 0xc));
    uVar2 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    *param_3 = *puVar5;
    param_3[1] = uVar2;
    param_3[2] = uVar3;
    param_3[3] = uVar4;
    uVar2 = puVar5[5];
    uVar3 = puVar5[6];
    uVar4 = puVar5[7];
    param_3[4] = puVar5[4];
    param_3[5] = uVar2;
    param_3[6] = uVar3;
    param_3[7] = uVar4;
    uVar2 = puVar5[9];
    uVar3 = puVar5[10];
    uVar4 = puVar5[0xb];
    param_3[8] = puVar5[8];
    param_3[9] = uVar2;
    param_3[10] = uVar3;
    param_3[0xb] = uVar4;
    return;
  }
  puVar5 = (undefined4 *)
           (*(int *)(*param_2 * 0x2c + 0x20 + *(int *)(param_1 + 0x98)) * 0x30 +
           *(int *)(param_1 + 0xb0));
  uVar2 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  *param_3 = *puVar5;
  param_3[1] = uVar2;
  param_3[2] = uVar3;
  param_3[3] = uVar4;
  uVar2 = puVar5[5];
  uVar3 = puVar5[6];
  uVar4 = puVar5[7];
  param_3[4] = puVar5[4];
  param_3[5] = uVar2;
  param_3[6] = uVar3;
  param_3[7] = uVar4;
  uVar2 = puVar5[9];
  uVar3 = puVar5[10];
  uVar4 = puVar5[0xb];
  param_3[8] = puVar5[8];
  param_3[9] = uVar2;
  param_3[10] = uVar3;
  param_3[0xb] = uVar4;
  return;
}



/* FUNCTION 12965 ; VA 0x0084a250 ; FUN_0084a250 */

int FUN_0084a250(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined auStack_10 [4];
  int *piStack_c;
  int *piStack_8;
  
  iVar2 = FUN_007c0ce0();
  if (iVar2 == 0) {
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0x34);
      iVar3 = param_1;
      if ((iVar2 != 0) && (iVar3 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
        iVar3 = FUN_005c8ac0();
      }
      if ((iVar3 != 0) &&
         (iVar2 = *(int *)(iVar3 + 0xc), iVar3 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_005789c0(&DAT_01ea8ad8,&LAB_0055d5d0);
        uVar4 = FUN_00560f40();
        piStack_8 = (int *)FUN_008aa140(uVar4);
        if (*piStack_8 == 0) {
          uVar4 = FUN_008aa950();
          piVar5 = (int *)FUN_008a9ba0(auStack_10,uVar4);
          iVar2 = *piVar5;
          iVar3 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piStack_8 = iVar2;
          piVar5 = (int *)piStack_8[1];
          piStack_8[1] = iVar3;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar2 = piVar5[1] + -1;
            piVar5[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar2 = piVar5[2] + -1;
              piVar5[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          if (piStack_c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_c[1] + -1;
            piStack_c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_c)();
              LOCK();
              piVar5 = piStack_c + 2;
              iVar2 = *piVar5;
              *piVar5 = *piVar5 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*piStack_c + 4))();
              }
            }
          }
        }
        iVar2 = *piStack_8;
        if ((iVar2 != 0) &&
           ((iVar2 == *(int *)(param_1 + 0x34) ||
            ((*(int *)(param_1 + 0x34) != 0 && (cVar1 = FUN_00620ec0(iVar2), cVar1 != '\0')))))) {
          return 0;
        }
      }
      if (param_1 != 0) {
        if (*(int *)(param_1 + 0x34) == 0) {
          return param_1;
        }
        iVar2 = FUN_005c8ac0();
        return iVar2;
      }
    }
    iVar2 = 0;
  }
  return iVar2;
}



/* FUNCTION 12966 ; VA 0x0084a3b0 ; FUN_0084a3b0 */

void __fastcall FUN_0084a3b0(int param_1)

{
  (**(code **)(**(int **)(param_1 + 0xcc) + 4))(*(undefined *)(param_1 + 0xd4));
  return;
}



/* FUNCTION 12967 ; VA 0x0084a3d0 ; FUN_0084a3d0 */

int __fastcall FUN_0084a3d0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 8) + 0x524);
  if (*(int *)(param_1 + 200) != 0) {
    return iVar1 + 0x70;
  }
  if (*(char *)(param_1 + 0xd4) != '\0') {
    return iVar1 + 0x68;
  }
  return iVar1 + 0x60;
}



/* FUNCTION 12968 ; VA 0x0084a400 ; FUN_0084a400 */

int * __thiscall FUN_0084a400(int param_1,char param_2,byte param_3)

{
  int iVar1;
  int *piVar2;
  undefined *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_c [8];
  
  iVar1 = *(int *)(param_1 + 4) + (uint)param_3 * 8;
  if (param_2 == '\0') {
    piVar2 = (int *)(iVar1 + 0x554);
  }
  else {
    piVar2 = (int *)(iVar1 + 0x564);
  }
  if (*piVar2 == 0) {
    iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (param_2 == '\0') {
      if (param_3 == 0) {
        if (*(int *)(iVar1 + 0x34) < DAT_01eb46dc) {
          FUN_016f3809(&DAT_01eb46dc);
          if (DAT_01eb46dc == -1) {
            FUN_0147c5c0(0,0,2,0,0);
            FUN_0147c5c0(0,0xc,6,1,0);
            FUN_0147c5c0(0,0x10,7,2,0);
            FUN_0147c5c0(0,0x14,6,2,1);
            FUN_0147c5c0(0,0x18,1,3,0);
            FUN_0147c5c0(0,0x20,1,3,1);
            FUN_0147c5c0(0,0x28,6,3,2);
            FUN_016f37bf(&DAT_01eb46dc);
          }
        }
        uVar5 = 0x2c;
        uVar4 = 7;
        puVar3 = &DAT_01eb4650;
      }
      else {
        if (*(int *)(iVar1 + 0x34) < DAT_01eb4794) {
          FUN_016f3809(&DAT_01eb4794);
          if (DAT_01eb4794 == -1) {
            FUN_0147c5c0(0,0,2,0,0);
            FUN_0147c5c0(0,0xc,6,1,0);
            FUN_0147c5c0(0,0x10,7,2,0);
            FUN_0147c5c0(0,0x14,6,2,1);
            FUN_0147c5c0(0,0x2c,6,3,4);
            FUN_0147c5c0(0,0x30,6,3,5);
            FUN_0147c5c0(0,0x18,1,3,0);
            FUN_0147c5c0(0,0x20,1,3,1);
            FUN_0147c5c0(0,0x28,6,3,2);
            FUN_016f37bf(&DAT_01eb4794);
          }
        }
        uVar5 = 0x34;
        uVar4 = 9;
        puVar3 = &DAT_01eb46e0;
      }
    }
    else if (param_3 == 0) {
      if (*(int *)(iVar1 + 0x34) < DAT_01eb45e0) {
        FUN_016f3809(&DAT_01eb45e0);
        if (DAT_01eb45e0 == -1) {
          FUN_0147c5c0(0,0,2,0,0);
          FUN_0147c5c0(0,0xc,6,2,0);
          FUN_0147c5c0(0,0x10,1,3,0);
          FUN_016f37bf(&DAT_01eb45e0);
        }
      }
      uVar5 = 0x18;
      uVar4 = 3;
      puVar3 = &DAT_01eb45a4;
    }
    else {
      if (*(int *)(iVar1 + 0x34) < DAT_01eb464c) {
        FUN_016f3809(&DAT_01eb464c);
        if (DAT_01eb464c == -1) {
          FUN_0147c5c0(0,0,2,0,0);
          FUN_0147c5c0(0,0xc,6,2,0);
          FUN_0147c5c0(0,0x10,1,3,0);
          FUN_0147c5c0(0,0x18,6,3,1);
          FUN_0147c5c0(0,0x1c,6,3,2);
          FUN_016f37bf(&DAT_01eb464c);
        }
      }
      uVar5 = 0x20;
      uVar4 = 5;
      puVar3 = &DAT_01eb45e8;
    }
    uVar4 = FUN_0147c1b0(auStack_c,puVar3,uVar4,uVar5);
    FUN_005587e0(uVar4);
    FUN_00550b30();
  }
  return piVar2;
}



/* FUNCTION 12969 ; VA 0x0084a780 ; FUN_0084a780 */

void __thiscall FUN_0084a780(int param_1,undefined4 param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar4 = (*(float *)(param_1 + 0x58) + *(float *)(param_1 + 100)) * DAT_018ce2f4;
  fVar2 = (*(float *)(param_1 + 0x5c) + *(float *)(param_1 + 0x68)) * DAT_018ce2f4;
  fVar3 = (*(float *)(param_1 + 0x60) + *(float *)(param_1 + 0x6c)) * DAT_018ce2f4;
  pfVar1 = (float *)(**(int **)(param_1 + 0x4c) * 0x30 + *(int *)(*(int *)(param_1 + 4) + 0xb0));
  fStack_8 = pfVar1[7] * fVar2 + pfVar1[6] * fVar4 + pfVar1[8] * fVar3 + pfVar1[0xb];
  fStack_c = pfVar1[4] * fVar2 + pfVar1[3] * fVar4 + pfVar1[5] * fVar3 + pfVar1[10];
  fStack_10 = pfVar1[1] * fVar2 + fVar4 * *pfVar1 + pfVar1[2] * fVar3 + pfVar1[9];
  FUN_00841650(param_2,&fStack_10,*(undefined4 *)(param_1 + 0x70));
  return;
}



/* FUNCTION 12970 ; VA 0x0084a870 ; FUN_0084a870 */

int __fastcall FUN_0084a870(int param_1)

{
  return param_1 + 0xdc;
}



/* FUNCTION 12971 ; VA 0x0084a880 ; FUN_0084a880 */

void __fastcall FUN_0084a880(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p with binding %p requests invalidateEntity",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
                    /* WARNING: Could not recover jumptable at 0x0084a8ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  return;
}



/* FUNCTION 12972 ; VA 0x0084a885 ; FUN_0084a885 */

void __fastcall FUN_0084a885(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests invalidateEntity",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
                    /* WARNING: Could not recover jumptable at 0x0084a8ae. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  return;
}



/* FUNCTION 12973 ; VA 0x0084a8c0 ; FUN_0084a8c0 */

void __fastcall FUN_0084a8c0(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: invalidateEntity",param_1 + -0x74);
  }
  if (*(char *)(param_1 + 0x61) == '\0') {
    *(undefined *)(param_1 + 0x61) = 1;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8c80(param_1);
  }
  return;
}



/* FUNCTION 12974 ; VA 0x0084a910 ; FUN_0084a910 */

undefined __fastcall FUN_0084a910(int param_1)

{
  return *(undefined *)(param_1 + 0xd4);
}



/* FUNCTION 12975 ; VA 0x0084a920 ; FUN_0084a920 */

undefined __fastcall FUN_0084a920(int param_1)

{
  return *(undefined *)(param_1 + 0xd7);
}



/* FUNCTION 12976 ; VA 0x0084a930 ; FUN_0084a930 */

void __fastcall FUN_0084a930(int *param_1)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar2 = FUN_0084a250(param_1[1]);
  if ((iVar2 == 0) || (iVar3 = FUN_008f7870(iVar2), iVar3 != 0)) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  iVar3 = param_1[1];
  if (iVar3 != 0) {
    if ((param_1[7] != iVar2) || (bVar1)) {
      (**(code **)(*param_1 + 4))();
      if (iVar2 != 0) {
        return;
      }
      FUN_007c8e00(param_1 + 1);
      return;
    }
    uVar4 = FUN_00d00f70(iVar3);
    *(undefined4 *)(iVar3 + 0xb4) = uVar4;
  }
  (**(code **)(*param_1 + 8))();
  return;
}



/* FUNCTION 12977 ; VA 0x0084a9b0 ; FUN_0084a9b0 */

void __fastcall FUN_0084a9b0(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p with binding %p requests castShadow change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12978 ; VA 0x0084a9b5 ; FUN_0084a9b5 */

void __fastcall FUN_0084a9b5(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests castShadow change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12979 ; VA 0x0084a9f0 ; FUN_0084a9f0 */

void __thiscall FUN_0084a9f0(int *param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0x18) == '\0') {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p requests clump change",param_1 + -0x1d,
                   param_2,0);
    }
    (**(code **)(*param_1 + 8))();
  }
  return;
}



/* FUNCTION 12980 ; VA 0x0084aa30 ; FUN_0084aa30 */

void __fastcall FUN_0084aa30(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  FUN_01158d30();
  if (DAT_01d6c85c != '\0') {
    iVar1 = *(int *)(param_1 + 4);
    if ((iVar1 != 0) && ((*(byte *)(iVar1 + 0xb4) & 0x40) != 0)) {
      uVar2 = FUN_00b65600(iVar1);
      *(undefined4 *)(param_1 + 0x20) = uVar2;
      uVar2 = FUN_008440a0();
      *(undefined4 *)(param_1 + 0x24) = uVar2;
      return;
    }
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  return;
}



/* FUNCTION 12981 ; VA 0x0084aa80 ; FUN_0084aa80 */

void __fastcall FUN_0084aa80(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  
  cVar1 = (**(code **)(**(int **)(param_1 + 0x18) + 0x20))();
  if (cVar1 != '\0') {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,
                   "FastCluster[%p]: part %p with binding %p requests coordinate frame change",
                   *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
    }
    (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
    piVar3 = *(int **)(param_1 + 0x18);
    if (piVar3[0x33] != 0) {
      uVar2 = (**(code **)(*piVar3 + 0x20))();
      FUN_007c8b40(piVar3 + 0x1d,uVar2);
      piVar3 = *(int **)(param_1 + 0x18);
    }
    *(undefined *)((int)piVar3 + 0xd6) = 1;
  }
  return;
}



/* FUNCTION 12982 ; VA 0x0084ab00 ; FUN_0084ab00 */

void __fastcall FUN_0084ab00(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p with binding %p requests size change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1[0x33] != 0) {
    uVar2 = (**(code **)(*piVar1 + 0x20))();
    FUN_007c8b40(piVar1 + 0x1d,uVar2);
    *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
    return;
  }
  *(undefined *)((int)piVar1 + 0xd6) = 1;
  return;
}



/* FUNCTION 12983 ; VA 0x0084ab80 ; FUN_0084ab80 */

void __thiscall FUN_0084ab80(int param_1,char param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  
  if ((*(int *)(param_1 + 0x58) != 0) && (*(char *)(param_1 + 0x60) != param_2)) {
    cVar1 = FUN_007c7420(param_3);
    if (cVar1 != *(char *)(param_1 + 0x60)) {
      if (DAT_01eb4564 != '\0') {
        FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: part %p, sleeping %d (fw %d -> %d)",
                     param_1 + -0x74,param_3,param_2,*(char *)(param_1 + 0x60),cVar1);
      }
      if (*(int *)(param_1 + 0x58) != 0) {
        uVar2 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
        FUN_007c8b40(param_1,uVar2);
      }
    }
  }
  return;
}



/* FUNCTION 12984 ; VA 0x0084ac00 ; FUN_0084ac00 */

void __fastcall FUN_0084ac00(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,
                 "FastCluster[%p]: part %p with binding %p requests special shape change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12985 ; VA 0x0084ac05 ; FUN_0084ac05 */

void __fastcall FUN_0084ac05(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests special shape change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12986 ; VA 0x0084ac40 ; FUN_0084ac40 */

void __fastcall FUN_0084ac40(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,
                 "FastCluster[%p]: part %p with binding %p requests transparency change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12987 ; VA 0x0084ac45 ; FUN_0084ac45 */

void __fastcall FUN_0084ac45(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests transparency change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xd6) = 1;
  return;
}



/* FUNCTION 12988 ; VA 0x0084ac80 ; FUN_0084ac80 */

/* WARNING: Removing unreachable block (ram,0x0084aeed) */
/* WARNING: Removing unreachable block (ram,0x0084aefc) */
/* WARNING: Removing unreachable block (ram,0x0084af30) */
/* WARNING: Removing unreachable block (ram,0x0084af0c) */

undefined4 FUN_0084ac80(int *param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint *puVar6;
  int iVar7;
  uint *puVar8;
  int *piVar9;
  uint *puStack_2c;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  puStack_c = &LAB_017b77d8;
  pvStack_10 = ExceptionList;
  puStack_2c = (uint *)0x0;
  piVar9 = (int *)param_1[1];
  piStack_1c = (int *)*param_1;
  uVar3 = (int)piVar9 - (int)piStack_1c >> 3;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    if (0x3fffffff < uVar3) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_007cfd20(uVar3);
    piVar9 = (int *)piVar2[1];
    piStack_1c = (int *)*piVar2;
  }
  puVar8 = (uint *)0x0;
  param_1 = (int *)CONCAT13(1,param_1._0_3_);
  uStack_14 = (uint)param_1;
  if (piStack_1c != piVar9) {
    do {
      iVar1 = *piStack_1c;
      iVar5 = *(int *)(iVar1 + 0xc);
      iVar4 = FUN_00cfb1a0();
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        iVar7 = iVar1;
      }
      if ((iVar7 != 0) && (*(char *)(iVar7 + 0x191) != '\0')) {
        uVar3 = *(uint *)(*piStack_1c + 0x34);
        if (param_1._3_1_ == '\0') {
          if (uVar3 == 0) {
            uVar3 = 0;
          }
          else {
            iVar1 = *(int *)(uVar3 + 0xc);
            iVar5 = FUN_00b63e30();
            if ((uint)*(ushort *)(iVar5 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
              uVar3 = FUN_007c0ca0();
            }
          }
          while (uVar3 != 0) {
            puVar6 = (uint *)0x0;
            if (puVar8 != (uint *)0x0) {
              do {
                if (*puVar6 == uVar3) {
                  if (puVar6 != puVar8) {
                    if (uStack_14 < (uint)((int)puVar6 >> 2)) {
                      uStack_14 = (int)puVar6 >> 2;
                    }
                    goto LAB_0084aeb7;
                  }
                  break;
                }
                puVar6 = puVar6 + 1;
              } while (puVar6 != puVar8);
            }
            uVar3 = *(uint *)(uVar3 + 0x34);
            if (uVar3 == 0) {
              uVar3 = 0;
            }
            else {
              iVar1 = *(int *)(uVar3 + 0xc);
              iVar5 = FUN_00b63e30();
              if ((uint)*(ushort *)(iVar5 + 0x1da) <
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
                uVar3 = FUN_007c0ca0();
              }
            }
          }
        }
        else {
          if (uVar3 == 0) {
            uVar3 = 0;
          }
          else {
            iVar1 = *(int *)(uVar3 + 0xc);
            iVar5 = FUN_00b63e30();
            if ((uint)*(ushort *)(iVar5 + 0x1da) <
                (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
              uVar3 = FUN_007c0ca0();
            }
          }
          param_1 = (int *)uVar3;
          if (uVar3 != 0) {
            do {
              param_1 = (int *)uVar3;
              if (puVar8 == (uint *)0x0) {
                FUN_0063d9b0(0,&param_1);
              }
              else {
                *puVar8 = uVar3;
                puStack_2c = puVar8 + 1;
              }
              uVar3 = *(uint *)((int)param_1 + 0x34);
              if (uVar3 == 0) {
                uVar3 = 0;
              }
              else {
                iVar1 = *(int *)(uVar3 + 0xc);
                iVar5 = FUN_00b63e30();
                if ((uint)*(ushort *)(iVar5 + 0x1da) <
                    (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
                  uVar3 = FUN_007c0ca0();
                }
              }
              puVar8 = puStack_2c;
            } while (uVar3 != 0);
            param_1 = (int *)0x0;
          }
          param_1 = (int *)((uint)param_1 & 0xffffff);
          uStack_14 = 0;
        }
      }
LAB_0084aeb7:
      piStack_1c = piStack_1c + 2;
    } while (piStack_1c != piVar9);
  }
  ExceptionList = pvStack_10;
  return *(undefined4 *)(uStack_14 * 4);
}



/* FUNCTION 12989 ; VA 0x0084af40 ; FUN_0084af40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0084af40(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  char cVar11;
  undefined4 *puVar12;
  float *pfVar13;
  int iVar14;
  undefined4 *puVar15;
  int *piVar16;
  int iVar17;
  undefined4 uVar18;
  float10 fVar19;
  double dVar20;
  uint uVar21;
  float fVar22;
  float fVar23;
  undefined auStack_1bc [36];
  undefined auStack_198 [12];
  undefined auStack_18c [24];
  undefined auStack_174 [44];
  float fStack_148;
  float fStack_13c;
  float fStack_130;
  float fStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined8 uStack_fc;
  float fStack_f4;
  float fStack_f0;
  float fStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  float fStack_dc;
  float fStack_d8;
  float fStack_d4;
  float fStack_d0;
  undefined8 uStack_cc;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  undefined8 uStack_b0;
  undefined8 uStack_98;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  undefined8 uStack_80;
  undefined8 uStack_68;
  double dStack_60;
  int *piStack_58;
  float *pfStack_54;
  undefined8 uStack_50;
  float fStack_48;
  float *pfStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  char cStack_11;
  
  fStack_40 = _DAT_018c4eb0;
  fStack_3c = _UNK_018c4eb4;
  fStack_38 = _UNK_018c4eb8;
  fStack_34 = _UNK_018c4ebc;
  uStack_68 = (double)CONCAT44(param_1,(undefined4)uStack_68);
  fStack_30 = -3.4028235e+38;
  fStack_2c = -3.4028235e+38;
  fStack_90 = *(float *)(param_1 + -0x5c);
  fStack_8c = *(float *)(param_1 + -0x58);
  fStack_88 = *(float *)(param_1 + -0x54);
  fStack_84 = *(float *)(param_1 + -0x50);
  piVar16 = *(int **)(param_1 + 0x24);
  cStack_11 = '\0';
  uStack_50 = (double)CONCAT44(*(int **)(param_1 + 0x28),(undefined4)uStack_50);
  uStack_80 = *(undefined8 *)(param_1 + -0x4c);
  piStack_58 = piVar16;
  if (piVar16 != *(int **)(param_1 + 0x28)) {
    do {
      pfStack_54 = (float *)(*(int *)(param_1 + 0x3c) + piVar16[8] * 0x30);
      piStack_58 = piVar16;
      if (*piVar16 != 0) {
        pfStack_44 = (float *)(*(int *)(param_1 + 0x48) + piVar16[8] * 0x30);
        cVar11 = FUN_00c93230(pfStack_54,pfStack_44,0x3727c5ac,0x3727c5ac);
        if (cVar11 == '\0') {
          uStack_120 = _DAT_018e3fb0;
          uStack_11c = _UNK_018e3fb4;
          uStack_118 = _UNK_018e3fb8;
          uStack_114 = _UNK_018e3fbc;
          uStack_110 = _DAT_018e3fb0;
          uStack_10c = _UNK_018e3fb4;
          uStack_108 = _UNK_018e3fb8;
          uStack_104 = _UNK_018e3fbc;
          uStack_100 = _DAT_018e3fb0;
          uStack_fc = CONCAT44(_UNK_018e3fb8,_UNK_018e3fb4);
          fStack_f4 = (float)_UNK_018e3fbc;
          puVar12 = (undefined4 *)FUN_011630b0(auStack_198);
          uStack_120 = *puVar12;
          uStack_11c = puVar12[1];
          uStack_118 = puVar12[2];
          uStack_114 = puVar12[3];
          uStack_110 = puVar12[4];
          uStack_10c = puVar12[5];
          uStack_108 = puVar12[6];
          uStack_104 = puVar12[7];
          uStack_100 = puVar12[8];
          pfVar13 = (float *)FUN_01160de0(auStack_1bc);
          fVar1 = pfStack_54[9];
          fVar2 = pfStack_54[10];
          fVar3 = pfStack_54[0xb];
          fVar23 = pfVar13[1] * fVar2 + *pfVar13 * fVar1 + pfVar13[2] * fVar3;
          fVar22 = pfVar13[3] * fVar1 + pfVar13[4] * fVar2 + pfVar13[5] * fVar3;
          fStack_130 = pfVar13[6] * fVar1 + pfVar13[7] * fVar2 + pfVar13[8] * fVar3;
          uStack_fc = CONCAT44(fVar22,fVar23);
          uStack_98 = (ulonglong)
                      (uint)(pfStack_44[1] * fVar22 + fVar23 * *pfStack_44 +
                             pfStack_44[2] * fStack_130 + pfStack_44[9]);
          fStack_48 = pfStack_44[4] * fVar22 + pfStack_44[3] * fVar23 + pfStack_44[5] * fStack_130 +
                      pfStack_44[10];
          fStack_13c = pfStack_44[7] * fVar22 + pfStack_44[6] * fVar23 + pfStack_44[8] * fStack_130
                       + pfStack_44[0xb];
          fStack_f4 = fStack_130;
          pfVar13 = (float *)FUN_01160c20(auStack_174,&uStack_120);
          uVar21 = piVar16[9];
          fStack_f0 = *pfVar13;
          fStack_ec = pfVar13[1];
          fStack_e8 = pfVar13[2];
          fStack_e4 = pfVar13[3];
          fStack_e0 = pfVar13[4];
          fStack_dc = pfVar13[5];
          fStack_d8 = pfVar13[6];
          fStack_d4 = pfVar13[7];
          fStack_d0 = pfVar13[8];
          fStack_c4 = fStack_13c;
          uStack_cc = CONCAT44(fStack_48,(int)uStack_98);
          fStack_48 = (float)uVar21;
          if (uVar21 < piVar16[10] + uVar21) {
            iVar17 = uVar21 * 0x3c;
            do {
              iVar14 = *(int *)(param_1 + 0x68) + 0xc + iVar17;
              fVar1 = *(float *)(iVar14 + 0x28);
              fVar2 = *(float *)(iVar14 + 0x24);
              fVar3 = *(float *)(iVar14 + 0x2c);
              dStack_60 = (double)(ulonglong)
                                  (uint)(fStack_f0 * fVar2 + fStack_ec * fVar1 + fStack_e8 * fVar3 +
                                        (float)uStack_cc);
              uStack_98 = CONCAT44(fStack_e4 * fVar2 + fStack_e0 * fVar1 + fStack_dc * fVar3 +
                                   uStack_cc._4_4_,(undefined4)uStack_98);
              fStack_148 = fStack_d8 * fVar2 + fStack_d4 * fVar1 + fStack_d0 * fVar3 + fStack_c4;
              puVar15 = (undefined4 *)FUN_01160c20(auStack_174,iVar14);
              uVar18 = puVar15[1];
              uVar5 = puVar15[2];
              uVar6 = puVar15[3];
              uVar7 = puVar15[4];
              uVar8 = puVar15[5];
              uVar9 = puVar15[6];
              uVar10 = puVar15[7];
              uStack_100 = puVar15[8];
              fStack_48 = (float)((int)fStack_48 + 1);
              fStack_f4 = fStack_148;
              iVar14 = *(int *)(param_1 + 0x68);
              uStack_fc = CONCAT44(uStack_98._4_4_,SUB84(dStack_60,0));
              puVar12 = (undefined4 *)(iVar17 + 0xc + iVar14);
              *puVar12 = *puVar15;
              puVar12[1] = uVar18;
              puVar12[2] = uVar5;
              puVar12[3] = uVar6;
              puVar12 = (undefined4 *)(iVar17 + 0x1c + iVar14);
              *puVar12 = uVar7;
              puVar12[1] = uVar8;
              puVar12[2] = uVar9;
              puVar12[3] = uVar10;
              puVar12 = (undefined4 *)(iVar17 + 0x2c + iVar14);
              *puVar12 = uStack_100;
              puVar12[1] = SUB84(dStack_60,0);
              puVar12[2] = uStack_98._4_4_;
              puVar12[3] = fStack_148;
              iVar17 = iVar17 + 0x3c;
              piVar16 = piStack_58;
            } while ((uint)fStack_48 < (uint)(piStack_58[10] + piStack_58[9]));
          }
          cStack_11 = '\x01';
        }
        fVar1 = pfStack_44[1];
        fVar2 = pfStack_44[2];
        fVar3 = pfStack_44[3];
        *pfStack_54 = *pfStack_44;
        pfStack_54[1] = fVar1;
        pfStack_54[2] = fVar2;
        pfStack_54[3] = fVar3;
        fVar1 = pfStack_44[5];
        fVar2 = pfStack_44[6];
        fVar3 = pfStack_44[7];
        pfStack_54[4] = pfStack_44[4];
        pfStack_54[5] = fVar1;
        pfStack_54[6] = fVar2;
        pfStack_54[7] = fVar3;
        fVar1 = pfStack_44[9];
        fVar2 = pfStack_44[10];
        fVar3 = pfStack_44[0xb];
        pfStack_54[8] = pfStack_44[8];
        pfStack_54[9] = fVar1;
        pfStack_54[10] = fVar2;
        pfStack_54[0xb] = fVar3;
      }
      pfVar13 = (float *)FUN_00c9f550(auStack_18c,pfStack_54);
      fStack_124 = fStack_38;
      if (pfVar13[2] <= fStack_38) {
        fStack_124 = pfVar13[2];
      }
      if (pfVar13[1] <= fStack_3c) {
        fStack_3c = pfVar13[1];
      }
      if (*pfVar13 <= fStack_40) {
        fStack_40 = *pfVar13;
      }
      if (fStack_2c <= pfVar13[5]) {
        fStack_2c = pfVar13[5];
      }
      if (fStack_30 <= pfVar13[4]) {
        fStack_30 = pfVar13[4];
      }
      if (fStack_34 <= pfVar13[3]) {
        fStack_34 = pfVar13[3];
      }
      piVar16 = piVar16 + 0xb;
      uStack_b0 = CONCAT44(fStack_2c,(undefined4)uStack_b0);
      piStack_58 = piVar16;
      fStack_38 = fStack_124;
    } while (piVar16 != uStack_50._4_4_);
  }
  piVar16 = *(int **)(param_1 + 0x5c);
  if (piVar16 != (int *)0x0) {
    if (DAT_01d622c0 == '\0') {
      if (*piVar16 != piVar16[1]) {
        uStack_b0 = CONCAT44(fStack_2c,fStack_30);
        fStack_c0 = fStack_40;
        fStack_bc = fStack_3c;
        fStack_b8 = fStack_38;
        fStack_b4 = fStack_34;
        pfVar13 = (float *)FUN_00732f90();
        fStack_40 = *pfVar13;
        fStack_3c = pfVar13[1];
        fStack_38 = pfVar13[2];
        fStack_34 = pfVar13[3];
        fStack_30 = (float)*(undefined8 *)(pfVar13 + 4);
        fStack_2c = (float)((ulonglong)*(undefined8 *)(pfVar13 + 4) >> 0x20);
        FUN_0084dc90(&fStack_c0,&fStack_40);
      }
    }
    else {
      cVar11 = FUN_00685240();
      if (cVar11 == '\0') {
        FUN_00d758a0(*(undefined4 *)(*(int *)(param_1 + 0x5c) + 0x2c),
                     *(undefined4 *)(*(int *)(param_1 + 0x5c) + 0x28));
        pfStack_44 = (float *)FUN_00d71a00();
        if (pfStack_44 != (float *)0x0) {
          iVar17 = 0;
          do {
            pfVar13 = (float *)(**(int **)(*(int *)(param_1 + 0x5c) + 0x28) + iVar17);
            iVar14 = *(int *)(*(int *)(param_1 + 0x5c) + 0xc) + iVar17;
            fVar1 = *(float *)(iVar14 + 0x28);
            fVar2 = *(float *)(iVar14 + 0x24);
            fVar3 = *(float *)(iVar14 + 0x2c);
            dStack_60 = (double)(ulonglong)
                                (uint)(pfVar13[1] * fVar1 + *pfVar13 * fVar2 + pfVar13[2] * fVar3 +
                                      pfVar13[9]);
            uStack_50 = (double)CONCAT44(pfVar13[3] * fVar2 + pfVar13[4] * fVar1 +
                                         pfVar13[5] * fVar3 + pfVar13[10],(undefined4)uStack_50);
            uStack_b0 = CONCAT44(pfVar13[6] * fVar2 + pfVar13[7] * fVar1 + pfVar13[8] * fVar3 +
                                 pfVar13[0xb],(undefined4)uStack_b0);
            puVar15 = (undefined4 *)FUN_01160c20(auStack_174,iVar14);
            uStack_fc = CONCAT44(uStack_50._4_4_,SUB84(dStack_60,0));
            uVar18 = puVar15[1];
            uVar5 = puVar15[2];
            uVar6 = puVar15[3];
            uVar7 = puVar15[4];
            uVar8 = puVar15[5];
            uVar9 = puVar15[6];
            uVar10 = puVar15[7];
            uStack_100 = puVar15[8];
            fStack_f4 = uStack_b0._4_4_;
            iVar14 = *(int *)(param_1 + 0x3c);
            puVar12 = (undefined4 *)(iVar14 + iVar17);
            *puVar12 = *puVar15;
            puVar12[1] = uVar18;
            puVar12[2] = uVar5;
            puVar12[3] = uVar6;
            puVar12 = (undefined4 *)(iVar14 + 0x10 + iVar17);
            *puVar12 = uVar7;
            puVar12[1] = uVar8;
            puVar12[2] = uVar9;
            puVar12[3] = uVar10;
            puVar12 = (undefined4 *)(iVar14 + 0x20 + iVar17);
            *puVar12 = uStack_100;
            puVar12[1] = SUB84(dStack_60,0);
            puVar12[2] = uStack_50._4_4_;
            puVar12[3] = uStack_b0._4_4_;
            iVar17 = iVar17 + 0x30;
            pfStack_44 = (float *)((int)pfStack_44 + -1);
          } while (pfStack_44 != (float *)0x0);
        }
      }
      cVar11 = FUN_00685240();
      if ((cVar11 == '\0') && (iVar17 = FUN_00d71a00(), iVar17 != 0)) {
        pfVar13 = (float *)FUN_00732f90();
        fStack_40 = *pfVar13;
        fStack_3c = pfVar13[1];
        fStack_38 = pfVar13[2];
        fStack_34 = pfVar13[3];
        fStack_30 = (float)*(undefined8 *)(pfVar13 + 4);
        fStack_2c = (float)((ulonglong)*(undefined8 *)(pfVar13 + 4) >> 0x20);
        if (iVar17 != 0) {
          iVar14 = 0;
          do {
            iVar4 = **(int **)(*(int *)(param_1 + 0x5c) + 0x28);
            fVar1 = *(float *)(iVar4 + 0x2c + iVar14);
            if (fVar1 <= fStack_38) {
              fStack_38 = fVar1;
            }
            fVar1 = *(float *)(iVar4 + 0x28 + iVar14);
            if (fVar1 <= fStack_3c) {
              fStack_3c = fVar1;
            }
            fVar1 = *(float *)(iVar4 + 0x24 + iVar14);
            if (fVar1 <= fStack_40) {
              fStack_40 = fVar1;
            }
            uStack_b0 = CONCAT44(fStack_38,(undefined4)uStack_b0);
            fVar1 = *(float *)(iVar4 + 0x2c + iVar14);
            fStack_124 = fStack_2c;
            if (fStack_2c <= fVar1) {
              fStack_124 = fVar1;
            }
            fVar1 = *(float *)(iVar4 + 0x28 + iVar14);
            if (fStack_30 <= fVar1) {
              fStack_30 = fVar1;
            }
            fVar1 = *(float *)(iVar4 + 0x24 + iVar14);
            if (fStack_34 <= fVar1) {
              fStack_34 = fVar1;
            }
            iVar14 = iVar14 + 0x30;
            iVar17 = iVar17 + -1;
            fStack_2c = fStack_124;
          } while (iVar17 != 0);
          param_1 = uStack_68._4_4_;
        }
      }
    }
    fVar1 = *(float *)(*(int *)(param_1 + 0x5c) + 0x18);
    fStack_34 = fStack_34 + fVar1;
    fStack_40 = fStack_40 - fVar1;
    fStack_3c = fStack_3c - fVar1;
    fStack_38 = fStack_38 - fVar1;
    fStack_30 = fStack_30 + fVar1;
    fStack_2c = fStack_2c + fVar1;
  }
  if (*(char *)(param_1 + 100) != '\0') {
    if (cStack_11 == '\0') {
      return;
    }
    FUN_00819480(0);
    goto LAB_0084b8bf;
  }
  uVar18 = *(undefined4 *)(*(int *)(*(int *)(param_1 + -0x6c) + 0x4e4) + 0x24);
  dVar20 = (double)((fStack_8c - fStack_3c) * (fStack_8c - fStack_3c) +
                    (fStack_90 - fStack_40) * (fStack_90 - fStack_40) +
                   (fStack_88 - fStack_38) * (fStack_88 - fStack_38));
  if (NAN(dVar20) == (dVar20 == 0.0)) {
    uVar21 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    dStack_60 = (double)CONCAT44((uint)((ulonglong)dVar20 >> 0x20) & uVar21,
                                 SUB84(dVar20,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_50 = (double)CONCAT44((uint)((ulonglong)(dVar20 - 0.0) >> 0x20) & uVar21,
                                 SUB84(dVar20 - 0.0,0) & (uint)DAT_018c0da0);
    fVar19 = (float10)FUN_01160810();
    uStack_68 = (double)fVar19;
    dVar20 = DAT_018f76b0;
    if ((NAN(dStack_60) || NAN(uStack_68)) == (dStack_60 == uStack_68)) {
      dVar20 = dStack_60 * DAT_018f76b0;
    }
    if (uStack_50 <= dVar20) goto LAB_0084b818;
  }
  else {
LAB_0084b818:
    dVar20 = (double)(((float)uStack_80 - fStack_30) * ((float)uStack_80 - fStack_30) +
                      (fStack_84 - fStack_34) * (fStack_84 - fStack_34) +
                     (uStack_80._4_4_ - fStack_2c) * (uStack_80._4_4_ - fStack_2c));
    if (NAN(dVar20) == (dVar20 == 0.0)) {
      uVar21 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      dStack_60 = (double)CONCAT44((uint)((ulonglong)dVar20 >> 0x20) & uVar21,
                                   SUB84(dVar20,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      uStack_50 = (double)CONCAT44((uint)((ulonglong)(dVar20 - 0.0) >> 0x20) & uVar21,
                                   SUB84(dVar20 - 0.0,0) & (uint)DAT_018c0da0);
      fVar19 = (float10)FUN_01160810();
      uStack_68 = (double)fVar19;
      dVar20 = DAT_018f76b0;
      if ((NAN(dStack_60) || NAN(uStack_68)) == (dStack_60 == uStack_68)) {
        dVar20 = dStack_60 * DAT_018f76b0;
      }
      if (dVar20 < uStack_50) goto LAB_0084b8b2;
    }
    if ((cStack_11 == '\0') && (*(char *)(param_1 + 0x62) == '\0')) {
      uVar18 = *(undefined4 *)(param_1 + -0x70);
    }
  }
LAB_0084b8b2:
  FUN_008411b0(&fStack_40,uVar18);
LAB_0084b8bf:
  if (cStack_11 != '\0') {
    iVar17 = *(int *)(param_1 + 0x54);
    if ((((iVar17 == 0) && (*(char *)(param_1 + 100) == '\0')) && (fStack_90 <= fStack_84)) &&
       ((fStack_8c <= (float)uStack_80 && (fStack_88 <= uStack_80._4_4_)))) {
      FUN_007c7690(&fStack_90,*(undefined *)(param_1 + 0x60));
      iVar17 = *(int *)(param_1 + 0x54);
    }
    if (((iVar17 == 0) && (*(char *)(param_1 + 100) == '\0')) &&
       ((fStack_40 <= fStack_34 && ((fStack_3c <= fStack_30 && (fStack_38 <= fStack_2c)))))) {
      FUN_007c7690(&fStack_40,*(undefined *)(param_1 + 0x60));
    }
  }
  return;
}



/* FUNCTION 12990 ; VA 0x0084b960 ; FUN_0084b960 */

void __fastcall FUN_0084b960(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  char cVar14;
  undefined4 *puVar15;
  undefined4 *puVar16;
  short *psVar17;
  int *piVar18;
  int *piVar19;
  undefined4 uVar20;
  int iVar21;
  float *pfVar22;
  int *piVar23;
  undefined auStack_58 [44];
  float fStack_2c;
  ulonglong uStack_28;
  short *psStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  
  cStack_11 = '\0';
  piVar18 = *(int **)(param_1 + 0x28);
  piVar23 = *(int **)(param_1 + 0x24);
  piStack_1c = piVar23;
  piStack_18 = piVar18;
  if (piVar23 != piVar18) {
    do {
      if (*piVar23 != 0) {
        piStack_1c = piVar23;
        puVar15 = (undefined4 *)FUN_00c157b0();
        uVar20 = puVar15[1];
        uVar4 = puVar15[2];
        uVar5 = puVar15[3];
        uVar6 = puVar15[4];
        uVar7 = puVar15[5];
        uVar8 = puVar15[6];
        uVar9 = puVar15[7];
        uVar10 = puVar15[8];
        uVar11 = puVar15[9];
        uVar12 = puVar15[10];
        uVar13 = puVar15[0xb];
        puVar16 = (undefined4 *)(piVar23[8] * 0x30 + *(int *)(param_1 + 0x48));
        *puVar16 = *puVar15;
        puVar16[1] = uVar20;
        puVar16[2] = uVar4;
        puVar16[3] = uVar5;
        puVar16[4] = uVar6;
        puVar16[5] = uVar7;
        puVar16[6] = uVar8;
        puVar16[7] = uVar9;
        puVar16[8] = uVar10;
        puVar16[9] = uVar11;
        puVar16[10] = uVar12;
        puVar16[0xb] = uVar13;
        piVar18 = piStack_18;
        if ((*(int **)(param_1 + 0x58) != (int *)0x0) && (cStack_11 == '\0')) {
          psStack_20 = (short *)(**(code **)(**(int **)(param_1 + 0x58) + 4))
                                          (*(undefined *)(param_1 + 0x60));
          psVar17 = (short *)(**(code **)(**(int **)(param_1 + 0x58) + 8))
                                       (&uStack_28,*piStack_1c,*(undefined *)(param_1 + 0x60));
          piVar18 = piStack_18;
          piVar23 = piStack_1c;
          if ((*psVar17 != *psStack_20) ||
             (((psVar17[1] != psStack_20[1] || (psVar17[2] != psStack_20[2])) ||
              (psVar17[3] != psStack_20[3])))) {
            cStack_11 = '\x01';
          }
        }
      }
      piVar23 = piVar23 + 0xb;
      piStack_1c = piVar23;
    } while (piVar23 != piVar18);
  }
  if ((*(int *)(param_1 + 0x5c) != 0) && (DAT_01d622c0 != '\0')) {
    piVar19 = (int *)FUN_00d71a00();
    piVar18 = *(int **)(param_1 + 0x28);
    piVar23 = *(int **)(param_1 + 0x24);
    piStack_1c = piVar18;
    piStack_18 = piVar19;
    if (piVar23 != piVar18) {
      do {
        if ((*piVar23 != 0) && ((int *)piVar23[8] < piVar19)) {
          iVar21 = piVar23[8] * 0x30;
          pfVar22 = (float *)(*(int *)(param_1 + 0x48) + iVar21);
          iVar21 = *(int *)(*(int *)(param_1 + 0x5c) + 0xc) + iVar21;
          fVar1 = *(float *)(iVar21 + 0x24);
          fVar2 = *(float *)(iVar21 + 0x28);
          fVar3 = *(float *)(iVar21 + 0x2c);
          uStack_28 = (ulonglong)
                      (uint)(pfVar22[1] * fVar2 + fVar1 * *pfVar22 + pfVar22[2] * fVar3 + pfVar22[9]
                            );
          psStack_20 = (short *)(pfVar22[3] * fVar1 + pfVar22[4] * fVar2 + pfVar22[5] * fVar3 +
                                pfVar22[10]);
          fStack_2c = pfVar22[6] * fVar1 + pfVar22[7] * fVar2 + pfVar22[8] * fVar3 + pfVar22[0xb];
          puVar15 = (undefined4 *)FUN_01160c20(auStack_58,iVar21);
          uVar4 = puVar15[1];
          uVar5 = puVar15[2];
          uVar6 = puVar15[3];
          uVar7 = puVar15[4];
          uVar8 = puVar15[5];
          uVar9 = puVar15[6];
          uVar10 = puVar15[7];
          uVar20 = puVar15[8];
          puVar16 = (undefined4 *)(piVar23[8] * 0x30 + *(int *)(param_1 + 0x48));
          *puVar16 = *puVar15;
          puVar16[1] = uVar4;
          puVar16[2] = uVar5;
          puVar16[3] = uVar6;
          puVar16[4] = uVar7;
          puVar16[5] = uVar8;
          puVar16[6] = uVar9;
          puVar16[7] = uVar10;
          puVar16[8] = uVar20;
          puVar16[9] = (int)uStack_28;
          puVar16[10] = psStack_20;
          puVar16[0xb] = fStack_2c;
          piVar18 = piStack_1c;
          piVar19 = piStack_18;
        }
        piVar23 = piVar23 + 0xb;
      } while (piVar23 != piVar18);
    }
  }
  if ((cStack_11 != '\0') && (*(int *)(param_1 + 0x58) != 0)) {
    uVar20 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
    FUN_007c8b40(param_1,uVar20);
  }
  piVar18 = *(int **)(param_1 + 0x5c);
  if (piVar18 != (int *)0x0) {
    if (DAT_01d622c0 != '\0') {
      cVar14 = FUN_00685240();
      if (cVar14 != '\0') {
        FUN_00847cf0();
      }
      FUN_00d71a20(*(undefined4 *)(*(int *)(param_1 + 0x5c) + 0x2c));
      return;
    }
    psStack_20 = (short *)piVar18[1];
    iVar21 = *piVar18;
    if ((short *)iVar21 != psStack_20) {
      do {
        FUN_0084a190(iVar21,*(int *)(iVar21 + 0xc) * 0x30 + *(int *)(param_1 + 0x48));
        iVar21 = iVar21 + 0x14;
      } while ((short *)iVar21 != psStack_20);
    }
  }
  return;
}



/* FUNCTION 12991 ; VA 0x0084bc40 ; FUN_0084bc40 */

void __fastcall FUN_0084bc40(int param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  char cVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  short *psVar18;
  int *piVar19;
  int iVar20;
  int *piVar21;
  float *pfVar22;
  int *piVar23;
  undefined auStack_58 [44];
  float fStack_2c;
  ulonglong uStack_28;
  short *psStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  
  cVar15 = '\0';
  cStack_11 = '\0';
  piVar21 = *(int **)(param_1 + 0x28);
  piVar23 = *(int **)(param_1 + 0x24);
  piStack_1c = piVar23;
  piStack_18 = piVar21;
  if (piVar23 != piVar21) {
    do {
      if (*piVar23 != 0) {
        piStack_1c = piVar23;
        puVar16 = (undefined4 *)FUN_00c157b0();
        uVar4 = puVar16[1];
        uVar5 = puVar16[2];
        uVar6 = puVar16[3];
        uVar7 = puVar16[4];
        uVar8 = puVar16[5];
        uVar9 = puVar16[6];
        uVar10 = puVar16[7];
        uVar11 = puVar16[8];
        uVar12 = puVar16[9];
        uVar13 = puVar16[10];
        uVar14 = puVar16[0xb];
        puVar17 = (undefined4 *)(piVar23[8] * 0x30 + *(int *)(param_1 + 0x48));
        *puVar17 = *puVar16;
        puVar17[1] = uVar4;
        puVar17[2] = uVar5;
        puVar17[3] = uVar6;
        puVar17[4] = uVar7;
        puVar17[5] = uVar8;
        puVar17[6] = uVar9;
        puVar17[7] = uVar10;
        puVar17[8] = uVar11;
        puVar17[9] = uVar12;
        puVar17[10] = uVar13;
        puVar17[0xb] = uVar14;
        piVar21 = piStack_18;
        cVar15 = cStack_11;
        if ((*(int **)(param_1 + 0x58) != (int *)0x0) && (cStack_11 == '\0')) {
          psStack_20 = (short *)(**(code **)(**(int **)(param_1 + 0x58) + 4))
                                          (*(undefined *)(param_1 + 0x60));
          psVar18 = (short *)(**(code **)(**(int **)(param_1 + 0x58) + 8))
                                       (&uStack_28,*piStack_1c,*(undefined *)(param_1 + 0x60));
          piVar21 = piStack_18;
          piVar23 = piStack_1c;
          if ((*psVar18 != *psStack_20) ||
             (((psVar18[1] != psStack_20[1] || (psVar18[2] != psStack_20[2])) ||
              (cVar15 = cStack_11, psVar18[3] != psStack_20[3])))) {
            cStack_11 = '\x01';
            cVar15 = cStack_11;
          }
        }
      }
      piVar23 = piVar23 + 0xb;
      piStack_1c = piVar23;
    } while (piVar23 != piVar21);
  }
  piVar21 = *(int **)(param_1 + 0x5c);
  if (piVar21 != (int *)0x0) {
    if (DAT_01d622c0 != '\0') {
      piVar19 = (int *)FUN_00d71a00();
      piVar21 = *(int **)(param_1 + 0x28);
      piVar23 = *(int **)(param_1 + 0x24);
      piStack_1c = piVar21;
      piStack_18 = piVar19;
      if (piVar23 != piVar21) {
        do {
          if ((*piVar23 != 0) && ((uint)piVar23[8] < piVar19)) {
            iVar20 = piVar23[8] * 0x30;
            pfVar22 = (float *)(*(int *)(param_1 + 0x48) + iVar20);
            iVar20 = *(int *)(*(int *)(param_1 + 0x5c) + 0xc) + iVar20;
            fVar1 = *(float *)(iVar20 + 0x24);
            fVar2 = *(float *)(iVar20 + 0x28);
            fVar3 = *(float *)(iVar20 + 0x2c);
            uStack_28 = (ulonglong)
                        (uint)(pfVar22[1] * fVar2 + fVar1 * *pfVar22 + pfVar22[2] * fVar3 +
                              pfVar22[9]);
            psStack_20 = (short *)(pfVar22[3] * fVar1 + pfVar22[4] * fVar2 + pfVar22[5] * fVar3 +
                                  pfVar22[10]);
            fStack_2c = pfVar22[6] * fVar1 + pfVar22[7] * fVar2 + pfVar22[8] * fVar3 + pfVar22[0xb];
            puVar16 = (undefined4 *)FUN_01160c20(auStack_58,iVar20);
            uVar5 = puVar16[1];
            uVar6 = puVar16[2];
            uVar7 = puVar16[3];
            uVar8 = puVar16[4];
            uVar9 = puVar16[5];
            uVar10 = puVar16[6];
            uVar11 = puVar16[7];
            uVar4 = puVar16[8];
            puVar17 = (undefined4 *)(piVar23[8] * 0x30 + *(int *)(param_1 + 0x48));
            *puVar17 = *puVar16;
            puVar17[1] = uVar5;
            puVar17[2] = uVar6;
            puVar17[3] = uVar7;
            puVar17[4] = uVar8;
            puVar17[5] = uVar9;
            puVar17[6] = uVar10;
            puVar17[7] = uVar11;
            puVar17[8] = uVar4;
            puVar17[9] = (int)uStack_28;
            puVar17[10] = psStack_20;
            puVar17[0xb] = fStack_2c;
            piVar21 = piStack_1c;
            piVar19 = piStack_18;
          }
          piVar23 = piVar23 + 0xb;
        } while (piVar23 != piVar21);
      }
      cVar15 = FUN_00685240();
      if (cVar15 != '\0') {
        FUN_00847cf0();
      }
      FUN_00d71a20(*(undefined4 *)(*(int *)(param_1 + 0x5c) + 0x2c));
      *(char *)(param_1 + 0x65) = cStack_11;
      return;
    }
    psStack_20 = (short *)piVar21[1];
    iVar20 = *piVar21;
    if ((short *)iVar20 != psStack_20) {
      do {
        FUN_0084a190(iVar20,*(int *)(iVar20 + 0xc) * 0x30 + *(int *)(param_1 + 0x48));
        iVar20 = iVar20 + 0x14;
        cVar15 = cStack_11;
      } while ((short *)iVar20 != psStack_20);
    }
  }
  *(char *)(param_1 + 0x65) = cVar15;
  return;
}



/* FUNCTION 12992 ; VA 0x0084bef0 ; FUN_0084bef0 */

void __fastcall FUN_0084bef0(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: priorityInvalidateEntity",param_1);
  }
  *(undefined *)(param_1 + 0xd5) = 1;
  FUN_007c8eb0(param_1 + 0x74);
  return;
}



/* FUNCTION 12993 ; VA 0x0084bef5 ; FUN_0084bef5 */

void __fastcall FUN_0084bef5(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_016774b0(in_AL,"FastCluster[%p]: priorityInvalidateEntity",param_1);
  }
  *(undefined *)(param_1 + 0xd5) = 1;
  FUN_007c8eb0(param_1 + 0x74);
  return;
}



/* FUNCTION 12994 ; VA 0x0084bf30 ; FUN_0084bf30 */

void FUN_0084bf30(int *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int extraout_ECX;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined auStack_1810 [8];
  undefined4 auStack_1808 [1527];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  FUN_016f40d0();
  piVar1 = *(int **)(extraout_ECX + 4);
  iStack_14 = 0x84bf52;
  cVar4 = (**(code **)(*piVar1 + 0x20))();
  if (cVar4 == '\0') {
    piVar7 = *(int **)(extraout_ECX + 0x4c);
    iStack_14 = *(int *)(extraout_ECX + 0x50) - (int)piVar7 >> 2;
    if (iStack_14 != 0) {
      iVar2 = piVar1[0x2c];
      puVar6 = auStack_1808;
      iVar8 = iStack_14;
      do {
        iVar3 = *piVar7;
        piVar7 = piVar7 + 1;
        puVar5 = (undefined4 *)(iVar3 * 0x30 + iVar2);
        puVar6[-2] = *puVar5;
        puVar6[-1] = puVar5[1];
        *puVar6 = puVar5[2];
        puVar6[1] = puVar5[9];
        puVar6[2] = puVar5[3];
        puVar6[3] = puVar5[4];
        puVar6[4] = puVar5[5];
        puVar6[5] = puVar5[10];
        puVar6[6] = puVar5[6];
        puVar6[7] = puVar5[7];
        puVar6[8] = puVar5[8];
        puVar6[9] = puVar5[0xb];
        iVar8 = iVar8 + -1;
        puVar6 = puVar6 + 0xc;
      } while (iVar8 != 0);
    }
    iStack_14 = iStack_14 * 0x30;
    puStack_18 = auStack_1810;
    uStack_1c = 1;
    uStack_20 = 0x84bffa;
    (**(code **)(*param_1 + 0x30))();
    param_4[2] = param_4[2] +
                 (*(int *)(extraout_ECX + 0x50) - *(int *)(extraout_ECX + 0x4c) >> 2) * 0x30;
  }
  iStack_14 = 0;
  puVar6 = *(undefined4 **)(param_2 + 8);
  puStack_18 = (undefined *)puVar6[5];
  uStack_1c = puVar6[4];
  uStack_20 = puVar6[3];
  uStack_24 = puVar6[2];
  uStack_28 = *puVar6;
  uStack_2c = 0x84c032;
  (**(code **)(*param_1 + 0x40))();
  *param_4 = *param_4 + 1;
  param_4[1] = param_4[1] + *(int *)(*(int *)(param_2 + 8) + 0x14);
  return;
}



/* FUNCTION 12995 ; VA 0x0084c050 ; FUN_0084c050 */

void __fastcall FUN_0084c050(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: unbind part %p from binding %p (%d connections)",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1,
                 *(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc) >> 2,0);
  }
  FUN_011590c0();
  return;
}



/* FUNCTION 12996 ; VA 0x0084c090 ; FUN_0084c090 */

void __fastcall FUN_0084c090(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: unbind (%d parts, %d own connections)",
                 param_1 + -0x74,*(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 3,
                 *(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc) >> 2);
  }
  FUN_011590c0();
  if (*(int *)(param_1 + 0x54) == 0) {
    iVar3 = (uint)(*(char *)(param_1 + 0x60) != '\0') * 8 + 100;
  }
  else {
    iVar3 = 0x74;
  }
  piVar1 = (int *)(*(int *)(*(int *)(param_1 + -0x6c) + 0x524) + iVar3);
  *piVar1 = *piVar1 - (*(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 3);
  uVar4 = 0;
  iVar3 = *(int *)(param_1 + 0x30);
  if (*(int *)(param_1 + 0x34) - iVar3 >> 3 != 0) {
    do {
      (**(code **)(**(int **)(iVar3 + 4 + uVar4 * 8) + 0x40))();
      puVar2 = *(undefined4 **)(iVar3 + 4 + uVar4 * 8);
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
      uVar4 = uVar4 + 1;
      iVar3 = *(int *)(param_1 + 0x30);
    } while (uVar4 < (uint)(*(int *)(param_1 + 0x34) - iVar3 >> 3));
  }
  *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_1 + 0x24);
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x30);
  *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_1 + 0x3c);
  iVar3 = *(int *)(param_1 + 0x5c);
  *(undefined4 *)(param_1 + 0x5c) = 0;
  if (iVar3 != 0) {
    FUN_00845070();
    FUN_01674ea0(iVar3,0x44);
  }
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_1 + 0x48);
  return;
}



/* FUNCTION 12997 ; VA 0x0084c180 ; FUN_0084c180 */

void __fastcall FUN_0084c180(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  
  if (*(char *)(param_1 + 0xd4) == '\0') {
    piVar6 = *(int **)(param_1 + 0xa4);
    piVar7 = *(int **)(param_1 + 0xa8);
    while (piVar6 != piVar7) {
      piVar4 = (int *)(*(int *)(*piVar6 + 0xa8) + 0xc);
      iVar1 = *(int *)(*(int *)(*piVar6 + 0xa8) + 0xc);
      while (iVar1 != 0) {
        piVar4 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
        iVar1 = *piVar4;
      }
      uVar5 = -(uint)(piVar4 != (int *)0x0) & (uint)(piVar4 + -1);
      if (uVar5 == 0) {
        piVar4 = (int *)&DAT_00000014;
      }
      else {
        piVar4 = (int *)(uVar5 + 0xc);
      }
      if (*piVar4 == 0) {
        piVar6 = piVar6 + 2;
      }
      else {
        do {
          piVar4 = piVar7;
          piVar7 = piVar4 + -2;
          if (piVar6 == piVar7) goto LAB_0084c24f;
          piVar3 = (int *)(*(int *)(*piVar7 + 0xa8) + 0xc);
          iVar1 = *piVar3;
          while (iVar1 != 0) {
            piVar3 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
            iVar1 = *piVar3;
          }
          uVar5 = -(uint)(piVar3 != (int *)0x0) & (uint)(piVar3 + -1);
          if (uVar5 == 0) {
            piVar3 = (int *)&DAT_00000014;
          }
          else {
            piVar3 = (int *)(uVar5 + 0xc);
          }
        } while (*piVar3 != 0);
        iVar1 = *piVar6;
        iVar2 = piVar6[1];
        *piVar6 = *piVar7;
        piVar6[1] = piVar4[-1];
        piVar6 = piVar6 + 2;
        *piVar7 = iVar1;
        piVar4[-1] = iVar2;
      }
    }
LAB_0084c24f:
    FUN_00843bd0(piVar6,*(int *)(param_1 + 0xa8),*(int *)(param_1 + 0xa8) - (int)piVar6 >> 3,param_1
                );
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,
                   "FastCluster[%p]: %d parts, %d single-clump parts, %d multi-clump parts",param_1,
                   *(int *)(param_1 + 0xa8) - *(int *)(param_1 + 0xa4) >> 3,
                   (int)piVar6 - *(int *)(param_1 + 0xa4) >> 3,
                   *(int *)(param_1 + 0xa8) - (int)piVar6 >> 3,0);
    }
  }
  return;
}



/* FUNCTION 12998 ; VA 0x0084c2c0 ; FUN_0084c2c0 */

void __fastcall FUN_0084c2c0(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0084c2c2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x48))();
  return;
}



/* FUNCTION 12999 ; VA 0x0084c2d0 ; FUN_0084c2d0 */

void __thiscall FUN_0084c2d0(int *param_1,char param_2)

{
  float fVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void **ppvVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  double *pdVar9;
  int *piVar10;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [8];
  double dStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7808;
  pvStack_10 = ExceptionList;
  if (param_2 == '\0') {
    ppvVar5 = &pvStack_10;
    if (*(char *)((int)param_1 + 0x61) == '\0') {
      if (DAT_01eb4564 == '\0') {
        return;
      }
      ExceptionList = &pvStack_10;
      FUN_01677490(DAT_01eb4564,
                   "FastCluster[%p]: skipping updateEntity dirty: %d, assetsUpdated: %d",
                   param_1 + -0x1d,0,0);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    *(undefined *)((int)param_1 + 0x62) = 1;
    ppvVar5 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar5;
  uVar6 = FUN_01675290(DAT_01eb2f54);
  uStack_8 = 0;
  uStack_14 = uVar6;
  FUN_016827e0(&dStack_24);
  piVar8 = param_1 + -0x1d;
  if (DAT_01eb4564 != '\0') {
    FUN_016773b0(DAT_01eb4564,
                 "FastCluster[%p]: updateEntity for %d parts (dirty: %d, light dirty: %d)",piVar8,
                 param_1[0xd] - param_1[0xc] >> 3,*(undefined *)((int)param_1 + 0x61),
                 *(undefined *)((int)param_1 + 0x62),0);
  }
  *(undefined *)((int)param_1 + 0x61) = 0;
  if (*(char *)(param_1 + 0x19) != '\0') {
    FUN_00819480(0);
  }
  if (DAT_01d622c0 == '\0') {
    if (param_2 != '\0') {
      piVar2 = (int *)param_1[0xd];
      for (piVar10 = (int *)param_1[0xc]; piVar10 != piVar2; piVar10 = piVar10 + 2) {
        if (*(int *)(*piVar10 + 0xac) != 0) {
          *(undefined *)(*(int *)(*piVar10 + 0xac) + 0x61) = 0;
        }
      }
    }
    FUN_0084dbe0();
  }
  FUN_00848170();
  if ((((*(char *)((int)param_1 + 0x62) != '\0') && (param_1[0x15] == 0)) &&
      (*(char *)(param_1 + 0x19) == '\0')) &&
     (((fVar1 = (float)param_1[-0x17],
       fVar1 < (float)param_1[-0x14] || fVar1 == (float)param_1[-0x14] &&
       ((float)param_1[-0x16] < (float)param_1[-0x13] ||
        (float)param_1[-0x16] == (float)param_1[-0x13])) &&
      ((float)param_1[-0x15] < (float)param_1[-0x12] ||
       (float)param_1[-0x15] == (float)param_1[-0x12])))) {
    FUN_007c7690(param_1 + -0x17,
                 CONCAT31((int3)((uint)param_1[-0x1b] >> 8),*(undefined *)(param_1 + 0x18)));
  }
  if (param_1[0xc] == param_1[0xd]) {
    if (DAT_01eb4564 != '\0') {
      FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: destroy (no more parts)",piVar8);
    }
    if ((int *)param_1[0x16] == (int *)0x0) {
      FUN_007c64e0(piVar8);
    }
    else {
      (**(code **)(*(int *)param_1[0x16] + 0x10))();
    }
  }
  else {
    uStack_3c = 1;
    iStack_38 = 0;
    iStack_34 = 0;
    uStack_30 = 0;
    uStack_8._0_1_ = 2;
    FUN_0084c180();
    uVar7 = FUN_0084c630(&uStack_3c);
    if (((DAT_01d5a208 != '\0') && (iStack_38 == iStack_34)) && (param_1[0x15] != 0)) {
      iVar3 = *(int *)(param_1[-0x1b] + 0x4e4);
      piVar8 = *(int **)(iVar3 + 0x18);
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = *(int **)(iVar3 + 0x18);
      }
      iStack_1c = *(int *)(iVar3 + 0x14);
      uStack_8._0_1_ = 3;
      piStack_18 = piVar8;
      if (iStack_1c != 0) {
        FUN_009020f0(param_1[0x15]);
      }
      uStack_8._0_1_ = 2;
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar3 = piVar8[1] + -1;
        piVar8[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar8)();
          LOCK();
          iVar3 = piVar8[2] + -1;
          piVar8[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    piVar8 = param_1;
    if (param_1 == (int *)0x74) {
      piVar8 = (int *)0x0;
    }
    FUN_007c7aa0(piVar8,&iStack_38);
    param_1[-0x19] = param_1[0xd] - param_1[0xc] >> 3;
    (**(code **)(*param_1 + 0x48))();
    (**(code **)(*param_1 + 0x4c))();
    if (((((*(char *)((int)param_1 + 0x62) != '\0') && (param_1[0x15] == 0)) &&
         (*(char *)(param_1 + 0x19) == '\0')) &&
        ((fVar1 = (float)param_1[-0x17],
         fVar1 < (float)param_1[-0x14] || fVar1 == (float)param_1[-0x14] &&
         ((float)param_1[-0x16] < (float)param_1[-0x13] ||
          (float)param_1[-0x16] == (float)param_1[-0x13])))) &&
       ((float)param_1[-0x15] < (float)param_1[-0x12] ||
        (float)param_1[-0x15] == (float)param_1[-0x12])) {
      FUN_007c7690(param_1 + -0x17,
                   CONCAT31((int3)((uint)param_1[-0x1b] >> 8),*(undefined *)(param_1 + 0x18)));
    }
    *(undefined *)((int)param_1 + 0x62) = 0;
    if (DAT_01eb4564 != '\0') {
      iVar3 = param_1[-0xe];
      iVar4 = param_1[-0xf];
      pdVar9 = (double *)FUN_016827e0(auStack_2c);
      FUN_016773b0(DAT_01eb4564,
                   "FastCluster[%p]: updated geometry for %d parts in %d usec (%d entities, %d vertices)"
                   ,param_1 + -0x1d,param_1[0xd] - param_1[0xc] >> 3,
                   (int)((*pdVar9 - dStack_24) * DAT_018c0d70 * DAT_018c0d70),iVar3 - iVar4 >> 2,
                   uVar7);
    }
    thunk_FUN_007c4590();
  }
  uStack_8 = 4;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return;
}


