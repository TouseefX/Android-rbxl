/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 13250 ; VA 0x00868c61 ; Catch@00868c61 */

undefined * Catch_00868c61(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x24);
  if (DAT_01f6dcc0 != '\0') {
    uVar2 = (**(code **)(*piVar1 + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating part geometry buffers: %s",uVar2);
    if (DAT_01f6dcc0 != '\0') {
      FUN_01677490(DAT_01f6dcc0,"Geometry: %d vertices, %d indices",
                   *(undefined4 *)(unaff_EBP + 0x28),*(undefined4 *)(unaff_EBP + 0x30),0);
    }
  }
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_0086f2f0(3,"Failed to allocate %d kB VRAM for part render data: %s",
               (uint)(*(int *)(unaff_EBP + 0x28) * 0x2c) >> 10,uVar2);
  return &DAT_00868cd1;
}



/* FUNCTION 13251 ; VA 0x00868cec ; FUN_00868cec */

undefined FUN_00868cec(void)

{
  int unaff_EBP;
  
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 0;
}



/* FUNCTION 13252 ; VA 0x00868d60 ; FUN_00868d60 */

undefined4 * __thiscall
FUN_00868d60(undefined4 *param_1,undefined4 param_2,int param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  short *psVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8820;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00841300(param_2,(param_3 != 0) * '\x02' + '\x04');
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  *param_1 = RBX::Graphics::FastCluster_DEPRECATED::vftable;
  param_1[0x1d] = RBX::Graphics::FastCluster_DEPRECATED::vftable;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = param_3;
  param_1[0x2f] = param_4;
  *(char *)(param_1 + 0x30) = (char)param_5;
  *(undefined4 *)((int)param_1 + 0xc1) = 0;
  *(undefined *)((int)param_1 + 0xc5) = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  uStack_8 = 4;
  if (param_4 != (int *)0x0) {
    iVar3 = (**(code **)(*param_4 + 0x14))();
    if (iVar3 != 0) {
      uVar2 = 1;
      goto LAB_00868ec4;
    }
  }
  uVar2 = 0;
LAB_00868ec4:
  *(undefined *)(param_1 + 0x31) = uVar2;
  if (param_3 == 0) {
    psVar4 = (short *)(**(code **)(*param_4 + 4))(param_5);
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: create (grid %dx%dx%d, flags %d)",param_1,
                   (int)*psVar4,(int)psVar4[1],(int)psVar4[2],psVar4[3]);
    }
  }
  else {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,"FastCluster[%p]: create (humanoid %p)",param_1,param_3,0);
    }
    if (DAT_01d622b0 != '\0') {
      iVar3 = FUN_0097bf90(param_3);
      if (iVar3 != 0) {
        *(bool *)((int)param_1 + 0xc3) = *(int *)(param_3 + 0x34) == iVar3;
      }
    }
  }
  if ((char)param_5 == '\0') {
    FUN_007c7840(param_1 + 0x1d,2);
  }
  if (param_1[0x2e] == 0) {
    iVar3 = (uint)(*(char *)(param_1 + 0x30) != '\0') * 8 + 0x60;
  }
  else {
    iVar3 = 0x70;
  }
  piVar1 = (int *)(*(int *)(param_1[2] + 0x524) + iVar3);
  *piVar1 = *piVar1 + 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13253 ; VA 0x00868fb0 ; FUN_00868fb0 */

void __fastcall FUN_00868fb0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  piVar4 = (int *)*param_1;
  piVar6 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar4 = (int *)*param_1;
  if (piVar6 != piVar4) {
    do {
      iVar1 = piVar6[6];
      piVar2 = (int *)*piVar6;
      if (iVar1 != 0) {
        uVar5 = piVar6[8] - iVar1 & 0xfffffffc;
        iVar3 = iVar1;
        if (0xfff < uVar5) {
          iVar3 = *(int *)(iVar1 + -4);
          uVar5 = uVar5 + 0x23;
          if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar5);
        piVar6[6] = 0;
        piVar6[7] = 0;
        piVar6[8] = 0;
      }
      FUN_008690c0();
      if ((undefined4 *)piVar6[2] != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)piVar6[2])(1);
      }
      FUN_01674ea0(piVar6,0x24);
      piVar4 = (int *)*param_1;
      piVar6 = piVar2;
    } while (piVar2 != piVar4);
  }
  FUN_01674ea0(piVar4,0x24);
  return;
}



/* FUNCTION 13254 ; VA 0x00869060 ; FUN_00869060 */

void __fastcall FUN_00869060(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00869630(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13255 ; VA 0x008690c0 ; FUN_008690c0 */

void __fastcall FUN_008690c0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056b650();
        iVar2 = iVar2 + 0x2c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x2c) * 0x2c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13256 ; VA 0x00869140 ; FUN_00869140 */

void __fastcall FUN_00869140(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x58) * 0x58;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13257 ; VA 0x008691b0 ; FUN_008691b0 */

void FUN_008691b0(void)

{
  FUN_0056b650();
  return;
}



/* FUNCTION 13258 ; VA 0x008691c0 ; FUN_008691c0 */

void __fastcall FUN_008691c0(int param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00764680();
  FUN_0072a1c0();
  iVar2 = *(int *)(param_1 + 0xe8);
  piVar1 = (int *)(param_1 + 0xe8);
  uStack_8 = 0;
  FUN_00869630(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  *(undefined4 *)(param_1 + 0xec) = 0;
  FUN_01674ea0(*piVar1,0x38);
  FUN_00777180();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13259 ; VA 0x00869250 ; FUN_00869250 */

void __fastcall FUN_00869250(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar1 = param_1 + 0x1d;
  ExceptionList = &pvStack_10;
  *puVar1 = RBX::Graphics::FastCluster_DEPRECATED::vftable;
  *param_1 = RBX::Graphics::FastCluster_DEPRECATED::vftable;
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: unbind (%d parts, %d own connections)",param_1,
                 (int)(param_1[0x29] - param_1[0x28]) >> 3,(int)(param_1[0x21] - param_1[0x20]) >> 2
                );
  }
  FUN_011590c0();
  if (param_1[0x2e] == 0) {
    iVar4 = (uint)(*(char *)(param_1 + 0x30) != '\0') * 8 + 100;
  }
  else {
    iVar4 = 0x74;
  }
  piVar2 = (int *)(iVar4 + *(int *)(param_1[2] + 0x524));
  *piVar2 = *piVar2 - ((int)(param_1[0x29] - param_1[0x28]) >> 3);
  iVar4 = param_1[0x28];
  uVar6 = 0;
  if (param_1[0x29] - iVar4 >> 3 != 0) {
    do {
      (**(code **)(**(int **)(iVar4 + 4 + uVar6 * 8) + 0x40))();
      puVar3 = *(undefined4 **)(iVar4 + 4 + uVar6 * 8);
      if (puVar3 != (undefined4 *)0x0) {
        (**(code **)*puVar3)(1);
      }
      uVar6 = uVar6 + 1;
      iVar4 = param_1[0x28];
    } while (uVar6 < (uint)(param_1[0x29] - iVar4 >> 3));
  }
  param_1[0x26] = param_1[0x25];
  param_1[0x29] = param_1[0x28];
  param_1[0x2c] = param_1[0x2b];
  if (param_1[0x2e] == 0) {
    iVar4 = (uint)(*(char *)(param_1 + 0x30) != '\0') * 8 + 0x60;
  }
  else {
    iVar4 = 0x70;
  }
  piVar2 = (int *)(iVar4 + *(int *)(param_1[2] + 0x524));
  *piVar2 = *piVar2 + -1;
  FUN_007c78a0(puVar1,2);
  FUN_007b2650();
  FUN_0073e270();
  FUN_007c27b0();
  iVar4 = param_1[0x28];
  if (iVar4 != 0) {
    uVar6 = param_1[0x2a] - iVar4 & 0xfffffff8;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x28] = 0;
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
  }
  FUN_00869140();
  *param_1 = RBX::Graphics::FastCluster::vftable;
  *puVar1 = RBX::Graphics::FastCluster::vftable;
  FUN_01158110();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13260 ; VA 0x00869430 ; FUN_00869430 */

int FUN_00869430(int param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = (undefined4 *)(param_1 + 0x1c);
    do {
      FUN_0170d1f0(param_1,0,0x58);
      puVar1[-5] = 0x7f7fffff;
      puVar1[-4] = 0x7f7fffff;
      puVar1[-3] = 0x7f7fffff;
      param_1 = param_1 + 0x58;
      puVar1[-2] = 0xff7fffff;
      puVar1[-1] = 0xff7fffff;
      *puVar1 = 0xff7fffff;
      puVar1[1] = 0x3f800000;
      puVar1[2] = 0;
      puVar1[3] = 0;
      puVar1[4] = 0;
      puVar1[5] = 0x3f800000;
      puVar1[6] = 0;
      puVar1[7] = 0;
      puVar1[8] = 0;
      puVar1[9] = 0x3f800000;
      puVar1[10] = 0;
      puVar1[0xb] = 0;
      puVar1[0xc] = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0x16;
    } while (param_2 != 0);
  }
  return param_1;
}



/* FUNCTION 13261 ; VA 0x008694ea ; FUN_008694ea */

void FUN_008694ea(void)

{
  FUN_008695b0();
  return;
}



/* FUNCTION 13262 ; VA 0x00869500 ; FUN_00869500 */

undefined4 __thiscall FUN_00869500(undefined4 param_1,byte param_2)

{
  FUN_01158110();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 13263 ; VA 0x00869530 ; FUN_00869530 */

undefined4 * __thiscall FUN_00869530(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::Graphics::FastClusterEntity_DEPRECATED::vftable;
  iVar1 = param_1[0x13];
  if (iVar1 != 0) {
    uVar3 = param_1[0x15] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  FUN_00841390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x74);
  }
  return param_1;
}



/* FUNCTION 13264 ; VA 0x008695b0 ; FUN_008695b0 */

undefined4 __thiscall FUN_008695b0(undefined4 param_1,byte param_2)

{
  FUN_00869250();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xe0);
  }
  return param_1;
}



/* FUNCTION 13265 ; VA 0x008695e0 ; FUN_008695e0 */

void FUN_008695e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_00868fb0();
  piVar2 = *(int **)(param_1 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_1,0x38);
  return;
}



/* FUNCTION 13266 ; VA 0x00869630 ; FUN_00869630 */

undefined4 __thiscall FUN_00869630(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_00869630(param_2[2]);
    piVar2 = (int *)*param_2;
    FUN_00868fb0();
    piVar3 = (int *)param_2[7];
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(param_2,0x38);
    param_2 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return param_1;
}



/* FUNCTION 13267 ; VA 0x008696b0 ; FUN_008696b0 */

void __thiscall FUN_008696b0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined4 uStack_8;
  
  uVar3 = DAT_018c45d0;
  uVar2 = DAT_018c45c4;
  uStack_2c = param_2;
  uStack_20 = 0x7f7fffff;
  puVar1 = *(undefined4 **)(param_1 + 0xf4);
  uStack_8 = 0xff7fffff;
  uStack_28 = CONCAT44(DAT_018c45c4,DAT_018c45c4);
  uStack_1c = CONCAT44(DAT_018c45d0,DAT_018c45d0);
  uStack_14 = 0xff7fffff;
  if (*(undefined4 **)(param_1 + 0xf8) != puVar1) {
    *puVar1 = param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar2;
    puVar1[3] = 0x7f7fffff;
    *(ulonglong *)(puVar1 + 4) = CONCAT44(uVar3,uVar3);
    puVar1[6] = 0xff7fffff;
    *(int *)(param_1 + 0xf4) = *(int *)(param_1 + 0xf4) + 0x1c;
    return;
  }
  FUN_00725c30(puVar1,&uStack_2c);
  return;
}



/* FUNCTION 13268 ; VA 0x00869730 ; FUN_00869730 */

int __thiscall
FUN_00869730(undefined4 *param_1,int param_2,int param_3,int param_4,uint param_5,uint *param_6,
            undefined4 param_7)

{
  int iVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  uint *puVar5;
  uint *puVar6;
  uint uVar7;
  undefined4 uVar8;
  int *piVar9;
  uint *puVar10;
  uint *puVar11;
  undefined auStack_d4 [76];
  int iStack_88;
  int iStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  int iStack_60;
  uint uStack_5c;
  int *piStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint *puStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  undefined uStack_15;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b884b;
  pvStack_10 = ExceptionList;
  puStack_24 = param_1 + 1;
  if (param_1[1] == 0) {
    puStack_24 = (undefined4 *)0x0;
  }
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  iVar4 = FUN_00761230(&uStack_5c,param_3,param_4,puStack_24,param_5);
  puVar11 = param_6;
  uStack_8 = 0;
  if (uStack_5c == 0) goto LAB_00869b16;
  if ((param_5 & 0x400) != 0) {
    uStack_54 = uStack_54 | 8;
  }
  piStack_1c = param_1 + 0x3a;
  puVar10 = (uint *)*piStack_1c;
  uStack_3c = uStack_5c;
  puStack_38 = param_6;
  puVar5 = (uint *)puVar10[1];
  if (*(char *)((int)puVar10[1] + 0xd) == '\0') {
    do {
      if ((puVar5[4] < uStack_5c) || ((puVar5[4] <= uStack_5c && ((int)puVar5[5] < (int)param_6))))
      {
        puVar6 = (uint *)puVar5[2];
      }
      else {
        puVar6 = (uint *)*puVar5;
        puVar10 = puVar5;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    if (((puVar10 == (uint *)*piStack_1c) || (uStack_5c < puVar10[4])) ||
       ((uStack_5c <= puVar10[4] && ((int)param_6 < (int)puVar10[5])))) goto LAB_008697f5;
  }
  else {
LAB_008697f5:
    puStack_14 = &uStack_3c;
    iVar4 = FUN_00841e90(&DAT_018bdeda,&puStack_14,&uStack_15);
    FUN_00867b40(&puStack_14,puVar10,iVar4 + 0x10,iVar4);
    puVar10 = puStack_14;
  }
  if (puVar10[6] == 0) {
    if (piStack_58 != (int *)0x0) {
      LOCK();
      piStack_58[1] = piStack_58[1] + 1;
      UNLOCK();
    }
    puVar10[6] = uStack_5c;
    piVar9 = (int *)puVar10[7];
    puVar10[7] = (uint)piStack_58;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar4 = piVar9[1] + -1;
      piVar9[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar9)();
        LOCK();
        iVar4 = piVar9[2] + -1;
        piVar9[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar9 + 4))();
        }
      }
    }
    puVar10[8] = (uint)param_6;
    puVar10[9] = uStack_54;
    puVar10[10] = uStack_50;
    *(bool *)(puVar10 + 0xb) = param_4 != 0;
    puVar11 = param_6;
  }
  if ((puVar11 == (uint *)&DAT_00000009) || (puVar11 == (uint *)&DAT_00000008)) {
    uVar7 = puVar10[0xd];
    if (uVar7 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(*(int *)(puVar10[0xc] + 4) + 0x10);
      if (*(int *)(*(int *)(puVar10[0xc] + 4) + 0xc) == iVar4) {
        iVar4 = 0;
      }
      else {
        iVar4 = *(int *)(iVar4 + -0x2c);
      }
    }
    if (param_3 == iVar4) goto LAB_00869895;
    bVar2 = true;
  }
  else {
    uVar7 = puVar10[0xd];
LAB_00869895:
    bVar2 = false;
  }
  if ((uVar7 == 0) || (bVar2)) {
    param_6 = (uint *)puVar10[0xc];
    puStack_14 = (uint *)param_6[1];
    uVar7 = FUN_00867790(param_6,puStack_14);
    if (puVar10[0xd] == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    puVar10[0xd] = puVar10[0xd] + 1;
    param_6[1] = uVar7;
    *puStack_14 = uVar7;
  }
  else {
    puVar11 = puVar10 + 0xc;
    if ((DAT_01d622a0 == '\0') &&
       (uVar7 = (**(code **)(**(int **)(*(int *)(*puVar11 + 4) + 8) + 0x14))(), 0x7fff < uVar7)) {
      FUN_008688a0();
    }
    else {
      iVar4 = *(int *)(*puVar11 + 4);
      param_6 = puVar11;
      if (((uint)puStack_20[0x37] <= (uint)(*(int *)(iVar4 + 0x1c) - *(int *)(iVar4 + 0x18) >> 2))
         && (*(int *)(*(int *)(iVar4 + 0x1c) + -4) != param_2)) {
        FUN_008688a0();
      }
    }
  }
  puVar11 = puVar10 + 0xc;
  if (((param_5 & 0x20) == 0) &&
     ((puStack_24 == (undefined4 *)0x0 || (cVar3 = FUN_01154e00(param_3), cVar3 == '\0')))) {
    uVar8 = 0;
  }
  else {
    uVar8 = 1;
  }
  FUN_007484a0(&uStack_34,param_3,puStack_24,uVar8,param_7,puStack_20[0x38]);
  iVar4 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0073dcf0(*puStack_20,param_3,param_4,puVar10[9],0xffffffff,6);
  if ((DAT_01d622a0 != '\0') &&
     (cVar3 = (**(code **)(**(int **)(*(int *)(*puVar11 + 4) + 8) + 0xc))
                        (iVar4,param_4,0,auStack_d4,&uStack_34,0), cVar3 == '\0')) {
    FUN_008688a0();
    (**(code **)(**(int **)(*(int *)(*puVar11 + 4) + 8) + 8))
              (iVar4,param_4,0,auStack_d4,&uStack_34,0);
  }
  iVar1 = *(int *)(*puVar11 + 4);
  if (DAT_01d622a0 == '\0') {
    (**(code **)(**(int **)(iVar1 + 8) + 8))(iVar4,param_4,0,auStack_d4,&uStack_34,0);
  }
  piVar9 = *(int **)(iVar1 + 0x1c);
  if ((*(int **)(iVar1 + 0x18) == piVar9) || (piVar9[-1] != param_2)) {
    if (*(int **)(iVar1 + 0x20) == piVar9) {
      FUN_00595d30(piVar9,&param_2);
    }
    else {
      *piVar9 = param_2;
      *(int *)(iVar1 + 0x1c) = *(int *)(iVar1 + 0x1c) + 4;
    }
    piVar9 = *(int **)(iVar1 + 0x1c);
  }
  iStack_88 = iVar4;
  iStack_84 = param_4;
  iStack_80 = ((int)piVar9 - *(int *)(iVar1 + 0x18) >> 2) + -1;
  uStack_7c = uStack_4c;
  uStack_78 = uStack_48;
  uStack_74 = uStack_44;
  uStack_70 = uStack_40;
  if (iStack_30 != 0) {
    LOCK();
    *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
    UNLOCK();
  }
  iStack_68 = iStack_30;
  uStack_6c = uStack_34;
  if (iStack_28 != 0) {
    LOCK();
    *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
    UNLOCK();
  }
  uStack_64 = uStack_2c;
  iStack_60 = iStack_28;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (*(int *)(iVar1 + 0x14) == *(int *)(iVar1 + 0x10)) {
    FUN_00867830(*(int *)(iVar1 + 0x10),&iStack_88);
  }
  else {
    FUN_00868830(iVar1 + 0xc);
    *(int *)(iVar1 + 0x10) = *(int *)(iVar1 + 0x10) + 0x2c;
  }
  FUN_0056b650();
  iVar4 = FUN_0056b650();
LAB_00869b16:
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_58 + 1;
    iVar1 = *piVar9;
    iVar4 = *piVar9;
    *piVar9 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_58)();
      LOCK();
      piVar9 = piStack_58 + 2;
      iVar1 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 13269 ; VA 0x00869b60 ; FUN_00869b60 */

void __thiscall FUN_00869b60(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b887f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eb4564 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: addPart %p (part count was %d)",param_1,*param_2,
                 *(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 3);
    if (DAT_01eb4564 != '\0') {
      puVar2 = (undefined4 *)FUN_008a2380(auStack_34);
      uStack_8 = 0;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677650(DAT_01eb4564,"FastCluster part: %s",puVar2);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_20) {
        uVar6 = uStack_20 + 1;
        uVar5 = auStack_34[0];
        if (0xfff < uVar6) {
          uVar5 = *(uint *)(auStack_34[0] - 4);
          uVar6 = uStack_20 + 0x24;
          if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar6);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
    }
  }
  iVar4 = *param_2;
  iStack_1c = iVar4;
  puVar2 = (undefined4 *)FUN_01674e20(0x20);
  uStack_8 = 1;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)0x0;
  }
  else {
    if (*(int **)(param_1 + 0xbc) == (int *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = (**(code **)(**(int **)(param_1 + 0xbc) + 0x14))();
    }
    *puVar2 = RBX::GfxBinding::vftable;
    puVar2[1] = 0;
    puVar2[2] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar2[1] = *param_2;
    puVar2[2] = param_2[1];
    puVar2[3] = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[7] = uVar3;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    *puVar2 = RBX::Graphics::FastClusterBinding_DEPRECATED::vftable;
    puVar2[6] = param_1;
    FUN_01158150(param_2);
    *(int *)(*param_2 + 0xb0) = param_1 + 0x74;
    puStack_18 = puVar2;
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: bound part %p to binding %p (%d connections)",
                   param_1,*param_2,puVar2,(int)(puVar2[4] - puVar2[3]) >> 2,0);
    }
  }
  piVar1 = *(int **)(param_1 + 0xa4);
  uStack_8 = 0xffffffff;
  if (*(int **)(param_1 + 0xa8) == piVar1) {
    FUN_00805800(piVar1,&iStack_1c);
  }
  else {
    *piVar1 = iVar4;
    piVar1[1] = (int)puStack_18;
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 8;
  }
  if (*(int *)(param_1 + 0xb8) == 0) {
    iVar4 = (uint)(*(char *)(param_1 + 0xc0) != '\0') * 8 + 100;
  }
  else {
    iVar4 = 0x74;
  }
  piVar1 = (int *)(*(int *)(*(int *)(param_1 + 8) + 0x524) + iVar4);
  *piVar1 = *piVar1 + 1;
  *(undefined *)(param_1 + 0xc2) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13270 ; VA 0x00869d90 ; FUN_00869d90 */

int __fastcall FUN_00869d90(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  iVar7 = *(int *)(param_1 + 8);
  puVar3 = *(undefined4 **)(param_1 + 0xa4);
  uStack_14 = *(undefined4 *)(iVar7 + 0x4e4);
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  for (puVar8 = *(undefined4 **)(param_1 + 0xa0); ExceptionList = ppvVar5, puVar8 != puVar3;
      puVar8 = puVar8 + 2) {
    uVar6 = FUN_0060dcd0(auStack_1c,*puVar8);
    uStack_8 = 0;
    iVar7 = FUN_007c8e00(uVar6);
    piVar4 = piStack_18;
    uStack_8 = 0xffffffff;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar7 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ppvVar5 = (void **)ExceptionList;
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 13271 ; VA 0x00869e40 ; FUN_00869e40 */

void __fastcall FUN_00869e40(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  void **ppvVar5;
  undefined4 *puVar6;
  char cVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined auStack_1c [4];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017af1f8;
  pvStack_10 = ExceptionList;
  puVar9 = *(undefined4 **)(param_1 + 0xa0);
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  ppvVar5 = &pvStack_10;
  if (*(int *)(param_1 + 0xa4) - (int)puVar9 >> 3 != 0) {
    do {
      uVar10 = uStack_14;
      cVar7 = FUN_011584c0();
      if (cVar7 == '\0') {
        if (DAT_01eb4564 != '\0') {
          FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p is no longer in workspace",param_1,
                       puVar9[uVar10 * 2],0);
        }
        if ((undefined4 *)puVar9[uVar10 * 2 + 1] != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)puVar9[uVar10 * 2 + 1])(1);
        }
        puVar9[uVar10 * 2 + 1] = 0;
      }
      else {
        iVar8 = FUN_007c7390(puVar9[uVar10 * 2]);
        if (*(int *)(param_1 + 0xb8) != iVar8) {
          if (DAT_01eb4564 != '\0') {
            FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: part %p changed humanoid from %p to %p",
                         param_1,puVar9[uVar10 * 2],iVar8,*(int *)(param_1 + 0xb8),0);
          }
          FUN_0060dcd0(auStack_1c,puVar9[uVar10 * 2]);
          uStack_8 = 0;
          (**(code **)(*(int *)puVar9[uVar10 * 2 + 1] + 0x40))();
          if ((undefined4 *)puVar9[uVar10 * 2 + 1] != (undefined4 *)0x0) {
            (*(code *)**(undefined4 **)puVar9[uVar10 * 2 + 1])(1);
          }
          puVar9[uVar10 * 2 + 1] = 0;
          FUN_007c8e00(auStack_1c);
          piVar4 = piStack_18;
          uStack_8 = 0xffffffff;
          uVar10 = uStack_14;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar8 = piStack_18[1] + -1;
            piStack_18[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar8 = *piVar1 + -1;
              *piVar1 = iVar8;
              UNLOCK();
              uVar10 = uStack_14;
              if (iVar8 == 0) {
                (**(code **)(*piVar4 + 4))();
                uVar10 = uStack_14;
              }
            }
          }
        }
      }
      if (puVar9[uVar10 * 2 + 1] == 0) {
        iVar8 = FUN_0086b780();
        *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + -1;
        *(undefined *)(param_1 + 0xc2) = 1;
      }
      uStack_14 = uVar10 + 1;
      puVar9 = *(undefined4 **)(param_1 + 0xa0);
      ppvVar5 = (void **)ExceptionList;
    } while (uStack_14 < (uint)(*(int *)(param_1 + 0xa4) - (int)puVar9 >> 3));
  }
  ExceptionList = ppvVar5;
  puVar2 = *(undefined4 **)(param_1 + 0xa4);
  if (puVar9 != puVar2) {
    do {
      if (puVar9[1] == 0) break;
      puVar9 = puVar9 + 2;
    } while (puVar9 != puVar2);
    puVar6 = puVar9;
    if (puVar9 != puVar2) {
      while (puVar3 = puVar6, puVar6 = puVar3 + 2, puVar6 != puVar2) {
        if (puVar3[3] != 0) {
          *puVar9 = *puVar6;
          puVar9[1] = puVar3[3];
          puVar9 = puVar9 + 2;
        }
      }
      if (puVar9 != puVar2) {
        iVar8 = *(int *)(param_1 + 0xa4) - (int)puVar2;
        FUN_0170cc70(puVar9,puVar2,iVar8);
        *(int *)(param_1 + 0xa4) = iVar8 + (int)puVar9;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13272 ; VA 0x0086a030 ; FUN_0086a030 */

void __fastcall FUN_0086a030(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  char cVar5;
  undefined uVar6;
  short *psVar7;
  undefined4 *puVar8;
  uint uVar9;
  int iVar10;
  undefined4 uVar11;
  short sVar12;
  uint uVar13;
  undefined4 *puVar14;
  char *pcVar15;
  int iVar16;
  undefined auStack_38 [8];
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7688;
  pvStack_10 = ExceptionList;
  if (param_1[0x2f] != 0) {
    ExceptionList = &pvStack_10;
    psVar7 = (short *)(**(code **)(*param_1 + 0x28))();
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: checking cluster (spatial index %dx%dx%d-%u)",
                   param_1,(int)*psVar7,(int)psVar7[1],(int)psVar7[2],psVar7[3]);
    }
    iVar10 = param_1[0x28];
    cStack_11 = '\0';
    uStack_1c = *(undefined4 *)(param_1[2] + 0x4e4);
    uStack_18 = 0;
    if (param_1[0x29] - iVar10 >> 3 != 0) {
      do {
        cVar5 = FUN_011584c0();
        if (cVar5 != '\0') {
          uVar6 = FUN_007c7420(*(undefined4 *)(iVar10 + uStack_18 * 8));
          uStack_20 = CONCAT31(uStack_20._1_3_,uVar6);
          uStack_28 = 0;
          uStack_24 = 0;
          puVar8 = (undefined4 *)
                   (**(code **)(*(int *)param_1[0x2f] + 8))
                             (auStack_38,*(undefined4 *)(iVar10 + uStack_18 * 8),uStack_20);
          uStack_28 = *puVar8;
          uVar11 = puVar8[1];
          uStack_24._2_2_ = (ushort)((uint)uVar11 >> 0x10);
          uStack_24 = uVar11;
          if (psVar7[3] == uStack_24._2_2_) {
            uStack_24._0_2_ = (short)uVar11;
            sVar12 = psVar7[2] - (short)uStack_24;
            uStack_28._2_2_ = (short)((uint)uStack_28 >> 0x10);
            if ((((DAT_01d623ec <= (short)(*psVar7 - (short)uStack_28)) &&
                 ((short)(*psVar7 - (short)uStack_28) <= DAT_01d623f4)) &&
                (DAT_01d623ee <= (short)(psVar7[1] - uStack_28._2_2_))) &&
               ((((short)(psVar7[1] - uStack_28._2_2_) <= DAT_01d623f6 && (DAT_01d623f0 <= sVar12))
                && (sVar12 <= DAT_01d623f8)))) goto LAB_0086a280;
          }
          if (cStack_11 == '\0') {
            FUN_007c5500(&uStack_28);
            (**(code **)(*param_1 + 0x18))();
          }
          cVar5 = FUN_007c5500(psVar7);
          if (cVar5 == '\0') {
            if (param_1[0x2f] != 0) {
              uVar11 = (**(code **)(*param_1 + 0x20))();
              FUN_007c8b40(param_1 + 0x1d,uVar11);
            }
            break;
          }
          uVar13 = (uint)(ushort)psVar7[3];
          if (psVar7[3] == uStack_24._2_2_) {
            if (DAT_01eb4564 != '\0') {
              iVar16 = (int)psVar7[2];
              uVar9 = (uint)psVar7[1];
              uVar13 = (uint)*psVar7;
              uVar11 = *(undefined4 *)(iVar10 + uStack_18 * 8);
              pcVar15 = "FastCluster[%p]: part %p changed spatial index to %dx%dx%d";
              goto LAB_0086a1dd;
            }
          }
          else if (DAT_01eb4564 != '\0') {
            iVar16 = 0;
            uVar9 = (uint)uStack_24._2_2_;
            uVar11 = *(undefined4 *)(iVar10 + uStack_18 * 8);
            pcVar15 = "FastCluster[%p]: part %p changed FW status from %d to %d";
LAB_0086a1dd:
            FUN_016773b0(DAT_01eb4564,pcVar15,param_1,uVar11,uVar13,uVar9,iVar16);
          }
          FUN_0060dcd0(auStack_30,*(undefined4 *)(iVar10 + uStack_18 * 8));
          uStack_8 = 0;
          (**(code **)(**(int **)(iVar10 + 4 + uStack_18 * 8) + 0x40))();
          puVar8 = *(undefined4 **)(iVar10 + 4 + uStack_18 * 8);
          if (puVar8 != (undefined4 *)0x0) {
            (**(code **)*puVar8)(1);
          }
          *(undefined4 *)(iVar10 + 4 + uStack_18 * 8) = 0;
          FUN_007c8e00(auStack_30);
          iVar10 = FUN_0086b780();
          piVar3 = piStack_2c;
          cStack_11 = '\x01';
          uStack_8 = 0xffffffff;
          *(int *)(iVar10 + 4) = *(int *)(iVar10 + 4) + -1;
          *(undefined *)((int)param_1 + 0xc2) = 1;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar10 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
LAB_0086a280:
        iVar10 = param_1[0x28];
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < (uint)(param_1[0x29] - iVar10 >> 3));
      if (cStack_11 != '\0') {
        puVar8 = (undefined4 *)param_1[0x29];
        puVar14 = (undefined4 *)param_1[0x28];
        if (puVar14 != puVar8) {
          do {
            if (puVar14[1] == 0) break;
            puVar14 = puVar14 + 2;
          } while (puVar14 != puVar8);
          puVar4 = puVar14;
          if (puVar14 != puVar8) {
            while (puVar2 = puVar4, puVar4 = puVar2 + 2, puVar4 != puVar8) {
              if (puVar2[3] != 0) {
                *puVar14 = *puVar4;
                puVar14[1] = puVar2[3];
                puVar14 = puVar14 + 2;
              }
            }
            if (puVar14 != puVar8) {
              iVar10 = param_1[0x29];
              FUN_0170cc70(puVar14,puVar8,iVar10 - (int)puVar8);
              param_1[0x29] = (iVar10 - (int)puVar8) + (int)puVar14;
            }
          }
        }
        (**(code **)(*(int *)param_1[0x2f] + 0xc))(param_1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13273 ; VA 0x0086a350 ; FUN_0086a350 */

int __thiscall FUN_0086a350(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined auStack_128 [4];
  int *piStack_124;
  undefined auStack_110 [4];
  int *piStack_10c;
  undefined auStack_f8 [4];
  int *piStack_f4;
  undefined auStack_f0 [4];
  int *piStack_ec;
  undefined auStack_e8 [4];
  int *piStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  int *piStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined8 uStack_ac;
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  int iStack_9c;
  int *piStack_98;
  int iStack_94;
  int *piStack_90;
  int *piStack_8c;
  int *piStack_88;
  int *piStack_84;
  int *piStack_80;
  int *piStack_7c;
  uint uStack_78;
  int iStack_74;
  int iStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  int iStack_5c;
  int *piStack_58;
  int *piStack_54;
  int iStack_50;
  int iStack_4c;
  undefined4 *puStack_48;
  int iStack_44;
  int *piStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b892f;
  pvStack_10 = ExceptionList;
  iStack_50 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if ((*(int *)(iStack_50 + 0x34) < DAT_01ece200) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ece200), DAT_01ece200 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","finalize",0xffffffff);
    DAT_01ece1fc = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ece1f8 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ece200);
  }
  uStack_b8 = DAT_01ece1f8;
  uStack_a4 = DAT_01ece1fc;
  uStack_e0 = DAT_01ece1f8;
  uStack_dc = DAT_01ece1fc;
  uStack_d8 = FUN_0152d930(DAT_01ece1f8,DAT_01ece1fc);
  iStack_28 = 0;
  piVar11 = (int *)0x0;
  iStack_94 = 0;
  piStack_90 = (int *)0x0;
  piStack_54 = (int *)0x0;
  piStack_8c = (int *)0x0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  iStack_1c = *(int *)param_1[0x3a];
  if ((int *)iStack_1c != (int *)param_1[0x3a]) {
    do {
      iStack_28 = iStack_1c + 0x18;
      piVar10 = (int *)**(int **)(iStack_1c + 0x30);
      if (piVar10 != *(int **)(iStack_1c + 0x30)) {
        do {
          piVar6 = piVar10 + 2;
          if (piVar10[3] != piVar10[4]) {
            iVar4 = (**(code **)(*(int *)*piVar6 + 0x14))();
            if (iVar4 != 0) {
              iVar4 = (**(code **)(*(int *)*piVar6 + 0x18))();
              if (iVar4 != 0) {
                iStack_9c = iStack_28;
                piStack_98 = piVar6;
                if (piStack_54 == piVar11) {
                  FUN_00559ce0(piVar11,&iStack_9c);
                  piStack_54 = piStack_8c;
                  piVar11 = piStack_90;
                }
                else {
                  *piVar11 = iStack_28;
                  piVar11[1] = (int)piVar6;
                  piStack_90 = piVar11 + 2;
                  piVar11 = piStack_90;
                }
              }
            }
          }
          piVar10 = (int *)*piVar10;
          param_1 = piStack_14;
        } while (piVar10 != (int *)*(int *)(iStack_28 + 0x18));
      }
      FUN_00551320();
    } while (iStack_1c != param_1[0x3a]);
    iStack_28 = iStack_94;
  }
  iVar4 = iStack_28;
  uStack_3c = (int)piVar11 - iStack_28 >> 3;
  iStack_94 = iStack_28;
  FUN_008684b0(iStack_28,piVar11,uStack_3c,param_2);
  iStack_24 = 0;
  uVar9 = 0;
  iStack_18 = 0;
  iStack_20 = 0;
  iStack_1c = 0;
  if (uStack_3c != 0) {
    puVar5 = (undefined4 *)(iVar4 + 4);
    puStack_a0 = puVar5;
    do {
      puVar1 = (undefined4 *)*puVar5;
      iVar4 = (**(code **)(*(int *)*puVar1 + 0x14))();
      iStack_24 = iStack_24 + iVar4;
      iVar4 = (**(code **)(*(int *)*puVar1 + 0x18))();
      iStack_18 = iStack_18 + iVar4;
      iVar4 = (**(code **)(*(int *)*puVar1 + 0x1c))();
      iStack_20 = iStack_20 + iVar4;
      iVar4 = (**(code **)(*(int *)*puVar1 + 0x20))();
      piVar11 = piStack_14;
      puVar5 = puVar5 + 2;
      iVar4 = iStack_1c + iVar4;
      uVar9 = uVar9 + 1;
      iStack_1c = iVar4;
    } while (uVar9 < uStack_3c);
    if ((iStack_24 != 0) || (iStack_18 != 0)) {
      piStack_88 = (int *)0x0;
      piStack_84 = (int *)0x0;
      piStack_6c = (int *)0x0;
      piStack_68 = (int *)0x0;
      piStack_80 = (int *)0x0;
      piStack_7c = (int *)0x0;
      piStack_64 = (int *)0x0;
      piStack_60 = (int *)0x0;
      uStack_8._0_1_ = 7;
      iStack_4c = 0;
      iStack_74 = 0;
      iStack_1c = 0;
      iStack_70 = 0;
      cVar3 = FUN_008688f0(&piStack_88,&piStack_6c,&piStack_80,&piStack_64,&iStack_4c,&iStack_74,
                           &iStack_1c,&iStack_70,iStack_24,iStack_20,iStack_18,iVar4);
      if (cVar3 == '\0') {
        iVar4 = 0;
      }
      else {
        iStack_5c = 0;
        piStack_58 = (int *)0x0;
        iStack_44 = 0;
        piStack_40 = (int *)0x0;
        uStack_8._0_1_ = 10;
        iStack_30 = 0;
        iStack_34 = 0;
        iStack_38 = 0;
        iStack_20 = 0;
        uStack_78 = 0;
        if (uStack_3c != 0) {
          do {
            iStack_18 = *(int *)(iStack_28 + uStack_78 * 8);
            puVar5 = (undefined4 *)puStack_a0[uStack_78 * 2];
            puStack_48 = puVar5;
            (**(code **)(*(int *)*puVar5 + 0x14))();
            (**(code **)(*(int *)*puVar5 + 0x1c))();
            if (iStack_5c == 0) {
              iVar4 = *piVar11;
              iStack_2c = *(int *)(iVar4 + 0x3c);
              if (*(int *)(iVar4 + 0x554) == 0) {
                if (*(int *)(iStack_50 + 0x34) < DAT_01ece2e4) {
                  FUN_016f3809(&DAT_01ece2e4);
                  if (DAT_01ece2e4 == -1) {
                    FUN_0147c5c0(0,0,2,0,0);
                    FUN_0147c5c0(0,0xc,6,1,0);
                    FUN_0147c5c0(0,0x10,7,2,0);
                    FUN_0147c5c0(0,0x14,6,2,1);
                    FUN_0147c5c0(0,0x18,1,3,0);
                    FUN_0147c5c0(0,0x20,1,3,1);
                    FUN_0147c5c0(0,0x28,6,3,2);
                    FUN_016f37bf(&DAT_01ece2e4);
                  }
                }
                puVar5 = (undefined4 *)FUN_0147c1b0(auStack_f0,&DAT_01ece258,7,0x2c);
                uVar7 = *puVar5;
                uVar2 = puVar5[1];
                *puVar5 = 0;
                puVar5[1] = 0;
                *(undefined4 *)(iVar4 + 0x554) = uVar7;
                piVar11 = *(int **)(iVar4 + 0x558);
                *(undefined4 *)(iVar4 + 0x558) = uVar2;
                if (piVar11 != (int *)0x0) {
                  LOCK();
                  iVar8 = piVar11[1] + -1;
                  piVar11[1] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)*piVar11)();
                    LOCK();
                    iVar8 = piVar11[2] + -1;
                    piVar11[2] = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)(*piVar11 + 4))();
                    }
                  }
                }
                piVar11 = piStack_ec;
                if (piStack_ec != (int *)0x0) {
                  LOCK();
                  iVar8 = piStack_ec[1] + -1;
                  piStack_ec[1] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)*piStack_ec)();
                    LOCK();
                    piVar10 = piVar11 + 2;
                    iVar8 = *piVar10 + -1;
                    *piVar10 = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)(*piVar11 + 4))();
                    }
                  }
                }
              }
              piVar6 = (int *)FUN_0147c0e0(auStack_f8,(undefined4 *)(iVar4 + 0x554),&piStack_88,
                                           &piStack_80);
              piVar10 = piStack_58;
              iStack_5c = *piVar6;
              piVar11 = (int *)piVar6[1];
              *piVar6 = 0;
              piVar6[1] = 0;
              if (piStack_58 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_58[1] + -1;
                piStack_58[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  puVar5 = (undefined4 *)*piStack_58;
                  piStack_58 = piVar11;
                  (*(code *)*puVar5)();
                  LOCK();
                  piVar11 = piVar10 + 2;
                  iVar4 = *piVar11 + -1;
                  *piVar11 = iVar4;
                  UNLOCK();
                  piVar11 = piStack_58;
                  if (iVar4 == 0) {
                    (**(code **)(*piVar10 + 4))();
                    piVar11 = piStack_58;
                  }
                }
              }
              piStack_58 = piVar11;
              piVar10 = piStack_f4;
              piVar11 = piStack_14;
              if (piStack_f4 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_f4[1] + -1;
                piStack_f4[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piStack_f4)();
                  LOCK();
                  piVar11 = piVar10 + 2;
                  iVar4 = *piVar11 + -1;
                  *piVar11 = iVar4;
                  UNLOCK();
                  piVar11 = piStack_14;
                  if (iVar4 == 0) {
                    (**(code **)(*piVar10 + 4))();
                    piVar11 = piStack_14;
                  }
                }
              }
            }
            if (((iStack_44 == 0) && (piStack_6c != (int *)0x0)) && (piStack_64 != (int *)0x0)) {
              iVar4 = *piVar11;
              iStack_2c = *(int *)(iVar4 + 0x3c);
              if (*(int *)(iVar4 + 0x564) == 0) {
                if (*(int *)(iStack_50 + 0x34) < DAT_01ece250) {
                  FUN_016f3809(&DAT_01ece250);
                  if (DAT_01ece250 == -1) {
                    FUN_0147c5c0(0,0,2,0,0);
                    FUN_0147c5c0(0,0xc,6,2,0);
                    FUN_0147c5c0(0,0x10,1,3,0);
                    FUN_016f37bf(&DAT_01ece250);
                  }
                }
                puVar5 = (undefined4 *)FUN_0147c1b0(auStack_e8,&DAT_01ece214,3,0x18);
                uVar7 = *puVar5;
                uVar2 = puVar5[1];
                *puVar5 = 0;
                puVar5[1] = 0;
                *(undefined4 *)(iVar4 + 0x564) = uVar7;
                piVar11 = *(int **)(iVar4 + 0x568);
                *(undefined4 *)(iVar4 + 0x568) = uVar2;
                if (piVar11 != (int *)0x0) {
                  LOCK();
                  iVar8 = piVar11[1] + -1;
                  piVar11[1] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)*piVar11)();
                    LOCK();
                    iVar8 = piVar11[2] + -1;
                    piVar11[2] = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)(*piVar11 + 4))();
                    }
                  }
                }
                piVar11 = piStack_e4;
                if (piStack_e4 != (int *)0x0) {
                  LOCK();
                  iVar8 = piStack_e4[1] + -1;
                  piStack_e4[1] = iVar8;
                  UNLOCK();
                  if (iVar8 == 0) {
                    (**(code **)*piStack_e4)();
                    LOCK();
                    piVar10 = piVar11 + 2;
                    iVar8 = *piVar10 + -1;
                    *piVar10 = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)(*piVar11 + 4))();
                    }
                  }
                }
              }
              piVar6 = (int *)FUN_0147c0e0(&uStack_ac,(undefined4 *)(iVar4 + 0x564),&piStack_6c,
                                           &piStack_64);
              piVar10 = piStack_40;
              iStack_44 = *piVar6;
              piVar11 = (int *)piVar6[1];
              *piVar6 = 0;
              piVar6[1] = 0;
              if (piStack_40 != (int *)0x0) {
                LOCK();
                iVar4 = piStack_40[1] + -1;
                piStack_40[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  puVar5 = (undefined4 *)*piStack_40;
                  piStack_40 = piVar11;
                  (*(code *)*puVar5)();
                  LOCK();
                  piVar11 = piVar10 + 2;
                  iVar4 = *piVar11 + -1;
                  *piVar11 = iVar4;
                  UNLOCK();
                  piVar11 = piStack_40;
                  if (iVar4 == 0) {
                    (**(code **)(*piVar10 + 4))();
                    piVar11 = piStack_40;
                  }
                }
              }
              piStack_40 = piVar11;
              piVar11 = uStack_ac._4_4_;
              if (uStack_ac._4_4_ != (int *)0x0) {
                LOCK();
                iVar4 = uStack_ac._4_4_[1] + -1;
                uStack_ac._4_4_[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*uStack_ac._4_4_)();
                  LOCK();
                  piVar10 = piVar11 + 2;
                  iVar4 = *piVar10 + -1;
                  *piVar10 = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar11 + 4))();
                  }
                }
              }
            }
            uVar7 = (**(code **)(*param_2 + 0x20))();
            puVar5 = puStack_48;
            FUN_0086afc0(auStack_128,iStack_18,puStack_48,iStack_30 * 0x2c + iStack_4c,
                         iStack_74 + iStack_38 * 0x18,iStack_1c + iStack_34 * 2,
                         iStack_70 + iStack_20 * 2,0,0,uVar7);
            uVar7 = (**(code **)(*(int *)*puVar5 + 0x18))();
            FUN_0147c720(&iStack_5c,0,iStack_34,iStack_30,uVar7);
            uStack_8._0_1_ = 0xb;
            FUN_0147c770();
            uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
            if (iStack_44 != 0) {
              iVar4 = (**(code **)(*(int *)*puVar5 + 0x20))();
              if (iVar4 != 0) {
                uVar7 = (**(code **)(*(int *)*puVar5 + 0x20))();
                puVar5 = (undefined4 *)FUN_0147c720(&iStack_44,0,iStack_20,iStack_38,uVar7);
                piVar10 = piStack_cc;
                uStack_d0 = *puVar5;
                piVar11 = (int *)puVar5[1];
                *puVar5 = 0;
                puVar5[1] = 0;
                if (piStack_cc != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_cc[1] + -1;
                  piStack_cc[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    puVar1 = (undefined4 *)*piStack_cc;
                    piStack_cc = piVar11;
                    (*(code *)*puVar1)();
                    LOCK();
                    piVar11 = piVar10 + 2;
                    iVar4 = *piVar11 + -1;
                    *piVar11 = iVar4;
                    UNLOCK();
                    piVar11 = piStack_cc;
                    if (iVar4 == 0) {
                      (**(code **)(*piVar10 + 4))();
                      piVar11 = piStack_cc;
                    }
                  }
                }
                piStack_cc = piVar11;
                piVar11 = piStack_124;
                uStack_c8 = puVar5[2];
                uStack_c4 = puVar5[3];
                uStack_c0 = puVar5[4];
                uStack_bc = puVar5[5];
                if (piStack_124 != (int *)0x0) {
                  LOCK();
                  iVar4 = piStack_124[1] + -1;
                  piStack_124[1] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)*piStack_124)();
                    LOCK();
                    piVar10 = piVar11 + 2;
                    iVar4 = *piVar10 + -1;
                    *piVar10 = iVar4;
                    UNLOCK();
                    if (iVar4 == 0) {
                      (**(code **)(*piVar11 + 4))();
                    }
                  }
                }
              }
            }
            iVar4 = *(int *)(iStack_18 + 8);
            if (iVar4 == 0) {
              iVar8 = (**(code **)(*param_2 + 0x1c))();
              if (iVar8 != 0) {
                iVar4 = 3;
              }
            }
            if (*(int *)(iStack_18 + 8) == 9) {
              iVar8 = (**(code **)(*param_2 + 0x1c))();
              if (iVar8 != 0) {
                iVar4 = 10;
              }
            }
            iStack_2c = DAT_018f998c;
            if (*(char *)(iStack_18 + 0x14) == '\0') {
              iStack_2c = 0;
            }
            piVar11 = (int *)FUN_01674e20(0x74);
            uStack_8._0_1_ = 0xd;
            piStack_98 = piVar11;
            if (piVar11 == (int *)0x0) {
              piVar11 = (int *)0x0;
              puVar5 = puStack_48;
            }
            else {
              FUN_00841220(param_2,auStack_110,&uStack_d0,iStack_18,iVar4,0xff,
                           *(undefined4 *)(iStack_18 + 0x10));
              puVar5 = puStack_48;
              uStack_8._0_1_ = 0xe;
              *piVar11 = (int)RBX::Graphics::FastClusterEntity_DEPRECATED::vftable;
              FUN_00650440(puStack_48 + 4);
              iVar4 = DAT_018c45d0;
              piVar11[0x16] = 0x7f7fffff;
              piVar11[0x17] = 0x7f7fffff;
              piVar11[0x18] = 0x7f7fffff;
              piVar11[0x19] = iVar4;
              piVar11[0x1a] = iVar4;
              piVar11[0x1b] = iVar4;
              piVar11[0x1c] = iStack_2c;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
            FUN_00841620(piVar11);
            iVar4 = (**(code **)(*(int *)*puVar5 + 0x14))();
            iStack_30 = iStack_30 + iVar4;
            iVar4 = (**(code **)(*(int *)*puVar5 + 0x18))();
            iStack_34 = iStack_34 + iVar4;
            iVar4 = (**(code **)(*(int *)*puVar5 + 0x1c))();
            iStack_38 = iStack_38 + iVar4;
            iVar4 = (**(code **)(*(int *)*puVar5 + 0x20))();
            piVar11 = piStack_cc;
            iStack_20 = iStack_20 + iVar4;
            if (piStack_cc != (int *)0x0) {
              LOCK();
              iVar4 = piStack_cc[1] + -1;
              piStack_cc[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_cc)();
                LOCK();
                piVar10 = piVar11 + 2;
                iVar4 = *piVar10 + -1;
                *piVar10 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar11 + 4))();
                }
              }
            }
            piVar11 = piStack_10c;
            uStack_8._0_1_ = 10;
            if (piStack_10c != (int *)0x0) {
              LOCK();
              iVar4 = piStack_10c[1] + -1;
              piStack_10c[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_10c)();
                LOCK();
                piVar10 = piVar11 + 2;
                iVar4 = *piVar10 + -1;
                *piVar10 = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)(*piVar11 + 4))();
                }
              }
            }
            uStack_78 = uStack_78 + 1;
            piVar11 = piStack_14;
          } while (uStack_78 < uStack_3c);
        }
        uStack_ac = CONCAT44(uStack_ac._4_4_,(undefined4)uStack_ac);
        if ((iStack_4c != 0) &&
           (uStack_ac = CONCAT44(uStack_ac._4_4_,(undefined4)uStack_ac), iStack_1c != 0)) {
          if (*(int *)(iStack_50 + 0x34) < DAT_01ece210) {
            FUN_016f3809(&DAT_01ece210);
            if (DAT_01ece210 == -1) {
              uStack_8._0_1_ = 0xf;
              uVar12 = FUN_0152dab0("Render","upload",0xffffffff);
              DAT_01ece20c = (undefined4)((ulonglong)uVar12 >> 0x20);
              DAT_01ece208 = (undefined4)uVar12;
              uStack_8._0_1_ = 10;
              FUN_016f37bf(&DAT_01ece210);
            }
          }
          uVar2 = DAT_01ece20c;
          uVar7 = DAT_01ece208;
          uStack_b4 = DAT_01ece208;
          uStack_b0 = DAT_01ece20c;
          uStack_ac = FUN_0152d930(DAT_01ece208,DAT_01ece20c);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
          (**(code **)(*piStack_88 + 0x14))();
          (**(code **)(*piStack_80 + 0x14))();
          if (piStack_6c != (int *)0x0) {
            (**(code **)(*piStack_6c + 0x14))();
          }
          if (piStack_64 != (int *)0x0) {
            (**(code **)(*piStack_64 + 0x14))();
          }
          uStack_8._0_1_ = 0x11;
          FUN_0152dda0(uVar7,uVar2,uStack_ac);
        }
        piVar11 = piStack_40;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_40[1] + -1;
          piStack_40[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_40)();
            LOCK();
            piVar10 = piVar11 + 2;
            iVar4 = *piVar10 + -1;
            *piVar10 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
        piVar11 = piStack_58;
        iVar4 = iStack_24;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_58[1] + -1;
          piStack_58[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            piVar10 = piVar11 + 2;
            iVar8 = *piVar10 + -1;
            *piVar10 = iVar8;
            UNLOCK();
            iVar4 = iStack_24;
            if (iVar8 == 0) {
              (**(code **)(*piVar11 + 4))();
              iVar4 = iStack_24;
            }
          }
        }
      }
      piVar11 = piStack_60;
      if (piStack_60 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_60[1] + -1;
        piStack_60[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_60)();
          LOCK();
          piVar10 = piVar11 + 2;
          iVar8 = *piVar10 + -1;
          *piVar10 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = piStack_7c;
      if (piStack_7c != (int *)0x0) {
        LOCK();
        iVar8 = piStack_7c[1] + -1;
        piStack_7c[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_7c)();
          LOCK();
          piVar10 = piVar11 + 2;
          iVar8 = *piVar10 + -1;
          *piVar10 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = piStack_68;
      if (piStack_68 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_68[1] + -1;
        piStack_68[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_68)();
          LOCK();
          piVar10 = piVar11 + 2;
          iVar8 = *piVar10 + -1;
          *piVar10 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = piStack_84;
      if (piStack_84 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_84[1] + -1;
        piStack_84[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_84)();
          LOCK();
          piVar10 = piVar11 + 2;
          iVar8 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar8 == 1) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      goto LAB_0086ad2b;
    }
  }
  iVar4 = 0;
LAB_0086ad2b:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_28 != 0) {
    uVar9 = ((int)piStack_54 - iStack_28 >> 3) * 8;
    iVar8 = iStack_28;
    if (0xfff < uVar9) {
      iVar8 = *(int *)(iStack_28 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iStack_28 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar9);
  }
  uStack_8 = 0x12;
  FUN_0152dda0(uStack_b8,uStack_a4,uStack_d8);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 13274 ; VA 0x0086af80 ; FUN_0086af80 */

void __fastcall FUN_0086af80(int param_1)

{
  undefined4 uVar1;
  
  if ((*(char *)(param_1 + 0x51) != '\0') && (*(int *)(param_1 + 0x48) != 0)) {
    uVar1 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
    FUN_007c8b40(param_1,uVar1);
  }
  return;
}



/* FUNCTION 13275 ; VA 0x0086afc0 ; FUN_0086afc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * __thiscall
FUN_0086afc0(undefined4 *param_1,undefined8 *param_2,int param_3,int param_4,float param_5,
            float param_6,float param_7,float param_8,undefined4 param_9,int param_10)

{
  float fVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  float *pfVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  undefined auStack_194 [48];
  undefined auStack_164 [84];
  float fStack_110;
  float fStack_104;
  float fStack_f8;
  float fStack_ec;
  float fStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  float fStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  float fStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  float fStack_b0;
  undefined auStack_ac [12];
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  ulonglong uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  float fStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  float fStack_34;
  undefined8 uStack_30;
  float fStack_28;
  float fStack_24;
  int *piStack_20;
  uint uStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b895c;
  pvStack_10 = ExceptionList;
  iStack_48 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  puStack_40 = param_1;
  if ((*(int *)(iStack_48 + 0x34) < DAT_01ece328) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ece328), DAT_01ece328 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("Render","generateBatchGeometry",0xffffffff);
    DAT_01ece324 = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01ece320 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ece328);
  }
  uStack_60 = DAT_01ece320;
  uStack_5c = DAT_01ece324;
  uStack_80 = DAT_01ece320;
  uStack_7c = DAT_01ece324;
  uStack_78 = FUN_0152d930(DAT_01ece320,DAT_01ece324);
  uStack_8 = 1;
  FUN_00746d50(&piStack_20,param_5,param_6,param_7,param_8,param_9,param_10);
  piVar2 = piStack_20;
  piStack_58 = param_1 + 1;
  if (*piStack_58 == 0) {
    piStack_58 = (int *)0x0;
  }
  uStack_1c = 0;
  param_6 = DAT_018c45c4;
  param_7 = DAT_018c45c4;
  iVar8 = *(int *)(param_4 + 4);
  iVar7 = *(int *)(param_4 + 8) - iVar8;
  fStack_34 = DAT_018c45c4;
  fStack_14 = DAT_018c45c4;
  uStack_3c = CONCAT44(DAT_018c45c4,DAT_018c45c4);
  fStack_18 = DAT_018c45d0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = iVar7 >> 0x1f;
  param_5 = DAT_018c45d0;
  uStack_30 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
  fStack_44 = DAT_018c45d0;
  fStack_28 = DAT_018c45d0;
  if (iVar7 / 0x2c + iVar4 != iVar4) {
    uStack_70 = uStack_3c;
    param_10 = 0;
    uStack_68 = uStack_30;
    do {
      iStack_50 = *(int *)(param_10 + 8 + iVar8);
      iVar4 = puStack_40[0x3c];
      iVar7 = *(int *)(*(int *)(param_4 + 0x10) + iStack_50 * 4);
      uStack_54 = *(undefined4 *)(param_3 + 0xc);
      fStack_24 = *(float *)(iVar4 + iVar7 * 0x1c);
      iStack_4c = iVar4;
      if (*(float *)(param_10 + iVar8) == fStack_24) {
        if (*(int *)(iStack_48 + 0x34) < DAT_01ece318) {
          FUN_016f3809(&DAT_01ece318);
          if (DAT_01ece318 == -1) {
            _DAT_01ece2e8 = _DAT_018e3fb0;
            uRam01ece2ec = _UNK_018e3fb4;
            uRam01ece2f0 = _UNK_018e3fb8;
            fRam01ece2f4 = _UNK_018e3fbc;
            _DAT_01ece2f8 = _DAT_018e3fb0;
            uRam01ece2fc = _UNK_018e3fb4;
            uRam01ece300 = _UNK_018e3fb8;
            fRam01ece304 = _UNK_018e3fbc;
            _DAT_01ece308 = _DAT_018e3fb0;
            uRam01ece30c = _UNK_018e3fb4;
            uRam01ece310 = _UNK_018e3fb8;
            fRam01ece314 = _UNK_018e3fbc;
            FUN_016f37bf(&DAT_01ece318);
          }
        }
        uStack_dc = _DAT_01ece2e8;
        uStack_d8 = uRam01ece2ec;
        uStack_d4 = uRam01ece2f0;
        fStack_d0 = fRam01ece2f4;
        uStack_cc = _DAT_01ece2f8;
        uStack_c8 = uRam01ece2fc;
        uStack_c4 = uRam01ece300;
        fStack_c0 = fRam01ece304;
        uStack_bc = _DAT_01ece308;
        uVar9 = uRam01ece30c;
        uVar10 = uRam01ece310;
        fStack_b0 = fRam01ece314;
LAB_0086b2aa:
        uStack_b8 = CONCAT44(uVar10,uVar9);
      }
      else {
        if (fStack_24 == 0.0) {
          puVar6 = (undefined4 *)FUN_00b077e0();
          uStack_dc = *puVar6;
          uStack_d8 = puVar6[1];
          uStack_d4 = puVar6[2];
          fStack_d0 = (float)puVar6[3];
          uStack_cc = puVar6[4];
          uStack_c8 = puVar6[5];
          uStack_c4 = puVar6[6];
          fStack_c0 = (float)puVar6[7];
          uStack_bc = puVar6[8];
          uVar9 = puVar6[9];
          uVar10 = puVar6[10];
          fStack_b0 = (float)puVar6[0xb];
          goto LAB_0086b2aa;
        }
        iVar4 = FUN_00b077e0();
        FUN_00b077e0();
        pfVar5 = (float *)FUN_0071fcc0(auStack_194);
        fVar11 = *(float *)(iVar4 + 0x28);
        fVar12 = *(float *)(iVar4 + 0x24);
        fVar1 = *(float *)(iVar4 + 0x2c);
        fStack_e0 = pfVar5[6] * fVar12 + pfVar5[7] * fVar11 + pfVar5[8] * fVar1 + pfVar5[0xb];
        fStack_24 = pfVar5[3] * fVar12 + pfVar5[4] * fVar11 + pfVar5[5] * fVar1 + pfVar5[10];
        uStack_88 = (ulonglong)
                    (uint)(pfVar5[1] * fVar11 + fVar12 * *pfVar5 + pfVar5[2] * fVar1 + pfVar5[9]);
        puVar6 = (undefined4 *)FUN_01160c20(auStack_ac,iVar4);
        uStack_dc = *puVar6;
        uStack_d8 = puVar6[1];
        uStack_d4 = puVar6[2];
        fStack_d0 = (float)puVar6[3];
        uStack_cc = puVar6[4];
        uStack_c8 = puVar6[5];
        uStack_c4 = puVar6[6];
        fStack_c0 = (float)puVar6[7];
        uStack_bc = puVar6[8];
        uStack_b8 = CONCAT44(fStack_24,(int)uStack_88);
        fStack_b0 = fStack_e0;
        iVar4 = iStack_4c;
      }
      FUN_0073dae0(*puStack_40,*(undefined4 *)(param_10 + iVar8),
                   *(undefined4 *)(param_10 + 4 + iVar8),&uStack_dc,uStack_54,iVar8 + 0xc + param_10
                   ,iStack_50,0xffffffff,6);
      (**(code **)(*piVar2 + 4))();
      (**(code **)(*piVar2 + 8))
                (*(undefined4 *)(param_10 + iVar8),*(undefined4 *)(param_10 + 4 + iVar8),0,
                 auStack_164,param_10 + 0x1c + iVar8,piStack_58);
      cVar3 = (**(code **)(*piVar2 + 0x24))();
      if (cVar3 != '\0') {
        (**(code **)(*piVar2 + 0x28))(&fStack_a0);
        fStack_ec = *(float *)(iVar4 + 0xc + iVar7 * 0x1c);
        if (fStack_98 <= fStack_ec) {
          fStack_ec = fStack_98;
        }
        fVar11 = *(float *)(iVar4 + 8 + iVar7 * 0x1c);
        if (fStack_9c <= fVar11) {
          fVar11 = fStack_9c;
        }
        fVar12 = *(float *)(iVar4 + 4 + iVar7 * 0x1c);
        if (fStack_a0 <= fVar12) {
          fVar12 = fStack_a0;
        }
        *(ulonglong *)(iVar4 + 4 + iVar7 * 0x1c) = CONCAT44(fVar11,fVar12);
        *(float *)(iVar4 + 0xc + iVar7 * 0x1c) = fStack_ec;
        param_8 = *(float *)(iVar4 + 0x18 + iVar7 * 0x1c);
        if (param_8 <= fStack_8c) {
          param_8 = fStack_8c;
        }
        fVar11 = *(float *)(iVar4 + 0x14 + iVar7 * 0x1c);
        if (fVar11 <= fStack_90) {
          fVar11 = fStack_90;
        }
        fVar12 = *(float *)(iVar4 + 0x10 + iVar7 * 0x1c);
        if (fVar12 <= fStack_94) {
          fVar12 = fStack_94;
        }
        fStack_f8 = param_8;
        *(ulonglong *)(iVar4 + 0x10 + iVar7 * 0x1c) = CONCAT44(fVar11,fVar12);
        *(float *)(iVar4 + 0x18 + iVar7 * 0x1c) = param_8;
        fStack_104 = fStack_98;
        if (param_7 < fStack_98) {
          fStack_104 = param_7;
        }
        fVar11 = fStack_9c;
        if (param_6 < fStack_9c) {
          fVar11 = param_6;
        }
        if (fStack_a0 <= fStack_14) {
          fStack_14 = fStack_a0;
        }
        uStack_70 = CONCAT44(fVar11,fStack_14);
        if (fStack_44 <= fStack_8c) {
          fStack_44 = fStack_8c;
        }
        fVar12 = fStack_90;
        if (fStack_90 < param_5) {
          fVar12 = param_5;
        }
        if (fStack_18 <= fStack_94) {
          fStack_18 = fStack_94;
        }
        uStack_68 = CONCAT44(fVar12,fStack_18);
        param_5 = fVar12;
        param_6 = fVar11;
        param_7 = fStack_104;
        fStack_110 = fStack_44;
        uStack_3c = uStack_70;
        fStack_34 = fStack_104;
        uStack_30 = uStack_68;
        fStack_28 = fStack_44;
      }
      uStack_1c = uStack_1c + 1;
      param_10 = param_10 + 0x2c;
      iVar8 = *(int *)(param_4 + 4);
    } while (uStack_1c < (uint)((*(int *)(param_4 + 8) - iVar8) / 0x2c));
    if (fStack_14 <= fStack_18) {
      *(undefined8 *)((int)param_2 + 0xc) = uStack_68;
      *param_2 = uStack_70;
      *(float *)((int)param_2 + 0x14) = fStack_28;
      *(float *)(param_2 + 1) = fStack_34;
      goto LAB_0086b569;
    }
  }
  *(undefined4 *)param_2 = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 4) = 0x7f7fffff;
  *(undefined4 *)(param_2 + 1) = 0x7f7fffff;
  *(undefined4 *)((int)param_2 + 0xc) = 0xff7fffff;
  *(undefined4 *)(param_2 + 2) = 0xff7fffff;
  *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
LAB_0086b569:
  if (piStack_20 != (int *)0x0) {
    (**(code **)*piStack_20)(1);
  }
  uStack_8 = 3;
  FUN_0152dda0(uStack_60,uStack_5c,uStack_78);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13276 ; VA 0x0086b650 ; FUN_0086b650 */

undefined4 * __thiscall FUN_0086b650(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  undefined4 *puStack_8;
  
  iStack_c = param_1;
  FUN_00843670(*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 3,param_2);
  iVar7 = 0;
  puVar6 = (undefined4 *)(*(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 3);
  puStack_8 = puVar6;
  if (0 < (int)puVar6) {
    do {
      puVar6 = (undefined4 *)
               FUN_0060dcd0(auStack_14,*(undefined4 *)(*(int *)(param_1 + 0xa0) + iVar7 * 8));
      uVar3 = puVar6[1];
      uVar4 = *puVar6;
      puVar8 = (undefined4 *)(*param_2 + iVar7 * 8);
      *puVar6 = 0;
      puVar6[1] = 0;
      *puVar8 = uVar4;
      piVar5 = (int *)puVar8[1];
      puVar8[1] = uVar3;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar2 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1;
          puVar6 = (undefined4 *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_10;
      if (piStack_10 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_10 + 1;
        iVar2 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_10)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1;
          puVar6 = (undefined4 *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puVar6 = (undefined4 *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      iVar7 = iVar7 + 1;
      param_1 = iStack_c;
    } while (iVar7 < (int)puStack_8);
  }
  return puVar6;
}



/* FUNCTION 13277 ; VA 0x0086b740 ; FUN_0086b740 */

undefined4 __fastcall FUN_0086b740(int param_1)

{
  return *(undefined4 *)(param_1 + 0xb8);
}



/* FUNCTION 13278 ; VA 0x0086b750 ; FUN_0086b750 */

int __fastcall FUN_0086b750(int param_1)

{
  return *(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c) >> 3;
}



/* FUNCTION 13279 ; VA 0x0086b760 ; FUN_0086b760 */

void __fastcall FUN_0086b760(int param_1)

{
  (**(code **)(**(int **)(param_1 + 0xbc) + 4))(*(undefined *)(param_1 + 0xc0));
  return;
}



/* FUNCTION 13280 ; VA 0x0086b780 ; FUN_0086b780 */

int __fastcall FUN_0086b780(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 8) + 0x524);
  if (*(int *)(param_1 + 0xb8) != 0) {
    return iVar1 + 0x70;
  }
  if (*(char *)(param_1 + 0xc0) != '\0') {
    return iVar1 + 0x68;
  }
  return iVar1 + 0x60;
}



/* FUNCTION 13281 ; VA 0x0086b7b0 ; FUN_0086b7b0 */

void __thiscall FUN_0086b7b0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar2 = **(int **)(param_1 + 0x4c) * 0x58;
  iVar1 = *(int *)(*(int *)(param_1 + 4) + 0x94);
  fVar3 = (*(float *)(param_1 + 0x5c) + *(float *)(param_1 + 0x68)) * DAT_018ce2f4;
  fVar5 = (*(float *)(param_1 + 0x58) + *(float *)(param_1 + 100)) * DAT_018ce2f4;
  fVar4 = (*(float *)(param_1 + 0x60) + *(float *)(param_1 + 0x6c)) * DAT_018ce2f4;
  fStack_8 = *(float *)(iVar2 + 0x3c + iVar1) * fVar3 + *(float *)(iVar2 + 0x38 + iVar1) * fVar5 +
             *(float *)(iVar2 + 0x40 + iVar1) * fVar4 + *(float *)(iVar2 + 0x4c + iVar1);
  fStack_c = *(float *)(iVar2 + 0x30 + iVar1) * fVar3 + *(float *)(iVar2 + 0x2c + iVar1) * fVar5 +
             *(float *)(iVar2 + 0x34 + iVar1) * fVar4 + *(float *)(iVar2 + 0x48 + iVar1);
  fStack_10 = *(float *)(iVar2 + 0x24 + iVar1) * fVar3 + fVar5 * *(float *)(iVar2 + 0x20 + iVar1) +
              *(float *)(iVar2 + 0x28 + iVar1) * fVar4 + *(float *)(iVar2 + 0x44 + iVar1);
  FUN_00841650(param_2,&fStack_10,*(undefined4 *)(param_1 + 0x70));
  return;
}



/* FUNCTION 13282 ; VA 0x0086b8b0 ; FUN_0086b8b0 */

void __fastcall FUN_0086b8b0(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: invalidateEntity",param_1 + -0x74);
  }
  if (*(char *)(param_1 + 0x4d) == '\0') {
    *(undefined *)(param_1 + 0x4d) = 1;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8c80(param_1);
  }
  return;
}



/* FUNCTION 13283 ; VA 0x0086b900 ; FUN_0086b900 */

undefined __fastcall FUN_0086b900(int param_1)

{
  return *(undefined *)(param_1 + 0xc0);
}



/* FUNCTION 13284 ; VA 0x0086b910 ; FUN_0086b910 */

undefined __fastcall FUN_0086b910(int param_1)

{
  return *(undefined *)(param_1 + 0xc3);
}



/* FUNCTION 13285 ; VA 0x0086b920 ; FUN_0086b920 */

void __fastcall FUN_0086b920(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p with binding %p requests castShadow change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13286 ; VA 0x0086b925 ; FUN_0086b925 */

void __fastcall FUN_0086b925(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests castShadow change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13287 ; VA 0x0086b960 ; FUN_0086b960 */

void __thiscall FUN_0086b960(int *param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0x13) == '\0') {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p requests clump change",param_1 + -0x1d,
                   param_2,0);
    }
    (**(code **)(*param_1 + 8))();
  }
  return;
}



/* FUNCTION 13288 ; VA 0x0086b9a0 ; FUN_0086b9a0 */

void __fastcall FUN_0086b9a0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  
  cVar1 = (**(code **)(**(int **)(param_1 + 0x18) + 0x20))();
  if (cVar1 != '\0') {
    if (DAT_01eb4564 != '\0') {
      FUN_01677490(DAT_01eb4564,
                   "FastCluster[%p]: part %p with binding %p requests coordinate frame change",
                   *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
    }
    (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
    piVar3 = *(int **)(param_1 + 0x18);
    if (piVar3[0x2f] != 0) {
      uVar2 = (**(code **)(*piVar3 + 0x20))();
      FUN_007c8b40(piVar3 + 0x1d,uVar2);
      piVar3 = *(int **)(param_1 + 0x18);
    }
    *(undefined *)((int)piVar3 + 0xc2) = 1;
  }
  return;
}



/* FUNCTION 13289 ; VA 0x0086ba20 ; FUN_0086ba20 */

void __fastcall FUN_0086ba20(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: part %p with binding %p requests size change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1[0x2f] != 0) {
    uVar2 = (**(code **)(*piVar1 + 0x20))();
    FUN_007c8b40(piVar1 + 0x1d,uVar2);
    *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
    return;
  }
  *(undefined *)((int)piVar1 + 0xc2) = 1;
  return;
}



/* FUNCTION 13290 ; VA 0x0086baa0 ; FUN_0086baa0 */

void __thiscall FUN_0086baa0(int param_1,char param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  
  if ((*(int *)(param_1 + 0x48) != 0) && (*(char *)(param_1 + 0x4c) != param_2)) {
    cVar1 = FUN_007c7420(param_3);
    if (cVar1 != *(char *)(param_1 + 0x4c)) {
      if (DAT_01eb4564 != '\0') {
        FUN_016773b0(DAT_01eb4564,"FastCluster[%p]: part %p, sleeping %d (fw %d -> %d)",
                     param_1 + -0x74,param_3,param_2,*(char *)(param_1 + 0x4c),cVar1);
      }
      if (*(int *)(param_1 + 0x48) != 0) {
        uVar2 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
        FUN_007c8b40(param_1,uVar2);
      }
    }
  }
  return;
}



/* FUNCTION 13291 ; VA 0x0086bb20 ; FUN_0086bb20 */

void __fastcall FUN_0086bb20(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,
                 "FastCluster[%p]: part %p with binding %p requests special shape change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13292 ; VA 0x0086bb25 ; FUN_0086bb25 */

void __fastcall FUN_0086bb25(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests special shape change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13293 ; VA 0x0086bb60 ; FUN_0086bb60 */

void __fastcall FUN_0086bb60(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,
                 "FastCluster[%p]: part %p with binding %p requests transparency change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13294 ; VA 0x0086bb65 ; FUN_0086bb65 */

void __fastcall FUN_0086bb65(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_01677490(in_AL,"FastCluster[%p]: part %p with binding %p requests transparency change",
                 *(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 4),param_1);
  }
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xc2) = 1;
  return;
}



/* FUNCTION 13295 ; VA 0x0086bba0 ; FUN_0086bba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0086bba0(int param_1)

{
  undefined4 *puVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  float *pfVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  float10 fVar17;
  double dVar18;
  float fVar19;
  uint uVar20;
  undefined auStack_134 [12];
  undefined auStack_128 [24];
  undefined auStack_110 [32];
  undefined4 uStack_f0;
  undefined8 uStack_ec;
  float fStack_e4;
  float fStack_cc;
  float fStack_c0;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  undefined8 uStack_70;
  double dStack_60;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  uint uStack_4c;
  undefined8 uStack_48;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  int iStack_18;
  char cStack_11;
  
  uStack_38 = 0;
  iVar14 = *(int *)(param_1 + 0x20);
  iVar15 = *(int *)(param_1 + 0x24) - iVar14;
  fStack_80 = *(float *)(param_1 + -0x5c);
  fStack_7c = *(float *)(param_1 + -0x58);
  fStack_78 = *(float *)(param_1 + -0x54);
  fStack_74 = *(float *)(param_1 + -0x50);
  fStack_1c = -3.4028235e+38;
  uStack_70 = *(undefined8 *)(param_1 + -0x4c);
  iVar16 = iVar15 >> 0x1f;
  cStack_11 = '\0';
  fStack_30 = _DAT_018c4eb0;
  fStack_2c = _UNK_018c4eb4;
  fStack_28 = _UNK_018c4eb8;
  uStack_24 = CONCAT44(0xff7fffff,_UNK_018c4ebc);
  iStack_34 = param_1;
  if (iVar15 / 0x58 + iVar16 != iVar16) {
    iStack_3c = 0;
    iStack_18 = 0;
    do {
      if (*(int *)(iStack_18 + iVar14) != 0) {
        puStack_50 = (undefined4 *)(*(int *)(param_1 + 0x38) + iStack_3c);
        iVar16 = iStack_18 + 0x20 + iVar14;
        uStack_48 = (double)CONCAT44(iVar16,(undefined4)uStack_48);
        cVar10 = FUN_00c93230(iVar16,puStack_50,0x3727c5ac,0x3727c5ac);
        if (cVar10 == '\0') {
          uVar11 = FUN_0071fcc0(auStack_110);
          FUN_0071f260(&fStack_b0,uVar11);
          uStack_4c = *(uint *)(iStack_18 + 0x50 + iVar14);
          if (uStack_4c < *(int *)(iStack_18 + 0x54 + iVar14) + uStack_4c) {
            iVar16 = uStack_4c * 0x3c;
            do {
              iVar15 = *(int *)(iStack_34 + 0x54) + 0xc + iVar16;
              fVar19 = *(float *)(iVar15 + 0x28);
              fVar2 = *(float *)(iVar15 + 0x24);
              fVar3 = *(float *)(iVar15 + 0x2c);
              dStack_60 = (double)(ulonglong)
                                  (uint)(fStack_b0 * fVar2 + fStack_ac * fVar19 + fStack_a8 * fVar3
                                        + fStack_8c);
              uStack_58 = (double)CONCAT44(fStack_a4 * fVar2 + fStack_a0 * fVar19 +
                                           fStack_9c * fVar3 + fStack_88,(undefined4)uStack_58);
              fStack_b4 = fStack_98 * fVar2 + fStack_94 * fVar19 + fStack_90 * fVar3 + fStack_84;
              puVar12 = (undefined4 *)FUN_01160c20(auStack_134,iVar15);
              uVar11 = puVar12[1];
              uVar4 = puVar12[2];
              uVar5 = puVar12[3];
              uVar6 = puVar12[4];
              uVar7 = puVar12[5];
              uVar8 = puVar12[6];
              uVar9 = puVar12[7];
              uStack_f0 = puVar12[8];
              uStack_4c = uStack_4c + 1;
              fStack_e4 = fStack_b4;
              uStack_ec = CONCAT44(uStack_58._4_4_,SUB84(dStack_60,0));
              iVar15 = *(int *)(iStack_34 + 0x54);
              puVar1 = (undefined4 *)(iVar16 + 0xc + iVar15);
              *puVar1 = *puVar12;
              puVar1[1] = uVar11;
              puVar1[2] = uVar4;
              puVar1[3] = uVar5;
              puVar1 = (undefined4 *)(iVar16 + 0x1c + iVar15);
              *puVar1 = uVar6;
              puVar1[1] = uVar7;
              puVar1[2] = uVar8;
              puVar1[3] = uVar9;
              puVar1 = (undefined4 *)(iVar16 + 0x2c + iVar15);
              *puVar1 = uStack_f0;
              puVar1[1] = SUB84(dStack_60,0);
              puVar1[2] = uStack_58._4_4_;
              puVar1[3] = fStack_b4;
              iVar16 = iVar16 + 0x3c;
              param_1 = iStack_34;
            } while (uStack_4c <
                     (uint)(*(int *)(iStack_18 + 0x54 + iVar14) +
                           *(int *)(iStack_18 + 0x50 + iVar14)));
          }
          cStack_11 = '\x01';
        }
        uVar11 = puStack_50[1];
        uVar4 = puStack_50[2];
        uVar5 = puStack_50[3];
        *uStack_48._4_4_ = *puStack_50;
        uStack_48._4_4_[1] = uVar11;
        uStack_48._4_4_[2] = uVar4;
        uStack_48._4_4_[3] = uVar5;
        uVar11 = puStack_50[5];
        uVar4 = puStack_50[6];
        uVar5 = puStack_50[7];
        uStack_48._4_4_[4] = puStack_50[4];
        uStack_48._4_4_[5] = uVar11;
        uStack_48._4_4_[6] = uVar4;
        uStack_48._4_4_[7] = uVar5;
        uVar11 = puStack_50[9];
        uVar4 = puStack_50[10];
        uVar5 = puStack_50[0xb];
        uStack_48._4_4_[8] = puStack_50[8];
        uStack_48._4_4_[9] = uVar11;
        uStack_48._4_4_[10] = uVar4;
        uStack_48._4_4_[0xb] = uVar5;
      }
      pfVar13 = (float *)FUN_00c9f550(auStack_128,iVar14 + 0x20 + iStack_18);
      fStack_c0 = fStack_28;
      if (pfVar13[2] <= fStack_28) {
        fStack_c0 = pfVar13[2];
      }
      if (pfVar13[1] <= fStack_2c) {
        fStack_2c = pfVar13[1];
      }
      if (*pfVar13 <= fStack_30) {
        fStack_30 = *pfVar13;
      }
      fStack_cc = fStack_1c;
      if (fStack_1c <= pfVar13[5]) {
        fStack_cc = pfVar13[5];
      }
      fVar19 = uStack_24._4_4_;
      if (uStack_24._4_4_ <= pfVar13[4]) {
        fVar19 = pfVar13[4];
      }
      if ((float)uStack_24 <= pfVar13[3]) {
        uStack_24._0_4_ = pfVar13[3];
      }
      iVar14 = *(int *)(param_1 + 0x20);
      uStack_38 = uStack_38 + 1;
      iStack_18 = iStack_18 + 0x58;
      iStack_3c = iStack_3c + 0x30;
      uStack_24 = CONCAT44(fVar19,(float)uStack_24);
      fStack_28 = fStack_c0;
      fStack_1c = fStack_cc;
    } while (uStack_38 < (uint)((*(int *)(param_1 + 0x24) - iVar14) / 0x58));
  }
  if (*(char *)(param_1 + 0x50) != '\0') {
    if (cStack_11 == '\0') {
      return;
    }
    FUN_00819480(0);
    goto LAB_0086c06f;
  }
  uVar11 = *(undefined4 *)(*(int *)(*(int *)(param_1 + -0x6c) + 0x4e4) + 0x24);
  dVar18 = (double)((fStack_7c - fStack_2c) * (fStack_7c - fStack_2c) +
                    (fStack_80 - fStack_30) * (fStack_80 - fStack_30) +
                   (fStack_78 - fStack_28) * (fStack_78 - fStack_28));
  if (NAN(dVar18) == (dVar18 == 0.0)) {
    uVar20 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    dStack_60 = (double)CONCAT44((uint)((ulonglong)dVar18 >> 0x20) & uVar20,
                                 SUB84(dVar18,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
    uStack_48 = (double)CONCAT44((uint)((ulonglong)(dVar18 - 0.0) >> 0x20) & uVar20,
                                 SUB84(dVar18 - 0.0,0) & (uint)DAT_018c0da0);
    fVar17 = (float10)FUN_01160810();
    uStack_58 = (double)fVar17;
    dVar18 = DAT_018f76b0;
    if ((NAN(dStack_60) || NAN(uStack_58)) == (dStack_60 == uStack_58)) {
      dVar18 = dStack_60 * DAT_018f76b0;
    }
    if (uStack_48 <= dVar18) goto LAB_0086bfc8;
  }
  else {
LAB_0086bfc8:
    dVar18 = (double)(((float)uStack_70 - uStack_24._4_4_) * ((float)uStack_70 - uStack_24._4_4_) +
                      (fStack_74 - (float)uStack_24) * (fStack_74 - (float)uStack_24) +
                     (uStack_70._4_4_ - fStack_1c) * (uStack_70._4_4_ - fStack_1c));
    if (NAN(dVar18) == (dVar18 == 0.0)) {
      uVar20 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
      dStack_60 = (double)CONCAT44((uint)((ulonglong)dVar18 >> 0x20) & uVar20,
                                   SUB84(dVar18,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      uStack_48 = (double)CONCAT44((uint)((ulonglong)(dVar18 - 0.0) >> 0x20) & uVar20,
                                   SUB84(dVar18 - 0.0,0) & (uint)DAT_018c0da0);
      fVar17 = (float10)FUN_01160810();
      uStack_58 = (double)fVar17;
      dVar18 = DAT_018f76b0;
      if ((NAN(dStack_60) || NAN(uStack_58)) == (dStack_60 == uStack_58)) {
        dVar18 = dStack_60 * DAT_018f76b0;
      }
      if (dVar18 < uStack_48) goto LAB_0086c062;
    }
    if ((cStack_11 == '\0') && (*(char *)(param_1 + 0x4e) == '\0')) {
      uVar11 = *(undefined4 *)(param_1 + -0x70);
    }
  }
LAB_0086c062:
  FUN_008411b0(&fStack_30,uVar11);
LAB_0086c06f:
  if (cStack_11 != '\0') {
    iVar14 = *(int *)(param_1 + 0x44);
    if ((((iVar14 == 0) && (*(char *)(param_1 + 0x50) == '\0')) && (fStack_80 <= fStack_74)) &&
       ((fStack_7c <= (float)uStack_70 && (fStack_78 <= uStack_70._4_4_)))) {
      FUN_007c7690(&fStack_80,*(undefined *)(param_1 + 0x4c));
      iVar14 = *(int *)(param_1 + 0x44);
    }
    if (((iVar14 == 0) && (*(char *)(param_1 + 0x50) == '\0')) &&
       ((fStack_30 <= (float)uStack_24 &&
        ((fStack_2c <= uStack_24._4_4_ && (fStack_28 <= fStack_1c)))))) {
      FUN_007c7690(&fStack_30,*(undefined *)(param_1 + 0x4c));
    }
  }
  return;
}



/* FUNCTION 13296 ; VA 0x0086c110 ; FUN_0086c110 */

void __fastcall FUN_0086c110(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  short *psVar14;
  undefined4 uVar15;
  int iVar16;
  int iVar17;
  undefined auStack_24 [8];
  short *psStack_1c;
  int *piStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  char cStack_5;
  
  cStack_5 = '\0';
  uStack_10 = 0;
  iVar17 = *(int *)(param_1 + 0x20);
  iVar16 = *(int *)(param_1 + 0x24) - iVar17;
  iVar1 = iVar16 >> 0x1f;
  if (iVar16 / 0x58 + iVar1 != iVar1) {
    iStack_c = 0;
    iStack_14 = 0;
    do {
      piStack_18 = (int *)(iStack_14 + iVar17);
      if (*piStack_18 != 0) {
        puVar12 = (undefined4 *)FUN_00c157b0();
        uVar15 = puVar12[1];
        uVar2 = puVar12[2];
        uVar3 = puVar12[3];
        uVar4 = puVar12[4];
        uVar5 = puVar12[5];
        uVar6 = puVar12[6];
        uVar7 = puVar12[7];
        uVar8 = puVar12[8];
        uVar9 = puVar12[9];
        uVar10 = puVar12[10];
        uVar11 = puVar12[0xb];
        puVar13 = (undefined4 *)(*(int *)(param_1 + 0x38) + iStack_c);
        *puVar13 = *puVar12;
        puVar13[1] = uVar15;
        puVar13[2] = uVar2;
        puVar13[3] = uVar3;
        puVar13[4] = uVar4;
        puVar13[5] = uVar5;
        puVar13[6] = uVar6;
        puVar13[7] = uVar7;
        puVar13[8] = uVar8;
        puVar13[9] = uVar9;
        puVar13[10] = uVar10;
        puVar13[0xb] = uVar11;
        if ((*(int **)(param_1 + 0x48) != (int *)0x0) && (cStack_5 == '\0')) {
          psStack_1c = (short *)(**(code **)(**(int **)(param_1 + 0x48) + 4))
                                          (*(undefined *)(param_1 + 0x4c));
          psVar14 = (short *)(**(code **)(**(int **)(param_1 + 0x48) + 8))
                                       (auStack_24,*piStack_18,*(undefined *)(param_1 + 0x4c));
          if ((*psVar14 != *psStack_1c) ||
             (((psVar14[1] != psStack_1c[1] || (psVar14[2] != psStack_1c[2])) ||
              (psVar14[3] != psStack_1c[3])))) {
            cStack_5 = '\x01';
          }
        }
      }
      iVar17 = *(int *)(param_1 + 0x20);
      uStack_10 = uStack_10 + 1;
      iStack_14 = iStack_14 + 0x58;
      iStack_c = iStack_c + 0x30;
    } while (uStack_10 < (uint)((*(int *)(param_1 + 0x24) - iVar17) / 0x58));
    if ((cStack_5 != '\0') && (*(int *)(param_1 + 0x48) != 0)) {
      uVar15 = (**(code **)(*(int *)(param_1 + -0x74) + 0x20))();
      FUN_007c8b40(param_1,uVar15);
    }
  }
  return;
}



/* FUNCTION 13297 ; VA 0x0086c250 ; FUN_0086c250 */

void __fastcall FUN_0086c250(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  short *psVar15;
  int iVar16;
  int iVar17;
  undefined auStack_24 [8];
  short *psStack_1c;
  int *piStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  char cStack_5;
  
  cStack_5 = '\0';
  uStack_10 = 0;
  iVar17 = *(int *)(param_1 + 0x20);
  iVar16 = *(int *)(param_1 + 0x24) - iVar17;
  iVar1 = iVar16 >> 0x1f;
  if (iVar16 / 0x58 + iVar1 != iVar1) {
    iStack_c = 0;
    iStack_14 = 0;
    do {
      piStack_18 = (int *)(iStack_14 + iVar17);
      if (*piStack_18 != 0) {
        puVar13 = (undefined4 *)FUN_00c157b0();
        uVar2 = puVar13[1];
        uVar3 = puVar13[2];
        uVar4 = puVar13[3];
        uVar5 = puVar13[4];
        uVar6 = puVar13[5];
        uVar7 = puVar13[6];
        uVar8 = puVar13[7];
        uVar9 = puVar13[8];
        uVar10 = puVar13[9];
        uVar11 = puVar13[10];
        uVar12 = puVar13[0xb];
        puVar14 = (undefined4 *)(*(int *)(param_1 + 0x38) + iStack_c);
        *puVar14 = *puVar13;
        puVar14[1] = uVar2;
        puVar14[2] = uVar3;
        puVar14[3] = uVar4;
        puVar14[4] = uVar5;
        puVar14[5] = uVar6;
        puVar14[6] = uVar7;
        puVar14[7] = uVar8;
        puVar14[8] = uVar9;
        puVar14[9] = uVar10;
        puVar14[10] = uVar11;
        puVar14[0xb] = uVar12;
        if ((*(int **)(param_1 + 0x48) != (int *)0x0) && (cStack_5 == '\0')) {
          psStack_1c = (short *)(**(code **)(**(int **)(param_1 + 0x48) + 4))
                                          (*(undefined *)(param_1 + 0x4c));
          psVar15 = (short *)(**(code **)(**(int **)(param_1 + 0x48) + 8))
                                       (auStack_24,*piStack_18,*(undefined *)(param_1 + 0x4c));
          if ((*psVar15 != *psStack_1c) ||
             (((psVar15[1] != psStack_1c[1] || (psVar15[2] != psStack_1c[2])) ||
              (psVar15[3] != psStack_1c[3])))) {
            cStack_5 = '\x01';
          }
        }
      }
      iVar17 = *(int *)(param_1 + 0x20);
      uStack_10 = uStack_10 + 1;
      iStack_14 = iStack_14 + 0x58;
      iStack_c = iStack_c + 0x30;
    } while (uStack_10 < (uint)((*(int *)(param_1 + 0x24) - iVar17) / 0x58));
  }
  *(char *)(param_1 + 0x51) = cStack_5;
  return;
}



/* FUNCTION 13298 ; VA 0x0086c360 ; FUN_0086c360 */

void __fastcall FUN_0086c360(int param_1)

{
  if (DAT_01eb4564 != '\0') {
    FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: priorityInvalidateEntity",param_1);
  }
  *(undefined *)(param_1 + 0xc1) = 1;
  FUN_007c8eb0(param_1 + 0x74);
  return;
}



/* FUNCTION 13299 ; VA 0x0086c365 ; FUN_0086c365 */

void __fastcall FUN_0086c365(int param_1)

{
  char in_AL;
  
  if (in_AL != '\0') {
    FUN_016774b0(in_AL,"FastCluster[%p]: priorityInvalidateEntity",param_1);
  }
  *(undefined *)(param_1 + 0xc1) = 1;
  FUN_007c8eb0(param_1 + 0x74);
  return;
}



/* FUNCTION 13300 ; VA 0x0086c3a0 ; FUN_0086c3a0 */

void FUN_0086c3a0(int *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  int extraout_ECX;
  int iVar4;
  int *piVar5;
  undefined *puVar6;
  undefined8 *puVar7;
  int unaff_EDI;
  undefined auStack_1818 [16];
  undefined8 auStack_1808 [764];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  int iStack_14;
  int iVar8;
  
  FUN_016f40d0();
  puStack_18 = (undefined *)extraout_ECX;
  cVar3 = (**(code **)(**(int **)(extraout_ECX + 4) + 0x20))();
  if (cVar3 == '\0') {
    piVar5 = *(int **)(extraout_ECX + 0x4c);
    iStack_14 = *(int *)(extraout_ECX + 0x50) - (int)piVar5 >> 2;
    puVar6 = (undefined *)extraout_ECX;
    if (iStack_14 != 0) {
      puVar7 = auStack_1808;
      iVar8 = iStack_14;
      do {
        iVar4 = *piVar5 * 0x58;
        piVar5 = piVar5 + 1;
        iVar8 = iVar8 + -1;
        iVar1 = *(int *)(unaff_EDI + 0x94);
        puVar7[-2] = *(undefined8 *)(iVar4 + 0x20 + iVar1);
        *(undefined4 *)(puVar7 + -1) = *(undefined4 *)(iVar4 + 0x28 + iVar1);
        *(undefined4 *)((int)puVar7 + -4) = *(undefined4 *)(iVar4 + 0x44 + iVar1);
        *puVar7 = *(undefined8 *)(iVar4 + 0x2c + iVar1);
        *(undefined4 *)(puVar7 + 1) = *(undefined4 *)(iVar4 + 0x34 + iVar1);
        *(undefined4 *)((int)puVar7 + 0xc) = *(undefined4 *)(iVar4 + 0x48 + iVar1);
        puVar7[2] = *(undefined8 *)(iVar4 + 0x38 + iVar1);
        *(undefined4 *)(puVar7 + 3) = *(undefined4 *)(iVar4 + 0x40 + iVar1);
        *(undefined4 *)((int)puVar7 + 0x1c) = *(undefined4 *)(iVar4 + 0x4c + iVar1);
        puVar6 = puStack_18;
        puVar7 = puVar7 + 6;
      } while (iVar8 != 0);
    }
    iStack_14 = iStack_14 * 0x30;
    puStack_18 = auStack_1818;
    uStack_1c = 1;
    uStack_20 = 0x86c46e;
    (**(code **)(*param_1 + 0x30))();
    param_4[2] = param_4[2] +
                 (*(int *)((int)puVar6 + 0x50) - *(int *)((int)puVar6 + 0x4c) >> 2) * 0x30;
  }
  puVar2 = *(undefined4 **)(param_2 + 8);
  iStack_14 = puVar2[5];
  puStack_18 = (undefined *)puVar2[4];
  uStack_1c = puVar2[3];
  uStack_20 = puVar2[2];
  uStack_24 = *puVar2;
  uStack_28 = 0x86c4a7;
  (**(code **)(*param_1 + 0x40))();
  *param_4 = *param_4 + 1;
  param_4[1] = param_4[1] + *(int *)(*(int *)(param_2 + 8) + 0x14);
  return;
}



/* FUNCTION 13301 ; VA 0x0086c4c0 ; FUN_0086c4c0 */

void __fastcall FUN_0086c4c0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  
  if (DAT_01eb4564 != '\0') {
    FUN_01677490(DAT_01eb4564,"FastCluster[%p]: unbind (%d parts, %d own connections)",
                 param_1 + -0x74,*(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c) >> 3,
                 *(int *)(param_1 + 0x10) - *(int *)(param_1 + 0xc) >> 2);
  }
  FUN_011590c0();
  if (*(int *)(param_1 + 0x44) == 0) {
    iVar3 = (uint)(*(char *)(param_1 + 0x4c) != '\0') * 8 + 100;
  }
  else {
    iVar3 = 0x74;
  }
  piVar1 = (int *)(*(int *)(*(int *)(param_1 + -0x6c) + 0x524) + iVar3);
  *piVar1 = *piVar1 - (*(int *)(param_1 + 0x30) - *(int *)(param_1 + 0x2c) >> 3);
  uVar4 = 0;
  iVar3 = *(int *)(param_1 + 0x2c);
  if (*(int *)(param_1 + 0x30) - iVar3 >> 3 != 0) {
    do {
      (**(code **)(**(int **)(iVar3 + 4 + uVar4 * 8) + 0x40))();
      puVar2 = *(undefined4 **)(iVar3 + 4 + uVar4 * 8);
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
      }
      uVar4 = uVar4 + 1;
      iVar3 = *(int *)(param_1 + 0x2c);
    } while (uVar4 < (uint)(*(int *)(param_1 + 0x30) - iVar3 >> 3));
  }
  *(undefined4 *)(param_1 + 0x24) = *(undefined4 *)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x2c);
  *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x38);
  return;
}



/* FUNCTION 13302 ; VA 0x0086c580 ; FUN_0086c580 */

void __fastcall FUN_0086c580(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  
  if (*(char *)(param_1 + 0xc0) == '\0') {
    piVar6 = *(int **)(param_1 + 0xa0);
    piVar7 = *(int **)(param_1 + 0xa4);
    while (piVar6 != piVar7) {
      piVar4 = (int *)(*(int *)(*piVar6 + 0xa8) + 0xc);
      iVar1 = *(int *)(*(int *)(*piVar6 + 0xa8) + 0xc);
      while (iVar1 != 0) {
        piVar4 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
        iVar1 = *piVar4;
      }
      uVar5 = -(uint)(piVar4 != (int *)0x0) & (uint)(piVar4 + -1);
      if (uVar5 == 0) {
        piVar4 = (int *)&DAT_00000014;
      }
      else {
        piVar4 = (int *)(uVar5 + 0xc);
      }
      if (*piVar4 == 0) {
        piVar6 = piVar6 + 2;
      }
      else {
        do {
          piVar4 = piVar7;
          piVar7 = piVar4 + -2;
          if (piVar6 == piVar7) goto LAB_0086c64f;
          piVar3 = (int *)(*(int *)(*piVar7 + 0xa8) + 0xc);
          iVar1 = *piVar3;
          while (iVar1 != 0) {
            piVar3 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
            iVar1 = *piVar3;
          }
          uVar5 = -(uint)(piVar3 != (int *)0x0) & (uint)(piVar3 + -1);
          if (uVar5 == 0) {
            piVar3 = (int *)&DAT_00000014;
          }
          else {
            piVar3 = (int *)(uVar5 + 0xc);
          }
        } while (*piVar3 != 0);
        iVar1 = *piVar6;
        iVar2 = piVar6[1];
        *piVar6 = *piVar7;
        piVar6[1] = piVar4[-1];
        piVar6 = piVar6 + 2;
        *piVar7 = iVar1;
        piVar4[-1] = iVar2;
      }
    }
LAB_0086c64f:
    FUN_00843bd0(piVar6,*(int *)(param_1 + 0xa4),*(int *)(param_1 + 0xa4) - (int)piVar6 >> 3,param_1
                );
    if (DAT_01eb4564 != '\0') {
      FUN_016773b0(DAT_01eb4564,
                   "FastCluster[%p]: %d parts, %d single-clump parts, %d multi-clump parts",param_1,
                   *(int *)(param_1 + 0xa4) - *(int *)(param_1 + 0xa0) >> 3,
                   (int)piVar6 - *(int *)(param_1 + 0xa0) >> 3,
                   *(int *)(param_1 + 0xa4) - (int)piVar6 >> 3,0);
    }
  }
  return;
}



/* FUNCTION 13303 ; VA 0x0086c6c0 ; FUN_0086c6c0 */

void __thiscall FUN_0086c6c0(int *param_1,char param_2)

{
  float fVar1;
  int iVar2;
  int iVar3;
  void **ppvVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int *piVar7;
  double *pdVar8;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  double dStack_24;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8988;
  pvStack_10 = ExceptionList;
  if (param_2 == '\0') {
    ppvVar4 = &pvStack_10;
    if (*(char *)((int)param_1 + 0x4d) == '\0') {
      if (DAT_01eb4564 == '\0') {
        return;
      }
      ExceptionList = &pvStack_10;
      FUN_01677490(DAT_01eb4564,
                   "FastCluster[%p]: skipping updateEntity dirty: %d, assetsUpdated: %d",
                   param_1 + -0x1d,0,0);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    *(undefined *)((int)param_1 + 0x4e) = 1;
    ppvVar4 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar4;
  uVar5 = FUN_01675290(DAT_01eb2f54);
  uStack_8 = 0;
  uStack_14 = uVar5;
  FUN_016827e0(&dStack_24);
  if (DAT_01eb4564 != '\0') {
    FUN_016773b0(DAT_01eb4564,
                 "FastCluster[%p]: updateEntity for %d parts (dirty: %d, light dirty: %d)",
                 param_1 + -0x1d,param_1[0xc] - param_1[0xb] >> 3,
                 *(undefined *)((int)param_1 + 0x4d),*(undefined *)((int)param_1 + 0x4e),0);
  }
  *(undefined *)((int)param_1 + 0x4d) = 0;
  if (*(char *)(param_1 + 0x14) != '\0') {
    FUN_00819480(0);
  }
  FUN_00869e40();
  if ((((*(char *)((int)param_1 + 0x4e) != '\0') && (param_1[0x11] == 0)) &&
      (*(char *)(param_1 + 0x14) == '\0')) &&
     (((fVar1 = (float)param_1[-0x17],
       fVar1 < (float)param_1[-0x14] || fVar1 == (float)param_1[-0x14] &&
       ((float)param_1[-0x16] < (float)param_1[-0x13] ||
        (float)param_1[-0x16] == (float)param_1[-0x13])) &&
      ((float)param_1[-0x15] < (float)param_1[-0x12] ||
       (float)param_1[-0x15] == (float)param_1[-0x12])))) {
    FUN_007c7690(param_1 + -0x17,
                 CONCAT31((int3)((uint)param_1[-0x1b] >> 8),*(undefined *)(param_1 + 0x13)));
  }
  if (param_1[0xb] == param_1[0xc]) {
    if (DAT_01eb4564 != '\0') {
      FUN_016774b0(DAT_01eb4564,"FastCluster[%p]: destroy (no more parts)",param_1 + -0x1d);
    }
    if ((int *)param_1[0x12] == (int *)0x0) {
      FUN_007c64e0(param_1 + -0x1d);
    }
    else {
      (**(code **)(*(int *)param_1[0x12] + 0x10))();
    }
  }
  else {
    uStack_34 = 1;
    iStack_30 = 0;
    iStack_2c = 0;
    uStack_28 = 0;
    uStack_8._0_1_ = 2;
    FUN_0086c580();
    uVar6 = FUN_0086c9f0(&uStack_34);
    if (((DAT_01d5a208 != '\0') && (iStack_30 == iStack_2c)) && (param_1[0x11] != 0)) {
      iVar2 = *(int *)(param_1[-0x1b] + 0x4e4);
      piVar7 = *(int **)(iVar2 + 0x18);
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        piVar7 = *(int **)(iVar2 + 0x18);
      }
      iStack_1c = *(int *)(iVar2 + 0x14);
      uStack_8._0_1_ = 3;
      piStack_18 = piVar7;
      if (iStack_1c != 0) {
        FUN_009020f0(param_1[0x11]);
      }
      uStack_8._0_1_ = 2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar2 = piVar7[1] + -1;
        piVar7[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar2 = piVar7[2] + -1;
          piVar7[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    piVar7 = param_1;
    if (param_1 == (int *)0x74) {
      piVar7 = (int *)0x0;
    }
    FUN_007c7aa0(piVar7,&iStack_30);
    param_1[-0x19] = param_1[0xc] - param_1[0xb] >> 3;
    (**(code **)(*param_1 + 0x48))();
    (**(code **)(*param_1 + 0x4c))();
    if (((((*(char *)((int)param_1 + 0x4e) != '\0') && (param_1[0x11] == 0)) &&
         (*(char *)(param_1 + 0x14) == '\0')) &&
        ((fVar1 = (float)param_1[-0x17],
         fVar1 < (float)param_1[-0x14] || fVar1 == (float)param_1[-0x14] &&
         ((float)param_1[-0x16] < (float)param_1[-0x13] ||
          (float)param_1[-0x16] == (float)param_1[-0x13])))) &&
       ((float)param_1[-0x15] < (float)param_1[-0x12] ||
        (float)param_1[-0x15] == (float)param_1[-0x12])) {
      FUN_007c7690(param_1 + -0x17,
                   CONCAT31((int3)((uint)param_1[-0x1b] >> 8),*(undefined *)(param_1 + 0x13)));
    }
    *(undefined *)((int)param_1 + 0x4e) = 0;
    if (DAT_01eb4564 != '\0') {
      iVar2 = param_1[-0xe];
      iVar3 = param_1[-0xf];
      pdVar8 = (double *)FUN_016827e0(&iStack_1c);
      FUN_016773b0(DAT_01eb4564,
                   "FastCluster[%p]: updated geometry for %d parts in %d usec (%d entities, %d vertices)"
                   ,param_1 + -0x1d,param_1[0xc] - param_1[0xb] >> 3,
                   (int)((*pdVar8 - dStack_24) * DAT_018c0d70 * DAT_018c0d70),iVar2 - iVar3 >> 2,
                   uVar6);
    }
    thunk_FUN_007c4590();
  }
  uStack_8 = 4;
  FUN_01675290(uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13304 ; VA 0x0086c9f0 ; FUN_0086c9f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0086c9f0(int *param_1,undefined4 *param_2)

{
  uint *puVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int *piVar13;
  uint uVar14;
  int iVar15;
  float10 fVar16;
  undefined8 uVar17;
  undefined auStack_1e0 [216];
  int iStack_108;
  undefined4 uStack_104;
  undefined uStack_100;
  int *piStack_fc;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined4 *puStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined8 uStack_c4;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  int iStack_64;
  uint uStack_60;
  uint uStack_5c;
  int *piStack_58;
  int iStack_54;
  int iStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  undefined4 *puStack_44;
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  int iStack_38;
  int iStack_34;
  float fStack_30;
  int *piStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  char cStack_19;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8a2e;
  pvStack_10 = ExceptionList;
  iStack_54 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_2c = param_1;
  if ((*(int *)(iStack_54 + 0x34) < DAT_01ece338) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ece338), DAT_01ece338 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0("Render","updateGeometry",0xffffffff);
    DAT_01ece334 = (undefined4)((ulonglong)uVar17 >> 0x20);
    DAT_01ece330 = (undefined4)uVar17;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ece338);
  }
  uStack_78 = DAT_01ece330;
  uStack_88 = DAT_01ece330;
  uStack_74 = DAT_01ece334;
  uStack_84 = DAT_01ece334;
  uStack_80 = FUN_0152d930(DAT_01ece330,DAT_01ece334);
  uStack_8 = 1;
  cVar6 = (**(code **)(*param_1 + 0x30))();
  uStack_24 = DAT_019011dc;
  if ((cVar6 != '\0') && (DAT_01d622a8 != '\0')) {
    uStack_24 = DAT_01919f9c;
  }
  cStack_11 = *(char *)(param_1 + 0x30);
  iStack_20 = param_1[2];
  uStack_18 = param_1[0x2e];
  uVar14 = param_1[0x29] - param_1[0x28] >> 3;
  FUN_01154090(uStack_18);
  uStack_8._0_1_ = 2;
  iStack_108 = 0;
  uStack_104 = uStack_24;
  piStack_fc = (int *)0x0;
  uStack_f8 = 0;
  piStack_fc = (int *)FUN_00845d90();
  iStack_f4 = 0;
  puStack_f0 = (undefined4 *)0x0;
  puStack_ec = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((DAT_01d622b0 == '\0') && (DAT_01d622a8 != '\0')) && (uStack_18 != 0)) {
    FUN_0097bf90(uStack_18);
  }
  if ((uint)(((int)puStack_ec - iStack_f4) / 0x1c) < uVar14) {
    if (0x9249249 < uVar14) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00830b40(uVar14);
  }
  if ((cStack_11 != '\0') ||
     (iStack_108 = *(int *)(*(int *)(iStack_20 + 0x520) + 0x20), iStack_108 == 0)) {
    iStack_108 = 1;
  }
  iVar7 = (**(code **)(**(int **)(iStack_20 + 0x3c) + 0x40))();
  uStack_100 = *(undefined *)(iVar7 + 0x38);
  iStack_50 = 0;
  puStack_4c = (undefined4 *)0x0;
  puStack_48 = (undefined4 *)0x0;
  puStack_44 = (undefined4 *)0x0;
  puStack_40 = (undefined4 *)0x0;
  puStack_3c = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (*(char *)(param_1 + 0x30) == '\0') {
    FUN_007cfd20(0x10);
    FUN_007cfd20(0x10);
  }
  else {
    FUN_008696b0(0);
    FUN_007cfd20(1);
    FUN_007cfd20(1);
    uStack_18 = 0xffffffff;
    if (puStack_48 == puStack_4c) {
      FUN_0063d9b0(puStack_4c,&uStack_18);
    }
    else {
      *puStack_4c = 0xffffffff;
      puStack_4c = puStack_4c + 1;
    }
    uStack_18 = 0;
    if (puStack_3c == puStack_40) {
      FUN_0063d9b0(puStack_40,&uStack_18);
    }
    else {
      *puStack_40 = 0;
      puStack_40 = puStack_40 + 1;
    }
  }
  uStack_5c = 0;
  if (*(int *)(iStack_54 + 0x34) < DAT_01ece348) {
    FUN_016f3809(&DAT_01ece348);
    if (DAT_01ece348 == -1) {
      uStack_8._0_1_ = 8;
      uVar17 = FUN_0152dab0("Render","FC geo prepare",0xffffffff);
      DAT_01ece344 = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ece340 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_016f37bf(&DAT_01ece348);
    }
  }
  iStack_34 = DAT_01ece340;
  uStack_98 = DAT_01ece340;
  iStack_38 = DAT_01ece344;
  uStack_94 = DAT_01ece344;
  uStack_90 = FUN_0152d930(DAT_01ece340,DAT_01ece344);
  piStack_68 = param_1 + 0x32;
  param_1[0x33] = param_1[0x32];
  uStack_8._0_1_ = 10;
  FUN_007b3200(param_1[0x35],param_1[0x36]);
  param_1[0x36] = param_1[0x35];
  uStack_8._0_1_ = 9;
  iVar7 = piStack_2c[0x28];
  uStack_24 = 0;
  iStack_20 = iVar7;
  if (piStack_2c[0x29] - iVar7 >> 3 != 0) {
    uStack_6c = DAT_018c45c4;
    uStack_70 = DAT_018c45d0;
    do {
      uVar14 = uStack_24;
      cStack_11 = '\0';
      iStack_20 = iVar7;
      uStack_28 = FUN_00760730(*(char *)(piStack_2c + 0x30) == '\0',
                               *(undefined4 *)(iVar7 + uStack_24 * 8),auStack_1e0,&cStack_11,0);
      if (*(char *)(piStack_2c + 0x31) != '\0') {
        uStack_28 = uStack_28 | 0x400;
      }
      iVar8 = FUN_00b084e0();
      if (iVar8 == 0x630) {
        uStack_28 = uStack_28 | 2;
      }
      uStack_60 = uStack_28 >> 1 & 0xffffff01;
      if (DAT_01d61b8c == '\0') {
LAB_0086cdc2:
        cStack_19 = '\0';
      }
      else {
        iVar8 = FUN_00b08820();
        if ((iVar8 == 0) || (cStack_19 = '\x01', (uStack_28 & 4) == 0)) goto LAB_0086cdc2;
      }
      fStack_30 = (float)FUN_00d37670(*(undefined4 *)(iVar7 + uVar14 * 8),0,0);
      uStack_18 = FUN_00b06f80();
      if ((*(char *)(piStack_2c + 0x30) == '\0') && ((uStack_18 == 0 || (uStack_18 != uStack_5c))))
      {
        uStack_d4 = *(undefined4 *)(iVar7 + uVar14 * 8);
        uStack_d0 = CONCAT44(uStack_6c,uStack_6c);
        uStack_c8 = 0x7f7fffff;
        uStack_c4 = CONCAT44(uStack_70,uStack_70);
        uStack_bc = 0xff7fffff;
        if (puStack_ec == puStack_f0) {
          FUN_00725c30(puStack_f0,&uStack_d4);
        }
        else {
          *puStack_f0 = uStack_d4;
          puStack_f0[1] = uStack_6c;
          puStack_f0[2] = uStack_6c;
          puStack_f0[3] = 0x7f7fffff;
          *(ulonglong *)(puStack_f0 + 4) = CONCAT44(uStack_70,uStack_70);
          puStack_f0[6] = 0xff7fffff;
          puStack_f0 = puStack_f0 + 7;
        }
        uStack_5c = uStack_18;
        uStack_18 = 0xffffffff;
        if (puStack_48 == puStack_4c) {
          FUN_0063d9b0(puStack_4c,&uStack_18);
        }
        else {
          *puStack_4c = 0xffffffff;
          puStack_4c = puStack_4c + 1;
        }
        uStack_18 = 0;
        if (puStack_3c == puStack_40) {
          FUN_0063d9b0(puStack_40,&uStack_18);
        }
        else {
          *puStack_40 = 0;
          puStack_40 = puStack_40 + 1;
        }
      }
      iStack_64 = ((int)puStack_f0 - iStack_f4) / 0x1c + -1;
      if (-1 < (int)fStack_30) {
        puStack_44[iStack_64] = puStack_44[iStack_64] + 1;
      }
      if ((char)uStack_60 == '\0') {
        if ((DAT_01d61b8c == '\0') || (cStack_19 == '\0')) {
          iVar7 = 0;
        }
        else {
          iVar7 = 5;
        }
      }
      else {
        iVar7 = FUN_00b084e0();
        iVar7 = (iVar7 != 0x620) + 8;
        fStack_30 = (float)iVar7;
      }
      fVar16 = (float10)FUN_00b08910();
      fStack_30 = (float)fVar16;
      if (fStack_30 < DAT_018ce2f8) {
        FUN_00869730(iStack_64,*(undefined4 *)(iStack_20 + uVar14 * 8),0,uStack_28,iVar7,param_2);
      }
      iVar7 = *(int *)(iStack_20 + uVar14 * 8);
      if ((((*(byte *)(iVar7 + 0xb4) & 1) != 0) &&
          (piStack_58 = *(int **)(iVar7 + 0x2c), piStack_58 != (int *)0x0)) && (cStack_11 == '\0'))
      {
        iVar7 = *piStack_58;
        uStack_28 = uStack_28 & 0x401 | 2;
        uStack_18 = 0;
        if (piStack_58[1] - iVar7 >> 3 != 0) {
          do {
            iVar7 = *(int *)(iVar7 + uStack_18 * 8);
            iVar8 = *(int *)(iVar7 + 0xc);
            iVar9 = FUN_00cffc50();
            iVar15 = 0;
            if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8) <=
                (uint)*(ushort *)(iVar9 + 0x1da)) {
              iVar15 = iVar7;
            }
            uVar14 = uStack_24;
            if (iVar15 != 0) {
              fVar16 = (float10)FUN_00d00910();
              uVar14 = uStack_24;
              fStack_30 = (float)fVar16;
              if (fStack_30 < DAT_018ce2f8) {
                if (((char)uStack_60 != '\0') || (uVar10 = 2, cStack_19 != '\0')) {
                  uVar10 = 9;
                }
                FUN_00869730(iStack_64,*(undefined4 *)(iStack_20 + uStack_24 * 8),iVar15,uStack_28,
                             uVar10,param_2);
              }
            }
            uStack_18 = uStack_18 + 1;
            iVar7 = *piStack_58;
          } while (uStack_18 < (uint)(piStack_58[1] - iVar7 >> 3));
        }
      }
      uStack_24 = uVar14 + 1;
      iVar7 = piStack_2c[0x28];
      iStack_20 = iVar7;
    } while (uStack_24 < (uint)(piStack_2c[0x29] - iVar7 >> 3));
  }
  uStack_8._0_1_ = 0xb;
  FUN_0152dda0(iStack_34,iStack_38,uStack_90);
  uStack_8._0_1_ = 7;
  if (*(int *)(iStack_54 + 0x34) < DAT_01ece358) {
    FUN_016f3809(&DAT_01ece358);
    if (DAT_01ece358 == -1) {
      uStack_8._0_1_ = 0xc;
      uVar17 = FUN_0152dab0("Render","clear",0xffffffff);
      DAT_01ece354 = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ece350 = (undefined4)uVar17;
      uStack_8._0_1_ = 7;
      FUN_016f37bf(&DAT_01ece358);
    }
  }
  piStack_58 = (int *)DAT_01ece350;
  iStack_38 = DAT_01ece354;
  uVar17 = FUN_0152d930(DAT_01ece350,DAT_01ece354);
  iStack_34 = (int)((ulonglong)uVar17 >> 0x20);
  uVar14 = 0;
  iVar7 = piStack_2c[0xe];
  piVar13 = piStack_2c;
  if (piStack_2c[0xf] - iVar7 >> 2 != 0) {
    do {
      puVar12 = *(undefined4 **)(iVar7 + uVar14 * 4);
      if (puVar12 != (undefined4 *)0x0) {
        (**(code **)*puVar12)(1);
        piVar13 = piStack_2c;
      }
      uVar14 = uVar14 + 1;
      iVar7 = piVar13[0xe];
    } while (uVar14 < (uint)(piVar13[0xf] - iVar7 >> 2));
  }
  piVar13[0xf] = iVar7;
  uStack_8._0_1_ = 0xd;
  FUN_0152dda0(piStack_58,iStack_38,(int)uVar17,iStack_34);
  piVar13 = piStack_2c;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iStack_38 = FUN_0086a350(piStack_2c);
  puVar1 = (uint *)(piVar13 + 0x25);
  FUN_008682e0(((int)puStack_f0 - iStack_f4) / 0x1c,puVar1);
  FUN_00843570(((int)puStack_f0 - iStack_f4) / 0x1c,piVar13 + 0x2b);
  uStack_18 = *puVar1;
  uStack_24 = 0;
  iVar7 = (int)(piVar13[0x26] - uStack_18) >> 0x1f;
  if ((int)(piVar13[0x26] - uStack_18) / 0x58 + iVar7 != iVar7) {
    iVar7 = 0;
    iStack_34 = iStack_50 - (int)puStack_44;
    iStack_20 = 0;
    param_2 = puStack_44;
    do {
      *(undefined4 *)(uStack_18 + iVar7) = *(undefined4 *)(iStack_f4 + iStack_20);
      uVar17 = *(undefined8 *)(iStack_f4 + 4 + iStack_20);
      uStack_98 = *(undefined4 *)(iStack_f4 + 0xc + iStack_20);
      uStack_90._4_4_ = *(undefined4 *)(iStack_f4 + 0x18 + iStack_20);
      uVar2 = *(undefined8 *)(iStack_f4 + 0x10 + iStack_20);
      uVar14 = *puVar1;
      uStack_94 = (undefined4)uVar2;
      uStack_90._0_4_ = (undefined4)((ulonglong)uVar2 >> 0x20);
      uStack_a0._0_4_ = (undefined4)uVar17;
      uStack_a0._4_4_ = (undefined4)((ulonglong)uVar17 >> 0x20);
      puVar12 = (undefined4 *)(iVar7 + 8 + uVar14);
      *puVar12 = (undefined4)uStack_a0;
      puVar12[1] = uStack_a0._4_4_;
      puVar12[2] = uStack_98;
      puVar12[3] = uStack_94;
      *(ulonglong *)(iVar7 + 0x18 + uVar14) = CONCAT44(uStack_90._4_4_,(undefined4)uStack_90);
      uVar14 = *puVar1;
      if (*(int *)(iVar7 + uVar14) == 0) {
        puVar12 = &uStack_b8;
        uStack_b8 = _DAT_018e3fb0;
        uStack_b4 = _UNK_018e3fb4;
        uStack_b0 = _UNK_018e3fb8;
        uStack_ac = _UNK_018e3fbc;
        uStack_a8 = _DAT_018e3fb0;
        uStack_a4 = _UNK_018e3fb4;
        uStack_a0 = CONCAT44(_UNK_018e3fbc,_UNK_018e3fb8);
        uStack_98 = _DAT_018e3fb0;
        uStack_94 = _UNK_018e3fb4;
        uStack_90._0_4_ = _UNK_018e3fb8;
        uStack_90._4_4_ = _UNK_018e3fbc;
      }
      else {
        uStack_a0 = uVar17;
        puVar11 = (undefined4 *)FUN_00b077e0();
        puVar12 = &uStack_e8;
        uStack_e8 = *puVar11;
        uStack_e4 = puVar11[1];
        uStack_e0 = puVar11[2];
        uStack_dc = puVar11[3];
        uStack_d8 = puVar11[4];
        uStack_d4 = puVar11[5];
        uStack_d0 = *(undefined8 *)(puVar11 + 6);
        uVar14 = *puVar1;
        uStack_c8 = puVar11[8];
        uStack_c4 = *(undefined8 *)(puVar11 + 9);
        uStack_bc = puVar11[0xb];
      }
      uVar10 = puVar12[1];
      uVar3 = puVar12[2];
      uVar4 = puVar12[3];
      puVar11 = (undefined4 *)(uVar14 + 0x20 + iVar7);
      *puVar11 = *puVar12;
      puVar11[1] = uVar10;
      puVar11[2] = uVar3;
      puVar11[3] = uVar4;
      uVar10 = puVar12[5];
      uVar3 = puVar12[6];
      uVar4 = puVar12[7];
      puVar11 = (undefined4 *)(uVar14 + 0x30 + iVar7);
      *puVar11 = puVar12[4];
      puVar11[1] = uVar10;
      puVar11[2] = uVar3;
      puVar11[3] = uVar4;
      uVar10 = puVar12[9];
      uVar3 = puVar12[10];
      uVar4 = puVar12[0xb];
      puVar11 = (undefined4 *)(uVar14 + 0x40 + iVar7);
      *puVar11 = puVar12[8];
      puVar11[1] = uVar10;
      puVar11[2] = uVar3;
      puVar11[3] = uVar4;
      iVar8 = *(int *)(iVar7 + *puVar1);
      if (iVar8 == 0) {
        uVar10 = 0;
      }
      else {
        uVar10 = *(undefined4 *)(iVar8 + 0xa8);
      }
      *(undefined4 *)(iVar7 + 4 + *puVar1) = uVar10;
      iStack_20 = iStack_20 + 0x1c;
      uStack_24 = uStack_24 + 1;
      *(undefined4 *)(iVar7 + 0x50 + *puVar1) = *(undefined4 *)(iStack_34 + (int)param_2);
      *(undefined4 *)(iVar7 + 0x54 + *puVar1) = *param_2;
      iVar7 = iVar7 + 0x58;
      uStack_18 = *puVar1;
      param_2 = param_2 + 1;
    } while (uStack_24 < (uint)((int)(piVar13[0x26] - uStack_18) / 0x58));
  }
  iVar8 = iStack_50;
  iVar7 = iStack_54;
  if (*(int *)(iStack_54 + 0x34) < DAT_01ece368) {
    FUN_016f3809(&DAT_01ece368);
    if (DAT_01ece368 == -1) {
      uStack_8._0_1_ = 0xe;
      uVar17 = FUN_0152da50("Render");
      DAT_01ece364 = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ece360 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_016f37bf(&DAT_01ece368);
    }
  }
  FUN_0152d760(DAT_01ece360,DAT_01ece364,"%d parts, %d entities",
               piStack_2c[0x29] - piStack_2c[0x28] >> 3,piStack_2c[0xf] - piStack_2c[0xe] >> 2);
  if (*(int *)(iVar7 + 0x34) < DAT_01ece378) {
    FUN_016f3809(&DAT_01ece378);
    if (DAT_01ece378 == -1) {
      uStack_8._0_1_ = 0xf;
      uVar17 = FUN_0152da50("Render");
      DAT_01ece374 = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ece370 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_016f37bf(&DAT_01ece378);
    }
  }
  iVar7 = iStack_38;
  FUN_0152d760(DAT_01ece370,DAT_01ece374,"%d vertices (%d KB)",iStack_38,
               (uint)(iStack_38 * 0x2c) >> 10);
  uStack_8._0_1_ = 6;
  if (puStack_44 != (undefined4 *)0x0) {
    uVar14 = ((int)puStack_3c - (int)puStack_44 >> 2) * 4;
    puVar12 = puStack_44;
    if (0xfff < uVar14) {
      puVar12 = (undefined4 *)puStack_44[-1];
      uVar14 = uVar14 + 0x23;
      if (0x1f < (uint)((int)puStack_44 + (-4 - (int)puVar12))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar12,uVar14);
  }
  uStack_8._0_1_ = 5;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (iVar8 != 0) {
    uVar14 = ((int)puStack_48 - iVar8 >> 2) * 4;
    iVar15 = iVar8;
    if (0xfff < uVar14) {
      iVar15 = *(int *)(iVar8 + -4);
      uVar14 = uVar14 + 0x23;
      if (0x1f < (iVar8 - iVar15) - 4U) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar15,uVar14);
  }
  uStack_8._0_1_ = 0x10;
  FUN_00764680();
  FUN_0072a1c0();
  piVar13 = piStack_fc;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  FUN_00869630(piStack_fc[1]);
  piStack_fc[1] = (int)piVar13;
  *piStack_fc = (int)piVar13;
  piStack_fc[2] = (int)piVar13;
  uStack_f8 = 0;
  FUN_01674ea0(piStack_fc,0x38);
  FUN_00777180();
  uStack_8 = 0x12;
  FUN_0152dda0(uStack_78,uStack_74,uStack_80);
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 13305 ; VA 0x0086d690 ; FUN_0086d690 */

void __thiscall FUN_0086d690(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  int *piVar2;
  char cVar3;
  sbyte sVar4;
  int iVar5;
  undefined4 uVar6;
  sbyte sVar7;
  uint uVar8;
  float10 fVar9;
  
  if ((*(char *)(param_1 + 0xc4) == '\0') && (cVar3 = FUN_00841130(), cVar3 != '\0')) {
    return;
  }
  cVar3 = FUN_01156450();
  if ((cVar3 == '\0') || (cVar3 = FUN_00795ec0(), cVar3 == '\0')) {
    sVar7 = 1;
  }
  else {
    sVar7 = 0;
  }
  fVar1 = *(float *)(param_1 + 0x14);
  fVar9 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4));
  sVar4 = 2;
  if (fVar1 < (float)fVar9) {
    sVar4 = sVar7;
  }
  if (*(char *)(param_1 + 0xc4) != '\0') {
    sVar4 = 1;
  }
  uVar6 = *(undefined4 *)(*(int *)(param_1 + 8) + 0x5c4);
  cVar3 = FUN_0078bd20();
  if ((cVar3 != '\0') && (*(char *)(param_1 + 0xc4) != '\0')) {
    uVar6 = 1;
  }
  uVar8 = 0;
  iVar5 = *(int *)(param_1 + 0x38);
  if (*(int *)(param_1 + 0x3c) - iVar5 >> 2 != 0) {
    do {
      piVar2 = *(int **)(iVar5 + uVar8 * 4);
      if ((*(byte *)(piVar2 + 3) & (byte)(1 << sVar4)) != 0) {
        (**(code **)(*piVar2 + 8))(param_2,param_3,sVar4,param_4,uVar6);
      }
      uVar8 = uVar8 + 1;
      iVar5 = *(int *)(param_1 + 0x38);
    } while (uVar8 < (uint)(*(int *)(param_1 + 0x3c) - iVar5 >> 2));
  }
  if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
    FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
  }
  return;
}



/* FUNCTION 13306 ; VA 0x0086d7b0 ; FUN_0086d7b0 */

undefined4 * __thiscall FUN_0086d7b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00841300(param_2,param_3);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  *param_1 = RBX::Graphics::ParticleEmitterBase::vftable;
  param_1[0x1d] = RBX::Graphics::ParticleEmitterBase::vftable;
  param_1[0x24] = 0xffffffff;
  return param_1;
}



/* FUNCTION 13307 ; VA 0x0086d830 ; FUN_0086d830 */

void __fastcall FUN_0086d830(undefined4 *param_1)

{
  param_1[0x1d] = RBX::Graphics::ParticleEmitterBase::vftable;
  *param_1 = RBX::Graphics::ParticleEmitterBase::vftable;
  FUN_01158110();
  FUN_00841420();
  return;
}



/* FUNCTION 13308 ; VA 0x0086d84f ; FUN_0086d84f */

void FUN_0086d84f(void)

{
  FUN_0086d860();
  return;
}



/* FUNCTION 13309 ; VA 0x0086d860 ; FUN_0086d860 */

undefined4 * __thiscall FUN_0086d860(undefined4 *param_1,byte param_2)

{
  param_1[0x1d] = RBX::Graphics::ParticleEmitterBase::vftable;
  *param_1 = RBX::Graphics::ParticleEmitterBase::vftable;
  FUN_01158110();
  FUN_00841420();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 13310 ; VA 0x0086d8a0 ; FUN_0086d8a0 */

bool FUN_0086d8a0(void)

{
  if (DAT_01ece3bc == 0) {
    FUN_016799d0();
    DAT_01ece3bc = FUN_01679e20(1,0,100,0);
  }
  return DAT_01ece3bc <= DAT_01ece38c;
}



/* FUNCTION 13311 ; VA 0x0086d8e0 ; FUN_0086d8e0 */

/* WARNING: Removing unreachable block (ram,0x0086db36) */
/* WARNING: Removing unreachable block (ram,0x0086db44) */
/* WARNING: Removing unreachable block (ram,0x0086dbb2) */
/* WARNING: Removing unreachable block (ram,0x0086db54) */

undefined4 * FUN_0086d8e0(undefined4 *param_1,undefined4 *param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  undefined4 ***pppuStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = DAT_01d624e4;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8a61;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_14 = (int *)&DAT_01d624d4;
  if (0xf < DAT_01d624e8) {
    piStack_14 = DAT_01d624d4;
  }
  if (DAT_01d624e4 < 0x10) {
    pppuStack_30 = (undefined4 ***)*piStack_14;
    iStack_2c = piStack_14[1];
    iStack_28 = piStack_14[2];
    iStack_24 = piStack_14[3];
    uStack_1c = 0xf;
    ExceptionList = &pvStack_10;
  }
  else {
    uVar8 = DAT_01d624e4 | 0xf;
    if (0x7fffffff < uVar8) {
      uVar8 = 0x7fffffff;
    }
    ExceptionList = &pvStack_10;
    pppuStack_30 = (undefined4 ***)FUN_00554060(uVar8 + 1);
    FUN_0170c6f0(pppuStack_30,piStack_14,uVar7 + 1);
    uStack_1c = uVar8;
  }
  uStack_20 = uVar7;
  uStack_8 = 0;
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  puVar4 = (undefined4 *)((int)puVar4 + param_2[4]);
  puVar9 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar9 = (undefined4 *)*param_2;
  }
  pcVar6 = "";
  do {
    if (puVar4 == puVar9) {
      if (pcVar6 == ".Client.dmp") {
LAB_0086d9b1:
        puVar4 = &DAT_01d62444;
        uVar10 = DAT_01d62454;
        if (0xf < DAT_01d62458) {
          puVar4 = DAT_01d62444;
        }
        goto LAB_0086da7d;
      }
      break;
    }
    if (pcVar6 == ".Client.dmp") goto LAB_0086d9b1;
    pcVar1 = (char *)((int)puVar4 + -1);
    puVar4 = (undefined4 *)((int)puVar4 + -1);
    pcVar6 = pcVar6 + -1;
  } while (*pcVar1 == *pcVar6);
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  puVar4 = (undefined4 *)((int)puVar4 + param_2[4]);
  puVar9 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar9 = (undefined4 *)*param_2;
  }
  pcVar6 = "";
  do {
    if (puVar4 == puVar9) {
      if (pcVar6 == ".RobloxStudio.dmp") {
LAB_0086da0d:
        puVar4 = &DAT_01d6245c;
        uVar10 = DAT_01d6246c;
        if (0xf < DAT_01d62470) {
          puVar4 = DAT_01d6245c;
        }
        goto LAB_0086da7d;
      }
      break;
    }
    if (pcVar6 == ".RobloxStudio.dmp") goto LAB_0086da0d;
    pcVar1 = (char *)((int)puVar4 + -1);
    puVar4 = (undefined4 *)((int)puVar4 + -1);
    pcVar6 = pcVar6 + -1;
  } while (*pcVar1 == *pcVar6);
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  puVar4 = (undefined4 *)((int)puVar4 + param_2[4]);
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  pcVar6 = "";
  do {
    if (puVar4 == param_2) {
      if (pcVar6 == ".dmp") {
LAB_0086da64:
        puVar4 = &DAT_01d62474;
        uVar10 = DAT_01d62484;
        if (0xf < DAT_01d62488) {
          puVar4 = DAT_01d62474;
        }
LAB_0086da7d:
        FUN_005542c0(puVar4,uVar10);
      }
      break;
    }
    if (pcVar6 == ".dmp") goto LAB_0086da64;
    pcVar1 = (char *)((int)puVar4 + -1);
    puVar4 = (undefined4 *)((int)puVar4 + -1);
    pcVar6 = pcVar6 + -1;
  } while (*pcVar1 == *pcVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_18 = 2;
  FUN_0058a190(DAT_01d6243c + 7);
  puVar4 = &DAT_01d6242c;
  if (0xf < DAT_01d62440) {
    puVar4 = DAT_01d6242c;
  }
  FUN_00554150(puVar4,DAT_01d6243c);
  FUN_00554150("&token=",7);
  ppppuVar5 = &pppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar5 = (undefined4 ****)pppuStack_30;
  }
  puVar4 = (undefined4 *)FUN_00554150(ppppuVar5,uStack_20);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar10 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar10;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    ppppuVar5 = (undefined4 ****)pppuStack_30;
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)pppuStack_30[-1];
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)pppuStack_30 + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13312 ; VA 0x0086dbc0 ; FUN_0086dbc0 */

undefined4 FUN_0086dbc0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_108 [120];
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8aa6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ece3bc == 0) {
    ExceptionList = &pvStack_10;
    FUN_016799d0();
    DAT_01ece3bc = FUN_01679e20(1,0,100,0);
  }
  if (DAT_01ece3bc <= DAT_01ece38c) {
    FUN_0086d8e0(param_1,param_2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("/Error/Dmp.ashx",0xf);
  uStack_8._0_1_ = 2;
  uVar1 = FUN_0151ed70(auStack_90);
  uStack_8._0_1_ = 3;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 4;
  FUN_0151bcc0(auStack_108,auStack_28,uVar1,auStack_40,auStack_58,auStack_70);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0151bb70(param_1);
  FUN_0056d9d0();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_7c) {
    uVar3 = uStack_7c + 1;
    uVar2 = auStack_90[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_90[0] - 4);
      uVar3 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar3 = uStack_44 + 1;
    uVar2 = auStack_58[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_58[0] - 4);
      uVar3 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar3 = uStack_5c + 1;
    uVar2 = auStack_70[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_70[0] - 4);
      uVar3 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13313 ; VA 0x0086de90 ; FUN_0086de90 */

undefined4 FUN_0086de90(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined auStack_108 [120];
  uint auStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8aa6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ece3bc == 0) {
    ExceptionList = &pvStack_10;
    FUN_016799d0();
    DAT_01ece3bc = FUN_01679e20(1,0,100,0);
  }
  if (DAT_01ece3bc <= DAT_01ece38c) {
    FUN_0086d8e0(param_1,param_2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("/Error/Grid.ashx",0x10);
  uStack_8._0_1_ = 2;
  uVar1 = FUN_0151ed70(auStack_90);
  uStack_8._0_1_ = 3;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("https",5);
  uStack_8._0_1_ = 4;
  FUN_0151bcc0(auStack_108,auStack_28,uVar1,auStack_40,auStack_58,auStack_70);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0151bb70(param_1);
  FUN_0056d9d0();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_7c) {
    uVar3 = uStack_7c + 1;
    uVar2 = auStack_90[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_90[0] - 4);
      uVar3 = uStack_7c + 0x24;
      if (0x1f < (auStack_90[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_80 = 0;
  uStack_7c = 0xf;
  auStack_90[0] = auStack_90[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar3 = uStack_44 + 1;
    uVar2 = auStack_58[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_58[0] - 4);
      uVar3 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar3 = uStack_5c + 1;
    uVar2 = auStack_70[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_70[0] - 4);
      uVar3 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13314 ; VA 0x0086e160 ; FUN_0086e160 */

uint * __thiscall FUN_0086e160(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2 * 8;
    if (uVar1 < 0x1000) {
      if (uVar1 == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_01674e20(uVar1);
      }
    }
    else {
      uVar2 = uVar1 + 0x23;
      if (uVar2 <= uVar1) {
        uVar2 = 0xffffffff;
      }
      iVar3 = FUN_01674e20(uVar2);
      if (iVar3 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar2 = iVar3 + 0x23U & 0xffffffe0;
      *(int *)(uVar2 - 4) = iVar3;
    }
    *param_1 = uVar2;
    param_1[1] = uVar2;
    param_1[2] = *param_1 + uVar1;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar4 = *param_3;
        puVar4[1] = param_3[1];
        puVar4 = puVar4 + 2;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 13315 ; VA 0x0086e210 ; FUN_0086e210 */

uint FUN_0086e210(undefined4 *param_1)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  
  pcVar4 = (char *)*param_1;
  pcVar2 = pcVar4;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  iVar3 = (int)pcVar2 - (int)(pcVar4 + 1);
  uVar5 = 0;
  param_1 = (undefined4 *)0x0;
  if (pcVar4 + iVar3 < pcVar4) {
    iVar3 = 0;
  }
  if (iVar3 != 0) {
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
      param_1 = (undefined4 *)((int)param_1 + 1);
      uVar5 = uVar5 ^ cVar1 + -0x61c88647 + uVar5 * 0x40 + (uVar5 >> 2);
    } while (param_1 != (undefined4 *)iVar3);
  }
  return uVar5;
}



/* FUNCTION 13316 ; VA 0x0086e270 ; FUN_0086e270 */

char * FUN_0086e270(char *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char *pcVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8ac7;
  pvStack_10 = ExceptionList;
  pcVar5 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar5 = *(char **)param_1;
  }
  iVar1 = DAT_01ede3c8;
  ExceptionList = &pvStack_10;
  if (DAT_01ede3c8 == 0) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_0086e660();
  }
  if ((pcVar5 != (char *)0x0) && (*pcVar5 != '\0')) {
    iVar2 = FUN_016dee6d(iVar1);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    iStack_8 = 0;
    param_1 = pcVar5;
    puVar3 = (undefined4 *)FUN_0086e520(&param_1);
    if (puVar3 == (undefined4 *)0x0) {
      param_1 = *(char **)(iVar1 + 0x3c);
      if (0x3fff < param_1) {
        param_1 = (char *)0xffffffff;
      }
      pcVar4 = (char *)FUN_01674e20(0x1c);
      iStack_8._0_1_ = 2;
      if (pcVar4 == (char *)0x0) {
        pcVar4 = (char *)0x0;
        uVar6 = (uint)param_1;
      }
      else {
        FUN_0054eff0(pcVar5);
        *(char **)(pcVar4 + 0x18) = param_1;
        uVar6 = (uint)param_1;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_1 = pcVar4;
      if (0xf < *(uint *)(pcVar4 + 0x14)) {
        param_1 = *(char **)pcVar4;
      }
      if ((uint)((*(int *)(iVar1 + 0x34) - *(int *)(iVar1 + 0x30) >> 3) * 3) >> 2 <=
          *(uint *)(iVar1 + 0x3c)) {
        FUN_0086e9a0();
      }
      iVar2 = FUN_0086e740(&param_1);
      *(char **)(iVar2 + 4) = pcVar4;
      if (-1 < (int)uVar6) {
        *(char **)(&DAT_01ece3c0 + uVar6 * 4) = pcVar4;
      }
      iStack_8 = 3;
    }
    else {
      pcVar4 = (char *)*puVar3;
      iStack_8 = 1;
    }
    iVar1 = FUN_016deec8(iVar1);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    ExceptionList = pvStack_10;
    return pcVar4;
  }
  ExceptionList = pvStack_10;
  return (char *)(iVar1 + 0x48);
}



/* FUNCTION 13317 ; VA 0x0086e3d0 ; FUN_0086e3d0 */

char * FUN_0086e3d0(char *param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  char *pcVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8ac7;
  pvStack_10 = ExceptionList;
  iVar2 = DAT_01ede3c8;
  ExceptionList = &pvStack_10;
  if (DAT_01ede3c8 == 0) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0086e660();
  }
  pcVar1 = param_1;
  if ((param_1 != (char *)0x0) && (*param_1 != '\0')) {
    iVar3 = FUN_016dee6d(iVar2);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    iStack_8 = 0;
    param_1 = pcVar1;
    puVar4 = (undefined4 *)FUN_0086e520(&param_1);
    if (puVar4 == (undefined4 *)0x0) {
      param_1 = *(char **)(iVar2 + 0x3c);
      if (0x3fff < param_1) {
        param_1 = (char *)0xffffffff;
      }
      pcVar5 = (char *)FUN_01674e20(0x1c);
      iStack_8._0_1_ = 2;
      if (pcVar5 == (char *)0x0) {
        pcVar5 = (char *)0x0;
        uVar6 = (uint)param_1;
      }
      else {
        FUN_0054eff0(pcVar1);
        *(char **)(pcVar5 + 0x18) = param_1;
        uVar6 = (uint)param_1;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      param_1 = pcVar5;
      if (0xf < *(uint *)(pcVar5 + 0x14)) {
        param_1 = *(char **)pcVar5;
      }
      if ((uint)((*(int *)(iVar2 + 0x34) - *(int *)(iVar2 + 0x30) >> 3) * 3) >> 2 <=
          *(uint *)(iVar2 + 0x3c)) {
        FUN_0086e9a0();
      }
      iVar3 = FUN_0086e740(&param_1);
      *(char **)(iVar3 + 4) = pcVar5;
      if (-1 < (int)uVar6) {
        *(char **)(&DAT_01ece3c0 + uVar6 * 4) = pcVar5;
      }
      iStack_8 = 3;
    }
    else {
      pcVar5 = (char *)*puVar4;
      iStack_8 = 1;
    }
    iVar2 = FUN_016deec8(iVar2);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    ExceptionList = pvStack_10;
    return pcVar5;
  }
  ExceptionList = pvStack_10;
  return (char *)(iVar2 + 0x48);
}



/* FUNCTION 13318 ; VA 0x0086e520 ; FUN_0086e520 */

uint __thiscall FUN_0086e520(int *param_1,undefined4 *param_2)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  byte *pbVar4;
  byte *pbVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  uint uVar10;
  int iVar11;
  bool bVar12;
  
  iVar2 = *param_1;
  if (iVar2 == param_1[1]) {
    return 0;
  }
  pbVar3 = (byte *)param_1[4];
  pbVar4 = (byte *)*param_2;
  pbVar5 = pbVar4;
  pbVar8 = pbVar3;
  do {
    bVar1 = *pbVar5;
    bVar12 = bVar1 < *pbVar8;
    if (bVar1 != *pbVar8) {
LAB_0086e580:
      uVar6 = -(uint)bVar12 | 1;
      goto LAB_0086e585;
    }
    if (bVar1 == 0) break;
    bVar1 = pbVar5[1];
    bVar12 = bVar1 < pbVar8[1];
    if (bVar1 != pbVar8[1]) goto LAB_0086e580;
    pbVar5 = pbVar5 + 2;
    pbVar8 = pbVar8 + 2;
  } while (bVar1 != 0);
  uVar6 = 0;
LAB_0086e585:
  if (uVar6 != 0) {
    uVar10 = (param_1[1] - *param_1 >> 3) - 1;
    uVar6 = FUN_0086e210(param_2);
    param_2 = (undefined4 *)0x0;
    do {
      uVar6 = uVar6 & uVar10;
      pbVar5 = *(byte **)(iVar2 + uVar6 * 8);
      iVar11 = iVar2 + uVar6 * 8;
      pbVar8 = pbVar5;
      pbVar9 = pbVar4;
      do {
        bVar1 = *pbVar8;
        bVar12 = bVar1 < *pbVar9;
        if (bVar1 != *pbVar9) {
LAB_0086e5e0:
          uVar7 = -(uint)bVar12 | 1;
          goto LAB_0086e5e5;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar8[1];
        bVar12 = bVar1 < pbVar9[1];
        if (bVar1 != pbVar9[1]) goto LAB_0086e5e0;
        pbVar8 = pbVar8 + 2;
        pbVar9 = pbVar9 + 2;
      } while (bVar1 != 0);
      uVar7 = 0;
LAB_0086e5e5:
      pbVar8 = pbVar3;
      if (uVar7 == 0) goto LAB_0086e62d;
      do {
        bVar1 = *pbVar5;
        bVar12 = bVar1 < *pbVar8;
        if (bVar1 != *pbVar8) {
LAB_0086e610:
          uVar7 = -(uint)bVar12 | 1;
          goto LAB_0086e615;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar5[1];
        bVar12 = bVar1 < pbVar8[1];
        if (bVar1 != pbVar8[1]) goto LAB_0086e610;
        pbVar5 = pbVar5 + 2;
        pbVar8 = pbVar8 + 2;
      } while (bVar1 != 0);
      uVar7 = 0;
LAB_0086e615:
      if (uVar7 == 0) break;
      uVar6 = uVar6 + 1 + (int)param_2;
      param_2 = (undefined4 *)((int)param_2 + 1);
    } while (param_2 <= uVar10);
  }
  iVar11 = 0;
LAB_0086e62d:
  return iVar11 + 4U & -(uint)(iVar11 != 0);
}



/* FUNCTION 13319 ; VA 0x0086e640 ; FUN_0086e640 */

int FUN_0086e640(void)

{
  int iVar1;
  
  iVar1 = DAT_01ede3c8;
  if (DAT_01ede3c8 == 0) {
    iVar1 = FUN_0086e660();
  }
  return iVar1 + 0x48;
}



/* FUNCTION 13320 ; VA 0x0086e660 ; FUN_0086e660 */

undefined4 FUN_0086e660(void)

{
  FUN_005789c0(&DAT_01ede3c0,FUN_0086e680);
  return DAT_01ede3c8;
}



/* FUNCTION 13321 ; VA 0x0086e680 ; FUN_0086e680 */

void FUN_0086e680(void)

{
  int iVar1;
  undefined1 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8b02;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(100);
  uStack_8 = 0;
  if (iVar1 != 0) {
    iStack_18 = iVar1;
    FUN_016dee4c(iVar1,2);
    uStack_8._0_1_ = 1;
    puStack_20 = &DAT_018bc9b8;
    uStack_1c = 0;
    FUN_0086e160(0x4000,&puStack_20,&uStack_11);
    *(undefined4 *)(iVar1 + 0x3c) = 0;
    *(undefined1 **)(iVar1 + 0x40) = &DAT_018bc9b8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0054eff0(&DAT_018bc9b8);
    *(undefined4 *)(iVar1 + 0x60) = 0xffffffff;
    DAT_01ede3c8 = iVar1;
    ExceptionList = pvStack_10;
    return;
  }
  DAT_01ede3c8 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13322 ; VA 0x0086e740 ; FUN_0086e740 */

undefined4 * __thiscall FUN_0086e740(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  int iVar3;
  uint uVar4;
  byte *pbVar5;
  uint uVar6;
  byte *pbVar7;
  byte *pbVar8;
  uint uVar9;
  uint uVar10;
  bool bVar11;
  
  iVar3 = *param_1;
  uVar9 = (param_1[1] - iVar3 >> 3) - 1;
  uVar4 = FUN_0086e210(param_2);
  uVar10 = 0;
  do {
    uVar4 = uVar4 & uVar9;
    pbVar8 = *(byte **)(iVar3 + uVar4 * 8);
    puVar1 = (undefined4 *)(iVar3 + uVar4 * 8);
    pbVar5 = pbVar8;
    pbVar7 = (byte *)param_1[4];
    do {
      bVar2 = *pbVar5;
      bVar11 = bVar2 < *pbVar7;
      if (bVar2 != *pbVar7) {
LAB_0086e7b0:
        uVar6 = -(uint)bVar11 | 1;
        goto LAB_0086e7b5;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar5[1];
      bVar11 = bVar2 < pbVar7[1];
      if (bVar2 != pbVar7[1]) goto LAB_0086e7b0;
      pbVar5 = pbVar5 + 2;
      pbVar7 = pbVar7 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_0086e7b5:
    pbVar5 = (byte *)*param_2;
    if (uVar6 == 0) {
      *puVar1 = pbVar5;
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    do {
      bVar2 = *pbVar8;
      bVar11 = bVar2 < *pbVar5;
      if (bVar2 != *pbVar5) {
LAB_0086e7e0:
        uVar6 = -(uint)bVar11 | 1;
        goto LAB_0086e7e5;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar8[1];
      bVar11 = bVar2 < pbVar5[1];
      if (bVar2 != pbVar5[1]) goto LAB_0086e7e0;
      pbVar8 = pbVar8 + 2;
      pbVar5 = pbVar5 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_0086e7e5:
    if (uVar6 == 0) {
      return puVar1;
    }
    uVar4 = uVar4 + 1 + uVar10;
    uVar10 = uVar10 + 1;
    if (uVar9 < uVar10) {
      return (undefined4 *)0x0;
    }
  } while( true );
}



/* FUNCTION 13323 ; VA 0x0086e830 ; FUN_0086e830 */

int FUN_0086e830(char *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  pcVar4 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar4 = *(char **)param_1;
  }
  iVar1 = DAT_01ede3c8;
  ExceptionList = &pvStack_10;
  if (DAT_01ede3c8 == 0) {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_0086e660();
  }
  if ((pcVar4 != (char *)0x0) && (*pcVar4 != '\0')) {
    iVar2 = FUN_016dee6d(iVar1);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    param_1 = pcVar4;
    piVar3 = (int *)FUN_0086e520(&param_1);
    if (piVar3 == (int *)0x0) {
      iVar2 = iVar1 + 0x48;
    }
    else {
      iVar2 = *piVar3;
    }
    uStack_8 = 0;
    iVar1 = FUN_016deec8(iVar1);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    ExceptionList = pvStack_10;
    return iVar2;
  }
  ExceptionList = pvStack_10;
  return iVar1 + 0x48;
}



/* FUNCTION 13324 ; VA 0x0086e8f0 ; FUN_0086e8f0 */

int FUN_0086e8f0(char *param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar2 = DAT_01ede3c8;
  ExceptionList = &pvStack_10;
  if (DAT_01ede3c8 == 0) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_0086e660();
  }
  pcVar1 = param_1;
  if ((param_1 != (char *)0x0) && (*param_1 != '\0')) {
    iVar3 = FUN_016dee6d(iVar2);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    param_1 = pcVar1;
    piVar4 = (int *)FUN_0086e520(&param_1);
    if (piVar4 == (int *)0x0) {
      iVar3 = iVar2 + 0x48;
    }
    else {
      iVar3 = *piVar4;
    }
    uStack_8 = 0;
    iVar2 = FUN_016deec8(iVar2);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    ExceptionList = pvStack_10;
    return iVar3;
  }
  ExceptionList = pvStack_10;
  return iVar2 + 0x48;
}



/* FUNCTION 13325 ; VA 0x0086e9a0 ; FUN_0086e9a0 */

void __fastcall FUN_0086e9a0(int *param_1)

{
  byte bVar1;
  byte *pbVar2;
  byte *pbVar3;
  uint uVar4;
  byte *pbVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  bool bVar11;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  byte *pbStack_18;
  undefined4 *puStack_14;
  uint uStack_10;
  int *piStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar8 = 0x10;
  }
  else {
    iVar8 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_28 = param_1[4];
  uStack_24 = 0;
  piStack_c = param_1;
  FUN_0086e160(iVar8,&iStack_28,&uStack_5);
  uStack_20 = 0;
  iVar8 = *piStack_c;
  pbVar2 = (byte *)piStack_c[4];
  iVar9 = iStack_40;
  if (piStack_c[1] - iVar8 >> 3 != 0) {
    do {
      puStack_1c = (undefined4 *)(iVar8 + uStack_20 * 8);
      pbVar5 = (byte *)piStack_c[4];
      pbStack_18 = (byte *)*puStack_1c;
      pbVar3 = pbStack_18;
      do {
        bVar1 = *pbVar3;
        bVar11 = bVar1 < *pbVar5;
        if (bVar1 != *pbVar5) {
LAB_0086ea30:
          uVar4 = -(uint)bVar11 | 1;
          goto LAB_0086ea35;
        }
        if (bVar1 == 0) break;
        bVar1 = pbVar3[1];
        bVar11 = bVar1 < pbVar5[1];
        if (bVar1 != pbVar5[1]) goto LAB_0086ea30;
        pbVar3 = pbVar3 + 2;
        pbVar5 = pbVar5 + 2;
      } while (bVar1 != 0);
      uVar4 = 0;
LAB_0086ea35:
      if (uVar4 != 0) {
        uVar10 = (iStack_3c - iVar9 >> 3) - 1;
        uStack_24 = uVar10;
        uVar4 = FUN_0086e210(puStack_1c);
        uStack_10 = 0;
        uVar4 = uVar4 & uVar10;
        do {
          pbVar5 = *(byte **)(iStack_40 + uVar4 * 8);
          puStack_14 = (undefined4 *)(iStack_40 + uVar4 * 8);
          pbVar3 = pbVar5;
          pbVar6 = pbVar2;
          do {
            bVar1 = *pbVar3;
            bVar11 = bVar1 < *pbVar6;
            if (bVar1 != *pbVar6) {
LAB_0086ea90:
              uVar10 = -(uint)bVar11 | 1;
              goto LAB_0086ea95;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar3[1];
            bVar11 = bVar1 < pbVar6[1];
            if (bVar1 != pbVar6[1]) goto LAB_0086ea90;
            pbVar3 = pbVar3 + 2;
            pbVar6 = pbVar6 + 2;
          } while (bVar1 != 0);
          uVar10 = 0;
LAB_0086ea95:
          pbVar3 = pbStack_18;
          puVar7 = puStack_14;
          if (uVar10 == 0) {
            *puStack_14 = pbStack_18;
            goto LAB_0086eae9;
          }
          do {
            bVar1 = *pbVar5;
            bVar11 = bVar1 < *pbVar3;
            if (bVar1 != *pbVar3) {
LAB_0086eac0:
              uVar10 = -(uint)bVar11 | 1;
              goto LAB_0086eac5;
            }
            if (bVar1 == 0) break;
            bVar1 = pbVar5[1];
            bVar11 = bVar1 < pbVar3[1];
            if (bVar1 != pbVar3[1]) goto LAB_0086eac0;
            pbVar5 = pbVar5 + 2;
            pbVar3 = pbVar3 + 2;
          } while (bVar1 != 0);
          uVar10 = 0;
LAB_0086eac5:
          if (uVar10 == 0) goto LAB_0086eae9;
          uVar4 = uVar4 + 1 + uStack_10;
          uStack_10 = uStack_10 + 1;
          uVar4 = uVar4 & uStack_24;
        } while (uStack_10 <= uStack_24);
        puVar7 = (undefined4 *)0x0;
LAB_0086eae9:
        *puVar7 = *puStack_1c;
        puVar7[1] = puStack_1c[1];
        iVar8 = *piStack_c;
        iVar9 = iStack_40;
      }
      uStack_20 = uStack_20 + 1;
    } while (uStack_20 < (uint)(piStack_c[1] - iVar8 >> 3));
  }
  if (piStack_c != &iStack_40) {
    *piStack_c = iVar9;
    piStack_c[1] = iStack_3c;
    iVar9 = piStack_c[2];
    piStack_c[2] = iStack_38;
    iStack_38 = iVar9;
    iVar9 = iVar8;
  }
  if (iVar9 != 0) {
    uVar4 = iStack_38 - iVar9 & 0xfffffff8;
    iVar8 = iVar9;
    if (0xfff < uVar4) {
      iVar8 = *(int *)(iVar9 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar9 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar4);
  }
  return;
}



/* FUNCTION 13326 ; VA 0x0086eb80 ; FUN_0086eb80 */

int * __fastcall FUN_0086eb80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0086f380();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    return piVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13327 ; VA 0x0086ebb0 ; thunk_FUN_0086f380 */

undefined * thunk_FUN_0086f380(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8b4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede44c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede44c);
    if (DAT_01ede44c == -1) {
      uStack_8 = 0;
      FUN_00bd6e30();
      FUN_016f3654(&LAB_01880110);
      FUN_016f37bf(&DAT_01ede44c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede3e8;
}



/* FUNCTION 13328 ; VA 0x0086ebc0 ; FUN_0086ebc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0086ebc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MessageType>::vftable;
  _DAT_01ede3dc = _DAT_01ede3dc + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 13329 ; VA 0x0086ebf0 ; FUN_0086ebf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0086ebf0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_0086f380();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ede45c) {
      FUN_016f3809(&DAT_01ede45c);
      if (DAT_01ede45c == -1) {
        _DAT_01ede450 = FUN_005c65e0;
        _DAT_01ede454 = FUN_005c65e0;
        _DAT_01ede458 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ede45c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ede450) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ede450;
  }
  return;
}



/* FUNCTION 13330 ; VA 0x0086ecb0 ; FUN_0086ecb0 */

void FUN_0086ecb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0086f380();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13331 ; VA 0x0086ecf0 ; FUN_0086ecf0 */

void FUN_0086ecf0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0086f380();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 13332 ; VA 0x0086ed30 ; FUN_0086ed30 */

void FUN_0086ed30(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00551260(&DAT_018bc9b8);
  uStack_8 = 0;
  FUN_0086f010(param_1,param_2,auStack_28,param_3);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13333 ; VA 0x0086edd0 ; FUN_0086edd0 */

void FUN_0086edd0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00551260(param_2);
  uStack_8 = 0;
  FUN_0086ed30(param_1,auStack_28,param_3);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13334 ; VA 0x0086ee70 ; FUN_0086ee70 */

void FUN_0086ee70(undefined4 *param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa5a0;
  pvStack_10 = ExceptionList;
  piVar7 = (int *)(param_2 + 0x18);
  ExceptionList = &pvStack_10;
  cVar2 = FUN_005ce6b0(piVar7,&DAT_018bc9b8);
  if (cVar2 == '\0') {
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_01675640(apppuStack_28,"%s \"%s\" failed to load: %s",param_1,param_3,param_4);
  }
  else {
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    if (0xf < *(uint *)(param_2 + 0x2c)) {
      piVar7 = (int *)*piVar7;
    }
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_01675640(apppuStack_28,"%s \"%s\" failed to load in \"%s\": %s",param_1,param_3,piVar7,
                 param_4);
  }
  uStack_8 = 0;
  cVar2 = FUN_005ce6b0(param_2,&DAT_018bc9b8);
  if (cVar2 == '\0') {
    ppppuVar4 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0086edd0(3,ppppuVar4,*(undefined4 *)(param_2 + 0x48));
  }
  else {
    uVar1 = *(undefined4 *)(param_2 + 0x48);
    uVar3 = FUN_00d108b0(aiStack_40,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0086f010(3,apppuStack_28,uVar3,uVar1);
    if (0xf < uStack_2c) {
      uVar6 = uStack_2c + 1;
      iVar5 = aiStack_40[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_40[0] + -4);
        uVar6 = uStack_2c + 0x24;
        if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
  }
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar6) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0][-1];
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13335 ; VA 0x0086eff0 ; FUN_0086eff0 */

void FUN_0086eff0(undefined4 param_1,int *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*param_2 + 4))(param_3);
  FUN_0086edd0(param_1,uVar1);
  return;
}



/* FUNCTION 13336 ; VA 0x0086f010 ; FUN_0086f010 */

void FUN_0086f010(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  uint uStack_44;
  uint uStack_40;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [8];
  undefined8 uStack_20;
  undefined4 *puStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8b30;
  pvStack_10 = ExceptionList;
  switch(param_1) {
  case 0:
  case 4:
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8d != '\0') {
      puVar3 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar3 = (undefined4 *)*param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,puVar3);
    }
    break;
  case 1:
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8d != '\0') {
      puVar3 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar3 = (undefined4 *)*param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_01677650(DAT_01d84e8d,"Info: %s",puVar3);
    }
    break;
  case 2:
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8f != '\0') {
      puVar3 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar3 = (undefined4 *)*param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_01677650(DAT_01d84e8f,"Warning: %s",puVar3);
    }
    break;
  case 3:
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8e != '\0') {
      puVar3 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar3 = (undefined4 *)*param_2;
      }
      ExceptionList = &pvStack_10;
      FUN_01677650(DAT_01d84e8e,"Error: %s",puVar3);
    }
    break;
  default:
    ExceptionList = &pvStack_10;
    if (DAT_01d84e8d != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01d84e8d,"Error: Standard Message Out set with incorrect MessageType %d",
                   param_1);
    }
  }
  if (DAT_01ede3d4 != 0) {
    uStack_60 = param_1;
    uStack_5c = param_4;
    FUN_0054ef60(param_2);
    uStack_8 = 0;
    FUN_0054ef60(param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (DAT_01d64450 == '\0') {
      FUN_0171e1b0(auStack_28);
    }
    else {
      uStack_20 = FUN_01682de0();
    }
    uStack_8 = 2;
    puStack_18 = &DAT_01ede3cc;
    uStack_14 = 0;
    LOCK();
    bVar8 = (int)DAT_01ede3cc < 0;
    DAT_01ede3cc = DAT_01ede3cc | 0x80000000;
    UNLOCK();
    uVar7 = DAT_01ede3cc;
    if (bVar8) {
      do {
        uVar4 = uVar7;
        uVar6 = uVar4 + 1;
        if (-1 < (int)uVar4) {
          uVar6 = uVar4 | 0x80000000;
        }
        LOCK();
        uVar7 = uVar4;
        uVar1 = uVar6;
        if (uVar4 != DAT_01ede3cc) {
          uVar7 = DAT_01ede3cc;
          uVar1 = DAT_01ede3cc;
        }
        DAT_01ede3cc = uVar1;
        UNLOCK();
      } while (uVar7 != uVar4);
      if (-1 < (int)uVar4) {
        uVar6 = uVar4;
      }
      if ((int)uVar6 < 0) {
        uVar2 = FUN_00554e40();
        do {
          WaitForSingleObjectEx(uVar2,0xffffffff,0);
          uVar7 = uVar6 & 0x3fffffff | 0x40000000;
          do {
            uVar6 = uVar7;
            uVar4 = uVar6;
            if (-1 < (int)uVar6) {
              uVar4 = uVar6 - 1 | 0x80000000;
            }
            LOCK();
            uVar7 = uVar6;
            uVar4 = uVar4 & 0xbfffffff;
            if (uVar6 != DAT_01ede3cc) {
              uVar7 = DAT_01ede3cc;
              uVar4 = DAT_01ede3cc;
            }
            DAT_01ede3cc = uVar4;
            UNLOCK();
          } while (uVar7 != uVar6);
        } while ((int)uVar6 < 0);
      }
    }
    uStack_14 = 1;
    uStack_8._0_1_ = 5;
    FUN_005e6780(&uStack_60);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    LOCK();
    uVar7 = DAT_01ede3cc + 0x80000000;
    UNLOCK();
    uVar6 = uVar7;
    if (((DAT_01ede3cc & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ede3cc)) {
      LOCK();
      DAT_01ede3cc = uVar7 | 0x40000000;
      UNLOCK();
      uVar6 = DAT_01ede3cc;
      if ((uVar7 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
        uVar6 = DAT_01ede3cc;
      }
    }
    DAT_01ede3cc = uVar6;
    if (0xf < uStack_2c) {
      uVar6 = uStack_2c + 1;
      uVar7 = uStack_40;
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(uStack_40 - 4);
        uVar6 = uStack_2c + 0x24;
        if (0x1f < (uStack_40 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    uStack_40 = uStack_40 & 0xffffff00;
    if (0xf < uStack_44) {
      uVar7 = uStack_44 + 1;
      iVar5 = iStack_58;
      if (0xfff < uVar7) {
        iVar5 = *(int *)(iStack_58 + -4);
        uVar7 = uStack_44 + 0x24;
        if (0x1f < (iStack_58 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13337 ; VA 0x0086f2f0 ; FUN_0086f2f0 */

void FUN_0086f2f0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675830(aiStack_28,param_2,&stack0x0000000c);
  uStack_8 = 0;
  FUN_0086ed30(param_1,aiStack_28,6);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13338 ; VA 0x0086f380 ; FUN_0086f380 */

undefined * FUN_0086f380(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8b4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede44c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede44c);
    if (DAT_01ede44c == -1) {
      uStack_8 = 0;
      FUN_00bd6e30();
      FUN_016f3654(&LAB_01880110);
      FUN_016f37bf(&DAT_01ede44c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede3e8;
}



/* FUNCTION 13339 ; VA 0x0086f410 ; FUN_0086f410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0086f410(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede45c) {
    FUN_016f3809(&DAT_01ede45c);
    if (DAT_01ede45c == -1) {
      _DAT_01ede450 = FUN_005c65e0;
      _DAT_01ede454 = FUN_005c65e0;
      _DAT_01ede458 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ede45c);
    }
  }
  return &DAT_01ede450;
}



/* FUNCTION 13340 ; VA 0x0086f480 ; FUN_0086f480 */

int * __thiscall FUN_0086f480(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017924f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  uStack_8 = 0;
  piVar3 = (int *)FUN_0086f5a0(param_2);
  iVar1 = param_1[1];
  param_1[1] = *piVar3;
  *piVar3 = iVar1;
  uStack_8._0_1_ = 1;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_14 + 4))();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 8))();
      }
    }
  }
  piVar3 = (int *)(-(uint)(param_2 != 0) & param_2 + 8U);
  if ((piVar3 != (int *)0x0) && ((piVar3[1] == 0 || (*(int *)(piVar3[1] + 4) == 0)))) {
    piVar2 = (int *)param_1[1];
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    *piVar3 = param_2;
    piVar4 = (int *)piVar3[1];
    uStack_8._0_1_ = 2;
    if (piVar2 != piVar4) {
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[2] = piVar2[2] + 1;
        UNLOCK();
        piVar4 = (int *)piVar3[1];
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[2] + -1;
        piVar4[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar4 + 8))();
        }
      }
      piVar3[1] = (int)piVar2;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = piVar2[1] + -1;
      piVar2[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar3 = piVar2 + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13341 ; VA 0x0086f5a0 ; FUN_0086f5a0 */

undefined4 * __thiscall FUN_0086f5a0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8b60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::sp_counted_impl_p<struct_boost::detail::shared_state<void>_>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13342 ; VA 0x0086f615 ; Catch_All@0086f615 */

void Catch_All_0086f615(void)

{
  int unaff_EBP;
  
  FUN_0055d6f0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13343 ; VA 0x0086f630 ; FUN_0086f630 */

/* WARNING: Removing unreachable block (ram,0x0086f7a0) */

int * __thiscall FUN_0086f630(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int aiStack_84 [9];
  int *piStack_60;
  int aiStack_5c [9];
  int *piStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8b88;
  pvStack_10 = ExceptionList;
  puStack_14 = auStack_34;
  ExceptionList = &pvStack_10;
  FUN_00871850(param_2);
  uStack_8 = 0;
  FUN_00871850(param_2 + 8);
  uStack_24 = *(undefined4 *)(param_2 + 0x10);
  uStack_20 = *(undefined4 *)(param_2 + 0x14);
  uStack_1c = *(undefined4 *)(param_2 + 0x18);
  piStack_38 = (int *)0x0;
  uStack_8 = 2;
  piStack_38 = (int *)FUN_008701e0(auStack_34);
  FUN_00872190();
  uStack_8 = 3;
  if ((piStack_38 != aiStack_5c) && (piVar1 = (int *)param_1[9], piVar1 != param_1)) {
    param_1[9] = (int)piStack_38;
    piStack_38 = piVar1;
    goto LAB_0086f7b9;
  }
  piStack_60 = (int *)0x0;
  if (piStack_38 != (int *)0x0) {
    if (piStack_38 == aiStack_5c) {
      piStack_60 = (int *)(**(code **)(*piStack_38 + 4))(aiStack_84);
      if (piStack_38 == (int *)0x0) goto LAB_0086f71a;
      (**(code **)(*piStack_38 + 0x10))(piStack_38 != aiStack_5c);
    }
    else {
      piStack_60 = piStack_38;
    }
    piStack_38 = (int *)0x0;
  }
LAB_0086f71a:
  piVar1 = (int *)param_1[9];
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_1) {
      piStack_38 = (int *)(**(code **)(*piVar1 + 4))(aiStack_5c);
      piVar1 = (int *)param_1[9];
      if (piVar1 == (int *)0x0) goto LAB_0086f765;
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_1);
      piVar1 = piStack_38;
    }
    piStack_38 = piVar1;
    param_1[9] = 0;
  }
LAB_0086f765:
  if (piStack_60 != (int *)0x0) {
    if (piStack_60 == aiStack_84) {
      iVar2 = (**(code **)(*piStack_60 + 4))(param_1);
      param_1[9] = iVar2;
      if (piStack_60 != (int *)0x0) {
        (**(code **)(*piStack_60 + 0x10))(piStack_60 != aiStack_84);
        piStack_60 = (int *)0x0;
      }
    }
    else {
      param_1[9] = (int)piStack_60;
    }
  }
LAB_0086f7b9:
  if (piStack_38 != (int *)0x0) {
    (**(code **)(*piStack_38 + 0x10))(piStack_38 != aiStack_5c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13344 ; VA 0x0086f7f0 ; FUN_0086f7f0 */

int FUN_0086f7f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8ba8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008736f0();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  puVar3 = (undefined4 *)(iVar1 + 0x28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *puVar3 = 0;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  *(undefined4 *)(iVar1 + 0x30) = 0;
  *(undefined4 *)(iVar1 + 0x34) = 0;
  *(undefined4 *)(iVar1 + 0x38) = 0;
  puVar2 = (undefined4 *)FUN_01674e20(8);
  *puVar3 = puVar2;
  *puVar2 = 0;
  puVar2[1] = 0;
  *(undefined4 **)*puVar3 = puVar3;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 13345 ; VA 0x0086f89b ; Catch_All@0086f89b */

void Catch_All_0086f89b(void)

{
  int unaff_EBP;
  
  FUN_00873e20(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13346 ; VA 0x0086f8b0 ; FUN_0086f8b0 */

undefined4 FUN_0086f8b0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8bc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005cb2b0(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 13347 ; VA 0x0086f90b ; Catch_All@0086f90b */

void Catch_All_0086f90b(void)

{
  int unaff_EBP;
  
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13348 ; VA 0x0086f930 ; FUN_0086f930 */

void FUN_0086f930(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xb;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) goto LAB_0086f9da;
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      uVar2 = puVar6[-6];
      if (0xf < uVar2) {
        uVar3 = puVar6[-0xb];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
LAB_0086f9da:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-7] = 0;
      puVar6[-6] = 0xf;
      *(undefined *)(puVar6 + -0xb) = 0;
      puVar1 = puVar6 + 3;
      puVar6 = puVar6 + 0xe;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 13349 ; VA 0x0086f9e0 ; FUN_0086f9e0 */

void FUN_0086f9e0(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xc;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) goto LAB_0086fa8a;
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      uVar2 = puVar6[-6];
      if (0xf < uVar2) {
        uVar3 = puVar6[-0xb];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
LAB_0086fa8a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-7] = 0;
      puVar6[-6] = 0xf;
      *(undefined *)(puVar6 + -0xb) = 0;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 0xd;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 13350 ; VA 0x0086fa90 ; FUN_0086fa90 */

int __thiscall FUN_0086fa90(int *param_1,int param_2,undefined4 param_3,undefined8 *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8bd0;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  iVar2 = param_1[1] - iVar3 >> 5;
  if (iVar2 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar4 = param_1[2] - iVar3 >> 5;
  uVar5 = uVar1;
  if ((uVar4 <= 0x7ffffff - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00577f40(uVar5);
  uVar4 = param_2 - iVar3 & 0xffffffe0;
  iVar3 = iVar2 + uVar4;
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  *(undefined8 *)(iVar3 + 0x18) = *param_4;
  if (param_2 == param_1[1]) {
    FUN_0055c650(*param_1,param_1[1],iVar2,param_1);
  }
  else {
    FUN_0055c650(*param_1,param_2,iVar2,param_1);
    FUN_0055c650(param_2,param_1[1],iVar3 + 0x20,param_1);
  }
  FUN_00575c60(iVar2,uVar1,uVar5);
  ExceptionList = pvStack_10;
  return *param_1 + uVar4;
}



/* FUNCTION 13351 ; VA 0x0086fb91 ; Catch_All@0086fb91 */

void Catch_All_0086fb91(void)

{
  int unaff_EBP;
  
  FUN_00576230(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13352 ; VA 0x0086fbc0 ; FUN_0086fbc0 */

int __thiscall
FUN_0086fbc0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined8 *param_5)

{
  uint uVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8be8;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  iVar4 = (param_1[1] - *param_1) / 0x38;
  if (iVar4 == 0x4924924) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar5 = (param_1[2] - *param_1) / 0x38;
  uVar8 = uVar1;
  if ((uVar5 <= 0x4924924 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar6 = FUN_0082c100(uVar8);
  uStack_8 = 0;
  iVar7 = ((param_2 - iVar3) / 0x38) * 0x38;
  iVar3 = iVar7 + iVar6;
  uVar2 = *param_5;
  FUN_0054ef60(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_4);
  *(undefined8 *)(iVar3 + 0x30) = uVar2;
  if (param_2 == param_1[1]) {
    FUN_008709c0(*param_1,param_1[1],iVar6,param_1);
  }
  else {
    FUN_008709c0(*param_1,param_2,iVar6,param_1);
    FUN_008709c0(param_2,param_1[1],iVar3 + 0x38,param_1);
  }
  FUN_00873710(iVar6,iVar4 + 1,uVar8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar7;
}



/* FUNCTION 13353 ; VA 0x0086fd24 ; Catch_All@0086fd24 */

void Catch_All_0086fd24(void)

{
  int unaff_EBP;
  
  FUN_00873a60(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_00875970(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13354 ; VA 0x0086fd50 ; FUN_0086fd50 */

int __thiscall FUN_0086fd50(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined4 *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8c00;
  pvStack_10 = ExceptionList;
  iVar7 = *param_1;
  iVar11 = (int)param_2 - iVar7 >> 3;
  iVar4 = param_1[1] - iVar7 >> 3;
  if (iVar4 == 0x1fffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar8 = param_1[2] - iVar7 >> 3;
  uVar5 = uVar1;
  if ((uVar8 <= 0x1fffffff - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  uVar8 = uVar5 * 8;
  if (uVar5 < 0x20000000) {
    if (0xfff < uVar8) goto LAB_0086fde0;
    if (uVar8 == 0) {
      puVar12 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar12 = (undefined4 *)FUN_01674e20(uVar8);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_0086fde0:
    uVar6 = uVar8 + 0x23;
    if (uVar6 <= uVar8) {
      uVar6 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_0086ff4f;
    puVar12 = (undefined4 *)(iVar7 + 0x23U & 0xffffffe0);
    puVar12[-1] = iVar7;
  }
  uStack_8 = 0;
  FUN_00871850(param_3);
  puVar2 = (undefined4 *)param_1[1];
  if (param_2 == puVar2) {
    puVar3 = (undefined4 *)*param_1;
    puVar9 = puVar12;
    if (puVar3 != puVar2) {
      puVar10 = puVar3;
      do {
        *puVar9 = *puVar10;
        iVar7 = *(int *)((int)puVar9 + (int)puVar3 + (4 - (int)puVar12));
        puVar9[1] = iVar7;
        if (iVar7 != 0) {
          LOCK();
          *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
          UNLOCK();
        }
        puVar10 = puVar10 + 2;
        puVar9 = puVar9 + 2;
      } while (puVar10 != puVar2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00559650(puVar9,puVar9,param_1);
  }
  else {
    FUN_00873fb0(*param_1,param_2,puVar12);
    FUN_00873fb0(param_2,param_1[1],puVar12 + iVar11 * 2 + 2);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00559650(*param_1,param_1[1],param_1);
    iVar7 = *param_1;
    uVar8 = param_1[2] - iVar7 & 0xfffffff8;
    iVar4 = iVar7;
    if (0xfff < uVar8) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_0086ff4f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar8);
  }
  *param_1 = (int)puVar12;
  param_1[1] = (int)(puVar12 + uVar1 * 2);
  param_1[2] = (int)(puVar12 + uVar5 * 2);
  ExceptionList = pvStack_10;
  return *param_1 + iVar11 * 8;
}



/* FUNCTION 13355 ; VA 0x0086ff25 ; Catch_All@0086ff25 */

void Catch_All_0086ff25(void)

{
  int unaff_EBP;
  
  FUN_00873aa0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d330(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13356 ; VA 0x0086ff60 ; FUN_0086ff60 */

int __thiscall
FUN_0086ff60(uint *param_1,uint param_2,undefined *param_3,undefined4 param_4,undefined4 param_5)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8c1b;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  iVar3 = (int)(param_1[1] - uVar2) / 0x34;
  if (iVar3 == 0x4ec4ec4) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar3 + 1;
  uVar4 = (int)(param_1[2] - uVar2) / 0x34;
  uVar8 = uVar6;
  if ((uVar4 <= 0x4ec4ec4 - (uVar4 >> 1)) && (uVar8 = (uVar4 >> 1) + uVar4, uVar8 < uVar6)) {
    uVar8 = uVar6;
  }
  uVar6 = uVar8 * 0x34;
  if (uVar8 < 0x4ec4ec5) {
    uVar8 = uVar6;
    if (0xfff < uVar6) goto LAB_00870019;
    if (uVar6 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00870019:
    uVar4 = uVar8 + 0x23;
    if (uVar4 <= uVar8) {
      uVar4 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_00870171;
    uVar8 = iVar5 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar5;
  }
  iVar5 = ((int)(param_2 - uVar2) / 0x34) * 0x34;
  puVar1 = (undefined *)(iVar5 + uVar8);
  uStack_8 = 0;
  *puVar1 = *param_3;
  FUN_0054ef60(param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_5);
  if (param_2 == param_1[1]) {
    FUN_00870a70(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_00870a70(*param_1,param_2,uVar8,param_1);
    FUN_00870a70(param_2,param_1[1],puVar1 + 0x34,param_1);
  }
  if (*param_1 != 0) {
    FUN_0086f9e0(*param_1,param_1[1],param_1);
    uVar2 = *param_1;
    uVar7 = ((int)(param_1[2] - uVar2) / 0x34) * 0x34;
    uVar4 = uVar2;
    if (0xfff < uVar7) {
      uVar4 = *(uint *)(uVar2 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar2 - uVar4) - 4) {
LAB_00870171:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar7);
  }
  *param_1 = uVar8;
  param_1[1] = (iVar3 + 1) * 0x34 + uVar8;
  param_1[2] = uVar6 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 13357 ; VA 0x00870148 ; Catch_All@00870148 */

void Catch_All_00870148(void)

{
  int unaff_EBP;
  
  FUN_00873a80(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_006bd430(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13358 ; VA 0x00870180 ; FUN_00870180 */

undefined4 * FUN_00870180(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::_Func_impl_no_alloc<class_<lambda_be228b3da3db7d400b30a15e16049664>,void>::vftable;
  puVar2[2] = *param_1;
  iVar1 = param_1[1];
  puVar2[3] = iVar1;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
  }
  puVar2[4] = param_1[2];
  iVar1 = param_1[3];
  puVar2[5] = iVar1;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
  }
  puVar2[6] = param_1[4];
  puVar2[7] = param_1[5];
  puVar2[8] = param_1[6];
  return puVar2;
}



/* FUNCTION 13359 ; VA 0x008701e0 ; FUN_008701e0 */

undefined4 * FUN_008701e0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8c38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  uStack_8 = 0;
  *puVar1 = std::_Func_impl_no_alloc<class_<lambda_be228b3da3db7d400b30a15e16049664>,void>::vftable;
  FUN_00871850(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00871850(param_1 + 8);
  puVar1[6] = *(undefined4 *)(param_1 + 0x10);
  puVar1[7] = *(undefined4 *)(param_1 + 0x14);
  puVar1[8] = *(undefined4 *)(param_1 + 0x18);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 13360 ; VA 0x00870263 ; Catch_All@00870263 */

void Catch_All_00870263(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13361 ; VA 0x00870280 ; FUN_00870280 */

void __thiscall FUN_00870280(int param_1,int *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8c50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar2 = param_3[4];
  puVar8 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar8 = (undefined4 *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (uVar2 != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)puVar8);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < uVar2);
  }
  iVar9 = (*(uint *)(param_1 + 0x18) & uVar10) * 8;
  piVar12 = *(int **)(param_1 + 4);
  piVar5 = (int *)(*(int *)(param_1 + 0xc) + iVar9);
  ExceptionList = &pvStack_10;
  if (piVar12 != (int *)*piVar5) {
    piVar12 = *(int **)piVar5[1];
    ExceptionList = &pvStack_10;
    while (piVar12 != (int *)*piVar5) {
      piVar12 = (int *)piVar12[1];
      piVar11 = piVar12 + 2;
      if (0xf < (uint)piVar12[7]) {
        piVar11 = (int *)*piVar11;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar4 = FUN_0055c360(puVar8,uVar2,piVar11,piVar12[6]);
      if (cVar4 != '\0') {
        *param_2 = (int)piVar12;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  uStack_8 = 0xffffffff;
  iVar3 = **(int **)(param_1 + 4);
  puVar8 = *(undefined4 **)(iVar3 + 4);
  uVar6 = FUN_0086f8b0(iVar3,puVar8,param_3);
  if (*(int *)(param_1 + 8) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *(undefined4 *)(iVar3 + 4) = uVar6;
  *puVar8 = uVar6;
  piVar5 = *(int **)(param_1 + 4);
  puVar8 = (undefined4 *)*piVar5;
  piVar11 = (int *)*puVar8;
  if (piVar12 != piVar11) {
    *(int **)puVar8[1] = piVar11;
    *(int **)piVar11[1] = piVar12;
    *(undefined4 **)piVar12[1] = puVar8;
    iVar3 = piVar12[1];
    piVar12[1] = piVar11[1];
    piVar11[1] = puVar8[1];
    puVar8[1] = iVar3;
    piVar5 = *(int **)(param_1 + 4);
  }
  piVar11 = (int *)(iVar9 + *(int *)(param_1 + 0xc));
  if ((int *)*piVar11 == piVar5) {
    *piVar11 = (int)puVar8;
    *(undefined4 **)(*(int *)(param_1 + 0xc) + 4 + iVar9) = puVar8;
  }
  else if ((int *)*piVar11 == piVar12) {
    *piVar11 = (int)puVar8;
  }
  else {
    iVar3 = *(int *)piVar11[1];
    piVar11[1] = iVar3;
    if ((undefined4 *)iVar3 != puVar8) {
      iVar9 = iVar9 + *(int *)(param_1 + 0xc);
      *(undefined4 *)(iVar9 + 4) = *(undefined4 *)(*(int *)(iVar9 + 4) + 4);
    }
  }
  uStack_8 = 2;
  FUN_005cb370();
  *param_2 = (int)puVar8;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13362 ; VA 0x00870430 ; Catch_All@00870430 */

void Catch_All_00870430(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_005cc1c0(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13363 ; VA 0x00870470 ; FUN_00870470 */

void __thiscall
FUN_00870470(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x4444442 < (uint)param_1[1]) {
    FUN_00873ac0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00870522:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00870522;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 13364 ; VA 0x008705d0 ; FUN_008705d0 */

undefined4 * __thiscall
FUN_008705d0(int *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8c60;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00870470(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar5 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar5 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar5,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_00870470(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_00870470(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00870470(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00870470(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar4 = (int *)FUN_00551320();
      piVar3 = piStack_18;
      if ((*piVar4 == *param_1) || (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00870470(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00870470(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_00870830(auStack_20,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13365 ; VA 0x00870818 ; Catch_All@00870818 */

void Catch_All_00870818(void)

{
  int unaff_EBP;
  
  FUN_00873ac0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13366 ; VA 0x00870830 ; FUN_00870830 */

void __thiscall
FUN_00870830(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,int param_5)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  byte bVar4;
  int *piVar5;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_4;
  puStack_c = &LAB_017b8c70;
  piVar7 = (int *)*param_1;
  bVar4 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar7[1] + 0xd);
  piVar5 = piVar7;
  piVar2 = (int *)piVar7[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar5 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      FUN_0055c2d0(puVar9,puVar6[4],piVar5,piVar2[8]);
      bVar4 = extraout_var_00 >> 7;
    }
    else {
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_0055c2d0(piVar5,piVar2[8],puVar9,puVar6[4]);
      bVar4 = extraout_var >> 7 ^ 1;
    }
    if (bVar4 == 0) {
      piVar10 = (int *)piVar2[2];
    }
    else {
      piVar10 = (int *)*piVar2;
    }
    piVar5 = piVar2;
    piVar2 = piVar10;
    cVar1 = *(char *)((int)piVar10 + 0xd);
  }
  param_3 = piVar5;
  if (bVar4 != 0) {
    if (piVar5 == (int *)*piVar7) {
      bVar4 = 1;
      goto LAB_008708fc;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar7 = param_3 + 4;
  puVar9 = puVar6;
  if (0xf < (uint)puVar6[5]) {
    puVar9 = (undefined4 *)*puVar6;
  }
  if (0xf < (uint)param_3[9]) {
    piVar7 = (int *)*piVar7;
  }
  iVar8 = FUN_0055c2d0(piVar7,param_3[8],puVar9,puVar6[4]);
  iVar3 = param_5;
  if (-1 < iVar8) {
    FUN_00870c10(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar3,0x3c);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_008708fc:
  puVar6 = (undefined4 *)FUN_00870470(&param_3,bVar4,piVar5,puVar6,param_5);
  *param_2 = *puVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13367 ; VA 0x0087099e ; Catch_All@0087099e */

void Catch_All_0087099e(void)

{
  int unaff_EBP;
  
  FUN_00873ac0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13368 ; VA 0x008709c0 ; FUN_008709c0 */

undefined4 *
FUN_008709c0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 0xb;
    do {
      puVar6[4] = 0;
      puVar6[5] = 0;
      puVar1 = puVar5 + 3;
      uVar2 = puVar5[-10];
      uVar3 = puVar5[-9];
      uVar4 = puVar5[-8];
      *puVar6 = puVar5[-0xb];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -7);
      puVar5[-7] = 0;
      puVar5[-6] = 0xf;
      *(undefined *)(puVar5 + -0xb) = 0;
      puVar6[10] = 0;
      *(undefined4 *)((int)param_3 + (-0x38 - (int)param_1) + (int)(puVar5 + 0xe)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      puVar6[6] = puVar5[-5];
      puVar6[7] = uVar2;
      puVar6[8] = uVar3;
      puVar6[9] = uVar4;
      *(undefined8 *)(puVar6 + 10) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      *(undefined8 *)(puVar6 + 0xc) = *(undefined8 *)(puVar5 + 1);
      puVar6 = puVar6 + 0xe;
      puVar5 = puVar5 + 0xe;
    } while (puVar1 != param_2);
  }
  FUN_0086f930(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 13369 ; VA 0x00870a70 ; FUN_00870a70 */

undefined *
FUN_00870a70(undefined4 *param_1,undefined4 *param_2,undefined *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined *puVar7;
  
  puVar7 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 6;
    puVar6 = (undefined8 *)(param_3 + 0x2c);
    do {
      *puVar7 = *(undefined *)(puVar5 + -6);
      *(undefined4 *)(puVar6 + -3) = 0;
      puVar1 = puVar5 + 7;
      *(undefined4 *)(param_3 + (-0x34 - (int)param_1) + (int)(puVar5 + 0xd)) = 0;
      puVar7 = puVar7 + 0x34;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *(undefined4 *)(puVar6 + -5) = puVar5[-5];
      *(undefined4 *)((int)puVar6 + -0x24) = uVar2;
      *(undefined4 *)(puVar6 + -4) = uVar3;
      *(undefined4 *)((int)puVar6 + -0x1c) = uVar4;
      puVar6[-3] = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      *(undefined4 *)puVar6 = 0;
      *(undefined4 *)((int)puVar6 + 4) = 0;
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      uVar4 = puVar5[4];
      *(undefined4 *)(puVar6 + -2) = puVar5[1];
      *(undefined4 *)((int)puVar6 + -0xc) = uVar2;
      *(undefined4 *)(puVar6 + -1) = uVar3;
      *(undefined4 *)((int)puVar6 + -4) = uVar4;
      *puVar6 = *(undefined8 *)(puVar5 + 5);
      puVar5[5] = 0;
      puVar5[6] = 0xf;
      *(undefined *)(puVar5 + 1) = 0;
      puVar5 = puVar5 + 0xd;
      puVar6 = (undefined8 *)((int)puVar6 + 0x34);
    } while (puVar1 != param_2);
  }
  FUN_0086f9e0(puVar7,puVar7,param_4);
  return puVar7;
}



/* FUNCTION 13370 ; VA 0x00870b20 ; FUN_00870b20 */

undefined4 *
FUN_00870b20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
    piVar1 = param_6 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  piVar1 = param_6 + 1;
  *param_1 = param_3;
  param_1[1] = param_4;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_5;
  param_1[3] = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 13371 ; VA 0x00870c10 ; FUN_00870c10 */

void FUN_00870c10(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_00592290();
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 13372 ; VA 0x00870c70 ; FUN_00870c70 */

void FUN_00870c70(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = param_2[6];
  if (iVar1 != 0) {
    uVar3 = param_2[8] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00870d02;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_2[6] = 0;
    param_2[7] = 0;
    param_2[8] = 0;
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar1 = *param_2;
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00870d02:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 13373 ; VA 0x00870d10 ; FUN_00870d10 */

void __thiscall FUN_00870d10(int param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8c8b;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined **)(param_1 + 4);
  if (*(undefined **)(param_1 + 8) != puVar1) {
    ExceptionList = &pvStack_10;
    *puVar1 = *param_2;
    FUN_0054ef60(param_3);
    uStack_8 = 0;
    FUN_0054ef60(param_4);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x34;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0086ff60(puVar1,param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13374 ; VA 0x00870da0 ; FUN_00870da0 */

undefined4 * FUN_00870da0(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x4c);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf1<void,class_RBX::DeferredEphemeral,class_std::shared_ptr<struct_`anonymous_namespace'::SharedState>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::DeferredEphemeral*>,class_boost::_bi::value<class_std::shared_ptr<struct_`anonymous_namespace'::SharedState>_>_>_>_>
              ::vftable;
    puVar3[0xf] = *param_1;
    puVar3[0x10] = param_1[1];
    puVar3[0x11] = 0;
    puVar3[0x12] = 0;
    puVar3[0x11] = param_1[2];
    puVar3[0x12] = param_1[3];
    param_1[2] = 0;
    param_1[3] = 0;
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 13375 ; VA 0x00870e38 ; Catch_All@00870e38 */

void Catch_All_00870e38(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13376 ; VA 0x00870e70 ; FUN_00870e70 */

undefined4 * FUN_00870e70(undefined4 *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8cc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = GetProcessHeap(0,0x4c);
  puVar3 = (undefined4 *)HeapAlloc(uVar2);
  if (puVar3 != (undefined4 *)0x0) {
    uStack_8 = 1;
    FUN_0056b3c0();
    *puVar3 = boost::detail::
              thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf1<void,class_RBX::Analytics::EventIngest::DeferredReporter,class_std::shared_ptr<struct_`anonymous_namespace'::SharedState>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::Analytics::EventIngest::DeferredReporter*>,class_boost::_bi::value<class_std::shared_ptr<struct_`anonymous_namespace'::SharedState>_>_>_>_>
              ::vftable;
    puVar3[0xf] = *param_1;
    puVar3[0x10] = param_1[1];
    puVar3[0x11] = 0;
    puVar3[0x12] = 0;
    puVar3[0x11] = param_1[2];
    puVar3[0x12] = param_1[3];
    param_1[2] = 0;
    param_1[3] = 0;
    ExceptionList = pvStack_10;
    return puVar3;
  }
  uVar2 = FUN_0054fbc0();
  uStack_8 = 0;
  FUN_005648a0(uVar2);
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined4 *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 13377 ; VA 0x00870f08 ; Catch_All@00870f08 */

void Catch_All_00870f08(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13378 ; VA 0x00870f40 ; FUN_00870f40 */

void __thiscall FUN_00870f40(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x18,param_1);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_`anonymous_namespace'::SharedState>::vftable;
    *(undefined8 *)(puVar1 + 3) = 0;
    puVar1[5] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *(undefined *)(puVar1 + 5) = 0;
    *param_2 = (int)(puVar1 + 3);
    param_2[1] = (int)puVar1;
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 13379 ; VA 0x00870fb0 ; FUN_00870fb0 */

void FUN_00870fb0(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  int *piVar3;
  undefined4 uVar4;
  void **ppvVar5;
  char *pcVar6;
  int iVar7;
  void *apvStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8d03;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00879010(apvStack_18,param_1,param_2);
  uStack_8 = 0;
  ppvVar5 = apvStack_18;
  do {
    piVar1 = (int *)ppvVar5[1];
    piVar3 = (int *)*ppvVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 1;
    if (piVar3 == (int *)0x0) {
      uVar4 = FUN_0056acb0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00564940(uVar4);
      pcVar2 = (code *)swi(3);
      (*pcVar2)();
      return;
    }
    piVar3 = (int *)(**(code **)(*piVar3 + 0x14))();
    iVar7 = *(int *)(*piVar3 + 0x70);
    if (iVar7 == 0) {
      iVar7 = *(int *)(*piVar3 + 0xc);
      if (((iVar7 != 200) && (iVar7 != 0xcc)) && (DAT_01ede471 != '\0')) {
        pcVar6 = "PointsList::send failed with HTTP status code %d";
        goto LAB_0087104b;
      }
    }
    else if (DAT_01ede471 != '\0') {
      pcVar6 = "PointsList::send failed with error %d";
LAB_0087104b:
      FUN_016774b0(DAT_01ede471,pcVar6,iVar7);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[1] + -1;
      piVar1[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar1 + 4))();
        LOCK();
        iVar7 = piVar1[2] + -1;
        piVar1[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar1 + 8))();
        }
      }
    }
    ppvVar5 = ppvVar5 + 2;
    if (ppvVar5 == &pvStack_10) {
      uStack_8 = 0xffffffff;
      FUN_016f32d1(apvStack_18,8,1,FUN_00550ad0);
      ExceptionList = pvStack_10;
      return;
    }
  } while( true );
}



/* FUNCTION 13380 ; VA 0x008710d0 ; FUN_008710d0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_008710d0(undefined4 param_1,uint param_2,int param_3)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined8 uVar9;
  undefined **appuStack_bc [15];
  undefined4 uStack_80;
  undefined4 auStack_7c [3];
  undefined4 uStack_70;
  undefined **appuStack_6c [18];
  undefined auStack_24 [8];
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b8d3f;
  pvStack_10 = ExceptionList;
  appuStack_bc[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_6c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_70 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_bc + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_bc[0][1] + (int)appuStack_bc) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_bc[0][1] + (int)&stack0xffffff40) = appuStack_bc[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_bc[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_80 = 0;
  auStack_7c[0] = 4;
  uStack_8 = 3;
  if (((param_2 == 0) && (param_3 == -0x80000000)) ||
     ((param_2 == 0xffffffff && (param_3 == 0x7fffffff)))) {
    if ((param_2 == 0xfffffffe) && (param_3 == 0x7fffffff)) goto LAB_008711e2;
    if ((param_2 == 0) && (param_3 == -0x80000000)) {
      iVar1 = 1;
    }
    else if ((param_2 == 0xffffffff) && (param_3 == 0x7fffffff)) {
      iVar1 = 2;
    }
    else {
      iVar1 = 5;
    }
  }
  else {
    if ((param_2 != 0xfffffffe) || (param_3 != 0x7fffffff)) {
      uStack_1c = 0;
      iVar1 = FUN_00874e00(&uStack_1c);
      if (iVar1 == -1) {
        FUN_005ed940(appuStack_bc,0x2d);
      }
      puVar2 = (undefined4 *)FUN_016df519(auStack_24,2,0);
      (*(code *)*puVar2)(appuStack_bc[0][1] + (int)appuStack_bc,puVar2[2],puVar2[3]);
      *(undefined *)((int)auStack_7c + (int)appuStack_bc[0][1]) = 0x30;
      uVar3 = FUN_016f3900(param_2,param_3,3600000000,0);
      uVar4 = FUN_005af260((uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f),&DAT_018c3838);
      FUN_00558890(uVar4);
      puVar2 = (undefined4 *)FUN_016df519(auStack_24,2,0);
      (*(code *)*puVar2)(appuStack_bc[0][1] + (int)appuStack_bc,puVar2[2],puVar2[3]);
      *(undefined *)((int)auStack_7c + (int)appuStack_bc[0][1]) = 0x30;
      uVar9 = FUN_016f3900(param_2,param_3,60000000,0);
      uVar3 = FUN_016f4270(uVar9,0x3c,0);
      uVar4 = FUN_005af260((uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f),&DAT_018c3838);
      FUN_00558890(uVar4);
      puVar2 = (undefined4 *)FUN_016df519(auStack_24,2,0);
      (*(code *)*puVar2)(appuStack_bc[0][1] + (int)appuStack_bc,puVar2[2],puVar2[3]);
      *(undefined *)((int)auStack_7c + (int)appuStack_bc[0][1]) = 0x30;
      uVar9 = FUN_016f3900(param_2,param_3,1000000,0);
      uVar3 = FUN_016f4270(uVar9,0x3c,0);
      FUN_005af260((uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f));
      uVar9 = FUN_016f3900(param_2,param_3,1000000,0);
      uVar9 = FUN_016f39b0(uVar9,1000000,0);
      uVar6 = (param_3 - (int)((ulonglong)uVar9 >> 0x20)) - (uint)(param_2 < (uint)uVar9);
      uVar3 = (int)uVar6 >> 0x1f;
      uVar7 = param_2 - (uint)uVar9 ^ uVar3;
      iVar8 = uVar7 - uVar3;
      iVar1 = ((uVar6 ^ uVar3) - uVar3) - (uint)(uVar7 < uVar3);
      if (iVar8 != 0 || iVar1 != 0) {
        piVar5 = (int *)FUN_00558890(appuStack_bc,&DAT_018c1030);
        puVar2 = (undefined4 *)FUN_016df519(auStack_24,6,0);
        (*(code *)*puVar2)(*(int *)(*piVar5 + 4) + (int)piVar5,puVar2[2],puVar2[3]);
        *(undefined *)(*(int *)(*piVar5 + 4) + 0x40 + (int)piVar5) = 0x30;
        FUN_00872bd0(iVar8,iVar1);
      }
      goto LAB_00871443;
    }
LAB_008711e2:
    iVar1 = 0;
  }
  if (iVar1 == 0) {
    FUN_00558890(appuStack_bc,"not-a-date-time");
  }
  else if (iVar1 == 1) {
    FUN_00558890(appuStack_bc,"-infinity");
  }
  else if (iVar1 == 2) {
    FUN_00558890(appuStack_bc,"+infinity");
  }
  else {
    FUN_00558890(appuStack_bc,&DAT_018bc9b8);
  }
LAB_00871443:
  FUN_0058c400(param_1);
  *(undefined ***)(appuStack_bc[0][1] + (int)appuStack_bc) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_bc[0][1] + (int)&stack0xffffff40) = appuStack_bc[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_bc[0][1] + (int)appuStack_bc) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_bc[0][1] + (int)&stack0xffffff40) = appuStack_bc[0][1] + -8;
  uStack_8 = 4;
  appuStack_6c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_6c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13381 ; VA 0x008714e0 ; FUN_008714e0 */

/* WARNING: Removing unreachable block (ram,0x0087159b) */

undefined4 FUN_008714e0(uint *param_1)

{
  uint uVar1;
  char cVar2;
  uint *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  bool bVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  undefined auStack_3c [8];
  undefined auStack_34 [8];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  undefined auStack_20 [8];
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8d58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0168eb30(&uStack_2c);
  while( true ) {
    puVar3 = (uint *)FUN_0168ea80(auStack_34);
    iVar9 = *param_1 - *puVar3;
    uVar1 = (uint)(*param_1 < *puVar3);
    iVar10 = param_1[1] - puVar3[1];
    iVar8 = iVar10 - uVar1;
    if ((iVar8 < 0) ||
       ((iVar8 == 0 || (SBORROW4(param_1[1],puVar3[1]) != SBORROW4(iVar10,uVar1)) != iVar8 < 0 &&
        (iVar9 == 0)))) {
      ExceptionList = pvStack_10;
      return 0;
    }
    lVar12 = FUN_016f39b0(uStack_2c,uStack_28,100,0);
    lVar12 = lVar12 + CONCAT44(iVar8,iVar9);
    uStack_18 = (uint)lVar12;
    puVar4 = (undefined4 *)FUN_0168eb30(auStack_3c);
    uVar13 = FUN_016f39b0(*puVar4,puVar4[1],100,0);
    bVar11 = uStack_18 < (uint)uVar13;
    uStack_18 = uStack_18 - (uint)uVar13;
    iVar10 = ((int)((ulonglong)lVar12 >> 0x20) - (int)((ulonglong)uVar13 >> 0x20)) - (uint)bVar11;
    lVar12 = FUN_016f3900(uStack_18,iVar10,1000000,0);
    lVar14 = FUN_016f39b0(lVar12,1000000,0);
    if (lVar14 < CONCAT44(iVar10,uStack_18)) {
      lVar12 = lVar12 + 1;
    }
    piVar5 = (int *)FUN_01689dd0(auStack_20);
    piVar6 = (int *)FUN_01689df0(auStack_24);
    if (*piVar5 == *piVar6) break;
    cVar2 = FUN_01689a20(lVar12,&cStack_11);
    if ((cVar2 != '\0') && (cStack_11 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  uVar7 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar7);
}



/* FUNCTION 13382 ; VA 0x00871630 ; FUN_00871630 */

/* WARNING: Removing unreachable block (ram,0x0087169b) */

undefined4 FUN_00871630(undefined4 param_1,int *param_2)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  longlong lVar4;
  undefined auStack_14 [8];
  uint uStack_c;
  int iStack_8;
  
  if ((0 < param_2[1]) || ((-1 < param_2[1] && (*param_2 != 0)))) {
    FUN_0168ea80(&uStack_c);
    FUN_005ef740(*param_2,param_2[1]);
    FUN_00560fc0(param_1);
    puVar3 = (uint *)FUN_0168ea80(auStack_14);
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    lVar4 = FUN_016f39b0(*param_2,param_2[1],1000000,0);
    if (CONCAT44((uVar2 - iStack_8) - (uint)(uVar1 < uStack_c),uVar1 - uStack_c) < lVar4) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 13383 ; VA 0x008716c0 ; FUN_008716c0 */

/* WARNING: Removing unreachable block (ram,0x00871787) */

undefined4 __thiscall FUN_008716c0(int param_1,uint *param_2)

{
  uint uVar1;
  bool bVar2;
  uint *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  undefined auStack_34 [8];
  uint uStack_2c;
  int iStack_28;
  uint *puStack_24;
  char cStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796188;
  pvStack_10 = ExceptionList;
  cStack_20 = '\0';
  puStack_24 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00587410();
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x19) == '\0') {
    FUN_0057df90(&puStack_24);
    if (*(char *)(param_1 + 0x18) == '\0') {
      iStack_1c = param_1 + 0x2c;
      do {
        FUN_0168ea80(&uStack_2c);
        if (((int)param_2[1] < iStack_28) ||
           (((int)param_2[1] <= iStack_28 && (*param_2 <= uStack_2c)))) {
LAB_00871835:
          if (*(char *)(iStack_14 + 0x18) == '\0') {
            uVar5 = 1;
            goto LAB_008717e6;
          }
          break;
        }
        iStack_18 = *param_2 - uStack_2c;
        iVar6 = (param_2[1] - iStack_28) - (uint)(*param_2 < uStack_2c);
        lVar7 = FUN_016f3900(iStack_18,iVar6,1000000,0);
        lVar8 = FUN_016f39b0(lVar7,1000000,0);
        if (lVar8 < CONCAT44(iVar6,iStack_18)) {
          lVar7 = lVar7 + 1;
        }
        FUN_005ef740(lVar7);
        FUN_00560fc0(&puStack_24);
        puVar3 = (uint *)FUN_0168ea80(auStack_34);
        if (((int)param_2[1] < (int)puVar3[1]) ||
           (((int)param_2[1] <= (int)puVar3[1] && (*param_2 <= *puVar3)))) {
          bVar2 = true;
        }
        else {
          bVar2 = false;
        }
        if (bVar2) goto LAB_00871835;
      } while (*(char *)(iStack_14 + 0x18) == '\0');
    }
    uVar5 = 0;
  }
  else {
    uVar5 = 2;
  }
LAB_008717e6:
  uStack_8 = 1;
  if (cStack_20 != '\0') {
    LOCK();
    uVar1 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 13384 ; VA 0x00871850 ; FUN_00871850 */

undefined4 * __thiscall FUN_00871850(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  iVar2 = param_2[1];
  param_1[1] = iVar2;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  *param_2 = 0;
  piVar3 = (int *)param_2[1];
  param_2[1] = 0;
  uStack_8 = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  *param_2 = 0;
  piVar3 = (int *)param_2[1];
  param_2[1] = 0;
  uStack_8 = 1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13385 ; VA 0x00871920 ; FUN_00871920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_00871920(undefined *param_1,int param_2)

{
  uint *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  float10 fVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8d80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  fVar7 = (float10)FUN_01725280(((double)*(int *)(param_2 + 8) +
                                (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 8) >> 0x1f)]) /
                                (double)*(float *)(param_2 + 0xc));
  if ((double)fVar7 + DAT_018c0d60 < _DAT_018c4e98) {
    FUN_016f3eb1();
  }
  uVar4 = FUN_00588320();
  puVar1 = (uint *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  *puVar1 = uVar4;
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  if (*(int *)(param_2 + 8) != 0) {
    FUN_005d2b00();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (*(int *)(param_2 + 8) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar3 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
    while (puVar6 != (undefined4 *)0x0) {
      puVar5 = (undefined4 *)FUN_01674e20();
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5[2] = 0;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;
      *(undefined8 *)(puVar5 + 6) = 0;
      puVar5[8] = 0;
      FUN_0054ef60();
      puVar5[8] = puVar6[8];
      puVar5[1] = puVar6[1];
      *puVar3 = puVar5;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar2 = (undefined4 *)*puVar3;
      puVar6 = (undefined4 *)*puVar6;
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *puVar1) * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *puVar1) * 4) == 0) {
        *puVar5 = puVar3;
        puVar3 = puVar2;
      }
      else {
        *puVar3 = *puVar2;
        *puVar2 = *(undefined4 *)*puVar5;
        *(undefined4 **)*puVar5 = puVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13386 ; VA 0x00871b00 ; FUN_00871b00 */

int * __fastcall FUN_00871b00(int *param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined **appuStack_50 [7];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b8df4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  puStack_2c = (undefined4 *)0x120;
  uStack_8 = 3;
  uStack_7 = 0;
  uStack_30 = 0x871b68;
  puVar4 = (undefined4 *)FUN_01674e20();
  uStack_8 = 4;
  puStack_18 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<class_RBX::Analytics::EphemeralCounter::EphemeralCounterState>::
              vftable;
    puStack_2c = (undefined4 *)0x871b94;
    FUN_00871d70();
  }
  uStack_8 = 3;
  *param_1 = (int)(puVar4 + 4);
  piVar1 = (int *)param_1[1];
  param_1[1] = (int)puVar4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_2c = (undefined4 *)0x871bbf;
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_2c = (undefined4 *)0x871bcf;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_2c = (undefined4 *)0xa0;
  uStack_30 = 0x871bd9;
  puVar4 = (undefined4 *)FUN_01674e20();
  uStack_8 = 5;
  puStack_18 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<class_RBX::Analytics::EventIngest::EventIngestState>::vftable;
    puStack_2c = (undefined4 *)0x871c05;
    FUN_00871f40();
  }
  uStack_8 = 3;
  param_1[2] = (int)(puVar4 + 3);
  piVar1 = (int *)param_1[3];
  param_1[3] = (int)puVar4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_2c = (undefined4 *)0x871c2e;
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_2c = (undefined4 *)0x871c3e;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_2c = (undefined4 *)0x1c;
  uStack_30 = 0x871c45;
  puVar4 = (undefined4 *)FUN_01674e20();
  uStack_8 = 6;
  puStack_18 = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puStack_2c = (undefined4 *)&uStack_11;
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<class_RBX::Analytics::Event::GAReporterState>::vftable;
    uStack_30 = 2;
    puVar4[3] = 0;
    uStack_34 = 0x871c7e;
    FUN_0071edc0();
  }
  uStack_8 = 3;
  param_1[4] = (int)(puVar4 + 3);
  piVar1 = (int *)param_1[5];
  param_1[5] = (int)puVar4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_2c = (undefined4 *)0x871ca8;
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_2c = (undefined4 *)0x871cb8;
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puStack_2c = (undefined4 *)0x8;
  uStack_30 = 0x871cc5;
  DAT_01ede460 = param_1;
  puStack_18 = (undefined4 *)FUN_01674e20();
  if (puStack_18 == (undefined4 *)0x0) {
    DAT_01ede464 = (undefined4 *)0x0;
  }
  else {
    *puStack_18 = 0;
    puStack_18[1] = 0;
    DAT_01ede464 = puStack_18;
  }
  if ((DAT_020c0b1c != '\0') && (DAT_01d6271c != '\0')) {
    puStack_2c = appuStack_50;
    appuStack_50[0] =
         std::_Func_impl_no_alloc<class_<lambda_3761ec029eb34b896717deca76820f8a>,void>::vftable;
    uVar5 = FUN_014ca6e0(&puStack_18);
    _uStack_8 = CONCAT31(uStack_7,7);
    uStack_30 = 0x871d20;
    puStack_2c = (undefined4 *)uVar5;
    cVar3 = FUN_01679300();
    if (cVar3 != '\0') {
      puStack_2c = (undefined4 *)0x871d2c;
      FUN_01679490();
      uStack_30 = 0x871d35;
      puStack_2c = (undefined4 *)uVar5;
      FUN_016791c0();
    }
    if (puStack_18 != (undefined4 *)0x0) {
      piVar1 = puStack_18 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_2c = puStack_18;
        uStack_30 = 0x871d50;
        FUN_01674ea0();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13387 ; VA 0x00871d70 ; FUN_00871d70 */

undefined * __fastcall FUN_00871d70(undefined *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8e79;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 1;
  FUN_00870f40(param_1 + 8);
  uStack_8 = 0;
  FUN_00610ca0();
  *(undefined4 *)(param_1 + 0x18) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x1c) = 0x7fffffff;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  param_1[0x4c] = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 0x50) = uVar1;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  uStack_8._0_1_ = 4;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  uVar1 = FUN_005cb2b0(0,0);
  *(undefined4 *)(param_1 + 0x68) = uVar1;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *(undefined4 *)(param_1 + 100) = 0x3f800000;
  FUN_005cb500(8);
  *(undefined4 *)(param_1 + 0xac) = 0;
  uStack_8 = 7;
  FUN_016dee4c(param_1 + 0xb0,2);
  uStack_8._0_1_ = 8;
  FUN_0075dc70();
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x100) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  *(undefined4 *)(param_1 + 0x104) = 0;
  *(undefined4 *)(param_1 + 0x108) = 0;
  uVar1 = FUN_00575b30();
  *(undefined4 *)(param_1 + 0x104) = uVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13388 ; VA 0x00871f40 ; FUN_00871f40 */

undefined * __fastcall FUN_00871f40(undefined *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8edf;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puStack_14 = param_1;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 4) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  param_1[0x18] = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 0x1c) = uVar1;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  param_1[0x30] = 0;
  uVar1 = FUN_00588320(0xb);
  *(undefined4 *)(param_1 + 0x34) = uVar1;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  uStack_8._0_1_ = 2;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  puStack_18 = param_1 + 0x48;
  FUN_005542c0("EventIngest TimerThread",0x17);
  uStack_8._0_1_ = 3;
  FUN_00870f40(param_1 + 0x48);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_34);
  uStack_8._0_1_ = 5;
  FUN_00610ca0();
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0;
  puVar4 = (undefined4 *)(param_1 + 0x8c);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  *puVar4 = 0;
  *(undefined4 *)(param_1 + 0x90) = 0;
  puStack_1c = puVar4;
  uVar1 = FUN_008736d0();
  *puVar4 = uVar1;
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar2 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13389 ; VA 0x008720e0 ; thunk_FUN_00872190 */

void * __fastcall thunk_FUN_00872190(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0xc);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  uStack_8 = 1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 13390 ; VA 0x008720f0 ; FUN_008720f0 */

void __fastcall FUN_008720f0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00559650(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13391 ; VA 0x00872130 ; FUN_00872130 */

void __fastcall FUN_00872130(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00870c10(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x34);
  }
  return;
}



/* FUNCTION 13392 ; VA 0x00872160 ; FUN_00872160 */

void __fastcall FUN_00872160(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00870c70(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x2c);
  }
  return;
}



/* FUNCTION 13393 ; VA 0x00872190 ; FUN_00872190 */

void * __fastcall FUN_00872190(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0xc);
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  uStack_8 = 1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*piVar3 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 13394 ; VA 0x00872220 ; FUN_00872220 */

uint __fastcall FUN_00872220(uint *param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined **ppuStack_38;
  undefined auStack_34 [16];
  undefined auStack_24 [8];
  uint *puStack_1c;
  char cStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  uVar6 = *param_1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (uVar6 != 0) {
    puStack_1c = (uint *)(uVar6 + 0x24);
    cStack_18 = '\0';
    ExceptionList = &pvStack_10;
    uVar6 = FUN_00587410();
    uVar3 = *param_1;
    if ((*(char *)(uVar3 + 0x18) == '\0') && (*(char *)(uVar3 + 0x20) == '\0')) {
      uVar7 = FUN_0168a9f0();
      FUN_0056abb0(1,uVar7);
      ppuStack_38 = boost::broken_promise::vftable;
      puVar8 = (undefined4 *)FUN_0055dd80(auStack_24,&ppuStack_38);
      uVar7 = *puVar8;
      iVar4 = puVar8[1];
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
      }
      *(undefined4 *)(uVar3 + 0x10) = uVar7;
      piVar5 = *(int **)(uVar3 + 0x14);
      *(int *)(uVar3 + 0x14) = iVar4;
      uStack_8 = 0;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
          LOCK();
          iVar4 = piVar5[2] + -1;
          piVar5[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 8))();
          }
        }
      }
      uStack_8 = 0xffffffff;
      FUN_00587e20(&puStack_1c);
      FUN_00550ad0();
      ppuStack_38 = std::exception::vftable;
      uVar6 = FUN_0170c289(auStack_34);
      param_1 = puStack_14;
    }
    uStack_8 = 1;
    if (cStack_18 != '\0') {
      LOCK();
      uVar6 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
        LOCK();
        uVar3 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar3 >> 0x1e & 1) == 0) {
          uVar7 = FUN_00554e40();
          uVar6 = SetEvent(uVar7);
        }
      }
    }
  }
  piVar5 = (int *)param_1[1];
  uStack_8 = 2;
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar6 = (**(code **)(*piVar5 + 4))();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar6 = (**(code **)(*piVar5 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 13395 ; VA 0x00872390 ; FUN_00872390 */

void __fastcall FUN_00872390(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008759c0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 13396 ; VA 0x00872410 ; FUN_00872410 */

void __fastcall FUN_00872410(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00870c70(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 13397 ; VA 0x008724c0 ; FUN_008724c0 */

void __fastcall FUN_008724c0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_008759c0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 13398 ; VA 0x008724d0 ; FUN_008724d0 */

void __fastcall FUN_008724d0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0086f930(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13399 ; VA 0x00872550 ; FUN_00872550 */

void __fastcall FUN_00872550(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0086f9e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x34) * 0x34;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13400 ; VA 0x008725d0 ; FUN_008725d0 */

/* WARNING: Removing unreachable block (ram,0x0087266a) */
/* WARNING: Removing unreachable block (ram,0x0087267d) */
/* WARNING: Removing unreachable block (ram,0x00872684) */
/* WARNING: Removing unreachable block (ram,0x0087268b) */

int __fastcall FUN_008725d0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d6271c != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_0087b360();
  }
  FUN_00587410();
  *param_1 = 0;
  piVar1 = (int *)param_1[1];
  param_1[1] = 0;
  param_1[2] = 0;
  piVar2 = (int *)param_1[3];
  param_1[3] = 0;
  param_1[4] = 0;
  piVar3 = (int *)param_1[5];
  param_1[5] = 0;
  uStack_8 = 0;
  DAT_01ede460 = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = 1;
  iVar5 = FUN_01679490();
  iVar4 = param_1[6];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    iVar5 = iVar5 + -1;
    if (iVar5 == 0) {
      iVar5 = FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[5];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      iVar5 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[3];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      iVar5 = *piVar2;
      *piVar2 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[1];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13401 ; VA 0x008727c0 ; FUN_008727c0 */

int __fastcall FUN_008727c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d62724 != '\0')) &&
     (ExceptionList = &pvStack_10, *(int **)(param_1 + 0xa4) != (int *)0x0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(param_1 + 0xa4) + 8))();
  }
  piVar3 = *(int **)(param_1 + 0xa4);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))
              (CONCAT31((int3)((uint)*piVar3 >> 8),piVar3 != (int *)(param_1 + 0x80)));
    *(undefined4 *)(param_1 + 0xa4) = 0;
  }
  FUN_005cafb0();
  FUN_005d1280();
  FUN_0056d3e0();
  iVar5 = *(int *)(param_1 + 0x34);
  if ((iVar5 != 0) && (iVar5 != -1)) {
    CloseHandle(iVar5);
  }
  FUN_0056d500();
  LOCK();
  iVar5 = *(int *)(param_1 + 0x1c);
  *(int *)(param_1 + 0x1c) = 0;
  UNLOCK();
  if (iVar5 != 0) {
    CloseHandle(iVar5);
  }
  uStack_8 = 0;
  iVar5 = FUN_016899e0();
  puVar4 = *(undefined4 **)(param_1 + 8);
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    piVar3 = puVar4 + 1;
    iVar2 = *piVar3;
    iVar5 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*puVar4)(0);
      uVar6 = GetProcessHeap(0,puVar4);
      iVar5 = HeapFree(uVar6);
    }
  }
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13402 ; VA 0x008728e0 ; FUN_008728e0 */

void __fastcall FUN_008728e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0087c860();
  piVar2 = *(int **)(param_1 + 0x48);
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 8))();
      }
    }
  }
  FUN_008724d0();
  piVar2 = *(int **)(param_1 + 0x34);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016dedfb(param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13403 ; VA 0x00872980 ; FUN_00872980 */

int __fastcall FUN_00872980(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_1 + 0x44);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00873d90(*(undefined4 *)(iVar5 + 4));
  *(int *)(*(int *)(param_1 + 0x44) + 4) = iVar5;
  **(int **)(param_1 + 0x44) = iVar5;
  *(int *)(*(int *)(param_1 + 0x44) + 8) = iVar5;
  *(undefined4 *)(param_1 + 0x48) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x44),0x3c);
  iVar5 = *(int *)(param_1 + 0x40);
  if ((iVar5 != 0) && (iVar5 != -1)) {
    CloseHandle(iVar5);
  }
  FUN_0056d500();
  LOCK();
  iVar5 = *(int *)(param_1 + 0x28);
  *(int *)(param_1 + 0x28) = 0;
  UNLOCK();
  if (iVar5 != 0) {
    CloseHandle(iVar5);
  }
  uStack_8 = 1;
  iVar5 = FUN_016899e0();
  puVar2 = *(undefined4 **)(param_1 + 0x20);
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    piVar4 = puVar2 + 1;
    iVar7 = *piVar4;
    iVar5 = *piVar4;
    *piVar4 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      (**(code **)*puVar2)(0);
      uVar6 = GetProcessHeap(0,puVar2);
      iVar5 = HeapFree(uVar6);
    }
  }
  uVar3 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar3) {
    iVar5 = *(int *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    iVar7 = iVar5;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar5 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar5 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar7,uVar8);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar7 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13404 ; VA 0x00872ac0 ; FUN_00872ac0 */

void __fastcall FUN_00872ac0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01521ff0();
  FUN_016dedfb(param_1 + 0xc);
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13405 ; VA 0x00872b10 ; FUN_00872b10 */

undefined4 * __thiscall FUN_00872b10(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  iVar2 = param_2[1];
  uVar3 = *param_2;
  ExceptionList = &pvStack_10;
  if (iVar2 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  *param_1 = uVar3;
  piVar4 = (int *)param_1[1];
  param_1[1] = iVar2;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  *param_2 = 0;
  piVar4 = (int *)param_2[1];
  param_2[1] = 0;
  uStack_8 = 1;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[1] + -1;
    piVar4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13406 ; VA 0x00872bd0 ; FUN_00872bd0 */

int * __thiscall FUN_00872bd0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  undefined *puVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  uint uStack_38;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8f08;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar7 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  puVar2 = &stack0xffffffbc;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) {
    piStack_20 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_1c = piStack_20;
    (**(code **)(*piStack_20 + 4))();
    uStack_8._0_1_ = 3;
    piStack_20 = (int *)FUN_00564aa0(auStack_24);
    uStack_8._0_1_ = 4;
    if ((piStack_1c != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_1c + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,
                                 *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    uVar8 = *(undefined4 *)(iVar7 + 0x38);
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    (**(code **)(*piStack_20 + 0x1c))(&param_2,uStack_38,uVar8,iVar7,piStack_1c,param_2,param_3);
    piVar5 = (int *)FUN_00872cfe(uStack_38,uVar8);
    return piVar5;
  }
  uVar1 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar1 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar1;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13407 ; VA 0x00872cdf ; Catch_All@00872cdf */

undefined * Catch_All_00872cdf(void)

{
  FUN_005565b0(4,1);
  return &DAT_00872cf8;
}



/* FUNCTION 13408 ; VA 0x00872cfe ; FUN_00872cfe */

void FUN_00872cfe(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 13409 ; VA 0x00872d70 ; FUN_00872d70 */

int * __thiscall FUN_00872d70(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  byte *pbVar9;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8f30;
  pvStack_10 = ExceptionList;
  pbVar9 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_0055c740(pbVar9,param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar5,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
  if (param_2 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  piVar3 = (int *)FUN_01674e20(0x34);
  piStack_18 = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_20 = piVar3;
  FUN_0170d1f0(piStack_18,0,0x2c);
  uStack_1c = CONCAT11(uStack_1c._1_1_,1);
  FUN_0054ef60(aiStack_3c);
  piVar7 = piVar3 + 8;
  *piVar7 = 0;
  piVar3[9] = 0;
  piVar3[10] = 0;
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  param_2 = piVar7;
  puVar4 = (undefined4 *)FUN_01674e20(8);
  *piVar7 = (int)puVar4;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  *puVar4 = 0;
  puVar4[1] = 0;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  *(int **)*piVar7 = piVar7;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar8 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = (int *)0x1;
    uVar6 = uVar1 >> 1;
    if ((uVar1 >> 1) + uVar1 <= uVar8) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar1);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar4;
      while (puVar2 != (undefined4 *)0x0) {
        piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar7 = (int)puVar4;
          puVar4 = puVar2;
        }
        else {
          *puVar4 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar7;
          *(undefined4 **)*piVar7 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar4;
      }
    }
  }
  piVar3[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar3;
    }
    *puVar4 = piVar7;
    *piVar3 = *piVar7;
  }
  else {
    *piVar3 = *piVar7;
    piVar7 = (int *)*puVar4;
  }
  *piVar7 = (int)piVar3;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 13410 ; VA 0x00872fd0 ; FUN_00872fd0 */

int * __thiscall FUN_00872fd0(byte *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8f50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0055c740(param_1 + *param_1 + 1,param_2);
  uStack_14 = uVar4 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
    uVar10 = uStack_14;
    if (puVar11 == (undefined4 *)0x0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)*puVar11;
    }
    for (; puVar11 != (undefined4 *)0x0; puVar11 = (undefined4 *)*puVar11) {
      if (uVar4 == puVar11[1]) {
        piVar5 = puVar11 + 2;
        if (0xf < (uint)puVar11[7]) {
          piVar5 = (int *)*piVar5;
        }
        puVar7 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar7 = (undefined4 *)*param_2;
        }
        cVar3 = FUN_0055c360(puVar7,param_2[4],piVar5,puVar11[6]);
        uVar10 = uStack_14;
        if (cVar3 != '\0') {
          if (puVar11 != (undefined4 *)0x0) {
            ExceptionList = pvStack_10;
            return puVar11 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar11[1] % *(uint *)(param_1 + 4) != uVar10) break;
    }
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(param_2);
  iStack_8._0_1_ = 1;
  FUN_00874f50();
  piVar5 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar5[8] = 0;
  piVar5[9] = 0;
  piVar5[10] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar10 = uStack_28 + 1;
    iVar6 = aiStack_3c[0];
    if (0xfff < uVar10) {
      iVar6 = *(int *)(aiStack_3c[0] + -4);
      uVar10 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar10 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar10 = FUN_005d6bb0(uVar10);
    if (uVar10 <= *(uint *)(param_1 + 4)) {
      uVar10 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar10);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar10) {
    uStack_14 = 1;
    uVar8 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar10) {
      uVar8 = 1;
    }
    iVar6 = FUN_005d6bb0(uVar8 + uVar2);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar11;
      while (puVar7 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar7[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar7[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar11;
          puVar11 = puVar7;
        }
        else {
          *puVar11 = *puVar7;
          *puVar7 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar7;
        }
        puVar7 = (undefined4 *)*puVar11;
      }
    }
  }
  piVar5[1] = uVar4;
  uVar4 = uVar4 % *(uint *)(param_1 + 4);
  piVar9 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar9 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar9 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *piVar1 = (int)piVar9;
    *piVar5 = *piVar9;
  }
  else {
    *piVar5 = *piVar9;
    piVar9 = (int *)*piVar1;
  }
  *piVar9 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 13411 ; VA 0x00873240 ; FUN_00873240 */

int __thiscall FUN_00873240(int *param_1,int param_2,char *param_3)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined uVar4;
  int iVar5;
  undefined4 *puVar6;
  char *pcVar7;
  uint uVar8;
  char *pcVar9;
  undefined ***pppuVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  undefined4 *puVar14;
  undefined **appuStack_5c [4];
  uint auStack_4c [4];
  undefined4 uStack_3c;
  undefined ***pppuStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8f90;
  pvStack_10 = ExceptionList;
  pcVar9 = (char *)(((int *)*param_1)[3] * 0x34 + *(int *)*param_1);
  ExceptionList = &pvStack_10;
  if (*pcVar9 != '\0') {
    iVar12 = (int)((*(double *)(*(int *)((int)param_3 + 0x90) + 0xd0) -
                   *(double *)(*(int *)((int)param_3 + 0x90) + 200)) * DAT_018c0d70);
    if (param_2 == 0) {
      iVar13 = *(int *)((int)param_3 + 0xc);
    }
    else {
      iVar13 = 500;
      if (param_2 == 5) {
        iVar13 = 0x28a;
      }
    }
    ExceptionList = &pvStack_10;
    param_3 = (char *)iVar13;
    iStack_14 = iVar12;
    iVar5 = FUN_00872fd0(pcVar9 + 0x1c);
    piVar2 = *(int **)(iVar5 + 0x1c);
    if (*(int **)(iVar5 + 0x20) == piVar2) {
      FUN_006c2580(piVar2,&param_3,&iStack_14);
    }
    else {
      *piVar2 = iVar13;
      piVar2[1] = iVar12;
      *(int *)(iVar5 + 0x1c) = *(int *)(iVar5 + 0x1c) + 8;
    }
  }
  *(int *)(*param_1 + 0xc) = *(int *)(*param_1 + 0xc) + 1;
  piVar2 = (int *)*param_1;
  if ((uint)piVar2[3] < (uint)((piVar2[1] - *piVar2) / 0x34)) {
    iVar12 = FUN_00876eb0(param_1);
  }
  else {
    FUN_014c9d60(&iStack_1c,0);
    iVar12 = *param_1;
    iStack_8 = 0;
    pcVar9 = (char *)&DAT_01d62784;
    if (0xf < DAT_01d62798) {
      pcVar9 = DAT_01d62784;
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    param_3 = pcVar9 + 1;
    pcVar7 = pcVar9;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar9,(int)pcVar7 - (int)param_3);
    iStack_8._0_1_ = 1;
    puVar6 = (undefined4 *)FUN_00d82830(auStack_4c,auStack_34,iVar12 + 0x10);
    puVar14 = puVar6 + 4;
    iStack_8._0_1_ = 2;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_014cbbc0(puVar6,*puVar14);
    iStack_8._0_1_ = 1;
    uVar4 = (undefined)iStack_8;
    iStack_8._0_1_ = 1;
    if (&DAT_0000000f < pppuStack_38) {
      pppuVar10 = (undefined ***)((int)pppuStack_38 + 1);
      uVar8 = auStack_4c[0];
      if ((undefined ***)0xfff < pppuVar10) {
        uVar8 = *(uint *)(auStack_4c[0] - 4);
        pppuVar10 = pppuStack_38 + 9;
        if (0x1f < (auStack_4c[0] - uVar8) - 4) {
LAB_008735fe:
          iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,pppuVar10);
    }
    uStack_3c = 0;
    pppuStack_38 = (undefined ***)0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    iStack_8._0_1_ = 0;
    uVar4 = (undefined)iStack_8;
    iStack_8._0_1_ = 0;
    if (0xf < uStack_20) {
      uVar11 = uStack_20 + 1;
      uVar8 = auStack_34[0];
      if (0xfff < uVar11) {
        uVar8 = *(uint *)(auStack_34[0] - 4);
        uVar11 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar8) - 4) {
          iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar11);
    }
    FUN_014cba40();
    appuStack_5c[0] =
         std::
         _Func_impl_no_alloc<class_<lambda_d69c79dd7ac1ccba628dca25efe6aaa8>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
         ::vftable;
    *(undefined4 *)(iStack_1c + 0xb0) = 0x17;
    pppuStack_38 = appuStack_5c;
    iStack_8._0_1_ = 3;
    iVar12 = FUN_014cb530(pppuStack_38);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (pppuStack_38 != (undefined ***)0x0) {
      iVar12 = (*(code *)(*pppuStack_38)[4])
                         (CONCAT31((int3)((uint)appuStack_5c >> 8),pppuStack_38 != appuStack_5c));
    }
    iVar13 = *param_1;
    if (*(int *)(iVar13 + 0x18) == 0) {
      puVar14 = (undefined4 *)0x0;
    }
    else {
      iVar12 = *(int *)(iVar13 + 0x14);
      puVar14 = *(undefined4 **)(*(int *)(iVar13 + 0x24) + iVar12 * 4);
    }
    for (; puVar14 != (undefined4 *)0x0; puVar14 = (undefined4 *)*puVar14) {
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      FUN_0151f9c0("DatacenterId",DAT_01d7a884);
      FUN_0151f950("NS1JobId",puVar14 + 2);
      iVar12 = puVar14[9];
      if (iVar12 - (int)puVar14[8] >> 3 != 0) {
        FUN_0151f9c0("HttpStatus_0",*(undefined4 *)puVar14[8]);
        FUN_0151f9c0("Latency_0",*(undefined4 *)(puVar14[8] + 4));
        iVar12 = puVar14[9];
      }
      if (1 < (uint)(iVar12 - puVar14[8] >> 3)) {
        FUN_0151f9c0("HttpStatus_1",*(undefined4 *)(puVar14[8] + 8));
        FUN_0151f9c0("Latency_1",*(undefined4 *)(puVar14[8] + 0xc));
      }
      uVar3 = DAT_01ede478;
      uStack_24 = 0;
      uStack_20 = 0xf;
      auStack_34[0] = auStack_34[0] & 0xffffff00;
      FUN_005542c0("CDNProbe",8);
      iStack_8._0_1_ = 5;
      FUN_01520d20(auStack_34,uVar3,0);
      iStack_8._0_1_ = 4;
      if (0xf < uStack_20) {
        uVar11 = uStack_20 + 1;
        uVar8 = auStack_34[0];
        if (0xfff < uVar11) {
          uVar8 = *(uint *)(auStack_34[0] - 4);
          uVar11 = uStack_20 + 0x24;
          uVar4 = (undefined)iStack_8;
          if (0x1f < (auStack_34[0] - uVar8) - 4) goto LAB_008735fe;
        }
        FUN_01674ea0(uVar8,uVar11);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      iVar12 = FUN_0151f7f0();
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_18 + 1;
      iVar13 = *piVar2;
      iVar12 = *piVar2;
      *piVar2 = iVar13 + -1;
      UNLOCK();
      if (iVar13 + -1 == 0) {
        iVar12 = (**(code **)*piStack_18)();
        LOCK();
        piVar2 = piStack_18 + 2;
        iVar13 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar13 == 1) {
          iVar12 = (**(code **)(*piStack_18 + 4))();
          ExceptionList = pvStack_10;
          return iVar12;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar12;
}



/* FUNCTION 13412 ; VA 0x00873610 ; FUN_00873610 */

undefined4 __thiscall FUN_00873610(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x120);
  }
  return param_1;
}



/* FUNCTION 13413 ; VA 0x00873640 ; FUN_00873640 */

undefined4 __thiscall FUN_00873640(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa0);
  }
  return param_1;
}



/* FUNCTION 13414 ; VA 0x00873670 ; FUN_00873670 */

int __thiscall FUN_00873670(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x48);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x4c);
  }
  return param_1;
}



/* FUNCTION 13415 ; VA 0x008736d0 ; FUN_008736d0 */

void FUN_008736d0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x3c);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 13416 ; VA 0x008736f0 ; FUN_008736f0 */

void __fastcall FUN_008736f0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x3c);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 13417 ; VA 0x00873710 ; FUN_00873710 */

void __thiscall FUN_00873710(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0086f930(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x38;
  param_1[2] = param_2 + param_4 * 0x38;
  return;
}



/* FUNCTION 13418 ; VA 0x008737b0 ; FUN_008737b0 */

void FUN_008737b0(undefined4 *param_1)

{
  *param_1 = std::_Func_impl_no_alloc<class_<lambda_3761ec029eb34b896717deca76820f8a>,void>::vftable
  ;
  return;
}



/* FUNCTION 13419 ; VA 0x008737c0 ; FUN_008737c0 */

void __thiscall FUN_008737c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_452f6d49855ace27422a33bc8b4a02f8>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 13420 ; VA 0x008737e0 ; FUN_008737e0 */

void __fastcall FUN_008737e0(int param_1)

{
  FUN_00870180(param_1 + 8);
  return;
}



/* FUNCTION 13421 ; VA 0x008737f0 ; FUN_008737f0 */

void __thiscall FUN_008737f0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_d3ebc6a19a443874f9916506d6289c0a>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 13422 ; VA 0x00873830 ; FUN_00873830 */

void FUN_00873830(undefined4 *param_1)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_d69c79dd7ac1ccba628dca25efe6aaa8>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  return;
}



/* FUNCTION 13423 ; VA 0x00873840 ; FUN_00873840 */

void __thiscall FUN_00873840(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_da95e8bdf458e2e5dcb161163bda11ea>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 13424 ; VA 0x00873880 ; FUN_00873880 */

void __thiscall FUN_00873880(undefined4 param_1,char param_2)

{
  FUN_00872190();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  return;
}



/* FUNCTION 13425 ; VA 0x008738b0 ; FUN_008738b0 */

void FUN_008738b0(void)

{
  FUN_00872410();
  FUN_00872550();
  return;
}



/* FUNCTION 13426 ; VA 0x008738d0 ; FUN_008738d0 */

void __fastcall FUN_008738d0(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x10);
  *(int *)(param_1 + 0x10) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 13427 ; VA 0x008738f0 ; FUN_008738f0 */

void FUN_008738f0(void)

{
  FUN_00872220();
  return;
}



/* FUNCTION 13428 ; VA 0x00873900 ; FUN_00873900 */

void __fastcall FUN_00873900(int param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179a980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087b440();
  iVar2 = *(int *)(param_1 + 0x114);
  piVar1 = (int *)(param_1 + 0x114);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00576720(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  *(undefined4 *)(param_1 + 0x118) = 0;
  FUN_01674ea0(*piVar1,0x28);
  LOCK();
  iVar2 = *(int *)(param_1 + 0x110);
  *(int *)(param_1 + 0x110) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  FUN_008728e0();
  FUN_008727c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13429 ; VA 0x008739a0 ; FUN_008739a0 */

void FUN_008739a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087b530();
  FUN_00872980();
  FUN_0056cfd0();
  FUN_0056cfd0();
  FUN_00872390();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13430 ; VA 0x00873a00 ; FUN_00873a00 */

void __fastcall FUN_00873a00(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x18) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  return;
}



/* FUNCTION 13431 ; VA 0x00873a60 ; FUN_00873a60 */

void __thiscall FUN_00873a60(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0086f930(param_2,param_3,param_1);
  return;
}



/* FUNCTION 13432 ; VA 0x00873a80 ; FUN_00873a80 */

void __thiscall FUN_00873a80(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0086f9e0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 13433 ; VA 0x00873aa0 ; FUN_00873aa0 */

void __thiscall FUN_00873aa0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00559650(param_2,param_3,param_1);
  return;
}



/* FUNCTION 13434 ; VA 0x00873ac0 ; FUN_00873ac0 */

void __thiscall FUN_00873ac0(undefined4 param_1,int param_2)

{
  FUN_00870c10(param_1,param_2 + 0x10);
  FUN_01674ea0(param_2,0x3c);
  return;
}



/* FUNCTION 13435 ; VA 0x00873af0 ; thunk_FUN_0087b360 */

int thunk_FUN_0087b360(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b99c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d6271c != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_014d27d0();
  }
  FUN_00876700(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_0087b440();
  }
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  iVar3 = FUN_00876840(&iStack_20);
  uStack_8 = 1;
  if (iStack_20 != 0) {
    iVar3 = FUN_0087b530();
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13436 ; VA 0x00873b00 ; FUN_00873b00 */

undefined4 __thiscall FUN_00873b00(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8fa8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 4);
  iVar3 = iVar1 + 0xc;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(iVar3);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_8 = 0;
  if (DAT_01d625e8 < (uint)(*(int *)(iVar1 + 0x3c) + *(int *)(param_2 + 0x10))) {
    if (DAT_01ede471 != '\0') {
      FUN_016774b0(DAT_01ede471,"PointsList::push exceeded DFInt::PointsListMaxDataSize",0);
    }
    uStack_8 = 1;
    iVar3 = FUN_016deec8(iVar3);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  if (*(int *)(param_2 + 0x10) != 0) {
    if (*(int *)(iVar1 + 8) == *(int *)(iVar1 + 4)) {
      FUN_00559960(*(int *)(iVar1 + 4),param_2);
    }
    else {
      FUN_0054ef60(param_2);
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0x18;
    }
    *(int *)(iVar1 + 0x3c) = *(int *)(iVar1 + 0x3c) + *(int *)(param_2 + 0x10);
  }
  uStack_8 = 2;
  iVar3 = FUN_016deec8(iVar3);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 13437 ; VA 0x00873c00 ; FUN_00873c00 */

void __fastcall FUN_00873c00(int param_1)

{
  int iVar1;
  char cVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8fc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0168a370();
  iVar1 = param_1 + 0x18;
  if (cVar2 != '\0') {
    FUN_008714e0(iVar1);
  }
  if (*(int *)(param_1 + 8) != 0) {
    FUN_008716c0(iVar1);
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_008716c0(iVar1);
  }
  if (DAT_01ede471 != '\0') {
    FUN_016774b0(DAT_01ede471,"Request shutdown returning",0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13438 ; VA 0x00873c80 ; FUN_00873c80 */

void FUN_00873c80(undefined4 *param_1,undefined4 param_2)

{
  FUN_00873240(*param_1,param_2);
  return;
}



/* FUNCTION 13439 ; VA 0x00873ca0 ; FUN_00873ca0 */

void __thiscall FUN_00873ca0(int param_1,undefined4 *param_2,int param_3)

{
  uint uVar1;
  code *pcVar2;
  int *piVar3;
  undefined4 uVar4;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ede471 != '\0') {
    piVar3 = (int *)(param_3 + 0x40);
    if (0xf < *(uint *)(param_3 + 0x54)) {
      piVar3 = (int *)*piVar3;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ede471,
                 "DeferredEphemeralV2::flush StatusCode: %d\nHttpErrorCode: %d\nBody: %s",
                 *(undefined4 *)(param_3 + 0xc),*param_2,piVar3);
  }
  piVar3 = *(int **)(param_1 + 4);
  FUN_00876cb0();
  puStack_18 = (uint *)(*piVar3 + 0x24);
  cStack_14 = '\0';
  FUN_00587410();
  uStack_8 = 0;
  if (*(char *)(*piVar3 + 0x18) == '\0') {
    FUN_00587e20(&puStack_18);
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar4 = FUN_0056b140();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005649e0(uVar4);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 13440 ; VA 0x00873d90 ; FUN_00873d90 */

void FUN_00873d90(int *param_1)

{
  char cVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  do {
    if (cVar1 != '\0') {
      return;
    }
    FUN_00873d90(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00592290();
    uVar3 = param_1[9];
    if (0xf < uVar3) {
      iVar4 = param_1[4];
      uVar6 = uVar3 + 1;
      iVar5 = iVar4;
      if (0xfff < uVar6) {
        iVar5 = *(int *)(iVar4 + -4);
        uVar6 = uVar3 + 0x24;
        if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    param_1[8] = 0;
    param_1[9] = 0xf;
    *(undefined *)(param_1 + 4) = 0;
    FUN_01674ea0(param_1,0x3c);
    cVar1 = *(char *)((int)piVar2 + 0xd);
    param_1 = piVar2;
  } while( true );
}



/* FUNCTION 13441 ; VA 0x00873e20 ; FUN_00873e20 */

void FUN_00873e20(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x3c);
  return;
}



/* FUNCTION 13442 ; VA 0x00873e40 ; FUN_00873e40 */

undefined4 * __thiscall FUN_00873e40(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8ff8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = std::_Func_impl_no_alloc<class_<lambda_be228b3da3db7d400b30a15e16049664>,void>::vftable
  ;
  FUN_00871850(param_1 + 8);
  uStack_8 = 0;
  FUN_00871850(param_1 + 0x10);
  param_2[6] = *(undefined4 *)(param_1 + 0x18);
  param_2[7] = *(undefined4 *)(param_1 + 0x1c);
  param_2[8] = *(undefined4 *)(param_1 + 0x20);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13443 ; VA 0x00873eb0 ; FUN_00873eb0 */

void __thiscall FUN_00873eb0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_da95e8bdf458e2e5dcb161163bda11ea>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 13444 ; VA 0x00873ef0 ; FUN_00873ef0 */

void __thiscall FUN_00873ef0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_0082c100(param_2);
  FUN_008709c0(*param_1,param_1[1],uVar3,param_1);
  FUN_00873710(uVar3,(iVar1 - iVar2) / 0x38,param_2);
  return;
}



/* FUNCTION 13445 ; VA 0x00873f50 ; FUN_00873f50 */

TypeDescriptor * FUN_00873f50(void)

{
  return &<lambda_3761ec029eb34b896717deca76820f8a>::RTTI_Type_Descriptor;
}



/* FUNCTION 13446 ; VA 0x00873f60 ; FUN_00873f60 */

TypeDescriptor * FUN_00873f60(void)

{
  return &<lambda_452f6d49855ace27422a33bc8b4a02f8>::RTTI_Type_Descriptor;
}



/* FUNCTION 13447 ; VA 0x00873f70 ; FUN_00873f70 */

TypeDescriptor * FUN_00873f70(void)

{
  return &<lambda_be228b3da3db7d400b30a15e16049664>::RTTI_Type_Descriptor;
}



/* FUNCTION 13448 ; VA 0x00873f80 ; FUN_00873f80 */

TypeDescriptor * FUN_00873f80(void)

{
  return &<lambda_d3ebc6a19a443874f9916506d6289c0a>::RTTI_Type_Descriptor;
}



/* FUNCTION 13449 ; VA 0x00873f90 ; FUN_00873f90 */

TypeDescriptor * FUN_00873f90(void)

{
  return &<lambda_d69c79dd7ac1ccba628dca25efe6aaa8>::RTTI_Type_Descriptor;
}



/* FUNCTION 13450 ; VA 0x00873fa0 ; FUN_00873fa0 */

TypeDescriptor * FUN_00873fa0(void)

{
  return &<lambda_da95e8bdf458e2e5dcb161163bda11ea>::RTTI_Type_Descriptor;
}



/* FUNCTION 13451 ; VA 0x00873fb0 ; FUN_00873fb0 */

int __thiscall FUN_00873fb0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9018;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_00871850(param_2);
      param_4 = param_4 + 8;
      param_2 = param_2 + 8;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_00559650(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 13452 ; VA 0x00874030 ; FUN_00874030 */

void __thiscall FUN_00874030(undefined4 param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d6272c != '\0')) &&
     (ExceptionList = &pvStack_10, cVar1 = FUN_0087b090(param_3), cVar1 != '\0')) {
    puVar2 = (undefined4 *)FUN_00876ad0();
    if (DAT_01ede471 != '\0') {
      puVar3 = puVar2;
      if (0xf < (uint)puVar2[5]) {
        puVar3 = (undefined4 *)*puVar2;
      }
      puVar6 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar6 = (undefined4 *)*param_3;
      }
      FUN_01677520(DAT_01ede471,"Adding counter %s%s = %d",puVar6,puVar3,param_4);
    }
    uVar4 = FUN_005f3cd0(auStack_2c,param_3,puVar2);
    uStack_8 = 0;
    piVar5 = (int *)FUN_005d1a60(uVar4);
    uStack_8 = 0xffffffff;
    *piVar5 = *piVar5 + param_4;
    FUN_005507b0();
  }
  if (DAT_01ede471 != '\0') {
    puVar2 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar2 = (undefined4 *)*param_3;
    }
    FUN_01677520(DAT_01ede471,"Adding counter %s = %d",puVar2,param_4);
  }
  piVar5 = (int *)FUN_005d1a60(param_3);
  *piVar5 = *piVar5 + param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13453 ; VA 0x00874130 ; FUN_00874130 */

uint __thiscall
FUN_00874130(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
            int *param_5)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9048;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)*param_1;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0087b8f0(&puStack_18);
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar2 = FUN_00876840(&iStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((iStack_20 == 0) ||
     (uVar2 = FUN_00874fb0(param_2,param_3,param_4,param_5,auStack_38), (char)uVar2 == '\0'))
  goto LAB_00874291;
  _guard_check_icall(param_2,auStack_38);
  param_5 = param_1 + 0x11;
  puVar4 = (undefined4 *)*param_5;
  puVar9 = puVar4;
  puVar7 = (undefined4 *)puVar4[1];
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    do {
      puVar9 = puVar7;
      piVar5 = puVar9 + 4;
      puVar7 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar7 = (undefined4 *)*param_2;
      }
      if (0xf < (uint)puVar9[9]) {
        piVar5 = (int *)*piVar5;
      }
      iVar3 = FUN_0055c2d0(piVar5,puVar9[8],puVar7,param_2[4]);
      if (iVar3 < 0) {
        puVar7 = (undefined4 *)puVar9[2];
        puVar9 = puVar4;
      }
      else {
        puVar7 = (undefined4 *)*puVar9;
      }
      puVar4 = puVar9;
    } while (*(char *)((int)puVar7 + 0xd) == '\0');
    puVar4 = (undefined4 *)*param_5;
  }
  if (puVar9 == puVar4) {
LAB_00874259:
    param_4 = param_2;
    iVar3 = FUN_0086f7f0(&DAT_018bdeda,&param_4,(int)&param_5 + 3);
    FUN_008705d0(&param_5,puVar9,iVar3 + 0x10,iVar3);
  }
  else {
    piVar5 = puVar9 + 4;
    if (0xf < (uint)puVar9[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar7 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar7 = (undefined4 *)*param_2;
    }
    iVar3 = FUN_0055c2d0(puVar7,param_2[4],piVar5,puVar9[8]);
    if (iVar3 < 0) goto LAB_00874259;
  }
  uVar2 = FUN_008777f0(auStack_38);
LAB_00874291:
  if (piStack_1c != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_1c + 1);
    uVar8 = *puVar1;
    uVar2 = *puVar1;
    *puVar1 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar2 = (**(code **)*piStack_1c)();
      LOCK();
      piVar5 = piStack_1c + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uVar2 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_24) {
    uVar8 = uStack_24 + 1;
    uVar2 = auStack_38[0];
    if (0xfff < uVar8) {
      uVar2 = *(uint *)(auStack_38[0] - 4);
      uVar8 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar2 = FUN_01674ea0(uVar2,uVar8);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = 3;
  if (cStack_14 != '\0') {
    LOCK();
    uVar2 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar8 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar8 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        uVar2 = SetEvent(uVar6);
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 13454 ; VA 0x00874360 ; FUN_00874360 */

int FUN_00874360(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9068;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876840(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_008743e0(param_1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13455 ; VA 0x008743e0 ; FUN_008743e0 */

void FUN_008743e0(byte *param_1)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  byte *pbVar6;
  byte *pbVar7;
  bool bVar8;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pbVar7 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9090;
  pvStack_10 = ExceptionList;
  bVar1 = false;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d79c78 == 0) {
LAB_00874467:
    param_1 = (byte *)((uint)param_1 & 0xffffff);
  }
  else {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("gameId",6);
    pbVar6 = pbVar7 + *pbVar7 + 1;
    bVar1 = true;
    uVar2 = FUN_0055c740(pbVar6,auStack_2c);
    FUN_00562fc0(&param_1,uVar2,auStack_2c,-(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1));
    bVar8 = param_1 != (byte *)0x0;
    param_1 = (byte *)CONCAT13(1,param_1._0_3_);
    if (bVar8) goto LAB_00874467;
  }
  if (bVar1) {
    if (0xf < uStack_18) {
      uVar5 = uStack_18 + 1;
      uVar4 = auStack_2c[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_2c[0] - 4);
        uVar5 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
  }
  bVar1 = false;
  if (param_1._3_1_ != '\0') {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("gameId",6);
    uStack_8 = 0;
    puVar3 = (undefined4 *)FUN_005d15d0(auStack_2c);
    if (puVar3 != &DAT_01d79c50) {
      puVar3 = &DAT_01d79c68;
      if (0xf < DAT_01d79c7c) {
        puVar3 = DAT_01d79c68;
      }
      FUN_005542c0(puVar3,DAT_01d79c78);
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar5 = uStack_18 + 1;
      uVar4 = auStack_2c[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_2c[0] - 4);
        uVar5 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
  }
  if (DAT_01d7a8f8 != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0(&DAT_0191bfb4,3);
    pbVar7 = pbVar7 + *pbVar7 + 1;
    bVar1 = true;
    uVar2 = FUN_0055c740(pbVar7,auStack_2c);
    FUN_00562fc0(&param_1,uVar2,auStack_2c,-(uint)(pbVar7 != (byte *)0x0) & (uint)(pbVar7 + 1));
    bVar8 = param_1 == (byte *)0x0;
    param_1 = (byte *)CONCAT13(1,param_1._0_3_);
    if (bVar8) goto LAB_008745b3;
  }
  param_1 = (byte *)((uint)param_1 & 0xffffff);
LAB_008745b3:
  if ((bVar1) && (0xf < uStack_18)) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (param_1._3_1_ != '\0') {
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    FUN_005542c0(&DAT_0191bfb4,3);
    uStack_8 = 1;
    puVar3 = (undefined4 *)FUN_005d15d0(auStack_44);
    if (puVar3 != &DAT_01d7a8d0) {
      puVar3 = &DAT_01d7a8e8;
      if (0xf < DAT_01d7a8fc) {
        puVar3 = DAT_01d7a8e8;
      }
      FUN_005542c0(puVar3,DAT_01d7a8f8);
    }
    if (0xf < uStack_30) {
      uVar5 = uStack_30 + 1;
      uVar4 = auStack_44[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_44[0] - 4);
        uVar5 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13456 ; VA 0x008746b0 ; FUN_008746b0 */

int FUN_008746b0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b90a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00876840(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    iVar2 = iStack_1c + 0x31 + (uint)*(byte *)(iStack_1c + 0x30);
    uVar3 = FUN_0055c740(iVar2,param_1);
    FUN_00562fc0(&iStack_14,uVar3,param_1,-(uint)(iVar2 != 0) & iVar2 + 1U);
    iVar2 = iStack_14;
    if (iStack_14 != 0) {
      piVar4 = (int *)(iStack_14 + 0x20);
      iVar2 = FUN_005d15d0(param_1);
      iVar2 = iVar2 + 0x18;
      if ((int *)iVar2 != piVar4) {
        if (0xf < *(uint *)(iStack_14 + 0x34)) {
          piVar4 = (int *)*piVar4;
        }
        iVar2 = FUN_005542c0(piVar4,*(undefined4 *)(iStack_14 + 0x30));
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_18 + 1;
    iVar1 = *piVar4;
    iVar2 = *piVar4;
    *piVar4 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*piStack_18)();
      LOCK();
      piVar4 = piStack_18 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 13457 ; VA 0x00874780 ; FUN_00874780 */

void __thiscall
FUN_00874780(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
            undefined4 param_6,int param_7,undefined4 param_8)

{
  uint uVar1;
  char cVar2;
  uint *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined8 uVar12;
  int aiStack_48 [5];
  uint uStack_34;
  uint *puStack_30;
  char cStack_2c;
  undefined auStack_28 [8];
  undefined auStack_20 [4];
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b90d8;
  pvStack_10 = ExceptionList;
  puStack_30 = (uint *)*param_1;
  uStack_8 = 0;
  cStack_2c = '\0';
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0087b760(&puStack_30);
  iVar7 = DAT_01d6255c;
  if ((param_1[0xe] == param_1[0xf]) && (param_1[0x13] == 0)) {
    iVar8 = DAT_01d6255c >> 0x1f;
    puVar3 = (uint *)FUN_0168ea80(auStack_20);
    uVar12 = FUN_016f39b0(iVar7,iVar8,1000000000,0);
    param_1 = puStack_14;
    uVar10 = *puVar3;
    uVar1 = puVar3[1];
    puStack_14[4] = (uint)uVar12 + *puVar3;
    puStack_14[5] = (int)((ulonglong)uVar12 >> 0x20) + uVar1 + (uint)CARRY4((uint)uVar12,uVar10);
    FUN_00588350();
  }
  puStack_18 = (undefined4 *)FUN_00876ad0();
  if (param_4 == 0) {
    puVar11 = (undefined4 *)0x0;
  }
  else {
    puVar11 = *(undefined4 **)(param_7 + param_3 * 4);
  }
  do {
    if (puVar11 == (undefined4 *)0x0) {
      if ((DAT_01d62564 <= (uint)(param_1[0x13] + ((int)(param_1[0xf] - param_1[0xe]) >> 5))) ||
         ((char)param_8 != '\0')) {
        FUN_0087b650(auStack_28,&puStack_30,param_8);
        FUN_00872190();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (cStack_2c != '\0') {
        LOCK();
        uVar10 = *puStack_30;
        *puStack_30 = *puStack_30 + 0x80000000;
        UNLOCK();
        if (((uVar10 & 0x40000000) == 0) && (-0x80000000 < (int)uVar10)) {
          LOCK();
          uVar10 = *puStack_30;
          *puStack_30 = *puStack_30 | 0x40000000;
          UNLOCK();
          if ((uVar10 >> 0x1e & 1) == 0) {
            uVar4 = FUN_00554e40();
            SetEvent(uVar4);
          }
        }
      }
      FUN_005d1280();
      ExceptionList = pvStack_10;
      return;
    }
    piVar6 = puVar11 + 2;
    if ((DAT_020c0b1c != '\0') && (DAT_01d6272c != '\0')) {
      cVar2 = FUN_0087b090(piVar6);
      if (cVar2 != '\0') {
        if (DAT_01ede471 != '\0') {
          puVar9 = puStack_18;
          if (0xf < (uint)puStack_18[5]) {
            puVar9 = (undefined4 *)*puStack_18;
          }
          piVar5 = piVar6;
          if (0xf < (uint)puVar11[7]) {
            piVar5 = (int *)*piVar6;
          }
          FUN_01677520(DAT_01ede471,"Adding counter %s%s = %d (bulk)",piVar5,puVar9,puVar11[8]);
        }
        iStack_1c = puVar11[8];
        uVar4 = FUN_005f3cd0(aiStack_48,piVar6,puStack_18);
        uStack_8._0_1_ = 2;
        piVar5 = (int *)FUN_005d1a60(uVar4);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        *piVar5 = *piVar5 + iStack_1c;
        if (0xf < uStack_34) {
          uVar10 = uStack_34 + 1;
          iVar7 = aiStack_48[0];
          if (0xfff < uVar10) {
            iVar7 = *(int *)(aiStack_48[0] + -4);
            uVar10 = uStack_34 + 0x24;
            if (0x1f < (aiStack_48[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar7,uVar10);
        }
      }
    }
    if (DAT_01ede471 != '\0') {
      piVar5 = piVar6;
      if (0xf < (uint)puVar11[7]) {
        piVar5 = (int *)*piVar6;
      }
      FUN_01677520(DAT_01ede471,"Adding counter %s = %d (bulk)",piVar5,puVar11[8]);
    }
    iVar7 = puVar11[8];
    piVar6 = (int *)FUN_005d1a60(piVar6);
    *piVar6 = *piVar6 + iVar7;
    puVar11 = (undefined4 *)*puVar11;
    param_1 = puStack_14;
  } while( true );
}



/* FUNCTION 13458 ; VA 0x008749d0 ; FUN_008749d0 */

int FUN_008749d0(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined auStack_40 [20];
  undefined4 uStack_2c;
  char **ppcStack_28;
  char *pcStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b90f8;
  pvStack_10 = ExceptionList;
  ppcStack_28 = &pcStack_1c;
  uStack_2c = 0x8749f6;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700();
  uStack_8 = 0;
  if ((pcStack_1c != (char *)0x0) && (*pcStack_1c != '\0')) {
    ppcStack_28 = (char **)param_2;
    puStack_14 = auStack_40;
    FUN_00871920(param_1);
    iVar3 = FUN_00874780();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_28 = (char **)0x874a40;
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppcStack_28 = (char **)0x874a4f;
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13459 ; VA 0x00874a60 ; FUN_00874a60 */

void __thiscall FUN_00874a60(undefined4 *param_1,int *param_2,undefined4 param_3)

{
  uint *puVar1;
  char cVar2;
  uint *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined8 uVar12;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint *puStack_38;
  char cStack_34;
  undefined auStack_30 [8];
  undefined auStack_28 [4];
  undefined4 *puStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9131;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_18 = 0;
  puStack_38 = (uint *)*param_1;
  cStack_34 = '\0';
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0087b760(&puStack_38);
  if ((param_1[0xe] == param_1[0xf]) && (param_1[0x13] == 0)) {
    iVar8 = DAT_01d6255c >> 0x1f;
    puStack_1c = (undefined4 *)DAT_01d6255c;
    puVar3 = (uint *)FUN_0168ea80(auStack_28);
    uVar12 = FUN_016f39b0(puStack_1c,iVar8,1000000000,0);
    param_1 = puStack_14;
    uVar9 = *puVar3;
    uVar7 = puVar3[1];
    puStack_14[4] = (uint)uVar12 + *puVar3;
    puStack_14[5] = (int)((ulonglong)uVar12 >> 0x20) + uVar7 + (uint)CARRY4((uint)uVar12,uVar9);
    FUN_00588350();
  }
  puStack_1c = (undefined4 *)FUN_00876ad0();
  puStack_24 = (undefined4 *)param_2[1];
  puVar11 = (undefined4 *)*param_2;
  if (puVar11 != puStack_24) {
    puVar3 = puVar11 + 6;
    do {
      if ((DAT_01d6272c != '\0') && (cVar2 = FUN_0087b090(puVar11), cVar2 != '\0')) {
        if (DAT_01ede471 != '\0') {
          puVar5 = puStack_1c;
          if (0xf < (uint)puStack_1c[5]) {
            puVar5 = (undefined4 *)*puStack_1c;
          }
          puVar4 = puVar11;
          if (0xf < puVar3[-1]) {
            puVar4 = (undefined4 *)*puVar11;
          }
          FUN_01677520(DAT_01ede471,"Adding stat %s%s = %f (bulk)",puVar4,puVar5,*puVar3,puVar3[1]);
        }
        uStack_20 = uStack_18 | 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uStack_40 = 0;
        uStack_3c = 0xf;
        uStack_50 = uStack_50 & 0xffffff00;
        uStack_18 = uStack_20;
        FUN_0058a190(puStack_1c[4] + puVar3[-2]);
        puVar5 = puVar11;
        if (0xf < puVar3[-1]) {
          puVar5 = (undefined4 *)*puVar11;
        }
        FUN_00554150(puVar5,puVar3[-2]);
        puVar5 = puStack_1c;
        if (0xf < (uint)puStack_1c[5]) {
          puVar5 = (undefined4 *)*puStack_1c;
        }
        FUN_00554150(puVar5,puStack_1c[4]);
        uVar9 = uStack_50;
        puVar1 = (uint *)puStack_14[0xf];
        if ((uint *)puStack_14[0x10] == puVar1) {
          FUN_00633500(puVar1,&uStack_50,puVar3);
          uVar9 = uStack_3c;
        }
        else {
          uStack_50 = uStack_50 & 0xffffff00;
          *puVar1 = uVar9;
          puVar1[1] = uStack_4c;
          puVar1[2] = uStack_48;
          puVar1[3] = uStack_44;
          *(ulonglong *)(puVar1 + 4) = CONCAT44(uStack_3c,uStack_40);
          uVar9 = *puVar3;
          uVar7 = puVar3[1];
          puStack_14[0xf] = puStack_14[0xf] + 0x20;
          puVar1[6] = uVar9;
          puVar1[7] = uVar7;
          uVar9 = 0xf;
        }
        uStack_18 = uStack_18 & 0xfffffffe;
        uStack_8 = uStack_8 & 0xffffff00;
        if (0xf < uVar9) {
          uVar10 = uVar9 + 1;
          uVar7 = uStack_50;
          if (0xfff < uVar10) {
            uVar7 = *(uint *)(uStack_50 - 4);
            uVar10 = uVar9 + 0x24;
            if (0x1f < (uStack_50 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,uVar10);
        }
      }
      if (DAT_01ede471 != '\0') {
        puVar5 = puVar11;
        if (0xf < puVar3[-1]) {
          puVar5 = (undefined4 *)*puVar11;
        }
        FUN_01677520(DAT_01ede471,"Adding stat %s = %f (bulk)",puVar5,*puVar3,puVar3[1]);
      }
      iVar8 = puStack_14[0xf];
      if (puStack_14[0x10] == iVar8) {
        FUN_0086fa90(iVar8,puVar11,puVar3);
      }
      else {
        FUN_0054ef60(puVar11);
        uVar9 = puVar3[1];
        *(uint *)(iVar8 + 0x18) = *puVar3;
        *(uint *)(iVar8 + 0x1c) = uVar9;
        puStack_14[0xf] = puStack_14[0xf] + 0x20;
      }
      puVar11 = puVar11 + 8;
      puVar3 = puVar3 + 8;
      param_1 = puStack_14;
    } while (puVar11 != puStack_24);
  }
  if ((DAT_01d62564 <= (uint)(param_1[0x13] + ((int)(param_1[0xf] - param_1[0xe]) >> 5))) ||
     ((char)param_3 != '\0')) {
    FUN_0087b650(auStack_30,&puStack_38,param_3);
    FUN_00872190();
  }
  uStack_8 = 2;
  if (cStack_34 != '\0') {
    LOCK();
    uVar9 = *puStack_38;
    *puStack_38 = *puStack_38 + 0x80000000;
    UNLOCK();
    if (((uVar9 & 0x40000000) == 0) && (-0x80000000 < (int)uVar9)) {
      LOCK();
      uVar9 = *puStack_38;
      *puStack_38 = *puStack_38 | 0x40000000;
      UNLOCK();
      if ((uVar9 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13460 ; VA 0x00874d70 ; FUN_00874d70 */

int FUN_00874d70(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700(&pcStack_18);
  uStack_8 = 0;
  if ((pcStack_18 != (char *)0x0) && (*pcStack_18 != '\0')) {
    iVar3 = FUN_00874a60(param_1,param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13461 ; VA 0x00874e00 ; FUN_00874e00 */

undefined4 __thiscall FUN_00874e00(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  if ((((uVar1 != 0) || (uVar2 != 0x80000000)) && ((uVar1 != 0xffffffff || (uVar2 != 0x7fffffff))))
     && ((uVar1 != 0xfffffffe || (uVar2 != 0x7fffffff)))) {
    uVar5 = *param_2;
    uVar4 = param_2[1];
    if (((uVar5 != 0) || (uVar4 != 0x80000000)) &&
       (((uVar5 != 0xffffffff || (uVar4 != 0x7fffffff)) &&
        ((uVar5 != 0xfffffffe || (uVar4 != 0x7fffffff)))))) goto LAB_00874f10;
  }
  if ((uVar1 == 0xfffffffe) && (uVar2 == 0x7fffffff)) {
    if (*param_2 != 0xfffffffe) {
      return 2;
    }
    if (param_2[1] == 0x7fffffff) {
      return 0;
    }
    return 2;
  }
  uVar5 = *param_2;
  uVar4 = param_2[1];
  if ((uVar5 == 0xfffffffe) && (uVar4 == 0x7fffffff)) {
    return 2;
  }
  if ((uVar1 == 0) && (uVar2 == 0x80000000)) {
    if (uVar5 != 0) {
      return 0xffffffff;
    }
    if (uVar4 != 0x80000000) {
      return 0xffffffff;
    }
LAB_00874ec0:
    if ((uVar1 != 0xffffffff) || (uVar2 != 0x7fffffff)) {
      if ((uVar5 == 0) &&
         ((uVar4 == 0x80000000 && (cVar3 = FUN_00586330(uVar1,uVar2), cVar3 == '\0')))) {
        return 1;
      }
      goto LAB_00874f10;
    }
  }
  else {
    if ((uVar5 != 0xffffffff) || (uVar4 != 0x7fffffff)) goto LAB_00874ec0;
    if (uVar1 != 0xffffffff) {
      return 0xffffffff;
    }
    if (uVar2 != 0x7fffffff) {
      return 0xffffffff;
    }
  }
  if (uVar5 != 0xffffffff) {
    return 1;
  }
  if (uVar4 != 0x7fffffff) {
    return 1;
  }
LAB_00874f10:
  if ((int)uVar2 <= (int)uVar4) {
    if (((int)uVar2 < (int)uVar4) || (uVar1 < uVar5)) {
      return 0xffffffff;
    }
    if (((int)uVar2 <= (int)uVar4) && (((int)uVar2 < (int)uVar4 || (uVar1 <= uVar5)))) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 13462 ; VA 0x00874f50 ; FUN_00874f50 */

void __fastcall FUN_00874f50(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x2c);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00870c70(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 13463 ; VA 0x00874fb0 ; FUN_00874fb0 */

undefined4 __thiscall
FUN_00874fb0(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4,int param_5)

{
  int iVar1;
  undefined uVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 ******ppppppuVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  undefined8 uVar13;
  undefined auStack_e0 [8];
  uint auStack_d8 [4];
  undefined4 uStack_c8;
  uint uStack_c4;
  undefined4 *****apppppuStack_c0 [4];
  undefined4 uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  int iStack_a4;
  uint uStack_a0;
  int iStack_9c;
  uint uStack_98;
  int iStack_94;
  int aiStack_90 [5];
  uint uStack_7c;
  uint auStack_78 [4];
  undefined4 uStack_68;
  uint uStack_64;
  uint auStack_60 [4];
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_48;
  int iStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  undefined4 *****pppppuStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b920f;
  pvStack_10 = ExceptionList;
  if (((*(int *)(param_2 + 0x10) == 0) || (param_3[4] == 0)) || (piVar8 = param_4 + 4, *piVar8 == 0)
     ) {
    return 0;
  }
  if (0xf < (uint)param_4[5]) {
    param_4 = (undefined4 *)*param_4;
  }
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0151d700(auStack_78,param_4,*piVar8);
  puVar5 = param_3 + 4;
  uStack_8 = 0;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_0151d700(auStack_60,param_3,*puVar5);
  uStack_8._0_1_ = 1;
  puVar4 = (uint *)FUN_00585d40(0,&DAT_0191bf94,4);
  uStack_40 = *puVar4;
  uStack_3c = puVar4[1];
  uStack_38 = puVar4[2];
  uStack_34 = puVar4[3];
  uStack_30 = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  uStack_8._0_1_ = 2;
  puVar5 = (undefined4 *)FUN_00554150("&evt=",5);
  pppppuStack_28 = (undefined4 *****)*puVar5;
  iStack_24 = puVar5[1];
  iStack_20 = puVar5[2];
  iStack_1c = puVar5[3];
  uStack_18 = *(undefined8 *)(puVar5 + 4);
  puVar5[4] = 0;
  puVar5[5] = 0xf;
  *(undefined *)puVar5 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar3 = FUN_00558ba0(aiStack_90,&pppppuStack_28,uVar3);
  FUN_005511f0(uVar3);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  FUN_005507b0();
  if (*(int *)(param_1 + 0x20) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x2c) + *(int *)(param_1 + 0x1c) * 4);
  }
  for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
    if ((puVar5[6] != 0) && (puVar5[0xc] != 0)) {
      piVar8 = puVar5 + 8;
      if (0xf < (uint)puVar5[0xd]) {
        piVar8 = (int *)*piVar8;
      }
      uVar3 = FUN_0151d700(auStack_78,piVar8,puVar5[0xc]);
      piVar8 = puVar5 + 2;
      uStack_8 = 4;
      if (0xf < (uint)puVar5[7]) {
        piVar8 = (int *)*piVar8;
      }
      FUN_0151d700(auStack_60,piVar8,puVar5[6]);
      uStack_8._0_1_ = 5;
      puVar4 = (uint *)FUN_00585d40(0,&DAT_0191bfa0,1);
      uStack_40 = *puVar4;
      uStack_3c = puVar4[1];
      uStack_38 = puVar4[2];
      uStack_34 = puVar4[3];
      uStack_30 = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
      uStack_8._0_1_ = 6;
      puVar6 = (undefined4 *)FUN_00554150(&DAT_0191bf9c,1);
      pppppuStack_28 = (undefined4 *****)*puVar6;
      iStack_24 = puVar6[1];
      iStack_20 = puVar6[2];
      iStack_1c = puVar6[3];
      uStack_18 = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
      uStack_8._0_1_ = 7;
      puVar7 = (undefined4 *)FUN_00558ba0(aiStack_90,&pppppuStack_28,uVar3);
      puVar6 = puVar7 + 4;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_00554150(puVar7,*puVar6);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      uStack_8._0_1_ = 0xff;
      uStack_8._1_3_ = 0xffffff;
      FUN_005507b0();
    }
  }
  if (*(int *)(param_5 + 8) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(*(int *)(param_5 + 0x14) + *(int *)(param_5 + 4) * 4);
  }
  for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
    if ((puVar5[6] != 0) && (puVar5[0xc] != 0)) {
      piVar8 = puVar5 + 8;
      if (0xf < (uint)puVar5[0xd]) {
        piVar8 = (int *)*piVar8;
      }
      uVar3 = FUN_0151d700(aiStack_90,piVar8,puVar5[0xc]);
      piVar8 = puVar5 + 2;
      uStack_8 = 9;
      if (0xf < (uint)puVar5[7]) {
        piVar8 = (int *)*piVar8;
      }
      FUN_0151d700(auStack_60,piVar8,puVar5[6]);
      uStack_8._0_1_ = 10;
      puVar6 = (undefined4 *)FUN_00585d40(0,&DAT_0191bfa0,1);
      pppppuStack_28 = (undefined4 *****)*puVar6;
      iStack_24 = puVar6[1];
      iStack_20 = puVar6[2];
      iStack_1c = puVar6[3];
      uStack_18 = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
      uStack_8._0_1_ = 0xb;
      puVar4 = (uint *)FUN_00554150(&DAT_0191bf9c,1);
      uStack_40 = *puVar4;
      uStack_3c = puVar4[1];
      uStack_38 = puVar4[2];
      uStack_34 = puVar4[3];
      uStack_30 = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
      uStack_8._0_1_ = 0xc;
      puVar7 = (undefined4 *)FUN_00558ba0(auStack_78,&uStack_40,uVar3);
      puVar6 = puVar7 + 4;
      uStack_8._0_1_ = 0xd;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      FUN_00554150(puVar7,*puVar6);
      uStack_8._0_1_ = 0xc;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 0xc;
      if (0xf < uStack_64) {
        uVar11 = uStack_64 + 1;
        uVar12 = auStack_78[0];
        if (0xfff < uVar11) {
          uVar12 = *(uint *)(auStack_78[0] - 4);
          uVar11 = uStack_64 + 0x24;
          if (0x1f < (auStack_78[0] - uVar12) - 4) goto LAB_00875945;
        }
        FUN_01674ea0(uVar12,uVar11);
      }
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = auStack_78[0] & 0xffffff00;
      uStack_8._0_1_ = 0xb;
      if (0xf < uStack_30._4_4_) {
        uVar11 = uStack_30._4_4_ + 1;
        uVar12 = uStack_40;
        if (0xfff < uVar11) {
          uVar12 = *(uint *)(uStack_40 - 4);
          uVar11 = uStack_30._4_4_ + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (uStack_40 - uVar12) - 4) goto LAB_00875945;
        }
        FUN_01674ea0(uVar12,uVar11);
      }
      uStack_30 = 0xf00000000;
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_8._0_1_ = 10;
      if (0xf < uStack_18._4_4_) {
        uVar12 = uStack_18._4_4_ + 1;
        ppppppuVar9 = (undefined4 ******)pppppuStack_28;
        if (0xfff < uVar12) {
          ppppppuVar9 = (undefined4 ******)pppppuStack_28[-1];
          uVar12 = uStack_18._4_4_ + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (uint)((int)pppppuStack_28 + (-4 - (int)ppppppuVar9))) goto LAB_00875945;
        }
        FUN_01674ea0(ppppppuVar9,uVar12);
      }
      uStack_18 = 0xf00000000;
      pppppuStack_28 = (undefined4 *****)((uint)pppppuStack_28 & 0xffffff00);
      uStack_8._0_1_ = 9;
      if (0xf < uStack_4c) {
        uVar11 = uStack_4c + 1;
        uVar12 = auStack_60[0];
        if (0xfff < uVar11) {
          uVar12 = *(uint *)(auStack_60[0] - 4);
          uVar11 = uStack_4c + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (auStack_60[0] - uVar12) - 4) goto LAB_00875945;
        }
        FUN_01674ea0(uVar12,uVar11);
      }
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = auStack_60[0] & 0xffffff00;
      uStack_8._0_1_ = 0xff;
      uStack_8._1_3_ = 0xffffff;
      if (0xf < uStack_7c) {
        uVar12 = uStack_7c + 1;
        iVar10 = aiStack_90[0];
        if (0xfff < uVar12) {
          iVar10 = *(int *)(aiStack_90[0] + -4);
          uVar12 = uStack_7c + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (aiStack_90[0] - iVar10) - 4U) goto LAB_00875945;
        }
        FUN_01674ea0(iVar10,uVar12);
      }
    }
  }
  uVar13 = FUN_01682de0();
  puVar6 = (undefined4 *)FUN_01682ab0(aiStack_90,uVar13);
  puVar5 = puVar6 + 4;
  uStack_8 = 0xe;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_0151d700(auStack_60,puVar6,*puVar5);
  uStack_8._0_1_ = 0xf;
  piVar8 = (int *)FUN_00585d40(0,&DAT_0191bfa4,4);
  pppppuStack_28 = (undefined4 *****)*piVar8;
  iStack_24 = piVar8[1];
  iStack_20 = piVar8[2];
  iStack_1c = piVar8[3];
  uVar13 = *(undefined8 *)(piVar8 + 4);
  piVar8[4] = 0;
  piVar8[5] = 0xf;
  *(undefined *)piVar8 = 0;
  uStack_18._4_4_ = (uint)((ulonglong)uVar13 >> 0x20);
  uStack_18._0_4_ = (undefined4)uVar13;
  uStack_8._0_1_ = 0x10;
  ppppppuVar9 = &pppppuStack_28;
  if (0xf < uStack_18._4_4_) {
    ppppppuVar9 = (undefined4 ******)pppppuStack_28;
  }
  uVar3 = (undefined4)uStack_18;
  uStack_18 = uVar13;
  FUN_00554150(ppppppuVar9,uVar3);
  uStack_8._0_1_ = 0xf;
  if (0xf < uStack_18._4_4_) {
    uVar12 = uStack_18._4_4_ + 1;
    ppppppuVar9 = (undefined4 ******)pppppuStack_28;
    if (0xfff < uVar12) {
      ppppppuVar9 = (undefined4 ******)pppppuStack_28[-1];
      uVar12 = uStack_18._4_4_ + 0x24;
      uVar2 = (undefined)uStack_8;
      if (0x1f < (uint)((int)pppppuStack_28 + (-4 - (int)ppppppuVar9))) {
LAB_00875945:
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppuVar9,uVar12);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (0xf < uStack_4c) {
    uVar11 = uStack_4c + 1;
    uVar12 = auStack_60[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_60[0] - 4);
      uVar11 = uStack_4c + 0x24;
      if (0x1f < (auStack_60[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  auStack_60[0] = auStack_60[0] & 0xffffff00;
  uStack_8 = 0xffffffff;
  if (0xf < uStack_7c) {
    uVar12 = uStack_7c + 1;
    iVar10 = aiStack_90[0];
    if (0xfff < uVar12) {
      iVar10 = *(int *)(aiStack_90[0] + -4);
      uVar12 = uStack_7c + 0x24;
      if (0x1f < (aiStack_90[0] - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar12);
  }
  if ((DAT_020c0b1c != '\0') && (DAT_01d627e4 != '\0')) {
    FUN_00b47170(&uStack_a8);
    if (((((uStack_a0 == 0) && (iStack_9c == -0x80000000)) ||
         ((uStack_a0 == 0xffffffff && (iStack_9c == 0x7fffffff)))) ||
        ((uStack_a0 == 0xfffffffe && (iStack_9c == 0x7fffffff)))) ||
       ((((uStack_a8 == 0 && (iStack_a4 == -0x80000000)) ||
         ((uStack_a8 == 0xffffffff && (iStack_a4 == 0x7fffffff)))) ||
        ((uStack_a8 == 0xfffffffe && (iStack_a4 == 0x7fffffff)))))) {
      iStack_94 = iStack_9c;
      uStack_98 = uStack_a0;
      uStack_48 = uStack_a8;
      iStack_44 = iStack_a4;
      piVar8 = (int *)FUN_00602640(auStack_e0,&uStack_48);
      iVar10 = *piVar8;
      iVar1 = piVar8[1];
      if ((iVar10 == -2) && (iVar1 == 0x7fffffff)) {
        FUN_0056b510(0);
      }
      else if ((iVar10 == 0) && (iVar1 == -0x80000000)) {
        FUN_0056b510(1);
      }
      else {
        if ((iVar10 != -1) || (uVar3 = 2, iVar1 != 0x7fffffff)) {
          uVar3 = 5;
        }
        FUN_0056b510(uVar3);
      }
    }
    else {
      FUN_005ef640(0,0,0,uStack_a0 - uStack_a8,
                   (iStack_9c - iStack_a4) - (uint)(uStack_a0 < uStack_a8));
    }
    FUN_008710d0(apppppuStack_c0,uStack_48,iStack_44);
    uStack_8 = 0x11;
    ppppppuVar9 = apppppuStack_c0;
    if (0xf < uStack_ac) {
      ppppppuVar9 = (undefined4 ******)apppppuStack_c0[0];
    }
    FUN_0151d700(auStack_d8,ppppppuVar9,uStack_b0);
    uStack_8._0_1_ = 0x12;
    piVar8 = (int *)FUN_00585d40(0,"&tmz=",5);
    pppppuStack_28 = (undefined4 *****)*piVar8;
    iStack_24 = piVar8[1];
    iStack_20 = piVar8[2];
    iStack_1c = piVar8[3];
    uVar13 = *(undefined8 *)(piVar8 + 4);
    piVar8[4] = 0;
    piVar8[5] = 0xf;
    *(undefined *)piVar8 = 0;
    uStack_18._4_4_ = (uint)((ulonglong)uVar13 >> 0x20);
    uStack_18._0_4_ = (undefined4)uVar13;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    ppppppuVar9 = &pppppuStack_28;
    if (0xf < uStack_18._4_4_) {
      ppppppuVar9 = (undefined4 ******)pppppuStack_28;
    }
    uVar3 = (undefined4)uStack_18;
    uStack_18 = uVar13;
    FUN_00554150(ppppppuVar9,uVar3);
    if (0xf < uStack_18._4_4_) {
      uVar12 = uStack_18._4_4_ + 1;
      ppppppuVar9 = (undefined4 ******)pppppuStack_28;
      if (0xfff < uVar12) {
        ppppppuVar9 = (undefined4 ******)pppppuStack_28[-1];
        uVar12 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppppuStack_28 + (-4 - (int)ppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppppuVar9,uVar12);
    }
    if (0xf < uStack_c4) {
      uVar11 = uStack_c4 + 1;
      uVar12 = auStack_d8[0];
      if (0xfff < uVar11) {
        uVar12 = *(uint *)(auStack_d8[0] - 4);
        uVar11 = uStack_c4 + 0x24;
        if (0x1f < (auStack_d8[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar11);
    }
    uStack_c8 = 0;
    uStack_c4 = 0xf;
    auStack_d8[0] = auStack_d8[0] & 0xffffff00;
    if (0xf < uStack_ac) {
      uVar12 = uStack_ac + 1;
      ppppppuVar9 = (undefined4 ******)apppppuStack_c0[0];
      if (0xfff < uVar12) {
        ppppppuVar9 = (undefined4 ******)apppppuStack_c0[0][-1];
        uVar12 = uStack_ac + 0x24;
        if (0x1f < (uint)((int)apppppuStack_c0[0] + (-4 - (int)ppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppppuVar9,uVar12);
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 13464 ; VA 0x00875970 ; FUN_00875970 */

void FUN_00875970(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x38;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 13465 ; VA 0x008759c0 ; FUN_008759c0 */

int __thiscall FUN_008759c0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00870c10(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x34);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 13466 ; VA 0x00875a20 ; FUN_00875a20 */

byte FUN_00875a20(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_1c [4];
  undefined auStack_18 [7];
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9228;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01689dd0(auStack_18);
  piVar3 = (int *)FUN_01689df0(auStack_1c);
  if (*piVar2 != *piVar3) {
    cVar1 = FUN_01689a20(param_1,param_2,&bStack_11);
    ExceptionList = pvStack_10;
    return -(cVar1 != '\0') & bStack_11;
  }
  uVar4 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar4);
}



/* FUNCTION 13467 ; VA 0x00875ab0 ; FUN_00875ab0 */

undefined4 __thiscall FUN_00875ab0(byte *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  param_1 = param_1 + *param_1 + 1;
  uVar1 = FUN_0055c740(param_1,param_3);
  FUN_00562fc0(param_2,uVar1,param_3,-(uint)(param_1 != (byte *)0x0) & (uint)(param_1 + 1));
  return param_2;
}



/* FUNCTION 13468 ; VA 0x00875af0 ; FUN_00875af0 */

int __thiscall FUN_00875af0(int param_1,char param_2)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *****pppppuVar6;
  undefined4 *****pppppuVar7;
  uint uVar8;
  undefined ***pppuVar9;
  int *piVar10;
  uint uVar11;
  int iVar12;
  int *piVar13;
  undefined auStack_168 [120];
  int iStack_f0;
  undefined **ppuStack_ec;
  int *piStack_e8;
  int *piStack_e4;
  uint auStack_dc [4];
  undefined4 uStack_cc;
  undefined ***pppuStack_c8;
  undefined4 ****appppuStack_c4 [4];
  undefined4 uStack_b4;
  uint uStack_b0;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  int *piStack_64;
  int *piStack_60;
  undefined4 ****appppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  int *piStack_44;
  int iStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int *piStack_30;
  uint auStack_2c [4];
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b92e0;
  pvStack_10 = ExceptionList;
  piStack_64 = (int *)0x0;
  piVar13 = (int *)0x0;
  piStack_60 = (int *)0x0;
  iVar12 = 0;
  iStack_40 = 0;
  iStack_3c = 0;
  uStack_38 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_f0 = param_1;
  iStack_14 = param_1;
  iVar3 = FUN_016dee6d();
  if (iVar3 != 0) {
    FUN_016df3c9();
  }
  uStack_8._0_1_ = 2;
  if (*(int *)(param_1 + 0x38) == *(int *)(iStack_14 + 0x3c)) {
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar12 = FUN_016deec8();
    if (iVar12 != 0) {
      FUN_016df3c9();
    }
LAB_00876220:
    iVar12 = FUN_008724d0();
    if (piVar13 != (int *)0x0) {
      LOCK();
      piVar10 = piVar13 + 1;
      iVar3 = *piVar10;
      iVar12 = *piVar10;
      *piVar10 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar12 = (**(code **)*piVar13)();
        LOCK();
        piVar10 = piVar13 + 2;
        iVar3 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar12 = (**(code **)(*piVar13 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar12;
  }
  piStack_18 = (int *)FUN_01674e20();
  if (piStack_18 == (int *)0x0) {
    piStack_44 = (int *)0x0;
  }
  else {
    piStack_18[1] = 1;
    piStack_18[2] = 1;
    *piStack_18 = (int)std::_Ref_count_obj<class_boost::promise<void>_>::vftable;
    piStack_18[3] = 0;
    piStack_18[4] = 0;
    *(undefined *)(piStack_18 + 5) = 0;
    piStack_44 = piStack_18;
  }
  piVar13 = piStack_44;
  piVar10 = piStack_44 + 3;
  piStack_64 = piVar10;
  piStack_60 = piStack_44;
  FUN_00876cb0();
  iVar3 = *piVar10;
  if (iVar3 == 0) {
    FUN_0056b1c0();
    uStack_8._0_1_ = 4;
    FUN_00564a30();
  }
  else if (*(char *)(piVar13 + 5) == '\0') {
    *(undefined *)(piVar13 + 5) = 1;
    piVar1 = (int *)piVar13[4];
    piVar10 = piVar1 + 1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      *piVar10 = *piVar10 + 1;
      UNLOCK();
      if (piVar1 != (int *)0x0) {
        LOCK();
        *piVar10 = *piVar10 + 1;
        UNLOCK();
      }
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      *piVar10 = *piVar10 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 6;
    iStack_1c = iVar3;
    piStack_18 = piVar1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = *piVar10;
      *piVar10 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piVar1 + 4))();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 7;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 8))();
        }
      }
    }
    uStack_8._0_1_ = 8;
    FUN_00872b10();
    uStack_8._0_1_ = 9;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 8))();
        }
      }
    }
    piVar10 = (int *)(iStack_14 + 0x38);
    if (&iStack_40 != piVar10) {
      iVar12 = *piVar10;
      *piVar10 = 0;
      iStack_3c = *(int *)(iStack_14 + 0x3c);
      *(undefined4 *)(iStack_14 + 0x3c) = 0;
      uStack_38 = *(undefined4 *)(iStack_14 + 0x40);
      *(undefined4 *)(iStack_14 + 0x40) = 0;
      iStack_40 = iVar12;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    iVar3 = FUN_016deec8();
    if (iVar3 != 0) {
      FUN_016df3c9();
    }
    uStack_8._0_1_ = 1;
    FUN_0167e9f0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_01681c10();
    iVar3 = iStack_3c;
    for (; iVar12 != iVar3; iVar12 = iVar12 + 0x38) {
      FUN_01681c30();
      FUN_01681e50("featureName",iVar12);
      FUN_01681e50("measureName",iVar12 + 0x18);
      FUN_01681020("value",*(undefined8 *)(iVar12 + 0x30));
      FUN_01681200();
      piVar13 = piStack_44;
    }
    FUN_016811a0();
    FUN_01681c50();
    FUN_0167ec80();
    uStack_8._0_1_ = 0xc;
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    FUN_005542c0("/v1/performance/measurements",0x1c);
    uStack_8._0_1_ = 0xd;
    iStack_1c = 0;
    piStack_18 = (int *)&DAT_0000000f;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0xe;
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 0xf;
    puVar4 = &DAT_01d6274c;
    if (0xf < DAT_01d62760) {
      puVar4 = DAT_01d6274c;
    }
    uVar5 = FUN_0151f070(auStack_dc,puVar4);
    uStack_8._0_1_ = 0x10;
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
    FUN_005542c0("https",5);
    uStack_8._0_1_ = 0x11;
    FUN_0151bcc0(auStack_168,auStack_94,uVar5,auStack_ac,auStack_7c,auStack_2c);
    uStack_8._0_1_ = 0x12;
    FUN_0151bb70();
    FUN_0056d9d0();
    uStack_8._0_1_ = 0x15;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x15;
    if (0xf < uStack_80) {
      uVar8 = uStack_80 + 1;
      uVar11 = auStack_94[0];
      if (0xfff < uVar8) {
        uVar11 = *(uint *)(auStack_94[0] - 4);
        uVar8 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar11) - 4) goto LAB_00876284;
      }
      FUN_01674ea0(uVar11,uVar8);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
    uStack_8._0_1_ = 0x16;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x16;
    if (&DAT_0000000f < pppuStack_c8) {
      pppuVar9 = (undefined ***)((int)pppuStack_c8 + 1);
      uVar11 = auStack_dc[0];
      if ((undefined ***)0xfff < pppuVar9) {
        uVar11 = *(uint *)(auStack_dc[0] - 4);
        pppuVar9 = pppuStack_c8 + 9;
        if (0x1f < (auStack_dc[0] - uVar11) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,pppuVar9);
    }
    uStack_cc = 0;
    pppuStack_c8 = (undefined ***)0xf;
    auStack_dc[0] = auStack_dc[0] & 0xffffff00;
    uStack_8._0_1_ = 0x17;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x17;
    if (0xf < uStack_68) {
      uVar8 = uStack_68 + 1;
      uVar11 = auStack_7c[0];
      if (0xfff < uVar8) {
        uVar11 = *(uint *)(auStack_7c[0] - 4);
        uVar8 = uStack_68 + 0x24;
        if (0x1f < (auStack_7c[0] - uVar11) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar8);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
    uStack_8._0_1_ = 0x18;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x18;
    if (&DAT_0000000f < piStack_18) {
      piVar10 = (int *)((int)piStack_18 + 1);
      uVar11 = auStack_2c[0];
      if ((int *)0xfff < piVar10) {
        uVar11 = *(uint *)(auStack_2c[0] - 4);
        piVar10 = piStack_18 + 9;
        if (0x1f < (auStack_2c[0] - uVar11) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,piVar10);
    }
    iStack_1c = 0;
    piStack_18 = (int *)0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_014c9d60(&iStack_34,0);
    pppppuVar6 = appppuStack_5c;
    if (0xf < uStack_48) {
      pppppuVar6 = (undefined4 *****)appppuStack_5c[0];
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    FUN_014cbbc0(pppppuVar6,uStack_4c);
    FUN_014cba10(&DAT_018c3c98,4);
    FUN_014cb780(appppuStack_c4,1);
    FUN_014cb8a0("Content-Type",0xc,"application/json",0x10);
    *(undefined4 *)(iStack_34 + 0xb0) = 0x17;
    if (DAT_01ede471 != '\0') {
      pppppuVar6 = appppuStack_c4;
      if (0xf < uStack_b0) {
        pppppuVar6 = (undefined4 *****)appppuStack_c4[0];
      }
      pppppuVar7 = appppuStack_5c;
      if (0xf < uStack_48) {
        pppppuVar7 = (undefined4 *****)appppuStack_5c[0];
      }
      FUN_01677520(DAT_01ede471,"DeferredEphemeralV2::flush URL: %s\nData: %s",pppppuVar7,pppppuVar6
                  );
    }
    if (piVar13 != (int *)0x0) {
      LOCK();
      piVar13[1] = piVar13[1] + 1;
      UNLOCK();
    }
    piStack_e8 = piVar13 + 3;
    ppuStack_ec = std::
                  _Func_impl_no_alloc<class_<lambda_da95e8bdf458e2e5dcb161163bda11ea>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                  ::vftable;
    pppuStack_c8 = &ppuStack_ec;
    uStack_8._0_1_ = 0x1a;
    piStack_e4 = piVar13;
    FUN_014cb530();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    if (pppuStack_c8 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_c8)[4])();
    }
    if (param_2 != '\0') {
      FUN_0087c860();
    }
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar12 = piStack_30[1] + -1;
      piStack_30[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar12 = piStack_30[2] + -1;
        piStack_30[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    if (0xf < uStack_48) {
      uVar11 = uStack_48 + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_5c[0];
      if (0xfff < uVar11) {
        pppppuVar6 = (undefined4 *****)appppuStack_5c[0][-1];
        uVar11 = uStack_48 + 0x24;
        if (0x1f < (uint)((int)appppuStack_5c[0] + (-4 - (int)pppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar11);
    }
    uStack_4c = 0;
    uStack_48 = 0xf;
    appppuStack_5c[0] = (undefined4 ****)((uint)appppuStack_5c[0] & 0xffffff00);
    if (0xf < uStack_98) {
      uVar8 = uStack_98 + 1;
      uVar11 = auStack_ac[0];
      if (0xfff < uVar8) {
        uVar11 = *(uint *)(auStack_ac[0] - 4);
        uVar8 = uStack_98 + 0x24;
        if (0x1f < (auStack_ac[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar8);
    }
    uStack_9c = 0;
    uStack_98 = 0xf;
    auStack_ac[0] = auStack_ac[0] & 0xffffff00;
    if (0xf < uStack_b0) {
      uVar11 = uStack_b0 + 1;
      pppppuVar6 = (undefined4 *****)appppuStack_c4[0];
      if (0xfff < uVar11) {
        pppppuVar6 = (undefined4 *****)appppuStack_c4[0][-1];
        uVar11 = uStack_b0 + 0x24;
        if (0x1f < (uint)((int)appppuStack_c4[0] + (-4 - (int)pppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar6,uVar11);
    }
    uStack_b4 = 0;
    uStack_b0 = 0xf;
    appppuStack_c4[0] = (undefined4 ****)((uint)appppuStack_c4[0] & 0xffffff00);
    goto LAB_00876220;
  }
  FUN_0056ab30();
  uStack_8._0_1_ = 5;
  FUN_005648f0();
  uVar2 = (undefined)uStack_8;
LAB_00876284:
  uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13469 ; VA 0x008762b0 ; FUN_008762b0 */

void __thiscall FUN_008762b0(int param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  int aiStack_34 [2];
  int iStack_2c;
  int iStack_24;
  int iStack_20;
  uint *puStack_1c;
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9300;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ede471 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ede471,"Send now, blocking = %d",param_2 & 0xff);
  }
  puStack_1c = *(uint **)(param_1 + 8);
  cStack_18 = '\0';
  FUN_00587410();
  uStack_8 = 0;
  FUN_0087b650(aiStack_34,&puStack_1c,0);
  iVar2 = DAT_01d6256c;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((char)param_2 != '\0') {
    iVar5 = DAT_01d6256c >> 0x1f;
    puVar3 = (uint *)FUN_0168ea80(&iStack_24);
    uVar6 = FUN_016f39b0(iVar2,iVar5,1000000,0);
    iStack_24 = (uint)uVar6 + *puVar3;
    iStack_20 = (int)((ulonglong)uVar6 >> 0x20) + puVar3[1] + (uint)CARRY4((uint)uVar6,*puVar3);
    if (aiStack_34[0] != 0) {
      FUN_008716c0(&iStack_24);
    }
    if (iStack_2c != 0) {
      FUN_008716c0(&iStack_24);
    }
  }
  FUN_00872190();
  uStack_8 = 4;
  if (cStack_18 != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (DAT_01d62764 != '\0') {
    FUN_00875af0(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13470 ; VA 0x008763f0 ; FUN_008763f0 */

uint FUN_008763f0(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  undefined4 uVar6;
  int iVar7;
  undefined8 uVar8;
  int *piStack_34;
  int *piStack_30;
  uint uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  uint *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9330;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876700(&puStack_18);
  uStack_8 = 0;
  if (puStack_18 != (uint *)0x0) {
    FUN_008762b0(1);
  }
  piVar4 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00876840(&uStack_28);
  uStack_8 = 1;
  if (uStack_28 != 0) {
    piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
    puStack_18 = *(uint **)(uStack_28 + 0x48);
    FUN_00587410();
    uStack_8._0_1_ = 2;
    if (DAT_01ede472 != '\0') {
      piVar4 = (int *)(uStack_28 + 0x50);
      if (0xf < *(uint *)(uStack_28 + 100)) {
        piVar4 = (int *)*piVar4;
      }
      FUN_016774b0(DAT_01ede472,"%s blocking flush...",piVar4);
    }
    FUN_008791c0(&piStack_34);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0058c660();
    iVar3 = DAT_01d6256c;
    iVar7 = DAT_01d6256c >> 0x1f;
    puVar5 = (uint *)FUN_0168ea80(&iStack_20);
    uVar8 = FUN_016f39b0(iVar3,iVar7,1000000,0);
    iStack_20 = (uint)uVar8 + *puVar5;
    iStack_1c = (int)((ulonglong)uVar8 >> 0x20) + puVar5[1] + (uint)CARRY4((uint)uVar8,*puVar5);
    for (; piStack_34 != piStack_30; piStack_34 = piStack_34 + 2) {
      if (*piStack_34 != 0) {
        FUN_008716c0(&iStack_20);
      }
    }
    uStack_28 = FUN_0056d560();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if ((char)piStack_14 != '\0') {
      LOCK();
      uStack_28 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uStack_28 & 0x40000000) == 0) && (-0x80000000 < (int)uStack_28)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar6 = FUN_00554e40();
          uStack_28 = SetEvent(uVar6);
        }
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar5 = (uint *)(piStack_24 + 1);
    uVar2 = *puVar5;
    uStack_28 = *puVar5;
    *puVar5 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uStack_28 = (**(code **)*piStack_24)();
      LOCK();
      piVar4 = piStack_24 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_28 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uStack_28;
}



/* FUNCTION 13471 ; VA 0x008765a0 ; FUN_008765a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __fastcall FUN_008765a0(int *param_1)

{
  int iVar1;
  
  if ((int *)*param_1 == (int *)0x0) {
    return *(undefined4 *)(_DAT_00000004 + (_DAT_00000008 - 1U & param_1[3]) * 4);
  }
  iVar1 = *(int *)*param_1;
  return *(undefined4 *)(*(int *)(iVar1 + 4) + (*(int *)(iVar1 + 8) - 1U & param_1[3]) * 4);
}



/* FUNCTION 13472 ; VA 0x008765d0 ; FUN_008765d0 */

void __fastcall FUN_008765d0(int param_1)

{
  uint uVar1;
  undefined4 uVar2;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0058cb00(&puStack_18,1);
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar1 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13473 ; VA 0x00876660 ; thunk_FUN_00990f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * thunk_FUN_00990f20(void)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined *puVar4;
  uint uVar5;
  undefined4 *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1318;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee341c) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee341c), DAT_01ee341c == -1)) {
    FUN_016f3654(&LAB_01885eb0);
    FUN_016f37bf(&DAT_01ee341c);
  }
  if (DAT_01d648a0 == 0) {
    FUN_00991530();
    puVar2 = (undefined4 *)FUN_00ef85d0(auStack_18);
    iStack_28 = 0;
    uStack_24 = 0xf;
    puStack_38 = (undefined4 *)((uint)puStack_38 & 0xffffff00);
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    (**(code **)(*(int *)*puVar2 + 0xa8))(&puStack_38);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      puVar2 = puStack_38;
      if (0xfff < uVar5) {
        puVar2 = (undefined4 *)puStack_38[-1];
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)puStack_38 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar2,uVar5);
    }
    iStack_28 = 0;
    uStack_24 = 0xf;
    puStack_38 = (undefined4 *)((uint)puStack_38 & 0xffffff00);
    iStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    iVar3 = FUN_00991530();
    FUN_0054ef60(iVar3 + 0x58);
    FUN_005507b0();
    DAT_01d64890 = puStack_38;
    uRam01d64894 = uStack_34;
    uRam01d64898 = uStack_30;
    uRam01d6489c = uStack_2c;
    _DAT_01d648a0 = CONCAT44(uStack_24,iStack_28);
    if (iStack_28 == 0) {
      puVar2 = (undefined4 *)FUN_00990d80(&puStack_38);
      if ((undefined4 **)puVar2 != &DAT_01d64890) {
        FUN_005507b0();
        DAT_01d64890 = (undefined4 *)*puVar2;
        uRam01d64894 = puVar2[1];
        uRam01d64898 = puVar2[2];
        uRam01d6489c = puVar2[3];
        _DAT_01d648a0 = *(undefined8 *)(puVar2 + 4);
        puVar2[4] = 0;
        puVar2[5] = 0xf;
        *(undefined *)puVar2 = 0;
      }
      FUN_005507b0();
      DAT_01ee3415 = 1;
      puVar4 = (undefined *)FUN_00991530();
      if (puVar4 != &DAT_01d64838) {
        puVar2 = &DAT_01d64890;
        if (0xf < DAT_01d648a4) {
          puVar2 = DAT_01d64890;
        }
        FUN_005542c0(puVar2,DAT_01d648a0);
      }
      FUN_00ef85d0(auStack_20);
      iStack_8 = 2;
      FUN_00910bf0();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piStack_1c + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01d64890;
}



/* FUNCTION 13474 ; VA 0x00876670 ; FUN_00876670 */

undefined4 FUN_00876670(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piStack_c;
  int *piStack_8;
  
  FUN_00876980(&piStack_c);
  if (piStack_c != (int *)0x0) {
    uVar2 = *(undefined4 *)(piStack_c[1] + *piStack_c * 4);
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return uVar2;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return 0;
}



/* FUNCTION 13475 ; VA 0x00876700 ; FUN_00876700 */

undefined4 * FUN_00876700(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (uint *)FUN_00877520();
  cStack_18 = '\0';
  FUN_00587410();
  puVar8 = DAT_01ede460;
  if (DAT_01ede460 == (undefined4 *)0x0) {
    piStack_20 = (int *)0x0;
    puVar8 = &uStack_24;
    bVar5 = false;
    bVar4 = true;
    uVar7 = 0;
  }
  else {
    piStack_28 = (int *)DAT_01ede460[1];
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
      piStack_28 = (int *)puVar8[1];
    }
    uVar7 = *puVar8;
    bVar5 = true;
    bVar4 = false;
    puVar8 = &uStack_2c;
  }
  *puVar8 = 0;
  *param_1 = uVar7;
  param_1[1] = puVar8[1];
  puVar8[1] = 0;
  piVar6 = piStack_20;
  if ((bVar4) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_28;
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (cStack_18 != '\0') {
    LOCK();
    uVar2 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar7 = FUN_00554e40();
        SetEvent(uVar7);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13476 ; VA 0x00876840 ; FUN_00876840 */

undefined4 * FUN_00876840(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (uint *)FUN_00877520();
  cStack_18 = '\0';
  FUN_00587410();
  iVar3 = DAT_01ede460;
  if (DAT_01ede460 == 0) {
    piStack_20 = (int *)0x0;
    puVar8 = &uStack_24;
    bVar5 = false;
    bVar4 = true;
    uVar7 = 0;
  }
  else {
    piStack_28 = *(int **)(DAT_01ede460 + 0xc);
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
      piStack_28 = *(int **)(iVar3 + 0xc);
    }
    uVar7 = *(undefined4 *)(iVar3 + 8);
    bVar5 = true;
    bVar4 = false;
    puVar8 = &uStack_2c;
  }
  *puVar8 = 0;
  *param_1 = uVar7;
  param_1[1] = puVar8[1];
  puVar8[1] = 0;
  piVar6 = piStack_20;
  if ((bVar4) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_28;
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (cStack_18 != '\0') {
    LOCK();
    uVar2 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar7 = FUN_00554e40();
        SetEvent(uVar7);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13477 ; VA 0x00876980 ; FUN_00876980 */

undefined4 * FUN_00876980(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  bool bVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (uint *)FUN_00877520();
  cStack_18 = '\0';
  FUN_00587410();
  iVar3 = DAT_01ede460;
  if (DAT_01ede460 == 0) {
    piStack_20 = (int *)0x0;
    puVar8 = &uStack_24;
    bVar5 = false;
    bVar4 = true;
    uVar7 = 0;
  }
  else {
    piStack_28 = *(int **)(DAT_01ede460 + 0x14);
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
      piStack_28 = *(int **)(iVar3 + 0x14);
    }
    uVar7 = *(undefined4 *)(iVar3 + 0x10);
    bVar5 = true;
    bVar4 = false;
    puVar8 = &uStack_2c;
  }
  *puVar8 = 0;
  *param_1 = uVar7;
  param_1[1] = puVar8[1];
  puVar8[1] = 0;
  piVar6 = piStack_20;
  if ((bVar4) && (piStack_20 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_28;
  if ((bVar5) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  uStack_8 = 0;
  if (cStack_18 != '\0') {
    LOCK();
    uVar2 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar7 = FUN_00554e40();
        SetEvent(uVar7);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13478 ; VA 0x00876ac0 ; thunk_FUN_009911a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * thunk_FUN_009911a0(void)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_1c [5];
  uint uStack_8;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3420) {
    FUN_016f3809(&DAT_01ee3420);
    if (DAT_01ee3420 == -1) {
      FUN_016f3654(&LAB_01885fd0);
      FUN_016f37bf(&DAT_01ee3420);
    }
  }
  if (DAT_01d648b8 == 0) {
    puVar1 = (undefined4 *)FUN_00990d80(aiStack_1c);
    if (puVar1 != &DAT_01d648a8) {
      FUN_005507b0();
      DAT_01d648a8 = *puVar1;
      uRam01d648ac = puVar1[1];
      uRam01d648b0 = puVar1[2];
      uRam01d648b4 = puVar1[3];
      _DAT_01d648b8 = *(undefined8 *)(puVar1 + 4);
      puVar1[4] = 0;
      puVar1[5] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    if (0xf < uStack_8) {
      uVar3 = uStack_8 + 1;
      iVar2 = aiStack_1c[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_1c[0] + -4);
        uVar3 = uStack_8 + 0x24;
        if (0x1f < (aiStack_1c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  return &DAT_01d648a8;
}



/* FUNCTION 13479 ; VA 0x00876ad0 ; FUN_00876ad0 */

undefined4 * FUN_00876ad0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b934c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede55c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede55c);
    if (DAT_01ede55c == -1) {
      uStack_8 = 0;
      FUN_005542c0("_ByVersion_0.461.0.416397",0x19);
      FUN_016f3654(&LAB_018807c0);
      FUN_016f37bf(&DAT_01ede55c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01d62808;
}



/* FUNCTION 13480 ; VA 0x00876b60 ; FUN_00876b60 */

int * __thiscall FUN_00876b60(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876cb0();
  iVar1 = *param_1;
  if (iVar1 == 0) {
    uVar4 = FUN_0056b1c0();
    uStack_8 = 0;
    FUN_00564a30(uVar4);
  }
  else if (*(char *)(param_1 + 2) == '\0') {
    *(undefined *)(param_1 + 2) = 1;
    piVar2 = (int *)param_1[1];
    piVar5 = piVar2 + 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar5 = *piVar5 + 1;
      UNLOCK();
      if (piVar2 != (int *)0x0) {
        LOCK();
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
    }
    *param_2 = iVar1;
    param_2[1] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    uStack_8 = 2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        iVar1 = piVar2[2] + -1;
        piVar2[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    uStack_8 = 3;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piVar2 + 4))();
        LOCK();
        piVar5 = piVar2 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar2 + 8))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar4 = FUN_0056ab30();
  uStack_8 = 1;
  FUN_005648f0(uVar4);
  pcVar3 = (code *)swi(3);
  piVar5 = (int *)(*pcVar3)();
  return piVar5;
}



/* FUNCTION 13481 ; VA 0x00876c60 ; FUN_00876c60 */

void FUN_00876c60(void)

{
  FUN_00875af0(0);
  return;
}



/* FUNCTION 13482 ; VA 0x00876c80 ; FUN_00876c80 */

bool FUN_00876c80(void)

{
  int iVar1;
  undefined8 uStack_c;
  
  uStack_c = 0;
  iVar1 = FUN_00874e00(&uStack_c);
  return iVar1 == -1;
}



/* FUNCTION 13483 ; VA 0x00876cb0 ; FUN_00876cb0 */

undefined4 * __fastcall FUN_00876cb0(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  int iStack_28;
  int *piStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b93a6;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(&DAT_01ea8970 + ((uint)param_1 % 0x29) * 4);
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00587580();
  piVar3 = (int *)param_1[1];
  iVar4 = *param_1;
  piVar7 = piVar3 + 1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  *puVar1 = 0;
  uStack_8 = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar7;
    puVar5 = (undefined4 *)*piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      piVar7 = piVar3 + 2;
      iVar2 = *piVar7;
      puVar5 = (undefined4 *)*piVar7;
      *piVar7 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar5 = (undefined4 *)(**(code **)(*piVar3 + 8))();
      }
    }
  }
  if (iVar4 == 0) {
    piVar7 = (int *)0x0;
    uStack_8 = 1;
    puVar5 = (undefined4 *)FUN_01674e20(0x88);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5[2] = 0;
      puVar5[3] = 0;
      *puVar5 = boost::detail::shared_state_base::vftable;
      puVar5[4] = 0;
      puVar5[5] = 0;
      *(undefined2 *)(puVar5 + 6) = 0;
      puVar5[7] = 0;
      *(undefined *)(puVar5 + 8) = 0;
      puVar5[9] = 0;
      puVar5[10] = 0;
      puVar5[0xb] = 0;
      puVar5[0xc] = 0;
      puVar5[0xd] = 0;
      puVar5[0xe] = 0;
      puVar5[0xf] = 0;
      puVar5[0x10] = 0;
      puVar5[0x11] = 0;
      puVar5[0x12] = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      puVar5[0x13] = 0;
      puVar5[0x14] = 0;
      uVar6 = FUN_00575b50(0,0);
      puVar5[0x13] = uVar6;
      puVar5[0x16] = 0;
      *(undefined *)(puVar5 + 0x1e) = 0;
      puVar5[0x1f] = 0;
      puVar5[0x20] = 0;
      *puVar5 = boost::detail::shared_state<void>::vftable;
    }
    uStack_8._0_1_ = 1;
    FUN_0086f480(puVar5);
    FUN_00587580();
    if ((*param_1 == 0) && (param_1[1] == 0)) {
      *param_1 = iStack_28;
      piVar3 = (int *)param_1[1];
      param_1[1] = (int)piStack_24;
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      piStack_24 = piVar3;
    }
    else {
      piVar7 = (int *)param_1[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
    }
    puVar5 = puVar1;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_24 + 1;
      iVar4 = *piVar3;
      puVar5 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)(*piStack_24 + 4))();
        LOCK();
        piVar3 = piStack_24 + 2;
        iVar4 = *piVar3;
        puVar5 = (undefined4 *)*piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar5 = (undefined4 *)(**(code **)(*piStack_24 + 8))();
        }
      }
    }
    uStack_8 = 10;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar3 = piVar7 + 1;
      iVar4 = *piVar3;
      puVar5 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        puVar5 = (undefined4 *)(**(code **)(*piVar7 + 4))();
        LOCK();
        piVar3 = piVar7 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puVar5 = (undefined4 *)(**(code **)(*piVar7 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 13484 ; VA 0x00876eb0 ; FUN_00876eb0 */

int FUN_00876eb0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined **ppuStack_40;
  int iStack_3c;
  int *piStack_38;
  undefined ***pppuStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b93c0;
  pvStack_10 = ExceptionList;
  iVar3 = ((int *)*param_1)[3] * 0x34 + *(int *)*param_1;
  ExceptionList = &pvStack_10;
  FUN_014c9d60(&iStack_18,0);
  puVar4 = (undefined4 *)(iVar3 + 4);
  uStack_8 = 0;
  if (0xf < *(uint *)(iVar3 + 0x18)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_014cbbc0(puVar4,*(undefined4 *)(iVar3 + 0x14));
  FUN_014cba40();
  FUN_0146d260(DAT_01d625d8);
  *(undefined4 *)(iStack_18 + 0xb0) = 0x17;
  piVar5 = (int *)param_1[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)param_1[1];
  }
  iStack_3c = *param_1;
  piVar1 = piVar5 + 1;
  ppuStack_40 = std::
                _Func_impl_no_alloc<class_<lambda_d3ebc6a19a443874f9916506d6289c0a>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                ::vftable;
  if (piVar5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pppuStack_1c = &ppuStack_40;
  piStack_38 = piVar5;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar3 = piVar5[2] + -1;
      piVar5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_014cb530(&ppuStack_40);
  if (pppuStack_1c != (undefined ***)0x0) {
    iVar3 = (*(code *)(*pppuStack_1c)[4])(pppuStack_1c != &ppuStack_40);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar2 = *piVar5;
    iVar3 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13485 ; VA 0x00876ff0 ; FUN_00876ff0 */

void FUN_00876ff0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da16fc);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_37814d4fd891a80cde4b25ce6ab15a31>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 13486 ; VA 0x00877050 ; FUN_00877050 */

void FUN_00877050(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da168c);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_3b2c0e90f7afaf13f396a187792da536>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 13487 ; VA 0x008770b0 ; FUN_008770b0 */

void FUN_008770b0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 == 1) {
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da16c4);
      iVar2 = 0;
      if (iVar1 == 0) {
        iVar2 = param_1;
      }
      *param_2 = iVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_7514c3c16fa56325099a7e2519e3d3c6>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 13488 ; VA 0x00877110 ; FUN_00877110 */

void FUN_00877110(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da1734);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_c7280ecb4e980af00c80091a16695b3c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 13489 ; VA 0x00877170 ; FUN_00877170 */

uint FUN_00877170(void)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  uint uVar4;
  undefined4 ****ppppuVar5;
  undefined4 ***pppuVar6;
  int *piVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  char *pcVar10;
  undefined4 **ppuStack_d8;
  undefined4 ***pppuStack_d4;
  char *pcStack_d0;
  undefined4 ***pppuStack_cc;
  undefined4 **appuStack_c0 [30];
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 ***apppuStack_3c [2];
  uint uStack_34;
  undefined4 ***apppuStack_30 [2];
  uint uStack_28;
  int *piStack_24;
  undefined4 ***pppuStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9403;
  pvStack_10 = ExceptionList;
  pppuStack_cc = (undefined4 ***)0x877195;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01679ce0();
  if (DAT_01ede474 <= uVar4 % 100) {
    ExceptionList = pvStack_10;
    return uVar4 / 100;
  }
  iStack_48 = 0;
  iStack_44 = 0;
  uStack_40 = 0;
  pppuStack_cc = (undefined4 ***)0x1;
  pppuStack_d4 = &pppuStack_20;
  iStack_8 = 0;
  pcStack_d0 = "|";
  pppuStack_20 = (undefined4 ****)0x0;
  piStack_18 = (int *)0x1;
  ppuStack_d8 = (undefined4 **)0x8771e4;
  FUN_0170cc70();
  ppuStack_d8 = (undefined4 **)piStack_24;
  FUN_0063e660(&pppuStack_20,(int)&pppuStack_20 + (int)piStack_18,
               ((int)&pppuStack_20 + (int)piStack_18) - (int)&pppuStack_20);
  piVar7 = piStack_18;
  pppuVar6 = &ppuStack_d8;
  iStack_8._0_1_ = 1;
  uStack_34 = (uint)piStack_18;
  apppuStack_3c[0] = (undefined4 ****)0x0;
  if (piStack_18 < 9) {
    ppppuVar5 = apppuStack_3c;
    ppppuVar9 = &pppuStack_20;
  }
  else {
    ppppuVar5 = (undefined4 ****)FUN_01674e20(piStack_18);
    ppppuVar9 = (undefined4 ****)pppuStack_20;
    apppuStack_3c[0] = ppppuVar5;
  }
  FUN_0170c6f0(ppppuVar5,ppppuVar9,piVar7);
  uVar4 = uStack_34;
  iStack_8._0_1_ = 2;
  uStack_28 = uStack_34;
  apppuStack_30[0] = (undefined4 ****)0x0;
  if (uStack_34 < 9) {
    ppppuVar5 = apppuStack_30;
    ppppuVar9 = apppuStack_3c;
  }
  else {
    ppppuVar5 = (undefined4 ****)FUN_01674e20(uStack_34);
    ppppuVar9 = (undefined4 ****)apppuStack_3c[0];
    apppuStack_30[0] = ppppuVar5;
  }
  FUN_0170c6f0(ppppuVar5,ppppuVar9,uVar4);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  pcStack_d0 = (char *)uStack_28;
  ppuStack_d8 = (undefined4 ***)0x0;
  if (uStack_28 < 9) {
    ppppuVar5 = apppuStack_30;
  }
  else {
    pppuVar6 = (undefined4 ***)FUN_01674e20(uStack_28);
    ppppuVar5 = (undefined4 ****)apppuStack_30[0];
    ppuStack_d8 = pppuVar6;
  }
  FUN_0170c6f0(pppuVar6,ppppuVar5,pcStack_d0);
  pppuStack_cc = (undefined4 ***)0x1;
  if ((8 < uStack_28) && ((undefined4 ****)apppuStack_30[0] != (undefined4 ****)0x0)) {
    FUN_01674ea0(apppuStack_30[0]);
  }
  iStack_8._0_1_ = 1;
  if ((8 < uVar4) && ((undefined4 ****)apppuStack_3c[0] != (undefined4 ****)0x0)) {
    FUN_01674ea0(apppuStack_3c[0]);
  }
  FUN_0063f980(&iStack_48,&DAT_01d6276c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if ((8 < piStack_18) && ((undefined4 ****)pppuStack_20 != (undefined4 ****)0x0)) {
    pppuStack_cc = pppuStack_20;
    pcStack_d0 = (char *)0x87730b;
    FUN_01674ea0();
  }
  pppuStack_cc = (undefined4 ***)0x34;
  pcStack_d0 = (char *)0x877315;
  piVar7 = (int *)FUN_01674e20();
  piStack_24 = piVar7;
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)0x0;
  }
  else {
    piVar7[1] = 1;
    piVar7[2] = 1;
    *piVar7 = (int)std::
                   _Ref_count_obj<struct_RBX::Analytics::NS1::`anonymous_namespace'::ProbeState>::
                   vftable;
    piVar7[3] = 0;
    piVar7[4] = 0;
    piVar7[5] = 0;
    piVar7[6] = 0;
    pppuStack_cc = (undefined4 ***)0xb;
    piVar7[7] = 0;
    piVar7[8] = 0;
    piVar7[9] = 0;
    piVar7[10] = 0;
    piVar7[0xb] = 0;
    piVar7[0xc] = 0;
    piVar7[3] = 0;
    piVar7[4] = 0;
    piVar7[5] = 0;
    piVar7[6] = 0;
    *(undefined *)(piVar7 + 7) = 0;
    pcStack_d0 = (char *)0x87736c;
    iVar8 = FUN_00588320();
    piVar7[8] = iVar8;
    piVar7[9] = 0;
    piVar7[10] = 0x3f800000;
    piVar7[0xb] = 0;
    piVar7[0xc] = 0;
  }
  piStack_1c = piVar7 + 3;
  iStack_8._0_1_ = 4;
  piStack_18 = piVar7;
  if (iStack_48 == iStack_44) goto LAB_008774dc;
  iVar8 = iStack_44 - iStack_48;
  pppuStack_cc = (undefined4 ***)0x8773c5;
  uVar4 = FUN_01679ce0();
  pcVar10 = (char *)((uVar4 % ((uint)(iVar8 / 0x18) >> 1)) * 0x30 + iStack_48);
  pppuStack_cc = *(undefined4 ****)(pcVar10 + 0x10);
  pcStack_d0 = pcVar10;
  if (0xf < *(uint *)(pcVar10 + 0x14)) {
    pcStack_d0 = *(char **)pcVar10;
  }
  pppuStack_d4 = appuStack_c0;
  ppuStack_d8 = (undefined4 **)0x8773f7;
  FUN_0151bda0();
  ppuStack_d8 = appuStack_c0;
  iStack_8._0_1_ = 5;
  uStack_11 = FUN_014cd370();
  if (DAT_01d6279c == '\0') {
LAB_00877455:
    bVar2 = false;
  }
  else {
    pppuStack_cc = appuStack_c0;
    pcStack_d0 = (char *)0x877422;
    cVar3 = FUN_014cd3b0();
    if (cVar3 == '\0') goto LAB_00877455;
    pppuStack_cc = (undefined4 ***)0x191c428;
    pcStack_d0 = (char *)0x877439;
    cVar3 = FUN_0151cdb0();
    if (cVar3 == '\0') {
      pppuStack_cc = (undefined4 ***)0x191c43c;
      pcStack_d0 = (char *)0x87744d;
      cVar3 = FUN_0151cdb0();
      if (cVar3 == '\0') goto LAB_00877455;
    }
    bVar2 = true;
  }
  if ((uStack_11 != '\0') || (bVar2)) {
    pppuStack_cc = (undefined4 ***)(pcVar10 + 0x18);
    uStack_11 = 0;
    pppuStack_d4 = (undefined4 ***)&uStack_11;
    ppuStack_d8 = (undefined4 **)0x87749b;
    pcStack_d0 = pcVar10;
    FUN_00870d10();
    pppuStack_cc = (undefined4 ***)(pcVar10 + 0x18);
    uStack_11 = 1;
    pppuStack_d4 = (undefined4 ***)&uStack_11;
    ppuStack_d8 = (undefined4 **)0x8774b0;
    pcStack_d0 = pcVar10;
    FUN_00870d10();
    pppuStack_cc = (undefined4 ***)(pcVar10 + 0x18);
    uStack_11 = '\x01';
    pppuStack_d4 = (undefined4 ***)&uStack_11;
    ppuStack_d8 = (undefined4 ***)0x8774c5;
    pcStack_d0 = pcVar10;
    FUN_00870d10();
    pppuStack_cc = (undefined4 ***)&piStack_1c;
    pcStack_d0 = (char *)0x8774ce;
    FUN_00876eb0();
  }
  else if (DAT_01d84e8e != 0) {
    if (0xf < *(uint *)(pcVar10 + 0x14)) {
      pcVar10 = *(char **)pcVar10;
    }
    pppuStack_d4 = (undefined4 ***)(uint)DAT_01d84e8e;
    pcStack_d0 = "Skipped performance probe on untrusted domain. Url = %s.";
    ppuStack_d8 = (undefined4 ***)0x877481;
    pppuStack_cc = (undefined4 ***)pcVar10;
    FUN_01677520();
  }
  pppuStack_cc = (undefined4 ***)0x8774dc;
  FUN_0056d9d0();
LAB_008774dc:
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar8 = piVar7[1] + -1;
    piVar7[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      pppuStack_cc = (undefined4 ***)0x8774f2;
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        pppuStack_cc = (undefined4 ***)0x877501;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  pppuStack_cc = (undefined4 ***)0x877509;
  uVar4 = FUN_00577a40();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 13490 ; VA 0x00877520 ; FUN_00877520 */

undefined4 FUN_00877520(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b941c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede57c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede57c);
    if (DAT_01ede57c == -1) {
      uStack_8 = 0;
      FUN_00871b00();
      FUN_016f3654(&LAB_01880750);
      FUN_016f37bf(&DAT_01ede57c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ede464;
}



/* FUNCTION 13491 ; VA 0x008775b0 ; FUN_008775b0 */

void FUN_008775b0(int param_1)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  uint uVar10;
  undefined4 ***pppuStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = -1;
  puStack_c = &LAB_017b9451;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bfd90,1);
  iStack_1c = 0;
  if (0 < DAT_01d6258c) {
    do {
      puVar5 = (undefined4 *)FUN_008765a0();
      uStack_24 = 0;
      uStack_18 = uStack_14 | 1;
      uStack_20 = 0xf;
      uStack_34 = uStack_34 & 0xffffff00;
      iStack_8 = 0;
      uStack_14 = uStack_18;
      FUN_0058a190(puVar5[4] + 1);
      FUN_00554150(&DAT_018c35d8,1);
      puVar1 = puVar5 + 4;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_00554150(puVar5,*puVar1);
      piVar6 = (int *)FUN_00554150(&DAT_018c35d8,1);
      uVar9 = uStack_14;
      uStack_18 = uStack_14 | 2;
      pppuStack_4c = (undefined4 ***)*piVar6;
      iStack_48 = piVar6[1];
      iStack_44 = piVar6[2];
      iStack_40 = piVar6[3];
      uVar2 = *(undefined8 *)(piVar6 + 4);
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      uStack_3c._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
      uStack_3c._0_4_ = (undefined4)uVar2;
      iStack_8._0_1_ = 1;
      ppppuVar8 = &pppuStack_4c;
      if (0xf < uStack_3c._4_4_) {
        ppppuVar8 = (undefined4 ****)pppuStack_4c;
      }
      uVar4 = (undefined4)uStack_3c;
      uStack_3c = uVar2;
      FUN_00554150(ppppuVar8,uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_3c._4_4_) {
        uVar10 = uStack_3c._4_4_ + 1;
        ppppuVar8 = (undefined4 ****)pppuStack_4c;
        if (0xfff < uVar10) {
          ppppuVar8 = (undefined4 ****)pppuStack_4c[-1];
          uVar10 = uStack_3c._4_4_ + 0x24;
          if (0x1f < (uint)((int)pppuStack_4c + (-4 - (int)ppppuVar8))) goto LAB_008777e8;
        }
        FUN_01674ea0(ppppuVar8,uVar10);
      }
      uStack_14 = uVar9 & 0xfffffffe | 2;
      iStack_8 = -1;
      if (0xf < uStack_20) {
        uVar10 = uStack_20 + 1;
        uVar9 = uStack_34;
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(uStack_34 - 4);
          uVar10 = uStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar9) - 4) goto LAB_008777e8;
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = uStack_34 & 0xffffff00;
      piVar6 = *(int **)(*(int *)(param_1 + 4) +
                        (*(int *)(param_1 + 8) - 1U & *(uint *)(param_1 + 0xc)) * 4);
      uVar9 = piVar6[5];
      if (0xf < uVar9) {
        iVar3 = *piVar6;
        uVar10 = uVar9 + 1;
        iVar7 = iVar3;
        if (0xfff < uVar10) {
          iVar7 = *(int *)(iVar3 + -4);
          uVar10 = uVar9 + 0x24;
          if (0x1f < (iVar3 - iVar7) - 4U) {
LAB_008777e8:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar10);
      }
      piVar6[4] = 0;
      piVar6[5] = 0xf;
      *(undefined *)piVar6 = 0;
      piVar6 = (int *)(param_1 + 0x10);
      *piVar6 = *piVar6 + -1;
      if (*piVar6 == 0) {
        *(undefined4 *)(param_1 + 0xc) = 0;
      }
      else {
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
      }
      if (*(int *)(param_1 + 0x10) == 0) break;
      FUN_00554150(&DAT_018bf378,1);
      iStack_1c = iStack_1c + 1;
    } while (iStack_1c < DAT_01d6258c);
  }
  FUN_00554150(&DAT_018bfd94,1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13492 ; VA 0x008777f0 ; FUN_008777f0 */

void __thiscall FUN_008777f0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  
  uVar3 = *(uint *)(param_1 + 8);
  if (uVar3 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_006174f0(1);
    uVar3 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar3 - 1;
  iVar1 = (*(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U) * 4;
  if (*(int *)(*(int *)(param_1 + 4) + iVar1) == 0) {
    uVar2 = FUN_01674e20(0x18);
    *(undefined4 *)(iVar1 + *(int *)(param_1 + 4)) = uVar2;
  }
  FUN_0054ef60(param_2);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  return;
}



/* FUNCTION 13493 ; VA 0x00877860 ; FUN_00877860 */

uint FUN_00877860(uint param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00876980(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    piVar5 = (int *)(iStack_18 + 4);
    iVar4 = *piVar5;
    if ((uint)(*(int *)(iStack_18 + 0xc) - iVar4 >> 2) < param_1) {
      FUN_006b9410(param_1,piVar5);
      iVar4 = *piVar5;
    }
    if (*(int *)(iVar4 + param_1 * 4) == 0) {
      *(uint *)(iVar4 + param_1 * 4) = param_2;
      uVar3 = param_2;
    }
    else {
      uVar3 = (uint)DAT_01ede470;
      if (DAT_01ede470 != 0) {
        uVar3 = FUN_016774b0(DAT_01ede470,"Google analytics already initialized!",0);
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar2 = *puVar1;
    uVar3 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 13494 ; VA 0x00877920 ; FUN_00877920 */

int FUN_00877920(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000018;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9490;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876840(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    FUN_0054ef60(&param_1);
    iVar3 = FUN_008779e0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar3 = param_1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_1 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13495 ; VA 0x008779e0 ; FUN_008779e0 */

void __thiscall FUN_008779e0(byte *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  int iVar2;
  byte *pbVar3;
  undefined uVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 *****pppppuVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  int *piVar14;
  uint uVar15;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined *puVar16;
  int iStack_dc;
  uint uStack_c8;
  uint uStack_a8;
  uint uStack_94;
  undefined4 ****ppppuStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  undefined8 uStack_7c;
  uint uStack_74;
  undefined4 uStack_64;
  uint uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ****appppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint *puStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b94e7;
  pvStack_10 = ExceptionList;
  uVar15 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  if (in_stack_00000014 != 0) {
    param_1 = param_1 + *param_1 + 1;
    ExceptionList = &pvStack_10;
    uVar6 = FUN_0055c740(param_1,&param_2);
    pbVar3 = pbStack_14;
    FUN_00562fc0(&piStack_20,uVar6,&param_2,-(uint)(param_1 != (byte *)0x0) & (uint)(param_1 + 1));
    if (piStack_20 != (int *)0x0) {
      iVar7 = FUN_00872d70(&param_2);
      for (iVar7 = *(int *)(iVar7 + 0x28); iVar7 != 0; iVar7 = *(int *)(iVar7 + 0x28)) {
        piVar13 = (int *)0x0;
        uStack_48 = 0xf;
        uStack_4c = 0;
        auStack_5c[0] = auStack_5c[0] & 0xffffff00;
        FUN_005542c0(&DAT_018bfd90,1);
        uStack_8 = 1;
        iVar7 = FUN_00872d70(&param_2);
        iVar7 = *(int *)(iVar7 + 0x28);
        while ((iVar7 != 0 && ((int)piVar13 < 900))) {
          piStack_20 = (int *)((int)piVar13 + 1);
          iVar7 = FUN_00872d70(&param_2);
          puVar10 = *(undefined4 **)(iVar7 + 0x18);
          if (puVar10 != (undefined4 *)0x0) {
            puVar10 = (undefined4 *)*puVar10;
          }
          piVar14 = *(int **)(puVar10[1] + (puVar10[2] - 1 & *(uint *)(iVar7 + 0x24)) * 4);
          uStack_64 = 0;
          uStack_60 = 0xf;
          uStack_1c = uVar15 | 1;
          uStack_74 = uStack_74 & 0xffffff00;
          uStack_8 = 2;
          FUN_0058a190(piVar14[4] + 1);
          FUN_00554150(&DAT_018c35d8,1);
          piVar13 = piVar14 + 4;
          if (0xf < (uint)piVar14[5]) {
            piVar14 = (int *)*piVar14;
          }
          FUN_00554150(piVar14,*piVar13);
          piVar13 = (int *)FUN_00554150(&DAT_018c35d8,1);
          ppppuStack_8c = (undefined4 ****)*piVar13;
          iStack_88 = piVar13[1];
          iStack_84 = piVar13[2];
          iStack_80 = piVar13[3];
          uVar1 = *(undefined8 *)(piVar13 + 4);
          piVar13[4] = 0;
          piVar13[5] = 0xf;
          *(undefined *)piVar13 = 0;
          uStack_7c._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
          uStack_7c._0_4_ = (undefined4)uVar1;
          uStack_8 = 3;
          pppppuVar9 = &ppppuStack_8c;
          if (0xf < uStack_7c._4_4_) {
            pppppuVar9 = (undefined4 *****)ppppuStack_8c;
          }
          uVar6 = (undefined4)uStack_7c;
          uStack_7c = uVar1;
          uStack_1c = uVar15 | 3;
          FUN_00554150(pppppuVar9,uVar6);
          uStack_8 = 2;
          uVar4 = uStack_8;
          uStack_8 = 2;
          if (0xf < uStack_7c._4_4_) {
            uVar11 = uStack_7c._4_4_ + 1;
            pppppuVar9 = (undefined4 *****)ppppuStack_8c;
            if (0xfff < uVar11) {
              pppppuVar9 = (undefined4 *****)ppppuStack_8c[-1];
              uVar11 = uStack_7c._4_4_ + 0x24;
              if (0x1f < (uint)((int)ppppuStack_8c + (-4 - (int)pppppuVar9))) goto LAB_00877f9b;
            }
            FUN_01674ea0(pppppuVar9,uVar11);
          }
          uStack_1c = (uVar15 | 3) & 0xfffffffe;
          uStack_8 = 1;
          if (0xf < uStack_60) {
            uVar11 = uStack_60 + 1;
            uVar15 = uStack_74;
            if (0xfff < uVar11) {
              uVar15 = *(uint *)(uStack_74 - 4);
              uVar11 = uStack_60 + 0x24;
              uVar4 = uStack_8;
              if (0x1f < (uStack_74 - uVar15) - 4) goto LAB_00877f9b;
            }
            FUN_01674ea0(uVar15,uVar11);
          }
          iVar7 = FUN_00872d70(&param_2);
          piVar13 = *(int **)(*(int *)(iVar7 + 0x1c) +
                             (*(int *)(iVar7 + 0x20) - 1U & *(uint *)(iVar7 + 0x24)) * 4);
          uVar15 = piVar13[5];
          if (0xf < uVar15) {
            iVar2 = *piVar13;
            uVar11 = uVar15 + 1;
            iVar8 = iVar2;
            if (0xfff < uVar11) {
              iVar8 = *(int *)(iVar2 + -4);
              uVar11 = uVar15 + 0x24;
              uVar4 = uStack_8;
              if (0x1f < (iVar2 - iVar8) - 4U) goto LAB_00877f9b;
            }
            FUN_01674ea0(iVar8,uVar11);
          }
          piVar13[4] = 0;
          piVar13[5] = 0xf;
          *(undefined *)piVar13 = 0;
          piVar13 = (int *)(iVar7 + 0x28);
          *piVar13 = *piVar13 + -1;
          if (*piVar13 == 0) {
            *(undefined4 *)(iVar7 + 0x24) = 0;
          }
          else {
            *(int *)(iVar7 + 0x24) = *(int *)(iVar7 + 0x24) + 1;
          }
          iVar7 = FUN_00872d70(&param_2);
          piVar13 = piStack_20;
          if ((*(int *)(iVar7 + 0x28) != 0) && ((int)piStack_20 < 900)) {
            FUN_00554150(&DAT_018bf378,1);
          }
          iVar7 = FUN_00872d70(&param_2);
          iVar7 = *(int *)(iVar7 + 0x28);
          uVar15 = uStack_1c;
        }
        FUN_00554150(&DAT_018bfd94,1);
        FUN_00d82b80(appppuStack_44,&param_2);
        pppppuVar9 = appppuStack_44;
        if (0xf < uStack_30) {
          pppppuVar9 = (undefined4 *****)appppuStack_44[0];
        }
        uStack_8 = 4;
        cVar5 = FUN_014cd610(pppppuVar9,0);
        if (cVar5 != '\0') {
          FUN_014cc090(appppuStack_44,0x17,0);
          uStack_8 = 5;
          auStack_18[0] = 0;
          cVar5 = FUN_00585a40(auStack_18);
          if (cVar5 == '\0') {
            puVar16 = &DAT_0191c655;
          }
          else {
            puVar16 = (undefined *)0x0;
          }
          FUN_014cd990(auStack_5c,&DAT_01d79f98,0,puVar16);
          uStack_8 = 4;
          if (0xf < uStack_94) {
            uVar12 = uStack_94 + 1;
            uVar11 = uStack_a8;
            if (0xfff < uVar12) {
              uVar11 = *(uint *)(uStack_a8 - 4);
              uVar12 = uStack_94 + 0x24;
              uVar4 = uStack_8;
              if (0x1f < (uStack_a8 - uVar11) - 4) goto LAB_00877f9b;
            }
            FUN_01674ea0(uVar11,uVar12);
          }
          uStack_94 = 0xf;
          uStack_a8 = uStack_a8 & 0xffffff00;
          FUN_0056cfd0();
          if (0xf < uStack_c8) {
            uVar11 = uStack_c8 + 1;
            iVar7 = iStack_dc;
            if (0xfff < uVar11) {
              iVar7 = *(int *)(iStack_dc + -4);
              uVar11 = uStack_c8 + 0x24;
              uVar4 = uStack_8;
              if (0x1f < (iStack_dc - iVar7) - 4U) goto LAB_00877f9b;
            }
            FUN_01674ea0(iVar7,uVar11);
          }
        }
        uStack_8 = 1;
        if (0xf < uStack_30) {
          uVar11 = uStack_30 + 1;
          pppppuVar9 = (undefined4 *****)appppuStack_44[0];
          if (0xfff < uVar11) {
            pppppuVar9 = (undefined4 *****)appppuStack_44[0][-1];
            uVar11 = uStack_30 + 0x24;
            uVar4 = uStack_8;
            if (0x1f < (uint)((int)appppuStack_44[0] + (-4 - (int)pppppuVar9))) goto LAB_00877f9b;
          }
          FUN_01674ea0(pppppuVar9,uVar11);
        }
        uStack_34 = 0;
        uStack_30 = 0xf;
        appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
        uStack_8 = 0;
        if (0xf < uStack_48) {
          uVar12 = uStack_48 + 1;
          uVar11 = auStack_5c[0];
          if (0xfff < uVar12) {
            uVar11 = *(uint *)(auStack_5c[0] - 4);
            uVar12 = uStack_48 + 0x24;
            uVar4 = uStack_8;
            if (0x1f < (auStack_5c[0] - uVar11) - 4) goto LAB_00877f9b;
          }
          FUN_01674ea0(uVar11,uVar12);
        }
        pbVar3 = pbStack_14;
        iVar7 = FUN_00872d70(&param_2);
      }
      if (*(int *)(pbVar3 + 8) != 0) {
        uStack_28 = FUN_0055c740(pbVar3 + *pbVar3 + 1,&param_2);
        puStack_2c = (uint *)(pbVar3 + 4);
        pbStack_14 = (byte *)*puStack_2c;
        uStack_1c = uStack_28 % (uint)pbStack_14;
        iStack_24 = uStack_1c * 4;
        piStack_20 = *(int **)(iStack_24 + *(int *)(pbVar3 + 0x14));
        if ((piStack_20 != (int *)0x0) &&
           (piVar13 = (int *)*piStack_20, (int *)*piStack_20 != (int *)0x0)) {
          while (piVar14 = piVar13, (uint)piVar14[1] % (uint)pbStack_14 == uStack_1c) {
            if (piVar14[1] == uStack_28) {
              piVar13 = piVar14 + 2;
              if (0xf < (uint)piVar14[7]) {
                piVar13 = (int *)*piVar13;
              }
              puVar10 = &param_2;
              if (0xf < in_stack_00000018) {
                puVar10 = param_2;
              }
              cVar5 = FUN_0055c360(puVar10,in_stack_00000014,piVar13,piVar14[6]);
              piVar13 = piStack_20;
              if (cVar5 != '\0') {
                FUN_008759c0(piStack_20,*piVar14);
                if (*piVar13 != 0) {
                  uVar15 = *(uint *)(*piVar13 + 4) % *puStack_2c;
                  if (uStack_1c == uVar15) break;
                  *(int **)(*(int *)(pbVar3 + 0x14) + uVar15 * 4) = piVar13;
                }
                if (*(int **)(*(int *)(pbVar3 + 0x14) + iStack_24) == piVar13) {
                  *(undefined4 *)(*(int *)(pbVar3 + 0x14) + iStack_24) = 0;
                }
                break;
              }
            }
            piVar13 = (int *)*piVar14;
            piStack_20 = piVar14;
            if ((int *)*piVar14 == (int *)0x0) break;
          }
        }
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar15 = in_stack_00000018 + 1;
    puVar10 = param_2;
    if (0xfff < uVar15) {
      puVar10 = (undefined4 *)param_2[-1];
      uVar15 = in_stack_00000018 + 0x24;
      uVar4 = uStack_8;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar10))) {
LAB_00877f9b:
        uStack_8 = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar15);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13496 ; VA 0x00877fb0 ; FUN_00877fb0 */

void __thiscall FUN_00877fb0(int param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint auStack_44 [2];
  int aiStack_3c [6];
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9518;
  pvStack_10 = ExceptionList;
  cStack_11 = '\0';
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  iVar4 = FUN_016dee6d(param_1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iStack_8 = 0;
  cVar3 = FUN_0056f530();
  if (cVar3 == '\0') {
    iStack_18 = param_1;
    cVar3 = FUN_00585a40(&iStack_18);
    if (cVar3 == '\0') {
      aiStack_3c[0] = iStack_18;
      auStack_44[0] = 0x191c64d;
    }
    else {
      auStack_44[0] = 0;
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    uVar5 = FUN_015346a0(auStack_24,auStack_44,(double)DAT_01d625bc,0);
    FUN_0056ecd0(uVar5);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iStack_8._0_1_ = 2;
    if (((auStack_44[0] != 0) && ((auStack_44[0] & 1) == 0)) &&
       (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_44[0] & 0xfffffffe))(aiStack_3c,aiStack_3c,2);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  iVar4 = *(int *)(param_1 + 0x40);
  if ((uint)((iVar4 - *(int *)(param_1 + 0x38)) / 0x38) < DAT_01d625b4) {
    if (0x4924924 < DAT_01d625b4) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00873ef0(DAT_01d625b4);
    iVar4 = *(int *)(param_1 + 0x40);
  }
  iVar2 = *(int *)(param_1 + 0x3c);
  if (iVar4 == iVar2) {
    FUN_0086fbc0(iVar2,param_2,param_3,&param_4);
  }
  else {
    iStack_18 = iVar2;
    FUN_0054ef60(param_2);
    iStack_8._0_1_ = 3;
    FUN_0054ef60(param_3);
    *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 0x38;
    *(undefined8 *)(iVar2 + 0x30) = param_4;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  if (DAT_01ede471 != '\0') {
    FUN_01677520(DAT_01ede471,"DeferredEphemeralV2::report current pendding list size is %d",
                 (*(int *)(param_1 + 0x3c) - *(int *)(param_1 + 0x38)) / 0x38);
  }
  cVar3 = cStack_11;
  if (DAT_01d625b4 <= (uint)((*(int *)(param_1 + 0x3c) - *(int *)(param_1 + 0x38)) / 0x38)) {
    cVar3 = '\x01';
  }
  iStack_8 = 4;
  iVar4 = FUN_016deec8(param_1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iStack_8 = 0xffffffff;
  if (cVar3 != '\0') {
    FUN_00875af0(0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13497 ; VA 0x008781f0 ; FUN_008781f0 */

void __thiscall FUN_008781f0(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined8 uVar12;
  undefined auStack_34 [8];
  undefined auStack_2c [8];
  undefined auStack_24 [8];
  uint *puStack_1c;
  char cStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9540;
  pvStack_10 = ExceptionList;
  cStack_18 = '\0';
  puStack_1c = (uint *)*param_1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00587410();
  iStack_8 = 0;
  FUN_0087b760(&puStack_1c);
  iVar3 = DAT_01d6255c;
  if ((param_1[0xe] == param_1[0xf]) && (param_1[0x13] == 0)) {
    iVar11 = DAT_01d6255c >> 0x1f;
    puVar5 = (uint *)FUN_0168ea80(auStack_24);
    uVar12 = FUN_016f39b0(iVar3,iVar11,1000000000,0);
    param_1 = puStack_14;
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    puStack_14[4] = (uint)uVar12 + *puVar5;
    puStack_14[5] = (int)((ulonglong)uVar12 >> 0x20) + uVar2 + (uint)CARRY4((uint)uVar12,uVar1);
    FUN_00588350();
  }
  if (DAT_020c0b1c != '\0') {
    if (DAT_01d7a7b0 != '\0') {
      FUN_00874030(&puStack_1c,param_2,param_3);
      goto LAB_00878365;
    }
    if ((DAT_01d6272c != '\0') && (cVar4 = FUN_0087b090(param_2), cVar4 != '\0')) {
      puVar6 = (undefined4 *)FUN_00876ad0();
      if (DAT_01ede471 != '\0') {
        puVar10 = puVar6;
        if (0xf < (uint)puVar6[5]) {
          puVar10 = (undefined4 *)*puVar6;
        }
        puVar7 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar7 = (undefined4 *)*param_2;
        }
        FUN_01677520(DAT_01ede471,"Adding counter %s%s = %d",puVar7,puVar10,param_3);
      }
      uVar9 = FUN_005f3cd0(auStack_34,param_2,puVar6);
      iStack_8._0_1_ = 1;
      piVar8 = (int *)FUN_005d1a60(uVar9);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      *piVar8 = *piVar8 + param_3;
      FUN_005507b0();
    }
  }
  if (DAT_01ede471 != '\0') {
    puVar6 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar6 = (undefined4 *)*param_2;
    }
    FUN_01677520(DAT_01ede471,"Adding counter %s = %d",puVar6,param_3);
  }
  piVar8 = (int *)FUN_005d1a60(param_2);
  *piVar8 = *piVar8 + param_3;
LAB_00878365:
  if ((DAT_01d62564 <= (uint)(param_1[0x13] + ((int)(param_1[0xf] - param_1[0xe]) >> 5))) ||
     ((char)param_4 != '\0')) {
    FUN_0087b650(auStack_2c,&puStack_1c,param_4);
    FUN_00872190();
  }
  iStack_8 = 2;
  if (cStack_18 != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar9 = FUN_00554e40();
        SetEvent(uVar9);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13498 ; VA 0x008783f0 ; FUN_008783f0 */

int FUN_008783f0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700(&pcStack_18);
  uStack_8 = 0;
  if ((pcStack_18 != (char *)0x0) && (*pcStack_18 != '\0')) {
    iVar3 = FUN_008781f0(param_1,param_2,param_3);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13499 ; VA 0x00878480 ; FUN_00878480 */

int FUN_00878480(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00878500(param_1,param_2);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}


