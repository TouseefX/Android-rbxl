/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 20500 ; VA 0x00a40b10 ; FUN_00a40b10 */

int FUN_00a40b10(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(param_1 + 0x18))(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20501 ; VA 0x00a40b80 ; FUN_00a40b80 */

undefined4 __thiscall FUN_00a40b80(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = param_2[1];
  uVar5 = uVar7;
  if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
    uVar5 = ~uVar7;
  }
  uVar5 = (uVar5 >> 2) + uVar5 * 0x40 + *param_2 ^ uVar5;
  uVar6 = uVar5 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    for (piVar2 = (int *)*piVar1;
        (piVar2 != (int *)0x0 && ((uint)piVar2[1] % *(uint *)(param_1 + 4) == uVar6));
        piVar2 = (int *)*piVar2) {
      if ((piVar2[1] == uVar5) && ((*param_2 == piVar2[2] && (uVar7 == piVar2[3])))) {
        uVar3 = FUN_00a40750(piVar1,*piVar2);
        if (*piVar1 != 0) {
          uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
          if (uVar6 == uVar7) {
            return uVar3;
          }
          *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
        }
        puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
        if ((int *)*puVar4 == piVar1) {
          *puVar4 = 0;
        }
        return uVar3;
      }
      piVar1 = piVar2;
    }
  }
  return 0;
}



/* FUNCTION 20502 ; VA 0x00a40c70 ; FUN_00a40c70 */

void __thiscall FUN_00a40c70(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint in_stack_0000002c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d46b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00926720(auStack_18,param_3,param_1 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a3f9d0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),uVar3,
               &param_4,&stack0x0000002c);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20503 ; VA 0x00a40d50 ; FUN_00a40d50 */

void __thiscall
FUN_00a40d50(int param_1,int param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined *param_16,undefined8 param_17)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_e0 [2];
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined8 uStack_c8;
  undefined4 uStack_c0;
  undefined auStack_bc [24];
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  undefined4 *puStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined *puStack_5c;
  undefined8 uStack_58;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  code *pcStack_38;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017de9d6;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_58 = CONCAT44(param_1 + 0x40,param_3);
  puStack_5c = auStack_48;
  uStack_60 = 0xa40d9a;
  ExceptionList = &pvStack_1c;
  uStack_28 = FUN_00926720();
  pcStack_38 = *(code **)(param_1 + 0x38);
  puStack_3c = (undefined *)auStack_70;
  puStack_40 = (undefined *)auStack_70;
  iStack_2c = *(int *)(param_1 + 0x3c) + param_2;
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee730a);
  uStack_14._0_1_ = 2;
  auStack_70[0] = 0;
  puVar3 = auStack_70;
  if (param_11 != 0) {
    auStack_70[0] = param_11;
    if ((param_11 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = &param_13;
      uStack_80 = 0xa40dfc;
      (**(code **)(param_11 & 0xfffffffe))();
      puVar3 = (uint *)puStack_3c;
    }
    else {
      uStack_68 = param_13;
      uStack_64 = param_14;
      uStack_60 = param_15;
      puStack_5c = param_16;
      uStack_58 = param_17;
      puVar3 = auStack_70;
    }
  }
  puStack_3c = (undefined *)puVar3;
  uStack_14._0_1_ = 3;
  uStack_94 = 0;
  uStack_c0 = uStack_24;
  puStack_40 = (undefined *)auStack_e0;
  auStack_e0[0] = 0;
  puVar3 = auStack_e0;
  if (param_4 != 0) {
    auStack_e0[0] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d8,0);
      puVar3 = (uint *)puStack_40;
    }
    else {
      uStack_d8 = param_6;
      uStack_d4 = param_7;
      uStack_d0 = param_8;
      uStack_cc = param_9;
      uStack_c8 = param_10;
      puVar3 = auStack_e0;
    }
  }
  puStack_40 = (undefined *)puVar3;
  FUN_008bfbf0(auStack_bc,FUN_00966b00);
  uStack_c0 = 0xa40e6b;
  FUN_00960740();
  uStack_94 = uStack_28;
  uStack_14 = CONCAT31(uStack_14._1_3_,2);
  uStack_98 = 0xa40e78;
  (*pcStack_38)();
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[1] + -1;
    piStack_44[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_98 = 0xa40e91;
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_98 = 0xa40ea0;
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,4);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_a0 = &param_6;
    uStack_98 = 2;
    uStack_a4 = 0xa40ec1;
    puStack_9c = puStack_a0;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 5;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_a0 = &param_13;
    uStack_98 = 2;
    uStack_a4 = 0xa40eef;
    puStack_9c = puStack_a0;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20504 ; VA 0x00a40f10 ; FUN_00a40f10 */

void __thiscall
FUN_00a40f10(int param_1,int param_2,int *param_3,uint param_4,undefined4 param_5,undefined4 param_6
            ,undefined4 param_7,undefined4 param_8,undefined4 param_9,undefined8 param_10,
            uint param_11,undefined4 param_12,undefined4 param_13,undefined4 param_14,
            undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  undefined uVar1;
  uint *puVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint auStack_1d8 [2];
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined8 uStack_1c0;
  undefined4 uStack_1b8;
  undefined auStack_1b4 [24];
  undefined4 uStack_19c;
  undefined4 *puStack_198;
  undefined4 *puStack_194;
  undefined *puStack_190;
  uint *puStack_18c;
  undefined4 uStack_178;
  undefined4 *puStack_174;
  undefined4 *puStack_170;
  undefined4 uStack_16c;
  uint auStack_168 [2];
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined *puStack_154;
  undefined8 uStack_150;
  undefined4 uStack_140;
  int iStack_13c;
  undefined auStack_138 [204];
  undefined *puStack_6c;
  undefined uStack_68;
  undefined auStack_5c [4];
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  code *pcStack_38;
  int iStack_2c;
  undefined4 uStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017dea19;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_150 = CONCAT44(0xa40f58,(undefined4)uStack_150);
  ExceptionList = &pvStack_1c;
  iVar4 = (**(code **)*param_3)();
  if (iVar4 != 0) {
    uStack_58 = 0;
    uStack_54 = 0xf;
    uStack_68 = 0;
    uStack_14._0_1_ = 2;
    uStack_150 = CONCAT44(0xa40f7c,(undefined4)uStack_150);
    uStack_140 = FUN_00888530();
    iStack_13c = 0;
    uStack_150 = CONCAT44(&uStack_140,1);
    uStack_14._0_1_ = 3;
    puStack_154 = (undefined *)0xa40fa2;
    cVar3 = (**(code **)(*param_3 + 4))();
    if (cVar3 != '\0') {
      uStack_150 = CONCAT44(0xa40fb1,(undefined4)uStack_150);
      uVar5 = FUN_008898b0();
      uStack_150 = CONCAT44(uVar5,0xa40fba);
      FUN_0054ef60();
      uStack_14 = CONCAT31(uStack_14._1_3_,4);
      if (iStack_13c != 0) {
        uStack_150 = CONCAT44(auStack_138,0xa40fd4);
        (**(code **)(iStack_13c + 8))();
      }
      uStack_150 = CONCAT44(0xa40fdf,(undefined4)uStack_150);
      FUN_005507b0();
      goto LAB_00a4101e;
    }
    uStack_14._0_1_ = 5;
    if (iStack_13c != 0) {
      uStack_150 = CONCAT44(auStack_138,0xa40ffb);
      (**(code **)(iStack_13c + 8))();
    }
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    uStack_150 = CONCAT44(0xa4100a,(undefined4)uStack_150);
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    puStack_154 = auStack_5c;
    uStack_150 = 0x1018c4db0;
    uStack_158 = 0xa411bb;
    FUN_016756b0();
    uStack_150 = CONCAT44(&DAT_01c17198,auStack_5c);
                    /* WARNING: Subroutine does not return */
    puStack_154 = (undefined *)0xa411cc;
    FUN_0170c2a8();
  }
  uStack_150 = CONCAT44(*(int *)(param_1 + 0x40),0xa4101e);
  FUN_0054ef60();
LAB_00a4101e:
  pcStack_38 = *(code **)(param_1 + 0x38);
  puStack_6c = (undefined *)auStack_168;
  puStack_24 = (undefined *)auStack_168;
  iStack_2c = param_2 + *(int *)(param_1 + 0x3c);
  uStack_28 = CONCAT31(uStack_28._1_3_,DAT_01ee730a);
  uStack_14._0_1_ = 6;
  auStack_168[0] = 0;
  puVar2 = auStack_168;
  if (param_11 != 0) {
    auStack_168[0] = param_11;
    if ((param_11 & 1) == 0) {
      puStack_170 = &uStack_160;
      uStack_16c = 0;
      puStack_174 = &param_13;
      uStack_178 = 0xa4107d;
      (**(code **)(param_11 & 0xfffffffe))();
      puVar2 = (uint *)puStack_6c;
    }
    else {
      uStack_160 = param_13;
      uStack_15c = param_14;
      uStack_158 = param_15;
      puStack_154 = (undefined *)param_16;
      uStack_150 = param_17;
      puVar2 = auStack_168;
    }
  }
  puStack_6c = (undefined *)puVar2;
  uStack_14._0_1_ = 7;
  puStack_18c = (uint *)0x0;
  uStack_1b8 = uStack_28;
  puStack_24 = (undefined *)auStack_1d8;
  auStack_1d8[0] = 0;
  puVar2 = auStack_1d8;
  if (param_4 != 0) {
    auStack_1d8[0] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_1d0,0);
      puVar2 = (uint *)puStack_24;
    }
    else {
      uStack_1d0 = param_6;
      uStack_1cc = param_7;
      uStack_1c8 = param_8;
      uStack_1c4 = param_9;
      uStack_1c0 = param_10;
      puVar2 = auStack_1d8;
    }
  }
  puStack_24 = (undefined *)puVar2;
  FUN_008bfbf0(auStack_1b4,FUN_00966b00);
  uStack_1b8 = 0xa410ec;
  FUN_00960740();
  puStack_18c = auStack_50;
  uStack_14._0_1_ = 6;
  puStack_190 = (undefined *)0xa410fa;
  (*pcStack_38)();
  uStack_14._0_1_ = 1;
  uVar1 = (undefined)uStack_14;
  uStack_14._0_1_ = 1;
  if (0xf < uStack_3c) {
    puStack_190 = (undefined *)(uStack_3c + 1);
    puStack_194 = (undefined4 *)auStack_50[0];
    if (0xfff < puStack_190) {
      puStack_194 = *(undefined4 **)(auStack_50[0] - 4);
      puStack_190 = (undefined *)(uStack_3c + 0x24);
      if (0x1f < (auStack_50[0] - (int)puStack_194) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_190 = &UNK_00a411d1;
        uStack_14._0_1_ = uVar1;
        FUN_017167a3();
      }
    }
    puStack_198 = (undefined4 *)0xa4112f;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_14 = CONCAT31(uStack_14._1_3_,8);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_198 = &param_6;
    puStack_190 = (undefined *)0x2;
    uStack_19c = 0xa41165;
    puStack_194 = puStack_198;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 9;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_198 = &param_13;
    puStack_190 = (undefined *)0x2;
    uStack_19c = 0xa41193;
    puStack_194 = puStack_198;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20505 ; VA 0x00a411e0 ; FUN_00a411e0 */

void __thiscall
FUN_00a411e0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined auStack_ac [28];
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined4 *puStack_88;
  undefined4 uStack_84;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined4 *puStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c862e;
  pvStack_1c = ExceptionList;
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_14 = 1;
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ee730a);
  uStack_60 = 0;
  ExceptionList = &pvStack_1c;
  if (param_11 != 0) {
    uStack_60 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_68 = &uStack_58;
      uStack_64 = 0;
      puStack_6c = &param_13;
      uStack_70 = 0xa41275;
      ExceptionList = &pvStack_1c;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_58 = param_13;
      uStack_54 = param_14;
      uStack_50 = param_15;
      uStack_4c = param_16;
      uStack_48 = param_17;
      ExceptionList = &pvStack_1c;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_84 = 0;
  uStack_b0 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_c8,0);
    }
    else {
      uStack_c8 = param_6;
      uStack_c4 = param_7;
      uStack_c0 = param_8;
      uStack_bc = param_9;
      uStack_b8 = param_10;
    }
  }
  FUN_008bfbf0(auStack_ac,FUN_00966b00);
  uStack_b0 = 0xa412e4;
  FUN_00960740();
  uStack_14._0_1_ = 1;
  uStack_84 = 0xa412ee;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_8c = &param_6;
    uStack_84 = 2;
    uStack_90 = 0xa4130f;
    puStack_88 = puStack_8c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &param_13;
    uStack_84 = 2;
    uStack_90 = 0xa4133d;
    puStack_88 = puStack_8c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 20506 ; VA 0x00a41360 ; FUN_00a41360 */

void __thiscall FUN_00a41360(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint in_stack_0000002c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d46b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00926720(auStack_18,param_3,param_1 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00a3fb60(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),uVar3,
               &param_4,&stack0x0000002c);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20507 ; VA 0x00a41440 ; FUN_00a41440 */

undefined4 __thiscall FUN_00a41440(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dea40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d1340(auStack_20,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5950(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar3;
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 20508 ; VA 0x00a41530 ; FUN_00a41530 */

undefined4 __thiscall FUN_00a41530(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dea60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d1340(auStack_20,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5980(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar3;
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 20509 ; VA 0x00a41620 ; FUN_00a41620 */

undefined4 __thiscall FUN_00a41620(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  (**(code **)(param_1 + 0x38))(uVar2);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 20510 ; VA 0x00a416c0 ; FUN_00a416c0 */

undefined4 FUN_00a416c0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_114 [4];
  int iStack_110;
  undefined auStack_10c [200];
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dea8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  uVar3 = FUN_009d1540(auStack_114,param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  iStack_8 = 0;
  uVar4 = FUN_009d09d0(auStack_44,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  iStack_8._0_1_ = 1;
  uVar3 = (**(code **)(iStack_14 + 0x38))(auStack_2c,uVar4,uVar3);
  iStack_8._0_1_ = 2;
  uVar3 = FUN_009d5710(param_2,uVar3);
  iStack_8._0_1_ = 1;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    uVar5 = auStack_44[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_44[0] - 4);
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  iStack_8 = 3;
  if (iStack_110 != 0) {
    (**(code **)(iStack_110 + 8))(auStack_10c);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 20511 ; VA 0x00a41830 ; FUN_00a41830 */

undefined4 FUN_00a41830(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int aiStack_4c [5];
  uint uStack_38;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deab8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_2);
  uVar3 = FUN_009d09d0(aiStack_4c,param_2,param_3,2,iVar2 - param_3,iStack_14 + 0x44);
  uStack_8 = 0;
  uVar4 = FUN_009d1340(auStack_1c,param_2,param_3,1,iVar2 - param_3,iStack_14 + 0x40);
  uStack_8._0_1_ = 1;
  uVar3 = (**(code **)(iStack_14 + 0x38))(aiStack_34,uVar4,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_009d5710(param_2,uVar3);
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar5) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar5);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_38) {
    uVar5 = uStack_38 + 1;
    iVar2 = aiStack_4c[0];
    if (0xfff < uVar5) {
      iVar2 = *(int *)(aiStack_4c[0] + -4);
      uVar5 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 20512 ; VA 0x00a41980 ; FUN_00a41980 */

void __thiscall FUN_00a41980(int param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c8;
  int *piStack_c4;
  int aiStack_c0 [6];
  uint uStack_a8;
  uint uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [12];
  undefined4 uStack_90;
  undefined *puStack_8c;
  undefined4 uStack_88;
  uint *puStack_84;
  undefined4 *puStack_80;
  int *piStack_7c;
  int *piStack_78;
  int *piStack_74;
  uint auStack_64 [2];
  int aiStack_5c [6];
  undefined auStack_44 [24];
  int aiStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deaf0;
  pvStack_10 = ExceptionList;
  iVar2 = param_1 + 0x239 + (uint)*(byte *)(param_1 + 0x238);
  piStack_74 = param_2;
  piStack_7c = (int *)0xa419bb;
  ExceptionList = &pvStack_10;
  piStack_78 = (int *)iVar2;
  iStack_14 = param_1;
  piStack_7c = (int *)FUN_0055c740();
  piStack_74 = (int *)(-(uint)(iVar2 != 0) & iVar2 + 1U);
  piStack_78 = piVar1;
  puStack_80 = &param_2;
  puStack_84 = (uint *)0xa419d5;
  FUN_00562fc0();
  iVar2 = iStack_14;
  if (param_2 == (int *)0x0) {
    piStack_74 = (int *)param_3;
    piStack_7c = aiStack_2c;
    piStack_78 = piVar1;
    puStack_80 = (undefined4 *)0xa419f1;
    FUN_00a42480();
    uStack_8 = 0;
    if (iStack_1c != 0) {
      piStack_74 = aiStack_2c;
      piStack_78 = (int *)auStack_44;
      piStack_7c = (int *)0xa41a0f;
      FUN_009cc590();
      uStack_a4 = (uint)DAT_01ee730b;
      piStack_74 = (int *)0x0;
      uStack_8._0_1_ = 1;
      uStack_a0 = param_4;
      uStack_a8 = (uint)DAT_01ee73a0;
      param_2 = aiStack_c0;
      piStack_c4 = piVar1;
      uStack_c8 = 0xa41a3e;
      FUN_0054ef60();
      uStack_8._0_1_ = 2;
      FUN_0060e0c0(&uStack_c8,iVar2);
      uStack_8._0_1_ = 1;
      FUN_00a39960(auStack_9c,FUN_00a45c10);
      uStack_a0 = 0xa41a6b;
      FUN_00a369f0();
      piStack_74 = (int *)iVar2;
      uStack_8._0_1_ = 3;
      piStack_78 = (int *)0xa41a75;
      FUN_005c28f0();
      piStack_74 = (int *)0xa41a7f;
      puStack_80 = (undefined4 *)FUN_008ccd70();
      piStack_74 = (int *)0x1;
      piStack_78 = (int *)0x3;
      piStack_7c = &DAT_01d62f20;
      puStack_84 = auStack_64;
      puStack_8c = auStack_44;
      uStack_88 = 0x428c0000;
      uStack_90 = 0xa41aa0;
      FUN_008cd330();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (((auStack_64[0] != 0) && ((auStack_64[0] & 1) == 0)) &&
         (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
        piStack_7c = aiStack_5c;
        piStack_74 = (int *)0x2;
        puStack_80 = (undefined4 *)0xa41ac1;
        piStack_78 = piStack_7c;
        (**(code **)(auStack_64[0] & 0xfffffffe))();
      }
      piStack_74 = (int *)0xa41acc;
      FUN_005507b0();
    }
    if (0xf < uStack_18) {
      piStack_74 = (int *)(uStack_18 + 1);
      iVar2 = aiStack_2c[0];
      if (0xfff < piStack_74) {
        iVar2 = *(int *)(aiStack_2c[0] + -4);
        piStack_74 = (int *)(uStack_18 + 0x24);
        if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_74 = (int *)&UNK_00a41b14;
          FUN_017167a3();
        }
      }
      piStack_7c = (int *)0xa41af9;
      piStack_78 = (int *)iVar2;
      FUN_01674ea0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20513 ; VA 0x00a41b20 ; FUN_00a41b20 */

void __thiscall FUN_00a41b20(int param_1,undefined4 ****param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  undefined4 uStack_e0;
  undefined4 ***pppuStack_dc;
  undefined4 **appuStack_d8 [6];
  uint uStack_c0;
  uint uStack_bc;
  undefined4 uStack_b8;
  undefined auStack_b4 [8];
  undefined4 uStack_ac;
  undefined4 *puStack_a8;
  undefined4 *puStack_a4;
  int iStack_a0;
  undefined4 **ppuStack_9c;
  undefined4 *puStack_98;
  undefined4 ***pppuStack_94;
  undefined4 ***pppuStack_90;
  undefined4 ***pppuStack_8c;
  undefined4 *apuStack_7c [2];
  undefined4 **appuStack_74 [6];
  undefined4 auStack_5c [6];
  undefined4 auStack_44 [6];
  undefined4 ***apppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  ppppuVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deb38;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 0x239 + (uint)*(byte *)(param_1 + 0x238);
  pppuStack_8c = param_2;
  pppuStack_94 = (undefined4 ***)0xa41b5d;
  ExceptionList = &pvStack_10;
  pppuStack_90 = (undefined4 ***)iVar4;
  iStack_14 = param_1;
  pppuStack_94 = (undefined4 ***)FUN_0055c740();
  pppuStack_8c = (undefined4 ***)(-(uint)(iVar4 != 0) & iVar4 + 1U);
  pppuStack_90 = ppppuVar3;
  puStack_98 = &param_2;
  ppuStack_9c = (undefined4 ***)0xa41b77;
  FUN_00562fc0();
  iVar4 = iStack_14;
  if (param_2 != (undefined4 ****)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  pppuStack_90 = &param_2;
  pppuStack_8c = ppppuVar3;
  uStack_8 = 0;
  pppuStack_94 = (undefined4 ****)0xa41baf;
  piVar1 = (int *)FUN_0097be30();
  pppuStack_8c = ppppuVar3;
  if (*piVar1 != *(int *)(iVar4 + 0x288)) {
    pppuStack_90 = (undefined4 ****)0xa41bc1;
    ppppuVar2 = (undefined4 ****)FUN_00a3ccd0();
    if (apppuStack_2c != ppppuVar2) {
      pppuStack_8c = ppppuVar2[4];
      if ((undefined4 ***)0xf < ppppuVar2[5]) {
        ppppuVar2 = (undefined4 ****)*ppppuVar2;
      }
      pppuStack_94 = (undefined4 ****)0xa41be1;
      pppuStack_90 = ppppuVar2;
      FUN_005542c0();
    }
    goto LAB_00a41ca1;
  }
  pppuStack_90 = (undefined4 ***)auStack_44;
  pppuStack_94 = (undefined4 ***)0xa41bef;
  FUN_00fc6260();
  pppuStack_94 = (undefined4 ***)0x2d;
  puStack_98 = auStack_44;
  uStack_8._0_1_ = 1;
  ppuStack_9c = appuStack_74;
  iStack_a0 = 0xa41c02;
  puStack_a4 = (undefined4 *)FUN_00a36cd0();
  iStack_a0 = iVar4 + 0x1a0;
  uStack_8._0_1_ = 2;
  puStack_a8 = auStack_5c;
  uStack_ac = 0xa41c17;
  FUN_00558c20();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  pppuStack_8c = (undefined4 ***)0xa41c26;
  FUN_005507b0();
  if (DAT_01d66088 == '\0') {
LAB_00a41c4d:
    pppuStack_8c = (undefined4 ***)auStack_44;
    pppuStack_90 = &param_2;
    pppuStack_94 = (undefined4 ****)0xa41c5c;
    piVar1 = (int *)FUN_0097be30();
    if (*piVar1 != *(int *)(iVar4 + 0x288)) {
      pppuStack_8c = (undefined4 ***)auStack_44;
      goto LAB_00a41c69;
    }
  }
  else {
    pppuStack_8c = (undefined4 ***)auStack_5c;
    pppuStack_90 = &param_2;
    pppuStack_94 = (undefined4 ****)0xa41c3e;
    piVar1 = (int *)FUN_0097be30();
    if (*piVar1 == *(int *)(iVar4 + 0x288)) goto LAB_00a41c4d;
    pppuStack_8c = (undefined4 ***)auStack_5c;
LAB_00a41c69:
    pppuStack_90 = (undefined4 ****)0xa41c71;
    ppppuVar2 = (undefined4 ****)FUN_00a3ccd0();
    if (apppuStack_2c != ppppuVar2) {
      pppuStack_8c = ppppuVar2[4];
      if ((undefined4 ***)0xf < ppppuVar2[5]) {
        ppppuVar2 = (undefined4 ****)*ppppuVar2;
      }
      pppuStack_94 = (undefined4 ****)0xa41c8d;
      pppuStack_90 = ppppuVar2;
      FUN_005542c0();
    }
  }
  pppuStack_8c = (undefined4 ***)0xa41c95;
  FUN_005507b0();
  uStack_8 = uStack_8 & 0xffffff00;
  pppuStack_8c = (undefined4 ***)0xa41ca1;
  FUN_005507b0();
LAB_00a41ca1:
  if (DAT_01ee7309 != 0) {
    pppuStack_8c = apppuStack_2c;
    if (0xf < uStack_18) {
      pppuStack_8c = apppuStack_2c[0];
    }
    pppuStack_90 = ppppuVar3;
    if ((undefined4 ***)0xf < ppppuVar3[5]) {
      pppuStack_90 = *ppppuVar3;
    }
    puStack_98 = (undefined4 *)(uint)DAT_01ee7309;
    pppuStack_94 = (undefined4 ***)0x1942ab8;
    ppuStack_9c = (undefined4 ***)0xa41cd0;
    FUN_01677520();
  }
  if (iStack_1c != 0) {
    pppuStack_8c = apppuStack_2c;
    pppuStack_90 = (undefined4 ***)auStack_5c;
    pppuStack_94 = (undefined4 ***)0xa41cea;
    FUN_009cc590();
    uStack_bc = (uint)DAT_01ee730b;
    pppuStack_8c = (undefined4 ***)0x0;
    uStack_8._0_1_ = 5;
    uStack_b8 = param_3;
    uStack_c0 = (uint)DAT_01ee73a0;
    param_2 = (undefined4 ****)appuStack_d8;
    pppuStack_dc = ppppuVar3;
    uStack_e0 = 0xa41d19;
    FUN_0054ef60();
    uStack_8._0_1_ = 6;
    FUN_0060e0c0(&uStack_e0,iVar4);
    uStack_8._0_1_ = 5;
    FUN_00a39960(auStack_b4,FUN_00a45c10);
    uStack_b8 = 0xa41d46;
    FUN_00a369f0();
    pppuStack_8c = (undefined4 ***)iVar4;
    uStack_8._0_1_ = 7;
    pppuStack_90 = (undefined4 ***)0xa41d50;
    FUN_005c28f0();
    pppuStack_8c = (undefined4 ***)0xa41d5a;
    puStack_98 = (undefined4 *)FUN_008ccd70();
    pppuStack_8c = (undefined4 ***)0x1;
    pppuStack_90 = (undefined4 ****)0x3;
    pppuStack_94 = (undefined4 ***)&DAT_01d62f20;
    ppuStack_9c = apuStack_7c;
    puStack_a4 = auStack_5c;
    iStack_a0 = 0x428c0000;
    puStack_a8 = (undefined4 *)0xa41d7b;
    FUN_008cd330();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if ((((undefined4 **)apuStack_7c[0] != (undefined4 **)0x0) && (((uint)apuStack_7c[0] & 1) == 0))
       && (*(code **)((uint)apuStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
      pppuStack_94 = appuStack_74;
      pppuStack_8c = (undefined4 ***)0x2;
      puStack_98 = (undefined4 *)0xa41d9c;
      pppuStack_90 = pppuStack_94;
      (**(code **)((uint)apuStack_7c[0] & 0xfffffffe))();
    }
    pppuStack_8c = (undefined4 ***)0xa41da7;
    FUN_005507b0();
  }
  if (0xf < uStack_18) {
    pppuStack_8c = (undefined4 ***)(uStack_18 + 1);
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < pppuStack_8c) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
      pppuStack_8c = (undefined4 ***)(uStack_18 + 0x24);
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_8c = (undefined4 ***)&UNK_00a41def;
        FUN_017167a3();
      }
    }
    pppuStack_94 = (undefined4 ***)0xa41dd4;
    pppuStack_90 = ppppuVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20514 ; VA 0x00a41df0 ; FUN_00a41df0 */

void __thiscall
FUN_00a41df0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined **ppuVar5;
  code *pcVar6;
  int *piStack_d8;
  int *piStack_d4;
  uint *puStack_d0;
  uint uStack_cc;
  int *piStack_c8;
  undefined4 *puStack_c4;
  undefined *puStack_c0;
  int aiStack_b0 [5];
  uint uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_90;
  int *piStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_78;
  undefined4 *puStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined **appuStack_58 [2];
  undefined4 auStack_50 [7];
  undefined4 auStack_34 [2];
  undefined4 *puStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deb7e;
  pvStack_10 = ExceptionList;
  piStack_c8 = aiStack_b0;
  puStack_c0 = (undefined *)param_3;
  puStack_c4 = (undefined4 *)param_2;
  uStack_cc = 0xa41e2a;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_009cc3c0();
  puStack_c0 = (undefined *)param_4;
  uStack_cc = (uint)DAT_01ee730b;
  puStack_c4 = (undefined4 *)param_3;
  piStack_c8 = (int *)param_2;
  puStack_d0 = (uint *)(uint)DAT_01ee73a0;
  uStack_8 = 0;
  FUN_0060e0c0(&piStack_d8,param_1);
  pcVar6 = FUN_00a47a60;
  FUN_00a39bf0(auStack_34,FUN_00a47a60);
  piVar2 = piStack_28;
  uStack_78 = auStack_34[0];
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piStack_28[2] = piStack_28[2] + 1;
    UNLOCK();
  }
  puStack_70 = puStack_2c;
  piStack_6c = piStack_28;
  uStack_68 = uStack_24;
  uStack_64 = uStack_20;
  uStack_60 = uStack_1c;
  appuStack_58[0] = (undefined **)0x0;
  uStack_98 = auStack_34[0];
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piStack_28[2] = piStack_28[2] + 1;
    UNLOCK();
  }
  puStack_90 = puStack_2c;
  piStack_8c = piStack_28;
  uStack_88 = uStack_24;
  uStack_84 = uStack_20;
  uStack_80 = uStack_1c;
  puStack_c0 = (undefined *)auStack_50;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piStack_28[2] = piStack_28[2] + 1;
    UNLOCK();
  }
  piStack_d8 = puStack_2c;
  piStack_d4 = piStack_28;
  puStack_d0 = (uint *)uStack_24;
  ppuVar5 = &PTR_FUN_01942fd0;
  uStack_cc = uStack_20;
  piStack_c8 = (int *)uStack_1c;
  cVar3 = FUN_00a397e0(auStack_34[0],pcVar6);
  if (cVar3 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  appuStack_58[0] = ppuVar5;
  if (piVar2 != (int *)0x0) {
    piVar1 = piVar2 + 2;
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puStack_c0 = (undefined *)0xa41f34;
      (**(code **)(*piVar2 + 4))();
    }
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puStack_c0 = (undefined *)0xa41f43;
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_28 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      puStack_c0 = (undefined *)0xa41f57;
      (**(code **)(*piStack_28 + 4))();
    }
  }
  puStack_c0 = (undefined *)uStack_14;
  uStack_8._0_1_ = 4;
  puStack_c4 = (undefined4 *)0xa41f63;
  FUN_005c28f0();
  puStack_c0 = (undefined *)0xa41f6d;
  uStack_cc = FUN_008ccd70();
  puStack_c0 = (undefined *)0x1;
  puStack_c4 = (undefined4 *)0x3;
  piStack_c8 = &DAT_01d62f20;
  puStack_d0 = (uint *)appuStack_58;
  piStack_d8 = aiStack_b0;
  piStack_d4 = (int *)0x428c0000;
  FUN_008cd330();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((appuStack_58[0] != (undefined **)0x0) && (((uint)appuStack_58[0] & 1) == 0)) &&
     (*(code **)((uint)appuStack_58[0] & 0xfffffffe) != (code *)0x0)) {
    piStack_c8 = auStack_50;
    puStack_c0 = (undefined *)0x2;
    uStack_cc = 0xa41fb2;
    puStack_c4 = piStack_c8;
    (**(code **)((uint)appuStack_58[0] & 0xfffffffe))();
  }
  if (0xf < uStack_9c) {
    puStack_c0 = (undefined *)(uStack_9c + 1);
    iVar4 = aiStack_b0[0];
    if (0xfff < puStack_c0) {
      iVar4 = *(int *)(aiStack_b0[0] + -4);
      puStack_c0 = (undefined *)(uStack_9c + 0x24);
      if (0x1f < (aiStack_b0[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_c0 = &UNK_00a42003;
        FUN_017167a3();
      }
    }
    piStack_c8 = (int *)0xa41fe8;
    puStack_c4 = (undefined4 *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20515 ; VA 0x00a42010 ; FUN_00a42010 */

void __thiscall FUN_00a42010(int param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint *puVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_78 [2];
  undefined auStack_70 [24];
  int aiStack_58 [5];
  uint uStack_44;
  uint auStack_40 [3];
  undefined4 uStack_34;
  int *piStack_30;
  uint uStack_2c;
  uint *puStack_28;
  undefined4 *puStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  uint *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deba8;
  pvStack_10 = ExceptionList;
  piStack_30 = (int *)0x0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("source",6);
  puVar3 = (undefined4 *)FUN_0097be30(&puStack_24,auStack_40);
  puVar5 = *(uint **)(param_1 + 0x288);
  puStack_18 = (uint *)*puVar3;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    uVar9 = auStack_40[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_40[0] - 4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  if (puStack_18 == puVar5) {
    *(undefined *)(param_1 + 0x2c1) = 1;
    if ((*(char *)(param_1 + 0x2c0) != '\0') && (cVar2 = FUN_00fce1e0(), cVar2 != '\x01')) {
      FUN_008a4940(&DAT_02125ff0);
    }
  }
  else {
    piStack_30 = (int *)0x0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("source",6);
    uStack_8 = 0;
    FUN_0097be30(&puStack_18,auStack_40);
    puVar5 = puStack_18;
    if (puStack_18 == *(uint **)(param_1 + 0x288)) {
      puStack_18 = auStack_40;
      uStack_20 = **(uint **)(param_1 + 0x288);
      puStack_24 = *(undefined4 **)(uStack_20 + 4);
      uVar4 = FUN_00a37040(uStack_20,puStack_24,&DAT_018bdeda,&puStack_18,&uStack_11);
      if (*(int *)(param_1 + 0x28c) == 0x4924923) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      *(int *)(param_1 + 0x28c) = *(int *)(param_1 + 0x28c) + 1;
      *(undefined4 *)(uStack_20 + 4) = uVar4;
      *puStack_24 = uVar4;
      FUN_00a377b0(&puStack_28,**(int **)(param_1 + 0x288) + 8,**(int **)(param_1 + 0x288));
      puVar5 = puStack_28;
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar9 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
    piStack_30 = (int *)0x0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_009cc590(aiStack_58,puVar5 + 8);
    puStack_24 = (undefined4 *)CONCAT31(puStack_24._1_3_,DAT_01ee730b);
    uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee73a0);
    uStack_8 = 1;
    FUN_0060e0c0(&uStack_1c,param_1);
    if (puStack_18 != (uint *)0x0) {
      LOCK();
      puStack_18[2] = puStack_18[2] + 1;
      UNLOCK();
    }
    puVar5 = puStack_18;
    if (puStack_18 != (uint *)0x0) {
      LOCK();
      puStack_18[2] = puStack_18[2] + 1;
      UNLOCK();
      LOCK();
      puStack_18[2] = puStack_18[2] + 1;
      UNLOCK();
    }
    FUN_00a3acd0(uStack_1c,puStack_18,uStack_20,puStack_24);
    if (puVar5 != (uint *)0x0) {
      LOCK();
      uVar9 = puVar5[2] - 1;
      puVar5[2] = uVar9;
      UNLOCK();
      if (uVar9 == 0) {
        (**(code **)(*puVar5 + 4))();
      }
      LOCK();
      uVar9 = puVar5[2] - 1;
      puVar5[2] = uVar9;
      UNLOCK();
      if (uVar9 == 0) {
        (**(code **)(*puVar5 + 4))();
      }
    }
    piVar1 = piStack_30;
    if (piStack_30 != (int *)0x0) {
      piVar6 = piStack_30 + 2;
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      LOCK();
      iVar7 = *piVar6;
      *piVar6 = iVar7 + -1;
      UNLOCK();
      if (iVar7 + -1 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
    puVar5 = puStack_18;
    if (puStack_18 != (uint *)0x0) {
      LOCK();
      uVar9 = puStack_18[2] - 1;
      puStack_18[2] = uVar9;
      UNLOCK();
      if (uVar9 == 0) {
        (**(code **)(*puVar5 + 4))();
      }
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[2] = piVar1[2] + 1;
      UNLOCK();
    }
    auStack_78[0] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[2] = piVar1[2] + 1;
      UNLOCK();
    }
    FUN_00a396c0(FUN_00a4d3e0,uStack_34,piVar1,param_2);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar7 = piVar1[2] + -1;
      piVar1[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
      piVar6 = piVar1 + 2;
      LOCK();
      iVar7 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    uStack_8._0_1_ = 2;
    FUN_005c28f0(param_1);
    uVar4 = FUN_008ccd70();
    FUN_008cd330(aiStack_58,0x428c0000,auStack_78,uVar4,&DAT_01d62f20,3,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((auStack_78[0] != 0) && ((auStack_78[0] & 1) == 0)) &&
       (*(code **)(auStack_78[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_78[0] & 0xfffffffe))(auStack_70,auStack_70,2);
    }
    if (0xf < uStack_44) {
      uVar9 = uStack_44 + 1;
      iVar7 = aiStack_58[0];
      if (0xfff < uVar9) {
        iVar7 = *(int *)(aiStack_58[0] + -4);
        uVar9 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar9);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20516 ; VA 0x00a423e0 ; FUN_00a423e0 */

int FUN_00a423e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  
  if ((param_1 != 0) && (puVar8 = *(undefined4 **)(param_1 + 0x2c), puVar8 != (undefined4 *)0x0)) {
    piVar2 = (int *)puVar8[1];
    for (piVar9 = (int *)*puVar8; piVar9 != piVar2; piVar9 = piVar9 + 2) {
      iVar3 = *piVar9;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar6 = FUN_00fd0780(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da))) {
        piVar7 = *(int **)(iVar3 + 0x28);
        puVar8 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar8 = (undefined4 *)*param_2;
        }
        piVar1 = piVar7 + 4;
        if (0xf < (uint)piVar7[5]) {
          piVar7 = (int *)*piVar7;
        }
        cVar5 = FUN_0055c360(piVar7,*piVar1,puVar8,param_2[4]);
        if (cVar5 != '\0') {
          return iVar3;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 20517 ; VA 0x00a42480 ; FUN_00a42480 */

undefined * FUN_00a42480(undefined *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined uVar2;
  undefined4 *puVar3;
  undefined4 ****ppppuVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 ***apppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puVar1 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dec0a;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00fc6260(apppuStack_48,param_2);
  puVar5 = param_3;
  iStack_8 = 0;
  if (param_3[4] != 0) {
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    uStack_18 = 2;
    FUN_0058a190(puVar1[4] + 1);
    puVar3 = puVar1;
    if (0xf < (uint)puVar1[5]) {
      puVar3 = (undefined4 *)*puVar1;
    }
    FUN_00554150(puVar3,puVar1[4]);
    FUN_00592760(0x2d);
    puVar3 = puVar5;
    if (0xf < (uint)puVar5[5]) {
      puVar3 = (undefined4 *)*puVar5;
    }
    puVar3 = (undefined4 *)FUN_00554150(puVar3,puVar5[4]);
    uStack_78 = *puVar3;
    uStack_74 = puVar3[1];
    uStack_70 = puVar3[2];
    uStack_6c = puVar3[3];
    uStack_68 = *(undefined8 *)(puVar3 + 4);
    puVar3[4] = 0;
    puVar3[5] = 0xf;
    *(undefined *)puVar3 = 0;
    iStack_8._0_1_ = 3;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 3;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar6 = uStack_30;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uStack_30 - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar6) - 4) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    iStack_8._0_1_ = 4;
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    uStack_18 = 0xc;
    FUN_0058a190(iStack_38 + 1);
    ppppuVar4 = apppuStack_48;
    if (0xf < uStack_34) {
      ppppuVar4 = (undefined4 ****)apppuStack_48[0];
    }
    FUN_00554150(ppppuVar4,iStack_38);
    FUN_00592760(0x2d);
    puVar3 = puVar5 + 4;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    puVar5 = (undefined4 *)FUN_00554150(puVar5,*puVar3);
    uStack_60 = *puVar5;
    uStack_5c = puVar5[1];
    uStack_58 = puVar5[2];
    uStack_54 = puVar5[3];
    uStack_50 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
    iStack_8._0_1_ = 6;
    uVar2 = (undefined)iStack_8;
    iStack_8._0_1_ = 6;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar6 = uStack_30;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uStack_30 - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar6) - 4) {
          iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    FUN_0097be30(&param_2,&uStack_78);
    param_3 = *(undefined4 **)(iStack_14 + 0x288);
    if ((param_2 != param_3) || (FUN_0097be30(&param_2,&uStack_60), param_2 != param_3)) {
      FUN_0054ef60(param_2 + 8);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_005507b0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  FUN_0097be30(&param_2,puVar1);
  puVar5 = *(undefined4 **)(iStack_14 + 0x288);
  if ((param_2 == puVar5) && (FUN_0097be30(&param_2,apppuStack_48), param_2 == puVar5)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_0054ef60(param_2 + 8);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20518 ; VA 0x00a42790 ; FUN_00a42790 */

void FUN_00a42790(undefined4 param_1,undefined4 param_2)

{
  FUN_00a3a6e0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 20519 ; VA 0x00a427b0 ; FUN_00a427b0 */

undefined4 __thiscall
FUN_00a427b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined auStack_4c [24];
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dec38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  iStack_8 = 0;
  if (iStack_1c == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("LocalizationService no longer exists");
  }
  piVar2 = (int *)FUN_00a42940();
  iVar7 = *piVar2;
  iVar1 = piVar2[1];
  while( true ) {
    if (iVar7 == iVar1) {
      (**(code **)(*param_1 + 0xb0))(auStack_4c);
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      uVar3 = FUN_005543f0();
      uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Key \"%s\" for locale \"%s\" not found in any active LocalizationTable",uVar4,
                   uVar3);
    }
    FUN_00fdd2c0(auStack_34,param_1,param_3,param_4,&cStack_11);
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    if (cStack_11 == '\0') break;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
LAB_00a42932:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    iVar7 = iVar7 + 8;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
  }
  FUN_0054ef60(auStack_34);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar5) - 4) goto LAB_00a42932;
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_18[1] + -1;
    piStack_18[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20520 ; VA 0x00a42940 ; FUN_00a42940 */

int __fastcall FUN_00a42940(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  
  iVar2 = param_1 + 0x2a8;
  if (*(char *)(param_1 + 0x2a4) == '\0') {
    FUN_00a3e510(param_1,iVar2);
    if (*(int *)(param_1 + 0x230) != 0) {
      puVar3 = *(undefined4 **)(param_1 + 0x2ac);
      if (*(undefined4 **)(param_1 + 0x2b0) != puVar3) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (*(int *)(param_1 + 0x234) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(param_1 + 0x234) + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *(undefined4 *)(param_1 + 0x230);
        puVar3[1] = *(undefined4 *)(param_1 + 0x234);
        *(int *)(param_1 + 0x2ac) = *(int *)(param_1 + 0x2ac) + 8;
        *(undefined *)(param_1 + 0x2a4) = 1;
        return iVar2;
      }
      FUN_00603260(puVar3,(undefined4 *)(param_1 + 0x230));
    }
    *(undefined *)(param_1 + 0x2a4) = 1;
  }
  return iVar2;
}



/* FUNCTION 20521 ; VA 0x00a429c0 ; FUN_00a429c0 */

void FUN_00a429c0(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  undefined4 uStack_f8;
  undefined4 *puStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dec7e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    puStack_14[1] = 1;
    puStack_14[2] = 1;
    *puStack_14 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_14[3] = 0;
    puStack_14[4] = 0;
    puStack_14[5] = 0;
  }
  puVar4 = puStack_14;
  puVar1 = puStack_14 + 3;
  iStack_8 = 0;
  puStack_28 = puVar1;
  puStack_24 = puStack_14;
  if (*param_2 != 0) {
    iVar5 = FUN_00a43840(*param_2);
    while (iVar5 != 0) {
      puVar6 = (undefined4 *)FUN_00fd8f40(auStack_20);
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      uStack_f8 = FUN_008882f0();
      iVar3 = _tls_index;
      puStack_f4 = (undefined4 *)0x0;
      uStack_f0 = *puVar6;
      uStack_ec = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar3 * 4) + 0x34) < DAT_01ea8c38) &&
         (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
        DAT_01ea8c2c = FUN_0057bbb0;
        DAT_01ea8c30 = FUN_005880a0;
        DAT_01ea8c34 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8c38);
      }
      puStack_f4 = &DAT_01ea8c2c;
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      if (puVar4[5] == puVar4[4]) {
        FUN_005ca4f0(puVar4[4],&uStack_f8);
      }
      else {
        FUN_005caf00(&uStack_f8);
        puVar4[4] = puVar4[4] + 0xd0;
      }
      iStack_8._0_1_ = 3;
      if (puStack_f4 != (undefined4 *)0x0) {
        (*(code *)puStack_f4[2])(&uStack_f0);
      }
      piVar8 = piStack_1c;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piVar8 + 2;
          iVar3 = *piVar2 + -1;
          *piVar2 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      iVar5 = *(int *)(iVar5 + 0x34);
      if ((iVar5 == 0) ||
         (iVar3 = *(int *)(iVar5 + 0xc), iVar7 = FUN_00fd0780(),
         (uint)*(ushort *)(iVar7 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
        iVar5 = 0;
      }
    }
  }
  piVar8 = (int *)FUN_00a42940();
  iVar3 = piVar8[1];
  for (iVar5 = *piVar8; iVar5 != iVar3; iVar5 = iVar5 + 8) {
    puVar6 = (undefined4 *)FUN_00fd8f40(auStack_20);
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    uStack_f8 = FUN_008882f0();
    iVar7 = _tls_index;
    puStack_f4 = (undefined4 *)0x0;
    uStack_f0 = *puVar6;
    uStack_ec = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar7 * 4) + 0x34) < DAT_01ea8c38) &&
       (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8c38);
    }
    puStack_f4 = &DAT_01ea8c2c;
    iStack_8 = CONCAT31(iStack_8._1_3_,5);
    if (puVar4[5] == puVar4[4]) {
      FUN_005ca4f0(puVar4[4],&uStack_f8);
    }
    else {
      FUN_005caf00(&uStack_f8);
      puVar4[4] = puVar4[4] + 0xd0;
    }
    iStack_8._0_1_ = 6;
    if (puStack_f4 != (undefined4 *)0x0) {
      (*(code *)puStack_f4[2])(&uStack_f0);
    }
    piVar8 = piStack_1c;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar8 + 2;
        iVar7 = *piVar2 + -1;
        *piVar2 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  *param_1 = (int)puVar1;
  param_1[1] = (int)puStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20522 ; VA 0x00a42d50 ; FUN_00a42d50 */

int * FUN_00a42d50(int *param_1,undefined4 *param_2,int param_3,int param_4,int param_5,
                  undefined4 param_6,uint param_7)

{
  char cVar1;
  undefined4 *puVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  puVar2 = &param_2;
  if (0xf < param_7) {
    puVar2 = param_2;
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(puVar2,param_6,"zh-cjv",6);
  if (cVar1 != '\0') {
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    FUN_005542c0("cmn-Hans",8);
    if (0xf < param_7) {
      uVar3 = param_7 + 1;
      puVar2 = param_2;
      if (0xfff < uVar3) {
        puVar2 = (undefined4 *)param_2[-1];
        uVar3 = param_7 + 0x24;
        if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = (int)param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  *(ulonglong *)(param_1 + 4) = CONCAT44(param_7,param_6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20523 ; VA 0x00a42e30 ; FUN_00a42e30 */

void FUN_00a42e30(void)

{
  int iVar1;
  
  if (DAT_01ee780c == 0) {
    iVar1 = FUN_00a36e80();
    DAT_01ee780c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 20524 ; VA 0x00a42e50 ; FUN_00a42e50 */

void __thiscall FUN_00a42e50(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deca0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5[2] = 0;
  }
  iStack_18 = 0;
  iStack_14 = 0;
  FUN_008aaf20(puVar5,param_2);
  iVar4 = iStack_18;
  piStack_1c = *(int **)(param_1 + 0x5c);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piStack_1c[1] = piStack_1c[1] + 1;
    UNLOCK();
    piStack_1c = *(int **)(param_1 + 0x5c);
  }
  uStack_20 = *(undefined4 *)(param_1 + 0x58);
  uStack_8 = 1;
  puVar5 = *(undefined4 **)(iStack_18 + 4);
  if (*(undefined4 **)(iStack_18 + 8) == puVar5) {
    FUN_00603a30(puVar5,&uStack_20);
    piVar3 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  else {
    *puVar5 = uStack_20;
    puVar5[1] = piStack_1c;
    *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 8;
  }
  *param_2 = iVar4;
  param_2[1] = iStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20525 ; VA 0x00a42f40 ; FUN_00a42f40 */

void __thiscall FUN_00a42f40(int param_1,undefined4 param_2,uint param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000028;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  uint *puStack_68;
  undefined8 uStack_64;
  int aiStack_50 [5];
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017decd8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa4;
  uStack_8 = 1;
  uStack_64 = CONCAT44(0xa42f6f,(undefined4)uStack_64);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01679ce0();
  uStack_8._0_1_ = 2;
  cStack_15 = DAT_01d66018 <= (int)(uVar1 % 10000);
  if (DAT_01d665a0 == '\0') {
    FUN_00a431c0(&uStack_74,param_2);
  }
  else {
    if (*(uint *)(param_1 + 0x60) == 0) {
      puStack_1c = (undefined *)&uStack_74;
      uVar3 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar3);
    }
    puStack_1c = (undefined *)&uStack_74;
    puVar2 = (undefined4 *)
             (**(code **)((*(uint *)(param_1 + 0x60) & 0xfffffffe) + 4))
                       (aiStack_50,param_1 + 0x68,param_2);
    uStack_74 = *puVar2;
    uStack_70 = puVar2[1];
    uStack_6c = puVar2[2];
    puStack_68 = (uint *)puVar2[3];
    uStack_64 = *(undefined8 *)(puVar2 + 4);
    puVar2[4] = 0;
    puVar2[5] = 0xf;
    *(undefined *)puVar2 = 0;
    if (0xf < uStack_3c) {
      uVar1 = uStack_3c + 1;
      iVar4 = aiStack_50[0];
      if (0xfff < uVar1) {
        iVar4 = *(int *)(aiStack_50[0] + -4);
        uVar1 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar1);
    }
  }
  FUN_005e65e0();
  if (cStack_15 != '\0') {
    uStack_64 = 0x2801942cec;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    puStack_68 = (uint *)0xa4305d;
    FUN_005542c0();
    puStack_68 = auStack_38;
    uStack_8._0_1_ = 4;
    uStack_64 = 1;
    uStack_6c = 0xa4306e;
    FUN_008783f0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      uVar1 = auStack_38[0];
      if (0xfff < uVar5) {
        uVar1 = *(uint *)(auStack_38[0] - 4);
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar1) - 4) {
          uStack_64 = CONCAT44(&UNK_00a431b4,(undefined4)uStack_64);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_64 = CONCAT44(uVar5,uVar1);
      puStack_68 = (uint *)0xa430a6;
      FUN_01674ea0();
    }
  }
  uStack_8 = 7;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_68 = (uint *)&stack0x00000010;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0xa430d1;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = (uint *)&stack0x00000030;
    uStack_64 = CONCAT44(2,puStack_68);
    uStack_6c = 0xa430ff;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20526 ; VA 0x00a43115 ; Catch@00a43115 */

undefined4 Catch_00a43115(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x1c);
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_0054eff0(uVar2);
  FUN_005e65e0();
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_0086f2f0(3,"GetCountryRegionForPlayerAsync failed %s",uVar2);
  if (*(char *)(unaff_EBP + -0x11) != '\0') {
    *(undefined4 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x20) = 0xf;
    *(undefined *)(unaff_EBP + -0x34) = 0;
    FUN_005542c0("GetCountryRegionForPlayerAsync_Failed",0x25);
    *(undefined *)(unaff_EBP + -4) = 6;
    FUN_008783f0(unaff_EBP + -0x34,1,0);
    FUN_005507b0();
  }
  return 0xa430a9;
}



/* FUNCTION 20527 ; VA 0x00a431c0 ; FUN_00a431c0 */

undefined4 __thiscall FUN_00a431c0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  int iStack_20;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00562c90(aiStack_18,param_3);
  uStack_8 = 0;
  if (aiStack_18[0] == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Instance was not a player");
  }
  iVar1 = FUN_008f7870(param_1);
  if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("LocalizationService is missing");
  }
  if (*(int *)(iVar1 + 0x4a0) == 1) {
    piVar2 = (int *)FUN_00564080();
    if (*piVar2 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Players not found");
    }
    if (*(int *)(*piVar2 + 0xf4) != aiStack_18[0]) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("This method cannot be called on the client for a non-local player");
    }
  }
  FUN_0054ef60(aiStack_18[0] + 0x458);
  FUN_005507b0();
  if (iStack_20 != 0) {
    FUN_0054ef60(aiStack_18[0] + 0x458);
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Empty value for player country region");
}



/* FUNCTION 20528 ; VA 0x00a432a0 ; FUN_00a432a0 */

undefined4 __thiscall FUN_00a432a0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x200);
  return param_2;
}



/* FUNCTION 20529 ; VA 0x00a432c0 ; FUN_00a432c0 */

undefined4 __thiscall FUN_00a432c0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x1e8);
  return param_2;
}



/* FUNCTION 20530 ; VA 0x00a432e0 ; FUN_00a432e0 */

int __fastcall FUN_00a432e0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 ****ppppuVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  (**(code **)(*(int *)(param_1 + -0x54) + 0xb0))(apppuStack_2c);
  uVar9 = uStack_18;
  ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
  iVar8 = param_1 + 4;
  uStack_8 = 0;
  if (0xf < *(uint *)(param_1 + 0x18)) {
    iVar8 = *(int *)(param_1 + 4);
  }
  ppppuVar5 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar5 = (undefined4 ****)apppuStack_2c[0];
  }
  cVar4 = FUN_0055c360(ppppuVar5,uStack_1c,iVar8,*(undefined4 *)(param_1 + 0x14));
  if (cVar4 == '\0') {
    puVar6 = (undefined4 *)FUN_00fc5080(apppuStack_2c);
    uVar1 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *(undefined4 *)(iStack_14 + 0x1c) = *puVar6;
    *(undefined4 *)(iStack_14 + 0x20) = uVar1;
    *(undefined4 *)(iStack_14 + 0x24) = uVar2;
    *(undefined4 *)(iStack_14 + 0x28) = uVar3;
    uVar1 = puVar6[5];
    uVar2 = puVar6[6];
    uVar3 = puVar6[7];
    *(undefined4 *)(iStack_14 + 0x2c) = puVar6[4];
    *(undefined4 *)(iStack_14 + 0x30) = uVar1;
    *(undefined4 *)(iStack_14 + 0x34) = uVar2;
    *(undefined4 *)(iStack_14 + 0x38) = uVar3;
    *(undefined8 *)(iStack_14 + 0x3c) = *(undefined8 *)(puVar6 + 8);
    ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
    uVar9 = uStack_18;
    if ((undefined4 ****)(iStack_14 + 4) != apppuStack_2c) {
      ppppuVar7 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_005542c0(ppppuVar7,uStack_1c);
      ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
      uVar9 = uStack_18;
    }
  }
  iStack_14 = iStack_14 + 0x1c;
  if (0xf < uVar9) {
    uVar10 = uVar9 + 1;
    ppppuVar5 = ppppuVar7;
    if (0xfff < uVar10) {
      ppppuVar5 = (undefined4 ****)ppppuVar7[-1];
      uVar10 = uVar9 + 0x24;
      if (0x1f < (uint)((int)ppppuVar7 + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar10);
  }
  ExceptionList = pvStack_10;
  return iStack_14;
}



/* FUNCTION 20531 ; VA 0x00a433e0 ; FUN_00a433e0 */

undefined4 __thiscall FUN_00a433e0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = param_1 + 0x1d0;
  if (*(int *)(param_1 + 0x1e0) == 0) {
    iVar1 = param_1 + 0x170;
  }
  FUN_0054ef60(iVar1);
  return param_2;
}



/* FUNCTION 20532 ; VA 0x00a43410 ; FUN_00a43410 */

undefined4 __thiscall FUN_00a43410(int param_1,undefined4 param_2)

{
  if (DAT_01d66090 == '\0') {
    if (*(int *)(param_1 + 0x1e0) == 0) {
      if (*(int *)(param_1 + 0x198) == 0) goto LAB_00a4342f;
      goto LAB_00a4346f;
    }
  }
  else {
    if (*(int *)(param_1 + 0x198) != 0) {
LAB_00a4346f:
      FUN_0054ef60(param_1 + 0x188);
      return param_2;
    }
    if (*(int *)(param_1 + 0x1e0) == 0) {
LAB_00a4342f:
      FUN_0054ef60(param_1 + 0x170);
      return param_2;
    }
  }
  FUN_0054ef60(param_1 + 0x1d0);
  return param_2;
}



/* FUNCTION 20533 ; VA 0x00a43490 ; FUN_00a43490 */

undefined4 __thiscall FUN_00a43490(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x218);
  return param_2;
}



/* FUNCTION 20534 ; VA 0x00a434b0 ; FUN_00a434b0 */

int * __thiscall FUN_00a434b0(int param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar1 = param_1 + 0x1d0;
  if (*(int *)(param_1 + 0x1e0) == 0) {
    iVar1 = param_1 + 0x170;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(iVar1);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    param_2[4] = 0;
    param_2[5] = 0;
    *param_2 = iStack_28;
    param_2[1] = iStack_24;
    param_2[2] = iStack_20;
    param_2[3] = iStack_1c;
    *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_14,iStack_18);
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = param_1 + 0x1b8;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    iVar1 = param_1 + 0x140;
  }
  FUN_0054ef60(iVar1);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = iStack_28;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(iStack_28 + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (iStack_28 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20535 ; VA 0x00a435a0 ; FUN_00a435a0 */

undefined * FUN_00a435a0(undefined *param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_8 = 0;
  if (param_2 != 0) {
    FUN_00a4a990(param_2,0,param_1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20536 ; VA 0x00a43620 ; FUN_00a43620 */

undefined4 __thiscall FUN_00a43620(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int aiStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d00a8;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  iStack_1c = 0;
  iVar7 = *(int *)(param_1 + 0xa4);
  ExceptionList = &pvStack_10;
  if (iVar7 != 0) {
    piVar1 = (int *)(iVar7 + 4);
    iVar7 = *(int *)(iVar7 + 4);
    ExceptionList = &pvStack_10;
    while (iVar7 != 0) {
      LOCK();
      iVar6 = *piVar1;
      if (iVar7 == iVar6) {
        *piVar1 = iVar7 + 1;
        iVar6 = iVar7;
      }
      UNLOCK();
      if (iVar6 == iVar7) {
        iStack_1c = *(int *)(param_1 + 0xa0);
        piStack_18 = *(int **)(param_1 + 0xa4);
        break;
      }
      iVar7 = *piVar1;
    }
  }
  piVar1 = piStack_18;
  uStack_8 = 0;
  if (iStack_1c == 0) {
    if (*(int *)(param_1 + 0xb8) == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Invalid player and locale for translator!");
    }
  }
  else {
    puStack_14 = (undefined4 *)FUN_00927240(aiStack_34);
    if ((undefined4 *)(param_1 + 0xa8) != puStack_14) {
      FUN_005507b0();
      uVar3 = puStack_14[1];
      uVar4 = puStack_14[2];
      uVar5 = puStack_14[3];
      *(undefined4 *)(param_1 + 0xa8) = *puStack_14;
      *(undefined4 *)(param_1 + 0xac) = uVar3;
      *(undefined4 *)(param_1 + 0xb0) = uVar4;
      *(undefined4 *)(param_1 + 0xb4) = uVar5;
      *(undefined8 *)(param_1 + 0xb8) = *(undefined8 *)(puStack_14 + 4);
      puStack_14[4] = 0;
      puStack_14[5] = 0xf;
      *(undefined *)puStack_14 = 0;
    }
    if (0xf < uStack_20) {
      uVar8 = uStack_20 + 1;
      iVar7 = aiStack_34[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_34[0] + -4);
        uVar8 = uStack_20 + 0x24;
        if (0x1f < (aiStack_34[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
  }
  FUN_0054ef60(param_1 + 0xa8);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar7 = piVar1[1] + -1;
    piVar1[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar7 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20537 ; VA 0x00a43780 ; FUN_00a43780 */

undefined4 __thiscall FUN_00a43780(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x26c);
  return param_2;
}



/* FUNCTION 20538 ; VA 0x00a437a0 ; FUN_00a437a0 */

undefined4 * __thiscall FUN_00a437a0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = *(int *)(param_1 + 0x140);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    piVar3 = (int *)(iVar1 + 4);
    if (iVar2 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar3;
        if (iVar2 == iVar1) {
          *piVar3 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) break;
        iVar2 = *piVar3;
        if (iVar2 == 0) {
          return param_2;
        }
      }
      *param_2 = *(undefined4 *)(param_1 + 0x13c);
      param_2[1] = *(undefined4 *)(param_1 + 0x140);
    }
  }
  return param_2;
}



/* FUNCTION 20539 ; VA 0x00a43810 ; FUN_00a43810 */

undefined4 __thiscall FUN_00a43810(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = param_1 + 0x1b8;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    iVar1 = param_1 + 0x140;
  }
  FUN_0054ef60(iVar1);
  return param_2;
}



/* FUNCTION 20540 ; VA 0x00a43840 ; FUN_00a43840 */

int FUN_00a43840(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_1 != 0) {
    do {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar3 = FUN_00d59db0();
      if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da)) && (iVar2 = *(int *)(param_1 + 0x140), iVar2 != 0)) {
        piVar4 = (int *)(iVar2 + 4);
        iVar2 = *(int *)(iVar2 + 4);
        while (iVar2 != 0) {
          LOCK();
          iVar3 = *piVar4;
          if (iVar2 == iVar3) {
            *piVar4 = iVar2 + 1;
            iVar3 = iVar2;
          }
          UNLOCK();
          if (iVar3 == iVar2) {
            iVar2 = *(int *)(param_1 + 0x13c);
            piVar4 = *(int **)(param_1 + 0x140);
            if (iVar2 != 0) {
              if (piVar4 != (int *)0x0) {
                LOCK();
                iVar3 = piVar4[1] + -1;
                piVar4[1] = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)*piVar4)();
                  LOCK();
                  piVar1 = piVar4 + 2;
                  iVar3 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar3 == 1) {
                    (**(code **)(*piVar4 + 4))();
                  }
                }
              }
              return iVar2;
            }
            if (piVar4 != (int *)0x0) {
              LOCK();
              iVar2 = piVar4[1] + -1;
              piVar4[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piVar4)();
                LOCK();
                iVar2 = piVar4[2] + -1;
                piVar4[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            break;
          }
          iVar2 = *piVar4;
        }
      }
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return 0;
}



/* FUNCTION 20541 ; VA 0x00a43920 ; FUN_00a43920 */

undefined __fastcall FUN_00a43920(int param_1)

{
  return *(undefined *)(param_1 + 0x2c2);
}



/* FUNCTION 20542 ; VA 0x00a43930 ; FUN_00a43930 */

undefined4 __thiscall FUN_00a43930(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x128);
  return param_2;
}



/* FUNCTION 20543 ; VA 0x00a43950 ; FUN_00a43950 */

void __thiscall
FUN_00a43950(int param_1,undefined4 param_2,int ****param_3,int ****param_4,uint param_5)

{
  char cVar1;
  int iVar2;
  int ****ppppiVar3;
  int iVar4;
  int ****ppppiVar5;
  int ***pppiVar6;
  uint in_stack_00000030;
  undefined4 uVar7;
  undefined4 *puVar8;
  int **appiStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 uStack_98;
  int ***pppiStack_94;
  int ***pppiStack_90;
  int ***pppiStack_8c;
  int ***pppiStack_88;
  undefined auStack_28 [4];
  int *piStack_24;
  int ***pppiStack_20;
  int ***pppiStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ded50;
  pvStack_10 = ExceptionList;
  iStack_18 = *(int *)(param_1 + 0x2c8);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x2c8) = iStack_18 + 1;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  cStack_11 = '\0';
  if (DAT_01d660d0 == '\0') {
    pppiStack_88 = (int ***)param_4;
    pppiVar6 = (int ***)(param_1 + 0x239 + (uint)*(byte *)(param_1 + 0x238));
    pppiStack_90 = (int ***)0xa43cce;
    pppiStack_8c = pppiVar6;
    pppiStack_90 = (int ***)FUN_0055c740();
    ppppiVar5 = param_4;
    pppiStack_88 = (int ***)(-(uint)(pppiVar6 != (int ***)0x0) & (int)pppiVar6 + 1U);
    pppiStack_8c = (int ***)param_4;
    pppiStack_94 = (int ***)&pppiStack_20;
    uStack_98 = 0xa43cef;
    FUN_00562fc0();
    if ((int ****)pppiStack_20 == (int ****)0x0) {
      pppiStack_88 = (int ***)ppppiVar5;
      if (*(char *)(param_1 + 0x250) == '\0') {
        pppiStack_8c = (int ***)0xa43e35;
        iVar4 = FUN_00a3c820();
        iVar2 = iStack_18;
        param_4 = (int ****)(iVar4 + 0x18);
        pppiStack_88 = (int ***)iStack_18;
        pppiStack_20 = appiStack_a8;
        FUN_0054f510(&stack0x00000030);
        uStack_8._0_1_ = 10;
        FUN_0054f510(&param_5);
        if (param_3 != (int ****)0x0) {
          LOCK();
          param_3[1] = (int ***)((int)param_3[1] + 1);
          UNLOCK();
        }
        uStack_8._0_1_ = 2;
        pppiStack_88 = (int ***)FUN_00a3b250(param_2,param_3);
        uStack_8._0_1_ = 0xb;
        pppiStack_8c = (int ***)0xa43ea3;
        FUN_00a4a710();
        uStack_8._0_1_ = 2;
        pppiStack_88 = (int ***)0xa43eaf;
        FUN_005e6080();
        pppiStack_88 = (int ***)iVar2;
        cVar1 = '\x01';
      }
      else {
        pppiStack_8c = (int ***)0xa43d4d;
        cVar1 = FUN_00a45700();
        if (cVar1 == '\0') {
          puStack_9c = &param_2;
          pppiStack_90 = (int ***)param_4;
          uStack_a0 = 0xa43e15;
          FUN_005587b0();
          uStack_a0 = 0xa43e1d;
          puStack_9c = &pppiStack_8c;
          FUN_00a44420();
          pppiStack_90 = (int ***)0xa43e25;
          FUN_0096e490();
          ppppiVar5 = param_4;
          pppiStack_88 = (int ***)iStack_18;
          cVar1 = cStack_11;
        }
        else {
          pppiStack_88 = (int ***)ppppiVar5;
          pppiStack_8c = (int ***)0xa43d61;
          FUN_00a3c820();
          pppiStack_88 = (int ***)iStack_18;
          pppiStack_20 = appiStack_a8;
          FUN_0054f510(&stack0x00000030);
          uStack_8._0_1_ = 8;
          puVar8 = &param_5;
          uVar7 = 0xa43d89;
          FUN_0054f510(puVar8);
          FUN_00557fc0(&param_2);
          uStack_8._0_1_ = 2;
          pppiStack_88 = (int ***)FUN_00a3b250(uVar7,puVar8);
          uStack_8._0_1_ = 9;
          pppiStack_8c = (int ***)0xa43db0;
          FUN_00a4a710();
          uStack_8._0_1_ = 2;
          pppiStack_88 = (int ***)0xa43dbc;
          FUN_005e6080();
          ppppiVar5 = param_4;
          pppiStack_88 = (int ***)param_4;
          pppiStack_8c = (int ***)0xa43dcb;
          iVar2 = FUN_00a3c820();
          if ((*(int *)(iVar2 + 0x1c) - *(int *)(iVar2 + 0x18)) / 0x50 == 1) {
            pppiStack_88 = (int ***)0x0;
            pppiStack_8c = (int ***)(param_1 + 0x1a0);
            pppiStack_90 = (int ***)ppppiVar5;
            pppiStack_94 = (int ***)0xa43df8;
            FUN_00a41980();
          }
          pppiStack_88 = (int ***)iStack_18;
          cVar1 = '\x01';
        }
      }
    }
    else {
      puStack_9c = &pppiStack_8c;
      pppiStack_90 = (int ***)ppppiVar5;
      if (param_3 != (int ****)0x0) {
        LOCK();
        param_3[2] = (int ***)((int)param_3[2] + 1);
        UNLOCK();
      }
      uStack_98 = param_2;
      pppiStack_94 = (int ***)param_3;
      uStack_a0 = 0xa43d2b;
      FUN_00a44420();
      pppiStack_90 = (int ***)0xa43d33;
      FUN_0096e490();
      pppiStack_88 = (int ***)iStack_18;
      cVar1 = cStack_11;
    }
  }
  else {
    pppiStack_8c = (int ***)0xa439a1;
    pppiStack_88 = (int ***)param_1;
    iVar2 = FUN_008f7870();
    if (iVar2 == 0) {
      puStack_9c = &pppiStack_8c;
      pppiStack_90 = (int ***)param_4;
      if (param_3 != (int ****)0x0) {
        LOCK();
        param_3[2] = (int ***)((int)param_3[2] + 1);
        UNLOCK();
      }
      uStack_98 = param_2;
      pppiStack_94 = (int ***)param_3;
      uStack_a0 = 0xa439d8;
      FUN_00a44420();
      pppiStack_90 = (int ***)0xa439e0;
      FUN_0096e490();
      goto LAB_00a43c2c;
    }
    pppiStack_20 = *(int ****)(iVar2 + 0x440);
    pppiStack_1c = *(int ****)(iVar2 + 0x444);
    pppiStack_88 = (int ***)auStack_28;
    pppiStack_8c = (int ***)0xa43a00;
    FUN_00a53720();
    ppppiVar5 = param_4;
    pppiStack_88 = (int ***)param_4;
    pppiStack_8c = pppiStack_1c;
    uStack_8._0_1_ = 3;
    pppiStack_90 = pppiStack_20;
    pppiStack_94 = (int ***)0xa43a19;
    cVar1 = FUN_00a540a0();
    if (cVar1 == '\0') {
      if (*(char *)(param_1 + 0x250) == '\0') {
        pppiStack_88 = (int ***)ppppiVar5;
        pppiStack_8c = (int ***)0xa43b84;
        FUN_00a3c820();
        pppiStack_88 = (int ***)iStack_18;
        pppiStack_20 = appiStack_a8;
        FUN_0054f510(&stack0x00000030);
        uStack_8._0_1_ = 6;
        puVar8 = &param_5;
        uVar7 = 0xa43bac;
        FUN_0054f510(puVar8);
        FUN_00557fc0(&param_2);
        uStack_8._0_1_ = 3;
        pppiStack_88 = (int ***)FUN_00a3b250(uVar7,puVar8);
        uStack_8._0_1_ = 7;
        pppiStack_8c = (int ***)0xa43bd3;
        FUN_00a4a710();
        pppiStack_88 = (int ***)0xa43bdb;
        FUN_005e6080();
      }
      else {
        pppiStack_88 = (int ***)(param_1 + 0x1a0);
        pppiStack_8c = (int ***)ppppiVar5;
        pppiStack_90 = pppiStack_1c;
        pppiStack_94 = pppiStack_20;
        uStack_98 = 0xa43a83;
        cVar1 = FUN_00a539f0();
        if (cVar1 == '\0') {
          puStack_9c = &param_2;
          pppiStack_90 = (int ***)param_4;
          uStack_a0 = 0xa43b66;
          FUN_005587b0();
          uStack_a0 = 0xa43b6e;
          puStack_9c = &pppiStack_8c;
          FUN_00a44420();
          pppiStack_90 = (int ***)0xa43b76;
          FUN_0096e490();
          goto LAB_00a43be0;
        }
        pppiStack_88 = (int ***)ppppiVar5;
        pppiStack_8c = (int ***)0xa43a97;
        FUN_00a3c820();
        pppiStack_88 = (int ***)iStack_18;
        pppiStack_20 = appiStack_a8;
        FUN_0054f510(&stack0x00000030);
        uStack_8._0_1_ = 4;
        puVar8 = &param_5;
        uVar7 = 0xa43abf;
        FUN_0054f510(puVar8);
        FUN_00557fc0(&param_2);
        uStack_8._0_1_ = 3;
        pppiStack_88 = (int ***)FUN_00a3b250(uVar7,puVar8);
        uStack_8._0_1_ = 5;
        pppiStack_8c = (int ***)0xa43ae6;
        FUN_00a4a710();
        uStack_8._0_1_ = 3;
        pppiStack_88 = (int ***)0xa43af2;
        FUN_005e6080();
        ppppiVar5 = param_4;
        pppiStack_88 = (int ***)param_4;
        pppiStack_8c = (int ***)0xa43b01;
        iVar2 = FUN_00a3c820();
        if ((*(int *)(iVar2 + 0x1c) - *(int *)(iVar2 + 0x18)) / 0x50 == 1) {
          pppiStack_8c = (int ***)0xa43b23;
          pppiStack_88 = (int ***)param_1;
          ppppiVar3 = (int ****)FUN_008f7870();
          if (ppppiVar3 == (int ****)0x0) {
            pppiStack_88 = (int ***)0xa43b32;
            FUN_00550b30();
            goto LAB_00a43c2c;
          }
          pppiStack_88 = (int ***)(param_1 + 0x1a0);
          pppiStack_8c = (int ***)ppppiVar5;
          pppiStack_94 = (int ***)0xa43b48;
          pppiStack_90 = (int ***)ppppiVar3;
          FUN_00a52ce0();
        }
      }
      cStack_11 = '\x01';
    }
    else {
      puStack_9c = &pppiStack_8c;
      pppiStack_90 = (int ***)ppppiVar5;
      if (param_3 != (int ****)0x0) {
        LOCK();
        param_3[2] = (int ***)((int)param_3[2] + 1);
        UNLOCK();
      }
      uStack_98 = param_2;
      pppiStack_94 = (int ***)param_3;
      uStack_a0 = 0xa43a53;
      FUN_00a44420();
      pppiStack_90 = (int ***)0xa43a5b;
      FUN_0096e490();
    }
LAB_00a43be0:
    uStack_8._0_1_ = 2;
    ppppiVar5 = param_4;
    pppiStack_88 = (int ***)iStack_18;
    cVar1 = cStack_11;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppiStack_88 = (int ***)0xa43bfa;
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = piStack_24[2] + -1;
        piStack_24[2] = iVar2;
        UNLOCK();
        ppppiVar5 = param_4;
        pppiStack_88 = (int ***)iStack_18;
        cVar1 = cStack_11;
        if (iVar2 == 0) {
          pppiStack_88 = (int ***)0xa43c0a;
          (**(code **)(*piStack_24 + 4))();
          ppppiVar5 = param_4;
          pppiStack_88 = (int ***)iStack_18;
          cVar1 = cStack_11;
        }
      }
    }
  }
  if ((DAT_01d66068 != '\0') && (cVar1 != '\0')) {
    pppiStack_90 = (int ***)0xa43c29;
    pppiStack_8c = (int ***)ppppiVar5;
    FUN_00a44500();
  }
LAB_00a43c2c:
  ppppiVar5 = param_3;
  if (param_3 != (int ****)0x0) {
    LOCK();
    pppiVar6 = (int ***)((int)param_3[1] + -1);
    param_3[1] = pppiVar6;
    UNLOCK();
    if (pppiVar6 == (int ***)0x0) {
      pppiStack_88 = (int ***)0xa43c42;
      (*(code *)**param_3)();
      LOCK();
      ppppiVar3 = ppppiVar5 + 2;
      pppiVar6 = *ppppiVar3;
      *ppppiVar3 = (int ***)((int)*ppppiVar3 + -1);
      UNLOCK();
      if (pppiVar6 == (int ***)0x1) {
        pppiStack_88 = (int ***)0xa43c51;
        (*(code *)(*ppppiVar5)[1])();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      pppiStack_90 = (int ***)&stack0x00000018;
      pppiStack_88 = (int ***)0x2;
      pppiStack_94 = (int ***)0xa43c72;
      pppiStack_8c = pppiStack_90;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    pppiStack_90 = (int ***)&stack0x00000038;
    pppiStack_88 = (int ***)0x2;
    pppiStack_94 = (int ***)0xa43ca0;
    pppiStack_8c = pppiStack_90;
    (**(code **)(in_stack_00000030 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20544 ; VA 0x00a43ec0 ; FUN_00a43ec0 */

void FUN_00a43ec0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
                 undefined4 param_6,undefined4 *param_7,ulonglong param_8,char *param_9,
                 undefined4 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
                 undefined4 param_14,undefined8 param_15)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_70 [2];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  undefined8 uStack_58;
  char *pcStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined8 uStack_38;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ded80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*(uint *)(param_1 + 0x10) < 2) {
    uStack_4c = 0x20;
    uStack_38 = 0xf00000000;
    pcStack_50 = "Too few characters in locale id!";
    uStack_48 = uStack_48 & 0xffffff00;
    uStack_58 = CONCAT44(0xa43f10,(undefined4)uStack_58);
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_4c = 0xa43f18;
    FUN_005e65e0();
  }
  else {
    uStack_38 = CONCAT44(param_1,auStack_2c);
    puStack_3c = (undefined4 *)0xa43f27;
    ExceptionList = &pvStack_10;
    FUN_00f854f0();
    puStack_14 = (undefined *)&pcStack_50;
    uStack_8._0_1_ = 2;
    pcStack_50 = (char *)0x0;
    if (param_9 != (char *)0x0) {
      pcStack_50 = param_9;
      if (((uint)param_9 & 1) == 0) {
        uStack_58 = ZEXT48(&uStack_48);
        puStack_5c = &param_11;
        uStack_60 = 0xa43f6f;
        (**(code **)((uint)param_9 & 0xfffffffe))();
      }
      else {
        uStack_48 = param_11;
        uStack_44 = param_12;
        uStack_40 = param_13;
        puStack_3c = (undefined4 *)param_14;
        uStack_38 = param_15;
      }
    }
    puStack_14 = (undefined *)auStack_70;
    uStack_8._0_1_ = 3;
    auStack_70[0] = 0;
    puVar1 = auStack_70;
    if (param_2 != 0) {
      auStack_70[0] = param_2;
      if ((param_2 & 1) == 0) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_68,0);
        puVar1 = (uint *)puStack_14;
      }
      else {
        uStack_68 = param_4;
        uStack_64 = param_5;
        uStack_60 = param_6;
        puStack_5c = param_7;
        uStack_58 = param_8;
        puVar1 = auStack_70;
      }
    }
    puStack_14 = (undefined *)puVar1;
    uStack_8._0_1_ = 2;
    FUN_00a43950(0,0,auStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_18) {
      uVar3 = uStack_18 + 1;
      uVar2 = auStack_2c[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_2c[0] - 4);
        uVar3 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar2) - 4) {
          uStack_38 = CONCAT44(&UNK_00a44089,(undefined4)uStack_38);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_38 = CONCAT44(uVar3,uVar2);
      puStack_3c = (undefined4 *)0xa4400c;
      FUN_01674ea0();
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_3c = &param_4;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xa44042;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_9 != (char *)0x0) && (((uint)param_9 & 1) == 0)) &&
     (*(code **)((uint)param_9 & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = &param_11;
    uStack_38 = CONCAT44(2,puStack_3c);
    uStack_40 = 0xa44070;
    (**(code **)((uint)param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20545 ; VA 0x00a44090 ; FUN_00a44090 */

undefined4 FUN_00a44090(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deda0;
  pvStack_10 = ExceptionList;
  if (*param_2 == 0) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Player cannot be nil");
  }
  ExceptionList = &pvStack_10;
  FUN_00562c90(aiStack_18,param_2);
  uStack_8 = 0;
  if (aiStack_18[0] == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Instance was not a player");
  }
  iVar1 = FUN_008f7870(*param_2);
  if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to access datamodel");
  }
  if (*(int *)(iVar1 + 0x4a0) == 1) {
    piVar2 = (int *)FUN_00564080();
    if (*piVar2 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Players not found");
    }
    if (*(int *)(*piVar2 + 0xf4) != aiStack_18[0]) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("This method cannot be called on the client for a non-local player.");
    }
  }
  iVar1 = FUN_009171d0(*param_2);
  if (iVar1 != 0) {
    FUN_0060dcd0(auStack_20,iVar1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar3 = FUN_00a39e60(auStack_28,aiStack_18,auStack_20);
    FUN_00557f90(uVar3);
    FUN_00550b30();
    FUN_00550b30();
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("LocalizationService not found for player. Player might be disconnected.");
}



/* FUNCTION 20546 ; VA 0x00a441c0 ; FUN_00a441c0 */

void __thiscall
FUN_00a441c0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
            ulonglong param_9,char *param_10,undefined4 param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_80 [2];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined8 uStack_68;
  char *pcStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined8 uStack_48;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dedd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_48 = CONCAT44(param_1,0xa441ef);
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  iVar3 = FUN_008f7870();
  if ((iVar3 != 0) && (*(int *)(iVar3 + 0x440) == 0 && *(int *)(iVar3 + 0x444) == 0)) {
    uStack_5c = 0x47;
    uStack_48 = 0xf00000000;
    pcStack_60 = "Publishing the game is required to use GetTranslatorForPlayerAsync API.";
    uStack_58 = uStack_58 & 0xffffff00;
    uStack_68 = CONCAT44(0xa44226,(undefined4)uStack_68);
    FUN_005542c0();
    uStack_5c = 0xa4422e;
    FUN_005e65e0();
  }
  uStack_48 = CONCAT44(param_2,&iStack_20);
  puStack_4c = (undefined4 *)0xa4423a;
  FUN_00562c90();
  uStack_8._0_1_ = 2;
  if (iStack_20 == 0) {
    uStack_5c = 0x19;
    uStack_48 = 0xf00000000;
    pcStack_60 = "Instance was not a player";
    uStack_58 = uStack_58 & 0xffffff00;
    uStack_68 = CONCAT44(0xa44266,(undefined4)uStack_68);
    FUN_005542c0();
    uStack_5c = 0xa4426e;
    FUN_005e65e0();
  }
  else {
    uStack_48 = CONCAT44(auStack_38,0xa44281);
    uVar4 = FUN_00927240();
    puStack_18 = (undefined *)&pcStack_60;
    uStack_8._0_1_ = 3;
    pcStack_60 = (char *)0x0;
    if (param_10 != (char *)0x0) {
      pcStack_60 = param_10;
      if (((uint)param_10 & 1) == 0) {
        uStack_68 = ZEXT48(&uStack_58);
        puStack_6c = &param_12;
        uStack_70 = 0xa442cb;
        (**(code **)((uint)param_10 & 0xfffffffe))();
      }
      else {
        uStack_58 = param_12;
        uStack_54 = param_13;
        uStack_50 = param_14;
        puStack_4c = (undefined4 *)param_15;
        uStack_48 = param_16;
      }
    }
    puStack_18 = (undefined *)auStack_80;
    uStack_8._0_1_ = 4;
    auStack_80[0] = 0;
    puVar2 = auStack_80;
    if (param_3 != 0) {
      auStack_80[0] = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_78,0);
        puVar2 = (uint *)puStack_18;
      }
      else {
        uStack_78 = param_5;
        uStack_74 = param_6;
        uStack_70 = param_7;
        puStack_6c = param_8;
        uStack_68 = param_9;
        puVar2 = auStack_80;
      }
    }
    puStack_18 = (undefined *)puVar2;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    FUN_00a43950(iStack_20,piStack_1c,uVar4);
    uStack_8._0_1_ = 2;
    if (0xf < uStack_24) {
      uVar6 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar6 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
          uStack_48 = CONCAT44(&UNK_00a4441d,(undefined4)uStack_48);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_48 = CONCAT44(uVar6,uVar5);
      puStack_4c = (undefined4 *)0xa4437a;
      FUN_01674ea0();
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      uStack_48 = CONCAT44(0xa443a5,(undefined4)uStack_48);
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_48 = CONCAT44(0xa443b4,(undefined4)uStack_48);
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_4c = &param_5;
    uStack_48 = CONCAT44(2,puStack_4c);
    uStack_50 = 0xa443d5;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_10 != (char *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_4c = &param_12;
    uStack_48 = CONCAT44(2,puStack_4c);
    uStack_50 = 0xa44403;
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20547 ; VA 0x00a44420 ; FUN_00a44420 */

undefined4 * __thiscall
FUN_00a44420(undefined4 param_1,undefined4 *param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dee00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0060dcd0(auStack_18,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar4 = (undefined4 *)FUN_00a3a000(auStack_20,&param_3,param_5,auStack_18);
  *param_2 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar2;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20548 ; VA 0x00a44500 ; FUN_00a44500 */

int __thiscall FUN_00a44500(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 auStack_9c [7];
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_68;
  int *piStack_64;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined auStack_3c [24];
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017dee40;
  pvStack_10 = ExceptionList;
  uStack_7c = (double)CONCAT44(param_1,0xa44526);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870();
  if (iVar3 != 0) {
    uStack_7c = (double)CONCAT44(0xa44539,(undefined4)uStack_7c);
    iVar3 = FUN_005cf2a0();
    if (iVar3 != 0) {
      uStack_7c = (double)CONCAT44(param_1,&uStack_20);
      uStack_80 = 0xa4454d;
      FUN_0060e0c0();
      puStack_18 = &uStack_68;
      uStack_7c = (double)DAT_01d6600c;
      puStack_14 = (undefined *)auStack_9c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[2] = piStack_1c[2] + 1;
        UNLOCK();
      }
      uStack_68 = uStack_20;
      piStack_64 = piStack_1c;
      iStack_8._0_1_ = 1;
      iStack_8._1_3_ = 0;
      FUN_0054ef60();
      uStack_48 = param_3;
      if (piStack_64 != (int *)0x0) {
        LOCK();
        piStack_64[2] = piStack_64[2] + 1;
        UNLOCK();
      }
      uStack_44 = uStack_68;
      piStack_40 = piStack_64;
      iStack_8._0_1_ = 3;
      FUN_0054ef60();
      uStack_24 = uStack_48;
      auStack_9c[0] = 0;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[2] = piStack_40[2] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 5;
      FUN_0054ef60(auStack_3c);
      iStack_8._0_1_ = 4;
      FUN_00a38f40();
      FUN_005d11a0();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005d11a0();
      iVar3 = FUN_009eef30();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          uStack_7c = (double)CONCAT44(0xa4466e,(undefined4)uStack_7c);
          iVar3 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20549 ; VA 0x00a44690 ; FUN_00a44690 */

uint FUN_00a44690(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    do {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00d59db0();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) &&
         (*(char *)(param_1 + 0x70) == '\0')) break;
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008aa870();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
LAB_00a44743:
        return CONCAT31((int3)(in_EAX >> 8),1);
      }
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b56e90();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX)
      goto LAB_00a44743;
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00b56db0();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX)
      goto LAB_00a44743;
      param_1 = *(int *)(param_1 + 0x34);
    } while (param_1 != 0);
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 20550 ; VA 0x00a44750 ; FUN_00a44750 */

void __fastcall FUN_00a44750(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(param_1 + 0x2a8);
  *(undefined *)(param_1 + 0x2a4) = 0;
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x2ac),puVar1);
  *(undefined4 *)(param_1 + 0x2ac) = *puVar1;
  FUN_00a44780(0);
  return;
}



/* FUNCTION 20551 ; VA 0x00a44780 ; FUN_00a44780 */

void __thiscall FUN_00a44780(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dee6c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee73c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee73c0), DAT_01ee73c0 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0(&DAT_018fdbdc,"LocalizationService::invalidateAutoTranslations",0xffffffff)
    ;
    DAT_01ee73bc = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01ee73b8 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee73c0);
  }
  uVar3 = DAT_01ee73bc;
  uVar2 = DAT_01ee73b8;
  uVar9 = FUN_0152d930(DAT_01ee73b8,DAT_01ee73bc);
  uStack_8 = 1;
  iVar4 = FUN_008f7870(param_1);
  if ((iVar4 != 0) && (*(char *)(iVar4 + 0x1df) == '\0')) {
    FUN_006eccd0();
    piVar5 = (int *)FUN_00564080();
    iVar4 = *piVar5;
    if (iVar4 != 0) {
      piVar5 = *(int **)(iVar4 + 0xbc);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = *(int **)(iVar4 + 0xbc);
      }
      piVar1 = *(int **)(iVar4 + 0xb8);
      uStack_8._0_1_ = 2;
      if (piVar1 != (int *)0x0) {
        iVar4 = piVar1[1];
        for (iVar8 = *piVar1; iVar8 != iVar4; iVar8 = iVar8 + 8) {
          uVar6 = thunk_FUN_00676db0();
          FUN_00a4ae10(uVar6,param_2);
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar4 = piVar5[1] + -1;
        piVar5[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    uVar6 = FUN_00562f00(param_2);
    FUN_00a4ae10(uVar6);
    if ((char)param_2 != '\0') {
      puVar7 = (undefined4 *)FUN_00636a50();
      FUN_00a4ae10(*puVar7,param_2);
    }
  }
  uStack_8 = 3;
  FUN_0152dda0(uVar2,uVar3,uVar9);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20552 ; VA 0x00a44960 ; FUN_00a44960 */

void FUN_00a44960(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  (*(code *)*param_1)(param_2,param_3,param_4);
  return;
}



/* FUNCTION 20553 ; VA 0x00a44980 ; FUN_00a44980 */

undefined4 * FUN_00a44980(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(*(code *)*param_2)(aiStack_1c,param_3);
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_1;
}



/* FUNCTION 20554 ; VA 0x00a44a10 ; FUN_00a44a10 */

int FUN_00a44a10(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a41df0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),
                         *(int *)(param_1 + 0x10) + 1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20555 ; VA 0x00a44aa0 ; FUN_00a44aa0 */

int FUN_00a44aa0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a41b20(iVar2 + 8,*(int *)(iVar2 + 0x20) + 1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20556 ; VA 0x00a44b30 ; FUN_00a44b30 */

int FUN_00a44b30(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a42010(*(int *)(param_1 + 8) + 1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20557 ; VA 0x00a44bb0 ; FUN_00a44bb0 */

void FUN_00a44bb0(void)

{
  FUN_00a3d390();
  return;
}



/* FUNCTION 20558 ; VA 0x00a44bc0 ; FUN_00a44bc0 */

void FUN_00a44bc0(void)

{
  FUN_00a3d410();
  return;
}



/* FUNCTION 20559 ; VA 0x00a44bd0 ; FUN_00a44bd0 */

int FUN_00a44bd0(int *param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dee90;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    cVar2 = *(char *)(iVar3 + 8);
    cVar4 = FUN_00fce1e0();
    if (cVar4 != cVar2) {
      FUN_008a4940(&DAT_02125ff0);
    }
    if (*(char *)(iStack_18 + 0x2c2) != *(char *)(iVar3 + 0x18)) {
      *(char *)(iStack_18 + 0x2c2) = *(char *)(iVar3 + 0x18);
      FUN_008a4940(&DAT_02126028);
    }
    if ((DAT_01d660a0 != '\0') && (*(int *)(iVar3 + 0x2c) != 0)) {
      FUN_0054ef60(iVar3 + 0x1c);
      FUN_00a4ca50();
    }
    iVar5 = *(int *)(iVar3 + 0x14);
    if ((iVar5 < 0) || ((iVar5 < 1 && (*(int *)(iVar3 + 0x10) == 0)))) {
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      FUN_005542c0(&DAT_018bf820,2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00a4ccd0(auStack_30);
      iVar5 = FUN_005507b0();
    }
    else {
      iVar5 = FUN_00a41df0(*(int *)(iVar3 + 0x10),iVar5,0);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20560 ; VA 0x00a44d00 ; FUN_00a44d00 */

void FUN_00a44d00(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  
  iVar3 = FUN_005cf2a0();
  if (iVar3 != 0) {
    uVar4 = param_1[2];
    piVar5 = (int *)param_1[1];
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
      piVar5 = (int *)param_1[1];
      uVar4 = param_1[2];
    }
    uVar2 = *param_1;
    piVar1 = piVar5 + 2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar6 = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a38d00(uVar2,piVar5,uVar4);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piVar5 + 4))(uVar6);
      }
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    FUN_009eef30(uVar6);
  }
  return;
}



/* FUNCTION 20561 ; VA 0x00a44dc0 ; FUN_00a44dc0 */

void FUN_00a44dc0(int *param_1)

{
  int iVar1;
  int iVar2;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deec8;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_005cf2a0();
  if (iVar2 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
      UNLOCK();
      iVar2 = *(int *)(iVar1 + 4);
    }
    uStack_8 = 0;
    FUN_0054ef60();
    uStack_14 = *(undefined4 *)(iVar1 + 0x20);
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    FUN_0054ef60();
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    FUN_0054ef60(auStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00a38b50();
    FUN_005d11a0();
    uStack_8 = 0xffffffff;
    FUN_005d11a0();
    FUN_009eef30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20562 ; VA 0x00a44f30 ; FUN_00a44f30 */

int FUN_00a44f30(char *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if ((iStack_18 != 0) && (*param_1 != '\0')) {
    piVar1 = (int *)(iStack_18 + 0x2a8);
    *(undefined *)(iStack_18 + 0x2a4) = 0;
    FUN_005596d0(*piVar1,*(undefined4 *)(iStack_18 + 0x2ac),piVar1);
    iVar3 = *piVar1;
    *(int *)(iStack_18 + 0x2ac) = iVar3;
    *(undefined *)(iStack_18 + 0x2c1) = 1;
    if (*(char *)(iStack_18 + 0x2c0) != '\0') {
      iVar3 = FUN_00fce1e0();
      if ((char)iVar3 != '\x01') {
        iVar3 = FUN_008a4940(&DAT_02125ff0);
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20563 ; VA 0x00a45000 ; FUN_00a45000 */

void FUN_00a45000(undefined4 param_1,undefined4 param_2)

{
  FUN_00a3d170(param_2);
  return;
}



/* FUNCTION 20564 ; VA 0x00a45020 ; FUN_00a45020 */

int FUN_00a45020(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dee90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bf820,2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_00a4ccd0(auStack_30);
    if (0xf < uStack_1c) {
      uVar5 = uStack_1c + 1;
      uVar4 = auStack_30[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_30[0] - 4);
        uVar5 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar3 = FUN_01674ea0(uVar4,uVar5);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20565 ; VA 0x00a45100 ; FUN_00a45100 */

int FUN_00a45100(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00a4ccd0(iVar2 + 8);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20566 ; VA 0x00a45180 ; FUN_00a45180 */

uint FUN_00a45180(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  char cVar5;
  byte bVar6;
  char cVar7;
  uint uVar8;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017de168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar8 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    cVar5 = *(char *)(param_1 + 8);
    cVar7 = FUN_00fce1e0();
    if (cVar7 != cVar5) {
      FUN_008a4940(&DAT_02125ff0);
    }
    bVar6 = *(byte *)(param_1 + 9);
    uVar8 = (uint)bVar6;
    if (*(byte *)(iStack_18 + 0x2c2) != bVar6) {
      *(byte *)(iStack_18 + 0x2c2) = bVar6;
      uVar8 = FUN_008a4940(&DAT_02126028);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_14 + 1);
    uVar3 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar8 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar8 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 20567 ; VA 0x00a45230 ; FUN_00a45230 */

void FUN_00a45230(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 in_stack_ffffffbc;
  undefined4 uVar8;
  
  iVar5 = FUN_005cf2a0();
  if (iVar5 != 0) {
    uVar6 = param_1[4];
    piVar7 = (int *)param_1[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[2] = piVar7[2] + 1;
      UNLOCK();
      piVar7 = (int *)param_1[1];
      uVar6 = param_1[4];
    }
    uVar2 = param_1[2];
    uVar3 = *param_1;
    uVar4 = param_1[3];
    piVar1 = piVar7 + 2;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar8 = 0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00a38e10(uVar3,piVar7,uVar2,uVar4,uVar6,in_stack_ffffffbc);
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)(*piVar7 + 4))(uVar8);
      }
      LOCK();
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
    FUN_009eef30(uVar8);
  }
  return;
}



/* FUNCTION 20568 ; VA 0x00a45310 ; FUN_00a45310 */

void FUN_00a45310(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  puVar2 = (undefined4 *)*param_1;
  uVar3 = puVar2[6];
  pcVar4 = (code *)*puVar2;
  uVar5 = puVar2[5];
  uVar6 = puVar2[4];
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar4)(puVar2[2],puVar2[3],param_2,param_3,uVar6,uVar5,uVar3);
  return;
}



/* FUNCTION 20569 ; VA 0x00a45360 ; FUN_00a45360 */

int FUN_00a45360(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puVar3 = (undefined4 *)*param_1;
  uVar4 = puVar3[9];
  pcVar5 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (puVar3[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar5)(puVar3[1],puVar3[2],puVar3 + 3,param_5,param_6,param_7,param_8,uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 20570 ; VA 0x00a45490 ; FUN_00a45490 */

int FUN_00a45490(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uVar3 = param_1[3];
  pcVar4 = (code *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(param_1[1],param_1[2],param_5,param_6,param_7,param_8,uVar3);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20571 ; VA 0x00a455c0 ; FUN_00a455c0 */

int FUN_00a455c0(int *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5,
                int *param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ad558;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puVar3 = (undefined4 *)*param_1;
  uVar4 = puVar3[6];
  pcVar5 = (code *)*puVar3;
  uVar6 = puVar3[5];
  uVar7 = puVar3[4];
  ExceptionList = &pvStack_10;
  if (param_8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (puVar3[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar8 = (*pcVar5)(puVar3[2],puVar3[3],param_5,param_6,param_7,param_8,uVar7,uVar6,uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 20572 ; VA 0x00a45700 ; FUN_00a45700 */

uint __thiscall FUN_00a45700(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *****pppppuVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 ****appppuStack_48 [4];
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017def22;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00fc6260(appppuStack_48,param_2);
  uStack_8 = 0;
  if (*(int *)(param_1 + 0x1b0) == 0) {
LAB_00a45914:
    piVar6 = (int *)FUN_0097be30(&param_2,puVar2);
    iVar1 = *(int *)(param_1 + 0x288);
    if (*piVar6 == iVar1) {
      piVar6 = (int *)FUN_0097be30(&param_2,appppuStack_48);
      param_2 = (undefined4 *)((uint)param_2 & 0xffffff);
      if (*piVar6 == iVar1) goto LAB_00a4594d;
    }
  }
  else {
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    uStack_14 = 1;
    FUN_0058a190(puVar2[4] + 1);
    puVar4 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar4 = (undefined4 *)*puVar2;
    }
    FUN_00554150(puVar4,puVar2[4]);
    FUN_00592760(0x2d);
    puVar9 = (undefined4 *)(param_1 + 0x1a0);
    puVar4 = puVar9;
    if (0xf < *(uint *)(param_1 + 0x1b4)) {
      puVar4 = (undefined4 *)*puVar9;
    }
    puVar4 = (undefined4 *)FUN_00554150(puVar4,*(undefined4 *)(param_1 + 0x1b0));
    uStack_78 = *puVar4;
    uStack_74 = puVar4[1];
    uStack_70 = puVar4[2];
    uStack_6c = puVar4[3];
    uStack_68 = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    uStack_8._0_1_ = 3;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar8 = uStack_30;
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(uStack_30 - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = uStack_30 & 0xffffff00;
    uStack_14 = 6;
    FUN_0058a190(iStack_38 + 1);
    pppppuVar5 = appppuStack_48;
    if (0xf < uStack_34) {
      pppppuVar5 = (undefined4 *****)appppuStack_48[0];
    }
    FUN_00554150(pppppuVar5,iStack_38);
    FUN_00592760(0x2d);
    if (0xf < *(uint *)(param_1 + 0x1b4)) {
      puVar9 = (undefined4 *)*puVar9;
    }
    puVar4 = (undefined4 *)FUN_00554150(puVar9,*(undefined4 *)(param_1 + 0x1b0));
    uStack_60 = *puVar4;
    uStack_5c = puVar4[1];
    uStack_58 = puVar4[2];
    uStack_54 = puVar4[3];
    uStack_50 = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar8 = uStack_30;
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(uStack_30 - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (uStack_30 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    param_1 = iStack_18;
    piVar6 = (int *)FUN_0097be30(&param_2,&uStack_78);
    if ((*piVar6 == *(int *)(param_1 + 0x288)) &&
       (piVar6 = (int *)FUN_0097be30(&param_2,&uStack_60), *piVar6 == *(int *)(param_1 + 0x288))) {
      FUN_005507b0();
      FUN_005507b0();
      goto LAB_00a45914;
    }
    FUN_005507b0();
    FUN_005507b0();
  }
  param_2 = (undefined4 *)CONCAT13(1,param_2._0_3_);
LAB_00a4594d:
  if (0xf < uStack_34) {
    uVar8 = uStack_34 + 1;
    pppppuVar5 = (undefined4 *****)appppuStack_48[0];
    if (0xfff < uVar8) {
      pppppuVar5 = (undefined4 *****)appppuStack_48[0][-1];
      uVar8 = uStack_34 + 0x24;
      if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar8);
  }
  ExceptionList = pvStack_10;
  return (uint)param_2 >> 0x18;
}



/* FUNCTION 20573 ; VA 0x00a459c0 ; FUN_00a459c0 */

uint FUN_00a459c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a36d80();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 20574 ; VA 0x00a459e0 ; FUN_00a459e0 */

uint FUN_00a459e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a36d80();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 20575 ; VA 0x00a45a00 ; FUN_00a45a00 */

int __thiscall FUN_00a45a00(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint *puVar8;
  int iVar9;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_24;
  uint *puStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017def48;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    uStack_18 = *(undefined4 *)(param_2 + 0x440);
    uStack_14 = *(undefined4 *)(param_2 + 0x444);
    ExceptionList = &pvStack_10;
    iStack_1c = param_1;
    iVar5 = FUN_00a53720(auStack_38);
    iStack_8 = 0;
    if (*(int *)(param_1 + 0x25c) == 0) {
      piVar7 = (int *)0x0;
    }
    else {
      iVar5 = *(int *)(param_1 + 0x268);
      piVar7 = *(int **)(iVar5 + *(int *)(param_1 + 600) * 4);
    }
    if (piVar7 != (int *)0x0) {
      param_1 = param_1 + 0x1a0;
      iStack_24 = param_1;
      do {
        piVar1 = piVar7 + 2;
        cVar4 = FUN_00a539f0(uStack_18,uStack_14,piVar1,param_1);
        if ((cVar4 == '\0') || (cVar4 = FUN_00a540a0(uStack_18,uStack_14,piVar1), cVar4 != '\0')) {
          puStack_20 = (uint *)piVar7[9];
          puVar8 = (uint *)piVar7[8];
          if (puVar8 != puStack_20) {
            do {
              if (puVar8[0x11] != 0) {
                LOCK();
                piVar1 = (int *)(puVar8[0x11] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
              }
              FUN_00a44420(&uStack_30,puVar8[0x10],puVar8[0x11],piVar7 + 2);
              piVar1 = piStack_2c;
              uVar6 = uStack_30;
              iStack_8._0_1_ = 1;
              if (*puVar8 == 0) {
                uVar6 = FUN_0054fda0();
                iStack_8 = CONCAT31(iStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0(uVar6);
              }
              uStack_30 = 0;
              piStack_2c = (int *)0x0;
              (**(code **)((*puVar8 & 0xfffffffe) + 4))(puVar8 + 2,uVar6,piVar1);
              piVar1 = piStack_2c;
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              if (piStack_2c != (int *)0x0) {
                LOCK();
                iVar5 = piStack_2c[1] + -1;
                piStack_2c[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_2c)();
                  LOCK();
                  piVar2 = piVar1 + 2;
                  iVar5 = *piVar2 + -1;
                  *piVar2 = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piVar1 + 4))();
                  }
                }
              }
              puVar8 = puVar8 + 0x14;
            } while (puVar8 != puStack_20);
          }
          iVar3 = piVar7[9];
          iVar9 = piVar7[8];
          iVar5 = iVar3;
          puStack_20 = (uint *)iVar3;
          if (iVar9 != iVar3) {
            do {
              iVar5 = FUN_005e6080();
              iVar9 = iVar9 + 0x50;
            } while (iVar9 != iVar3);
            iVar9 = piVar7[8];
          }
          piVar7[9] = iVar9;
          param_1 = iStack_24;
        }
        else {
          iVar5 = FUN_00a52ce0(param_2,piVar1,param_1);
        }
        piVar7 = (int *)*piVar7;
      } while (piVar7 != (int *)0x0);
    }
    param_2 = iVar5;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar7 = piStack_34 + 1;
      iVar5 = *piVar7;
      param_2 = *piVar7;
      *piVar7 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        param_2 = (**(code **)*piStack_34)();
        LOCK();
        piVar7 = piStack_34 + 2;
        iVar5 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          param_2 = (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 20576 ; VA 0x00a45c10 ; FUN_00a45c10 */

int * FUN_00a45c10(undefined4 *param_1,int *param_2,undefined4 ***param_3,int param_4,int *param_5,
                  int *param_6,int *param_7,uint param_8)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  undefined4 ***pppuVar5;
  int iVar6;
  undefined4 **ppuVar7;
  undefined4 *puStack_d0;
  int *piStack_cc;
  undefined4 uStack_b4;
  undefined4 ***pppuStack_b0;
  undefined *puStack_ac;
  char *pcStack_a8;
  undefined4 ***pppuStack_a4;
  undefined *puStack_a0;
  undefined4 uStack_9c;
  int **ppiStack_98;
  undefined4 ***pppuStack_94;
  undefined4 ***pppuStack_90;
  undefined4 ***pppuStack_8c;
  undefined4 *puStack_80;
  int *piStack_7c;
  undefined auStack_78 [4];
  undefined auStack_74 [20];
  uint uStack_60;
  undefined4 ***pppuStack_5c;
  undefined4 **ppuStack_58;
  undefined4 **ppuStack_54;
  undefined4 **ppuStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  int *piStack_40;
  undefined4 *puStack_3c;
  int *piStack_38;
  undefined auStack_34 [4];
  undefined4 ***apppuStack_30 [3];
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  undefined4 **ppuStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017defd3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_4c = 0xf00000000;
  pppuStack_5c = (undefined4 ***)((uint)pppuStack_5c & 0xffffff00);
  pppuStack_8c = (undefined4 ***)&iStack_44;
  pppuStack_90 = (undefined4 ***)0xa45c52;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  iVar6 = iStack_44;
  uStack_8._0_1_ = 4;
  if (iStack_44 == 0) {
    pppuStack_8c = (undefined4 ***)0x20;
    pppuStack_90 = (undefined4 ***)0x19428e8;
    iStack_20 = iStack_44;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    pppuStack_94 = (undefined4 ***)0xa45c7e;
    FUN_005542c0();
    pppuStack_8c = (undefined4 ***)iStack_44;
    pppuStack_94 = apppuStack_30;
    uStack_8._0_1_ = 5;
    pppuStack_90 = (undefined4 ***)0x1;
    ppiStack_98 = (int **)0xa45c8e;
    piVar3 = (int *)FUN_008783f0();
    if (0xf < uStack_1c) {
      pppuStack_8c = (undefined4 ***)(uStack_1c + 1);
      pppuVar5 = apppuStack_30[0];
      if (0xfff < pppuStack_8c) {
        pppuVar5 = (undefined4 ***)apppuStack_30[0][-1];
        pppuStack_8c = (undefined4 ***)(uStack_1c + 0x24);
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)pppuVar5))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_8c = (undefined4 ***)0xa4619d;
          FUN_017167a3();
        }
      }
      pppuStack_94 = (undefined4 ****)0xa45cc2;
      pppuStack_90 = pppuVar5;
      piVar3 = (int *)FUN_01674ea0();
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_40 + 1;
      iVar6 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        pppuStack_8c = (undefined4 ***)0xa45cde;
        (**(code **)*piStack_40)();
        LOCK();
        piVar1 = piStack_40 + 2;
        iVar6 = *piVar1;
        piVar3 = (int *)*piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          pppuStack_8c = (undefined4 ***)0xa45cee;
          piVar3 = (int *)(**(code **)(*piStack_40 + 4))();
        }
      }
    }
    if (uStack_4c._4_4_ < 0x10) goto LAB_00a46116;
    pppuStack_8c = (undefined4 ***)(uStack_4c._4_4_ + 1);
    pppuVar5 = pppuStack_5c;
    if (0xfff < pppuStack_8c) {
      pppuVar5 = (undefined4 ***)pppuStack_5c[-1];
      pppuStack_8c = (undefined4 ***)(uStack_4c._4_4_ + 0x24);
      if (0x1f < (uint)((int)pppuStack_5c + (-4 - (int)pppuVar5))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_8c = (undefined4 ***)0xa461a2;
        FUN_017167a3();
      }
    }
  }
  else {
    if (param_4 == 0) {
      if (param_6 == (int *)0x0) {
        pppuStack_8c = (undefined4 ***)0x36;
        pppuStack_90 = (undefined4 ***)0x1942a80;
        pppuStack_94 = (undefined4 ****)0xa460a7;
        piVar3 = (int *)FUN_005542c0();
      }
      else {
        pppuStack_8c = (undefined4 ***)0xa45ebe;
        pppuStack_90 = (undefined4 ***)(**(code **)(*param_6 + 4))();
        pppuStack_8c = (undefined4 ***)param_8;
        ppiStack_98 = (int **)auStack_74;
        pppuStack_94 = (undefined4 ***)0x1942a48;
        uStack_9c = 0xa45ed0;
        ppppuVar4 = (undefined4 ****)FUN_01675640();
        if (&pppuStack_5c != ppppuVar4) {
          pppuStack_8c = (undefined4 ***)0xa45ee3;
          FUN_005507b0();
          pppuStack_5c = *ppppuVar4;
          ppuStack_58 = ppppuVar4[1];
          ppuStack_54 = ppppuVar4[2];
          ppuStack_50 = ppppuVar4[3];
          uStack_4c = *(undefined8 *)(ppppuVar4 + 4);
          ppppuVar4[4] = (undefined4 ***)0x0;
          ppppuVar4[5] = (undefined4 ***)0xf;
          *(undefined *)ppppuVar4 = 0;
        }
        pppuStack_8c = (undefined4 ***)0xa45f0d;
        FUN_005507b0();
        if ((int)param_8 < DAT_01d65fe0) {
          pppuStack_8c = (undefined4 ***)iStack_44;
          pppuStack_90 = (undefined4 ***)0xa45f22;
          piVar3 = (int *)FUN_008f7870();
          if (piVar3 != (int *)0x0) {
            ppuStack_18 = &puStack_3c;
            pppuStack_8c = (undefined4 ***)0x1;
            piStack_14 = (int *)&puStack_ac;
            if (param_2 != (int *)0x0) {
              LOCK();
              param_2[2] = param_2[2] + 1;
              UNLOCK();
            }
            puStack_3c = param_1;
            piStack_38 = param_2;
            pppuStack_b0 = param_3;
            uStack_8._0_1_ = 8;
            uStack_b4 = 0xa45f71;
            FUN_0054ef60();
            uStack_1c = param_8;
            ppuStack_18 = &puStack_80;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              piStack_38[2] = piStack_38[2] + 1;
              UNLOCK();
            }
            puStack_80 = puStack_3c;
            piStack_7c = piStack_38;
            pppuStack_b0 = (undefined4 ***)auStack_34;
            uStack_8._0_1_ = 10;
            uStack_b4 = 0xa45faf;
            FUN_0054ef60();
            uStack_60 = uStack_1c;
            ppuStack_18 = &puStack_d0;
            *piStack_14 = 0;
            if (piStack_7c != (int *)0x0) {
              LOCK();
              piStack_7c[2] = piStack_7c[2] + 1;
              UNLOCK();
            }
            puStack_d0 = puStack_80;
            piStack_cc = piStack_7c;
            uStack_8._0_1_ = 0xc;
            FUN_0054ef60(auStack_78);
            pppuStack_b0 = (undefined4 ***)uStack_60;
            uStack_8._0_1_ = 0xb;
            FUN_00a386e0();
            pppuStack_b0 = (undefined4 ***)0xa46013;
            FUN_005d11a0();
            uStack_8._0_1_ = 4;
            pppuStack_b0 = (undefined4 ***)0xa4601f;
            FUN_005d11a0();
            pppuStack_b0 = (undefined4 ***)0xa46026;
            piVar3 = (int *)FUN_0090ca30();
          }
        }
        else {
          pppuStack_8c = param_3;
          pppuStack_90 = &ppuStack_18;
          pppuStack_94 = (undefined4 ****)0xa4603d;
          piVar3 = (int *)FUN_00875ab0();
          if (*piVar3 != 0) {
            pppuStack_8c = param_3;
            pppuStack_90 = (undefined4 ***)0xa4604a;
            piStack_14 = (int *)FUN_00939b30();
            ppuStack_18 = (undefined4 **)piStack_14[1];
            ppuVar7 = (undefined4 **)*piStack_14;
            if (ppuVar7 != ppuStack_18) {
              do {
                pppuStack_a4 = param_3;
                if ((undefined4 **)0xf < param_3[5]) {
                  pppuStack_a4 = (undefined4 ***)*param_3;
                }
                puStack_ac = (undefined *)&puStack_a0;
                pcStack_a8 = "Failed to load locale: %s";
                pppuStack_b0 = (undefined4 ***)0xa4607b;
                FUN_01675640();
                pppuStack_a4 = (undefined4 ***)0xa46086;
                FUN_005e65e0();
                ppuVar7 = ppuVar7 + 0x14;
              } while (ppuVar7 != ppuStack_18);
            }
            pppuStack_8c = (undefined4 ***)0xa46096;
            piVar3 = (int *)FUN_00a3fd20();
          }
        }
      }
    }
    else {
      pppuStack_8c = (undefined4 ***)0xa45d36;
      FUN_00a40170();
      pppuStack_8c = (undefined4 ***)param_4;
      pppuStack_90 = (undefined4 ***)0xa45d47;
      FUN_0054ef60();
      pppuStack_8c = (undefined4 ***)ppuStack_18;
      pppuStack_90 = &pppuStack_5c;
      uStack_8._0_1_ = 6;
      pppuStack_94 = (undefined4 ***)auStack_74;
      uStack_24 = 0;
      iStack_20 = 0;
      uStack_1c = 0;
      ppiStack_98 = (int **)0xa45d73;
      FUN_00604490();
      pppuStack_8c = (undefined4 ***)&uStack_24;
      uStack_8._0_1_ = 7;
      pppuStack_90 = (undefined4 ***)0xa45d82;
      FUN_00fda0d0();
      pppuStack_8c = (undefined4 ***)0xa45d8a;
      FUN_00577a40();
      pppuStack_8c = (undefined4 ***)FUN_005507b0;
      pppuStack_90 = (undefined4 ***)0x1;
      pppuStack_94 = (undefined4 ***)0x18;
      ppiStack_98 = (int **)auStack_74;
      uStack_8._0_1_ = 4;
      uStack_9c = 0xa45da0;
      FUN_016f32d1();
      pppuStack_8c = param_3;
      pppuStack_90 = param_3;
      pppuStack_94 = (undefined4 ***)&iStack_20;
      ppiStack_98 = (int **)0xa45db4;
      FUN_00676530();
      ppuStack_18 = (undefined4 **)(iVar6 + 0x254);
      pppuStack_8c = param_3;
      pppuVar5 = (undefined4 ***)(iVar6 + 0x255 + (uint)*(byte *)(iVar6 + 0x254));
      pppuStack_94 = (undefined4 ***)0xa45dd2;
      pppuStack_90 = pppuVar5;
      pppuStack_94 = (undefined4 ***)FUN_0055c740();
      pppuStack_8c = (undefined4 ***)(-(uint)(pppuVar5 != (undefined4 ***)0x0) & (int)pppuVar5 + 1U)
      ;
      pppuStack_90 = param_3;
      ppiStack_98 = &piStack_14;
      uStack_9c = 0xa45df3;
      FUN_00562fc0();
      if (piStack_14 != (int *)0x0) {
        pppuStack_8c = param_3;
        pppuStack_90 = (undefined4 ***)0xa45e06;
        piStack_14 = (int *)FUN_00939b30();
        iVar6 = *piStack_14;
        iVar2 = piStack_14[1];
        if (iVar6 != iVar2) {
          do {
            puStack_a0 = (undefined *)&pppuStack_90;
            pppuStack_94 = param_3;
            if (*(int *)(iVar6 + 0x44) != 0) {
              LOCK();
              piVar3 = (int *)(*(int *)(iVar6 + 0x44) + 8);
              *piVar3 = *piVar3 + 1;
              UNLOCK();
            }
            uStack_9c = *(undefined4 *)(iVar6 + 0x40);
            ppiStack_98 = *(int ***)(iVar6 + 0x44);
            pppuStack_a4 = (undefined4 ***)0xa45e4b;
            FUN_00a44420();
            pppuStack_94 = (undefined4 ***)0xa45e52;
            FUN_0096e490();
            iVar6 = iVar6 + 0x50;
          } while (iVar6 != iVar2);
          iVar2 = piStack_14[1];
          iVar6 = *piStack_14;
          if (iVar6 != iVar2) {
            do {
              pppuStack_8c = (undefined4 ***)0xa45e6c;
              FUN_005e6080();
              iVar6 = iVar6 + 0x50;
            } while (iVar6 != iVar2);
            iVar6 = *piStack_14;
          }
        }
        piStack_14[1] = iVar6;
        iVar6 = iStack_44;
      }
      piVar3 = (int *)(iVar6 + 0x2a8);
      *(undefined *)(iVar6 + 0x2a4) = 0;
      pppuStack_90 = *(undefined4 ****)(iVar6 + 0x2ac);
      pppuStack_94 = (undefined4 ***)*piVar3;
      ppiStack_98 = (int **)0xa45e96;
      pppuStack_8c = (undefined4 ***)piVar3;
      FUN_005596d0();
      *(int *)(iVar6 + 0x2ac) = *piVar3;
      pppuStack_8c = (undefined4 ***)0x0;
      pppuStack_90 = (undefined4 ***)0xa45ea7;
      piVar3 = (int *)FUN_00a44780();
    }
    if ((int)uStack_4c != 0) {
      pppuStack_8c = &pppuStack_5c;
      pppuStack_90 = (undefined4 ***)0xa460b6;
      piVar3 = (int *)FUN_00a4acd0();
    }
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_40 + 1;
      iVar6 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        pppuStack_8c = (undefined4 ***)0xa460d2;
        (**(code **)*piStack_40)();
        LOCK();
        piVar1 = piStack_40 + 2;
        iVar6 = *piVar1;
        piVar3 = (int *)*piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          pppuStack_8c = (undefined4 ***)0xa460e2;
          piVar3 = (int *)(**(code **)(*piStack_40 + 4))();
        }
      }
    }
    if (uStack_4c._4_4_ < 0x10) goto LAB_00a46116;
    pppuStack_8c = (undefined4 ***)(uStack_4c._4_4_ + 1);
    pppuVar5 = pppuStack_5c;
    if (0xfff < pppuStack_8c) {
      pppuVar5 = (undefined4 ***)pppuStack_5c[-1];
      pppuStack_8c = (undefined4 ***)(uStack_4c._4_4_ + 0x24);
      if (0x1f < (uint)((int)pppuStack_5c + (-4 - (int)pppuVar5))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_8c = (undefined4 ***)&UNK_00a461a7;
        FUN_017167a3();
      }
    }
  }
  pppuStack_94 = (undefined4 ****)0xa46113;
  pppuStack_90 = pppuVar5;
  piVar3 = (int *)FUN_01674ea0();
LAB_00a46116:
  pppuStack_5c = (undefined4 ***)((uint)pppuStack_5c & 0xffffff00);
  uStack_4c = 0xf00000000;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar6 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pppuStack_8c = (undefined4 ***)0xa4613d;
      piVar3 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar6 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pppuStack_8c = (undefined4 ***)0xa46153;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar6 = *piVar1;
      piVar3 = (int *)*piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        pppuStack_8c = (undefined4 ***)0xa46163;
        piVar3 = (int *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar6 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      pppuStack_8c = (undefined4 ***)0xa46179;
      piVar3 = (int *)(**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        pppuStack_8c = (undefined4 ***)0xa46188;
        piVar3 = (int *)(**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 20577 ; VA 0x00a461b0 ; FUN_00a461b0 */

void FUN_00a461b0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined *puVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 ***pppuVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  undefined uStack_90;
  char cStack_8f;
  char cStack_8e;
  char cStack_8d;
  undefined4 uStack_8c;
  undefined auStack_68 [24];
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 **appuStack_38 [4];
  int iStack_28;
  uint uStack_24;
  int *piStack_1c;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017deffb;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff64;
  ExceptionList = &pvStack_10;
  puVar1 = &stack0xffffff64;
  if (((param_1 == (int *)0x0) ||
      (iVar5 = param_1[3], ExceptionList = &pvStack_10, iVar3 = FUN_00c3ebd0(), puVar1 = puStack_14,
      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da))) && (puStack_14 = puVar1, param_3 != param_2)) {
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar4,param_2[4]);
  }
  if (param_1 != (int *)0x0) {
    piStack_1c = (int *)param_1[0xd];
    if (piStack_1c == (int *)0x0) {
      piStack_1c = param_1;
    }
    else if (piStack_1c[0xd] != 0) {
      piStack_1c = (int *)FUN_005c8ac0();
    }
    if ((piStack_1c != (int *)0x0) &&
       (iVar5 = piStack_1c[3], iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      piStack_1c = (int *)FUN_00635a10();
      goto LAB_00a46281;
    }
  }
  piStack_1c = (int *)0x0;
LAB_00a46281:
  piVar10 = piStack_1c;
  puVar4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar4 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_00f854b0(puVar4,param_2[4]);
  if (((piVar10 != (int *)0x0) && (cVar2 != '\0')) &&
     ((iVar5 = FUN_008f7870(piVar10), *(int *)(iVar5 + 0x4a0) == 1 &&
      (piVar10 = param_1, param_1 != (int *)0x0)))) {
    do {
      iVar5 = piVar10[3];
      iVar3 = FUN_00d59db0();
      if (((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da)) && (*(char *)(piVar10 + 0x1c) == '\0')) break;
      iVar5 = piVar10[3];
      iVar3 = FUN_008aa870();
      if (((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
           (uint)*(ushort *)(iVar3 + 0x1da)) ||
         ((iVar5 = piVar10[3], iVar3 = FUN_00b56e90(),
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da) ||
          (iVar5 = piVar10[3], iVar3 = FUN_00b56db0(),
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da))))) {
        uStack_8 = 0;
        FUN_00a3baf0();
        iStack_28 = 0;
        uStack_24 = 0xf;
        appuStack_38[0] = (undefined4 **)((uint)appuStack_38[0] & 0xffffff00);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        iVar5 = FUN_00a3a560();
        piVar10 = piStack_1c;
        if (iVar5 == 0) {
          iVar5 = FUN_00a43410(auStack_50);
          piStack_1c = *(int **)(iVar5 + 0x10);
          if (0xf < uStack_3c) {
            uVar9 = uStack_3c + 1;
            uVar8 = auStack_50[0];
            if (0xfff < uVar9) {
              uVar8 = *(uint *)(auStack_50[0] - 4);
              uVar9 = uStack_3c + 0x24;
              if (0x1f < (auStack_50[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar8,uVar9);
          }
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = auStack_50[0] & 0xffffff00;
          if (piStack_1c == (int *)0x0) goto LAB_00a46432;
          FUN_00a43410(auStack_68);
        }
        else {
LAB_00a46432:
          iVar5 = (int)piVar10 + 0x1b8;
          if (*(int *)((int)piVar10 + 0x1c8) == 0) {
            iVar5 = (int)piVar10 + 0x140;
          }
          FUN_0054ef60(iVar5);
        }
        FUN_005511f0(auStack_68);
        FUN_005507b0();
        if ((iStack_28 == 0) ||
           (cVar2 = FUN_00a3eb70(param_1,param_2,appuStack_38,param_3,&uStack_90), cVar2 == '\0')) {
          cStack_15 = '\0';
        }
        else {
          cStack_15 = '\x01';
        }
        if (cStack_8d == '\0') {
          if (cStack_15 != '\0') {
            if (cStack_8f == '\0') goto LAB_00a4654e;
            goto LAB_00a464a8;
          }
          if ((((cStack_8e != '\0') &&
               (iVar5 = param_1[3], iVar3 = FUN_00d59db0(),
               (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
               (uint)*(ushort *)(iVar3 + 0x1da))) &&
              (piVar7 = (int *)(**(code **)(*param_1 + 0xfc))(), piVar7 != (int *)0x0)) &&
             (*piVar7 == 0)) {
            *(int *)((int)piVar10 + 0x94) = *(int *)((int)piVar10 + 0x94) + 1;
            *piVar7 = 1;
          }
        }
        else {
LAB_00a464a8:
          FUN_00a4dce0(param_1,uStack_8c);
          if (cStack_15 != '\0') goto LAB_00a4654e;
        }
        pppuVar6 = appuStack_38;
        if (0xf < uStack_24) {
          pppuVar6 = (undefined4 ***)appuStack_38[0];
        }
        cVar2 = FUN_0055c360(pppuVar6,iStack_28,"zh-cjv",6);
        if (cVar2 == '\0') {
          FUN_00551230(param_2);
        }
        else {
          FUN_005542c0(&DAT_018bc9b8,0);
        }
LAB_00a4654e:
        if (DAT_01d66098 != '\0') {
          (**(code **)**(undefined4 **)((int)piVar10 + 0xac))(&uStack_90);
        }
        FUN_005507b0();
        FUN_0056baf0();
        ExceptionList = pvStack_10;
        return;
      }
      piVar10 = (int *)piVar10[0xd];
    } while (piVar10 != (int *)0x0);
  }
  if (param_3 != param_2) {
    puVar4 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20578 ; VA 0x00a4658c ; Catch@00a4658c */

undefined4 Catch_00a4658c(void)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_EBP;
  
  FUN_00a435a0(unaff_EBP + -100,*(undefined4 *)(unaff_EBP + 8));
  *(undefined *)(unaff_EBP + -4) = 4;
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  iVar2 = unaff_EBP + -100;
  if (0xf < *(uint *)(unaff_EBP + -0x50)) {
    iVar2 = *(int *)(unaff_EBP + -100);
  }
  FUN_0086f2f0(3,"Error translating text for %s: %s",iVar2,uVar1);
  FUN_00551230(*(undefined4 *)(unaff_EBP + 0xc));
  FUN_005507b0();
  return 0xa4637d;
}



/* FUNCTION 20579 ; VA 0x00a465f0 ; FUN_00a465f0 */

void FUN_00a465f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a4d330();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 20580 ; VA 0x00a46630 ; FUN_00a46630 */

void FUN_00a46630(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dc9e7c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01dc9e78;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20581 ; VA 0x00a466b0 ; FUN_00a466b0 */

void FUN_00a466b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a3a820(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a3bb40();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc9658);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_18eacc991c4c7e9639c16d1a24399c91>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20582 ; VA 0x00a46800 ; FUN_00a46800 */

int * FUN_00a46800(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a468bd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a4683e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9be8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_21f8873364904c61fb03419975abf2a4>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20583 ; VA 0x00a468e0 ; FUN_00a468e0 */

int * FUN_00a468e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46991. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a4691e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9b78);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_482ab558d3060a4fb93597527a977941>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20584 ; VA 0x00a469b0 ; FUN_00a469b0 */

void FUN_00a469b0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df027;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x24);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        puVar3[8] = puVar2[8];
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9b08);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_4a6b89f47f3180d91608b7e555f10ff2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20585 ; VA 0x00a46b30 ; FUN_00a46b30 */

int * FUN_00a46b30(undefined *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  undefined *puVar5;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined *)param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (*(int *)(param_1 + 8) != 0) {
        LOCK();
        piVar4 = (int *)(*(int *)(param_1 + 8) + 8);
        *piVar4 = *piVar4 + 1;
        UNLOCK();
      }
      param_2[1] = *(int *)(param_1 + 4);
      piVar4 = *(int **)(param_1 + 8);
      param_2[2] = (int)piVar4;
      if (param_3 != 1) {
        return piVar4;
      }
      piVar3 = *(int **)(param_1 + 8);
      if (piVar3 == (int *)0x0) {
        return piVar4;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46be2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar4 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar4;
    }
    if (param_3 == 2) {
      piVar4 = (int *)param_2[2];
      if (piVar4 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46b6e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar4 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar4;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9c58);
      puVar5 = (undefined *)0x0;
      if (piVar4 == (int *)0x0) {
        puVar5 = param_1;
      }
      *param_2 = (int)puVar5;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_572cf74dea5aba73e00169f31270033c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20586 ; VA 0x00a46c00 ; FUN_00a46c00 */

void FUN_00a46c00(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df027;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x24);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        *(undefined *)(puVar3 + 2) = *(undefined *)(puVar2 + 2);
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 3);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a3bbb0();
        FUN_01674ea0(iVar4,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9c20);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_6e519e62ef2f246119a2e97d22c1cab2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20587 ; VA 0x00a46d80 ; FUN_00a46d80 */

void FUN_00a46d80(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df027;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x24);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        puVar3[8] = puVar2[8];
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9b40);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_70b271e10824cfbbd463842a87ae91bc>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20588 ; VA 0x00a46f00 ; FUN_00a46f00 */

int * FUN_00a46f00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46fab. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46f3e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc95b0);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_77474e62ce97e3a66bf881f4cda5447d>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20589 ; VA 0x00a46fc0 ; FUN_00a46fc0 */

int * FUN_00a46fc0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a47071. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a46ffe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9bb0);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_807b19ea2784aa4d1bab1f2047a7e363>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20590 ; VA 0x00a47090 ; FUN_00a47090 */

int * FUN_00a47090(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a4714d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a470ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9620);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_a133cec7bb17e18de7c29e3b15f32b65>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20591 ; VA 0x00a47170 ; FUN_00a47170 */

void FUN_00a47170(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df027;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x24);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        puVar3[8] = puVar2[8];
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9d00);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_ca0f4455a41d47ad6073ef7602c047c9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20592 ; VA 0x00a472f0 ; FUN_00a472f0 */

void FUN_00a472f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df057;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar2 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = 0;
        puVar3[1] = 0;
        if (puVar2[1] != 0) {
          LOCK();
          piVar1 = (int *)(puVar2[1] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        *puVar3 = *puVar2;
        puVar3[1] = puVar2[1];
        uStack_8 = 1;
        FUN_0054ef60(puVar2 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar4,0x20);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dc9c90);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d5bc160812019d1bef48eeec0aed324b>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20593 ; VA 0x00a47460 ; FUN_00a47460 */

int * FUN_00a47460(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  byte bVar3;
  int *piVar4;
  int *piVar5;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar4 = (int *)(param_1[1] + 8);
        *piVar4 = *piVar4 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *(undefined *)(param_2 + 2) = *(undefined *)(param_1 + 2);
      bVar3 = *(byte *)((int)param_1 + 9);
      *(byte *)((int)param_2 + 9) = bVar3;
      if (param_3 != 1) {
        return (int *)(uint)bVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return (int *)(uint)bVar3;
      }
      LOCK();
      piVar5 = piVar4 + 2;
      iVar1 = *piVar5;
      piVar2 = (int *)*piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a47519. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar4 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar4;
    }
    if (param_3 == 2) {
      piVar4 = (int *)param_2[1];
      if (piVar4 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar5 = piVar4 + 2;
      iVar1 = *piVar5;
      piVar2 = (int *)*piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a4749e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar4 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar4;
    }
    if (param_3 == 3) {
      piVar5 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9cc8);
      piVar4 = (int *)0x0;
      if (piVar5 == (int *)0x0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return piVar5;
    }
  }
  *param_2 = (int)&<lambda_e7df6205ae05a8efab46b915e5fbed35>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20594 ; VA 0x00a47530 ; FUN_00a47530 */

int * FUN_00a47530(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a475ed. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a4756e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc95e8);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_efc0fc186b3056a2f9912353d4083914>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20595 ; VA 0x00a47610 ; FUN_00a47610 */

void FUN_00a47610(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc9d3c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::_mfi::mf1<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::LocalizationService,class_std::shared_ptr<class_RBX::Instance>_const&>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::LocalizationService*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20596 ; VA 0x00a47680 ; FUN_00a47680 */

void FUN_00a47680(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a3ac00(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005d11a0();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dc9694);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LocalizationService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>,int),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LocalizationService>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_boost::arg<3>,struct_boost::arg<4>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 20597 ; VA 0x00a477d0 ; FUN_00a477d0 */

void FUN_00a477d0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x20);
      if (iVar2 != 0) {
        iVar3 = FUN_00a3ac80(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc947c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LocalizationService>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*,__int64,int),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LocalizationService>_>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<__int64>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20598 ; VA 0x00a478b0 ; FUN_00a478b0 */

int * FUN_00a478b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a47968. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a478ee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dc9864);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LocalizationService>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>,int),class_boost::_bi::list4<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LocalizationService>_>,struct_boost::arg<3>,struct_boost::arg<4>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 20599 ; VA 0x00a47980 ; FUN_00a47980 */

void FUN_00a47980(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      iVar2 = FUN_01674e20(0x20);
      if (iVar2 != 0) {
        iVar3 = FUN_00a3ac80(iVar3);
        *param_2 = iVar3;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dc99ac);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LocalizationService>,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<class_std::exception>,__int64,int),class_boost::_bi::list5<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LocalizationService>_>,struct_boost::arg<3>,struct_boost::arg<4>,class_boost::_bi::value<__int64>,class_boost::_bi::value<int>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 20600 ; VA 0x00a47a60 ; FUN_00a47a60 */

int FUN_00a47a60(undefined4 param_1,int *param_2,int param_3,int *param_4,int param_5,int *param_6,
                undefined4 param_7,undefined4 param_8,int param_9)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_ffffff74;
  uint auStack_54 [4];
  int iStack_44;
  uint uStack_40;
  uint uStack_3c;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_6;
  piVar1 = param_4;
  puStack_c = &LAB_017df0a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iStack_2c = 0;
  uStack_28 = 0xf;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 4;
  if (iStack_24 == 0) {
    iStack_44 = iStack_24;
    uStack_40 = 0xf;
    auStack_54[0] = auStack_54[0] & 0xffffff00;
    FUN_005542c0("LocalizationServiceInvalidHandle",0x20);
    uStack_8._0_1_ = 5;
    iVar4 = FUN_008783f0(auStack_54,1,0);
    if (0xf < uStack_40) {
      uVar7 = uStack_40 + 1;
      uVar6 = auStack_54[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_54[0] - 4);
        uVar7 = uStack_40 + 0x24;
        if (0x1f < (auStack_54[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar4 = FUN_01674ea0(uVar6,uVar7);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (uStack_28 < 0x10) goto LAB_00a47de9;
    uVar7 = uStack_28 + 1;
    uVar6 = uStack_3c;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_3c - 4);
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (uStack_3c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    if ((0 < DAT_01ee72fc) && (param_9 < DAT_01ee72fc)) {
      iStack_1c = 0;
      piStack_18 = (int *)0x0;
      param_3 = 0;
      param_4 = (int *)0x0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar4 = piVar1[1] + -1;
        piVar1[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar4 = piVar1[2] + -1;
          piVar1[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      FUN_00550b30();
      iStack_14 = FUN_01674e20();
      if (iStack_14 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_00550130();
      }
      iStack_1c = 0;
      piStack_18 = (int *)0x0;
      FUN_00a37eb0(uVar5,iStack_14);
      param_5 = iStack_1c;
      param_6 = piStack_18;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    if (param_3 == 0) {
      if (param_5 == 0) {
        iVar4 = FUN_005542c0("manifestResponseHandler missing response/exception!",0x33);
      }
      else {
        iVar4 = FUN_008f7870();
        if ((iVar4 != 0) && (iStack_14 = FUN_005cf2a0(), iStack_14 != 0)) {
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          uVar5 = 0;
          piVar1 = param_2 + 2;
          if (param_2 != (int *)0x0) {
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_00a384a0(param_1,param_2,param_7,param_8,param_9,in_stack_ffffff74);
          if (param_2 != (int *)0x0) {
            LOCK();
            iVar4 = *piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              (**(code **)(*param_2 + 4))(uVar5);
            }
            LOCK();
            iVar4 = *piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              (**(code **)(*param_2 + 4))();
            }
          }
          FUN_009eef30(uVar5);
        }
        iStack_44 = 0;
        uStack_40 = 0xf;
        auStack_54[0] = auStack_54[0] & 0xffffff00;
        FUN_005542c0("LocalizationServiceAsyncLoadingHttpError_Manifest",0x31);
        uStack_8._0_1_ = 6;
        FUN_008783f0(auStack_54,1,0);
        uStack_8._0_1_ = 4;
        iVar4 = FUN_005507b0();
      }
    }
    else {
      iVar4 = FUN_00a4ccd0();
    }
    if (iStack_2c != 0) {
      iVar4 = FUN_00a4acd0();
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (uStack_28 < 0x10) goto LAB_00a47de9;
    uVar7 = uStack_28 + 1;
    uVar6 = uStack_3c;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_3c - 4);
      uVar7 = uStack_28 + 0x24;
      if (0x1f < (uStack_3c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  iVar4 = FUN_01674ea0(uVar6,uVar7);
LAB_00a47de9:
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_28 = 0xf;
  iStack_2c = 0;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20601 ; VA 0x00a47e80 ; FUN_00a47e80 */

void __thiscall FUN_00a47e80(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  
  if (param_2 != 0) {
    iVar2 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00fd0780();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      puVar1 = (undefined4 *)(param_1 + 0x2a8);
      *(undefined *)(param_1 + 0x2a4) = 0;
      FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x2ac),puVar1);
      *(undefined4 *)(param_1 + 0x2ac) = *puVar1;
      FUN_00a44780(0);
    }
  }
  return;
}



/* FUNCTION 20602 ; VA 0x00a47ee0 ; FUN_00a47ee0 */

int FUN_00a47ee0(int param_1,int param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint in_stack_00000024;
  undefined auStack_30 [28];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df0f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870();
  if (((iVar3 != 0) &&
      (piVar1 = (int *)(iVar3 + 0x440), iVar3 = *(int *)(iVar3 + 0x444), *piVar1 == param_1)) &&
     (iVar3 == param_2)) {
    FUN_0060e0c0();
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 2;
    FUN_0054ef60();
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
    FUN_0054ef60();
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 6;
    FUN_0054ef60(auStack_30);
    uStack_8._0_1_ = 5;
    FUN_00a389a0();
    FUN_00a3bbb0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00a3bbb0();
    iVar3 = FUN_0090ca30();
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20603 ; VA 0x00a480a0 ; FUN_00a480a0 */

int FUN_00a480a0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cef88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00562c90(&iStack_20,param_1);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    uStack_18 = FUN_00928340();
    iVar3 = FUN_00a40b80(&uStack_18);
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20604 ; VA 0x00a48130 ; FUN_00a48130 */

void __thiscall FUN_00a48130(int param_1,undefined *param_2)

{
  char cVar1;
  int iVar2;
  
  if (param_2 != &DAT_02125ff0) {
    if ((DAT_01d660d0 != '\0') && (param_2 == &DAT_02126060)) {
      iVar2 = FUN_008f7870(param_1);
      if (iVar2 != 0) {
        if (*(int *)(iVar2 + 0x4a0) == 1) {
          FUN_00a48b00();
          *(undefined *)(param_1 + 0x250) = 1;
          return;
        }
        if (*(int *)(iVar2 + 0x4a0) == 2) {
          FUN_00a48e00();
        }
        *(undefined *)(param_1 + 0x250) = 1;
      }
    }
    return;
  }
  cVar1 = FUN_00fce1e0();
  if (cVar1 == '\0') {
    FUN_00a4db60(1);
    return;
  }
  *(undefined *)(param_1 + 0x2c0) = 0;
  FUN_00fd0340();
  return;
}



/* FUNCTION 20605 ; VA 0x00a481d0 ; FUN_00a481d0 */

void __thiscall FUN_00a481d0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  double *pdVar7;
  undefined auStack_7c [16];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  code *pcStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  undefined auStack_54 [4];
  int *piStack_50;
  int iStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df225;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piStack_28 = (int *)(param_1 + 0x2e4);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_01679490();
  iStack_30 = param_1 + 0x2e8;
  FUN_01679490();
  iStack_34 = param_1 + 0x2ec;
  FUN_01679490();
  iStack_38 = param_1 + 0x2f0;
  FUN_01679490();
  iStack_3c = param_1 + 0x2f4;
  FUN_01679490();
  if ((param_3 == 0) || (iVar3 = FUN_008f7870(param_3), iVar3 == 0)) goto LAB_00a48a45;
  if (*(int *)(iVar3 + 0x4a0) == 2) {
    puVar4 = (undefined4 *)FUN_00564080();
    piVar6 = (int *)*puVar4;
    if ((int *)*puVar4 == (int *)0x0) {
      FUN_0055e4a0(&piStack_44);
      uStack_8 = 0;
      FUN_008a5700(iVar3 + 0xc);
      FUN_005789c0();
      uVar5 = FUN_00560c40();
      puVar4 = (undefined4 *)FUN_008aa140(uVar5);
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      *puVar4 = piStack_44;
      piVar6 = (int *)puVar4[1];
      puVar4[1] = piStack_40;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar3 = piVar6[2] + -1;
          piVar6[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar6 = piStack_40;
      piStack_1c = piStack_44;
      uStack_8 = 0xffffffff;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_40[1] + -1;
        piStack_40[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar6 = piStack_1c;
      if (piStack_1c == (int *)0x0) goto LAB_00a48456;
    }
    piStack_20 = piVar6 + 0xaa;
    pcStack_64 = FUN_00a480a0;
    iStack_60 = 0;
    uStack_5c = (double)CONCAT44(uStack_5c._4_4_,iStack_18);
    uStack_8 = 1;
    iVar3 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 2;
    iStack_2c = iVar3;
    piStack_24 = (int *)FUN_01674e20();
    if (piStack_24 == (int *)0x0) {
      piStack_24 = (int *)0x0;
    }
    else {
      *piStack_24 = 0;
      piStack_24[1] = 1;
      piStack_24[2] = (int)FUN_00a40b10;
      piStack_24[3] = (int)_guard_check_icall;
      piStack_24[4] = 0;
      piStack_24[5] = (int)piStack_20;
      piStack_24[6] = (int)pcStack_64;
      piStack_24[7] = iStack_60;
      piStack_24[8] = (int)uStack_5c;
      piStack_24[9] = uStack_5c._4_4_;
    }
    FUN_016797d0(piStack_24);
    piStack_1c = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    uStack_14 = 1;
    uStack_8._0_1_ = 3;
    FUN_01675290(iVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    cVar2 = FUN_01679300(&piStack_1c);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_1c);
    }
    uStack_8 = 0xffffffff;
    uStack_14 = 0;
    if (piStack_1c != (int *)0x0) {
      piVar6 = piStack_1c + 1;
      LOCK();
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      uStack_14 = 0;
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_1c);
        uStack_14 = 0;
      }
    }
  }
LAB_00a48456:
  param_1 = iStack_18;
  if (DAT_01d660d0 != '\0') {
    piVar6 = (int *)FUN_00a53720(&uStack_5c);
    piStack_1c = (int *)(*piVar6 + 8);
    uStack_8 = 4;
    piVar6 = (int *)FUN_0060e0c0(auStack_54,iStack_18);
    iStack_4c = *piVar6;
    piStack_48 = (int *)piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    uStack_8._0_1_ = 7;
    iStack_2c = iStack_4c;
    piStack_28 = piStack_48;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 8;
    piStack_40 = (int *)uVar5;
    piStack_24 = (int *)FUN_01674e20(0x20);
    if (piStack_24 == (int *)0x0) {
      piStack_24 = (int *)0x0;
    }
    else {
      *piStack_24 = 0;
      piStack_24[1] = 1;
      piStack_24[2] = (int)FUN_00a409e0;
      piStack_24[3] = (int)FUN_005d3660;
      piStack_24[4] = 0;
      piStack_24[5] = (int)piStack_1c;
      piStack_24[6] = 0;
      piStack_24[7] = 0;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[2] = piStack_28[2] + 1;
        UNLOCK();
      }
      piStack_24[6] = iStack_2c;
      piStack_24[7] = (int)piStack_28;
    }
    FUN_016797d0(piStack_24);
    piStack_20 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    uStack_14 = 2;
    uStack_8._0_1_ = 9;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    cVar2 = FUN_01679300(&piStack_20);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_20);
    }
    uStack_14 = 0;
    if (piStack_20 != (int *)0x0) {
      piVar6 = piStack_20 + 1;
      LOCK();
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_20);
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_50[2] + -1;
      piStack_50[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    piVar6 = (int *)FUN_00a53720(&iStack_4c);
    piStack_20 = (int *)(*piVar6 + 0xc);
    uStack_8 = 10;
    piVar6 = (int *)FUN_0060e0c0(auStack_54,iStack_18);
    iStack_30 = *piVar6;
    piStack_24 = (int *)piVar6[1];
    uStack_5c = *(double *)piVar6;
    *piVar6 = 0;
    piVar6[1] = 0;
    uStack_8._0_1_ = 0xd;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0xe;
    piStack_40 = (int *)uVar5;
    piStack_28 = (int *)FUN_01674e20(0x20);
    if (piStack_28 == (int *)0x0) {
      piStack_28 = (int *)0x0;
    }
    else {
      *piStack_28 = 0;
      piStack_28[1] = 1;
      piStack_28[2] = (int)FUN_00a409c0;
      piStack_28[3] = (int)FUN_005d3660;
      piStack_28[4] = 0;
      piStack_28[5] = (int)piStack_20;
      piStack_28[6] = 0;
      piStack_28[7] = 0;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      piStack_28[6] = iStack_30;
      piStack_28[7] = (int)piStack_24;
    }
    FUN_016797d0(piStack_28);
    piStack_1c = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    uStack_14 = 4;
    uStack_8._0_1_ = 0xf;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    cVar2 = FUN_01679300(&piStack_1c);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_1c);
    }
    uStack_14 = 0;
    if (piStack_1c != (int *)0x0) {
      piVar6 = piStack_1c + 1;
      LOCK();
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_1c);
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_50[2] + -1;
      piStack_50[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    piVar6 = (int *)FUN_00a53720(&iStack_4c);
    piStack_20 = (int *)(*piVar6 + 0x10);
    uStack_8 = 0x10;
    piVar6 = (int *)FUN_0060e0c0(auStack_54,iStack_18);
    iStack_34 = *piVar6;
    piStack_24 = (int *)piVar6[1];
    uStack_5c = *(double *)piVar6;
    *piVar6 = 0;
    piVar6[1] = 0;
    uStack_8._0_1_ = 0x13;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x14;
    piStack_40 = (int *)uVar5;
    piStack_28 = (int *)FUN_01674e20(0x20);
    if (piStack_28 == (int *)0x0) {
      piStack_28 = (int *)0x0;
    }
    else {
      *piStack_28 = 0;
      piStack_28[1] = 1;
      piStack_28[2] = (int)FUN_00a409a0;
      piStack_28[3] = (int)FUN_005d3660;
      piStack_28[4] = 0;
      piStack_28[5] = (int)piStack_20;
      piStack_28[6] = 0;
      piStack_28[7] = 0;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      piStack_28[6] = iStack_34;
      piStack_28[7] = (int)piStack_24;
    }
    FUN_016797d0(piStack_28);
    piStack_1c = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    uStack_14 = 8;
    uStack_8._0_1_ = 0x15;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    cVar2 = FUN_01679300(&piStack_1c);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_1c);
    }
    uStack_14 = 0;
    if (piStack_1c != (int *)0x0) {
      piVar6 = piStack_1c + 1;
      LOCK();
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_1c);
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_50[2] + -1;
      piStack_50[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    piVar6 = (int *)FUN_00a53720(&iStack_4c);
    piStack_20 = (int *)(*piVar6 + 0x14);
    uStack_8 = 0x16;
    pdVar7 = (double *)FUN_0060e0c0(auStack_54,iStack_18);
    iStack_38 = *(int *)pdVar7;
    piStack_24 = *(int **)((int)pdVar7 + 4);
    uStack_5c = *pdVar7;
    *(int *)pdVar7 = 0;
    *(int *)((int)pdVar7 + 4) = 0;
    uStack_8._0_1_ = 0x19;
    piVar6 = (int *)FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 0x1a;
    piStack_40 = piVar6;
    piStack_28 = (int *)FUN_01674e20(0x20);
    if (piStack_28 == (int *)0x0) {
      piStack_28 = (int *)0x0;
    }
    else {
      *piStack_28 = 0;
      piStack_28[1] = 1;
      piStack_28[2] = (int)FUN_00a40a00;
      piStack_28[3] = (int)FUN_005d3660;
      piStack_28[4] = 0;
      piStack_28[5] = (int)piStack_20;
      piStack_28[6] = 0;
      piStack_28[7] = 0;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[2] = piStack_24[2] + 1;
        UNLOCK();
      }
      piStack_28[6] = iStack_38;
      piStack_28[7] = (int)piStack_24;
    }
    FUN_016797d0(piStack_28);
    piStack_1c = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piStack_28[1] = piStack_28[1] + 1;
      UNLOCK();
    }
    uStack_14 = 0x10;
    uStack_8._0_1_ = 0x1b;
    FUN_01675290(piVar6);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    cVar2 = FUN_01679300(&piStack_1c);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&piStack_1c);
    }
    if (piStack_1c != (int *)0x0) {
      piVar6 = piStack_1c + 1;
      LOCK();
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(piStack_1c);
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_50 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    param_1 = iStack_18;
  }
LAB_00a48a45:
  if ((param_2 != 0) && (param_3 == 0)) {
    *(undefined *)(param_1 + 0x2c0) = 0;
    FUN_00fd0340();
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = 0;
    uStack_5c = (double)*(int *)(param_1 + 0x2c4) +
                (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x2c4) >> 0x1f)];
    FUN_005542c0();
    uStack_8 = 0x1c;
    FUN_00878cf0(auStack_7c,uStack_5c,0);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  FUN_008a4210();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20606 ; VA 0x00a48b00 ; FUN_00a48b00 */

int __fastcall FUN_00a48b00(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df260;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_008f7870(param_1);
  if (piVar5 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  iStack_20 = piVar5[0x111];
  iVar6 = piVar5[0x110];
  piStack_18 = piVar5;
  FUN_00a53720(auStack_28);
  uStack_8 = 0;
  FUN_00a54ce0(iVar6,iStack_20,param_1 + 0x26c);
  FUN_00a53bd0(iVar6,iStack_20);
  FUN_00a45a00(piVar5);
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("source",6);
  uStack_8._0_1_ = 2;
  cStack_11 = FUN_00a539f0(iVar6,iStack_20,auStack_40,auStack_58);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    uVar7 = auStack_58[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_58[0] - 4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar7) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  if (cStack_11 != '\0') {
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    FUN_005542c0("source",6);
    uStack_8._0_1_ = 3;
    cVar4 = FUN_00a540a0(iVar6,iStack_20,auStack_58);
    uStack_8._0_1_ = 0;
    FUN_005507b0();
    piVar5 = piStack_18;
    if (cVar4 == '\0') {
      FUN_00a53230(piStack_18);
      goto LAB_00a48cef;
    }
  }
  *(undefined *)(param_1 + 0x2c1) = 1;
  piVar5 = piStack_18;
  if ((*(char *)(param_1 + 0x2c0) != '\0') &&
     (cVar4 = FUN_00fce1e0(), piVar5 = piStack_18, cVar4 != '\x01')) {
    FUN_008a4940(&DAT_02125ff0);
    piVar5 = piStack_18;
  }
LAB_00a48cef:
  iStack_20 = piVar5[0x111];
  iVar2 = piVar5[0x110];
  FUN_00a434b0(auStack_58);
  uStack_8._0_1_ = 4;
  FUN_00a53720(auStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar6 = FUN_00a539f0(iVar2,iStack_20,auStack_58,param_1 + 0x1a0);
  if (((char)iVar6 != '\0') &&
     (iVar6 = FUN_00a540a0(iVar2,iStack_20,auStack_58), (char)iVar6 == '\0')) {
    iVar6 = FUN_00a52ce0(piVar5,auStack_58,param_1 + 0x1a0);
  }
  piVar5 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    uVar7 = auStack_58[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_58[0] - 4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(uVar7,uVar8);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_24 + 1;
    iVar2 = *piVar5;
    iVar6 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piStack_24)();
      LOCK();
      piVar5 = piStack_24 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 20607 ; VA 0x00a48e00 ; FUN_00a48e00 */

int __fastcall FUN_00a48e00(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017df288;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iVar7 = FUN_008f7870(param_1);
  if (iVar7 != 0) {
    uVar3 = *(undefined4 *)(iVar7 + 0x440);
    uVar4 = *(undefined4 *)(iVar7 + 0x444);
    iStack_14 = iVar7;
    FUN_00a53720(auStack_20);
    iStack_8 = 0;
    FUN_00a54ce0(uVar3,uVar4,param_1 + 0x26c);
    FUN_00a53bd0(uVar3,uVar4);
    FUN_00a45a00(iStack_14);
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    iStack_8._0_1_ = 1;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0("source",6);
    iStack_8._0_1_ = 2;
    iVar7 = FUN_00a539f0(uVar3,uVar4,auStack_38,auStack_50);
    cVar5 = (char)iVar7;
    iStack_8._0_1_ = 1;
    uVar6 = (undefined)iStack_8;
    iStack_8._0_1_ = 1;
    if (0xf < uStack_24) {
      uVar9 = uStack_24 + 1;
      uVar8 = auStack_38[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_38[0] - 4);
        uVar9 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar8) - 4) {
          iStack_8._0_1_ = uVar6;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar7 = FUN_01674ea0(uVar8,uVar9);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_3c) {
      uVar9 = uStack_3c + 1;
      uVar8 = auStack_50[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_50[0] - 4);
        uVar9 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar7 = FUN_01674ea0(uVar8,uVar9);
    }
    if (cVar5 == '\0') {
      *(undefined *)(iStack_18 + 0x2c1) = 1;
      if ((*(char *)(iStack_18 + 0x2c0) != '\0') && (iVar7 = FUN_00fce1e0(), (char)iVar7 != '\x01'))
      {
        iVar7 = FUN_008a4940(&DAT_02125ff0);
      }
    }
    else {
      iVar7 = FUN_00a53230(iStack_14);
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar7 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 20608 ; VA 0x00a48fe0 ; FUN_00a48fe0 */

void __fastcall FUN_00a48fe0(int param_1)

{
  undefined uVar1;
  char cVar2;
  char *pcVar3;
  uint *puVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  undefined4 ****ppppuVar8;
  char *pcVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  undefined auStack_124 [28];
  uint uStack_108;
  uint uStack_104;
  uint uStack_100;
  uint uStack_fc;
  undefined auStack_f8 [24];
  undefined auStack_e0 [24];
  int aiStack_c8 [4];
  int iStack_b8;
  undefined4 uStack_b4;
  undefined auStack_b0 [12];
  undefined auStack_a4 [8];
  undefined auStack_9c [8];
  undefined auStack_94 [4];
  undefined8 uStack_90;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  int iStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 ***pppuStack_54;
  undefined4 **ppuStack_50;
  undefined4 **ppuStack_4c;
  undefined4 **ppuStack_48;
  undefined8 uStack_44;
  undefined4 ***pppuStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  undefined auStack_24 [4];
  char *pcStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df348;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  puStack_14 = &stack0xfffffed0;
  uStack_18 = 0;
  uStack_78 = 0xf00000000;
  uStack_88 = uStack_88 & 0xffffff00;
  piVar5 = (int *)(param_1 + 0x26c);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  piVar10 = piVar5;
  if (0xf < *(uint *)(param_1 + 0x280)) {
    piVar10 = (int *)*piVar5;
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  pcStack_20 = (char *)((int)piVar10 + 1);
  pcVar9 = (char *)piVar10;
  do {
    cVar2 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  iStack_70 = param_1;
  FUN_005542c0(piVar10,(int)pcVar9 - (int)pcStack_20);
  uStack_8._0_1_ = 2;
  FUN_016819e0(auStack_b0,auStack_6c);
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_58) {
    uVar11 = uStack_58 + 1;
    uVar12 = auStack_6c[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_6c[0] - 4);
      uVar11 = uStack_58 + 0x24;
      if (0x1f < (auStack_6c[0] - uVar12) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar11);
  }
  uStack_5c = 0;
  uStack_58 = 0xf;
  auStack_6c[0] = auStack_6c[0] & 0xffffff00;
  cVar2 = FUN_016816d0();
  if (cVar2 == '\0') {
    cVar2 = FUN_01681870();
    if (cVar2 == '\0') {
      FUN_005542c0("Manifest parse - Not a JSON object",0x22);
      FUN_0167ec40();
      FUN_00a4970c();
      return;
    }
    FUN_0167eea0(&uStack_100,"translations");
    cVar2 = FUN_01681830();
    if (cVar2 == '\0') {
      if (0xf < *(uint *)(param_1 + 0x280)) {
        piVar5 = (int *)*piVar5;
      }
      cVar2 = FUN_0055c360(piVar5,*(undefined4 *)(param_1 + 0x27c),&DAT_018bf820,2);
      if (cVar2 == '\0') {
        FUN_005542c0("Manifest parse error: Malformed (non-empty) translation list.",0x3d);
        FUN_0167ec40();
        FUN_00a4970c();
        return;
      }
    }
    else {
      FUN_016810c0(&pcStack_20);
      FUN_01680ea0(auStack_24);
      FUN_01681140(auStack_94);
      while (cVar2 = FUN_005e0cd0(auStack_94), cVar2 != '\0') {
        FUN_0167efb0(&uStack_90);
        FUN_0167eea0(auStack_9c,"assetUrl");
        FUN_0167eea0(auStack_a4,"locale");
        cVar2 = FUN_01682670();
        if ((cVar2 == '\0') || (cVar2 = FUN_0167e580(), cVar2 == '\0')) {
          iStack_b8 = 0;
          uStack_b4 = 0xf;
          aiStack_c8[0]._0_1_ = 0;
          FUN_005542c0(&DAT_018bc9b8,0);
          piVar5 = aiStack_c8;
          uVar12 = uStack_18 | 2;
        }
        else {
          piVar5 = (int *)FUN_00563600(auStack_f8);
          uVar12 = uStack_18 | 1;
        }
        uStack_2c = 0;
        uStack_1c = uVar12;
        uStack_18 = uVar12;
        pppuStack_3c = (undefined4 ****)*piVar5;
        iStack_38 = piVar5[1];
        iStack_34 = piVar5[2];
        iStack_30 = piVar5[3];
        uStack_2c = *(undefined8 *)(piVar5 + 4);
        piVar5[4] = 0;
        piVar5[5] = 0xf;
        *(undefined *)piVar5 = 0;
        uStack_8 = 7;
        if ((uVar12 & 2) != 0) {
          uStack_1c = uVar12 & 0xfffffffd;
          uStack_18 = uStack_1c;
          FUN_005507b0();
          uVar12 = uStack_18;
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        if ((uVar12 & 1) != 0) {
          uStack_1c = uVar12 & 0xfffffffe;
          uStack_18 = uStack_1c;
          FUN_005507b0();
        }
        cVar2 = FUN_01682670();
        if ((cVar2 == '\0') || (cVar2 = FUN_0167e580(), cVar2 == '\0')) {
          iStack_b8 = 0;
          uStack_b4 = 0xf;
          aiStack_c8[0]._0_1_ = 0;
          FUN_005542c0(&DAT_018bc9b8,0);
          piVar5 = aiStack_c8;
          uVar12 = uStack_18 | 8;
        }
        else {
          piVar5 = (int *)FUN_00563600(auStack_124);
          uVar12 = uStack_18 | 4;
        }
        uStack_44 = 0;
        uStack_1c = uVar12;
        uStack_18 = uVar12;
        pppuStack_54 = (undefined4 ****)*piVar5;
        ppuStack_50 = (undefined4 ***)piVar5[1];
        ppuStack_4c = (undefined4 ***)piVar5[2];
        ppuStack_48 = (undefined4 ***)piVar5[3];
        uStack_44 = *(undefined8 *)(piVar5 + 4);
        piVar5[4] = 0;
        piVar5[5] = 0xf;
        *(undefined *)piVar5 = 0;
        uStack_8 = 10;
        if ((uVar12 & 8) != 0) {
          uStack_1c = uVar12 & 0xfffffff7;
          uStack_18 = uStack_1c;
          FUN_005507b0();
          uVar12 = uStack_18;
        }
        uStack_8._0_1_ = 0xb;
        if ((uVar12 & 4) != 0) {
          uStack_1c = uVar12 & 0xfffffffb;
          uStack_18 = uStack_1c;
          FUN_005507b0();
        }
        if (((int)uStack_2c == 0) || ((int)uStack_44 == 0)) {
          FUN_005542c0("Manifest parse error: invalid asset url and/or locale",0x35);
        }
        else {
          ppppuVar6 = (undefined4 ****)FUN_00f854f0(auStack_f8,&pppuStack_54);
          if (&pppuStack_54 != ppppuVar6) {
            FUN_005507b0();
            pppuStack_54 = *ppppuVar6;
            ppuStack_50 = ppppuVar6[1];
            ppuStack_4c = ppppuVar6[2];
            ppuStack_48 = ppppuVar6[3];
            uStack_44 = *(undefined8 *)(ppppuVar6 + 4);
            ppppuVar6[4] = (undefined4 ***)0x0;
            ppppuVar6[5] = (undefined4 ***)0xf;
            *(undefined *)ppppuVar6 = 0;
          }
          FUN_005507b0();
          FUN_0054ef60(&pppuStack_54);
          FUN_00f85650(auStack_e0);
          uStack_8._0_1_ = 0xc;
          if (iStack_b8 != 0) {
            uVar7 = FUN_00a36cd0(auStack_f8,auStack_e0,0x2d);
            uStack_8._0_1_ = 0xd;
            uVar7 = FUN_00558c20(auStack_124,uVar7,aiStack_c8);
            FUN_005511f0(uVar7);
            FUN_005507b0();
            uStack_8._0_1_ = 0xc;
            FUN_005507b0();
          }
          if (DAT_01ee7309 != '\0') {
            ppppuVar6 = &pppuStack_3c;
            if (0xf < uStack_2c._4_4_) {
              ppppuVar6 = (undefined4 ****)pppuStack_3c;
            }
            ppppuVar8 = &pppuStack_54;
            if (0xf < uStack_44._4_4_) {
              ppppuVar8 = (undefined4 ****)pppuStack_54;
            }
            FUN_01677520(DAT_01ee7309,"parsed locale url: locale: %s, assetUrl: %s",ppppuVar8,
                         ppppuVar6);
          }
          ppppuVar6 = (undefined4 ****)FUN_00a3ccd0(&pppuStack_54);
          if (ppppuVar6 != &pppuStack_3c) {
            ppppuVar6 = &pppuStack_3c;
            if (0xf < uStack_2c._4_4_) {
              ppppuVar6 = (undefined4 ****)pppuStack_3c;
            }
            FUN_005542c0(ppppuVar6,(int)uStack_2c);
          }
          FUN_005509f0();
        }
        uStack_8._0_1_ = 8;
        uVar1 = (undefined)uStack_8;
        uStack_8._0_1_ = 8;
        if (0xf < uStack_44._4_4_) {
          uVar12 = uStack_44._4_4_ + 1;
          ppppuVar6 = (undefined4 ****)pppuStack_54;
          if (0xfff < uVar12) {
            ppppuVar6 = (undefined4 ****)pppuStack_54[-1];
            uVar12 = uStack_44._4_4_ + 0x24;
            if (0x1f < (uint)((int)pppuStack_54 + (-4 - (int)ppppuVar6))) {
              uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar6,uVar12);
        }
        uStack_44 = 0xf00000000;
        pppuStack_54 = (undefined4 ***)((uint)pppuStack_54 & 0xffffff00);
        uStack_8._0_1_ = 4;
        if (0xf < uStack_2c._4_4_) {
          uVar12 = uStack_2c._4_4_ + 1;
          ppppuVar6 = (undefined4 ****)pppuStack_3c;
          if (0xfff < uVar12) {
            ppppuVar6 = (undefined4 ****)pppuStack_3c[-1];
            uVar12 = uStack_2c._4_4_ + 0x24;
            if (0x1f < (uint)((int)pppuStack_3c + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(ppppuVar6,uVar12);
        }
        FUN_0167f070();
      }
    }
  }
  else {
    pcVar3 = (char *)FUN_016814a0();
    uStack_2c = 0xf00000000;
    pppuStack_3c = (undefined4 ***)((uint)pppuStack_3c & 0xffffff00);
    pcVar9 = pcVar3;
    do {
      cVar2 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar3,(int)pcVar9 - (int)(pcVar3 + 1));
    uStack_8._0_1_ = 5;
    puVar4 = (uint *)FUN_00585d40(0,"Manifest parse error: ",0x16);
    uStack_108 = *puVar4;
    uStack_104 = puVar4[1];
    uStack_100 = puVar4[2];
    uStack_fc = puVar4[3];
    uStack_90 = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    FUN_005507b0();
    uStack_8._0_1_ = 4;
    uStack_88 = uStack_108;
    uStack_84 = uStack_104;
    uStack_80 = uStack_100;
    uStack_7c = uStack_fc;
    uStack_78 = uStack_90;
    if (0xf < uStack_2c._4_4_) {
      uVar12 = uStack_2c._4_4_ + 1;
      ppppuVar6 = (undefined4 ****)pppuStack_3c;
      if (0xfff < uVar12) {
        ppppuVar6 = (undefined4 ****)pppuStack_3c[-1];
        uVar12 = uStack_2c._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppuStack_3c + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar6,uVar12);
      FUN_0167ec40();
      FUN_00a4970c();
      return;
    }
  }
  FUN_0167ec40();
  FUN_00a4970c();
  return;
}



/* FUNCTION 20609 ; VA 0x00a496af ; Catch@00a496af */

undefined * Catch_00a496af(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x108) + 4))();
  uVar1 = FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  uVar1 = FUN_00558d90(unaff_EBP + -0x120,"manifestFetchComplete parse error: ",uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  FUN_005507b0();
  return &DAT_00a49709;
}



/* FUNCTION 20610 ; VA 0x00a4970c ; FUN_00a4970c */

void FUN_00a4970c(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int unaff_EBP;
  uint unaff_ESI;
  
  iVar1 = *(int *)(unaff_EBP + -0x74);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  if (iVar1 != 0) {
    *(undefined *)(unaff_EBP + -4) = 0x10;
    *(undefined4 *)(unaff_EBP + -0x58) = 0;
    *(undefined4 *)(unaff_EBP + -0x54) = 0xf;
    *(undefined *)(unaff_EBP + -0x68) = 0;
    *(uint *)(unaff_EBP + -0x18) = unaff_ESI | 0x20;
    FUN_0058a190(iVar1 + 0x13);
    FUN_00554150("Malformed manifest:",0x13);
    iVar3 = unaff_EBP + -0x84;
    if (0xf < *(uint *)(unaff_EBP + -0x70)) {
      iVar3 = *(int *)(unaff_EBP + -0x84);
    }
    FUN_00554150(iVar3,iVar1);
    FUN_00a4acd0(unaff_EBP + -0x68);
    uVar2 = *(uint *)(unaff_EBP + -0x54);
    if (0xf < uVar2) {
      iVar1 = *(int *)(unaff_EBP + -0x68);
      uVar4 = uVar2 + 1;
      iVar3 = iVar1;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar1 + -4);
        uVar4 = uVar2 + 0x24;
        if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
  }
  uVar2 = *(uint *)(unaff_EBP + -0x70);
  if (0xf < uVar2) {
    iVar1 = *(int *)(unaff_EBP + -0x84);
    uVar4 = uVar2 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar2 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 20611 ; VA 0x00a49810 ; FUN_00a49810 */

void FUN_00a49810(int param_1,int param_2)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ea0;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    return;
  }
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_00928340();
  uVar2 = FUN_01679ce0();
  bVar1 = (int)(uVar2 % 10000) < DAT_01d65ffc;
  if (param_2 == 1) {
    iVar3 = FUN_00a3ca30(&uStack_18);
    FUN_00fcc2f0(iVar3 + 8);
    if (bVar1) goto LAB_00a49916;
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = 0;
    FUN_005542c0("TrackPlayerTextScraping_PlayerTrusted",0x25);
    uStack_8 = 0;
    FUN_008783f0(auStack_30,1,0);
  }
  else {
    if (((param_2 != 2) && (param_2 != 3)) || (bVar1)) goto LAB_00a49916;
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = 0;
    FUN_005542c0("TrackPlayerTextScraping_PlayerUntrusted",0x27);
    uStack_8 = 1;
    FUN_008783f0(auStack_48,1,0);
  }
  FUN_005507b0();
LAB_00a49916:
  FUN_00a40b80(&uStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20612 ; VA 0x00a49940 ; FUN_00a49940 */

void __fastcall FUN_00a49940(int param_1)

{
  *(undefined *)(param_1 + 0x2c0) = 0;
  FUN_00fd0340();
  FUN_008a50b0();
  return;
}



/* FUNCTION 20613 ; VA 0x00a49960 ; FUN_00a49960 */

/* WARNING: Removing unreachable block (ram,0x00a49a0b) */
/* WARNING: Removing unreachable block (ram,0x00a49a1e) */
/* WARNING: Removing unreachable block (ram,0x00a49a25) */
/* WARNING: Removing unreachable block (ram,0x00a49a2c) */

void __fastcall FUN_00a49960(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  uStack_14 = uStack_14 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  iVar2 = *(int *)(param_1 + 8);
  iVar1 = *(int *)(param_1 + 0xc) - iVar2 >> 2;
  uStack_8 = 0;
  if (iVar1 != 0) {
    iVar3 = *(int *)(param_1 + 0x14);
    if (*(int *)(param_1 + 0x18) - iVar3 >> 2 != iVar1) {
      FUN_005f86c0(iVar1,(int *)(param_1 + 0x14));
      iVar3 = *(int *)(param_1 + 0x14);
      iVar2 = *(int *)(param_1 + 8);
    }
    FUN_0170cc70(iVar3,iVar2,*(int *)(param_1 + 0xc) - iVar2);
  }
  FUN_0058c660();
  FUN_00a38120(*(int *)(param_1 + 0x14),*(int *)(param_1 + 0x18),
               *(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14) >> 2,uStack_14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20614 ; VA 0x00a49a50 ; FUN_00a49a50 */

int __thiscall FUN_00a49a50(undefined4 param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined auStack_118 [200];
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df39b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffed4;
  ExceptionList = &pvStack_10;
  uStack_24 = param_1;
  puVar2 = &stack0xfffffed4;
  if (param_2 == &DAT_021261e8) {
    piVar7 = (int *)0x0;
    iStack_18 = 0;
    iStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    ExceptionList = &pvStack_10;
    FUN_008c03c0(&iStack_20);
    uStack_8._0_1_ = 2;
    if (iStack_20 != 0) {
      piVar4 = (int *)FUN_00562c90(auStack_50,&iStack_20);
      iStack_2c = *piVar4;
      piVar7 = (int *)piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      piStack_28 = piVar7;
      iStack_18 = iStack_2c;
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          iVar5 = piStack_4c[2] + -1;
          piStack_4c[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_4c + 4))();
          }
        }
      }
    }
    piVar4 = piStack_1c;
    uStack_8._0_1_ = 1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (iStack_18 == 0) {
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0("TextScraping_MissingPlayerError",0x1f);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_008783f0(auStack_44,1,0);
      iVar5 = FUN_005507b0();
      if (piVar7 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return iVar5;
      }
      LOCK();
      piVar4 = piVar7 + 1;
      iVar5 = *piVar4;
      iVar6 = *piVar4;
      *piVar4 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 != 0) {
        ExceptionList = pvStack_10;
        return iVar6;
      }
      iVar6 = (**(code **)*piVar7)();
      LOCK();
      piVar4 = piVar7 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 != 1) {
        ExceptionList = pvStack_10;
        return iVar6;
      }
      iVar5 = (**(code **)(*piVar7 + 4))();
      ExceptionList = pvStack_10;
      return iVar5;
    }
    FUN_00927d30(&iStack_18);
    cVar3 = FUN_005e0cd0(param_4);
    if (cVar3 != '\0') {
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      FUN_005542c0("TrackPlayerTextScraping_PlayerSenderMismatch",0x2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008783f0(auStack_44,1,0);
      FUN_005507b0();
      iVar5 = FUN_00550b30();
      ExceptionList = pvStack_10;
      return iVar5;
    }
    piVar7 = (int *)*param_3;
    iVar5 = *piVar7;
    iVar6 = FUN_0088c8c0();
    if (iVar5 == iVar6) {
      iVar5 = *piVar7;
      iVar6 = FUN_0088c8c0();
      if (iVar5 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar4 = piVar7 + 2;
      if (piVar7[1] == 0) {
        piVar4 = (int *)0x0;
      }
      iVar5 = *piVar4;
    }
    else {
      if ((undefined4 *)piVar7[1] != (undefined4 *)0x0) {
        (**(code **)piVar7[1])(piVar7 + 2,auStack_118);
      }
      iVar6 = piVar7[1];
      uStack_8._0_1_ = 4;
      piVar7 = (int *)FUN_00889220();
      iVar5 = *piVar7;
      uStack_8._0_1_ = 5;
      if (iVar6 != 0) {
        (**(code **)(iVar6 + 8))(auStack_118);
      }
      uStack_8._0_1_ = 1;
    }
    FUN_00a3a5b0(&iStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    FUN_00a49dc0(iVar5,&iStack_2c,iStack_20,piStack_1c);
    FUN_00550b30();
    FUN_00550b30();
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0xffffffff;
  iVar5 = FUN_009cba80(param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20615 ; VA 0x00a49d4a ; Catch@00a49d4a */

undefined4 Catch_00a49d4a(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x44) + 4))();
  FUN_0086f2f0(3,"LocalizationService::processRemoteEvent error %s",uVar1);
  *(undefined4 *)(unaff_EBP + -0x30) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0xf;
  *(undefined *)(unaff_EBP + -0x40) = 0;
  FUN_005542c0("TrackPlayerTextScraping_ArgParseError",0x25);
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_008783f0(unaff_EBP + -0x40,1,0);
  FUN_005507b0();
  return 0xa49cc5;
}



/* FUNCTION 20616 ; VA 0x00a49da5 ; Catch_All@00a49da5 */

undefined4 Catch_All_00a49da5(void)

{
  return 0xa49caa;
}



/* FUNCTION 20617 ; VA 0x00a49dc0 ; FUN_00a49dc0 */

uint __thiscall
FUN_00a49dc0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined auStack_10c [16];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined auStack_f4 [20];
  undefined4 uStack_e0;
  undefined4 uStack_b4;
  int *piStack_b0;
  undefined *puStack_ac;
  int *piStack_a8;
  undefined auStack_98 [4];
  int *piStack_94;
  undefined auStack_50 [24];
  undefined auStack_38 [24];
  undefined8 uStack_20;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df3fe;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar5 = *(uint *)(*param_3 + 0x440);
  piStack_14 = param_1;
  if (uVar5 == 0) {
    piStack_a8 = (int *)0xa49e08;
    ExceptionList = &pvStack_10;
    uStack_20 = FUN_00928340();
    piStack_a8 = (int *)&uStack_20;
    puStack_ac = (undefined *)0xa49e1d;
    iVar4 = FUN_00a3ca30();
    piStack_14 = (int *)(iVar4 + 8);
    uVar5 = (*(int *)(iVar4 + 0xc) - *piStack_14) / 0x48;
    if (DAT_01d65ff4 <= uVar5) {
      param_1[0xb1] = param_1[0xb1] + 1;
      goto LAB_00a4a04f;
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puStack_ac = (undefined *)param_4;
    piStack_a8 = param_5;
    piStack_b0 = (int *)0xa49e78;
    FUN_00fc9e40();
    uStack_8._0_1_ = 1;
    piStack_a8 = (int *)(*param_3 + 0x2a8);
    puStack_ac = (undefined *)0xa49e8f;
    FUN_0054ef60();
    piStack_a8 = (int *)auStack_38;
    uStack_8._0_1_ = 2;
    puStack_ac = auStack_50;
    piStack_b0 = (int *)0xa49ea0;
    FUN_00fce8e0();
    uStack_8._0_1_ = 4;
    piStack_a8 = (int *)0xa49eaf;
    FUN_005507b0();
    piStack_a8 = (int *)0xa49eb8;
    uVar6 = FUN_00928340();
    puStack_f8 = auStack_50;
    puStack_18 = auStack_f4;
    uStack_fc = 0xa49ed3;
    FUN_0054ef60();
    uStack_8._0_1_ = 5;
    FUN_00927520(auStack_10c);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00a3b080(uVar6);
    uStack_e0 = 0xa49efc;
    FUN_00fd06e0();
    piVar2 = piStack_14;
    piStack_a8 = (int *)auStack_98;
    puStack_ac = (undefined *)piStack_14[1];
    if ((undefined *)piStack_14[2] == puStack_ac) {
      piStack_b0 = (int *)0xa49f2b;
      FUN_00a37190();
    }
    else {
      piStack_b0 = piStack_14;
      uStack_b4 = 0xa49f15;
      FUN_00a39cf0();
      piVar2[1] = piVar2[1] + 0x48;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (uVar5 != 1) goto LAB_00a4a04f;
    ExceptionList = &pvStack_10;
    if (param_5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puStack_ac = (undefined *)param_4;
    piStack_a8 = param_5;
    piStack_b0 = (int *)0xa49f7a;
    FUN_00fc9e40();
    piStack_a8 = (int *)(*param_3 + 0x2a8);
    uStack_8._0_1_ = 6;
    puStack_ac = (undefined *)0xa49f8e;
    FUN_0054ef60();
    piStack_a8 = (int *)auStack_50;
    uStack_8._0_1_ = 7;
    puStack_ac = auStack_38;
    piStack_b0 = (int *)0xa49f9f;
    FUN_00fce8e0();
    uStack_8._0_1_ = 9;
    piStack_a8 = (int *)0xa49fae;
    FUN_005507b0();
    piStack_a8 = (int *)0xa49fb7;
    uVar6 = FUN_00928340();
    puStack_f8 = auStack_38;
    uStack_20._4_4_ = auStack_f4;
    uStack_fc = 0xa49fd2;
    FUN_0054ef60();
    uStack_8._0_1_ = 10;
    FUN_00927520(auStack_10c);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_00a3b080(uVar6);
    uStack_e0 = 0xa49ffb;
    FUN_00fd06e0();
    piStack_a8 = (int *)auStack_98;
    puStack_ac = (undefined *)0xa4a010;
    FUN_00fcc250();
  }
  piStack_a8 = (int *)0xa4a018;
  FUN_005507b0();
  piStack_a8 = (int *)0xa4a023;
  uVar5 = FUN_00651cc0();
  if (piStack_94 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_94 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_a8 = (int *)0xa4a03f;
      (**(code **)*piStack_94)();
      LOCK();
      puVar1 = (uint *)(piStack_94 + 2);
      uVar3 = *puVar1;
      uVar5 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        piStack_a8 = (int *)0xa4a04f;
        uVar5 = (**(code **)(*piStack_94 + 4))();
      }
    }
  }
LAB_00a4a04f:
  if (param_5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_5 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      piStack_a8 = (int *)0xa4a065;
      uVar5 = (**(code **)*param_5)();
      LOCK();
      piVar2 = param_5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piStack_a8 = (int *)0xa4a074;
        uVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 20618 ; VA 0x00a4a090 ; FUN_00a4a090 */

void FUN_00a4a090(int *param_1,uint param_2)

{
  code *pcVar1;
  undefined uVar2;
  uint in_stack_00000028;
  int iStack_24;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df438;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  ExceptionList = &pvStack_10;
  FUN_00a3a470();
  uStack_8._0_1_ = 2;
  if (iStack_1c != 0) {
    FUN_00eb65e0();
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (*(int **)(iStack_24 + 0x58) != (int *)0x0) {
      pcVar1 = *(code **)(**(int **)(iStack_24 + 0x58) + 0x7c);
      FUN_0054f510(&stack0x00000028);
      uStack_8._0_1_ = 4;
      FUN_0054f510(&param_2);
      if (iStack_18 != 0) {
        LOCK();
        *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      (*pcVar1)(iStack_1c,iStack_18);
      FUN_00550b30();
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (param_2 != 0) {
        if (((param_2 & 1) == 0) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
        }
        param_2 = 0;
      }
      uStack_8 = 6;
      if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
         (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 20619 ; VA 0x00a4a1f0 ; FUN_00a4a1f0 */

void __thiscall
FUN_00a4a1f0(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 *param_7,ulonglong param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            int *param_14,undefined8 param_15)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  uint *puVar4;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined8 uStack_3c;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df478;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = CONCAT44(param_1,&uStack_24);
  piStack_40 = (int *)0xa4a21e;
  ExceptionList = &pvStack_10;
  FUN_0060e0c0();
  piStack_40 = &iStack_2c;
  uStack_8._0_1_ = 2;
  uStack_44 = 0xa4a22b;
  FUN_00eb65e0();
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int **)(iStack_2c + 0x58) == (int *)0x0) {
    uStack_3c = 0x194230000a4a3b1;
    uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  puStack_18 = (undefined *)auStack_54;
  puStack_1c = (undefined *)auStack_54;
  pcStack_14 = *(code **)(**(int **)(iStack_2c + 0x58) + 0x70);
  auStack_54[0] = 0;
  puVar4 = auStack_54;
  if (param_9 != 0) {
    auStack_54[0] = param_9;
    if ((param_9 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &param_11;
      uStack_64 = 0xa4a28c;
      (**(code **)(param_9 & 0xfffffffe))();
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_4c = param_11;
      uStack_48 = param_12;
      uStack_44 = param_13;
      piStack_40 = param_14;
      uStack_3c = param_15;
      puVar4 = auStack_54;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)auStack_74;
  uStack_8._0_1_ = 4;
  auStack_74[0] = 0;
  puVar4 = auStack_74;
  if (param_2 != 0) {
    auStack_74[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_6c,0);
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_6c = param_4;
      uStack_68 = param_5;
      uStack_64 = param_6;
      puStack_60 = param_7;
      uStack_5c = param_8;
      puVar4 = auStack_74;
    }
  }
  puStack_1c = (undefined *)puVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (*pcStack_14)(uStack_24,piStack_20);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 6;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20620 ; VA 0x00a4a3c0 ; FUN_00a4a3c0 */

void __thiscall
FUN_00a4a3c0(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 *param_7,ulonglong param_8,uint param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            int *param_14,undefined8 param_15)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  uint *puVar4;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined8 uStack_3c;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df478;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = CONCAT44(param_1,&uStack_24);
  piStack_40 = (int *)0xa4a3ee;
  ExceptionList = &pvStack_10;
  FUN_0060e0c0();
  piStack_40 = &iStack_2c;
  uStack_8._0_1_ = 2;
  uStack_44 = 0xa4a3fb;
  FUN_00eb65e0();
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (*(int **)(iStack_2c + 0x58) == (int *)0x0) {
    uStack_3c = 0x194230000a4a581;
    uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  puStack_18 = (undefined *)auStack_54;
  puStack_1c = (undefined *)auStack_54;
  pcStack_14 = *(code **)(**(int **)(iStack_2c + 0x58) + 0x6c);
  auStack_54[0] = 0;
  puVar4 = auStack_54;
  if (param_9 != 0) {
    auStack_54[0] = param_9;
    if ((param_9 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &param_11;
      uStack_64 = 0xa4a45c;
      (**(code **)(param_9 & 0xfffffffe))();
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_4c = param_11;
      uStack_48 = param_12;
      uStack_44 = param_13;
      piStack_40 = param_14;
      uStack_3c = param_15;
      puVar4 = auStack_54;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)auStack_74;
  uStack_8._0_1_ = 4;
  auStack_74[0] = 0;
  puVar4 = auStack_74;
  if (param_2 != 0) {
    auStack_74[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_6c,0);
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_6c = param_4;
      uStack_68 = param_5;
      uStack_64 = param_6;
      puStack_60 = param_7;
      uStack_5c = param_8;
      puVar4 = auStack_74;
    }
  }
  puStack_1c = (undefined *)puVar4;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (*pcStack_14)(uStack_24,piStack_20);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar2 = piStack_28[2] + -1;
      piStack_28[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  uStack_8 = 6;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20621 ; VA 0x00a4a590 ; FUN_00a4a590 */

void FUN_00a4a590(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,ulonglong param_7,uint param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined8 param_14)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  uint *puVar4;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  ulonglong uStack_50;
  uint auStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df4b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_30 = CONCAT44(&iStack_20,0xa4a5bd);
  ExceptionList = &pvStack_10;
  FUN_00eb65e0();
  uStack_8._0_1_ = 2;
  if (*(int **)(iStack_20 + 0x58) == (int *)0x0) {
    uStack_30 = 0x194230000a4a704;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  puStack_14 = (undefined *)auStack_48;
  puStack_18 = (undefined *)auStack_48;
  pcVar2 = *(code **)(**(int **)(iStack_20 + 0x58) + 0x78);
  auStack_48[0] = 0;
  puVar4 = auStack_48;
  if (param_8 != 0) {
    auStack_48[0] = param_8;
    if ((param_8 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_40);
      puStack_54 = &param_10;
      uStack_58 = 0xa4a61b;
      (**(code **)(param_8 & 0xfffffffe))();
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_40 = param_10;
      uStack_3c = param_11;
      uStack_38 = param_12;
      uStack_34 = param_13;
      uStack_30 = param_14;
      puVar4 = auStack_48;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puStack_18 = (undefined *)auStack_68;
  uStack_8._0_1_ = 3;
  auStack_68[0] = 0;
  puVar4 = auStack_68;
  if (param_1 != 0) {
    auStack_68[0] = param_1;
    if ((param_1 & 1) == 0) {
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_60,0);
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_60 = param_3;
      uStack_5c = param_4;
      uStack_58 = param_5;
      puStack_54 = param_6;
      uStack_50 = param_7;
      puVar4 = auStack_68;
    }
  }
  puStack_18 = (undefined *)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)();
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
  }
  uStack_8 = 5;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_8 & 0xfffffffe))(&param_10,&param_10,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20622 ; VA 0x00a4a710 ; FUN_00a4a710 */

void __thiscall FUN_00a4a710(int param_1,int param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dde48;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    ExceptionList = &pvStack_10;
    *puVar1 = 0;
    FUN_005880d0(param_2);
    uStack_8 = 0;
    puVar1[8] = 0;
    FUN_005880d0(param_2 + 0x20);
    puVar1[0x10] = 0;
    puVar1[0x11] = 0;
    puVar1[0x10] = *(undefined4 *)(param_2 + 0x40);
    puVar1[0x11] = *(undefined4 *)(param_2 + 0x44);
    *(undefined4 *)(param_2 + 0x40) = 0;
    *(undefined4 *)(param_2 + 0x44) = 0;
    puVar1[0x12] = *(undefined4 *)(param_2 + 0x48);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x50;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00a37370(puVar1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20623 ; VA 0x00a4a7d0 ; FUN_00a4a7d0 */

int __thiscall FUN_00a4a7d0(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8f68;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)0x0;
  uStack_24 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870();
  if (iVar2 != 0) {
    piVar3 = (int *)FUN_00564080();
    iVar2 = *piVar3;
    if (iVar2 != 0) {
      piVar4 = *(int **)(iVar2 + 0xf8);
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = *(int **)(iVar2 + 0xf8);
      }
      uStack_24 = *(undefined4 *)(iVar2 + 0xf4);
    }
  }
  if (*(int *)(param_2 + 4) != 0) {
    LOCK();
    piVar3 = (int *)(*(int *)(param_2 + 4) + 4);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  iVar2 = FUN_00a4aad0(param_1,1,uStack_24,piVar4);
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar3 = piVar4 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20624 ; VA 0x00a4a910 ; FUN_00a4a910 */

int FUN_00a4a910(undefined4 *param_1,undefined4 *param_2)

{
  char *pcVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  
  puVar2 = param_1;
  iVar5 = 0;
  puVar4 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  puVar3 = (undefined4 *)(param_1[4] + (int)puVar4);
  param_1 = param_2;
  if (0xf < (uint)param_2[5]) {
    param_1 = (undefined4 *)*param_2;
  }
  param_1 = (undefined4 *)(((param_2[4] - puVar2[4]) - (int)puVar4) + (int)puVar3 + (int)param_1);
  while( true ) {
    puVar4 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar4 = (undefined4 *)*puVar2;
    }
    if (puVar3 <= puVar4) {
      return iVar5;
    }
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    if (param_1 <= puVar4) break;
    pcVar1 = (char *)((int)puVar3 + -1);
    puVar3 = (undefined4 *)((int)puVar3 + -1);
    if (*pcVar1 != *(char *)((int)param_1 + -1)) {
      return iVar5;
    }
    iVar5 = iVar5 + 1;
    param_1 = (undefined4 *)((int)param_1 + -1);
  }
  return iVar5;
}



/* FUNCTION 20625 ; VA 0x00a4a990 ; FUN_00a4a990 */

void FUN_00a4a990(int param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  iVar2 = *(int *)(param_1 + 0x34);
  param_2 = param_2 + *(int *)(*(int *)(param_1 + 0x28) + 0x10);
  if (iVar2 != 0) {
    iVar3 = *(int *)(iVar2 + 0xc);
    iVar4 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar4 + 0x1da) <
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
      iVar3 = *(int *)(iVar2 + 0xc);
      iVar4 = FUN_00913630();
      if ((uint)*(ushort *)(iVar4 + 0x1da) <
          (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
        FUN_00a4a990(iVar2,param_2 + 1,param_3);
        FUN_00592760(0x2e);
        goto LAB_00a4aa16;
      }
    }
  }
  FUN_0058a190(param_2);
LAB_00a4aa16:
  piVar5 = *(int **)(param_1 + 0x28);
  piVar1 = piVar5 + 4;
  if (0xf < (uint)piVar5[5]) {
    piVar5 = (int *)*piVar5;
  }
  FUN_00554150(piVar5,*piVar1);
  return;
}



/* FUNCTION 20626 ; VA 0x00a4aa40 ; FUN_00a4aa40 */

uint * __thiscall FUN_00a4aa40(int param_1,undefined4 *param_2)

{
  byte *pbVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  
  puVar2 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  uVar3 = 0;
  uVar4 = 0x811c9dc5;
  if (*puVar2 != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)param_2);
      uVar3 = uVar3 + 1;
      uVar4 = (*pbVar1 ^ uVar4) * 0x1000193;
    } while (uVar3 < *puVar2);
  }
  puVar2 = *(uint **)(param_1 + 0x18);
  uVar3 = (int)puVar2 - *(int *)(param_1 + 0x14) >> 2;
  if (uVar3 < 10) {
    if (*(uint **)(param_1 + 0x1c) != puVar2) {
      *puVar2 = uVar4;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
      return puVar2;
    }
    param_2 = (undefined4 *)uVar4;
    puVar2 = (uint *)FUN_00595d30(puVar2,&param_2);
    return puVar2;
  }
  *(uint *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 0x10) * 4) = uVar4;
  uVar4 = *(int *)(param_1 + 0x10) + 1;
  *(uint *)(param_1 + 0x10) = uVar4 % uVar3;
  return (uint *)(uVar4 / uVar3);
}



/* FUNCTION 20627 ; VA 0x00a4aad0 ; FUN_00a4aad0 */

/* WARNING: Removing unreachable block (ram,0x00a4ac72) */
/* WARNING: Removing unreachable block (ram,0x00a4ac7b) */
/* WARNING: Removing unreachable block (ram,0x00a4ac8a) */
/* WARNING: Removing unreachable block (ram,0x00a4ac98) */
/* WARNING: Removing unreachable block (ram,0x00a4aca1) */
/* WARNING: Removing unreachable block (ram,0x00a4acaf) */

undefined4
FUN_00a4aad0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  code *pcStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017df517;
  pvStack_10 = ExceptionList;
  uStack_14 = param_5;
  uStack_30 = param_5;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_18 = param_6;
  uStack_2c = param_6;
  uStack_28 = param_3;
  uStack_24 = param_4;
  uStack_8 = 3;
  uStack_7 = 0;
  pcStack_20 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_2b4 = FUN_0088c8c0();
  uStack_2b0 = 0;
  uStack_2ac = param_2;
  uStack_2b0 = FUN_005c9cc0();
  uStack_8 = 4;
  uStack_1e4 = FUN_0088cdc0();
  uStack_1e0 = 0;
  uStack_1dc = param_3;
  uStack_1d8 = param_4;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_1e0 = FUN_006309e0();
  uStack_8 = 5;
  uStack_114 = FUN_0088cbe0();
  uStack_10c = uStack_14;
  uStack_110 = 0;
  uStack_108 = uStack_18;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_110 = FUN_00630900();
  uStack_8 = 6;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_00687980(&uStack_2b4,&uStack_44,param_1);
  uStack_8 = 7;
  (*pcStack_20)(uStack_1c,&uStack_3c,&uStack_44);
  uStack_8 = 8;
  FUN_00577b20();
  _uStack_8 = CONCAT31(uStack_7,3);
  uVar1 = FUN_016f32d1(&uStack_2b4,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20628 ; VA 0x00a4acd0 ; FUN_00a4acd0 */

void FUN_00a4acd0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151f950("Error",param_1);
  uVar1 = DAT_01ee72f8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("LocalizationServiceFailure",0x1a);
  uStack_8._0_1_ = 1;
  FUN_01520d20(auStack_28,uVar1,0);
  uStack_8._0_1_ = 0;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("LocalizationServiceAsyncLoadingError",0x24);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008783f0(auStack_28,1,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20629 ; VA 0x00a4ae10 ; FUN_00a4ae10 */

void FUN_00a4ae10(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  bool bVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined auStack_10 [4];
  int *piStack_c;
  uint uStack_8;
  
  uStack_8 = 0;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    iVar6 = FUN_00c3ebd0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      FUN_00c44c40();
    }
    iVar2 = param_1[3];
    iVar6 = FUN_00d59db0();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      (**(code **)(*param_1 + 0xf8))();
    }
    puVar3 = (undefined4 *)param_1[0xb];
    if (puVar3 != (undefined4 *)0x0) {
      piVar4 = (int *)puVar3[1];
      for (piVar9 = (int *)*puVar3; piVar9 != piVar4; piVar9 = piVar9 + 2) {
        iVar2 = *piVar9;
        if ((iVar2 == 0) ||
           (iVar6 = *(int *)(iVar2 + 0xc), iVar7 = FUN_00d59db0(),
           (uint)*(ushort *)(iVar7 + 0x1da) <
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
LAB_00a4af32:
          FUN_00a4ae10(*piVar9,param_2);
        }
        else if (*(char *)(iVar2 + 0x70) != '\0') {
          if ((char)param_2 == '\0') {
            piVar8 = (int *)FUN_00a437a0(auStack_10);
            uStack_8 = uStack_8 | 1;
            if (*piVar8 == 0) goto LAB_00a4aef9;
            bVar5 = true;
          }
          else {
LAB_00a4aef9:
            bVar5 = false;
          }
          piVar8 = piStack_c;
          if (((uStack_8 & 1) != 0) && (uStack_8 = uStack_8 & 0xfffffffe, piStack_c != (int *)0x0))
          {
            LOCK();
            iVar2 = piStack_c[1] + -1;
            piStack_c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_c)();
              LOCK();
              piVar1 = piVar8 + 2;
              iVar2 = *piVar1 + -1;
              *piVar1 = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          if (!bVar5) goto LAB_00a4af32;
        }
      }
    }
  }
  return;
}



/* FUNCTION 20630 ; VA 0x00a4af60 ; FUN_00a4af60 */

/* WARNING: Removing unreachable block (ram,0x00a4b896) */
/* WARNING: Removing unreachable block (ram,0x00a4b75d) */
/* WARNING: Removing unreachable block (ram,0x00a4b624) */
/* WARNING: Removing unreachable block (ram,0x00a4b3f7) */
/* WARNING: Removing unreachable block (ram,0x00a4bafe) */
/* WARNING: Removing unreachable block (ram,0x00a4b2f8) */
/* WARNING: Removing unreachable block (ram,0x00a4baf4) */
/* WARNING: Removing unreachable block (ram,0x00a4b1f9) */
/* WARNING: Removing unreachable block (ram,0x00a4baea) */
/* WARNING: Removing unreachable block (ram,0x00a4b147) */
/* WARNING: Removing unreachable block (ram,0x00a4bae5) */
/* WARNING: Removing unreachable block (ram,0x00a4b0c2) */
/* WARNING: Removing unreachable block (ram,0x00a4bae0) */
/* WARNING: Removing unreachable block (ram,0x00a4b03d) */
/* WARNING: Removing unreachable block (ram,0x00a4b02f) */
/* WARNING: Removing unreachable block (ram,0x00a4b051) */
/* WARNING: Removing unreachable block (ram,0x00a4b0b4) */
/* WARNING: Removing unreachable block (ram,0x00a4b0d6) */
/* WARNING: Removing unreachable block (ram,0x00a4b139) */
/* WARNING: Removing unreachable block (ram,0x00a4b15b) */
/* WARNING: Removing unreachable block (ram,0x00a4b1eb) */
/* WARNING: Removing unreachable block (ram,0x00a4b20d) */
/* WARNING: Removing unreachable block (ram,0x00a4b2ea) */
/* WARNING: Removing unreachable block (ram,0x00a4b30c) */
/* WARNING: Removing unreachable block (ram,0x00a4b3e9) */
/* WARNING: Removing unreachable block (ram,0x00a4b40b) */
/* WARNING: Removing unreachable block (ram,0x00a4b4e4) */
/* WARNING: Removing unreachable block (ram,0x00a4b4f2) */
/* WARNING: Removing unreachable block (ram,0x00a4b506) */
/* WARNING: Removing unreachable block (ram,0x00a4b632) */
/* WARNING: Removing unreachable block (ram,0x00a4bb08) */
/* WARNING: Removing unreachable block (ram,0x00a4b646) */
/* WARNING: Removing unreachable block (ram,0x00a4b76b) */
/* WARNING: Removing unreachable block (ram,0x00a4bb12) */
/* WARNING: Removing unreachable block (ram,0x00a4b77f) */
/* WARNING: Removing unreachable block (ram,0x00a4b8a4) */
/* WARNING: Removing unreachable block (ram,0x00a4bb1c) */
/* WARNING: Removing unreachable block (ram,0x00a4b8b8) */

void FUN_00a4af60(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  undefined uVar11;
  int iStack_60;
  uint uStack_4c;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df5f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00563d40();
  uStack_8 = 0;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar7 = FUN_005d15d0();
  if (iVar7 + 0x18 != param_1) {
    FUN_005542c0();
  }
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar7 = FUN_005d15d0();
  if (iVar7 + 0x18 != param_2) {
    FUN_005542c0();
  }
  uStack_8 = uStack_8 & 0xffffff00;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar7 = FUN_005d15d0();
  if (iVar7 + 0x18 != param_3) {
    FUN_005542c0();
  }
  uStack_8 = uStack_8 & 0xffffff00;
  puVar8 = (undefined4 *)FUN_01675640();
  uStack_8._0_1_ = 4;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar7 = FUN_005d15d0();
  if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
    FUN_005507b0();
    uVar2 = puVar8[1];
    uVar3 = puVar8[2];
    uVar4 = puVar8[3];
    *(undefined4 *)(iVar7 + 0x18) = *puVar8;
    *(undefined4 *)(iVar7 + 0x1c) = uVar2;
    *(undefined4 *)(iVar7 + 0x20) = uVar3;
    *(undefined4 *)(iVar7 + 0x24) = uVar4;
    uVar2 = puVar8[5];
    *(undefined4 *)(iVar7 + 0x28) = puVar8[4];
    *(undefined4 *)(iVar7 + 0x2c) = uVar2;
    puVar8[4] = 0;
    puVar8[5] = 0xf;
    *(undefined *)puVar8 = 0;
  }
  uStack_8._0_1_ = 0;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  puVar8 = (undefined4 *)FUN_01675640();
  uStack_8._0_1_ = 6;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar7 = FUN_005d15d0();
  if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
    FUN_005507b0();
    uVar2 = puVar8[1];
    uVar3 = puVar8[2];
    uVar4 = puVar8[3];
    *(undefined4 *)(iVar7 + 0x18) = *puVar8;
    *(undefined4 *)(iVar7 + 0x1c) = uVar2;
    *(undefined4 *)(iVar7 + 0x20) = uVar3;
    *(undefined4 *)(iVar7 + 0x24) = uVar4;
    uVar2 = puVar8[5];
    *(undefined4 *)(iVar7 + 0x28) = puVar8[4];
    *(undefined4 *)(iVar7 + 0x2c) = uVar2;
    puVar8[4] = 0;
    puVar8[5] = 0xf;
    *(undefined *)puVar8 = 0;
  }
  uStack_8._0_1_ = 0;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  puVar8 = (undefined4 *)FUN_01675640();
  uStack_8._0_1_ = 8;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar7 = FUN_005d15d0();
  if ((undefined4 *)(iVar7 + 0x18) != puVar8) {
    FUN_005507b0();
    uVar2 = puVar8[1];
    uVar3 = puVar8[2];
    uVar4 = puVar8[3];
    *(undefined4 *)(iVar7 + 0x18) = *puVar8;
    *(undefined4 *)(iVar7 + 0x1c) = uVar2;
    *(undefined4 *)(iVar7 + 0x20) = uVar3;
    *(undefined4 *)(iVar7 + 0x24) = uVar4;
    uVar2 = puVar8[5];
    *(undefined4 *)(iVar7 + 0x28) = puVar8[4];
    *(undefined4 *)(iVar7 + 0x2c) = uVar2;
    puVar8[4] = 0;
    puVar8[5] = 0xf;
    *(undefined *)puVar8 = 0;
  }
  uStack_8._0_1_ = 0;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  FUN_00a434b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  piVar9 = (int *)FUN_00a42940();
  iVar1 = piVar9[1];
  for (iVar7 = *piVar9; iVar7 != iVar1; iVar7 = iVar7 + 8) {
    FUN_005542c0();
    uStack_8._0_1_ = 0xb;
    FUN_00fd9780();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_00fd9780();
  }
  piVar10 = (int *)FUN_01675640();
  uStack_8._0_1_ = 0xc;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  iVar7 = FUN_005d15d0();
  piVar9 = (int *)(iVar7 + 0x18);
  if (piVar9 != piVar10) {
    if (0xf < *(uint *)(iVar7 + 0x2c)) {
      if ((0xfff < *(uint *)(iVar7 + 0x2c) + 1) && (0x1f < (*piVar9 - *(int *)(*piVar9 + -4)) - 4U))
      goto LAB_00a4badb;
      FUN_01674ea0();
    }
    *(undefined4 *)(iVar7 + 0x28) = 0;
    *(undefined4 *)(iVar7 + 0x2c) = 0xf;
    *(undefined *)piVar9 = 0;
    iVar1 = piVar10[1];
    iVar5 = piVar10[2];
    iVar6 = piVar10[3];
    *piVar9 = *piVar10;
    *(int *)(iVar7 + 0x1c) = iVar1;
    *(int *)(iVar7 + 0x20) = iVar5;
    *(int *)(iVar7 + 0x24) = iVar6;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(piVar10 + 4);
    piVar10[4] = 0;
    piVar10[5] = 0xf;
    *(undefined *)piVar10 = 0;
  }
  uStack_8._0_1_ = 10;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar10 = (int *)FUN_01675640();
  uStack_8._0_1_ = 0xe;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  iVar7 = FUN_005d15d0();
  piVar9 = (int *)(iVar7 + 0x18);
  if (piVar9 != piVar10) {
    if (0xf < *(uint *)(iVar7 + 0x2c)) {
      if ((0xfff < *(uint *)(iVar7 + 0x2c) + 1) && (0x1f < (*piVar9 - *(int *)(*piVar9 + -4)) - 4U))
      goto LAB_00a4badb;
      FUN_01674ea0();
    }
    *(undefined4 *)(iVar7 + 0x28) = 0;
    *(undefined4 *)(iVar7 + 0x2c) = 0xf;
    *(undefined *)piVar9 = 0;
    iVar1 = piVar10[1];
    iVar5 = piVar10[2];
    iVar6 = piVar10[3];
    *piVar9 = *piVar10;
    *(int *)(iVar7 + 0x1c) = iVar1;
    *(int *)(iVar7 + 0x20) = iVar5;
    *(int *)(iVar7 + 0x24) = iVar6;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(piVar10 + 4);
    piVar10[4] = 0;
    piVar10[5] = 0xf;
    *(undefined *)piVar10 = 0;
  }
  uStack_8._0_1_ = 10;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar10 = (int *)FUN_01675640();
  uStack_8._0_1_ = 0x10;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  iVar7 = FUN_005d15d0();
  piVar9 = (int *)(iVar7 + 0x18);
  if (piVar9 != piVar10) {
    if (0xf < *(uint *)(iVar7 + 0x2c)) {
      if ((0xfff < *(uint *)(iVar7 + 0x2c) + 1) && (0x1f < (*piVar9 - *(int *)(*piVar9 + -4)) - 4U))
      goto LAB_00a4badb;
      FUN_01674ea0();
    }
    *(undefined4 *)(iVar7 + 0x28) = 0;
    *(undefined4 *)(iVar7 + 0x2c) = 0xf;
    *(undefined *)piVar9 = 0;
    iVar1 = piVar10[1];
    iVar5 = piVar10[2];
    iVar6 = piVar10[3];
    *piVar9 = *piVar10;
    *(int *)(iVar7 + 0x1c) = iVar1;
    *(int *)(iVar7 + 0x20) = iVar5;
    *(int *)(iVar7 + 0x24) = iVar6;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(piVar10 + 4);
    piVar10[4] = 0;
    piVar10[5] = 0xf;
    *(undefined *)piVar10 = 0;
  }
  uStack_8._0_1_ = 10;
  uVar11 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_4c) {
    if ((0xfff < uStack_4c + 1) && (0x1f < (iStack_60 - *(int *)(iStack_60 + -4)) - 4U)) {
      uStack_8._0_1_ = uVar11;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  piVar10 = (int *)FUN_01675640();
  uStack_8._0_1_ = 0x12;
  FUN_005542c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  iVar7 = FUN_005d15d0();
  piVar9 = (int *)(iVar7 + 0x18);
  if (piVar9 != piVar10) {
    if (0xf < *(uint *)(iVar7 + 0x2c)) {
      if ((0xfff < *(uint *)(iVar7 + 0x2c) + 1) && (0x1f < (*piVar9 - *(int *)(*piVar9 + -4)) - 4U))
      {
LAB_00a4badb:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    *(undefined4 *)(iVar7 + 0x28) = 0;
    *(undefined4 *)(iVar7 + 0x2c) = 0xf;
    *(undefined *)piVar9 = 0;
    iVar1 = piVar10[1];
    iVar5 = piVar10[2];
    iVar6 = piVar10[3];
    *piVar9 = *piVar10;
    *(int *)(iVar7 + 0x1c) = iVar1;
    *(int *)(iVar7 + 0x20) = iVar5;
    *(int *)(iVar7 + 0x24) = iVar6;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(piVar10 + 4);
    piVar10[4] = 0;
    piVar10[5] = 0xf;
    *(undefined *)piVar10 = 0;
  }
  FUN_005507b0();
  uStack_8._0_1_ = 10;
  FUN_005507b0();
  FUN_005542c0();
  uStack_8._0_1_ = 0x14;
  FUN_008746b0();
  uStack_8._0_1_ = 10;
  FUN_005507b0();
  FUN_00874360();
  FUN_0060e660();
  uStack_8._0_1_ = 0x15;
  FUN_005542c0();
  uStack_8._0_1_ = 0x16;
  FUN_005542c0("localization",0xc);
  uStack_8._0_1_ = 0x17;
  uVar11 = 0;
  FUN_005542c0("client",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_0087a540(uVar11);
  FUN_005507b0();
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20631 ; VA 0x00a4bb30 ; FUN_00a4bb30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00a4bb30(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint **ppuVar7;
  code *pcVar8;
  int aiStack_50 [5];
  uint uStack_3c;
  uint auStack_38 [2];
  uint *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint *puStack_20;
  char cStack_1c;
  uint **ppuStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar8 = SetEvent_exref;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df633;
  pvStack_10 = ExceptionList;
  puStack_30 = _DAT_01943020;
  uStack_2c = _UNK_01943024;
  uStack_28 = _UNK_01943028;
  uStack_24 = _UNK_0194302c;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8) >> 2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00a49960();
    ppuVar7 = &puStack_30;
    ppuStack_18 = ppuVar7;
    do {
      puStack_14 = *ppuVar7;
      puStack_20 = (uint *)(param_1 + 0x20);
      cStack_1c = '\0';
      ppuStack_18 = ppuVar7;
      FUN_00587410();
      iVar3 = *(int *)(param_1 + 0xc) - *(int *)(param_1 + 8) >> 2;
      uStack_8 = 0;
      if (iVar3 == 0) {
        uStack_8 = 1;
        if (cStack_1c != '\0') {
          LOCK();
          uVar4 = *puStack_20;
          *puStack_20 = *puStack_20 + 0x80000000;
          UNLOCK();
          if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
            LOCK();
            uVar4 = *puStack_20;
            *puStack_20 = *puStack_20 | 0x40000000;
            UNLOCK();
            if ((uVar4 >> 0x1e & 1) == 0) {
              uVar2 = FUN_00554e40();
              (*pcVar8)(uVar2);
            }
          }
        }
        puStack_14 = (uint *)0x0;
      }
      else {
        piVar1 = (int *)(param_1 + 0x14);
        if (*(int *)(param_1 + 0x18) - *piVar1 >> 2 == iVar3) {
          FUN_0058c660();
        }
        else {
          FUN_005f86c0(iVar3,piVar1);
          FUN_0170cc70(*piVar1,*(int *)(param_1 + 8),*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8)
                      );
          FUN_0058c660();
          FUN_00a38120(*piVar1,*(int *)(param_1 + 0x18),*(int *)(param_1 + 0x18) - *piVar1 >> 2,
                       ppuStack_18);
        }
        uVar6 = *(int *)(param_1 + 0x18) - *piVar1 >> 2;
        uVar5 = (uVar6 * (int)puStack_14) / 100;
        uVar4 = uVar6 - 1;
        if (uVar5 < uVar6) {
          uVar4 = uVar5;
        }
        puStack_14 = (uint *)*(float *)(*piVar1 + uVar4 * 4);
        uStack_8 = 2;
        ppuVar7 = ppuStack_18;
        pcVar8 = SetEvent_exref;
        if (cStack_1c != '\0') {
          LOCK();
          uVar4 = *puStack_20;
          *puStack_20 = *puStack_20 + 0x80000000;
          UNLOCK();
          pcVar8 = SetEvent_exref;
          if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
            LOCK();
            uVar4 = *puStack_20;
            *puStack_20 = *puStack_20 | 0x40000000;
            UNLOCK();
            pcVar8 = SetEvent_exref;
            if ((uVar4 >> 0x1e & 1) == 0) {
              uVar2 = FUN_00554e40();
              pcVar8 = SetEvent_exref;
              SetEvent(uVar2);
              ppuVar7 = ppuStack_18;
            }
          }
        }
      }
      uStack_8 = 0xffffffff;
      uVar2 = FUN_01675640(aiStack_50,
                           "LocalizationServicePerformance_AttemptTranslationExecTime_P%d",*ppuVar7)
      ;
      uStack_8 = 3;
      FUN_00878cf0(uVar2,(double)(float)puStack_14,0);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_3c) {
        uVar4 = uStack_3c + 1;
        iVar3 = aiStack_50[0];
        if (0xfff < uVar4) {
          iVar3 = *(int *)(aiStack_50[0] + -4);
          uVar4 = uStack_3c + 0x24;
          if (0x1f < (aiStack_50[0] - iVar3) - 4U) goto LAB_00a4bff0;
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      ppuVar7 = ppuVar7 + 1;
      ppuStack_18 = ppuVar7;
    } while (ppuVar7 != &puStack_20);
  }
  if (*(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 2 != 0) {
    FUN_00a49960();
    ppuVar7 = &puStack_30;
    ppuStack_18 = ppuVar7;
    do {
      puStack_14 = *ppuVar7;
      puStack_20 = (uint *)(param_1 + 0x48);
      cStack_1c = '\0';
      ppuStack_18 = ppuVar7;
      FUN_00587410();
      iVar3 = *(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30) >> 2;
      uStack_8 = 4;
      if (iVar3 == 0) {
        uStack_8 = 5;
        if (cStack_1c != '\0') {
          LOCK();
          uVar4 = *puStack_20;
          *puStack_20 = *puStack_20 + 0x80000000;
          UNLOCK();
          if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
            LOCK();
            uVar4 = *puStack_20;
            *puStack_20 = *puStack_20 | 0x40000000;
            UNLOCK();
            if ((uVar4 >> 0x1e & 1) == 0) {
              uVar2 = FUN_00554e40();
              (*pcVar8)(uVar2);
            }
          }
        }
        puStack_14 = (uint *)0x0;
      }
      else {
        piVar1 = (int *)(param_1 + 0x3c);
        if (*(int *)(param_1 + 0x40) - *piVar1 >> 2 == iVar3) {
          FUN_0058c660();
        }
        else {
          FUN_005f86c0(iVar3,piVar1);
          FUN_0170cc70(*piVar1,*(int *)(param_1 + 0x30),
                       *(int *)(param_1 + 0x34) - *(int *)(param_1 + 0x30));
          FUN_0058c660();
          FUN_00a38120(*piVar1,*(int *)(param_1 + 0x40),*(int *)(param_1 + 0x40) - *piVar1 >> 2,
                       ppuStack_18);
        }
        uVar6 = *(int *)(param_1 + 0x40) - *piVar1 >> 2;
        uVar5 = (uVar6 * (int)puStack_14) / 100;
        uVar4 = uVar6 - 1;
        if (uVar5 < uVar6) {
          uVar4 = uVar5;
        }
        puStack_14 = (uint *)*(float *)(*piVar1 + uVar4 * 4);
        uStack_8 = 6;
        ppuVar7 = ppuStack_18;
        if (cStack_1c != '\0') {
          LOCK();
          uVar4 = *puStack_20;
          *puStack_20 = *puStack_20 + 0x80000000;
          UNLOCK();
          if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
            LOCK();
            uVar4 = *puStack_20;
            *puStack_20 = *puStack_20 | 0x40000000;
            UNLOCK();
            if ((uVar4 >> 0x1e & 1) == 0) {
              uVar2 = FUN_00554e40();
              SetEvent(uVar2);
              ppuVar7 = ppuStack_18;
            }
          }
        }
      }
      uStack_8 = 0xffffffff;
      uVar2 = FUN_01675640(aiStack_50,
                           "LocalizationServicePerformance_AttemptTranslationByExpressionMatchExecTime_P%d"
                           ,*ppuVar7);
      uStack_8 = 7;
      FUN_00878cf0(uVar2,(double)(float)puStack_14,0);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_3c) {
        uVar4 = uStack_3c + 1;
        iVar3 = aiStack_50[0];
        if (0xfff < uVar4) {
          iVar3 = *(int *)(aiStack_50[0] + -4);
          uVar4 = uStack_3c + 0x24;
          if (0x1f < (aiStack_50[0] - iVar3) - 4U) goto LAB_00a4bff0;
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      ppuVar7 = ppuVar7 + 1;
      ppuStack_18 = ppuVar7;
      pcVar8 = SetEvent_exref;
    } while (ppuVar7 != &puStack_20);
  }
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 8;
  FUN_0151fb00("AttemptTranslationByExpressionMatchMaxTime",(double)*(float *)(param_1 + 0x50));
  FUN_0151f950("MaxTimeTakenText",param_1 + 0x54);
  uVar2 = DAT_01ee7304;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("LocalizationServicePerformance",0x1e);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_01520d20(auStack_38,uVar2,0);
  if (0xf < uStack_24) {
    uVar5 = uStack_24 + 1;
    uVar4 = auStack_38[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_38[0] - 4);
      uVar5 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar4) - 4) {
LAB_00a4bff0:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20632 ; VA 0x00a4c000 ; FUN_00a4c000 */

void __fastcall FUN_00a4c000(int param_1)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  float10 fVar4;
  int aiStack_60 [5];
  uint uStack_4c;
  int aiStack_48 [5];
  uint uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017df658;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x94) != 0) {
    ExceptionList = &pvStack_10;
    if (DAT_01ee72f4 != 1000000) {
      ExceptionList = &pvStack_10;
      FUN_016799d0();
      fVar4 = (float10)FUN_01679fb0();
      dStack_18 = (double)(fVar4 * (float10)DAT_0193e468);
      if ((double)DAT_01ee72f4 <= dStack_18) goto LAB_00a4c17c;
    }
    iVar2 = param_1 + 0x1d0;
    if (*(int *)(param_1 + 0x1e0) == 0) {
      iVar2 = param_1 + 0x170;
    }
    FUN_0054ef60(iVar2);
    iVar2 = param_1 + 0x1b8;
    iStack_8 = 0;
    if (*(int *)(param_1 + 0x1c8) == 0) {
      iVar2 = param_1 + 0x140;
    }
    FUN_0054ef60(iVar2);
    iStack_8._0_1_ = 1;
    FUN_0054ef60(param_1 + 0x128);
    iStack_8._0_1_ = 2;
    FUN_00a4af60(aiStack_60,aiStack_30,aiStack_48);
    iStack_8._0_1_ = 1;
    uVar1 = (undefined)iStack_8;
    iStack_8._0_1_ = 1;
    if (0xf < uStack_4c) {
      uVar3 = uStack_4c + 1;
      iVar2 = aiStack_60[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_60[0] + -4);
        uVar3 = uStack_4c + 0x24;
        if (0x1f < (aiStack_60[0] - iVar2) - 4U) {
          iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      uVar3 = uStack_1c + 1;
      iVar2 = aiStack_30[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_30[0] + -4);
        uVar3 = uStack_1c + 0x24;
        if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    iStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar3 = uStack_34 + 1;
      iVar2 = aiStack_48[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_48[0] + -4);
        uVar3 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
LAB_00a4c17c:
  if (DAT_01d66078 != '\0') {
    FUN_00a4bb30();
  }
  if (DAT_01d66098 != '\0') {
    (**(code **)(**(int **)(param_1 + 0xac) + 8))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20633 ; VA 0x00a4c1d0 ; FUN_00a4c1d0 */

void __fastcall FUN_00a4c1d0(int param_1)

{
  FUN_008749d0(param_1 + 4,0);
  return;
}



/* FUNCTION 20634 ; VA 0x00a4c1e0 ; FUN_00a4c1e0 */

void __thiscall FUN_00a4c1e0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8af8;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(param_1 + 0x1d0);
  iStack_14 = param_1;
  if (*(int *)(param_1 + 0x1e0) == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 0x170);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(puVar1);
  }
  puVar10 = (undefined4 *)(param_1 + 0x170);
  uStack_8 = 0;
  puVar6 = (undefined4 *)FUN_00f854f0(apppuStack_2c,param_2);
  if (puVar1 != puVar6) {
    FUN_005507b0();
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *puVar1 = *puVar6;
    *(undefined4 *)(param_1 + 0x1d4) = uVar2;
    *(undefined4 *)(param_1 + 0x1d8) = uVar3;
    *(undefined4 *)(param_1 + 0x1dc) = uVar4;
    *(undefined8 *)(param_1 + 0x1e0) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  if (*(int *)(iStack_14 + 0x1e0) != 0) {
    puVar10 = puVar1;
  }
  FUN_0054ef60(puVar10);
  ppppuVar8 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar8 = (undefined4 ****)apppuStack_44[0];
  }
  ppppuVar7 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
  }
  cVar5 = FUN_0055c360(ppppuVar7,uStack_1c,ppppuVar8,uStack_34);
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  if (cVar5 == '\0') {
    FUN_00a44780(1);
  }
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_44[0][-1];
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20635 ; VA 0x00a4c380 ; FUN_00a4c380 */

void __thiscall FUN_00a4c380(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00f854f0(apppuStack_2c,param_2);
  uVar7 = uStack_18;
  ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
  ppppuVar5 = (undefined4 ****)(param_1 + 0x200);
  uStack_8 = 0;
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  ppppuVar2 = ppppuVar5;
  if (0xf < *(uint *)(param_1 + 0x214)) {
    ppppuVar2 = (undefined4 ****)*ppppuVar5;
  }
  cVar1 = FUN_0055c360(ppppuVar2,*(undefined4 *)(param_1 + 0x210),ppppuVar3,uStack_1c);
  if (cVar1 == '\0') {
    if (ppppuVar5 != apppuStack_2c) {
      ppppuVar3 = apppuStack_2c;
      if (0xf < uVar7) {
        ppppuVar3 = ppppuVar6;
      }
      FUN_005542c0(ppppuVar3,uStack_1c);
    }
    FUN_008a4940(&DAT_02126140);
    FUN_008a4940(&DAT_02126178);
    ppppuVar6 = (undefined4 ****)apppuStack_2c[0];
    uVar7 = uStack_18;
  }
  if (0xf < uVar7) {
    uVar4 = uVar7 + 1;
    ppppuVar3 = ppppuVar6;
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)ppppuVar6[-1];
      uVar4 = uVar7 + 0x24;
      if (0x1f < (uint)((int)ppppuVar6 + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20636 ; VA 0x00a4c470 ; FUN_00a4c470 */

void __thiscall FUN_00a4c470(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  uint uVar9;
  undefined4 ****ppppuVar10;
  int aiStack_44 [5];
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00f854f0(apppuStack_2c,param_2);
  ppppuVar10 = (undefined4 ****)apppuStack_2c[0];
  puVar1 = (undefined4 *)(param_1 + 0x1e8);
  ppppuVar7 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
  }
  uStack_8 = 0;
  puVar6 = puVar1;
  if (0xf < *(uint *)(param_1 + 0x1fc)) {
    puVar6 = (undefined4 *)*puVar1;
  }
  cVar5 = FUN_0055c360(puVar6,*(undefined4 *)(param_1 + 0x1f8),ppppuVar7,uStack_1c);
  if (cVar5 == '\0') {
    puVar6 = (undefined4 *)FUN_00f854f0(aiStack_44,apppuStack_2c);
    if (puVar1 != puVar6) {
      FUN_005507b0();
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      *puVar1 = *puVar6;
      *(undefined4 *)(param_1 + 0x1ec) = uVar2;
      *(undefined4 *)(param_1 + 0x1f0) = uVar3;
      *(undefined4 *)(param_1 + 500) = uVar4;
      *(undefined8 *)(param_1 + 0x1f8) = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
    }
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      iVar8 = aiStack_44[0];
      if (0xfff < uVar9) {
        iVar8 = *(int *)(aiStack_44[0] + -4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (aiStack_44[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar9);
    }
    FUN_008a4940(&DAT_021260d0);
    FUN_008a4940(&DAT_02126108);
    ppppuVar10 = (undefined4 ****)apppuStack_2c[0];
  }
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    ppppuVar7 = ppppuVar10;
    if (0xfff < uVar9) {
      ppppuVar7 = (undefined4 ****)ppppuVar10[-1];
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)ppppuVar10 + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20637 ; VA 0x00a4c5c0 ; FUN_00a4c5c0 */

void __thiscall FUN_00a4c5c0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8af8;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(param_1 + 0x1b8);
  iStack_14 = param_1;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 0x140);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(puVar1);
  }
  puVar10 = (undefined4 *)(param_1 + 0x140);
  uStack_8 = 0;
  puVar6 = (undefined4 *)FUN_00f854f0(apppuStack_2c,param_2);
  if (puVar1 != puVar6) {
    FUN_005507b0();
    uVar2 = puVar6[1];
    uVar3 = puVar6[2];
    uVar4 = puVar6[3];
    *puVar1 = *puVar6;
    *(undefined4 *)(param_1 + 0x1bc) = uVar2;
    *(undefined4 *)(param_1 + 0x1c0) = uVar3;
    *(undefined4 *)(param_1 + 0x1c4) = uVar4;
    *(undefined8 *)(param_1 + 0x1c8) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  if (*(int *)(iStack_14 + 0x1c8) != 0) {
    puVar10 = puVar1;
  }
  FUN_0054ef60(puVar10);
  ppppuVar8 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar8 = (undefined4 ****)apppuStack_44[0];
  }
  ppppuVar7 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
  }
  cVar5 = FUN_0055c360(ppppuVar7,uStack_1c,ppppuVar8,uStack_34);
  if (0xf < uStack_18) {
    uVar9 = uStack_18 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar9 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  if (cVar5 == '\0') {
    FUN_00a44780(1);
    FUN_008a4940(&DAT_02125cd0);
  }
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_44[0][-1];
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20638 ; VA 0x00a4c770 ; FUN_00a4c770 */

void __thiscall FUN_00a4c770(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int ****ppppiVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  ulonglong uVar5;
  char cVar6;
  undefined4 *puVar7;
  int *****pppppiVar8;
  int *****pppppiVar9;
  undefined4 *****pppppuVar10;
  int *piVar11;
  int ****ppppiVar12;
  uint uVar13;
  undefined4 *puVar14;
  uint uVar15;
  uint in_stack_0000001c;
  int ***pppiStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  undefined8 uStack_84;
  uint uStack_7c;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 ****appppuStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  int ****appppiStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined4 ****appppuStack_34 [4];
  int iStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df6a1;
  pvStack_10 = ExceptionList;
  uStack_1c = (ulonglong)(uint)uStack_1c;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee7309 != '\0') {
    puVar7 = &param_3;
    if (0xf < in_stack_0000001c) {
      puVar7 = param_3;
    }
    puVar14 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar14 = (undefined4 *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ee7309,"setGameLocaleId: %s; callsite: %s",puVar14,puVar7);
  }
  FUN_00a43410(appppuStack_64);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_2);
  FUN_00f85650(appppiStack_4c);
  pppppiVar9 = (int *****)(param_1 + 0x170);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (pppppiVar9 != appppiStack_4c) {
    pppppiVar8 = appppiStack_4c;
    if (0xf < uStack_38) {
      pppppiVar8 = (int *****)appppiStack_4c[0];
    }
    FUN_005542c0(pppppiVar8,iStack_3c);
  }
  if (iStack_24 != 0) {
    if ((DAT_01d66088 != '\0') && ((undefined4 *****)(param_1 + 0x1a0) != appppuStack_34)) {
      pppppuVar10 = appppuStack_34;
      if (0xf < uStack_20) {
        pppppuVar10 = (undefined4 *****)appppuStack_34[0];
      }
      FUN_005542c0(pppppuVar10,iStack_24);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_6c = 0;
    uStack_68 = 0xf;
    uStack_7c = uStack_7c & 0xffffff00;
    uStack_1c = CONCAT44(1,(uint)uStack_1c);
    FUN_0058a190(iStack_3c + 1);
    pppppiVar9 = appppiStack_4c;
    if (0xf < uStack_38) {
      pppppiVar9 = (int *****)appppiStack_4c[0];
    }
    FUN_00554150(pppppiVar9,iStack_3c);
    FUN_00592760(0x2d);
    pppppuVar10 = appppuStack_34;
    if (0xf < uStack_20) {
      pppppuVar10 = (undefined4 *****)appppuStack_34[0];
    }
    piVar11 = (int *)FUN_00554150(pppppuVar10,iStack_24);
    pppppiVar9 = (int *****)(param_1 + 0x188);
    ppppiVar1 = (int ****)*piVar11;
    iVar2 = piVar11[1];
    iVar3 = piVar11[2];
    iVar4 = piVar11[3];
    uStack_1c = *(ulonglong *)(piVar11 + 4);
    piVar11[4] = 0;
    piVar11[5] = 0xf;
    *(undefined *)piVar11 = 0;
    pppiStack_94 = (int ***)ppppiVar1;
    iStack_90 = iVar2;
    iStack_8c = iVar3;
    iStack_88 = iVar4;
    uStack_84 = uStack_1c;
    if (pppppiVar9 == (int *****)&pppiStack_94) {
      uStack_84._4_4_ = (uint)(uStack_1c >> 0x20);
      uVar5 = uStack_1c;
      if (0xf < uStack_84._4_4_) {
        uVar13 = uStack_84._4_4_ + 1;
        ppppiVar12 = ppppiVar1;
        if (0xfff < uVar13) {
          ppppiVar12 = (int ****)ppppiVar1[-1];
          uVar13 = uStack_84._4_4_ + 0x24;
          if (0x1f < (uint)((int)ppppiVar1 + (-4 - (int)ppppiVar12))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppiVar12,uVar13);
        uVar5 = uStack_84;
      }
    }
    else {
      FUN_005507b0();
      *pppppiVar9 = ppppiVar1;
      *(int *)(param_1 + 0x18c) = iVar2;
      *(int *)(param_1 + 400) = iVar3;
      *(int *)(param_1 + 0x194) = iVar4;
      *(ulonglong *)(param_1 + 0x198) = uStack_1c;
      uVar5 = uStack_84;
    }
    uStack_84 = uVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_68) {
      uVar15 = uStack_68 + 1;
      uVar13 = uStack_7c;
      if (0xfff < uVar15) {
        uVar13 = *(uint *)(uStack_7c - 4);
        uVar15 = uStack_68 + 0x24;
        if (0x1f < (uStack_7c - uVar13) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar13,uVar15);
    }
  }
  pppppiVar8 = pppppiVar9 + 4;
  pppppuVar10 = appppuStack_64;
  if (0xf < uStack_50) {
    pppppuVar10 = (undefined4 *****)appppuStack_64[0];
  }
  if ((int ****)0xf < pppppiVar9[5]) {
    pppppiVar9 = (int *****)*pppppiVar9;
  }
  cVar6 = FUN_0055c360(pppppiVar9,*pppppiVar8,pppppuVar10,uStack_54);
  if (cVar6 == '\0') {
    FUN_00a44780(1);
  }
  FUN_005509f0();
  if (0xf < uStack_50) {
    uVar13 = uStack_50 + 1;
    pppppuVar10 = (undefined4 *****)appppuStack_64[0];
    if (0xfff < uVar13) {
      pppppuVar10 = (undefined4 *****)appppuStack_64[0][-1];
      uVar13 = uStack_50 + 0x24;
      if (0x1f < (uint)((int)appppuStack_64[0] + (-4 - (int)pppppuVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar10,uVar13);
  }
  if (0xf < in_stack_0000001c) {
    uVar13 = in_stack_0000001c + 1;
    puVar7 = param_3;
    if (0xfff < uVar13) {
      puVar7 = (undefined4 *)param_3[-1];
      uVar13 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar7,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20639 ; VA 0x00a4ca50 ; FUN_00a4ca50 */

void __thiscall
FUN_00a4ca50(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint param_7)

{
  int iVar1;
  uint uVar2;
  
  if ((int *)(param_1 + 0x218) != &param_2) {
    FUN_005507b0();
    *(int *)(param_1 + 0x218) = param_2;
    *(undefined4 *)(param_1 + 0x21c) = param_3;
    *(undefined4 *)(param_1 + 0x220) = param_4;
    *(undefined4 *)(param_1 + 0x224) = param_5;
    *(ulonglong *)(param_1 + 0x228) = CONCAT44(param_7,param_6);
    return;
  }
  if (0xf < param_7) {
    uVar2 = param_7 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = param_7 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 20640 ; VA 0x00a4cac0 ; FUN_00a4cac0 */

void __thiscall
FUN_00a4cac0(int param_1,uint param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017df6d0;
  pvStack_10 = ExceptionList;
  iStack_8._0_1_ = 0;
  iStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (((iVar2 == 0) || (cVar1 = FUN_008ff0d0(), cVar1 == '\0')) ||
     (cVar1 = FUN_008ff0a0(), cVar1 != '\0')) {
    uStack_18._0_4_ = 0;
    uStack_18._4_4_ = 0xf;
    uStack_28 = uStack_28 & 0xffffff00;
    FUN_005542c0("SetGetCountryRegionForPlayerDelegateError_NotInStudioPlayMode",0x3d);
    iStack_8._0_1_ = 5;
    FUN_008783f0(&uStack_28,1,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_18._4_4_) {
      uVar4 = uStack_18._4_4_ + 1;
      uVar3 = uStack_28;
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(uStack_28 - 4);
        uVar4 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uStack_28 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uStack_18 = 0xf00000000;
    uStack_28 = uStack_28 & 0xffffff00;
  }
  else {
    auStack_30[0] = 0;
    if (param_2 != 0) {
      auStack_30[0] = param_2;
      if ((param_2 & 1) == 0) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_28,0);
      }
      else {
        uStack_28 = param_4;
        uStack_24 = param_5;
        uStack_20 = param_6;
        uStack_1c = param_7;
        uStack_18 = param_8;
      }
    }
    if ((uint *)(param_1 + 0x60) != auStack_30) {
      auStack_50[0] = 0;
      iStack_8._0_1_ = 2;
      FUN_005880d0(auStack_30);
      FUN_005880d0((uint *)(param_1 + 0x60));
      FUN_005880d0(auStack_50);
      iStack_8._0_1_ = 3;
      if (((auStack_50[0] != 0) && ((auStack_50[0] & 1) == 0)) &&
         (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
      }
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
    }
  }
  iStack_8 = 6;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20641 ; VA 0x00a4cca0 ; FUN_00a4cca0 */

void FUN_00a4cca0(char param_1)

{
  char cVar1;
  
  cVar1 = FUN_00fce1e0();
  if (cVar1 != param_1) {
    FUN_008a4940(&DAT_02125ff0);
  }
  return;
}



/* FUNCTION 20642 ; VA 0x00a4ccd0 ; FUN_00a4ccd0 */

void __thiscall FUN_00a4ccd0(int param_1,int *param_2)

{
  uint *puVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  uint *puVar10;
  int iVar11;
  int aiStack_50 [5];
  uint uStack_3c;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df700;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee7309 != '\0') {
    piVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      piVar3 = (int *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ee7309,"setLocaleManifest: %s",piVar3);
  }
  piVar3 = (int *)(param_1 + 0x26c);
  piVar6 = piVar3;
  if (0xf < *(uint *)(param_1 + 0x280)) {
    piVar6 = (int *)*piVar3;
  }
  iVar7 = param_2[4];
  piVar8 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar8 = (int *)*param_2;
  }
  cVar2 = FUN_0055c360(piVar8,iVar7,piVar6,*(undefined4 *)(param_1 + 0x27c));
  if (cVar2 == '\0') {
    if (DAT_01d660d0 != '\0') {
      if (piVar3 != param_2) {
        if (0xf < (uint)param_2[5]) {
          param_2 = (int *)*param_2;
        }
        FUN_005542c0(param_2,iVar7);
      }
      FUN_008a4940(&DAT_02126060);
      ExceptionList = pvStack_10;
      return;
    }
    if (piVar3 != param_2) {
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,iVar7);
    }
    FUN_00a48fe0();
    FUN_00a40170();
    FUN_008a4940(&DAT_02126060);
    *(undefined *)(param_1 + 0x250) = 1;
    if (*(int *)(param_1 + 0x25c) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar4 = *(undefined4 **)(*(int *)(param_1 + 0x268) + *(int *)(param_1 + 600) * 4);
    }
    for (; puVar4 != (undefined4 *)0x0; puVar4 = (undefined4 *)*puVar4) {
      cVar2 = FUN_00a45700(puVar4 + 2);
      if (cVar2 == '\0') {
        puVar1 = (uint *)puVar4[9];
        for (puVar10 = (uint *)puVar4[8]; puVar10 != puVar1; puVar10 = puVar10 + 0x14) {
          if (puVar10[0x11] != 0) {
            LOCK();
            piVar3 = (int *)(puVar10[0x11] + 8);
            *piVar3 = *piVar3 + 1;
            UNLOCK();
          }
          FUN_00a44420(&uStack_20,puVar10[0x10],puVar10[0x11],puVar4 + 2);
          piVar3 = piStack_1c;
          uVar5 = uStack_20;
          uStack_8 = 0;
          if (*puVar10 == 0) {
            uVar5 = FUN_0054fda0();
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
            FUN_0054e5e0(uVar5);
          }
          uStack_20 = 0;
          piStack_1c = (int *)0x0;
          (**(code **)((*puVar10 & 0xfffffffe) + 4))(puVar10 + 2,uVar5,piVar3);
          piVar3 = piStack_1c;
          uStack_8 = 0xffffffff;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar7 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              piVar6 = piVar3 + 2;
              iVar7 = *piVar6 + -1;
              *piVar6 = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
        iVar7 = puVar4[9];
        iVar11 = puVar4[8];
        if (iVar11 != iVar7) {
          do {
            FUN_005e6080();
            iVar11 = iVar11 + 0x50;
          } while (iVar11 != iVar7);
          iVar11 = puVar4[8];
        }
        puVar4[9] = iVar11;
        param_1 = iStack_14;
      }
      else {
        FUN_00a41980(puVar4 + 2,param_1 + 0x1a0,0);
      }
    }
    FUN_00a42010(0);
    if (DAT_01ee7309 != '\0') {
      puVar4 = (undefined4 *)FUN_00a434b0(aiStack_38);
      uStack_8 = 2;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_01677520(DAT_01ee7309,"get localeInternal from player: %s",puVar4);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_24) {
        uVar9 = uStack_24 + 1;
        iVar7 = aiStack_38[0];
        if (0xfff < uVar9) {
          iVar7 = *(int *)(aiStack_38[0] + -4);
          uVar9 = uStack_24 + 0x24;
          if (0x1f < (aiStack_38[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar9);
      }
    }
    uVar5 = FUN_00a434b0(aiStack_50);
    uStack_8 = 3;
    FUN_00a41980(uVar5,param_1 + 0x1a0,0);
    if (0xf < uStack_3c) {
      uVar9 = uStack_3c + 1;
      iVar7 = aiStack_50[0];
      if (0xfff < uVar9) {
        iVar7 = *(int *)(aiStack_50[0] + -4);
        uVar9 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar9);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20643 ; VA 0x00a4d020 ; FUN_00a4d020 */

void FUN_00a4d020(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Untracked",9);
  uStack_8 = 0;
  FUN_00a4d0c0(param_1,auStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20644 ; VA 0x00a4d0c0 ; FUN_00a4d0c0 */

void __thiscall FUN_00a4d0c0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  undefined4 ****ppppuVar8;
  uint uVar9;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  iVar6 = param_1 + 0x1b8;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    iVar6 = param_1 + 0x140;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(iVar6);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_00f854f0(apppuStack_28,param_2);
  if ((undefined4 *)(param_1 + 0x140) != puVar5) {
    FUN_005507b0();
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)(param_1 + 0x140) = *puVar5;
    *(undefined4 *)(param_1 + 0x144) = uVar1;
    *(undefined4 *)(param_1 + 0x148) = uVar2;
    *(undefined4 *)(param_1 + 0x14c) = uVar3;
    *(undefined8 *)(param_1 + 0x150) = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
  }
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_28[0][-1];
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  iVar6 = param_1 + 0x1b8;
  if (*(int *)(param_1 + 0x1c8) == 0) {
    iVar6 = param_1 + 0x140;
  }
  FUN_0054ef60(iVar6);
  ppppuVar8 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar8 = (undefined4 ****)apppuStack_40[0];
  }
  ppppuVar7 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar7 = (undefined4 ****)apppuStack_28[0];
  }
  cVar4 = FUN_0055c360(ppppuVar7,uStack_18,ppppuVar8,uStack_30);
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_28[0][-1];
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  if (cVar4 == '\0') {
    FUN_00a44780(1);
    FUN_008a4940(&DAT_02125cd0);
  }
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    ppppuVar8 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar9) {
      ppppuVar8 = (undefined4 ****)apppuStack_40[0][-1];
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar8,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20645 ; VA 0x00a4d270 ; FUN_00a4d270 */

void __thiscall FUN_00a4d270(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x2c2) != param_2) {
    *(char *)(param_1 + 0x2c2) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 20646 ; VA 0x00a4d2a0 ; FUN_00a4d2a0 */

void __thiscall FUN_00a4d2a0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)FUN_00f854f0(aiStack_1c,param_2);
  if ((undefined4 *)(param_1 + 0x128) != puVar4) {
    FUN_005507b0();
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)(param_1 + 0x128) = *puVar4;
    *(undefined4 *)(param_1 + 300) = uVar1;
    *(undefined4 *)(param_1 + 0x130) = uVar2;
    *(undefined4 *)(param_1 + 0x134) = uVar3;
    *(undefined8 *)(param_1 + 0x138) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return;
}



/* FUNCTION 20647 ; VA 0x00a4d330 ; FUN_00a4d330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a4d330(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df726;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee7874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee7874);
    if (DAT_01ee7874 == -1) {
      uStack_8 = 0;
      FUN_009ca470("Language");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee7810 = RBX::Reflection::EnumDesc<enum_RBX::LocalizationService::Language>::vftable;
      FUN_009caf20(&DAT_01d660b0,1);
      FUN_016f3654(&LAB_01889c90);
      FUN_016f37bf(&DAT_01ee7874);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee7810;
}



/* FUNCTION 20648 ; VA 0x00a4d3e0 ; FUN_00a4d3e0 */

int FUN_00a4d3e0(uint *param_1,int *param_2,int param_3,int *param_4,int *param_5,int *param_6,
                int param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_6c [24];
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  uint auStack_3c [3];
  undefined4 uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df77b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_44 = 0xf00000000;
  uStack_54 = uStack_54 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_24);
  uStack_8._0_1_ = 4;
  if (iStack_24 == 0) {
    iStack_2c = iStack_24;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_005542c0("LocalizationServiceInvalidHandle",0x20);
    uStack_8._0_1_ = 5;
    iVar3 = FUN_008783f0(auStack_3c,1,0);
    if (0xf < uStack_28) {
      uVar6 = uStack_28 + 1;
      uVar5 = auStack_3c[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_3c[0] - 4);
        uVar6 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar3 = FUN_01674ea0(uVar5,uVar6);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (uStack_44._4_4_ < 0x10) goto LAB_00a4d73b;
    uVar6 = uStack_44._4_4_ + 1;
    uVar5 = uStack_54;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_54 - 4);
      uVar6 = uStack_44._4_4_ + 0x24;
      if (0x1f < (uStack_54 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    if (param_3 == 0) {
      if (param_5 == (int *)0x0) {
        iVar3 = FUN_005542c0("sourceLocaleAssetResponseHandler missing response/exception!",0x3c);
      }
      else {
        uVar4 = (**(code **)(*param_5 + 4))();
        puStack_14 = (uint *)FUN_01675640(auStack_6c,
                                          "sourceLocaleAssetResponseHandler exception: %s, retries: %d"
                                          ,uVar4,param_7);
        if (&uStack_54 != puStack_14) {
          FUN_005507b0();
          uStack_54 = *puStack_14;
          uStack_50 = puStack_14[1];
          uStack_4c = puStack_14[2];
          uStack_48 = puStack_14[3];
          uStack_44 = *(undefined8 *)(puStack_14 + 4);
          puStack_14[4] = 0;
          puStack_14[5] = 0xf;
          *(undefined *)puStack_14 = 0;
        }
        FUN_005507b0();
        iVar3 = param_7;
        if ((param_7 < DAT_01d65fe0) &&
           (iVar3 = FUN_008f7870(iStack_24), iStack_18 = iVar3, iVar3 != 0)) {
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          puStack_14 = param_1;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          uVar4 = 0;
          if (param_2 != (int *)0x0) {
            LOCK();
            param_2[2] = param_2[2] + 1;
            UNLOCK();
          }
          FUN_00a385d0(param_1,param_2,param_7);
          if (param_2 != (int *)0x0) {
            LOCK();
            iVar3 = param_2[2] + -1;
            param_2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*param_2 + 4))(uVar4);
            }
            LOCK();
            iVar3 = param_2[2] + -1;
            param_2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*param_2 + 4))();
            }
          }
          iVar3 = FUN_0090ca30(uVar4);
        }
      }
    }
    else {
      FUN_00a40170();
      FUN_0054ef60(param_3);
      uStack_8._0_1_ = 6;
      uStack_30 = 0;
      iStack_2c = 0;
      uStack_28 = 0;
      FUN_00604490(auStack_6c,&uStack_54,iStack_18);
      uStack_8._0_1_ = 7;
      FUN_00fda0d0(&uStack_30);
      FUN_00577a40();
      uStack_8._0_1_ = 4;
      iVar3 = FUN_016f32d1(auStack_6c,0x18,1,FUN_005507b0);
      *(undefined *)(iStack_24 + 0x2c1) = 1;
      if ((*(char *)(iStack_24 + 0x2c0) != '\0') && (iVar3 = FUN_00fce1e0(), (char)iVar3 != '\x01'))
      {
        iVar3 = FUN_008a4940(&DAT_02125ff0);
      }
    }
    if ((int)uStack_44 != 0) {
      iVar3 = FUN_00a4acd0(&uStack_54);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piStack_20 + 2;
        iVar2 = *piVar1;
        iVar3 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar3 = (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (uStack_44._4_4_ < 0x10) goto LAB_00a4d73b;
    uVar6 = uStack_44._4_4_ + 1;
    uVar5 = uStack_54;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(uStack_54 - 4);
      uVar6 = uStack_44._4_4_ + 0x24;
      if (0x1f < (uStack_54 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  iVar3 = FUN_01674ea0(uVar5,uVar6);
LAB_00a4d73b:
  uStack_54 = uStack_54 & 0xffffff00;
  uStack_44 = 0xf00000000;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20649 ; VA 0x00a4d7d0 ; FUN_00a4d7d0 */

void FUN_00a4d7d0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 *puVar1;
  undefined auStack_190 [8];
  uint uStack_188;
  uint uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined auStack_174 [20];
  undefined4 uStack_160;
  undefined1 **ppuStack_15c;
  undefined4 *puStack_158;
  undefined4 uStack_154;
  undefined4 uStack_13c;
  undefined1 **ppuStack_138;
  undefined1 *puStack_134;
  undefined *puStack_130;
  undefined1 *apuStack_50 [5];
  uint uStack_3c;
  undefined1 *apuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df7be;
  pvStack_10 = ExceptionList;
  puStack_130 = (undefined *)param_2;
  puStack_134 = (undefined1 *)param_1;
  if (DAT_01d5a4c0 == '\0') {
    ppuStack_138 = apuStack_38;
    uStack_13c = 0xa4d941;
    ExceptionList = &pvStack_10;
    FUN_00f57020();
    puStack_130 = (undefined *)0x0;
    puStack_134 = (undefined1 *)0x0;
    ppuStack_138 = apuStack_38;
    uStack_8 = 3;
    uStack_13c = 0xa4d95e;
    FUN_014cc090();
    uStack_184 = (uint)DAT_01ee73a1;
    puStack_130 = (undefined *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_154 = 0;
    uStack_178 = param_3;
    uStack_17c = param_2;
    uStack_180 = param_1;
    uStack_188 = (uint)DAT_01ee730a;
    FUN_0060e0c0(auStack_190,uStack_18);
    FUN_00a39af0(auStack_174,FUN_00a3f190);
    uStack_178 = 0xa4d9ad;
    FUN_00a36af0();
    uStack_154 = 0xa4d9b8;
    FUN_014ccc70();
    puStack_130 = (undefined *)0xa4d9c3;
    FUN_0056db40();
    if (uStack_24 < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    puStack_130 = (undefined *)(uStack_24 + 1);
    puVar1 = apuStack_38[0];
    if (0xfff < puStack_130) {
      puVar1 = *(undefined1 **)(apuStack_38[0] + -4);
      puStack_130 = (undefined *)(uStack_24 + 0x24);
      if ((undefined1 *)0x1f < apuStack_38[0] + (-4 - (int)puVar1)) {
                    /* WARNING: Subroutine does not return */
        puStack_130 = &UNK_00a4da15;
        FUN_017167a3();
      }
    }
  }
  else {
    ppuStack_138 = apuStack_50;
    uStack_13c = 0xa4d811;
    ExceptionList = &pvStack_10;
    FUN_00f56da0();
    puStack_130 = (undefined *)0x0;
    puStack_134 = (undefined1 *)0x0;
    ppuStack_138 = apuStack_50;
    uStack_8 = 0;
    uStack_13c = 0xa4d82e;
    FUN_014cc090();
    uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01ee73a1);
    puStack_130 = (undefined *)0x0;
    puStack_134 = &DAT_018bc9b8;
    uStack_8._0_1_ = 1;
    uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee730a);
    uStack_28 = 0;
    uStack_24 = 0xf;
    apuStack_38[0] = (undefined1 *)((uint)apuStack_38[0] & 0xffffff00);
    ppuStack_138 = (undefined1 **)0xa4d867;
    FUN_005542c0();
    puStack_130 = (undefined *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_154 = 0;
    uStack_178 = param_3;
    uStack_17c = param_2;
    uStack_180 = param_1;
    uStack_184 = uStack_1c;
    uStack_188 = uStack_20;
    FUN_0060e0c0(auStack_190,uStack_18);
    FUN_00a39af0(auStack_174,FUN_00a3f190);
    uStack_178 = 0xa4d8ac;
    FUN_00a36af0();
    uStack_154 = 0;
    puStack_158 = &DAT_01d79f68;
    ppuStack_15c = apuStack_38;
    uStack_160 = 0xa4d8c2;
    FUN_014cd990();
    if (0xf < uStack_24) {
      puStack_130 = (undefined *)(uStack_24 + 1);
      puVar1 = apuStack_38[0];
      if (0xfff < puStack_130) {
        puVar1 = *(undefined1 **)(apuStack_38[0] + -4);
        puStack_130 = (undefined *)(uStack_24 + 0x24);
        if ((undefined1 *)0x1f < apuStack_38[0] + (-4 - (int)puVar1)) {
                    /* WARNING: Subroutine does not return */
          puStack_130 = (undefined *)0xa4da0b;
          FUN_017167a3();
        }
      }
      ppuStack_138 = (undefined1 **)0xa4d8f3;
      puStack_134 = puVar1;
      FUN_01674ea0();
    }
    puStack_130 = (undefined *)0xa4d901;
    FUN_0056db40();
    if (uStack_3c < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    puStack_130 = (undefined *)(uStack_3c + 1);
    puVar1 = apuStack_50[0];
    if (0xfff < puStack_130) {
      puVar1 = *(undefined1 **)(apuStack_50[0] + -4);
      puStack_130 = (undefined *)(uStack_3c + 0x24);
      if ((undefined1 *)0x1f < apuStack_50[0] + (-4 - (int)puVar1)) {
                    /* WARNING: Subroutine does not return */
        puStack_130 = (undefined *)0xa4da10;
        FUN_017167a3();
      }
    }
  }
  ppuStack_138 = (undefined1 **)0xa4d9f0;
  puStack_134 = puVar1;
  FUN_01674ea0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20650 ; VA 0x00a4da20 ; FUN_00a4da20 */

void __fastcall FUN_00a4da20(int param_1)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  if (DAT_01d66070 == '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00a4db60(0);
    if (cVar1 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    *(int *)(*(int *)(param_1 + 0x120) + 0x88) = param_1;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
    pcVar3 = "Text scraper failed to start - Missing DataModel.";
LAB_00a4da60:
    FUN_0086f2f0(2,pcVar3);
  }
  else {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = 0;
    cStack_11 = FUN_00fcfc30(*(undefined4 *)(iVar2 + 0x4a0),param_1,auStack_2c);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    cVar1 = FUN_008ff0d0();
    if (cVar1 != '\0') {
      if (cStack_11 == '\0') {
        pcVar3 = "Text scraper failed to start - startService failed.";
        goto LAB_00a4da60;
      }
      FUN_0086f2f0(1,"Text scraper successfully started.");
    }
    if ((cStack_11 != '\0') && (iVar2 = FUN_008fbd40(), iVar2 == 0)) {
      *(int *)(*(int *)(param_1 + 0x120) + 0x88) = param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20651 ; VA 0x00a4db60 ; FUN_00a4db60 */

char __thiscall FUN_00a4db60(int param_1,char param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  char cStack00000007;
  undefined4 uVar4;
  char *pcVar5;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if ((iVar2 == 0) || ((*(int *)(iVar2 + 0x4a0) == 1 && (0x1cd < DAT_01ee7300)))) {
    ExceptionList = pvStack_10;
    return '\0';
  }
  if (param_2 != '\0') {
    if (*(int *)(iVar2 + 0x4a0) == 1) {
      piVar3 = (int *)FUN_00564080();
      if (*piVar3 == 0) {
        ExceptionList = pvStack_10;
        return '\0';
      }
      iVar1 = *(int *)(*piVar3 + 0xf4);
      if (iVar1 == 0) {
        ExceptionList = pvStack_10;
        return '\0';
      }
      if (*(int *)(iVar1 + 0x454) < DAT_01d65fe8) {
        ExceptionList = pvStack_10;
        return '\0';
      }
    }
    *(undefined *)(param_1 + 0x2c0) = 1;
    if (*(char *)(param_1 + 0x2c1) == '\0') {
      ExceptionList = pvStack_10;
      return '\0';
    }
  }
  if (DAT_01d660a0 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = 0;
    cStack00000007 = FUN_00fcfc30(*(undefined4 *)(iVar2 + 0x4a0),param_1,auStack_28);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
  }
  else {
    cStack00000007 = FUN_00fcfc30(*(undefined4 *)(iVar2 + 0x4a0),param_1,param_1 + 0x218);
  }
  if (*(int *)(iVar2 + 0x4a0) == 3) {
    if (cStack00000007 == '\0') {
      pcVar5 = "Text scraper failed to start.";
      uVar4 = 2;
    }
    else {
      pcVar5 = "Text scraper successfully started.";
      uVar4 = 1;
    }
    FUN_0086f2f0(uVar4,pcVar5);
  }
  FUN_00a44780(0);
  ExceptionList = pvStack_10;
  return cStack00000007;
}



/* FUNCTION 20652 ; VA 0x00a4dce0 ; FUN_00a4dce0 */

void __thiscall FUN_00a4dce0(int param_1,int *param_2,char param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  if (param_2 == (int *)0x0) {
    return;
  }
  iVar1 = param_2[3];
  iVar2 = FUN_00d59db0();
  if ((uint)*(ushort *)(iVar2 + 0x1da) <
      (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
    return;
  }
  piVar3 = (int *)(**(code **)(*param_2 + 0xfc))();
  if (piVar3 == (int *)0x0) {
    return;
  }
  if (*piVar3 == 0) {
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  }
  else if (*piVar3 != 1) goto LAB_00a4dd3d;
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
  if (param_3 != '\0') {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
  }
LAB_00a4dd3d:
  *piVar3 = 2;
  return;
}



/* FUNCTION 20653 ; VA 0x00a4dd50 ; FUN_00a4dd50 */

undefined4 FUN_00a4dd50(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00a4dd70(param_1,param_2,param_3);
  return param_1;
}



/* FUNCTION 20654 ; VA 0x00a4dd70 ; FUN_00a4dd70 */

undefined4 * FUN_00a4dd70(undefined4 *param_1,int *param_2,undefined4 param_3)

{
  byte *pbVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 ***pppuVar5;
  undefined uVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  undefined4 ****ppppuVar10;
  undefined8 uVar11;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined uStack_84;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined4 ***pppuStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df818;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_54 = 0xf00000000;
  uStack_64 = uStack_64 & 0xffffff00;
  uStack_8 = 0;
  iVar2 = *param_2;
  if (iVar2 == 0) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Context must be an Instance.");
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_24._0_4_ = 0;
  uStack_24._4_4_ = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  uStack_18 = 2;
  ExceptionList = &pvStack_10;
  FUN_00a4a990(iVar2,0,&uStack_34);
  FUN_005507b0();
  uStack_8._0_1_ = 0;
  uVar6 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  uStack_64 = uStack_34;
  uStack_60 = uStack_30;
  uStack_5c = uStack_2c;
  uStack_58 = uStack_28;
  uStack_54 = CONCAT44(uStack_24._4_4_,(undefined4)uStack_24);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee73b0) {
    uStack_8._0_1_ = uVar6;
    FUN_016f3809(&DAT_01ee73b0);
    if (DAT_01ee73b0 == -1) {
      uStack_8._0_1_ = 2;
      uVar11 = FUN_0152dab0(&DAT_018fdbdc,"LocalizationService::attemptTranslation",0xffffffff);
      DAT_01ee73ac = (undefined4)((ulonglong)uVar11 >> 0x20);
      DAT_01ee73a8 = (undefined4)uVar11;
      uStack_8._0_1_ = 0;
      FUN_016f37bf(&DAT_01ee73b0);
    }
  }
  uVar4 = DAT_01ee73ac;
  uStack_14 = DAT_01ee73a8;
  uStack_2c = DAT_01ee73a8;
  uStack_28 = DAT_01ee73ac;
  uStack_24 = FUN_0152d930(DAT_01ee73a8,DAT_01ee73ac);
  uStack_8._0_1_ = 3;
  iVar8 = FUN_009171d0(iVar2);
  uStack_8c = 0;
  uStack_88 = 0;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  cVar7 = (**(code **)(*piStack_1c + 0xa4))(&uStack_64,param_3,&pppuStack_4c,&uStack_8c);
  if (cVar7 != '\0') {
    if ((uStack_8c._1_1_ != '\0') && (iVar8 != 0)) {
      piStack_1c = (int *)0x811c9dc5;
      ppppuVar10 = &pppuStack_4c;
      if (0xf < uStack_38) {
        ppppuVar10 = (undefined4 ****)pppuStack_4c;
      }
      uVar9 = 0;
      if (uStack_3c != 0) {
        do {
          pbVar1 = (byte *)(uVar9 + (int)ppppuVar10);
          uVar9 = uVar9 + 1;
          piStack_1c = (int *)(((uint)*pbVar1 ^ (uint)piStack_1c) * 0x1000193);
        } while (uVar9 < uStack_3c);
      }
      puVar3 = *(undefined4 **)(iVar8 + 0xa4);
      uVar9 = (int)puVar3 - *(int *)(iVar8 + 0xa0) >> 2;
      if (uVar9 < 10) {
        if (*(undefined4 **)(iVar8 + 0xa8) == puVar3) {
          FUN_00595d30(puVar3,&piStack_1c);
        }
        else {
          *puVar3 = piStack_1c;
          *(int *)(iVar8 + 0xa4) = *(int *)(iVar8 + 0xa4) + 4;
        }
      }
      else {
        *(int **)(*(int *)(iVar8 + 0xa0) + *(int *)(iVar8 + 0x9c) * 4) = piStack_1c;
        *(uint *)(iVar8 + 0x9c) = (*(int *)(iVar8 + 0x9c) + 1U) % uVar9;
      }
    }
    pppuVar5 = pppuStack_4c;
    pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
    param_1[4] = 0;
    param_1[5] = 0;
    *param_1 = pppuVar5;
    param_1[1] = uStack_48;
    param_1[2] = uStack_44;
    param_1[3] = uStack_40;
    *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_38,uStack_3c);
    uStack_3c = 0;
    uStack_38 = 0xf;
    FUN_005507b0();
    FUN_0056baf0();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_0152dda0(uStack_14,uVar4,uStack_24);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (((char)uStack_8c == '\0') && (iVar8 != 0)) {
    FUN_00a3e410(iVar2,&uStack_64,param_3);
  }
  FUN_0054ef60(param_3);
  FUN_005507b0();
  FUN_0056baf0();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0152dda0(uStack_14,uVar4,uStack_24);
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20655 ; VA 0x00a4e0c0 ; FUN_00a4e0c0 */

undefined4 FUN_00a4e0c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017df840;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  iStack_8 = 0;
  if (iStack_1c == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("LocalizationService no longer exists");
  }
  piVar2 = (int *)FUN_00a42940();
  iVar5 = *piVar2;
  iVar1 = piVar2[1];
  do {
    if (iVar5 == iVar1) {
      *param_4 = '\x01';
      FUN_0054ef60(param_2);
LAB_00a4e1d5:
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_18[1] + -1;
        piStack_18[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar2 = piStack_18 + 2;
          iVar5 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_00fdd2c0(auStack_34,uStack_14,param_2,param_3,param_4);
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    if (*param_4 == '\0') {
      FUN_0054ef60(auStack_34);
      if (0xf < uStack_20) {
        uVar4 = uStack_20 + 1;
        uVar3 = auStack_34[0];
        if (0xfff < uVar4) {
          uVar3 = *(uint *)(auStack_34[0] - 4);
          uVar4 = uStack_20 + 0x24;
          if (0x1f < (auStack_34[0] - uVar3) - 4) {
LAB_00a4e21c:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar3,uVar4);
      }
      goto LAB_00a4e1d5;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_20) {
      uVar4 = uStack_20 + 1;
      uVar3 = auStack_34[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_34[0] - 4);
        uVar4 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar3) - 4) goto LAB_00a4e21c;
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    uStack_24 = 0;
    iVar5 = iVar5 + 8;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
  } while( true );
}



/* FUNCTION 20656 ; VA 0x00a4e230 ; FUN_00a4e230 */

void __thiscall FUN_00a4e230(int param_1,double param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  float fStack_8;
  
  fStack_8 = (float)param_2;
  FUN_00a3e1f0(&fStack_8);
  if ((double)*(float *)(param_1 + 0x50) < param_2) {
    *(float *)(param_1 + 0x50) = (float)param_2;
    if ((undefined4 *)(param_1 + 0x54) != param_3) {
      puVar1 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      FUN_005542c0(param_3,*puVar1);
    }
  }
  return;
}



/* FUNCTION 20657 ; VA 0x00a4e2a0 ; FUN_00a4e2a0 */

void FUN_00a4e2a0(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df88a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piVar5 = *(int **)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8 = 0;
    uStack_14 = 1;
    ExceptionList = &pvStack_10;
    FUN_0058a190(piVar5[4] + 0x3b);
    FUN_00554150("CloudLocalizationTableSelfCleaningInfo_SourceLifeCycleInfo_",0x3b);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    FUN_00554150(piVar5,*piVar1);
    iVar2 = FUN_005d1470(auStack_2c);
    uStack_8 = 0xffffffff;
    *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 1;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  piVar5 = *(int **)(param_1 + 0x24);
  if (piVar5 != (int *)0x0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8 = 1;
    uStack_14 = 2;
    FUN_0058a190(piVar5[4] + 0x40);
    FUN_00554150("CloudLocalizationTableSelfCleaningInfo_TranslationLifeCycleInfo_",0x40);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    FUN_00554150(piVar5,*piVar1);
    iVar2 = FUN_005d1470(auStack_2c);
    uStack_8 = 0xffffffff;
    *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 1;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("CloudLocalizationTableSelfCleaningInfo_ExpiredEntry",0x33);
    uStack_8 = 2;
    iVar2 = FUN_005d1470(auStack_2c);
    *(int *)(iVar2 + 0x18) = *(int *)(iVar2 + 0x18) + 1;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20658 ; VA 0x00a4e4b0 ; FUN_00a4e4b0 */

void FUN_00a4e4b0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_005d1470(param_1);
  *(int *)(iVar1 + 0x18) = *(int *)(iVar1 + 0x18) + 1;
  return;
}



/* FUNCTION 20659 ; VA 0x00a4e4d0 ; FUN_00a4e4d0 */

undefined4 * __thiscall FUN_00a4e4d0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = std::
             _Func_impl_no_alloc<class_<lambda_011c894a80405c4d8a40da9c3ab4dad1>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse_const&>
             ::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[4] = param_2[2];
  param_1[5] = param_2[3];
  param_2[2] = 0;
  param_2[3] = 0;
  param_1[6] = param_2[4];
  param_1[7] = param_2[5];
  param_1[8] = param_2[6];
  return param_1;
}



/* FUNCTION 20660 ; VA 0x00a4e550 ; FUN_00a4e550 */

undefined4 * __thiscall
FUN_00a4e550(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[2] = param_3[2] + 1;
      UNLOCK();
    }
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01943574;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 20661 ; VA 0x00a4e690 ; FUN_00a4e690 */

undefined4 * __thiscall FUN_00a4e690(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df8a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::
             _Func_impl_no_alloc<class_std::function<void___cdecl(enum_RBX::HttpErrorCode,class_RBX::HttpResponse_const&)>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_1[0xb] = 0;
  uStack_8 = 0;
  piVar1 = (int *)param_2[9];
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2) {
      uVar2 = (**(code **)(*piVar1 + 4))(param_1 + 2);
      param_1[0xb] = uVar2;
      piVar1 = (int *)param_2[9];
      if (piVar1 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return param_1;
      }
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2);
    }
    else {
      param_1[0xb] = piVar1;
    }
    param_2[9] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20662 ; VA 0x00a4e720 ; FUN_00a4e720 */

int FUN_00a4e720(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df8c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00616d10(param_1,param_2);
  uStack_8 = 0;
  *(undefined4 *)(iVar1 + 8) = *param_3;
  FUN_0054ef60(param_3 + 1);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 20663 ; VA 0x00a4e784 ; Catch_All@00a4e784 */

void Catch_All_00a4e784(void)

{
  int unaff_EBP;
  
  FUN_00781060(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20664 ; VA 0x00a4e7a0 ; FUN_00a4e7a0 */

void FUN_00a4e7a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_006d3cd0(param_1,param_2);
  puVar1 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0xc) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x10) = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  return;
}



/* FUNCTION 20665 ; VA 0x00a4e7d0 ; FUN_00a4e7d0 */

int FUN_00a4e7d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df8d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0070ad30(param_1,param_2);
  uStack_8 = 0;
  puVar1 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0xc) = puVar1[1];
  FUN_00a3aff0();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20666 ; VA 0x00a4e838 ; Catch_All@00a4e838 */

void Catch_All_00a4e838(void)

{
  int unaff_EBP;
  
  FUN_007c6100(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20667 ; VA 0x00a4e850 ; FUN_00a4e850 */

int FUN_00a4e850(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df8f6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0070ad30(param_1,param_2);
  puVar1 = (undefined4 *)*param_4;
  uStack_8 = 0;
  *(undefined4 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0xc) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x10) = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  *(undefined4 *)(iVar2 + 0x18) = 0;
  uVar3 = FUN_005cb2b0(0,0);
  *(undefined4 *)(iVar2 + 0x14) = uVar3;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 *)(iVar2 + 0x10) = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 20668 ; VA 0x00a4e901 ; Catch_All@00a4e901 */

void Catch_All_00a4e901(void)

{
  int unaff_EBP;
  
  FUN_007c6100(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20669 ; VA 0x00a4e920 ; FUN_00a4e920 */

int FUN_00a4e920(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df918;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  iVar4 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 == 0) {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
          ExceptionList = pvStack_10;
          return iVar4;
        }
      }
    }
  }
  else {
    iVar4 = FUN_016dee6d(iStack_18 + 0x38);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
    uStack_8._0_1_ = 2;
    FUN_00a51eb0(*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc),0);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar4 = FUN_016deec8(iStack_18 + 0x38);
    if (iVar4 != 0) {
      iVar4 = FUN_016df3c9(iVar4);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar4 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20670 ; VA 0x00a4ea90 ; FUN_00a4ea90 */

undefined4 * FUN_00a4ea90(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_011c894a80405c4d8a40da9c3ab4dad1>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse_const&>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  puVar2[4] = 0;
  puVar2[5] = 0;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[4] = param_1[2];
  puVar2[5] = param_1[3];
  puVar2[6] = param_1[4];
  puVar2[7] = param_1[5];
  puVar2[8] = param_1[6];
  return puVar2;
}



/* FUNCTION 20671 ; VA 0x00a4eb10 ; FUN_00a4eb10 */

undefined4 FUN_00a4eb10(undefined4 param_1)

{
  undefined4 extraout_ECX;
  
  FUN_01674e20(0x28);
  FUN_00a4e4d0(param_1);
  return extraout_ECX;
}



/* FUNCTION 20672 ; VA 0x00a4eb30 ; FUN_00a4eb30 */

undefined4 * FUN_00a4eb30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df938;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x30);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_a28c0a00a43e99a7590723021c1391a6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[5] = param_1[3];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 4);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 20673 ; VA 0x00a4ebc7 ; Catch_All@00a4ebc7 */

void Catch_All_00a4ebc7(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20674 ; VA 0x00a4ebe0 ; FUN_00a4ebe0 */

undefined4 * FUN_00a4ebe0(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x30);
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_a28c0a00a43e99a7590723021c1391a6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
            ::vftable;
  puVar1[2] = 0;
  puVar1[3] = 0;
  puVar1[2] = *param_1;
  puVar1[3] = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  puVar1[4] = param_1[2];
  puVar1[5] = param_1[3];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 4);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 20675 ; VA 0x00a4ec79 ; Catch_All@00a4ec79 */

void Catch_All_00a4ec79(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20676 ; VA 0x00a4ec90 ; FUN_00a4ec90 */

undefined4 * FUN_00a4ec90(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df978;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0x30);
  *puVar2 = std::
            _Func_impl_no_alloc<class_<lambda_accba61a656593ab0e063b1837e5dced>,void,class_std::shared_ptr<class_std::exception_const_>_>
            ::vftable;
  puVar2[2] = 0;
  puVar2[3] = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar2[2] = *param_1;
  puVar2[3] = param_1[1];
  puVar2[4] = param_1[2];
  puVar2[5] = param_1[3];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 4);
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 20677 ; VA 0x00a4ed27 ; Catch_All@00a4ed27 */

void Catch_All_00a4ed27(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20678 ; VA 0x00a4ed40 ; FUN_00a4ed40 */

undefined4 * FUN_00a4ed40(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x30);
  *puVar1 = std::
            _Func_impl_no_alloc<class_<lambda_accba61a656593ab0e063b1837e5dced>,void,class_std::shared_ptr<class_std::exception_const_>_>
            ::vftable;
  puVar1[2] = 0;
  puVar1[3] = 0;
  puVar1[2] = *param_1;
  puVar1[3] = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  puVar1[4] = param_1[2];
  puVar1[5] = param_1[3];
  uStack_8 = 1;
  FUN_0054ef60(param_1 + 4);
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 20679 ; VA 0x00a4edd9 ; Catch_All@00a4edd9 */

void Catch_All_00a4edd9(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20680 ; VA 0x00a4edf0 ; FUN_00a4edf0 */

undefined4 * FUN_00a4edf0(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df9b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x30);
  *puVar1 = std::
            _Func_impl_no_alloc<class_std::function<void___cdecl(enum_RBX::HttpErrorCode,class_RBX::HttpResponse_const&)>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
            ::vftable;
  puVar1[0xb] = 0;
  uStack_8 = 1;
  if (*(undefined4 **)(param_1 + 0x24) != (undefined4 *)0x0) {
    uVar2 = (**(code **)**(undefined4 **)(param_1 + 0x24))(puVar1 + 2);
    puVar1[0xb] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 20681 ; VA 0x00a4ee63 ; Catch_All@00a4ee63 */

void Catch_All_00a4ee63(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20682 ; VA 0x00a4ee80 ; FUN_00a4ee80 */

undefined4 FUN_00a4ee80(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017df9d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01674e20(0x30);
  uStack_8 = 0;
  FUN_00a4e690(param_1);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 20683 ; VA 0x00a4eed4 ; Catch_All@00a4eed4 */

void Catch_All_00a4eed4(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20684 ; VA 0x00a4eef0 ; FUN_00a4eef0 */

void __thiscall FUN_00a4eef0(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df9e0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        puStack_14 = &stack0xffffffd0;
        FUN_00a52520(param_4);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00a4eef0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20685 ; VA 0x00a4f0ce ; Catch_All@00a4f0ce */

void Catch_All_00a4f0ce(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a4f950(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20686 ; VA 0x00a4f100 ; FUN_00a4f100 */

void __thiscall FUN_00a4f100(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  uint uVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017df9f0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  uVar3 = FUN_005e6570(param_3);
  uVar3 = uVar3 & (uint)param_1[6];
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + uVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + uVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        FUN_00a52350(param_4);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar3 * 8);
    *(float **)((int)fVar5 + 4 + uVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00a4f100(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20687 ; VA 0x00a4f2a6 ; Catch_All@00a4f2a6 */

void Catch_All_00a4f2a6(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a4fa00(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20688 ; VA 0x00a4f2d0 ; FUN_00a4f2d0 */

void __thiscall FUN_00a4f2d0(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  uint uVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfa00;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  uVar3 = FUN_005e6570(param_3);
  uVar3 = uVar3 & (uint)param_1[6];
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + uVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + uVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00a3bd10();
        FUN_01674ea0(param_4,0x30);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar3 * 8);
    *(float **)((int)fVar5 + 4 + uVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00a4f2d0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20689 ; VA 0x00a4f496 ; Catch_All@00a4f496 */

void Catch_All_00a4f496(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a4fa70(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20690 ; VA 0x00a4f4c0 ; FUN_00a4f4c0 */

void __thiscall FUN_00a4f4c0(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  uint uVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfa10;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  uVar3 = FUN_005e6570(param_3);
  uVar3 = uVar3 & (uint)param_1[6];
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + uVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + uVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_005cafb0();
        FUN_01674ea0(param_4,0x30);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar3 * 8);
    *(float **)((int)fVar5 + 4 + uVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00a4f4c0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20691 ; VA 0x00a4f686 ; Catch_All@00a4f686 */

void Catch_All_00a4f686(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00a4fb00(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 20692 ; VA 0x00a4f6b0 ; FUN_00a4f6b0 */

void __thiscall FUN_00a4f6b0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0194357c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 20693 ; VA 0x00a4f7c0 ; FUN_00a4f7c0 */

void __thiscall FUN_00a4f7c0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  undefined auStack_1c4 [4];
  int *piStack_1c0;
  undefined auStack_134 [4];
  int *piStack_130;
  undefined auStack_a4 [4];
  int *piStack_a0;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfa5b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00a4fbd0(&param_2);
  uStack_8._0_1_ = 1;
  FUN_00a4fbd0(auStack_1c4);
  uStack_8._0_1_ = 2;
  cVar4 = FUN_00585a40(auStack_a4);
  if (cVar4 == '\0') {
    FUN_00a4fbd0(auStack_a4);
    uStack_8._0_1_ = 3;
    iStack_14 = FUN_01674e20(0x90);
    uStack_8._0_1_ = 4;
    if (iStack_14 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00a4fbd0(auStack_134);
    }
    param_1[2] = uVar5;
    FUN_00a50480();
    if (piStack_130 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_130[2] + -1;
      piStack_130[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_130 + 4))();
      }
    }
    FUN_00a50480();
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_a0[2] + -1;
      piStack_a0[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_a0 + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    FUN_00a50480();
    if (piStack_a0 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_a0[2] + -1;
      piStack_a0[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_a0 + 4))();
      }
    }
    bVar3 = false;
  }
  FUN_00a50480();
  if (piStack_1c0 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c0[2] + -1;
    piStack_1c0[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c0 + 4))();
    }
  }
  ppuVar6 = &PTR_FUN_0194355c;
  if (!bVar3) {
    ppuVar6 = (undefined **)0x0;
  }
  *param_1 = ppuVar6;
  FUN_00a50480();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20694 ; VA 0x00a4f950 ; FUN_00a4f950 */

void __thiscall FUN_00a4f950(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00a52520(param_3);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 20695 ; VA 0x00a4fa00 ; FUN_00a4fa00 */

undefined4 __thiscall FUN_00a4fa00(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  
  uVar3 = FUN_005e6570(param_3 + 2);
  iVar1 = (uVar3 & *(uint *)(param_1 + 0x18)) * 8;
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + iVar1);
  puVar4 = (undefined4 *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((undefined4 *)puVar4[1] == param_3) {
    if (puVar2 == param_3) {
      *puVar4 = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + iVar1) = *(undefined4 *)(param_1 + 4);
    }
    else {
      puVar4[1] = param_3[1];
    }
  }
  else if (puVar2 == param_3) {
    *puVar4 = *param_3;
  }
  FUN_00a528a0(param_2,param_3);
  return param_2;
}



/* FUNCTION 20696 ; VA 0x00a4fa70 ; FUN_00a4fa70 */

void __thiscall FUN_00a4fa70(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = FUN_005e6570(param_3 + 2);
  iVar1 = (uVar3 & *(uint *)(param_1 + 0x18)) * 8;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar1);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if (piVar2 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar2 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00a3bd10();
  FUN_01674ea0(param_3,0x30);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 20697 ; VA 0x00a4fb00 ; FUN_00a4fb00 */

void __thiscall FUN_00a4fb00(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = FUN_005e6570(param_3 + 2);
  iVar1 = (uVar3 & *(uint *)(param_1 + 0x18)) * 8;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar1);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if (piVar2 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar2 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_005cafb0();
  FUN_01674ea0(param_3,0x30);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 20698 ; VA 0x00a4fb90 ; FUN_00a4fb90 */

undefined4 * __thiscall FUN_00a4fb90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  return param_1;
}



/* FUNCTION 20699 ; VA 0x00a4fbd0 ; FUN_00a4fbd0 */

undefined4 * __thiscall FUN_00a4fbd0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dfab4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(param_2 + 5);
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_2[0xd] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xd] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = param_2[0xd];
  param_1[0x17] = 0;
  uStack_8 = 4;
  if ((undefined4 *)param_2[0x17] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x17])(param_1 + 0xe);
    param_1[0x17] = uVar2;
  }
  param_1[0x21] = 0;
  _uStack_8 = CONCAT31(uStack_7,6);
  if ((undefined4 *)param_2[0x21] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x21])(param_1 + 0x18);
    param_1[0x21] = uVar2;
  }
  param_1[0x22] = param_2[0x22];
  param_1[0x23] = param_2[0x23];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20700 ; VA 0x00a4fd00 ; FUN_00a4fd00 */

undefined4 * __thiscall FUN_00a4fd00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dfafc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_2[1] = 0;
  param_2[2] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  uVar4 = param_2[4];
  uVar2 = param_2[5];
  uVar3 = param_2[6];
  param_1[3] = param_2[3];
  param_1[4] = uVar4;
  param_1[5] = uVar2;
  param_1[6] = uVar3;
  *(undefined8 *)(param_1 + 7) = *(undefined8 *)(param_2 + 7);
  param_2[7] = 0;
  param_2[8] = 0xf;
  *(undefined *)(param_2 + 3) = 0;
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_2[10] = 0;
  param_2[0xb] = 0;
  param_1[0x15] = 0;
  piVar1 = (int *)param_2[0x15];
  uStack_8 = 3;
  uStack_7 = 0;
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 0xc) {
      uVar4 = (**(code **)(*piVar1 + 4))(param_1 + 0xc);
      param_1[0x15] = uVar4;
      piVar1 = (int *)param_2[0x15];
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x10))(CONCAT31((int3)((uint)*piVar1 >> 8),piVar1 != param_2 + 0xc));
        param_2[0x15] = 0;
      }
    }
    else {
      param_1[0x15] = piVar1;
      param_2[0x15] = 0;
    }
  }
  param_1[0x1f] = 0;
  piVar1 = (int *)param_2[0x1f];
  _uStack_8 = CONCAT31(uStack_7,5);
  if (piVar1 != (int *)0x0) {
    if (piVar1 == param_2 + 0x16) {
      uVar4 = (**(code **)(*piVar1 + 4))(param_1 + 0x16);
      param_1[0x1f] = uVar4;
      piVar1 = (int *)param_2[0x1f];
      if (piVar1 == (int *)0x0) goto LAB_00a4fe5e;
      (**(code **)(*piVar1 + 0x10))(piVar1 != param_2 + 0x16);
    }
    else {
      param_1[0x1f] = piVar1;
    }
    param_2[0x1f] = 0;
  }
LAB_00a4fe5e:
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20701 ; VA 0x00a4fe90 ; FUN_00a4fe90 */

undefined4 * __thiscall FUN_00a4fe90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfb49;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 2);
  param_1[8] = param_2[8];
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_2[10] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[10] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0x15] = 0;
  uStack_8._0_1_ = 3;
  if ((undefined4 *)param_2[0x15] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x15])(param_1 + 0xc);
    param_1[0x15] = uVar2;
  }
  param_1[0x1f] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if ((undefined4 *)param_2[0x1f] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x1f])(param_1 + 0x16);
    param_1[0x1f] = uVar2;
  }
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20702 ; VA 0x00a4ff90 ; FUN_00a4ff90 */

undefined4 * __thiscall FUN_00a4ff90(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017dfba4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(param_2 + 4);
  param_1[10] = param_2[10];
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  if (param_2[0xc] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xc] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  param_1[0x17] = 0;
  uStack_8 = 4;
  if ((undefined4 *)param_2[0x17] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x17])(param_1 + 0xe);
    param_1[0x17] = uVar2;
  }
  param_1[0x21] = 0;
  _uStack_8 = CONCAT31(uStack_7,6);
  if ((undefined4 *)param_2[0x21] != (undefined4 *)0x0) {
    uVar2 = (*(code *)**(undefined4 **)param_2[0x21])(param_1 + 0x18);
    param_1[0x21] = uVar2;
  }
  param_1[0x22] = param_2[0x22];
  param_1[0x23] = param_2[0x23];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20703 ; VA 0x00a500b0 ; FUN_00a500b0 */

undefined4 * __fastcall FUN_00a500b0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfcaa;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 4;
  piVar3 = (int *)FUN_01674e20(0x18);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3[1] = 1;
    piVar3[2] = 1;
    *piVar3 = (int)std::_Ref_count_obj<class_RBX::CloudLocalization::AssetFetcher>::vftable;
    piVar3[3] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[3] = (int)RBX::CloudLocalization::AssetFetcher::vftable;
  }
  piVar1 = piVar3 + 3;
  if ((piVar1 != (int *)0x0) && ((piVar3[5] == 0 || (*(int *)(piVar3[5] + 4) == 0)))) {
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar3[2] = piVar3[2] + 1;
        UNLOCK();
      }
    }
    piVar3[4] = (int)piVar1;
    piVar2 = (int *)piVar3[5];
    piVar3[5] = (int)piVar3;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar2 = piVar3 + 2;
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  param_1[6] = piVar1;
  param_1[7] = piVar3;
  uStack_8._0_1_ = 5;
  puVar4 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[1] = 1;
    puVar4[2] = 1;
    *puVar4 = std::_Ref_count_obj<class_RBX::CloudLocalization::AnalyticsHandler>::vftable;
    puVar4[3] = 0;
    puVar4[3] = RBX::CloudLocalization::AnalyticsHandler::vftable;
  }
  param_1[9] = puVar4;
  param_1[8] = puVar4 + 3;
  uStack_8._0_1_ = 6;
  iVar5 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (iVar5 == 0) {
    uVar6 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar6);
  }
  param_1[0xb] = iVar5;
  iVar5 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[0xc] = iVar5;
  if (iVar5 == 0) {
    FUN_006ddd60(param_1[0xb],0x7fffffff);
    uVar6 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar6);
  }
  iVar5 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[0xd] = iVar5;
  if (iVar5 == 0) {
    FUN_006ddd60(param_1[0xb],0x7fffffff);
    FUN_006ddd60(param_1[0xc],0x7fffffff);
    uVar6 = FUN_005503c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar6);
  }
  param_1[10] = 0;
  FUN_016dee4c(param_1 + 0xe,2);
  uStack_8._0_1_ = 0xb;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  uVar6 = FUN_006d3cd0(0,0);
  param_1[0x1b] = uVar6;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  uStack_8._0_1_ = 0xd;
  param_1[0x1a] = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 0xe;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  uVar6 = FUN_006d3cd0(0,0);
  param_1[0x23] = uVar6;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  uStack_8._0_1_ = 0x10;
  param_1[0x22] = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 0x11;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uVar6 = FUN_0070ad30(0,0);
  param_1[0x2b] = uVar6;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  uStack_8._0_1_ = 0x13;
  param_1[0x2a] = 0x3f800000;
  FUN_005cb500(8);
  uStack_8._0_1_ = 0x14;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  uVar6 = FUN_0070ad30(0,0);
  param_1[0x33] = uVar6;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  param_1[0x32] = 0x3f800000;
  FUN_005cb500(8);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 20704 ; VA 0x00a50450 ; FUN_00a50450 */

int __fastcall FUN_00a50450(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00a50480();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00a5046f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 20705 ; VA 0x00a50480 ; FUN_00a50480 */

void __fastcall FUN_00a50480(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x7c);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x58));
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x54);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x30));
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x2c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x20);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0xc);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a50542. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20706 ; VA 0x00a50550 ; FUN_00a50550 */

void __fastcall FUN_00a50550(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x7c);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x58));
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x54);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x30));
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 8);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a50612. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20707 ; VA 0x00a50620 ; FUN_00a50620 */

void __fastcall FUN_00a50620(int param_1)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x10);
    uVar5 = uVar1 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[2] + -1;
    piVar3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00a50679. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20708 ; VA 0x00a50690 ; FUN_00a50690 */

void __fastcall FUN_00a50690(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = *(int **)(param_1 + 0x84);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x60));
    *(undefined4 *)(param_1 + 0x84) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x5c);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x38));
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar3) {
    iVar4 = *(int *)(param_1 + 0x10);
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[2] + -1;
    piVar2[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a5076a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20709 ; VA 0x00a50780 ; FUN_00a50780 */

void __fastcall FUN_00a50780(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50900();
  return;
}



/* FUNCTION 20710 ; VA 0x00a507e0 ; FUN_00a507e0 */

void __fastcall FUN_00a507e0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50990();
  return;
}



/* FUNCTION 20711 ; VA 0x00a50840 ; FUN_00a50840 */

void __fastcall FUN_00a50840(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50a10();
  return;
}



/* FUNCTION 20712 ; VA 0x00a508a0 ; FUN_00a508a0 */

void __fastcall FUN_00a508a0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50a60();
  return;
}



/* FUNCTION 20713 ; VA 0x00a50900 ; FUN_00a50900 */

void __fastcall FUN_00a50900(int *param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int *piVar7;
  
  piVar5 = (int *)*param_1;
  piVar7 = (int *)*piVar5;
  *piVar5 = (int)piVar5;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar5 = (int *)*param_1;
  if (piVar7 != piVar5) {
    do {
      uVar1 = piVar7[8];
      piVar2 = (int *)*piVar7;
      if (0xf < uVar1) {
        iVar3 = piVar7[3];
        uVar6 = uVar1 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar6 = uVar1 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
      }
      piVar7[7] = 0;
      piVar7[8] = 0xf;
      *(undefined *)(piVar7 + 3) = 0;
      FUN_01674ea0(piVar7,0x24);
      piVar5 = (int *)*param_1;
      piVar7 = piVar2;
    } while (piVar2 != piVar5);
  }
  FUN_01674ea0(piVar5,0x24);
  return;
}



/* FUNCTION 20714 ; VA 0x00a50990 ; FUN_00a50990 */

void __fastcall FUN_00a50990(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[5];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x18);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x18);
  return;
}



/* FUNCTION 20715 ; VA 0x00a50a10 ; FUN_00a50a10 */

void __fastcall FUN_00a50a10(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_00a3bd10();
      FUN_01674ea0(piVar3,0x30);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x30);
  return;
}



/* FUNCTION 20716 ; VA 0x00a50a60 ; FUN_00a50a60 */

void __fastcall FUN_00a50a60(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_005cafb0();
      FUN_01674ea0(piVar3,0x30);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x30);
  return;
}



/* FUNCTION 20717 ; VA 0x00a50ab0 ; thunk_FUN_00a507e0 */

void __fastcall thunk_FUN_00a507e0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50990();
  return;
}



/* FUNCTION 20718 ; VA 0x00a50ac0 ; FUN_00a50ac0 */

void __fastcall FUN_00a50ac0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_00a50a10();
  return;
}



/* FUNCTION 20719 ; VA 0x00a50ad0 ; FUN_00a50ad0 */

int * __thiscall FUN_00a50ad0(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  int *piStack_10;
  int *piStack_c;
  int iStack_8;
  
  piVar5 = param_2;
  iStack_8 = param_1;
  uVar7 = FUN_005e6570(param_2);
  iVar6 = iStack_8;
  iVar1 = (uVar7 & *(uint *)(param_1 + 0x18)) * 8;
  piVar2 = *(int **)(param_1 + 4);
  piVar3 = *(int **)(*(int *)(param_1 + 0xc) + iVar1);
  piVar9 = piVar3;
  while( true ) {
    piVar10 = piVar2;
    if (piVar3 != piVar2) {
      piVar10 = (int *)**(undefined4 **)(iVar1 + *(int *)(param_1 + 0xc) + 4);
    }
    if (piVar9 == piVar10) goto LAB_00a50b28;
    if ((piVar9[2] == *piVar5) && (piVar9[3] == piVar5[1])) break;
    piVar9 = (int *)*piVar9;
  }
  if (piVar9 == piVar2) {
LAB_00a50b28:
    iVar1 = *piVar2;
    piStack_c = piVar5;
    puVar4 = *(undefined4 **)(iVar1 + 4);
    uVar8 = FUN_00a4e850(iVar1,puVar4,&DAT_018bdeda,&piStack_c,(int)&param_2 + 3);
    if (*(int *)(iVar6 + 8) == 0x5555554) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar8;
    *puVar4 = uVar8;
    FUN_00a4f4c0(&piStack_10,**(int **)(iVar6 + 4) + 8,**(int **)(iVar6 + 4));
    piVar9 = piStack_10;
  }
  return piVar9 + 4;
}



/* FUNCTION 20720 ; VA 0x00a50ba0 ; FUN_00a50ba0 */

int __thiscall FUN_00a50ba0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined auStack_60 [4];
  undefined auStack_5c [12];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  char cStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  undefined *puStack_30;
  int *piStack_2c;
  undefined *puStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dfcf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_40);
  uStack_8 = 0;
  iVar4 = FUN_00587490(&iStack_38);
  iVar1 = iStack_40;
  uStack_8._0_1_ = 1;
  if ((iStack_40 != 0) && (iStack_38 != 0)) {
    if (param_3[3] == 200) {
      puVar7 = param_1 + 4;
      puStack_14 = puVar7;
      FUN_00a553d0(&puStack_30,*puVar7,param_1[5],param_3 + 0x10);
      uStack_8._0_1_ = 2;
      if (puStack_30 == (undefined *)0x0) {
        iVar4 = FUN_00550b30();
      }
      else {
        FUN_006d0720(iVar1 + 0x28);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_0097bf20(&param_3,puVar7);
        piVar6 = param_3;
        if (param_3 == *(int **)(iVar1 + 0x6c)) {
          iVar4 = **(int **)(iVar1 + 0x6c);
          puStack_1c = *(undefined4 **)(iVar4 + 4);
          puStack_18 = puVar7;
          uVar5 = FUN_00a4e7a0(iVar4,puStack_1c,&DAT_018bdeda,&puStack_18,(int)&param_3 + 3);
          if (*(int *)(iVar1 + 0x70) == 0xaaaaaa9) {
                    /* WARNING: Subroutine does not return */
            FUN_016ddcd9("list<T> too long");
          }
          *(int *)(iVar1 + 0x70) = *(int *)(iVar1 + 0x70) + 1;
          *(undefined4 *)(iVar4 + 4) = uVar5;
          *puStack_1c = uVar5;
          FUN_00a4f100(&piStack_20,**(int **)(iVar1 + 0x6c) + 8,**(int **)(iVar1 + 0x6c));
          piVar6 = piStack_20;
        }
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[1] = piStack_2c[1] + 1;
          UNLOCK();
        }
        piVar6[4] = (int)puStack_30;
        piVar2 = (int *)piVar6[5];
        piVar6[5] = (int)piStack_2c;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar4 = piVar2[1] + -1;
          piVar2[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar4 = piVar2[2] + -1;
            piVar2[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_00a55cc0();
        FUN_005dbd10(iStack_40 + 0x38);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        FUN_00a51dd0(*puStack_14,puStack_14[1],*puStack_30,puStack_30[1]);
        if ((piStack_20 == (int *)0x0) || ((char)puStack_1c == '\0')) {
          puVar7 = (undefined4 *)FUN_00621c50(&puStack_28,1);
          FUN_00610cc0(*puVar7,puVar7[1]);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_5c,&DAT_01c2a4ec);
        }
        iVar4 = FUN_016deec8(piStack_20);
        if (iVar4 != 0) {
          FUN_016df3c9(iVar4);
        }
        puStack_1c = (undefined4 *)((uint)puStack_1c & 0xffffff00);
        FUN_00a53020(iStack_38,*(undefined4 *)(puStack_30 + 8),*(undefined4 *)(puStack_30 + 0xc));
        pcVar3 = *(code **)(**(int **)(iStack_40 + 0x20) + 0xc);
        if (piStack_2c != (int *)0x0) {
          LOCK();
          piStack_2c[1] = piStack_2c[1] + 1;
          UNLOCK();
        }
        puStack_28 = puStack_30;
        piStack_24 = piStack_2c;
        uStack_8._0_1_ = 5;
        (*pcVar3)(*puStack_14,puStack_14[1],&puStack_28);
        piVar6 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_24[1] + -1;
          piStack_24[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar2 = piVar6 + 2;
            iVar4 = *piVar2 + -1;
            *piVar2 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (cStack_44 != '\0') {
          FUN_006e00b0();
        }
        iVar4 = FUN_00550b30();
      }
    }
    else {
      piVar6 = (int *)param_1[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
        piVar6 = (int *)param_1[1];
      }
      param_3 = (int *)param_1[6];
      uVar5 = *param_1;
      piVar2 = piVar6 + 2;
      if (piVar6 != (int *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      uVar8 = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_00a4f6b0(uVar5,piVar6,param_3);
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar4 = *piVar2;
        *piVar2 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          (**(code **)(*piVar6 + 4))(uVar8);
        }
        LOCK();
        iVar4 = *piVar2;
        *piVar2 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
      FUN_0090ca30(uVar8);
      uStack_50 = 0;
      uStack_4c = 0xf;
      auStack_60[0] = 0;
      pcVar3 = *(code **)(**(int **)(iStack_40 + 0x20) + 4);
      FUN_005542c0("CloudLocalizationSettingsHttpFailure",0x24);
      uStack_8._0_1_ = 7;
      (*pcVar3)(auStack_60);
      iVar4 = FUN_005507b0();
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_34 + 1;
    iVar1 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar6 = piStack_34 + 2;
      iVar1 = *piVar6;
      iVar4 = *piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar6 = piStack_3c + 1;
    iVar1 = *piVar6;
    iVar4 = *piVar6;
    *piVar6 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar4 = (**(code **)*piStack_3c)();
      LOCK();
      piVar6 = piStack_3c + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar4 = (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 20721 ; VA 0x00a50f40 ; FUN_00a50f40 */

int FUN_00a50f40(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  char cStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfd53;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_28);
  iVar2 = iStack_28;
  uStack_8._0_1_ = 1;
  if (iStack_28 != 0) {
    puStack_14 = puStack_14 + 2;
    FUN_0097bf20(&uStack_18,puStack_14);
    FUN_006d0720(iVar2 + 0x28);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(param_1);
    uStack_8._0_1_ = 3;
    uStack_20 = 0;
    iStack_1c = 0;
    uStack_18 = 0;
    FUN_00604490(auStack_48,auStack_30,param_2);
    uStack_8._0_1_ = 4;
    FUN_00fda0d0(&uStack_20);
    FUN_00577a40();
    uStack_8._0_1_ = 2;
    FUN_016f32d1(auStack_48,0x18,1,FUN_005507b0);
    FUN_00a50ad0(puStack_14);
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    FUN_005542c0("source",6);
    uStack_8._0_1_ = 5;
    FUN_005ca900(&iStack_1c,auStack_48,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_34) {
      uVar5 = uStack_34 + 1;
      uVar4 = auStack_48[0];
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(auStack_48[0] - 4);
        uVar5 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    FUN_00a55cc0();
    iStack_1c = iStack_28 + 0x38;
    iVar3 = FUN_016dee6d(iStack_1c);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_18 = CONCAT31(uStack_18._1_3_,1);
    uStack_8._0_1_ = 6;
    FUN_00a51eb0(*puStack_14,puStack_14[1],1);
    uStack_8._0_1_ = 7;
    iVar3 = FUN_016deec8(iStack_28 + 0x38);
    if (iVar3 != 0) {
      iVar3 = FUN_016df3c9(iVar3);
    }
    if (cStack_2c != '\0') {
      iVar3 = FUN_006e00b0();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20722 ; VA 0x00a51170 ; FUN_00a51170 */

int FUN_00a51170(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfd80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((iStack_20 != 0) && (iStack_18 != 0)) {
    iVar3 = FUN_016dee6d(iStack_20 + 0x38);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8._0_1_ = 3;
    FUN_0091c070(*(undefined4 *)(iStack_18 + 0x440),*(undefined4 *)(iStack_18 + 0x444),param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    iVar3 = FUN_016deec8(iStack_20 + 0x38);
    if (iVar3 != 0) {
      iVar3 = FUN_016df3c9(iVar3);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 20723 ; VA 0x00a512a0 ; FUN_00a512a0 */

void __thiscall FUN_00a512a0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfdb8;
  pvStack_10 = ExceptionList;
  pcVar2 = *(code **)(*param_2 + 4);
  uVar3 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((undefined4 *)param_1[0x1f] != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    (*(code *)**(undefined4 **)param_1[0x1f])();
  }
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if ((undefined4 *)param_1[0x15] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x15])();
  }
  if (param_1[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(param_1 + 3);
  uStack_8 = 0xffffffff;
  (*pcVar2)(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20724 ; VA 0x00a513a0 ; FUN_00a513a0 */

void __thiscall FUN_00a513a0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined auStack_1c8 [4];
  int *piStack_1c4;
  undefined4 uStack_138;
  int *piStack_134;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  int iStack_a0;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [36];
  undefined4 uStack_54;
  undefined auStack_50 [36];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dfe3d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cf2a0();
  iStack_a0 = param_1[1];
  puStack_1c = &uStack_138;
  puStack_20 = &uStack_a8;
  uStack_a8 = param_2;
  if (iStack_a0 != 0) {
    LOCK();
    *(int *)(iStack_a0 + 8) = *(int *)(iStack_a0 + 8) + 1;
    UNLOCK();
    iStack_a0 = param_1[1];
  }
  uStack_a4 = *param_1;
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 2);
  iStack_7c = param_1[10];
  uStack_84 = param_1[8];
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
    UNLOCK();
    iStack_7c = param_1[10];
  }
  uStack_80 = param_1[9];
  puStack_14 = auStack_78;
  uStack_54 = 0;
  uStack_8._0_1_ = 3;
  if ((undefined4 *)param_1[0x15] != (undefined4 *)0x0) {
    uStack_54 = (*(code *)**(undefined4 **)param_1[0x15])(auStack_78);
  }
  puStack_14 = auStack_50;
  uStack_2c = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if ((undefined4 *)param_1[0x1f] != (undefined4 *)0x0) {
    uStack_2c = (*(code *)**(undefined4 **)param_1[0x1f])(auStack_50);
  }
  uStack_28 = param_1[0x20];
  piStack_134 = (int *)param_1[1];
  uStack_24 = param_1[0x21];
  if (piStack_134 != (int *)0x0) {
    LOCK();
    piStack_134[2] = piStack_134[2] + 1;
    UNLOCK();
    piStack_134 = (int *)param_1[1];
  }
  uStack_138 = *param_1;
  uStack_18 = 0;
  puStack_14 = (undefined *)0x0;
  uStack_8 = 8;
  FUN_00a4fd00(&uStack_a8);
  FUN_00a50480();
  uStack_8 = 9;
  FUN_00a4fbd0(&uStack_138);
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  FUN_00a4fbd0(auStack_1c8);
  FUN_00a4f7c0();
  FUN_00a50480();
  if (piStack_1c4 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c4[2] + -1;
    piStack_1c4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_1c4 + 4))();
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00a50480();
  if (piStack_134 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_134 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*piStack_134 + 4))();
    }
  }
  FUN_009eef30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20725 ; VA 0x00a515d0 ; FUN_00a515d0 */

int FUN_00a515d0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_50 [24];
  undefined auStack_38 [4];
  char cStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfe8b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00587490(&iStack_30);
  uStack_8._0_1_ = 1;
  if (iStack_30 != 0) {
    FUN_006d0720(iStack_30 + 0x28);
    puStack_28 = (undefined4 *)(iStack_14 + 8);
    uStack_8._0_1_ = 2;
    FUN_0097bf20(&uStack_1c,puStack_28);
    FUN_0054ef60(param_1);
    uStack_8._0_1_ = 3;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    FUN_00604490(auStack_50,auStack_38,param_2);
    uStack_8._0_1_ = 4;
    FUN_00fda0d0(&uStack_24);
    FUN_00577a40();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016f32d1(auStack_50,0x18,1,FUN_005507b0);
    puVar5 = puStack_28;
    FUN_00a50ad0(puStack_28);
    puStack_28 = (undefined4 *)(iStack_14 + 0x10);
    FUN_00870280(&uStack_20,puStack_28,param_2);
    FUN_00a55cc0();
    iStack_18 = iStack_30 + 0x38;
    iVar6 = FUN_016dee6d(iStack_18);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
    iStack_14 = CONCAT31(iStack_14._1_3_,1);
    uVar3 = *puVar5;
    uVar4 = puVar5[1];
    uStack_8._0_1_ = 5;
    FUN_0054ef60(puStack_28);
    FUN_0091bf30(uVar3,uVar4,1);
    uStack_8._0_1_ = 6;
    iVar6 = FUN_016deec8(iStack_18);
    if (iVar6 != 0) {
      iVar6 = FUN_016df3c9(iVar6);
    }
    if (cStack_34 != '\0') {
      iVar6 = FUN_006e00b0();
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 20726 ; VA 0x00a517b0 ; FUN_00a517b0 */

int __thiscall FUN_00a517b0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dfeb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar5 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    iVar5 = FUN_016dee6d(iStack_1c + 0x38);
    if (iVar5 != 0) {
      FUN_016df3c9(iVar5);
    }
    uVar3 = *(undefined4 *)(param_1 + 8);
    uStack_8._0_1_ = 2;
    uVar4 = *(undefined4 *)(iStack_14 + 0xc);
    FUN_0054ef60(iStack_14 + 0x10);
    FUN_0091bf30(uVar3,uVar4,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar5 = FUN_016deec8(iStack_1c + 0x38);
    if (iVar5 != 0) {
      iVar5 = FUN_016df3c9(iVar5);
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 20727 ; VA 0x00a518c0 ; FUN_00a518c0 */

void * __thiscall
FUN_00a518c0(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4,int *param_5,
            code *param_6,int *param_7,code *param_8)

{
  code *pcVar1;
  code *pcVar2;
  int iVar3;
  undefined3 uVar4;
  char cVar5;
  void *pvVar6;
  int *piVar7;
  undefined auStack_384 [136];
  undefined auStack_2fc [136];
  undefined auStack_274 [136];
  undefined auStack_1ec [136];
  undefined auStack_164 [184];
  undefined4 uStack_ac;
  int iStack_a8;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  int iStack_84;
  undefined auStack_7c [36];
  undefined4 uStack_58;
  undefined auStack_54 [36];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  code *pcStack_20;
  undefined *puStack_1c;
  int *piStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017dffb9;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  if ((param_2 == 1) && (param_5 != (int *)0x0)) {
    ExceptionList = &pvStack_10;
    if (param_6 != (code *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      *(int *)(param_6 + 4) = *(int *)(param_6 + 4) + 1;
      UNLOCK();
    }
    piStack_18 = param_5;
    pcStack_14 = param_6;
    uStack_8._1_3_ = 0;
    uVar4 = uStack_8._1_3_;
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    if ((int *)param_1[0x17] == (int *)0x0) {
      uStack_8._1_3_ = uVar4;
                    /* WARNING: Subroutine does not return */
      FUN_016ddc9c();
    }
    pvVar6 = (void *)(**(code **)(*(int *)param_1[0x17] + 8))();
    pcVar2 = pcStack_14;
    if (pcStack_14 != (code *)0x0) {
      LOCK();
      pcVar1 = pcStack_14 + 4;
      iVar3 = *(int *)pcVar1;
      pvVar6 = *(void **)pcVar1;
      *(int *)pcVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (*(code *)**(undefined4 **)pcStack_14)();
        LOCK();
        pcVar1 = pcVar2 + 8;
        iVar3 = *(int *)pcVar1;
        pvVar6 = *(void **)pcVar1;
        *(int *)pcVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          pvVar6 = (void *)(**(code **)(*(int *)pcVar2 + 4))();
        }
      }
    }
    goto LAB_00a51d3f;
  }
  pvVar6 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_7 == (int *)0x0) goto LAB_00a51d3f;
  if (((int)param_1[0x23] < 1) || ((int)param_1[0x22] <= (int)param_1[0x23])) {
    ExceptionList = &pvStack_10;
    pvVar6 = (void *)FUN_00587490();
    uStack_8._0_1_ = 5;
    if (iStack_24 == 0) {
      if (pcStack_20 != (code *)0x0) {
        LOCK();
        pcVar2 = pcStack_20 + 4;
        iVar3 = *(int *)pcVar2;
        pvVar6 = *(void **)pcVar2;
        *(int *)pcVar2 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (*(code *)**(undefined4 **)pcStack_20)();
          LOCK();
          pcVar2 = pcStack_20 + 8;
          iVar3 = *(int *)pcVar2;
          pvVar6 = *(void **)pcVar2;
          *(int *)pcVar2 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            pvVar6 = (void *)(**(code **)(*(int *)pcStack_20 + 4))();
          }
        }
      }
      goto LAB_00a51d3f;
    }
    iStack_a8 = param_1[1];
    pcStack_14 = (code *)&uStack_ac;
    if (iStack_a8 != 0) {
      LOCK();
      *(int *)(iStack_a8 + 8) = *(int *)(iStack_a8 + 8) + 1;
      UNLOCK();
      iStack_a8 = param_1[1];
    }
    uStack_ac = *param_1;
    uStack_8._0_1_ = 6;
    FUN_0054ef60(param_1 + 4);
    iStack_84 = param_1[0xc];
    uStack_8c = param_1[10];
    if (iStack_84 != 0) {
      LOCK();
      *(int *)(iStack_84 + 4) = *(int *)(iStack_84 + 4) + 1;
      UNLOCK();
      iStack_84 = param_1[0xc];
    }
    uStack_88 = param_1[0xb];
    puStack_1c = auStack_7c;
    uStack_58 = 0;
    uStack_8._0_1_ = 9;
    if ((undefined4 *)param_1[0x17] != (undefined4 *)0x0) {
      uStack_58 = (*(code *)**(undefined4 **)param_1[0x17])(auStack_7c);
    }
    puStack_1c = auStack_54;
    uStack_30 = 0;
    uStack_8._0_1_ = 0xb;
    if ((undefined4 *)param_1[0x21] != (undefined4 *)0x0) {
      uStack_30 = (*(code *)**(undefined4 **)param_1[0x21])(auStack_54);
    }
    uStack_2c = param_1[0x22];
    uStack_28 = param_1[0x23];
    uStack_8._0_1_ = 0xc;
    FUN_00a4fe90(&uStack_ac);
    uStack_8._0_1_ = 0xd;
    FUN_00a4fe90(auStack_384);
    uStack_8._0_1_ = 0xe;
    FUN_00a4fe90(auStack_2fc);
    uStack_8._0_1_ = 0xf;
    FUN_00a4fe90(auStack_274);
    uStack_8._0_1_ = 0x10;
    cVar5 = FUN_00585a40(auStack_164);
    if (cVar5 == '\0') {
      FUN_00a4fe90(auStack_164);
      uStack_8._0_1_ = 0x11;
      pcStack_14 = (code *)FUN_01674e20(0x88);
      uStack_8._0_1_ = 0x12;
      if (pcStack_14 != (code *)0x0) {
        FUN_00a4fe90(auStack_1ec);
      }
      FUN_00a50550();
      FUN_00a50550();
    }
    else {
      FUN_00a50550();
    }
    FUN_00a50550();
    FUN_00a50550();
    FUN_00a50550();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_00a50550();
    FUN_0090ca30();
LAB_00a51c3e:
    uStack_8._0_1_ = 2;
    if (pcStack_20 != (code *)0x0) {
      LOCK();
      iVar3 = *(int *)(pcStack_20 + 4) + -1;
      *(int *)(pcStack_20 + 4) = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (*(code *)**(undefined4 **)pcStack_20)();
        LOCK();
        iVar3 = *(int *)(pcStack_20 + 8) + -1;
        *(int *)(pcStack_20 + 8) = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*(int *)pcStack_20 + 4))();
        }
      }
    }
  }
  else {
    piVar7 = (int *)param_1[0x21];
    ExceptionList = &pvStack_10;
    if (piVar7 != (int *)0x0) {
      ExceptionList = &pvStack_10;
      if (param_8 != (code *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        *(int *)(param_8 + 4) = *(int *)(param_8 + 4) + 1;
        UNLOCK();
        piVar7 = (int *)param_1[0x21];
      }
      piStack_18 = param_7;
      pcStack_14 = param_8;
      uStack_8 = 4;
      if (piVar7 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddc9c();
      }
      (**(code **)(*piVar7 + 8))();
      pcStack_20 = pcStack_14;
      goto LAB_00a51c3e;
    }
  }
  pcVar2 = *(code **)(*(int *)param_1[0xb] + 4);
  FUN_00a53890();
  uStack_8._0_1_ = 0x13;
  FUN_01675640();
  uStack_8._0_1_ = 0x14;
  (*pcVar2)();
  FUN_005507b0();
  uStack_8._0_1_ = 2;
  FUN_005507b0();
  pcStack_14 = *(code **)(*(int *)param_1[0xb] + 8);
  puStack_1c = (undefined *)(**(code **)(*param_7 + 4))();
  FUN_00a53890();
  uStack_8._0_1_ = 0x15;
  FUN_01675640();
  uStack_8._0_1_ = 0x16;
  (*pcStack_14)();
  FUN_005507b0();
  pvVar6 = (void *)FUN_005507b0();
LAB_00a51d3f:
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar7 = param_4 + 1;
    iVar3 = *piVar7;
    pvVar6 = (void *)*piVar7;
    *piVar7 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar7 = param_4 + 2;
      iVar3 = *piVar7;
      pvVar6 = (void *)*piVar7;
      *piVar7 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar6 = (void *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (code *)0x0) {
    LOCK();
    pcVar2 = param_6 + 4;
    iVar3 = *(int *)pcVar2;
    pvVar6 = *(void **)pcVar2;
    *(int *)pcVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (*(code *)**(undefined4 **)param_6)();
      LOCK();
      pcVar2 = param_6 + 8;
      iVar3 = *(int *)pcVar2;
      pvVar6 = *(void **)pcVar2;
      *(int *)pcVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar6 = (void *)(**(code **)(*(int *)param_6 + 4))();
      }
    }
  }
  if (param_8 != (code *)0x0) {
    LOCK();
    pcVar2 = param_8 + 4;
    iVar3 = *(int *)pcVar2;
    pvVar6 = *(void **)pcVar2;
    *(int *)pcVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      pvVar6 = (void *)(*(code *)**(undefined4 **)param_8)();
      LOCK();
      pcVar2 = param_8 + 8;
      iVar3 = *(int *)pcVar2;
      *(int *)pcVar2 = *(int *)pcVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        pvVar6 = (void *)(**(code **)(*(int *)param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 20728 ; VA 0x00a51dd0 ; FUN_00a51dd0 */

/* WARNING: Removing unreachable block (ram,0x00a51e2a) */
/* WARNING: Removing unreachable block (ram,0x00a51e3a) */
/* WARNING: Removing unreachable block (ram,0x00a51e40) */

void __fastcall FUN_00a51dd0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017dffe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20729 ; VA 0x00a51e82 ; Catch@00a51e82 */

undefined * Catch_00a51e82(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00a51e93;
}



/* FUNCTION 20730 ; VA 0x00a51eb0 ; FUN_00a51eb0 */

/* WARNING: Removing unreachable block (ram,0x00a51f0a) */
/* WARNING: Removing unreachable block (ram,0x00a51f1a) */
/* WARNING: Removing unreachable block (ram,0x00a51f20) */

void __fastcall FUN_00a51eb0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e0000;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 20731 ; VA 0x00a51f5f ; Catch@00a51f5f */

undefined * Catch_00a51f5f(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00a51f70;
}



/* FUNCTION 20732 ; VA 0x00a51f90 ; FUN_00a51f90 */

undefined4 __thiscall FUN_00a51f90(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xf4);
  }
  return param_1;
}



/* FUNCTION 20733 ; VA 0x00a51fc0 ; FUN_00a51fc0 */

undefined4 * __thiscall FUN_00a51fc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::CloudLocalization::IAnalyticsHandler::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 20734 ; VA 0x00a51ff0 ; FUN_00a51ff0 */

undefined4 * __thiscall FUN_00a51ff0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  *param_1 = RBX::CloudLocalization::IAssetFetcher::vftable;
  piVar1 = (int *)param_1[2];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 20735 ; VA 0x00a52030 ; FUN_00a52030 */

void __fastcall FUN_00a52030(int param_1)

{
  FUN_00a4ea90(param_1 + 8);
  return;
}



/* FUNCTION 20736 ; VA 0x00a52040 ; FUN_00a52040 */

void __thiscall FUN_00a52040(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_14a35e609901ef61391affbc55ca94e6>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0xc) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  return;
}



/* FUNCTION 20737 ; VA 0x00a52090 ; FUN_00a52090 */

undefined4 * __thiscall FUN_00a52090(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_1a51b86597b025c2f4b998a4b1528dd7>,void,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>
             ::vftable;
  param_2[1] = 0;
  param_2[2] = 0;
  if (*(int *)(param_1 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 8) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = 0;
  param_2[4] = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  return param_2;
}



/* FUNCTION 20738 ; VA 0x00a520f0 ; FUN_00a520f0 */

void __thiscall FUN_00a520f0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_8f1a69fff0aff060eff14970b7b6deca>,void,class_std::shared_ptr<class_std::exception_const_>_>
             ::vftable;
  param_2[2] = 0;
  param_2[3] = 0;
  if (*(int *)(param_1 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0xc) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[2] = *(undefined4 *)(param_1 + 8);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  param_2[4] = *(undefined4 *)(param_1 + 0x10);
  param_2[5] = *(undefined4 *)(param_1 + 0x14);
  return;
}



/* FUNCTION 20739 ; VA 0x00a52140 ; FUN_00a52140 */

void __fastcall FUN_00a52140(int param_1)

{
  FUN_00a4eb30(param_1 + 8);
  return;
}



/* FUNCTION 20740 ; VA 0x00a52150 ; FUN_00a52150 */

void __fastcall FUN_00a52150(int param_1)

{
  FUN_00a4ec90(param_1 + 8);
  return;
}



/* FUNCTION 20741 ; VA 0x00a52160 ; FUN_00a52160 */

void __fastcall FUN_00a52160(int param_1)

{
  FUN_00a4edf0(param_1 + 8);
  return;
}



/* FUNCTION 20742 ; VA 0x00a52170 ; FUN_00a52170 */

void __thiscall FUN_00a52170(int param_1,char param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x28);
  }
  return;
}



/* FUNCTION 20743 ; VA 0x00a521c0 ; FUN_00a521c0 */

void __thiscall FUN_00a521c0(int param_1,char param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x18);
  }
  return;
}



/* FUNCTION 20744 ; VA 0x00a52200 ; FUN_00a52200 */

void __thiscall FUN_00a52200(undefined4 param_1,char param_2)

{
  FUN_00a50620();
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x30);
  }
  return;
}



/* FUNCTION 20745 ; VA 0x00a52230 ; FUN_00a52230 */

void __thiscall FUN_00a52230(int param_1,char param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x10))(piVar1 != (int *)(param_1 + 8));
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x30);
  }
  return;
}



/* FUNCTION 20746 ; VA 0x00a52270 ; FUN_00a52270 */

void __fastcall FUN_00a52270(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  FUN_00a508a0();
  FUN_00a50840();
  FUN_00a507e0();
  FUN_00a507e0();
  FUN_016dedfb(param_1 + 0x44);
  CloseHandle(*(undefined4 *)(param_1 + 0x40));
  CloseHandle(*(undefined4 *)(param_1 + 0x38));
  CloseHandle(*(undefined4 *)(param_1 + 0x3c));
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00a52342. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 20747 ; VA 0x00a52350 ; FUN_00a52350 */

void __thiscall FUN_00a52350(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  piVar2 = (int *)param_2[5];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01674ea0(param_2,0x18);
  return;
}



/* FUNCTION 20748 ; VA 0x00a523b0 ; FUN_00a523b0 */

void FUN_00a523b0(undefined4 *param_1,undefined4 param_2)

{
  FUN_00a50ba0(*param_1,param_2);
  return;
}



/* FUNCTION 20749 ; VA 0x00a523d0 ; FUN_00a523d0 */

void FUN_00a523d0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = *param_1;
  uVar2 = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a50f40(uVar1,uVar2);
  return;
}


