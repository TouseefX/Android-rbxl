/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 12500 ; VA 0x00818b12 ; FUN_00818b12 */

void FUN_00818b12(void)

{
  FUN_00818b20();
  return;
}



/* FUNCTION 12501 ; VA 0x00818b20 ; FUN_00818b20 */

undefined4 __thiscall FUN_00818b20(undefined4 param_1,byte param_2)

{
  FUN_00818790();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x318);
  }
  return param_1;
}



/* FUNCTION 12502 ; VA 0x00818b50 ; FUN_00818b50 */

undefined4 * __thiscall FUN_00818b50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::ISuperCluster::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 12503 ; VA 0x00818b80 ; FUN_00818b80 */

void __thiscall FUN_00818b80(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  undefined4 *puVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint *puStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  uVar4 = FUN_007c7390(*param_2);
  if (uVar4 == 0) {
    cVar3 = FUN_007c7420(*param_2);
    puStack_10 = (uint *)CONCAT31(puStack_10._1_3_,cVar3);
    iVar5 = 0x4c;
    if (cVar3 != '\0') {
      iVar5 = 0x40;
    }
    piVar6 = (int *)(iVar5 + param_1);
    iVar5 = piVar6[1] - *piVar6 >> 2;
    do {
      iVar5 = iVar5 + -1;
      if (iVar5 < 0) {
        puStack_10 = (uint *)FUN_008486e0(*(undefined4 *)(param_1 + 0x2c),0,param_1,puStack_10,0);
        puVar2 = (undefined4 *)piVar6[1];
        if ((undefined4 *)piVar6[2] == puVar2) {
          FUN_006030d0(puVar2,&puStack_10);
        }
        else {
          *puVar2 = puStack_10;
          piVar6[1] = piVar6[1] + 4;
        }
        piVar6 = *(int **)(piVar6[1] + -4);
        goto LAB_00818cbc;
      }
      uVar4 = (**(code **)(*(int *)(*(int *)(*piVar6 + iVar5 * 4) + 0x74) + 0x58))();
    } while (DAT_01d622e0 <= uVar4);
    piVar6 = *(int **)(*piVar6 + iVar5 * 4);
LAB_00818cbc:
    (**(code **)(*piVar6 + 0x14))(param_2);
    (**(code **)(piVar6[0x1d] + 8))();
    return;
  }
  puVar1 = *(uint **)(param_1 + 0x60);
  puVar7 = (uint *)puVar1[1];
  puVar9 = puVar1;
  uStack_c = uVar4;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      if (puVar7[4] < uVar4) {
        puVar8 = (uint *)puVar7[2];
      }
      else {
        puVar8 = (uint *)*puVar7;
        puVar9 = puVar7;
      }
      puVar7 = puVar8;
    } while (*(char *)((int)puVar8 + 0xd) == '\0');
    if ((puVar9 != puVar1) && (puVar9[4] <= uVar4)) goto LAB_00818c00;
  }
  puStack_10 = &uStack_c;
  iVar5 = FUN_005f81a0(&DAT_018bdeda,&puStack_10,&uStack_5);
  FUN_005f83b0(&puStack_10,puVar9,iVar5 + 0x10,iVar5);
  puVar9 = puStack_10;
LAB_00818c00:
  piVar6 = (int *)puVar9[5];
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)FUN_008486e0(*(undefined4 *)(param_1 + 0x2c),uVar4,param_1,0,0);
    puVar9[5] = (uint)piVar6;
  }
  (**(code **)(*piVar6 + 0x14))(param_2);
  (**(code **)(*(int *)(puVar9[5] + 0x74) + 8))();
  return;
}



/* FUNCTION 12504 ; VA 0x00818ce0 ; FUN_00818ce0 */

void __thiscall FUN_00818ce0(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5e18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  cVar2 = (**(code **)(*param_2 + 0x20))();
  iStack_2c = 0;
  iVar5 = 0x4c;
  iStack_28 = 0;
  iStack_24 = 0;
  if (cVar2 != '\0') {
    iVar5 = 0x40;
  }
  piStack_14 = (int *)(iVar5 + (int)param_1);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_2[0x1d] + 0x58))();
  if ((uVar3 == 0) || (DAT_01d622e0 >> 1 < uVar3)) {
    if (iStack_2c == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00616fc0(iStack_2c,iStack_28);
    uVar3 = iStack_24 - iStack_2c & 0xfffffff8;
    iVar5 = iStack_2c;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iStack_2c + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_2c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  else {
    iVar5 = 0;
    uStack_20 = *(undefined4 *)(param_1[0xb] + 0x4e4);
    iStack_18 = piStack_14[1] - *piStack_14 >> 2;
    uVar6 = uVar3;
    while (0 < (int)uVar6) {
      if (iStack_18 <= iVar5) {
        if (0 < (int)uVar6) goto LAB_00818dfc;
        break;
      }
      piVar1 = *(int **)(*piStack_14 + iVar5 * 4);
      if (piVar1 != param_2) {
        iVar4 = (**(code **)(piVar1[0x1d] + 0x58))();
        uVar6 = uVar6 + (iVar4 - DAT_01d622e0);
      }
      iVar5 = iVar5 + 1;
    }
    (**(code **)(*param_2 + 0x10))(&iStack_2c);
    (**(code **)(*piStack_1c + 0x10))(param_2);
    uVar6 = 0;
    if (uVar3 != 0) {
      do {
        FUN_007c8e00(iStack_2c + uVar6 * 8);
        uVar6 = uVar6 + 1;
      } while (uVar6 < uVar3);
    }
    FUN_00616fc0(iStack_2c,iStack_28);
    iStack_28 = iStack_2c;
LAB_00818dfc:
    if (iStack_2c == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_00616fc0(iStack_2c,iStack_28);
    uVar3 = iStack_24 - iStack_2c & 0xfffffff8;
    iVar5 = iStack_2c;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iStack_2c + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_2c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
  }
  FUN_01674ea0(iVar5,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12505 ; VA 0x00818eb0 ; FUN_00818eb0 */

void __thiscall FUN_00818eb0(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  int iStack_10;
  undefined4 *puStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  uVar5 = (**(code **)(*param_2 + 0x1c))();
  if (uVar5 == 0) {
    iVar2 = *(int *)(param_1 + 0x44);
    piVar6 = (int *)FUN_00817fe0(&iStack_10,*(undefined4 *)(param_1 + 0x40),iVar2,&param_2);
    iVar3 = *piVar6;
    if (iVar3 != iVar2) {
      iVar11 = *(int *)(iStack_8 + 0x44) - iVar2;
      FUN_0170cc70(iVar3,iVar2,iVar11);
      *(int *)(iStack_8 + 0x44) = iVar11 + iVar3;
    }
    iVar2 = *(int *)(iStack_8 + 0x50);
    piVar6 = (int *)FUN_00817fe0(&iStack_10,*(undefined4 *)(iStack_8 + 0x4c),iVar2,&param_2);
    iVar3 = *piVar6;
    if (iVar3 != iVar2) {
      iVar11 = *(int *)(iStack_8 + 0x50) - iVar2;
      FUN_0170cc70(iVar3,iVar2,iVar11);
      *(int *)(iStack_8 + 0x50) = iVar11 + iVar3;
    }
  }
  else {
    puVar10 = *(undefined4 **)(param_1 + 0x60);
    iStack_10 = param_1 + 0x60;
    puVar7 = (undefined4 *)puVar10[1];
    cVar1 = *(char *)((int)puVar7 + 0xd);
    puVar4 = puVar10;
    puVar8 = puVar7;
    while (cVar1 == '\0') {
      if ((uint)puVar8[4] < uVar5) {
        puVar9 = (undefined4 *)puVar8[2];
        puVar8 = puVar4;
      }
      else {
        if ((*(char *)((int)puVar10 + 0xd) != '\0') && (uVar5 < (uint)puVar8[4])) {
          puVar10 = puVar8;
        }
        puVar9 = (undefined4 *)*puVar8;
      }
      puVar4 = puVar8;
      puVar8 = puVar9;
      cVar1 = *(char *)((int)puVar9 + 0xd);
    }
    if (*(char *)((int)puVar10 + 0xd) == '\0') {
      puVar7 = (undefined4 *)*puVar10;
    }
    cVar1 = *(char *)((int)puVar7 + 0xd);
    while (puStack_c = puVar4, cVar1 == '\0') {
      if (uVar5 < (uint)puVar7[4]) {
        puVar8 = (undefined4 *)*puVar7;
        puVar10 = puVar7;
      }
      else {
        puVar8 = (undefined4 *)puVar7[2];
      }
      puVar7 = puVar8;
      cVar1 = *(char *)((int)puVar8 + 0xd);
    }
    while (puStack_c != puVar10) {
      FUN_00551320();
    }
    FUN_006a9630(&puStack_c,puVar4,puVar10);
  }
  (**(code **)*param_2)(1);
  *(undefined *)(iStack_8 + 0x75) = 0;
  return;
}



/* FUNCTION 12506 ; VA 0x00818fe0 ; FUN_00818fe0 */

int FUN_00818fe0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00818a30(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 12507 ; VA 0x00819070 ; FUN_00819070 */

int FUN_00819070(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  piStack_14 = param_3;
  uStack_8 = 1;
  iVar4 = FUN_0170d75d(param_2,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Effect::RTTI_Type_Descriptor,0);
  if (iVar4 != 0) {
    iVar4 = FUN_007c8af0(&uStack_18);
  }
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 12508 ; VA 0x00819150 ; FUN_00819150 */

void FUN_00819150(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3);
  return;
}



/* FUNCTION 12509 ; VA 0x00819170 ; FUN_00819170 */

void __thiscall FUN_00819170(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x3a0);
  *param_2 = *(undefined8 *)(param_1 + 0x398);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12510 ; VA 0x00819190 ; FUN_00819190 */

void __thiscall FUN_00819190(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x330);
  *param_2 = *(undefined8 *)(param_1 + 0x328);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12511 ; VA 0x008191e0 ; FUN_008191e0 */

void __thiscall FUN_008191e0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x3ac);
  *param_2 = *(undefined8 *)(param_1 + 0x3a4);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12512 ; VA 0x00819200 ; FUN_00819200 */

void __thiscall FUN_00819200(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x3b8);
  *param_2 = *(undefined8 *)(param_1 + 0x3b0);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12513 ; VA 0x00819220 ; FUN_00819220 */

undefined4 __fastcall FUN_00819220(int param_1)

{
  return *(undefined4 *)(param_1 + 0x58);
}



/* FUNCTION 12514 ; VA 0x00819230 ; FUN_00819230 */

void __thiscall FUN_00819230(int param_1,undefined4 *param_2,undefined4 param_3,byte param_4)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x34 + (param_4 ^ 1) * 8);
  *param_2 = *(undefined4 *)(param_1 + 0x30 + (param_4 ^ 1) * 8);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 12515 ; VA 0x00819260 ; FUN_00819260 */

int __thiscall FUN_00819260(int param_1,byte param_2)

{
  return param_1 + 0x30 + (param_2 ^ 1) * 8;
}



/* FUNCTION 12516 ; VA 0x00819280 ; FUN_00819280 */

void __fastcall FUN_00819280(int param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  uint uVar4;
  
  piVar3 = *(int **)(param_1 + 0x40);
  uVar2 = (*(int *)(param_1 + 0x44) - (int)piVar3) + 3U >> 2;
  uVar4 = 0;
  if (*(int **)(param_1 + 0x44) < piVar3) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    do {
      (**(code **)(*(int *)(*piVar3 + 0x74) + 8))();
      uVar4 = uVar4 + 1;
      piVar3 = piVar3 + 1;
    } while (uVar4 != uVar2);
  }
  piVar3 = *(int **)(param_1 + 0x4c);
  uVar4 = 0;
  uVar2 = (*(int *)(param_1 + 0x50) - (int)piVar3) + 3U >> 2;
  if (*(int **)(param_1 + 0x50) < piVar3) {
    uVar2 = 0;
  }
  if (uVar2 != 0) {
    do {
      (**(code **)(*(int *)(*piVar3 + 0x74) + 8))();
      uVar4 = uVar4 + 1;
      piVar3 = piVar3 + 1;
    } while (uVar4 != uVar2);
  }
  piVar3 = *(int **)(param_1 + 0x60);
  piVar1 = (int *)*piVar3;
  while (piVar1 != piVar3) {
    (**(code **)(*(int *)(piVar1[5] + 0x74) + 8))();
    FUN_00551320();
  }
  return;
}



/* FUNCTION 12517 ; VA 0x00819330 ; FUN_00819330 */

void __thiscall FUN_00819330(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined uVar2;
  int iVar3;
  int *piVar4;
  
  if (param_2 == 2) {
    puVar1 = *(undefined4 **)(param_3 + 4);
    if ((((((puVar1 == (undefined4 *)&DAT_0213f7fc) || (puVar1 == (undefined4 *)&DAT_02138508)) ||
          (puVar1 == (undefined4 *)&DAT_021384d0)) ||
         ((puVar1 == (undefined4 *)&DAT_02138540 || (puVar1 == &DAT_0213f3c0)))) ||
        ((puVar1 == (undefined4 *)&DAT_0213f3f8 ||
         ((puVar1 == (undefined4 *)&DAT_0213f4a0 || (puVar1 == (undefined4 *)&DAT_0213f4d8)))))) ||
       (puVar1 == &DAT_0213f510)) {
      *(undefined *)(param_1 + 0x74) = 1;
      return;
    }
  }
  else if (param_2 == 5) {
    iVar3 = FUN_006bf290();
    *(bool *)(param_1 + 0x78) = iVar3 != 0;
    piVar4 = (int *)FUN_00817fa0();
    if (piVar4 == (int *)0x0) {
      *(undefined *)(param_1 + 0x77) = 0;
      return;
    }
    uVar2 = (**(code **)(*piVar4 + 0x10c))();
    *(undefined *)(param_1 + 0x77) = uVar2;
  }
  return;
}



/* FUNCTION 12518 ; VA 0x008193d0 ; FUN_008193d0 */

void __fastcall FUN_008193d0(int param_1)

{
  *(undefined *)(param_1 + 0x71) = 0;
  return;
}



/* FUNCTION 12519 ; VA 0x008193e0 ; FUN_008193e0 */

void __fastcall FUN_008193e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(undefined4 *)(param_1 + 0x2fc) = 0;
  piVar2 = *(int **)(param_1 + 0x300);
  *(undefined4 *)(param_1 + 0x300) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x304) = 0;
  piVar2 = *(int **)(param_1 + 0x308);
  *(undefined4 *)(param_1 + 0x308) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00773ad0(*(int *)(*(int *)(param_1 + 0x2c) + 0x4ec) + 0x3c);
  return;
}



/* FUNCTION 12520 ; VA 0x00819480 ; FUN_00819480 */

void __thiscall FUN_00819480(int param_1,char param_2)

{
  *(char *)(param_1 + 0x75) = param_2;
  if (param_2 == '\0') {
    *(undefined4 *)(param_1 + 0x7c) = 0xffffffff;
  }
  return;
}



/* FUNCTION 12521 ; VA 0x008194a0 ; FUN_008194a0 */

undefined4 __fastcall FUN_008194a0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  float *pfVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  
  if ((DAT_01d61fe8 != '\0') || (*(char *)(param_1 + 0x78) == '\0')) {
    if ((*(char *)(param_1 + 0x77) != '\0') &&
       (((iStack_c = param_1, cVar4 = FUN_00c78580(), cVar4 != '\0' &&
         (iVar5 = FUN_00817fa0(), iVar5 != 0)) && (*(char *)(iVar5 + 0x15c) != '\0')))) {
      FUN_00d5c5d0(&fStack_30);
      piVar6 = (int *)FUN_00d5be40();
      if (((piVar6 != (int *)0x0) &&
          (pfVar7 = (float *)FUN_00d5bec0(),
          (NAN(*pfVar7) || NAN(DAT_018ce2f0)) != (*pfVar7 == DAT_018ce2f0))) &&
         (((**(code **)(*piVar6 + 0xd4))(&fStack_20), fStack_28 <= fStack_20 ||
          (((fStack_24 <= fStack_1c || (fStack_18 <= fStack_30)) || (fStack_14 <= fStack_2c)))))) {
        *(undefined2 *)(param_1 + 0x74) = 1;
        *(undefined *)(param_1 + 0x76) = 1;
        return 1;
      }
      *(undefined *)(param_1 + 0x76) = 0;
      if (*(int *)(param_1 + 0x7c) != 0) {
        iVar5 = 0;
        puVar10 = *(undefined4 **)(param_1 + 0x40);
        iStack_8 = 0;
        uStack_10 = (*(int *)(param_1 + 0x44) - (int)puVar10) + 3U >> 2;
        if (*(undefined4 **)(param_1 + 0x44) < puVar10) {
          uStack_10 = 0;
        }
        iVar8 = iStack_8;
        if (uStack_10 != 0) {
          uVar9 = 0;
          do {
            iVar8 = (**(code **)(*(int *)*puVar10 + 0x24))();
            uVar9 = uVar9 + 1;
            puVar10 = puVar10 + 1;
            iVar5 = iVar5 + iVar8;
            param_1 = iStack_c;
            iVar8 = iVar5;
          } while (uVar9 != uStack_10);
        }
        iStack_8 = iVar8;
        puVar10 = *(undefined4 **)(param_1 + 0x4c);
        uStack_10 = (*(int *)(param_1 + 0x50) - (int)puVar10) + 3U >> 2;
        if (*(undefined4 **)(param_1 + 0x50) < puVar10) {
          uStack_10 = 0;
        }
        iVar5 = iStack_8;
        if (uStack_10 != 0) {
          uVar9 = 0;
          do {
            iVar8 = (**(code **)(*(int *)*puVar10 + 0x24))();
            uVar9 = uVar9 + 1;
            puVar10 = puVar10 + 1;
            iVar5 = iVar5 + iVar8;
            param_1 = iStack_c;
          } while (uVar9 != uStack_10);
        }
        iStack_8 = iVar5;
        puVar10 = *(undefined4 **)(param_1 + 0x60);
        puVar1 = (undefined4 *)*puVar10;
        iVar5 = iStack_8;
        while (puVar1 != puVar10) {
          iVar8 = (**(code **)(*(int *)puVar1[5] + 0x24))();
          iVar5 = iVar5 + iVar8;
          puVar2 = (undefined4 *)puVar1[2];
          param_1 = iStack_c;
          if (*(char *)((int)puVar2 + 0xd) == '\0') {
            cVar4 = *(char *)((int)*puVar2 + 0xd);
            puVar1 = puVar2;
            puVar2 = (undefined4 *)*puVar2;
            while (cVar4 == '\0') {
              cVar4 = *(char *)((int)*puVar2 + 0xd);
              puVar1 = puVar2;
              puVar2 = (undefined4 *)*puVar2;
            }
          }
          else {
            cVar4 = *(char *)((int)puVar1[1] + 0xd);
            puVar3 = (undefined4 *)puVar1[1];
            puVar2 = puVar1;
            while ((puVar1 = puVar3, cVar4 == '\0' && (puVar2 == (undefined4 *)puVar1[2]))) {
              cVar4 = *(char *)((int)puVar1[1] + 0xd);
              puVar3 = (undefined4 *)puVar1[1];
              puVar2 = puVar1;
            }
          }
        }
        iStack_8 = iVar5;
        if (iVar5 != *(int *)(param_1 + 0x7c)) {
          *(undefined *)(param_1 + 0x75) = 0;
          *(int *)(param_1 + 0x7c) = iVar5;
        }
      }
      FUN_00819900();
      return 1;
    }
    if (*(char *)(param_1 + 0x78) == '\0') {
      return 0;
    }
  }
  *(undefined2 *)(param_1 + 0x74) = 1;
  *(undefined *)(param_1 + 0x76) = 1;
  return 1;
}



/* FUNCTION 12522 ; VA 0x008196b0 ; FUN_008196b0 */

undefined4 * __thiscall FUN_008196b0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_44 [16];
  undefined auStack_34 [12];
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5e68;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar4 = FUN_01675290(DAT_01eb3ab0);
  uStack_8 = 0;
  uStack_28 = uVar4;
  if (((*(char *)(param_1 + 0x76) == '\0') && (*(short *)(param_1 + 0x2c4) != 0)) &&
     (*(short *)(param_1 + 0x2c6) != 0)) {
    iVar6 = *(int *)(param_1 + 0x2fc);
    if (((iVar6 == 0) || (*(int *)(iVar6 + 0x28) != (int)*(short *)(param_1 + 0x2c4))) ||
       (*(int *)(iVar6 + 0x2c) != (int)*(short *)(param_1 + 0x2c6))) {
      uStack_8 = 1;
      puVar5 = (undefined4 *)
               FUN_0147c180(auStack_24,0,3,(int)*(short *)(param_1 + 0x2c4),
                            (int)*(short *)(param_1 + 0x2c6),3);
      uVar2 = *puVar5;
      uVar3 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 *)(param_1 + 0x304) = uVar2;
      piStack_1c = *(int **)(param_1 + 0x308);
      *(undefined4 *)(param_1 + 0x308) = uVar3;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar6 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar6 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      FUN_00550b30();
      piStack_20 = *(int **)(param_1 + 8);
      piStack_1c = (int *)FUN_0147d4b0();
      uStack_8._0_1_ = 2;
      FUN_0147d420(param_1 + 0x304);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      puVar5 = (undefined4 *)FUN_0147bf30(auStack_34,auStack_44,piStack_1c);
      uVar2 = *puVar5;
      uVar3 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      *(undefined4 *)(param_1 + 0x2fc) = uVar2;
      piStack_20 = *(int **)(param_1 + 0x300);
      *(undefined4 *)(param_1 + 0x300) = uVar3;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[1] + -1;
        piStack_20[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piStack_20 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      FUN_00550b30();
      FUN_00550b30();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00550b30();
      FUN_00773ad0(param_1 + 0x304);
    }
  }
  else if (*(int *)(param_1 + 0x2fc) != 0) {
    FUN_008193e0();
  }
  iVar6 = *(int *)(param_1 + 0x300);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = *(int *)(param_1 + 0x300);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x2fc);
  param_2[1] = iVar6;
  uStack_8 = 5;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12523 ; VA 0x00819865 ; Catch@00819865 */

undefined * Catch_00819865(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x28) + 4))(6);
  FUN_0086edd0(3,uVar1);
  FUN_008193e0();
  return &DAT_00819888;
}



/* FUNCTION 12524 ; VA 0x00819900 ; FUN_00819900 */

void __fastcall FUN_00819900(int param_1)

{
  undefined8 uVar1;
  ulonglong uVar2;
  undefined4 *puVar3;
  int iVar4;
  float10 fVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  undefined8 uStack_50;
  float fStack_48;
  float fStack_3c;
  undefined8 uStack_38;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  uint uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b5e88;
  pvStack_1c = ExceptionList;
  if (*(char *)(param_1 + 0x74) != '\0') {
    ExceptionList = &pvStack_1c;
    *(undefined2 *)(param_1 + 0x74) = 0;
    FUN_00d5c5d0(&fStack_60);
    fStack_48 = fStack_54 - fStack_5c;
    fStack_3c = fStack_58 - fStack_60;
    fStack_2c = (float)DAT_01d61fb8;
    fVar8 = 0.0;
    if (0.0 <= fStack_48) {
      fVar8 = fStack_48;
    }
    fStack_28 = fStack_2c;
    if (fVar8 <= fStack_2c) {
      fStack_28 = fVar8;
    }
    fVar8 = 0.0;
    if (0.0 <= fStack_3c) {
      fVar8 = fStack_3c;
    }
    if (fVar8 <= fStack_2c) {
      fStack_2c = fVar8;
    }
    puVar3 = (undefined4 *)FUN_01166750(&fStack_2c);
    *(undefined4 *)(param_1 + 0x2c4) = *puVar3;
    iVar4 = (**(code **)(**(int **)(param_1 + 8) + 0x40))();
    uStack_24 = DAT_018ce2f4;
    if ((*(char *)(iVar4 + 9) != '\0') && (*(char *)(iVar4 + 0x3b) == '\0')) {
      uStack_24 = DAT_018e452c;
    }
    iVar4 = FUN_00d40720();
    if (iVar4 != 0) {
      fStack_28 = (float)(uStack_24 ^ DAT_018c4ea0);
      fVar5 = (float10)FUN_00d22f10();
      fStack_30 = (float)fVar5;
      if ((NAN(fStack_30) || NAN(fStack_28)) == (fStack_30 == fStack_28)) {
        FUN_008e9960(*(undefined4 *)(param_1 + 0x58));
        uStack_14 = 0;
        FUN_00d25be0(fStack_28);
        uStack_14 = 0xffffffff;
        FUN_008eb200();
      }
    }
    FUN_007cd9c0(*(int *)(param_1 + 0x58) + 0x354);
    FUN_007cd880(*(undefined4 *)(*(int *)(param_1 + 0x58) + 900),fStack_3c / fStack_48,
                 (float)DAT_01d6cb00,uStack_24,0);
    iVar4 = *(int *)(param_1 + 0x58);
    uStack_38 = *(undefined8 *)(iVar4 + 0x328);
    fStack_30 = *(float *)(iVar4 + 0x330);
    dVar7 = (double)((float)uStack_38 * (float)uStack_38 * DAT_018e1340);
    FUN_017267a0();
    fStack_48 = (float)dVar7;
    dVar7 = (double)(uStack_38._4_4_ * uStack_38._4_4_ * DAT_018e1340);
    FUN_017267a0();
    fStack_3c = (float)dVar7;
    dVar7 = (double)(fStack_30 * fStack_30 * DAT_018e1340);
    FUN_017267a0();
    fVar6 = DAT_018ce2f8 - *(float *)(iVar4 + 0x344);
    *(float *)(param_1 + 0x2c8) = fStack_48;
    *(float *)(param_1 + 0x2cc) = fStack_3c;
    *(float *)(param_1 + 0x2d0) = (float)dVar7;
    fVar8 = 0.0;
    if (0.0 <= fVar6) {
      fVar8 = fVar6;
    }
    fVar6 = DAT_018ce2f8;
    if (fVar8 <= DAT_018ce2f8) {
      fVar6 = fVar8;
    }
    *(float *)(param_1 + 0x2d4) = fVar6;
    uVar1 = *(undefined8 *)(*(int *)(param_1 + 0x58) + 0x398);
    fVar8 = *(float *)(*(int *)(param_1 + 0x58) + 0x3a0);
    uStack_50._0_4_ = (float)uVar1;
    uStack_50._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
    *(float *)(param_1 + 0x2d8) = (float)uStack_50 * (float)uStack_50;
    *(float *)(param_1 + 0x2dc) = uStack_50._4_4_ * uStack_50._4_4_;
    *(float *)(param_1 + 0x2e0) = fVar8 * fVar8;
    uVar1 = *(undefined8 *)(*(int *)(param_1 + 0x58) + 0x3a4);
    fStack_48 = *(float *)(*(int *)(param_1 + 0x58) + 0x3ac);
    uStack_50._0_4_ = (float)uVar1;
    uStack_50._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
    *(float *)(param_1 + 0x2e8) = uStack_50._4_4_ * uStack_50._4_4_;
    *(float *)(param_1 + 0x2e4) = (float)uStack_50 * (float)uStack_50;
    *(float *)(param_1 + 0x2ec) = fStack_48 * fStack_48;
    uVar2 = *(ulonglong *)(*(int *)(param_1 + 0x58) + 0x3b0);
    fStack_30 = *(float *)(*(int *)(param_1 + 0x58) + 0x3b8);
    uStack_38._0_4_ = (float)uVar2;
    uStack_50 = uVar2 & 0xffffffff;
    uStack_38._4_4_ = (float)(uVar2 >> 0x20);
    dVar7 = (double)((float)uStack_38 * (float)uStack_38 + uStack_38._4_4_ * uStack_38._4_4_ +
                    fStack_30 * fStack_30);
    uStack_38 = uVar2;
    FUN_017267a0();
    fVar8 = DAT_018ce2f8 / (float)dVar7;
    *(ulonglong *)(param_1 + 0x2f0) = CONCAT44(uStack_38._4_4_ * fVar8,(float)uStack_50 * fVar8);
    *(float *)(param_1 + 0x2f8) = fStack_30 * fVar8;
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12525 ; VA 0x00819cb0 ; FUN_00819cb0 */

void __thiscall FUN_00819cb0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  uVar3 = (uint)((int)*(undefined4 **)(param_1 + 0x44) + (3 - (int)puVar4)) >> 2;
  uVar5 = 0;
  if (*(undefined4 **)(param_1 + 0x44) < puVar4) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      (**(code **)(*(int *)*puVar4 + 4))(param_2,param_3,param_4);
      puVar4 = puVar4 + 1;
      uVar5 = uVar5 + 1;
    } while (uVar5 != uVar3);
  }
  uVar5 = 0;
  puVar4 = *(undefined4 **)(param_1 + 0x4c);
  uVar3 = (uint)((int)*(undefined4 **)(param_1 + 0x50) + (3 - (int)puVar4)) >> 2;
  if (*(undefined4 **)(param_1 + 0x50) < puVar4) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      (**(code **)(*(int *)*puVar4 + 4))(param_2,param_3,param_4);
      puVar4 = puVar4 + 1;
      uVar5 = uVar5 + 1;
    } while (uVar5 != uVar3);
  }
  piVar1 = *(int **)(param_1 + 0x60);
  piVar2 = (int *)*piVar1;
  while (piVar2 != piVar1) {
    (**(code **)(*(int *)piVar2[5] + 4))(param_2,param_3,param_4);
    FUN_00551320();
  }
  return;
}



/* FUNCTION 12526 ; VA 0x00819d80 ; FUN_00819d80 */

int __thiscall FUN_00819d80(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  uint uVar13;
  
  iVar2 = ((int)param_2 - *param_1) / 0x18;
  iVar3 = (param_1[1] - *param_1) / 0x18;
  if (iVar3 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = (param_1[2] - *param_1) / 0x18;
  uVar13 = iVar3 + 1;
  if (uVar4 <= 0xaaaaaaa - (uVar4 >> 1)) {
    uVar13 = (uVar4 >> 1) + uVar4;
    if (uVar13 < iVar3 + 1U) {
      uVar13 = iVar3 + 1U;
    }
  }
  puVar8 = (undefined4 *)FUN_00577fb0(uVar13);
  puVar9 = puVar8 + iVar2 * 6;
  uVar5 = param_3[1];
  uVar6 = param_3[2];
  uVar7 = param_3[3];
  *puVar9 = *param_3;
  puVar9[1] = uVar5;
  puVar9[2] = uVar6;
  puVar9[3] = uVar7;
  *(undefined8 *)(puVar9 + 4) = *(undefined8 *)(param_3 + 4);
  puVar12 = (undefined4 *)param_1[1];
  puVar10 = (undefined4 *)*param_1;
  puVar11 = puVar8;
  if (param_2 == puVar12) {
    for (; puVar10 != puVar12; puVar10 = puVar10 + 6) {
      uVar5 = puVar10[1];
      uVar6 = puVar10[2];
      uVar7 = puVar10[3];
      *puVar11 = *puVar10;
      puVar11[1] = uVar5;
      puVar11[2] = uVar6;
      puVar11[3] = uVar7;
      *(undefined8 *)(puVar11 + 4) = *(undefined8 *)(puVar10 + 4);
      puVar11 = puVar11 + 6;
    }
  }
  else {
    if (puVar10 != param_2) {
      do {
        uVar5 = puVar10[1];
        uVar6 = puVar10[2];
        uVar7 = puVar10[3];
        *puVar11 = *puVar10;
        puVar11[1] = uVar5;
        puVar11[2] = uVar6;
        puVar11[3] = uVar7;
        puVar1 = (undefined8 *)(puVar10 + 4);
        puVar10 = puVar10 + 6;
        *(undefined8 *)(puVar11 + 4) = *puVar1;
        puVar11 = puVar11 + 6;
      } while (puVar10 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      do {
        uVar5 = param_2[1];
        uVar6 = param_2[2];
        uVar7 = param_2[3];
        puVar9[6] = *param_2;
        puVar9[7] = uVar5;
        puVar9[8] = uVar6;
        puVar9[9] = uVar7;
        puVar1 = (undefined8 *)(param_2 + 4);
        param_2 = param_2 + 6;
        *(undefined8 *)(puVar9 + 10) = *puVar1;
        puVar9 = puVar9 + 6;
      } while (param_2 != puVar12);
    }
  }
  FUN_00616d60(puVar8,iVar3 + 1,uVar13);
  return *param_1 + iVar2 * 0x18;
}



/* FUNCTION 12527 ; VA 0x00819ed0 ; FUN_00819ed0 */

void __thiscall FUN_00819ed0(uint *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  
  uVar10 = *param_1;
  uVar11 = (int)(param_1[1] - uVar10) >> 4;
  uVar9 = (int)(param_1[2] - uVar10) >> 4;
  if (param_2 <= uVar9) {
    if (param_2 <= uVar11) {
      if (param_2 != uVar11) {
        param_1[1] = param_2 * 0x10 + uVar10;
      }
      return;
    }
    uVar10 = FUN_0081a890(param_1[1],param_2 - uVar11);
    param_1[1] = uVar10;
    return;
  }
  if (0xfffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar10 = param_2;
  if ((uVar9 <= 0xfffffff - (uVar9 >> 1)) && (uVar10 = (uVar9 >> 1) + uVar9, uVar10 < param_2)) {
    uVar10 = param_2;
  }
  uVar9 = uVar10 * 0x10;
  if (uVar10 < 0x10000000) {
    uVar10 = uVar9;
    if (0xfff < uVar9) goto LAB_00819f3b;
    if (uVar9 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_01674e20(uVar9);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_00819f3b:
    uVar5 = uVar10 + 0x23;
    if (uVar5 <= uVar10) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_0081a02f;
    uVar10 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar10 - 4) = iVar6;
  }
  FUN_0081a890(uVar11 * 0x10 + uVar10,param_2 - uVar11);
  puVar7 = (undefined4 *)*param_1;
  puVar8 = (undefined4 *)param_1[1];
  if (puVar7 != puVar8) {
    iVar6 = uVar10 - (int)puVar7;
    do {
      uVar2 = puVar7[1];
      uVar3 = puVar7[2];
      uVar4 = puVar7[3];
      puVar1 = (undefined4 *)(iVar6 + (int)puVar7);
      *puVar1 = *puVar7;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      puVar7 = puVar7 + 4;
    } while (puVar7 != puVar8);
    puVar7 = (undefined4 *)*param_1;
  }
  if (puVar7 != (undefined4 *)0x0) {
    uVar11 = param_1[2] - (int)puVar7 & 0xfffffff0;
    puVar8 = puVar7;
    if (0xfff < uVar11) {
      puVar8 = (undefined4 *)puVar7[-1];
      uVar11 = uVar11 + 0x23;
      if (0x1f < (uint)((int)puVar7 + (-4 - (int)puVar8))) {
LAB_0081a02f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar11);
  }
  *param_1 = uVar10;
  param_1[1] = param_2 * 0x10 + uVar10;
  param_1[2] = uVar9 + uVar10;
  return;
}



/* FUNCTION 12528 ; VA 0x0081a040 ; FUN_0081a040 */

int * __thiscall FUN_0081a040(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  undefined auStack_74 [88];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b5f30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  uStack_8 = 2;
  uStack_7 = 0;
  piStack_1c = param_1;
  FUN_016f4053(param_1 + 5,8,6,FUN_0075dc70,FUN_00550b30);
  uStack_8 = 3;
  FUN_016f4053(param_1 + 0x11,8,6,FUN_0075dc70,FUN_00550b30);
  uStack_8 = 4;
  iVar4 = 6;
  do {
    FUN_00791e90();
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0x3f800000;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0x3f800000;
  param_1[0x47] = 0x43fa0000;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0x3f800000;
  param_1[0x51] = 0x437a0000;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 3;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  *(undefined *)(param_1 + 0x62) = 0;
  _uStack_8 = CONCAT31(uStack_7,8);
  piVar1 = (int *)FUN_0147c1b0(auStack_18,&DAT_01eb3ac4,3,0x18);
  iVar4 = *piVar1;
  iVar2 = piVar1[1];
  *piVar1 = 0;
  piVar1[1] = 0;
  param_1[1] = iVar4;
  piVar1 = (int *)param_1[2];
  param_1[2] = iVar2;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar4 = piStack_14[2] + -1;
      piStack_14[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  iVar4 = FUN_0081a930(*(undefined4 *)(param_2 + 0x3c),param_1 + 1,3);
  piStack_14 = (int *)param_1[3];
  param_1[3] = iVar4;
  if (piStack_14 != (int *)0x0) {
    piVar1 = *(int **)((int)piStack_14 + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[1] + -1;
      piVar1[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar4 = piVar1[2] + -1;
        piVar1[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(piStack_14,0x18);
  }
  iVar2 = FUN_0081a930(*(undefined4 *)(param_2 + 0x3c),param_1 + 1,1);
  iVar4 = param_1[4];
  param_1[4] = iVar2;
  if (iVar4 != 0) {
    piVar1 = *(int **)(iVar4 + 4);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar3 = piVar1 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar4,0x18);
  }
  FUN_00d6b090();
  uStack_8 = 9;
  FUN_0081b210(param_1 + 5,auStack_bc,auStack_d4,auStack_a4,auStack_8c,auStack_ec,auStack_74);
  _uStack_8 = CONCAT31(uStack_7,8);
  FUN_0081a520();
  FUN_0081ca60();
  iVar4 = 6;
  piVar1 = param_1 + 0x1f;
  do {
    piVar3 = (int *)FUN_011669a0();
    piVar1[-2] = *piVar3;
    piVar1[-1] = piVar3[1];
    *piVar1 = piVar3[2];
    piVar1[1] = piVar3[3];
    iVar4 = iVar4 + -1;
    piVar1 = piVar1 + 4;
  } while (iVar4 != 0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12529 ; VA 0x0081a3c0 ; FUN_0081a3c0 */

int __fastcall FUN_0081a3c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0081a7c0();
  FUN_0081a7c0();
  piVar2 = *(int **)(param_1 + 0x14c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x124);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x44,8,6,FUN_00550b30);
  iVar4 = FUN_016f32d1(param_1 + 0x14,8,6,FUN_00550b30);
  iVar3 = *(int *)(param_1 + 0x10);
  if (iVar3 != 0) {
    piVar2 = *(int **)(iVar3 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    iVar4 = FUN_01674ea0(iVar3,0x18);
  }
  iVar3 = *(int *)(param_1 + 0xc);
  if (iVar3 != 0) {
    piVar2 = *(int **)(iVar3 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    iVar4 = FUN_01674ea0(iVar3,0x18);
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 12530 ; VA 0x0081a520 ; FUN_0081a520 */

void __fastcall FUN_0081a520(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x110);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xfc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0xf;
  *(undefined *)(param_1 + 0xfc) = 0;
  uVar1 = *(uint *)(param_1 + 0xf8);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xe4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0xf;
  *(undefined *)(param_1 + 0xe4) = 0;
  uVar1 = *(uint *)(param_1 + 0xe0);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xcc);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0xe0) = 0xf;
  *(undefined *)(param_1 + 0xcc) = 0;
  uVar1 = *(uint *)(param_1 + 200);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xb4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 200) = 0xf;
  *(undefined *)(param_1 + 0xb4) = 0;
  uVar1 = *(uint *)(param_1 + 0xb0);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x9c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  uVar1 = *(uint *)(param_1 + 0x98);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x84);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0xf;
  *(undefined *)(param_1 + 0x84) = 0;
  uVar1 = *(uint *)(param_1 + 0x80);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x6c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081a7b3;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x7c) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0xf;
  *(undefined *)(param_1 + 0x6c) = 0;
  uVar1 = *(uint *)(param_1 + 0x68);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x54);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0081a7b3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0xf;
  *(undefined *)(param_1 + 0x54) = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 12531 ; VA 0x0081a7c0 ; FUN_0081a7c0 */

void __fastcall FUN_0081a7c0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar2 = (int *)param_1[5];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = param_1[3];
  if (iVar3 != 0) {
    piVar2 = *(int **)(iVar3 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar3,0x18);
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar5 = param_1[2] - iVar3 & 0xfffffff0;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12532 ; VA 0x0081a890 ; FUN_0081a890 */

void FUN_0081a890(undefined4 *param_1,int param_2)

{
  if (param_2 != 0) {
    do {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1 = param_1 + 4;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 12533 ; VA 0x0081a8d0 ; FUN_0081a8d0 */

void __thiscall FUN_0081a8d0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  puVar8 = (undefined4 *)FUN_00577fb0(param_2);
  puVar3 = (undefined4 *)param_1[1];
  puVar7 = puVar8;
  for (puVar9 = (undefined4 *)*param_1; puVar9 != puVar3; puVar9 = puVar9 + 6) {
    uVar4 = puVar9[1];
    uVar5 = puVar9[2];
    uVar6 = puVar9[3];
    *puVar7 = *puVar9;
    puVar7[1] = uVar4;
    puVar7[2] = uVar5;
    puVar7[3] = uVar6;
    *(undefined8 *)(puVar7 + 4) = *(undefined8 *)(puVar9 + 4);
    puVar7 = puVar7 + 6;
  }
  FUN_00616d60(puVar8,(iVar1 - iVar2) / 0x18,param_2);
  return;
}



/* FUNCTION 12534 ; VA 0x0081a930 ; FUN_0081a930 */

undefined4 FUN_0081a930(int *param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  float *pfVar3;
  float *pfVar4;
  uint uVar5;
  int iVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined auStack_7c [4];
  int *piStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  int *piStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  int iStack_4c;
  float fStack_48;
  int iStack_44;
  float fStack_40;
  undefined8 uStack_3c;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  int iStack_24;
  float *pfStack_20;
  float *pfStack_1c;
  float fStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5faf;
  pvStack_10 = ExceptionList;
  fStack_18 = 0.0;
  iStack_24 = 0;
  pfStack_20 = (float *)0x0;
  pfStack_14 = (float *)0x0;
  pfStack_1c = (float *)0x0;
  uStack_8 = 0;
  uVar5 = (param_3 + 2) * param_3 * 2 - 2;
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    if (0xaaaaaaa < uVar5) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_0081a8d0(uVar5);
    pfStack_14 = pfStack_1c;
    fStack_18 = (float)iStack_24;
  }
  uStack_3c = 0;
  fStack_34 = 0.0;
  fStack_2c = 0.0;
  fStack_28 = 0.0;
  fStack_30 = -NAN;
  iStack_4c = 0;
  pfStack_1c = pfStack_14;
  if (0 < param_3) {
    fStack_60 = 0.0;
    fStack_6c = 0.0;
    fVar10 = DAT_018ce2f8;
    iStack_24 = (int)fStack_18;
    fStack_18 = (float)param_3;
    do {
      iStack_44 = iStack_4c + 1;
      fVar7 = (float)iStack_4c / fStack_18;
      fVar9 = (float)iStack_44 / fStack_18;
      fVar8 = fVar7 + 0.0;
      fStack_48 = fVar10 - (fVar7 + fVar7);
      fStack_28 = fVar9 + 0.0;
      fStack_40 = fVar10 - (fVar9 + fVar9);
      pfVar4 = pfStack_14;
      pfVar3 = (float *)fStack_28;
      if (0 < iStack_4c) {
        uStack_3c = CONCAT44(fStack_40,DAT_018f7864);
        fStack_34 = 0.0;
        fStack_2c = 0.0;
        if (pfStack_14 == pfStack_20) {
          pfStack_14 = (float *)fStack_28;
          FUN_00819d80(pfStack_20,&uStack_3c);
          pfVar4 = pfStack_1c;
          fVar10 = DAT_018ce2f8;
          pfVar3 = pfStack_14;
        }
        else {
          *pfStack_20 = DAT_018f7864;
          pfStack_20[1] = fStack_40;
          pfStack_20[2] = 0.0;
          pfStack_20[3] = fStack_30;
          *(ulonglong *)(pfStack_20 + 4) = (ulonglong)(uint)fStack_28 << 0x20;
          pfStack_20 = pfStack_20 + 6;
          pfVar3 = (float *)fStack_28;
        }
      }
      pfStack_14 = pfVar3;
      iVar6 = 0;
      fStack_70 = fStack_48;
      fStack_64 = fStack_40;
      do {
        fStack_34 = fStack_60;
        fVar7 = (float)iVar6 / fStack_18;
        fStack_40 = fVar7 + 0.0;
        fStack_68 = (fVar7 + fVar7) - fVar10;
        uStack_3c = CONCAT44(fStack_64,fStack_68);
        piStack_50 = (int *)fStack_68;
        if (pfVar4 == pfStack_20) {
          fStack_2c = fStack_40;
          fStack_28 = (float)pfStack_14;
          FUN_00819d80(pfStack_20,&uStack_3c);
          pfVar4 = pfStack_1c;
        }
        else {
          *pfStack_20 = fStack_68;
          pfStack_20[1] = fStack_64;
          pfStack_20[2] = fStack_60;
          pfStack_20[3] = fStack_30;
          *(ulonglong *)(pfStack_20 + 4) = CONCAT44(pfStack_14,fStack_40);
          pfStack_20 = pfStack_20 + 6;
        }
        fStack_74 = (float)piStack_50;
        uStack_3c = CONCAT44(fStack_70,piStack_50);
        fStack_34 = fStack_6c;
        fStack_2c = fStack_40;
        fStack_28 = fVar8;
        if (pfVar4 == pfStack_20) {
          FUN_00819d80(pfStack_20,&uStack_3c);
          pfVar4 = pfStack_1c;
        }
        else {
          *pfStack_20 = (float)piStack_50;
          pfStack_20[1] = fStack_70;
          pfStack_20[2] = fStack_6c;
          pfStack_20[3] = fStack_30;
          *(ulonglong *)(pfStack_20 + 4) = CONCAT44(fVar8,fStack_40);
          pfStack_20 = pfStack_20 + 6;
        }
        fVar10 = DAT_018ce2f8;
        iVar6 = iVar6 + 1;
      } while (iVar6 <= param_3);
      pfStack_14 = pfVar4;
      if (iStack_4c < param_3 + -1) {
        uStack_3c = CONCAT44(fStack_48,DAT_018ce2f8);
        fStack_34 = 0.0;
        fStack_2c = 1.0;
        if (pfVar4 == pfStack_20) {
          fStack_28 = fVar8;
          FUN_00819d80(pfStack_20,&uStack_3c);
          pfStack_14 = pfStack_1c;
          fVar10 = DAT_018ce2f8;
        }
        else {
          *pfStack_20 = DAT_018ce2f8;
          pfStack_20[1] = fStack_48;
          pfStack_20[2] = 0.0;
          pfStack_20[3] = fStack_30;
          *(ulonglong *)(pfStack_20 + 4) = CONCAT44(fVar8,0x3f800000);
          pfStack_20 = pfStack_20 + 6;
          fStack_28 = fVar8;
        }
      }
      iStack_4c = iStack_44;
    } while (iStack_44 < param_3);
    fStack_18 = (float)iStack_24;
  }
  iStack_44 = ((int)pfStack_20 - (int)fStack_18) / 0x18;
  iVar6 = iStack_44 * 0x18;
  iStack_24 = (int)fStack_18;
  (**(code **)(*param_1 + 0x3c))(&piStack_5c,0,iVar6,0x18,0);
  fVar10 = fStack_18;
  uStack_8._0_1_ = 1;
  (**(code **)(*piStack_5c + 0x18))(0,fStack_18,iVar6);
  uStack_54 = 0;
  piStack_50 = (int *)0x0;
  uStack_8._0_1_ = 2;
  FUN_0147c0e0(auStack_7c,param_2,&piStack_5c,&uStack_54);
  piVar2 = piStack_50;
  uStack_8._0_1_ = 4;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_50[1] + -1;
    piStack_50[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iVar6 == 0) {
    param_3 = 0;
  }
  else {
    param_3 = FUN_0147c720(auStack_7c,3,0,0,iStack_44);
  }
  if (piStack_78 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_78[1] + -1;
    piStack_78[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_78)();
      LOCK();
      iVar6 = piStack_78[2] + -1;
      piStack_78[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_78 + 4))();
      }
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_58[1] + -1;
    piStack_58[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      piVar2 = piStack_58 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  if (fVar10 != 0.0) {
    uVar5 = (((int)pfStack_14 - (int)fVar10) / 0x18) * 0x18;
    fVar7 = fVar10;
    if (0xfff < uVar5) {
      fVar7 = *(float *)((int)fVar10 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < ((int)fVar10 - (int)fVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(fVar7,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 12535 ; VA 0x0081adf0 ; FUN_0081adf0 */

void __thiscall FUN_0081adf0(int param_1,uint param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_c = (int)((float)(int)param_2 * DAT_018fabe0);
  iStack_8 = param_1;
  FUN_0081c620(param_1,param_2 - iStack_c);
  iVar4 = *(int *)(param_1 + 0x154);
  param_2 = 0;
  if (*(int *)(param_1 + 0x158) - iVar4 >> 4 != 0) {
    iVar5 = 0;
    do {
      uVar2 = FUN_01166120();
      FUN_011655d0(&fStack_18,uVar2);
      fVar6 = fStack_10 * DAT_01901f60;
      *(ulonglong *)(iVar5 + iVar4) = CONCAT44(fStack_14 * DAT_01901f60,fStack_18 * DAT_01901f60);
      *(float *)(iVar5 + 8 + iVar4) = fVar6;
      iVar3 = FUN_0171d737();
      fVar9 = DAT_018fde64;
      fVar6 = DAT_018fabdc;
      fVar8 = ((float)iVar3 * DAT_018ce2f4) / DAT_01901f68 + DAT_018fde64;
      *(float *)(iVar5 + 0xc + iVar4) = fVar8;
      fVar7 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                      DAT_018c0da0._4_4_,
                                      SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      if (fVar6 <= fVar7) {
        if (fVar9 <= fVar7) {
          if (fVar7 < DAT_01901f38) {
            fVar8 = fVar8 * DAT_0190193c;
          }
        }
        else {
          fVar8 = fVar8 * DAT_018e4440;
        }
      }
      else {
        fVar8 = fVar8 * DAT_01901f38;
      }
      param_2 = param_2 + 1;
      *(float *)(iVar5 + 0xc + iVar4) = fVar8 * fVar8;
      iVar5 = iVar5 + 0x10;
      iVar4 = *(int *)(iStack_8 + 0x154);
    } while (param_2 < (uint)(*(int *)(iStack_8 + 0x158) - iVar4 >> 4));
  }
  iVar5 = iStack_8;
  piVar1 = (int *)(iStack_8 + 0x16c);
  FUN_0081c620(iStack_8,iStack_c);
  iVar4 = *piVar1;
  param_2 = 0;
  if (*(int *)(iVar5 + 0x170) - iVar4 >> 4 != 0) {
    iVar5 = 0;
    do {
      uVar2 = FUN_01166120();
      FUN_011655d0(&fStack_18,uVar2);
      fStack_14 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                          DAT_018c0da0._4_4_,
                                          SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      fVar6 = fStack_10 * DAT_01901f60;
      *(ulonglong *)(iVar5 + iVar4) = CONCAT44(fStack_14 * DAT_01901f60,fStack_18 * DAT_01901f60);
      *(float *)(iVar5 + 8 + iVar4) = fVar6;
      iVar3 = FUN_0171d737();
      fVar6 = ((float)iVar3 * DAT_018ce2f4) / DAT_01901f68 + DAT_018fabe0;
      *(float *)(iVar5 + 0xc + iVar4) = fVar6;
      fVar9 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                      DAT_018c0da0._4_4_,
                                      SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      if (DAT_018fde64 <= fVar9) {
        if (fVar9 < DAT_01901f38) {
          fVar6 = fVar6 * DAT_0190193c;
        }
      }
      else {
        fVar6 = fVar6 * DAT_01901f3c;
      }
      param_2 = param_2 + 1;
      *(float *)(iVar5 + 0xc + iVar4) = fVar6 * fVar6;
      iVar5 = iVar5 + 0x10;
      iVar4 = *(int *)(iStack_8 + 0x16c);
    } while (param_2 < (uint)(*(int *)(iStack_8 + 0x170) - iVar4 >> 4));
  }
  return;
}



/* FUNCTION 12536 ; VA 0x0081b070 ; FUN_0081b070 */

undefined4 FUN_0081b070(undefined4 param_1,float *param_2,undefined4 param_3)

{
  double dVar1;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  dVar1 = (double)(*param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
  FUN_017267a0();
  fStack_c = DAT_018ce2f8 / (float)dVar1;
  fStack_14 = *param_2 * fStack_c;
  fStack_10 = param_2[1] * fStack_c;
  fStack_c = param_2[2] * fStack_c;
  FUN_01161370(param_1,&fStack_14,param_3);
  return param_1;
}



/* FUNCTION 12537 ; VA 0x0081b110 ; FUN_0081b110 */

undefined4 FUN_0081b110(undefined4 param_1,float *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  double dVar2;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  undefined auStack_74 [36];
  undefined auStack_50 [36];
  undefined auStack_2c [40];
  
  dVar2 = (double)(*param_2 * *param_2 + param_2[1] * param_2[1] + param_2[2] * param_2[2]);
  FUN_017267a0();
  fStack_78 = DAT_018ce2f8 / (float)dVar2;
  fStack_80 = *param_2 * fStack_78;
  fStack_7c = param_2[1] * fStack_78;
  fStack_78 = param_2[2] * fStack_78;
  FUN_00c93af0(auStack_50,&fStack_80);
  FUN_01160a40(param_3,0,0,0,param_3,0,0,0,param_3);
  uVar1 = FUN_01160c20(auStack_2c,auStack_74);
  FUN_01165980(uVar1,param_2);
  return param_1;
}



/* FUNCTION 12538 ; VA 0x0081b210 ; FUN_0081b210 */

void __thiscall
FUN_0081b210(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined auStack_58 [4];
  int *piStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6032;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_14 = CONCAT31(uStack_14._1_3_,-(DAT_01d6200c != '\0')) & 0xffffff04;
  uStack_18 = *(undefined4 *)(*param_1 + 0x4ec);
  ExceptionList = &pvStack_10;
  FUN_005542c0("Sky.SkyboxRt",0xc);
  uStack_8 = 0;
  uVar5 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar6 = (undefined4 *)FUN_00782550(auStack_38,param_3,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *param_2 = uVar5;
  piVar3 = (int *)param_2[1];
  param_2[1] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxUp",0xc);
  uStack_8 = 2;
  uVar5 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar6 = (undefined4 *)FUN_00782550(auStack_38,param_7,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_2[2] = uVar5;
  piVar3 = (int *)param_2[3];
  param_2[3] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxBk",0xc);
  uStack_8 = 4;
  uVar5 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar6 = (undefined4 *)FUN_00782550(auStack_38,param_5,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_2[4] = uVar5;
  piVar3 = (int *)param_2[5];
  param_2[5] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxLf",0xc);
  uStack_8 = 6;
  uVar5 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar6 = (undefined4 *)FUN_00782550(auStack_38,param_4,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_2[6] = uVar5;
  piVar3 = (int *)param_2[7];
  param_2[7] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxDn",0xc);
  uStack_8 = 8;
  uVar5 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  puVar6 = (undefined4 *)FUN_00782550(auStack_38,param_8,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_2[8] = uVar5;
  piVar3 = (int *)param_2[9];
  param_2[9] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_34[1] + -1;
    piStack_34[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar4 = piStack_34[2] + -1;
      piStack_34[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar8 = uStack_1c + 1;
    uVar7 = auStack_30[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_30[0] - 4);
      uVar8 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxFt",0xc);
  uStack_8 = 10;
  uVar5 = FUN_00d102b0(auStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  puVar6 = (undefined4 *)FUN_00782550(auStack_58,param_6,uStack_14,0,uVar5,0x425c0000,0x80);
  uVar5 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_2[10] = uVar5;
  piVar3 = (int *)param_2[0xb];
  param_2[0xb] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_54[1] + -1;
    piStack_54[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar3 = piStack_54 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  FUN_00637950();
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar7 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12539 ; VA 0x0081b8a0 ; FUN_0081b8a0 */

void __fastcall FUN_0081b8a0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  iVar4 = 0;
  piVar6 = param_1 + 0x11;
  piVar3 = piVar6;
  do {
    if (*piVar3 == 0) goto LAB_0081b9cf;
    iVar1 = *(int *)(*piVar3 + 8);
    if (iVar1 != 3) {
      if ((iVar1 == 0) || (iVar1 == 1)) goto LAB_0081b9cf;
      goto LAB_0081b980;
    }
    iVar4 = iVar4 + 1;
    piVar3 = piVar3 + 2;
  } while (iVar4 < 6);
  if (piVar6 != param_1 + 0x1d) {
    piVar3 = param_1 + 6;
    piVar5 = piVar6;
    do {
      iVar4 = piVar5[1];
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = piVar5[1];
      }
      piVar3[-1] = *piVar5;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar4;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar4 = piVar2[1] + -1;
        piVar2[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar4 = piVar2[2] + -1;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar5 = piVar5 + 2;
      piVar3 = piVar3 + 2;
    } while (piVar5 != param_1 + 0x1d);
  }
  *(undefined *)(param_1 + 0x62) = 1;
  FUN_0081cf60(param_1 + 5,param_1 + 0x1d,param_1 + 0x35);
  if (*(int *)(*(int *)(*param_1 + 0x4f8) + 0x44c) != 0) {
    FUN_00827ce0();
  }
LAB_0081b980:
  if (piVar6 != param_1 + 0x1d) {
    do {
      *piVar6 = 0;
      piVar3 = (int *)piVar6[1];
      piVar6[1] = 0;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar6 = piVar6 + 2;
    } while (piVar6 != param_1 + 0x1d);
  }
LAB_0081b9cf:
  param_1[0x61] = param_1[0x61] + 1;
  if (((0x27 < param_1[0x61]) && (param_1[0x61] = 0, param_1[0x54] != 3)) &&
     (param_1[0x5b] != param_1[0x5c])) {
    FUN_0081d870();
  }
  return;
}



/* FUNCTION 12540 ; VA 0x0081ba10 ; FUN_0081ba10 */

void FUN_0081ba10(int *param_1,int param_2,byte param_3,char param_4)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  float *pfVar4;
  undefined4 *puVar5;
  int *piVar6;
  char *pcVar7;
  int *piVar8;
  int iVar9;
  undefined4 uVar10;
  char *pcVar11;
  undefined8 uVar12;
  undefined auStack_364 [36];
  undefined4 uStack_340;
  undefined4 uStack_33c;
  undefined4 uStack_338;
  undefined4 uStack_334;
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  undefined4 uStack_31c;
  undefined4 uStack_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined4 uStack_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined4 uStack_2f8;
  undefined4 uStack_2f4;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  int iStack_2c0;
  int iStack_2bc;
  int iStack_2b8;
  int iStack_2b4;
  int iStack_2b0;
  int iStack_2ac;
  int iStack_2a8;
  int iStack_2a4;
  undefined auStack_29c [36];
  undefined4 uStack_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined auStack_1f4 [36];
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  int iStack_c0;
  int iStack_bc;
  int iStack_b8;
  int iStack_b4;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  char *pcStack_6c;
  undefined4 uStack_68;
  char *pcStack_64;
  int iStack_60;
  int iStack_5c;
  int *piStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  int *piStack_48;
  char *pcStack_44;
  undefined8 uStack_40;
  undefined uStack_38;
  char acStack_30 [4];
  undefined2 auStack_2c [2];
  undefined4 uStack_28;
  ushort uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b607b;
  pvStack_1c = ExceptionList;
  iVar9 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_1c;
  puVar2 = &stack0xfffffffc;
  if ((*(int *)(iVar9 + 0x34) < DAT_01eb3b08) &&
     (ExceptionList = &pvStack_1c, FUN_016f3809(&DAT_01eb3b08), puVar2 = puStack_20,
     DAT_01eb3b08 == -1)) {
    uStack_14 = 0;
    uVar12 = FUN_0152dab0("Render",&DAT_01901ea0,0xffffffff);
    DAT_01eb3b04 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3b00 = (undefined4)uVar12;
    uStack_14 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3b08);
    puVar2 = puStack_20;
  }
  puStack_20 = puVar2;
  uStack_7c = DAT_01eb3b00;
  uStack_a0 = DAT_01eb3b00;
  uStack_78 = DAT_01eb3b04;
  uStack_9c = DAT_01eb3b04;
  uStack_98 = FUN_0152d930(DAT_01eb3b00,DAT_01eb3b04);
  uStack_14 = 1;
  if (*(int *)(iVar9 + 0x34) < DAT_01eb3b18) {
    FUN_016f3809(&DAT_01eb3b18);
    if (DAT_01eb3b18 == -1) {
      uStack_14._0_1_ = 2;
      uVar12 = FUN_0152dab0(&DAT_018fb928,&DAT_01901ea0,0xffffffff);
      DAT_01eb3b14 = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb3b10 = (undefined4)uVar12;
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      FUN_016f37bf(&DAT_01eb3b18);
    }
  }
  uStack_74 = DAT_01eb3b10;
  uStack_90 = DAT_01eb3b10;
  uStack_70 = DAT_01eb3b14;
  uStack_8c = DAT_01eb3b14;
  uStack_88 = FUN_0152d930(DAT_01eb3b10,DAT_01eb3b14);
  uStack_14._0_1_ = 3;
  acStack_30[0] = (param_3 ^ 1) << 2;
  uStack_278 = *(undefined4 *)(param_2 + 0x1c);
  uStack_274 = *(undefined4 *)(param_2 + 0x20);
  uStack_270 = *(undefined4 *)(param_2 + 0x24);
  uStack_26c = *(undefined4 *)(param_2 + 0x28);
  uStack_268 = *(undefined4 *)(param_2 + 0x2c);
  uStack_264 = *(undefined4 *)(param_2 + 0x30);
  uStack_260 = *(undefined4 *)(param_2 + 0x34);
  uStack_25c = *(undefined4 *)(param_2 + 0x38);
  acStack_30[1] = '\0';
  acStack_30[2] = '\0';
  uStack_258 = *(undefined4 *)(param_2 + 0x3c);
  uStack_254 = *(undefined4 *)(param_2 + 0x40);
  uStack_250 = *(undefined4 *)(param_2 + 0x44);
  uStack_24c = *(undefined4 *)(param_2 + 0x48);
  uStack_248 = *(undefined4 *)(param_2 + 0x4c);
  uStack_244 = *(undefined4 *)(param_2 + 0x50);
  uStack_240 = *(undefined4 *)(param_2 + 0x54);
  uStack_23c = *(undefined4 *)(param_2 + 0x58);
  pcStack_6c = (char *)0x0;
  uStack_68 = 0;
  pcStack_64 = (char *)0x0;
  iStack_60 = 0;
  FUN_01165f20(3,&pcStack_6c);
  FUN_01165af0(&uStack_190,&uStack_278);
  piVar8 = piStack_48;
  pcStack_64 = "SkyLinearFS";
  if (param_4 == '\0') {
    pcStack_64 = "SkyFS";
  }
  pcStack_44 = pcStack_64 + 1;
  pcVar7 = pcStack_64;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  iStack_60 = (int)pcVar7 - (int)pcStack_44;
  pcStack_6c = "SkyVS";
  uStack_68 = 5;
  FUN_00790e00(&iStack_5c,&pcStack_6c,2);
  uStack_14._0_1_ = 4;
  if (iStack_5c == 0) {
LAB_0081c23c:
    uStack_14._0_1_ = 3;
    piStack_48 = piStack_58;
    if (piStack_58 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_58[1] + -1;
      piStack_58[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_58)();
        LOCK();
        iVar9 = piStack_48[2] + -1;
        piStack_48[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_48 + 4))();
        }
      }
    }
    if (param_3 != 0) goto LAB_0081c491;
    pcStack_6c = "StarsVS";
    uStack_68 = 7;
    pcStack_64 = "StarsFS";
    iStack_60 = 7;
    FUN_00790e00(&iStack_5c,&pcStack_6c,2);
    uStack_14._0_1_ = 9;
    if (((iStack_5c != 0) && (piVar8[0x54] != 3)) && ((piVar8[0x58] != 0 || (piVar8[0x5e] != 0)))) {
      (**(code **)(*param_1 + 0x24))(iStack_5c);
      uStack_40 = 0x40004000000000f;
      uStack_38 = 0;
      auStack_2c[0] = 0;
      uStack_28 = 0;
      uStack_24 = uStack_24 & 0xff00;
      (**(code **)(*param_1 + 0x3c))(auStack_2c,&uStack_40,acStack_30);
      puVar5 = (undefined4 *)FUN_01165df0();
      uStack_150 = *puVar5;
      uStack_14c = puVar5[1];
      uStack_148 = puVar5[2];
      uStack_144 = puVar5[3];
      uStack_140 = puVar5[4];
      uStack_13c = puVar5[5];
      uStack_138 = puVar5[6];
      uStack_134 = puVar5[7];
      uStack_130 = puVar5[8];
      uStack_12c = puVar5[9];
      uStack_128 = puVar5[10];
      uStack_124 = puVar5[0xb];
      uStack_120 = puVar5[0xc];
      uStack_11c = puVar5[0xd];
      uStack_118 = puVar5[0xe];
      uStack_114 = puVar5[0xf];
      uStack_110 = uStack_190;
      uStack_10c = uStack_18c;
      uStack_108 = uStack_188;
      uStack_104 = uStack_184;
      uStack_100 = uStack_180;
      uStack_fc = uStack_17c;
      uStack_f8 = uStack_178;
      uStack_f4 = uStack_174;
      uStack_f0 = uStack_170;
      uStack_ec = uStack_16c;
      uStack_e8 = uStack_168;
      uStack_e4 = uStack_164;
      uStack_e0 = uStack_160;
      uStack_dc = uStack_15c;
      uStack_d8 = uStack_158;
      uStack_d4 = uStack_154;
      piVar6 = (int *)FUN_0115ee70();
      iStack_d0 = *piVar6;
      iStack_cc = piVar6[1];
      iStack_c8 = piVar6[2];
      iStack_c4 = 0x3f800000;
      piVar6 = (int *)FUN_0115ee70();
      auStack_2c[0] = 1;
      uStack_28 = 0;
      uStack_24 = 0;
      iStack_c0 = *piVar6;
      iStack_bc = piVar6[1];
      iStack_b8 = piVar6[2];
      iStack_b4 = 0x3f800000;
      (**(code **)(*param_1 + 0x34))(0,*(undefined4 *)(*(int *)(*piVar8 + 0x4ec) + 0x24),auStack_2c)
      ;
      (**(code **)(*param_1 + 0x30))(1,&uStack_150,0xa0);
      puVar5 = (undefined4 *)piVar8[0x58];
      if (puVar5 != (undefined4 *)0x0) {
        (**(code **)(*param_1 + 0x40))(*puVar5,puVar5[2],puVar5[3],puVar5[4],puVar5[5],0);
      }
      if ((piVar8[0x54] != 2) && (piVar8[0x5e] != 0)) {
        FUN_00778470(piVar8[0x5e],0);
      }
    }
  }
  else {
    (**(code **)(*param_1 + 0x24))(iStack_5c);
    uStack_40 = 0x10001000000000f;
    uStack_38 = 0;
    auStack_2c[0] = 0;
    uStack_28 = 0;
    uStack_24 = uStack_24 & 0xff00;
    (**(code **)(*param_1 + 0x3c))(auStack_2c,&uStack_40,acStack_30);
    iVar9 = 0;
    uStack_40 = DAT_018c0d60;
    pcVar7 = DAT_018f8ff0;
    pcVar11 = DAT_01901f78;
    uVar12 = DAT_018c0d60;
    do {
      piVar6 = (int *)&DAT_01eb1b04;
      if ((int *)piVar8[iVar9 * 2 + 5] != (int *)0x0) {
        piVar6 = (int *)piVar8[iVar9 * 2 + 5];
      }
      if (*piVar6 != 0) {
        pcStack_44 = pcVar7;
        if ((iVar9 != 1) && (pcStack_44 = pcVar11, iVar9 != 4)) {
          pcStack_44 = (char *)0x0;
        }
        uVar3 = (undefined4)uVar12;
        uVar10 = (undefined4)((ulonglong)uVar12 >> 0x20);
        FUN_017267a0();
        fStack_a8 = DAT_018ce2f8 / (float)(double)CONCAT44(uVar10,uVar3);
        fStack_ac = fStack_a8 * DAT_018ce2f0;
        fStack_a4 = fStack_ac;
        FUN_01161370(auStack_1f4,&fStack_ac,pcStack_44);
        FUN_01160a40(&DAT_bf800000,0,0,0,0x3f800000,0,0,0,0x3f800000);
        FUN_01160c20(&uStack_21c,auStack_364);
        uVar3 = FUN_00d6a420(iVar9);
        FUN_01160c20(auStack_29c,uVar3);
        pfVar4 = (float *)FUN_011612d0(&uStack_68,2);
        fStack_54 = *pfVar4 * DAT_01901f64;
        fStack_50 = pfVar4[1] * DAT_01901f64;
        fStack_4c = pfVar4[2] * DAT_01901f64;
        FUN_01160a40(0x4528c000,0,0,0,0x4528c000,0,0,0,0x4528c000);
        uVar3 = FUN_01160c20(&uStack_21c,auStack_1f4);
        FUN_01165980(uVar3,&fStack_54);
        piVar8 = piStack_48;
        uStack_150 = uStack_1d0;
        uStack_14c = uStack_1cc;
        uStack_148 = uStack_1c8;
        uStack_144 = uStack_1c4;
        iStack_c4 = 0x3f800000;
        iStack_b4 = 0x3f800000;
        uStack_140 = uStack_1c0;
        uStack_13c = uStack_1bc;
        uStack_138 = uStack_1b8;
        uStack_134 = uStack_1b4;
        auStack_2c[0] = 0x101;
        uStack_130 = uStack_1b0;
        uStack_12c = uStack_1ac;
        uStack_128 = uStack_1a8;
        uStack_124 = uStack_1a4;
        puVar5 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)piStack_48[iVar9 * 2 + 5] != (undefined4 *)0x0) {
          puVar5 = (undefined4 *)piStack_48[iVar9 * 2 + 5];
        }
        uStack_28 = 0;
        uStack_120 = uStack_1a0;
        uStack_11c = uStack_19c;
        uStack_118 = uStack_198;
        uStack_114 = uStack_194;
        uStack_24 = 0;
        uStack_110 = uStack_190;
        uStack_10c = uStack_18c;
        uStack_108 = uStack_188;
        uStack_104 = uStack_184;
        uStack_100 = uStack_180;
        uStack_fc = uStack_17c;
        uStack_f8 = uStack_178;
        uStack_f4 = uStack_174;
        uStack_f0 = uStack_170;
        uStack_ec = uStack_16c;
        uStack_e8 = uStack_168;
        uStack_e4 = uStack_164;
        uStack_e0 = uStack_160;
        uStack_dc = uStack_15c;
        uStack_d8 = uStack_158;
        uStack_d4 = uStack_154;
        iStack_d0 = piStack_48[0x39];
        iStack_cc = piStack_48[0x3a];
        iStack_c8 = piStack_48[0x3b];
        iStack_c0 = piStack_48[0x3c];
        iStack_bc = piStack_48[0x3d];
        iStack_b8 = piStack_48[0x3e];
        (**(code **)(*param_1 + 0x34))(0,*puVar5,auStack_2c);
        (**(code **)(*param_1 + 0x30))(1,&uStack_150,0xa0);
        puVar5 = (undefined4 *)piVar8[3];
        (**(code **)(*param_1 + 0x40))(*puVar5,puVar5[2],puVar5[3],puVar5[4],puVar5[5],0);
        pcVar7 = DAT_018f8ff0;
        pcVar11 = DAT_01901f78;
        uVar12 = uStack_40;
      }
      iVar9 = iVar9 + 1;
    } while (iVar9 < 6);
    if (param_4 == '\0') {
      if (*(char *)(piVar8 + 0x3f) != '\0') {
        uStack_40 = 0xf;
        uStack_38 = 0;
        auStack_2c[0] = 0;
        uStack_28 = 0;
        uStack_24 = uStack_24 & 0xff00;
        (**(code **)(*param_1 + 0x3c))(auStack_2c,&uStack_40,acStack_30);
        fStack_54 = (float)piVar8[0x40] * DAT_01901f64;
        fStack_50 = (float)piVar8[0x41] * DAT_01901f64;
        fStack_4c = (float)piVar8[0x42] * DAT_01901f64;
        FUN_0081b110(&uStack_1d0,&fStack_54,piVar8[0x47]);
        auStack_2c[0] = 0x101;
        uStack_150 = uStack_1d0;
        uStack_14c = uStack_1cc;
        uStack_148 = uStack_1c8;
        uStack_144 = uStack_1c4;
        uStack_28 = 0;
        uStack_140 = uStack_1c0;
        uStack_13c = uStack_1bc;
        uStack_138 = uStack_1b8;
        uStack_134 = uStack_1b4;
        puVar5 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)piVar8[0x48] != (undefined4 *)0x0) {
          puVar5 = (undefined4 *)piVar8[0x48];
        }
        uStack_24 = 0;
        uStack_130 = uStack_1b0;
        uStack_12c = uStack_1ac;
        uStack_128 = uStack_1a8;
        uStack_124 = uStack_1a4;
        uStack_120 = uStack_1a0;
        uStack_11c = uStack_19c;
        uStack_118 = uStack_198;
        uStack_114 = uStack_194;
        uStack_110 = uStack_190;
        uStack_10c = uStack_18c;
        uStack_108 = uStack_188;
        uStack_104 = uStack_184;
        uStack_100 = uStack_180;
        uStack_fc = uStack_17c;
        uStack_f8 = uStack_178;
        uStack_f4 = uStack_174;
        uStack_f0 = uStack_170;
        uStack_ec = uStack_16c;
        uStack_e8 = uStack_168;
        uStack_e4 = uStack_164;
        uStack_e0 = uStack_160;
        uStack_dc = uStack_15c;
        uStack_d8 = uStack_158;
        uStack_d4 = uStack_154;
        iStack_d0 = piVar8[0x43];
        iStack_cc = piVar8[0x44];
        iStack_c8 = piVar8[0x45];
        iStack_c4 = piVar8[0x46];
        iStack_c0 = piVar8[0x43];
        iStack_bc = piVar8[0x44];
        iStack_b8 = piVar8[0x45];
        iStack_b4 = piVar8[0x46];
        (**(code **)(*param_1 + 0x34))(0,*puVar5,auStack_2c);
        (**(code **)(*param_1 + 0x30))(1,&uStack_150,0xa0);
        puVar5 = (undefined4 *)piVar8[4];
        (**(code **)(*param_1 + 0x40))(*puVar5,puVar5[2],puVar5[3],puVar5[4],puVar5[5],0);
        fStack_54 = (float)piVar8[0x4a] * DAT_01901f64;
        fStack_50 = (float)piVar8[0x4b] * DAT_01901f64;
        fStack_4c = (float)piVar8[0x4c] * DAT_01901f64;
        FUN_0081b110(&uStack_238,&fStack_54,piVar8[0x51]);
        auStack_2c[0] = 0x101;
        uStack_340 = uStack_238;
        uStack_33c = uStack_234;
        uStack_338 = uStack_230;
        uStack_334 = uStack_22c;
        uStack_28 = 0;
        uStack_330 = uStack_228;
        uStack_32c = uStack_224;
        uStack_328 = uStack_220;
        uStack_324 = uStack_21c;
        puVar5 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)piVar8[0x52] != (undefined4 *)0x0) {
          puVar5 = (undefined4 *)piVar8[0x52];
        }
        uStack_24 = 0;
        uStack_320 = uStack_218;
        uStack_31c = uStack_214;
        uStack_318 = uStack_210;
        uStack_314 = uStack_20c;
        uStack_310 = uStack_208;
        uStack_30c = uStack_204;
        uStack_308 = uStack_200;
        uStack_304 = uStack_1fc;
        uStack_300 = uStack_190;
        uStack_2fc = uStack_18c;
        uStack_2f8 = uStack_188;
        uStack_2f4 = uStack_184;
        uStack_2f0 = uStack_180;
        uStack_2ec = uStack_17c;
        uStack_2e8 = uStack_178;
        uStack_2e4 = uStack_174;
        uStack_2e0 = uStack_170;
        uStack_2dc = uStack_16c;
        uStack_2d8 = uStack_168;
        uStack_2d4 = uStack_164;
        uStack_2d0 = uStack_160;
        uStack_2cc = uStack_15c;
        uStack_2c8 = uStack_158;
        uStack_2c4 = uStack_154;
        iStack_2c0 = piVar8[0x4d];
        iStack_2bc = piVar8[0x4e];
        iStack_2b8 = piVar8[0x4f];
        iStack_2b4 = piVar8[0x50];
        iStack_2b0 = piVar8[0x4d];
        iStack_2ac = piVar8[0x4e];
        iStack_2a8 = piVar8[0x4f];
        iStack_2a4 = piVar8[0x50];
        (**(code **)(*param_1 + 0x34))(0,*puVar5,auStack_2c);
        (**(code **)(*param_1 + 0x30))(1,&uStack_340,0xa0);
        puVar5 = (undefined4 *)piVar8[4];
        (**(code **)(*param_1 + 0x40))(*puVar5,puVar5[2],puVar5[3],puVar5[4],puVar5[5],0);
      }
      goto LAB_0081c23c;
    }
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_58[1] + -1;
    piStack_58[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_58)();
      LOCK();
      piVar8 = piStack_58 + 2;
      iVar9 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piStack_58 + 4))();
      }
    }
  }
LAB_0081c491:
  uStack_14 = CONCAT31(uStack_14._1_3_,10);
  FUN_0152dda0(uStack_74,uStack_70,uStack_88);
  uStack_14 = 0xb;
  FUN_0152dda0(uStack_7c,uStack_78,uStack_98);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12541 ; VA 0x0081c590 ; FUN_0081c590 */

int __fastcall FUN_0081c590(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = *param_1;
  param_1[1] = iVar4;
  iVar2 = param_1[3];
  param_1[3] = 0;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    iVar4 = FUN_01674ea0(iVar2,0x18);
  }
  param_1[4] = 0;
  piVar3 = (int *)param_1[5];
  param_1[5] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  return iVar4;
}



/* FUNCTION 12542 ; VA 0x0081c620 ; FUN_0081c620 */

int __thiscall FUN_0081c620(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  bool bVar8;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b60d1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  iStack_1c = param_1;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0081c590();
    ExceptionList = pvStack_10;
    return iVar5;
  }
  ExceptionList = &pvStack_10;
  FUN_00819ed0(param_3,param_1);
  puVar6 = (undefined4 *)
           (**(code **)(**(int **)(*param_2 + 0x3c) + 0x3c))(auStack_24,0,param_3 * 0x18,0x18,1);
  puStack_18 = (undefined4 *)(param_1 + 0x10);
  uVar7 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *puStack_18 = uVar7;
  piVar3 = *(int **)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x14) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar5 = piStack_20[2] + -1;
      piStack_20[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piStack_20 = (int *)FUN_01674e20(0x18);
  uStack_8 = 0;
  bVar8 = piStack_20 == (int *)0x0;
  if (bVar8) {
    uVar7 = 0;
  }
  else {
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    uStack_8 = 1;
    uStack_14 = 1;
    uVar7 = FUN_0147c0e0(auStack_34,param_2 + 1,puStack_18,&uStack_2c);
    uStack_8 = 2;
    uStack_14 = 3;
    uVar7 = FUN_0147c720(uVar7,2,0,0,param_3);
  }
  iVar4 = *(int *)(iStack_1c + 0xc);
  *(undefined4 *)(iStack_1c + 0xc) = uVar7;
  iVar5 = iStack_1c;
  if (iVar4 != 0) {
    piVar3 = *(int **)(iVar4 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[1] + -1;
      piVar3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar5 = piVar3[2] + -1;
        piVar3[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    iVar5 = FUN_01674ea0(iVar4,0x18);
  }
  if (!bVar8) {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_30 + 1;
      iVar4 = *piVar3;
      iVar5 = *piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar3 = piStack_30 + 2;
        iVar4 = *piVar3;
        iVar5 = *piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar5 = (**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  piVar3 = piStack_28;
  if ((!bVar8) && (piStack_28 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar4 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 12543 ; VA 0x0081c820 ; FUN_0081c820 */

void __thiscall FUN_0081c820(int param_1,float param_2)

{
  double dVar1;
  
  dVar1 = (double)(DAT_01d62044 * param_2);
  FUN_01728120();
  *(float *)(param_1 + 0x144) = (float)dVar1 * DAT_01901f64;
  return;
}



/* FUNCTION 12544 ; VA 0x0081c860 ; FUN_0081c860 */

void __thiscall FUN_0081c860(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b60e8;
  pvStack_10 = ExceptionList;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00782480(auStack_18,param_2,4,auStack_64,0x425c0000,0);
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x148) = uVar1;
  piVar3 = *(int **)(param_1 + 0x14c);
  *(undefined4 *)(param_1 + 0x14c) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piStack_14 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12545 ; VA 0x0081c970 ; FUN_0081c970 */

void __thiscall
FUN_0081c970(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  FUN_0081b210(param_1 + 0x44,param_2,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* FUNCTION 12546 ; VA 0x0081c9a0 ; FUN_0081c9a0 */

void __fastcall FUN_0081c9a0(int param_1)

{
  undefined auStack_e0 [24];
  undefined auStack_c8 [24];
  undefined auStack_b0 [24];
  undefined auStack_98 [24];
  undefined auStack_80 [24];
  undefined auStack_68 [88];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b610b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00d6b090();
  uStack_8 = 0;
  FUN_0081b210(param_1 + 0x44,auStack_b0,auStack_c8,auStack_98,auStack_80,auStack_e0,auStack_68);
  FUN_0081a520();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12547 ; VA 0x0081ca20 ; FUN_0081ca20 */

void __thiscall FUN_0081ca20(int param_1,float param_2)

{
  double dVar1;
  
  dVar1 = (double)(DAT_01d62044 * param_2);
  FUN_01728120();
  *(float *)(param_1 + 0x11c) = (float)dVar1 * DAT_01901f64;
  return;
}



/* FUNCTION 12548 ; VA 0x0081ca60 ; FUN_0081ca60 */

void __fastcall FUN_0081ca60(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6130;
  pvStack_10 = ExceptionList;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_00782480(auStack_18,&DAT_01d62014,4,auStack_64,0x425c0000,0);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x120) = uVar2;
  piVar4 = *(int **)(param_1 + 0x124);
  *(undefined4 *)(param_1 + 0x124) = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = 0;
  uStack_8 = 1;
  puVar6 = (undefined4 *)FUN_00782480(auStack_18,&DAT_01d6202c,4,auStack_64,0x425c0000,0);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *(undefined4 *)(param_1 + 0x148) = uVar2;
  piVar4 = *(int **)(param_1 + 0x14c);
  *(undefined4 *)(param_1 + 0x14c) = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar4 = piStack_14 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_00637950();
  *(undefined4 *)(param_1 + 0x11c) = 0x43fa0000;
  *(undefined4 *)(param_1 + 0x144) = 0x437a0000;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12549 ; VA 0x0081cc60 ; FUN_0081cc60 */

void __thiscall FUN_0081cc60(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b60e8;
  pvStack_10 = ExceptionList;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = 0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00782480(auStack_18,param_2,4,auStack_64,0x425c0000,0);
  uVar1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  *(undefined4 *)(param_1 + 0x120) = uVar1;
  piVar3 = *(int **)(param_1 + 0x124);
  *(undefined4 *)(param_1 + 0x124) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piStack_14 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  FUN_00637950();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12550 ; VA 0x0081cd70 ; FUN_0081cd70 */

void __thiscall FUN_0081cd70(int param_1,undefined4 *param_2,int param_3,char param_4)

{
  int iVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  
  fVar6 = DAT_018ce2f8;
  *(undefined4 *)(param_1 + 0xe4) = *param_2;
  *(undefined4 *)(param_1 + 0xe8) = param_2[1];
  *(undefined4 *)(param_1 + 0xec) = param_2[2];
  *(undefined4 *)(param_1 + 0xf0) = param_2[0x11];
  *(undefined4 *)(param_1 + 0xf4) = param_2[0x12];
  *(undefined4 *)(param_1 + 0xf8) = param_2[0x13];
  *(char *)(param_1 + 0xfc) = param_4;
  *(undefined8 *)(param_1 + 0x100) = *(undefined8 *)(param_2 + 10);
  *(undefined4 *)(param_1 + 0x108) = param_2[0xc];
  *(undefined4 *)(param_1 + 0x118) = 0x3f800000;
  fVar4 = (*(float *)(param_1 + 0x104) + DAT_018e452c) * DAT_018fde94;
  fVar3 = 0.0;
  if (0.0 <= fVar4) {
    fVar3 = fVar4;
  }
  fVar4 = fVar6;
  if (fVar3 <= fVar6) {
    fVar4 = fVar3;
  }
  fVar4 = fVar4 * DAT_018f994c;
  *(float *)(param_1 + 0x10c) = fVar4;
  *(float *)(param_1 + 0x110) = fVar4;
  *(float *)(param_1 + 0x114) = fVar4;
  *(undefined8 *)(param_1 + 0x128) = *(undefined8 *)(param_2 + 0xd);
  *(undefined4 *)(param_1 + 0x130) = param_2[0xf];
  fVar3 = (float)param_2[1];
  *(undefined4 *)(param_1 + 0x140) = 0x3f800000;
  fVar3 = (fVar6 - fVar3) + DAT_018e452c;
  if (fVar3 <= fVar6) {
    fVar6 = fVar3;
  }
  *(float *)(param_1 + 0x134) = fVar6;
  *(float *)(param_1 + 0x138) = fVar6;
  *(float *)(param_1 + 0x13c) = fVar6;
  if ((param_4 != '\0') && (param_3 != 0)) {
    dVar5 = (double)(float)param_2[0xe];
    iVar1 = *(int *)(param_1 + 0x150);
    if (DAT_01901f80 < dVar5) {
      if (DAT_01901f70 < dVar5) {
        if (DAT_018e2380 < dVar5) {
          *(undefined4 *)(param_1 + 0x150) = 0;
          iVar2 = 0;
        }
        else {
          *(undefined4 *)(param_1 + 0x150) = 1;
          iVar2 = 1;
        }
      }
      else {
        *(undefined4 *)(param_1 + 0x150) = 2;
        iVar2 = 2;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x150) = 3;
      iVar2 = 3;
    }
    if ((*(int *)(param_1 + 0x158) - *(int *)(param_1 + 0x154) >> 4) +
        (*(int *)(param_1 + 0x170) - *(int *)(param_1 + 0x16c) >> 4) == param_3) {
      if (iVar1 == iVar2) {
        return;
      }
    }
    else {
      FUN_0081adf0(param_3);
    }
    FUN_0081d610();
    FUN_0081d870();
    return;
  }
  FUN_0081c590();
  FUN_0081c590();
  return;
}



/* FUNCTION 12551 ; VA 0x0081cf60 ; FUN_0081cf60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0081cf60(int param_1,int param_2,float *param_3)

{
  float *pfVar1;
  int iVar2;
  uint *puVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  float10 fVar7;
  float10 fVar8;
  float10 fVar9;
  float10 fVar10;
  double dVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  uint uVar17;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  uint uStack_c4;
  int iStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float *pfStack_90;
  float *pfStack_80;
  int iStack_7c;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  float fStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined *puStack_c;
  
  pfStack_80 = (float *)(param_2 + 8);
  uStack_50 = _DAT_01901f90;
  uStack_4c = _UNK_01901f94;
  fStack_48 = _UNK_01901f98;
  uStack_44 = _UNK_01901f9c;
  pfStack_90 = &fStack_48;
  uStack_40 = _DAT_018f99a0;
  uStack_3c = _UNK_018f99a4;
  uStack_38 = _UNK_018f99a8;
  uStack_34 = _UNK_018f99ac;
  uStack_30 = _DAT_018ffaf0;
  uStack_2c = _UNK_018ffaf4;
  uStack_28 = _UNK_018ffaf8;
  uStack_24 = _UNK_018ffafc;
  uStack_20 = _DAT_018e3fc0;
  uStack_1c = _UNK_018e3fc4;
  uStack_18 = _UNK_018e3fc8;
  uStack_14 = _UNK_018e3fcc;
  uStack_10 = 0;
  puStack_c = &DAT_bf800000;
  iStack_7c = 6;
  fVar14 = DAT_018ce2f8;
  uVar17 = DAT_018c4ea0;
  fVar13 = DAT_018ce2f4;
  do {
    fStack_a0 = 0.0;
    fStack_9c = 0.0;
    fStack_98 = 0.0;
    fStack_94 = 0.0;
    iStack_a4 = 0;
    do {
      iVar2 = *(int *)(param_1 + (&DAT_01901e58)[iStack_a4] * 8);
      if (iVar2 == 0) {
        piVar4 = &DAT_01eb1b1c;
      }
      else {
        piVar4 = (int *)(iVar2 + 0x1c);
      }
      puVar3 = (uint *)*piVar4;
      if (puVar3 != (uint *)0x0) {
        uVar6 = *puVar3;
        uVar5 = puVar3[1];
        uStack_c4 = 0;
        fVar15 = fVar14 / (float)((double)(int)uVar6 +
                                 (double)(&DAT_018c0d90)[-((int)uVar6 >> 0x1f)]);
        fVar12 = fVar14 / (float)((double)(int)uVar5 +
                                 (double)(&DAT_018c0d90)[-((int)uVar5 >> 0x1f)]);
        if (uVar5 != 0) {
          do {
            uVar5 = 0;
            if (uVar6 != 0) {
              fVar16 = ((float)((double)(int)uStack_c4 +
                               (double)(&DAT_018c0d90)[-((int)uStack_c4 >> 0x1f)]) + fVar13) *
                       fVar12;
              fVar16 = (fVar16 + fVar16) - fVar14;
              do {
                fStack_d4 = 0.0;
                fStack_d0 = 0.0;
                fVar13 = ((float)((double)(int)uVar5 +
                                 (double)(&DAT_018c0d90)[-((int)uVar5 >> 0x1f)]) + fVar13) * fVar15;
                fStack_cc = 0.0;
                fVar13 = (fVar13 + fVar13) - fVar14;
                switch(iStack_a4) {
                case 0:
                  fStack_d4 = fVar13;
                  fStack_cc = fVar14;
                  break;
                case 1:
                  fStack_cc = DAT_018f7864;
                  fStack_d4 = (float)((uint)fVar13 ^ uVar17);
                  break;
                case 2:
                  fStack_d4 = (float)((uint)fVar13 ^ uVar17);
                  fStack_d0 = fVar14;
                  fStack_cc = (float)((uint)fVar16 ^ uVar17);
                  goto switchD_0081d141_caseD_6;
                case 3:
                  fStack_d4 = (float)((uint)fVar13 ^ uVar17);
                  fStack_d0 = DAT_018f7864;
                  fStack_cc = fVar16;
                  goto switchD_0081d141_caseD_6;
                case 4:
                  fStack_d4 = fVar14;
                  fStack_cc = (float)((uint)fVar13 ^ uVar17);
                  break;
                case 5:
                  fStack_d4 = DAT_018f7864;
                  fStack_cc = fVar13;
                  break;
                default:
                  goto switchD_0081d141_caseD_6;
                }
                fStack_d0 = (float)((uint)fVar16 ^ uVar17);
switchD_0081d141_caseD_6:
                dVar11 = (double)(fStack_d0 * fStack_d0 + fStack_cc * fStack_cc +
                                 fStack_d4 * fStack_d4);
                FUN_017267a0();
                fVar14 = DAT_018ce2f8 / (float)dVar11;
                fVar13 = fStack_d0 * fVar14 * pfStack_90[-1] + fStack_cc * fVar14 * pfStack_90[-2] +
                         fStack_d4 * fVar14 * *pfStack_90;
                fVar14 = 0.0;
                if (0.0 <= fVar13) {
                  fVar14 = fVar13;
                }
                if (0.0 < fVar14) {
                  FUN_011669b0(&fStack_60,puVar3[uVar6 * uStack_c4 + uVar5 + 2]);
                  FUN_017267a0();
                  fVar7 = (float10)FUN_01728580();
                  FUN_017267a0();
                  fVar8 = (float10)FUN_01728580();
                  FUN_017267a0();
                  fVar9 = (float10)FUN_01728580();
                  FUN_017267a0();
                  fVar10 = (float10)FUN_01728580();
                  fVar14 = ((((float)fVar7 - (float)fVar8) - (float)fVar9) + (float)fVar10) * fVar14
                  ;
                  fStack_a0 = fStack_60 * fStack_60 * fVar14 + fStack_a0;
                  fStack_9c = fStack_5c * fStack_5c * fVar14 + fStack_9c;
                  fStack_98 = fStack_58 * fStack_58 * fVar14 + fStack_98;
                  fStack_94 = fVar14 * fStack_54 + fStack_94;
                }
                uVar5 = uVar5 + 1;
                uVar6 = *puVar3;
                fVar14 = DAT_018ce2f8;
                uVar17 = DAT_018c4ea0;
                fVar13 = DAT_018ce2f4;
              } while (uVar5 < uVar6);
            }
            uStack_c4 = uStack_c4 + 1;
          } while (uStack_c4 < puVar3[1]);
        }
      }
      fVar12 = DAT_01901f30;
      iStack_a4 = iStack_a4 + 1;
    } while (iStack_a4 < 6);
    fStack_a0 = fStack_a0 * DAT_01901f30;
    pfStack_90 = pfStack_90 + 3;
    fStack_9c = fStack_9c * DAT_01901f30;
    pfStack_80[-2] = fStack_a0;
    fStack_94 = fStack_94 * DAT_01901f30;
    pfStack_80[-1] = fStack_9c;
    *pfStack_80 = fStack_98 * fVar12;
    pfStack_80[1] = fStack_94;
    *param_3 = fStack_a0 + *param_3;
    param_3[1] = param_3[1] + pfStack_80[-1];
    param_3[2] = param_3[2] + *pfStack_80;
    pfVar1 = pfStack_80 + 1;
    pfStack_80 = pfStack_80 + 4;
    iStack_7c = iStack_7c + -1;
    param_3[3] = *pfVar1 + param_3[3];
    if (iStack_7c == 0) {
      FUN_01166940(0x40c00000);
      return;
    }
  } while( true );
}



/* FUNCTION 12552 ; VA 0x0081d610 ; FUN_0081d610 */

void __fastcall FUN_0081d610(int *param_1)

{
  float fVar1;
  char cVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  float fVar10;
  double dVar11;
  float fVar12;
  int iStack_10;
  uint uStack_c;
  float fStack_8;
  
  iVar6 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  cVar2 = *(char *)(iVar6 + 0x38);
  if ((param_1[0x55] != param_1[0x56]) &&
     (iVar6 = (**(code **)(*(int *)param_1[0x59] + 0x10))(), dVar5 = DAT_01901f58,
     dVar4 = DAT_01901f50, dVar3 = DAT_01901f48, iVar6 != 0)) {
    iVar8 = param_1[0x55];
    uStack_c = 0;
    if (param_1[0x56] - iVar8 >> 4 != 0) {
      iStack_10 = 0;
      puVar9 = (undefined4 *)(iVar6 + 0x10);
      fStack_8 = DAT_018df57c;
      fVar12 = DAT_01901f38;
      fVar10 = DAT_01901f34;
      do {
        *(undefined8 *)(puVar9 + -4) = *(undefined8 *)(iStack_10 + iVar8);
        puVar9[-2] = *(undefined4 *)(iStack_10 + 8 + iVar8);
        fVar1 = *(float *)(param_1[0x55] + 0xc + iStack_10);
        if ((param_1[0x54] != 0) && (fStack_8 = fVar12, param_1[0x54] == 1)) {
          fStack_8 = fVar10;
        }
        iVar6 = FUN_0171d737();
        dVar11 = (double)((float)iVar6 / DAT_01901f68 + 0.0);
        fStack_8 = fStack_8 * fVar1;
        fVar10 = 0.0;
        if (0.0 <= fStack_8) {
          fVar10 = fStack_8;
        }
        if (dVar3 <= dVar11) {
          if (dVar4 <= dVar11) {
            fVar12 = DAT_018ce2f8;
            if (fVar10 <= DAT_018ce2f8) {
              fVar12 = fVar10;
            }
            iVar6 = (int)(fVar12 * DAT_018f9000 + DAT_018ce2f4);
            if (dVar11 < dVar5) {
              uVar7 = iVar6 << 0x18;
              if (cVar2 != '\0') goto LAB_0081d7e2;
              goto LAB_0081d76e;
            }
            uVar7 = iVar6 << 0x18;
            if (cVar2 == '\0') {
              uVar7 = uVar7 | 0xff80bf;
            }
            else {
              uVar7 = uVar7 | 0xbf80ff;
            }
          }
          else {
            fVar12 = DAT_018ce2f8;
            if (fVar10 <= DAT_018ce2f8) {
              fVar12 = fVar10;
            }
            uVar7 = (int)(fVar12 * DAT_018f9000 + DAT_018ce2f4) << 0x18 | 0xffffff;
          }
        }
        else {
          fVar12 = DAT_018ce2f8;
          if (fVar10 <= DAT_018ce2f8) {
            fVar12 = fVar10;
          }
          uVar7 = (int)(fVar12 * DAT_018f9000 + DAT_018ce2f4) << 0x18;
          if (cVar2 == '\0') {
LAB_0081d7e2:
            uVar7 = uVar7 | 0xb3ccff;
          }
          else {
LAB_0081d76e:
            uVar7 = uVar7 | 0xffccb3;
          }
        }
        uStack_c = uStack_c + 1;
        iStack_10 = iStack_10 + 0x10;
        puVar9[-1] = uVar7;
        fVar12 = DAT_01901f38;
        fVar10 = DAT_01901f34;
        fStack_8 = DAT_018df57c;
        *puVar9 = 0;
        puVar9[1] = 0;
        puVar9 = puVar9 + 6;
        iVar8 = param_1[0x55];
      } while (uStack_c < (uint)(param_1[0x56] - iVar8 >> 4));
    }
    (**(code **)(*(int *)param_1[0x59] + 0x14))();
  }
  return;
}



/* FUNCTION 12553 ; VA 0x0081d870 ; FUN_0081d870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0081d870(int *param_1)

{
  float fVar1;
  char cVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  float fVar11;
  float fVar12;
  double dVar13;
  uint uStack_10;
  
  iVar6 = (**(code **)(**(int **)(*param_1 + 0x3c) + 0x40))();
  cVar2 = *(char *)(iVar6 + 0x38);
  if ((param_1[0x5b] != param_1[0x5c]) &&
     (iVar6 = (**(code **)(*(int *)param_1[0x5f] + 0x10))(), dVar5 = DAT_01901f58,
     dVar4 = DAT_01901f50, dVar3 = DAT_01901f48, iVar6 != 0)) {
    iVar8 = param_1[0x5b];
    uStack_10 = 0;
    if (param_1[0x5c] - iVar8 >> 4 != 0) {
      iVar9 = 0;
      puVar10 = (undefined4 *)(iVar6 + 0x10);
      do {
        *(undefined8 *)(puVar10 + -4) = *(undefined8 *)(iVar9 + iVar8);
        puVar10[-2] = *(undefined4 *)(iVar9 + 8 + iVar8);
        iVar6 = FUN_0171d737();
        fVar11 = ((float)iVar6 * _DAT_01901f40) / DAT_01901f68 + DAT_018fde64;
        fVar12 = DAT_018ce2f8;
        if (param_1[0x54] == 1) {
          fVar12 = DAT_018ce2f4;
        }
        fVar1 = *(float *)(param_1[0x5b] + 0xc + iVar9);
        iVar6 = FUN_0171d737();
        dVar13 = (double)((float)iVar6 / DAT_01901f68 + 0.0);
        fVar11 = fVar1 * fVar11 * fVar12 + DAT_018fabe0;
        fVar12 = 0.0;
        if (0.0 <= fVar11) {
          fVar12 = fVar11;
        }
        if (dVar3 <= dVar13) {
          if (dVar4 <= dVar13) {
            fVar11 = DAT_018ce2f8;
            if (fVar12 <= DAT_018ce2f8) {
              fVar11 = fVar12;
            }
            iVar6 = (int)(fVar11 * DAT_018f9000 + DAT_018ce2f4);
            if (dVar13 < dVar5) {
              uVar7 = iVar6 << 0x18;
              if (cVar2 != '\0') goto LAB_0081da51;
              goto LAB_0081d9db;
            }
            uVar7 = iVar6 << 0x18;
            if (cVar2 == '\0') {
              uVar7 = uVar7 | 0xff80bf;
            }
            else {
              uVar7 = uVar7 | 0xbf80ff;
            }
          }
          else {
            fVar11 = DAT_018ce2f8;
            if (fVar12 <= DAT_018ce2f8) {
              fVar11 = fVar12;
            }
            uVar7 = (int)(fVar11 * DAT_018f9000 + DAT_018ce2f4) << 0x18 | 0xffffff;
          }
        }
        else {
          fVar11 = DAT_018ce2f8;
          if (fVar12 <= DAT_018ce2f8) {
            fVar11 = fVar12;
          }
          uVar7 = (int)(fVar11 * DAT_018f9000 + DAT_018ce2f4) << 0x18;
          if (cVar2 == '\0') {
LAB_0081da51:
            uVar7 = uVar7 | 0xb3ccff;
          }
          else {
LAB_0081d9db:
            uVar7 = uVar7 | 0xffccb3;
          }
        }
        iVar9 = iVar9 + 0x10;
        puVar10[-1] = uVar7;
        uStack_10 = uStack_10 + 1;
        *puVar10 = 0;
        puVar10[1] = 0;
        puVar10 = puVar10 + 6;
        iVar8 = param_1[0x5b];
      } while (uStack_10 < (uint)(param_1[0x5c] - iVar8 >> 4));
    }
    (**(code **)(*(int *)param_1[0x5f] + 0x14))();
  }
  return;
}



/* FUNCTION 12554 ; VA 0x0081dac0 ; FUN_0081dac0 */

int * __thiscall FUN_0081dac0(int *param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  undefined uVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  uint uStack_130;
  int *piStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  uint uStack_118;
  int *piStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  uint uStack_100;
  int *piStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined8 uStack_f0;
  uint uStack_e8;
  int *piStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  uint uStack_d0;
  undefined **ppuStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  uint uStack_b8;
  undefined **ppuStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  uint uStack_a0;
  undefined **ppuStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  uint uStack_88;
  int *piStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined auStack_70 [4];
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  int *piStack_58;
  int iStack_54;
  int *piStack_50;
  undefined uStack_4c;
  int *piStack_48;
  uint uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  uint uStack_28;
  undefined **ppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b62dd;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0x3f800000;
  param_1[3] = 0x3f800000;
  param_1[4] = 0x3f800000;
  param_1[5] = 0x3f800000;
  param_1[6] = 0x3f800000;
  param_1[7] = 0x3f800000;
  param_1[8] = 0x3f800000;
  param_1[9] = 0x3f800000;
  param_1[10] = 0x3f800000;
  param_1[0xb] = 0x3f800000;
  param_1[0xc] = 0x3f800000;
  param_1[0xd] = 0x3f800000;
  param_1[0xe] = 0x3f800000;
  param_1[0xf] = 0x3f800000;
  param_1[0x10] = 0x3f800000;
  param_1[0x11] = 0x3f800000;
  param_1[0x12] = 0x3f800000;
  param_1[0x13] = 0x3f800000;
  param_1[0x14] = 0x3f800000;
  param_1[0x15] = 0x3f800000;
  param_1[0x16] = 0x3f800000;
  param_1[0x17] = 0x3f800000;
  param_1[0x18] = 0x3f800000;
  param_1[0x19] = 0x3f800000;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0x40deb852;
  param_1[0x20] = 0x413ccccd;
  param_1[0x21] = 0x41c33333;
  param_1[0x22] = 0x3f800000;
  param_1[0x23] = 0x3f800000;
  param_1[0x24] = 0x3f800000;
  param_1[0x25] = 0;
  param_1[0x26] = 0x3f800000;
  param_1[0x27] = 0;
  piStack_2c = param_1;
  piVar5 = (int *)FUN_01166a60();
  iVar12 = *piVar5;
  iVar9 = piVar5[1];
  iVar2 = piVar5[2];
  iVar3 = piVar5[3];
  param_1[0x2c] = 0x41a00000;
  param_1[0x28] = iVar12;
  param_1[0x29] = iVar9;
  param_1[0x2a] = iVar2;
  param_1[0x2b] = iVar3;
  param_1[0x2d] = 0;
  param_1[0x2e] = (int)&DAT_bf800000;
  param_1[0x2f] = 0;
  piVar5 = (int *)FUN_01166a60();
  iVar12 = *piVar5;
  iVar9 = piVar5[1];
  iVar2 = piVar5[2];
  iVar3 = piVar5[3];
  param_1[0x34] = 0x41a00000;
  param_1[0x30] = iVar12;
  param_1[0x31] = iVar9;
  param_1[0x32] = iVar2;
  param_1[0x33] = iVar3;
  param_1[0x35] = 0x3f800000;
  param_1[0x36] = 0x3f800000;
  param_1[0x37] = 0x3f800000;
  param_1[0x38] = 0x3f800000;
  param_1[0x39] = 0x3f800000;
  param_1[0x3a] = 0x3f800000;
  param_1[0x3b] = 3000;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  uStack_8 = 0;
  thunk_FUN_016def21(param_1 + 0x3e);
  FUN_016dee4c(param_1 + 0x48,2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0x40deb852;
  param_1[0x5b] = 0x413ccccd;
  param_1[0x5c] = 0x41c33333;
  param_1[0x5d] = 0x3f800000;
  param_1[0x5e] = 0x3f800000;
  param_1[0x5f] = 0x3f800000;
  param_1[0x60] = 0;
  param_1[0x61] = 0x3f800000;
  param_1[0x62] = 0;
  piVar5 = (int *)FUN_01166a60();
  iVar12 = *piVar5;
  iVar9 = piVar5[1];
  iVar2 = piVar5[2];
  iVar3 = piVar5[3];
  param_1[0x67] = 0x41a00000;
  param_1[99] = iVar12;
  param_1[100] = iVar9;
  param_1[0x65] = iVar2;
  param_1[0x66] = iVar3;
  param_1[0x68] = 0;
  param_1[0x69] = (int)&DAT_bf800000;
  param_1[0x6a] = 0;
  piVar5 = (int *)FUN_01166a60();
  iVar12 = *piVar5;
  iVar9 = piVar5[1];
  iVar2 = piVar5[2];
  iVar3 = piVar5[3];
  param_1[0x6f] = 0x41a00000;
  param_1[0x6b] = iVar12;
  param_1[0x6c] = iVar9;
  param_1[0x6d] = iVar2;
  param_1[0x6e] = iVar3;
  param_1[0x70] = 0x3f800000;
  param_1[0x71] = 0x3f800000;
  param_1[0x72] = 0x3f800000;
  param_1[0x73] = 0x3f800000;
  param_1[0x74] = 0x3f800000;
  param_1[0x75] = 0x3f800000;
  param_1[0x76] = 3000;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  param_1[0x82] = 0;
  iVar12 = 6;
  do {
    FUN_00569440();
    piVar5 = piStack_2c;
    iVar12 = iVar12 + -1;
  } while (iVar12 != 0);
  piStack_50 = piStack_2c + 0x95;
  *piStack_50 = 0;
  piStack_5c = piStack_2c + 0x96;
  *piStack_5c = 0;
  piStack_2c[0x97] = 0;
  piStack_68 = piStack_2c + 0x98;
  *piStack_68 = 0;
  piStack_2c[0x99] = 0;
  piStack_64 = piStack_2c + 0x9a;
  uStack_8._0_1_ = 4;
  FUN_016f4053(piStack_64,0x18,6,FUN_0147c770,FUN_00550b30);
  piStack_48 = piVar5 + 0xbe;
  uStack_8._0_1_ = 5;
  FUN_0147c770();
  uStack_8._0_1_ = 6;
  FUN_0147c770();
  piVar5[0xca] = 0;
  piVar5[0xcb] = 0;
  piVar5[0xcc] = 0;
  piVar5[0xcd] = 0;
  uStack_8._0_1_ = 9;
  FUN_016f4053(piVar5 + 0xce,8,6,FUN_0075dc70,FUN_00550b30);
  uStack_8._0_1_ = 10;
  FUN_016f4053(piVar5 + 0xda,8,6,FUN_0075dc70,FUN_00550b30);
  piVar5[0xe6] = 0;
  piVar5[0xe7] = 0;
  piVar5[0xe8] = 0;
  piVar5[0xe9] = 0;
  piVar5[0xea] = 0;
  piVar5[0xeb] = 0;
  piVar5[0xec] = 0;
  piVar5[0xed] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  iVar12 = 6;
  do {
    FUN_00791e90();
    iVar12 = iVar12 + -1;
  } while (iVar12 != 0);
  piStack_58 = piStack_2c + 0x10a;
  piStack_2c[0x106] = 0;
  piStack_2c[0x107] = 0;
  piStack_2c[0x108] = 0;
  piStack_2c[0x109] = 0x3f800000;
  iVar12 = 6;
  do {
    FUN_005c4650();
    piVar5 = piStack_2c;
    iVar12 = iVar12 + -1;
  } while (iVar12 != 0);
  piStack_2c[0x12e] = 3;
  piStack_2c[0x12f] = 0;
  piStack_2c[0x130] = 0;
  piStack_2c[0x131] = 0;
  piStack_2c[0x132] = 0;
  piStack_2c[0x133] = 0;
  piStack_2c[0x134] = 0;
  piStack_2c[0x135] = 0;
  piStack_2c[0x136] = 0;
  piStack_2c[0x137] = 0;
  piStack_2c[0x138] = 0;
  piStack_2c[0x139] = 0;
  piStack_2c[0x13a] = 0;
  piStack_2c[0x13b] = 0;
  uStack_60 = *(undefined4 *)(param_2 + 0x3c);
  *piStack_2c = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  piStack_2c[1] = 0;
  piVar6 = (int *)FUN_0147c1b0(auStack_70,&DAT_01eb3b24,3,0x24);
  iVar12 = *piVar6;
  iVar9 = piVar6[1];
  *piVar6 = 0;
  piVar6[1] = 0;
  piVar5[0x96] = iVar12;
  piVar6 = (int *)piVar5[0x97];
  piVar5[0x97] = iVar9;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar12 = piVar6[1] + -1;
    piVar6[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar12 = piVar6[2] + -1;
      piVar6[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (piStack_6c != (int *)0x0) {
    LOCK();
    iVar12 = piStack_6c[1] + -1;
    piStack_6c[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_6c)();
      LOCK();
      iVar12 = piStack_6c[2] + -1;
      piStack_6c[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piStack_6c + 4))();
      }
    }
  }
  uStack_18 = 0;
  puStack_14 = (undefined4 *)0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  pcVar1 = *(code **)(*(int *)piVar5[0x96] + 0xc);
  FUN_005542c0("SkyVertex2 VL",0xd);
  uStack_8._0_1_ = 0x12;
  (*pcVar1)(&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (0xf < puStack_14) {
    uVar11 = (int)puStack_14 + 1;
    uVar10 = uStack_28;
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(uStack_28 - 4);
      uVar11 = (int)puStack_14 + 0x24;
      if (0x1f < (uStack_28 - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  piVar5 = piStack_5c;
  uVar7 = uStack_60;
  if (piStack_5c[1] != 0) {
    LOCK();
    piVar6 = (int *)(piStack_5c[1] + 4);
    *piVar6 = *piVar6 + 1;
    UNLOCK();
  }
  FUN_0081fca0(piStack_50,piStack_68,piStack_64,uStack_60,*piStack_5c,piStack_5c[1],piStack_58);
  uVar7 = FUN_0081f7c0(&uStack_44,uVar7,piVar5);
  FUN_0076b300(uVar7);
  piVar5 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar12 = piStack_40[1] + -1;
    piStack_40[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar6 = piVar5 + 2;
      iVar12 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  puVar8 = (undefined4 *)FUN_01674e20(4);
  piVar5 = piStack_2c;
  if (puVar8 == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puVar8 = piStack_2c;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  iVar12 = FUN_016df16d(&uStack_20);
  if (iVar12 != 0) {
    FUN_016df3c9(iVar12);
  }
  auStack_70[0] = 1;
  piStack_6c = (int *)uStack_20;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  iVar12 = FUN_016dee1a(&uStack_1c,1);
  if (iVar12 != 0) {
    FUN_016df3c9(iVar12);
  }
  uStack_4c = 1;
  piStack_48 = (int *)uStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  uStack_18 = uStack_18 & 0xffffff00;
  iVar12 = FUN_016dee6d(uStack_1c);
  if (iVar12 != 0) {
    FUN_016df3c9(iVar12);
  }
  ppuStack_24 = std::
                _LaunchPad<class_std::unique_ptr<class_std::tuple<class_<lambda_1bd093435a7fd657032485d293bb202f>_>,struct_std::default_delete<class_std::tuple<class_<lambda_1bd093435a7fd657032485d293bb202f>_>_>_>_>
                ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  puStack_14 = puVar8;
  iVar9 = FUN_016de8aa(&iStack_54,FUN_005535c0,&ppuStack_24);
  iVar12 = 1;
  if (iVar9 != 4) {
    iVar12 = iVar9;
  }
  if (iVar12 != 0) {
    FUN_016df3c9(iVar12);
  }
  while ((char)uStack_18 == '\0') {
    iVar12 = FUN_016df1c8(uStack_20,uStack_1c);
    if (iVar12 != 0) {
      FUN_016df3c9(iVar12);
    }
  }
  if (puStack_14 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_14,4);
  }
  uVar7 = uStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  piStack_48 = (int *)uStack_20;
  iVar12 = FUN_016deec8(uStack_1c);
  if (iVar12 != 0) {
    FUN_016df3c9(iVar12);
  }
  FUN_016dede1(uVar7);
  FUN_016df136(piStack_48);
  uStack_8._0_1_ = 0x11;
  if (piVar5[0x3d] != 0) {
    FUN_0171d16a();
    uVar4 = (undefined)uStack_8;
LAB_0081e87a:
    uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
    FUN_017167a3();
  }
  piVar5[0x3c] = iStack_54;
  piVar5[0x3d] = (int)piStack_50;
  uStack_120 = 0xf00000000;
  uStack_130 = uStack_130 & 0xffffff00;
  uStack_108 = 0xf00000000;
  uStack_118 = uStack_118 & 0xffffff00;
  uStack_f0 = 0xf00000000;
  uStack_100 = uStack_100 & 0xffffff00;
  uStack_d8 = 0xf00000000;
  uStack_e8 = uStack_e8 & 0xffffff00;
  uStack_c0 = 0xf00000000;
  uStack_d0 = uStack_d0 & 0xffffff00;
  uStack_a8 = 0xf00000000;
  uStack_b8 = uStack_b8 & 0xffffff00;
  uStack_90 = 0xf00000000;
  uStack_a0 = uStack_a0 & 0xffffff00;
  uStack_78 = 0xf00000000;
  uStack_88 = uStack_88 & 0xffffff00;
  uStack_8._0_1_ = 0x18;
  uVar7 = FUN_009cc450(&uStack_28,"textures/sky/sky512_up.tex");
  uStack_8._0_1_ = 0x19;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x18;
  uStack_130 = uStack_44;
  piStack_12c = piStack_40;
  uStack_128 = uStack_3c;
  uStack_124 = uStack_38;
  if (&DAT_0000000f < puStack_14) {
    puVar8 = (undefined4 *)((int)puStack_14 + 1);
    uVar10 = uStack_28;
    if ((undefined4 *)0xfff < puVar8) {
      uVar10 = *(uint *)(uStack_28 - 4);
      puVar8 = puStack_14 + 9;
      if (0x1f < (uStack_28 - uVar10) - 4) goto LAB_0081e87a;
    }
    FUN_01674ea0(uVar10,puVar8);
  }
  uVar7 = FUN_009cc450(&uStack_28,"textures/sky/sky512_lf.tex");
  uStack_8._0_1_ = 0x1a;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x18;
  uStack_118 = uStack_44;
  piStack_114 = piStack_40;
  uStack_110 = uStack_3c;
  uStack_10c = uStack_38;
  if (&DAT_0000000f < puStack_14) {
    puVar8 = (undefined4 *)((int)puStack_14 + 1);
    uVar10 = uStack_28;
    if ((undefined4 *)0xfff < puVar8) {
      uVar10 = *(uint *)(uStack_28 - 4);
      puVar8 = puStack_14 + 9;
      if (0x1f < (uStack_28 - uVar10) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,puVar8);
  }
  uVar7 = FUN_009cc450(&uStack_28,"textures/sky/sky512_rt.tex");
  uStack_8._0_1_ = 0x1b;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x18;
  uStack_100 = uStack_44;
  piStack_fc = piStack_40;
  uStack_f8 = uStack_3c;
  uStack_f4 = uStack_38;
  if (&DAT_0000000f < puStack_14) {
    puVar8 = (undefined4 *)((int)puStack_14 + 1);
    uVar10 = uStack_28;
    if ((undefined4 *)0xfff < puVar8) {
      uVar10 = *(uint *)(uStack_28 - 4);
      puVar8 = puStack_14 + 9;
      if (0x1f < (uStack_28 - uVar10) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,puVar8);
  }
  uVar7 = FUN_009cc450(&uStack_28,"textures/sky/sky512_bk.tex");
  uStack_8._0_1_ = 0x1c;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  uStack_e8 = uStack_44;
  piStack_e4 = piStack_40;
  uStack_e0 = uStack_3c;
  uStack_dc = uStack_38;
  FUN_005507b0();
  uVar7 = FUN_009cc450(&uStack_44,"textures/sky/sky512_ft.tex");
  uStack_8._0_1_ = 0x1d;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_d0 = uStack_28;
  uStack_28 = uStack_28 & 0xffffff00;
  ppuStack_cc = ppuStack_24;
  uStack_c8 = uStack_20;
  uStack_c4 = uStack_1c;
  uStack_c0 = CONCAT44(puStack_14,uStack_18);
  uStack_18 = 0;
  puStack_14 = (undefined4 *)0xf;
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  FUN_005507b0();
  uVar7 = FUN_009cc450(&uStack_44,"textures/sky/sky512_dn.tex");
  uStack_8._0_1_ = 0x1e;
  FUN_0054ef60(uVar7);
  FUN_005507b0();
  uStack_b8 = uStack_28;
  uStack_28 = uStack_28 & 0xffffff00;
  ppuStack_b4 = ppuStack_24;
  uStack_b0 = uStack_20;
  uStack_ac = uStack_1c;
  uStack_a8 = CONCAT44(puStack_14,uStack_18);
  uStack_18 = 0;
  puStack_14 = (undefined4 *)0xf;
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  FUN_005507b0();
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = uStack_44 & 0xffffff00;
  FUN_005542c0("rbxasset://sky/sun.jpg",0x16);
  uStack_8._0_1_ = 0x1f;
  FUN_009cbbb0(&uStack_44);
  uStack_8._0_1_ = 0x20;
  FUN_0054ef60(&uStack_44);
  FUN_005507b0();
  uStack_a0 = uStack_28;
  uStack_28 = uStack_28 & 0xffffff00;
  ppuStack_9c = ppuStack_24;
  uStack_98 = uStack_20;
  uStack_94 = uStack_1c;
  uStack_90 = CONCAT44(puStack_14,uStack_18);
  uStack_18 = 0;
  puStack_14 = (undefined4 *)0xf;
  FUN_005507b0();
  uStack_8._0_1_ = 0x18;
  FUN_005507b0();
  uStack_18 = 0;
  puStack_14 = (undefined4 *)0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("rbxasset://sky/moon.jpg",0x17);
  uStack_8._0_1_ = 0x21;
  FUN_009cbbb0(&uStack_28);
  uStack_8._0_1_ = 0x22;
  FUN_0054ef60(&uStack_28);
  FUN_005507b0();
  uStack_88 = uStack_44;
  uStack_44 = uStack_44 & 0xffffff00;
  piStack_84 = piStack_40;
  uStack_80 = uStack_3c;
  uStack_7c = uStack_38;
  uStack_78 = CONCAT44(uStack_30,uStack_34);
  uStack_34 = 0;
  uStack_30 = 0xf;
  FUN_005507b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  FUN_005507b0();
  FUN_008219e0(&uStack_130);
  if (DAT_01eb3b1c != '\0') {
    FUN_01677520(DAT_01eb3b1c,"AdvSky: created");
  }
  FUN_0081ec60();
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 12555 ; VA 0x0081e890 ; FUN_0081e890 */

void __fastcall FUN_0081e890(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x10) != 0) {
    ExceptionList = &pvStack_10;
    FUN_01674ea0(*(int *)(param_1 + 0x10),4);
  }
  uVar1 = *(undefined4 *)(param_1 + 4);
  uVar2 = *(undefined4 *)(param_1 + 8);
  uStack_8 = 0;
  iVar3 = FUN_016deec8(uVar2);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  FUN_016dede1(uVar2);
  FUN_016df136(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12556 ; VA 0x0081e900 ; FUN_0081e900 */

void __fastcall FUN_0081e900(int param_1)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016dee6d(param_1 + 0x120);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  *(undefined4 *)(param_1 + 0x150) = 0x8000;
  uStack_8 = 0;
  iVar4 = FUN_016deec8(param_1 + 0x120);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = 1;
  iVar4 = FUN_016df1a0(param_1 + 0xf8);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0xf4) == 0) {
    FUN_016df3f6(1);
    if (*(int *)(param_1 + 0xf4) == 0) {
      FUN_016df3f6(1);
    }
  }
  iVar4 = GetCurrentThreadId();
  if (*(int *)(param_1 + 0xf4) == iVar4) {
    FUN_016df3f6(5);
  }
  iVar4 = FUN_016de7ec(*(undefined4 *)(param_1 + 0xf0),*(undefined4 *)(param_1 + 0xf4),0);
  if (iVar4 != 0) {
    FUN_016df3f6(2);
  }
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x254));
  if (DAT_01eb3b1c != '\0') {
    FUN_01677520(DAT_01eb3b1c,"AdvSky: destroyed");
  }
  FUN_0081a7c0();
  FUN_0081a7c0();
  piVar2 = *(int **)(param_1 + 0x3b4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x3ac);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x3a4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x39c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x368,8,6,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x338,8,6,FUN_00550b30);
  piVar2 = *(int **)(param_1 + 0x334);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x32c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x314);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x2fc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0x268,0x18,6,FUN_00550b30);
  piVar2 = *(int **)(param_1 + 0x264);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x25c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016dedfb(param_1 + 0x120);
  FUN_016df150(param_1 + 0xf8);
  if (*(int *)(param_1 + 0xf4) == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0171d16a();
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



/* FUNCTION 12557 ; VA 0x0081ec60 ; FUN_0081ec60 */

void __fastcall FUN_0081ec60(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = param_1[0x2f];
  if (0xf < uVar1) {
    iVar2 = param_1[0x2a];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x2e] = 0;
  param_1[0x2f] = 0xf;
  *(undefined *)(param_1 + 0x2a) = 0;
  uVar1 = param_1[0x29];
  if (0xf < uVar1) {
    iVar2 = param_1[0x24];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x28] = 0;
  param_1[0x29] = 0xf;
  *(undefined *)(param_1 + 0x24) = 0;
  uVar1 = param_1[0x23];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1e];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x22] = 0;
  param_1[0x23] = 0xf;
  *(undefined *)(param_1 + 0x1e) = 0;
  uVar1 = param_1[0x1d];
  if (0xf < uVar1) {
    iVar2 = param_1[0x18];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1c] = 0;
  param_1[0x1d] = 0xf;
  *(undefined *)(param_1 + 0x18) = 0;
  uVar1 = param_1[0x17];
  if (0xf < uVar1) {
    iVar2 = param_1[0x12];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x16] = 0;
  param_1[0x17] = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  uVar1 = param_1[0x11];
  if (0xf < uVar1) {
    iVar2 = param_1[0xc];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x10] = 0;
  param_1[0x11] = 0xf;
  *(undefined *)(param_1 + 0xc) = 0;
  uVar1 = param_1[0xb];
  if (0xf < uVar1) {
    iVar2 = param_1[6];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0081eeb2;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  uVar1 = param_1[5];
  if (0xf < uVar1) {
    iVar2 = *param_1;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0081eeb2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 12558 ; VA 0x0081eec0 ; FUN_0081eec0 */

undefined4 * __thiscall FUN_0081eec0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  *(undefined8 *)(param_1 + 0xb) = *(undefined8 *)(param_2 + 0xb);
  param_1[0xd] = param_2[0xd];
  param_1[0xe] = param_2[0xe];
  param_1[0xf] = param_2[0xf];
  param_1[0x10] = param_2[0x10];
  param_1[0x11] = param_2[0x11];
  param_1[0x12] = param_2[0x12];
  *(undefined8 *)(param_1 + 0x13) = *(undefined8 *)(param_2 + 0x13);
  param_1[0x15] = param_2[0x15];
  param_1[0x16] = param_2[0x16];
  param_1[0x17] = param_2[0x17];
  param_1[0x18] = param_2[0x18];
  param_1[0x19] = param_2[0x19];
  param_1[0x1a] = param_2[0x1a];
  param_1[0x1b] = param_2[0x1b];
  param_1[0x1c] = param_2[0x1c];
  param_1[0x1d] = param_2[0x1d];
  param_1[0x1e] = param_2[0x1e];
  param_1[0x1f] = param_2[0x1f];
  param_1[0x20] = param_2[0x20];
  param_1[0x21] = param_2[0x21];
  return param_1;
}



/* FUNCTION 12559 ; VA 0x0081efa0 ; FUN_0081efa0 */

void __fastcall FUN_0081efa0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar1 = *(undefined4 *)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  uStack_8 = 0;
  iVar2 = FUN_016dee6d(*(undefined4 *)(param_1 + 8));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  *(undefined *)(param_1 + 0xc) = 1;
  iVar2 = FUN_016df1a0(*(undefined4 *)(param_1 + 4));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  iVar2 = FUN_016deec8(*(undefined4 *)(param_1 + 8));
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  FUN_0081f040();
  FUN_016df1dd();
  FUN_01674ea0(uVar1,4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12560 ; VA 0x0081f040 ; FUN_0081f040 */

void __fastcall FUN_0081f040(int param_1)

{
  int iVar1;
  int iVar2;
  float *pfVar3;
  float *pfVar4;
  float10 fVar5;
  float fVar6;
  double dVar7;
  undefined4 uVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  float afStack_190 [4];
  float fStack_180;
  float fStack_fc;
  float afStack_f8 [6];
  uint uStack_e0;
  uint uStack_dc;
  uint uStack_d8;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  int iStack_80;
  undefined uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_64;
  undefined4 uStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  undefined8 uStack_50;
  undefined8 uStack_48;
  float fStack_3c;
  int iStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b630c;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iStack_38 = param_1;
  FUN_0151a220("AdvSkyThread");
  iVar2 = param_1 + 0x120;
  while( true ) {
    if (DAT_01eb3b1c != '\0') {
      FUN_016774b0(DAT_01eb3b1c,"AdvSky Compute: waiting for jobs",0);
    }
    iStack_80 = iVar2;
    iVar1 = FUN_016dee6d(iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    uStack_7c = 1;
    iStack_14 = 0;
    iVar1 = FUN_016df1c8(param_1 + 0xf8,iVar2);
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    if ((*(uint *)(param_1 + 0x150) & 0x8000) != 0) break;
    if ((*(uint *)(param_1 + 0x150) & 1) == 0) {
      iStack_14 = 7;
      iVar1 = FUN_016deec8(iVar2);
    }
    else {
      if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3b98)
      {
        FUN_016f3809(&DAT_01eb3b98);
        if (DAT_01eb3b98 == -1) {
          iStack_14._0_1_ = 2;
          uVar14 = FUN_0152dab0("Render","AdvSky/Compute",0xffffffff);
          DAT_01eb3b94 = (undefined4)((ulonglong)uVar14 >> 0x20);
          DAT_01eb3b90 = (undefined4)uVar14;
          iStack_14 = (uint)iStack_14._1_3_ << 8;
          FUN_016f37bf(&DAT_01eb3b98);
        }
      }
      uStack_64 = DAT_01eb3b90;
      uStack_78 = DAT_01eb3b90;
      uStack_60 = DAT_01eb3b94;
      uStack_74 = DAT_01eb3b94;
      uVar14 = FUN_0152d930(DAT_01eb3b90,DAT_01eb3b94);
      iStack_14 = CONCAT31(iStack_14._1_3_,3);
      uStack_70 = uVar14;
      if (DAT_01eb3b1c != '\0') {
        FUN_016774b0(DAT_01eb3b1c,"AdvSky Compute: processing",0);
      }
      pfVar3 = (float *)(param_1 + 0x154);
      pfVar4 = afStack_190;
      for (iVar2 = 0x22; iVar2 != 0; iVar2 = iVar2 + -1) {
        *pfVar4 = *pfVar3;
        pfVar3 = pfVar3 + 1;
        pfVar4 = pfVar4 + 1;
      }
      pfVar3 = (float *)(iStack_38 + 0x1dc);
      pfVar4 = afStack_f8;
      for (iVar2 = 0x1e; iVar2 != 0; iVar2 = iVar2 + -1) {
        *pfVar4 = *pfVar3;
        pfVar3 = pfVar3 + 1;
        pfVar4 = pfVar4 + 1;
      }
      if (NAN(fStack_180) == (fStack_180 == 0.0)) {
        dVar7 = (double)(fStack_180 - DAT_01901f38);
        FUN_01726ab0();
        fStack_180 = (float)dVar7;
      }
      else {
        fStack_180 = 0.0;
      }
      pfVar4 = *(float **)(iStack_38 + 0x254);
      pfVar3 = pfVar4 + 0x3cf6;
      if (pfVar4 != pfVar3) {
        fStack_54 = (float)(uStack_e0 ^ DAT_018c4ea0);
        fStack_58 = (float)(uStack_dc ^ DAT_018c4ea0);
        fStack_5c = (float)(uStack_d8 ^ DAT_018c4ea0);
        do {
          dVar7 = (double)(pfVar4[1] * pfVar4[1] + *pfVar4 * *pfVar4 + pfVar4[2] * pfVar4[2]);
          FUN_017267a0();
          fVar10 = DAT_018ce2f8 / (float)dVar7;
          fStack_24 = fVar10 * *pfVar4;
          fVar9 = fVar10 * pfVar4[1];
          fVar13 = 0.0;
          if (0.0 <= fVar9) {
            fVar13 = fVar9;
          }
          fVar12 = DAT_018ce2f8;
          if (fVar13 <= DAT_018ce2f8) {
            fVar12 = fVar13;
          }
          dVar7 = (double)fVar12;
          uStack_48._4_4_ = fVar10 * pfVar4[2];
          uStack_50._4_4_ = fVar9;
          FUN_01726ab0();
          fVar5 = (float10)FUN_016973e0(afStack_190[3] / ((float)dVar7 + DAT_018f784c));
          fVar13 = DAT_01eb3b68;
          if (DAT_01eb3b68 <= uStack_48._4_4_) {
            fVar13 = uStack_48._4_4_;
          }
          fVar9 = DAT_01d620d0;
          if (fVar13 <= DAT_01d620d0) {
            fVar9 = fVar13;
          }
          fVar13 = DAT_01eb3b64;
          if (DAT_01eb3b64 <= uStack_50._4_4_) {
            fVar13 = uStack_50._4_4_;
          }
          fStack_30 = DAT_01d620cc;
          if (fVar13 <= DAT_01d620cc) {
            fStack_30 = fVar13;
          }
          fVar13 = DAT_01eb3b60;
          if (DAT_01eb3b60 <= fStack_24) {
            fVar13 = fStack_24;
          }
          fVar10 = DAT_01eb3b60;
          if (DAT_01eb3b60 <= (float)((uint)fStack_24 ^ DAT_018c4ea0)) {
            fVar10 = (float)((uint)fStack_24 ^ DAT_018c4ea0);
          }
          fStack_34 = (float)((float10)1 - fVar5);
          fVar12 = DAT_01d620c8;
          if (fVar13 <= DAT_01d620c8) {
            fVar12 = fVar13;
          }
          fVar13 = DAT_01d620c8;
          if (fVar10 <= DAT_01d620c8) {
            fVar13 = fVar10;
          }
          fVar10 = DAT_01eb3b68;
          if (DAT_01eb3b68 <= (float)((uint)uStack_48._4_4_ ^ DAT_018c4ea0)) {
            fVar10 = (float)((uint)uStack_48._4_4_ ^ DAT_018c4ea0);
          }
          fVar11 = DAT_01eb3b64;
          if (DAT_01eb3b64 <= (float)((uint)uStack_50._4_4_ ^ DAT_018c4ea0)) {
            fVar11 = (float)((uint)uStack_50._4_4_ ^ DAT_018c4ea0);
          }
          fVar12 = fVar12 * fVar12;
          fVar6 = DAT_01d620d0;
          if (fVar10 <= DAT_01d620d0) {
            fVar6 = fVar10;
          }
          fVar10 = DAT_01d620cc;
          if (fVar11 <= DAT_01d620cc) {
            fVar10 = fVar11;
          }
          fStack_30 = fStack_30 * fStack_30;
          fVar9 = fVar9 * fVar9;
          fVar6 = fVar6 * fVar6;
          fVar10 = fVar10 * fVar10;
          fVar13 = fVar13 * fVar13;
          fStack_3c = fStack_d4 *
                      (fVar6 * fStack_8c +
                      fVar9 * fStack_98 +
                      fVar10 * fStack_a4 +
                      fStack_b0 * fStack_30 + fStack_bc * fVar13 + fStack_c8 * fVar12);
          fStack_2c = fStack_d0 *
                      (fVar6 * fStack_88 +
                      fVar9 * fStack_94 +
                      fVar10 * fStack_a0 +
                      fStack_ac * fStack_30 + fStack_b8 * fVar13 + fStack_c4 * fVar12);
          fStack_28 = fStack_cc *
                      (fVar6 * fStack_84 +
                      fVar9 * fStack_90 +
                      fVar10 * fStack_9c +
                      fStack_a8 * fStack_30 + fStack_b4 * fVar13 + fStack_c0 * fVar12);
          dVar7 = (double)((fStack_54 * fStack_24 + fStack_58 * uStack_50._4_4_ +
                           fStack_5c * uStack_48._4_4_) * DAT_018ce2f4 + DAT_018ce2f4);
          uStack_48 = dVar7;
          FUN_01726ab0();
          uVar8 = (undefined4)((ulonglong)dVar7 >> 0x20);
          fVar13 = (float)dVar7 * fStack_34;
          if (0.0 <= fVar13) {
            if (DAT_018ce2f8 < fVar13) {
              uVar8 = 0;
              fVar13 = DAT_018ce2f8;
            }
          }
          else {
            uVar8 = 0;
            fVar13 = 0.0;
          }
          uStack_50 = CONCAT44(uVar8,fVar13 * afStack_190[2]);
          dVar7 = uStack_48;
          FUN_01726ab0();
          fStack_24 = (float)dVar7 * fStack_34;
          if (0.0 <= fStack_24) {
            if (DAT_018ce2f8 < fStack_24) {
              fStack_24 = DAT_018ce2f8;
            }
          }
          else {
            fStack_24 = 0.0;
          }
          fStack_24 = fStack_24 * afStack_190[2];
          dVar7 = uStack_48;
          FUN_01726ab0();
          fVar13 = DAT_018ce2f8;
          fVar9 = (float)dVar7 * fStack_34;
          if (0.0 <= fVar9) {
            if (DAT_018ce2f8 < fVar9) {
              fVar9 = DAT_018ce2f8;
            }
          }
          else {
            fVar9 = 0.0;
          }
          fStack_fc = fVar9 * afStack_190[2] * afStack_f8[2] + fStack_28;
          fVar9 = DAT_018ce2f8 - fStack_34;
          pfVar4[5] = (float)uStack_50 * afStack_f8[0] + fStack_3c;
          pfVar4[6] = fStack_24 * afStack_f8[1] + fStack_2c;
          pfVar4[7] = fStack_fc;
          if (0.0 <= fVar9) {
            if (fVar13 < fVar9) {
              fVar9 = fVar13;
            }
          }
          else {
            fVar9 = 0.0;
          }
          pfVar4[8] = fVar9;
          pfVar4 = pfVar4 + 9;
        } while (pfVar4 != pfVar3);
      }
      param_1 = iStack_38;
      *(uint *)(iStack_38 + 0x150) = *(uint *)(iStack_38 + 0x150) & 0xfffffffe;
      if (DAT_01eb3b1c != '\0') {
        FUN_016774b0(DAT_01eb3b1c,"AdvSky Compute: processing complete",0);
      }
      iStack_14 = CONCAT31(iStack_14._1_3_,4);
      FUN_0152dda0(uStack_64,uStack_60,uStack_70);
      iVar2 = param_1 + 0x120;
      iStack_14 = 5;
      iVar1 = FUN_016deec8(iVar2);
    }
    if (iVar1 != 0) {
      FUN_016df3c9(iVar1);
    }
    iStack_14 = 0xffffffff;
  }
  *(undefined4 *)(param_1 + 0x150) = 0;
  if (DAT_01eb3b1c != '\0') {
    FUN_016774b0(DAT_01eb3b1c,"AdvSky Compute: quit signaled",0);
  }
  iStack_14 = 1;
  iVar2 = FUN_016deec8(iVar2);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12561 ; VA 0x0081f7c0 ; FUN_0081f7c0 */

undefined4 FUN_0081f7c0(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  undefined uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6340;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_2 + 0x3c))(&piStack_18,0,0x90,0x24,0);
  uStack_8 = 0;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar3 = *(code **)(*piStack_18 + 0xc);
  FUN_005542c0("advskybillboard",0xf);
  uStack_8._0_1_ = 1;
  (*pcVar3)(auStack_40);
  uStack_8._0_1_ = 0;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar6 = auStack_40[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_40[0] - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  (**(code **)(*piStack_18 + 0x18))(0,&DAT_01917f90,0x90);
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8._0_1_ = 2;
  FUN_0147c0e0(auStack_28,param_3,&piStack_18,&uStack_20);
  piVar2 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0147c720(auStack_28,3,0,0,4);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_24[2] + -1;
      piStack_24[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_14[1] + -1;
    piStack_14[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12562 ; VA 0x0081f950 ; FUN_0081f950 */

void __thiscall FUN_0081f950(int *param_1,uint param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  int iStack_c;
  int *piStack_8;
  
  iStack_c = (int)((float)(int)param_2 * DAT_018fabe0);
  uVar4 = *(undefined4 *)(*param_1 + 0x3c);
  if (param_1[0x97] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[0x97] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piStack_8 = param_1;
  FUN_008216c0(uVar4,param_1[0x96],param_1[0x97],param_2 - iStack_c);
  iVar6 = param_1[0x12f];
  param_2 = 0;
  if (param_1[0x130] - iVar6 >> 4 != 0) {
    iVar7 = 0;
    do {
      uVar4 = FUN_01166120();
      FUN_011655d0(&fStack_18,uVar4);
      fVar8 = fStack_10 * DAT_01901f60;
      *(ulonglong *)(iVar7 + iVar6) = CONCAT44(fStack_14 * DAT_01901f60,fStack_18 * DAT_01901f60);
      *(float *)(iVar7 + 8 + iVar6) = fVar8;
      iVar5 = FUN_0171d737();
      fVar11 = DAT_018fde64;
      fVar8 = DAT_018fabdc;
      fVar10 = ((float)iVar5 * DAT_018ce2f4) / DAT_01901f68 + DAT_018fde64;
      *(float *)(iVar7 + 0xc + iVar6) = fVar10;
      fVar9 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                      DAT_018c0da0._4_4_,
                                      SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      if (fVar8 <= fVar9) {
        if (fVar11 <= fVar9) {
          if (fVar9 < DAT_01901f38) {
            fVar10 = fVar10 * DAT_0190193c;
          }
        }
        else {
          fVar10 = fVar10 * DAT_018e4440;
        }
      }
      else {
        fVar10 = fVar10 * DAT_01901f38;
      }
      param_2 = param_2 + 1;
      *(float *)(iVar7 + 0xc + iVar6) = fVar10 * fVar10;
      iVar7 = iVar7 + 0x10;
      iVar6 = piStack_8[0x12f];
    } while (param_2 < (uint)(piStack_8[0x130] - iVar6 >> 4));
  }
  piVar3 = piStack_8;
  piVar1 = piStack_8 + 0x135;
  uVar4 = *(undefined4 *)(*piStack_8 + 0x3c);
  if (piStack_8[0x97] != 0) {
    LOCK();
    piVar2 = (int *)(piStack_8[0x97] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  FUN_008216c0(uVar4,piStack_8[0x96],piStack_8[0x97],iStack_c);
  iVar6 = *piVar1;
  param_2 = 0;
  if (piVar3[0x136] - iVar6 >> 4 != 0) {
    iVar7 = 0;
    do {
      uVar4 = FUN_01166120();
      FUN_011655d0(&fStack_18,uVar4);
      fStack_14 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                          DAT_018c0da0._4_4_,
                                          SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      fVar8 = fStack_10 * DAT_01901f60;
      *(ulonglong *)(iVar7 + iVar6) = CONCAT44(fStack_14 * DAT_01901f60,fStack_18 * DAT_01901f60);
      *(float *)(iVar7 + 8 + iVar6) = fVar8;
      iVar5 = FUN_0171d737();
      fVar8 = ((float)iVar5 * DAT_018ce2f4) / DAT_01901f68 + DAT_018fabe0;
      *(float *)(iVar7 + 0xc + iVar6) = fVar8;
      fVar11 = (float)(double)CONCAT44((uint)((ulonglong)(double)fStack_14 >> 0x20) &
                                       DAT_018c0da0._4_4_,
                                       SUB84((double)fStack_14,0) & (uint)DAT_018c0da0);
      if (DAT_018fde64 <= fVar11) {
        if (fVar11 < DAT_01901f38) {
          fVar8 = fVar8 * DAT_0190193c;
        }
      }
      else {
        fVar8 = fVar8 * DAT_01901f3c;
      }
      param_2 = param_2 + 1;
      *(float *)(iVar7 + 0xc + iVar6) = fVar8 * fVar8;
      iVar7 = iVar7 + 0x10;
      iVar6 = piStack_8[0x135];
    } while (param_2 < (uint)(piStack_8[0x136] - iVar6 >> 4));
  }
  return;
}



/* FUNCTION 12563 ; VA 0x0081fc30 ; FUN_0081fc30 */

void __fastcall FUN_0081fc30(undefined4 *param_1)

{
  int iVar1;
  
  if (param_1[1] == 0) {
    FUN_016df3f6(1);
    if (param_1[1] == 0) {
      FUN_016df3f6(1);
    }
  }
  iVar1 = GetCurrentThreadId();
  if (param_1[1] == iVar1) {
    FUN_016df3f6(5);
  }
  iVar1 = FUN_016de7ec(*param_1,param_1[1],0);
  if (iVar1 != 0) {
    FUN_016df3f6(2);
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}



/* FUNCTION 12564 ; VA 0x0081fca0 ; FUN_0081fca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_0081fca0(int *param_1,undefined4 *param_2,int param_3,int *param_4,undefined4 param_5,
                  int *param_6,int param_7)

{
  int *piVar1;
  int iVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  undefined uVar8;
  undefined4 *puVar9;
  int iVar10;
  float *pfVar11;
  int *piVar12;
  uint uVar13;
  float *pfVar14;
  uint uVar15;
  uint uVar16;
  float *pfVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  int *piStack_90;
  undefined auStack_70 [4];
  int *piStack_6c;
  undefined auStack_68 [4];
  int *piStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  float fStack_44;
  int *piStack_40;
  int *piStack_3c;
  float *pfStack_38;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined2 *puStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6378;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar9 = (undefined4 *)(**(code **)(*param_4 + 0x3c))(auStack_68,0,0xf3d8,0x24,1);
  uVar4 = *puVar9;
  uVar5 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  *param_2 = uVar4;
  piVar12 = (int *)param_2[1];
  param_2[1] = uVar5;
  if (piVar12 != (int *)0x0) {
    LOCK();
    iVar10 = piVar12[1] + -1;
    piVar12[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piVar12)();
      LOCK();
      iVar10 = piVar12[2] + -1;
      piVar12[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_64[1] + -1;
    piStack_64[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_64)();
      LOCK();
      iVar10 = piStack_64[2] + -1;
      piStack_64[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piStack_64 + 4))();
      }
    }
  }
  (**(code **)(*param_4 + 0x3c))(&piStack_40,1,0x4800,2,0);
  uStack_8._0_1_ = 1;
  uStack_48 = 0;
  fStack_44 = 2.10195e-44;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar6 = *(code **)(*(int *)*param_2 + 0xc);
  FUN_005542c0("advskyboxVB",0xb);
  uStack_8._0_1_ = 2;
  (*pcVar6)(auStack_58);
  uStack_8._0_1_ = 1;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < (uint)fStack_44) {
    uVar15 = (int)fStack_44 + 1;
    uVar13 = auStack_58[0];
    if (0xfff < uVar15) {
      uVar13 = *(uint *)(auStack_58[0] - 4);
      uVar15 = (int)fStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar13) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar15);
  }
  uStack_48 = 0;
  fStack_44 = 2.10195e-44;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar6 = *(code **)(*piStack_40 + 0xc);
  FUN_005542c0("advskyboxIB",0xb);
  uStack_8._0_1_ = 3;
  (*pcVar6)(auStack_58);
  uStack_8._0_1_ = 1;
  uVar8 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < (uint)fStack_44) {
    uVar15 = (int)fStack_44 + 1;
    uVar13 = auStack_58[0];
    if (0xfff < uVar15) {
      uVar13 = *(uint *)(auStack_58[0] - 4);
      uVar15 = (int)fStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar13) - 4) {
        uStack_8._0_1_ = uVar8;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar13,uVar15);
  }
  FUN_0147c0e0(auStack_70,&param_5,param_2,&piStack_40);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar10 = FUN_01674e20(0xf3d8);
  piStack_64 = (int *)iVar10;
  iStack_18 = iVar10;
  puStack_20 = (undefined2 *)(**(code **)(*piStack_40 + 0x10))();
  iVar2 = param_3 - param_7;
  pfVar17 = (float *)(param_7 + 0x10);
  piStack_1c = (int *)(param_3 + 4);
  iStack_24 = 0;
  iStack_2c = 0;
  uStack_60 = DAT_018c45d0;
  do {
    fVar19 = _UNK_018c4ebc;
    fVar3 = _UNK_018c4eb8;
    fVar21 = _UNK_018c4eb4;
    iStack_28 = *(int *)((int)&DAT_01917f48 + iStack_2c);
    iStack_34 = *(int *)((int)&PTR_DAT_01d62080 + iStack_2c);
    pfVar17[-4] = _DAT_018c4eb0;
    pfVar17[-3] = fVar21;
    pfVar17[-2] = fVar3;
    pfVar17[-1] = fVar19;
    uVar13 = *(uint *)((int)&DAT_01917f78 + iStack_2c);
    iStack_5c = *(int *)((int)&PTR_DAT_01d620b0 + iStack_2c);
    pfVar11 = *(float **)((int)&PTR_DAT_01d62068 + iStack_2c);
    *(ulonglong *)pfVar17 = CONCAT44(uStack_60,uStack_60);
    if (iStack_28 != 0) {
      pfVar14 = (float *)(iVar10 + 8);
      iVar10 = iStack_28;
      do {
        fVar21 = pfVar11[2];
        fVar3 = *pfVar11;
        fVar19 = pfVar11[1];
        pfVar14[-2] = fVar3;
        pfVar14[-1] = fVar19;
        *pfVar14 = fVar21;
        fVar22 = pfVar17[-2];
        if (fVar21 <= pfVar17[-2]) {
          fVar22 = fVar21;
        }
        fVar20 = pfVar17[-3];
        if (fVar19 <= pfVar17[-3]) {
          fVar20 = fVar19;
        }
        fVar18 = pfVar17[-4];
        if (fVar3 <= pfVar17[-4]) {
          fVar18 = fVar3;
        }
        *(ulonglong *)(pfVar17 + -4) = CONCAT44(fVar20,fVar18);
        pfVar17[-2] = fVar22;
        fStack_44 = pfVar17[1];
        if (pfVar17[1] <= fVar21) {
          fStack_44 = fVar21;
        }
        fVar21 = *pfVar17;
        if (*pfVar17 <= fVar19) {
          fVar21 = fVar19;
        }
        fVar19 = pfVar17[-1];
        if (pfVar17[-1] <= fVar3) {
          fVar19 = fVar3;
        }
        *(ulonglong *)(pfVar17 + -1) = CONCAT44(fVar21,fVar19);
        pfVar17[1] = fStack_44;
        pfVar14[1] = (float)&DAT_bf800000;
        pfVar11 = pfVar11 + 3;
        pfVar14[2] = (float)&DAT_bf800000;
        pfVar14[3] = 1.0;
        pfVar14[4] = 0.0;
        pfVar14[5] = 1.0;
        pfVar14[6] = 1.0;
        pfVar14 = pfVar14 + 9;
        iVar10 = iVar10 + -1;
      } while (iVar10 != 0);
    }
    uStack_14 = 0;
    if (uVar13 != 0) {
      piStack_30 = (int *)(*(int *)((int)&PTR_DAT_01d62098 + iStack_2c) - (int)puStack_20);
      do {
        *puStack_20 = *(undefined2 *)((int)piStack_30 + (int)puStack_20);
        uVar15 = (uint)*(ushort *)(iStack_5c + 2 + uStack_14 * 4);
        uVar16 = (uint)*(ushort *)(iStack_5c + uStack_14 * 4);
        *(undefined4 *)(iStack_18 + 0xc + uVar15 * 0x24) = *(undefined4 *)(iStack_34 + uVar16 * 8);
        uStack_14 = uStack_14 + 1;
        *(undefined4 *)(iStack_18 + 0x10 + uVar15 * 0x24) =
             *(undefined4 *)(iStack_34 + 4 + uVar16 * 8);
        puStack_20 = puStack_20 + 1;
      } while (uStack_14 < uVar13);
    }
    pfStack_38 = pfVar17;
    piVar12 = (int *)FUN_0147c720(auStack_70,0,iStack_24,0,uVar13);
    iVar10 = *piVar12;
    iVar7 = piVar12[1];
    *piVar12 = 0;
    piVar12[1] = 0;
    piStack_1c[-1] = iVar10;
    piStack_30 = (int *)*piStack_1c;
    *piStack_1c = iVar7;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_30[1] + -1;
      piStack_30[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar10 = piStack_30[2] + -1;
        piStack_30[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    piStack_1c[1] = piVar12[2];
    piStack_1c[2] = piVar12[3];
    *(int *)(iVar2 + (int)pfVar17) = piVar12[4];
    piStack_1c[4] = piVar12[5];
    if (piStack_90 != (int *)0x0) {
      LOCK();
      iVar10 = piStack_90[1] + -1;
      piStack_90[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)*piStack_90)();
        LOCK();
        iVar10 = piStack_90[2] + -1;
        piStack_90[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_90 + 4))();
        }
      }
    }
    piVar12 = piStack_64;
    pfVar17 = pfVar17 + 6;
    iStack_24 = iStack_24 + uVar13;
    piStack_1c = piStack_1c + 6;
    iStack_2c = iStack_2c + 4;
    iVar10 = iStack_18 + iStack_28 * 0x24;
    iStack_18 = iVar10;
  } while (iStack_2c < 0x18);
  pfStack_38 = pfVar17;
  (**(code **)(*(int *)*param_2 + 0x18))(0,piStack_64,0xf3d8);
  (**(code **)(*piStack_40 + 0x14))();
  *param_1 = (int)piVar12;
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piVar12 = piStack_6c + 1;
    iVar10 = *piVar12;
    param_1 = (int *)*piVar12;
    *piVar12 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      (**(code **)*piStack_6c)();
      LOCK();
      piVar12 = piStack_6c + 2;
      iVar10 = *piVar12;
      param_1 = (int *)*piVar12;
      *piVar12 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        param_1 = (int *)(**(code **)(*piStack_6c + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar12 = piStack_3c + 1;
    iVar10 = *piVar12;
    param_1 = (int *)*piVar12;
    *piVar12 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar12 = piStack_3c + 2;
      iVar10 = *piVar12;
      param_1 = (int *)*piVar12;
      *piVar12 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        param_1 = (int *)(**(code **)(*piStack_3c + 4))();
      }
    }
  }
  piVar12 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar10 = *piVar1;
    param_1 = (int *)*piVar1;
    *piVar1 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      param_1 = (int *)(**(code **)*param_6)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        param_1 = (int *)(**(code **)(*piVar12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12565 ; VA 0x008201e0 ; FUN_008201e0 */

/* WARNING: Type propagation algorithm not settling */

int * __fastcall FUN_008201e0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined auStack_3c [8];
  undefined auStack_34 [12];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6398;
  pvStack_10 = ExceptionList;
  uVar7 = param_1[1];
  piStack_28 = *(int **)(*(int *)(*param_1 + 0x4f8) + 0x44c);
  piVar1 = piStack_28;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  if ((uVar7 & 1) != 0) {
    piVar6 = param_1 + 0xda;
    iStack_14 = 0;
    iVar9 = 6;
    do {
      if (*piVar6 == 0) {
        iVar8 = 0;
      }
      else {
        iVar8 = *(int *)(*piVar6 + 8);
      }
      piVar1 = (int *)(uint)(iVar8 == 3);
      piVar6 = piVar6 + 2;
      iStack_14 = iStack_14 + (int)piVar1;
      iVar9 = iVar9 + -1;
    } while (iVar9 != 0);
    ExceptionList = &pvStack_10;
    if (iStack_14 == 6) {
      piVar1 = param_1 + 0xdb;
      iStack_14 = 6;
      ExceptionList = &pvStack_10;
      do {
        iVar9 = *piVar1;
        if (iVar9 != 0) {
          LOCK();
          *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
          UNLOCK();
          iVar9 = *piVar1;
        }
        piVar1[-0xd] = piVar1[-1];
        piVar6 = (int *)piVar1[-0xc];
        piVar1[-0xc] = iVar9;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar9 = piVar6[1] + -1;
          piVar6[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar9 = piVar6[2] + -1;
            piVar6[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar1[-1] = 0;
        piVar6 = (int *)*piVar1;
        *piVar1 = 0;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar9 = piVar6[1] + -1;
          piVar6[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar9 = piVar6[2] + -1;
            piVar6[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        param_1 = piStack_20;
        piVar1 = piVar1 + 2;
        iStack_14 = iStack_14 + -1;
      } while (iStack_14 != 0);
      if (DAT_01eb3b1c != '\0') {
        FUN_016774b0(DAT_01eb3b1c,"AdvSky: kDirtySky: all textures ready",0);
      }
      piVar1 = (int *)FUN_0081cf60(param_1 + 0xce,param_1 + 0xee,param_1 + 0x106);
      uVar7 = param_1[1] & 0xfffffffeU | 8;
      param_1[1] = uVar7;
    }
  }
  if ((uVar7 & 4) != 0) {
    piVar1 = (int *)param_1[0xe8];
    piVar6 = (int *)&DAT_01eb1b04;
    if (piVar1 != (int *)0x0) {
      piVar6 = piVar1;
    }
    if (*piVar6 != 0) {
      if (DAT_01eb3b1c != '\0') {
        FUN_016774b0(DAT_01eb3b1c,"AdvSky: kDirtySun: texture ready",0);
      }
      iVar9 = param_1[0xe9];
      if (iVar9 != 0) {
        LOCK();
        *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
        UNLOCK();
        iVar9 = param_1[0xe9];
      }
      piVar1 = (int *)param_1[0xe8];
      param_1[0xe6] = (int)piVar1;
      piVar6 = (int *)param_1[0xe7];
      param_1[0xe7] = iVar9;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar2 = piVar6 + 1;
        iVar9 = *piVar2;
        piVar1 = (int *)*piVar2;
        *piVar2 = iVar9 + -1;
        UNLOCK();
        if (iVar9 + -1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar9 = *piVar2;
          piVar1 = (int *)*piVar2;
          *piVar2 = iVar9 + -1;
          UNLOCK();
          if (iVar9 + -1 == 0) {
            piVar1 = (int *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_1[0xe8] = 0;
      piVar6 = (int *)param_1[0xe9];
      param_1[0xe9] = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar2 = piVar6 + 1;
        iVar9 = *piVar2;
        piVar1 = (int *)*piVar2;
        *piVar2 = iVar9 + -1;
        UNLOCK();
        if (iVar9 + -1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar9 = *piVar2;
          piVar1 = (int *)*piVar2;
          *piVar2 = iVar9 + -1;
          UNLOCK();
          if (iVar9 + -1 == 0) {
            piVar1 = (int *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_1[1] = param_1[1] & 0xfffffffb;
      uVar7 = param_1[1];
    }
  }
  if ((uVar7 & 2) != 0) {
    piVar1 = (int *)param_1[0xec];
    piVar6 = (int *)&DAT_01eb1b04;
    if (piVar1 != (int *)0x0) {
      piVar6 = piVar1;
    }
    if (*piVar6 != 0) {
      if (DAT_01eb3b1c != '\0') {
        FUN_016774b0(DAT_01eb3b1c,"AdvSky: kDirtyMoon: texture ready",0);
      }
      iVar9 = param_1[0xed];
      if (iVar9 != 0) {
        LOCK();
        *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
        UNLOCK();
        iVar9 = param_1[0xed];
      }
      piVar1 = (int *)param_1[0xec];
      param_1[0xea] = (int)piVar1;
      piVar6 = (int *)param_1[0xeb];
      param_1[0xeb] = iVar9;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar2 = piVar6 + 1;
        iVar9 = *piVar2;
        piVar1 = (int *)*piVar2;
        *piVar2 = iVar9 + -1;
        UNLOCK();
        if (iVar9 + -1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar9 = *piVar2;
          piVar1 = (int *)*piVar2;
          *piVar2 = iVar9 + -1;
          UNLOCK();
          if (iVar9 + -1 == 0) {
            piVar1 = (int *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_1[0xec] = 0;
      piVar6 = (int *)param_1[0xed];
      param_1[0xed] = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar2 = piVar6 + 1;
        iVar9 = *piVar2;
        piVar1 = (int *)*piVar2;
        *piVar2 = iVar9 + -1;
        UNLOCK();
        if (iVar9 + -1 == 0) {
          piVar1 = (int *)(**(code **)*piVar6)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar9 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            piVar1 = (int *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
      param_1[1] = param_1[1] & 0xfffffffd;
      uVar7 = param_1[1];
    }
  }
  if ((uVar7 & 0x18) != 0) {
    if (DAT_01eb3b1c != '\0') {
      FUN_01677490(DAT_01eb3b1c,"AdvSky: props|wait: %d|%d, trying mutex",uVar7 >> 3 & 1,
                   uVar7 >> 4 & 1,0);
    }
    piVar6 = param_1 + 0x48;
    piStack_20 = (int *)((uint)piStack_20 & 0xffffff00);
    uStack_8 = 0;
    piStack_24 = piVar6;
    if (piVar6 == (int *)0x0) {
      puVar5 = (undefined4 *)FUN_00621c50(auStack_18,1);
      FUN_00610cc0(*puVar5,puVar5[1]);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_3c,&DAT_01c2a4ec);
    }
    piVar2 = (int *)FUN_016dee92(piVar6);
    piVar1 = piVar2;
    if ((piVar2 != (int *)0x0) && (piVar2 != (int *)0x3)) {
      piVar1 = (int *)FUN_016df3c9(piVar2);
    }
    piStack_20 = (int *)CONCAT31(piStack_20._1_3_,piVar2 == (int *)0x0);
    if (piVar2 == (int *)0x0) {
      piVar1 = (int *)param_1[1];
      if (((uint)piVar1 & 0x10) != 0) {
        if (DAT_01eb3b1c != '\0') {
          FUN_016774b0(DAT_01eb3b1c,"AdvSky: kComputeWait: ready, uploading the VB",0);
          piVar1 = (int *)param_1[1];
        }
        param_1[1] = (uint)piVar1 & 0xffffffef;
        (**(code **)(*(int *)param_1[0x98] + 0x18))(0,param_1[0x95],0xf3d8);
        FUN_00827ce0();
        piVar1 = (int *)param_1[1];
      }
      if (((uint)piVar1 & 8) != 0) {
        if (DAT_01eb3b1c != '\0') {
          FUN_016774b0(DAT_01eb3b1c,"AdvSky: kDirtyProps: kicking off the updater",0);
          piVar1 = (int *)param_1[1];
        }
        param_1[0x54] = param_1[0x54] | 1;
        param_1[1] = (uint)piVar1 & 0xfffffff7 | 0x10;
        FUN_0081eec0(param_1 + 0x1a);
        uVar3 = FUN_011658d0(auStack_1c);
        piVar1 = (int *)FUN_0115e8f0(uVar3);
        param_1[0x77] = *piVar1;
        param_1[0x78] = piVar1[1];
        param_1[0x79] = piVar1[2];
        puVar4 = (undefined8 *)FUN_011658d0(auStack_34);
        *(undefined8 *)(param_1 + 0x7d) = *puVar4;
        param_1[0x7f] = *(int *)(puVar4 + 1);
        param_1[0x80] = param_1[0x22];
        param_1[0x81] = param_1[0x23];
        param_1[0x82] = param_1[0x24];
        uVar3 = FUN_011658d0(auStack_34);
        piVar1 = (int *)FUN_0115e8f0(uVar3);
        param_1[0x7a] = *piVar1;
        param_1[0x7b] = piVar1[1];
        param_1[0x7c] = piVar1[2];
        param_1[0x83] = param_1[0xee];
        param_1[0x84] = param_1[0xef];
        param_1[0x85] = param_1[0xf0];
        param_1[0x86] = param_1[0xf2];
        param_1[0x87] = param_1[0xf3];
        param_1[0x88] = param_1[0xf4];
        param_1[0x89] = param_1[0xf6];
        param_1[0x8a] = param_1[0xf7];
        param_1[0x8b] = param_1[0xf8];
        param_1[0x8c] = param_1[0xfa];
        param_1[0x8d] = param_1[0xfb];
        param_1[0x8e] = param_1[0xfc];
        param_1[0x8f] = param_1[0xfe];
        param_1[0x90] = param_1[0xff];
        param_1[0x91] = param_1[0x100];
        param_1[0x92] = param_1[0x102];
        param_1[0x93] = param_1[0x103];
        param_1[0x94] = param_1[0x104];
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        piVar1 = (int *)FUN_016df1a0(param_1 + 0x3e);
        if (piVar1 != (int *)0x0) {
          piVar1 = (int *)FUN_016df3c9(piVar1);
        }
      }
    }
    uStack_8 = 2;
    if (((char)piStack_20 != '\0') && (piVar1 = (int *)FUN_016deec8(piVar6), piVar1 != (int *)0x0))
    {
      piVar1 = (int *)FUN_016df3c9(piVar1);
    }
    uStack_8 = 0xffffffff;
  }
  param_1[0x13b] = param_1[0x13b] + 1;
  if (((0x27 < param_1[0x13b]) && (param_1[0x13b] = 0, param_1[0x12e] != 3)) &&
     (piVar1 = (int *)param_1[0x135], piVar1 != (int *)param_1[0x136])) {
    piVar1 = (int *)FUN_00822420();
  }
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 12566 ; VA 0x00820880 ; FUN_00820880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00820880(int *param_1,int *param_2,undefined4 *param_3,byte param_4,char param_5)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  char **ppcVar5;
  char *pcVar6;
  int *piVar7;
  int iVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  undefined8 uVar12;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined4 uStack_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  int iStack_21c;
  int iStack_218;
  int iStack_214;
  undefined4 uStack_210;
  int iStack_20c;
  int iStack_208;
  int iStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 uStack_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  int iStack_19c;
  int iStack_198;
  int iStack_194;
  undefined4 uStack_190;
  int iStack_18c;
  int iStack_188;
  int iStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  int iStack_12c;
  int iStack_128;
  int iStack_124;
  int iStack_120;
  int iStack_11c;
  int iStack_118;
  int iStack_114;
  int iStack_110;
  int iStack_10c;
  int iStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  int iStack_fc;
  int iStack_f8;
  int iStack_f4;
  int iStack_f0;
  int iStack_ec;
  int iStack_e8;
  int iStack_e4;
  int iStack_e0;
  int iStack_dc;
  int iStack_d8;
  int iStack_d4;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  int iStack_c0;
  int iStack_bc;
  int iStack_b8;
  int iStack_b4;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined8 uStack_74;
  int *piStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  char *pcStack_48;
  uint uStack_44;
  char *pcStack_40;
  int *piStack_3c;
  char acStack_38 [4];
  char *pcStack_34;
  undefined4 uStack_30;
  char *pcStack_2c;
  int *piStack_28;
  int *piStack_24;
  char *pcStack_20;
  float fStack_1c;
  char *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b640c;
  pvStack_10 = ExceptionList;
  piStack_54 = (int *)0x0;
  iVar8 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_4c = param_1;
  if ((*(int *)(iVar8 + 0x34) < DAT_01eb3b78) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3b78), DAT_01eb3b78 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","AdvSky",0xffffffff);
    DAT_01eb3b74 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3b70 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3b78);
  }
  uStack_64 = DAT_01eb3b70;
  uStack_8c = DAT_01eb3b70;
  uStack_60 = DAT_01eb3b74;
  uStack_88 = DAT_01eb3b74;
  uStack_84 = FUN_0152d930(DAT_01eb3b70,DAT_01eb3b74);
  uStack_8 = 1;
  if (*(int *)(iVar8 + 0x34) < DAT_01eb3b88) {
    FUN_016f3809(&DAT_01eb3b88);
    if (DAT_01eb3b88 == -1) {
      uStack_8._0_1_ = 2;
      uVar12 = FUN_0152dab0(&DAT_018fb928,"AdvSky",0xffffffff);
      DAT_01eb3b84 = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb3b80 = (undefined4)uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb3b88);
    }
  }
  uStack_5c = DAT_01eb3b80;
  uStack_7c = DAT_01eb3b80;
  uStack_58 = DAT_01eb3b84;
  uStack_78 = DAT_01eb3b84;
  uStack_74 = FUN_0152d930(DAT_01eb3b80,DAT_01eb3b84);
  uStack_8._0_1_ = 3;
  acStack_38[0] = (param_4 ^ 1) << 2;
  uStack_26c = param_3[7];
  uStack_268 = param_3[8];
  uStack_264 = param_3[9];
  uStack_260 = param_3[10];
  uStack_25c = param_3[0xb];
  uStack_258 = param_3[0xc];
  uStack_254 = param_3[0xd];
  uStack_250 = param_3[0xe];
  acStack_38[1] = '\0';
  acStack_38[2] = '\0';
  uStack_24c = param_3[0xf];
  uStack_248 = param_3[0x10];
  uStack_244 = param_3[0x11];
  uStack_240 = param_3[0x12];
  uStack_23c = param_3[0x13];
  uStack_238 = param_3[0x14];
  uStack_234 = param_3[0x15];
  uStack_230 = param_3[0x16];
  pcStack_34 = _DAT_018f99a0;
  uStack_30 = _UNK_018f99a4;
  pcStack_2c = _UNK_018f99a8;
  piStack_28 = _UNK_018f99ac;
  FUN_01165f20(3,&pcStack_34);
  FUN_01165af0(&uStack_1ec,&uStack_26c);
  piStack_6c = (int *)0x0;
  piStack_68 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_4 == 0) {
    pcStack_40 = "AdvSkyLinearFS";
    if (param_5 == '\0') {
      pcStack_40 = "AdvSkyFS";
    }
    piStack_24 = (int *)(pcStack_40 + 1);
    pcVar6 = pcStack_40;
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    piStack_3c = (int *)((int)pcVar6 - (int)piStack_24);
    pcStack_48 = "AdvSkyVS";
    uStack_44 = 8;
    FUN_00790e00(&pcStack_18,&pcStack_48,2);
    ppcVar5 = &pcStack_18;
    piVar7 = (int *)&DAT_0000000a;
  }
  else {
    pcStack_40 = "AdvSkyLinearEnvFS";
    if (param_5 == '\0') {
      pcStack_40 = "AdvSkyEnvFS";
    }
    piStack_24 = (int *)(pcStack_40 + 1);
    pcVar6 = pcStack_40;
    do {
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    piStack_3c = (int *)((int)pcVar6 - (int)piStack_24);
    pcStack_48 = "AdvSkyVS";
    uStack_44 = 8;
    FUN_00790e00(&pcStack_2c,&pcStack_48,2);
    ppcVar5 = &pcStack_2c;
    piVar7 = (int *)&DAT_00000005;
  }
  piStack_6c = (int *)*ppcVar5;
  piStack_68 = (int *)ppcVar5[1];
  *ppcVar5 = (char *)0x0;
  ppcVar5[1] = (char *)0x0;
  piStack_54 = piStack_68;
  piStack_3c = piStack_6c;
  if (((uint)piVar7 & 2) != 0) {
    piStack_50 = (int *)((uint)piVar7 & 0xfffffffd);
    piStack_24 = piStack_14;
    piVar7 = piStack_50;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar8 = piStack_14[1] + -1;
      piStack_14[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar8 = piStack_24[2] + -1;
        piStack_24[2] = iVar8;
        UNLOCK();
        piVar7 = piStack_50;
        if (iVar8 == 0) {
          (**(code **)(*piStack_24 + 4))();
          piVar7 = piStack_50;
        }
      }
    }
  }
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  if ((((uint)piVar7 & 1) != 0) && (piStack_24 = piStack_28, piStack_28 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_28[1] + -1;
    piStack_28[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar8 = piStack_24[2] + -1;
      piStack_24[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    (**(code **)(*param_2 + 0x24))(piStack_3c);
    pcStack_2c = (char *)0x1000100;
    uStack_30 = 0xf;
    piStack_28 = (int *)((uint)piStack_28 & 0xffffff00);
    fStack_1c = (float)((uint)fStack_1c & 0xffff0000);
    pcStack_18 = (char *)0x0;
    piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
    (**(code **)(*param_2 + 0x3c))(&fStack_1c,&uStack_30,acStack_38);
    puVar2 = (undefined4 *)FUN_01165df0();
    iStack_108 = param_1[0x1e];
    iStack_f0 = param_1[0x1c];
    iStack_f4 = param_1[0x21];
    uStack_1ac = *puVar2;
    uStack_1a8 = puVar2[1];
    uStack_1a4 = puVar2[2];
    uStack_1a0 = puVar2[3];
    iStack_19c = puVar2[4];
    iStack_198 = puVar2[5];
    iStack_194 = puVar2[6];
    uStack_190 = puVar2[7];
    iStack_18c = puVar2[8];
    iStack_188 = puVar2[9];
    iStack_184 = puVar2[10];
    uStack_180 = puVar2[0xb];
    uStack_17c = puVar2[0xc];
    uStack_178 = puVar2[0xd];
    uStack_174 = puVar2[0xe];
    uStack_170 = puVar2[0xf];
    iStack_120 = 0x3f800000;
    iStack_110 = 0x3f800000;
    uStack_104 = 0;
    iStack_f8 = param_1[0x20];
    uStack_16c = uStack_1ec;
    uStack_168 = uStack_1e8;
    uStack_164 = uStack_1e4;
    uStack_160 = uStack_1e0;
    uStack_100 = 0;
    uStack_15c = uStack_1dc;
    uStack_158 = uStack_1d8;
    uStack_154 = uStack_1d4;
    uStack_150 = uStack_1d0;
    uStack_14c = uStack_1cc;
    uStack_148 = uStack_1c8;
    uStack_144 = uStack_1c4;
    uStack_140 = uStack_1c0;
    uStack_13c = uStack_1bc;
    uStack_138 = uStack_1b8;
    uStack_134 = uStack_1b4;
    uStack_130 = uStack_1b0;
    iStack_12c = param_1[0x35];
    iStack_128 = param_1[0x36];
    iStack_124 = param_1[0x37];
    iStack_11c = param_1[0x38];
    iStack_118 = param_1[0x39];
    iStack_114 = param_1[0x3a];
    iStack_10c = param_1[0x1d];
    iStack_fc = param_1[0x1f];
    iVar8 = 6;
    do {
      FUN_00791e90();
      piVar7 = piStack_4c;
      iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
    iStack_ec = piStack_4c[0xee];
    iStack_e8 = piStack_4c[0xef];
    iStack_e4 = piStack_4c[0xf0];
    iStack_e0 = piStack_4c[0xf1];
    iStack_dc = piStack_4c[0xf2];
    iStack_d8 = piStack_4c[0xf3];
    iStack_d4 = piStack_4c[0xf4];
    iStack_d0 = piStack_4c[0xf5];
    iStack_cc = piStack_4c[0xf6];
    iStack_c8 = piStack_4c[0xf7];
    iStack_c4 = piStack_4c[0xf8];
    iStack_c0 = piStack_4c[0xf9];
    iStack_bc = piStack_4c[0xfa];
    iStack_b8 = piStack_4c[0xfb];
    iStack_b4 = piStack_4c[0xfc];
    iStack_b0 = piStack_4c[0xfd];
    iStack_ac = piStack_4c[0xfe];
    iStack_a8 = piStack_4c[0xff];
    iStack_a4 = piStack_4c[0x100];
    iStack_a0 = piStack_4c[0x101];
    iStack_9c = piStack_4c[0x102];
    iStack_98 = piStack_4c[0x103];
    iStack_94 = piStack_4c[0x104];
    iStack_90 = piStack_4c[0x105];
    (**(code **)(*param_2 + 0x30))(1,&uStack_1ac,0x120);
    piStack_50 = piVar7 + 0xce;
    iStack_21c = _DAT_018e3fb0;
    iStack_218 = _UNK_018e3fb4;
    iStack_214 = _UNK_018e3fb8;
    uStack_210 = _UNK_018e3fbc;
    uStack_1fc = 0x3f800000;
    iStack_20c = _DAT_018e3fb0;
    iStack_208 = _UNK_018e3fb4;
    iStack_204 = _UNK_018e3fb8;
    uStack_200 = _UNK_018e3fbc;
    uStack_1f8 = *param_3;
    uStack_1f4 = param_3[1];
    uStack_1f0 = param_3[2];
    piVar7 = piVar7 + 0x9e;
    piStack_24 = (int *)0x6;
    do {
      piVar4 = (int *)*piStack_50;
      piVar3 = (int *)&DAT_01eb1b04;
      if (piVar4 != (int *)0x0) {
        piVar3 = piVar4;
      }
      if (*piVar3 != 0) {
        uStack_30 = CONCAT22(uStack_30._2_2_,0x101);
        pcStack_2c = (char *)0x0;
        piStack_28 = (int *)((uint)piStack_28 & 0xffff0000);
        piVar3 = (int *)&DAT_01eb1b04;
        if (piVar4 != (int *)0x0) {
          piVar3 = piVar4;
        }
        (**(code **)(*param_2 + 0x34))(0,*piVar3,&uStack_30);
        cVar1 = FUN_007cce20(piVar7 + 0x6c,&iStack_21c);
        if (cVar1 != '\0') {
          (**(code **)(*param_2 + 0x40))(piVar7[-4],piVar7[-2],piVar7[-1],*piVar7,piVar7[1],0);
        }
      }
      piVar7 = piVar7 + 6;
      piStack_50 = piStack_50 + 2;
      piStack_24 = (int *)((int)piStack_24 + -1);
    } while (piStack_24 != (int *)0x0);
    piStack_24 = (int *)0x0;
    param_1 = piStack_4c;
  }
  if (param_5 == '\0') {
    pcStack_34 = "AdvSunVS";
    uStack_30 = 8;
    pcStack_2c = "AdvSunFS";
    piStack_28 = (int *)&DAT_00000008;
    FUN_00790e00(&pcStack_40,&pcStack_34,2);
    uStack_8._0_1_ = 8;
    if (pcStack_40 != (char *)0x0) {
      dVar10 = (double)((float)param_1[0x2c] * _DAT_01d620d4);
      FUN_01728120();
      fVar11 = (float)dVar10 * DAT_01901f64;
      dVar10 = (double)((float)param_1[0x34] * _DAT_01d620d4);
      FUN_01728120();
      fVar9 = (float)dVar10 * DAT_01901f64;
      (**(code **)(*param_2 + 0x24))(pcStack_40);
      pcStack_2c = (char *)0x30000;
      uStack_30 = 0xf;
      piStack_28 = (int *)((uint)piStack_28 & 0xffffff00);
      fStack_1c = (float)((uint)fStack_1c & 0xffff0000);
      pcStack_18 = (char *)0x0;
      piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
      (**(code **)(*param_2 + 0x3c))(&fStack_1c,&uStack_30,acStack_38);
      piVar7 = (int *)&DAT_01eb1b04;
      if ((int *)param_1[0xe6] != (int *)0x0) {
        piVar7 = (int *)param_1[0xe6];
      }
      if (*piVar7 != 0) {
        fStack_1c = (float)CONCAT22(fStack_1c._2_2_,0x101);
        pcStack_18 = (char *)0x0;
        piStack_14 = (int *)((uint)piStack_14 & 0xffff0000);
        puVar2 = (undefined4 *)&DAT_01eb1b04;
        if ((undefined4 *)param_1[0xe6] != (undefined4 *)0x0) {
          puVar2 = (undefined4 *)param_1[0xe6];
        }
        (**(code **)(*param_2 + 0x34))(0,*puVar2,&fStack_1c);
        piStack_14 = (int *)((float)param_1[0x27] * DAT_01901f64);
        fStack_1c = (float)param_1[0x25] * DAT_01901f64;
        pcStack_18 = (char *)((float)param_1[0x26] * DAT_01901f64);
        FUN_0081b110(&uStack_22c,&fStack_1c,fVar11);
        iStack_108 = param_1[0x1e];
        uStack_1ac = uStack_22c;
        uStack_1a8 = uStack_228;
        uStack_1a4 = uStack_224;
        uStack_1a0 = uStack_220;
        uStack_104 = 0;
        uStack_100 = 0;
        iStack_f0 = param_1[0x1c];
        iStack_19c = iStack_21c;
        iStack_198 = iStack_218;
        iStack_194 = iStack_214;
        uStack_190 = uStack_210;
        iStack_f4 = param_1[0x21];
        iStack_18c = iStack_20c;
        iStack_188 = iStack_208;
        iStack_184 = iStack_204;
        uStack_180 = uStack_200;
        uStack_17c = uStack_1fc;
        uStack_178 = uStack_1f8;
        uStack_174 = uStack_1f4;
        uStack_170 = uStack_1f0;
        iStack_f8 = param_1[0x20];
        uStack_16c = uStack_1ec;
        uStack_168 = uStack_1e8;
        uStack_164 = uStack_1e4;
        uStack_160 = uStack_1e0;
        uStack_15c = uStack_1dc;
        uStack_158 = uStack_1d8;
        uStack_154 = uStack_1d4;
        uStack_150 = uStack_1d0;
        uStack_14c = uStack_1cc;
        uStack_148 = uStack_1c8;
        uStack_144 = uStack_1c4;
        uStack_140 = uStack_1c0;
        uStack_13c = uStack_1bc;
        uStack_138 = uStack_1b8;
        uStack_134 = uStack_1b4;
        uStack_130 = uStack_1b0;
        iStack_12c = param_1[0x28];
        iStack_128 = param_1[0x29];
        iStack_124 = param_1[0x2a];
        iStack_120 = param_1[0x2b];
        iStack_11c = param_1[0x28];
        iStack_118 = param_1[0x29];
        iStack_114 = param_1[0x2a];
        iStack_110 = param_1[0x2b];
        iStack_10c = param_1[0x1d];
        iStack_fc = param_1[0x1f];
        iVar8 = 6;
        do {
          FUN_00791e90();
          iVar8 = iVar8 + -1;
        } while (iVar8 != 0);
        (**(code **)(*param_2 + 0x30))(1,&uStack_1ac,0x120);
        param_1 = piStack_4c;
        (**(code **)(*param_2 + 0x40))
                  (piStack_4c[0xbe],piStack_4c[0xc0],piStack_4c[0xc1],piStack_4c[0xc2],
                   piStack_4c[0xc3],0);
        (**(code **)(*param_2 + 0x40))
                  (param_1[0xbe],param_1[0xc0],param_1[0xc1],param_1[0xc2],param_1[0xc3],0);
        (**(code **)(*param_2 + 0x40))
                  (param_1[0xbe],param_1[0xc0],param_1[0xc1],param_1[0xc2],param_1[0xc3],0);
      }
      piVar7 = (int *)param_1[0xea];
      piVar4 = (int *)&DAT_01eb1b04;
      if (piVar7 != (int *)0x0) {
        piVar4 = piVar7;
      }
      if (*piVar4 != 0) {
        fStack_1c = (float)CONCAT22(fStack_1c._2_2_,0x101);
        piVar4 = (int *)&DAT_01eb1b04;
        if (piVar7 != (int *)0x0) {
          piVar4 = piVar7;
        }
        pcStack_18 = (char *)0x0;
        piStack_14 = (int *)((uint)piStack_14 & 0xffff0000);
        (**(code **)(*param_2 + 0x34))(0,*piVar4,&fStack_1c);
        piStack_14 = (int *)((float)param_1[0x2f] * DAT_01901f64);
        fStack_1c = (float)param_1[0x2d] * DAT_01901f64;
        pcStack_18 = (char *)((float)param_1[0x2e] * DAT_01901f64);
        FUN_0081b110(&uStack_22c,&fStack_1c,fVar9);
        iStack_108 = param_1[0x1e];
        uStack_1ac = uStack_22c;
        uStack_1a8 = uStack_228;
        uStack_1a4 = uStack_224;
        uStack_1a0 = uStack_220;
        uStack_104 = 0;
        uStack_100 = 0;
        iStack_f0 = param_1[0x1c];
        iStack_19c = iStack_21c;
        iStack_198 = iStack_218;
        iStack_194 = iStack_214;
        uStack_190 = uStack_210;
        iStack_f4 = param_1[0x21];
        iStack_18c = iStack_20c;
        iStack_188 = iStack_208;
        iStack_184 = iStack_204;
        uStack_180 = uStack_200;
        uStack_17c = uStack_1fc;
        uStack_178 = uStack_1f8;
        uStack_174 = uStack_1f4;
        uStack_170 = uStack_1f0;
        iStack_f8 = param_1[0x20];
        uStack_16c = uStack_1ec;
        uStack_168 = uStack_1e8;
        uStack_164 = uStack_1e4;
        uStack_160 = uStack_1e0;
        uStack_15c = uStack_1dc;
        uStack_158 = uStack_1d8;
        uStack_154 = uStack_1d4;
        uStack_150 = uStack_1d0;
        uStack_14c = uStack_1cc;
        uStack_148 = uStack_1c8;
        uStack_144 = uStack_1c4;
        uStack_140 = uStack_1c0;
        uStack_13c = uStack_1bc;
        uStack_138 = uStack_1b8;
        uStack_134 = uStack_1b4;
        uStack_130 = uStack_1b0;
        iStack_12c = param_1[0x30];
        iStack_128 = param_1[0x31];
        iStack_124 = param_1[0x32];
        iStack_120 = param_1[0x33];
        iStack_11c = param_1[0x30];
        iStack_118 = param_1[0x31];
        iStack_114 = param_1[0x32];
        iStack_110 = param_1[0x33];
        iStack_10c = param_1[0x1d];
        iStack_fc = param_1[0x1f];
        iVar8 = 6;
        do {
          FUN_00791e90();
          iVar8 = iVar8 + -1;
        } while (iVar8 != 0);
        (**(code **)(*param_2 + 0x30))(1,&uStack_1ac,0x120);
        param_1 = piStack_4c;
        (**(code **)(*param_2 + 0x40))
                  (piStack_4c[0xbe],piStack_4c[0xc0],piStack_4c[0xc1],piStack_4c[0xc2],
                   piStack_4c[0xc3],0);
      }
    }
    piVar7 = piStack_3c;
    uStack_8._0_1_ = 4;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar4 = piVar7 + 2;
        iVar8 = *piVar4 + -1;
        *piVar4 = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    if (param_4 == 0) {
      pcStack_20 = "AdvStarsVS";
      fStack_1c = 1.4013e-44;
      pcStack_18 = "AdvStarsFS";
      piStack_14 = (int *)&DAT_0000000a;
      FUN_00790e00(&pcStack_2c,&pcStack_20,2);
      uStack_8._0_1_ = 0xb;
      if (((pcStack_2c != (char *)0x0) && (param_1[0x12e] != 3)) &&
         ((param_1[0x132] != 0 || (param_1[0x138] != 0)))) {
        (**(code **)(*param_2 + 0x24))(pcStack_2c);
        pcStack_18 = (char *)0x60006;
        fStack_1c = 2.10195e-44;
        piStack_14 = (int *)((uint)piStack_14 & 0xffffff00);
        uStack_44 = uStack_44 & 0xffff0000;
        pcStack_40 = (char *)0x0;
        piStack_3c = (int *)((uint)piStack_3c & 0xffffff00);
        (**(code **)(*param_2 + 0x3c))(&uStack_44,&fStack_1c,acStack_38);
        puVar2 = (undefined4 *)FUN_01165df0();
        uStack_1ac = *puVar2;
        uStack_1a8 = puVar2[1];
        uStack_1a4 = puVar2[2];
        uStack_1a0 = puVar2[3];
        iStack_19c = puVar2[4];
        iStack_198 = puVar2[5];
        iStack_194 = puVar2[6];
        uStack_190 = puVar2[7];
        iStack_18c = puVar2[8];
        iStack_188 = puVar2[9];
        iStack_184 = puVar2[10];
        uStack_180 = puVar2[0xb];
        uStack_17c = puVar2[0xc];
        uStack_178 = puVar2[0xd];
        uStack_174 = puVar2[0xe];
        uStack_170 = puVar2[0xf];
        uStack_16c = uStack_1ec;
        uStack_168 = uStack_1e8;
        uStack_164 = uStack_1e4;
        uStack_160 = uStack_1e0;
        uStack_15c = uStack_1dc;
        uStack_158 = uStack_1d8;
        uStack_154 = uStack_1d4;
        uStack_150 = uStack_1d0;
        uStack_14c = uStack_1cc;
        uStack_148 = uStack_1c8;
        uStack_144 = uStack_1c4;
        uStack_140 = uStack_1c0;
        uStack_13c = uStack_1bc;
        uStack_138 = uStack_1b8;
        uStack_134 = uStack_1b4;
        uStack_130 = uStack_1b0;
        piVar7 = (int *)FUN_0115ee70();
        iStack_12c = *piVar7;
        iStack_128 = piVar7[1];
        iStack_124 = piVar7[2];
        iStack_120 = 0x3f800000;
        piVar7 = (int *)FUN_0115ee70();
        iVar8 = 6;
        iStack_11c = *piVar7;
        iStack_118 = piVar7[1];
        iStack_114 = piVar7[2];
        iStack_110 = _DAT_018e3fb0;
        iStack_10c = _UNK_018e3fb4;
        iStack_108 = _UNK_018e3fb8;
        uStack_104 = _UNK_018e3fbc;
        iStack_f0 = 0;
        uStack_100 = 0;
        iStack_fc = 0;
        iStack_f8 = 0;
        iStack_f4 = 0;
        do {
          FUN_00791e90();
          iVar8 = iVar8 + -1;
        } while (iVar8 != 0);
        (**(code **)(*param_2 + 0x30))(1,&uStack_1ac,0x120);
        piVar7 = piStack_4c;
        uStack_44 = CONCAT22(uStack_44._2_2_,1);
        pcStack_40 = (char *)0x0;
        piStack_3c = (int *)((uint)piStack_3c & 0xffff0000);
        (**(code **)(*param_2 + 0x34))
                  (0,*(undefined4 *)(*(int *)(*piStack_4c + 0x4ec) + 0x24),&uStack_44);
        puVar2 = (undefined4 *)piVar7[0x132];
        if (puVar2 != (undefined4 *)0x0) {
          (**(code **)(*param_2 + 0x40))(*puVar2,puVar2[2],puVar2[3],puVar2[4],puVar2[5],0);
        }
        if ((piVar7[0x12e] != 2) &&
           (puVar2 = (undefined4 *)piVar7[0x138], puVar2 != (undefined4 *)0x0)) {
          (**(code **)(*param_2 + 0x40))(*puVar2,puVar2[2],puVar2[3],puVar2[4],puVar2[5],0);
        }
      }
      piVar7 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar8 = piStack_28[1] + -1;
        piStack_28[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar4 = piVar7 + 2;
          iVar8 = *piVar4 + -1;
          *piVar4 = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
  }
  piVar7 = piStack_54;
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_54[1] + -1;
    piStack_54[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar4 = piVar7 + 2;
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_0152dda0(uStack_5c,uStack_58,uStack_74);
  uStack_8 = 0xd;
  FUN_0152dda0(uStack_64,uStack_60,uStack_84);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12567 ; VA 0x008216c0 ; FUN_008216c0 */

int __thiscall FUN_008216c0(int param_1,int *param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  bool bVar8;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6469;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 0;
  iStack_1c = param_1;
  if (param_5 == 0) {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0081c590();
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_00819ed0(param_5,param_1);
    puVar6 = (undefined4 *)(**(code **)(*param_2 + 0x3c))(&uStack_28,0,param_5 * 0x24,0x24,1);
    puStack_14 = (undefined4 *)(param_1 + 0x10);
    uVar7 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *puStack_14 = uVar7;
    piVar4 = *(int **)(param_1 + 0x14);
    *(undefined4 *)(param_1 + 0x14) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    iStack_20 = FUN_01674e20(0x18);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    bVar8 = iStack_20 == 0;
    if (bVar8) {
      uVar7 = 0;
    }
    else {
      uStack_28 = 0;
      piStack_24 = (int *)0x0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_18 = 1;
      uVar7 = FUN_0147c0e0(auStack_30,&param_3,puStack_14,&uStack_28);
      uStack_8 = 3;
      uStack_18 = 3;
      uVar7 = FUN_0147c720(uVar7,2,0,0,param_5);
    }
    param_5 = *(int *)(iStack_1c + 0xc);
    *(undefined4 *)(iStack_1c + 0xc) = uVar7;
    iVar5 = iStack_1c;
    if (param_5 != 0) {
      piVar4 = *(int **)(param_5 + 4);
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = FUN_01674ea0(param_5,0x18);
    }
    if (!bVar8) {
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piVar4 = piStack_2c + 1;
        iVar2 = *piVar4;
        iVar5 = *piVar4;
        *piVar4 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar4 = piStack_2c + 2;
          iVar2 = *piVar4;
          iVar5 = *piVar4;
          *piVar4 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            iVar5 = (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
    piVar4 = piStack_24;
    if ((!bVar8) && (piStack_24 != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar5 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  piVar4 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 12568 ; VA 0x008218e0 ; FUN_008218e0 */

void __thiscall FUN_008218e0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  
  FUN_0081eec0(param_2);
  *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 8;
  iVar1 = *(int *)(param_1 + 0xec);
  if (iVar1 == 0) {
    FUN_0081c590();
    FUN_0081c590();
    return;
  }
  dVar4 = (double)*(float *)(param_1 + 0xb8);
  iVar2 = *(int *)(param_1 + 0x4b8);
  if (DAT_01901f80 < dVar4) {
    if (DAT_01901f70 < dVar4) {
      if (DAT_018e2380 < dVar4) {
        *(undefined4 *)(param_1 + 0x4b8) = 0;
        iVar3 = 0;
      }
      else {
        *(undefined4 *)(param_1 + 0x4b8) = 1;
        iVar3 = 1;
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x4b8) = 2;
      iVar3 = 2;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x4b8) = 3;
    iVar3 = 3;
  }
  if ((*(int *)(param_1 + 0x4d8) - *(int *)(param_1 + 0x4d4) >> 4) +
      (*(int *)(param_1 + 0x4c0) - *(int *)(param_1 + 0x4bc) >> 4) == iVar1) {
    if (iVar2 == iVar3) {
      return;
    }
  }
  else {
    FUN_0081f950(iVar1);
  }
  FUN_00822280();
  FUN_00822420();
  return;
}



/* FUNCTION 12569 ; VA 0x008219e0 ; FUN_008219e0 */

void __thiscall FUN_008219e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_8c [4];
  int *piStack_88;
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined uStack_54;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6502;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_18 = CONCAT31(uStack_18._1_3_,-(DAT_01d6200c != '\0')) & 0xffffff04;
  uStack_14 = *(undefined4 *)(*param_1 + 0x4ec);
  ExceptionList = &pvStack_10;
  FUN_005542c0("Sky.SkyboxLf",0xc);
  uStack_8 = 0;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2 + 0x18,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xda] = iVar2;
  piVar5 = (int *)param_1[0xdb];
  param_1[0xdb] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxRt",0xc);
  uStack_8 = 2;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2 + 0x30,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xdc] = iVar2;
  piVar5 = (int *)param_1[0xdd];
  param_1[0xdd] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxUp",0xc);
  uStack_8 = 4;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xde] = iVar2;
  piVar5 = (int *)param_1[0xdf];
  param_1[0xdf] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxDn",0xc);
  uStack_8 = 6;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2 + 0x78,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xe0] = iVar2;
  piVar5 = (int *)param_1[0xe1];
  param_1[0xe1] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxFt",0xc);
  uStack_8 = 8;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2 + 0x60,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xe2] = iVar2;
  piVar5 = (int *)param_1[0xe3];
  param_1[0xe3] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("Sky.SkyboxBk",0xc);
  uStack_8 = 10;
  uVar4 = FUN_00d102b0(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  piVar5 = (int *)FUN_00782550(auStack_20,param_2 + 0x48,uStack_18,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xe4] = iVar2;
  piVar5 = (int *)param_1[0xe5];
  param_1[0xe5] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    uVar6 = auStack_38[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_38[0] - 4);
      uVar7 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = 0;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = 0;
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_54 = 0;
  uStack_8 = 0xc;
  piVar5 = (int *)FUN_00782480(auStack_20,param_2 + 0x90,4,auStack_84,0x425c0000,0);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xe8] = iVar2;
  piVar5 = (int *)param_1[0xe9];
  param_1[0xe9] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_74 = 0;
  uStack_70 = 0xf;
  auStack_84[0] = 0;
  uStack_5c = 0;
  uStack_58 = 0xf;
  uStack_6c = 0;
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_54 = 0;
  uStack_8 = 0xd;
  piVar5 = (int *)FUN_00782480(auStack_8c,param_2 + 0xa8,4,auStack_84,0x425c0000,0);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xec] = iVar2;
  piVar5 = (int *)param_1[0xed];
  param_1[0xed] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_88 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_88[1] + -1;
    piStack_88[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_88)();
      LOCK();
      piVar5 = piStack_88 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_88 + 4))();
      }
    }
  }
  FUN_00637950();
  param_1[1] = param_1[1] | 0xf;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12570 ; VA 0x00822280 ; FUN_00822280 */

void __fastcall FUN_00822280(int param_1)

{
  float fVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined8 *puVar5;
  double dVar6;
  float fVar7;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  uint uStack_c;
  
  if ((*(int *)(param_1 + 0x4bc) != *(int *)(param_1 + 0x4c0)) &&
     (iVar2 = (**(code **)(**(int **)(param_1 + 0x4cc) + 0x10))(), iVar2 != 0)) {
    iVar3 = *(int *)(param_1 + 0x4bc);
    uStack_c = 0;
    if (*(int *)(param_1 + 0x4c0) - iVar3 >> 4 != 0) {
      iVar4 = 0;
      puVar5 = (undefined8 *)(iVar2 + 0xc);
      do {
        *(undefined8 *)((int)puVar5 + -0xc) = *(undefined8 *)(iVar4 + iVar3);
        *(undefined4 *)((int)puVar5 + -4) = *(undefined4 *)(iVar4 + 8 + iVar3);
        fVar1 = *(float *)(iVar4 + 0xc + *(int *)(param_1 + 0x4bc));
        fVar7 = DAT_018df57c;
        if ((*(int *)(param_1 + 0x4b8) != 0) &&
           (fVar7 = DAT_01901f38, *(int *)(param_1 + 0x4b8) == 1)) {
          fVar7 = DAT_01901f34;
        }
        iVar2 = FUN_0171d737();
        dVar6 = (double)((float)iVar2 / DAT_01901f68 + 0.0);
        if (DAT_01901f48 <= dVar6) {
          if (DAT_01901f50 <= dVar6) {
            if (DAT_01901f58 <= dVar6) {
              uStack_1c = 0x3f400000;
              uStack_18 = 0x3f000000;
            }
            else {
              uStack_1c = 0x3f333333;
              uStack_18 = 0x3f4ccccd;
            }
          }
          else {
            uStack_1c = 0x3f800000;
            uStack_18 = 0x3f800000;
          }
          uStack_14 = 0x3f800000;
        }
        else {
          uStack_1c = 0x3f800000;
          uStack_18 = 0x3f4ccccd;
          uStack_14 = 0x3f333333;
        }
        iVar4 = iVar4 + 0x10;
        uStack_c = uStack_c + 1;
        *(undefined4 *)(puVar5 + 1) = uStack_1c;
        *(undefined4 *)((int)puVar5 + 0xc) = uStack_18;
        *(undefined4 *)(puVar5 + 2) = uStack_14;
        *(float *)((int)puVar5 + 0x14) = fVar1 * fVar7;
        *puVar5 = 0;
        puVar5 = (undefined8 *)((int)puVar5 + 0x24);
        iVar3 = *(int *)(param_1 + 0x4bc);
      } while (uStack_c < (uint)(*(int *)(param_1 + 0x4c0) - iVar3 >> 4));
    }
    (**(code **)(**(int **)(param_1 + 0x4cc) + 0x14))();
  }
  return;
}



/* FUNCTION 12571 ; VA 0x00822420 ; FUN_00822420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00822420(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  float fVar5;
  double dVar6;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  uint uStack_c;
  
  if ((*(int *)(param_1 + 0x4d4) != *(int *)(param_1 + 0x4d8)) &&
     (iVar1 = (**(code **)(**(int **)(param_1 + 0x4e4) + 0x10))(), iVar1 != 0)) {
    iVar2 = *(int *)(param_1 + 0x4d4);
    uStack_c = 0;
    if (*(int *)(param_1 + 0x4d8) - iVar2 >> 4 != 0) {
      iVar3 = 0;
      puVar4 = (undefined8 *)(iVar1 + 0xc);
      do {
        *(undefined8 *)((int)puVar4 + -0xc) = *(undefined8 *)(iVar3 + iVar2);
        *(undefined4 *)((int)puVar4 + -4) = *(undefined4 *)(iVar3 + 8 + iVar2);
        iVar1 = FUN_0171d737();
        fVar5 = DAT_018ce2f8;
        if (*(int *)(param_1 + 0x4b8) == 1) {
          fVar5 = DAT_018ce2f4;
        }
        fVar5 = *(float *)(iVar3 + 0xc + *(int *)(param_1 + 0x4d4)) *
                (((float)iVar1 * _DAT_01901f40) / DAT_01901f68 + DAT_018fde64) * fVar5 +
                DAT_018fabe0;
        iVar1 = FUN_0171d737();
        dVar6 = (double)((float)iVar1 / DAT_01901f68 + 0.0);
        if (DAT_01901f48 <= dVar6) {
          if (DAT_01901f50 <= dVar6) {
            if (DAT_01901f58 <= dVar6) {
              uStack_1c = 0x3f400000;
              uStack_18 = 0x3f000000;
            }
            else {
              uStack_1c = 0x3f333333;
              uStack_18 = 0x3f4ccccd;
            }
          }
          else {
            uStack_1c = 0x3f800000;
            uStack_18 = 0x3f800000;
          }
          uStack_14 = 0x3f800000;
        }
        else {
          uStack_1c = 0x3f800000;
          uStack_18 = 0x3f4ccccd;
          uStack_14 = 0x3f333333;
        }
        iVar3 = iVar3 + 0x10;
        uStack_c = uStack_c + 1;
        *(undefined4 *)(puVar4 + 1) = uStack_1c;
        *(undefined4 *)((int)puVar4 + 0xc) = uStack_18;
        *(undefined4 *)(puVar4 + 2) = uStack_14;
        *(float *)((int)puVar4 + 0x14) = fVar5;
        *puVar4 = 0;
        puVar4 = (undefined8 *)((int)puVar4 + 0x24);
        iVar2 = *(int *)(param_1 + 0x4d4);
      } while (uStack_c < (uint)(*(int *)(param_1 + 0x4d8) - iVar2 >> 4));
    }
    (**(code **)(**(int **)(param_1 + 0x4e4) + 0x14))();
  }
  return;
}



/* FUNCTION 12572 ; VA 0x008225e0 ; FUN_008225e0 */

undefined4 * __thiscall FUN_008225e0(undefined4 *param_1,int param_2)

{
  void *pvVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  pvVar1 = ExceptionList;
  puStack_c = &LAB_017b6544;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = param_2;
  *(undefined2 *)(param_1 + 0x18) = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  uStack_8 = 3;
  uStack_7 = 0;
  if (DAT_01d62104 == '\0') {
    ExceptionList = pvVar1;
    return param_1;
  }
  puStack_14 = param_1;
  (**(code **)(**(int **)(param_2 + 0x3c) + 0x30))(aiStack_2c);
  _uStack_8 = CONCAT31(uStack_7,4);
  iVar4 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  if (((((*(char *)(iVar4 + 0x16) == '\0') || (DAT_01d6210c != '\0')) ||
       (cVar2 = FUN_00558b60(aiStack_2c,&DAT_019183f4), cVar2 != '\0')) ||
      ((cVar2 = FUN_00558b60(aiStack_2c,"glsles"), cVar2 != '\0' ||
       (cVar2 = FUN_00558b60(aiStack_2c,"glsles3"), cVar2 != '\0')))) ||
     ((cVar2 = FUN_00558b60(aiStack_2c,&DAT_019183fc), cVar2 != '\0' ||
      ((cVar2 = FUN_00558b60(aiStack_2c,"d3d10"), cVar2 != '\0' ||
       (cVar2 = FUN_00558b60(aiStack_2c,"d3d10_1"), cVar2 != '\0')))))) {
    cVar2 = '\x01';
  }
  *(char *)(param_1 + 0x18) = cVar2;
  uVar3 = FUN_00558b60(aiStack_2c,&DAT_019183f4);
  *(undefined *)((int)param_1 + 0x61) = uVar3;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    iVar4 = aiStack_2c[0];
    if (0xfff < uVar5) {
      iVar4 = *(int *)(aiStack_2c[0] + -4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12573 ; VA 0x00822820 ; FUN_00822820 */

void __fastcall FUN_00822820(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x80);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x78);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x70);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x68);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x008228c2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 12574 ; VA 0x008228d0 ; FUN_008228d0 */

void __thiscall FUN_008228d0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  char *pcStack_4c;
  uint uStack_48;
  char *pcStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  ushort uStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  undefined uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b65f8;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 0x84) == 3) && (*(char *)(param_1 + 0x61) == '\0')) {
    iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3bd8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eb3bd8);
      if (DAT_01eb3bd8 == -1) {
        uStack_8 = 0;
        uVar6 = FUN_0152dab0("Render","CloudsComp",0xffffffff);
        DAT_01eb3bd4 = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb3bd0 = (undefined4)uVar6;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb3bd8);
      }
    }
    uStack_28 = DAT_01eb3bd0;
    uStack_24 = DAT_01eb3bd4;
    uVar6 = FUN_0152d930(DAT_01eb3bd0,DAT_01eb3bd4);
    uStack_8 = 1;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3be8) {
      FUN_016f3809(&DAT_01eb3be8);
      if (DAT_01eb3be8 == -1) {
        uStack_8._0_1_ = 2;
        uVar7 = FUN_0152dab0(&DAT_018fb928,"CloudsComp",0xffffffff);
        DAT_01eb3be4 = (undefined4)((ulonglong)uVar7 >> 0x20);
        DAT_01eb3be0 = (undefined4)uVar7;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb3be8);
      }
    }
    uStack_20 = DAT_01eb3be0;
    uStack_1c = DAT_01eb3be4;
    uVar7 = FUN_0152d930(DAT_01eb3be0,DAT_01eb3be4);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    pcStack_4c = "CloudsVS";
    uStack_48 = 8;
    pcStack_44 = "CloudsCompFS";
    uStack_40 = 0xc;
    FUN_00790e00(&iStack_30,&pcStack_4c,2);
    iStack_18 = iStack_30;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar2 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    if ((iStack_18 != 0) && (*(int *)(param_1 + 0x7c) != 0)) {
      uStack_14 = 0x104;
      uStack_12 = 0;
      uStack_38 = 0x4030403;
      uStack_3c = 0xf;
      uStack_34 = uStack_34 & 0xff00;
      uStack_48 = uStack_48 & 0xffff0000;
      pcStack_44 = (char *)0x0;
      uStack_40 = uStack_40 & 0xffffff00;
      (**(code **)(*param_2 + 0x3c))(&uStack_48,&uStack_3c,&uStack_14);
      (**(code **)(*param_2 + 0x24))(iStack_18);
      uStack_3c._0_2_ = 0x101;
      uStack_38 = 0;
      uStack_34 = 0;
      (**(code **)(*param_2 + 0x34))(0,**(undefined4 **)(param_1 + 0x7c),&uStack_3c);
      uStack_3c = CONCAT22(uStack_3c._2_2_,0x101);
      uStack_38 = 0;
      uStack_34 = 0;
      puVar3 = *(undefined4 **)(*(int *)(*(int *)(*(int *)(param_1 + 0x5c) + 0x4f8) + 0x44c) + 0x84)
      ;
      puVar5 = (undefined4 *)&DAT_01eb1b04;
      if (puVar3 != (undefined4 *)0x0) {
        puVar5 = puVar3;
      }
      (**(code **)(*param_2 + 0x34))(0xf,*puVar5,&uStack_3c);
      (**(code **)(*param_2 + 0x30))(2,param_1,0x10);
      puVar3 = *(undefined4 **)(*(int *)(*(int *)(param_1 + 0x5c) + 0x4f8) + 0x41c);
      (**(code **)(*param_2 + 0x40))(*puVar3,puVar3[2],puVar3[3],puVar3[4],puVar3[5],0);
      *(undefined4 *)(param_1 + 0x7c) = 0;
      piVar4 = *(int **)(param_1 + 0x80);
      *(undefined4 *)(param_1 + 0x80) = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar2 = piVar4[1] + -1;
        piVar4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    FUN_0152dda0(uStack_20,uStack_1c,uVar7);
    uStack_8 = 7;
    FUN_0152dda0(uStack_28,uStack_24,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12575 ; VA 0x00822c20 ; FUN_00822c20 */

void __fastcall FUN_00822c20(int param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6630;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x84);
  if (iVar4 == 0) {
    *(undefined4 *)(param_1 + 0x84) = 1;
    return;
  }
  if (iVar4 == 1) {
    if ((DAT_01d62104 != '\0') && (*(char *)(param_1 + 0x60) != '\0')) {
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = 0;
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      uVar3 = FUN_00782480(auStack_18,&DAT_01d6212c,0,auStack_64,0x425c0000,0);
      FUN_005587e0(uVar3);
      FUN_00550b30();
      FUN_00637950();
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      uStack_3c = 0;
      uStack_38 = 0xf;
      uStack_4c = 0;
      uStack_24 = 0;
      uStack_20 = 0xf;
      uStack_34 = 0;
      uStack_8 = 1;
      uVar3 = FUN_00782480(auStack_18,&DAT_01d6215c,0,auStack_64,0x425c0000,0);
      FUN_005587e0(uVar3);
      FUN_00550b30();
      FUN_00637950();
      *(undefined4 *)(param_1 + 0x84) = 2;
      ExceptionList = pvStack_10;
      return;
    }
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = 0;
    uStack_24 = 0;
    uStack_20 = 0xf;
    uStack_34 = 0;
    uStack_8 = 2;
    ExceptionList = &pvStack_10;
    uVar3 = FUN_00782480(auStack_18,&DAT_01d62114,0,auStack_64,0x425c0000,0);
    FUN_005587e0(uVar3);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_00637950();
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = 0;
    uStack_3c = 0;
    uStack_38 = 0xf;
    uStack_4c = 0;
    uStack_24 = 0;
    uStack_20 = 0xf;
    uStack_34 = 0;
    uStack_8 = 3;
    uVar3 = FUN_00782480(auStack_18,&DAT_01d62144,0,auStack_64,0x425c0000,0);
    FUN_005587e0(uVar3);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar2 = piStack_14 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    FUN_00637950();
    *(undefined4 *)(param_1 + 0x84) = 2;
    ExceptionList = pvStack_10;
    return;
  }
  if (iVar4 == 2) {
    if ((DAT_01d62104 == '\0') || (*(char *)(param_1 + 0x60) == '\0')) {
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    else {
      iVar4 = *(int *)(param_1 + 100);
    }
    if ((((iVar4 != 0) && (*(int *)(iVar4 + 8) == 3)) && (*(int *)(param_1 + 0x74) != 0)) &&
       (*(int *)(*(int *)(param_1 + 0x74) + 8) == 3)) {
      *(undefined4 *)(param_1 + 0x84) = 3;
    }
  }
  return;
}



/* FUNCTION 12576 ; VA 0x00822f40 ; FUN_00822f40 */

void __thiscall
FUN_00822f40(float *param_1,int *param_2,undefined4 param_3,int param_4,uint param_5,
            undefined4 param_6)

{
  double dVar1;
  int iVar2;
  int iVar3;
  uint3 uVar4;
  uint uVar5;
  uint uVar6;
  float *pfVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined4 *puVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined8 uVar15;
  undefined4 uVar16;
  float afStack_104 [5];
  float fStack_f0;
  undefined4 uStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  undefined4 uStack_b4;
  undefined auStack_78 [8];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  char *pcStack_2c;
  uint uStack_28;
  char *pcStack_24;
  char *pcStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6668;
  pvStack_10 = ExceptionList;
  if ((param_1[0x21] == 4.2039e-45) && (*(char *)((int)param_1 + 0x61) == '\0')) {
    iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    if ((*(int *)(iVar2 + 0x34) < DAT_01eb3bb8) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3bb8), DAT_01eb3bb8 == -1)) {
      uStack_8 = 0;
      uVar15 = FUN_0152dab0("Render","Clouds",0xffffffff);
      DAT_01eb3bb4 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eb3bb0 = (undefined4)uVar15;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3bb8);
    }
    uStack_50 = DAT_01eb3bb0;
    uStack_70 = DAT_01eb3bb0;
    uStack_4c = DAT_01eb3bb4;
    uStack_6c = DAT_01eb3bb4;
    uStack_68 = FUN_0152d930(DAT_01eb3bb0,DAT_01eb3bb4);
    uStack_8 = 1;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3bc8) {
      FUN_016f3809(&DAT_01eb3bc8);
      if (DAT_01eb3bc8 == -1) {
        uStack_8._0_1_ = 2;
        uVar15 = FUN_0152dab0(&DAT_018fb928,"Clouds",0xffffffff);
        DAT_01eb3bc4 = (undefined4)((ulonglong)uVar15 >> 0x20);
        DAT_01eb3bc0 = (undefined4)uVar15;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb3bc8);
      }
    }
    uStack_48 = DAT_01eb3bc0;
    uStack_60 = DAT_01eb3bc0;
    uStack_44 = DAT_01eb3bc4;
    uStack_5c = DAT_01eb3bc4;
    uStack_58 = FUN_0152d930(DAT_01eb3bc0,DAT_01eb3bc4);
    fVar14 = DAT_018ce2f8;
    fVar13 = DAT_018ce2f4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar2 = *(int *)(param_5 + 0x28);
    iVar3 = *(int *)(param_5 + 0x2c);
    uVar16 = 3;
    dVar1 = (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)];
    fVar12 = DAT_018ce2f4 / (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]);
    uVar5 = iVar2 + 1U >> 1;
    uStack_34 = 1;
    if (uVar5 != 0) {
      uStack_34 = uVar5;
    }
    uVar6 = iVar3 + 1U >> 1;
    uVar5 = 1;
    if (uVar6 != 0) {
      uVar5 = uVar6;
    }
    *param_1 = DAT_018ce2f8 / (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]);
    param_1[2] = fVar12;
    param_1[1] = fVar14 / (float)((double)iVar3 + dVar1);
    param_1[3] = fVar13 / (float)((double)iVar3 + dVar1);
    uStack_30 = uVar5;
    pfVar7 = (float *)FUN_00799920(auStack_40,uStack_34,uVar5,3);
    fVar13 = *pfVar7;
    fVar14 = pfVar7[1];
    *pfVar7 = 0.0;
    pfVar7[1] = 0.0;
    param_1[0x1f] = fVar13;
    piVar8 = (int *)param_1[0x20];
    param_1[0x20] = fVar14;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar2 = piVar8[1] + -1;
      piVar8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uVar16 = 0x8230e0;
        (**(code **)*piVar8)();
        LOCK();
        iVar2 = piVar8[2] + -1;
        piVar8[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          uVar16 = 0x8230f3;
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piVar8 = piStack_3c;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uVar16 = 0x82310a;
        (**(code **)*piStack_3c)();
        LOCK();
        piVar10 = piVar8 + 2;
        iVar2 = *piVar10;
        *piVar10 = *piVar10 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          uVar16 = 0x82311c;
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    if (param_1[0x1f] != 0.0) {
      puVar9 = (undefined4 *)&DAT_01eb1b04;
      if ((undefined4 *)param_1[0x1d] != (undefined4 *)0x0) {
        puVar9 = (undefined4 *)param_1[0x1d];
      }
      piStack_3c = (int *)*puVar9;
      if ((DAT_01d62104 == '\0') || (*(char *)(param_1 + 0x18) == '\0')) {
        piVar8 = (int *)param_1[0x1b];
      }
      else {
        piVar8 = (int *)param_1[0x19];
      }
      piVar10 = (int *)&DAT_01eb1b04;
      if (piVar8 != (int *)0x0) {
        piVar10 = piVar8;
      }
      iStack_38 = *piVar10;
      if ((piStack_3c != (int *)0x0) && (iStack_38 != 0)) {
        pcStack_2c = "CloudsFS";
        uStack_28 = 0x1918418;
        pcStack_24 = "Clouds2dFS";
        pcStack_20 = "Clouds2dFoVFixFS";
        FUN_0056a400((&pcStack_2c)[(uint)DAT_01d620fc + (uint)*(byte *)(param_1 + 0x18) * 2]);
        piVar8 = (int *)FUN_00779c60(auStack_78,"CloudsVS",8,uVar5,uVar16);
        iVar2 = *piVar8;
        FUN_00550b30();
        if (iVar2 != 0) {
          FUN_0147bca0();
          fStack_c0 = param_1[0x14];
          fStack_bc = param_1[0x15];
          fStack_b8 = param_1[0x16];
          uStack_c4 = 1;
          uStack_b4 = 0;
          (**(code **)(*param_2 + 0x14))(*(undefined4 *)((int)param_1[0x1f] + 8),0,1,&uStack_c4,0);
          uVar4 = (uint3)param_5;
          param_5 = (uint)(uVar4 & 0xff);
          uStack_18 = 0x1000100;
          uStack_1c = 0xf;
          uStack_14 = (ushort)uStack_14._1_1_ << 8;
          uStack_28 = uStack_28 & 0xffff0000;
          pcStack_24 = (char *)0x0;
          pcStack_20 = (char *)((uint)pcStack_20 & 0xffffff00);
          (**(code **)(*param_2 + 0x3c))(&uStack_28,&uStack_1c,(int)&param_5 + 1);
          (**(code **)(*param_2 + 0x24))(iVar2);
          uStack_1c._0_2_ = 1;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(0,iStack_38,&uStack_1c);
          uStack_1c._0_2_ = 1;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(1,piStack_3c,&uStack_1c);
          uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
          uStack_18 = 0;
          uStack_14 = 0;
          puVar9 = *(undefined4 **)(*(int *)(*(int *)((int)param_1[0x17] + 0x4f8) + 0x44c) + 0x84);
          puVar11 = (undefined4 *)&DAT_01eb1b04;
          if (puVar9 != (undefined4 *)0x0) {
            puVar11 = puVar9;
          }
          (**(code **)(*param_2 + 0x34))(0xf,*puVar11,&uStack_1c);
          (**(code **)(*param_2 + 0x30))(0,param_6,0x350);
          if (DAT_01d620fc == 0) {
            fVar13 = *(float *)(param_4 + 0x70);
            pcStack_20 = (char *)(fVar13 * DAT_018f7860);
            fVar14 = DAT_018ce2f8 /
                     (float)((double)(int)uStack_30 +
                            (double)(&DAT_018c0d90)[-((int)uStack_30 >> 0x1f)]);
            uStack_28 = (uint)(fVar14 * fVar13);
            fVar13 = (float)((uint)(fVar14 * (float)((double)(int)uStack_34 +
                                                    (double)(&DAT_018c0d90)
                                                            [-((int)uStack_34 >> 0x1f)])) ^
                            DAT_018c4ea0) * fVar13;
            pcStack_2c = (char *)((DAT_018ce2f8 /
                                  (float)((double)(int)uStack_34 +
                                         (double)(&DAT_018c0d90)[-((int)uStack_34 >> 0x1f)])) *
                                 fVar13);
            pcStack_24 = (char *)(fVar13 * DAT_018f7860);
          }
          else {
            FUN_01165e00(afStack_104);
            uStack_28 = (uint)(DAT_018daf58 /
                              (float)((double)(int)uStack_30 +
                                     (double)(&DAT_018c0d90)[-((int)uStack_30 >> 0x1f)]));
            pcStack_2c = (char *)(DAT_018daf58 /
                                 (float)((double)(int)uStack_34 +
                                        (double)(&DAT_018c0d90)[-((int)uStack_34 >> 0x1f)]));
            pcStack_24 = (char *)afStack_104[0];
            pcStack_20 = (char *)fStack_f0;
          }
          param_1[0x10] = (float)pcStack_2c;
          param_1[0x11] = (float)uStack_28;
          param_1[0x12] = (float)pcStack_24;
          param_1[0x13] = (float)pcStack_20;
          (**(code **)(*param_2 + 0x30))(1,param_1 + 0x10,0x10);
          pcStack_2c = (char *)0x0;
          uStack_28 = 0;
          pcStack_24 = (char *)0x3f800000;
          pcStack_20 = (char *)(*(float *)((int)param_1[0x17] + 0x28) / DAT_018ce324);
          param_1[4] = 0.0;
          param_1[5] = 0.0;
          param_1[6] = 1.0;
          param_1[7] = (float)pcStack_20;
          (**(code **)(*param_2 + 0x30))(2,param_1 + 4,0x30);
          FUN_00778470(*(undefined4 *)(*(int *)((int)param_1[0x17] + 0x4f8) + 0x41c),0);
          (**(code **)(*param_2 + 0x18))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_0152dda0(uStack_48,uStack_44,uStack_58);
    uStack_8 = 0xb;
    FUN_0152dda0(uStack_50,uStack_4c,uStack_68);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12577 ; VA 0x008235b0 ; FUN_008235b0 */

void __thiscall FUN_008235b0(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  
  *(undefined4 *)(param_1 + 0x50) = *param_3;
  *(undefined4 *)(param_1 + 0x54) = param_3[1];
  *(undefined4 *)(param_1 + 0x58) = param_3[2];
  puVar4 = (undefined4 *)&stack0x0000000c;
  if (*(int *)(param_2 + 0x24) != 0) {
    puVar4 = (undefined4 *)&stack0x0000001c;
  }
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *(undefined4 *)(param_1 + 0x20) = *puVar4;
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  *(undefined4 *)(param_1 + 0x28) = uVar2;
  *(undefined4 *)(param_1 + 0x2c) = uVar3;
  *(undefined4 *)(param_1 + 0x30) = in_stack_0000002c;
  *(undefined4 *)(param_1 + 0x34) = in_stack_00000030;
  *(undefined4 *)(param_1 + 0x38) = in_stack_00000034;
  *(undefined4 *)(param_1 + 0x3c) = in_stack_00000038;
  return;
}



/* FUNCTION 12578 ; VA 0x008235f0 ; FUN_008235f0 */

int * __thiscall FUN_008235f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  uint auStack_7c [22];
  undefined8 uStack_24;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6704;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  iStack_14 = 0;
  uStack_8 = 0xb;
  piStack_1c = param_1;
  do {
    iStack_18 = 4;
    do {
      piVar6 = *(int **)(param_2 + 0x3c);
      dVar10 = (double)((float)*(int *)((int)&DAT_01918480 + iStack_14) * DAT_018f8ff4 *
                       DAT_018f9938);
      uStack_24 = dVar10;
      FUN_01728390();
      fVar12 = (float)dVar10 * DAT_018ce2f4 + DAT_018ce2f4;
      fVar11 = 0.0;
      if (0.0 <= fVar12) {
        fVar11 = fVar12;
      }
      fVar12 = DAT_018ce2f8;
      if (fVar11 <= DAT_018ce2f8) {
        fVar12 = fVar11;
      }
      uVar9 = (uint)(fVar12 * DAT_018f9000 + DAT_018ce2f4);
      dVar10 = uStack_24;
      FUN_017279f0();
      fVar12 = (float)dVar10 * DAT_018ce2f4 + DAT_018ce2f4;
      fVar11 = 0.0;
      if (0.0 <= fVar12) {
        fVar11 = fVar12;
      }
      fVar12 = DAT_018ce2f8;
      if (fVar11 <= DAT_018ce2f8) {
        fVar12 = fVar11;
      }
      uVar8 = (uint)(fVar12 * DAT_018f9000 + DAT_018ce2f4);
      iVar5 = (**(code **)(*piVar6 + 0x40))();
      if (*(char *)(iVar5 + 0x38) == '\0') {
        uVar9 = uVar9 | (uVar8 | 0xffff0000) << 8;
      }
      else {
        uVar9 = ((uVar9 | 0xffffff00) << 8 | uVar8) << 8;
      }
      *(uint *)((int)auStack_7c + iStack_14) = uVar9;
      iStack_14 = iStack_14 + 4;
      iStack_18 = iStack_18 + -1;
    } while (iStack_18 != 0);
  } while (iStack_14 < 0x40);
  piVar6 = (int *)FUN_0147c180(&uStack_24,0,3,4,4,5);
  piVar4 = piStack_1c;
  iVar5 = *piVar6;
  iVar2 = piVar6[1];
  *piVar6 = 0;
  piVar6[1] = 0;
  piStack_1c[3] = iVar5;
  piVar6 = (int *)piStack_1c[4];
  piStack_1c[4] = iVar2;
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar5 = piVar6[2] + -1;
      piVar6[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = uStack_24._4_4_;
  if (uStack_24._4_4_ != (int *)0x0) {
    LOCK();
    iVar5 = uStack_24._4_4_[1] + -1;
    uStack_24._4_4_[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*uStack_24._4_4_)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  pcVar3 = *(code **)(*(int *)piVar4[3] + 0x10);
  uVar7 = FUN_0147ce60(0,0,4,4);
  (*pcVar3)(0,0,uVar7,auStack_7c,0x40);
  (**(code **)(*(int *)piVar4[3] + 0x2c))();
  piVar4[0x1a] = 0;
  piVar4[0x19] = 0;
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 12579 ; VA 0x008238c0 ; FUN_008238c0 */

void __fastcall FUN_008238c0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x60);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x58);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x50);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x48);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x40);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x38);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x28);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x20);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00823a8f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 12580 ; VA 0x00823aa0 ; FUN_00823aa0 */

float10 FUN_00823aa0(uint param_1,uint param_2)

{
  ulonglong uVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  float fStack_8;
  
  fVar4 = 0.0;
  fStack_8 = 0.0;
  if (param_1 != 0) {
    fVar3 = DAT_018ce2f8;
    do {
      uVar1 = (ulonglong)param_1;
      param_1 = param_1 / param_2;
      iVar2 = (int)(uVar1 % (ulonglong)param_2);
      fVar3 = fVar3 / (float)((double)(int)param_2 +
                             (double)(&DAT_018c0d90)[-((int)param_2 >> 0x1f)]);
      fVar4 = fVar4 + (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]) * fVar3;
      fStack_8 = fVar4;
    } while (param_1 != 0);
  }
  return (float10)fStack_8;
}



/* FUNCTION 12581 ; VA 0x00823b20 ; FUN_00823b20 */

void FUN_00823b20(int *param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  undefined8 uVar6;
  undefined auStack_e8 [16];
  float fStack_d8;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined4 uStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  int iStack_48;
  char *pcStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined2 auStack_1c [2];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6724;
  pvStack_10 = ExceptionList;
  iStack_3c = *(int *)(param_4 + 0x30);
  iStack_38 = *(int *)(param_4 + 0x34);
  pcStack_44 = "AoBlurUpsampleCS";
  uStack_40 = 0x10;
  iStack_34 = *(int *)(param_3 + 0x30);
  iStack_48 = *(int *)(param_3 + 0x34);
  ExceptionList = &pvStack_10;
  FUN_00790e00(&uStack_18,&pcStack_44,1);
  fStack_20 = (float)uStack_18;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3ca8) {
    FUN_016f3809(&DAT_01eb3ca8);
    if (DAT_01eb3ca8 == -1) {
      uStack_8 = 0;
      uVar6 = FUN_0152dab0(&DAT_018fb928,"Blur & upsample AO",0xffffffff);
      DAT_01eb3ca4 = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb3ca0 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3ca8);
    }
  }
  uStack_40 = DAT_01eb3ca0;
  uStack_68 = DAT_01eb3ca0;
  uStack_58 = DAT_01eb3ca4;
  uStack_64 = DAT_01eb3ca4;
  uStack_60 = FUN_0152d930(DAT_01eb3ca0,DAT_01eb3ca4);
  uStack_8 = 1;
  (**(code **)(*param_1 + 0x44))();
  (**(code **)(*param_1 + 0x24))(fStack_20);
  fStack_50 = (float)((double)iStack_34 + (double)(&DAT_018c0d90)[-(iStack_34 >> 0x1f)]);
  fStack_4c = (float)((double)iStack_3c + (double)(&DAT_018c0d90)[-(iStack_3c >> 0x1f)]);
  fVar4 = fStack_50 / fStack_4c;
  dVar3 = DAT_018d8a10;
  FUN_01726ab0();
  fVar5 = DAT_018ce2f8 - (float)dVar3 * fVar4;
  piStack_14 = (int *)(fVar5 * fVar5);
  dVar3 = DAT_018d8a10;
  FUN_01726ab0();
  fStack_20 = (float)dVar3;
  dVar3 = DAT_018d8a10;
  FUN_01726ab0();
  iVar2 = iStack_48;
  fStack_54 = DAT_018ce2f8 / ((float)dVar3 + fStack_20);
  FUN_00829a50(iStack_34,iStack_48);
  fStack_d8 = DAT_018ce2f8 / fStack_4c;
  fStack_d4 = DAT_018ce2f8 /
              (float)((double)iStack_38 + (double)(&DAT_018c0d90)[-(iStack_38 >> 0x1f)]);
  fStack_d0 = DAT_018ce2f8 / fStack_50;
  fStack_cc = DAT_018ce2f8 / (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]);
  fStack_30 = fStack_54;
  fStack_28 = (float)piStack_14;
  fStack_24 = fStack_20;
  fStack_c8 = fStack_54;
  fStack_c0 = (float)piStack_14;
  fStack_bc = fStack_20;
  fStack_c4 = fVar4;
  fStack_2c = fVar4;
  (**(code **)(*param_1 + 0x30))(1,auStack_e8,0x80);
  auStack_1c[0] = 0x100;
  uStack_18 = 0;
  piStack_14 = (int *)((uint)piStack_14 & 0xffff0000);
  (**(code **)(*param_1 + 0x34))(0,param_4,auStack_1c);
  auStack_1c[0] = 0x100;
  uStack_18 = 0;
  piStack_14 = (int *)((uint)piStack_14 & 0xffff0000);
  (**(code **)(*param_1 + 0x34))(3,param_3,auStack_1c);
  fStack_2c = (float)CONCAT22(fStack_2c._2_2_,0x100);
  fStack_28 = 0.0;
  fStack_24 = (float)((uint)fStack_24 & 0xffff0000);
  (**(code **)(*param_1 + 0x34))(2,param_5,&fStack_2c);
  (**(code **)(*param_1 + 0x38))(5,param_2);
  (**(code **)(*param_1 + 0x4c))(iStack_3c + 2,iStack_38 + 2,1);
  (**(code **)(*param_1 + 0x48))();
  uStack_8 = 2;
  FUN_0152dda0(uStack_40,uStack_58,uStack_60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12582 ; VA 0x00823ed0 ; FUN_00823ed0 */

void __thiscall
FUN_00823ed0(undefined4 *param_1,int *param_2,int param_3,undefined4 param_4,undefined4 *param_5,
            char param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined2 uStack00000015;
  undefined uStack00000017;
  undefined auStack_d8 [16];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined8 uStack_1c;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6758;
  pvStack_10 = ExceptionList;
  puStack_20 = param_1;
  if ((param_1[0xb] != 0) && (param_1[9] != 0)) {
    uStack_28._0_4_ = 0x10001;
    puVar6 = (undefined8 *)&uStack_2c;
    if (param_6 == '\0') {
      puVar6 = &uStack_1c;
    }
    uStack_2c = 0xf;
    uStack_28._4_4_ = uStack_28._4_4_ & 0xffffff00;
    uStack_1c._4_4_ = 0x10102;
    uStack_1c._0_4_ = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    uStack_58 = *puVar6;
    uStack_50 = *(undefined4 *)(puVar6 + 1);
    ExceptionList = &pvStack_10;
    FUN_00829a50(*(undefined4 *)(param_3 + 0x30),*(undefined4 *)(param_3 + 0x34));
    uStack_c8 = *param_5;
    uStack_c4 = param_5[1];
    uStack_c0 = param_5[2];
    uStack_bc = param_5[3];
    iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3c88) {
      FUN_016f3809(&DAT_01eb3c88);
      if (DAT_01eb3c88 == -1) {
        uStack_8 = 0;
        uVar7 = FUN_0152dab0("Render","SSAOApply",0xffffffff);
        DAT_01eb3c84 = (undefined4)((ulonglong)uVar7 >> 0x20);
        DAT_01eb3c80 = (undefined4)uVar7;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb3c88);
      }
    }
    uStack_3c = DAT_01eb3c80;
    uStack_4c = DAT_01eb3c80;
    uStack_38 = DAT_01eb3c84;
    uStack_48 = DAT_01eb3c84;
    uStack_44 = FUN_0152d930(DAT_01eb3c80,DAT_01eb3c84);
    uStack_8 = 1;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3c98) {
      FUN_016f3809(&DAT_01eb3c98);
      if (DAT_01eb3c98 == -1) {
        uStack_8._0_1_ = 2;
        uVar7 = FUN_0152dab0(&DAT_018fb928,"SSAOApply",0xffffffff);
        DAT_01eb3c94 = (undefined4)((ulonglong)uVar7 >> 0x20);
        DAT_01eb3c90 = (undefined4)uVar7;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb3c98);
      }
    }
    uVar4 = DAT_01eb3c94;
    uStack_34 = DAT_01eb3c90;
    uStack_30 = DAT_01eb3c90;
    uStack_2c = DAT_01eb3c94;
    uStack_28 = FUN_0152d930(DAT_01eb3c90,DAT_01eb3c94);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_1c._0_2_ = 0x101;
    uStack_1c._4_4_ = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,puStack_20[0xb],&uStack_1c);
    puVar5 = puStack_20;
    uStack_1c._0_2_ = 0x101;
    uStack_1c._4_4_ = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(1,*(undefined4 *)puStack_20[9],&uStack_1c);
    uStack_1c._0_4_ = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_1c._4_4_ = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(3,param_3,&uStack_1c);
    uStack00000015 = 0;
    uStack00000017 = 0;
    FUN_0082a430(param_2,*puVar5,"SSAOVS","HbaoCompositFS",auStack_d8,&uStack_58,&stack0x00000015);
    puVar5[9] = 0;
    piVar3 = (int *)puVar5[10];
    puStack_20[10] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = piVar3[1] + -1;
      piVar3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0152dda0(uStack_34,uVar4,uStack_28);
    uStack_8 = 5;
    FUN_0152dda0(uStack_3c,uStack_38,uStack_44);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12583 ; VA 0x008241c0 ; FUN_008241c0 */

void __thiscall
FUN_008241c0(undefined4 *param_1,int *param_2,int *param_3,int *param_4,undefined4 *param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  float fVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  uint3 uVar5;
  ulonglong uVar6;
  undefined uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int iVar10;
  float10 fVar11;
  undefined8 uVar12;
  undefined auStack_224 [128];
  undefined auStack_1a4 [128];
  undefined auStack_124 [8];
  float fStack_11c;
  float fStack_118;
  float fStack_114;
  float fStack_110;
  float fStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  int *piStack_6c;
  undefined4 *puStack_68;
  int *piStack_64;
  undefined4 *puStack_60;
  int *piStack_5c;
  undefined auStack_58 [4];
  undefined4 uStack_54;
  uint uStack_50;
  int *piStack_4c;
  undefined8 uStack_48;
  int *piStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined8 uStack_2c;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6866;
  pvStack_10 = ExceptionList;
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_38 = iVar10;
  puStack_20 = param_1;
  if ((*(int *)(iVar10 + 0x34) < DAT_01eb3cb8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3cb8), DAT_01eb3cb8 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","HbaoRenderCompute",0xffffffff);
    DAT_01eb3cb4 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3cb0 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3cb8);
  }
  uStack_84 = DAT_01eb3cb0;
  uStack_a4 = DAT_01eb3cb0;
  uStack_80 = DAT_01eb3cb4;
  uStack_a0 = DAT_01eb3cb4;
  uStack_9c = FUN_0152d930(DAT_01eb3cb0,DAT_01eb3cb4);
  uStack_8 = 1;
  if (*(int *)(iVar10 + 0x34) < DAT_01eb3cc8) {
    FUN_016f3809(&DAT_01eb3cc8);
    if (DAT_01eb3cc8 == -1) {
      uStack_8._0_1_ = 2;
      uVar12 = FUN_0152dab0(&DAT_018fb928,"HbaoRenderCompute",0xffffffff);
      DAT_01eb3cc4 = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb3cc0 = (undefined4)uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb3cc8);
    }
  }
  uStack_7c = DAT_01eb3cc0;
  uStack_94 = DAT_01eb3cc0;
  uStack_78 = DAT_01eb3cc4;
  uStack_90 = DAT_01eb3cc4;
  uStack_8c = FUN_0152d930(DAT_01eb3cc0,DAT_01eb3cc4);
  piVar4 = param_4;
  uStack_8._0_1_ = 3;
  FUN_00825d10(param_2,param_4[0xc],param_4[0xd]);
  FUN_00829b90(piVar4[0xc],piVar4[0xd],param_7);
  if (param_1[0xb] == 0) goto LAB_00824da5;
  piStack_40 = param_1 + 5;
  FUN_00799920(&puStack_70,*(undefined4 *)(*piStack_40 + 0x30),*(undefined4 *)(*piStack_40 + 0x34),
               0x1b);
  uStack_8._0_1_ = 6;
  FUN_00799920(&puStack_60,*(undefined4 *)(param_1[5] + 0x30),*(undefined4 *)(param_1[5] + 0x34),0);
  uStack_8._0_1_ = 7;
  FUN_00799920(&puStack_68,piVar4[0xc],piVar4[0xd],6);
  uStack_8._0_1_ = 8;
  if (((puStack_70 == (undefined4 *)0x0) || (puStack_60 == (undefined4 *)0x0)) ||
     (puStack_68 == (undefined4 *)0x0)) {
    param_1[0xb] = 0;
    piVar4 = (int *)param_1[0xc];
    param_1[0xc] = 0;
    uStack_48 = CONCAT44(uStack_48._4_4_,(undefined4)uStack_48);
    uStack_2c = CONCAT44(uStack_2c._4_4_,(float)uStack_2c);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar10 = piVar4[1] + -1;
      piVar4[1] = iVar10;
      UNLOCK();
      uStack_48 = CONCAT44(uStack_48._4_4_,(undefined4)uStack_48);
      uStack_2c = CONCAT44(uStack_2c._4_4_,(float)uStack_2c);
      if (iVar10 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar10 = piVar4[2] + -1;
        piVar4[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  else {
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3cd8) {
      FUN_016f3809(&DAT_01eb3cd8);
      if (DAT_01eb3cd8 == -1) {
        uStack_8._0_1_ = 0xb;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Gen Normals",0xffffffff);
        DAT_01eb3cd4 = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3cd0 = (int *)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3cd8);
      }
    }
    piStack_24 = DAT_01eb3cd0;
    piStack_34 = DAT_01eb3cd0;
    piStack_3c = DAT_01eb3cd4;
    piStack_30 = DAT_01eb3cd4;
    uStack_2c = FUN_0152d930(DAT_01eb3cd0,DAT_01eb3cd4);
    uVar6 = (ulonglong)uStack_2c >> 0x20;
    uStack_8._0_1_ = 0xc;
    (**(code **)(*param_2 + 0x14))(puStack_70[2],0,1,0,0);
    piVar4 = param_2;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(3,param_4,&uStack_1c);
    uStack_54 = (uint)(byte)uStack_54;
    uStack_48._0_4_ = 0x1000100;
    piStack_4c = (int *)&DAT_0000000f;
    uStack_48._4_4_ = uStack_48._4_4_ & 0xffffff00;
    FUN_0082a430(piVar4,*puStack_20,"SSAOVS","GenNormalsFS",auStack_1a4,&piStack_4c,
                 (int)&uStack_54 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0xd;
    FUN_0152dda0(piStack_24,piStack_3c,(float)uStack_2c,(int)uVar6);
    uStack_8._0_1_ = 8;
    if (param_5 != (undefined4 *)0x0) {
      puVar8 = (undefined4 *)
               FUN_00799920(&uStack_48,*(undefined4 *)(*piStack_40 + 0x30),
                            *(undefined4 *)(*piStack_40 + 0x34),0x1b);
      puVar9 = puStack_20;
      uVar2 = *puVar8;
      uVar3 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      puStack_20[9] = uVar2;
      param_3 = (int *)puStack_20[10];
      puStack_20[10] = uVar3;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar10 = param_3[1] + -1;
        param_3[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*param_3)();
          LOCK();
          iVar10 = param_3[2] + -1;
          param_3[2] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*param_3 + 4))();
          }
        }
      }
      FUN_00550b30();
      if (puVar9[9] == 0) goto LAB_00824d34;
      if (*(int *)(iStack_38 + 0x34) < DAT_01eb3ce8) {
        FUN_016f3809(&DAT_01eb3ce8);
        if (DAT_01eb3ce8 == -1) {
          uStack_8._0_1_ = 0x10;
          uVar12 = FUN_0152dab0(&DAT_018fb928,"Copy Color",0xffffffff);
          DAT_01eb3ce4 = (int *)((ulonglong)uVar12 >> 0x20);
          DAT_01eb3ce0 = (int *)uVar12;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb3ce8);
        }
      }
      piStack_3c = DAT_01eb3ce0;
      piStack_34 = DAT_01eb3ce0;
      piStack_24 = DAT_01eb3ce4;
      piStack_30 = DAT_01eb3ce4;
      uVar12 = FUN_0152d930(DAT_01eb3ce0,DAT_01eb3ce4);
      uStack_8._0_1_ = 0x11;
      uStack_2c = uVar12;
      (**(code **)(*piVar4 + 0x14))(*(undefined4 *)(puStack_20[9] + 8),0,1,0,0);
      piVar4 = param_2;
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_2 + 0x34))(0,param_5,&uStack_1c);
      param_3._0_3_ = (uint3)param_3 & 0xff;
      param_3 = (int *)(uint)(uint3)param_3;
      uStack_48._0_4_ = 0x1000100;
      piStack_4c = (int *)&DAT_0000000f;
      uStack_48._4_4_ = uStack_48._4_4_ & 0xffffff00;
      FUN_0082a430(piVar4,*puStack_20,"PassThroughVS","PassThroughFS",auStack_1a4,&piStack_4c,
                   (int)&param_3 + 1);
      (**(code **)(*piVar4 + 0x18))();
      uStack_8._0_1_ = 0x12;
      FUN_0152dda0(piStack_3c,piStack_24,(float)uStack_2c,(int)((ulonglong)uVar12 >> 0x20));
    }
    uStack_8._0_1_ = 8;
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3cf8) {
      FUN_016f3809(&DAT_01eb3cf8);
      if (DAT_01eb3cf8 == -1) {
        uStack_8._0_1_ = 0x13;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Depth",0xffffffff);
        DAT_01eb3cf4 = (undefined4)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3cf0 = (undefined4)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3cf8);
      }
    }
    piStack_3c = (int *)DAT_01eb3cf0;
    piStack_34 = (int *)DAT_01eb3cf0;
    piStack_24 = (int *)DAT_01eb3cf4;
    piStack_30 = (int *)DAT_01eb3cf4;
    uVar12 = FUN_0152d930(DAT_01eb3cf0,DAT_01eb3cf4);
    puVar9 = puStack_20;
    puStack_74 = puStack_20 + 0xd;
    uStack_2c = uVar12;
    FUN_00557fc0(puStack_74);
    FUN_0056ecd0(puVar9 + 5);
    FUN_0056ecd0(&uStack_48);
    param_5 = puVar9 + 0xf;
    FUN_00557fc0(param_5);
    uStack_8._0_1_ = 0x16;
    FUN_0056ecd0(puVar9 + 7);
    FUN_0056ecd0(auStack_58);
    piVar4 = param_2;
    (**(code **)(*param_2 + 0x14))(puVar9[7],0,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(3,param_4,&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (int *)(uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar4,*puStack_20,"SSAOVS","HBAODepthDownFS",auStack_1a4,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar4 + 0x18))();
    FUN_00550b30();
    FUN_00550b30();
    uStack_8._0_1_ = 0x17;
    FUN_0152dda0(piStack_3c,piStack_24,(float)uStack_2c,(int)((ulonglong)uVar12 >> 0x20));
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3d08) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb3d08);
      if (DAT_01eb3d08 == -1) {
        uStack_8._0_1_ = 0x18;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Hbao PS",0xffffffff);
        DAT_01eb3d04 = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3d00 = (uint)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3d08);
      }
    }
    uStack_54 = DAT_01eb3d00;
    uStack_50 = DAT_01eb3d00;
    piStack_3c = DAT_01eb3d04;
    piStack_4c = DAT_01eb3d04;
    uStack_48 = FUN_0152d930(DAT_01eb3d00,DAT_01eb3d04);
    uVar6 = (ulonglong)uStack_48 >> 0x20;
    uStack_8._0_1_ = 0x19;
    (**(code **)(*piVar4 + 0x14))(puStack_60[2],0,1,0,0);
    piVar4 = param_2;
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,*puStack_70,&uStack_1c);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(3,*piStack_40,&uStack_1c);
    FUN_00829b90(*(undefined4 *)(*piStack_40 + 0x30),*(undefined4 *)(*piStack_40 + 0x34),param_7);
    iVar10 = (int)((ulonglong)(DAT_01eb3d0c + 1) % 20000000);
    DAT_01eb3d0c = iVar10;
    fVar11 = (float10)FUN_00823aa0(iVar10,3);
    piStack_24 = (int *)(float)fVar11;
    fVar11 = (float10)FUN_00823aa0(iVar10,2);
    piVar4 = param_2;
    fVar1 = (float)fVar11;
    fStack_114 = ((fVar1 + fVar1) - DAT_018ce2f8) * fStack_11c;
    fStack_110 = (((float)piStack_24 + (float)piStack_24) - DAT_018ce2f8) * fStack_118;
    fStack_10c = (float)((double)iVar10 + DAT_018c0d90);
    uStack_2c._4_4_ = 0;
    param_3._0_3_ = SUB43(fVar1,0) & 0xff;
    param_3 = (int *)(uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_108 = 0;
    uStack_14 = uStack_14 & 0xff00;
    piStack_34 = (int *)fStack_114;
    piStack_30 = (int *)fStack_110;
    uStack_2c._0_4_ = fStack_10c;
    FUN_0082a430(param_2,*puStack_20,"PassThroughVS","HbaoFS",auStack_124,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0x1a;
    FUN_0152dda0(uStack_54,piStack_3c,(undefined4)uStack_48,(int)uVar6);
    uStack_8._0_1_ = 8;
    FUN_00829b90(*(undefined4 *)(*piStack_40 + 0x30),*(undefined4 *)(*piStack_40 + 0x34),param_7);
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3d18) {
      FUN_016f3809(&DAT_01eb3d18);
      if (DAT_01eb3d18 == -1) {
        uStack_8._0_1_ = 0x1b;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Reproject & filter",0xffffffff);
        DAT_01eb3d14 = (undefined4)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3d10 = (int *)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3d18);
      }
    }
    piStack_24 = DAT_01eb3d10;
    piStack_34 = DAT_01eb3d10;
    param_7 = DAT_01eb3d14;
    piStack_30 = (int *)DAT_01eb3d14;
    uStack_2c = FUN_0152d930(DAT_01eb3d10,DAT_01eb3d14);
    uVar6 = (ulonglong)uStack_2c >> 0x20;
    uStack_8._0_1_ = 0x1c;
    (**(code **)(*piVar4 + 0x14))(puStack_20[0x17],0,1,0,0);
    piVar4 = param_2;
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,*puStack_60,&uStack_1c);
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(2,puStack_20[0x11],&uStack_1c);
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(3,*piStack_40,&uStack_1c);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(4,*puStack_74,&uStack_1c);
    puVar9 = (undefined4 *)FUN_01165f10(0);
    uStack_e4 = *puVar9;
    uStack_e0 = puVar9[1];
    uStack_dc = puVar9[2];
    uStack_d8 = puVar9[3];
    puVar9 = (undefined4 *)FUN_01165f10(1);
    uStack_d4 = *puVar9;
    uStack_d0 = puVar9[1];
    uStack_cc = puVar9[2];
    uStack_c8 = puVar9[3];
    puVar9 = (undefined4 *)FUN_01165f10(2);
    uStack_c4 = *puVar9;
    uStack_c0 = puVar9[1];
    uStack_bc = puVar9[2];
    uStack_b8 = puVar9[3];
    puVar9 = (undefined4 *)FUN_01165f10(3);
    piVar4 = param_2;
    uStack_b4 = *puVar9;
    uStack_b0 = puVar9[1];
    uStack_ac = puVar9[2];
    uStack_a8 = puVar9[3];
    (**(code **)(*param_2 + 0x30))(2,&uStack_e4,0x40);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (int *)(uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar4,*puStack_20,"PassThroughVS","ReprojectFilterFS",auStack_224,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0x1d;
    FUN_0152dda0(piStack_24,param_7,(float)uStack_2c,(int)uVar6);
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3d28) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb3d28);
      if (DAT_01eb3d28 == -1) {
        uStack_8._0_1_ = 0x1e;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Dilate Temporal",0xffffffff);
        DAT_01eb3d24 = (undefined4)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3d20 = (undefined4)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3d28);
      }
    }
    param_8 = DAT_01eb3d20;
    piStack_34 = (int *)DAT_01eb3d20;
    param_7 = DAT_01eb3d24;
    piStack_30 = (int *)DAT_01eb3d24;
    uVar12 = FUN_0152d930(DAT_01eb3d20,DAT_01eb3d24);
    uStack_8._0_1_ = 0x1f;
    uStack_2c = uVar12;
    (**(code **)(*piVar4 + 0x14))(puStack_20[0x15],0,1,0,0);
    piVar4 = param_2;
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,*puStack_60,&uStack_1c);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar4 + 0x34))(2,puStack_20[0x13],&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (int *)(uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar4,*puStack_20,"PassThroughVS","DilateTemporalFS",auStack_224,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0x20;
    FUN_0152dda0(param_8,param_7,(float)uStack_2c,(int)((ulonglong)uVar12 >> 0x20));
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3d38) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb3d38);
      if (DAT_01eb3d38 == -1) {
        uStack_8._0_1_ = 0x21;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Linearize full resolution depth",0xffffffff);
        DAT_01eb3d34 = (undefined4)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3d30 = (undefined4)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3d38);
      }
    }
    param_8 = DAT_01eb3d30;
    piStack_34 = (int *)DAT_01eb3d30;
    param_7 = DAT_01eb3d34;
    piStack_30 = (int *)DAT_01eb3d34;
    uVar12 = FUN_0152d930(DAT_01eb3d30,DAT_01eb3d34);
    uStack_8._0_1_ = 0x22;
    uStack_2c = uVar12;
    (**(code **)(*piVar4 + 0x14))(puStack_68[2],0,1,0,0);
    piVar4 = param_2;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(3,param_4,&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (int *)(uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar4,*puStack_20,"PassThroughVS","LinearizeDepthBufferFS",auStack_1a4,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0x23;
    FUN_0152dda0(param_8,param_7,(float)uStack_2c,(int)((ulonglong)uVar12 >> 0x20));
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (*(int *)(iStack_38 + 0x34) < DAT_01eb3d48) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb3d48);
      if (DAT_01eb3d48 == -1) {
        uStack_8._0_1_ = 0x24;
        uVar12 = FUN_0152dab0(&DAT_018fb928,"Linearize half resolution depth",0xffffffff);
        DAT_01eb3d44 = (int *)((ulonglong)uVar12 >> 0x20);
        DAT_01eb3d40 = (int *)uVar12;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb3d48);
      }
    }
    param_4 = DAT_01eb3d40;
    piStack_34 = DAT_01eb3d40;
    param_3 = DAT_01eb3d44;
    piStack_30 = DAT_01eb3d44;
    uVar12 = FUN_0152d930(DAT_01eb3d40,DAT_01eb3d44);
    uStack_8._0_1_ = 0x25;
    uStack_2c = uVar12;
    (**(code **)(*piVar4 + 0x14))(*param_5,0,1,0,0);
    piVar4 = param_2;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(3,*piStack_40,&uStack_1c);
    uVar5 = (uint3)param_2;
    param_2 = (int *)(uint)(uVar5 & 0xff);
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar4,*puStack_20,"PassThroughVS","LinearizeDepthBufferFS",auStack_224,&uStack_1c,
                 (int)&param_2 + 1);
    (**(code **)(*piVar4 + 0x18))();
    uStack_8._0_1_ = 0x26;
    FUN_0152dda0(param_4,param_3,(float)uStack_2c,(int)((ulonglong)uVar12 >> 0x20));
    uStack_8._0_1_ = 8;
    FUN_00823b20(piVar4,puStack_20[0xb],*puStack_68,puStack_20[0xd],puStack_20[0x11]);
  }
LAB_00824d34:
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar10 = piStack_64[1] + -1;
    piStack_64[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_64)();
      LOCK();
      iVar10 = piStack_64[2] + -1;
      piStack_64[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piStack_64 + 4))();
      }
    }
  }
  if (piStack_5c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_5c[1] + -1;
    piStack_5c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      iVar10 = piStack_5c[2] + -1;
      piStack_5c[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (piStack_6c != (int *)0x0) {
    LOCK();
    iVar10 = piStack_6c[1] + -1;
    piStack_6c[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*piStack_6c)();
      LOCK();
      piVar4 = piStack_6c + 2;
      iVar10 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        (**(code **)(*piStack_6c + 4))();
      }
    }
  }
LAB_00824da5:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x27);
  FUN_0152dda0(uStack_7c,uStack_78,uStack_8c);
  uStack_8 = 0x28;
  FUN_0152dda0(uStack_84,uStack_80,uStack_9c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12584 ; VA 0x00825160 ; FUN_00825160 */

undefined4 * __thiscall
FUN_00825160(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  ulonglong uVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  undefined4 *puVar7;
  undefined8 uVar8;
  undefined auStack_d8 [128];
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined8 uStack_1c;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6898;
  pvStack_10 = ExceptionList;
  puStack_20 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    uStack_28._0_4_ = 0x10001;
    puVar6 = (undefined8 *)&uStack_2c;
    if ((char)param_5 == '\0') {
      puVar6 = &uStack_1c;
    }
    uStack_2c = 0xf;
    uStack_28._4_4_ = uStack_28._4_4_ & 0xffffff00;
    uStack_1c._4_4_ = 0x10102;
    uStack_1c._0_4_ = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    uStack_58 = *puVar6;
    uStack_50 = *(undefined4 *)(puVar6 + 1);
    ExceptionList = &pvStack_10;
    FUN_00829d10(param_4);
    iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3c68) {
      FUN_016f3809(&DAT_01eb3c68);
      if (DAT_01eb3c68 == -1) {
        uStack_8 = 0;
        uVar8 = FUN_0152dab0("Render","SSAOApply",0xffffffff);
        DAT_01eb3c64 = (undefined4)((ulonglong)uVar8 >> 0x20);
        DAT_01eb3c60 = (undefined4)uVar8;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb3c68);
      }
    }
    uStack_3c = DAT_01eb3c60;
    uStack_30 = DAT_01eb3c60;
    uStack_38 = DAT_01eb3c64;
    uStack_2c = DAT_01eb3c64;
    uStack_28 = FUN_0152d930(DAT_01eb3c60,DAT_01eb3c64);
    uStack_8 = 1;
    if (*(int *)(iVar2 + 0x34) < DAT_01eb3c78) {
      FUN_016f3809(&DAT_01eb3c78);
      if (DAT_01eb3c78 == -1) {
        uStack_8._0_1_ = 2;
        uVar8 = FUN_0152dab0(&DAT_018fb928,"SSAOApply",0xffffffff);
        DAT_01eb3c74 = (undefined4)((ulonglong)uVar8 >> 0x20);
        DAT_01eb3c70 = (undefined4)uVar8;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_016f37bf(&DAT_01eb3c78);
      }
    }
    uVar5 = DAT_01eb3c74;
    uStack_34 = DAT_01eb3c70;
    uStack_4c = DAT_01eb3c70;
    uStack_48 = DAT_01eb3c74;
    uStack_44 = FUN_0152d930(DAT_01eb3c70,DAT_01eb3c74);
    uVar4 = (ulonglong)uStack_44 >> 0x20;
    uStack_1c._0_2_ = 0x100;
    uStack_1c._4_4_ = 0;
    uStack_14 = 0;
    uStack_8._0_1_ = 3;
    (**(code **)(*param_2 + 0x34))(2,*(undefined4 *)puStack_20[1],&uStack_1c);
    uStack_1c._0_4_ = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_1c._4_4_ = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(3,param_3,&uStack_1c);
    param_5._1_2_ = 0;
    param_5._3_1_ = 0;
    FUN_0082a430(param_2,*puStack_20,"SSAOCompositVS","SSAOCompositFS",auStack_d8,&uStack_58,
                 (int)&param_5 + 1);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0152dda0(uStack_34,uVar5,(undefined4)uStack_44,(int)uVar4);
    uStack_8 = 5;
    FUN_0152dda0(uStack_3c,uStack_38,uStack_28);
  }
  puStack_20[1] = 0;
  piVar3 = (int *)puStack_20[2];
  puStack_20[2] = 0;
  puVar7 = puStack_20;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    puVar7 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar7 = (undefined4 *)(**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar7 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar7;
}



/* FUNCTION 12585 ; VA 0x00825410 ; FUN_00825410 */

int FUN_00825410(int *param_1,int param_2,uint param_3)

{
  int iVar1;
  uint3 uVar2;
  ulonglong uVar3;
  undefined uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined auStack_104 [16];
  float fStack_f4;
  float fStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  int *piStack_60;
  float fStack_5c;
  float fStack_58;
  undefined8 uStack_54;
  undefined4 *puStack_4c;
  int *piStack_48;
  undefined4 *puStack_44;
  int *piStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  int *piStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6954;
  pvStack_10 = ExceptionList;
  uVar9 = *(int *)(param_3 + 0x30) + 1U >> 1;
  if (uVar9 == 0) {
    uVar9 = 1;
  }
  uVar7 = *(int *)(param_3 + 0x34) + 1U >> 1;
  if (uVar7 == 0) {
    uVar7 = 1;
  }
  ExceptionList = &pvStack_10;
  uStack_3c = uVar7;
  uStack_20 = uVar9;
  uVar5 = FUN_0147d0e0(uVar9,uVar7,1);
  uStack_28 = DAT_01d62174;
  if (uVar5 < DAT_01d62174) {
    uStack_28 = uVar5;
  }
  FUN_00799920(&puStack_44,uVar9,uVar7,5);
  uStack_8 = 0;
  FUN_00799920(&puStack_64,uVar9,uStack_3c,5);
  uStack_8._0_1_ = 1;
  iVar6 = FUN_007994e0(&puStack_4c,uVar9,uStack_3c,uStack_28,5);
  uStack_8._0_1_ = 2;
  uStack_7c = CONCAT44(uStack_7c._4_4_,(undefined4)uStack_7c);
  uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54);
  uStack_30 = CONCAT44(uStack_30._4_4_,(undefined4)uStack_30);
  if (((puStack_44 != (undefined4 *)0x0) &&
      (uStack_7c = CONCAT44(uStack_7c._4_4_,(undefined4)uStack_7c),
      uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54),
      uStack_30 = CONCAT44(uStack_30._4_4_,(undefined4)uStack_30), puStack_64 != (undefined4 *)0x0))
     && (uStack_7c = CONCAT44(uStack_7c._4_4_,(undefined4)uStack_7c),
        uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54),
        uStack_30 = CONCAT44(uStack_30._4_4_,(undefined4)uStack_30), puStack_4c != (undefined4 *)0x0
        )) {
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    piStack_24[1] = (int)puStack_44;
    piVar8 = (int *)piStack_24[2];
    piStack_24[2] = (int)piStack_40;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar6 = piVar8[1] + -1;
      piVar8[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar6 = piVar8[2] + -1;
        piVar8[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    iVar6 = *piStack_24;
    FUN_00829a50(uStack_20,uStack_3c);
    fStack_f4 = *(float *)(iVar6 + 0x9c) * DAT_018ce2f4;
    fStack_f0 = *(float *)(iVar6 + 0xb0) * DAT_018ce2f4;
    uStack_54._0_4_ = 0;
    iVar6 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    uStack_54._4_4_ = 0;
    uStack_ec = 0;
    uStack_e8 = 0;
    param_2 = iVar6;
    if ((*(int *)(iVar6 + 0x34) < DAT_01eb3bf8) &&
       (fStack_5c = fStack_f4, fStack_58 = fStack_f0, FUN_016f3809(&DAT_01eb3bf8),
       DAT_01eb3bf8 == -1)) {
      uStack_8._0_1_ = 3;
      uVar10 = FUN_0152dab0("Render",&DAT_019184c0,0xffffffff);
      DAT_01eb3bf4 = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb3bf0 = (undefined4)uVar10;
      uStack_8._0_1_ = 2;
      FUN_016f37bf(&DAT_01eb3bf8);
    }
    uStack_74 = DAT_01eb3bf0;
    fStack_5c = (float)DAT_01eb3bf0;
    uStack_70 = DAT_01eb3bf4;
    fStack_58 = (float)DAT_01eb3bf4;
    uStack_54 = FUN_0152d930(DAT_01eb3bf0,DAT_01eb3bf4);
    uStack_8._0_1_ = 4;
    if (*(int *)(iVar6 + 0x34) < DAT_01eb3c08) {
      FUN_016f3809(&DAT_01eb3c08);
      if (DAT_01eb3c08 == -1) {
        uStack_8._0_1_ = 5;
        uVar10 = FUN_0152dab0(&DAT_018fb928,&DAT_019184c0,0xffffffff);
        DAT_01eb3c04 = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3c00 = (undefined4)uVar10;
        uStack_8._0_1_ = 4;
        FUN_016f37bf(&DAT_01eb3c08);
      }
    }
    uStack_6c = DAT_01eb3c00;
    uStack_84 = DAT_01eb3c00;
    uStack_68 = DAT_01eb3c04;
    uStack_80 = DAT_01eb3c04;
    uStack_7c = FUN_0152d930(DAT_01eb3c00,DAT_01eb3c04);
    uStack_8._0_1_ = 6;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (*(int *)(iVar6 + 0x34) < DAT_01eb3c18) {
      uStack_8._0_1_ = uVar4;
      FUN_016f3809(&DAT_01eb3c18);
      if (DAT_01eb3c18 == -1) {
        uStack_8._0_1_ = 7;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"Depth",0xffffffff);
        DAT_01eb3c14 = (uint)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3c10 = (uint)uVar10;
        uStack_8._0_1_ = 6;
        FUN_016f37bf(&DAT_01eb3c18);
      }
    }
    uStack_3c = DAT_01eb3c10;
    uStack_38 = DAT_01eb3c10;
    uStack_20 = DAT_01eb3c14;
    uStack_34 = DAT_01eb3c14;
    uStack_30 = FUN_0152d930(DAT_01eb3c10,DAT_01eb3c14);
    uVar3 = (ulonglong)uStack_30 >> 0x20;
    uStack_8._0_1_ = 8;
    (**(code **)(*param_1 + 0x14))(puStack_4c[2],0,1,0,0);
    piVar8 = param_1;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_1 + 0x34))(3,param_3,&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar8,*piStack_24,"SSAOVS","SSAODepthDownFS",auStack_104,&uStack_1c,
                 (int)&param_3 + 1);
    (**(code **)(*piVar8 + 0x18))();
    uStack_8._0_1_ = 9;
    FUN_0152dda0(uStack_3c,uStack_20,(undefined4)uStack_30,(int)uVar3);
    uStack_8._0_1_ = 6;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (1 < uStack_28) {
      if (*(int *)(param_2 + 0x34) < DAT_01eb3c28) {
        uStack_8._0_1_ = uVar4;
        FUN_016f3809(&DAT_01eb3c28);
        if (DAT_01eb3c28 == -1) {
          uStack_8._0_1_ = 10;
          uVar10 = FUN_0152dab0(&DAT_018fb928,"DepthMip",0xffffffff);
          DAT_01eb3c24 = (uint)((ulonglong)uVar10 >> 0x20);
          DAT_01eb3c20 = (uint)uVar10;
          uStack_8._0_1_ = 6;
          FUN_016f37bf(&DAT_01eb3c28);
        }
      }
      uStack_20 = DAT_01eb3c20;
      uStack_38 = DAT_01eb3c20;
      param_3 = DAT_01eb3c24;
      uStack_34 = DAT_01eb3c24;
      uVar10 = FUN_0152d930(DAT_01eb3c20,DAT_01eb3c24);
      uStack_8._0_1_ = 0xb;
      uStack_30 = uVar10;
      (**(code **)(*piVar8 + 0x10))(*puStack_4c);
      uStack_8._0_1_ = 0xc;
      FUN_0152dda0(uStack_20,param_3,(undefined4)uStack_30,(int)((ulonglong)uVar10 >> 0x20));
      piVar8 = param_1;
    }
    uStack_8._0_1_ = 6;
    if (*(int *)(param_2 + 0x34) < DAT_01eb3c38) {
      FUN_016f3809(&DAT_01eb3c38);
      if (DAT_01eb3c38 == -1) {
        uStack_8._0_1_ = 0xd;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"Compute",0xffffffff);
        DAT_01eb3c34 = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3c30 = (undefined4)uVar10;
        uStack_8._0_1_ = 6;
        FUN_016f37bf(&DAT_01eb3c38);
      }
    }
    uStack_28 = DAT_01eb3c30;
    uStack_38 = DAT_01eb3c30;
    uStack_20 = DAT_01eb3c34;
    uStack_34 = DAT_01eb3c34;
    uVar10 = FUN_0152d930(DAT_01eb3c30,DAT_01eb3c34);
    uStack_8._0_1_ = 0xe;
    uStack_30 = uVar10;
    (**(code **)(*piVar8 + 0x14))(puStack_44[2],0,1,0,0);
    piVar8 = param_1;
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_1 + 0x34))(0,*puStack_4c,&uStack_1c);
    uStack_1c = (uint)uStack_1c._2_2_ << 0x10;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*piVar8 + 0x34))(1,piStack_24[3],&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar8,*piStack_24,"SSAOVS","SSAOFS",auStack_104,&uStack_1c,(int)&param_3 + 1);
    (**(code **)(*piVar8 + 0x18))();
    uStack_8._0_1_ = 0xf;
    FUN_0152dda0(uStack_28,uStack_20,(undefined4)uStack_30,(int)((ulonglong)uVar10 >> 0x20));
    uStack_8._0_1_ = 6;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (*(int *)(param_2 + 0x34) < DAT_01eb3c48) {
      uStack_8._0_1_ = uVar4;
      FUN_016f3809(&DAT_01eb3c48);
      if (DAT_01eb3c48 == -1) {
        uStack_8._0_1_ = 0x10;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"BlurX",0xffffffff);
        DAT_01eb3c44 = (uint)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3c40 = (uint)uVar10;
        uStack_8._0_1_ = 6;
        FUN_016f37bf(&DAT_01eb3c48);
      }
    }
    uStack_28 = DAT_01eb3c40;
    uStack_38 = DAT_01eb3c40;
    uStack_20 = DAT_01eb3c44;
    uStack_34 = DAT_01eb3c44;
    uVar10 = FUN_0152d930(DAT_01eb3c40,DAT_01eb3c44);
    uStack_8._0_1_ = 0x11;
    uStack_30 = uVar10;
    (**(code **)(*piVar8 + 0x14))(puStack_64[2],0,1,0,0);
    piVar8 = param_1;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_1 + 0x34))(2,*puStack_44,&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar8,*piStack_24,"SSAOVS","SSAOBlurXFS",auStack_104,&uStack_1c,(int)&param_3 + 1)
    ;
    (**(code **)(*piVar8 + 0x18))();
    uStack_8._0_1_ = 0x12;
    FUN_0152dda0(uStack_28,uStack_20,(undefined4)uStack_30,(int)((ulonglong)uVar10 >> 0x20));
    uStack_8._0_1_ = 6;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (*(int *)(param_2 + 0x34) < DAT_01eb3c58) {
      uStack_8._0_1_ = uVar4;
      FUN_016f3809(&DAT_01eb3c58);
      if (DAT_01eb3c58 == -1) {
        uStack_8._0_1_ = 0x13;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"BlurY",0xffffffff);
        DAT_01eb3c54 = (int)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3c50 = (undefined4)uVar10;
        uStack_8._0_1_ = 6;
        FUN_016f37bf(&DAT_01eb3c58);
      }
    }
    param_2 = DAT_01eb3c50;
    uStack_38 = DAT_01eb3c50;
    param_3 = DAT_01eb3c54;
    uStack_34 = DAT_01eb3c54;
    uVar10 = FUN_0152d930(DAT_01eb3c50,DAT_01eb3c54);
    uStack_8._0_1_ = 0x14;
    uStack_30 = uVar10;
    (**(code **)(*piVar8 + 0x14))(puStack_44[2],0,1,0,0);
    piVar8 = param_1;
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_1 + 0x34))(2,*puStack_64,&uStack_1c);
    uVar2 = (uint3)param_1;
    param_1 = (int *)(uint)(uVar2 & 0xff);
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(piVar8,*piStack_24,"SSAOVS","SSAOBlurYFS",auStack_104,&uStack_1c,(int)&param_1 + 1)
    ;
    (**(code **)(*piVar8 + 0x18))();
    uStack_8._0_1_ = 0x15;
    FUN_0152dda0(param_2,param_3,(undefined4)uStack_30,(int)((ulonglong)uVar10 >> 0x20));
    uStack_8._0_1_ = 0x16;
    FUN_0152dda0(uStack_6c,uStack_68,uStack_7c);
    uStack_8._0_1_ = 0x17;
    iVar6 = FUN_0152dda0(uStack_74,uStack_70,uStack_54);
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_48 + 1;
    iVar1 = *piVar8;
    iVar6 = *piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar8 = piStack_48 + 2;
      iVar1 = *piVar8;
      iVar6 = *piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_60 + 1;
    iVar1 = *piVar8;
    iVar6 = *piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_60)();
      LOCK();
      piVar8 = piStack_60 + 2;
      iVar1 = *piVar8;
      iVar6 = *piVar8;
      *piVar8 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_60 + 4))();
      }
    }
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_40 + 1;
    iVar1 = *piVar8;
    iVar6 = *piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar6 = (**(code **)*piStack_40)();
      LOCK();
      piVar8 = piStack_40 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar6 = (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 12586 ; VA 0x00825d10 ; FUN_00825d10 */

undefined4 * __thiscall FUN_00825d10(int param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 auStack_88 [20];
  int *piStack_38;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined auStack_1c [4];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b69a0;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 100) != param_3) ||
     (puVar6 = (undefined4 *)ExceptionList, *(int *)(param_1 + 0x68) != param_4)) {
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x68) = param_4;
    uStack_14 = param_3 + 1U >> 1;
    uVar5 = param_4 + 1U >> 1;
    *(int *)(param_1 + 100) = param_3;
    puVar6 = (undefined4 *)FUN_0147c150(auStack_1c,0,0,param_3,param_4,1,1,1,0x21);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x2c) = uVar7;
    piVar3 = *(int **)(param_1 + 0x30);
    *(undefined4 *)(param_1 + 0x30) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_0147c150(auStack_1c,0,6,uStack_14,uVar5,1,1,1,3);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x14) = uVar7;
    piVar3 = *(int **)(param_1 + 0x18);
    *(undefined4 *)(param_1 + 0x18) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uVar7 = FUN_0147d4b0();
    uStack_8 = 0;
    FUN_0147d420(param_1 + 0x14);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar6 = (undefined4 *)FUN_0147bf30(auStack_1c,auStack_2c,uVar7);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x1c) = uVar7;
    piVar3 = *(int **)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x20) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_28[1] + -1;
      piStack_28[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_38;
    uStack_8 = 0xffffffff;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_38[1] + -1;
      piStack_38[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_0147c150(auStack_1c,0,7,uStack_14,uVar5,1,1,1,3);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x4c) = uVar7;
    piVar3 = *(int **)(param_1 + 0x50);
    *(undefined4 *)(param_1 + 0x50) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uVar7 = FUN_0147d4b0();
    uStack_8 = 2;
    FUN_0147d420(param_1 + 0x4c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar6 = (undefined4 *)FUN_0147bf30(auStack_1c,auStack_2c,uVar7);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x5c) = uVar7;
    piVar3 = *(int **)(param_1 + 0x60);
    *(undefined4 *)(param_1 + 0x60) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_28[1] + -1;
      piStack_28[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_38;
    uStack_8 = 0xffffffff;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_38[1] + -1;
      piStack_38[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_0147c150(auStack_1c,0,7,uStack_14,uVar5,1,1,1,3);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x44) = uVar7;
    piVar3 = *(int **)(param_1 + 0x48);
    *(undefined4 *)(param_1 + 0x48) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uVar7 = FUN_0147d4b0();
    uStack_8 = 4;
    FUN_0147d420(param_1 + 0x44);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    puVar6 = (undefined4 *)FUN_0147bf30(auStack_1c,auStack_2c,uVar7);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x54) = uVar7;
    piVar3 = *(int **)(param_1 + 0x58);
    *(undefined4 *)(param_1 + 0x58) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_28[1] + -1;
      piStack_28[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_38;
    uStack_8 = 0xffffffff;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_38[1] + -1;
      piStack_38[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_0147c150(auStack_1c,0,6,uStack_14,uVar5,1,1,1,3);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x34) = uVar7;
    piVar3 = *(int **)(param_1 + 0x38);
    *(undefined4 *)(param_1 + 0x38) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uVar7 = FUN_0147d4b0();
    uStack_8 = 6;
    FUN_0147d420(param_1 + 0x34);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    puVar6 = (undefined4 *)FUN_0147bf30(auStack_1c,auStack_2c,uVar7);
    uVar7 = *puVar6;
    uVar2 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x3c) = uVar7;
    piVar3 = *(int **)(param_1 + 0x40);
    *(undefined4 *)(param_1 + 0x40) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar4 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_18 + 1;
      iVar4 = *piVar3;
      puVar6 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar3 = piStack_18 + 2;
        iVar4 = *piVar3;
        puVar6 = (undefined4 *)*piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (piStack_28 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_28 + 1;
      iVar4 = *piVar3;
      puVar6 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar3 = piStack_28 + 2;
        iVar4 = *piVar3;
        puVar6 = (undefined4 *)*piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_38 + 1;
      iVar4 = *piVar3;
      puVar6 = (undefined4 *)*piVar3;
      *piVar3 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar3 = piStack_38 + 2;
        iVar4 = *piVar3;
        puVar6 = (undefined4 *)*piVar3;
        *piVar3 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_38 + 4))();
        }
      }
    }
    if ((((((*(int *)(param_1 + 0x2c) != 0) && (*(int *)(param_1 + 0x14) != 0)) &&
          (*(int *)(param_1 + 0x1c) != 0)) &&
         ((*(int *)(param_1 + 0x4c) != 0 && (*(int *)(param_1 + 0x5c) != 0)))) &&
        ((*(int *)(param_1 + 0x44) != 0 &&
         ((*(int *)(param_1 + 0x54) != 0 && (*(int *)(param_1 + 0x34) != 0)))))) &&
       (*(int *)(param_1 + 0x3c) != 0)) {
      FUN_0147bca0();
      auStack_88[0] = 1;
      (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_1 + 0x1c),0,1,auStack_88,0);
      (**(code **)(*param_2 + 0x18))();
      (**(code **)(*param_2 + 0x14))(*(undefined4 *)(param_1 + 0x54),0,1,auStack_88,0);
      puVar6 = (undefined4 *)(**(code **)(*param_2 + 0x18))();
      ExceptionList = pvStack_10;
      return puVar6;
    }
    *(undefined4 *)(param_1 + 0x2c) = 0;
    piVar3 = *(int **)(param_1 + 0x30);
    *(undefined4 *)(param_1 + 0x30) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar4 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puVar6 = (undefined4 *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 12587 ; VA 0x00826490 ; FUN_00826490 */

void __thiscall FUN_00826490(int *param_1,uint param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uStack_8;
  
  uVar1 = param_2;
  puVar4 = (undefined4 *)param_1[1];
  iVar3 = *param_1;
  uVar5 = (int)puVar4 - iVar3 >> 3;
  uStack_8 = param_1[2] - iVar3 >> 3;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar5) {
      if (param_2 != uVar5) {
        param_1[1] = iVar3 + param_2 * 8;
      }
      return;
    }
    for (iVar3 = param_2 - uVar5; iVar3 != 0; iVar3 = iVar3 + -1) {
      *puVar4 = *param_4;
      puVar4[1] = param_4[1];
      puVar4 = puVar4 + 2;
    }
    param_1[1] = (int)puVar4;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x1fffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar2 = FUN_00578020(uStack_8);
  iVar3 = uVar1 - uVar5;
  puVar4 = (undefined4 *)(iVar2 + uVar5 * 8);
  for (; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = *param_4;
    puVar4[1] = param_4[1];
    puVar4 = puVar4 + 2;
    uVar1 = param_2;
  }
  iVar3 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar2,iVar3,param_1[1] - iVar3);
  FUN_00654980(iVar2,uVar1,uStack_8);
  return;
}



/* FUNCTION 12588 ; VA 0x008265a0 ; FUN_008265a0 */

undefined4 * __thiscall FUN_008265a0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  bool bVar4;
  bool bVar5;
  char cVar6;
  undefined uVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 uVar10;
  uint uVar11;
  int *piVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint auStack_94 [3];
  int *piStack_88;
  undefined4 uStack_84;
  uint uStack_80;
  uint auStack_7c [3];
  int *piStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined auStack_64 [4];
  int *piStack_60;
  int aiStack_5c [2];
  undefined auStack_54 [4];
  int *piStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6b33;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff60;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  FUN_0147cac0(*(undefined4 *)(param_2 + 0x3c));
  *param_1 = RBX::Graphics::EnvMapPBR::vftable;
  param_1[10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  param_1[0xc] = 6;
  FUN_016f4053(param_1 + 0xd,8,9,FUN_005502b0,FUN_00550b30);
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  uStack_8._0_1_ = 7;
  iVar14 = 6;
  do {
    FUN_0060f2c0();
    iVar14 = iVar14 + -1;
  } while (iVar14 != 0);
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0x3f800000;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  uStack_8._0_1_ = 0xb;
  FUN_016f4053(param_1 + 0x4c,8,6,FUN_005502b0,FUN_00550b30);
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  uStack_8._0_1_ = 0xf;
  uStack_30 = FUN_01675290(DAT_01eb3d50);
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  *(undefined *)(param_1 + 0x6d) = 0;
  param_1[0x6c] = 1;
  param_1[0x69] = 0;
  param_1[0x68] = 0;
  param_1[0x67] = 0;
  param_1[0xb] = param_2;
  piVar2 = *(int **)(param_2 + 0x3c);
  uStack_8._0_1_ = 0x10;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0x40800000;
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  piStack_1c = piVar2;
  FUN_005542c0("Global envmap",0xd);
  uStack_8._0_1_ = 0x11;
  FUN_0147cd70(auStack_94);
  uStack_8._0_1_ = 0x10;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x10;
  if (0xf < uStack_80) {
    uVar11 = uStack_80 + 1;
    uVar15 = auStack_94[0];
    if (0xfff < uVar11) {
      uVar15 = *(uint *)(auStack_94[0] - 4);
      uVar11 = uStack_80 + 0x24;
      if (0x1f < (auStack_94[0] - uVar15) - 4) {
        uStack_8._0_1_ = uVar7;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar15,uVar11);
  }
  piStack_28 = (int *)0x100;
  iVar14 = FUN_01674e20(0x68);
  uStack_8._0_1_ = 0x12;
  if (iVar14 == 0) {
    uVar8 = 0;
  }
  else {
    uVar8 = FUN_008272d0(param_1[0xb]);
  }
  iVar14 = param_1[0x27];
  param_1[0x27] = uVar8;
  if (iVar14 != 0) {
    uStack_8._0_1_ = 0x13;
    FUN_016f32d1(iVar14 + 0x34,8,6,FUN_00550b30);
    FUN_016f32d1(iVar14 + 4,8,6,FUN_00550b30);
    FUN_01674ea0(iVar14,0x68);
  }
  FUN_0170d1f0(param_1 + 0x28,0,0x60);
  iVar14 = *(int *)(param_1[0xb] + 0x4ec);
  if (*(int *)(iVar14 + 0x58) != 0) {
    LOCK();
    piVar12 = (int *)(*(int *)(iVar14 + 0x58) + 4);
    *piVar12 = *piVar12 + 1;
    UNLOCK();
  }
  uStack_44 = *(undefined4 *)(iVar14 + 0x54);
  piStack_40 = *(int **)(iVar14 + 0x58);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  puVar9 = (undefined4 *)FUN_00773a00(auStack_4c,&uStack_44);
  uVar8 = *puVar9;
  uVar10 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  param_1[0x21] = uVar8;
  piVar12 = (int *)param_1[0x22];
  param_1[0x22] = uVar10;
  if (piVar12 != (int *)0x0) {
    LOCK();
    iVar14 = piVar12[1] + -1;
    piVar12[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piVar12)();
      LOCK();
      iVar14 = piVar12[2] + -1;
      piVar12[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  piVar12 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_48[1] + -1;
    piStack_48[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar14 = *piVar1 + -1;
      *piVar1 = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  puVar9 = (undefined4 *)FUN_00773a00(auStack_4c,&uStack_44);
  uVar8 = *puVar9;
  uVar10 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  param_1[0x25] = uVar8;
  piVar12 = (int *)param_1[0x26];
  param_1[0x26] = uVar10;
  if (piVar12 != (int *)0x0) {
    LOCK();
    iVar14 = piVar12[1] + -1;
    piVar12[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piVar12)();
      LOCK();
      iVar14 = piVar12[2] + -1;
      piVar12[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  piVar12 = piStack_48;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_48[1] + -1;
    piStack_48[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar14 = *piVar1 + -1;
      *piVar1 = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar12 + 4))();
      }
    }
  }
  uStack_24 = FUN_0147d0e0(0x100,0x100,1);
  uVar8 = (**(code **)(*piVar2 + 0x30))(aiStack_5c);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  bVar5 = false;
  bVar4 = false;
  uStack_18 = 1;
  cVar6 = FUN_00558b60(uVar8,&DAT_019183f4);
  if (cVar6 == '\0') {
    uVar8 = (**(code **)(*piVar2 + 0x30))(auStack_7c);
    uStack_8 = 0x16;
    bVar5 = false;
    bVar4 = true;
    uStack_18 = 3;
    cVar6 = FUN_00558b60(uVar8,"glsles");
    if (cVar6 != '\0') goto LAB_00826a59;
    uVar8 = (**(code **)(*piVar2 + 0x30))(auStack_94);
    bVar5 = true;
    bVar4 = true;
    cVar6 = FUN_00558b60(uVar8,&DAT_019183fc);
    if (cVar6 != '\0') goto LAB_00826a59;
    uVar7 = 1;
  }
  else {
LAB_00826a59:
    uVar7 = 0;
  }
  *(undefined *)(param_1 + 0x5d) = uVar7;
  if (bVar5) {
    if (0xf < uStack_80) {
      uVar11 = uStack_80 + 1;
      uVar15 = auStack_94[0];
      if (0xfff < uVar11) {
        uVar15 = *(uint *)(auStack_94[0] - 4);
        uVar11 = uStack_80 + 0x24;
        if (0x1f < (auStack_94[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar11);
    }
    uStack_84 = 0;
    uStack_80 = 0xf;
    auStack_94[0] = auStack_94[0] & 0xffffff00;
  }
  uStack_8 = 0x15;
  if (bVar4) {
    if (0xf < uStack_68) {
      uVar11 = uStack_68 + 1;
      uVar15 = auStack_7c[0];
      if (0xfff < uVar11) {
        uVar15 = *(uint *)(auStack_7c[0] - 4);
        uVar11 = uStack_68 + 0x24;
        if (0x1f < (auStack_7c[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar11);
    }
    uStack_6c = 0;
    uStack_68 = 0xf;
    auStack_7c[0] = auStack_7c[0] & 0xffffff00;
  }
  uStack_8 = 0x14;
  if (&DAT_0000000f < piStack_48) {
    piVar12 = (int *)((int)piStack_48 + 1);
    iVar14 = aiStack_5c[0];
    if ((int *)0xfff < piVar12) {
      iVar14 = *(int *)(aiStack_5c[0] + -4);
      piVar12 = piStack_48 + 9;
      if (0x1f < (aiStack_5c[0] - iVar14) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar14,piVar12);
  }
  iVar14 = (**(code **)(*piVar2 + 0x40))();
  if (*(char *)(iVar14 + 0x1d) == '\0') {
    piStack_28 = (int *)&DAT_00000020;
    uStack_24 = 1;
    *(undefined *)(param_1 + 0x5d) = 0;
  }
  else if (*(char *)(param_1 + 0x5d) != '\0') {
    iVar14 = *(int *)(param_1[0xb] + 0x4ec);
    iVar13 = *(int *)(iVar14 + 0x58);
    if (iVar13 != 0) {
      LOCK();
      *(int *)(iVar13 + 4) = *(int *)(iVar13 + 4) + 1;
      UNLOCK();
      iVar13 = *(int *)(iVar14 + 0x58);
    }
    param_1[0x44] = *(undefined4 *)(iVar14 + 0x54);
    piVar2 = (int *)param_1[0x45];
    param_1[0x45] = iVar13;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar14 = piVar2[1] + -1;
      piVar2[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar14 = piVar2[2] + -1;
        piVar2[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    iVar14 = (**(code **)(*(int *)param_1[1] + 0x40))();
    uVar8 = 3;
    if (*(char *)(iVar14 + 0x13) != '\0') {
      uVar8 = 0x1b;
    }
    uStack_24 = FUN_0147d0e0(0x100,0x100,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
    puVar9 = (undefined4 *)FUN_0147c150(auStack_4c,2,uVar8,0x100,0x100,1,uStack_24,1,3);
    uVar10 = *puVar9;
    uVar3 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    param_1[0x1f] = uVar10;
    piStack_28 = (int *)param_1[0x20];
    param_1[0x20] = uVar3;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_28[1] + -1;
      piStack_28[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar14 = piStack_28[2] + -1;
        piStack_28[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    piStack_28 = piStack_48;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_48[1] + -1;
      piStack_48[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        iVar14 = piStack_28[2] + -1;
        piStack_28[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    puVar9 = (undefined4 *)FUN_0147c150(auStack_4c,2,uVar8,0x100,0x100,1,uStack_24,1,3);
    uVar10 = *puVar9;
    uVar3 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    param_1[0x23] = uVar10;
    piVar2 = (int *)param_1[0x24];
    param_1[0x24] = uVar3;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar14 = piVar2[1] + -1;
      piVar2[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar14 = piVar2[2] + -1;
        piVar2[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_48;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_48[1] + -1;
      piStack_48[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_48)();
        LOCK();
        piVar12 = piVar2 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar15 = 0;
    while (uStack_18 = uVar15, uVar15 < uStack_24) {
      uVar10 = FUN_0147d110(0x100,uVar15);
      FUN_0147c180(auStack_4c,0,uVar8,uVar10,uVar10,3);
      uStack_8._0_1_ = 0x18;
      piStack_28 = (int *)FUN_0147d4b0();
      uStack_8._0_1_ = 0x19;
      uVar10 = FUN_0147d470(auStack_4c,0,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      puVar9 = (undefined4 *)FUN_0147bf30(auStack_64,uVar10,piStack_28);
      uVar10 = *puVar9;
      uVar3 = puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      param_1[uVar15 * 2 + 0xd] = uVar10;
      piVar2 = (int *)param_1[uVar15 * 2 + 0xe];
      param_1[uStack_18 * 2 + 0xe] = uVar3;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar14 = piVar2[1] + -1;
        piVar2[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar14 = piVar2[2] + -1;
          piVar2[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_60;
      if (piStack_60 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_60[1] + -1;
        piStack_60[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_60)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_70;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_70[1] + -1;
        piStack_70[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_88;
      if (piStack_88 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_88[1] + -1;
        piStack_88[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_88)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_48;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_48[1] + -1;
        piStack_48[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_48)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      uVar15 = uStack_18 + 1;
    }
    goto code_r0x00827023;
  }
  iVar14 = (**(code **)(*piVar2 + 0x40))();
  if (*(char *)(iVar14 + 0x1e) == '\0') {
    uVar8 = FUN_0147c150(auStack_64,2,3,0x20,0x20,1,1,1,5);
    FUN_005587e0(uVar8);
    piVar2 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_60[1] + -1;
      piStack_60[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        piVar12 = piVar2 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar8 = FUN_0147c180(auStack_64,0,3,0x20,0x20,3);
    FUN_005587e0(uVar8);
    piVar2 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_60[1] + -1;
      piStack_60[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        piVar12 = piVar2 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x1c;
    uVar8 = FUN_0147d4b0();
    uStack_8._0_1_ = 0x1d;
    FUN_0147d420(param_1 + 0x48);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    uVar8 = FUN_0147bf30(auStack_64,auStack_54,uVar8);
    FUN_005587e0(uVar8);
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_60[1] + -1;
      piStack_60[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        iVar14 = piStack_60[2] + -1;
        piStack_60[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_60 + 4))();
        }
      }
    }
    if (piStack_50 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_50[1] + -1;
      piStack_50[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_50)();
        LOCK();
        iVar14 = piStack_50[2] + -1;
        piStack_50[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_50 + 4))();
        }
      }
    }
    if (piStack_88 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_88[1] + -1;
      piStack_88[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_88)();
        LOCK();
        iVar14 = piStack_88[2] + -1;
        piStack_88[2] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piStack_88 + 4))();
          puVar9 = (undefined4 *)FUN_00827023();
          return puVar9;
        }
      }
    }
  }
  else {
    uVar8 = FUN_0147c150(auStack_64,2,3,piStack_28,piStack_28,1,uStack_24,1,3);
    FUN_005587e0(uVar8);
    piVar2 = piStack_60;
    if (piStack_60 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_60[1] + -1;
      piStack_60[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_60)();
        LOCK();
        piVar12 = piVar2 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 0x20;
    for (uVar15 = 0; uVar15 < 6; uVar15 = uVar15 + 1) {
      FUN_0147d470(param_1 + 0x44,uVar15,0);
      uStack_8._0_1_ = 0x21;
      uVar8 = FUN_0147d4b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x22);
      puVar9 = (undefined4 *)FUN_0147bf30(auStack_64,auStack_54,uVar8);
      uVar8 = *puVar9;
      uVar10 = puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      param_1[uVar15 * 2 + 0x4c] = uVar8;
      piVar2 = (int *)param_1[uVar15 * 2 + 0x4d];
      param_1[uVar15 * 2 + 0x4d] = uVar10;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar14 = piVar2[1] + -1;
        piVar2[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          iVar14 = piVar2[2] + -1;
          piVar2[2] = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_60;
      if (piStack_60 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_60[1] + -1;
        piStack_60[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_60)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_88;
      if (piStack_88 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_88[1] + -1;
        piStack_88[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_88)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      piVar2 = piStack_50;
      uStack_8._0_1_ = 0x20;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar14 = piStack_50[1] + -1;
        piStack_50[1] = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)*piStack_50)();
          LOCK();
          piVar12 = piVar2 + 2;
          iVar14 = *piVar12 + -1;
          *piVar12 = iVar14;
          UNLOCK();
          if (iVar14 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
  }
code_r0x00827023:
  uStack_8 = 0x14;
  FUN_007735a0(param_1 + 0x44,3);
  piVar12 = piStack_28;
  param_1[0x46] = uStack_2c;
  piVar2 = (int *)param_1[0x47];
  uStack_2c = 0;
  piStack_28 = (int *)0x0;
  param_1[0x47] = piVar12;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar14 = piVar2[1] + -1;
    piVar2[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar14 = piVar2[2] + -1;
      piVar2[2] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    piVar2 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar14 = piStack_28[1] + -1;
      piStack_28[1] = iVar14;
      UNLOCK();
      if (iVar14 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        piVar12 = piVar2 + 2;
        iVar14 = *piVar12 + -1;
        *piVar12 = iVar14;
        UNLOCK();
        if (iVar14 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  FUN_00827a70();
  piVar2 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar14 = piStack_40[1] + -1;
    piStack_40[1] = iVar14;
    UNLOCK();
    if (iVar14 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar12 = piVar2 + 2;
      iVar14 = *piVar12;
      *piVar12 = *piVar12 + -1;
      UNLOCK();
      if (iVar14 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
  FUN_01675290(uStack_30);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12589 ; VA 0x00826ff0 ; Catch@00826ff0 */

undefined * Catch_00826ff0(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x30) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating env conv map: %s",uVar1);
  }
  return &DAT_0082701d;
}



/* FUNCTION 12590 ; VA 0x00827023 ; FUN_00827023 */

void FUN_00827023(void)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int unaff_EBP;
  int unaff_ESI;
  int unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 0x14;
  FUN_007735a0(unaff_EDI + 0x110,3);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x24);
  *(undefined4 *)(unaff_EDI + 0x118) = *(undefined4 *)(unaff_EBP + -0x28);
  piVar3 = *(int **)(unaff_EDI + 0x11c);
  *(undefined4 *)(unaff_EBP + -0x28) = 0;
  *(undefined4 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EDI + 0x11c) = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + unaff_ESI;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + unaff_ESI;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = *(int **)(unaff_EBP + -0x24);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + unaff_ESI;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + unaff_ESI;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  FUN_00827a70();
  piVar3 = *(int **)(unaff_EBP + -0x3c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + unaff_ESI;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + unaff_ESI;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 0x24;
  FUN_01675290(*(undefined4 *)(unaff_EBP + -0x2c));
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 12591 ; VA 0x008270fa ; Catch@008270fa */

undefined * Catch_008270fa(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x34) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating env map framebuffer: %s",uVar1);
  }
  return &DAT_0082701d;
}



/* FUNCTION 12592 ; VA 0x0082728b ; Catch@0082728b */

undefined * Catch_0082728b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x38) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating env map framebuffer: %s",uVar1);
  }
  return &DAT_0082701d;
}



/* FUNCTION 12593 ; VA 0x008272d0 ; FUN_008272d0 */

undefined4 * __thiscall FUN_008272d0(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int aiStack_a4 [5];
  uint uStack_90;
  undefined4 *puStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6ba8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  puStack_8c = param_1;
  FUN_016f4053(param_1 + 1,8,6,FUN_0075dc70,FUN_00550b30);
  uStack_8 = 0;
  FUN_016f4053(param_1 + 0xd,8,6,FUN_0075dc70,FUN_00550b30);
  uStack_8._0_1_ = 1;
  *(undefined *)(param_1 + 0x19) = 0;
  FUN_009cc450(aiStack_a4,"textures/sky/indoor512_up.tex");
  uStack_8._0_1_ = 2;
  FUN_009cc450(auStack_88,"textures/sky/indoor512_lf.tex");
  uStack_8._0_1_ = 3;
  FUN_009cc450(auStack_70,"textures/sky/indoor512_rt.tex");
  uStack_8._0_1_ = 4;
  FUN_009cc450(auStack_58,"textures/sky/indoor512_bk.tex");
  uStack_8._0_1_ = 5;
  FUN_009cc450(auStack_40,"textures/sky/indoor512_ft.tex");
  uStack_8._0_1_ = 6;
  FUN_009cc450(auStack_28,"textures/sky/indoor512_dn.tex");
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_00828a60(auStack_70,auStack_88,auStack_58,auStack_40,aiStack_a4,auStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar3 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar2 = uStack_2c + 1;
    uVar3 = auStack_40[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_40[0] - 4);
      uVar2 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar2 = uStack_44 + 1;
    uVar3 = auStack_58[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_58[0] - 4);
      uVar2 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar2 = uStack_5c + 1;
    uVar3 = auStack_70[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_70[0] - 4);
      uVar2 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (0xf < uStack_74) {
    uVar2 = uStack_74 + 1;
    uVar3 = auStack_88[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_88[0] - 4);
      uVar2 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  if (0xf < uStack_90) {
    uVar3 = uStack_90 + 1;
    iVar1 = aiStack_a4[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_a4[0] + -4);
      uVar3 = uStack_90 + 0x24;
      if (0x1f < (aiStack_a4[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12594 ; VA 0x008275a0 ; FUN_008275a0 */

void __fastcall FUN_008275a0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar1 + 0x34,8,6,FUN_00550b30);
    FUN_016f32d1(iVar1 + 4,8,6,FUN_00550b30);
    FUN_01674ea0(iVar1,0x68);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12595 ; VA 0x00827610 ; FUN_00827610 */

void __fastcall FUN_00827610(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::EnvMapPBR::vftable;
  iVar2 = param_1[100];
  if (iVar2 != 0) {
    uVar5 = (param_1[0x66] - iVar2 >> 3) * 8;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00827931;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[100] = 0;
    param_1[0x65] = 0;
    param_1[0x66] = 0;
  }
  iVar2 = param_1[0x61];
  if (iVar2 != 0) {
    uVar5 = (param_1[99] - iVar2 >> 3) * 8;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00827931;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x61] = 0;
    param_1[0x62] = 0;
    param_1[99] = 0;
  }
  iVar2 = param_1[0x5e];
  if (iVar2 != 0) {
    uVar5 = (param_1[0x60] - iVar2 >> 3) * 8;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00827931:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x5e] = 0;
    param_1[0x5f] = 0;
    param_1[0x60] = 0;
  }
  FUN_016f32d1(param_1 + 0x4c,8,6,FUN_00550b30);
  piVar3 = (int *)param_1[0x4b];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x49];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x47];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x45];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar2 = param_1[0x27];
  if (iVar2 != 0) {
    uStack_8 = 0;
    FUN_016f32d1(iVar2 + 0x34,8,6,FUN_00550b30);
    FUN_016f32d1(iVar2 + 4,8,6,FUN_00550b30);
    uStack_8 = 0xffffffff;
    FUN_01674ea0(iVar2,0x68);
  }
  piVar3 = (int *)param_1[0x26];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x24];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x22];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = (int *)param_1[0x20];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_016f32d1(param_1 + 0xd,8,9,FUN_00550b30);
  FUN_016790b0();
  FUN_0147cba0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12596 ; VA 0x00827940 ; FUN_00827940 */

undefined4 __thiscall FUN_00827940(undefined4 param_1,byte param_2)

{
  FUN_00827610();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1b8);
  }
  return param_1;
}



/* FUNCTION 12597 ; VA 0x00827970 ; FUN_00827970 */

void __thiscall FUN_00827970(int param_1,int *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  if ((*(int *)(param_1 + 0x94) != 0) && (*(int *)(*(int *)(param_1 + 0x94) + 8) == 1)) {
    (**(code **)(*param_2 + 0x10))(*(undefined4 *)(param_1 + 0x8c));
    iVar1 = *(int *)(param_1 + 0x9c);
    *(undefined4 *)(param_1 + 0x9c) = 0;
    if (iVar1 != 0) {
      uStack_8 = 0;
      FUN_016f32d1(iVar1 + 0x34,8,6,FUN_00550b30);
      FUN_016f32d1(iVar1 + 4,8,6,FUN_00550b30);
      FUN_01674ea0(iVar1,0x68);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12598 ; VA 0x00827a10 ; FUN_00827a10 */

void __thiscall FUN_00827a10(int param_1,int *param_2)

{
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  if ((*(int *)(param_1 + 0x110) != 0) && (1 < *(uint *)(*(int *)(param_1 + 0x110) + 0x3c))) {
                    /* WARNING: Could not recover jumptable at 0x00827a36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_2 + 0x10))();
    return;
  }
  return;
}



/* FUNCTION 12599 ; VA 0x00827a40 ; FUN_00827a40 */

void __thiscall FUN_00827a40(int param_1,int *param_2)

{
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  if ((*(int *)(param_1 + 0x84) != 0) && (*(int *)(*(int *)(param_1 + 0x84) + 8) == 1)) {
    (**(code **)(*param_2 + 0x10))(*(undefined4 *)(param_1 + 0x7c));
  }
  return;
}



/* FUNCTION 12600 ; VA 0x00827a70 ; FUN_00827a70 */

void __fastcall FUN_00827a70(int param_1)

{
  undefined4 *puVar1;
  code *pcStack_c;
  undefined4 uStack_8;
  
  pcStack_c = FUN_00828370;
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x174) != '\0') {
    FUN_00826490(6,param_1 + 0x184,&pcStack_c);
    puVar1 = *(undefined4 **)(param_1 + 0x188);
    pcStack_c = FUN_00827a40;
    uStack_8 = 0;
    if (*(undefined4 **)(param_1 + 0x18c) == puVar1) {
      FUN_006c6ad0(puVar1,&pcStack_c);
    }
    else {
      *puVar1 = FUN_00827a40;
      puVar1[1] = 0;
      *(int *)(param_1 + 0x188) = *(int *)(param_1 + 0x188) + 8;
    }
    pcStack_c = FUN_008291c0;
    uStack_8 = 0;
    FUN_00826490(*(int *)(param_1 + 0x30) * 6 + 1,param_1 + 0x184,&pcStack_c);
    pcStack_c = FUN_008289f0;
    uStack_8 = 0;
    FUN_00826490(6,param_1 + 400,&pcStack_c);
    puVar1 = *(undefined4 **)(param_1 + 0x194);
    pcStack_c = FUN_00827970;
    uStack_8 = 0;
    if (*(undefined4 **)(param_1 + 0x198) == puVar1) {
      FUN_006c6ad0(puVar1,&pcStack_c);
    }
    else {
      *puVar1 = FUN_00827970;
      puVar1[1] = 0;
      *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + 8;
    }
    pcStack_c = FUN_008290f0;
    uStack_8 = 0;
    FUN_00826490(*(int *)(param_1 + 0x30) * 6 + 1,param_1 + 400,&pcStack_c);
    return;
  }
  FUN_00826490(6,param_1 + 0x178,&pcStack_c);
  puVar1 = *(undefined4 **)(param_1 + 0x17c);
  pcStack_c = FUN_00827a10;
  uStack_8 = 0;
  if (*(undefined4 **)(param_1 + 0x180) != puVar1) {
    *puVar1 = FUN_00827a10;
    puVar1[1] = 0;
    *(int *)(param_1 + 0x17c) = *(int *)(param_1 + 0x17c) + 8;
    return;
  }
  FUN_006c6ad0(puVar1,&pcStack_c);
  return;
}



/* FUNCTION 12601 ; VA 0x00827bd0 ; FUN_00827bd0 */

undefined4 *
FUN_00827bd0(undefined4 *param_1,float param_2,float param_3,float param_4,float param_5,
            float param_6,float param_7,float param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  undefined4 uStack_8;
  
  puVar4 = (undefined4 *)FUN_01165df0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  uStack_8 = 0;
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  uVar1 = puVar4[0xd];
  uVar2 = puVar4[0xe];
  uVar3 = puVar4[0xf];
  param_1[0xc] = puVar4[0xc];
  param_1[0xd] = uVar1;
  param_1[0xe] = uVar2;
  param_1[0xf] = uVar3;
  fStack_14 = param_4 * param_8 * param_6 - param_3 * param_8 * param_7;
  fStack_10 = param_2 * param_8 * param_7 - param_4 * param_8 * param_5;
  fStack_c = param_3 * param_8 * param_5 - param_2 * param_8 * param_6;
  FUN_01165f50(0,&fStack_14);
  fStack_14 = param_5;
  fStack_10 = param_6;
  fStack_c = param_7;
  uStack_8 = 0;
  FUN_01165f50(1,&fStack_14);
  fStack_14 = param_2;
  fStack_10 = param_3;
  fStack_c = param_4;
  uStack_8 = 0;
  FUN_01165f50(2,&fStack_14);
  return param_1;
}



/* FUNCTION 12602 ; VA 0x00827ce0 ; FUN_00827ce0 */

void __fastcall FUN_00827ce0(int param_1)

{
  int iVar1;
  
  iVar1 = 0x184;
  if (*(char *)(param_1 + 0x174) == '\0') {
    iVar1 = 0x178;
  }
  FUN_008280b0(iVar1 + param_1);
  FUN_006eccd0();
  return;
}



/* FUNCTION 12603 ; VA 0x00827d10 ; FUN_00827d10 */

void __fastcall FUN_00827d10(int param_1)

{
  FUN_008280b0(param_1 + 0x178);
  *(undefined *)(param_1 + 0x1b4) = 1;
  return;
}



/* FUNCTION 12604 ; VA 0x00827d30 ; FUN_00827d30 */

void __fastcall FUN_00827d30(int param_1)

{
  *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a0);
  *(undefined4 *)(param_1 + 0x1a0) = *(undefined4 *)(param_1 + 0x1a4);
  *(undefined4 *)(param_1 + 0x1a4) = 0;
  *(undefined4 *)(param_1 + 0x1a8) = 0;
  *(undefined4 *)(param_1 + 0x1b0) = 1;
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  return;
}



/* FUNCTION 12605 ; VA 0x00827d80 ; FUN_00827d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00827d80(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint3 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  float fStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined2 uStack_24;
  char *pcStack_20;
  uint uStack_1c;
  char *pcStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b6bc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcStack_20 = "SpecularConvVS";
  uStack_1c = 0xe;
  pcStack_18 = "SpecularConvFS";
  uStack_14 = 0xe;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00790e00(&iStack_60,&pcStack_20,2);
  iStack_34 = iStack_60;
  if (piStack_5c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_5c + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_5c)();
      LOCK();
      piVar1 = piStack_5c + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piStack_5c + 4))();
      }
    }
  }
  if (iStack_34 == 0) goto LAB_00828061;
  switch(param_4) {
  case 0:
    uVar7 = 0x3fc90fdb;
    break;
  case 1:
    uVar7 = 0xbfc90fdb;
    break;
  case 2:
    uStack_1c = 0x3f800000;
    pcStack_18 = (char *)0x0;
    uVar7 = 0xbfc90fdb;
    goto LAB_00827e3e;
  case 3:
    uStack_1c = 0x3f800000;
    pcStack_18 = (char *)0x0;
    uVar7 = 0x3fc90fdb;
    goto LAB_00827e3e;
  default:
    uStack_38 = DAT_01d71e7c;
    uStack_58 = _DAT_01d71e5c;
    uStack_54 = uRam01d71e60;
    uStack_50 = uRam01d71e64;
    uStack_4c = _DAT_01d71e68;
    uStack_48 = _DAT_01d71e6c;
    uStack_44 = uRam01d71e70;
    uStack_40 = _DAT_01d71e74;
    uStack_3c = uRam01d71e78;
    goto LAB_00827eb9;
  case 5:
    uVar7 = 0x40490fdb;
  }
  pcStack_18 = (char *)0x3f800000;
  uStack_1c = 0;
LAB_00827e3e:
  uStack_14 = 0;
  FUN_0081b070(&uStack_58,&uStack_1c,uVar7);
LAB_00827eb9:
  uVar5 = param_5;
  uStack_a0 = uStack_58;
  uStack_9c = uStack_54;
  uStack_98 = uStack_50;
  iVar6 = *(int *)(iStack_30 + 0x30) + -1;
  uStack_90 = uStack_4c;
  uStack_8c = uStack_48;
  uStack_88 = uStack_44;
  uStack_80 = uStack_40;
  uStack_7c = uStack_3c;
  uStack_78 = uStack_38;
  uStack_94 = 0x3f800000;
  uStack_84 = 0x3f800000;
  uStack_74 = 0x3f800000;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  fStack_70 = (float)(int)param_5 /
              (float)((double)iVar6 + (double)(&DAT_018c0d90)[-(iVar6 >> 0x1f)]);
  (**(code **)(*param_1 + 0x14))(*(undefined4 *)(iStack_30 + 0x34 + param_5 * 8),0,1,0,0);
  uVar4 = (uint3)param_5;
  param_5 = (uint)(uVar4 & 0xff);
  uStack_28 = 0x1000100;
  uStack_2c = 0xf;
  uStack_24 = (ushort)uStack_24._1_1_ << 8;
  uStack_1c = uStack_1c & 0xffff0000;
  pcStack_18 = (char *)0x0;
  uStack_14 = uStack_14 & 0xffffff00;
  (**(code **)(*param_1 + 0x3c))(&uStack_1c,&uStack_2c,(int)&param_5 + 1);
  (**(code **)(*param_1 + 0x24))(iStack_34);
  (**(code **)(*param_1 + 0x30))(2,&uStack_a0,0x40);
  uStack_2c = CONCAT22(uStack_2c._2_2_,1);
  uStack_28 = 0;
  uStack_24 = 0;
  (**(code **)(*param_1 + 0x34))(0,param_2,&uStack_2c);
  puVar3 = *(undefined4 **)(*(int *)(*(int *)(iStack_30 + 0x2c) + 0x4f8) + 0x41c);
  (**(code **)(*param_1 + 0x40))(*puVar3,puVar3[2],puVar3[3],puVar3[4],puVar3[5],0);
  (**(code **)(*param_1 + 0x18))();
  iVar6 = (**(code **)(*param_1 + 8))
                    (*(undefined4 *)(iStack_30 + 0x34 + uVar5 * 8),param_2,uVar5,param_4);
LAB_00828061:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 12606 ; VA 0x008280b0 ; FUN_008280b0 */

void __thiscall FUN_008280b0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  do {
    iVar1 = *(int *)(param_1 + 0x19c + iVar2 * 4);
    if (iVar1 == 0) {
      *(int *)(param_1 + iVar2 * 4 + 0x19c) = param_2;
      return;
    }
    if (iVar1 == param_2) {
      if (iVar2 != 0) {
        return;
      }
      if (*(int *)(param_1 + 0x1a8) == 0) {
        return;
      }
    }
    iVar2 = iVar2 + 1;
    if (2 < iVar2) {
      return;
    }
  } while( true );
}



/* FUNCTION 12607 ; VA 0x00828100 ; FUN_00828100 */

void __thiscall FUN_00828100(undefined4 *param_1,int *param_2,undefined4 *param_3,uint param_4)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  undefined auStack_d0 [128];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6c08;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  puStack_24 = param_1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb3d60) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb3d60);
    if (DAT_01eb3d60 == -1) {
      uStack_8 = 0;
      uVar5 = FUN_0152dab0("Render","IndoorEnv",0xffffffff);
      DAT_01eb3d5c = (undefined4)((ulonglong)uVar5 >> 0x20);
      DAT_01eb3d58 = (undefined4)uVar5;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3d60);
    }
  }
  uVar2 = DAT_01eb3d58;
  uStack_30 = DAT_01eb3d5c;
  uStack_50 = DAT_01eb3d58;
  uStack_4c = DAT_01eb3d5c;
  uStack_48 = FUN_0152d930(DAT_01eb3d58,DAT_01eb3d5c);
  uStack_8 = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb3d70) {
    FUN_016f3809(&DAT_01eb3d70);
    if (DAT_01eb3d70 == -1) {
      uStack_8._0_1_ = 2;
      uVar5 = FUN_0152dab0(&DAT_018fb928,"IndoorEnv",0xffffffff);
      DAT_01eb3d6c = (undefined4)((ulonglong)uVar5 >> 0x20);
      DAT_01eb3d68 = (undefined4)uVar5;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb3d70);
    }
  }
  uStack_2c = DAT_01eb3d68;
  uStack_28 = DAT_01eb3d6c;
  uStack_40 = DAT_01eb3d68;
  uStack_3c = DAT_01eb3d6c;
  uStack_38 = FUN_0152d930(DAT_01eb3d68,DAT_01eb3d6c);
  uStack_8._0_1_ = 3;
  puStack_20 = param_1 + *(int *)(&DAT_019186c4 + param_4 * 4) * 2 + 1;
  piVar3 = (int *)&DAT_01eb1b04;
  if ((int *)*puStack_20 != (int *)0x0) {
    piVar3 = (int *)*puStack_20;
  }
  if (*piVar3 != 0) {
    (**(code **)(*param_2 + 0x14))(*param_3,0,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = 0;
    puVar4 = (undefined4 *)&DAT_01eb1b04;
    if ((undefined4 *)*puStack_20 != (undefined4 *)0x0) {
      puVar4 = (undefined4 *)*puStack_20;
    }
    (**(code **)(*param_2 + 0x34))(0,*puVar4,&uStack_1c);
    FUN_00829d10(*param_3);
    param_4 = param_4 & 0xff000000;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(param_2,*puStack_24,"PassThroughVS","SRGBToLinearFS",auStack_d0,&uStack_1c,&param_4
                );
    (**(code **)(*param_2 + 0x18))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0152dda0(uStack_2c,uStack_28,uStack_38);
  uStack_8 = 5;
  FUN_0152dda0(uVar2,uStack_30,uStack_48);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12608 ; VA 0x00828370 ; FUN_00828370 */

void __thiscall FUN_00828370(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 auStack_5d0 [60];
  undefined4 uStack_4e0;
  undefined auStack_280 [580];
  int iStack_3c;
  int iStack_38;
  undefined8 uStack_34;
  undefined *puStack_24;
  undefined *puStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6c2c;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0x1ac);
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x1ac) = iVar2 + 1;
  iStack_3c = param_1;
  iStack_38 = iVar2;
  if (DAT_01eb3d4c != '\0') {
    FUN_01677520(DAT_01eb3d4c,"EnvMapPBR: renderFace(%d), step %u",iVar2,
                 *(undefined4 *)(param_1 + 0x1a8));
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4078) &&
     (FUN_016f3809(&DAT_01eb4078), DAT_01eb4078 == -1)) {
    puStack_18 = (undefined *)0x0;
    puStack_24 = (undefined *)0x0;
    uStack_8 = 0;
    uStack_34 = 0;
    FUN_00827bd0(&DAT_01eb3d78,DAT_018f7864,0,(ulonglong)DAT_018ce2f8 << 0x20,0,&DAT_bf800000);
    puStack_24 = (undefined *)0x0;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3db8,CONCAT44((int)uStack_34,DAT_018ce2f8),0,
                 CONCAT44(DAT_018ce2f8,(int)uStack_34),0,&DAT_bf800000);
    puStack_24 = &DAT_bf800000;
    uVar6 = (undefined4)uStack_34;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3df8,CONCAT44(DAT_018f7864,uVar6),0,CONCAT44(uVar6,uVar6),&DAT_bf800000,
                 &DAT_bf800000);
    puStack_24 = (undefined *)0x3f800000;
    uVar6 = (undefined4)uStack_34;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3e38,CONCAT44(DAT_018ce2f8,uVar6),0,CONCAT44(uVar6,uVar6),0x3f800000,
                 &DAT_bf800000);
    uVar6 = (undefined4)uStack_34;
    puStack_24 = (undefined *)0x0;
    puStack_18 = &DAT_bf800000;
    FUN_00827bd0(&DAT_01eb3e78,CONCAT44(uVar6,uVar6),&DAT_bf800000,CONCAT44(DAT_018ce2f8,uVar6),0,
                 &DAT_bf800000);
    uVar6 = (undefined4)uStack_34;
    puStack_24 = (undefined *)0x0;
    puStack_18 = (undefined *)0x3f800000;
    FUN_00827bd0(&DAT_01eb3eb8,CONCAT44(uVar6,uVar6),0x3f800000,CONCAT44(DAT_018ce2f8,uVar6),0,
                 &DAT_bf800000);
    puStack_24 = (undefined *)0x0;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3ef8,CONCAT44((int)uStack_34,DAT_018f7864),0,
                 CONCAT44(DAT_018f7864,(int)uStack_34),0,0x3f800000);
    puStack_24 = (undefined *)0x0;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3f38,CONCAT44((int)uStack_34,DAT_018ce2f8),0,
                 CONCAT44(DAT_018f7864,(int)uStack_34),0,0x3f800000);
    puStack_24 = (undefined *)0x3f800000;
    uVar6 = (undefined4)uStack_34;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3f78,CONCAT44(DAT_018f7864,uVar6),0,CONCAT44(uVar6,uVar6),0x3f800000,
                 0x3f800000);
    puStack_24 = &DAT_bf800000;
    uVar6 = (undefined4)uStack_34;
    puStack_18 = (undefined *)0x0;
    FUN_00827bd0(&DAT_01eb3fb8,CONCAT44(DAT_018ce2f8,uVar6),0,CONCAT44(uVar6,uVar6),&DAT_bf800000,
                 0x3f800000);
    uVar6 = (undefined4)uStack_34;
    puStack_24 = (undefined *)0x0;
    puStack_18 = &DAT_bf800000;
    FUN_00827bd0(&DAT_01eb3ff8,CONCAT44(uVar6,uVar6),&DAT_bf800000,CONCAT44(DAT_018f7864,uVar6),0,
                 0x3f800000);
    uVar6 = (undefined4)uStack_34;
    puStack_24 = (undefined *)0x0;
    puStack_18 = (undefined *)0x3f800000;
    FUN_00827bd0(&DAT_01eb4038,CONCAT44(uVar6,uVar6),0x3f800000,CONCAT44(DAT_018f7864,uVar6),0,
                 0x3f800000);
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb4078);
  }
  iVar3 = *(int *)(*(int *)(param_1 + 0x2c) + 0x4f8);
  iVar1 = (**(code **)(**(int **)(*(int *)(param_1 + 0x2c) + 0x3c) + 0x40))();
  bStack_11 = *(byte *)(iVar1 + 0x3a);
  FUN_007cc9d0();
  FUN_007cdb40(&DAT_01eb3d78 + (iVar2 + (uint)bStack_11 * 6) * 0x40);
  FUN_007cd880(0x3fc90fdb,0x3f800000,0x453b8000,0x3f000000,0);
  puVar4 = (undefined4 *)(iVar3 + 0x54);
  puVar5 = auStack_5d0;
  for (iVar2 = 0xd4; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar5 = *puVar4;
    puVar4 = puVar4 + 1;
    puVar5 = puVar5 + 1;
  }
  FUN_007ce460(auStack_280);
  iVar2 = iStack_3c;
  if (*(char *)(iStack_3c + 0x174) == '\0') {
    iVar3 = *(int *)(iStack_3c + 0x128);
    if ((iVar3 == 0) && (iVar3 = *(int *)(iStack_3c + 0x130 + iStack_38 * 8), iVar3 == 0)) {
      ExceptionList = pvStack_10;
      return;
    }
    iStack_3c = iVar3;
    (**(code **)(*param_2 + 0x14))(iVar3,0,1,0,0);
    (**(code **)(*param_2 + 0x30))(0,auStack_5d0,0x350);
    FUN_0079d410(param_2,auStack_280,1,0);
    (**(code **)(*param_2 + 0x18))();
    if (iStack_3c != *(int *)(iVar2 + 0x128)) goto LAB_00828564;
    uVar6 = *(undefined4 *)(iVar2 + 0x110);
    iVar3 = iStack_3c;
  }
  else {
    (**(code **)(*param_2 + 0x14))(*(undefined4 *)(iStack_3c + 0x34),0,1,0,0);
    (**(code **)(*param_2 + 0x30))(0,auStack_5d0,0x350);
    FUN_0079d410(param_2,auStack_280,1,1);
    (**(code **)(*param_2 + 0x18))();
    uVar6 = *(undefined4 *)(iVar2 + 0x7c);
    iVar3 = *(int *)(iVar2 + 0x34);
  }
  (**(code **)(*param_2 + 8))(iVar3,uVar6,0,iStack_38);
LAB_00828564:
  if (iStack_38 == 0) {
    *(undefined4 *)(iVar2 + 0x170) = uStack_4e0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12609 ; VA 0x008289f0 ; FUN_008289f0 */

void __thiscall FUN_008289f0(int param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1ac);
  *(int *)(param_1 + 0x1ac) = iVar1 + 1;
  if (DAT_01eb3d4c != '\0') {
    FUN_01677520(DAT_01eb3d4c,"EnvMapPBR: renderFaceIndoor(%d), step %u",iVar1,
                 *(undefined4 *)(param_1 + 0x1a8));
  }
  FUN_00828100(param_2,(undefined4 *)(param_1 + 0x34),iVar1);
  (**(code **)(*param_2 + 8))
            (*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(param_1 + 0x8c),0,iVar1);
  return;
}



/* FUNCTION 12610 ; VA 0x00828a60 ; FUN_00828a60 */

void __thiscall
FUN_00828a60(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_58 [4];
  int *piStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6032;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_14 = CONCAT31(uStack_14._1_3_,-(DAT_01d6200c != '\0')) & 0xffffff04;
  uStack_18 = *(undefined4 *)(*param_1 + 0x4ec);
  ExceptionList = &pvStack_10;
  FUN_005542c0("IndoorEnv.IndoorEnvRt",0x15);
  uStack_8 = 0;
  uVar4 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piVar5 = (int *)FUN_00782550(auStack_38,param_2,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xd] = iVar2;
  piVar5 = (int *)param_1[0xe];
  param_1[0xe] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("IndoorEnv.IndoorEnvUp",0x15);
  uStack_8 = 2;
  uVar4 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piVar5 = (int *)FUN_00782550(auStack_38,param_6,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0xf] = iVar2;
  piVar5 = (int *)param_1[0x10];
  param_1[0x10] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("IndoorEnv.IndoorEnvBk",0x15);
  uStack_8 = 4;
  uVar4 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piVar5 = (int *)FUN_00782550(auStack_38,param_4,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0x11] = iVar2;
  piVar5 = (int *)param_1[0x12];
  param_1[0x12] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("IndoorEnv.IndoorEnvLf",0x15);
  uStack_8 = 6;
  uVar4 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  piVar5 = (int *)FUN_00782550(auStack_38,param_3,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0x13] = iVar2;
  piVar5 = (int *)param_1[0x14];
  param_1[0x14] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  piVar5 = piStack_34;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("IndoorEnv.IndoorEnvDn",0x15);
  uStack_8 = 8;
  uVar4 = FUN_00d102b0(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  piVar5 = (int *)FUN_00782550(auStack_38,param_7,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0x15] = iVar2;
  piVar5 = (int *)param_1[0x16];
  param_1[0x16] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  FUN_00637950();
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar6 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  FUN_005542c0("IndoorEnv.IndoorEnvFt",0x15);
  uStack_8 = 10;
  uVar4 = FUN_00d102b0(auStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  piVar5 = (int *)FUN_00782550(auStack_58,param_5,uStack_14,0,uVar4,0x425c0000,0x80);
  iVar2 = *piVar5;
  iVar3 = piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  param_1[0x17] = iVar2;
  piVar5 = (int *)param_1[0x18];
  param_1[0x18] = iVar3;
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar2 = piVar5[1] + -1;
    piVar5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar2 = piVar5[2] + -1;
      piVar5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_54[1] + -1;
    piStack_54[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      piVar5 = piStack_54 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  FUN_00637950();
  if (0xf < uStack_3c) {
    uVar7 = uStack_3c + 1;
    uVar6 = auStack_50[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_50[0] - 4);
      uVar7 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12611 ; VA 0x008290f0 ; FUN_008290f0 */

void __thiscall FUN_008290f0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *(int *)(param_1 + 0x1ac);
  *(int *)(param_1 + 0x1ac) = iVar2 + 1;
  if (DAT_01eb3d4c != '\0') {
    FUN_01677520(DAT_01eb3d4c,"EnvMapPBR: specularConvolutionIndoor(%d, %u), step %u",iVar2,
                 *(undefined4 *)(param_1 + 0x1b0),*(undefined4 *)(param_1 + 0x1a8));
  }
  uVar3 = *(undefined4 *)(param_1 + 0x1b0);
  if (*(int *)(param_1 + 0x90) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x90) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00827d80(param_2,*(undefined4 *)(param_1 + 0x8c),*(undefined4 *)(param_1 + 0x90),iVar2,uVar3);
  if (*(int *)(param_1 + 0x1ac) == 6) {
    *(int *)(param_1 + 0x1b0) = *(int *)(param_1 + 0x1b0) + 1;
    *(undefined4 *)(param_1 + 0x1ac) = 0;
    if (((*(int *)(param_1 + 0x1b0) == *(int *)(param_1 + 0x30)) && (*(int *)(param_1 + 0x94) != 0))
       && (*(int *)(*(int *)(param_1 + 0x94) + 8) == 1)) {
      FUN_00773c10((undefined4 *)(param_1 + 0x8c));
    }
  }
  return;
}



/* FUNCTION 12612 ; VA 0x008291c0 ; FUN_008291c0 */

void __thiscall FUN_008291c0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *(int *)(param_1 + 0x1ac);
  *(int *)(param_1 + 0x1ac) = iVar2 + 1;
  if (DAT_01eb3d4c != '\0') {
    FUN_01677520(DAT_01eb3d4c,"EnvMapPBR: specularConvolutionOutdoor(%d, %u), step %u",iVar2,
                 *(undefined4 *)(param_1 + 0x1b0),*(undefined4 *)(param_1 + 0x1a8));
  }
  uVar3 = *(undefined4 *)(param_1 + 0x1b0);
  if (*(int *)(param_1 + 0x80) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x80) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00827d80(param_2,*(undefined4 *)(param_1 + 0x7c),*(undefined4 *)(param_1 + 0x80),iVar2,uVar3);
  if (*(int *)(param_1 + 0x1ac) == 6) {
    *(int *)(param_1 + 0x1b0) = *(int *)(param_1 + 0x1b0) + 1;
    *(undefined4 *)(param_1 + 0x1ac) = 0;
    if (((*(int *)(param_1 + 0x1b0) == *(int *)(param_1 + 0x30)) && (*(int *)(param_1 + 0x84) != 0))
       && (*(int *)(*(int *)(param_1 + 0x84) + 8) == 1)) {
      FUN_00773c10((undefined4 *)(param_1 + 0x7c));
    }
  }
  return;
}



/* FUNCTION 12613 ; VA 0x00829290 ; FUN_00829290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00829290(int param_1,undefined4 param_2,double param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  float10 fVar6;
  double dVar7;
  uint uVar8;
  
  if (*(int *)(param_1 + 0x110) != 0) {
    iVar2 = *(int *)(param_1 + 0x9c);
    if (iVar2 != 0) {
      cVar1 = *(char *)(iVar2 + 100);
      piVar5 = (int *)(iVar2 + 0x34);
      iVar4 = 0;
      piVar3 = piVar5;
      do {
        if ((*piVar3 == 0) || (*(int *)(*piVar3 + 8) != 3)) goto LAB_00829338;
        iVar4 = iVar4 + 1;
        piVar3 = piVar3 + 2;
      } while (iVar4 < 6);
      if (piVar5 != (int *)(iVar2 + 100)) {
        do {
          iVar4 = piVar5[1];
          if (iVar4 != 0) {
            LOCK();
            *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
            UNLOCK();
            iVar4 = piVar5[1];
          }
          piVar5[-0xc] = *piVar5;
          piVar3 = (int *)piVar5[-0xb];
          piVar5[-0xb] = iVar4;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[1] + -1;
            piVar3[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)*piVar3)();
              LOCK();
              iVar4 = piVar3[2] + -1;
              piVar3[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          piVar5 = piVar5 + 2;
        } while (piVar5 != (int *)(iVar2 + 100));
      }
      *(undefined *)(iVar2 + 100) = 1;
LAB_00829338:
      if ((cVar1 == '\0') && (*(char *)(*(int *)(param_1 + 0x9c) + 100) != '\0')) {
        FUN_0081cf60(*(int *)(param_1 + 0x9c) + 4,param_1 + 0xa0,param_1 + 0x100);
        FUN_006eccd0();
        if (*(char *)(param_1 + 0x174) != '\0') {
          FUN_008280b0(param_1 + 400);
        }
      }
    }
    fVar6 = (float10)FUN_01683110();
    if (*(char *)(*(int *)(*(int *)(param_1 + 0x2c) + 0x510) + 0x2c) == '\0') {
      if (*(char *)(param_1 + 0x174) == '\0') {
        dVar7 = *(double *)(param_1 + 0x160) - param_3;
        uVar8 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
        if ((_DAT_01918980 <
             (double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & uVar8,
                              SUB84(dVar7,0) & (uint)DAT_018c0da0)) ||
           (dVar7 = *(double *)(param_1 + 0x168) - (double)fVar6,
           DAT_018ce310 <
           (double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & uVar8,
                            SUB84(dVar7,0) & (uint)DAT_018c0da0))) {
          *(double *)(param_1 + 0x160) = param_3;
          *(double *)(param_1 + 0x168) = (double)fVar6;
          FUN_008280b0(param_1 + 0x178);
        }
      }
    }
    else {
      *(undefined *)(param_1 + 0x1b4) = 1;
    }
    piVar5 = *(int **)(param_1 + 0x19c);
    if (*(char *)(param_1 + 0x1b4) != '\0') {
      while (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + *(int *)(param_1 + 0x1a8) * 8))(param_2);
        *(int *)(param_1 + 0x1a8) = *(int *)(param_1 + 0x1a8) + 1;
        if ((uint)((*(int **)(param_1 + 0x19c))[1] - **(int **)(param_1 + 0x19c) >> 3) <=
            *(uint *)(param_1 + 0x1a8)) {
          *(undefined4 *)(param_1 + 0x19c) = *(undefined4 *)(param_1 + 0x1a0);
          *(undefined4 *)(param_1 + 0x1a0) = *(undefined4 *)(param_1 + 0x1a4);
          *(undefined4 *)(param_1 + 0x1a4) = 0;
          *(undefined4 *)(param_1 + 0x1a8) = 0;
          *(undefined4 *)(param_1 + 0x1b0) = 1;
          *(undefined4 *)(param_1 + 0x1ac) = 0;
        }
        piVar5 = *(int **)(param_1 + 0x19c);
      }
      *(undefined *)(param_1 + 0x1b4) = 0;
      return;
    }
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + *(int *)(param_1 + 0x1a8) * 8))(param_2);
      *(int *)(param_1 + 0x1a8) = *(int *)(param_1 + 0x1a8) + 1;
      if ((uint)((*(int **)(param_1 + 0x19c))[1] - **(int **)(param_1 + 0x19c) >> 3) <=
          *(uint *)(param_1 + 0x1a8)) {
        FUN_00827d30();
      }
    }
  }
  return;
}



/* FUNCTION 12614 ; VA 0x00829500 ; FUN_00829500 */

void __thiscall FUN_00829500(int param_1,int param_2)

{
  float fVar1;
  float fVar2;
  double dVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  float *pfVar7;
  float *pfVar8;
  float *pfVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_8 = *(float *)(param_2 + 0x19c);
  *(undefined4 *)(param_2 + 0x1b0) = *(undefined4 *)(param_2 + 0x80);
  *(undefined4 *)(param_2 + 0x1b4) = *(undefined4 *)(param_2 + 0x84);
  *(undefined4 *)(param_2 + 0x1b8) = *(undefined4 *)(param_2 + 0x88);
  *(undefined4 *)(param_2 + 0x1bc) = *(undefined4 *)(param_2 + 0x8c);
  *(undefined4 *)(param_2 + 0x1c0) = *(undefined4 *)(param_2 + 0x90);
  *(undefined4 *)(param_2 + 0x1c4) = *(undefined4 *)(param_2 + 0x94);
  *(undefined4 *)(param_2 + 0x1c8) = *(undefined4 *)(param_2 + 0x98);
  *(undefined4 *)(param_2 + 0x1cc) = *(undefined4 *)(param_2 + 0x9c);
  if ((DAT_01d60bd8 == '\0') && (fStack_8 < DAT_018f784c)) {
    FUN_0170d1f0(param_2 + 0x1d0,0,0xc0);
    return;
  }
  iVar6 = FUN_007994b0();
  dVar3 = DAT_018c0d60;
  if (DAT_01d60bd8 == '\0') {
    dVar3 = (double)fStack_8;
  }
  fVar10 = (float)dVar3;
  pfVar7 = (float *)FUN_011658d0(&uStack_2c);
  fStack_c = *pfVar7 * fVar10;
  fStack_10 = pfVar7[1] * fVar10;
  fStack_14 = pfVar7[2] * fVar10;
  pfVar7 = (float *)FUN_011658d0(&uStack_2c);
  fStack_18 = *pfVar7 * fVar10;
  fStack_1c = pfVar7[1] * fVar10;
  fStack_20 = pfVar7[2] * fVar10;
  fVar11 = (fStack_c + fStack_18) * DAT_018ce2f4;
  fVar12 = (fStack_10 + fStack_1c) * DAT_018ce2f4;
  fVar13 = (fStack_14 + fStack_20) * DAT_018ce2f4;
  pfVar7 = (float *)FUN_01165750(iVar6);
  fStack_48 = pfVar7[1] * fVar12;
  fStack_44 = pfVar7[2] * fVar13;
  fStack_40 = pfVar7[3] * 0.0;
  *(float *)(param_2 + 0x1d0) = *pfVar7 * fVar11;
  *(float *)(param_2 + 0x1d4) = fStack_48;
  *(float *)(param_2 + 0x1d8) = fStack_44;
  *(float *)(param_2 + 0x1dc) = fStack_40;
  pfVar7 = (float *)FUN_01165750(iVar6 + 0x10);
  fStack_48 = pfVar7[1] * fVar12;
  fStack_44 = pfVar7[2] * fVar13;
  fStack_40 = pfVar7[3] * 0.0;
  *(float *)(param_2 + 0x1e0) = *pfVar7 * fVar11;
  *(float *)(param_2 + 0x1e4) = fStack_48;
  *(float *)(param_2 + 0x1e8) = fStack_44;
  *(float *)(param_2 + 0x1ec) = fStack_40;
  pfVar7 = (float *)FUN_01165750(iVar6 + 0x20);
  fStack_48 = pfVar7[1] * fStack_10;
  fStack_44 = pfVar7[2] * fStack_14;
  fStack_40 = pfVar7[3] * 0.0;
  *(float *)(param_2 + 0x1f0) = fStack_c * *pfVar7;
  *(float *)(param_2 + 500) = fStack_48;
  *(float *)(param_2 + 0x1f8) = fStack_44;
  *(float *)(param_2 + 0x1fc) = fStack_40;
  pfVar7 = (float *)FUN_01165750(iVar6 + 0x30);
  fStack_48 = pfVar7[1] * fStack_1c;
  fStack_44 = pfVar7[2] * fStack_20;
  fStack_40 = pfVar7[3] * 0.0;
  *(float *)(param_2 + 0x200) = fStack_18 * *pfVar7;
  *(float *)(param_2 + 0x204) = fStack_48;
  *(float *)(param_2 + 0x208) = fStack_44;
  *(float *)(param_2 + 0x20c) = fStack_40;
  pfVar7 = (float *)FUN_01165750(iVar6 + 0x40);
  fStack_48 = pfVar7[1] * fVar12;
  fStack_44 = pfVar7[2] * fVar13;
  fStack_40 = pfVar7[3] * 0.0;
  *(float *)(param_2 + 0x210) = *pfVar7 * fVar11;
  *(float *)(param_2 + 0x214) = fStack_48;
  *(float *)(param_2 + 0x218) = fStack_44;
  *(float *)(param_2 + 0x21c) = fStack_40;
  pfVar8 = (float *)FUN_01165750(iVar6 + 0x50);
  pfVar7 = (float *)(param_1 + 0xa8);
  iVar6 = 6;
  fVar14 = pfVar8[1];
  fVar1 = pfVar8[2];
  fVar2 = pfVar8[3];
  pfVar9 = (float *)(param_2 + 0x1d4);
  *(float *)(param_2 + 0x220) = fVar11 * *pfVar8;
  *(float *)(param_2 + 0x224) = fVar14 * fVar12;
  *(float *)(param_2 + 0x228) = fVar1 * fVar13;
  *(float *)(param_2 + 0x22c) = fVar2 * 0.0;
  do {
    pfVar8 = pfVar7 + -2;
    pfVar4 = pfVar7 + -1;
    fStack_44 = *pfVar7;
    pfVar5 = pfVar7 + 1;
    pfVar7 = pfVar7 + 4;
    fStack_48 = *pfVar4 * fVar10;
    fStack_44 = fStack_44 * fVar10;
    fStack_40 = *pfVar5 * fVar10;
    pfVar9[0x17] = *pfVar8 * fVar10;
    pfVar9[0x18] = fStack_48;
    pfVar9[0x19] = fStack_44;
    pfVar9[0x1a] = fStack_40;
    pfVar9[-1] = pfVar9[-1] - pfVar9[0x17];
    *pfVar9 = *pfVar9 - pfVar9[0x18];
    pfVar9[1] = pfVar9[1] - pfVar9[0x19];
    pfVar9[2] = pfVar9[2] - pfVar9[0x1a];
    pfVar9 = pfVar9 + 4;
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  fVar14 = DAT_018ce2f8;
  if (DAT_01d60bd8 != '\0') {
    fVar14 = fStack_8;
  }
  uStack_2c = *(undefined4 *)(param_1 + 0x100);
  uStack_28 = *(undefined4 *)(param_1 + 0x104);
  uStack_24 = *(undefined4 *)(param_1 + 0x108);
  pfVar7 = (float *)FUN_0115e8f0(&uStack_2c);
  fStack_20 = fStack_8 * *pfVar7;
  fStack_1c = pfVar7[1] * fStack_8;
  fStack_18 = pfVar7[2] * fStack_8;
  FUN_00798b60(&uStack_2c);
  pfVar7 = (float *)FUN_0115e8f0(&uStack_2c);
  pfVar9 = (float *)FUN_011658d0(&fStack_48);
  fVar1 = *pfVar7;
  fVar2 = pfVar7[1];
  fVar10 = *pfVar9;
  fVar11 = pfVar9[1];
  fVar12 = pfVar7[2];
  fVar13 = pfVar9[2];
  *(float *)(param_2 + 0x80) = fStack_20 + *(float *)(param_2 + 0x80);
  *(float *)(param_2 + 0x84) = fStack_1c + *(float *)(param_2 + 0x84);
  *(float *)(param_2 + 0x88) = fStack_18 + *(float *)(param_2 + 0x88);
  *(float *)(param_2 + 0x8c) = *(float *)(param_2 + 0x8c) + 0.0;
  *(float *)(param_2 + 0x90) = (fVar1 * fVar10 * fVar14 - fStack_20) + *(float *)(param_2 + 0x90);
  *(float *)(param_2 + 0x94) = (fVar2 * fVar11 * fVar14 - fStack_1c) + *(float *)(param_2 + 0x94);
  *(float *)(param_2 + 0x98) = (fVar12 * fVar13 * fVar14 - fStack_18) + *(float *)(param_2 + 0x98);
  *(float *)(param_2 + 0x9c) = *(float *)(param_2 + 0x9c) + 0.0;
  return;
}



/* FUNCTION 12615 ; VA 0x00829a50 ; FUN_00829a50 */

float * __thiscall FUN_00829a50(float *param_1,int param_2,int param_3)

{
  double dVar1;
  double dVar2;
  float fVar3;
  
  fVar3 = DAT_018ce2f8;
  param_1[4] = 0.0;
  param_1[5] = 0.0;
  param_1[6] = 0.0;
  param_1[7] = 0.0;
  param_1[8] = 0.0;
  param_1[9] = 0.0;
  param_1[10] = 0.0;
  dVar1 = (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)];
  param_1[0xb] = 0.0;
  param_1[0xc] = 0.0;
  param_1[0xd] = 0.0;
  param_1[0xe] = 0.0;
  param_1[0xf] = 0.0;
  param_1[0x10] = 0.0;
  param_1[0x11] = 0.0;
  param_1[0x12] = 0.0;
  param_1[0x13] = 0.0;
  param_1[0x14] = 0.0;
  param_1[0x15] = 0.0;
  param_1[0x16] = 0.0;
  param_1[0x17] = 0.0;
  dVar2 = (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
  param_1[0x18] = 0.0;
  param_1[0x19] = 0.0;
  param_1[0x1a] = 0.0;
  param_1[0x1b] = 0.0;
  param_1[0x1c] = 0.0;
  param_1[0x1d] = 0.0;
  param_1[0x1e] = 0.0;
  param_1[0x1f] = 0.0;
  *param_1 = (float)((double)param_2 + dVar1);
  param_1[1] = (float)((double)param_3 + dVar2);
  param_1[2] = fVar3 / (float)((double)param_2 + dVar1);
  param_1[3] = fVar3 / (float)((double)param_3 + dVar2);
  return param_1;
}



/* FUNCTION 12616 ; VA 0x00829b90 ; FUN_00829b90 */

float * __thiscall FUN_00829b90(float *param_1,int param_2,int param_3)

{
  double dVar1;
  double dVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float *pfVar6;
  
  fVar3 = DAT_018ce2f8;
  dVar1 = (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)];
  param_1[4] = 0.0;
  param_1[5] = 0.0;
  param_1[6] = 0.0;
  param_1[7] = 0.0;
  param_1[8] = 0.0;
  param_1[9] = 0.0;
  param_1[10] = 0.0;
  param_1[0xb] = 0.0;
  param_1[0xc] = 0.0;
  param_1[0xd] = 0.0;
  param_1[0xe] = 0.0;
  param_1[0xf] = 0.0;
  param_1[0x10] = 0.0;
  dVar2 = (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
  param_1[0x11] = 0.0;
  param_1[0x12] = 0.0;
  param_1[0x13] = 0.0;
  param_1[0x14] = 0.0;
  param_1[0x15] = 0.0;
  param_1[0x16] = 0.0;
  param_1[0x17] = 0.0;
  param_1[0x18] = 0.0;
  param_1[0x19] = 0.0;
  param_1[0x1a] = 0.0;
  param_1[0x1b] = 0.0;
  param_1[0x1c] = 0.0;
  param_1[0x1d] = 0.0;
  param_1[0x1e] = 0.0;
  param_1[0x1f] = 0.0;
  *param_1 = (float)((double)param_2 + dVar1);
  param_1[1] = (float)((double)param_3 + dVar2);
  param_1[2] = fVar3 / (float)((double)param_2 + dVar1);
  param_1[3] = fVar3 / (float)((double)param_3 + dVar2);
  pfVar6 = (float *)FUN_01165f10(0);
  fVar3 = pfVar6[1];
  fVar4 = pfVar6[2];
  fVar5 = pfVar6[3];
  param_1[0xc] = *pfVar6;
  param_1[0xd] = fVar3;
  param_1[0xe] = fVar4;
  param_1[0xf] = fVar5;
  pfVar6 = (float *)FUN_01165f10(1);
  fVar3 = pfVar6[1];
  fVar4 = pfVar6[2];
  fVar5 = pfVar6[3];
  param_1[0x10] = *pfVar6;
  param_1[0x11] = fVar3;
  param_1[0x12] = fVar4;
  param_1[0x13] = fVar5;
  pfVar6 = (float *)FUN_01165f10(2);
  fVar3 = pfVar6[1];
  fVar4 = pfVar6[2];
  fVar5 = pfVar6[3];
  param_1[0x14] = *pfVar6;
  param_1[0x15] = fVar3;
  param_1[0x16] = fVar4;
  param_1[0x17] = fVar5;
  pfVar6 = (float *)FUN_01165f10(3);
  fVar3 = pfVar6[1];
  fVar4 = pfVar6[2];
  fVar5 = pfVar6[3];
  param_1[0x18] = *pfVar6;
  param_1[0x19] = fVar3;
  param_1[0x1a] = fVar4;
  param_1[0x1b] = fVar5;
  return param_1;
}



/* FUNCTION 12617 ; VA 0x00829d10 ; FUN_00829d10 */

float * __thiscall FUN_00829d10(float *param_1,int param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = DAT_018ce2f8;
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 0.0;
  param_1[5] = 0.0;
  param_1[6] = 0.0;
  param_1[7] = 0.0;
  param_1[8] = 0.0;
  param_1[9] = 0.0;
  param_1[10] = 0.0;
  param_1[0xb] = 0.0;
  param_1[0xc] = 0.0;
  param_1[0xd] = 0.0;
  param_1[0xe] = 0.0;
  param_1[0xf] = 0.0;
  param_1[0x10] = 0.0;
  param_1[0x11] = 0.0;
  param_1[0x12] = 0.0;
  param_1[0x13] = 0.0;
  param_1[0x14] = 0.0;
  param_1[0x15] = 0.0;
  param_1[0x16] = 0.0;
  param_1[0x17] = 0.0;
  param_1[0x18] = 0.0;
  param_1[0x19] = 0.0;
  param_1[0x1a] = 0.0;
  param_1[0x1b] = 0.0;
  param_1[0x1c] = 0.0;
  param_1[0x1d] = 0.0;
  param_1[0x1e] = 0.0;
  param_1[0x1f] = 0.0;
  fVar3 = (float)((double)*(int *)(param_2 + 0x28) +
                 (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 0x28) >> 0x1f)]);
  fVar2 = (float)((double)*(int *)(param_2 + 0x2c) +
                 (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 0x2c) >> 0x1f)]);
  *param_1 = fVar3;
  param_1[1] = fVar2;
  param_1[2] = fVar1 / fVar3;
  param_1[3] = fVar1 / fVar2;
  return param_1;
}



/* FUNCTION 12618 ; VA 0x00829e70 ; FUN_00829e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00829e70(int *param_1,int param_2,undefined4 param_3,uint *param_4,int param_5)

{
  int iVar1;
  uint3 uVar2;
  undefined *puVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  double dVar7;
  undefined8 uVar8;
  undefined4 uVar9;
  char *pcVar10;
  float fStack_100;
  float fStack_fc;
  float fStack_f8;
  float fStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  uint uStack_c0;
  uint uStack_bc;
  undefined4 uStack_b8;
  uint uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  uint uStack_90;
  float fStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b6c70;
  pvStack_1c = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_1c;
  puVar3 = &stack0xfffffffc;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb40a8) {
    ExceptionList = &pvStack_1c;
    FUN_016f3809(&DAT_01eb40a8);
    puVar3 = puStack_20;
    if (DAT_01eb40a8 == -1) {
      uStack_14 = 0;
      uVar8 = FUN_0152dab0("Render","ColorCorrection",0xffffffff);
      DAT_01eb40a4 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01eb40a0 = (undefined4)uVar8;
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb40a8);
      puVar3 = puStack_20;
    }
  }
  puStack_20 = puVar3;
  uStack_60 = DAT_01eb40a0;
  uStack_80 = DAT_01eb40a0;
  uStack_5c = DAT_01eb40a4;
  uStack_7c = DAT_01eb40a4;
  uStack_78 = FUN_0152d930(DAT_01eb40a0,DAT_01eb40a4);
  uStack_14 = 1;
  if (*(int *)(iVar1 + 0x34) < DAT_01eb40b8) {
    FUN_016f3809(&DAT_01eb40b8);
    if (DAT_01eb40b8 == -1) {
      uStack_14._0_1_ = 2;
      uVar8 = FUN_0152dab0(&DAT_018fb928,"ColorCorrection",0xffffffff);
      DAT_01eb40b4 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01eb40b0 = (undefined4)uVar8;
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      FUN_016f37bf(&DAT_01eb40b8);
    }
  }
  uStack_58 = DAT_01eb40b0;
  uStack_70 = DAT_01eb40b0;
  uStack_54 = DAT_01eb40b4;
  uStack_6c = DAT_01eb40b4;
  uStack_68 = FUN_0152d930(DAT_01eb40b0,DAT_01eb40b4);
  uStack_14._0_1_ = 3;
  uStack_34 = *param_4 & 0xffffff01;
  uStack_50 = *param_4 >> 1 & 0xffffff01;
  uStack_3c = 0;
  uStack_38 = 0xf;
  apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
  FUN_005542c0("ImageProcess",0xc);
  uStack_14 = CONCAT31(uStack_14._1_3_,4);
  if ((char)uStack_34 != '\0') {
    FUN_00551620("Alpha");
  }
  if ((char)uStack_50 != '\0') {
    FUN_00551620("LQNeon");
  }
  if ((param_4[0x12] != 0) && (0.0 < (float)param_4[0x14])) {
    FUN_00551620(&DAT_01918994);
  }
  if (param_4[0x1a] == 0) {
    if (param_4[0x15] == 0) goto LAB_00829fed;
    if (DAT_018ce2f8 < (float)param_4[0x14] || DAT_018ce2f8 == (float)param_4[0x14]) {
      if (param_4[0x15] == 0) goto LAB_00829fed;
      goto LAB_00829fda;
    }
    pcVar10 = "Bloom";
  }
  else {
LAB_00829fda:
    if (DAT_018ce2f8 < (float)param_4[0x14] || DAT_018ce2f8 == (float)param_4[0x14])
    goto LAB_00829fed;
    pcVar10 = "FXComposition";
  }
  FUN_00551620(pcVar10);
LAB_00829fed:
  if ((*(byte *)(param_4 + 0x1c) != 0) && ((param_4[0x1a] != 0 || (param_4[0x15] != 0)))) {
    FUN_00551620(&DAT_018fd75c);
  }
  FUN_00551620(&DAT_018fd764);
  uStack_34 = *(undefined4 *)(*(int *)(param_2 + 0x4ec) + 0x3c);
  uStack_9c = 0;
  uStack_98 = 0;
  uStack_94 = 0;
  fStack_fc = (float)((double)*(int *)(param_5 + 0x2c) +
                     (double)(&DAT_018c0d90)[-(*(int *)(param_5 + 0x2c) >> 0x1f)]);
  fStack_100 = (float)((double)*(int *)(param_5 + 0x28) +
                      (double)(&DAT_018c0d90)[-(*(int *)(param_5 + 0x28) >> 0x1f)]);
  fStack_f8 = DAT_018ce2f8 / fStack_100;
  fStack_f4 = DAT_018ce2f8 / fStack_fc;
  if ((*(byte *)param_4 & 4) == 0) {
    uStack_f0 = _DAT_018e3fb0;
    uStack_ec = _UNK_018e3fb4;
    uStack_e8 = _UNK_018e3fb8;
    uStack_e4 = _UNK_018e3fbc;
    uStack_e0 = _DAT_019189f0;
    uStack_dc = _UNK_019189f4;
    uStack_d8 = _UNK_019189f8;
    uStack_d4 = _UNK_019189fc;
    uStack_d0 = _DAT_018e3fc0;
    uStack_cc = _UNK_018e3fc4;
    uStack_c8 = _UNK_018e3fc8;
    uStack_c4 = _UNK_018e3fcc;
  }
  else {
    puVar4 = (undefined4 *)FUN_01165f10(0);
    uStack_f0 = *puVar4;
    uStack_ec = puVar4[1];
    uStack_e8 = puVar4[2];
    uStack_e4 = puVar4[3];
    puVar4 = (undefined4 *)FUN_01165f10(1);
    uStack_e0 = *puVar4;
    uStack_dc = puVar4[1];
    uStack_d8 = puVar4[2];
    uStack_d4 = puVar4[3];
    puVar4 = (undefined4 *)FUN_01165f10(2);
    uStack_d0 = *puVar4;
    uStack_cc = puVar4[1];
    uStack_c8 = puVar4[2];
    uStack_c4 = puVar4[3];
  }
  uStack_c0 = param_4[0x14];
  uStack_b4 = param_4[0x11];
  uStack_28 = 0;
  uStack_bc = param_4[0x17];
  uStack_b8 = 0;
  if (param_4[0x1d] == 2) {
    uStack_a0 = 0x400b851f;
    uStack_b0 = _DAT_01918a00;
    uStack_ac = _UNK_01918a04;
    uStack_a8 = _UNK_01918a08;
    uStack_a4 = _UNK_01918a0c;
  }
  else {
    uStack_a0 = 0x3f800000;
    uStack_b0 = _DAT_01918a10;
    uStack_ac = _UNK_01918a14;
    uStack_a8 = _UNK_01918a18;
    uStack_a4 = _UNK_01918a1c;
  }
  dVar7 = (double)((float)param_4[0x18] * DAT_018e1340);
  uStack_30 = uStack_c0;
  uStack_2c = uStack_bc;
  uStack_24 = uStack_b4;
  FUN_017267a0();
  fStack_8c = (float)dVar7;
  uStack_90 = param_4[0x19];
  uStack_88 = 0;
  uStack_84 = 0;
  uStack_2c._2_2_ = (undefined2)((uint)fStack_8c >> 0x10);
  if ((param_4[0x12] == 0) || ((float)param_4[0x14] < DAT_018ce2f8)) {
    uStack_2c._0_2_ = 0x101;
  }
  else {
    uStack_2c._0_2_ = 0x100;
    param_3 = uStack_34;
  }
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_30 = uStack_90;
  (**(code **)(*param_1 + 0x34))(0,param_3,&uStack_2c);
  if ((undefined4 *)param_4[0x12] != (undefined4 *)0x0) {
    uStack_2c._0_2_ = 0x101;
    uStack_28 = 0;
    uStack_24 = uStack_24 & 0xffff0000;
    (**(code **)(*param_1 + 0x34))(1,*(undefined4 *)param_4[0x12],&uStack_2c);
  }
  uStack_28 = 0;
  uStack_24 = uStack_24 & 0xffff0000;
  if ((undefined4 *)param_4[0x1a] == (undefined4 *)0x0) {
    uStack_2c._0_2_ = 0x100;
    uVar9 = uStack_34;
  }
  else {
    uStack_2c._0_2_ = 0x101;
    uVar9 = *(undefined4 *)param_4[0x1a];
  }
  (**(code **)(*param_1 + 0x34))(2,uVar9,&uStack_2c);
  uStack_28 = 0;
  uStack_24 = uStack_24 & 0xffff0000;
  if ((undefined4 *)param_4[0x15] == (undefined4 *)0x0) {
    uStack_2c = CONCAT22(uStack_2c._2_2_,0x100);
    uVar9 = uStack_34;
  }
  else {
    uStack_2c = CONCAT22(uStack_2c._2_2_,0x101);
    uVar9 = *(undefined4 *)param_4[0x15];
  }
  (**(code **)(*param_1 + 0x34))(3,uVar9,&uStack_2c);
  uVar2 = (uint3)uStack_34;
  uStack_34 = (uint)(uVar2 & 0xff);
  uStack_28 = 0x1000100;
  ppppuVar5 = apppuStack_4c;
  if (0xf < uStack_38) {
    ppppuVar5 = (undefined4 ****)apppuStack_4c[0];
  }
  uStack_2c = 0xf;
  uStack_24 = uStack_24 & 0xffffff00;
  FUN_0082a430(param_1,param_2,"PassThroughVS",ppppuVar5,&fStack_100,&uStack_2c,(int)&uStack_34 + 1)
  ;
  uStack_14._0_1_ = 3;
  if (0xf < uStack_38) {
    uVar6 = uStack_38 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar6 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  uStack_3c = 0;
  uStack_38 = 0xf;
  apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
  uStack_14 = CONCAT31(uStack_14._1_3_,5);
  FUN_0152dda0(uStack_58,uStack_54,uStack_68);
  uStack_14 = 6;
  FUN_0152dda0(uStack_60,uStack_5c,uStack_78);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12619 ; VA 0x0082a430 ; FUN_0082a430 */

int FUN_0082a430(int *param_1,int param_2,char *param_3,char *param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  char *pcVar6;
  char *pcStack_20;
  uint uStack_1c;
  char *pcStack_18;
  uint uStack_14;
  int iStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = *(undefined4 *)(param_2 + 0x4f4);
  if (param_4 == (char *)0x0) {
    uStack_14 = 0;
  }
  else {
    pcVar6 = param_4;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    uStack_14 = (int)pcVar6 - (int)(param_4 + 1);
  }
  if (param_3 == (char *)0x0) {
    uStack_1c = 0;
  }
  else {
    pcVar6 = param_3;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    uStack_1c = (int)pcVar6 - (int)(param_3 + 1);
  }
  pcStack_20 = param_3;
  pcStack_18 = param_4;
  iVar5 = FUN_00790e00(&iStack_10,&pcStack_20,2);
  if (piStack_c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piStack_c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (iStack_10 != 0) {
    uStack_1c = uStack_1c & 0xffff0000;
    pcStack_18 = (char *)0x0;
    uStack_14 = uStack_14 & 0xffffff00;
    (**(code **)(*param_1 + 0x3c))(&uStack_1c,param_6,param_7);
    (**(code **)(*param_1 + 0x24))(iStack_10);
    (**(code **)(*param_1 + 0x30))(1,param_5,0x80);
    puVar4 = *(undefined4 **)(*(int *)(param_2 + 0x4f8) + 0x41c);
    iVar5 = (**(code **)(*param_1 + 0x40))(*puVar4,puVar4[2],puVar4[3],puVar4[4],puVar4[5],0);
  }
  return iVar5;
}



/* FUNCTION 12620 ; VA 0x0082a540 ; FUN_0082a540 */

void FUN_0082a540(int *param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6,undefined4 ****param_7,undefined4 ****param_8)

{
  char *pcVar1;
  int iVar2;
  uint3 uVar3;
  undefined4 ***pppuVar4;
  undefined uVar5;
  undefined4 ***pppuVar6;
  uint uVar7;
  undefined4 ****ppppuVar8;
  undefined4 ****ppppuVar9;
  char cVar10;
  undefined4 ****ppppuVar11;
  undefined8 uVar12;
  undefined auStack_f0 [16];
  float fStack_e0;
  float fStack_dc;
  undefined4 ***pppuStack_d8;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  undefined4 ***apppuStack_38 [4];
  undefined4 ***pppuStack_28;
  undefined4 ***pppuStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  ushort uStack_18;
  undefined4 ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6cb0;
  pvStack_10 = ExceptionList;
  iStack_40 = *(int *)(param_3 + 0x30);
  iStack_3c = *(int *)(param_3 + 0x34);
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb4088) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4088), DAT_01eb4088 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","blurRender",0xffffffff);
    DAT_01eb4084 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb4080 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb4088);
  }
  uStack_50 = DAT_01eb4080;
  uStack_70 = DAT_01eb4080;
  uStack_4c = DAT_01eb4084;
  uStack_6c = DAT_01eb4084;
  uStack_68 = FUN_0152d930(DAT_01eb4080,DAT_01eb4084);
  uStack_8 = 1;
  if (*(int *)(iVar2 + 0x34) < DAT_01eb4098) {
    FUN_016f3809(&DAT_01eb4098);
    if (DAT_01eb4098 == -1) {
      uStack_8._0_1_ = 2;
      uVar12 = FUN_0152dab0(&DAT_018fb928,"blurRender",0xffffffff);
      DAT_01eb4094 = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb4090 = (undefined4)uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb4098);
    }
  }
  uStack_48 = DAT_01eb4090;
  uStack_60 = DAT_01eb4090;
  uStack_44 = DAT_01eb4094;
  uStack_5c = DAT_01eb4094;
  uStack_58 = FUN_0152d930(DAT_01eb4090,DAT_01eb4094);
  uVar7 = 0;
  ppppuVar11 = param_7;
  if ((float)param_8 <= (float)param_7) {
    ppppuVar11 = param_8;
  }
  uStack_8._0_1_ = 3;
  pppuStack_14 = (undefined4 ***)0x7050301;
  do {
    cVar10 = *(char *)((int)&pppuStack_14 + uVar7);
    if ((float)ppppuVar11 <= (float)(int)cVar10) break;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 4);
  pppuStack_28 = (undefined4 ****)0x0;
  pppuStack_24 = (undefined4 ***)&DAT_0000000f;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  FUN_005542c0(&DAT_01918994,4);
  pppuVar4 = pppuStack_28;
  cVar10 = cVar10 + '0';
  uStack_8._0_1_ = 4;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  pppuStack_14 = pppuStack_24;
  if (pppuStack_28 < pppuStack_24) {
    ppppuVar11 = apppuStack_38;
    if (&DAT_0000000f < pppuStack_24) {
      ppppuVar11 = (undefined4 ****)apppuStack_38[0];
    }
    pcVar1 = (char *)((int)ppppuVar11 + (int)pppuStack_28);
    pppuStack_28 = (undefined4 ****)((int)pppuStack_28 + 1);
    *pcVar1 = cVar10;
    ((undefined *)((int)ppppuVar11 + 1))[(int)pppuVar4] = 0;
  }
  else {
    if ((undefined4 ****)pppuStack_28 == (undefined4 ****)0x7fffffff) {
      uStack_8._0_1_ = uVar5;
      FUN_00554040();
      goto LAB_0082aa31;
    }
    param_8 = (undefined4 ****)((uint)((int)pppuStack_28 + 1) | 0xf);
    if (param_8 < &DAT_80000000) {
      if ((undefined4 ****)(0x7fffffff - ((uint)pppuStack_24 >> 1)) < pppuStack_24) {
        param_8 = (undefined4 ****)0x7fffffff;
      }
      else {
        ppppuVar11 = (undefined4 ****)(((uint)pppuStack_24 >> 1) + (int)pppuStack_24);
        if (param_8 < ppppuVar11) {
          param_8 = ppppuVar11;
        }
      }
    }
    else {
      param_8 = (undefined4 ****)0x7fffffff;
    }
    ppppuVar11 = (undefined4 ****)((int)param_8 + 1);
    if (ppppuVar11 < &DAT_00001000) {
      if (ppppuVar11 == (undefined4 ****)0x0) {
        ppppuVar11 = (undefined4 ****)0x0;
      }
      else {
        ppppuVar11 = (undefined4 ****)FUN_01674e20(ppppuVar11);
      }
    }
    else {
      ppppuVar9 = param_8 + 9;
      if (ppppuVar9 <= ppppuVar11) {
        ppppuVar9 = (undefined4 ****)0xffffffff;
      }
      pppuVar6 = (undefined4 ***)FUN_01674e20(ppppuVar9);
      if (pppuVar6 == (undefined4 ***)0x0) goto LAB_0082aa31;
      ppppuVar11 = (undefined4 ****)((int)pppuVar6 + 0x23U & 0xffffffe0);
      ppppuVar11[-1] = pppuVar6;
    }
    pppuStack_28 = (undefined4 ***)((int)pppuVar4 + 1);
    pppuStack_24 = param_8;
    if (pppuStack_14 < &DAT_00000010) {
      FUN_0170c6f0(ppppuVar11,apppuStack_38,pppuVar4);
      *(char *)((int)pppuVar4 + (int)ppppuVar11) = cVar10;
      ((undefined *)((int)pppuVar4 + 1))[(int)ppppuVar11] = 0;
      apppuStack_38[0] = ppppuVar11;
    }
    else {
      param_8 = (undefined4 ****)apppuStack_38[0];
      FUN_0170c6f0(ppppuVar11,apppuStack_38[0],pppuVar4);
      ppppuVar8 = (undefined4 ****)((int)pppuStack_14 + 1);
      *(char *)((int)pppuVar4 + (int)ppppuVar11) = cVar10;
      ((undefined *)((int)pppuVar4 + 1))[(int)ppppuVar11] = 0;
      ppppuVar9 = param_8;
      if ((undefined4 ****)0xfff < ppppuVar8) {
        ppppuVar9 = (undefined4 ****)param_8[-1];
        ppppuVar8 = (undefined4 ****)(pppuStack_14 + 9);
        if ((undefined *)0x1f < (undefined *)((int)param_8 + (-4 - (int)ppppuVar9)))
        goto LAB_0082aa31;
      }
      FUN_01674ea0(ppppuVar9,ppppuVar8);
      apppuStack_38[0] = ppppuVar11;
    }
  }
  FUN_00551620(&DAT_018fd764);
  iVar2 = iStack_40;
  FUN_00829a50(iStack_40,iStack_3c);
  fStack_e0 = DAT_018ce2f8 / (float)iVar2;
  pppuStack_d8 = param_7;
  (**(code **)(*param_1 + 0x14))(param_6,0,1,0,0);
  uStack_20 = CONCAT22(uStack_20._2_2_,0x101);
  uStack_1c = 0;
  uStack_18 = 0;
  (**(code **)(*param_1 + 0x34))(0,param_3,&uStack_20);
  ppppuVar11 = apppuStack_38;
  if (&DAT_0000000f < pppuStack_24) {
    ppppuVar11 = (undefined4 ****)apppuStack_38[0];
  }
  uVar3 = (uint3)param_3;
  param_3 = (uint)(uVar3 & 0xff);
  uStack_1c = 0x1000100;
  uStack_20 = 0xf;
  uStack_18 = uStack_18 & 0xff00;
  FUN_0082a430(param_1,param_2,"PassThroughVS",ppppuVar11,auStack_f0,&uStack_20,(int)&param_3 + 1);
  (**(code **)(*param_1 + 0x18))();
  FUN_00829a50(iVar2,iStack_3c);
  fStack_dc = DAT_018ce2f8 / (float)iStack_3c;
  pppuStack_d8 = param_7;
  (**(code **)(*param_1 + 0x14))(param_4,0,1,0,0);
  uStack_20 = CONCAT22(uStack_20._2_2_,0x101);
  uStack_1c = 0;
  uStack_18 = 0;
  (**(code **)(*param_1 + 0x34))(0,param_5,&uStack_20);
  uVar3 = (uint3)param_7;
  param_7 = (undefined4 ****)(uint)(uVar3 & 0xff);
  uStack_1c = 0x1000100;
  ppppuVar11 = apppuStack_38;
  if (&DAT_0000000f < pppuStack_24) {
    ppppuVar11 = (undefined4 ****)apppuStack_38[0];
  }
  uStack_20 = 0xf;
  uStack_18 = uStack_18 & 0xff00;
  FUN_0082a430(param_1,param_2,"PassThroughVS",ppppuVar11,auStack_f0,&uStack_20,(int)&param_7 + 1);
  (**(code **)(*param_1 + 0x18))();
  uStack_8._0_1_ = 3;
  if (&DAT_0000000f < pppuStack_24) {
    ppppuVar9 = (undefined4 ****)((int)pppuStack_24 + 1);
    ppppuVar11 = (undefined4 ****)apppuStack_38[0];
    if ((undefined4 ****)0xfff < ppppuVar9) {
      ppppuVar11 = (undefined4 ****)apppuStack_38[0][-1];
      ppppuVar9 = (undefined4 ****)(pppuStack_24 + 9);
      if ((undefined *)0x1f < (undefined *)((int)apppuStack_38[0] + (-4 - (int)ppppuVar11))) {
LAB_0082aa31:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar11,ppppuVar9);
  }
  pppuStack_28 = (undefined4 ***)0x0;
  pppuStack_24 = (undefined4 ***)0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0152dda0(uStack_48,uStack_44,uStack_58);
  uStack_8 = 6;
  FUN_0152dda0(uStack_50,uStack_4c,uStack_68);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12621 ; VA 0x0082aa40 ; FUN_0082aa40 */

int __thiscall FUN_0082aa40(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  iVar7 = *param_1;
  iVar6 = (param_1[1] - *param_1) / 0x38;
  if (iVar6 == 0x4924924) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar6 + 1;
  uVar2 = (param_1[2] - *param_1) / 0x38;
  uVar9 = uVar8;
  if ((uVar2 <= 0x4924924 - (uVar2 >> 1)) && (uVar9 = (uVar2 >> 1) + uVar2, uVar9 < uVar8)) {
    uVar9 = uVar8;
  }
  iVar6 = FUN_0082c100(uVar9);
  iVar7 = ((param_2 - iVar7) / 0x38) * 0x38;
  puVar1 = (undefined4 *)(iVar7 + iVar6);
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  uVar3 = param_3[5];
  uVar4 = param_3[6];
  uVar5 = param_3[7];
  puVar1[4] = param_3[4];
  puVar1[5] = uVar3;
  puVar1[6] = uVar4;
  puVar1[7] = uVar5;
  uVar3 = param_3[9];
  uVar4 = param_3[10];
  uVar5 = param_3[0xb];
  puVar1[8] = param_3[8];
  puVar1[9] = uVar3;
  puVar1[10] = uVar4;
  puVar1[0xb] = uVar5;
  *(undefined8 *)(puVar1 + 0xc) = *(undefined8 *)(param_3 + 0xc);
  if (param_2 == param_1[1]) {
    FUN_0082c0b0(*param_1,param_1[1],iVar6);
  }
  else {
    FUN_0082c070(*param_1,param_2,iVar6);
    FUN_0082c070(param_2,param_1[1],puVar1 + 0xe);
  }
  FUN_0082bf90(iVar6,uVar8,uVar9);
  return *param_1 + iVar7;
}



/* FUNCTION 12622 ; VA 0x0082ab60 ; FUN_0082ab60 */

int FUN_0082ab60(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  undefined8 uVar5;
  uint uVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  int iVar22;
  int iVar23;
  int iVar24;
  int iVar25;
  int iVar26;
  
  iVar24 = (param_2 - param_1) * -0x6db6db6d;
  uVar6 = (param_2 - param_1) / 0x38;
  iVar26 = (int)uVar6 >> 1;
  if (0 < iVar26) {
    iVar22 = (int)(uVar6 - 1) >> 1;
    iVar23 = param_1 + iVar26 * 0x38;
    do {
      fVar7 = *(float *)(iVar23 + -0x38);
      fVar8 = *(float *)(iVar23 + -0x34);
      fVar9 = *(float *)(iVar23 + -0x30);
      fVar10 = *(float *)(iVar23 + -0x2c);
      iVar24 = iVar23 + -0x38;
      iVar26 = iVar26 + -1;
      uVar11 = *(undefined4 *)(iVar23 + -0x28);
      uVar12 = *(undefined4 *)(iVar23 + -0x24);
      uVar13 = *(undefined4 *)(iVar23 + -0x20);
      uVar14 = *(undefined4 *)(iVar23 + -0x1c);
      uVar15 = *(undefined4 *)(iVar23 + -0x18);
      uVar16 = *(undefined4 *)(iVar23 + -0x14);
      uVar17 = *(undefined4 *)(iVar23 + -0x10);
      uVar18 = *(undefined4 *)(iVar23 + -0xc);
      uVar5 = *(undefined8 *)(iVar23 + -8);
      iVar23 = iVar26;
      while (iVar23 < iVar22) {
        fVar4 = *(float *)(param_1 + 0x70 + iVar23 * 0x70);
        pfVar3 = (float *)(param_1 + 0x38 + iVar23 * 0x70);
        iVar25 = iVar23 * 2 + ((*pfVar3 <= fVar4 && fVar4 != *pfVar3) ^ 1) + 1;
        puVar1 = (undefined4 *)(param_1 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x10 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x10 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x20 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x20 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x30 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        puVar2 = (undefined4 *)(param_1 + 0x30 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        iVar23 = iVar25;
      }
      if ((iVar23 == iVar22) && ((uVar6 & 1) == 0)) {
        puVar2 = (undefined4 *)(param_1 + -0x38 + uVar6 * 0x38);
        uVar19 = puVar2[1];
        uVar20 = puVar2[2];
        uVar21 = puVar2[3];
        puVar1 = (undefined4 *)(param_1 + iVar23 * 0x38);
        *puVar1 = *puVar2;
        puVar1[1] = uVar19;
        puVar1[2] = uVar20;
        puVar1[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + -0x28 + uVar6 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x10 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + -0x18 + uVar6 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x20 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + -8 + uVar6 * 0x38);
        uVar19 = puVar1[1];
        puVar2 = (undefined4 *)(param_1 + 0x30 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        iVar23 = uVar6 - 1;
      }
      while ((iVar26 < iVar23 &&
             (iVar25 = iVar23 + -1 >> 1, fVar7 < *(float *)(param_1 + iVar25 * 0x38)))) {
        puVar1 = (undefined4 *)(param_1 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x10 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x10 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x20 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        uVar20 = puVar1[2];
        uVar21 = puVar1[3];
        puVar2 = (undefined4 *)(param_1 + 0x20 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        puVar2[2] = uVar20;
        puVar2[3] = uVar21;
        puVar1 = (undefined4 *)(param_1 + 0x30 + iVar25 * 0x38);
        uVar19 = puVar1[1];
        puVar2 = (undefined4 *)(param_1 + 0x30 + iVar23 * 0x38);
        *puVar2 = *puVar1;
        puVar2[1] = uVar19;
        iVar23 = iVar25;
      }
      pfVar3 = (float *)(param_1 + iVar23 * 0x38);
      *pfVar3 = fVar7;
      pfVar3[1] = fVar8;
      pfVar3[2] = fVar9;
      pfVar3[3] = fVar10;
      puVar1 = (undefined4 *)(param_1 + 0x10 + iVar23 * 0x38);
      *puVar1 = uVar11;
      puVar1[1] = uVar12;
      puVar1[2] = uVar13;
      puVar1[3] = uVar14;
      puVar1 = (undefined4 *)(param_1 + 0x20 + iVar23 * 0x38);
      *puVar1 = uVar15;
      puVar1[1] = uVar16;
      puVar1[2] = uVar17;
      puVar1[3] = uVar18;
      *(undefined8 *)(param_1 + 0x30 + iVar23 * 0x38) = uVar5;
      iVar23 = iVar24;
    } while (0 < iVar26);
  }
  return iVar24;
}



/* FUNCTION 12623 ; VA 0x0082ad20 ; FUN_0082ad20 */

void FUN_0082ad20(float *param_1,float *param_2,float *param_3)

{
  undefined8 uVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  
  fVar16 = *param_2;
  if (*param_1 <= fVar16 && fVar16 != *param_1) {
    fVar16 = param_1[1];
    fVar2 = param_1[2];
    fVar3 = param_1[3];
    fVar4 = *param_2;
    fVar5 = param_2[1];
    fVar6 = param_2[2];
    fVar7 = param_2[3];
    fVar8 = param_2[4];
    fVar9 = param_2[5];
    fVar10 = param_2[6];
    fVar11 = param_2[7];
    fVar12 = param_2[8];
    fVar13 = param_2[9];
    fVar14 = param_2[10];
    fVar15 = param_2[0xb];
    uVar1 = *(undefined8 *)(param_2 + 0xc);
    *param_2 = *param_1;
    param_2[1] = fVar16;
    param_2[2] = fVar2;
    param_2[3] = fVar3;
    fVar16 = param_1[5];
    fVar2 = param_1[6];
    fVar3 = param_1[7];
    param_2[4] = param_1[4];
    param_2[5] = fVar16;
    param_2[6] = fVar2;
    param_2[7] = fVar3;
    fVar16 = param_1[9];
    fVar2 = param_1[10];
    fVar3 = param_1[0xb];
    param_2[8] = param_1[8];
    param_2[9] = fVar16;
    param_2[10] = fVar2;
    param_2[0xb] = fVar3;
    *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_1 + 0xc);
    *param_1 = fVar4;
    param_1[1] = fVar5;
    param_1[2] = fVar6;
    param_1[3] = fVar7;
    param_1[4] = fVar8;
    param_1[5] = fVar9;
    param_1[6] = fVar10;
    param_1[7] = fVar11;
    param_1[8] = fVar12;
    param_1[9] = fVar13;
    param_1[10] = fVar14;
    param_1[0xb] = fVar15;
    *(undefined8 *)(param_1 + 0xc) = uVar1;
    fVar16 = *param_2;
  }
  if (fVar16 < *param_3) {
    fVar16 = param_2[1];
    fVar2 = param_2[2];
    fVar3 = param_2[3];
    fVar4 = *param_3;
    fVar5 = param_3[1];
    fVar6 = param_3[2];
    fVar7 = param_3[3];
    fVar8 = param_3[4];
    fVar9 = param_3[5];
    fVar10 = param_3[6];
    fVar11 = param_3[7];
    fVar12 = param_3[8];
    fVar13 = param_3[9];
    fVar14 = param_3[10];
    fVar15 = param_3[0xb];
    uVar1 = *(undefined8 *)(param_3 + 0xc);
    *param_3 = *param_2;
    param_3[1] = fVar16;
    param_3[2] = fVar2;
    param_3[3] = fVar3;
    fVar16 = param_2[5];
    fVar2 = param_2[6];
    fVar3 = param_2[7];
    param_3[4] = param_2[4];
    param_3[5] = fVar16;
    param_3[6] = fVar2;
    param_3[7] = fVar3;
    fVar16 = param_2[9];
    fVar2 = param_2[10];
    fVar3 = param_2[0xb];
    param_3[8] = param_2[8];
    param_3[9] = fVar16;
    param_3[10] = fVar2;
    param_3[0xb] = fVar3;
    *(undefined8 *)(param_3 + 0xc) = *(undefined8 *)(param_2 + 0xc);
    *param_2 = fVar4;
    param_2[1] = fVar5;
    param_2[2] = fVar6;
    param_2[3] = fVar7;
    param_2[4] = fVar8;
    param_2[5] = fVar9;
    param_2[6] = fVar10;
    param_2[7] = fVar11;
    param_2[8] = fVar12;
    param_2[9] = fVar13;
    param_2[10] = fVar14;
    param_2[0xb] = fVar15;
    *(undefined8 *)(param_2 + 0xc) = uVar1;
    if (*param_1 <= *param_2 && *param_2 != *param_1) {
      fVar16 = param_1[1];
      fVar2 = param_1[2];
      fVar3 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = fVar16;
      param_2[2] = fVar2;
      param_2[3] = fVar3;
      fVar16 = param_1[5];
      fVar2 = param_1[6];
      fVar3 = param_1[7];
      param_2[4] = param_1[4];
      param_2[5] = fVar16;
      param_2[6] = fVar2;
      param_2[7] = fVar3;
      fVar16 = param_1[9];
      fVar2 = param_1[10];
      fVar3 = param_1[0xb];
      param_2[8] = param_1[8];
      param_2[9] = fVar16;
      param_2[10] = fVar2;
      param_2[0xb] = fVar3;
      *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_1 + 0xc);
      *param_1 = fVar4;
      param_1[1] = fVar5;
      param_1[2] = fVar6;
      param_1[3] = fVar7;
      param_1[4] = fVar8;
      param_1[5] = fVar9;
      param_1[6] = fVar10;
      param_1[7] = fVar11;
      param_1[8] = fVar12;
      param_1[9] = fVar13;
      param_1[10] = fVar14;
      param_1[0xb] = fVar15;
      *(undefined8 *)(param_1 + 0xc) = uVar1;
    }
  }
  return;
}



/* FUNCTION 12624 ; VA 0x0082ae00 ; FUN_0082ae00 */

void FUN_0082ae00(undefined4 *param_1,float *param_2,float *param_3,undefined4 param_4)

{
  undefined8 uVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float *pfVar17;
  int iVar18;
  float *pfVar19;
  float *pfVar20;
  float *pfVar21;
  float *pfVar22;
  float *pfVar23;
  float *pfVar24;
  
  pfVar19 = param_3 + -0xe;
  pfVar24 = param_2 + (((int)param_3 - (int)param_2) / 0x38 >> 1) * 0xe;
  iVar18 = ((int)pfVar19 - (int)param_2) / 0x38;
  if (iVar18 < 0x29) {
    FUN_0082ad20(param_2,pfVar24,param_3 + -0xe,param_4);
  }
  else {
    iVar18 = iVar18 + 1 >> 3;
    FUN_0082ad20(param_2,param_2 + iVar18 * 0xe,param_2 + iVar18 * 0x1c,param_4);
    FUN_0082ad20(pfVar24 + iVar18 * -0xe,pfVar24,pfVar24 + iVar18 * 0xe,param_4);
    FUN_0082ad20(pfVar19 + iVar18 * -0x1c,pfVar19 + iVar18 * -0xe,pfVar19,param_4);
    FUN_0082ad20(param_2 + iVar18 * 0xe,pfVar24,pfVar19 + iVar18 * -0xe,param_4);
  }
  pfVar19 = pfVar24 + 0xe;
  for (; param_2 < pfVar24; pfVar24 = pfVar24 + -0xe) {
    if ((*pfVar24 < pfVar24[-0xe]) || (pfVar24[-0xe] < *pfVar24)) break;
  }
  pfVar20 = pfVar19;
  pfVar22 = pfVar24;
  if (pfVar19 < param_3) {
    do {
      pfVar20 = pfVar19;
      if ((*pfVar24 < *pfVar19) || (*pfVar19 < *pfVar24)) break;
      pfVar19 = pfVar19 + 0xe;
      pfVar20 = pfVar19;
    } while (pfVar19 < param_3);
  }
joined_r0x0082af42:
  do {
    pfVar17 = pfVar24;
    if (param_3 <= pfVar19) {
joined_r0x0082afa6:
      for (; param_2 < pfVar17; pfVar17 = pfVar17 + -0xe) {
        pfVar21 = pfVar24 + -0xe;
        pfVar23 = pfVar22;
        if (*pfVar21 <= *pfVar22) {
          if (*pfVar21 < *pfVar22) break;
          pfVar23 = pfVar22 + -0xe;
          if (pfVar23 != pfVar21) {
            fVar2 = pfVar24[-0xd];
            fVar3 = pfVar24[-0xc];
            fVar4 = pfVar24[-0xb];
            fVar5 = *pfVar23;
            fVar6 = pfVar22[-0xd];
            fVar7 = pfVar22[-0xc];
            fVar8 = pfVar22[-0xb];
            fVar9 = pfVar22[-10];
            fVar10 = pfVar22[-9];
            fVar11 = pfVar22[-8];
            fVar12 = pfVar22[-7];
            fVar13 = pfVar22[-6];
            fVar14 = pfVar22[-5];
            fVar15 = pfVar22[-4];
            fVar16 = pfVar22[-3];
            uVar1 = *(undefined8 *)(pfVar22 + -2);
            *pfVar23 = *pfVar21;
            pfVar22[-0xd] = fVar2;
            pfVar22[-0xc] = fVar3;
            pfVar22[-0xb] = fVar4;
            fVar2 = pfVar24[-9];
            fVar3 = pfVar24[-8];
            fVar4 = pfVar24[-7];
            pfVar22[-10] = pfVar24[-10];
            pfVar22[-9] = fVar2;
            pfVar22[-8] = fVar3;
            pfVar22[-7] = fVar4;
            fVar2 = pfVar24[-5];
            fVar3 = pfVar24[-4];
            fVar4 = pfVar24[-3];
            pfVar22[-6] = pfVar24[-6];
            pfVar22[-5] = fVar2;
            pfVar22[-4] = fVar3;
            pfVar22[-3] = fVar4;
            *(undefined8 *)(pfVar22 + -2) = *(undefined8 *)(pfVar24 + -2);
            *pfVar21 = fVar5;
            pfVar24[-0xd] = fVar6;
            pfVar24[-0xc] = fVar7;
            pfVar24[-0xb] = fVar8;
            pfVar24[-10] = fVar9;
            pfVar24[-9] = fVar10;
            pfVar24[-8] = fVar11;
            pfVar24[-7] = fVar12;
            pfVar24[-6] = fVar13;
            pfVar24[-5] = fVar14;
            pfVar24[-4] = fVar15;
            pfVar24[-3] = fVar16;
            *(undefined8 *)(pfVar24 + -2) = uVar1;
          }
        }
        pfVar24 = pfVar21;
        pfVar22 = pfVar23;
      }
      if (pfVar17 == param_2) {
        if (pfVar19 == param_3) {
          *param_1 = pfVar22;
          param_1[1] = pfVar20;
          return;
        }
        if (pfVar20 != pfVar19) {
          fVar2 = pfVar20[1];
          fVar3 = pfVar20[2];
          fVar4 = pfVar20[3];
          fVar5 = *pfVar22;
          fVar6 = pfVar22[1];
          fVar7 = pfVar22[2];
          fVar8 = pfVar22[3];
          fVar9 = pfVar22[4];
          fVar10 = pfVar22[5];
          fVar11 = pfVar22[6];
          fVar12 = pfVar22[7];
          fVar13 = pfVar22[8];
          fVar14 = pfVar22[9];
          fVar15 = pfVar22[10];
          fVar16 = pfVar22[0xb];
          uVar1 = *(undefined8 *)(pfVar22 + 0xc);
          *pfVar22 = *pfVar20;
          pfVar22[1] = fVar2;
          pfVar22[2] = fVar3;
          pfVar22[3] = fVar4;
          fVar2 = pfVar20[5];
          fVar3 = pfVar20[6];
          fVar4 = pfVar20[7];
          pfVar22[4] = pfVar20[4];
          pfVar22[5] = fVar2;
          pfVar22[6] = fVar3;
          pfVar22[7] = fVar4;
          fVar2 = pfVar20[9];
          fVar3 = pfVar20[10];
          fVar4 = pfVar20[0xb];
          pfVar22[8] = pfVar20[8];
          pfVar22[9] = fVar2;
          pfVar22[10] = fVar3;
          pfVar22[0xb] = fVar4;
          *(undefined8 *)(pfVar22 + 0xc) = *(undefined8 *)(pfVar20 + 0xc);
          *pfVar20 = fVar5;
          pfVar20[1] = fVar6;
          pfVar20[2] = fVar7;
          pfVar20[3] = fVar8;
          pfVar20[4] = fVar9;
          pfVar20[5] = fVar10;
          pfVar20[6] = fVar11;
          pfVar20[7] = fVar12;
          pfVar20[8] = fVar13;
          pfVar20[9] = fVar14;
          pfVar20[10] = fVar15;
          pfVar20[0xb] = fVar16;
          *(undefined8 *)(pfVar20 + 0xc) = uVar1;
        }
        fVar2 = pfVar19[1];
        fVar3 = pfVar19[2];
        fVar4 = pfVar19[3];
        fVar5 = *pfVar22;
        fVar6 = pfVar22[1];
        fVar7 = pfVar22[2];
        fVar8 = pfVar22[3];
        fVar9 = pfVar22[4];
        fVar10 = pfVar22[5];
        fVar11 = pfVar22[6];
        fVar12 = pfVar22[7];
        fVar13 = pfVar22[8];
        fVar14 = pfVar22[9];
        fVar15 = pfVar22[10];
        fVar16 = pfVar22[0xb];
        uVar1 = *(undefined8 *)(pfVar22 + 0xc);
        *pfVar22 = *pfVar19;
        pfVar22[1] = fVar2;
        pfVar22[2] = fVar3;
        pfVar22[3] = fVar4;
        fVar2 = pfVar19[5];
        fVar3 = pfVar19[6];
        fVar4 = pfVar19[7];
        pfVar22[4] = pfVar19[4];
        pfVar22[5] = fVar2;
        pfVar22[6] = fVar3;
        pfVar22[7] = fVar4;
        fVar2 = pfVar19[9];
        fVar3 = pfVar19[10];
        fVar4 = pfVar19[0xb];
        pfVar22[8] = pfVar19[8];
        pfVar22[9] = fVar2;
        pfVar22[10] = fVar3;
        pfVar22[0xb] = fVar4;
        *(undefined8 *)(pfVar22 + 0xc) = *(undefined8 *)(pfVar19 + 0xc);
        *pfVar19 = fVar5;
        pfVar19[1] = fVar6;
        pfVar19[2] = fVar7;
        pfVar19[3] = fVar8;
        pfVar19[4] = fVar9;
        pfVar19[5] = fVar10;
        pfVar19[6] = fVar11;
        pfVar19[7] = fVar12;
        pfVar19[8] = fVar13;
        pfVar19[9] = fVar14;
        pfVar19[10] = fVar15;
        pfVar19[0xb] = fVar16;
        *(undefined8 *)(pfVar19 + 0xc) = uVar1;
        pfVar19 = pfVar19 + 0xe;
        pfVar20 = pfVar20 + 0xe;
        pfVar24 = pfVar17;
        pfVar22 = pfVar22 + 0xe;
      }
      else {
        pfVar24 = pfVar17 + -0xe;
        if (pfVar19 == param_3) {
          pfVar23 = pfVar22 + -0xe;
          if (pfVar24 != pfVar23) {
            fVar2 = pfVar22[-0xd];
            fVar3 = pfVar22[-0xc];
            fVar4 = pfVar22[-0xb];
            fVar5 = *pfVar24;
            fVar6 = pfVar17[-0xd];
            fVar7 = pfVar17[-0xc];
            fVar8 = pfVar17[-0xb];
            fVar9 = pfVar17[-10];
            fVar10 = pfVar17[-9];
            fVar11 = pfVar17[-8];
            fVar12 = pfVar17[-7];
            fVar13 = pfVar17[-6];
            fVar14 = pfVar17[-5];
            fVar15 = pfVar17[-4];
            fVar16 = pfVar17[-3];
            uVar1 = *(undefined8 *)(pfVar17 + -2);
            *pfVar24 = *pfVar23;
            pfVar17[-0xd] = fVar2;
            pfVar17[-0xc] = fVar3;
            pfVar17[-0xb] = fVar4;
            fVar2 = pfVar22[-9];
            fVar3 = pfVar22[-8];
            fVar4 = pfVar22[-7];
            pfVar17[-10] = pfVar22[-10];
            pfVar17[-9] = fVar2;
            pfVar17[-8] = fVar3;
            pfVar17[-7] = fVar4;
            fVar2 = pfVar22[-5];
            fVar3 = pfVar22[-4];
            fVar4 = pfVar22[-3];
            pfVar17[-6] = pfVar22[-6];
            pfVar17[-5] = fVar2;
            pfVar17[-4] = fVar3;
            pfVar17[-3] = fVar4;
            *(undefined8 *)(pfVar17 + -2) = *(undefined8 *)(pfVar22 + -2);
            *pfVar23 = fVar5;
            pfVar22[-0xd] = fVar6;
            pfVar22[-0xc] = fVar7;
            pfVar22[-0xb] = fVar8;
            pfVar22[-10] = fVar9;
            pfVar22[-9] = fVar10;
            pfVar22[-8] = fVar11;
            pfVar22[-7] = fVar12;
            pfVar22[-6] = fVar13;
            pfVar22[-5] = fVar14;
            pfVar22[-4] = fVar15;
            pfVar22[-3] = fVar16;
            *(undefined8 *)(pfVar22 + -2) = uVar1;
          }
          fVar2 = pfVar20[-0xd];
          fVar3 = pfVar20[-0xc];
          fVar4 = pfVar20[-0xb];
          fVar5 = *pfVar23;
          fVar6 = pfVar22[-0xd];
          fVar7 = pfVar22[-0xc];
          fVar8 = pfVar22[-0xb];
          fVar9 = pfVar22[-10];
          fVar10 = pfVar22[-9];
          fVar11 = pfVar22[-8];
          fVar12 = pfVar22[-7];
          fVar13 = pfVar22[-6];
          fVar14 = pfVar22[-5];
          fVar15 = pfVar22[-4];
          fVar16 = pfVar22[-3];
          uVar1 = *(undefined8 *)(pfVar22 + -2);
          *pfVar23 = pfVar20[-0xe];
          pfVar22[-0xd] = fVar2;
          pfVar22[-0xc] = fVar3;
          pfVar22[-0xb] = fVar4;
          fVar2 = pfVar20[-9];
          fVar3 = pfVar20[-8];
          fVar4 = pfVar20[-7];
          pfVar22[-10] = pfVar20[-10];
          pfVar22[-9] = fVar2;
          pfVar22[-8] = fVar3;
          pfVar22[-7] = fVar4;
          fVar2 = pfVar20[-5];
          fVar3 = pfVar20[-4];
          fVar4 = pfVar20[-3];
          pfVar22[-6] = pfVar20[-6];
          pfVar22[-5] = fVar2;
          pfVar22[-4] = fVar3;
          pfVar22[-3] = fVar4;
          *(undefined8 *)(pfVar22 + -2) = *(undefined8 *)(pfVar20 + -2);
          pfVar20[-0xe] = fVar5;
          pfVar20[-0xd] = fVar6;
          pfVar20[-0xc] = fVar7;
          pfVar20[-0xb] = fVar8;
          pfVar20[-10] = fVar9;
          pfVar20[-9] = fVar10;
          pfVar20[-8] = fVar11;
          pfVar20[-7] = fVar12;
          pfVar20[-6] = fVar13;
          pfVar20[-5] = fVar14;
          pfVar20[-4] = fVar15;
          pfVar20[-3] = fVar16;
          *(undefined8 *)(pfVar20 + -2) = uVar1;
          pfVar20 = pfVar20 + -0xe;
          pfVar22 = pfVar23;
        }
        else {
          fVar2 = pfVar17[-0xd];
          fVar3 = pfVar17[-0xc];
          fVar4 = pfVar17[-0xb];
          fVar5 = *pfVar19;
          fVar6 = pfVar19[1];
          fVar7 = pfVar19[2];
          fVar8 = pfVar19[3];
          fVar9 = pfVar19[4];
          fVar10 = pfVar19[5];
          fVar11 = pfVar19[6];
          fVar12 = pfVar19[7];
          fVar13 = pfVar19[8];
          fVar14 = pfVar19[9];
          fVar15 = pfVar19[10];
          fVar16 = pfVar19[0xb];
          uVar1 = *(undefined8 *)(pfVar19 + 0xc);
          *pfVar19 = *pfVar24;
          pfVar19[1] = fVar2;
          pfVar19[2] = fVar3;
          pfVar19[3] = fVar4;
          fVar2 = pfVar17[-9];
          fVar3 = pfVar17[-8];
          fVar4 = pfVar17[-7];
          pfVar19[4] = pfVar17[-10];
          pfVar19[5] = fVar2;
          pfVar19[6] = fVar3;
          pfVar19[7] = fVar4;
          fVar2 = pfVar17[-5];
          fVar3 = pfVar17[-4];
          fVar4 = pfVar17[-3];
          pfVar19[8] = pfVar17[-6];
          pfVar19[9] = fVar2;
          pfVar19[10] = fVar3;
          pfVar19[0xb] = fVar4;
          *(undefined8 *)(pfVar19 + 0xc) = *(undefined8 *)(pfVar17 + -2);
          pfVar19 = pfVar19 + 0xe;
          *pfVar24 = fVar5;
          pfVar17[-0xd] = fVar6;
          pfVar17[-0xc] = fVar7;
          pfVar17[-0xb] = fVar8;
          pfVar17[-10] = fVar9;
          pfVar17[-9] = fVar10;
          pfVar17[-8] = fVar11;
          pfVar17[-7] = fVar12;
          pfVar17[-6] = fVar13;
          pfVar17[-5] = fVar14;
          pfVar17[-4] = fVar15;
          pfVar17[-3] = fVar16;
          *(undefined8 *)(pfVar17 + -2) = uVar1;
        }
      }
      goto joined_r0x0082af42;
    }
    if (*pfVar22 <= *pfVar19) {
      if (*pfVar22 < *pfVar19) goto joined_r0x0082afa6;
      if (pfVar20 != pfVar19) {
        fVar2 = pfVar19[1];
        fVar3 = pfVar19[2];
        fVar4 = pfVar19[3];
        fVar5 = *pfVar20;
        fVar6 = pfVar20[1];
        fVar7 = pfVar20[2];
        fVar8 = pfVar20[3];
        fVar9 = pfVar20[4];
        fVar10 = pfVar20[5];
        fVar11 = pfVar20[6];
        fVar12 = pfVar20[7];
        fVar13 = pfVar20[8];
        fVar14 = pfVar20[9];
        fVar15 = pfVar20[10];
        fVar16 = pfVar20[0xb];
        uVar1 = *(undefined8 *)(pfVar20 + 0xc);
        *pfVar20 = *pfVar19;
        pfVar20[1] = fVar2;
        pfVar20[2] = fVar3;
        pfVar20[3] = fVar4;
        fVar2 = pfVar19[5];
        fVar3 = pfVar19[6];
        fVar4 = pfVar19[7];
        pfVar20[4] = pfVar19[4];
        pfVar20[5] = fVar2;
        pfVar20[6] = fVar3;
        pfVar20[7] = fVar4;
        fVar2 = pfVar19[9];
        fVar3 = pfVar19[10];
        fVar4 = pfVar19[0xb];
        pfVar20[8] = pfVar19[8];
        pfVar20[9] = fVar2;
        pfVar20[10] = fVar3;
        pfVar20[0xb] = fVar4;
        *(undefined8 *)(pfVar20 + 0xc) = *(undefined8 *)(pfVar19 + 0xc);
        *pfVar19 = fVar5;
        pfVar19[1] = fVar6;
        pfVar19[2] = fVar7;
        pfVar19[3] = fVar8;
        pfVar19[4] = fVar9;
        pfVar19[5] = fVar10;
        pfVar19[6] = fVar11;
        pfVar19[7] = fVar12;
        pfVar19[8] = fVar13;
        pfVar19[9] = fVar14;
        pfVar19[10] = fVar15;
        pfVar19[0xb] = fVar16;
        *(undefined8 *)(pfVar19 + 0xc) = uVar1;
      }
      pfVar20 = pfVar20 + 0xe;
    }
    pfVar19 = pfVar19 + 0xe;
  } while( true );
}



/* FUNCTION 12625 ; VA 0x0082b1b0 ; FUN_0082b1b0 */

void FUN_0082b1b0(int param_1,int param_2,uint param_3,float *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  float fVar8;
  float fVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  
  iVar12 = (int)(param_3 - 1) >> 1;
  iVar11 = param_2;
  iVar10 = param_2;
  if (param_2 < iVar12) {
    do {
      fVar4 = *(float *)(param_1 + 0x70 + iVar11 * 0x70);
      pfVar3 = (float *)(param_1 + 0x38 + iVar11 * 0x70);
      iVar10 = iVar11 * 2 + ((*pfVar3 <= fVar4 && fVar4 != *pfVar3) ^ 1) + 1;
      puVar1 = (undefined4 *)(param_1 + iVar10 * 0x38);
      uVar5 = puVar1[1];
      uVar6 = puVar1[2];
      uVar7 = puVar1[3];
      puVar2 = (undefined4 *)(param_1 + iVar11 * 0x38);
      *puVar2 = *puVar1;
      puVar2[1] = uVar5;
      puVar2[2] = uVar6;
      puVar2[3] = uVar7;
      puVar1 = (undefined4 *)(param_1 + 0x10 + iVar10 * 0x38);
      uVar5 = puVar1[1];
      uVar6 = puVar1[2];
      uVar7 = puVar1[3];
      puVar2 = (undefined4 *)(param_1 + 0x10 + iVar11 * 0x38);
      *puVar2 = *puVar1;
      puVar2[1] = uVar5;
      puVar2[2] = uVar6;
      puVar2[3] = uVar7;
      puVar1 = (undefined4 *)(param_1 + 0x20 + iVar10 * 0x38);
      uVar5 = puVar1[1];
      uVar6 = puVar1[2];
      uVar7 = puVar1[3];
      puVar2 = (undefined4 *)(param_1 + 0x20 + iVar11 * 0x38);
      *puVar2 = *puVar1;
      puVar2[1] = uVar5;
      puVar2[2] = uVar6;
      puVar2[3] = uVar7;
      *(undefined8 *)(param_1 + 0x30 + iVar11 * 0x38) =
           *(undefined8 *)(param_1 + 0x30 + iVar10 * 0x38);
      iVar11 = iVar10;
    } while (iVar10 < iVar12);
  }
  if ((iVar10 == iVar12) && ((param_3 & 1) == 0)) {
    puVar2 = (undefined4 *)(param_1 + -0x38 + param_3 * 0x38);
    uVar5 = puVar2[1];
    uVar6 = puVar2[2];
    uVar7 = puVar2[3];
    puVar1 = (undefined4 *)(param_1 + iVar10 * 0x38);
    *puVar1 = *puVar2;
    puVar1[1] = uVar5;
    puVar1[2] = uVar6;
    puVar1[3] = uVar7;
    puVar1 = (undefined4 *)(param_1 + -0x28 + param_3 * 0x38);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + 0x10 + iVar10 * 0x38);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar1 = (undefined4 *)(param_1 + -0x18 + param_3 * 0x38);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + 0x20 + iVar10 * 0x38);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    *(undefined8 *)(param_1 + 0x30 + iVar10 * 0x38) = *(undefined8 *)(param_1 + -8 + param_3 * 0x38)
    ;
    iVar10 = param_3 - 1;
  }
  while ((param_2 < iVar10 &&
         (iVar11 = iVar10 + -1 >> 1, fVar4 = *(float *)(param_1 + iVar11 * 0x38),
         *param_4 <= fVar4 && fVar4 != *param_4))) {
    puVar1 = (undefined4 *)(param_1 + iVar11 * 0x38);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + iVar10 * 0x38);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar1 = (undefined4 *)(param_1 + 0x10 + iVar11 * 0x38);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + 0x10 + iVar10 * 0x38);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    puVar1 = (undefined4 *)(param_1 + 0x20 + iVar11 * 0x38);
    uVar5 = puVar1[1];
    uVar6 = puVar1[2];
    uVar7 = puVar1[3];
    puVar2 = (undefined4 *)(param_1 + 0x20 + iVar10 * 0x38);
    *puVar2 = *puVar1;
    puVar2[1] = uVar5;
    puVar2[2] = uVar6;
    puVar2[3] = uVar7;
    *(undefined8 *)(param_1 + 0x30 + iVar10 * 0x38) =
         *(undefined8 *)(param_1 + 0x30 + iVar11 * 0x38);
    iVar10 = iVar11;
  }
  fVar4 = param_4[1];
  fVar8 = param_4[2];
  fVar9 = param_4[3];
  pfVar3 = (float *)(param_1 + iVar10 * 0x38);
  *pfVar3 = *param_4;
  pfVar3[1] = fVar4;
  pfVar3[2] = fVar8;
  pfVar3[3] = fVar9;
  fVar4 = param_4[5];
  fVar8 = param_4[6];
  fVar9 = param_4[7];
  pfVar3 = (float *)(param_1 + 0x10 + iVar10 * 0x38);
  *pfVar3 = param_4[4];
  pfVar3[1] = fVar4;
  pfVar3[2] = fVar8;
  pfVar3[3] = fVar9;
  fVar4 = param_4[9];
  fVar8 = param_4[10];
  fVar9 = param_4[0xb];
  pfVar3 = (float *)(param_1 + 0x20 + iVar10 * 0x38);
  *pfVar3 = param_4[8];
  pfVar3[1] = fVar4;
  pfVar3[2] = fVar8;
  pfVar3[3] = fVar9;
  *(undefined8 *)(param_1 + 0x30 + iVar10 * 0x38) = *(undefined8 *)(param_4 + 0xc);
  return;
}



/* FUNCTION 12626 ; VA 0x0082b320 ; FUN_0082b320 */

int __thiscall FUN_0082b320(int *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  
  uVar5 = param_2;
  iVar2 = *param_1;
  uVar3 = (param_1[1] - iVar2) / 0x38;
  iVar6 = (param_1[2] - iVar2) * -0x6db6db6d;
  uVar4 = (param_1[2] - iVar2) / 0x38;
  if (param_2 <= uVar4) {
    if (param_2 <= uVar3) {
      if (param_2 != uVar3) {
        iVar6 = iVar2 + param_2 * 0x38;
        param_1[1] = iVar6;
      }
      return iVar6;
    }
    iVar6 = FUN_0082be30(param_1[1],param_2 - uVar3);
    param_1[1] = iVar6;
    return iVar6;
  }
  if (0x4924924 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar4 <= 0x4924924 - (uVar4 >> 1)) && (uVar1 = (uVar4 >> 1) + uVar4, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar6 = FUN_0082c100(param_2);
  FUN_0082be30(iVar6 + uVar3 * 0x38,uVar5 - uVar3);
  FUN_0082c0b0(*param_1,param_1[1],iVar6);
  iVar6 = FUN_0082bf90(iVar6,uVar5,param_2);
  return iVar6;
}



/* FUNCTION 12627 ; VA 0x0082b430 ; FUN_0082b430 */

void FUN_0082b430(float *param_1,float *param_2,int param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float *pfVar4;
  int iVar5;
  float *pfVar6;
  float *pfVar7;
  float *pfVar8;
  int iVar9;
  float *pfVar10;
  float *pfVar11;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float *pfStack_c;
  float *pfStack_8;
  
  iVar5 = (int)param_2 - (int)param_1;
  pfVar8 = param_2;
  pfVar11 = param_1;
  iVar9 = param_3;
  do {
    iVar5 = iVar5 / 0x38;
    if (iVar5 < 0x21) {
LAB_0082b506:
      if (((1 < iVar5) && (pfVar11 != pfVar8)) && (pfVar10 = pfVar11 + 0xe, pfVar10 != pfVar8)) {
        param_1 = (float *)0x38;
        do {
          fStack_24 = *pfVar10;
          fStack_20 = pfVar10[1];
          fStack_1c = pfVar10[2];
          fStack_18 = pfVar10[3];
          fStack_34 = pfVar10[4];
          fStack_30 = pfVar10[5];
          fStack_2c = pfVar10[6];
          fStack_28 = pfVar10[7];
          fStack_44 = pfVar10[8];
          fStack_40 = pfVar10[9];
          fStack_3c = pfVar10[10];
          fStack_38 = pfVar10[0xb];
          uStack_14 = *(undefined8 *)(pfVar10 + 0xc);
          if (fStack_24 < *pfVar11 || fStack_24 == *pfVar11) {
            pfVar4 = (float *)((int)param_1 + -0x38 + (int)pfVar11);
            pfVar6 = pfVar10;
            pfVar7 = pfVar10;
            if (*pfVar4 <= fStack_24 && fStack_24 != *pfVar4) {
              do {
                pfVar7 = pfVar4;
                fVar1 = pfVar7[1];
                fVar2 = pfVar7[2];
                fVar3 = pfVar7[3];
                *pfVar6 = *pfVar7;
                pfVar6[1] = fVar1;
                pfVar6[2] = fVar2;
                pfVar6[3] = fVar3;
                fVar1 = pfVar7[5];
                fVar2 = pfVar7[6];
                fVar3 = pfVar7[7];
                pfVar6[4] = pfVar7[4];
                pfVar6[5] = fVar1;
                pfVar6[6] = fVar2;
                pfVar6[7] = fVar3;
                fVar1 = pfVar7[9];
                fVar2 = pfVar7[10];
                fVar3 = pfVar7[0xb];
                pfVar6[8] = pfVar7[8];
                pfVar6[9] = fVar1;
                pfVar6[10] = fVar2;
                pfVar6[0xb] = fVar3;
                fVar1 = pfVar7[0xd];
                pfVar6[0xc] = pfVar7[0xc];
                pfVar6[0xd] = fVar1;
                pfVar4 = pfVar7 + -0xe;
                pfVar6 = pfVar7;
              } while (*pfVar4 <= fStack_24 && fStack_24 != *pfVar4);
            }
            *pfVar7 = fStack_24;
            pfVar7[1] = fStack_20;
            pfVar7[2] = fStack_1c;
            pfVar7[3] = fStack_18;
            pfVar7[4] = fStack_34;
            pfVar7[5] = fStack_30;
            pfVar7[6] = fStack_2c;
            pfVar7[7] = fStack_28;
            pfVar7[8] = fStack_44;
            pfVar7[9] = fStack_40;
            pfVar7[10] = fStack_3c;
            pfVar7[0xb] = fStack_38;
            *(undefined8 *)(pfVar7 + 0xc) = uStack_14;
          }
          else {
            FUN_0055b6b0((int)&param_2 + 3,&pfStack_8,&pfStack_8);
            FUN_0170cc70(pfVar11 + 0xe,pfVar11,param_1);
            *pfVar11 = fStack_24;
            pfVar11[1] = fStack_20;
            pfVar11[2] = fStack_1c;
            pfVar11[3] = fStack_18;
            pfVar11[4] = fStack_34;
            pfVar11[5] = fStack_30;
            pfVar11[6] = fStack_2c;
            pfVar11[7] = fStack_28;
            pfVar11[8] = fStack_44;
            pfVar11[9] = fStack_40;
            pfVar11[10] = fStack_3c;
            pfVar11[0xb] = fStack_38;
            pfVar11[0xc] = (float)uStack_14;
            pfVar11[0xd] = uStack_14._4_4_;
          }
          pfVar10 = pfVar10 + 0xe;
          param_1 = (float *)((int)param_1 + 0x38);
        } while (pfVar10 != pfVar8);
      }
      return;
    }
    if (iVar9 < 1) {
      if (0x20 < iVar5) {
        FUN_0082ab60(pfVar11,pfVar8,param_4);
        if (((int)pfVar8 - (int)pfVar11) / 0x38 < 2) {
          return;
        }
        pfVar8 = pfVar8 + -0xe;
        do {
          fStack_7c = *pfVar8;
          fStack_78 = pfVar8[1];
          fStack_74 = pfVar8[2];
          fStack_70 = pfVar8[3];
          fStack_6c = pfVar8[4];
          fStack_68 = pfVar8[5];
          fStack_64 = pfVar8[6];
          fStack_60 = pfVar8[7];
          fStack_5c = pfVar8[8];
          fStack_58 = pfVar8[9];
          fStack_54 = pfVar8[10];
          fStack_50 = pfVar8[0xb];
          uStack_4c = *(undefined8 *)(pfVar8 + 0xc);
          fVar1 = pfVar11[1];
          fVar2 = pfVar11[2];
          fVar3 = pfVar11[3];
          *pfVar8 = *pfVar11;
          pfVar8[1] = fVar1;
          pfVar8[2] = fVar2;
          pfVar8[3] = fVar3;
          fVar1 = pfVar11[5];
          fVar2 = pfVar11[6];
          fVar3 = pfVar11[7];
          pfVar8[4] = pfVar11[4];
          pfVar8[5] = fVar1;
          pfVar8[6] = fVar2;
          pfVar8[7] = fVar3;
          fVar1 = pfVar11[9];
          fVar2 = pfVar11[10];
          fVar3 = pfVar11[0xb];
          pfVar8[8] = pfVar11[8];
          pfVar8[9] = fVar1;
          pfVar8[10] = fVar2;
          pfVar8[0xb] = fVar3;
          *(undefined8 *)(pfVar8 + 0xc) = *(undefined8 *)(pfVar11 + 0xc);
          FUN_0082b1b0(pfVar11,0,((int)pfVar8 - (int)pfVar11) / 0x38,&fStack_7c,param_4);
          pfVar8 = pfVar8 + -0xe;
        } while (1 < ((int)pfVar8 + (0x38 - (int)pfVar11)) / 0x38);
        return;
      }
      goto LAB_0082b506;
    }
    FUN_0082ae00(&pfStack_c,pfVar11,pfVar8,param_4);
    iVar9 = (iVar9 >> 1) + (iVar9 >> 2);
    param_3 = iVar9;
    if (((int)pfStack_c - (int)pfVar11) / 0x38 < ((int)pfVar8 - (int)pfStack_8) / 0x38) {
      FUN_0082b430(pfVar11,pfStack_c,iVar9,param_4);
      pfVar11 = pfStack_8;
    }
    else {
      FUN_0082b430(pfStack_8,pfVar8,iVar9,param_4);
      pfVar8 = pfStack_c;
    }
    iVar5 = (int)pfVar8 - (int)pfVar11;
  } while( true );
}



/* FUNCTION 12628 ; VA 0x0082b6e0 ; FUN_0082b6e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0082b6e0(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined uVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  uint auStack_64 [2];
  undefined8 uStack_5c;
  undefined4 uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_3c;
  undefined4 uStack_30;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b6d14;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Emitter::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0x3f800000;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0x3f800000;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0x3f800000;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0x3f800000;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0x3f800000;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0x3f800000;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_20 = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  puStack_14 = param_1;
  FUN_0147c770();
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  *(undefined *)(param_1 + 0x4d) = 0;
  iVar11 = 0x20;
  _uStack_8 = CONCAT31(uStack_7,2);
  do {
    FUN_00569440();
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  iVar11 = 0x20;
  do {
    FUN_00569440();
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  iVar11 = 0x20;
  do {
    FUN_005502b0();
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  iVar11 = 0x20;
  do {
    FUN_005502b0();
    puVar5 = puStack_14;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  puStack_14[0x193] = 0;
  puStack_14[0x194] = 0xf;
  *(undefined *)(puStack_14 + 399) = 0;
  uStack_8 = 3;
  FUN_016f4053(puStack_14 + 0x197,8,2,FUN_005502b0,FUN_00550b30);
  puVar5[0x19e] = 0;
  puVar5[0x19f] = 0;
  puVar5[0x1a0] = 0;
  puVar5[0x1a1] = 0;
  puVar5[0x1a3] = 0x7f7fffff;
  puVar5[0x1a4] = 0x7f7fffff;
  puVar5[0x1a5] = 0x7f7fffff;
  puVar5[0x1a6] = 0xff7fffff;
  puVar5[0x1a7] = 0xff7fffff;
  puVar5[0x1a8] = 0xff7fffff;
  uStack_8 = 4;
  uVar7 = FUN_01675290(DAT_01eb40cc);
  _uStack_8 = CONCAT31(uStack_7,5);
  puVar5[1] = *(undefined4 *)(param_2 + 0x500);
  uStack_18 = uVar7;
  FUN_0082d6e0(param_2);
  iVar11 = puVar5[1];
  iVar9 = *(int *)(iVar11 + 0x20);
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = *(int *)(iVar11 + 0x20);
  }
  puVar5[0x1d] = *(undefined4 *)(iVar11 + 0x1c);
  piVar1 = (int *)puVar5[0x1e];
  puVar5[0x1e] = iVar9;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar11 = piVar1[1] + -1;
    piVar1[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar11 = piVar1[2] + -1;
      piVar1[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  puVar5[0x1f] = 0;
  if ((uint)((int)(puVar5[4] - puVar5[2]) / 0x38) < 0x3c) {
    FUN_0082c020(0x3c);
  }
  uVar2 = DAT_018f7860;
  uVar12 = DAT_018ce2f4;
  puVar5[0x23] = 0;
  puVar5[0x24] = 0x40a00000;
  puVar5[0x25] = 0x40a00000;
  uStack_5c = CONCAT44(uVar2,uVar2);
  puVar5[0x26] = 0;
  puVar5[0x27] = 0x41200000;
  uStack_24 = 0xbf000000;
  uStack_30 = 0x3f000000;
  puVar5[0x28] = uVar2;
  puVar5[0x29] = uVar2;
  puVar5[0x2a] = 0xbf000000;
  puVar5[0x2b] = uVar12;
  *(ulonglong *)(puVar5 + 0x2c) = CONCAT44(0x3f000000,uVar12);
  uVar12 = (undefined4)uStack_20;
  puVar5[0x2e] = 0;
  puVar5[0x2f] = 0;
  puVar5[0x30] = 0;
  puVar5[0x31] = 0;
  puVar5[0x38] = 0;
  *(ulonglong *)(puVar5 + 0x32) = CONCAT44(uVar12,uVar12);
  *(ulonglong *)(puVar5 + 0x35) = CONCAT44(uVar12,uVar12);
  uStack_3c = 0;
  puVar5[0x34] = 0;
  puVar5[0x37] = 0;
  puVar5[0x39] = 0;
  puVar5[0x3a] = 0;
  puVar5[0x3b] = 0;
  puVar5[0x3c] = 0;
  puVar5[0x3d] = 0x3f800000;
  puVar5[0x3e] = 0x3f800000;
  puVar5[0x3f] = 0x3f800000;
  puVar5[0x40] = 0x3f800000;
  puVar5[0x41] = 0;
  puVar5[0x42] = 0;
  puVar5[0x43] = 0;
  puVar5[0x44] = 0;
  puVar5[0x45] = 0;
  puVar5[0x46] = 0;
  puVar5[0x18e] = 0;
  *(ulonglong *)(puVar5 + 0x47) = CONCAT44(uVar12,uVar12);
  puVar5[0x4a] = 0;
  *(undefined *)(puVar5 + 0x49) = 0;
  puVar5[0x4b] = 0x3fc90fdb;
  puVar5[0x4c] = 0x3fc90fdb;
  uStack_54 = 0;
  uStack_50 = 0xf;
  auStack_64[0] = auStack_64[0] & 0xffffff00;
  uStack_8 = 6;
  uStack_4c = 3;
  uStack_48 = 1;
  FUN_005542c0("rbxasset://textures/particles/sparkles_main.dds",0x2f);
  uVar4 = _UNK_018e004c;
  uVar3 = _UNK_018e0048;
  uVar2 = _UNK_018e0044;
  uVar12 = _DAT_018e0040;
  puVar5[0x1a2] = 0;
  puVar5[0x19e] = uVar12;
  puVar5[0x19f] = uVar2;
  puVar5[0x1a0] = uVar3;
  puVar5[0x1a1] = uVar4;
  puVar5[0x19b] = 0;
  puVar5[0x19c] = 0x3f000000;
  puVar5[0x19d] = 0;
  FUN_0082e340(auStack_64,param_3);
  _DAT_01eb4134 = _DAT_01eb4134 + 1;
  uStack_8 = 5;
  uVar6 = uStack_8;
  uStack_8 = 5;
  if (0xf < uStack_50) {
    uVar10 = uStack_50 + 1;
    uVar8 = auStack_64[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_64[0] - 4);
      uVar10 = uStack_50 + 0x24;
      if (0x1f < (auStack_64[0] - uVar8) - 4) {
        uStack_8 = uVar6;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  _uStack_8 = CONCAT31(uStack_7,7);
  FUN_01675290(uVar7);
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 12629 ; VA 0x0082bd80 ; FUN_0082bd80 */

int __fastcall FUN_0082bd80(int param_1)

{
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  return param_1;
}



/* FUNCTION 12630 ; VA 0x0082bdb0 ; FUN_0082bdb0 */

void __fastcall FUN_0082bdb0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12631 ; VA 0x0082be30 ; FUN_0082be30 */

int FUN_0082be30(int param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = (undefined4 *)(param_1 + 0xc);
    do {
      FUN_0170d1f0(param_1,0,0x38);
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      param_1 = param_1 + 0x38;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0xe;
    } while (param_2 != 0);
  }
  return param_1;
}



/* FUNCTION 12632 ; VA 0x0082be90 ; FUN_0082be90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0082be90(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  _DAT_01eb4134 = _DAT_01eb4134 + -1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::Emitter::vftable;
  FUN_016f32d1(param_1 + 0x197,8,2,FUN_00550b30);
  uVar2 = param_1[0x194];
  if (0xf < uVar2) {
    iVar3 = param_1[399];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0x193] = 0;
  param_1[0x194] = 0xf;
  *(undefined *)(param_1 + 399) = 0;
  piVar4 = (int *)param_1[0x1e];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0082bdb0();
  FUN_007f6360();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x6a4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12633 ; VA 0x0082bf90 ; FUN_0082bf90 */

void __thiscall FUN_0082bf90(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x38) * 0x38;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x38;
  param_1[2] = param_2 + param_4 * 0x38;
  return;
}



/* FUNCTION 12634 ; VA 0x0082c020 ; FUN_0082c020 */

void __thiscall FUN_0082c020(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_0082c100(param_2);
  FUN_0082c0b0(*param_1,param_1[1],uVar3);
  FUN_0082bf90(uVar3,(iVar1 - iVar2) / 0x38,param_2);
  return;
}



/* FUNCTION 12635 ; VA 0x0082c070 ; FUN_0082c070 */

void FUN_0082c070(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      *param_3 = *param_1;
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      param_3[4] = param_1[4];
      param_3[5] = uVar2;
      param_3[6] = uVar3;
      param_3[7] = uVar4;
      uVar2 = param_1[9];
      uVar3 = param_1[10];
      uVar4 = param_1[0xb];
      param_3[8] = param_1[8];
      param_3[9] = uVar2;
      param_3[10] = uVar3;
      param_3[0xb] = uVar4;
      puVar1 = (undefined8 *)(param_1 + 0xc);
      param_1 = param_1 + 0xe;
      *(undefined8 *)(param_3 + 0xc) = *puVar1;
      param_3 = param_3 + 0xe;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12636 ; VA 0x0082c0b0 ; FUN_0082c0b0 */

void FUN_0082c0b0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      puVar1 = (undefined4 *)(param_3 + (int)param_1);
      *puVar1 = *param_1;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      puVar1 = (undefined4 *)(param_3 + 0x10 + (int)param_1);
      *puVar1 = param_1[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = param_1[9];
      uVar3 = param_1[10];
      uVar4 = param_1[0xb];
      puVar1 = (undefined4 *)(param_3 + 0x20 + (int)param_1);
      *puVar1 = param_1[8];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(param_3 + 0x30 + (int)param_1) = *(undefined8 *)(param_1 + 0xc);
      param_1 = param_1 + 0xe;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12637 ; VA 0x0082c100 ; FUN_0082c100 */

uint FUN_0082c100(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x38;
  if (param_1 < 0x4924925) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 12638 ; VA 0x0082c170 ; FUN_0082c170 */

int __thiscall FUN_0082c170(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  float10 fVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  float fStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  float fStack_28;
  int iStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  code *pcStack_c;
  code *pcStack_8;
  
  if (*(int *)(param_1 + 0x65c) != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    if (*(int *)(param_1 + 8) == iVar2) {
      *(undefined4 *)(param_1 + 0x44) = *(undefined4 *)(param_1 + 0x14);
      *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_1 + 0x18);
      *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_1 + 0x1c);
      *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_1 + 0x20);
      *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_1 + 0x24);
      *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x28);
      *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x2c);
      *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x30);
      *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 0x34);
      *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_1 + 0x38);
      *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x3c);
      *(undefined4 *)(param_1 + 0x70) = *(undefined4 *)(param_1 + 0x40);
      iVar2 = *(int *)(param_1 + 0xc);
    }
    iVar2 = 60000 - (iVar2 - *(int *)(param_1 + 8)) / 0x38;
    iStack_2c = param_2;
    if (iVar2 < param_2) {
      iStack_2c = iVar2;
    }
    if (0 < iStack_2c) {
      piVar3 = (int *)(*(int *)(param_1 + 4) + 0x84);
      fStack_28 = (*(float *)(param_1 + 0xac) - *(float *)(param_1 + 0xa0)) * DAT_018ce2f4;
      fVar6 = (*(float *)(param_1 + 0xb0) - *(float *)(param_1 + 0xa4)) * DAT_018ce2f4;
      fStack_20 = (*(float *)(param_1 + 0xb4) - *(float *)(param_1 + 0xa8)) * DAT_018ce2f4;
      FUN_01161480(&fStack_94,*(undefined4 *)(param_1 + 300),*(undefined4 *)(param_1 + 0x130),0);
      uStack_68 = (uint)fVar6 ^ DAT_018c4ea0;
      uStack_70 = (uint)fStack_28 ^ DAT_018c4ea0;
      uStack_6c = (uint)fStack_20 ^ DAT_018c4ea0;
      iStack_24 = iStack_2c;
      do {
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_c)(uStack_70,fStack_28);
        fStack_10 = (float)fVar4;
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_c)(uStack_68,fVar6);
        fStack_14 = (float)fVar4;
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_c)(uStack_6c,fStack_20);
        fStack_18 = (float)fVar4;
        if (*(char *)(param_1 + 0x124) == '\0') {
          fVar11 = *(float *)(param_1 + 0x18) * fStack_14 + *(float *)(param_1 + 0x14) * fStack_10 +
                   *(float *)(param_1 + 0x1c) * fStack_18 + *(float *)(param_1 + 0x38);
          fVar9 = *(float *)(param_1 + 0x20) * fStack_10 + *(float *)(param_1 + 0x24) * fStack_14 +
                  *(float *)(param_1 + 0x28) * fStack_18 + *(float *)(param_1 + 0x3c);
          fStack_58 = *(float *)(param_1 + 0x2c) * fStack_10 +
                      *(float *)(param_1 + 0x30) * fStack_14 +
                      *(float *)(param_1 + 0x34) * fStack_18 + *(float *)(param_1 + 0x40);
        }
        else {
          fVar11 = *(float *)(param_1 + 0x48) * fStack_14 + fStack_10 * *(float *)(param_1 + 0x44) +
                   *(float *)(param_1 + 0x4c) * fStack_18 + *(float *)(param_1 + 0x68);
          fVar9 = *(float *)(param_1 + 0x50) * fStack_10 + *(float *)(param_1 + 0x54) * fStack_14 +
                  *(float *)(param_1 + 0x58) * fStack_18 + *(float *)(param_1 + 0x6c);
          fStack_58 = *(float *)(param_1 + 0x5c) * fStack_10 +
                      *(float *)(param_1 + 0x60) * fStack_14 + *(float *)(param_1 + 100) * fStack_18
                      + *(float *)(param_1 + 0x70);
        }
        fStack_10 = *(float *)(param_1 + 0xc4);
        pcStack_8 = *(code **)(param_1 + 0xb8);
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fStack_1c = *(float *)(param_1 + 0xbc);
        uStack_60 = CONCAT44(fVar9,fVar11);
        fVar4 = (float10)(*pcStack_c)(*(uint *)(param_1 + 0xc0) ^ DAT_018c4ea0,
                                      *(uint *)(param_1 + 0xc0));
        fStack_18 = (float)fVar4;
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_c)((uint)fStack_10 ^ DAT_018c4ea0,fStack_10);
        pcStack_c = *(code **)(*piVar3 + 0x14);
        fStack_14 = (float)(fVar4 + (float10)DAT_018f8ff0);
        fVar4 = (float10)(*pcStack_c)(pcStack_8,fStack_1c);
        dVar5 = (double)fStack_14;
        pcStack_c = (code *)(float)fVar4;
        FUN_01728390();
        fStack_10 = (float)dVar5 * (float)pcStack_c;
        dVar5 = (double)fStack_18;
        FUN_017279f0();
        fStack_1c = (float)dVar5 * fStack_10;
        dVar5 = (double)fStack_18;
        FUN_01728390();
        pcStack_8 = (code *)((float)dVar5 * fStack_10);
        dVar5 = (double)fStack_14;
        FUN_017279f0();
        fVar9 = (float)dVar5 * (float)pcStack_c;
        fVar11 = fStack_90 * (float)pcStack_8 + fStack_94 * fStack_1c + fStack_8c * fVar9;
        fVar10 = fStack_84 * (float)pcStack_8 + fStack_88 * fStack_1c + fStack_80 * fVar9;
        fVar9 = fStack_78 * (float)pcStack_8 + fStack_7c * fStack_1c + fStack_74 * fVar9;
        if (*(char *)(param_1 + 0x124) == '\0') {
          fVar8 = *(float *)(param_1 + 0x18) * fVar10 + *(float *)(param_1 + 0x14) * fVar11 +
                  *(float *)(param_1 + 0x1c) * fVar9;
          fVar7 = *(float *)(param_1 + 0x24) * fVar10 + *(float *)(param_1 + 0x20) * fVar11 +
                  *(float *)(param_1 + 0x28) * fVar9;
          fStack_4c = *(float *)(param_1 + 0x30) * fVar10 + *(float *)(param_1 + 0x2c) * fVar11 +
                      *(float *)(param_1 + 0x34) * fVar9;
          uStack_54 = CONCAT44(fVar7,fVar8);
          if (NAN(*(float *)(param_1 + 0x128)) == (*(float *)(param_1 + 0x128) == 0.0)) {
            fVar10 = fStack_58 - *(float *)(param_1 + 0x40);
            fVar9 = (float)uStack_60 - *(float *)(param_1 + 0x38);
            fVar11 = uStack_60._4_4_ - *(float *)(param_1 + 0x3c);
            fStack_4c = ((fVar11 * *(float *)(param_1 + 0x118) - fVar9 * *(float *)(param_1 + 0x11c)
                         ) + *(float *)(param_1 + 0x114)) * *(float *)(param_1 + 0x128) + fStack_4c;
            uStack_54 = CONCAT44(((fVar9 * *(float *)(param_1 + 0x120) -
                                  fVar10 * *(float *)(param_1 + 0x118)) +
                                 *(float *)(param_1 + 0x110)) * *(float *)(param_1 + 0x128) + fVar7,
                                 ((fVar10 * *(float *)(param_1 + 0x11c) -
                                  fVar11 * *(float *)(param_1 + 0x120)) +
                                 *(float *)(param_1 + 0x10c)) * *(float *)(param_1 + 0x128) + fVar8)
            ;
          }
        }
        else {
          uStack_54 = CONCAT44(*(float *)(param_1 + 0x54) * fVar10 +
                               *(float *)(param_1 + 0x50) * fVar11 +
                               *(float *)(param_1 + 0x58) * fVar9,
                               *(float *)(param_1 + 0x48) * fVar10 +
                               *(float *)(param_1 + 0x44) * fVar11 +
                               *(float *)(param_1 + 0x4c) * fVar9);
          fStack_4c = *(float *)(param_1 + 0x60) * fVar10 + *(float *)(param_1 + 0x5c) * fVar11 +
                      *(float *)(param_1 + 100) * fVar9;
        }
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_8)(*(undefined4 *)(param_1 + 0x90),
                                      *(undefined4 *)(param_1 + 0x94));
        fStack_40 = (float)fVar4;
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fStack_3c = fStack_40;
        fVar4 = (float10)(*pcStack_8)(*(undefined4 *)(param_1 + 0xf4),
                                      *(undefined4 *)(param_1 + 0xf8));
        fStack_38 = (float)fVar4;
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_8)(*(undefined4 *)(param_1 + 0xfc),
                                      *(undefined4 *)(param_1 + 0x100));
        fStack_34 = (float)fVar4;
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_8)(*(undefined4 *)(param_1 + 0xe4),
                                      *(undefined4 *)(param_1 + 0xe8));
        fStack_48 = (float)fVar4;
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_8)(*(undefined4 *)(param_1 + 0xec),
                                      *(undefined4 *)(param_1 + 0xf0));
        fStack_44 = (float)fVar4;
        pcStack_8 = *(code **)(*piVar3 + 0x14);
        fVar4 = (float10)(*pcStack_8)(0,0x46fffdfb);
        pcStack_8 = (code *)(float)fVar4;
        uStack_30 = FUN_016f3cd0();
        puVar1 = *(undefined4 **)(param_1 + 0xc);
        if (*(undefined4 **)(param_1 + 0x10) == puVar1) {
          FUN_0082aa40(puVar1,&uStack_64);
        }
        else {
          *puVar1 = uStack_64;
          puVar1[1] = (float)uStack_60;
          puVar1[2] = uStack_60._4_4_;
          puVar1[3] = fStack_58;
          puVar1[4] = (undefined4)uStack_54;
          puVar1[5] = uStack_54._4_4_;
          puVar1[6] = fStack_4c;
          puVar1[7] = fStack_48;
          puVar1[8] = fStack_44;
          puVar1[9] = fStack_40;
          puVar1[10] = fStack_3c;
          puVar1[0xb] = fStack_38;
          *(ulonglong *)(puVar1 + 0xc) = CONCAT44(uStack_30,fStack_34);
          *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x38;
        }
        iStack_24 = iStack_24 + -1;
      } while (iStack_24 != 0);
      return iStack_2c;
    }
  }
  return 0;
}



/* FUNCTION 12639 ; VA 0x0082c950 ; FUN_0082c950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float * __thiscall FUN_0082c950(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  int iVar5;
  float *pfVar6;
  float fVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  double dVar11;
  double dVar12;
  float fVar13;
  undefined8 uVar14;
  float fVar15;
  undefined *puVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  undefined auStack_ba0 [4];
  float afStack_b9c [3];
  undefined8 uStack_b90;
  float afStack_b88 [694];
  uint uStack_b0;
  uint uStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  undefined *puStack_6c;
  undefined8 uStack_68;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined8 uStack_4c;
  undefined *puStack_44;
  int iStack_40;
  int iStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  undefined *puStack_2c;
  float fStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  float fStack_18;
  int iStack_14;
  float fStack_10;
  float fStack_c;
  char cStack_5;
  
  uVar14 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uVar10 = CONCAT44(DAT_018f7864,DAT_018f7864);
  puStack_2c = &DAT_bf800000;
  cStack_5 = *(char *)(param_1 + 0x124);
  *(undefined *)(param_1 + 0x124) = 0;
  *(undefined8 *)param_2 = uVar10;
  *(undefined8 *)(param_2 + 3) = uVar14;
  fStack_18 = DAT_018ce2f4;
  param_2[2] = (float)&DAT_bf800000;
  param_2[5] = 1.0;
  fVar7 = *(float *)(param_1 + 0xcc);
  fVar13 = *(float *)(param_1 + 200);
  fVar18 = *(float *)(param_1 + 0xd0);
  fStack_28 = (*(float *)(param_1 + 0xac) - *(float *)(param_1 + 0xa0)) * fStack_18;
  fStack_1c = (*(float *)(param_1 + 0xb0) - *(float *)(param_1 + 0xa4)) * fStack_18;
  fStack_18 = (*(float *)(param_1 + 0xb4) - *(float *)(param_1 + 0xa8)) * fStack_18;
  fVar20 = *(float *)(param_1 + 0xd4);
  fStack_50 = fVar7 * *(float *)(param_1 + 0x18) + *(float *)(param_1 + 0x14) * fVar13 +
              fVar18 * *(float *)(param_1 + 0x1c) + fVar20;
  fVar17 = *(float *)(param_1 + 0xd8);
  fVar19 = *(float *)(param_1 + 0xdc);
  uStack_4c._0_4_ =
       fVar7 * *(float *)(param_1 + 0x24) + *(float *)(param_1 + 0x20) * fVar13 +
       fVar18 * *(float *)(param_1 + 0x28) + fVar17;
  uStack_4c._4_4_ =
       (undefined *)
       (fVar7 * *(float *)(param_1 + 0x30) + *(float *)(param_1 + 0x2c) * fVar13 +
        fVar18 * *(float *)(param_1 + 0x34) + fVar19);
  if (cStack_5 == '\0') {
    uStack_68 = CONCAT44((float)uStack_4c,fStack_50);
    puStack_44 = uStack_4c._4_4_;
  }
  else {
    puStack_2c = (undefined *)
                 (fVar20 * *(float *)(param_1 + 0x2c) + fVar17 * *(float *)(param_1 + 0x30) +
                 fVar19 * *(float *)(param_1 + 0x34));
    uStack_68 = CONCAT44(fVar20 * *(float *)(param_1 + 0x20) + fVar17 * *(float *)(param_1 + 0x24) +
                         fVar19 * *(float *)(param_1 + 0x28),
                         fVar20 * *(float *)(param_1 + 0x14) + fVar17 * *(float *)(param_1 + 0x18) +
                         fVar19 * *(float *)(param_1 + 0x1c));
    puStack_44 = puStack_2c;
  }
  iStack_14 = param_1;
  fStack_c = fStack_28;
  uStack_24._0_4_ = fStack_1c;
  uStack_24._4_4_ = fStack_18;
  FUN_01161480(&fStack_98,*(undefined4 *)(param_1 + 300),*(undefined4 *)(param_1 + 0x130),0);
  iStack_3c = 4;
  iStack_40 = 4;
  if (NAN(*(float *)(param_1 + 0xc0)) != (*(float *)(param_1 + 0xc0) == 0.0)) {
    iStack_40 = 1;
  }
  uStack_b0 = (uint)fStack_c ^ DAT_018c4ea0;
  uStack_ac = (uint)fStack_1c ^ DAT_018c4ea0;
  fStack_a8 = (float)((uint)fStack_18 ^ DAT_018c4ea0);
  if (NAN(*(float *)(param_1 + 0xc4)) != (*(float *)(param_1 + 0xc4) == 0.0)) {
    iStack_3c = 1;
  }
  fStack_9c = uStack_24._4_4_;
  fStack_c = 7.00649e-44;
  fStack_a4 = fStack_28;
  fStack_a0 = (float)uStack_24;
  do {
    fStack_c = (float)((int)fStack_c + -1);
    FUN_0082bd80();
    iVar5 = iStack_14;
  } while (fStack_c != 0.0);
  iVar8 = 0;
  fStack_c = (float)iStack_3c;
  fStack_18 = 0.0;
  fStack_38 = *(float *)(iStack_14 + 0x94);
  fStack_1c = *(float *)(iStack_14 + 0xc4);
  fStack_60 = (float)iStack_40;
  fStack_5c = *(float *)(iStack_14 + 0x18);
  do {
    iStack_14 = 0;
    fStack_54 = (float)(int)fStack_18 / fStack_60;
    do {
      uStack_24._4_4_ = (float)(*(uint *)(iVar5 + 0xc0) ^ DAT_018c4ea0);
      dVar11 = (double)(float)((double)(((float)iStack_14 / fStack_c) *
                                        (fStack_1c - (float)((uint)fStack_1c ^ DAT_018c4ea0)) +
                                       (float)((uint)fStack_1c ^ DAT_018c4ea0)) + _DAT_01918c70);
      uStack_4c = dVar11;
      FUN_01728390();
      fStack_10 = (float)dVar11 * *(float *)(iVar5 + 0xbc);
      dVar11 = (double)((*(float *)(iVar5 + 0xc0) - uStack_24._4_4_) * fStack_54 + uStack_24._4_4_);
      uStack_24 = dVar11;
      FUN_017279f0();
      fStack_58 = (float)dVar11 * fStack_10;
      dVar11 = uStack_24;
      FUN_01728390();
      dVar12 = uStack_4c;
      uStack_24._4_4_ = (float)dVar11 * fStack_10;
      FUN_017279f0();
      fVar13 = (float)dVar12 * *(float *)(iVar5 + 0xbc);
      fVar7 = *(float *)(iVar5 + 0x18);
      fVar20 = fStack_94 * uStack_24._4_4_ + fStack_98 * fStack_58 + fStack_90 * fVar13;
      fVar18 = fStack_88 * uStack_24._4_4_ + fStack_8c * fStack_58 + fStack_84 * fVar13;
      fVar13 = fStack_7c * uStack_24._4_4_ + fStack_80 * fStack_58 + fStack_78 * fVar13;
      fStack_34 = *(float *)(iVar5 + 0x14) * fVar20 + fVar7 * fVar18 +
                  *(float *)(iVar5 + 0x1c) * fVar13;
      pfVar6 = &fStack_a8;
      fStack_10 = 2.8026e-45;
      fStack_30 = fVar20 * *(float *)(iVar5 + 0x20) + *(float *)(iVar5 + 0x24) * fVar18 +
                  *(float *)(iVar5 + 0x28) * fVar13;
      puStack_2c = (undefined *)
                   (*(float *)(iVar5 + 0x30) * fVar18 + fVar20 * *(float *)(iVar5 + 0x2c) +
                   *(float *)(iVar5 + 0x34) * fVar13);
      do {
        fVar13 = pfVar6[-1];
        fVar18 = pfVar6[-2];
        fVar20 = *pfVar6;
        fVar17 = *(float *)(iVar5 + 0x14);
        fVar19 = *(float *)(iVar5 + 0x20);
        iVar9 = iVar8;
        if (0x31 < iVar8) {
          iVar9 = 0x31;
        }
        fVar1 = *(float *)(iVar5 + 0x2c);
        iVar8 = iVar9 + 1;
        fVar15 = *(float *)(iVar5 + 0x1c);
        afStack_b88[iVar9 * 0xe + 4] = fStack_38;
        afStack_b88[iVar9 * 0xe + 3] = fStack_38;
        fVar21 = *(float *)(iVar5 + 0x24);
        fVar22 = *(float *)(iVar5 + 0x30);
        fVar2 = *(float *)(iVar5 + 0x38);
        fVar3 = *(float *)(iVar5 + 0x28);
        fVar4 = *(float *)(iVar5 + 0x34);
        *(ulonglong *)(afStack_b88 + iVar9 * 0xe + -2) = CONCAT44(fStack_30,fStack_34);
        puStack_6c = (undefined *)
                     (fVar18 * fVar1 + fVar13 * fVar22 + fVar20 * fVar4 + *(float *)(iVar5 + 0x40));
        *(ulonglong *)(afStack_b9c + iVar9 * 0xe) =
             CONCAT44(fVar18 * fVar19 + fVar13 * fVar21 + fVar20 * fVar3 + *(float *)(iVar5 + 0x3c),
                      fVar18 * fVar17 + fVar13 * fVar7 + fVar20 * fVar15 + fVar2);
        afStack_b9c[iVar9 * 0xe + 2] = (float)puStack_6c;
        afStack_b88[iVar9 * 0xe] = (float)puStack_2c;
        if ((cStack_5 == '\0') &&
           (NAN(*(float *)(iVar5 + 0x128)) == (*(float *)(iVar5 + 0x128) == 0.0))) {
          fVar21 = afStack_b9c[iVar9 * 0xe + 1] - *(float *)(iVar5 + 0x3c);
          fVar15 = afStack_b9c[iVar9 * 0xe + 2] - *(float *)(iVar5 + 0x40);
          fVar7 = *(float *)(iVar5 + 0x11c);
          fVar13 = *(float *)(iVar5 + 0x120);
          fVar22 = afStack_b9c[iVar9 * 0xe] - *(float *)(iVar5 + 0x38);
          fVar18 = *(float *)(iVar5 + 0x118);
          fVar20 = *(float *)(iVar5 + 0x128);
          fVar17 = *(float *)(iVar5 + 0x114);
          fVar19 = *(float *)(iVar5 + 0x110);
          afStack_b88[iVar9 * 0xe + -2] =
               ((fVar7 * fVar15 - fVar13 * fVar21) + *(float *)(iVar5 + 0x10c)) *
               *(float *)(iVar5 + 0x128) + afStack_b88[iVar9 * 0xe + -2];
          fVar1 = afStack_b88[iVar9 * 0xe + -1];
          afStack_b88[iVar9 * 0xe] =
               ((fVar18 * fVar21 - fVar7 * fVar22) + fVar17) * fVar20 + afStack_b88[iVar9 * 0xe];
          afStack_b88[iVar9 * 0xe + -1] =
               ((fVar13 * fVar22 - fVar18 * fVar15) + fVar19) * fVar20 + fVar1;
          fVar7 = fStack_5c;
        }
        pfVar6 = pfVar6 + 3;
        fStack_10 = (float)((int)fStack_10 + -1);
      } while (fStack_10 != 0.0);
      iStack_14 = iStack_14 + 1;
      fStack_10 = (float)iVar8;
    } while (iStack_14 <= iStack_3c);
    fStack_18 = (float)((int)fStack_18 + 1);
  } while ((int)fStack_18 <= iStack_40);
  fStack_c = 7.00649e-45;
  do {
    FUN_0082ecb0(auStack_ba0,fStack_10,*(float *)(iVar5 + 0x94) / DAT_018e3f90,uStack_68,puStack_44)
    ;
    if (0 < (int)fStack_10) {
      pfVar6 = afStack_b9c + 2;
      fVar7 = fStack_10;
      do {
        fVar18 = pfVar6[-2] - *(float *)(iVar5 + 0x38);
        fVar20 = pfVar6[-1] - *(float *)(iVar5 + 0x3c);
        fVar13 = *pfVar6 - *(float *)(iVar5 + 0x40);
        fVar19 = *(float *)(iVar5 + 0x20) * fVar20 + *(float *)(iVar5 + 0x14) * fVar18 +
                 *(float *)(iVar5 + 0x2c) * fVar13;
        fVar17 = *(float *)(iVar5 + 0x18) * fVar18 + fVar20 * *(float *)(iVar5 + 0x24) +
                 fVar13 * *(float *)(iVar5 + 0x30);
        puVar16 = (undefined *)
                  (fVar20 * *(float *)(iVar5 + 0x28) + fVar18 * *(float *)(iVar5 + 0x1c) +
                  fVar13 * *(float *)(iVar5 + 0x34));
        puStack_6c = (undefined *)param_2[2];
        if ((float)puVar16 <= param_2[2]) {
          puStack_6c = puVar16;
        }
        fVar13 = param_2[1];
        if (fVar17 <= param_2[1]) {
          fVar13 = fVar17;
        }
        fVar18 = *param_2;
        if (fVar19 <= *param_2) {
          fVar18 = fVar19;
        }
        *(ulonglong *)param_2 = CONCAT44(fVar13,fVar18);
        param_2[2] = (float)puStack_6c;
        puStack_2c = (undefined *)param_2[5];
        if (param_2[5] <= (float)puVar16) {
          puStack_2c = puVar16;
        }
        fVar13 = param_2[4];
        if (param_2[4] <= fVar17) {
          fVar13 = fVar17;
        }
        fVar18 = param_2[3];
        if (param_2[3] <= fVar19) {
          fVar18 = fVar19;
        }
        pfVar6 = pfVar6 + 0xe;
        *(ulonglong *)(param_2 + 3) = CONCAT44(fVar13,fVar18);
        param_2[5] = (float)puStack_2c;
        fVar7 = (float)((int)fVar7 + -1);
      } while (fVar7 != 0.0);
    }
    fStack_c = (float)((int)fStack_c + -1);
  } while (fStack_c != 0.0);
  *(char *)(iVar5 + 0x124) = cStack_5;
  return param_2;
}



/* FUNCTION 12640 ; VA 0x0082d1e0 ; FUN_0082d1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0082d1e0(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  uint uVar5;
  float fVar6;
  undefined uVar7;
  undefined uVar8;
  undefined uVar9;
  undefined uVar10;
  undefined2 uVar11;
  undefined2 uVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fStack_5c;
  undefined4 uStack_58;
  undefined2 uStack_48;
  undefined2 uStack_46;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  
  fStack_1c = DAT_018c45c4;
  fStack_38 = DAT_018c45c4;
  fStack_34 = DAT_018c45c4;
  fStack_30 = DAT_018c45c4;
  fStack_18 = DAT_018c45d0;
  fStack_44 = DAT_018c45d0;
  fStack_40 = DAT_018c45d0;
  fStack_3c = DAT_018c45d0;
  iVar16 = (*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8)) / 0x38;
  if (iVar16 != 0) {
    iVar15 = 0;
    fVar23 = DAT_01901f68;
    do {
      fVar6 = DAT_01901f68;
      iVar14 = *(int *)(param_1 + 8) + iVar15;
      fStack_38 = *(float *)(iVar14 + 4);
      fVar19 = *(float *)(iVar14 + 8);
      fVar21 = *(float *)(iVar14 + 0xc);
      fStack_14 = *(float *)(iVar14 + 0x30);
      fVar17 = *(float *)(iVar14 + 0x24) / *(float *)(iVar14 + 0x28);
      fStack_10 = *(float *)(iVar14 + 0x2c);
      fVar18 = (DAT_018ce2f8 - fVar17) * DAT_01918c78;
      fVar23 = (float)((double)*(int *)(iVar14 + 0x34) +
                      (&DAT_018c0d90)[-(*(int *)(iVar14 + 0x34) >> 0x1f)]) / fVar23;
      if (*(char *)(param_1 + 0x134) != '\0') {
        iVar13 = (int)fVar18;
        fStack_14 = *(float *)(param_1 + 0x538 + iVar13 * 8);
        fStack_14 = (*(float *)(param_1 + 0x540 + iVar13 * 8) - fStack_14) *
                    (fVar18 - (float)iVar13) + fStack_14;
        fVar22 = *(float *)(param_1 + 0x53c + iVar13 * 8);
        fStack_14 = (((*(float *)(param_1 + 0x544 + iVar13 * 8) - fVar22) * (fVar18 - (float)iVar13)
                     + fVar22) - fStack_14) * fVar23 + fStack_14;
        fStack_10 = fStack_14;
      }
      iVar13 = (int)fVar18;
      fVar18 = fVar18 - (float)iVar13;
      fVar22 = *(float *)(param_1 + 0x138 + iVar13 * 0xc);
      fVar1 = *(float *)(param_1 + 0x2b8 + iVar13 * 0xc);
      fVar2 = *(float *)(param_1 + 700 + iVar13 * 0xc);
      fVar22 = (*(float *)(param_1 + 0x144 + iVar13 * 0xc) - fVar22) * fVar18 + fVar22;
      fVar24 = *(float *)(param_1 + 0x13c + iVar13 * 0xc);
      fVar24 = (*(float *)(param_1 + 0x148 + iVar13 * 0xc) - fVar24) * fVar18 + fVar24;
      fVar25 = *(float *)(param_1 + 0x140 + iVar13 * 0xc);
      fVar25 = (*(float *)(param_1 + 0x14c + iVar13 * 0xc) - fVar25) * fVar18 + fVar25;
      fVar20 = *(float *)(param_1 + 0x438 + iVar13 * 8);
      fVar20 = (*(float *)(param_1 + 0x440 + iVar13 * 8) - fVar20) * fVar18 + fVar20;
      fVar3 = *(float *)(param_1 + 0x43c + iVar13 * 8);
      fVar4 = *(float *)(param_1 + 0x2c0 + iVar13 * 0xc);
      uVar7 = (undefined)
              (int)(((((*(float *)(param_1 + 0x444 + iVar13 * 8) - fVar3) * fVar18 + fVar3) - fVar20
                     ) * fVar23 + fVar20) * DAT_018f9000);
      uVar8 = (undefined)
              (int)(((((*(float *)(param_1 + 0x2c4 + iVar13 * 0xc) - fVar1) * fVar18 + fVar1) -
                     fVar22) * fVar23 + fVar22) * DAT_018f9000);
      uVar9 = (undefined)
              (int)(((((*(float *)(param_1 + 0x2c8 + iVar13 * 0xc) - fVar2) * fVar18 + fVar2) -
                     fVar24) * fVar23 + fVar24) * DAT_018f9000);
      uVar10 = (undefined)
               (int)(((((*(float *)(param_1 + 0x2cc + iVar13 * 0xc) - fVar4) * fVar18 + fVar4) -
                      fVar25) * fVar23 + fVar25) * DAT_018f9000);
      _fStack_5c = CONCAT26((short)(int)((fStack_14 - DAT_018f8ff8) * DAT_018f9980 + DAT_018ce2f4),
                            CONCAT24((short)(int)((fStack_10 - DAT_018f8ff8) * DAT_018f9980 +
                                                 DAT_018ce2f4),fVar21));
      uVar5 = *(uint *)(*(int *)(param_1 + 4) + 0xb8);
      fVar17 = (float)CONCAT22((short)(int)(fVar17 * DAT_01901f68 + DAT_018ce2f4),
                               (short)(int)((*(float *)(iVar14 + 0x20) * *(float *)(iVar14 + 0x24) +
                                            *(float *)(iVar14 + 0x1c)) * _DAT_01918c80 +
                                           DAT_018ce2f4));
      *(uint *)(*(int *)(param_1 + 4) + 0xb8) = uVar5 + 1;
      fVar23 = *(float *)(*(int *)(param_1 + 4) + 0xbc);
      uVar11 = (undefined2)(int)((float)((double)(uVar5 & 0x7f) + DAT_018c0d90) * fVar23);
      uVar12 = (undefined2)(int)((float)((double)(uVar5 >> 7) + DAT_018c0d90) * fVar23);
      *param_2 = fStack_38;
      param_2[1] = fVar19;
      param_2[2] = fVar21;
      param_2[3] = uStack_58;
      param_2[4] = fVar17;
      param_2[5] = 0.0;
      param_2[6] = (float)CONCAT13(uVar7,CONCAT12(uVar10,CONCAT11(uVar9,uVar8)));
      param_2[7] = (float)CONCAT22(uVar12,uVar11);
      param_2[8] = fStack_38;
      param_2[9] = fVar19;
      param_2[10] = fVar21;
      param_2[0xb] = uStack_58;
      param_2[0xc] = fVar17;
      param_2[0xd] = 1.4013e-45;
      param_2[0xe] = (float)CONCAT13(uVar7,CONCAT12(uVar10,CONCAT11(uVar9,uVar8)));
      param_2[0xf] = (float)CONCAT22(uVar12,uVar11);
      param_2[0x10] = fStack_38;
      param_2[0x11] = fVar19;
      param_2[0x12] = fVar21;
      param_2[0x13] = uStack_58;
      param_2[0x14] = fVar17;
      param_2[0x15] = 9.18355e-41;
      param_2[0x16] = (float)CONCAT13(uVar7,CONCAT12(uVar10,CONCAT11(uVar9,uVar8)));
      param_2[0x17] = (float)CONCAT22(uVar12,uVar11);
      param_2[0x18] = fStack_38;
      param_2[0x19] = fVar19;
      param_2[0x1a] = fVar21;
      param_2[0x1b] = uStack_58;
      param_2[0x1c] = fVar17;
      param_2[0x1d] = 9.18369e-41;
      param_2[0x1e] = (float)CONCAT13(uVar7,CONCAT12(uVar10,CONCAT11(uVar9,uVar8)));
      param_2[0x1f] = (float)CONCAT22(uVar12,uVar11);
      param_2 = param_2 + 0x20;
      fVar17 = fVar19;
      if (fStack_34 <= fVar19) {
        fVar17 = fStack_34;
      }
      if (fVar19 <= fStack_40) {
        fVar19 = fStack_40;
      }
      fVar18 = fVar21;
      if (fStack_30 <= fVar21) {
        fVar18 = fStack_30;
      }
      if (fVar21 <= fStack_3c) {
        fVar21 = fStack_3c;
      }
      fStack_44 = fStack_38;
      if (fStack_38 <= fStack_18) {
        fStack_44 = fStack_18;
      }
      if (fStack_1c <= fStack_38) {
        fStack_38 = fStack_1c;
      }
      iVar15 = iVar15 + 0x38;
      iVar16 = iVar16 + -1;
      fVar23 = fVar6;
      fStack_40 = fVar19;
      fStack_3c = fVar21;
      fStack_34 = fVar17;
      fStack_30 = fVar18;
      fStack_1c = fStack_38;
      fStack_18 = fStack_44;
    } while (iVar16 != 0);
  }
  uStack_48 = SUB42(fStack_3c,0);
  uStack_46 = (undefined2)((uint)fStack_3c >> 0x10);
  *(float *)(param_1 + 0x68c) = fStack_38;
  *(float *)(param_1 + 0x690) = fStack_34;
  *(float *)(param_1 + 0x694) = fStack_30;
  *(float *)(param_1 + 0x698) = fStack_44;
  *(ulonglong *)(param_1 + 0x69c) = CONCAT26(uStack_46,CONCAT24(uStack_48,fStack_40));
  return;
}



/* FUNCTION 12641 ; VA 0x0082d6e0 ; FUN_0082d6e0 */

void __thiscall FUN_0082d6e0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  short sVar7;
  int iVar8;
  short *psVar9;
  int *piStack_44;
  char *pcStack_38;
  int *piStack_34;
  char *pcStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6d38;
  pvStack_10 = ExceptionList;
  piStack_18 = param_1 + 3;
  if (param_1[3] == 0) {
    ExceptionList = &pvStack_10;
    piStack_1c = param_1;
    uStack_20 = FUN_01675290(DAT_01eb40cc);
    *param_1 = param_2;
    uStack_8 = 0;
    iVar3 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
    *(undefined *)(param_1 + 0x24) = *(undefined *)(iVar3 + 0x38);
    piStack_14 = *(int **)(*param_1 + 0x3c);
    piVar4 = (int *)(**(code **)(*piStack_14 + 0x3c))(&iStack_28,0,0x1f4000,0x20,1);
    iVar3 = *piVar4;
    iVar8 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    param_1[1] = iVar3;
    piVar4 = (int *)param_1[2];
    param_1[2] = iVar8;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar3 = *piVar5 + -1;
        *piVar5 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = (int *)(**(code **)(*piStack_14 + 0x3c))(&iStack_28,1,0x2ee00,2,0);
    iVar3 = *piVar4;
    iVar8 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piStack_18 = iVar3;
    piVar4 = (int *)piStack_18[1];
    piStack_18[1] = iVar8;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar5 = piVar4 + 2;
        iVar3 = *piVar5 + -1;
        *piVar5 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    iVar3 = (**(code **)(*(int *)*piStack_18 + 0x10))();
    iVar8 = 0;
    psVar9 = (short *)(iVar3 + 4);
    do {
      sVar7 = (short)iVar8 * 4;
      iVar8 = iVar8 + 1;
      psVar9[-2] = sVar7;
      *psVar9 = sVar7 + 2;
      psVar9[1] = sVar7 + 2;
      psVar9[-1] = sVar7 + 1;
      psVar9[2] = sVar7 + 1;
      psVar9[3] = sVar7 + 3;
      psVar9 = psVar9 + 6;
    } while (iVar8 < 16000);
    (**(code **)(*(int *)*piStack_18 + 0x14))();
    piVar5 = (int *)FUN_0147c1b0(&iStack_28,&DAT_01eb40d0,5,0x20);
    piVar4 = piStack_1c;
    uVar2 = uStack_20;
    iVar3 = *piVar5;
    iVar8 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    piStack_1c[5] = iVar3;
    piStack_18 = (int *)piStack_1c[6];
    piStack_1c[6] = iVar8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piVar5 = (int *)FUN_0147c0e0(&iStack_28,piVar4 + 5,piVar4 + 1,piVar4 + 3);
    iVar3 = *piVar5;
    iVar8 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    piVar4[7] = iVar3;
    piStack_18 = (int *)piVar4[8];
    piVar4[8] = iVar8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    pcStack_38 = "ParticleCurveVS";
    piStack_34 = (int *)0xf;
    pcStack_30 = "ParticleCurveAddFS";
    uStack_2c = 0x12;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[9] = iStack_28;
    piStack_18 = (int *)piVar4[10];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[10] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS";
    piStack_34 = (int *)0xf;
    pcStack_30 = "ParticleCurveModulateFS";
    uStack_2c = 0x17;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0xd] = iStack_28;
    piStack_18 = (int *)piVar4[0xe];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0xe] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS";
    piStack_34 = (int *)0xf;
    pcStack_30 = "ParticleCurveCrazyFS";
    uStack_2c = 0x14;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0x11] = iStack_28;
    piStack_18 = (int *)piVar4[0x12];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x12] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS";
    piStack_34 = (int *)0xf;
    pcStack_30 = "ParticleCurveCrazySparklesFS";
    uStack_2c = 0x1c;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0x15] = iStack_28;
    piStack_18 = (int *)piVar4[0x16];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x16] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCustomVS";
    piStack_34 = (int *)0x10;
    pcStack_30 = "ParticleCustomFS";
    uStack_2c = 0x10;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0x19] = iStack_28;
    piStack_18 = (int *)piVar4[0x1a];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x1a] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS_Soft";
    piStack_34 = (int *)0x14;
    pcStack_30 = "ParticleCurveAddFS_Soft";
    uStack_2c = 0x17;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0xb] = iStack_28;
    piStack_18 = (int *)piVar4[0xc];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0xc] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS_Soft";
    piStack_34 = (int *)0x14;
    pcStack_30 = "ParticleCurveModulateFS_Soft";
    uStack_2c = 0x1c;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0xf] = iStack_28;
    piStack_18 = (int *)piVar4[0x10];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x10] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS_Soft";
    piStack_34 = (int *)0x14;
    pcStack_30 = "ParticleCurveCrazyFS_Soft";
    uStack_2c = 0x19;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0x13] = iStack_28;
    piStack_18 = (int *)piVar4[0x14];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x14] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCurveVS";
    piStack_34 = (int *)0xf;
    pcStack_30 = "ParticleCurveCrazySparklesFS";
    uStack_2c = 0x1c;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar5 = piStack_24;
    piVar4[0x17] = iStack_28;
    piStack_18 = (int *)piVar4[0x18];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x18] = (int)piVar5;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar3 = piStack_18[2] + -1;
        piStack_18[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      piStack_18 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar3 = piStack_18[2] + -1;
          piStack_18[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    pcStack_38 = "ParticleCustomVS_Soft";
    piStack_34 = (int *)&DAT_00000015;
    pcStack_30 = "ParticleCustomFS_Soft";
    uStack_2c = 0x15;
    FUN_00790e00(&iStack_28,&pcStack_38,2);
    piVar1 = piStack_24;
    piVar4[0x1b] = iStack_28;
    piVar5 = (int *)piVar4[0x1c];
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    piVar4[0x1c] = (int)piVar1;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar3 = piVar5[2] + -1;
        piVar5[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    piVar5 = (int *)FUN_0147c180(&iStack_28,0,3,0x400,1000,3);
    iVar3 = *piVar5;
    iVar8 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    piVar4[0x1d] = iVar3;
    piVar5 = (int *)piVar4[0x1e];
    piVar4[0x1e] = iVar8;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar3 = piVar5[2] + -1;
        piVar5[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    uVar6 = FUN_0147d4b0();
    uStack_8._0_1_ = 1;
    FUN_0147d420(piVar4 + 0x1d);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piVar4 = (int *)FUN_0147bf30(&iStack_28,&pcStack_38,uVar6);
    piVar5 = piStack_1c;
    iVar3 = *piVar4;
    iVar8 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    piStack_1c[0x1f] = iVar3;
    piVar4 = (int *)piStack_1c[0x20];
    piStack_1c[0x20] = iVar8;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_34[1] + -1;
      piStack_34[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_44 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_44[1] + -1;
      piStack_44[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_44)();
        LOCK();
        piVar4 = piStack_44 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
    piVar5[0x2e] = 0;
    piVar5[0x2f] = 0x41000000;
    uStack_8 = 3;
    FUN_01675290(uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12642 ; VA 0x0082e190 ; FUN_0082e190 */

void __fastcall FUN_0082e190(int param_1)

{
  *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 12643 ; VA 0x0082e1a0 ; FUN_0082e1a0 */

void __fastcall FUN_0082e1a0(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  
  piVar2 = (int *)FUN_006cb070();
  if (-1 < *piVar2) {
    piVar2 = (int *)FUN_006cb070();
    iVar1 = *piVar2;
    *(undefined4 *)(*(int *)(param_1 + 0xac) + iVar1 * 4) =
         *(undefined4 *)(*(int *)(param_1 + 0xac) + -4 + *(int *)(param_1 + 0xb0) * 4);
    piVar2 = (int *)FUN_006cb070();
    *piVar2 = iVar1;
    FUN_0078c900(*(int *)(param_1 + 0xb0) + -1,0);
    puVar3 = (undefined4 *)FUN_006cb070();
    *puVar3 = 0xffffffff;
  }
  return;
}



/* FUNCTION 12644 ; VA 0x0082e210 ; FUN_0082e210 */

int __fastcall FUN_0082e210(int param_1)

{
  return (*(int *)(param_1 + 0xc) - *(int *)(param_1 + 8)) / 0x38;
}



/* FUNCTION 12645 ; VA 0x0082e230 ; FUN_0082e230 */

void __thiscall FUN_0082e230(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0xa4);
  if (*(undefined4 **)(param_1 + 0xa8) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 12646 ; VA 0x0082e260 ; FUN_0082e260 */

void __thiscall FUN_0082e260(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  uVar2 = param_2;
  piVar3 = (int *)FUN_006cb070();
  if (*piVar3 < 0) {
    uVar1 = *(undefined4 *)(param_1 + 0xb0);
    param_2 = uVar2;
    puVar4 = (undefined4 *)FUN_006cb070();
    *puVar4 = uVar1;
    FUN_007c5360(&param_2);
  }
  return;
}



/* FUNCTION 12647 ; VA 0x0082e2a0 ; FUN_0082e2a0 */

void __thiscall FUN_0082e2a0(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x98);
  if (*(undefined4 **)(param_1 + 0x9c) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 12648 ; VA 0x0082e2d0 ; FUN_0082e2d0 */

void __thiscall FUN_0082e2d0(int param_1,undefined4 param_2,char param_3)

{
  float *pfVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  undefined auStack_c [8];
  
  pfVar2 = (float *)(param_1 + 0x438);
  FUN_00a935e0(pfVar2,0x20,0,0x3f800000);
  iVar3 = 0;
  do {
    if (param_3 == '\0') {
      return;
    }
    pfVar1 = (float *)FUN_01163210(auStack_c);
    iVar3 = iVar3 + 1;
    fVar4 = DAT_018ce2f8 - pfVar1[1];
    *pfVar2 = DAT_018ce2f8 - *pfVar1;
    pfVar2[1] = fVar4;
    pfVar2 = pfVar2 + 2;
  } while (iVar3 < 0x20);
  return;
}



/* FUNCTION 12649 ; VA 0x0082e340 ; FUN_0082e340 */

uint __thiscall FUN_0082e340(uint param_1,uint *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint *puVar9;
  undefined auStack_90 [4];
  int *piStack_8c;
  undefined auStack_88 [4];
  int *piStack_84;
  undefined2 auStack_80 [2];
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined2 auStack_74 [2];
  undefined4 uStack_70;
  undefined2 uStack_6c;
  undefined2 auStack_68 [2];
  undefined4 uStack_64;
  undefined2 uStack_60;
  undefined2 auStack_5c [2];
  undefined4 uStack_58;
  undefined2 uStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  uint *puStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar9 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6d88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  if ((uint *)(param_1 + 0x63c) != param_2) {
    puVar3 = param_2;
    if (0xf < param_2[5]) {
      puVar3 = (uint *)*param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar3,param_2[4]);
  }
  puStack_50 = puVar9 + 6;
  uStack_30 = 0;
  *(uint *)(param_1 + 0x654) = *puStack_50;
  puStack_4c = puVar9 + 7;
  *(uint *)(param_1 + 0x658) = *puStack_4c;
  uStack_2c = 0;
  piStack_28 = *(int **)(**(int **)(param_1 + 4) + 0x4ec);
  puStack_24 = (uint *)puVar9[4];
  if (0xf < puVar9[5]) {
    puVar9 = (uint *)*puVar9;
  }
  if (puStack_24 < 0x10) {
    uStack_40 = *puVar9;
    uStack_3c = puVar9[1];
    uStack_38 = puVar9[2];
    uStack_34 = puVar9[3];
    uStack_2c = 0xf;
  }
  else {
    uVar6 = (uint)puStack_24 | 0xf;
    if (0x7fffffff < uVar6) {
      uVar6 = 0x7fffffff;
    }
    uStack_40 = FUN_00554060(uVar6 + 1);
    FUN_0170c6f0(uStack_40,puVar9,(int)puStack_24 + 1);
    param_1 = uStack_20;
    uStack_2c = uVar6;
  }
  uStack_8 = 0;
  uStack_30 = (uint)puStack_24;
  FUN_009cbbb0(&uStack_40);
  uStack_8 = 1;
  FUN_00782480(auStack_90,&uStack_40,4,param_3,0x425c0000,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar6 = uStack_40;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(uStack_40 - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (uStack_40 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = uStack_40 & 0xffffff00;
  puVar9 = (uint *)(param_1 + 0x65c);
  uStack_8 = 2;
  auStack_80[0] = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  param_2 = (uint *)CONCAT13(param_2._3_1_,4);
  param_3 = 0;
  puStack_24 = puVar9;
  while( true ) {
    *puVar9 = 0;
    piVar1 = (int *)puVar9[1];
    puVar9[1] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar2 = param_3 + *puStack_4c * 2;
    iVar8 = *(int *)(uStack_20 + 4) + 0x24;
    uVar6 = uStack_20;
    if (*(int *)(iVar8 + iVar2 * 8) == 0) goto LAB_0082e70f;
    iVar4 = FUN_01674e20(0x50);
    uStack_8._0_1_ = 3;
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_0078ded0(iVar8 + iVar2 * 8,0,0);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_48 = 0;
    uStack_44 = 0;
    FUN_007f73a0(uVar5,param_2);
    *puVar9 = uStack_48;
    piVar1 = (int *)puVar9[1];
    puVar9[1] = uStack_44;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (*puVar9 == 0) break;
    FUN_0078e530(auStack_80);
    FUN_0078e510(&param_2);
    switch(*puStack_50) {
    case 0:
      uStack_18 = 0x100;
      break;
    case 1:
      uStack_18 = 0x60000;
      break;
    case 2:
      uStack_18 = 0x60102;
      break;
    case 3:
      uStack_18 = 0x60403;
      break;
    case 4:
      uStack_18 = 0x60400;
      break;
    case 5:
      uStack_18 = 0x60003;
      break;
    default:
      uStack_18 = 0x1000100;
    }
    uStack_1c = 0xf;
    uStack_14 = 0;
    FUN_0078e480(&uStack_1c);
    auStack_5c[0] = 0x101;
    uStack_58 = 0;
    uStack_54 = 0;
    FUN_0078e550(0,auStack_90,auStack_5c);
    auStack_68[0] = 0x101;
    uStack_64 = 0;
    uStack_60 = 0;
    FUN_007735a0(*(int *)(uStack_20 + 4) + 0x74,3);
    uStack_8._0_1_ = 4;
    FUN_0078e550(2,auStack_88,auStack_68);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_28 = piStack_84;
    if (piStack_84 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_84[1] + -1;
      piStack_84[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_84)();
        LOCK();
        iVar2 = piStack_28[2] + -1;
        piStack_28[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    auStack_74[0] = 0x101;
    uStack_70 = 0;
    uStack_6c = 0;
    FUN_0078e550(0xf,*(int *)(*(int *)(**(int **)(uStack_20 + 4) + 0x4f8) + 0x44c) + 0x84,auStack_74
                );
    puVar9 = puVar9 + 2;
    uVar6 = param_3 + 1;
    param_3 = uVar6;
    if (1 < uVar6) {
LAB_0082e70f:
      if (piStack_8c != (int *)0x0) {
        LOCK();
        puVar9 = (uint *)(piStack_8c + 1);
        uVar7 = *puVar9;
        uVar6 = *puVar9;
        *puVar9 = uVar7 - 1;
        UNLOCK();
        if (uVar7 - 1 == 0) {
          uVar6 = (**(code **)*piStack_8c)();
          LOCK();
          piVar1 = piStack_8c + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            uVar6 = (**(code **)(*piStack_8c + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  uVar7 = puStack_24[1];
  if (uVar7 != 0) {
    LOCK();
    *(int *)(uVar7 + 4) = *(int *)(uVar7 + 4) + 1;
    UNLOCK();
    uVar7 = puStack_24[1];
  }
  uVar6 = *puStack_24;
  *(uint *)(uStack_20 + 0x65c + param_3 * 8) = uVar6;
  piVar1 = *(int **)(uStack_20 + 0x660 + param_3 * 8);
  *(uint *)(uStack_20 + 0x660 + param_3 * 8) = uVar7;
  if (piVar1 != (int *)0x0) {
    LOCK();
    puVar9 = (uint *)(piVar1 + 1);
    uVar7 = *puVar9;
    uVar6 = *puVar9;
    *puVar9 = uVar7 - 1;
    UNLOCK();
    if (uVar7 - 1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      puVar9 = (uint *)(piVar1 + 2);
      uVar7 = *puVar9;
      uVar6 = *puVar9;
      *puVar9 = uVar7 - 1;
      UNLOCK();
      if (uVar7 - 1 == 0) {
        uVar6 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  goto LAB_0082e70f;
}



/* FUNCTION 12650 ; VA 0x0082e7d0 ; FUN_0082e7d0 */

void __fastcall FUN_0082e7d0(int param_1)

{
  FUN_00a91b00(param_1 + 0x138,param_1 + 0x2b8,0x20);
  return;
}



/* FUNCTION 12651 ; VA 0x0082e7f0 ; FUN_0082e7f0 */

void __thiscall FUN_0082e7f0(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar2 = 0.0;
  if (0.0 <= param_2) {
    fVar2 = param_2;
  }
  fVar1 = DAT_018e3fa0;
  if (fVar2 <= DAT_018e3fa0) {
    fVar1 = fVar2;
  }
  *(float *)(param_1 + 0x9c) = fVar1;
  return;
}



/* FUNCTION 12652 ; VA 0x0082e820 ; FUN_0082e820 */

void __thiscall FUN_0082e820(int param_1,float param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar2 = param_3;
  if (param_2 <= param_3) {
    fVar2 = param_2;
  }
  if (param_3 <= param_2) {
    param_3 = param_2;
  }
  fVar1 = 0.0;
  if (0.0 <= fVar2) {
    fVar1 = fVar2;
  }
  fVar2 = 0.0;
  if (0.0 <= param_3) {
    fVar2 = param_3;
  }
  fVar3 = DAT_019011dc;
  if (fVar1 <= DAT_019011dc) {
    fVar3 = fVar1;
  }
  fVar1 = DAT_019011dc;
  if (fVar2 <= DAT_019011dc) {
    fVar1 = fVar2;
  }
  *(float *)(param_1 + 0x90) = fVar3;
  *(float *)(param_1 + 0x94) = fVar1;
  return;
}



/* FUNCTION 12653 ; VA 0x0082e870 ; FUN_0082e870 */

void __fastcall FUN_0082e870(int param_1)

{
  float fVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  
  *(undefined4 *)(param_1 + 0x638) = 0;
  FUN_00a935e0(param_1 + 0x538,0x20,0,(float)DAT_01d621bc);
  fVar4 = *(float *)(param_1 + 0x638);
  pfVar2 = (float *)(param_1 + 0x53c);
  iVar3 = 0x20;
  do {
    fVar1 = *pfVar2;
    if (*pfVar2 <= fVar4) {
      fVar1 = fVar4;
    }
    fVar4 = fVar1;
    pfVar2 = pfVar2 + 2;
    *(float *)(param_1 + 0x638) = fVar4;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  *(undefined *)(param_1 + 0x134) = 1;
  return;
}



/* FUNCTION 12654 ; VA 0x0082e8f0 ; FUN_0082e8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0082e8f0(int param_1,float param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  float *pfVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  char cVar20;
  int iVar21;
  float10 fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  double dVar26;
  float fVar27;
  uint uStack_2c;
  uint uStack_28;
  
  iVar6 = **(int **)(param_1 + 4);
  fVar22 = (float10)FUN_01156c80();
  fVar27 = DAT_018e452c;
  if (DAT_018e452c <= (float)fVar22) {
    fVar27 = (float)fVar22;
  }
  fVar23 = *(float *)(iVar6 + 0x40) - *(float *)(param_1 + 0x38);
  fVar24 = *(float *)(iVar6 + 0x44) - *(float *)(param_1 + 0x3c);
  fVar25 = *(float *)(iVar6 + 0x48) - *(float *)(param_1 + 0x40);
  iVar21 = FUN_0082c170();
  dVar26 = (double)(fVar23 * fVar23 + fVar24 * fVar24 + fVar25 * fVar25);
  FUN_017267a0();
  piVar1 = (int *)(param_1 + 8);
  fVar24 = DAT_018ce2f8 - ((float)dVar26 - DAT_01901960) / _DAT_01918c7c;
  fVar23 = 0.0;
  if (0.0 <= fVar24) {
    fVar23 = fVar24;
  }
  fVar24 = DAT_018ce2f8;
  if (fVar27 <= DAT_018ce2f8) {
    fVar24 = fVar27;
  }
  fVar27 = DAT_018ce2f8;
  if (fVar23 <= DAT_018ce2f8) {
    fVar27 = fVar23;
  }
  *(float *)(param_1 + 0x8c) =
       fVar27 * *(float *)(param_1 + 0x9c) * param_2 * fVar24 +
       (*(float *)(param_1 + 0x8c) - (float)iVar21);
  if (*piVar1 != *(int *)(param_1 + 0xc)) {
    FUN_0082ecb0(*piVar1,(*(int *)(param_1 + 0xc) - *piVar1) / 0x38,param_2);
    uStack_2c = 0;
    uStack_28 = (*(int *)(param_1 + 0xc) - *piVar1) / 0x38;
    if (uStack_28 != 0) {
      iVar21 = 0;
      do {
        iVar7 = *piVar1;
        pfVar3 = (float *)(iVar7 + 0x24 + iVar21);
        if (((*pfVar3 <= DAT_018f784c && DAT_018f784c != *pfVar3) ||
            (pfVar3 = (float *)(iVar7 + 0x2c + iVar21), *pfVar3 <= 0.0 && *pfVar3 != 0.0)) ||
           (pfVar3 = (float *)(iVar7 + 0x30 + iVar21), *pfVar3 <= 0.0 && *pfVar3 != 0.0)) {
          iVar8 = (*(int *)(param_1 + 0xc) - iVar7) / 0x38;
          if (iVar8 == 0) {
            uStack_28 = 0;
          }
          else {
            uStack_28 = iVar8 - 1;
            puVar2 = (undefined4 *)(iVar7 + uStack_28 * 0x38);
            uVar9 = puVar2[1];
            uVar10 = puVar2[2];
            uVar11 = puVar2[3];
            puVar4 = (undefined4 *)(iVar7 + 0x10 + uStack_28 * 0x38);
            uVar12 = *puVar4;
            uVar13 = puVar4[1];
            uVar14 = puVar4[2];
            uVar15 = puVar4[3];
            puVar4 = (undefined4 *)(iVar7 + 0x20 + uStack_28 * 0x38);
            uVar16 = *puVar4;
            uVar17 = puVar4[1];
            uVar18 = puVar4[2];
            uVar19 = puVar4[3];
            uVar5 = *(undefined8 *)(iVar7 + 0x30 + uStack_28 * 0x38);
            puVar4 = (undefined4 *)(iVar7 + iVar21);
            *puVar4 = *puVar2;
            puVar4[1] = uVar9;
            puVar4[2] = uVar10;
            puVar4[3] = uVar11;
            puVar2 = (undefined4 *)(iVar7 + 0x10 + iVar21);
            *puVar2 = uVar12;
            puVar2[1] = uVar13;
            puVar2[2] = uVar14;
            puVar2[3] = uVar15;
            puVar2 = (undefined4 *)(iVar7 + 0x20 + iVar21);
            *puVar2 = uVar16;
            puVar2[1] = uVar17;
            puVar2[2] = uVar18;
            puVar2[3] = uVar19;
            *(undefined8 *)(iVar7 + 0x30 + iVar21) = uVar5;
            FUN_0082b320();
          }
        }
        else {
          fVar27 = (*(float *)(iVar7 + 8 + iVar21) - *(float *)(iVar6 + 0x44)) *
                   *(float *)(iVar6 + 0x54) +
                   (*(float *)(iVar7 + 4 + iVar21) - *(float *)(iVar6 + 0x40)) *
                   *(float *)(iVar6 + 0x50) +
                   (*(float *)(iVar7 + 0xc + iVar21) - *(float *)(iVar6 + 0x48)) *
                   *(float *)(iVar6 + 0x58);
          cVar20 = FUN_00c94350();
          if (cVar20 != '\0') {
            fVar27 = 0.0;
          }
          *(float *)(iVar21 + *piVar1) = fVar27;
          uStack_2c = uStack_2c + 1;
          iVar21 = iVar21 + 0x38;
        }
      } while (uStack_2c < uStack_28);
    }
    uVar12 = _UNK_018c4ebc;
    uVar11 = _UNK_018c4eb8;
    uVar10 = _UNK_018c4eb4;
    uVar9 = DAT_018c45d0;
    if (*piVar1 == *(int *)(param_1 + 0xc)) {
      *(undefined4 *)(param_1 + 0x68c) = _DAT_018c4eb0;
      *(undefined4 *)(param_1 + 0x690) = uVar10;
      *(undefined4 *)(param_1 + 0x694) = uVar11;
      *(undefined4 *)(param_1 + 0x698) = uVar12;
      *(ulonglong *)(param_1 + 0x69c) = CONCAT44(uVar9,uVar9);
    }
  }
  *(undefined4 *)(param_1 + 0x44) = *(undefined4 *)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_1 + 0x1c);
  *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_1 + 0x20);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_1 + 0x24);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x2c);
  *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x30);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 0x34);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_1 + 0x38);
  *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x3c);
  *(undefined4 *)(param_1 + 0x70) = *(undefined4 *)(param_1 + 0x40);
  return;
}



/* FUNCTION 12655 ; VA 0x0082ecb0 ; FUN_0082ecb0 */

void __thiscall
FUN_0082ecb0(int param_1,int param_2,int param_3,float param_4,undefined8 param_5,float param_6)

{
  float fVar1;
  float fVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uStack_30;
  float fStack_28;
  
  uStack_30 = param_5;
  fStack_28 = param_6;
  if (*(char *)(param_1 + 0x124) != '\0') {
    fVar1 = *(float *)(param_1 + 0xd8);
    fVar2 = *(float *)(param_1 + 0xd4);
    fVar4 = *(float *)(param_1 + 0xdc);
    fVar5 = *(float *)(param_1 + 200);
    fVar6 = *(float *)(param_1 + 0xd0);
    fVar8 = *(float *)(param_1 + 0xcc);
    fStack_28 = fVar8 * *(float *)(param_1 + 0x30) + fVar5 * *(float *)(param_1 + 0x2c) +
                fVar6 * *(float *)(param_1 + 0x34) +
                fVar1 * *(float *)(param_1 + 0x30) + *(float *)(param_1 + 0x2c) * fVar2 +
                fVar4 * *(float *)(param_1 + 0x34);
    uStack_30 = CONCAT44(fVar8 * *(float *)(param_1 + 0x24) + fVar5 * *(float *)(param_1 + 0x20) +
                         fVar6 * *(float *)(param_1 + 0x28) +
                         fVar1 * *(float *)(param_1 + 0x24) + *(float *)(param_1 + 0x20) * fVar2 +
                         fVar4 * *(float *)(param_1 + 0x28),
                         fVar8 * *(float *)(param_1 + 0x18) + fVar5 * *(float *)(param_1 + 0x14) +
                         fVar6 * *(float *)(param_1 + 0x1c) +
                         fVar1 * *(float *)(param_1 + 0x18) + *(float *)(param_1 + 0x14) * fVar2 +
                         fVar4 * *(float *)(param_1 + 0x1c));
  }
  fVar4 = param_4 * DAT_018ce2f4 * param_4;
  fVar1 = *(float *)(param_1 + 0x104);
  fVar2 = *(float *)(param_1 + 0x108);
  dVar7 = DAT_018ce308;
  FUN_01726ab0();
  fVar5 = (float)dVar7;
  if (param_3 != 0) {
    pfVar3 = (float *)(param_2 + 0xc);
    do {
      fVar6 = pfVar3[6] - param_4;
      if (fVar6 < 0.0) {
        fVar6 = 0.0;
      }
      pfVar3[6] = fVar6;
      if (*(char *)(param_1 + 0x124) != '\0') {
        fVar6 = pfVar3[2];
        fVar8 = pfVar3[1];
        fVar9 = pfVar3[3];
        fVar12 = *(float *)(param_1 + 0x48) * fVar8 + fVar6 * *(float *)(param_1 + 0x54) +
                 *(float *)(param_1 + 0x60) * fVar9;
        fVar11 = *(float *)(param_1 + 0x50) * fVar6 + fVar8 * *(float *)(param_1 + 0x44) +
                 fVar9 * *(float *)(param_1 + 0x5c);
        fVar10 = *(float *)(param_1 + 0x58) * fVar6 + fVar8 * *(float *)(param_1 + 0x4c) +
                 *(float *)(param_1 + 100) * fVar9;
        fVar6 = *(float *)(param_1 + 0x30);
        fVar8 = *(float *)(param_1 + 0x2c);
        fVar9 = *(float *)(param_1 + 0x34);
        *(ulonglong *)(pfVar3 + 1) =
             CONCAT44(fVar12 * *(float *)(param_1 + 0x24) + fVar11 * *(float *)(param_1 + 0x20) +
                      fVar10 * *(float *)(param_1 + 0x28),
                      fVar11 * *(float *)(param_1 + 0x14) + fVar12 * *(float *)(param_1 + 0x18) +
                      *(float *)(param_1 + 0x1c) * fVar10);
        pfVar3[3] = fVar12 * fVar6 + fVar11 * fVar8 + fVar9 * fVar10;
        fVar9 = pfVar3[-2] - *(float *)(param_1 + 0x68);
        fVar6 = pfVar3[-1] - *(float *)(param_1 + 0x6c);
        fVar8 = *pfVar3 - *(float *)(param_1 + 0x70);
        fVar13 = *(float *)(param_1 + 0x44) * fVar9 + *(float *)(param_1 + 0x50) * fVar6 +
                 fVar8 * *(float *)(param_1 + 0x5c);
        fVar12 = *(float *)(param_1 + 0x48) * fVar9 + fVar6 * *(float *)(param_1 + 0x54) +
                 *(float *)(param_1 + 0x60) * fVar8;
        fVar11 = *(float *)(param_1 + 0x58) * fVar6 + fVar9 * *(float *)(param_1 + 0x4c) +
                 *(float *)(param_1 + 100) * fVar8;
        fVar6 = *(float *)(param_1 + 0x30);
        fVar8 = *(float *)(param_1 + 0x2c);
        fVar9 = *(float *)(param_1 + 0x34);
        fVar10 = *(float *)(param_1 + 0x40);
        *(ulonglong *)(pfVar3 + -2) =
             CONCAT44(*(float *)(param_1 + 0x24) * fVar12 + *(float *)(param_1 + 0x20) * fVar13 +
                      *(float *)(param_1 + 0x28) * fVar11 + *(float *)(param_1 + 0x3c),
                      *(float *)(param_1 + 0x18) * fVar12 + *(float *)(param_1 + 0x14) * fVar13 +
                      *(float *)(param_1 + 0x1c) * fVar11 + *(float *)(param_1 + 0x38));
        *pfVar3 = fVar6 * fVar12 + fVar8 * fVar13 + fVar9 * fVar11 + fVar10;
      }
      pfVar3[-2] = pfVar3[1] * param_4 + (float)uStack_30 * fVar4 + pfVar3[-2];
      pfVar3[-1] = pfVar3[2] * param_4 + uStack_30._4_4_ * fVar4 + pfVar3[-1];
      *pfVar3 = pfVar3[3] * param_4 + fStack_28 * fVar4 + *pfVar3;
      pfVar3[1] = (pfVar3[1] + (float)uStack_30 * param_4) * fVar5;
      pfVar3[2] = (uStack_30._4_4_ * param_4 + pfVar3[2]) * fVar5;
      pfVar3[3] = (fStack_28 * param_4 + pfVar3[3]) * fVar5;
      pfVar3[8] = fVar1 * param_4 + pfVar3[8];
      pfVar3[9] = fVar2 * param_4 + pfVar3[9];
      pfVar3 = pfVar3 + 0xe;
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 12656 ; VA 0x0082f190 ; FUN_0082f190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0082f190(int *param_1,uint param_2,int *param_3)

{
  char *pcVar1;
  float fVar2;
  uint3 uVar3;
  ulonglong uVar4;
  int *piVar5;
  undefined uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  undefined4 auStack_454 [212];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  int iStack_90;
  undefined4 uStack_8c;
  int iStack_88;
  int *piStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined2 auStack_68 [2];
  undefined4 uStack_64;
  undefined uStack_60;
  int iStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  char *pcStack_40;
  float fStack_3c;
  undefined8 uStack_38;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  float fStack_20;
  int *piStack_1c;
  uint uStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6e07;
  pvStack_10 = ExceptionList;
  if (param_1[0x25] != param_1[0x26]) {
    iStack_24 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    piStack_1c = param_1;
    if ((*(int *)(iStack_24 + 0x34) < DAT_01eb4140) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4140), DAT_01eb4140 == -1)) {
      uStack_8 = 0;
      uVar14 = FUN_0152dab0("Render","updateParticles",0xffffffff);
      DAT_01eb413c = (undefined4)((ulonglong)uVar14 >> 0x20);
      DAT_01eb4138 = (undefined4)uVar14;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb4140);
    }
    uStack_54 = DAT_01eb4138;
    uStack_78 = DAT_01eb4138;
    uStack_50 = DAT_01eb413c;
    uStack_74 = DAT_01eb413c;
    uStack_70 = FUN_0152d930(DAT_01eb4138,DAT_01eb413c);
    uStack_8 = 1;
    uVar7 = FUN_01675290(DAT_01eb40cc);
    uStack_8._0_1_ = 2;
    uStack_30 = uVar7;
    iStack_28 = (**(code **)(*(int *)param_1[1] + 0x10))();
    if (iStack_28 != 0) {
      piStack_2c = (int *)param_1[0x26];
      piVar10 = (int *)param_1[0x25];
      uStack_18 = 0;
      pcStack_14 = (char *)0xfa00;
      if (piVar10 != piStack_2c) {
        uVar11 = 0;
        do {
          iVar8 = *piVar10;
          fStack_20 = (float)*(double *)(**(int **)(iVar8 + 4) + 0x18);
          if (*(char *)(*(int *)(**(int **)(iVar8 + 4) + 0x510) + 0x2c) == '\0') {
            fVar2 = DAT_01918c68;
            if (fStack_20 <= DAT_01918c68) {
              fVar2 = fStack_20;
            }
            FUN_0082e8f0(fVar2);
          }
          else if (0.0 < fStack_20) {
            do {
              FUN_0082e8f0(0x3c83126f);
              fStack_20 = fStack_20 - _DAT_01918c64;
            } while (DAT_018ce2f0 < fStack_20);
          }
          if ((*(int *)(iVar8 + 8) != *(int *)(iVar8 + 0xc)) &&
             (iVar9 = (*(int *)(iVar8 + 0xc) - *(int *)(iVar8 + 8)) / 0x38,
             pcVar1 = (char *)(iVar9 * 4), pcVar1 < pcStack_14 || (int)pcVar1 - (int)pcStack_14 == 0
             )) {
            FUN_0082b430(*(undefined4 *)(iVar8 + 8),*(undefined4 *)(iVar8 + 0xc),iVar9,param_2);
            FUN_0082d1e0(uVar11 * 0x20 + iStack_28,pcStack_14);
            iVar9 = (*(int *)(iVar8 + 0xc) - *(int *)(iVar8 + 8)) / 0x38;
            iVar8 = iVar9 * 4;
            if (iVar8 != 0) {
              FUN_0082fbd0(param_2,uVar11,iVar8);
              uVar11 = uStack_18 + iVar8;
              pcStack_14 = pcStack_14 + iVar9 * -4;
              uStack_18 = uVar11;
            }
          }
          piVar10 = piVar10 + 1;
          uVar7 = uStack_30;
        } while (piVar10 != piStack_2c);
      }
      uVar11 = uStack_18;
      param_1 = piStack_1c;
      (**(code **)(*(int *)piStack_1c[1] + 0x14))();
      iVar8 = FUN_01156c60();
      param_1[0x2e] = 0;
      if (8 < iVar8) {
        iVar8 = 8;
      }
      param_1[0x2f] = (int)(float)iVar8;
      if (uVar11 != 0) {
        pcStack_40 = "ParticleLightingVS";
        fStack_3c = 2.52234e-44;
        uStack_38._0_4_ = "ParticleLightingFS";
        uStack_38._4_4_ = 0x12;
        FUN_00790e00(&iStack_5c,&pcStack_40,2);
        iVar8 = iStack_24;
        uStack_8._0_1_ = 5;
        if (iStack_5c != 0) {
          if (*(int *)(iStack_24 + 0x34) < DAT_01eb4150) {
            FUN_016f3809(&DAT_01eb4150);
            if (DAT_01eb4150 == -1) {
              uStack_8._0_1_ = 6;
              uVar14 = FUN_0152dab0("Render","ParticleLighting",0xffffffff);
              DAT_01eb414c = (float)((ulonglong)uVar14 >> 0x20);
              DAT_01eb4148 = (char *)uVar14;
              uStack_8._0_1_ = 5;
              FUN_016f37bf(&DAT_01eb4150);
            }
          }
          pcStack_14 = DAT_01eb4148;
          pcStack_40 = DAT_01eb4148;
          fStack_20 = DAT_01eb414c;
          fStack_3c = DAT_01eb414c;
          uStack_38 = FUN_0152d930(DAT_01eb4148,DAT_01eb414c);
          uStack_8._0_1_ = 7;
          uVar6 = (undefined)uStack_8;
          uStack_8._0_1_ = 7;
          if (*(int *)(iVar8 + 0x34) < DAT_01eb4160) {
            uStack_8._0_1_ = uVar6;
            FUN_016f3809(&DAT_01eb4160);
            if (DAT_01eb4160 == -1) {
              uStack_8._0_1_ = 8;
              uVar14 = FUN_0152dab0(&DAT_018fb928,"ParticleLighting",0xffffffff);
              DAT_01eb415c = (int *)((ulonglong)uVar14 >> 0x20);
              DAT_01eb4158 = (int)uVar14;
              uStack_8._0_1_ = 7;
              FUN_016f37bf(&DAT_01eb4160);
            }
          }
          iStack_28 = DAT_01eb4158;
          iStack_88 = DAT_01eb4158;
          piStack_2c = DAT_01eb415c;
          piStack_84 = DAT_01eb415c;
          uStack_80 = FUN_0152d930(DAT_01eb4158,DAT_01eb415c);
          uVar4 = (ulonglong)uStack_80 >> 0x20;
          uStack_8._0_1_ = 9;
          iVar8 = *piStack_1c;
          puVar12 = (undefined4 *)(*(int *)(iVar8 + 0x4f8) + 0x54);
          puVar13 = auStack_454;
          for (iVar9 = 0xd4; iVar9 != 0; iVar9 = iVar9 + -1) {
            *puVar13 = *puVar12;
            puVar12 = puVar12 + 1;
            puVar13 = puVar13 + 1;
          }
          FUN_007ce460(iVar8 + 0x284);
          piVar5 = piStack_1c;
          uStack_98 = 0x3a800000;
          uStack_b8 = 0;
          uStack_b4 = 0;
          uStack_b0 = 0;
          uStack_ac = 0;
          uStack_94 = 0x3a83126f;
          uStack_a8 = 0;
          uStack_a4 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uStack_8c = 0;
          iStack_90 = piStack_1c[0x2f];
          FUN_0147bca0();
          piVar10 = param_3;
          uStack_104 = 1;
          uStack_100 = _DAT_018f99a0;
          uStack_fc = _UNK_018f99a4;
          uStack_f8 = _UNK_018f99a8;
          uStack_f4 = _UNK_018f99ac;
          (**(code **)(*param_3 + 0x14))(piVar5[0x1f],0,1,&uStack_104,0);
          FUN_0078a340(piVar10,0);
          uVar3 = (uint3)param_2;
          param_2 = (uint)(uVar3 & 0xff);
          uStack_48 = 0x1000100;
          uStack_4c = 0xf;
          uStack_44 = 0;
          auStack_68[0] = 0;
          uStack_64 = 0;
          uStack_60 = 0;
          (**(code **)(*piVar10 + 0x3c))(auStack_68,&uStack_4c,(int)&param_2 + 1);
          (**(code **)(*piVar10 + 0x24))(iStack_5c);
          (**(code **)(*piVar10 + 0x30))(0,auStack_454,0x350);
          (**(code **)(*piVar10 + 0x30))(1,&uStack_b8,0x30);
          uVar11 = uStack_18;
          (**(code **)(*piVar10 + 0x40))(piStack_1c[7],0,0,0,(uStack_18 >> 2) * 6,0);
          (**(code **)(*piVar10 + 0x18))();
          uStack_8._0_1_ = 10;
          FUN_0152dda0(iStack_28,piStack_2c,(undefined4)uStack_80,(int)uVar4);
          uStack_8._0_1_ = 0xb;
          FUN_0152dda0(pcStack_14,fStack_20,uStack_38);
          param_1 = piStack_1c;
          uVar7 = uStack_30;
        }
        uStack_8._0_1_ = 2;
        param_3 = piStack_58;
        if (piStack_58 != (int *)0x0) {
          LOCK();
          iVar8 = piStack_58[1] + -1;
          piStack_58[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_58)();
            LOCK();
            iVar8 = param_3[2] + -1;
            param_3[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*param_3 + 4))();
            }
          }
        }
      }
      if (*(int *)(iStack_24 + 0x34) < DAT_01eb4170) {
        FUN_016f3809(&DAT_01eb4170);
        if (DAT_01eb4170 == -1) {
          uStack_8._0_1_ = 0xc;
          uVar14 = FUN_0152da50("Render");
          DAT_01eb416c = (undefined4)((ulonglong)uVar14 >> 0x20);
          DAT_01eb4168 = (undefined4)uVar14;
          uStack_8._0_1_ = 2;
          FUN_016f37bf(&DAT_01eb4170);
        }
      }
      FUN_0152d760(DAT_01eb4168,DAT_01eb416c,"Emitters: %d",param_1[0x26] - param_1[0x25] >> 2);
      if (*(int *)(iStack_24 + 0x34) < DAT_01eb4180) {
        FUN_016f3809(&DAT_01eb4180);
        if (DAT_01eb4180 == -1) {
          uStack_8._0_1_ = 0xd;
          uVar14 = FUN_0152da50("Render");
          DAT_01eb417c = (undefined4)((ulonglong)uVar14 >> 0x20);
          DAT_01eb4178 = (undefined4)uVar14;
          uStack_8._0_1_ = 2;
          FUN_016f37bf(&DAT_01eb4180);
        }
      }
      FUN_0152d760(DAT_01eb4178,DAT_01eb417c,"Particles: %d",uVar11 >> 2);
    }
    param_1[0x26] = param_1[0x25];
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    FUN_01675290(uVar7);
    uStack_8 = 0xf;
    FUN_0152dda0(uStack_54,uStack_50,uStack_70);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12657 ; VA 0x0082f870 ; FUN_0082f870 */

void __fastcall FUN_0082f870(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6e34;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xa0) != *(int *)(param_1 + 0xa4)) {
    ExceptionList = &pvStack_10;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4190) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eb4190);
      if (DAT_01eb4190 == -1) {
        uStack_8 = 0;
        uVar6 = FUN_0152dab0("Render","updateParticleBoundings",0xffffffff);
        DAT_01eb418c = (undefined4)((ulonglong)uVar6 >> 0x20);
        DAT_01eb4188 = (undefined4)uVar6;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eb4190);
      }
    }
    uVar2 = DAT_01eb418c;
    uVar1 = DAT_01eb4188;
    uVar6 = FUN_0152d930(DAT_01eb4188,DAT_01eb418c);
    puVar4 = *(undefined4 **)(param_1 + 0xa0);
    uVar5 = 0;
    uStack_8 = 1;
    uVar3 = (uint)((int)*(undefined4 **)(param_1 + 0xa4) + (3 - (int)puVar4)) >> 2;
    if (*(undefined4 **)(param_1 + 0xa4) < puVar4) {
      uVar3 = 0;
    }
    if (uVar3 != 0) {
      do {
        (**(code **)(*(int *)*puVar4 + 0xc))();
        uVar5 = uVar5 + 1;
        puVar4 = puVar4 + 1;
      } while (uVar5 != uVar3);
    }
    *(undefined4 *)(param_1 + 0xa4) = *(undefined4 *)(param_1 + 0xa0);
    uStack_8 = 2;
    FUN_0152dda0(uVar1,uVar2,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12658 ; VA 0x0082f9c0 ; FUN_0082f9c0 */

void __fastcall FUN_0082f9c0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6e60;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xb0) != 0) {
    iVar4 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    if ((*(int *)(iVar4 + 0x34) < DAT_01eb41a0) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb41a0), DAT_01eb41a0 == -1)) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0("Render","Emitter estimated boundings",0xffffffff);
      DAT_01eb419c = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01eb4198 = (undefined4)uVar8;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb41a0);
    }
    uVar2 = DAT_01eb419c;
    uVar1 = DAT_01eb4198;
    uVar8 = FUN_0152d930(DAT_01eb4198,DAT_01eb419c);
    puVar3 = *(undefined4 **)(param_1 + 0xac);
    uVar6 = 0;
    uStack_8 = 1;
    uVar5 = *(int *)(param_1 + 0xb0) * 4 + 3U >> 2;
    if (puVar3 + *(int *)(param_1 + 0xb0) < puVar3) {
      uVar5 = 0;
    }
    if (uVar5 != 0) {
      do {
        (**(code **)(*(int *)*puVar3 + 0x10))();
        uVar6 = uVar6 + 1;
        puVar3 = puVar3 + 1;
      } while (uVar6 != uVar5);
    }
    if ((*(int *)(iVar4 + 0x34) < DAT_01eb41b0) && (FUN_016f3809(&DAT_01eb41b0), DAT_01eb41b0 == -1)
       ) {
      uStack_8._0_1_ = 2;
      uVar9 = FUN_0152da50("Render");
      DAT_01eb41ac = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eb41a8 = (undefined4)uVar9;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb41b0);
    }
    FUN_0152d760(DAT_01eb41a8,DAT_01eb41ac,"Emitters: %d",*(undefined4 *)(param_1 + 0xb0));
    iVar4 = *(int *)(param_1 + 0xb0);
    iVar7 = 0;
    if (0 < iVar4) {
      do {
        puVar3 = (undefined4 *)FUN_006cb070();
        iVar7 = iVar7 + 1;
        *puVar3 = 0xffffffff;
        iVar4 = *(int *)(param_1 + 0xb0);
      } while (iVar7 < iVar4);
    }
    if (iVar4 != 0) {
      *(undefined4 *)(param_1 + 0xb0) = 0;
      if (*(int *)(param_1 + 0xb4) < 0) {
        if (*(int *)(param_1 + 0xb4) == 0) {
          *(undefined4 *)(param_1 + 0xb4) = 0;
        }
        else {
          *(undefined4 *)(param_1 + 0xb4) = 10;
        }
        FUN_0078c480(iVar4);
      }
    }
    uStack_8 = 3;
    FUN_0152dda0(uVar1,uVar2,uVar8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12659 ; VA 0x0082fbd0 ; FUN_0082fbd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0082fbd0(uint param_1,int param_2,uint param_3,uint param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint *puVar4;
  char cVar5;
  byte bVar6;
  float *pfVar7;
  int *piVar8;
  int *piVar9;
  int iVar10;
  float10 fVar11;
  float fVar12;
  float fVar13;
  double dVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  float fStack_44;
  float fStack_40;
  undefined4 uStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  float fStack_c;
  
  iVar2 = **(int **)(param_1 + 4);
  cVar5 = FUN_01156450();
  if ((cVar5 == '\0') || (*(int *)(param_1 + 0x664) == 0)) {
    bVar6 = 0;
  }
  else {
    bVar6 = 1;
  }
  uVar3 = *(uint *)(param_1 + 0x65c + (uint)bVar6 * 8);
  if (uVar3 != 0) {
    fVar11 = (float10)FUN_01156c80();
    fVar12 = DAT_018e452c;
    if (DAT_018e452c <= (float)fVar11) {
      fVar12 = (float)fVar11;
    }
    uVar1 = *(undefined4 *)(*(int *)(param_1 + 4) + 0xbc);
    fVar13 = *(float *)(param_1 + 0x66c);
    fVar15 = DAT_018ce2f8;
    if (fVar12 <= DAT_018ce2f8) {
      fVar15 = fVar12;
    }
    pfVar7 = (float *)FUN_01165820(&uStack_50,fVar15);
    fStack_38 = (*pfVar7 - *(float *)(param_1 + 0x678)) * fVar13 + *(float *)(param_1 + 0x678);
    fStack_2c = (pfVar7[3] - *(float *)(param_1 + 0x684)) * fVar13 + *(float *)(param_1 + 0x684);
    fStack_34 = (pfVar7[1] - *(float *)(param_1 + 0x67c)) * fVar13 + *(float *)(param_1 + 0x67c);
    fStack_30 = (pfVar7[2] - *(float *)(param_1 + 0x680)) * fVar13 + *(float *)(param_1 + 0x680);
    uStack_28 = *(undefined4 *)(param_1 + 0x688);
    uStack_24 = *(undefined4 *)(param_1 + 0x670);
    fStack_20 = _DAT_01918c90;
    fStack_1c = _UNK_01918c94;
    uStack_18 = _UNK_01918c98;
    uStack_14 = _UNK_01918c9c;
    dVar14 = (double)*(float *)(param_1 + 0x674);
    uStack_10 = uVar1;
    FUN_017267a0();
    fStack_c = (float)dVar14;
    if (bVar6 != 0) {
      piVar8 = (int *)FUN_00798fd0();
      uStack_50 = uStack_50 & 0xffff0000;
      uStack_4c = 0;
      uStack_48 = uStack_48 & 0xffff0000;
      FUN_0078e550(3,piVar8,&uStack_50);
      fStack_1c = DAT_018ce2f4;
      if (*piVar8 == 0) {
        piVar9 = &DAT_01eb1b0c;
      }
      else {
        piVar9 = (int *)(*piVar8 + 0xc);
      }
      iVar10 = (uint)(*piVar9 == 0) + *piVar9;
      fStack_20 = DAT_018ce2f4 /
                  (float)((double)iVar10 + (double)(&DAT_018c0d90)[-(iVar10 >> 0x1f)]);
      if (*piVar8 == 0) {
        piVar8 = &DAT_01eb1b10;
      }
      else {
        piVar8 = (int *)(*piVar8 + 0x10);
      }
      iVar10 = (uint)(*piVar8 == 0) + *piVar8;
      *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | 4;
      fStack_1c = fStack_1c / (float)((double)iVar10 + (double)(&DAT_018c0d90)[-(iVar10 >> 0x1f)]);
    }
    FUN_0078e4a0(1,&fStack_38,0x30);
    fVar12 = DAT_01918c84 - *(float *)(param_1 + 0x688);
    *(uint *)(param_1 + 0x80) = (param_3 >> 2) * 6;
    *(uint *)(param_1 + 0x88) = (param_4 >> 2) * 6;
    fVar11 = (float10)FUN_00841650(iVar2 + 0x40,param_1 + 0x38,fVar12);
    fStack_44 = (float)fVar11;
    if (DAT_01d60f98 == '\0') {
      fStack_40 = 0.0;
    }
    else {
      fVar12 = *(float *)(param_1 + 0x698) - *(float *)(param_1 + 0x68c);
      fVar18 = *(float *)(param_1 + 0x69c) - *(float *)(param_1 + 0x690);
      fVar17 = *(float *)(param_1 + 0x6a0) - *(float *)(param_1 + 0x694);
      fVar16 = *(float *)(param_1 + 0x38) -
               (*(float *)(param_1 + 0x698) + *(float *)(param_1 + 0x68c)) * DAT_018ce2f4;
      fVar15 = *(float *)(param_1 + 0x3c) -
               (*(float *)(param_1 + 0x69c) + *(float *)(param_1 + 0x690)) * DAT_018ce2f4;
      fVar13 = *(float *)(param_1 + 0x40) -
               (*(float *)(param_1 + 0x6a0) + *(float *)(param_1 + 0x694)) * DAT_018ce2f4;
      dVar14 = (double)(fVar18 * fVar18 + fVar12 * fVar12 + fVar17 * fVar17);
      FUN_017267a0();
      fVar12 = (float)dVar14 * DAT_018ce2f4;
      dVar14 = (double)(fVar15 * fVar15 + fVar16 * fVar16 + fVar13 * fVar13);
      FUN_017267a0();
      fStack_40 = fVar12 + (float)dVar14 + DAT_018e452c +
                  (float)(double)CONCAT44((uint)((ulonglong)(double)*(float *)(param_1 + 0x688) >>
                                                0x20) & DAT_018c0da0._4_4_,
                                          SUB84((double)*(float *)(param_1 + 0x688),0) &
                                          (uint)DAT_018c0da0);
    }
    uStack_48 = param_1 + 0x74;
    puVar4 = *(uint **)(param_2 + 0x70);
    uStack_3c = 0;
    if (*(uint **)(param_2 + 0x74) != puVar4) {
      *puVar4 = param_1;
      puVar4[1] = uVar3;
      puVar4[2] = uStack_48;
      puVar4[3] = (uint)fStack_44;
      *(ulonglong *)(puVar4 + 4) = (ulonglong)(uint)fStack_40;
      *(int *)(param_2 + 0x70) = *(int *)(param_2 + 0x70) + 0x18;
      return;
    }
    uStack_50 = param_1;
    uStack_4c = uVar3;
    FUN_006c6730(puVar4,&uStack_50);
  }
  return;
}



/* FUNCTION 12660 ; VA 0x00830040 ; FUN_00830040 */

void __thiscall FUN_00830040(int *param_1,uint param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uStack_8;
  
  puVar7 = (undefined4 *)param_1[1];
  uVar1 = ((int)puVar7 - *param_1) / 0x1c;
  uStack_8 = (param_1[2] - *param_1) / 0x1c;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar1) {
      if (param_2 != uVar1) {
        param_1[1] = *param_1 + param_2 * 0x1c;
      }
      return;
    }
    for (iVar6 = param_2 - uVar1; iVar6 != 0; iVar6 = iVar6 + -1) {
      uVar2 = param_4[1];
      uVar3 = param_4[2];
      uVar4 = param_4[3];
      *puVar7 = *param_4;
      puVar7[1] = uVar2;
      puVar7[2] = uVar3;
      puVar7[3] = uVar4;
      *(undefined8 *)(puVar7 + 4) = *(undefined8 *)(param_4 + 4);
      puVar7[6] = param_4[6];
      puVar7 = puVar7 + 7;
    }
    param_1[1] = (int)puVar7;
    return;
  }
  if (0x9249249 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x9249249 - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar5 = FUN_0072e960(uStack_8);
  puVar7 = (undefined4 *)(iVar5 + uVar1 * 0x1c);
  for (iVar6 = param_2 - uVar1; iVar6 != 0; iVar6 = iVar6 + -1) {
    uVar2 = param_4[1];
    uVar3 = param_4[2];
    uVar4 = param_4[3];
    *puVar7 = *param_4;
    puVar7[1] = uVar2;
    puVar7[2] = uVar3;
    puVar7[3] = uVar4;
    *(undefined8 *)(puVar7 + 4) = *(undefined8 *)(param_4 + 4);
    puVar7[6] = param_4[6];
    puVar7 = puVar7 + 7;
  }
  FUN_0072e4f0(*param_1,param_1[1],iVar5);
  FUN_0072db50(iVar5,param_2,uStack_8);
  return;
}



/* FUNCTION 12661 ; VA 0x00830190 ; FUN_00830190 */

undefined4 * __thiscall FUN_00830190(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined2 auStack_34 [2];
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined2 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  undefined uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6f61;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00841300(param_2,0);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x1d] = RBX::GfxPart::vftable;
  param_1[0x23] = 0xffffffff;
  param_1[0x24] = RBX::Graphics::Renderable::vftable;
  param_1[0x25] = RBX::Graphics::PlaneEffect::vftable;
  *param_1 = RBX::Graphics::TrailNode::vftable;
  param_1[0x1d] = RBX::Graphics::TrailNode::vftable;
  param_1[0x24] = RBX::Graphics::TrailNode::vftable;
  param_1[0x25] = RBX::Graphics::TrailNode::vftable;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  *(undefined2 *)(param_1 + 0x28) = 1;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  uStack_8._0_1_ = 5;
  uStack_8._1_3_ = 0;
  param_1[0x2d] = 0;
  FUN_0147c770();
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0x7f7fffff;
  param_1[0x3d] = 0x7f7fffff;
  param_1[0x3e] = 0x7f7fffff;
  param_1[0x3f] = 0xff7fffff;
  param_1[0x40] = 0xff7fffff;
  param_1[0x41] = 0xff7fffff;
  *(undefined *)(param_1 + 0x42) = 1;
  param_1[0x43] = 0;
  param_1[0x45] = 0x3f800000;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  uStack_8._0_1_ = 0xc;
  *(undefined *)(param_1 + 0x51) = 0;
  param_1[0x52] = 0x3dcccccd;
  param_1[0x53] = 0x40000000;
  *(undefined2 *)(param_1 + 0x54) = 1;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  iVar6 = 0x20;
  do {
    FUN_00569440();
    iVar6 = iVar6 + -1;
  } while (iVar6 != 0);
  uVar3 = FUN_01675290(DAT_01eb41bc);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  param_1[0x29] = param_2[0x141];
  uStack_1c = uVar3;
  FUN_00832180(param_2);
  iVar6 = param_1[0x29];
  iVar5 = *(int *)(iVar6 + 0x18);
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = *(int *)(iVar6 + 0x18);
  }
  param_1[0x2e] = *(undefined4 *)(iVar6 + 0x14);
  piVar1 = (int *)param_1[0x2f];
  param_1[0x2f] = iVar5;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar6 = piVar1[1] + -1;
    piVar1[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar6 = piVar1[2] + -1;
      piVar1[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  param_1[0x30] = 3;
  if ((uint)((int)(param_1[0x2c] - param_1[0x2a]) / 0x1c) < 0x3c) {
    FUN_00830b40(0x3c);
  }
  if (*(int *)(param_1[0x29] + 0x1c) == 0) {
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  }
  else {
    param_2 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 0xf;
    if (param_2 == (undefined4 *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078ded0(param_1[0x29] + 0x1c,0,0);
    }
    uStack_8._0_1_ = 0xd;
    FUN_007f76e0(uVar4);
    auStack_34[0] = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_14 = 4;
    uStack_12 = 0;
    FUN_0078e530(auStack_34);
    FUN_0078e510(&uStack_14);
    uStack_24 = 0x60400;
    uStack_28 = 0xf;
    uStack_20 = (ushort)uStack_20._1_1_ << 8;
    FUN_0078e480(&uStack_28);
    uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    param_2 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 0x10;
    if (param_2 == (undefined4 *)0x0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078ded0(param_1[0x29] + 0x2c,0,0);
    }
    uStack_8._0_1_ = 0xd;
    FUN_007f76e0(uVar4);
    FUN_0078e530(auStack_34);
    FUN_0078e510(&uStack_14);
    uStack_24 = 0x60400;
    uStack_28 = 0xf;
    uStack_20 = uStack_20 & 0xff00;
    FUN_0078e480(&uStack_28);
    uStack_28._0_2_ = 0x101;
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x46c,&uStack_28);
    uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
    uStack_24 = 0;
    uStack_20 = 0;
    FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    cVar2 = FUN_0078b7d0();
    if (cVar2 != '\0') {
      param_2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 0x11;
      if (param_2 == (undefined4 *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_0078ded0(param_1[0x29] + 0x3c,0,0);
      }
      uStack_8._0_1_ = 0xd;
      FUN_007f76e0(uVar4);
      FUN_0078e530(auStack_34);
      FUN_0078e510(&uStack_14);
      uStack_24 = 0x60400;
      uStack_28 = 0xf;
      uStack_20 = uStack_20 & 0xff00;
      FUN_0078e480(&uStack_28);
      uStack_28._0_2_ = 0x101;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x474,&uStack_28);
      uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    }
    cVar2 = FUN_0078ba00();
    if (cVar2 != '\0') {
      param_2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 0x12;
      if (param_2 == (undefined4 *)0x0) {
        uVar4 = 0;
      }
      else {
        uVar4 = FUN_0078ded0(param_1[0x29] + 0x4c,0,0);
      }
      uStack_8._0_1_ = 0xd;
      FUN_007f76e0(uVar4);
      FUN_0078e530(auStack_34);
      FUN_0078e510(&uStack_14);
      uStack_24 = 0x60400;
      uStack_28 = 0xf;
      uStack_20 = uStack_20 & 0xff00;
      FUN_0078e480(&uStack_28);
      uStack_28._0_2_ = 0x101;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(1,*(int *)(param_1[2] + 0x4f8) + 0x474,&uStack_28);
      uStack_28 = CONCAT22(uStack_28._2_2_,0x101);
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0078e550(0xf,*(int *)(*(int *)(param_1[2] + 0x4f8) + 0x44c) + 0x84,&uStack_28);
    }
    param_2 = param_1 + 0x25;
    FUN_00708ea0(&uStack_24,&param_2,param_2);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  }
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12662 ; VA 0x00830890 ; FUN_00830890 */

void __fastcall FUN_00830890(undefined4 *param_1)

{
  *param_1 = RBX::Graphics::PlaneEffect::vftable;
  return;
}



/* FUNCTION 12663 ; VA 0x008308a0 ; FUN_008308a0 */

void __fastcall FUN_008308a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puStack_14 = param_1 + 0x25;
  ExceptionList = &pvStack_10;
  *puStack_14 = RBX::Graphics::TrailNode::vftable;
  *param_1 = RBX::Graphics::TrailNode::vftable;
  param_1[0x1d] = RBX::Graphics::TrailNode::vftable;
  param_1[0x24] = RBX::Graphics::TrailNode::vftable;
  FUN_00831e60(&puStack_14);
  FUN_011590c0();
  param_1[0x26] = 0;
  piVar2 = (int *)param_1[0x27];
  param_1[0x27] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0x1d,5);
  piVar2 = (int *)param_1[0x4a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x48];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x3b];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x39];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x37];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x35];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x2f];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0072a1c0();
  piVar2 = (int *)param_1[0x27];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x25] = RBX::Graphics::PlaneEffect::vftable;
  FUN_007f6360();
  FUN_01158110();
  FUN_00841420();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12664 ; VA 0x00830ab7 ; FUN_00830ab7 */

void FUN_00830ab7(void)

{
  FUN_00830b10();
  return;
}



/* FUNCTION 12665 ; VA 0x00830abf ; FUN_00830abf */

void FUN_00830abf(void)

{
  FUN_00830b10();
  return;
}



/* FUNCTION 12666 ; VA 0x00830aca ; FUN_00830aca */

void FUN_00830aca(void)

{
  FUN_00830b10();
  return;
}



/* FUNCTION 12667 ; VA 0x00830ae0 ; FUN_00830ae0 */

undefined4 * __thiscall FUN_00830ae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Graphics::PlaneEffect::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 12668 ; VA 0x00830b10 ; FUN_00830b10 */

undefined4 __thiscall FUN_00830b10(undefined4 param_1,byte param_2)

{
  FUN_008308a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3e0);
  }
  return param_1;
}



/* FUNCTION 12669 ; VA 0x00830b40 ; FUN_00830b40 */

void __thiscall FUN_00830b40(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  iVar8 = FUN_0072e960(param_2);
  puVar9 = (undefined4 *)*param_1;
  puVar4 = (undefined4 *)param_1[1];
  if (puVar9 != puVar4) {
    iVar10 = iVar8 - (int)puVar9;
    do {
      uVar5 = puVar9[1];
      uVar6 = puVar9[2];
      uVar7 = puVar9[3];
      puVar1 = (undefined4 *)(iVar10 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined8 *)(iVar10 + 0x10 + (int)puVar9) = *(undefined8 *)(puVar9 + 4);
      *(undefined4 *)(iVar10 + 0x18 + (int)puVar9) = puVar9[6];
      puVar9 = puVar9 + 7;
    } while (puVar9 != puVar4);
  }
  FUN_0072db50(iVar8,(iVar2 - iVar3) / 0x1c,param_2);
  return;
}



/* FUNCTION 12670 ; VA 0x00830bc0 ; FUN_00830bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00830bc0(int param_1)

{
  int *piVar1;
  float *pfVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  float10 fVar9;
  float fVar10;
  double dVar11;
  float fVar12;
  float fVar13;
  float *pfStack_34;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  undefined4 uStack_c;
  
  piVar1 = (int *)(param_1 + 0xa8);
  if (((1 < (uint)((*(int *)(param_1 + 0xac) - *piVar1) / 0x1c)) &&
      (*(char *)(param_1 + 0x150) != '\0')) && (*(char *)(param_1 + 0x144) != '\0')) {
    *(undefined *)(param_1 + 0x144) = 0;
    iVar3 = *piVar1;
    iVar5 = (*(int *)(param_1 + 0xac) - iVar3) / 0x1c;
    pfVar2 = (float *)(param_1 + 300);
    iVar8 = (iVar5 + -2) * 0x1c;
    if ((((NAN(*(float *)(iVar8 + iVar3)) || NAN(*pfVar2)) == (*(float *)(iVar8 + iVar3) == *pfVar2)
         ) || (fVar10 = *(float *)(iVar8 + 4 + iVar3),
              (NAN(fVar10) || NAN(*(float *)(param_1 + 0x130))) ==
              (fVar10 == *(float *)(param_1 + 0x130)))) ||
       ((fVar10 = *(float *)(iVar8 + 8 + iVar3),
        (NAN(fVar10) || NAN(*(float *)(param_1 + 0x134))) == (fVar10 == *(float *)(param_1 + 0x134))
        || (cVar6 = FUN_006d29e0(param_1 + 0x138), cVar6 == '\0')))) {
      pfStack_34 = (float *)(param_1 + 0x138);
      iVar3 = *(int *)(param_1 + 8);
      fVar13 = *(float *)(iVar3 + 0x44) - *(float *)(param_1 + 0x6c);
      fVar12 = *(float *)(iVar3 + 0x40) - *(float *)(param_1 + 0x68);
      fVar10 = *(float *)(iVar3 + 0x48) - *(float *)(param_1 + 0x70);
      dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
      FUN_017267a0();
      fVar10 = DAT_018ce2f8 - ((float)dVar11 - DAT_01901960) / _DAT_01918c7c;
      fVar9 = (float10)FUN_01156c80();
      fVar10 = (float)(fVar9 * (float10)fVar10);
      fVar12 = DAT_018e452c;
      if (DAT_018e452c <= fVar10) {
        fVar12 = fVar10;
      }
      fVar10 = DAT_018ce2f8;
      if (fVar12 <= DAT_018ce2f8) {
        fVar10 = fVar12;
      }
      fVar10 = *(float *)(param_1 + 0x148) / fVar10;
      FUN_00730d10(param_1 + 300);
      FUN_00730d10(param_1 + 0x138);
      *(undefined *)(param_1 + 0x108) = 1;
      iVar3 = *(int *)(param_1 + 0xa8);
      if ((0x1b < (*(int *)(param_1 + 0xac) - iVar3) - 0x38U) &&
         (*(int *)(iVar3 + -4 + iVar5 * 0x1c) == *(int *)(iVar3 + -0x3c + iVar5 * 0x1c))) {
        if ((*(float *)(iVar3 + -0x28 + iVar5 * 0x1c) < fVar10) &&
           (*(float *)(iVar3 + -0xc + iVar5 * 0x1c) < fVar10)) {
          *(undefined8 *)(iVar3 + iVar8) = *(undefined8 *)pfVar2;
          *(undefined4 *)(iVar3 + 8 + iVar8) = *(undefined4 *)(param_1 + 0x134);
          iVar7 = iVar5 + -4;
          iVar4 = *piVar1;
          fVar13 = *(float *)(iVar4 + 4 + iVar7 * 0x1c) - *(float *)(param_1 + 0x130);
          fVar12 = *(float *)(iVar4 + iVar7 * 0x1c) - *pfVar2;
          fVar10 = *(float *)(iVar4 + 8 + iVar7 * 0x1c) - *(float *)(param_1 + 0x134);
          dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
          FUN_017267a0();
          *(float *)(iVar3 + 0x10 + iVar8) = (float)dVar11;
          iVar3 = *piVar1;
          *(undefined8 *)(iVar3 + -0x1c + iVar5 * 0x1c) = *(undefined8 *)pfStack_34;
          *(undefined4 *)(iVar3 + -0x14 + iVar5 * 0x1c) = *(undefined4 *)(param_1 + 0x140);
          iVar7 = iVar5 + -3;
          iVar8 = *piVar1;
          fVar13 = *(float *)(iVar8 + 4 + iVar7 * 0x1c) - *(float *)(param_1 + 0x13c);
          fVar12 = *(float *)(iVar8 + iVar7 * 0x1c) - *pfStack_34;
          fVar10 = *(float *)(iVar8 + 8 + iVar7 * 0x1c) - *(float *)(param_1 + 0x140);
          dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
          FUN_017267a0();
          *(float *)(iVar3 + -0xc + iVar5 * 0x1c) = (float)dVar11;
          return;
        }
        FUN_007cc990();
        uStack_c = *(undefined4 *)(param_1 + 0xb4);
        uStack_18 = *(undefined4 *)(param_1 + 0x14c);
        uStack_1c = *(undefined4 *)(param_1 + 0x134);
        iVar3 = *(int *)(param_1 + 0xa8);
        uStack_24 = *(undefined8 *)(param_1 + 300);
        fVar13 = *(float *)(iVar3 + iVar8) - (float)uStack_24;
        fVar10 = *(float *)(iVar3 + 4 + iVar8) - *(float *)(param_1 + 0x130);
        fVar12 = *(float *)(iVar3 + 8 + iVar8) - *(float *)(param_1 + 0x134);
        dVar11 = (double)(fVar13 * fVar13 + fVar10 * fVar10 + fVar12 * fVar12);
        FUN_017267a0();
        fStack_14 = (float)dVar11;
        FUN_00832a00(&uStack_24);
        uStack_1c = *(undefined4 *)(param_1 + 0x140);
        uStack_24 = *(undefined8 *)(param_1 + 0x138);
        iVar3 = *(int *)(param_1 + 0xa8);
        fVar12 = *(float *)(iVar3 + -0x1c + iVar5 * 0x1c) - (float)uStack_24;
        fVar13 = *(float *)(iVar3 + -0x18 + iVar5 * 0x1c) - *(float *)(param_1 + 0x13c);
        fVar10 = *(float *)(iVar3 + -0x14 + iVar5 * 0x1c) - *(float *)(param_1 + 0x140);
        dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
        FUN_017267a0();
        fStack_14 = (float)dVar11;
        FUN_00832a00(&uStack_24);
        return;
      }
      FUN_007cc990();
      uStack_c = *(undefined4 *)(param_1 + 0xb4);
      uStack_18 = *(undefined4 *)(param_1 + 0x14c);
      uStack_1c = *(undefined4 *)(param_1 + 0x134);
      iVar3 = *(int *)(param_1 + 0xa8);
      uStack_24 = *(undefined8 *)(param_1 + 300);
      fVar12 = *(float *)(iVar3 + iVar8) - (float)uStack_24;
      fVar13 = *(float *)(iVar3 + 4 + iVar8) - *(float *)(param_1 + 0x130);
      fVar10 = *(float *)(iVar3 + 8 + iVar8) - *(float *)(param_1 + 0x134);
      dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
      FUN_017267a0();
      fStack_14 = (float)dVar11;
      FUN_00832a00(&uStack_24);
      uStack_1c = *(undefined4 *)(param_1 + 0x140);
      uStack_24 = *(undefined8 *)(param_1 + 0x138);
      piVar1 = (int *)(param_1 + 0xa8);
      iVar3 = *piVar1;
      fVar12 = *(float *)(iVar3 + -0x1c + iVar5 * 0x1c) - (float)uStack_24;
      fVar13 = *(float *)(iVar3 + -0x18 + iVar5 * 0x1c) - *(float *)(param_1 + 0x13c);
      fVar10 = *(float *)(iVar3 + -0x14 + iVar5 * 0x1c) - *(float *)(param_1 + 0x140);
      dVar11 = (double)(fVar13 * fVar13 + fVar12 * fVar12 + fVar10 * fVar10);
      FUN_017267a0();
      fStack_14 = (float)dVar11;
      FUN_00832a00(&uStack_24);
      *(undefined4 *)(*piVar1 + -0x2c + iVar5 * 0x1c) = *(undefined4 *)(param_1 + 0x14c);
      *(undefined4 *)(*piVar1 + -0x24 + iVar5 * 0x1c) = 0;
      *(undefined4 *)(*piVar1 + -0x10 + iVar5 * 0x1c) = *(undefined4 *)(param_1 + 0x14c);
      *(undefined4 *)(*piVar1 + -8 + iVar5 * 0x1c) = 0;
    }
  }
  return;
}



/* FUNCTION 12671 ; VA 0x00831150 ; FUN_00831150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00831150(int param_1)

{
  int *piVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  char cVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  float fVar14;
  undefined uVar15;
  undefined *puVar16;
  int iVar17;
  char *pcVar18;
  undefined4 *puVar19;
  char *pcVar20;
  uint uVar21;
  float *pfVar22;
  int iVar23;
  undefined8 *puVar24;
  int *piVar25;
  uint uVar26;
  int iVar27;
  double dVar28;
  float fVar29;
  undefined auStack_3b8 [384];
  undefined auStack_238 [8];
  float afStack_230 [30];
  float afStack_1b8 [65];
  uint uStack_b4;
  undefined4 uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined4 uStack_8c;
  uint uStack_88;
  uint uStack_84;
  undefined4 uStack_74;
  uint uStack_70;
  undefined auStack_68 [4];
  int *piStack_64;
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  ulonglong uStack_50;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b6f8b;
  pvStack_1c = ExceptionList;
  if (*(int *)(param_1 + 0x98) != 0) {
    cVar7 = *(char *)(*(int *)(param_1 + 0x98) + 0x70);
    ExceptionList = &pvStack_1c;
    iStack_28 = param_1;
    puVar16 = &stack0xfffffffc;
    if (*(char *)(param_1 + 0x150) != cVar7) {
      ExceptionList = &pvStack_1c;
      *(char *)(param_1 + 0x150) = cVar7;
      if (cVar7 == '\0') {
        FUN_007c7a50(param_1 + 0x74,5);
        puVar16 = puStack_20;
      }
      else {
        piVar25 = (int *)(param_1 + 0xa8);
        piStack_2c = piVar25;
        if ((uint)((*(int *)(param_1 + 0xac) - *piVar25) / 0x1c) < 3) {
          puStack_20 = &stack0xfffffffc;
          FUN_00832900();
          FUN_008333b0();
          puVar16 = puStack_20;
        }
        else {
          *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + 1;
          iVar27 = *(int *)(param_1 + 0xac);
          uStack_60 = *(undefined4 *)(iVar27 + -0x1c);
          uStack_5c = *(uint *)(iVar27 + -0x18);
          uStack_58 = *(undefined4 *)(iVar27 + -0x14);
          uStack_54 = *(undefined4 *)(iVar27 + -0x10);
          uStack_48 = *(undefined4 *)(iVar27 + -4);
          uStack_50 = *(ulonglong *)(iVar27 + -0xc) & 0xffffffff00000000;
          puStack_20 = &stack0xfffffffc;
          FUN_00830040((iVar27 - *piVar25) / 0x1c + 4,piVar25,&uStack_60);
          FUN_008333b0();
          iVar27 = *(int *)(param_1 + 0xac);
          iVar17 = *piVar25;
          uVar8 = *(undefined4 *)(iVar27 + -0x14);
          iVar23 = (iVar27 - iVar17) / 0x1c + -3;
          *(undefined8 *)(iVar17 + iVar23 * 0x1c) = *(undefined8 *)(iVar27 + -0x1c);
          *(undefined4 *)(iVar17 + 8 + iVar23 * 0x1c) = uVar8;
          iVar27 = *(int *)(iStack_28 + 0xac);
          iVar17 = *piStack_2c;
          uVar8 = *(undefined4 *)(iVar27 + -0x14);
          iVar23 = (iVar27 - iVar17) / 0x1c + -4;
          *(undefined8 *)(iVar17 + iVar23 * 0x1c) = *(undefined8 *)(iVar27 + -0x1c);
          *(undefined4 *)(iVar17 + 8 + iVar23 * 0x1c) = uVar8;
          param_1 = iStack_28;
          puVar16 = puStack_20;
        }
      }
    }
    puStack_20 = puVar16;
    fVar29 = *(float *)(*(int *)(param_1 + 0x98) + 0x74);
    fVar2 = DAT_018daf54;
    if (DAT_018daf54 <= fVar29) {
      fVar2 = fVar29;
    }
    fVar29 = DAT_019011dc;
    if (fVar2 <= DAT_019011dc) {
      fVar29 = fVar2;
    }
    if (fVar29 < *(float *)(param_1 + 0x14c)) {
      iVar27 = *(int *)(param_1 + 0xac);
      for (iVar17 = *(int *)(param_1 + 0xa8); iVar17 != iVar27; iVar17 = iVar17 + 0x1c) {
        if (fVar29 < *(float *)(iVar17 + 0xc)) {
          *(float *)(iVar17 + 0xc) = fVar29;
        }
      }
    }
    *(float *)(param_1 + 0x14c) = fVar29;
    uStack_24 = FUN_00d3c220();
    piStack_2c = (int *)0x20;
    do {
      piStack_2c = (int *)((int)piStack_2c + -1);
      FUN_00569440();
    } while (piStack_2c != (int *)0x0);
    iVar27 = 0x20;
    do {
      FUN_00569440();
      iVar27 = iVar27 + -1;
    } while (iVar27 != 0);
    FUN_00a91b00(auStack_238,auStack_3b8,0x20);
    fVar29 = DAT_018f9000;
    iVar27 = 0x20;
    pfVar22 = afStack_230;
    puVar24 = (undefined8 *)(iStack_28 + 0x1e0);
    do {
      fVar2 = *pfVar22;
      *puVar24 = CONCAT44(pfVar22[-1] * fVar29,pfVar22[-2] * fVar29);
      piStack_30 = (int *)(fVar2 * fVar29);
      *(float *)(puVar24 + 1) = fVar2 * fVar29;
      iVar27 = iVar27 + -1;
      pfVar22 = pfVar22 + 3;
      puVar24 = (undefined8 *)((int)puVar24 + 0xc);
    } while (iVar27 != 0);
    uStack_24 = FUN_007635c0();
    iVar27 = 0x20;
    do {
      FUN_005502b0();
      iVar27 = iVar27 + -1;
    } while (iVar27 != 0);
    FUN_00a935e0(afStack_1b8,0x20,0,0x3f800000);
    iVar27 = iStack_28;
    fVar14 = DAT_018f9000;
    fVar2 = DAT_018ce2f8;
    fVar29 = DAT_018ce2f4;
    iVar17 = 0;
    pfVar22 = (float *)(iStack_28 + 0x164);
    do {
      fVar3 = afStack_1b8[iVar17 * 2 + 3];
      fVar4 = afStack_1b8[iVar17 * 2 + 2];
      pfVar22[-1] = (fVar2 - (afStack_1b8[iVar17 * 2 + 1] + afStack_1b8[iVar17 * 2]) * fVar29) *
                    fVar14;
      fVar5 = afStack_1b8[iVar17 * 2 + 5];
      fVar6 = afStack_1b8[iVar17 * 2 + 4];
      *pfVar22 = (fVar2 - (fVar3 + fVar4) * fVar29) * fVar14;
      fVar3 = afStack_1b8[iVar17 * 2 + 7];
      fVar4 = afStack_1b8[iVar17 * 2 + 6];
      pfVar22[1] = (fVar2 - (fVar5 + fVar6) * fVar29) * fVar14;
      fVar5 = afStack_1b8[iVar17 * 2 + 9];
      fVar6 = afStack_1b8[iVar17 * 2 + 8];
      pfVar22[2] = (fVar2 - (fVar3 + fVar4) * fVar29) * fVar14;
      fVar3 = afStack_1b8[iVar17 * 2 + 0xb];
      fVar4 = afStack_1b8[iVar17 * 2 + 10];
      pfVar22[3] = (fVar2 - (fVar5 + fVar6) * fVar29) * fVar14;
      fVar5 = afStack_1b8[iVar17 * 2 + 0xd];
      fVar6 = afStack_1b8[iVar17 * 2 + 0xc];
      pfVar22[4] = (fVar2 - (fVar3 + fVar4) * fVar29) * fVar14;
      fVar3 = afStack_1b8[iVar17 * 2 + 0xf];
      fVar4 = afStack_1b8[iVar17 * 2 + 0xe];
      iVar17 = iVar17 + 8;
      pfVar22[5] = (fVar2 - (fVar5 + fVar6) * fVar29) * fVar14;
      pfVar22[6] = (fVar2 - (fVar3 + fVar4) * fVar29) * fVar14;
      pfVar22 = pfVar22 + 8;
    } while (iVar17 < 0x20);
    uStack_50 = uStack_50 & 0xffffffff;
    uStack_48 = 0xf;
    uStack_5c = uStack_5c & 0xffffff00;
    FUN_005542c0("Texture",7);
    iStack_14 = 0;
    uStack_24 = FUN_00d10320(*(undefined4 *)(iVar27 + 0x98),&uStack_5c);
    iStack_14._0_1_ = 1;
    pcVar18 = (char *)FUN_0074ae10();
    if (0xf < *(uint *)(pcVar18 + 0x14)) {
      pcVar18 = *(char **)pcVar18;
    }
    uStack_34 = 0;
    piStack_30 = (int *)&DAT_0000000f;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar20 = pcVar18;
    do {
      cVar7 = *pcVar20;
      pcVar20 = pcVar20 + 1;
    } while (cVar7 != '\0');
    FUN_005542c0(pcVar18,(int)pcVar20 - (int)(pcVar18 + 1));
    iStack_14._0_1_ = 2;
    FUN_00833720(auStack_44,uStack_24);
    iStack_14._0_1_ = 1;
    uVar15 = (undefined)iStack_14;
    iStack_14._0_1_ = 1;
    if (&DAT_0000000f < piStack_30) {
      piVar25 = (int *)((int)piStack_30 + 1);
      uVar21 = auStack_44[0];
      if ((int *)0xfff < piVar25) {
        uVar21 = *(uint *)(auStack_44[0] - 4);
        piVar25 = piStack_30 + 9;
        if (0x1f < (auStack_44[0] - uVar21) - 4) {
          iStack_14._0_1_ = uVar15;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar21,piVar25);
    }
    iStack_14 = (uint)iStack_14._1_3_ << 8;
    if (0xf < uStack_70) {
      uVar26 = uStack_70 + 1;
      uVar21 = uStack_84;
      if (0xfff < uVar26) {
        uVar21 = *(uint *)(uStack_84 - 4);
        uVar26 = uStack_70 + 0x24;
        if (0x1f < (uStack_84 - uVar21) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar21,uVar26);
    }
    uStack_74 = 0;
    uStack_70 = 0xf;
    uStack_84 = uStack_84 & 0xffffff00;
    if (0xf < uStack_88) {
      uVar26 = uStack_88 + 1;
      uVar21 = uStack_9c;
      if (0xfff < uVar26) {
        uVar21 = *(uint *)(uStack_9c - 4);
        uVar26 = uStack_88 + 0x24;
        if (0x1f < (uStack_9c - uVar21) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar21,uVar26);
    }
    uStack_8c = 0;
    uStack_88 = 0xf;
    uStack_9c = uStack_9c & 0xffffff00;
    if (0xf < uStack_a0) {
      uVar26 = uStack_a0 + 1;
      uVar21 = uStack_b4;
      if (0xfff < uVar26) {
        uVar21 = *(uint *)(uStack_b4 - 4);
        uVar26 = uStack_a0 + 0x24;
        if (0x1f < (uStack_b4 - uVar21) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar21,uVar26);
    }
    uStack_a4 = 0;
    uStack_a0 = 0xf;
    uStack_b4 = uStack_b4 & 0xffffff00;
    iStack_14 = 0xffffffff;
    if (0xf < uStack_48) {
      uVar26 = uStack_48 + 1;
      uVar21 = uStack_5c;
      if (0xfff < uVar26) {
        uVar21 = *(uint *)(uStack_5c - 4);
        uVar26 = uStack_48 + 0x24;
        if (0x1f < (uStack_5c - uVar21) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar21,uVar26);
    }
    fVar29 = DAT_018e452c;
    iVar17 = *(int *)(iVar27 + 0x98);
    *(undefined4 *)(iVar27 + 0x148) = *(undefined4 *)(iVar17 + 0x94);
    if (fVar29 <= *(float *)(iVar17 + 0xb0)) {
      fVar29 = *(float *)(iVar17 + 0xb0);
    }
    *(float *)(iVar27 + 0x114) = fVar29;
    *(undefined4 *)(iVar27 + 0x118) = *(undefined4 *)(iVar17 + 0xb4);
    puVar19 = (undefined4 *)FUN_00587490(auStack_68);
    uStack_24 = *puVar19;
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar17 = piStack_64[1] + -1;
      piStack_64[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar17 = piStack_64[2] + -1;
        piStack_64[2] = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    puVar19 = (undefined4 *)FUN_00587490(&uStack_34);
    piVar25 = piStack_30;
    piStack_2c = (int *)*puVar19;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar17 = piStack_30[1] + -1;
      piStack_30[1] = iVar17;
      UNLOCK();
      if (iVar17 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piVar25 + 2;
        iVar17 = *piVar1 + -1;
        *piVar1 = iVar17;
        UNLOCK();
        if (iVar17 == 0) {
          (**(code **)(*piVar25 + 4))();
        }
      }
    }
    FUN_00833570(piStack_2c,uStack_24);
    iVar17 = *(int *)(iVar27 + 0x98);
    *(undefined *)(iVar27 + 0x151) = *(undefined *)(iVar17 + 0xb8);
    *(undefined4 *)(iVar27 + 0x154) = *(undefined4 *)(iVar17 + 0x90);
    dVar28 = (double)*(float *)(iVar17 + 0xbc);
    FUN_017267a0();
    *(float *)(iVar27 + 0x158) = (float)dVar28;
    *(undefined4 *)(iVar27 + 0x15c) = *(undefined4 *)(iVar17 + 0xc0);
    uStack_24 = FUN_00858c80();
    iVar27 = 0x20;
    do {
      FUN_005502b0();
      iVar27 = iVar27 + -1;
    } while (iVar27 != 0);
    FUN_00a935e0(afStack_1b8,0x20,0,0x3f800000);
    iVar27 = iStack_28;
    fVar29 = DAT_018ce2f4;
    iVar17 = 0;
    pfVar22 = (float *)(iStack_28 + 0x364);
    do {
      pfVar22[-1] = (afStack_1b8[iVar17 * 2 + 1] + afStack_1b8[iVar17 * 2]) * fVar29;
      *pfVar22 = (afStack_1b8[iVar17 * 2 + 3] + afStack_1b8[iVar17 * 2 + 2]) * fVar29;
      pfVar22[1] = (afStack_1b8[iVar17 * 2 + 5] + afStack_1b8[iVar17 * 2 + 4]) * fVar29;
      pfVar22[2] = (afStack_1b8[iVar17 * 2 + 7] + afStack_1b8[iVar17 * 2 + 6]) * fVar29;
      pfVar22[3] = (afStack_1b8[iVar17 * 2 + 9] + afStack_1b8[iVar17 * 2 + 8]) * fVar29;
      pfVar22[4] = (afStack_1b8[iVar17 * 2 + 0xb] + afStack_1b8[iVar17 * 2 + 10]) * fVar29;
      pfVar22[5] = (afStack_1b8[iVar17 * 2 + 0xd] + afStack_1b8[iVar17 * 2 + 0xc]) * fVar29;
      iVar23 = iVar17 * 2;
      iVar9 = iVar17 * 2;
      iVar17 = iVar17 + 8;
      pfVar22[6] = (afStack_1b8[iVar23 + 0xf] + afStack_1b8[iVar9 + 0xe]) * fVar29;
      uVar13 = _UNK_018c4ebc;
      uVar12 = _UNK_018c4eb8;
      uVar11 = _UNK_018c4eb4;
      uVar10 = _DAT_018c4eb0;
      uVar8 = DAT_018c45d0;
      pfVar22 = pfVar22 + 8;
    } while (iVar17 < 0x20);
    if (*(char *)(iStack_28 + 0xa1) != '\0') {
      *(undefined4 *)(iStack_28 + 0xac) = *(undefined4 *)(iStack_28 + 0xa8);
      *(undefined4 *)(iStack_28 + 0xf0) = uVar10;
      *(undefined4 *)(iStack_28 + 0xf4) = uVar11;
      *(undefined4 *)(iStack_28 + 0xf8) = uVar12;
      *(undefined4 *)(iStack_28 + 0xfc) = uVar13;
      *(undefined4 *)(iStack_28 + 0x10c) = 0;
      *(ulonglong *)(iStack_28 + 0x100) = CONCAT44(uVar8,uVar8);
      *(undefined *)(iStack_28 + 0x108) = 1;
      FUN_008333b0();
      *(undefined *)(iVar27 + 0xa1) = 0;
    }
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12672 ; VA 0x00831a60 ; FUN_00831a60 */

void FUN_00831a60(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  int *piVar9;
  int iVar10;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b6fea;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  iVar2 = *param_1;
  iVar3 = *(int *)(iVar2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar6 = FUN_00d3cec0();
  iVar10 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
      (uint)*(ushort *)(iVar6 + 0x1da)) {
    iVar10 = iVar2;
  }
  puVar7 = (undefined4 *)FUN_0060dcd0(auStack_24,iVar10);
  uVar8 = *puVar7;
  uVar4 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  *(undefined4 *)(iStack_14 + 0x98) = uVar8;
  piVar9 = *(int **)(iStack_14 + 0x9c);
  *(undefined4 *)(iStack_14 + 0x9c) = uVar4;
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar2 = piVar9[1] + -1;
    piVar9[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      iVar2 = piVar9[2] + -1;
      piVar9[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  iVar2 = iStack_14;
  if (*(int *)(iStack_14 + 0x98) != 0) {
    iVar3 = *param_1;
    iStack_8 = 0;
    uVar8 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    piStack_20 = (int *)uVar8;
    puStack_1c = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_00819150;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = iVar3 + 0x50;
      puStack_1c[6] = FUN_00832940;
      puStack_1c[7] = 0;
      puStack_1c[8] = iVar2;
      puStack_1c[9] = uStack_28;
      puVar7 = puStack_1c;
    }
    FUN_016797d0(puVar7);
    if (puVar7 != (undefined4 *)0x0) {
      LOCK();
      puVar7[1] = puVar7[1] + 1;
      UNLOCK();
    }
    uStack_18 = 1;
    iStack_8._0_1_ = 2;
    puStack_1c = puVar7;
    FUN_01675290(uVar8);
    iVar2 = iStack_14;
    puVar5 = *(undefined4 **)(iStack_14 + 0x84);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (*(undefined4 **)(iStack_14 + 0x88) == puVar5) {
      FUN_006335f0(puVar5,&puStack_1c);
      puVar7 = puStack_1c;
    }
    else {
      *puVar5 = puVar7;
      *(int *)(iStack_14 + 0x84) = *(int *)(iStack_14 + 0x84) + 4;
      puVar7 = (undefined4 *)0x0;
    }
    uStack_18 = 0;
    iStack_8 = 0xffffffff;
    if (puVar7 != (undefined4 *)0x0) {
      piVar9 = puVar7 + 1;
      LOCK();
      iVar3 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(puVar7);
      }
    }
    iVar2 = *(int *)(iVar2 + 0x98);
    FUN_006eccd0();
    iStack_8 = 3;
    piVar9 = (int *)FUN_01675290(DAT_02110da8);
    iStack_8 = 4;
    piStack_20 = piVar9;
    puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_1c == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      *puStack_1c = 0;
      puStack_1c[1] = 1;
      puStack_1c[2] = FUN_00831e40;
      puStack_1c[3] = _guard_check_icall;
      puStack_1c[4] = 0;
      puStack_1c[5] = iVar2 + 0x58;
      puStack_1c[6] = iStack_14;
      puVar7 = puStack_1c;
    }
    FUN_016797d0(puVar7);
    if (puVar7 != (undefined4 *)0x0) {
      LOCK();
      puVar7[1] = puVar7[1] + 1;
      UNLOCK();
    }
    uStack_18 = 4;
    iStack_8 = 5;
    puStack_1c = puVar7;
    FUN_01675290(piVar9);
    iStack_8 = 6;
    puVar5 = *(undefined4 **)(iStack_14 + 0x84);
    if (*(undefined4 **)(iStack_14 + 0x88) == puVar5) {
      FUN_006335f0(puVar5,&puStack_1c);
      puVar7 = puStack_1c;
    }
    else {
      *puVar5 = puVar7;
      *(int *)(iStack_14 + 0x84) = *(int *)(iStack_14 + 0x84) + 4;
      puVar7 = (undefined4 *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (puVar7 != (undefined4 *)0x0) {
      piVar9 = puVar7 + 1;
      LOCK();
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puVar7);
      }
    }
  }
  (**(code **)(*(int *)(iStack_14 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12673 ; VA 0x00831d60 ; FUN_00831d60 */

void __thiscall FUN_00831d60(float *param_1,float *param_2)

{
  double dVar1;
  float fVar2;
  
  dVar1 = (double)(*param_1 * *param_1 + param_1[1] * param_1[1] + param_1[2] * param_1[2]);
  FUN_017267a0();
  fVar2 = (float)dVar1;
  if (fVar2 < DAT_01918ee4) {
    *param_2 = 0.0;
    param_2[1] = 0.0;
    param_2[2] = 0.0;
    return;
  }
  if ((fVar2 < DAT_01918ee8) && (DAT_018fd17c < fVar2)) {
    fVar2 = param_1[2];
    *(undefined8 *)param_2 = *(undefined8 *)param_1;
    param_2[2] = fVar2;
    return;
  }
  fVar2 = DAT_018ce2f8 / fVar2;
  *param_2 = *param_1 * fVar2;
  param_2[1] = param_1[1] * fVar2;
  param_2[2] = param_1[2] * fVar2;
  return;
}



/* FUNCTION 12674 ; VA 0x00831e40 ; FUN_00831e40 */

void FUN_00831e40(int param_1)

{
  *(undefined *)(*(int *)(param_1 + 0x18) + 0xa1) = 1;
                    /* WARNING: Could not recover jumptable at 0x00831e5a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(*(int *)(param_1 + 0x18) + 0x74) + 8))();
  return;
}



/* FUNCTION 12675 ; VA 0x00831e60 ; FUN_00831e60 */

int __thiscall FUN_00831e60(int param_1,byte *param_2)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0xc);
  piVar2 = *(int **)(param_1 + 4);
  uVar4 = ((((*param_2 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_2[1]) * 0x1000193 ^ (uint)param_2[2])
           * 0x1000193 ^ (uint)param_2[3]) * 0x1000193 & *(uint *)(param_1 + 0x18);
  piVar8 = *(int **)(iVar1 + uVar4 * 8);
  iVar7 = uVar4 * 8 + 4;
  piVar10 = piVar8;
  while( true ) {
    piVar5 = piVar2;
    if (piVar8 != piVar2) {
      piVar5 = (int *)**(undefined4 **)(iVar1 + iVar7);
    }
    if (piVar10 == piVar5) goto LAB_00831f3d;
    piVar5 = piVar10;
    if (piVar10[2] == *(int *)param_2) break;
    piVar10 = (int *)*piVar10;
  }
  while( true ) {
    piVar6 = piVar2;
    if (piVar8 != piVar2) {
      piVar6 = (int *)**(undefined4 **)(iVar1 + iVar7);
    }
    if ((piVar5 == piVar6) || (*(int *)param_2 != piVar5[2])) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar10 == piVar5) {
LAB_00831f3d:
    piVar5 = piVar2;
    piVar10 = piVar2;
  }
  iVar7 = 0;
  for (piVar8 = piVar10; piVar8 != piVar5; piVar8 = (int *)*piVar8) {
    iVar7 = iVar7 + 1;
  }
  piVar8 = (int *)*piVar2;
  ppvVar3 = &pvStack_10;
  if ((piVar10 == piVar8) && (piVar5 == piVar2)) {
    ExceptionList = &pvStack_10;
    *piVar2 = (int)piVar2;
    uStack_8 = 0;
    *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
    *(undefined4 *)(param_1 + 8) = 0;
    if (piVar8 != *(int **)(param_1 + 4)) {
      do {
        piVar2 = (int *)*piVar8;
        FUN_01674ea0(piVar8,0xc);
        piVar8 = piVar2;
      } while (piVar2 != *(int **)(param_1 + 4));
    }
    FUN_005cb500(8);
  }
  else {
    while (ExceptionList = ppvVar3, piVar10 != piVar5) {
      piVar2 = (int *)*piVar10;
      iVar1 = (((((*(byte *)(piVar10 + 2) ^ 0x811c9dc5) * 0x1000193 ^
                 (uint)*(byte *)((int)piVar10 + 9)) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 10)
                ) * 0x1000193 ^ (uint)*(byte *)((int)piVar10 + 0xb)) * 0x1000193 &
              *(uint *)(param_1 + 0x18)) * 8;
      puVar9 = (undefined4 *)(iVar1 + *(int *)(param_1 + 0xc));
      if ((int *)puVar9[1] == piVar10) {
        if ((int *)*puVar9 == piVar10) {
          *puVar9 = *(undefined4 *)(param_1 + 4);
          *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          puVar9[1] = piVar10[1];
        }
      }
      else if ((int *)*puVar9 == piVar10) {
        *puVar9 = piVar2;
      }
      *(int *)piVar10[1] = *piVar10;
      *(int *)(*piVar10 + 4) = piVar10[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_01674ea0(piVar10,0xc);
      piVar10 = piVar2;
      ppvVar3 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 12676 ; VA 0x00832070 ; FUN_00832070 */

undefined4 FUN_00832070(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 12677 ; VA 0x008320c0 ; FUN_008320c0 */

undefined4 FUN_008320c0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 12678 ; VA 0x00832130 ; FUN_00832130 */

float10 __fastcall FUN_00832130(int param_1)

{
  return (float10)*(float *)(param_1 + 0x74);
}



/* FUNCTION 12679 ; VA 0x00832140 ; FUN_00832140 */

float10 __fastcall FUN_00832140(int param_1)

{
  return (float10)*(float *)(param_1 + 0x90);
}



/* FUNCTION 12680 ; VA 0x00832150 ; FUN_00832150 */

float10 __fastcall FUN_00832150(int param_1)

{
  return (float10)*(float *)(param_1 + 0xbc);
}



/* FUNCTION 12681 ; VA 0x00832170 ; FUN_00832170 */

float10 __fastcall FUN_00832170(int param_1)

{
  return (float10)*(float *)(param_1 + 0x7c);
}



/* FUNCTION 12682 ; VA 0x00832180 ; FUN_00832180 */

void __thiscall FUN_00832180(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  char *pcStack_40;
  undefined4 uStack_3c;
  char *pcStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7010;
  pvStack_10 = ExceptionList;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    uVar4 = FUN_01675290(DAT_01eb41bc);
    *param_1 = param_2;
    piStack_18 = *(int **)(param_2 + 0x3c);
    uStack_8 = 0;
    uStack_28 = uVar4;
    piVar5 = (int *)(**(code **)(*piStack_18 + 0x3c))(&uStack_30,0,0x1b5800,0x1c,1);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    param_1[1] = iVar1;
    piVar5 = (int *)param_1[2];
    param_1[2] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4200) {
      FUN_016f3809(&DAT_01eb4200);
      if (DAT_01eb4200 == -1) {
        FUN_0147c5c0(0,0,2,0,0);
        FUN_0147c5c0(0,0xc,2,3,0);
        FUN_0147c5c0(0,0x18,6,3,1);
        FUN_016f37bf(&DAT_01eb4200);
      }
    }
    piVar6 = (int *)FUN_0147c1b0(&uStack_30,&DAT_01eb41c4,3,0x1c);
    piVar5 = piStack_14;
    iVar1 = *piVar6;
    iVar2 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    piStack_14[3] = iVar1;
    piStack_20 = (int *)piStack_14[4];
    piStack_14[4] = iVar2;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar1 = piStack_20[2] + -1;
        piStack_20[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    piStack_20 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar1 = piStack_20[2] + -1;
        piStack_20[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    uStack_30 = 0;
    piStack_2c = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar6 = (int *)FUN_0147c0e0(&pcStack_38,piVar5 + 3,piVar5 + 1,&uStack_30);
    iVar1 = *piVar6;
    iVar2 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    piVar5[5] = iVar1;
    piVar6 = (int *)piVar5[6];
    piVar5[6] = iVar2;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[1] + -1;
      piVar6[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar1 = piVar6[2] + -1;
        piVar6[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_34[1] + -1;
      piStack_34[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar1 = piStack_34[2] + -1;
        piStack_34[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
    piVar5 = piStack_2c;
    uStack_8 = uStack_8 & 0xffffff00;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    pcStack_40 = "TrailVS";
    uStack_3c = 7;
    pcStack_38 = "TrailFS";
    piStack_34 = (int *)0x7;
    FUN_00790e00(&iStack_1c,&pcStack_40,2);
    iVar1 = iStack_1c;
    iStack_1c = 0;
    piStack_14[7] = iVar1;
    piVar5 = (int *)piStack_14[8];
    piStack_14[8] = (int)piStack_18;
    piStack_18 = (int *)0x0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_18;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    pcStack_40 = "TrailVSQuad";
    uStack_3c = 0xb;
    pcStack_38 = "TrailFSQuad";
    piStack_34 = (int *)0xb;
    FUN_00790e00(&iStack_24,&pcStack_40,2);
    piVar6 = piStack_20;
    iVar1 = iStack_24;
    iStack_24 = 0;
    piStack_14[9] = iVar1;
    piVar5 = (int *)piStack_14[10];
    piStack_20 = (int *)0x0;
    piStack_14[10] = (int)piVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    pcStack_40 = "TrailVSLight";
    uStack_3c = 0xc;
    pcStack_38 = "TrailFSLight";
    piStack_34 = (int *)0xc;
    FUN_00790e00(&iStack_24,&pcStack_40,2);
    piVar6 = piStack_20;
    iVar1 = iStack_24;
    iStack_24 = 0;
    piStack_14[0xb] = iVar1;
    piVar5 = (int *)piStack_14[0xc];
    piStack_20 = (int *)0x0;
    piStack_14[0xc] = (int)piVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    pcStack_40 = "TrailVSLightShadow";
    uStack_3c = 0x12;
    pcStack_38 = "TrailFSLightShadow";
    piStack_34 = (int *)0x12;
    FUN_00790e00(&iStack_24,&pcStack_40,2);
    piVar6 = piStack_20;
    iVar1 = iStack_24;
    iStack_24 = 0;
    piStack_14[0xf] = iVar1;
    piVar5 = (int *)piStack_14[0x10];
    piStack_20 = (int *)0x0;
    piStack_14[0x10] = (int)piVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    pcStack_40 = "TrailVSQuadLight";
    uStack_3c = 0x10;
    pcStack_38 = "TrailFSQuadLight";
    piStack_34 = (int *)0x10;
    FUN_00790e00(&iStack_24,&pcStack_40,2);
    piVar6 = piStack_20;
    iVar1 = iStack_24;
    iStack_24 = 0;
    piStack_14[0xd] = iVar1;
    piVar5 = (int *)piStack_14[0xe];
    piStack_20 = (int *)0x0;
    piStack_14[0xe] = (int)piVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    pcStack_40 = "TrailVSQuadLightShadow";
    uStack_3c = 0x16;
    pcStack_38 = "TrailFSQuadLightShadow";
    piStack_34 = (int *)0x16;
    FUN_00790e00(&iStack_24,&pcStack_40,2);
    piVar6 = piStack_20;
    iVar1 = iStack_24;
    iStack_24 = 0;
    piStack_14[0x11] = iVar1;
    piVar5 = (int *)piStack_14[0x12];
    piStack_20 = (int *)0x0;
    piStack_14[0x12] = (int)piVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piVar5 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    cVar3 = FUN_0078ba00();
    if (cVar3 != '\0') {
      pcStack_40 = "TrailVSLightShadowFSM";
      uStack_3c = 0x15;
      pcStack_38 = "TrailFSLightShadowFSM";
      piStack_34 = (int *)0x15;
      FUN_00790e00(&uStack_30,&pcStack_40,2);
      FUN_005587e0(&uStack_30);
      piStack_20 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar1 = piStack_20[2] + -1;
          piStack_20[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
      pcStack_40 = "TrailVSQuadLightShadowFSM";
      uStack_3c = 0x19;
      pcStack_38 = "TrailFSQuadLightShadowFSM";
      piStack_34 = (int *)0x19;
      FUN_00790e00(&uStack_30,&pcStack_40,2);
      FUN_005587e0(&uStack_30);
      piVar5 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    uStack_8 = 2;
    FUN_01675290(uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12683 ; VA 0x008328d0 ; FUN_008328d0 */

void __fastcall FUN_008328d0(int param_1)

{
  if (*(char *)(param_1 + 0x2c) != '\0') {
    *(undefined *)(param_1 + 0x2c) = 0;
    if (param_1 == 0x74) {
      param_1 = 0;
    }
    FUN_007c8ce0(param_1);
  }
  return;
}



/* FUNCTION 12684 ; VA 0x00832900 ; FUN_00832900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00832900(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  uVar5 = _UNK_018c4ebc;
  uVar4 = _UNK_018c4eb8;
  uVar3 = _UNK_018c4eb4;
  uVar2 = _DAT_018c4eb0;
  uVar1 = DAT_018c45d0;
  *(undefined4 *)(param_1 + 0xac) = *(undefined4 *)(param_1 + 0xa8);
  *(undefined4 *)(param_1 + 0xf0) = uVar2;
  *(undefined4 *)(param_1 + 0xf4) = uVar3;
  *(undefined4 *)(param_1 + 0xf8) = uVar4;
  *(undefined4 *)(param_1 + 0xfc) = uVar5;
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(ulonglong *)(param_1 + 0x100) = CONCAT44(uVar1,uVar1);
  *(undefined *)(param_1 + 0x108) = 1;
  return;
}



/* FUNCTION 12685 ; VA 0x00832940 ; FUN_00832940 */

int __thiscall FUN_00832940(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if (param_2 != 2) {
    if (param_2 == 5) {
      piVar3 = *(int **)(param_1 + 0x9c);
      ExceptionList = &pvStack_10;
      if (piVar3 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        piVar3[1] = piVar3[1] + 1;
        UNLOCK();
        piVar3 = *(int **)(param_1 + 0x9c);
      }
      uStack_8 = 0;
      param_2 = FUN_011584d0(*(undefined4 *)(param_1 + 0x98));
      if ((char)param_2 == '\0') {
        param_2 = (**(code **)(*(int *)(param_1 + 0x74) + 4))();
      }
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar1 = piVar3 + 1;
        iVar2 = *piVar1;
        param_2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          param_2 = (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            param_2 = (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(*(int *)(param_1 + 0x74) + 8))();
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 12686 ; VA 0x00832a00 ; FUN_00832a00 */

void __thiscall FUN_00832a00(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    puVar1[6] = param_2[6];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x1c;
    return;
  }
  FUN_00725c30(puVar1,param_2);
  return;
}



/* FUNCTION 12687 ; VA 0x00832a40 ; FUN_00832a40 */

void __thiscall FUN_00832a40(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  float10 fVar7;
  float fVar8;
  double dVar9;
  double dVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined4 uStack_30;
  float fStack_2c;
  float fStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  float fStack_14;
  float fStack_10;
  undefined4 uStack_c;
  
  fVar8 = *(float *)(param_1 + -0x80);
  fVar7 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + -0x8c) + 0x5c4));
  if ((float)fVar7 <= fVar8) {
LAB_00832a96:
    bVar4 = false;
  }
  else {
    cVar5 = FUN_0078b7c0();
    bVar4 = true;
    if (cVar5 == '\0') goto LAB_00832a96;
  }
  fVar8 = *(float *)(param_1 + -0x80);
  fVar7 = (float10)FUN_01156fe0(*(undefined4 *)(*(int *)(param_1 + -0x8c) + 0x5c4));
  if (fVar8 < (float)fVar7) {
    cVar5 = FUN_0078bd20();
    if (cVar5 != '\0') {
      bVar3 = true;
      goto LAB_00832adf;
    }
  }
  bVar3 = false;
LAB_00832adf:
  fStack_28 = *(float *)(param_1 + 0xc4);
  if (fStack_28 <= DAT_018f784c) {
    iVar6 = *(int *)(param_1 + 0x3c);
  }
  else if (bVar4) {
    iVar6 = *(int *)(param_1 + 0x54);
  }
  else if (bVar3) {
    iVar6 = *(int *)(param_1 + 0x4c);
  }
  else {
    iVar6 = *(int *)(param_1 + 0x44);
  }
  if (iVar6 != 0) {
    fStack_2c = DAT_018ce2f8 - *(float *)(param_1 + 0xc0);
    iVar1 = **(int **)(param_1 + 0x10);
    uStack_30 = 0;
    uStack_24 = 0;
    FUN_0078e4a0(1,&uStack_30,0x10);
    *(undefined4 *)(param_1 + 0x30) = param_3;
    *(undefined4 *)(param_1 + 0x38) = param_4;
    fVar7 = (float10)FUN_00841650(iVar1 + 0x40,*(int *)(param_1 + 0x18) + -0x1c,0xbdcccccd);
    fStack_14 = (float)fVar7;
    if (DAT_01d60f98 == '\0') {
      fStack_10 = 0.0;
    }
    else {
      iVar1 = *(int *)(param_1 + 0x18);
      fVar11 = (*(float *)(param_1 + 0x60) + *(float *)(param_1 + 0x6c)) * DAT_018ce2f4 -
               *(float *)(iVar1 + -0x18);
      fVar13 = *(float *)(param_1 + 0x6c) - *(float *)(param_1 + 0x60);
      fVar12 = (*(float *)(param_1 + 0x5c) + *(float *)(param_1 + 0x68)) * DAT_018ce2f4 -
               *(float *)(iVar1 + -0x1c);
      fVar15 = *(float *)(param_1 + 0x70) - *(float *)(param_1 + 100);
      fVar14 = *(float *)(param_1 + 0x68) - *(float *)(param_1 + 0x5c);
      fVar8 = (*(float *)(param_1 + 100) + *(float *)(param_1 + 0x70)) * DAT_018ce2f4 -
              *(float *)(iVar1 + -0x14);
      dVar9 = (double)(fVar11 * fVar11 + fVar12 * fVar12 + fVar8 * fVar8);
      FUN_017267a0();
      dVar10 = (double)(fVar14 * fVar14 + fVar13 * fVar13 + fVar15 * fVar15);
      FUN_017267a0();
      fStack_10 = (float)dVar9 + (float)dVar10 * DAT_018ce2f4 + DAT_018e452c + 0.0;
    }
    if (param_1 == 0x94) {
      iStack_20 = 0;
    }
    else {
      iStack_20 = param_1 + -4;
    }
    iStack_18 = param_1 + 0x24;
    piVar2 = *(int **)(param_2 + 0x70);
    uStack_c = 0;
    if (*(int **)(param_2 + 0x74) != piVar2) {
      *piVar2 = iStack_20;
      piVar2[1] = iVar6;
      piVar2[2] = iStack_18;
      piVar2[3] = (int)fStack_14;
      *(ulonglong *)(piVar2 + 4) = (ulonglong)(uint)fStack_10;
      *(int *)(param_2 + 0x70) = *(int *)(param_2 + 0x70) + 0x18;
      return;
    }
    iStack_1c = iVar6;
    FUN_006c6730(piVar2,&iStack_20);
  }
  return;
}



/* FUNCTION 12688 ; VA 0x00832d10 ; FUN_00832d10 */

void __fastcall FUN_00832d10(int param_1)

{
  int iVar1;
  int iVar2;
  float *pfVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  int iStack_8;
  
  iVar4 = *(int *)(param_1 + 0xa8);
  iVar2 = (*(int *)(param_1 + 0xac) - iVar4) / 0x1c;
  if (*(int *)(param_1 + 0x118) == 0) {
    iVar4 = 0;
    iStack_8 = 0;
    if (0 < iVar2 + -1) {
      iVar6 = 1;
      iVar7 = 0x38;
      do {
        if ((iVar6 == iVar2 + -1) ||
           (*(int *)(*(int *)(param_1 + 0xa8) + -0x20 + iVar7) !=
            *(int *)(*(int *)(param_1 + 0xa8) + 0x18 + iVar7))) {
          iVar4 = iVar4 + 2;
          fVar9 = *(float *)(param_1 + 0x114);
          fVar10 = 0.0;
          fVar8 = 0.0;
          *(undefined4 *)(iVar7 + -0x24 + *(int *)(param_1 + 0xa8)) = 0;
          *(undefined4 *)(iVar7 + -8 + *(int *)(param_1 + 0xa8)) = 0;
          if (iVar4 < iVar6) {
            pfVar3 = (float *)(*(int *)(param_1 + 0xa8) + 0x2c + iVar4 * 0x1c);
            iVar4 = ((iVar6 - iVar4) - 1U >> 1) + 1;
            do {
              fVar10 = fVar10 + pfVar3[-7];
              fVar8 = fVar8 + *pfVar3;
              pfVar3 = pfVar3 + 0xe;
              iVar4 = iVar4 + -1;
            } while (iVar4 != 0);
          }
          if (iStack_8 <= iVar6 + -3) {
            iVar4 = iVar7 + -0x70;
            iVar5 = ((iVar6 - iStack_8) - 3U >> 1) + 1;
            do {
              iVar1 = *(int *)(param_1 + 0xa8);
              *(float *)(iVar4 + 0x14 + iVar1) =
                   *(float *)(iVar4 + 0x48 + iVar1) * (fVar9 / fVar10) +
                   *(float *)(iVar4 + 0x4c + iVar1);
              iVar1 = *(int *)(param_1 + 0xa8);
              *(float *)(iVar4 + 0x30 + iVar1) =
                   *(float *)(iVar4 + 100 + iVar1) * (fVar9 / fVar8) +
                   *(float *)(iVar4 + 0x68 + iVar1);
              iVar4 = iVar4 + -0x38;
              iVar5 = iVar5 + -1;
            } while (iVar5 != 0);
          }
          iVar4 = iVar6 + 1;
          iStack_8 = iVar4;
        }
        iVar6 = iVar6 + 2;
        iVar7 = iVar7 + 0x38;
      } while (iVar6 <= iVar2 + -1);
      return;
    }
  }
  else if (*(int *)(param_1 + 0x118) == 1) {
    iVar7 = iVar2 + -4;
    *(undefined4 *)(iVar4 + -0x24 + iVar2 * 0x1c) = 0;
    *(undefined4 *)(*(int *)(param_1 + 0xa8) + -8 + iVar2 * 0x1c) = 0;
    if (-1 < iVar7) {
      iVar4 = iVar7 * 0x1c;
      while (iVar2 = *(int *)(param_1 + 0xa8),
            *(int *)(iVar4 + 0x18 + iVar2) == *(int *)(iVar4 + 0x50 + iVar2)) {
        fVar9 = *(float *)(iVar4 + 0x48 + iVar2);
        fVar8 = *(float *)(iVar4 + 100 + iVar2);
        if (fVar8 <= fVar9) {
          fVar8 = fVar9;
        }
        fVar8 = fVar8 / *(float *)(param_1 + 0x114);
        *(float *)(iVar4 + 0x14 + iVar2) = *(float *)(iVar4 + 0x4c + iVar2) + fVar8;
        *(float *)(iVar4 + 0x30 + *(int *)(param_1 + 0xa8)) =
             *(float *)(iVar4 + 0x68 + *(int *)(param_1 + 0xa8)) + fVar8;
        iVar4 = iVar4 + -0x38;
        iVar7 = iVar7 + -2;
        if (iVar7 < 0) {
          return;
        }
      }
    }
  }
  else if ((2 < iVar2) &&
          (*(int *)(iVar4 + -4 + iVar2 * 0x1c) == *(int *)(iVar4 + -0x3c + iVar2 * 0x1c))) {
    iVar7 = *(int *)(param_1 + 0xac);
    fVar9 = *(float *)(iVar4 + 0x10 + (iVar2 + -2) * 0x1c);
    if (fVar9 <= *(float *)(iVar7 + -0xc)) {
      fVar9 = *(float *)(iVar7 + -0xc);
    }
    *(float *)(iVar7 + -8) =
         *(float *)(iVar4 + -0x5c + iVar2 * 0x1c) - fVar9 / *(float *)(param_1 + 0x114);
    fVar8 = DAT_01918eec;
    fVar9 = *(float *)(iVar4 + -0x40 + iVar2 * 0x1c) - fVar9 / *(float *)(param_1 + 0x114);
    *(float *)(iVar4 + 0x14 + (iVar2 + -2) * 0x1c) = fVar9;
    if (((fVar9 < fVar8) && (fVar9 = *(float *)(iVar4 + 0x14), (int)fVar9 < -5000)) &&
       (iVar4 != iVar7)) {
      do {
        *(float *)(iVar4 + 0x14) = *(float *)(iVar4 + 0x14) - (float)(int)fVar9;
        iVar4 = iVar4 + 0x1c;
      } while (iVar4 != iVar7);
    }
  }
  return;
}



/* FUNCTION 12689 ; VA 0x00832fe0 ; FUN_00832fe0 */

float * __fastcall FUN_00832fe0(int param_1)

{
  undefined *puVar1;
  int iVar2;
  double dVar3;
  undefined4 uVar4;
  undefined *puVar5;
  float *pfVar6;
  float *pfVar7;
  float *pfVar8;
  float *pfVar9;
  int iVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  undefined *puStack_20;
  int iStack_1c;
  float *pfStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_5;
  
  fVar15 = DAT_018f784c;
  iStack_14 = *(int *)(param_1 + 0xa8);
  pfVar7 = (float *)((*(int *)(param_1 + 0xac) - iStack_14) / 0x1c);
  if (2 < (int)pfVar7) {
    if (DAT_01d621f8 == '\0') {
      dVar3 = *(double *)(*(int *)(param_1 + 8) + 0x20);
    }
    else {
      dVar3 = *(double *)(*(int *)(param_1 + 8) + 0x18);
    }
    puStack_20 = (undefined *)((int)pfVar7 + -2);
    pfVar8 = (float *)0x0;
    iStack_10 = 0;
    fVar14 = DAT_01918c68;
    if ((float)dVar3 <= DAT_01918c68) {
      fVar14 = (float)dVar3;
    }
    iVar11 = iStack_14;
    if (3 < (int)puStack_20) {
      iStack_1c = ((uint)((int)pfVar7 + -6) >> 2) + 1;
      iStack_10 = iStack_1c * 4;
      iVar10 = 0;
      iVar11 = iStack_1c;
      do {
        fVar12 = *(float *)(iVar10 + 0xc + iStack_14) - fVar14;
        *(float *)(iVar10 + 0xc + iStack_14) = fVar12;
        pfVar6 = (float *)((int)pfVar8 + 1);
        if (fVar15 <= fVar12) {
          pfVar6 = pfVar8;
        }
        fVar12 = *(float *)(iVar10 + 0x28 + iStack_14) - fVar14;
        *(float *)(iVar10 + 0x28 + iStack_14) = fVar12;
        fVar13 = *(float *)(iVar10 + 0x44 + iStack_14) - fVar14;
        pfVar8 = (float *)((int)pfVar6 + 1);
        if (fVar15 <= fVar12) {
          pfVar8 = pfVar6;
        }
        *(float *)(iVar10 + 0x44 + iStack_14) = fVar13;
        fVar12 = *(float *)(iVar10 + 0x60 + iStack_14) - fVar14;
        pfVar6 = (float *)((int)pfVar8 + 1);
        if (fVar15 <= fVar13) {
          pfVar6 = pfVar8;
        }
        *(float *)(iVar10 + 0x60 + iStack_14) = fVar12;
        pfVar8 = (float *)((int)pfVar6 + 1);
        if (fVar15 <= fVar12) {
          pfVar8 = pfVar6;
        }
        iVar10 = iVar10 + 0x70;
        iVar11 = iVar11 + -1;
      } while (iVar11 != 0);
      iVar11 = *(int *)(param_1 + 0xa8);
    }
    if (iStack_10 < (int)puStack_20) {
      pfVar9 = (float *)(iVar11 + iStack_10 * 0x1c + 0xc);
      iVar11 = (int)puStack_20 - iStack_10;
      pfVar6 = pfVar8;
      do {
        fVar12 = *pfVar9;
        *pfVar9 = fVar12 - fVar14;
        pfVar8 = (float *)((int)pfVar6 + 1);
        if (fVar15 <= fVar12 - fVar14) {
          pfVar8 = pfVar6;
        }
        pfVar9 = pfVar9 + 7;
        iVar11 = iVar11 + -1;
        pfVar6 = pfVar8;
      } while (iVar11 != 0);
      iVar11 = *(int *)(param_1 + 0xa8);
    }
    *(float *)(iVar11 + -0x10 + (int)pfVar7 * 0x1c) =
         *(float *)(iVar11 + -0x10 + (int)pfVar7 * 0x1c) - fVar14;
    *(float *)(iVar11 + -0x2c + (int)pfVar7 * 0x1c) =
         *(float *)(iVar11 + -0x2c + (int)pfVar7 * 0x1c) - fVar14;
    pfVar6 = pfVar7 + -16000;
    if ((int)pfVar7 - (int)pfVar8 < 0xfa01) {
      pfVar6 = pfVar8;
    }
    pfVar8 = (float *)((int)pfVar7 - (int)pfVar8);
    pfStack_18 = pfVar7;
    iStack_c = param_1;
    if (0 < (int)pfVar6) {
      *(int *)(param_1 + 0x10c) = (int)(*(int *)(param_1 + 0x10c) + (int)pfVar6);
      puStack_20 = *(undefined **)(param_1 + 0xa8);
      puVar1 = puStack_20 + (int)pfVar6 * 0x1c;
      if (puStack_20 != puVar1) {
        FUN_0055b6b0(&uStack_5,&iStack_1c,&iStack_1c);
        puVar5 = puStack_20;
        iVar11 = *(int *)(param_1 + 0xac) - (int)puVar1;
        FUN_0170cc70(puStack_20,puVar1,iVar11);
        *(undefined **)(iStack_c + 0xac) = puVar5 + iVar11;
      }
      pfVar8 = (float *)((*(int *)(iStack_c + 0xac) - *(int *)(iStack_c + 0xa8)) + -0x38);
      if (pfVar8 < &DAT_0000001c) {
        *(undefined4 *)(iStack_c + 0x10c) = 0x14;
      }
    }
    pfVar7 = pfVar8;
    fVar15 = 0.0;
    if (0.0 < *(float *)(iStack_c + 0x15c)) {
      iStack_10 = 0;
      if (0 < (int)pfStack_18 + -1) {
        pfVar7 = (float *)(*(int *)(iStack_c + 0xa8) + 0x18);
        while (*pfVar7 != *(float *)(iStack_c + 0xb4)) {
          iStack_10 = iStack_10 + 2;
          pfVar7 = pfVar7 + 0xe;
          if ((int)((int)pfStack_18 + -1) <= iStack_10) {
            return pfVar7;
          }
        }
        iVar11 = *(int *)(iStack_c + 0xac) - *(int *)(iStack_c + 0xa8);
        pfVar7 = (float *)(iVar11 * -0x6db6db6d);
        iVar11 = iVar11 / 0x1c + -2;
        if (iStack_10 < iVar11) {
          iVar10 = *(int *)(iStack_c + 0xa8);
          pfVar7 = (float *)(iVar10 + (iVar11 * 7 + 4) * 4);
          do {
            fVar15 = fVar15 + (pfVar7[7] + *pfVar7) * DAT_018ce2f4;
            if (*(float *)(iStack_c + 0x15c) < fVar15) {
              *(int *)(iStack_c + 0x10c) = *(int *)(iStack_c + 0x10c) + (iVar11 - iStack_10);
              iVar11 = iVar10 + iVar11 * 0x1c;
              iVar2 = iVar10 + iStack_10 * 0x1c;
              if (iVar2 == iVar11) {
                puStack_20 = *(undefined **)(iStack_c + 0xac);
              }
              else {
                FUN_0055b6b0(&uStack_5,&puStack_20,&puStack_20);
                puStack_20 = (undefined *)(*(int *)(iStack_c + 0xac) - iVar11);
                FUN_0170cc70(iVar2,iVar11,puStack_20);
                puStack_20 = puStack_20 + iVar2;
                *(undefined **)(iStack_c + 0xac) = puStack_20;
                iVar10 = *(int *)(iStack_c + 0xa8);
              }
              pfVar7 = (float *)(puStack_20 + (-0x38 - iVar10));
              if (pfVar7 < &DAT_0000001c) {
                *(undefined4 *)(iStack_c + 0x10c) = 0x14;
              }
              break;
            }
            iVar11 = iVar11 + -2;
            pfVar7 = pfVar7 + -0xe;
          } while (iStack_10 < iVar11);
        }
        if ((0 < iStack_10) &&
           (pfVar7 = (float *)(iStack_10 + 1),
           (int)pfVar7 < (*(int *)(iStack_c + 0xac) - *(int *)(iStack_c + 0xa8)) / 0x1c)) {
          iVar11 = *(int *)(iStack_c + 0xa8);
          *(undefined8 *)(iVar11 + -0x1c + iStack_10 * 0x1c) =
               *(undefined8 *)(iVar11 + 0x1c + iStack_10 * 0x1c);
          *(undefined4 *)(iVar11 + -0x14 + iStack_10 * 0x1c) =
               *(undefined4 *)(iVar11 + 0x24 + iStack_10 * 0x1c);
          iVar11 = *(int *)(iStack_c + 0xa8);
          pfVar7 = (float *)(iStack_10 + -2);
          uVar4 = *(undefined4 *)(iVar11 + 0x24 + iStack_10 * 0x1c);
          *(undefined8 *)(iVar11 + (int)pfVar7 * 0x1c) =
               *(undefined8 *)(iVar11 + 0x1c + iStack_10 * 0x1c);
          *(undefined4 *)(iVar11 + 8 + (int)pfVar7 * 0x1c) = uVar4;
        }
      }
    }
  }
  return pfVar7;
}



/* FUNCTION 12690 ; VA 0x008333b0 ; FUN_008333b0 */

undefined4 * __fastcall FUN_008333b0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [12];
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7030;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_28);
  uStack_8 = 0;
  FUN_00587490(&iStack_20);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_18 = -(uint)(param_1 != 0) & param_1 + 0x74U;
  puVar3 = (undefined4 *)FUN_007c7a50(uStack_18,5);
  if ((iStack_28 != 0) && (iStack_20 != 0)) {
    uStack_38 = *(undefined4 *)(param_1 + 0xb4);
    uStack_44 = *(undefined4 *)(param_1 + 0x14c);
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_14 = uStack_38;
    puVar4 = (undefined8 *)FUN_00d6cb20(auStack_34);
    uStack_50 = *puVar4;
    uStack_48 = *(undefined4 *)(puVar4 + 1);
    puVar3 = *(undefined4 **)(param_1 + 0xac);
    if (*(undefined4 **)(param_1 + 0xb0) == puVar3) {
      FUN_00725c30(puVar3,&uStack_50);
      uStack_14 = uStack_38;
    }
    else {
      uStack_50._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      *puVar3 = (undefined4)uStack_50;
      puVar3[1] = uStack_50._4_4_;
      puVar3[2] = uStack_48;
      puVar3[3] = uStack_44;
      *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_3c,uStack_40);
      puVar3[6] = uStack_14;
      *(int *)(param_1 + 0xac) = *(int *)(param_1 + 0xac) + 0x1c;
    }
    puVar4 = (undefined8 *)FUN_00d6cb20(auStack_34);
    uStack_50 = *puVar4;
    uStack_48 = *(undefined4 *)(puVar4 + 1);
    puVar3 = *(undefined4 **)(param_1 + 0xac);
    if (*(undefined4 **)(param_1 + 0xb0) == puVar3) {
      puVar3 = (undefined4 *)FUN_00725c30(puVar3,&uStack_50);
    }
    else {
      uStack_50._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      *puVar3 = (undefined4)uStack_50;
      puVar3[1] = uStack_50._4_4_;
      puVar3[2] = uStack_48;
      puVar3[3] = uStack_44;
      *(ulonglong *)(puVar3 + 4) = CONCAT44(uStack_3c,uStack_40);
      puVar3[6] = uStack_14;
      *(int *)(param_1 + 0xac) = *(int *)(param_1 + 0xac) + 0x1c;
    }
    if (*(char *)(param_1 + 0x150) != '\0') {
      puVar3 = (undefined4 *)FUN_007c7840(uStack_18,5);
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    puVar3 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      puVar3 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar3 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    puVar3 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar3 = (undefined4 *)(**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar3 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 12691 ; VA 0x00833570 ; FUN_00833570 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_00833570(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  bool bVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  undefined4 *puVar11;
  undefined auStack_18 [4];
  int *piStack_14;
  undefined auStack_10 [4];
  int *piStack_c;
  char cStack_5;
  
  piStack_c = (int *)0x0;
  piVar10 = (int *)FUN_00587490(auStack_18);
  bVar5 = false;
  if (*piVar10 == param_2) {
    piVar10 = (int *)FUN_00587490(auStack_10);
    bVar5 = true;
    cStack_5 = '\x01';
    if (*piVar10 == param_3) goto LAB_008335bf;
  }
  cStack_5 = '\0';
LAB_008335bf:
  piVar9 = piStack_c;
  if ((bVar5) && (piStack_c != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_c + 1;
    iVar2 = *piVar1;
    piVar10 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      piVar10 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar10 = (int *)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  piVar9 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piVar10 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      piVar10 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar10 = (int *)(**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (cStack_5 == '\0') {
    puVar11 = (undefined4 *)FUN_0060e0c0(auStack_18,param_2);
    uVar3 = *puVar11;
    uVar4 = puVar11[1];
    *puVar11 = 0;
    puVar11[1] = 0;
    *(undefined4 *)(param_1 + 0x11c) = uVar3;
    piVar10 = *(int **)(param_1 + 0x120);
    *(undefined4 *)(param_1 + 0x120) = uVar4;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar2 = piVar10[2] + -1;
      piVar10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[2] + -1;
      piStack_14[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    puVar11 = (undefined4 *)FUN_0060e0c0(auStack_18,param_3);
    uVar3 = *puVar11;
    uVar4 = puVar11[1];
    *puVar11 = 0;
    puVar11[1] = 0;
    *(undefined4 *)(param_1 + 0x124) = uVar3;
    piVar10 = *(int **)(param_1 + 0x128);
    *(undefined4 *)(param_1 + 0x128) = uVar4;
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar2 = piVar10[2] + -1;
      piVar10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar10 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar10 = piStack_14 + 2;
      iVar2 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar8 = _UNK_018c4ebc;
    uVar7 = _UNK_018c4eb8;
    uVar6 = _UNK_018c4eb4;
    uVar4 = _DAT_018c4eb0;
    uVar3 = DAT_018c45d0;
    *(undefined4 *)(param_1 + 0xac) = *(undefined4 *)(param_1 + 0xa8);
    *(undefined4 *)(param_1 + 0xf0) = uVar4;
    *(undefined4 *)(param_1 + 0xf4) = uVar6;
    *(undefined4 *)(param_1 + 0xf8) = uVar7;
    *(undefined4 *)(param_1 + 0xfc) = uVar8;
    *(undefined4 *)(param_1 + 0x10c) = 0;
    *(ulonglong *)(param_1 + 0x100) = CONCAT44(uVar3,uVar3);
    *(undefined *)(param_1 + 0x108) = 1;
    piVar10 = (int *)FUN_008333b0();
  }
  return piVar10;
}



/* FUNCTION 12692 ; VA 0x00833720 ; FUN_00833720 */

void * __thiscall FUN_00833720(int param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  void *pvVar5;
  undefined auStack_3c [24];
  undefined2 auStack_24 [2];
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017b7058;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if ((*(int *)(param_1 + 0xd0) != 0) && (*(int *)(param_1 + 0xd8) != 0)) {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    iStack_8 = 0;
    if (*(int *)(param_2 + 0x10) == 0) {
      ExceptionList = &pvStack_10;
      FUN_007735a0(*(int *)(*(int *)(param_1 + 8) + 0x4ec) + 0x24,3);
      FUN_005587e0(&uStack_20);
      FUN_00550b30();
    }
    else {
      ExceptionList = &pvStack_10;
      FUN_0054ef60(param_2);
      iStack_8._0_1_ = 1;
      FUN_009cbbb0(auStack_3c);
      iStack_8._0_1_ = 2;
      uVar4 = FUN_00782480(&uStack_20,auStack_3c,1,param_3,0x425c0000,0);
      FUN_005587e0(uVar4);
      FUN_00550b30();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    auStack_24[0] = 1;
    uStack_20 = 0;
    uStack_1c = 0;
    FUN_0078e550(0,&uStack_18,auStack_24);
    auStack_24[0] = 1;
    uStack_20 = 0;
    uStack_1c = 0;
    pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    if (*(int *)(param_1 + 0xe0) != 0) {
      auStack_24[0] = 1;
      uStack_20 = 0;
      uStack_1c = 0;
      pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    }
    if (*(int *)(param_1 + 0xe8) != 0) {
      auStack_24[0] = 1;
      uStack_20 = 0;
      uStack_1c = 0;
      pvVar5 = (void *)FUN_0078e550(0,&uStack_18,auStack_24);
    }
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 12693 ; VA 0x008338f0 ; FUN_008338f0 */

int __fastcall FUN_008338f0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_011590c0();
  *(undefined4 *)(param_1 + 0x24) = 0;
  piVar3 = *(int **)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x28) = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0083392e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 12694 ; VA 0x00833940 ; FUN_00833940 */

void __thiscall FUN_00833940(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b708c;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x5c) != *(int *)(param_1 + 0x60)) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4210)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4210), DAT_01eb4210 == -1)) {
      uStack_8 = 0;
      uVar10 = FUN_0152dab0("Render","updatePlaneEffect",0xffffffff);
      DAT_01eb420c = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb4208 = (undefined4)uVar10;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb4210);
    }
    uVar3 = DAT_01eb420c;
    uVar2 = DAT_01eb4208;
    uVar10 = FUN_0152d930(DAT_01eb4208,DAT_01eb420c);
    uStack_8 = 1;
    uVar4 = FUN_01675290(DAT_01eb41bc);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar5 = (**(code **)(**(int **)(param_1 + 4) + 0x10))();
    if (iVar5 != 0) {
      puVar1 = *(undefined4 **)(param_1 + 0x60);
      puVar9 = *(undefined4 **)(param_1 + 0x5c);
      iVar7 = 0;
      if (puVar9 != puVar1) {
        iVar8 = 64000;
        do {
          iVar6 = (**(code **)(*(int *)*puVar9 + 4))(iVar5 + iVar7 * 0x1c,iVar8);
          if (iVar6 != 0) {
            (**(code **)(*(int *)*puVar9 + 0xc))(param_2,iVar7,iVar6);
            iVar7 = iVar7 + iVar6;
            iVar8 = iVar8 - iVar6;
          }
          puVar9 = puVar9 + 1;
        } while (puVar9 != puVar1);
      }
      (**(code **)(**(int **)(param_1 + 4) + 0x14))();
    }
    *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x5c);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar4);
    uStack_8 = 6;
    FUN_0152dda0(uVar2,uVar3,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12695 ; VA 0x00833ae0 ; FUN_00833ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00833ae0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  float *pfVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  FUN_00832fe0();
  FUN_00830bc0();
  uVar4 = _UNK_018c4ebc;
  uVar3 = _UNK_018c4eb8;
  uVar2 = _UNK_018c4eb4;
  uVar1 = DAT_018c45d0;
  if (0x13 < *(int *)(param_1 + 0x78)) {
    *(undefined4 *)(param_1 + 0x5c) = _DAT_018c4eb0;
    *(undefined4 *)(param_1 + 0x60) = uVar2;
    *(undefined4 *)(param_1 + 100) = uVar3;
    *(undefined4 *)(param_1 + 0x68) = uVar4;
    *(undefined4 *)(param_1 + 0x78) = 0;
    *(ulonglong *)(param_1 + 0x6c) = CONCAT44(uVar1,uVar1);
    *(undefined *)(param_1 + 0x74) = 1;
    for (pfVar5 = *(float **)(param_1 + 0x14); pfVar5 != *(float **)(param_1 + 0x18);
        pfVar5 = pfVar5 + 7) {
      fVar8 = *(float *)(param_1 + 100);
      if (pfVar5[2] <= *(float *)(param_1 + 100)) {
        fVar8 = pfVar5[2];
      }
      fVar7 = *(float *)(param_1 + 0x60);
      if (pfVar5[1] <= *(float *)(param_1 + 0x60)) {
        fVar7 = pfVar5[1];
      }
      fVar6 = *(float *)(param_1 + 0x5c);
      if (*pfVar5 <= *(float *)(param_1 + 0x5c)) {
        fVar6 = *pfVar5;
      }
      *(ulonglong *)(param_1 + 0x5c) = CONCAT44(fVar7,fVar6);
      *(float *)(param_1 + 100) = fVar8;
      fVar8 = *(float *)(param_1 + 0x70);
      if (*(float *)(param_1 + 0x70) <= pfVar5[2]) {
        fVar8 = pfVar5[2];
      }
      fVar7 = *(float *)(param_1 + 0x6c);
      if (*(float *)(param_1 + 0x6c) <= pfVar5[1]) {
        fVar7 = pfVar5[1];
      }
      fVar6 = *(float *)(param_1 + 0x68);
      if (*(float *)(param_1 + 0x68) <= *pfVar5) {
        fVar6 = *pfVar5;
      }
      *(ulonglong *)(param_1 + 0x68) = CONCAT44(fVar7,fVar6);
      *(float *)(param_1 + 0x70) = fVar8;
    }
  }
  if (*(char *)(param_1 + 0x74) != '\0') {
    FUN_008411b0(param_1 + 0x5c,*(undefined4 *)(param_1 + -0x90));
    *(undefined *)(param_1 + 0x74) = 0;
  }
  return;
}



/* FUNCTION 12696 ; VA 0x00833c00 ; FUN_00833c00 */

void __fastcall FUN_00833c00(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b70b4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb4220) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb4220), cVar3 = DAT_01d7ad48,
     DAT_01eb4220 == -1)) {
    uStack_8 = 0;
    uVar6 = FUN_0152dab0("Render","updateEffectBoundings",0xffffffff);
    if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar6);
    }
    uStack_8 = 0xffffffff;
    DAT_01eb4218 = (int)uVar6;
    DAT_01eb421c = (int)((ulonglong)uVar6 >> 0x20);
    FUN_016f37bf(&DAT_01eb4220);
  }
  uVar5 = DAT_01eb421c;
  uVar4 = DAT_01eb4218;
  cVar3 = DAT_01d7ad48;
  uVar6 = FUN_01532c80(DAT_01eb4218,DAT_01eb421c);
  uStack_8 = 1;
  puVar1 = *(undefined4 **)(param_1 + 0x6c);
  for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
    (**(code **)(*(int *)puVar2[2] + 8))();
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar4,uVar5,uVar6);
  if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12697 ; VA 0x00833d60 ; FUN_00833d60 */

int __fastcall FUN_00833d60(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined auStack_2c [12];
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b70d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8 = 0;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((((iStack_20 != 0) && (iStack_18 != 0)) && (*(int *)(iStack_20 + 0x34) != 0)) &&
     (*(int *)(iStack_18 + 0x34) != 0)) {
    puVar4 = (undefined8 *)FUN_00d6cb20(auStack_2c);
    *(undefined8 *)(param_1 + 0xb8) = *puVar4;
    *(undefined4 *)(param_1 + 0xc0) = *(undefined4 *)(puVar4 + 1);
    puVar4 = (undefined8 *)FUN_00d6cb20(auStack_2c);
    *(undefined8 *)(param_1 + 0xc4) = *puVar4;
    iVar3 = *(int *)(puVar4 + 1);
    *(int *)(param_1 + 0xcc) = iVar3;
    *(undefined *)(param_1 + 0xd0) = 1;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 12698 ; VA 0x00833e70 ; FUN_00833e70 */

int __thiscall FUN_00833e70(int param_1,float *param_2,uint param_3)

{
  float *pfVar1;
  uint uVar2;
  undefined8 *puVar3;
  int iVar4;
  int iVar5;
  float10 fVar6;
  float fVar7;
  float fVar8;
  double dVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fStack_134;
  undefined8 uStack_128;
  float fStack_120;
  float fStack_11c;
  float fStack_118;
  uint uStack_114;
  float fStack_110;
  float fStack_10c;
  float fStack_108;
  float fStack_104;
  undefined8 uStack_100;
  float fStack_f4;
  float fStack_f0;
  uint uStack_ec;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  undefined8 uStack_bc;
  ulonglong uStack_b0;
  undefined8 uStack_a4;
  float fStack_9c;
  undefined8 uStack_98;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  double dStack_68;
  double dStack_60;
  double dStack_58;
  float fStack_48;
  float fStack_3c;
  float fStack_30;
  float fStack_24;
  undefined auStack_20 [12];
  undefined auStack_14 [16];
  
  uVar2 = (*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x14)) / 0x1c;
  if (uVar2 < 3) {
    return 0;
  }
  FUN_00832d10();
  fStack_11c = 0.0;
  uStack_114 = -(uint)(param_3 < uVar2) & uVar2 - param_3;
  uStack_a4 = *(undefined8 *)(*(int *)(param_1 + -0x8c) + 0x40);
  fStack_9c = *(float *)(*(int *)(param_1 + -0x8c) + 0x48);
  fStack_118 = 0.0;
  fStack_134 = 0.0;
  uStack_ec = uStack_114;
  if (uStack_114 < uVar2 - 1) {
    iVar5 = uStack_114 * 0x1c;
    fVar7 = DAT_018ce2f4;
    do {
      iVar4 = *(int *)(param_1 + 0x14);
      pfVar1 = (float *)(iVar4 + iVar5);
      fStack_cc = *pfVar1;
      fStack_c8 = pfVar1[1];
      fVar8 = pfVar1[2];
      fStack_c0 = pfVar1[3];
      uStack_bc = *(undefined8 *)(iVar4 + 0x10 + iVar5);
      pfVar1 = (float *)(iVar4 + 0x1c + iVar5);
      fStack_110 = *pfVar1;
      fStack_10c = pfVar1[1];
      fStack_108 = pfVar1[2];
      fStack_104 = pfVar1[3];
      uStack_100 = *(undefined8 *)(iVar4 + 0x2c + iVar5);
      fStack_c4 = fVar8;
      if (*(char *)(param_1 + 0xbd) != '\0') {
        if (uStack_114 == uVar2 - 2) {
          uStack_b0 = (ulonglong)(uint)((fStack_110 + fStack_cc) * fVar7);
          fVar13 = (fStack_108 + fVar8) * DAT_018ce2f4;
          fVar7 = (fStack_10c + fStack_c8) * DAT_018ce2f4;
          dVar9 = (double)((fStack_c8 - fStack_10c) * (fStack_c8 - fStack_10c) +
                           (fStack_cc - fStack_110) * (fStack_cc - fStack_110) +
                          (fVar8 - fStack_108) * (fVar8 - fStack_108));
          FUN_017267a0();
          fVar8 = (float)dVar9 * DAT_018ce2f4;
          fStack_134 = fStack_134 * fVar8;
          fStack_118 = fStack_118 * fVar8;
          fStack_11c = fStack_11c * fVar8;
          fStack_110 = (float)uStack_b0 - fStack_118;
          fStack_c4 = fVar13 + fStack_134;
          fStack_108 = fVar13 - fStack_134;
          fStack_10c = fVar7 - fStack_11c;
          fStack_cc = (float)uStack_b0 + fStack_118;
          fStack_c8 = fVar7 + fStack_11c;
          fStack_48 = fStack_c4;
          fStack_3c = fStack_108;
        }
        else {
          fVar13 = (fStack_110 + fStack_cc) * fVar7;
          fVar11 = (fStack_10c + fStack_c8) * fVar7;
          fVar16 = (*(float *)(iVar4 + 0x38 + iVar5) + *(float *)(iVar4 + 0x54 + iVar5)) * fVar7;
          fVar12 = (*(float *)(iVar4 + 0x3c + iVar5) + *(float *)(iVar4 + 0x58 + iVar5)) * fVar7;
          uStack_b0 = (ulonglong)(uint)fVar13;
          fVar17 = fVar16 - fVar13;
          fVar15 = (fStack_108 + fVar8) * fVar7;
          fVar10 = fVar12 - fVar11;
          fVar14 = (fVar12 + fVar11) * fVar7 - uStack_a4._4_4_;
          fVar12 = (*(float *)(iVar4 + 0x40 + iVar5) + *(float *)(iVar4 + 0x5c + iVar5)) * fVar7;
          fVar16 = (fVar16 + fVar13) * fVar7 - (float)uStack_a4;
          fVar13 = fVar12 - fVar15;
          fVar7 = (fVar12 + fVar15) * fVar7 - fStack_9c;
          fStack_8c = fVar10 * fVar7 - fVar13 * fVar14;
          fStack_88 = fVar13 * fVar16 - fVar17 * fVar7;
          fStack_84 = fVar17 * fVar14 - fVar10 * fVar16;
          fStack_f4 = fStack_cc;
          fStack_f0 = fStack_c8;
          FUN_00831d60(&uStack_128);
          dVar9 = (double)(uStack_128._4_4_ * uStack_128._4_4_ +
                           (float)uStack_128 * (float)uStack_128 + fStack_120 * fStack_120);
          if (NAN(dVar9) == (dVar9 == 0.0)) {
            dStack_68 = (double)CONCAT44((uint)((ulonglong)dVar9 >> 0x20) & DAT_018c0da0._4_4_,
                                         SUB84(dVar9,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
            dStack_58 = (double)CONCAT44((uint)((ulonglong)(dVar9 - 0.0) >> 0x20) &
                                         DAT_018c0da0._4_4_,
                                         SUB84(dVar9 - 0.0,0) & (uint)DAT_018c0da0);
            fVar6 = (float10)FUN_01160810();
            dStack_60 = (double)fVar6;
            dVar9 = DAT_018f76b0;
            if ((NAN(dStack_68) || NAN(dStack_60)) == (dStack_68 == dStack_60)) {
              dVar9 = dStack_68 * DAT_018f76b0;
            }
            if (dStack_58 <= dVar9) goto LAB_008342a0;
          }
          else {
LAB_008342a0:
            fStack_80 = fStack_f4 - fStack_110;
            fStack_7c = fStack_f0 - fStack_10c;
            fStack_78 = fVar8 - fStack_108;
            puVar3 = (undefined8 *)FUN_00831d60(auStack_20);
            uStack_128 = *puVar3;
            fStack_120 = *(float *)(puVar3 + 1);
          }
          if (uStack_114 != 0) {
            fStack_74 = (fStack_118 - (float)uStack_128) * DAT_018ce2f4 + (float)uStack_128;
            fStack_70 = (fStack_11c - uStack_128._4_4_) * DAT_018ce2f4 + uStack_128._4_4_;
            fStack_6c = (fStack_134 - fStack_120) * DAT_018ce2f4 + fStack_120;
            puVar3 = (undefined8 *)FUN_00831d60(auStack_14);
            uStack_128 = *puVar3;
            fStack_120 = *(float *)(puVar3 + 1);
          }
          dVar9 = (double)((fStack_f0 - fStack_10c) * (fStack_f0 - fStack_10c) +
                           (fStack_f4 - fStack_110) * (fStack_f4 - fStack_110) +
                          (fVar8 - fStack_108) * (fVar8 - fStack_108));
          uStack_98 = uStack_128;
          fStack_90 = fStack_120;
          FUN_017267a0();
          fVar7 = (float)dVar9 * DAT_018ce2f4;
          fStack_120 = fStack_120 * fVar7;
          uStack_128._0_4_ = (float)uStack_128 * fVar7;
          uStack_128._4_4_ = uStack_128._4_4_ * fVar7;
          fStack_c4 = fVar15 + fStack_120;
          fStack_110 = (float)uStack_b0 - (float)uStack_128;
          fStack_c8 = fVar11 + uStack_128._4_4_;
          fStack_cc = (float)uStack_b0 + (float)uStack_128;
          fStack_108 = fVar15 - fStack_120;
          fStack_10c = fVar11 - uStack_128._4_4_;
          fStack_134 = fStack_90;
          fStack_11c = uStack_98._4_4_;
          fStack_118 = (float)uStack_98;
          fStack_30 = fStack_c4;
          fStack_24 = fStack_108;
        }
      }
      fVar7 = DAT_018ce2f4;
      fVar17 = (fStack_108 + fStack_c4) * DAT_018ce2f4;
      fVar10 = (DAT_018ce2f8 - fStack_c0 / *(float *)(param_1 + 0xb8)) * DAT_018fee54 * DAT_01918c78
      ;
      iVar4 = (int)fVar10;
      fVar8 = *(float *)(param_1 + 0xcc + iVar4 * 4);
      fVar10 = fVar10 - (float)iVar4;
      fVar13 = *(float *)(param_1 + 0x14c + iVar4 * 0xc);
      fVar11 = *(float *)(param_1 + 0x150 + iVar4 * 0xc);
      fVar15 = *(float *)(param_1 + 0x154 + iVar4 * 0xc);
      fVar12 = *(float *)(param_1 + 0x2cc + iVar4 * 4);
      uStack_d0._3_1_ =
           (undefined)(int)((*(float *)(param_1 + 0xd0 + iVar4 * 4) - fVar8) * fVar10 + fVar8);
      uStack_d0._0_3_ =
           CONCAT12((char)(int)((*(float *)(param_1 + 0x160 + iVar4 * 0xc) - fVar15) * fVar10 +
                               fVar15),
                    CONCAT11((char)(int)((*(float *)(param_1 + 0x15c + iVar4 * 0xc) - fVar11) *
                                         fVar10 + fVar11),
                             (char)(int)((*(float *)(param_1 + 0x158 + iVar4 * 0xc) - fVar13) *
                                         fVar10 + fVar13)));
      fVar12 = (*(float *)(param_1 + 0x2d0 + iVar4 * 4) - fVar12) * fVar10 + fVar12;
      fVar11 = (fStack_c4 - fStack_108) * DAT_018ce2f4 * fVar12;
      fVar8 = (fStack_110 + fStack_cc) * DAT_018ce2f4;
      fVar15 = (fStack_cc - fStack_110) * DAT_018ce2f4 * fVar12;
      fVar13 = (fStack_10c + fStack_c8) * DAT_018ce2f4;
      fVar12 = (fStack_c8 - fStack_10c) * DAT_018ce2f4 * fVar12;
      fStack_e4 = fVar13 - fVar12;
      fStack_e8 = fVar8 - fVar15;
      fStack_e0 = fVar17 - fVar11;
      iVar5 = iVar5 + 0x38;
      uStack_dc = 0x3f800000;
      *param_2 = fVar15 + fVar8;
      param_2[1] = fVar12 + fVar13;
      param_2[2] = fVar11 + fVar17;
      param_2[3] = 0.0;
      *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_d4,uStack_bc._4_4_);
      uStack_d8 = uStack_100._4_4_;
      param_2[6] = uStack_d0;
      param_2[7] = fStack_e8;
      param_2[8] = fStack_e4;
      param_2[9] = fStack_e0;
      param_2[10] = 1.0;
      *(ulonglong *)(param_2 + 0xb) = CONCAT44(uStack_d4,uStack_100._4_4_);
      param_2[0xd] = uStack_d0;
      param_2 = param_2 + 0xe;
      uStack_114 = uStack_114 + 2;
    } while (uStack_114 < uVar2 - 1);
  }
  return uVar2 - uStack_ec;
}



/* FUNCTION 12699 ; VA 0x00834760 ; FUN_00834760 */

void __fastcall FUN_00834760(int *param_1)

{
  if (param_1[3] == param_1[4]) {
    if (param_1 == (int *)0x74) {
      param_1 = (int *)0x0;
    }
    FUN_007c64b0(param_1);
    return;
  }
  FUN_00831150();
  (**(code **)(*param_1 + 0x44))();
  *(undefined *)(param_1 + 0xb) = 1;
  return;
}



/* FUNCTION 12700 ; VA 0x008347a0 ; FUN_008347a0 */

void __thiscall FUN_008347a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  int *piVar2;
  
  if ((3 < (uint)((*(int *)(param_1 + 0xac) - *(int *)(param_1 + 0xa8)) / 0x1c)) && (param_4 == 0))
  {
    iVar1 = *(int *)(param_1 + 0xa4);
    param_4 = param_1 + 0x94;
    piVar2 = *(int **)(iVar1 + 0x60);
    if (*(int **)(iVar1 + 100) == piVar2) {
      FUN_006030d0(piVar2,&param_4);
    }
    else {
      *piVar2 = param_4;
      *(int *)(iVar1 + 0x60) = *(int *)(iVar1 + 0x60) + 4;
    }
    if (*(char *)(*(int *)(*(int *)(param_1 + 8) + 0x510) + 0x20) != '\0') {
      FUN_008416d0(*(int *)(param_1 + 8),param_1 + 0x18);
    }
  }
  return;
}



/* FUNCTION 12701 ; VA 0x00834820 ; FUN_00834820 */

int __thiscall
FUN_00834820(int *param_1,undefined8 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined8 *puVar6;
  uint uVar7;
  uint uVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  int iVar11;
  undefined8 *puVar12;
  
  iVar5 = *param_1;
  iVar4 = (param_1[1] - *param_1) / 0xc;
  if (iVar4 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar7 = (param_1[2] - *param_1) / 0xc;
  uVar8 = uVar1;
  if ((uVar7 <= 0x15555555 - (uVar7 >> 1)) && (uVar8 = (uVar7 >> 1) + uVar7, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar7 = uVar8 * 0xc;
  if (uVar8 < 0x15555556) {
    uVar8 = uVar7;
    if (0xfff < uVar7) goto LAB_008348b9;
    if (uVar7 == 0) {
      puVar10 = (undefined8 *)0x0;
    }
    else {
      puVar10 = (undefined8 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_008348b9:
    uVar3 = uVar8 + 0x23;
    if (uVar3 <= uVar8) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00834a05;
    puVar10 = (undefined8 *)(iVar4 + 0x23U & 0xffffffe0);
    *(int *)((int)puVar10 + -4) = iVar4;
  }
  iVar5 = (((int)param_2 - iVar5) / 0xc) * 0xc;
  uVar2 = *param_4;
  *(undefined4 *)(iVar5 + (int)puVar10) = *param_3;
  *(undefined4 *)(iVar5 + 4 + (int)puVar10) = param_3[1];
  *(undefined4 *)(iVar5 + 8 + (int)puVar10) = uVar2;
  puVar12 = (undefined8 *)param_1[1];
  puVar6 = (undefined8 *)*param_1;
  puVar9 = puVar10;
  if (param_2 == puVar12) {
    for (; puVar6 != puVar12; puVar6 = (undefined8 *)((int)puVar6 + 0xc)) {
      *puVar9 = *puVar6;
      *(undefined4 *)(puVar9 + 1) = *(undefined4 *)(puVar6 + 1);
      puVar9 = (undefined8 *)((int)puVar9 + 0xc);
    }
  }
  else {
    if (puVar6 != param_2) {
      do {
        *puVar9 = *puVar6;
        puVar12 = puVar6 + 1;
        puVar6 = (undefined8 *)((int)puVar6 + 0xc);
        *(undefined4 *)(puVar9 + 1) = *(undefined4 *)puVar12;
        puVar9 = (undefined8 *)((int)puVar9 + 0xc);
      } while (puVar6 != param_2);
      puVar12 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar12) {
      puVar6 = (undefined8 *)(iVar5 + 0xc + (int)puVar10);
      do {
        *puVar6 = *param_2;
        puVar9 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar6 + 1) = *(undefined4 *)puVar9;
        puVar6 = (undefined8 *)((int)puVar6 + 0xc);
      } while (param_2 != puVar12);
    }
  }
  iVar4 = *param_1;
  if (iVar4 != 0) {
    uVar8 = ((param_1[2] - iVar4) / 0xc) * 0xc;
    iVar11 = iVar4;
    if (0xfff < uVar8) {
      iVar11 = *(int *)(iVar4 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar4 - iVar11) - 4U) {
LAB_00834a05:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar11,uVar8);
  }
  *param_1 = (int)puVar10;
  param_1[1] = (int)puVar10 + uVar1 * 0xc;
  param_1[2] = uVar7 + (int)puVar10;
  return *param_1 + iVar5;
}



/* FUNCTION 12702 ; VA 0x00834a10 ; FUN_00834a10 */

int FUN_00834a10(int param_1,int param_2)

{
  undefined8 *puVar1;
  int *piVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iStack_24;
  int iStack_20;
  
  iVar7 = (param_2 - param_1) * 0x2aaaaaab;
  uVar5 = (param_2 - param_1) / 0xc;
  iVar10 = (int)uVar5 >> 1;
  if (0 < iVar10) {
    iVar9 = (int)(uVar5 - 1) >> 1;
    iVar6 = param_1 + iVar10 * 0xc;
    do {
      uVar3 = *(undefined8 *)(iVar6 + -0xc);
      iVar7 = iVar6 + -0xc;
      iVar10 = iVar10 + -1;
      uVar4 = *(undefined4 *)(iVar6 + -4);
      iVar6 = iVar10;
      while (iVar6 < iVar9) {
        iVar8 = param_1 + iVar6 * 0x18;
        iVar8 = (2 - (uint)((uint)(*(int *)(param_1 + 0x10 + iVar6 * 0x18) + *(int *)(iVar8 + 0xc))
                           < (uint)(*(int *)(iVar8 + 0x1c) + *(int *)(iVar8 + 0x18)))) + iVar6 * 2;
        puVar1 = (undefined8 *)(param_1 + iVar6 * 0xc);
        *puVar1 = *(undefined8 *)(param_1 + iVar8 * 0xc);
        *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + iVar8 * 0xc + 8);
        iVar6 = iVar8;
      }
      if ((iVar6 == iVar9) && ((uVar5 & 1) == 0)) {
        puVar1 = (undefined8 *)(param_1 + iVar6 * 0xc);
        *puVar1 = *(undefined8 *)(param_1 + -0xc + uVar5 * 0xc);
        *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + uVar5 * 0xc + -4);
        iVar6 = uVar5 - 1;
      }
      if (iVar10 < iVar6) {
        iStack_20 = (int)((ulonglong)uVar3 >> 0x20);
        iStack_24 = (int)uVar3;
        do {
          iVar8 = iVar6 + -1 >> 1;
          piVar2 = (int *)(param_1 + iVar8 * 0xc);
          if ((uint)(piVar2[1] + *piVar2) <= (uint)(iStack_20 + iStack_24)) break;
          puVar1 = (undefined8 *)(param_1 + iVar6 * 0xc);
          *puVar1 = *(undefined8 *)piVar2;
          *(int *)(puVar1 + 1) = piVar2[2];
          iVar6 = iVar8;
        } while (iVar10 < iVar8);
      }
      *(undefined8 *)(param_1 + iVar6 * 0xc) = uVar3;
      *(undefined4 *)(param_1 + 8 + iVar6 * 0xc) = uVar4;
      iVar6 = iVar7;
    } while (0 < iVar10);
  }
  return iVar7;
}



/* FUNCTION 12703 ; VA 0x00834b60 ; FUN_00834b60 */

void FUN_00834b60(int *param_1,int *param_2,int *param_3)

{
  undefined8 uVar1;
  int iVar2;
  
  iVar2 = param_2[1];
  if ((uint)(*param_1 + param_1[1]) < (uint)(*param_2 + iVar2)) {
    uVar1 = *(undefined8 *)param_2;
    iVar2 = param_2[2];
    *(undefined8 *)param_2 = *(undefined8 *)param_1;
    param_2[2] = param_1[2];
    *(undefined8 *)param_1 = uVar1;
    param_1[2] = iVar2;
    iVar2 = param_2[1];
  }
  if ((uint)(*param_2 + iVar2) < (uint)(param_3[1] + *param_3)) {
    uVar1 = *(undefined8 *)param_3;
    iVar2 = param_3[2];
    *(undefined8 *)param_3 = *(undefined8 *)param_2;
    param_3[2] = param_2[2];
    *(undefined8 *)param_2 = uVar1;
    param_2[2] = iVar2;
    if ((uint)(*param_1 + param_1[1]) < (uint)(*param_2 + param_2[1])) {
      *(undefined8 *)param_2 = *(undefined8 *)param_1;
      param_2[2] = param_1[2];
      *(undefined8 *)param_1 = uVar1;
      param_1[2] = iVar2;
    }
  }
  return;
}



/* FUNCTION 12704 ; VA 0x00834bf0 ; FUN_00834bf0 */

void FUN_00834bf0(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  undefined8 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar5 = param_3 + -3;
  piVar8 = param_2 + (((int)param_3 - (int)param_2) / 0xc >> 1) * 3;
  iVar2 = ((int)piVar5 - (int)param_2) / 0xc;
  if (iVar2 < 0x29) {
    FUN_00834b60(param_2,piVar8,piVar5,param_4);
  }
  else {
    iVar2 = iVar2 + 1 >> 3;
    FUN_00834b60(param_2,param_2 + iVar2 * 3,param_2 + iVar2 * 6,param_4);
    FUN_00834b60(piVar8 + iVar2 * -3,piVar8,piVar8 + iVar2 * 3,param_4);
    FUN_00834b60(piVar5 + iVar2 * -6,piVar5 + iVar2 * -3,piVar5,param_4);
    FUN_00834b60(param_2 + iVar2 * 3,piVar8,piVar5 + iVar2 * -3,param_4);
  }
  piVar5 = piVar8 + 3;
  for (; ((param_2 < piVar8 &&
          (uVar3 = *piVar8 + piVar8[1], uVar4 = piVar8[-3] + piVar8[-2],
          uVar3 > uVar4 || uVar4 == uVar3)) && (uVar3 <= uVar4)); piVar8 = piVar8 + -3) {
  }
  piVar10 = piVar5;
  piStack_10 = piVar5;
  piStack_8 = piVar5;
  piStack_c = piVar8;
  piVar9 = piVar8;
  if (piVar5 < param_3) {
    do {
      piVar10 = piVar5;
      piStack_10 = piVar5;
      piStack_8 = piVar5;
      if (((uint)(piVar8[1] + *piVar8) < (uint)(*piVar5 + piVar5[1])) ||
         ((uint)(*piVar5 + piVar5[1]) < (uint)(piVar8[1] + *piVar8))) break;
      piVar5 = piVar5 + 3;
      piVar10 = piVar5;
      piStack_10 = piVar5;
      piStack_8 = piVar5;
    } while (piVar5 < param_3);
  }
joined_r0x00834d17:
  do {
    piVar11 = piStack_c;
    if (param_3 <= piVar5) {
joined_r0x00834d6b:
      while (piVar7 = piVar8, piVar12 = piVar10, param_2 < piVar8) {
        piVar6 = piVar11 + -3;
        piVar10 = piVar9;
        piVar5 = piStack_10;
        if ((uint)(piVar11[-2] + *piVar6) <= (uint)(*piVar9 + piVar9[1])) {
          piVar7 = piStack_c;
          piVar12 = piStack_8;
          if ((uint)(piVar11[-2] + *piVar6) < (uint)(*piVar9 + piVar9[1])) break;
          piVar10 = piVar9 + -3;
          if (piVar10 != piVar6) {
            uVar1 = *(undefined8 *)piVar10;
            iVar2 = piVar9[-1];
            *(undefined8 *)piVar10 = *(undefined8 *)piVar6;
            piVar9[-1] = piVar11[-1];
            *(undefined8 *)piVar6 = uVar1;
            piVar11[-1] = iVar2;
          }
        }
        piStack_c = piStack_c + -3;
        piVar9 = piVar10;
        piVar10 = piStack_8;
        piVar11 = piVar6;
        piVar8 = piStack_c;
      }
      if (piVar7 == param_2) {
        if (piVar5 == param_3) {
          param_1[1] = piVar12;
          *param_1 = piVar9;
          return;
        }
        if (piVar12 != piVar5) {
          uVar1 = *(undefined8 *)piVar9;
          iVar2 = piVar9[2];
          *(undefined8 *)piVar9 = *(undefined8 *)piVar12;
          piVar9[2] = piVar12[2];
          *(undefined8 *)piVar12 = uVar1;
          piVar12[2] = iVar2;
        }
        iVar2 = piVar9[2];
        uVar1 = *(undefined8 *)piVar9;
        *(undefined8 *)piVar9 = *(undefined8 *)piVar5;
        piVar9[2] = piVar5[2];
        *(undefined8 *)piVar5 = uVar1;
        piVar5[2] = iVar2;
        piVar5 = piVar5 + 3;
        piVar8 = piVar7;
        piVar10 = piVar12 + 3;
        piStack_10 = piVar5;
        piStack_8 = piVar12 + 3;
        piVar9 = piVar9 + 3;
      }
      else {
        piVar8 = piVar7 + -3;
        piStack_c = piVar8;
        if (piVar5 == param_3) {
          piVar11 = piVar9 + -3;
          if (piVar8 != piVar11) {
            uVar1 = *(undefined8 *)piVar8;
            iVar2 = piVar7[-1];
            *(undefined8 *)piVar8 = *(undefined8 *)piVar11;
            piVar7[-1] = piVar9[-1];
            *(undefined8 *)piVar11 = uVar1;
            piVar9[-1] = iVar2;
          }
          iVar2 = piVar9[-1];
          piVar10 = piVar12 + -3;
          uVar1 = *(undefined8 *)piVar11;
          *(undefined8 *)piVar11 = *(undefined8 *)piVar10;
          piVar9[-1] = piVar12[-1];
          *(undefined8 *)piVar10 = uVar1;
          piVar12[-1] = iVar2;
          piStack_8 = piVar10;
          piVar9 = piVar11;
        }
        else {
          iVar2 = piVar5[2];
          uVar1 = *(undefined8 *)piVar5;
          *(undefined8 *)piVar5 = *(undefined8 *)piVar8;
          piVar5[2] = piVar7[-1];
          piVar5 = piVar5 + 3;
          *(undefined8 *)piVar8 = uVar1;
          piVar7[-1] = iVar2;
          piVar10 = piVar12;
          piStack_10 = piVar5;
        }
      }
      goto joined_r0x00834d17;
    }
    piVar8 = piStack_c;
    if ((uint)(piVar9[1] + *piVar9) <= (uint)(piVar5[1] + *piVar5)) {
      piStack_8 = piVar10;
      piStack_10 = piVar5;
      if ((uint)(piVar9[1] + *piVar9) < (uint)(piVar5[1] + *piVar5)) goto joined_r0x00834d6b;
      if (piVar10 != piVar5) {
        uVar1 = *(undefined8 *)piVar10;
        iVar2 = piVar10[2];
        *(undefined8 *)piVar10 = *(undefined8 *)piVar5;
        piVar10[2] = piVar5[2];
        *(undefined8 *)piVar5 = uVar1;
        piVar5[2] = iVar2;
      }
      piVar10 = piVar10 + 3;
    }
    piVar5 = piVar5 + 3;
    piStack_10 = piVar5;
    piStack_8 = piVar10;
  } while( true );
}



/* FUNCTION 12705 ; VA 0x00834eb0 ; FUN_00834eb0 */

void FUN_00834eb0(int param_1,int param_2,uint param_3,int *param_4)

{
  undefined8 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar5) {
    do {
      iVar3 = param_1 + iVar4 * 0x18;
      iVar3 = (2 - (uint)((uint)(*(int *)(param_1 + 0x10 + iVar4 * 0x18) + *(int *)(iVar3 + 0xc)) <
                         (uint)(*(int *)(iVar3 + 0x1c) + *(int *)(iVar3 + 0x18)))) + iVar4 * 2;
      puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
      *puVar1 = *(undefined8 *)(param_1 + iVar3 * 0xc);
      *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + iVar3 * 0xc + 8);
      iVar4 = iVar3;
    } while (iVar3 < iVar5);
  }
  if ((iVar3 == iVar5) && ((param_3 & 1) == 0)) {
    puVar1 = (undefined8 *)(param_1 + iVar3 * 0xc);
    *puVar1 = *(undefined8 *)(param_1 + -0xc + param_3 * 0xc);
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + param_3 * 0xc + -4);
    iVar3 = param_3 - 1;
  }
  while (param_2 < iVar3) {
    iVar4 = iVar3 + -1 >> 1;
    piVar2 = (int *)(param_1 + iVar4 * 0xc);
    if ((uint)(*(int *)(param_1 + 4 + iVar4 * 0xc) + *piVar2) <= (uint)(param_4[1] + *param_4))
    break;
    puVar1 = (undefined8 *)(param_1 + iVar3 * 0xc);
    *puVar1 = *(undefined8 *)piVar2;
    *(int *)(puVar1 + 1) = piVar2[2];
    iVar3 = iVar4;
  }
  puVar1 = (undefined8 *)(param_1 + iVar3 * 0xc);
  *puVar1 = *(undefined8 *)param_4;
  *(int *)(puVar1 + 1) = param_4[2];
  return;
}



/* FUNCTION 12706 ; VA 0x00834fc0 ; FUN_00834fc0 */

void FUN_00834fc0(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  undefined8 uVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  int *piStack_10;
  int iStack_c;
  uint uStack_8;
  
  iVar5 = (int)param_2 - (int)param_1;
  piVar7 = param_2;
  piVar10 = param_1;
  iVar8 = param_3;
  do {
    iVar5 = iVar5 / 0xc;
    if (iVar5 < 0x21) {
LAB_00835086:
      if (((1 < iVar5) && (piVar10 != piVar7)) && (piVar9 = piVar10 + 3, piVar9 != piVar7)) {
        param_1 = (int *)0xc;
        do {
          iStack_c = piVar9[2];
          uVar1 = *(undefined8 *)piVar9;
          iStack_28 = (int)((ulonglong)uVar1 >> 0x20);
          piStack_10 = (int *)((int)param_1 + 0xc + (int)piVar10);
          iStack_2c = (int)uVar1;
          uStack_8 = iStack_28 + iStack_2c;
          if ((uint)(*piVar10 + piVar10[1]) < uStack_8) {
            iStack_1c = iStack_2c;
            iStack_18 = iStack_28;
            FUN_0055b6b0((int)&param_2 + 3,&piStack_10,&piStack_10);
            FUN_0170cc70(piVar10 + 3,piVar10,param_1);
            *(ulonglong *)piVar10 = CONCAT44(iStack_18,iStack_1c);
            piVar10[2] = iStack_c;
          }
          else {
            piVar4 = (int *)((int)param_1 + -0xc + (int)piVar10);
            uVar6 = piStack_10[-5] + *piVar4;
            piVar3 = piVar9;
            while (piVar2 = piVar4, uVar6 < uStack_8) {
              *(undefined8 *)piVar3 = *(undefined8 *)piVar2;
              piVar3[2] = piVar2[2];
              piVar4 = piVar2 + -3;
              piVar3 = piVar2;
              uVar6 = piVar2[-2] + piVar2[-3];
            }
            *(undefined8 *)piVar3 = uVar1;
            piVar3[2] = iStack_c;
          }
          param_1 = (int *)((int)param_1 + 0xc);
          piVar9 = piVar9 + 3;
        } while (piVar9 != piVar7);
      }
      return;
    }
    if (iVar8 < 1) {
      if (0x20 < iVar5) {
        FUN_00834a10(piVar10,piVar7,param_4);
        if (((int)piVar7 - (int)piVar10) / 0xc < 2) {
          return;
        }
        piVar7 = piVar7 + -3;
        do {
          iStack_18 = piVar7[2];
          uStack_20 = (undefined4)*(undefined8 *)piVar7;
          iStack_1c = (int)((ulonglong)*(undefined8 *)piVar7 >> 0x20);
          *(undefined8 *)piVar7 = *(undefined8 *)piVar10;
          piVar7[2] = piVar10[2];
          FUN_00834eb0(piVar10,0,((int)piVar7 - (int)piVar10) / 0xc,&uStack_20,param_4);
          piVar7 = piVar7 + -3;
        } while (1 < ((int)piVar7 + (0xc - (int)piVar10)) / 0xc);
        return;
      }
      goto LAB_00835086;
    }
    FUN_00834bf0(&piStack_14,piVar10,piVar7,param_4);
    iVar8 = (iVar8 >> 1) + (iVar8 >> 2);
    param_3 = iVar8;
    if (((int)piStack_14 - (int)piVar10) / 0xc < ((int)piVar7 - (int)piStack_10) / 0xc) {
      FUN_00834fc0(piVar10,piStack_14,iVar8,param_4);
      piVar10 = piStack_10;
    }
    else {
      FUN_00834fc0(piStack_10,piVar7,iVar8,param_4);
      piVar7 = piStack_14;
    }
    iVar5 = (int)piVar7 - (int)piVar10;
  } while( true );
}



/* FUNCTION 12707 ; VA 0x00835210 ; FUN_00835210 */

int * __thiscall
FUN_00835210(int *param_1,undefined4 param_2,uint param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b711a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018bfd64;
    param_1[0x1a] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  uStack_18 = (uint)(param_5 != 0);
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -8;
  iVar6 = *(int *)(*param_1 + 4);
  *(undefined4 *)((int)param_1 + iVar6 + 0x30) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 8) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x10) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x14) = 0x201;
  *(undefined4 *)((int)param_1 + iVar6 + 0x18) = 6;
  *(undefined4 *)((int)param_1 + iVar6 + 0x1c) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x20) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x24) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x28) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0x2c) = 0;
  *(undefined4 *)((int)param_1 + iVar6 + 0xc) = 0;
  piStack_14 = param_1;
  iVar4 = FUN_01674e20(8);
  if (iVar4 == 0) {
    iVar4 = 0;
  }
  else {
    uStack_8 = 2;
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iVar4 + 4) = uVar5;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  }
  *(int *)((int)param_1 + iVar6 + 0x30) = iVar4;
  piVar1 = param_1 + 1;
  *(undefined4 *)((int)param_1 + iVar6 + 0x3c) = 0;
  *(int **)((int)param_1 + iVar6 + 0x38) = piVar1;
  uVar2 = FUN_00556f60(0x20);
  *(undefined *)((int)param_1 + iVar6 + 0x40) = uVar2;
  if (*(int *)((int)param_1 + iVar6 + 0x38) == 0) {
    FUN_00554460(*(uint *)((int)param_1 + iVar6 + 0xc) | 4,0);
  }
  uStack_8 = 3;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_ofstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x68;
  *piVar1 = (int)std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
  iVar6 = FUN_01674e20(8);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uVar5 = FUN_016de181(1);
    *(undefined4 *)(iVar6 + 4) = uVar5;
  }
  param_1[0xe] = iVar6;
  piStack_1c = param_1 + 2;
  param_1[4] = (int)piStack_1c;
  param_1[8] = (int)(param_1 + 6);
  param_1[9] = (int)(param_1 + 7);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xd] = (int)(param_1 + 0xb);
  param_1[3] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[4] = (int)piStack_1c;
  *piVar1 = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  *(undefined *)(param_1 + 0x13) = 0;
  *(undefined *)((int)param_1 + 0x41) = 0;
  param_1[5] = (int)(param_1 + 3);
  param_1[8] = (int)(param_1 + 6);
  param_1[9] = (int)(param_1 + 7);
  param_1[0xc] = (int)(param_1 + 10);
  param_1[0xd] = (int)(param_1 + 0xb);
  param_1[3] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[4] = 0;
  *(undefined4 *)param_1[8] = 0;
  *(undefined4 *)param_1[0xc] = 0;
  param_1[0x14] = 0;
  param_1[0x11] = DAT_01e90d08;
  param_1[0x12] = DAT_01e90d0c;
  param_1[0xf] = 0;
  uStack_8._0_1_ = 5;
  iVar6 = FUN_016de722(param_2,param_3 | 2,param_4);
  piVar1 = piStack_14;
  if (iVar6 != 0) {
    FUN_00553bc0(iVar6,1);
    piVar1 = *(int **)(param_1[0xe] + 4);
    uStack_8._0_1_ = 6;
    piStack_1c = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_18 = uStack_18 | 4;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    piVar7 = (int *)FUN_0054e680(auStack_20);
    cVar3 = (**(code **)(*piVar7 + 0xc))();
    if (cVar3 == '\0') {
      param_1[0xf] = (int)piVar7;
      FUN_00553ca0();
    }
    else {
      param_1[0xf] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (piVar1 != (int *)0x0) {
      puVar8 = (undefined4 *)(**(code **)(*piVar1 + 8))();
      if (puVar8 != (undefined4 *)0x0) {
        (**(code **)*puVar8)(1);
      }
    }
    ExceptionList = pvStack_10;
    return piStack_14;
  }
  FUN_00554460((uint)(*(int *)((int)piStack_14 + *(int *)(*piStack_14 + 4) + 0x38) == 0) * 4 + 2 |
               *(uint *)((int)piStack_14 + *(int *)(*piStack_14 + 4) + 0xc),0);
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 12708 ; VA 0x00835540 ; FUN_00835540 */

int * __fastcall FUN_00835540(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  undefined auStack_6c [16];
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int iStack_28;
  undefined8 uStack_24;
  uint *puStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b7162;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_8 = 0;
  iVar3 = 0x8000;
  piStack_14 = param_1;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  piStack_14[0x40002] = 0;
  piStack_14[0x40003] = 0;
  piStack_14[0x40004] = 0;
  piStack_14[0x4000f] = 0;
  piStack_14[0x40010] = 0;
  piStack_14[0x40011] = 0;
  piStack_14[0x40012] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piStack_14[0x40008] = 0;
  piStack_14[0x40009] = 0;
  piStack_14[0x4000a] = 0;
  piStack_14[0x4000b] = 0;
  piStack_14[0x40006] = 1;
  piStack_14[0x40007] = 0;
  *(undefined2 *)(piStack_14 + 0x4000c) = 1;
  piStack_14[0x4000d] = 0;
  *(undefined *)(piStack_14 + 0x4000e) = 0;
  uStack_2c = FUN_01674fa0(0x1000,0x10);
  FUN_0170d1f0(uStack_2c,0,0x1000);
  iVar3 = 0x100;
  do {
    FUN_0054eb90();
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  uStack_8._0_1_ = 4;
  iVar3 = *piStack_14;
  *piStack_14 = uStack_2c;
  if (iVar3 != 0) {
    FUN_01674ee0(iVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_2c = FUN_01674fa0(0x40000,0x10);
  FUN_0170d1f0(uStack_2c,0,0x40000);
  iVar3 = 0x80;
  do {
    FUN_00835800();
    piVar4 = piStack_14;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar3 = piStack_14[0x40012];
  piStack_14[0x40012] = uStack_2c;
  if (iVar3 != 0) {
    FUN_01674ee0(iVar3);
  }
  uStack_54 = 1;
  iStack_28 = 0;
  uStack_5c = 0;
  uStack_50 = 0;
  uStack_2c = 0;
  do {
    puStack_1c = (uint *)(piVar4[0x40012] + uStack_2c);
    puVar1 = (uint *)FUN_00835940(auStack_6c,iStack_28,0);
    uVar2 = puVar1[2];
    uStack_44 = uVar2 - 1;
    uStack_40 = (puVar1[3] - 1) + (uint)(uVar2 != 0);
    if ((uStack_40 < puVar1[3]) || ((uStack_40 <= puVar1[3] && (uStack_44 <= uVar2)))) {
      uStack_24 = 0;
      uStack_24._0_4_ = 0;
      uVar2 = (uint)uStack_24;
    }
    else {
      uVar2 = 1;
    }
    uStack_24 = CONCAT44(0x80,(uint)uStack_24);
    uStack_4c = *puVar1 - uVar2;
    uStack_48 = puVar1[1] - (uint)(*puVar1 < uVar2);
    do {
      uStack_18 = uStack_48 << 1 | uStack_4c >> 0x1f;
      uVar2 = uStack_4c * 2;
      *puStack_1c = uStack_4c;
      puStack_1c[1] = uStack_48;
      puStack_1c[2] = uStack_44;
      puStack_1c[3] = uStack_40;
      uStack_4c = -((int)uStack_40 >> 0x1f) + uVar2;
      uStack_48 = uStack_18 + CARRY4(-((int)uStack_40 >> 0x1f),uVar2);
      puStack_1c = puStack_1c + 4;
      uStack_40 = uStack_40 << 1 | uStack_44 >> 0x1f;
      uStack_44 = uStack_44 * 2;
      iVar3 = uStack_24._4_4_ + -1;
      uStack_24 = CONCAT44(iVar3,(uint)uStack_24);
    } while (iVar3 != 0);
    uStack_2c = uStack_2c + 0x800;
    iStack_28 = iStack_28 + 1;
    piVar4 = piStack_14;
    uStack_3c = uStack_4c;
    uStack_38 = uStack_48;
    uStack_34 = uStack_44;
    uStack_30 = uStack_40;
  } while (uStack_2c < 0x40000);
  ExceptionList = pvStack_10;
  return piStack_14;
}



/* FUNCTION 12709 ; VA 0x00835800 ; FUN_00835800 */

undefined4 __fastcall FUN_00835800(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = 0x80;
  do {
    FUN_0054eb90();
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return param_1;
}



/* FUNCTION 12710 ; VA 0x00835830 ; FUN_00835830 */

void __fastcall FUN_00835830(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01674ee0(*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12711 ; VA 0x00835870 ; FUN_00835870 */

void __fastcall FUN_00835870(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[0x40012] != 0) {
    ExceptionList = &pvStack_10;
    FUN_01674ee0(param_1[0x40012]);
  }
  uStack_8 = 0xffffffff;
  FUN_00617ad0();
  iVar1 = param_1[0x40002];
  if (iVar1 != 0) {
    uVar3 = (param_1[0x40004] - iVar1 >> 1) * 2;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x40002] = 0;
    param_1[0x40003] = 0;
    param_1[0x40004] = 0;
  }
  uStack_8 = 1;
  if (*param_1 != 0) {
    FUN_01674ee0(*param_1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12712 ; VA 0x00835940 ; FUN_00835940 */

longlong * __thiscall FUN_00835940(undefined4 *param_1,longlong *param_2,uint param_3,int param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong lVar5;
  
  if ((param_4 == 0) && (param_3 < 0x80)) {
    if (param_3 == 0x40) {
      *(undefined4 *)param_2 = param_1[2];
      *(undefined4 *)((int)param_2 + 4) = param_1[3];
      goto LAB_00835a52;
    }
    if (param_3 == 0) {
      uVar1 = param_1[1];
      uVar2 = param_1[2];
      uVar3 = param_1[3];
      *(undefined4 *)param_2 = *param_1;
      *(undefined4 *)((int)param_2 + 4) = uVar1;
      *(undefined4 *)(param_2 + 1) = uVar2;
      *(undefined4 *)((int)param_2 + 0xc) = uVar3;
      return param_2;
    }
    if (param_3 < 0x40) {
      lVar4 = FUN_016f4650();
      lVar5 = FUN_016f4490();
      *param_2 = lVar4 + lVar5;
      lVar4 = FUN_016f4490();
      param_2[1] = lVar4;
      return param_2;
    }
    if ((param_3 < 0x80) && (0x40 < param_3)) {
      lVar4 = FUN_016f4490();
      *param_2 = lVar4;
      *(undefined4 *)(param_2 + 1) = 0;
      *(undefined4 *)((int)param_2 + 0xc) = 0;
      return param_2;
    }
  }
  *(undefined4 *)param_2 = 0;
  *(undefined4 *)((int)param_2 + 4) = 0;
LAB_00835a52:
  *(undefined4 *)((int)param_2 + 0xc) = 0;
  *(undefined4 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 12713 ; VA 0x00835a70 ; FUN_00835a70 */

uint FUN_00835a70(int param_1)

{
  return param_1 + 0x1fU & 0xffffffe0;
}



/* FUNCTION 12714 ; VA 0x00835a80 ; FUN_00835a80 */

void __thiscall FUN_00835a80(int param_1,int *param_2,int *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iStack_c;
  uint uStack_8;
  
  piVar4 = param_2;
  *(undefined4 *)(param_1 + 0x100040) = *(undefined4 *)(param_1 + 0x10003c);
  param_3[1] = *param_3;
  FUN_006b9410(param_2[1] - *param_2 >> 3,param_3);
  iVar7 = *piVar4;
  param_2 = (int *)0x0;
  if (piVar4[1] - iVar7 >> 3 != 0) {
    do {
      puVar1 = (undefined4 *)(iVar7 + (int)param_2 * 8);
      puVar2 = *(undefined4 **)(param_1 + 0x100040);
      if (*(undefined4 **)(param_1 + 0x100044) == puVar2) {
        FUN_00834820(puVar2,puVar1,&param_2);
      }
      else {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        puVar2[2] = param_2;
        *(int *)(param_1 + 0x100040) = *(int *)(param_1 + 0x100040) + 0xc;
      }
      param_2 = (int *)((int)param_2 + 1);
      iVar7 = *piVar4;
    } while (param_2 < (uint)(piVar4[1] - iVar7 >> 3));
  }
  FUN_00834fc0(*(int *)(param_1 + 0x10003c),*(int *)(param_1 + 0x100040),
               (*(int *)(param_1 + 0x100040) - *(int *)(param_1 + 0x10003c)) / 0xc,param_3);
  iVar7 = *(int *)(param_1 + 0x10003c);
  uStack_8 = 0;
  iVar6 = *(int *)(param_1 + 0x100040) - iVar7;
  iVar3 = iVar6 >> 0x1f;
  if (iVar6 / 0xc + iVar3 != iVar3) {
    iStack_c = 0;
    do {
      iVar3 = *(int *)(iStack_c + iVar7);
      iVar7 = *(int *)(iStack_c + 4 + iVar7);
      uVar5 = FUN_00835cf0(iVar3,iVar7);
      if ((((int)uVar5 < 0) ||
          (iVar6 = (uVar5 & 0xffff) * 0x20,
          *(short *)(iVar6 + 0x20 + param_1) != (short)(uVar5 >> 0x10))) ||
         (*(char *)(iVar6 + 0x22 + param_1) == '\0')) {
        uVar5 = 0;
        uVar8 = 0;
        param_2 = (int *)0x0;
        do {
          iVar6 = param_1 + 8 + (uVar8 & 0xffff) * 0x20;
          if ((*(char *)(iVar6 + 0x1a) != '\0') &&
             ((*(int *)(param_1 + 0x10001c) - *(int *)(iVar6 + 0x14) !=
               (uint)(*(uint *)(param_1 + 0x100018) < *(uint *)(iVar6 + 0x10)) ||
              (uVar5 = (uint)param_2, 1 < *(uint *)(param_1 + 0x100018) - *(uint *)(iVar6 + 0x10))))
             ) {
            FUN_00836120(uVar8 & 0xffff,iVar6);
            param_2 = (int *)((int)param_2 + 1);
            uVar5 = (uint)param_2;
          }
          uVar8 = uVar8 + 1;
        } while (uVar8 < 0x8000);
        if ((((int)uVar5 < 1) || (uVar5 = FUN_00835cf0(iVar3,iVar7), (int)uVar5 < 0)) ||
           ((iVar6 = (uVar5 & 0xffff) * 0x20,
            *(short *)(iVar6 + 0x20 + param_1) != (short)(uVar5 >> 0x10) ||
            (*(char *)(iVar6 + 0x22 + param_1) == '\0')))) {
          param_2 = (int *)0x0;
          uVar8 = iVar3 + 0x1fU >> 1 & 0x7ffffff0;
          uVar9 = iVar7 + 0x1fU >> 1 & 0x7ffffff0;
          do {
            if ((uVar8 < 0x20) || (uVar9 < 0x20)) break;
            uVar5 = FUN_00835cf0(uVar8,uVar9);
            if ((-1 < (int)uVar5) &&
               ((iVar7 = (uVar5 & 0xffff) * 0x20,
                *(short *)(iVar7 + 0x20 + param_1) == (short)(uVar5 >> 0x10) &&
                (*(char *)(iVar7 + 0x22 + param_1) != '\0')))) goto LAB_00835c93;
            param_2 = (int *)((int)param_2 + 1);
            uVar8 = uVar8 >> 1;
            uVar9 = uVar9 >> 1;
          } while ((int)param_2 < 1);
          uVar5 = 0xffffffff;
        }
      }
LAB_00835c93:
      uStack_8 = uStack_8 + 1;
      iVar7 = iStack_c + 8;
      iStack_c = iStack_c + 0xc;
      *(uint *)(*param_3 + *(int *)(iVar7 + *(int *)(param_1 + 0x10003c)) * 4) = uVar5;
      iVar7 = *(int *)(param_1 + 0x10003c);
    } while (uStack_8 < (uint)((*(int *)(param_1 + 0x100040) - iVar7) / 0xc));
  }
  return;
}



/* FUNCTION 12715 ; VA 0x00835cf0 ; FUN_00835cf0 */

undefined4 __thiscall FUN_00835cf0(int *param_1,int param_2,int param_3)

{
  ushort uVar1;
  short sVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  short sVar7;
  uint uVar8;
  uint *puVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  undefined auVar16 [16];
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  uint uStack_38;
  int iStack_34;
  uint uStack_1c;
  
  if (((param_2 + 0x1fU & 0xffffffe0) <= (uint)param_1[0x40008]) &&
     ((param_3 + 0x1fU & 0xffffffe0) <= (uint)param_1[0x40009])) {
    uVar12 = param_2 + 0x1fU >> 5;
    uVar15 = param_3 + 0x1fU >> 5;
    uVar8 = (param_1[0x4000a] - uVar12) + 1;
    uStack_1c = 0;
    if (uVar8 != 0) {
      do {
        uVar10 = (uStack_1c + param_1[0x4000d]) % uVar8;
        puVar9 = (uint *)(uVar12 * 0x800 + param_1[0x40012] + uVar10 * 0x10);
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        uVar13 = 0;
        if (param_1[0x4000b] - uVar15 != -1) {
          do {
            uVar11 = 0;
            if (uVar15 == 0) {
LAB_00835dd9:
              iVar14 = uVar13 - uVar15;
              if (uVar15 != 0) {
                puVar9 = (uint *)(iVar14 * 0x10 + *param_1);
                do {
                  *puVar9 = *puVar9 | uVar3;
                  puVar9[1] = puVar9[1] | uVar4;
                  puVar9[2] = puVar9[2] | uVar5;
                  puVar9[3] = puVar9[3] | uVar6;
                  uVar15 = uVar15 - 1;
                  puVar9 = puVar9 + 4;
                } while (uVar15 != 0);
              }
              uVar1 = *(ushort *)(param_1[0x40003] + -2);
              param_1[0x40003] = param_1[0x40003] + -2;
              uStack_38 = uStack_38 & 0xff000000;
              param_1[(uint)uVar1 * 8 + 2] = uVar10 << 5;
              param_1[(uint)uVar1 * 8 + 3] = iVar14 * 0x20;
              param_1[(uint)uVar1 * 8 + 4] = param_2;
              param_1[(uint)uVar1 * 8 + 5] = param_3;
              param_1[(uint)uVar1 * 8 + 6] = 0;
              param_1[(uint)uVar1 * 8 + 7] = 0;
              param_1[(uint)uVar1 * 8 + 8] = uStack_38;
              param_1[(uint)uVar1 * 8 + 9] = iStack_34;
              sVar2 = *(short *)(param_1 + 0x4000c);
              sVar7 = sVar2 + 1;
              *(short *)(param_1 + 0x4000c) = sVar7;
              if (sVar7 < 0) {
                *(undefined2 *)(param_1 + 0x4000c) = 1;
              }
              *(short *)(param_1 + (uint)uVar1 * 8 + 8) = sVar2;
              param_1[(uint)uVar1 * 8 + 6] = param_1[0x40006];
              param_1[(uint)uVar1 * 8 + 7] = param_1[0x40007];
              *(undefined *)((int)param_1 + (uint)uVar1 * 0x20 + 0x22) = 1;
              param_1[0x4000d] = uVar10;
              return CONCAT22(*(undefined2 *)(param_1 + (uint)uVar1 * 8 + 8),uVar1);
            }
            puVar9 = (uint *)(uVar13 * 0x10 + *param_1);
            while( true ) {
              uVar17 = *puVar9 & uVar3;
              uVar18 = puVar9[1] & uVar4;
              uVar19 = puVar9[2] & uVar5;
              uVar20 = puVar9[3] & uVar6;
              uVar13 = uVar13 + 1;
              auVar16[0] = -((char)uVar17 == '\0');
              auVar16[1] = -((char)(uVar17 >> 8) == '\0');
              auVar16[2] = -((char)(uVar17 >> 0x10) == '\0');
              auVar16[3] = -((char)(uVar17 >> 0x18) == '\0');
              auVar16[4] = -((char)uVar18 == '\0');
              auVar16[5] = -((char)(uVar18 >> 8) == '\0');
              auVar16[6] = -((char)(uVar18 >> 0x10) == '\0');
              auVar16[7] = -((char)(uVar18 >> 0x18) == '\0');
              auVar16[8] = -((char)uVar19 == '\0');
              auVar16[9] = -((char)(uVar19 >> 8) == '\0');
              auVar16[10] = -((char)(uVar19 >> 0x10) == '\0');
              auVar16[0xb] = -((char)(uVar19 >> 0x18) == '\0');
              auVar16[0xc] = -((char)uVar20 == '\0');
              auVar16[0xd] = -((char)(uVar20 >> 8) == '\0');
              auVar16[0xe] = -((char)(uVar20 >> 0x10) == '\0');
              auVar16[0xf] = -((char)(uVar20 >> 0x18) == '\0');
              if ((ushort)((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                           (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                           (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                           (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                           (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                           (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                           (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                           (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                           (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                           (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                           (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                           (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                           (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                           (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                           (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                          (ushort)(auVar16[0xf] >> 7) << 0xf) != 0xffff) break;
              uVar11 = uVar11 + 1;
              puVar9 = puVar9 + 4;
              if (uVar15 <= uVar11) goto LAB_00835dd9;
            }
          } while (uVar13 < (param_1[0x4000b] - uVar15) + 1);
        }
        uStack_1c = uStack_1c + 1;
      } while (uStack_1c < uVar8);
    }
  }
  return 0xffffffff;
}



/* FUNCTION 12716 ; VA 0x00835ef0 ; FUN_00835ef0 */

void FUN_00835ef0(undefined4 *param_1)

{
  FUN_00835cf0(*param_1,param_1[1]);
  return;
}



/* FUNCTION 12717 ; VA 0x00835f10 ; FUN_00835f10 */

void __fastcall FUN_00835f10(undefined4 *param_1)

{
  short *psVar1;
  undefined2 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uStack_28;
  undefined4 uStack_24;
  uint uStack_14;
  
  puVar3 = (undefined4 *)*param_1;
  if (DAT_01d62208 == '\0') {
    *(short *)(param_1 + 0x4000c) = *(short *)(param_1 + 0x4000c) + 1;
  }
  else {
    psVar1 = (short *)(param_1 + 0x4000c);
    *psVar1 = *psVar1 + 1;
    if (*psVar1 < 0) {
      *(undefined2 *)(param_1 + 0x4000c) = 1;
    }
  }
  iVar4 = 0x100;
  do {
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3 = puVar3 + 4;
    iVar4 = iVar4 + -1;
  } while (iVar4 != 0);
  if ((uint)((int)(param_1[0x40004] - param_1[0x40002]) >> 1) < 0x8000) {
    FUN_0072e0d0(0x8000);
  }
  uVar5 = 0;
  param_1[0x40003] = param_1[0x40002];
  do {
    uStack_14 = 0x7fff - uVar5 & 0xffff;
    puVar2 = (undefined2 *)param_1[0x40003];
    if ((undefined2 *)param_1[0x40004] == puVar2) {
      FUN_00725750(puVar2,&uStack_14);
    }
    else {
      *puVar2 = (short)(0x7fff - uVar5);
      param_1[0x40003] = param_1[0x40003] + 2;
    }
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x8000);
  for (puVar3 = param_1 + 2; puVar3 != param_1 + 0x40002; puVar3 = puVar3 + 8) {
    uStack_28 = uStack_28 & 0xff000000;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[6] = uStack_28;
    puVar3[7] = uStack_24;
  }
  *(undefined *)(param_1 + 0x4000e) = 0;
  return;
}



/* FUNCTION 12718 ; VA 0x00836020 ; FUN_00836020 */

void __fastcall FUN_00836020(undefined4 *param_1)

{
  short *psVar1;
  int *piVar2;
  short sVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uStack_28;
  undefined4 uStack_24;
  
  if (DAT_01d62208 != '\0') {
    psVar1 = (short *)(param_1 + 0x4000c);
    *psVar1 = *psVar1 + 1;
    if (*psVar1 < 0) {
      *(undefined2 *)(param_1 + 0x4000c) = 1;
    }
  }
  puVar4 = (undefined4 *)*param_1;
  uVar5 = 0;
  if (param_1[0x4000b] != 0) {
    do {
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4[2] = 0;
      puVar4[3] = 0;
      puVar4 = puVar4 + 4;
      uVar5 = uVar5 + 1;
    } while (uVar5 < (uint)param_1[0x4000b]);
  }
  piVar2 = param_1 + 0x40002;
  uVar5 = 0x8000 - (param_1[0x40003] - *piVar2 >> 1);
  if (uVar5 != 0) {
    puVar4 = param_1 + 2;
    uVar6 = uVar5;
    do {
      uStack_28 = uStack_28 & 0xff000000;
      *puVar4 = 0;
      puVar4[1] = 0;
      puVar4[2] = 0;
      puVar4[3] = 0;
      puVar4[4] = 0;
      puVar4[5] = 0;
      puVar4[6] = uStack_28;
      puVar4[7] = uStack_24;
      uVar6 = uVar6 - 1;
      puVar4 = puVar4 + 8;
    } while (uVar6 != 0);
  }
  FUN_00727cd0(0x8000,piVar2);
  if (uVar5 != 0) {
    uVar6 = 0;
    iVar7 = (0x8000 - uVar5) * 2;
    do {
      sVar3 = (short)uVar6;
      uVar6 = uVar6 + 1;
      *(short *)(iVar7 + *piVar2) = ((short)uVar5 - sVar3) + -1;
      iVar7 = iVar7 + 2;
    } while (uVar6 < uVar5);
  }
  *(undefined *)(param_1 + 0x4000e) = 0;
  return;
}



/* FUNCTION 12719 ; VA 0x00836120 ; FUN_00836120 */

void __thiscall FUN_00836120(int *param_1,undefined2 param_2,uint *param_3)

{
  undefined2 *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  uint uStack_18;
  uint uStack_14;
  
  puVar7 = (uint *)(((param_3[2] + 0x1f >> 5) * 0x80 + (*param_3 >> 5)) * 0x10 + param_1[0x40012]);
  uVar6 = param_3[1] >> 5;
  uVar2 = *puVar7;
  uVar3 = puVar7[1];
  uVar4 = puVar7[2];
  uVar5 = puVar7[3];
  uVar8 = param_3[3] + 0x1f >> 5;
  if (uVar6 < uVar8 + uVar6) {
    puVar7 = (uint *)(uVar6 * 0x10 + *param_1);
    do {
      *puVar7 = *puVar7 & (uVar2 ^ 0xffffffff);
      puVar7[1] = puVar7[1] & (uVar3 ^ 0xffffffff);
      puVar7[2] = puVar7[2] & (uVar4 ^ 0xffffffff);
      puVar7[3] = puVar7[3] & (uVar5 ^ 0xffffffff);
      uVar8 = uVar8 - 1;
      puVar7 = puVar7 + 4;
    } while (uVar8 != 0);
  }
  uStack_18 = uStack_18 & 0xff000000;
  *param_3 = 0;
  param_3[1] = 0;
  param_3[2] = 0;
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  param_3[6] = uStack_18;
  param_3[7] = uStack_14;
  puVar1 = (undefined2 *)param_1[0x40003];
  if ((undefined2 *)param_1[0x40004] != puVar1) {
    *puVar1 = param_2;
    param_1[0x40003] = param_1[0x40003] + 2;
    return;
  }
  FUN_00725750(puVar1,&param_2);
  return;
}



/* FUNCTION 12720 ; VA 0x008361f0 ; FUN_008361f0 */

int __thiscall FUN_008361f0(int param_1,ushort param_2)

{
  return (uint)param_2 * 0x20 + param_1 + 8;
}



/* FUNCTION 12721 ; VA 0x00836210 ; FUN_00836210 */

void __thiscall FUN_00836210(undefined4 *param_1,uint param_2,uint param_3)

{
  undefined2 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uStack_28;
  undefined4 uStack_24;
  uint uStack_14;
  
  param_1[0x40008] = param_2;
  param_1[0x40009] = param_3;
  param_1[0x4000a] = param_2 >> 5;
  param_1[0x4000b] = param_3 >> 5;
  param_1[0x40006] = 1;
  param_1[0x40007] = 0;
  *(undefined2 *)(param_1 + 0x4000c) = 1;
  puVar2 = (undefined4 *)*param_1;
  *(undefined2 *)(param_1 + 0x4000c) = 2;
  iVar3 = 0x100;
  do {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    puVar2 = puVar2 + 4;
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  if ((uint)((int)(param_1[0x40004] - param_1[0x40002]) >> 1) < 0x8000) {
    FUN_0072e0d0(0x8000);
  }
  uVar4 = 0;
  param_1[0x40003] = param_1[0x40002];
  do {
    uStack_14 = 0x7fff - uVar4 & 0xffff;
    puVar1 = (undefined2 *)param_1[0x40003];
    if ((undefined2 *)param_1[0x40004] == puVar1) {
      FUN_00725750(puVar1,&uStack_14);
    }
    else {
      *puVar1 = (short)(0x7fff - uVar4);
      param_1[0x40003] = param_1[0x40003] + 2;
    }
    uVar4 = uVar4 + 1;
  } while (uVar4 < 0x8000);
  for (puVar2 = param_1 + 2; puVar2 != param_1 + 0x40002; puVar2 = puVar2 + 8) {
    uStack_28 = uStack_28 & 0xff000000;
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[6] = uStack_28;
    puVar2[7] = uStack_24;
  }
  *(undefined *)(param_1 + 0x4000e) = 0;
  return;
}



/* FUNCTION 12722 ; VA 0x00836350 ; FUN_00836350 */

uint __thiscall FUN_00836350(int param_1,uint param_2,int param_3)

{
  uint in_EAX;
  
  if ((((-1 < (int)param_2) &&
       (in_EAX = (param_2 & 0xffff) * 0x20,
       *(short *)(in_EAX + 0x20 + param_1) == (short)(param_2 >> 0x10))) &&
      (*(char *)(in_EAX + 0x22 + param_1) != '\0')) &&
     ((*(int *)(in_EAX + 0x10 + param_1) == param_3 &&
      (*(int *)(in_EAX + 0x14 + param_1) == param_3)))) {
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 12723 ; VA 0x008363a0 ; FUN_008363a0 */

uint __thiscall FUN_008363a0(int param_1,uint param_2)

{
  uint in_EAX;
  
  if (((-1 < (int)param_2) &&
      (in_EAX = (param_2 & 0xffff) * 0x20,
      *(short *)(in_EAX + 0x20 + param_1) == (short)(param_2 >> 0x10))) &&
     (*(char *)(in_EAX + 0x22 + param_1) != '\0')) {
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 12724 ; VA 0x008363d0 ; FUN_008363d0 */

void __fastcall FUN_008363d0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  
  puVar1 = (uint *)(param_1 + 0x100018);
  uVar2 = *puVar1;
  *puVar1 = *puVar1 + 1;
  *(int *)(param_1 + 0x10001c) = *(int *)(param_1 + 0x10001c) + (uint)(0xfffffffe < uVar2);
  return;
}



/* FUNCTION 12725 ; VA 0x008363e0 ; FUN_008363e0 */

void __thiscall FUN_008363e0(int param_1,ushort param_2)

{
  *(undefined4 *)((uint)param_2 * 0x20 + 0x18 + param_1) = *(undefined4 *)(param_1 + 0x100018);
  *(undefined4 *)((uint)param_2 * 0x20 + 0x1c + param_1) = *(undefined4 *)(param_1 + 0x10001c);
  return;
}



/* FUNCTION 12726 ; VA 0x00836410 ; thunk_FUN_00d6bbd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00d6bbd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0181be30;
  pvStack_10 = ExceptionList;
  if (DAT_01f0e9f4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f0ec08) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01f0ec08);
      if (DAT_01f0ec08 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Attachment",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01f0ec00 = RBX::Creator<class_RBX::Attachment>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01f0e9f8,&DAT_01f0ec00);
        FUN_016f3654(FUN_0189c810);
        FUN_016f37bf(&DAT_01f0ec08);
      }
    }
    DAT_01f0e9f4 = &DAT_01f0e9f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01f0e9f4;
}



/* FUNCTION 12727 ; VA 0x00836450 ; FUN_00836450 */

undefined4 * __thiscall FUN_00836450(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00838650;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12728 ; VA 0x00836510 ; FUN_00836510 */

int FUN_00836510(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d6bbd0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 12729 ; VA 0x00836550 ; FUN_00836550 */

int __fastcall FUN_00836550(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d41330();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 12730 ; VA 0x00836580 ; FUN_00836580 */

int __fastcall FUN_00836580(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00d41430();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 12731 ; VA 0x008365b0 ; FUN_008365b0 */

undefined4 * __thiscall FUN_008365b0(undefined4 *param_1,undefined4 param_2)

{
  FUN_00841020(param_2,1);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0xe] = RBX::GfxPart::vftable;
  param_1[0x14] = 0xffffffff;
  *param_1 = RBX::Graphics::LightObject::vftable;
  param_1[0xe] = RBX::Graphics::LightObject::vftable;
  param_1[0x1b] = 0x3f800000;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0x3f800000;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0x3f800000;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0x3e4ccccd;
  *(undefined2 *)(param_1 + 0x3e) = 0;
  return param_1;
}



/* FUNCTION 12732 ; VA 0x00836790 ; FUN_00836790 */

void __fastcall FUN_00836790(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::LightObject::vftable;
  param_1[0xe] = RBX::Graphics::LightObject::vftable;
  FUN_011590c0();
  param_1[0x15] = 0;
  piVar2 = (int *)param_1[0x16];
  param_1[0x16] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x17] = 0;
  piVar2 = (int *)param_1[0x18];
  param_1[0x18] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007c78a0(param_1 + 0xe,4);
  if ((undefined4 *)param_1[0x1a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x1a])(1);
  }
  iVar3 = param_1[0x19];
  if (iVar3 != 0) {
    FUN_01674ea0(*(undefined4 *)(iVar3 + 0x10));
    FUN_01674ea0(*(undefined4 *)(iVar3 + 0xc));
    FUN_01674ea0(*(undefined4 *)(iVar3 + 8));
    FUN_01674ea0(*(undefined4 *)(iVar3 + 4));
    FUN_01674ea0(iVar3,0x14);
  }
  piVar2 = (int *)param_1[0x18];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x16];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01158110();
  FUN_00841090();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12733 ; VA 0x008368ee ; FUN_008368ee */

void FUN_008368ee(void)

{
  FUN_00836900();
  return;
}



/* FUNCTION 12734 ; VA 0x00836900 ; FUN_00836900 */

undefined4 __thiscall FUN_00836900(undefined4 param_1,byte param_2)

{
  FUN_00836790();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xfc);
  }
  return param_1;
}



/* FUNCTION 12735 ; VA 0x00836930 ; FUN_00836930 */

void __thiscall FUN_00836930(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  bool bVar9;
  code *pcStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b71ba;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  iVar4 = param_2[1];
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_2[1];
  }
  *(int *)(param_1 + 0x54) = *param_2;
  piVar1 = *(int **)(param_1 + 0x58);
  *(int *)(param_1 + 0x58) = iVar4;
  iStack_24 = param_1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar4 = param_3[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_3[1];
  }
  *(int *)(param_1 + 0x5c) = *param_3;
  piVar1 = *(int **)(param_1 + 0x60);
  *(int *)(param_1 + 0x60) = iVar4;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  pcStack_38 = FUN_00838b10;
  uStack_34 = 0;
  puStack_1c = (undefined4 *)(*param_3 + 0x50);
  iStack_8 = 0;
  iStack_30 = param_1;
  uVar3 = FUN_01675290(DAT_02110da8);
  iStack_8._0_1_ = 1;
  uStack_28 = uVar3;
  puStack_14 = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    *puStack_14 = 0;
    puStack_14[1] = 1;
    puStack_14[2] = FUN_00819150;
    puStack_14[3] = _guard_check_icall;
    puStack_14[4] = 0;
    puStack_14[5] = puStack_1c;
    puStack_14[6] = pcStack_38;
    puStack_14[7] = uStack_34;
    puStack_14[8] = iStack_30;
    puStack_14[9] = uStack_2c;
  }
  FUN_016797d0(puStack_14);
  puStack_20 = puStack_14;
  if (puStack_14 != (undefined4 *)0x0) {
    LOCK();
    puStack_14[1] = puStack_14[1] + 1;
    UNLOCK();
  }
  uStack_18 = 1;
  iStack_8._0_1_ = 2;
  FUN_01675290(uVar3);
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (*(undefined4 **)(param_1 + 0x4c) == puVar5) {
    FUN_006335f0(puVar5,&puStack_20);
    puVar5 = puStack_20;
  }
  else {
    *puVar5 = puStack_14;
    *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 4;
    puVar5 = (undefined4 *)0x0;
  }
  uStack_18 = 0;
  iStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    piVar1 = puVar5 + 1;
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(puVar5);
    }
  }
  if (*param_2 != 0) {
    iVar4 = FUN_008a4100();
    puStack_20 = (undefined4 *)(iVar4 + 0x80);
    pcStack_38 = FUN_00838c10;
    uStack_34 = 0;
    iStack_8 = 3;
    iStack_30 = param_1;
    uVar3 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 4;
    uStack_28 = uVar3;
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_14 == (undefined4 *)0x0) {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 1;
      puStack_14[2] = FUN_00838650;
      puStack_14[3] = _guard_check_icall;
      puStack_14[4] = 0;
      puStack_14[5] = puStack_20;
      puStack_14[6] = pcStack_38;
      puStack_14[7] = uStack_34;
      puStack_14[8] = iStack_30;
      puStack_14[9] = uStack_2c;
    }
    FUN_016797d0(puStack_14);
    puStack_1c = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    uStack_18 = 2;
    iStack_8._0_1_ = 5;
    FUN_01675290(uVar3);
    puVar5 = *(undefined4 **)(param_1 + 0x48);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    if (*(undefined4 **)(param_1 + 0x4c) == puVar5) {
      FUN_006335f0(puVar5,&puStack_1c);
      puVar5 = puStack_1c;
    }
    else {
      *puVar5 = puStack_14;
      *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 4;
      puVar5 = (undefined4 *)0x0;
    }
    iStack_8 = 0xffffffff;
    if (puVar5 != (undefined4 *)0x0) {
      piVar1 = puVar5 + 1;
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(puVar5);
      }
    }
    iVar4 = *param_3;
    iVar2 = *(int *)(iVar4 + 0xc);
    iVar6 = FUN_00d41530();
    param_1 = iStack_24;
    iVar8 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iVar8 = iVar4;
    }
    if (iVar8 != 0) {
      pcStack_38 = FUN_00838be0;
      uStack_34 = 0;
      iStack_30 = iStack_24;
      puVar7 = (undefined4 *)FUN_00836450(&param_3,&pcStack_38);
      puVar5 = *(undefined4 **)(param_1 + 0x48);
      iStack_8 = 6;
      if (*(undefined4 **)(param_1 + 0x4c) == puVar5) {
        FUN_006335f0(puVar5,puVar7);
      }
      else {
        *puVar5 = *puVar7;
        *puVar7 = 0;
        *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 4;
      }
      iStack_8 = 0xffffffff;
      if (param_3 != (int *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          FUN_01674ea0(param_3);
        }
      }
    }
    if (DAT_01d6866c == '\0') {
      bVar9 = *(int *)(*param_2 + 0x70) == 0;
    }
    else {
      bVar9 = *(int *)(*param_2 + 0x6c) == -1;
    }
    if (bVar9) {
      FUN_007c7a50(-(uint)(param_1 != 0) & param_1 + 0x38U,4);
    }
    else {
      FUN_007c7840(-(uint)(param_1 != 0) & param_1 + 0x38U,4);
    }
  }
  (**(code **)(*(int *)(param_1 + 0x38) + 8))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12736 ; VA 0x00836d10 ; FUN_00836d10 */

int FUN_00836d10(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined *puStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b71e0;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(*param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if ((iVar6 == 0) ||
     (iVar2 = *(int *)(iVar6 + 0xc), ExceptionList = &pvStack_10, iVar1 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar1 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8))) {
    iVar6 = 0;
  }
  FUN_0060dcd0(&iStack_28,iVar6);
  iStack_8 = 0;
  piVar3 = piStack_24;
  if (((iStack_28 == 0) && (iStack_18 = *(int *)(*param_1 + 0x34), iStack_18 != 0)) &&
     (iVar6 = *(int *)(iStack_18 + 0xc), iVar2 = FUN_00d6bbd0(), piVar3 = piStack_24,
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    piStack_1c = *(int **)(iStack_18 + 0x34);
    if ((piStack_1c == (int *)0x0) ||
       (iVar6 = *(int *)((int)piStack_1c + 0xc), iVar2 = FUN_00aff8c0(), piVar3 = piStack_1c,
       (uint)*(ushort *)(iVar2 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
      piVar3 = (int *)0;
    }
    piVar4 = (int *)FUN_0060dcd0(&iStack_30,piVar3);
    iStack_28 = *piVar4;
    piVar3 = (int *)piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    piStack_1c = piStack_24;
    piVar4 = piVar3;
    piStack_20 = piVar3;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puVar5 = (undefined4 *)*piStack_24;
        piStack_24 = piVar3;
        (*(code *)*puVar5)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        piVar4 = piStack_24;
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
          piVar4 = piStack_24;
        }
      }
    }
    piStack_24 = piVar4;
    piStack_1c = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    puStack_38 = &LAB_00838c00;
    uStack_34 = 0;
    iStack_30 = iStack_14;
    puVar5 = (undefined4 *)FUN_00836450(&iStack_18,&puStack_38);
    iStack_8._0_1_ = 1;
    if (*(int *)(iStack_14 + 0x4c) == *(int *)(iStack_14 + 0x48)) {
      FUN_006335f0(*(int *)(iStack_14 + 0x48),puVar5);
    }
    else {
      **(undefined4 **)(iStack_14 + 0x48) = *puVar5;
      *puVar5 = 0;
      *(int *)(iStack_14 + 0x48) = *(int *)(iStack_14 + 0x48) + 4;
      piVar3 = piStack_20;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (iStack_18 != 0) {
      piVar4 = (int *)(iStack_18 + 4);
      LOCK();
      iVar6 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_01674ea0(iStack_18);
      }
    }
  }
  iVar6 = FUN_00836930(&iStack_28,param_1);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar4 = piVar3 + 1;
    iVar2 = *piVar4;
    iVar6 = *piVar4;
    *piVar4 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 12737 ; VA 0x00836f30 ; FUN_00836f30 */

undefined8 *
FUN_00836f30(undefined8 *param_1,undefined8 *param_2,float param_3,undefined8 *param_4,float param_5
            )

{
  undefined8 uVar1;
  undefined8 uVar2;
  float fVar3;
  float fVar4;
  int iVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fStack_d4;
  float fStack_d0;
  float fStack_b8;
  float fStack_b4;
  float fStack_a0;
  float fStack_9c;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  undefined4 auStack_50 [2];
  float afStack_48 [6];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_1c;
  undefined4 uStack_c;
  
  iVar5 = 6;
  do {
    FUN_00569440();
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  uVar1 = *param_2;
  fVar3 = *(float *)(param_2 + 1);
  uVar2 = *param_4;
  fVar4 = *(float *)(param_4 + 1);
  dVar6 = (double)((param_5 * DAT_018ce2f4 * DAT_018f8ff4) / DAT_01900a20);
  dVar7 = dVar6;
  FUN_017279f0();
  FUN_01728390();
  iVar5 = 0;
  fStack_d0 = (float)((ulonglong)uVar2 >> 0x20);
  do {
    fVar10 = *(float *)((int)&DAT_01d62218 + iVar5);
    fStack_9c = (float)((ulonglong)*(undefined8 *)((int)&DAT_01d62210 + iVar5) >> 0x20);
    fStack_a0 = (float)*(undefined8 *)((int)&DAT_01d62210 + iVar5);
    fStack_d4 = (float)uVar2;
    fVar9 = fStack_9c * fStack_d0 + fStack_a0 * fStack_d4 + fVar10 * fVar4;
    fStack_b8 = (float)uVar1;
    fStack_b4 = (float)((ulonglong)uVar1 >> 0x20);
    if (fVar9 < (float)dVar7) {
      if ((float)((uint)(float)dVar6 ^ DAT_018c4ea0) < fVar9) {
        FUN_01160a40(fStack_d4 * fStack_d4,fStack_d4 * fStack_d0,fStack_d4 * fVar4,
                     fStack_d4 * fStack_d0,fStack_d0 * fStack_d0,fStack_d0 * fVar4,fStack_d4 * fVar4
                     ,fStack_d0 * fVar4,fVar4 * fVar4);
        fVar12 = (float)dVar7 * param_3;
        fVar13 = fStack_a0 - (fStack_78 * fStack_9c + fStack_7c * fStack_a0 + fStack_74 * fVar10);
        fVar14 = fStack_9c - (fStack_6c * fStack_9c + fStack_70 * fStack_a0 + fStack_68 * fVar10);
        fVar10 = fVar10 - (fStack_60 * fStack_9c + fStack_64 * fStack_a0 + fStack_5c * fVar10);
        dVar8 = (double)(fVar14 * fVar14 + fVar13 * fVar13 + fVar10 * fVar10);
        FUN_017267a0();
        fVar11 = DAT_018ce2f8 / (float)dVar8;
        fVar9 = (float)dVar6 * param_3;
        fVar10 = fVar11 * fVar10 * fVar9 + fVar12 * fVar4 + fVar3;
        *(ulonglong *)((int)auStack_50 + iVar5) =
             CONCAT44(fVar11 * fVar14 * fVar9 + fVar12 * fStack_d0 + fStack_b4,
                      fVar11 * fVar13 * fVar9 + fVar12 * fStack_d4 + fStack_b8);
        goto LAB_008372bd;
      }
      *(undefined8 *)((int)auStack_50 + iVar5) = uVar1;
      *(float *)((int)afStack_48 + iVar5) = fVar3;
    }
    else {
      fVar10 = fVar10 * param_3 + fVar3;
      *(ulonglong *)((int)auStack_50 + iVar5) =
           CONCAT44(fStack_9c * param_3 + fStack_b4,fStack_a0 * param_3 + fStack_b8);
LAB_008372bd:
      *(float *)((int)afStack_48 + iVar5) = fVar10;
    }
    iVar5 = iVar5 + 0xc;
    if (0x47 < iVar5) {
      *param_1 = CONCAT44(afStack_48[2],auStack_50[0]);
      *(undefined4 *)(param_1 + 1) = uStack_30;
      *(ulonglong *)((int)param_1 + 0xc) = CONCAT44(uStack_1c,uStack_2c);
      *(undefined4 *)((int)param_1 + 0x14) = uStack_c;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 12738 ; VA 0x00837340 ; FUN_00837340 */

undefined8 * __thiscall FUN_00837340(int param_1,undefined8 *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  float *pfVar5;
  float *pfVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined auStack_e4 [36];
  undefined auStack_c0 [36];
  undefined auStack_9c [36];
  undefined auStack_78 [12];
  undefined auStack_6c [16];
  undefined auStack_5c [12];
  undefined auStack_50 [12];
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  iVar4 = *(int *)(param_1 + 0xd4);
  if (iVar4 == 1) {
    fStack_8 = *(float *)(param_1 + 0xe8);
    fStack_18 = *(float *)(param_1 + 0x9c);
    fStack_14 = *(float *)(param_1 + 0xa0);
    fStack_10 = *(float *)(param_1 + 0xa4);
    uStack_c = 0x3f800000;
    FUN_01165b90(auStack_6c,&fStack_18);
    pfVar5 = (float *)FUN_011658d0(auStack_5c);
    fVar1 = *pfVar5;
    fVar2 = pfVar5[1];
    fVar3 = pfVar5[2];
    *param_2 = CONCAT44(fVar2 - fStack_8,fVar1 - fStack_8);
    *(float *)(param_2 + 1) = fVar3 - fStack_8;
    *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(fVar2 + fStack_8,fVar1 + fStack_8);
    *(float *)((int)param_2 + 0x14) = fVar3 + fStack_8;
    return param_2;
  }
  if (iVar4 != 2) {
    if (iVar4 != 3) {
      *(undefined4 *)param_2 = 0x7f7fffff;
      *(undefined4 *)((int)param_2 + 4) = 0x7f7fffff;
      *(undefined4 *)(param_2 + 1) = 0x7f7fffff;
      *(undefined4 *)((int)param_2 + 0xc) = 0xff7fffff;
      *(undefined4 *)(param_2 + 2) = 0xff7fffff;
      *(undefined4 *)((int)param_2 + 0x14) = 0xff7fffff;
      return param_2;
    }
    fStack_8 = *(float *)(param_1 + 0xd0);
    pfVar5 = (float *)FUN_01165f80(auStack_c0);
    pfVar6 = (float *)FUN_011658d0(auStack_50);
    fVar1 = pfVar6[1];
    fVar2 = *pfVar6;
    fVar3 = pfVar6[2];
    fStack_44 = pfVar5[1] * fVar1 + *pfVar5 * fVar2 + pfVar5[2] * fVar3;
    fStack_40 = pfVar5[3] * fVar2 + pfVar5[4] * fVar1 + pfVar5[5] * fVar3;
    fStack_3c = pfVar5[6] * fVar2 + pfVar5[7] * fVar1 + pfVar5[8] * fVar3;
    uStack_38 = fStack_8;
    uVar7 = *(undefined4 *)(param_1 + 0xc0);
    pfVar5 = (float *)FUN_01165f80(auStack_e4);
    pfVar6 = (float *)FUN_011658d0(auStack_78);
    fVar1 = *pfVar6;
    fVar2 = pfVar6[1];
    fVar3 = pfVar6[2];
    fStack_18 = pfVar5[1] * fVar2 + fVar1 * *pfVar5 + pfVar5[2] * fVar3;
    fStack_14 = pfVar5[3] * fVar1 + pfVar5[4] * fVar2 + pfVar5[5] * fVar3;
    fStack_10 = pfVar5[6] * fVar1 + pfVar5[7] * fVar2 + pfVar5[8] * fVar3;
    uVar8 = *(undefined4 *)(param_1 + 0xec);
    uStack_c = uVar7;
    pfVar5 = (float *)FUN_01165f80(auStack_9c);
    fVar1 = *(float *)(param_1 + 0xa8);
    fVar2 = *(float *)(param_1 + 0xac);
    fVar3 = *(float *)(param_1 + 0xb0);
    fStack_24 = pfVar5[1] * fVar2 + fVar1 * *pfVar5 + pfVar5[2] * fVar3;
    fStack_20 = pfVar5[4] * fVar2 + pfVar5[3] * fVar1 + pfVar5[5] * fVar3;
    uStack_28 = 0x3f800000;
    fStack_1c = pfVar5[7] * fVar2 + pfVar5[6] * fVar1 + pfVar5[8] * fVar3;
    fStack_8 = *(float *)(param_1 + 0xe8);
    uStack_34 = *(undefined4 *)(param_1 + 0x9c);
    uStack_30 = *(undefined4 *)(param_1 + 0xa0);
    uStack_2c = *(undefined4 *)(param_1 + 0xa4);
    FUN_01165b90(auStack_6c,&uStack_34);
    uVar7 = FUN_011658d0(auStack_5c);
    FUN_00837bc0(param_2,uVar7,fStack_8,&fStack_24,uVar8,&fStack_18,&fStack_44);
    return param_2;
  }
  fStack_8 = *(float *)(param_1 + 0xec);
  pfVar5 = (float *)FUN_01165f80(auStack_9c);
  fVar1 = *(float *)(param_1 + 0xa8);
  fVar2 = *(float *)(param_1 + 0xac);
  fVar3 = *(float *)(param_1 + 0xb0);
  fStack_24 = pfVar5[1] * fVar2 + fVar1 * *pfVar5 + pfVar5[2] * fVar3;
  fStack_20 = pfVar5[4] * fVar2 + pfVar5[3] * fVar1 + pfVar5[5] * fVar3;
  uStack_c = 0x3f800000;
  fStack_1c = pfVar5[7] * fVar2 + pfVar5[6] * fVar1 + pfVar5[8] * fVar3;
  uVar7 = *(undefined4 *)(param_1 + 0xe8);
  fStack_18 = *(float *)(param_1 + 0x9c);
  fStack_14 = *(float *)(param_1 + 0xa0);
  fStack_10 = *(float *)(param_1 + 0xa4);
  FUN_01165b90(auStack_6c,&fStack_18);
  uVar8 = FUN_011658d0(auStack_5c);
  FUN_00836f30(param_2,uVar8,uVar7,&fStack_24,fStack_8);
  return param_2;
}



/* FUNCTION 12739 ; VA 0x00837840 ; FUN_00837840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float * FUN_00837840(float *param_1,float *param_2,undefined4 param_3,int param_4,int param_5,
                    float param_6)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  float *pfVar6;
  uint uVar7;
  float fVar8;
  float fVar9;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  undefined auStack_48 [8];
  float fStack_40;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  int iStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar3 = *(int *)((int)param_6 + 0xc);
  iVar4 = FUN_00d41330();
  iVar5 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da)) {
    iVar5 = (int)param_6;
  }
  if (iVar5 != 0) {
    fVar8 = *(float *)(iVar5 + 0x6c);
    fVar9 = *param_2;
    fVar1 = param_2[1];
    fVar2 = param_2[2];
    *(ulonglong *)param_1 = CONCAT44(fVar1 - fVar8,fVar9 - fVar8);
    param_1[2] = fVar2 - fVar8;
    *(ulonglong *)(param_1 + 3) = CONCAT44(fVar1 + fVar8,fVar9 + fVar8);
    param_1[5] = fVar2 + fVar8;
    return param_1;
  }
  iVar3 = *(int *)((int)param_6 + 0xc);
  iVar5 = FUN_00d41530();
  iStack_18 = 0;
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
      (uint)*(ushort *)(iVar5 + 0x1da)) {
    iStack_18 = (int)param_6;
  }
  if (iStack_18 == 0) {
    iVar3 = *(int *)((int)param_6 + 0xc);
    iVar4 = FUN_00d41430();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar5 = (int)param_6;
    }
    if (iVar5 == 0) {
      *param_1 = 3.4028235e+38;
      param_1[1] = 3.4028235e+38;
      param_1[2] = 3.4028235e+38;
      param_1[3] = -3.4028235e+38;
      param_1[4] = -3.4028235e+38;
      param_1[5] = -3.4028235e+38;
      return param_1;
    }
    FUN_00836f30(param_1,param_2,*(undefined4 *)(iVar5 + 0x6c),param_3,*(undefined4 *)(iVar5 + 0x70)
                );
    return param_1;
  }
  pfVar6 = (float *)FUN_011658d0(auStack_48);
  fStack_14 = *(float *)(param_4 + 0xc);
  fStack_c = *pfVar6 * fStack_14;
  fStack_10 = pfVar6[1] * fStack_14;
  fStack_14 = pfVar6[2] * fStack_14;
  pfVar6 = (float *)FUN_011658d0(auStack_48);
  fStack_24 = *(float *)(param_5 + 0xc);
  uVar7 = 0;
  fStack_1c = *pfVar6 * fStack_24;
  fStack_20 = pfVar6[1] * fStack_24;
  fStack_24 = pfVar6[2] * fStack_24;
  fStack_60 = _DAT_018c4eb0;
  fStack_5c = _UNK_018c4eb4;
  fStack_58 = _UNK_018c4eb8;
  fStack_54 = _UNK_018c4ebc;
  param_6 = DAT_018c45d0;
  fStack_8 = DAT_018c45d0;
  do {
    fVar9 = (float)(int)((uVar7 & 1) * 2 + -1);
    fVar8 = (float)(int)((uint)((uVar7 & 2) != 0) * 2 + -1);
    fStack_30 = fStack_c * fVar9 + *param_2 + fStack_1c * fVar8;
    fStack_2c = fStack_10 * fVar9 + param_2[1] + fStack_20 * fVar8;
    fStack_28 = fStack_14 * fVar9 + param_2[2] + fStack_24 * fVar8;
    FUN_00836f30(&fStack_78,&fStack_30,*(undefined4 *)(iStack_18 + 0x6c),param_3,
                 *(undefined4 *)(iStack_18 + 0x70));
    if (fStack_70 <= fStack_58) {
      fStack_58 = fStack_70;
    }
    if (fStack_74 <= fStack_5c) {
      fStack_5c = fStack_74;
    }
    if (fStack_78 <= fStack_60) {
      fStack_60 = fStack_78;
    }
    if (param_6 <= fStack_64) {
      param_6 = fStack_64;
    }
    if (fStack_8 <= fStack_68) {
      fStack_8 = fStack_68;
    }
    if (fStack_54 <= fStack_6c) {
      fStack_54 = fStack_6c;
    }
    uVar7 = uVar7 + 1;
    fStack_50 = fStack_8;
    fStack_4c = param_6;
    fStack_40 = param_6;
    fStack_34 = fStack_58;
  } while ((int)uVar7 < 4);
  *param_1 = fStack_60;
  param_1[1] = fStack_5c;
  param_1[2] = fStack_58;
  param_1[3] = fStack_54;
  *(ulonglong *)(param_1 + 4) = CONCAT44(param_6,fStack_8);
  return param_1;
}



/* FUNCTION 12740 ; VA 0x00837bc0 ; FUN_00837bc0 */

float * FUN_00837bc0(float *param_1,float *param_2,undefined4 param_3,undefined4 param_4,
                    undefined4 param_5,int param_6,int param_7)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float *pfVar5;
  uint uVar6;
  float fVar7;
  float fVar8;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  undefined auStack_38 [8];
  float fStack_30;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  pfVar5 = (float *)FUN_011658d0(auStack_38);
  fVar1 = *(float *)(param_6 + 0xc);
  fVar2 = *pfVar5;
  fStack_8 = pfVar5[1] * fVar1;
  fStack_c = pfVar5[2] * fVar1;
  pfVar5 = (float *)FUN_011658d0(auStack_38);
  fVar3 = *(float *)(param_7 + 0xc);
  uVar6 = 0;
  fVar4 = *pfVar5;
  fStack_10 = pfVar5[1];
  fStack_14 = pfVar5[2];
  *param_1 = 3.4028235e+38;
  fStack_10 = fStack_10 * fVar3;
  param_1[1] = 3.4028235e+38;
  fStack_14 = fStack_14 * fVar3;
  param_1[2] = 3.4028235e+38;
  param_1[3] = -3.4028235e+38;
  param_1[4] = -3.4028235e+38;
  param_1[5] = -3.4028235e+38;
  do {
    fVar8 = (float)(int)((uVar6 & 1) * 2 + -1);
    fVar7 = (float)(int)((uint)((uVar6 & 2) != 0) * 2 + -1);
    fStack_20 = fVar2 * fVar1 * fVar8 + *param_2 + fVar4 * fVar3 * fVar7;
    fStack_1c = fStack_8 * fVar8 + param_2[1] + fStack_10 * fVar7;
    fStack_18 = fStack_c * fVar8 + param_2[2] + fStack_14 * fVar7;
    FUN_00836f30(&fStack_50,&fStack_20,param_3,param_4,param_5);
    fStack_24 = param_1[2];
    if (fStack_48 <= param_1[2]) {
      fStack_24 = fStack_48;
    }
    fVar7 = param_1[1];
    if (fStack_4c <= param_1[1]) {
      fVar7 = fStack_4c;
    }
    fVar8 = *param_1;
    if (fStack_50 <= *param_1) {
      fVar8 = fStack_50;
    }
    *(ulonglong *)param_1 = CONCAT44(fVar7,fVar8);
    param_1[2] = fStack_24;
    fStack_30 = param_1[5];
    if (param_1[5] <= fStack_3c) {
      fStack_30 = fStack_3c;
    }
    fVar7 = param_1[4];
    if (param_1[4] <= fStack_40) {
      fVar7 = fStack_40;
    }
    fVar8 = param_1[3];
    if (param_1[3] <= fStack_44) {
      fVar8 = fStack_44;
    }
    uVar6 = uVar6 + 1;
    *(ulonglong *)(param_1 + 3) = CONCAT44(fVar7,fVar8);
    param_1[5] = fStack_30;
  } while ((int)uVar6 < 4);
  return param_1;
}



/* FUNCTION 12741 ; VA 0x00837de0 ; FUN_00837de0 */

void FUN_00837de0(float *param_1,float *param_2,float param_3,float *param_4,float param_5,
                 int param_6,int param_7)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float *pfVar10;
  float *pfVar11;
  float fVar12;
  float fVar13;
  double dVar14;
  double dVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  undefined auStack_20 [12];
  undefined auStack_14 [16];
  
  pfVar10 = (float *)FUN_011658d0(auStack_20);
  fVar13 = *(float *)(param_6 + 0xc);
  fVar18 = *pfVar10;
  fVar21 = pfVar10[1];
  fVar1 = pfVar10[2];
  pfVar10 = (float *)FUN_011658d0(auStack_20);
  fVar2 = *(float *)(param_7 + 0xc);
  fVar3 = *pfVar10;
  fVar4 = pfVar10[1];
  fVar5 = pfVar10[2];
  fVar20 = *param_4;
  fVar22 = param_4[1];
  fVar6 = param_4[2];
  fVar12 = param_3 * DAT_018ce2f4;
  fVar7 = *param_2;
  fVar16 = fVar20 * fVar12 + fVar7;
  fVar8 = param_2[1];
  fVar17 = fVar22 * fVar12 + fVar8;
  fVar9 = param_2[2];
  fVar19 = fVar6 * fVar12 + fVar9;
  pfVar10 = (float *)FUN_011658d0(auStack_20);
  pfVar11 = (float *)FUN_011658d0(auStack_14);
  dVar14 = (double)((param_5 * DAT_018ce2f4 * DAT_018f8ff4) / DAT_01900a20);
  FUN_01728390();
  fVar12 = (float)dVar14 * param_3;
  fVar23 = (fVar7 + fVar13 * fVar18 + fVar3 * fVar2 + fVar20 * param_3 +
           (*pfVar10 + *pfVar11) * fVar12) - fVar16;
  fVar22 = (fVar8 + fVar21 * fVar13 + fVar4 * fVar2 + fVar22 * param_3 +
           (pfVar10[1] + pfVar11[1]) * fVar12) - fVar17;
  fVar20 = (fVar9 + fVar1 * fVar13 + fVar5 * fVar2 + fVar6 * param_3 +
           (pfVar10[2] + pfVar11[2]) * fVar12) - fVar19;
  dVar14 = (double)(fVar23 * fVar23 + fVar22 * fVar22 + fVar20 * fVar20);
  FUN_017267a0();
  fVar21 = ((fVar8 - fVar21 * fVar13) - fVar4 * fVar2) - fVar17;
  fVar18 = ((fVar7 - fVar13 * fVar18) - fVar3 * fVar2) - fVar16;
  fVar13 = ((fVar9 - fVar1 * fVar13) - fVar5 * fVar2) - fVar19;
  dVar15 = (double)(fVar21 * fVar21 + fVar18 * fVar18 + fVar13 * fVar13);
  FUN_017267a0();
  fVar13 = (float)dVar14;
  if ((float)dVar14 <= (float)dVar15) {
    fVar13 = (float)dVar15;
  }
  *param_1 = fVar16;
  param_1[1] = fVar17;
  param_1[2] = fVar19;
  param_1[3] = fVar13;
  return;
}



/* FUNCTION 12742 ; VA 0x008380d0 ; FUN_008380d0 */

float * __thiscall FUN_008380d0(int param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  float *pfVar3;
  float *pfVar4;
  undefined4 uVar5;
  float fVar6;
  double dVar7;
  undefined4 uVar8;
  float fVar9;
  undefined auStack_f0 [36];
  undefined auStack_cc [36];
  undefined auStack_a8 [36];
  undefined auStack_84 [12];
  undefined auStack_78 [12];
  undefined auStack_6c [16];
  undefined auStack_5c [12];
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  float fStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  iVar2 = *(int *)(param_1 + 0xd4);
  if (iVar2 == 1) {
    fStack_8 = *(float *)(param_1 + 0xe8);
    fStack_18 = *(float *)(param_1 + 0x9c);
    fStack_14 = *(float *)(param_1 + 0xa0);
    fStack_10 = *(float *)(param_1 + 0xa4);
    uStack_c = 0x3f800000;
    FUN_01165b90(auStack_6c,&fStack_18);
    pfVar3 = (float *)FUN_011658d0(auStack_5c);
    *param_2 = *pfVar3;
    param_2[1] = pfVar3[1];
    param_2[2] = pfVar3[2];
    param_2[3] = fStack_8;
    return param_2;
  }
  if (iVar2 != 2) {
    if (iVar2 != 3) {
      *param_2 = 0.0;
      param_2[1] = 0.0;
      param_2[2] = 0.0;
      param_2[3] = 0.0;
      return param_2;
    }
    fStack_8 = *(float *)(param_1 + 0xd0);
    pfVar3 = (float *)FUN_01165f80(auStack_cc);
    pfVar4 = (float *)FUN_011658d0(auStack_78);
    fVar6 = pfVar4[1];
    fVar9 = *pfVar4;
    fVar1 = pfVar4[2];
    fStack_50 = pfVar3[1] * fVar6 + *pfVar3 * fVar9 + pfVar3[2] * fVar1;
    fStack_4c = pfVar3[3] * fVar9 + pfVar3[4] * fVar6 + pfVar3[5] * fVar1;
    fStack_48 = pfVar3[6] * fVar9 + pfVar3[7] * fVar6 + pfVar3[8] * fVar1;
    uStack_44 = fStack_8;
    uVar5 = *(undefined4 *)(param_1 + 0xc0);
    pfVar3 = (float *)FUN_01165f80(auStack_f0);
    pfVar4 = (float *)FUN_011658d0(auStack_84);
    fVar6 = *pfVar4;
    fVar9 = pfVar4[1];
    fVar1 = pfVar4[2];
    fStack_18 = pfVar3[1] * fVar9 + fVar6 * *pfVar3 + pfVar3[2] * fVar1;
    fStack_14 = pfVar3[3] * fVar6 + pfVar3[4] * fVar9 + pfVar3[5] * fVar1;
    fStack_10 = pfVar3[6] * fVar6 + pfVar3[7] * fVar9 + pfVar3[8] * fVar1;
    uVar8 = *(undefined4 *)(param_1 + 0xec);
    uStack_c = uVar5;
    pfVar3 = (float *)FUN_01165f80(auStack_a8);
    fVar6 = *(float *)(param_1 + 0xa8);
    fVar9 = *(float *)(param_1 + 0xac);
    fVar1 = *(float *)(param_1 + 0xb0);
    fStack_30 = pfVar3[1] * fVar9 + fVar6 * *pfVar3 + pfVar3[2] * fVar1;
    uStack_34 = 0x3f800000;
    fStack_8 = *(float *)(param_1 + 0xe8);
    uStack_40 = *(undefined4 *)(param_1 + 0x9c);
    uStack_3c = *(undefined4 *)(param_1 + 0xa0);
    uStack_38 = *(undefined4 *)(param_1 + 0xa4);
    uStack_2c = (double)CONCAT44(pfVar3[6] * fVar6 + pfVar3[7] * fVar9 + pfVar3[8] * fVar1,
                                 pfVar3[3] * fVar6 + pfVar3[4] * fVar9 + pfVar3[5] * fVar1);
    FUN_01165b90(auStack_6c,&uStack_40);
    uVar5 = FUN_011658d0(auStack_5c);
    FUN_00837de0(param_2,uVar5,fStack_8,&fStack_30,uVar8,&fStack_18,&fStack_50);
    return param_2;
  }
  fStack_1c = *(float *)(param_1 + 0xec);
  pfVar3 = (float *)FUN_01165f80(auStack_a8);
  fVar6 = *(float *)(param_1 + 0xac);
  fVar9 = *(float *)(param_1 + 0xa8);
  fVar1 = *(float *)(param_1 + 0xb0);
  fStack_24 = pfVar3[4] * fVar6 + pfVar3[3] * fVar9 + pfVar3[5] * fVar1;
  fStack_8 = pfVar3[7] * fVar6 + pfVar3[6] * fVar9 + pfVar3[8] * fVar1;
  uStack_c = 0x3f800000;
  fStack_20 = pfVar3[1] * fVar6 + fVar9 * *pfVar3 + pfVar3[2] * fVar1;
  fVar6 = *(float *)(param_1 + 0xe8);
  fStack_18 = *(float *)(param_1 + 0x9c);
  fStack_14 = *(float *)(param_1 + 0xa0);
  fStack_10 = *(float *)(param_1 + 0xa4);
  FUN_01165b90(auStack_6c,&fStack_18);
  pfVar3 = (float *)FUN_011658d0(auStack_5c);
  dVar7 = (double)((fStack_1c * DAT_018ce2f4 * DAT_018f8ff4) / DAT_01900a20);
  uStack_2c = dVar7;
  FUN_017279f0();
  fVar9 = (float)dVar7;
  if (fStack_1c <= DAT_01918f84) {
    fVar6 = fVar6 / (fVar9 + fVar9);
    fStack_18 = fStack_20 * fVar6 + *pfVar3;
    fStack_14 = fStack_24 * fVar6 + pfVar3[1];
    fStack_10 = fStack_8 * fVar6 + pfVar3[2];
  }
  else {
    fVar9 = fVar6 * fVar9;
    uVar5 = SUB84(uStack_2c,0);
    uVar8 = (undefined4)((ulonglong)uStack_2c >> 0x20);
    fStack_18 = fStack_20 * fVar9 + *pfVar3;
    fStack_14 = fStack_24 * fVar9 + pfVar3[1];
    fStack_10 = fStack_8 * fVar9 + pfVar3[2];
    FUN_01728390();
    fVar6 = (float)(double)CONCAT44(uVar8,uVar5) * fVar6;
  }
  *param_2 = fStack_18;
  param_2[1] = fStack_14;
  param_2[2] = fStack_10;
  param_2[3] = fVar6;
  return param_2;
}



/* FUNCTION 12743 ; VA 0x00838650 ; FUN_00838650 */

void FUN_00838650(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))(param_2);
  return;
}



/* FUNCTION 12744 ; VA 0x00838670 ; FUN_00838670 */

undefined8 * FUN_00838670(undefined8 *param_1,float *param_2,float param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  
  fVar1 = *param_2;
  fVar2 = param_2[1];
  fVar3 = param_2[2];
  *param_1 = CONCAT44(fVar2 - param_3,fVar1 - param_3);
  *(float *)(param_1 + 1) = fVar3 - param_3;
  *(ulonglong *)((int)param_1 + 0xc) = CONCAT44(fVar2 + param_3,fVar1 + param_3);
  *(float *)((int)param_1 + 0x14) = fVar3 + param_3;
  return param_1;
}



/* FUNCTION 12745 ; VA 0x008386f0 ; FUN_008386f0 */

void FUN_008386f0(int param_1,undefined4 *param_2,float *param_3,float *param_4,undefined4 *param_5,
                 undefined4 *param_6)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  float fVar7;
  
  switch(param_1) {
  case 0:
  case 3:
    iVar6 = param_1 % 3;
    fVar7 = (float)((param_1 / 3) * -2 + 1);
    fVar1 = (float)param_2[iVar6 + 3];
    fVar2 = (float)param_2[iVar6 + 6];
    fVar3 = *param_3;
    *param_4 = (float)param_2[iVar6] * fVar7;
    param_4[1] = fVar1 * fVar7;
    param_4[2] = fVar2 * fVar7;
    param_4[3] = fVar3;
    uVar4 = param_2[4];
    uVar5 = param_2[7];
    fVar1 = param_3[1];
    *param_5 = param_2[1];
    param_5[1] = uVar4;
    param_5[2] = uVar5;
    param_5[3] = fVar1;
    uVar4 = param_2[5];
    uVar5 = param_2[8];
    fVar1 = param_3[2];
    *param_6 = param_2[2];
    param_6[1] = uVar4;
    param_6[2] = uVar5;
    param_6[3] = fVar1;
    return;
  case 1:
  case 4:
    iVar6 = param_1 % 3;
    fVar7 = (float)((param_1 / 3) * -2 + 1);
    fVar1 = (float)param_2[iVar6 + 3];
    fVar2 = (float)param_2[iVar6 + 6];
    fVar3 = param_3[1];
    *param_4 = (float)param_2[iVar6] * fVar7;
    param_4[1] = fVar1 * fVar7;
    param_4[2] = fVar2 * fVar7;
    param_4[3] = fVar3;
    uVar4 = param_2[5];
    uVar5 = param_2[8];
    fVar1 = param_3[2];
    *param_5 = param_2[2];
    param_5[1] = uVar4;
    param_5[2] = uVar5;
    param_5[3] = fVar1;
    uVar4 = param_2[3];
    uVar5 = param_2[6];
    fVar1 = *param_3;
    *param_6 = *param_2;
    param_6[1] = uVar4;
    param_6[2] = uVar5;
    param_6[3] = fVar1;
    return;
  case 2:
  case 5:
    iVar6 = param_1 % 3;
    fVar7 = (float)((param_1 / 3) * -2 + 1);
    fVar1 = (float)param_2[iVar6 + 3];
    fVar2 = (float)param_2[iVar6 + 6];
    fVar3 = param_3[2];
    *param_4 = (float)param_2[iVar6] * fVar7;
    param_4[1] = fVar1 * fVar7;
    param_4[2] = fVar2 * fVar7;
    param_4[3] = fVar3;
    uVar4 = param_2[3];
    uVar5 = param_2[6];
    fVar1 = *param_3;
    *param_5 = *param_2;
    param_5[1] = uVar4;
    param_5[2] = uVar5;
    param_5[3] = fVar1;
    uVar4 = param_2[4];
    uVar5 = param_2[7];
    fVar1 = param_3[1];
    *param_6 = param_2[1];
    param_6[1] = uVar4;
    param_6[2] = uVar5;
    param_6[3] = fVar1;
    return;
  default:
    *param_5 = 0;
    param_5[1] = 0;
    param_5[2] = 0;
    param_5[3] = 0;
    *param_6 = 0;
    param_6[1] = 0;
    param_6[2] = 0;
    param_6[3] = 0;
    return;
  }
}



/* FUNCTION 12746 ; VA 0x008389c0 ; FUN_008389c0 */

void __thiscall FUN_008389c0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 100);
  *param_2 = *(undefined8 *)(param_1 + 0x5c);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12747 ; VA 0x008389e0 ; FUN_008389e0 */

undefined4 __fastcall FUN_008389e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x74);
}



/* FUNCTION 12748 ; VA 0x008389f0 ; FUN_008389f0 */

undefined4 __fastcall FUN_008389f0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (*(int *)(param_1 + 0x68) != 0) {
    switch(*(undefined4 *)(*(int *)(param_1 + 0x68) + 0x1d4)) {
    default:
      iVar2 = 0;
      break;
    case 1:
      iVar2 = 1;
      break;
    case 2:
      iVar2 = 2;
      break;
    case 4:
      iVar2 = 3;
    }
    if (iVar2 == *(int *)(param_1 + 0xd4)) goto LAB_00838a44;
  }
  uVar3 = FUN_0083abe0(param_1);
  puVar1 = *(undefined4 **)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 0x68) = uVar3;
  if (puVar1 == (undefined4 *)0x0) {
    return uVar3;
  }
  (**(code **)*puVar1)(1);
LAB_00838a44:
  return *(undefined4 *)(param_1 + 0x68);
}



/* FUNCTION 12749 ; VA 0x00838a60 ; FUN_00838a60 */

float10 __fastcall FUN_00838a60(int param_1)

{
  return (float10)*(float *)(param_1 + 0x6c);
}


