/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 17250 ; VA 0x00953250 ; FUN_00953250 */

void FUN_00953250(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar5 = (undefined4 *)FUN_01674e20(0x40);
      if (puVar5 != (undefined4 *)0x0) {
        uVar2 = puVar1[1];
        uVar3 = puVar1[2];
        uVar4 = puVar1[3];
        *puVar5 = *puVar1;
        puVar5[1] = uVar2;
        puVar5[2] = uVar3;
        puVar5[3] = uVar4;
        uVar2 = puVar1[5];
        uVar3 = puVar1[6];
        uVar4 = puVar1[7];
        puVar5[4] = puVar1[4];
        puVar5[5] = uVar2;
        puVar5[6] = uVar3;
        puVar5[7] = uVar4;
        uVar2 = puVar1[9];
        uVar3 = puVar1[10];
        uVar4 = puVar1[0xb];
        puVar5[8] = puVar1[8];
        puVar5[9] = uVar2;
        puVar5[10] = uVar3;
        puVar5[0xb] = uVar4;
        uVar2 = puVar1[0xd];
        uVar3 = puVar1[0xe];
        uVar4 = puVar1[0xf];
        puVar5[0xc] = puVar1[0xc];
        puVar5[0xd] = uVar2;
        puVar5[0xe] = uVar3;
        puVar5[0xf] = uVar4;
        *param_2 = (int)puVar5;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      FUN_01674ea0(*param_2,0x40);
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1db697c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_RBX::ScriptContext&,class_RBX::Security::Identity_const&,struct_lua_State*,struct_RBX::ScriptContext::AssetModuleInfo*,__int64),class_boost::_bi::list7<struct_boost::arg<1>,struct_boost::arg<2>,class_boost::reference_wrapper<class_RBX::ScriptContext>,class_boost::_bi::value<class_RBX::Security::Identity>,class_boost::_bi::value<struct_lua_State*>,class_boost::_bi::value<struct_RBX::ScriptContext::AssetModuleInfo*>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17251 ; VA 0x00953320 ; FUN_00953320 */

int FUN_00953320(int *param_1,int *param_2,int *param_3,int *param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7,int *param_8,undefined4 param_9,
                undefined4 param_10)

{
  int **ppiVar1;
  int *piVar2;
  undefined3 uVar3;
  undefined *puVar4;
  undefined3 uVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  undefined4 in_stack_ffffff84;
  undefined4 uVar12;
  undefined4 uVar13;
  int *piVar14;
  undefined auStack_54 [4];
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbc90;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa0;
  piStack_1c = (int *)0x0;
  piStack_34 = (int *)0x0;
  iStack_30 = 0;
  uStack_8._1_3_ = 0;
  uVar3 = uStack_8._1_3_;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  ppiVar1 = (int **)(param_8 + 1);
  ExceptionList = &pvStack_10;
  if (&piStack_38 != ppiVar1) {
    piStack_1c = *ppiVar1;
    ExceptionList = &pvStack_10;
    *ppiVar1 = (int *)0x0;
    piStack_34 = (int *)param_8[2];
    param_8[2] = 0;
    iStack_30 = param_8[3];
    param_8[3] = 0;
  }
  piStack_38 = piStack_1c;
  if (*param_8 == 4) {
    param_8[4] = 0;
    piVar7 = (int *)param_8[5];
    param_8[5] = 0;
    puStack_14 = &stack0xffffffa0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar9 = piVar7[1] + -1;
      piVar7[1] = iVar9;
      UNLOCK();
      puStack_14 = &stack0xffffffa0;
      if (iVar9 == 0) {
        puStack_14 = &stack0xffffffa0;
        (**(code **)*piVar7)();
        LOCK();
        iVar9 = piVar7[2] + -1;
        piVar7[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    uVar6 = FUN_01675640(auStack_50,"%s %lld.  %s","Downloading asset failed for asset id",param_9,
                         param_10,"Is the asset id correct and is the asset type \"Model\"?");
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0094e0d0(&piStack_38,uVar6);
    if (0xf < uStack_3c) {
      uVar11 = uStack_3c + 1;
      uVar10 = auStack_50[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_50[0] - 4);
        uVar11 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
  }
  else if (param_3 == (int *)0x0) {
    piStack_20 = param_3;
    piStack_1c = param_3;
    *param_8 = 3;
    puStack_14 = &stack0xffffffa0;
    uStack_8._1_3_ = uVar3;
    FUN_005587e0(&piStack_20);
    piVar7 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar7 + 2;
        iVar9 = *piVar2 + -1;
        *piVar2 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    uVar6 = FUN_01675640(auStack_50,"%s %lld.  %s","Unable to find module for asset id",param_9,
                         param_10,"Does the asset have a ModuleScript named \"MainModule\"?");
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_0094e0d0(&piStack_38,uVar6);
    FUN_005507b0();
  }
  else {
    *param_8 = 2;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    param_8[4] = (int)param_3;
    piStack_18 = (int *)param_8[5];
    param_8[5] = (int)param_4;
    puVar4 = &stack0xffffffa0;
    uVar5 = uVar3;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_18[1] + -1;
      piStack_18[1] = iVar9;
      UNLOCK();
      puVar4 = &stack0xffffffa0;
      uVar5 = uStack_8._1_3_;
      if (iVar9 == 0) {
        uStack_8._1_3_ = uVar3;
        (**(code **)*piStack_18)();
        LOCK();
        iVar9 = piStack_18[2] + -1;
        piStack_18[2] = iVar9;
        UNLOCK();
        puVar4 = puStack_14;
        uVar5 = uStack_8._1_3_;
        if (iVar9 == 0) {
          (**(code **)(*piStack_18 + 4))();
          puVar4 = puStack_14;
          uVar5 = uStack_8._1_3_;
        }
      }
    }
    uStack_8._1_3_ = uVar5;
    puStack_14 = puVar4;
    piVar7 = (int *)FUN_00942ec0(auStack_2c);
    iVar9 = *piVar7;
    iVar8 = piVar7[1];
    *piVar7 = 0;
    piVar7[1] = 0;
    param_8[6] = iVar9;
    piStack_18 = (int *)param_8[7];
    param_8[7] = iVar8;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_18[1] + -1;
      piStack_18[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar9 = piStack_18[2] + -1;
        piStack_18[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_28;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_18[2] + -1;
        piStack_18[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    for (piStack_18 = (int *)0x0; piStack_18 < (uint)(param_1[1] - *param_1 >> 3);
        piStack_18 = (int *)((int)piStack_18 + 1)) {
      FUN_008a65e0(param_8[6],0);
    }
    uStack_8 = 2;
    if (param_8[5] != 0) {
      LOCK();
      piVar7 = (int *)(param_8[5] + 4);
      *piVar7 = *piVar7 + 1;
      UNLOCK();
    }
    iVar9 = param_8[4];
    uVar6 = 0x95365b;
    uVar12 = param_7;
    FUN_0095ccc0(param_6,param_7,iVar9,param_8[5],0);
    FUN_009edbb0(param_7);
    iVar8 = FUN_005817e0();
    piVar2 = piStack_34;
    piVar7 = piStack_1c;
    if (iVar8 == 1) {
      for (; piVar7 != piVar2; piVar7 = piVar7 + 7) {
        uVar13 = 0x9536f9;
        piVar14 = piVar7;
        FUN_00d88710(piVar7);
        uStack_8._0_1_ = 9;
        FUN_00d88710(auStack_54);
        FUN_009ece40(in_stack_ffffff84,uVar6,param_6,uVar12,iVar9,uVar13,piVar14);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00d88aa0();
      }
    }
    else if (iVar8 == 2) {
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = auStack_50[0] & 0xffffff00;
      FUN_005542c0("Requested module experienced an error while loading",0x33);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_0094e0d0(&piStack_38,auStack_50);
      FUN_005507b0();
    }
    else if (iVar8 == 3) {
      uVar6 = FUN_00615970();
      FUN_0095bd50(&piStack_38,uVar6);
    }
  }
  iVar9 = FUN_00946e40();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar7 = param_2 + 1;
    iVar8 = *piVar7;
    iVar9 = *piVar7;
    *piVar7 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar7 = param_2 + 2;
      iVar8 = *piVar7;
      iVar9 = *piVar7;
      *piVar7 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar7 = param_4 + 1;
    iVar8 = *piVar7;
    iVar9 = *piVar7;
    *piVar7 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      iVar9 = (**(code **)*param_4)();
      LOCK();
      piVar7 = param_4 + 2;
      iVar8 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        iVar9 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 17252 ; VA 0x009535ae ; Catch@009535ae */

undefined * Catch_009535ae(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x20);
  **(undefined4 **)(unaff_EBP + 0x24) = 3;
  uVar2 = (**(code **)(*piVar1 + 4))();
  uVar2 = FUN_01675640(unaff_EBP + -0x4c,"%s (%s)",
                       "Requested module experienced an error while setting Instance parents",uVar2)
  ;
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_0094e0d0(unaff_EBP + -0x34,uVar2);
  FUN_005507b0();
  return &LAB_009535f4;
}



/* FUNCTION 17253 ; VA 0x009537a0 ; FUN_009537a0 */

undefined4 FUN_009537a0(undefined4 param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  char cVar6;
  
  if (param_2 != 0) {
    iVar5 = FUN_009edbb0(param_1);
    puVar1 = *(undefined4 **)(iVar5 + 4);
    puVar2 = (undefined4 *)*puVar1;
    while (puVar2 != puVar1) {
      cVar6 = puVar2[4] == param_3;
      if (!(bool)cVar6) {
        cVar6 = FUN_009537a0(param_1,puVar2[4],param_3);
      }
      if (cVar6 != '\0') {
        return 1;
      }
      puVar3 = (undefined4 *)puVar2[2];
      if (*(char *)((int)puVar3 + 0xd) == '\0') {
        cVar6 = *(char *)((int)*puVar3 + 0xd);
        puVar2 = puVar3;
        puVar3 = (undefined4 *)*puVar3;
        while (cVar6 == '\0') {
          cVar6 = *(char *)((int)*puVar3 + 0xd);
          puVar2 = puVar3;
          puVar3 = (undefined4 *)*puVar3;
        }
      }
      else {
        cVar6 = *(char *)((int)puVar2[1] + 0xd);
        puVar4 = (undefined4 *)puVar2[1];
        puVar3 = puVar2;
        while ((puVar2 = puVar4, cVar6 == '\0' && (puVar3 == (undefined4 *)puVar2[2]))) {
          cVar6 = *(char *)((int)puVar2[1] + 0xd);
          puVar4 = (undefined4 *)puVar2[1];
          puVar3 = puVar2;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 17254 ; VA 0x00953840 ; FUN_00953840 */

void FUN_00953840(undefined4 param_1,uint param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  char *pcVar6;
  undefined4 uVar7;
  char *pcVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  undefined4 ***apppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbcc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pcVar6 = (char *)FUN_01257440(param_1,0xffffffff,0);
  if (pcVar6 != (char *)0x0) {
    pcVar8 = pcVar6;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    if (pcVar8 != pcVar6 + 1) goto LAB_00953890;
  }
  pcVar6 = "An error occurred";
LAB_00953890:
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8._0_1_ = 1;
  FUN_0094ef20(apppuStack_48,param_1,&uStack_1c,&uStack_14);
  piVar4 = piStack_18;
  ppppuVar9 = apppuStack_48;
  if (0xf < uStack_34) {
    ppppuVar9 = (undefined4 ****)apppuStack_48[0];
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  uStack_24 = uStack_1c;
  piStack_20 = piStack_18;
  uStack_8._0_1_ = 3;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (param_2 != 0) {
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    (**(code **)((param_2 & 0xfffffffe) + 4))
              (&stack0x00000010,pcVar6,ppppuVar9,uStack_1c,piStack_18,uStack_14);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_34) {
      uVar10 = uStack_34 + 1;
      ppppuVar9 = (undefined4 ****)apppuStack_48[0];
      if (0xfff < uVar10) {
        ppppuVar9 = (undefined4 ****)apppuStack_48[0][-1];
        uVar10 = uStack_34 + 0x24;
        if (0x1f < (uint)((int)apppuStack_48[0] + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar10);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    apppuStack_48[0] = (undefined4 ***)((uint)apppuStack_48[0] & 0xffffff00);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    uStack_8 = 5;
    if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
       (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8._0_1_ = uVar5;
  uVar7 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar7);
}



/* FUNCTION 17255 ; VA 0x009539d0 ; FUN_009539d0 */

void __thiscall FUN_009539d0(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int **ppiVar7;
  int *piVar8;
  int aiStack_b4 [26];
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbd00;
  pvStack_10 = ExceptionList;
  piStack_40 = (int *)DAT_01ee2a70;
  piStack_44 = (int *)0x9539fa;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_01675290();
  uStack_8 = 0;
  if ((param_2 != 0) != (bool)*(char *)(param_1 + 0x6c)) {
    *(bool *)(param_1 + 0x6c) = param_2 != 0;
    piStack_44 = (int *)0x953a20;
    piStack_40 = (int *)param_1;
    param_2 = FUN_008c0050();
    if (*(char *)(param_1 + 0x6c) == '\0') {
      piStack_40 = *(int **)(param_1 + 100);
      ppiVar7 = (int **)(param_1 + 100);
      piStack_44 = (int *)*piStack_40;
      puStack_48 = (undefined4 *)0x953b5a;
      FUN_009438f0();
      piStack_2c = (int *)0x0;
      uStack_28 = 0;
      piStack_40 = (int *)0x953b70;
      piVar6 = (int *)FUN_00601dc0();
      uStack_8._0_1_ = 4;
      piVar8 = piVar6;
      if (ppiVar7 != &piStack_2c) {
        piVar8 = *ppiVar7;
        *ppiVar7 = piVar6;
        uVar3 = *(undefined4 *)(param_1 + 0x68);
        *(undefined4 *)(param_1 + 0x68) = uStack_28;
        uStack_28 = uVar3;
      }
      piVar6 = (int *)*piVar8;
      piStack_2c = piVar8;
      while (piVar6 != piVar8) {
        piStack_40 = (int *)piVar6[5];
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[2] = piStack_40[2] + 1;
          UNLOCK();
          piStack_40 = (int *)piVar6[5];
        }
        piStack_44 = (int *)piVar6[4];
        uStack_8._0_1_ = 5;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[2] = piStack_40[2] + 1;
          UNLOCK();
        }
        puStack_48 = (undefined4 *)0x953bf0;
        iStack_1c = (int)piStack_44;
        piStack_14 = piStack_40;
        FUN_00959050();
        uStack_8._0_1_ = 4;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar4 = piStack_14[2] + -1;
          piStack_14[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            piStack_40 = (int *)0x953c0c;
            (**(code **)(*piStack_14 + 4))();
          }
        }
        piVar1 = (int *)piVar6[2];
        if (*(char *)((int)piVar1 + 0xd) == '\0') {
          cVar2 = *(char *)(*piVar1 + 0xd);
          piVar6 = piVar1;
          piVar1 = (int *)*piVar1;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*piVar1 + 0xd);
            piVar6 = piVar1;
            piVar1 = (int *)*piVar1;
          }
        }
        else {
          cVar2 = *(char *)(piVar6[1] + 0xd);
          piVar5 = (int *)piVar6[1];
          piVar1 = piVar6;
          while ((piVar6 = piVar5, cVar2 == '\0' && (piVar1 == (int *)piVar6[2]))) {
            cVar2 = *(char *)(piVar6[1] + 0xd);
            piVar5 = (int *)piVar6[1];
            piVar1 = piVar6;
          }
        }
      }
      piStack_40 = (int *)0x953c5c;
      FUN_0094b940();
      piStack_40 = piStack_2c;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      piStack_44 = (int *)*piStack_2c;
      puStack_48 = &param_2;
      uStack_4c = 0x953c72;
      FUN_0094e3b0();
      piStack_44 = piStack_2c;
    }
    else {
      piStack_40 = *(int **)(param_1 + 0x5c);
      ppiVar7 = (int **)(param_1 + 0x5c);
      piStack_44 = (int *)*piStack_40;
      puStack_48 = (undefined4 *)0x953a41;
      FUN_009438f0();
      piStack_24 = (int *)0x0;
      uStack_20 = 0;
      piStack_40 = (int *)0x953a57;
      piVar6 = (int *)FUN_00601dc0();
      uStack_8._0_1_ = 2;
      piVar8 = piVar6;
      if (ppiVar7 != &piStack_24) {
        piVar8 = *ppiVar7;
        *ppiVar7 = piVar6;
        uVar3 = *(undefined4 *)(param_1 + 0x60);
        *(undefined4 *)(param_1 + 0x60) = uStack_20;
        uStack_20 = uVar3;
      }
      piVar6 = (int *)*piVar8;
      piStack_24 = piVar8;
      while (piVar6 != piVar8) {
        piStack_14 = aiStack_b4;
        FUN_01255470(2,0,0,0);
        piVar1 = piStack_14;
        piStack_14[6] = 0;
        piVar1[0xe] = 0;
        piVar1[0x16] = 0;
        if (piVar6[5] != 0) {
          LOCK();
          piVar1 = (int *)(piVar6[5] + 8);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_0094a730(piVar6[4],piVar6[5]);
        piVar1 = (int *)piVar6[2];
        if (*(char *)((int)piVar1 + 0xd) == '\0') {
          cVar2 = *(char *)(*piVar1 + 0xd);
          piVar6 = piVar1;
          piVar1 = (int *)*piVar1;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*piVar1 + 0xd);
            piVar6 = piVar1;
            piVar1 = (int *)*piVar1;
          }
        }
        else {
          cVar2 = *(char *)(piVar6[1] + 0xd);
          piVar5 = (int *)piVar6[1];
          piVar1 = piVar6;
          while ((piVar6 = piVar5, cVar2 == '\0' && (piVar1 == (int *)piVar6[2]))) {
            cVar2 = *(char *)(piVar6[1] + 0xd);
            piVar5 = (int *)piVar6[1];
            piVar1 = piVar6;
          }
        }
      }
      piStack_44 = (int *)*piStack_24;
      puStack_48 = &param_2;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uStack_4c = 0x953b3f;
      piStack_40 = piStack_24;
      FUN_0094e3b0();
      piStack_44 = piStack_24;
    }
    piStack_40 = (int *)0x18;
    puStack_48 = (undefined4 *)0x953c7c;
    FUN_01674ea0();
  }
  uStack_8 = 7;
  piStack_44 = (int *)0x953c8f;
  piStack_40 = (int *)uStack_18;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17256 ; VA 0x00953cb0 ; FUN_00953cb0 */

void FUN_00953cb0(undefined4 param_1,undefined4 param_2)

{
  FUN_009539d0(param_2);
  return;
}



/* FUNCTION 17257 ; VA 0x00953cc0 ; FUN_00953cc0 */

void __thiscall FUN_00953cc0(undefined4 param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbd31;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
  }
  FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    iVar3 = FUN_005f5170();
    FUN_009539d0(*(undefined4 *)(iVar3 + 0x68));
    param_3 = iVar3 + 0xd8;
    iStack_8 = 0;
    uVar4 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_14 == (undefined4 *)0x0) {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 1;
      puStack_14[2] = FUN_00819150;
      puStack_14[3] = _guard_check_icall;
      puStack_14[4] = 0;
      puStack_14[5] = param_3;
      puStack_14[6] = FUN_00953cb0;
      puStack_14[7] = 0;
      puStack_14[8] = param_1;
      puStack_14[9] = uStack_20;
    }
    FUN_016797d0(puStack_14);
    param_2 = puStack_14;
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    iStack_8._0_1_ = 2;
    FUN_01675290(uVar4);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar2 = FUN_01679300(&param_2);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    if (param_2 != (undefined4 *)0x0) {
      piVar1 = param_2 + 1;
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17258 ; VA 0x00953e30 ; FUN_00953e30 */

/* WARNING: Removing unreachable block (ram,0x009542fb) */
/* WARNING: Removing unreachable block (ram,0x00954305) */

int * __thiscall FUN_00953e30(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint *puVar10;
  undefined4 *puVar11;
  code *pcStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  uint *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbd7f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    cVar4 = FUN_0168a370();
    if (cVar4 != '\0') {
      puStack_20 = (uint *)(param_1 + 0xd9);
      piStack_1c = (int *)((uint)piStack_1c & 0xffffff00);
      FUN_00587410();
      uStack_8 = 0;
      *(undefined *)(param_1 + 0xe3) = 1;
      FUN_00588350();
      uStack_8 = 1;
      if ((char)piStack_1c != '\0') {
        LOCK();
        uVar9 = *puStack_20;
        *puStack_20 = *puStack_20 + 0x80000000;
        UNLOCK();
        if (((uVar9 & 0x40000000) == 0) && (-0x80000000 < (int)uVar9)) {
          LOCK();
          uVar9 = *puStack_20;
          *puStack_20 = *puStack_20 | 0x40000000;
          UNLOCK();
          if ((uVar9 >> 0x1e & 1) == 0) {
            uVar5 = FUN_00554e40();
            SetEvent(uVar5);
          }
        }
      }
      uStack_8 = 0xffffffff;
      piVar6 = (int *)FUN_01689dd0(&piStack_1c);
      piVar7 = (int *)FUN_01689df0(&piStack_18);
      if (*piVar6 == *piVar7) {
        uVar5 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
        uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
        FUN_0054e630(uVar5);
      }
      FUN_0168a200();
    }
    FUN_0094bc70();
    iVar2 = param_1[0xb1];
    if (iVar2 != 0) {
      piVar6 = *(int **)(iVar2 + 0x2c);
      if (piVar6 != (int *)0x0) {
        piStack_24 = *(int **)(iVar2 + 0x30);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
          piStack_24 = *(int **)(iVar2 + 0x30);
          piVar6 = *(int **)(iVar2 + 0x2c);
        }
        puVar8 = (undefined4 *)piVar6[1];
        uStack_8 = 0;
        piStack_1c = piStack_24;
        piStack_28 = piVar6;
        param_1 = piStack_14;
        for (puVar11 = (undefined4 *)*piVar6; piStack_14 = param_1, puVar11 != puVar8;
            puVar11 = puVar11 + 2) {
          piStack_2c = (int *)puVar11[1];
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
            piStack_2c = (int *)puVar11[1];
          }
          piStack_30 = (int *)*puVar11;
          uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          piStack_18 = piStack_2c;
          (**(code **)(*piStack_30 + 0x2c))();
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_18[1] + -1;
            piStack_18[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              iVar2 = piStack_18[2] + -1;
              piStack_18[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
          param_1 = piStack_14;
        }
        uStack_8 = 0xffffffff;
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar2 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            iVar2 = piStack_1c[2] + -1;
            piStack_1c[2] = iVar2;
            UNLOCK();
            param_1 = piStack_14;
            if (iVar2 == 0) {
              (**(code **)(*piStack_1c + 4))();
              param_1 = piStack_14;
            }
          }
        }
      }
      param_1[0xb1] = 0;
      piStack_1c = (int *)param_1[0xb2];
      param_1[0xb2] = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar2 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    FUN_0094d070();
  }
  if (param_1[0x61] != 0) {
    FUN_008a65e0(0,0);
    param_1[0x61] = 0;
    piStack_1c = (int *)param_1[0x62];
    param_1[0x62] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (param_1[100] != 0) {
    param_1[100] = 0;
    piStack_1c = (int *)param_1[0x65];
    param_1[0x65] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar2 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  FUN_008a4210(param_2,param_3);
  if (param_3 == 0) {
    uVar5 = 0;
  }
  else {
    piStack_1c = (int *)FUN_006fb410();
    if (piStack_1c != (int *)0x0) {
      piVar6 = (int *)FUN_00f86660(&piStack_30,param_1);
      iVar2 = *piVar6;
      iVar3 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      param_1[0x61] = iVar2;
      piVar6 = (int *)param_1[0x62];
      param_1[0x62] = iVar3;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar2 = piVar6[2] + -1;
          piVar6[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      piVar6 = piStack_2c;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar2 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar7 = piVar6 + 2;
          iVar2 = *piVar7 + -1;
          *piVar7 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      FUN_008a65e0(piStack_1c,0);
      if (*(char *)(param_1 + 99) != '\0') {
        puVar8 = (undefined4 *)FUN_01674e20(0x28);
        uStack_8 = 5;
        if (puVar8 == (undefined4 *)0x0) {
          puVar8 = (undefined4 *)0x0;
        }
        else {
          puVar8[1] = 1;
          puVar8[2] = 1;
          *puVar8 = std::_Ref_count_obj<class_RBX::ScriptStats>::vftable;
          FUN_00f86490();
        }
        uStack_8 = 0xffffffff;
        param_1[100] = (int)(puVar8 + 3);
        piVar6 = (int *)param_1[0x65];
        param_1[0x65] = (int)puVar8;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar2 = piVar6[1] + -1;
          piVar6[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar2 = piVar6[2] + -1;
            piVar6[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
    }
    piVar6 = param_1 + 0x1e;
    param_2 = 2;
    do {
      FUN_009547a0(piVar6);
      piVar6 = piVar6 + 0x10;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
    pcStack_38 = FUN_0095edc0;
    uStack_34 = 0;
    piStack_30 = param_1;
    puVar8 = (undefined4 *)FUN_009437b0(&pcStack_38);
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      puVar8[1] = puVar8[1] + 1;
      UNLOCK();
    }
    uStack_8 = 6;
    cVar4 = FUN_0168a8f0();
    if (cVar4 == '\0') {
      uVar5 = FUN_005503c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar5);
    }
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      puVar8[1] = puVar8[1] + 1;
      UNLOCK();
    }
    puVar11 = (undefined4 *)param_1[0xd8];
    param_1[0xd8] = (int)puVar8;
    if (puVar11 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puVar11[1] + -1;
      puVar11[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puVar11)(0);
        uVar5 = GetProcessHeap(0,puVar11);
        HeapFree(uVar5);
      }
    }
    if (puVar8 != (undefined4 *)0x0) {
      LOCK();
      iVar2 = puVar8[1] + -1;
      puVar8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*puVar8)(0);
        uVar5 = GetProcessHeap(0,puVar8);
        HeapFree(uVar5);
      }
    }
    uStack_8 = 8;
    FUN_016899e0();
    uStack_8 = 0xffffffff;
    if (DAT_01d5b288 == '\0') {
      cVar4 = FUN_00554b40();
      if (cVar4 == '\0') {
        uVar5 = FUN_009edf00();
        *(undefined4 *)(*(int *)((param_1[0x3d] ^ (uint)(param_1 + 0x3d)) + 0x10) + 0x18) = uVar5;
      }
      else {
        piVar6 = param_1 + 0x1e;
        if (piVar6 != param_1 + 0x3e) {
          puVar10 = (uint *)(param_1 + 0x2d);
          do {
            piVar6 = piVar6 + 0x10;
            uVar9 = *puVar10 ^ (uint)puVar10;
            puVar10 = puVar10 + 0x10;
            *(undefined4 *)(*(int *)(uVar9 + 0x10) + 0x18) = 1;
          } while (piVar6 != param_1 + 0x3e);
          uVar5 = FUN_005f5170();
          goto LAB_0095438d;
        }
      }
    }
    uVar5 = FUN_005f5170();
  }
LAB_0095438d:
  piVar6 = (int *)FUN_0060dcd0(&piStack_28,uVar5);
  iVar2 = *piVar6;
  iVar3 = piVar6[1];
  *piVar6 = 0;
  piVar6[1] = 0;
  param_1[0x5d] = iVar2;
  piVar7 = (int *)param_1[0x5e];
  param_1[0x5e] = iVar3;
  piVar6 = piVar7;
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar2 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      piVar6 = (int *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar6 = (int *)(**(code **)(*piVar7 + 4))();
      }
    }
  }
  piVar7 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar2 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar6 = (int *)(**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar6 = (int *)(**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 17259 ; VA 0x00954450 ; FUN_00954450 */

void FUN_00954450(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbda0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_009d53a0(&uStack_1c,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  FUN_00948fa0(uStack_1c,piStack_18);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = 2;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17260 ; VA 0x00954510 ; FUN_00954510 */

void FUN_00954510(int *param_1,uint param_2)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cbdc0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (*param_1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = *(undefined4 *)(*param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  pcVar3 = (char *)FUN_00881a60(uVar2,0xffffffff);
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar4 = pcVar3;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar4 - (int)(pcVar3 + 1));
  iStack_8._0_1_ = 1;
  if (param_2 != 0) {
    FUN_0054ef60(auStack_28);
    FUN_005e65e0();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  iStack_8 = 2;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17261 ; VA 0x00954610 ; FUN_00954610 */

void FUN_00954610(int *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint in_stack_00000028;
  undefined4 uStack_24;
  int *piStack_20;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbdf0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc4;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  puVar4 = &stack0xffffffc4;
  if (param_2 != 0) {
    if (*param_1 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(undefined4 *)(*param_1 + 8);
    }
    ExceptionList = &pvStack_10;
    uVar5 = FUN_01256300(uVar5);
    if (*param_1 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = *(undefined4 *)(*param_1 + 8);
    }
    FUN_0094c6b0(&uStack_24,uVar6,uVar5);
    piVar3 = piStack_20;
    uVar5 = uStack_24;
    uStack_8._0_1_ = 3;
    if (param_2 == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    (**(code **)((param_2 & 0xfffffffe) + 4))(&stack0x00000010,uVar5,piVar3);
    piVar3 = piStack_20;
    puVar4 = puStack_14;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        puVar4 = puStack_14;
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
          puVar4 = puStack_14;
        }
      }
    }
  }
  puStack_14 = puVar4;
  uStack_8 = 6;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
  }
  uStack_8 = 7;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000028 & 0xfffffffe))(&stack0x00000030,&stack0x00000030,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17262 ; VA 0x00954756 ; Catch@00954756 */

undefined4 Catch_00954756(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 0x2c) != 0) {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
    FUN_0054eff0(uVar1);
    FUN_005e65e0();
  }
  return 0x9546ec;
}



/* FUNCTION 17263 ; VA 0x009547a0 ; FUN_009547a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_009547a0(int param_1,int param_2)

{
  undefined4 uVar1;
  char cVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbe8c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee2ae5 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01259b40(0,0,0);
    FUN_01259a20(0,0,0);
    FUN_01259ac0(0,0,0);
    FUN_01259ba0(0,0,0);
    FUN_01256320(0,0,0);
    FUN_012572d0(0,0,0);
  }
  uVar3 = FUN_01259100(FUN_00952460,0);
  if (uVar3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Failed to create Lua state");
  }
  *(code **)(*(int *)(uVar3 + 0x10) + 0x3b4) = FUN_0095eb40;
  *(code **)(*(int *)(uVar3 + 0x10) + 0x3b8) = FUN_0095ea30;
  puVar4 = (undefined4 *)FUN_01674e20(0x40);
  if (puVar4 == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
    piStack_1c = puVar4;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    piStack_1c = puVar4;
    piStack_14 = (int *)FUN_01674e20(0x10);
    if (piStack_14 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      *piStack_14 = 0;
      piStack_14[1] = 0;
      piStack_14[2] = 0;
      piStack_14[3] = 0;
      piVar5 = piStack_14;
    }
    puVar4[3] = 0;
    puVar4[4] = 0;
    FUN_00941000(piVar5,param_2);
    puVar4[5] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_01255470(0,0,0,0);
    *(undefined *)(puVar4 + 0xc) = 0;
    puVar4[0xd] = 0;
    puVar4[0xe] = 0;
    puVar4[0xf] = 0;
    *(int *)puVar4[3] = *(int *)puVar4[3] + 1;
    FUN_00951290(puVar4);
    puVar8 = puVar4;
  }
  *(undefined4 **)(uVar3 + 0x6c) = puVar8;
  uStack_8 = 0xffffffff;
  *(int *)(puVar8[3] + 4) = param_1;
  puVar8[10] = param_1;
  FUN_0125ad20(uVar3);
  FUN_01257280(uVar3,0xfffffffe);
  iVar6 = FUN_0125b4d0(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_0125e700(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  FUN_01256930(uVar3,&DAT_018bc9b8,0);
  FUN_01256220(uVar3,0xffffffff);
  FUN_00880890(uVar3,0xffffffff);
  FUN_01257280(uVar3,0xfffffffd);
  iVar6 = FUN_00952560(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_0125c1e0(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_00952540(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_00952590(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_0125fa80(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  iVar6 = FUN_0125c8c0(uVar3);
  FUN_01257190(uVar3,0xffffffff,1);
  FUN_01257280(uVar3,-1 - iVar6);
  FUN_01255f00(uVar3,0,0);
  FUN_01257030(uVar3,0xffffd8ee,&DAT_01933e84);
  FUN_00881620(uVar3);
  FUN_008816a0(uVar3);
  FUN_00881720(uVar3);
  FUN_00da4450(uVar3);
  FUN_00880aa0(uVar3);
  FUN_008815a0(uVar3);
  FUN_00d98920(uVar3);
  FUN_00d98d40(uVar3);
  FUN_008814a0(uVar3);
  FUN_00d992d0(uVar3);
  FUN_00d99130(uVar3);
  FUN_00881420(uVar3);
  FUN_00881320(uVar3);
  FUN_00d991d0(uVar3);
  FUN_00d99000(uVar3);
  FUN_00d98c40(uVar3);
  FUN_00d98820(uVar3);
  FUN_00880ca0(uVar3);
  FUN_00d98f70(uVar3);
  FUN_00d98e40(uVar3);
  FUN_00880fa0(uVar3);
  FUN_00880c20(uVar3);
  FUN_00880da0(uVar3);
  FUN_00880b20(uVar3);
  FUN_00880ba0(uVar3);
  FUN_008811a0(uVar3);
  FUN_00880e20(uVar3);
  FUN_00881220(uVar3);
  FUN_00880ea0(uVar3);
  FUN_00881120(uVar3);
  FUN_00881520(uVar3);
  FUN_00880f20(uVar3);
  FUN_008813a0(uVar3);
  FUN_00d98b40(uVar3);
  FUN_008812a0(uVar3);
  FUN_00d98a40(uVar3);
  FUN_00881020(uVar3);
  FUN_008810a0(uVar3);
  FUN_00880d20(uVar3);
  FUN_008817a0(uVar3);
  FUN_008817d0(uVar3);
  FUN_00881800(uVar3);
  FUN_00d994c0(uVar3);
  FUN_00d99760(uVar3);
  FUN_00d99790(uVar3);
  FUN_00d998e0(uVar3);
  FUN_00d99880(uVar3);
  FUN_00d99730(uVar3);
  FUN_00d99670(uVar3);
  FUN_00d998b0(uVar3);
  FUN_00d99850(uVar3);
  FUN_00d99700(uVar3);
  FUN_00d99430(uVar3);
  FUN_00d993a0(uVar3);
  FUN_00d99820(uVar3);
  FUN_00d997f0(uVar3);
  FUN_00d99550(uVar3);
  FUN_00d99370(uVar3);
  FUN_00d99400(uVar3);
  FUN_00da44e0(uVar3);
  FUN_00da4540(uVar3);
  FUN_00d995e0(uVar3);
  FUN_00d99460(uVar3);
  FUN_00d99610(uVar3);
  FUN_00d99490(uVar3);
  FUN_00d995b0(uVar3);
  FUN_00d99580(uVar3);
  FUN_00d997c0(uVar3);
  FUN_00d99520(uVar3);
  FUN_00d996a0(uVar3);
  FUN_00d996d0(uVar3);
  FUN_00d99640(uVar3);
  FUN_00d994f0(uVar3);
  FUN_00d993d0(uVar3);
  FUN_00d890b0(&piStack_14,uVar3);
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = *piStack_14;
    *piStack_14 = *piStack_14 + -1;
    UNLOCK();
    if ((iVar6 == 1) && (piStack_14 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piStack_1c,8);
    }
  }
  iVar6 = param_1;
  if (*(int *)(param_1 + 0x34) != 0) {
    iVar6 = FUN_005c8ac0();
  }
  uVar7 = FUN_0060dcd0(&uStack_18,iVar6);
  uStack_8 = 4;
  FUN_00da3620(uVar3,uVar7);
  uStack_8 = 0xffffffff;
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01257030(uVar3,0xffffd8ee,&DAT_01933e88);
  iVar6 = param_1;
  if (*(int *)(param_1 + 0x34) != 0) {
    iVar6 = FUN_005c8ac0();
  }
  uVar7 = FUN_0060dcd0(&uStack_18,iVar6);
  uStack_8 = 5;
  FUN_00da3620(uVar3,uVar7);
  uStack_8 = 0xffffffff;
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01257030(uVar3,0xffffd8ee,&DAT_018c5f98);
  uVar7 = FUN_005c3ac0(param_1);
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_24,uVar7);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 7;
  FUN_00da3620(uVar3,&uStack_18);
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  piStack_1c = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01257030(uVar3,0xffffd8ee,"workspace");
  uVar7 = FUN_005c3ac0(param_1);
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_24,uVar7);
  uStack_18 = *puVar4;
  piStack_14 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = 9;
  FUN_00da3620(uVar3,&uStack_18);
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  piStack_1c = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar6 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  FUN_01257030(uVar3,0xffffd8ee,"Workspace");
  FUN_01255f00(uVar3,0,0);
  FUN_01257030(uVar3,0xffffd8ee,"shared");
  FUN_01256aa0(uVar3,0xffffd8ee);
  FUN_01258200(uVar3,0,&PTR_s_print_01933cc8);
  FUN_01257280(uVar3,0xfffffffe);
  if (DAT_01d644e0 != '\0') {
    FUN_01255f00(uVar3,0,0);
    FUN_01258200(uVar3,0,&PTR_s_synchronize_01933e34);
    FUN_01257030(uVar3,0xffffd8ee,&DAT_01933ea4);
  }
  if (DAT_01d644a8 != '\0') {
    FUN_01256820(uVar3,FUN_0094c5f0,0,0,0);
    FUN_01257030(uVar3,0xffffd8ee,"crash__");
  }
  if (DAT_01d644b0 != '\0') {
    FUN_01256820(uVar3,FUN_009510e0,0,0,0);
    FUN_01257030(uVar3,0xffffd8ee,"hang__");
  }
  FUN_012561a0(uVar3,0xffffd8ee,"pcall");
  FUN_01257030(uVar3,0xffffd8ee,"ypcall");
  FUN_012561a0(uVar3,0xffffd8ee,"table");
  FUN_012561a0(uVar3,0xffffffff,"unpack");
  FUN_01257030(uVar3,0xffffd8ee,"unpack");
  FUN_01257280(uVar3,0xfffffffe);
  cVar2 = FUN_00ec6a90();
  if (cVar2 != '\0') {
    FUN_01256820(uVar3,FUN_0094cc80,"DebuggerManager",0,0);
    FUN_01257030(uVar3,0xffffd8ee,"DebuggerManager");
  }
  FUN_00d87c10(uVar3);
  LOCK();
  _DAT_01ee2aac = _DAT_01ee2aac + 1;
  UNLOCK();
  if (*(int *)(param_1 + 0x17c) == 0) {
    piStack_1c = (int *)FUN_01674e20(0x14);
    uStack_8 = 10;
    if (piStack_1c == (int *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_00d9e0a0(param_1);
    }
    iVar6 = *(int *)(param_1 + 0x17c);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(param_1 + 0x17c) = uVar7;
    if (iVar6 != 0) {
      FUN_00948ed0(iVar6);
    }
  }
  *(undefined *)(param_1 + 0x181) = 0;
  if (*(int *)(param_1 + 0x340) == 0) {
    uVar7 = FUN_0060dcd0(&uStack_18,param_1);
    uStack_8 = 0xb;
    puVar4 = (undefined4 *)FUN_00943b80(auStack_24,uVar7);
    uVar7 = *puVar4;
    uVar1 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0x340) = uVar7;
    piStack_1c = *(int **)(param_1 + 0x344);
    *(undefined4 *)(param_1 + 0x344) = uVar1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piStack_1c = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_1c = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x344) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(param_1 + 0x344) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0x340),*(undefined4 *)(param_1 + 0x344));
  }
  if (*(int *)(param_1 + 0x348) == 0) {
    uVar7 = FUN_0060dcd0(&uStack_18,param_1);
    uStack_8 = 0xc;
    puVar4 = (undefined4 *)FUN_00943ea0(auStack_24,uVar7);
    uVar7 = *puVar4;
    uVar1 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0x348) = uVar7;
    piStack_1c = *(int **)(param_1 + 0x34c);
    *(undefined4 *)(param_1 + 0x34c) = uVar1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piStack_1c = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_1c = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x34c) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(param_1 + 0x34c) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0x348),*(undefined4 *)(param_1 + 0x34c));
  }
  if ((*(int *)(param_1 + 0x350) == 0) && (DAT_01d644e8 != '\0')) {
    uVar7 = FUN_0060dcd0(&uStack_18,param_1);
    uStack_8 = 0xd;
    puVar4 = (undefined4 *)FUN_00943d10(auStack_24,uVar7);
    uVar7 = *puVar4;
    uVar1 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0x350) = uVar7;
    piStack_1c = *(int **)(param_1 + 0x354);
    *(undefined4 *)(param_1 + 0x354) = uVar1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    if (*(int *)(param_1 + 0x354) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(param_1 + 0x354) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0x350),*(undefined4 *)(param_1 + 0x354));
  }
  if (*(int *)(param_1 + 0x358) == 0) {
    uVar7 = FUN_0060dcd0(&uStack_18,param_1);
    uStack_8 = 0xe;
    puVar4 = (undefined4 *)FUN_009439f0(auStack_24,uVar7);
    uVar7 = *puVar4;
    uVar1 = puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined4 *)(param_1 + 0x358) = uVar7;
    piStack_1c = *(int **)(param_1 + 0x35c);
    *(undefined4 *)(param_1 + 0x35c) = uVar1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piStack_1c = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_1c = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar5 = piStack_1c + 2;
        iVar6 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0x35c) != 0) {
      LOCK();
      piVar5 = (int *)(*(int *)(param_1 + 0x35c) + 4);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0x358),*(undefined4 *)(param_1 + 0x35c));
  }
  uVar3 = param_2 + 0x3cU ^ uVar3;
  *(uint *)(param_2 + 0x3c) = uVar3;
  ExceptionList = pvStack_10;
  return CONCAT31((int3)(uVar3 >> 8),1);
}



/* FUNCTION 17264 ; VA 0x00955470 ; FUN_00955470 */

undefined4 FUN_00955470(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbeb7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01255560();
  cVar4 = FUN_01255580(uVar5,1);
  if (cVar4 == '\0') {
    FUN_01255600(1,"PluginManager()");
  }
  if (param_1 == 0) {
    iVar6 = 0;
  }
  else {
    iVar6 = *(int *)(param_1 + 0x6c);
  }
  iVar6 = *(int *)(*(int *)(iVar6 + 0xc) + 4);
  if (*(int *)(iVar6 + 0x2c4) == 0) {
    piStack_14 = (int *)FUN_01674e20(0x54);
    uStack_8 = 0;
    if (piStack_14 == (int *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00eb6980();
    }
    uStack_8 = 0xffffffff;
    FUN_00941090(uVar5,param_1);
    *(undefined4 *)(iVar6 + 0x2c4) = 0;
    piVar2 = *(int **)(iVar6 + 0x2c8);
    *(undefined4 *)(iVar6 + 0x2c8) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  piStack_14 = *(int **)(iVar6 + 0x2c8);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piStack_14[1] = piStack_14[1] + 1;
    UNLOCK();
    piStack_14 = *(int **)(iVar6 + 0x2c8);
  }
  uStack_18 = *(undefined4 *)(iVar6 + 0x2c4);
  uStack_8 = 1;
  FUN_00da3620(param_1,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_14[1] + -1;
    piStack_14[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17265 ; VA 0x009555e0 ; FUN_009555e0 */

undefined4 __fastcall FUN_009555e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x2a4) - *(int *)(param_1 + 0x2a0) >> 2;
  if (iVar2 == 0) {
    if (DAT_01ee4208 != '\0') {
      FUN_016774b0(DAT_01ee4208,"popProfilerUserActiveRegion - No active resume context.",0);
      return 0;
    }
  }
  else {
    iVar2 = *(int *)(param_1 + 0x2a0) + iVar2 * 4;
    iVar1 = *(int *)(iVar2 + -4);
    if (iVar1 != 0) {
      *(int *)(iVar2 + -4) = iVar1 + -1;
      iVar2 = *(int *)(param_1 + 0x2b0);
      FUN_0152dda0(*(undefined4 *)(iVar2 + -0x10),*(undefined4 *)(iVar2 + -0xc),
                   *(undefined4 *)(iVar2 + -8),*(undefined4 *)(iVar2 + -4));
      *(int *)(param_1 + 0x2b0) = *(int *)(param_1 + 0x2b0) + -0x10;
      return 1;
    }
    if (DAT_01ee4208 != '\0') {
      FUN_016774b0(DAT_01ee4208,
                   "popProfilerUserActiveRegion - No active profile annotation for context.",0);
    }
  }
  return 0;
}



/* FUNCTION 17266 ; VA 0x00955690 ; FUN_00955690 */

void FUN_00955690(undefined4 param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = 0;
  FUN_0094d4b0(param_1,&uStack_8);
  return;
}



/* FUNCTION 17267 ; VA 0x009556b0 ; FUN_009556b0 */

void * FUN_009556b0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  void *pvVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 *******pppppppuVar6;
  uint *puVar7;
  undefined4 uVar8;
  uint *puVar9;
  uint *puVar10;
  undefined4 ******ppppppuVar11;
  uint uVar12;
  int iVar13;
  undefined auStack_114 [160];
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined4 ******appppppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  uint *puStack_44;
  uint *puStack_40;
  undefined4 ******ppppppuStack_38;
  undefined4 *****pppppuStack_34;
  undefined4 *****pppppuStack_30;
  undefined4 *****pppppuStack_2c;
  undefined4 *****pppppuStack_28;
  undefined4 *****pppppuStack_24;
  int iStack_20;
  int *piStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbf13;
  pvStack_10 = ExceptionList;
  pvVar3 = ExceptionList;
  iVar13 = DAT_01ee1708;
  ExceptionList = &pvStack_10;
  if (DAT_01ee1708 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    puStack_14 = (uint *)((uint)puStack_14 & 0xffffff00);
    iVar13 = *piVar2;
    puStack_18 = (uint *)(iVar13 + 0x94);
    pvVar3 = (void *)FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ee1708 == 0) {
      FUN_00911550(&iStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pvVar3 = (void *)FUN_008a65e0(iVar13,0);
      piVar2 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar9 = (uint *)(piStack_1c + 1);
        uVar12 = *puVar9;
        pvVar3 = (void *)*puVar9;
        *puVar9 = uVar12 - 1;
        UNLOCK();
        if (uVar12 - 1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          puVar9 = (uint *)(piVar2 + 2);
          uVar12 = *puVar9;
          pvVar3 = (void *)*puVar9;
          *puVar9 = uVar12 - 1;
          UNLOCK();
          if (uVar12 - 1 == 0) {
            pvVar3 = (void *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    iVar13 = DAT_01ee1708;
    uStack_8 = 2;
    if ((char)puStack_14 != '\0') {
      LOCK();
      pvVar3 = (void *)*puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if ((((uint)pvVar3 & 0x40000000) == 0) && (-0x80000000 < (int)pvVar3)) {
        LOCK();
        uVar12 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar12 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          pvVar3 = (void *)SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (*(char *)(iVar13 + 0x58) == '\0') {
    ExceptionList = pvStack_10;
    return pvVar3;
  }
  FUN_00565940(3,1);
  uStack_8 = 3;
  FUN_00eced00(&puStack_44,param_1,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar13 = (int)puStack_40 - (int)puStack_44 >> 0x1f;
  if (((int)puStack_40 - (int)puStack_44) / 0x70 + iVar13 != iVar13) {
    if (param_2 == 0) {
      FUN_0086edd0(1,"Stack Begin",6);
    }
    else {
      uVar4 = FUN_00558890(auStack_114,"Stack Begin",param_3);
      FUN_00558890(uVar4);
    }
  }
  if (puStack_44 != puStack_40) {
    puVar9 = puStack_44 + 0x1a;
    do {
      uVar12 = puVar9[1];
      if (-1 < (int)uVar12) {
        pppppuStack_28 = (undefined4 ******)0x0;
        pppppuStack_24 = (undefined4 ******)0xf;
        ppppppuStack_38 = (undefined4 ******)((uint)ppppppuStack_38 & 0xffffff00);
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        puStack_14 = puVar9;
        if ((puVar9[-0x13] == 0) || (puVar9[-7] == 0)) {
          puVar7 = puVar9 + -5;
          if (0xf < *puVar9) {
            puVar7 = (uint *)*puVar7;
          }
          pppppppuVar6 = (undefined4 *******)
                         FUN_01675640(appppppuStack_5c,"Script \'%s\', Line %d",puVar7,uVar12);
          if (&ppppppuStack_38 != pppppppuVar6) {
            FUN_005507b0();
            ppppppuStack_38 = *pppppppuVar6;
            pppppuStack_34 = pppppppuVar6[1];
            pppppuStack_30 = pppppppuVar6[2];
            pppppuStack_2c = pppppppuVar6[3];
            pppppuStack_28 = pppppppuVar6[4];
            pppppuStack_24 = pppppppuVar6[5];
            pppppppuVar6[4] = (undefined4 ******)0x0;
            pppppppuVar6[5] = (undefined4 ******)0xf;
            *(undefined *)pppppppuVar6 = 0;
          }
          if (0xf < uStack_48) {
            uVar12 = uStack_48 + 1;
            pppppppuVar6 = (undefined4 *******)appppppuStack_5c[0];
            if (0xfff < uVar12) {
              pppppppuVar6 = (undefined4 *******)appppppuStack_5c[0][-1];
              uVar12 = uStack_48 + 0x24;
              if (0x1f < (uint)((int)appppppuStack_5c[0] + (-4 - (int)pppppppuVar6)))
              goto LAB_00955bb1;
            }
            FUN_01674ea0(pppppppuVar6,uVar12);
          }
        }
        else {
          puVar7 = puVar9 + -0x17;
          if (0xf < puVar9[-0x12]) {
            puVar7 = (uint *)*puVar7;
          }
          puVar5 = puVar9 + -0xb;
          if (0xf < puVar9[-6]) {
            puVar5 = (uint *)*puVar5;
          }
          puVar10 = puVar9 + -5;
          if (0xf < *puVar9) {
            puVar10 = (uint *)*puVar10;
          }
          pppppppuVar6 = (undefined4 *******)
                         FUN_01675640(appppppuStack_5c,"Script \'%s\', Line %d - %s %s",puVar10,
                                      uVar12,puVar5,puVar7);
          if (&ppppppuStack_38 != pppppppuVar6) {
            FUN_005507b0();
            ppppppuStack_38 = *pppppppuVar6;
            pppppuStack_34 = pppppppuVar6[1];
            pppppuStack_30 = pppppppuVar6[2];
            pppppuStack_2c = pppppppuVar6[3];
            pppppuStack_28 = pppppppuVar6[4];
            pppppuStack_24 = pppppppuVar6[5];
            pppppppuVar6[4] = (undefined4 ******)0x0;
            pppppppuVar6[5] = (undefined4 ******)0xf;
            *(undefined *)pppppppuVar6 = 0;
          }
          FUN_005507b0();
        }
        if (param_2 == 0) {
          if (puVar9[-0x1a] == 0) {
            pppppppuVar6 = &ppppppuStack_38;
            if ((undefined4 ******)0xf < pppppuStack_24) {
              pppppppuVar6 = (undefined4 *******)ppppppuStack_38;
            }
            FUN_0086edd0(1,pppppppuVar6,6);
          }
          else {
            uStack_64 = 0;
            uStack_60 = 0xf;
            uStack_74 = uStack_74 & 0xffffff00;
            FUN_005542c0(&DAT_018bc9b8,0);
            uStack_8._0_1_ = 6;
            FUN_009430d0(&iStack_20,puVar9 + -0x1a);
            uStack_8._0_1_ = 7;
            if (iStack_20 != 0) {
              uVar4 = FUN_008ed2c0(iStack_20);
              uVar12 = puVar9[1];
              uVar8 = FUN_00ae6180();
              puVar9 = (uint *)FUN_00d10cd0(appppppuStack_5c,uVar8,uVar12,uVar4);
              if (&uStack_74 != puVar9) {
                FUN_005507b0();
                uStack_74 = *puVar9;
                uStack_70 = puVar9[1];
                uStack_6c = puVar9[2];
                uStack_68 = puVar9[3];
                uStack_64 = puVar9[4];
                uStack_60 = puVar9[5];
                puVar9[4] = 0;
                puVar9[5] = 0xf;
                *(undefined *)puVar9 = 0;
              }
              FUN_005507b0();
              puVar9 = puStack_14;
            }
            piVar2 = piStack_1c;
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar13 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar13;
              UNLOCK();
              if (iVar13 == 0) {
                (**(code **)*piStack_1c)();
                LOCK();
                piVar1 = piVar2 + 2;
                iVar13 = *piVar1 + -1;
                *piVar1 = iVar13;
                UNLOCK();
                if (iVar13 == 0) {
                  (**(code **)(*piVar2 + 4))();
                }
              }
            }
            FUN_0086f010(1,&ppppppuStack_38,&uStack_74,6);
            FUN_005507b0();
          }
        }
        else {
          pppppppuVar6 = &ppppppuStack_38;
          if ((undefined4 ******)0xf < pppppuStack_24) {
            pppppppuVar6 = (undefined4 *******)ppppppuStack_38;
          }
          uVar4 = FUN_0055b3b0(auStack_114,pppppppuVar6,pppppuStack_28,param_3);
          FUN_00558890(uVar4);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        if ((undefined4 ******)0xf < pppppuStack_24) {
          ppppppuVar11 = (undefined4 ******)((int)pppppuStack_24 + 1);
          pppppppuVar6 = (undefined4 *******)ppppppuStack_38;
          if ((undefined4 ******)0xfff < ppppppuVar11) {
            pppppppuVar6 = (undefined4 *******)ppppppuStack_38[-1];
            ppppppuVar11 = (undefined4 ******)(pppppuStack_24 + 9);
            if (0x1f < (uint)((int)ppppppuStack_38 + (-4 - (int)pppppppuVar6))) goto LAB_00955bb1;
          }
          FUN_01674ea0(pppppppuVar6,ppppppuVar11);
        }
      }
      puStack_14 = puVar9 + 0x1c;
      puVar7 = puVar9 + 2;
      puVar9 = puStack_14;
    } while (puVar7 != puStack_40);
  }
  iVar13 = (int)puStack_40 - (int)puStack_44 >> 0x1f;
  if (((int)puStack_40 - (int)puStack_44) / 0x70 + iVar13 != iVar13) {
    if (param_2 == 0) {
      FUN_0086edd0(1,"Stack End",6);
      goto LAB_00955b8e;
    }
    FUN_00558890(auStack_114,"Stack End");
  }
  if (param_2 != 0) {
    FUN_0058c420(appppppuStack_5c);
    pppppppuVar6 = appppppuStack_5c;
    if (0xf < uStack_48) {
      pppppppuVar6 = (undefined4 *******)appppppuStack_5c[0];
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_00554150(pppppppuVar6,uStack_4c);
    if (0xf < uStack_48) {
      uVar12 = uStack_48 + 1;
      pppppppuVar6 = (undefined4 *******)appppppuStack_5c[0];
      if (0xfff < uVar12) {
        pppppppuVar6 = (undefined4 *******)appppppuStack_5c[0][-1];
        uVar12 = uStack_48 + 0x24;
        if (0x1f < (uint)((int)appppppuStack_5c[0] + (-4 - (int)pppppppuVar6))) {
LAB_00955bb1:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar6,uVar12);
    }
  }
LAB_00955b8e:
  FUN_00946d50();
  pvVar3 = (void *)FUN_005705c0();
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 17268 ; VA 0x00955bc0 ; FUN_00955bc0 */

int FUN_00955bc0(undefined4 *param_1)

{
  uint uVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 ****ppppuVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  uint in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined auStack_44 [24];
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar12 = in_stack_00000014;
  puStack_c = &LAB_017cbf40;
  pvStack_10 = ExceptionList;
  puVar6 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar6 = param_1;
  }
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (in_stack_00000014 == 0) {
LAB_00955cfb:
    iVar4 = FUN_0086ed30(3,&param_1,6);
  }
  else {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_0170db20(puVar6,0x3a,in_stack_00000014);
    if ((iVar4 == 0) || (iVar4 = iVar4 - (int)puVar6, iVar4 == -1)) goto LAB_00955cfb;
    uVar1 = iVar4 + 1;
    puStack_14 = &param_1;
    if (0xf < in_stack_00000018) {
      puStack_14 = param_1;
    }
    if (uVar12 <= uVar1) goto LAB_00955cfb;
    iVar5 = FUN_0170db20((int)puStack_14 + uVar1,0x3a,uVar12 - uVar1);
    if ((iVar5 == 0) || (iVar5 - (int)puStack_14 == -1)) goto LAB_00955cfb;
    uStack_1c = 0;
    uStack_18 = 0xf;
    apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
    if (uVar12 < uVar1) {
      FUN_00554050();
      goto LAB_00955d8b;
    }
    uVar11 = ((iVar5 - (int)puStack_14) - iVar4) - 1;
    if (uVar12 - uVar1 < uVar11) {
      uVar11 = uVar12 - uVar1;
    }
    puVar6 = &param_1;
    if (0xf < in_stack_00000018) {
      puVar6 = param_1;
    }
    FUN_005542c0((int)puVar6 + uVar1,uVar11);
    uStack_8._0_1_ = 2;
    ppppuVar7 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar7 = (undefined4 ****)apppuStack_2c[0];
    }
    uVar8 = FUN_01717832(ppppuVar7);
    uVar9 = FUN_008ed2c0(in_stack_0000001c);
    uVar10 = FUN_00ae6180();
    FUN_00d10cd0(auStack_44,uVar10,uVar8,uVar9);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_0086f010(3,&param_1,auStack_44,6);
    FUN_005507b0();
    iVar4 = FUN_005507b0();
  }
  if (0xf < in_stack_00000018) {
    uVar12 = in_stack_00000018 + 1;
    puVar6 = param_1;
    if (0xfff < uVar12) {
      puVar6 = (undefined4 *)param_1[-1];
      uVar12 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar6))) {
LAB_00955d8b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(puVar6,uVar12);
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000020 + 1;
    iVar5 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17269 ; VA 0x00955da0 ; FUN_00955da0 */

void FUN_00955da0(undefined4 param_1,int param_2,undefined4 *param_3)

{
  uint *puVar1;
  undefined4 uVar2;
  uint *puVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined4 uVar10;
  undefined auStack_e8 [24];
  int iStack_d0;
  int *piStack_cc;
  uint uStack_c8;
  uint auStack_c4 [6];
  uint auStack_ac [6];
  uint auStack_94 [6];
  uint auStack_7c [6];
  int *piStack_64;
  int aiStack_60 [5];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  undefined8 uStack_38;
  int *piStack_30;
  int *piStack_2c;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbf96;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00eced00(&piStack_30,param_2,0);
  iStack_8 = 0;
  if (piStack_30 != piStack_2c) {
    FUN_00945900();
    iStack_8._0_1_ = 1;
    if (piStack_30 != piStack_2c) {
      puVar3 = (uint *)(piStack_30 + 8);
      piVar9 = piStack_30;
      do {
        piVar6 = (int *)puVar3[-7];
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
          piVar6 = (int *)puVar3[-7];
        }
        iStack_d0 = *piVar9;
        piStack_14 = piStack_cc;
        if (piStack_cc != (int *)0x0) {
          LOCK();
          iVar4 = piStack_cc[1] + -1;
          piStack_cc[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            puVar5 = (undefined4 *)*piStack_cc;
            piStack_cc = piVar6;
            (*(code *)*puVar5)();
            LOCK();
            iVar4 = piStack_14[2] + -1;
            piStack_14[2] = iVar4;
            UNLOCK();
            piVar6 = piStack_cc;
            if (iVar4 == 0) {
              (**(code **)(*piStack_14 + 4))();
              piVar6 = piStack_cc;
            }
          }
        }
        piStack_cc = piVar6;
        uStack_c8 = puVar3[-6];
        if (auStack_c4 != puVar3 + -5) {
          puVar1 = puVar3 + -5;
          if (0xf < *puVar3) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar3[-1]);
        }
        puVar1 = puVar3 + 1;
        if (auStack_ac != puVar1) {
          if (0xf < puVar3[6]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar3[5]);
        }
        puVar1 = puVar3 + 7;
        if (auStack_94 != puVar1) {
          if (0xf < puVar3[0xc]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar3[0xb]);
        }
        puVar1 = puVar3 + 0xd;
        if (auStack_7c != puVar1) {
          if (0xf < puVar3[0x12]) {
            puVar1 = (uint *)*puVar1;
          }
          FUN_005542c0(puVar1,puVar3[0x11]);
        }
        piStack_64 = (int *)puVar3[0x13];
        piStack_14 = piStack_64;
        if (0 < (int)piStack_64) {
          if ((piVar9 != piStack_2c) && (iStack_d0 != 0)) {
            uStack_38 = 0xf00000000;
            uStack_48 = uStack_48 & 0xffffff00;
            FUN_005542c0(&DAT_018bc9b8,0);
            iStack_8._0_1_ = 2;
            FUN_009430d0(&iStack_20,&iStack_d0);
            iStack_8 = CONCAT31(iStack_8._1_3_,3);
            uStack_24 = FUN_008ed2c0(iStack_20);
            piVar9 = piStack_14;
            if (iStack_20 != 0) {
              uVar10 = FUN_00ae6180(piStack_14,uStack_24);
              puVar3 = (uint *)FUN_00d10cd0(aiStack_60,uVar10);
              if (&uStack_48 != puVar3) {
                FUN_005507b0();
                uStack_48 = *puVar3;
                uStack_44 = puVar3[1];
                uStack_40 = puVar3[2];
                uStack_3c = puVar3[3];
                uStack_38 = *(undefined8 *)(puVar3 + 4);
                puVar3[4] = 0;
                puVar3[5] = 0xf;
                *(undefined *)puVar3 = 0;
              }
              if (0xf < uStack_4c) {
                uVar7 = uStack_4c + 1;
                iVar4 = aiStack_60[0];
                if (0xfff < uVar7) {
                  iVar4 = *(int *)(aiStack_60[0] + -4);
                  uVar7 = uStack_4c + 0x24;
                  if (0x1f < (aiStack_60[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(iVar4,uVar7);
              }
            }
            if (((DAT_01d644c0 != '\0') && (iVar4 = FUN_008f7870(iStack_20), iVar4 != 0)) &&
               (iVar4 = FUN_00635890(), iVar4 != 0)) {
              if (piStack_1c != (int *)0x0) {
                LOCK();
                piStack_1c[1] = piStack_1c[1] + 1;
                UNLOCK();
              }
              iStack_18 = iStack_20;
              piStack_14 = piStack_1c;
              iStack_8._0_1_ = 4;
              puVar5 = (undefined4 *)FUN_00b76e60(auStack_e8,&iStack_18);
              iStack_8._0_1_ = 5;
              if (0xf < (uint)puVar5[5]) {
                puVar5 = (undefined4 *)*puVar5;
              }
              uVar10 = FUN_01675640(aiStack_60,"%s:%i",puVar5,piVar9);
              FUN_005511f0(uVar10);
              FUN_005507b0();
              FUN_005507b0();
              iStack_8 = CONCAT31(iStack_8._1_3_,3);
              FUN_00550b30();
            }
            FUN_00637260(param_1);
            uVar10 = FUN_0094c0f0(aiStack_60);
            iStack_8 = CONCAT31(iStack_8._1_3_,6);
            FUN_0086f010(*param_3,uVar10,&uStack_48,uStack_24);
            if (0xf < uStack_4c) {
              uVar7 = uStack_4c + 1;
              iVar4 = aiStack_60[0];
              if (0xfff < uVar7) {
                iVar4 = *(int *)(aiStack_60[0] + -4);
                uVar7 = uStack_4c + 0x24;
                if (0x1f < (aiStack_60[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(iVar4,uVar7);
            }
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar4 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                (**(code **)*piStack_1c)();
                LOCK();
                piVar9 = piStack_1c + 2;
                iVar4 = *piVar9;
                *piVar9 = *piVar9 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                  (**(code **)(*piStack_1c + 4))();
                }
              }
            }
            if (0xf < uStack_38._4_4_) {
              uVar8 = uStack_38._4_4_ + 1;
              uVar7 = uStack_48;
              if (0xfff < uVar8) {
                uVar7 = *(uint *)(uStack_48 - 4);
                uVar8 = uStack_38._4_4_ + 0x24;
                if (0x1f < (uStack_48 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(uVar7,uVar8);
            }
            uStack_38 = 0xf00000000;
            uStack_48 = uStack_48 & 0xffffff00;
            FUN_00946f60();
            goto LAB_0095620a;
          }
          break;
        }
        piVar9 = piVar9 + 0x1c;
        puVar3 = puVar3 + 0x1c;
      } while (piVar9 != piStack_2c);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00946f60();
  }
  uVar10 = 6;
  if ((param_2 != 0) && (*(int *)(param_2 + 0x6c) != 0)) {
    uVar10 = FUN_008ed2c0(*(undefined4 *)(*(int *)(*(int *)(param_2 + 0x6c) + 0xc) + 4));
  }
  FUN_00637260(param_1);
  uVar2 = FUN_0094c0f0(aiStack_60);
  iStack_8 = CONCAT31(iStack_8._1_3_,7);
  FUN_0086ed30(*param_3,uVar2,uVar10);
  if (0xf < uStack_4c) {
    uVar7 = uStack_4c + 1;
    iVar4 = aiStack_60[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_60[0] + -4);
      uVar7 = uStack_4c + 0x24;
      if (0x1f < (aiStack_60[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
LAB_0095620a:
  FUN_00946d50();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17270 ; VA 0x00956240 ; FUN_00956240 */

undefined4 FUN_00956240(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  
  piVar1 = (int *)FUN_01255560();
  iVar4 = *piVar1;
  iVar6 = piVar1[1];
  iVar7 = piVar1[2];
  iVar8 = piVar1[3];
  uVar9 = *(undefined8 *)(piVar1 + 4);
  iVar2 = FUN_01256300(param_1);
  iVar5 = iVar4;
  if (iVar2 < 1) {
    FUN_0086f2f0(0,"Current identity is %d",iVar4);
  }
  else {
    uVar3 = FUN_01257440(param_1,0xffffffff,0);
    FUN_0086f2f0(0,"%s %d",uVar3);
  }
  if (iVar4 == 5) {
    if (iVar7 != 0 || iVar8 != 0) {
      FUN_0086f2f0(0,"Current asset id is %lld",iVar7,iVar8,iVar5,iVar6,iVar7,iVar8,uVar9);
    }
  }
  return 0;
}



/* FUNCTION 17271 ; VA 0x009562d0 ; FUN_009562d0 */

void __thiscall FUN_009562d0(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a4d58;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar6 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar6 & 1) != 0);
  } while (uStack_8 != 0);
  uVar6 = *(uint *)(param_1 + 8);
  if (uVar6 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_00716150(1);
    uVar6 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar6 - 1;
  iVar2 = (*(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U) * 4;
  iVar7 = *(int *)(param_1 + 4);
  if (*(int *)(iVar7 + iVar2) == 0) {
    uVar5 = FUN_01674e20(0xc);
    *(undefined4 *)(iVar2 + *(int *)(param_1 + 4)) = uVar5;
    iVar7 = *(int *)(param_1 + 4);
  }
  puVar3 = *(undefined4 **)(iVar2 + iVar7);
  piVar4 = (int *)*param_2;
  *puVar3 = piVar4;
  if (piVar4 != (int *)0x0) {
    LOCK();
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  puVar3[1] = 0;
  puVar3[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar4 = (int *)(param_2[2] + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  puVar3[1] = param_2[1];
  puVar3[2] = param_2[2];
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17272 ; VA 0x009563b0 ; FUN_009563b0 */

void __thiscall FUN_009563b0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined8 uVar6;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_18;
  int iStack_14;
  
  iVar2 = *(int *)(param_1 + 0x2a4) - *(int *)(param_1 + 0x2a0) >> 2;
  if (iVar2 == 0) {
    if (DAT_01ee4208 != '\0') {
      FUN_016774b0(DAT_01ee4208,
                   "pushProfilerActiveRegionForResumeContext - No active resume context.",0);
      return;
    }
  }
  else {
    piVar4 = (int *)(*(int *)(param_1 + 0x2a0) + -4 + iVar2 * 4);
    *piVar4 = *piVar4 + 1;
    iVar2 = param_1 + 0x31d + (uint)*(byte *)(param_1 + 0x31c);
    uVar3 = FUN_005702d0(param_2);
    FUN_00562fc0(&iStack_18,uVar3,param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
    if (iStack_18 == 0) {
      iVar2 = *(int *)(param_1 + 700) - *(int *)(param_1 + 0x2b8) >> 3;
      if (iVar2 == 0) {
        iStack_18 = *(int *)(param_1 + 0x338);
        iStack_14 = *(int *)(param_1 + 0x33c);
      }
      else {
        if (iVar2 == 1) {
          FUN_0086f2f0(2,
                       "debug.profilebegin() - Out of available annotation tokens. Averages in the profiler may not be correct."
                      );
        }
        iStack_28 = -2;
        iStack_24 = 0x7fffffff;
        uVar3 = FUN_0056a9c0(0);
        FUN_005672c0(uVar3,&iStack_28);
        piVar4 = (int *)(*(int *)(param_1 + 700) + -8);
        iVar2 = *piVar4;
        iVar1 = *(int *)(*(int *)(param_1 + 700) + -4);
        *(int **)(param_1 + 700) = piVar4;
        iStack_18 = iVar2;
        iStack_14 = iVar1;
        iVar5 = FUN_00947bf0(param_2);
        *(int *)(iVar5 + 0x18) = iVar2;
        *(int *)(iVar5 + 0x1c) = iVar1;
        *(undefined4 *)(iVar5 + 0x20) = uStack_48;
        *(undefined4 *)(iVar5 + 0x24) = uStack_44;
      }
    }
    else {
      iVar2 = FUN_00947bf0(param_2);
      iStack_18 = *(int *)(iVar2 + 0x18);
      iStack_14 = *(int *)(iVar2 + 0x1c);
    }
    uVar6 = FUN_0152d930(iStack_18,iStack_14);
    iStack_30 = iStack_18;
    iVar2 = (int)((ulonglong)uVar6 >> 0x20);
    iStack_24 = (int)uVar6;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0152d740(iStack_18,iStack_14,param_2);
    iStack_28 = iStack_24;
    iStack_2c = iStack_14;
    piVar4 = *(int **)(param_1 + 0x2b0);
    if (*(int **)(param_1 + 0x2b4) != piVar4) {
      *piVar4 = iStack_30;
      piVar4[1] = iStack_14;
      piVar4[2] = iStack_24;
      piVar4[3] = iVar2;
      *(int *)(param_1 + 0x2b0) = *(int *)(param_1 + 0x2b0) + 0x10;
      return;
    }
    iStack_24 = iVar2;
    FUN_0093f600(piVar4,&iStack_30);
  }
  return;
}



/* FUNCTION 17273 ; VA 0x00956580 ; FUN_00956580 */

void __thiscall FUN_00956580(int param_1,int *param_2,undefined8 param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbfb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_016dee6d();
  if (iVar1 != 0) {
    FUN_016df3c9();
  }
  uStack_8._0_1_ = 1;
  if (*(int *)(param_1 + 0x17c) != 0) {
    if (param_2 == (int *)0x0) {
      iVar1 = 0;
    }
    else {
      iVar1 = param_2[2];
    }
    FUN_00d9e200(iVar1,param_3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar1 = FUN_016deec8();
  if (iVar1 != 0) {
    FUN_016df3c9();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17274 ; VA 0x00956650 ; FUN_00956650 */

undefined4 FUN_00956650(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_01682800();
  FUN_012569a0(param_1,*puVar1);
  return 1;
}



/* FUNCTION 17275 ; VA 0x00956680 ; FUN_00956680 */

undefined4 *
FUN_00956680(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cbfd9;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_18 = 1;
  uStack_8 = 1;
  uStack_1c = 0;
  puVar4 = (undefined4 *)FUN_009567b0(aiStack_38,param_2,param_3,&uStack_1c,param_4);
  if (param_1 != puVar4) {
    FUN_005507b0();
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *param_1 = *puVar4;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    iVar5 = aiStack_38[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_38[0] + -4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17276 ; VA 0x0095675b ; Catch@0095675b */

undefined * Catch_0095675b(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  uVar1 = FUN_01675640(unaff_EBP + -0x34,&DAT_01934808,uVar1);
  FUN_005511f0(uVar1);
  FUN_005507b0();
  return &DAT_0095678e;
}



/* FUNCTION 17277 ; VA 0x009567b0 ; FUN_009567b0 */

void FUN_009567b0(uint *param_1,undefined4 param_2,int param_3,int *param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  float *pfVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  undefined4 *puVar7;
  int iVar8;
  char *pcVar9;
  char *pcVar10;
  float10 fVar11;
  undefined *puVar12;
  undefined8 uVar13;
  int aiStack_178 [52];
  undefined auStack_a8 [24];
  undefined auStack_90 [24];
  undefined4 uStack_78;
  int iStack_74;
  undefined auStack_70 [16];
  int iStack_60;
  undefined4 uStack_5c;
  undefined4 ***pppuStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 ***apppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cc05f;
  pvStack_10 = ExceptionList;
  uStack_78 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300();
  if (iVar2 < param_3) {
LAB_00956803:
    uVar13 = 0x1e0193480c;
    goto LAB_00956d5b;
  }
  uVar3 = FUN_012578b0(param_2,param_3);
  switch(uVar3) {
  case 1:
    iVar2 = FUN_01257360(param_2,param_3);
    pcVar10 = "true";
    if (iVar2 == 0) {
      pcVar10 = "false";
    }
    pcVar9 = pcVar10;
    do {
      cVar1 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar1 != '\0');
    uVar13 = CONCAT44((int)pcVar9 - (int)(pcVar10 + 1),pcVar10);
    break;
  default:
    uVar3 = FUN_012578b0(param_2,param_3);
    pcVar9 = (char *)FUN_012578f0(param_2,uVar3);
    pcVar10 = pcVar9;
    do {
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 != '\0');
    uVar13 = CONCAT44((int)pcVar10 - (int)(pcVar9 + 1),pcVar9);
    break;
  case 3:
    fVar11 = (float10)FUN_01257500();
    FUN_01675640(&pppuStack_58,"%.14g",(double)fVar11);
    goto LAB_0095684a;
  case 4:
    pfVar4 = (float *)FUN_01257860(param_2,1);
    FUN_01675640(&pppuStack_58,"%.14g, %.14g, %.14g",(double)*pfVar4,(double)pfVar4[1],
                 (double)pfVar4[2]);
LAB_0095684a:
    FUN_005511f0();
    FUN_005507b0();
    goto LAB_00956d63;
  case 5:
    uVar3 = FUN_01257440();
    FUN_00565770(uVar3,param_3);
    iStack_8._0_1_ = 1;
    puVar5 = (undefined4 *)FUN_00585d40();
    pppuStack_58 = (undefined4 ***)*puVar5;
    uStack_54 = puVar5[1];
    uStack_50 = puVar5[2];
    uStack_4c = puVar5[3];
    uStack_48 = *(undefined8 *)(puVar5 + 4);
    puVar5[4] = 0;
    puVar5[5] = 0xf;
    *(undefined *)puVar5 = 0;
    iStack_8 = CONCAT31(iStack_8._1_3_,2);
    FUN_00558c80();
    FUN_005511f0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    goto LAB_00956d63;
  case 6:
    iStack_74 = FUN_01257580(param_2,param_3);
    if (iStack_74 != 0) {
      FUN_01675640();
      FUN_005511f0();
      FUN_005507b0();
      if (param_5 != (int *)0x0) {
        if ((uint)((param_5[1] - *param_5 >> 3) * 3) >> 2 <= (uint)param_5[3]) {
          FUN_00958880();
        }
        iVar2 = FUN_00620bc0();
        if (*(char *)(iVar2 + 4) != '\0') goto LAB_00956d63;
        *(undefined *)(iVar2 + 4) = 1;
      }
      iVar2 = FUN_01255e10(param_2,2);
      if (iVar2 != 0) {
        FUN_00554150(&DAT_01934854,3);
        if (param_3 < 1) {
          FUN_01256300();
        }
        FUN_01256980();
        iVar2 = FUN_01256670();
        if (iVar2 == 0) {
LAB_00956b86:
          FUN_00554150(&DAT_0193486c,1);
        }
        else {
          do {
            uStack_30 = 0;
            uStack_2c = 0xf;
            apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
            iStack_8 = CONCAT31(iStack_8._1_3_,3);
            iVar2 = FUN_012578b0(param_2,0xfffffffe);
            if (iVar2 == 6) {
              uVar3 = FUN_012578b0(param_2,0xfffffffe);
              FUN_012578f0(param_2,uVar3);
              FUN_00551260();
            }
            else {
              FUN_009567b0();
              FUN_005511f0();
              FUN_005507b0();
            }
            ppppuVar6 = apppuStack_40;
            if (0xf < uStack_2c) {
              ppppuVar6 = (undefined4 ****)apppuStack_40[0];
            }
            FUN_00554150(ppppuVar6,uStack_30);
            FUN_00554150(&DAT_01934858,3);
            puVar7 = (undefined4 *)FUN_009567b0();
            puVar5 = puVar7 + 4;
            iStack_8._0_1_ = 4;
            if (0xf < (uint)puVar7[5]) {
              puVar7 = (undefined4 *)*puVar7;
            }
            FUN_00554150(puVar7,*puVar5);
            iStack_8._0_1_ = 3;
            FUN_005507b0();
            FUN_00554150(&DAT_018c5308,2);
            iVar2 = FUN_012578b0(param_2);
            if (iVar2 != 6) {
              *param_4 = *param_4 + 1;
            }
            if (DAT_01d643f4 <= *param_4) {
              FUN_00554150("*truncated,\n",0xc);
              FUN_01257280(param_2,0xfffffffd);
              iStack_8 = (uint)iStack_8._1_3_ << 8;
              FUN_005507b0();
              goto LAB_00956b86;
            }
            FUN_01257280(param_2);
            iStack_8 = (uint)iStack_8._1_3_ << 8;
            FUN_005507b0();
            iVar2 = FUN_01256670();
          } while (iVar2 != 0);
          FUN_00554150(&DAT_0193486c,1);
        }
      }
      goto LAB_00956d63;
    }
    goto LAB_00956803;
  case 8:
    aiStack_178[0] = FUN_00888530();
    aiStack_178[1] = 0;
    iStack_8._0_1_ = 5;
    uVar3 = FUN_012578b0(param_2,param_3);
    FUN_012578f0(param_2,uVar3);
    FUN_0054eff0();
    iStack_8._0_1_ = 6;
    cVar1 = FUN_009d34f0();
    if (cVar1 != '\0') {
      FUN_0054eff0();
      iStack_8._0_1_ = 7;
      if (iStack_60 != 0) {
        FUN_00551230();
      }
      FUN_005507b0();
    }
    iVar2 = aiStack_178[0];
    iStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = 0;
    iStack_8 = CONCAT31(iStack_8._1_3_,8);
    iVar8 = FUN_00888530();
    if (iVar2 == iVar8) {
      FUN_005542c0("*unrecognized userdata",0x16);
    }
    else {
      FUN_00956e50(apppuStack_40,aiStack_178);
      FUN_005511f0();
      FUN_005507b0();
    }
    uVar13 = uStack_48;
    iStack_8._0_1_ = 9;
    uStack_30 = 0;
    uStack_2c = 0xf;
    apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
    uStack_78 = 4;
    FUN_0058a190();
    FUN_00554150(&DAT_018c3500,1);
    ppppuVar6 = &pppuStack_58;
    if (0xf < uStack_48._4_4_) {
      ppppuVar6 = (undefined4 ****)pppuStack_58;
    }
    FUN_00554150(ppppuVar6,(int)uVar13);
    uVar13 = CONCAT44(&DAT_01934888,apppuStack_40);
    puVar12 = auStack_a8;
    uVar3 = FUN_00558c80();
    iStack_8 = CONCAT31(iStack_8._1_3_,10);
    FUN_00558c20(auStack_90,uVar3,auStack_70,puVar12,uVar13);
    FUN_005511f0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_0056e5b0();
    goto LAB_00956d63;
  }
LAB_00956d5b:
  FUN_005542c0(uVar13);
LAB_00956d63:
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = uStack_28;
  param_1[1] = uStack_24;
  param_1[2] = uStack_20;
  param_1[3] = uStack_1c;
  *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_14,uStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17278 ; VA 0x00956dc0 ; FUN_00956dc0 */

undefined4 * FUN_00956dc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar6 = (undefined4 *)FUN_0094c6b0(auStack_c,param_2,param_3);
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  *param_1 = uVar3;
  piVar5 = (int *)param_1[1];
  param_1[1] = uVar4;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    param_1 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      param_1 = (undefined4 *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_1 = (undefined4 *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_8 + 1;
    iVar2 = *piVar5;
    param_1 = (undefined4 *)*piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (undefined4 *)(**(code **)*piStack_8)();
      LOCK();
      piVar5 = piStack_8 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (undefined4 *)(**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17279 ; VA 0x00956e50 ; FUN_00956e50 */

undefined * FUN_00956e50(undefined *param_1,int *param_2)

{
  undefined8 uVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined4 *puVar6;
  uint *puVar7;
  int *piVar8;
  int iVar9;
  int *piVar10;
  char *pcVar11;
  undefined4 uVar12;
  undefined auStack_1fc [200];
  undefined auStack_134 [8];
  int iStack_12c;
  int iStack_128;
  int iStack_124;
  int iStack_120;
  int iStack_11c;
  undefined4 *puStack_118;
  undefined auStack_114 [200];
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined2 uStack_18;
  undefined2 uStack_16;
  undefined2 uStack_14;
  undefined2 uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc1a8;
  pvStack_10 = ExceptionList;
  piVar10 = (int *)*param_2;
  ExceptionList = &pvStack_10;
  switch(piVar10[7]) {
  case 0:
    uVar12 = 3;
    pcVar11 = "nil";
    ExceptionList = &pvStack_10;
    break;
  case 8:
    ExceptionList = &pvStack_10;
    FUN_008c03c0(&uStack_18);
    uStack_8 = 0;
    FUN_0054ef60(*(undefined4 *)(CONCAT22(uStack_16,uStack_18) + 0x28));
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  case 10:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d370();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d370();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = (uint *)(piVar2 + 2);
      if (piVar2[1] == 0) {
        puVar7 = (uint *)0x0;
      }
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x12;
      puStack_118 = puVar6;
      puVar7 = (uint *)FUN_0088aec0();
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_8 = 0x13;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d861e0(param_1,&uStack_28);
    ExceptionList = pvStack_10;
    return param_1;
  case 0xb:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d730();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d730();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uStack_18 = (undefined2)*piVar10;
      uStack_16 = (undefined2)((uint)*piVar10 >> 0x10);
      uStack_14 = (undefined2)piVar10[1];
      uStack_12 = (undefined2)((uint)piVar10[1] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x10;
      puStack_118 = puVar6;
      puVar6 = (undefined4 *)FUN_0088b680();
      uStack_18 = (undefined2)*puVar6;
      uStack_16 = (undefined2)((uint)*puVar6 >> 0x10);
      uStack_14 = (undefined2)puVar6[1];
      uStack_12 = (undefined2)((uint)puVar6[1] >> 0x10);
      uStack_8 = 0x11;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d86910(param_1,&uStack_18);
    ExceptionList = pvStack_10;
    return param_1;
  case 0xc:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d870();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d870();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uVar1 = *(undefined8 *)piVar10;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[2];
      uStack_12 = (undefined2)((uint)piVar10[2] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0xc;
      puStack_118 = puVar6;
      puVar5 = (undefined8 *)FUN_0088b880();
      uVar1 = *puVar5;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)*(undefined4 *)(puVar5 + 1);
      uStack_12 = (undefined2)((uint)*(undefined4 *)(puVar5 + 1) >> 0x10);
      uStack_8 = 0xd;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d86ac0(param_1,&uStack_1c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0xd:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d7d0();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d7d0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      param_2 = piVar2 + 2;
      if (piVar2[1] == 0) {
        param_2 = (int *)0x0;
      }
      param_2 = (int *)*param_2;
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 10;
      puStack_118 = puVar6;
      param_2 = (int *)FUN_0088b790();
      param_2 = (int *)*param_2;
      uStack_8 = 0xb;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d869e0(param_1,&param_2);
    ExceptionList = pvStack_10;
    return param_1;
  case 0xe:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d910();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d910();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uStack_16 = (undefined2)*piVar10;
      uStack_14 = (undefined2)((uint)*piVar10 >> 0x10);
      uStack_12 = *(undefined2 *)(piVar10 + 1);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 8;
      puStack_118 = puVar6;
      puVar6 = (undefined4 *)FUN_0088b990();
      uStack_16 = (undefined2)*puVar6;
      uStack_14 = (undefined2)((uint)*puVar6 >> 0x10);
      uStack_12 = *(undefined2 *)(puVar6 + 1);
      uStack_8 = 9;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d86c00(param_1,&uStack_16);
    ExceptionList = pvStack_10;
    return param_1;
  case 0xf:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d410();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d410();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      puStack_20 = (undefined4 *)*piVar10;
      uStack_1c = piVar10[1];
      uStack_18 = (undefined2)piVar10[2];
      uStack_16 = (undefined2)((uint)piVar10[2] >> 0x10);
      uStack_14 = (undefined2)piVar10[3];
      uStack_12 = (undefined2)((uint)piVar10[3] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0xe;
      puStack_118 = puVar6;
      piVar10 = (int *)FUN_0088afd0();
      puStack_20 = (undefined4 *)*piVar10;
      uStack_1c = piVar10[1];
      uStack_18 = (undefined2)piVar10[2];
      uStack_16 = (undefined2)((uint)piVar10[2] >> 0x10);
      uStack_14 = (undefined2)piVar10[3];
      uStack_12 = (undefined2)((uint)piVar10[3] >> 0x10);
      uStack_8 = 0xf;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d864e0(param_1,&puStack_20);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x10:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00b00260();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00b00260();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      iStack_40 = *piVar10;
      iStack_3c = piVar10[1];
      iStack_38 = piVar10[2];
      iStack_34 = piVar10[3];
      iStack_30 = piVar10[4];
      iStack_2c = piVar10[5];
      uStack_28 = piVar10[6];
      uStack_24 = piVar10[7];
      puStack_20 = (undefined4 *)piVar10[8];
      uStack_1c = piVar10[9];
      uStack_18 = (undefined2)piVar10[10];
      uStack_16 = (undefined2)((uint)piVar10[10] >> 0x10);
      uStack_14 = (undefined2)piVar10[0xb];
      uStack_12 = (undefined2)((uint)piVar10[0xb] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 2;
      puStack_118 = puVar6;
      piVar10 = (int *)FUN_0088ab30();
      iStack_40 = *piVar10;
      iStack_3c = piVar10[1];
      iStack_38 = piVar10[2];
      iStack_34 = piVar10[3];
      iStack_30 = piVar10[4];
      iStack_2c = piVar10[5];
      uStack_28 = piVar10[6];
      uStack_24 = piVar10[7];
      puStack_20 = (undefined4 *)piVar10[8];
      uStack_1c = piVar10[9];
      uStack_18 = (undefined2)piVar10[10];
      uStack_16 = (undefined2)((uint)piVar10[10] >> 0x10);
      uStack_14 = (undefined2)piVar10[0xb];
      uStack_12 = (undefined2)((uint)piVar10[0xb] >> 0x10);
      uStack_8 = 3;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d85e30(param_1,&iStack_40);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x11:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d050();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d050();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uVar1 = *(undefined8 *)piVar10;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[2];
      uStack_12 = (undefined2)((uint)piVar10[2] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x14;
      puStack_118 = puVar6;
      puVar5 = (undefined8 *)FUN_0088a700();
      uVar1 = *puVar5;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)*(undefined4 *)(puVar5 + 1);
      uStack_12 = (undefined2)((uint)*(undefined4 *)(puVar5 + 1) >> 0x10);
      uStack_8 = 0x15;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d85d20(param_1,&uStack_1c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x13:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d690();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d690();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uStack_18 = (undefined2)*piVar10;
      uStack_16 = (undefined2)((uint)*piVar10 >> 0x10);
      uStack_14 = (undefined2)piVar10[1];
      uStack_12 = (undefined2)((uint)piVar10[1] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x18;
      puStack_118 = puVar6;
      puVar6 = (undefined4 *)FUN_0088b570();
      uStack_18 = (undefined2)*puVar6;
      uStack_16 = (undefined2)((uint)*puVar6 >> 0x10);
      uStack_14 = (undefined2)puVar6[1];
      uStack_12 = (undefined2)((uint)puVar6[1] >> 0x10);
      uStack_8 = 0x19;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00da8350(param_1,&uStack_18);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x14:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d5f0();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d5f0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      puStack_20 = (undefined4 *)*piVar10;
      uStack_1c = piVar10[1];
      uStack_18 = (undefined2)piVar10[2];
      uStack_16 = (undefined2)((uint)piVar10[2] >> 0x10);
      uStack_14 = (undefined2)piVar10[3];
      uStack_12 = (undefined2)((uint)piVar10[3] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x1a;
      puStack_118 = puVar6;
      piVar10 = (int *)FUN_0088b450();
      puStack_20 = (undefined4 *)*piVar10;
      uStack_1c = piVar10[1];
      uStack_18 = (undefined2)piVar10[2];
      uStack_16 = (undefined2)((uint)piVar10[2] >> 0x10);
      uStack_14 = (undefined2)piVar10[3];
      uStack_12 = (undefined2)((uint)piVar10[3] >> 0x10);
      uStack_8 = 0x1b;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00da8050(param_1,&puStack_20);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x15:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088d230();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088d230();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      param_2 = piVar2 + 2;
      if (piVar2[1] == 0) {
        param_2 = (int *)0x0;
      }
      param_2 = (int *)*param_2;
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x1c;
      puStack_118 = puVar6;
      param_2 = (int *)FUN_0088acc0();
      param_2 = (int *)*param_2;
      uStack_8 = 0x1d;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00a922c0(param_1,&param_2);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x16:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088ce60();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088ce60();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      param_2 = piVar2 + 2;
      if (piVar2[1] == 0) {
        param_2 = (int *)0x0;
      }
      param_2 = (int *)*param_2;
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x1e;
      puStack_118 = puVar6;
      param_2 = (int *)FUN_0088a510();
      param_2 = (int *)*param_2;
      uStack_8 = 0x1f;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00aa5450(param_1,&param_2);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x17:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00a73110();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00a73110();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      iStack_4c = *piVar10;
      iStack_48 = piVar10[1];
      iStack_44 = piVar10[2];
      iStack_40 = piVar10[3];
      iStack_3c = piVar10[4];
      iStack_38 = piVar10[5];
      iStack_34 = piVar10[6];
      iStack_30 = piVar10[7];
      iStack_2c = piVar10[8];
      uStack_28 = piVar10[9];
      uStack_24 = piVar10[10];
      puStack_20 = (undefined4 *)piVar10[0xb];
      uVar1 = *(undefined8 *)(piVar10 + 0xc);
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[0xe];
      uStack_12 = (undefined2)((uint)piVar10[0xe] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 4;
      puStack_118 = puVar6;
      piVar10 = (int *)FUN_0088b0e0();
      iStack_4c = *piVar10;
      iStack_48 = piVar10[1];
      iStack_44 = piVar10[2];
      iStack_40 = piVar10[3];
      iStack_3c = piVar10[4];
      iStack_38 = piVar10[5];
      iStack_34 = piVar10[6];
      iStack_30 = piVar10[7];
      iStack_2c = piVar10[8];
      uStack_28 = piVar10[9];
      uStack_24 = piVar10[10];
      puStack_20 = (undefined4 *)piVar10[0xb];
      uVar1 = *(undefined8 *)(piVar10 + 0xc);
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[0xe];
      uStack_12 = (undefined2)((uint)piVar10[0xe] >> 0x10);
      uStack_8 = 5;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d866c0(param_1,&iStack_4c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x18:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00b33940();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00b33940();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uVar1 = *(undefined8 *)piVar10;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[2];
      uStack_12 = (undefined2)((uint)piVar10[2] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 6;
      puStack_118 = puVar6;
      puVar5 = (undefined8 *)FUN_0088b220();
      uVar1 = *puVar5;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)*(undefined4 *)(puVar5 + 1);
      uStack_12 = (undefined2)((uint)*(undefined4 *)(puVar5 + 1) >> 0x10);
      uStack_8 = 7;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d86840(param_1,&uStack_1c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x1c:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_0088cfa0();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_0088cfa0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      param_2 = piVar2 + 2;
      if (piVar2[1] == 0) {
        param_2 = (int *)0x0;
      }
      param_2 = (int *)*param_2;
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x16;
      puStack_118 = puVar6;
      param_2 = (int *)FUN_0088a610();
      param_2 = (int *)*param_2;
      uStack_8 = 0x17;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00d859e0(param_1,&param_2);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x20:
    if (*(char *)((int)piVar10 + 0x22) == '\0') {
      piVar10 = (int *)0x0;
    }
    ExceptionList = &pvStack_10;
    if (piVar10 != (int *)0x0) {
      ExceptionList = &pvStack_10;
      iVar4 = (**(code **)(*piVar10 + 8))(param_2);
      uStack_18 = 0;
      uStack_16 = 0;
      uStack_14 = 0xf;
      uStack_12 = 0;
      uStack_28 = uStack_28 & 0xffffff00;
      uStack_8 = 1;
      if ((iVar4 != 0) && (cVar3 = FUN_009cb330(&uStack_28), cVar3 != '\0')) {
        FUN_0054ef20(&uStack_28);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
  default:
    uVar12 = 0x1e;
    pcVar11 = "*cannot read value as a string";
    break;
  case 0x29:
    ExceptionList = &pvStack_10;
    uVar12 = FUN_00943400(&uStack_1c);
    uStack_8 = 0x21;
    FUN_00a905f0(param_1,uVar12);
    thunk_FUN_00617bc0();
    ExceptionList = pvStack_10;
    return param_1;
  case 0x2a:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00a8dd60();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00a8dd60();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = (uint *)(piVar2 + 2);
      if (piVar2[1] == 0) {
        puVar7 = (uint *)0x0;
      }
      uStack_24 = *puVar7;
      puStack_20 = (undefined4 *)puVar7[1];
      uStack_1c = puVar7[2];
      uStack_14 = (undefined2)puVar7[4];
      uStack_12 = (undefined2)(puVar7[4] >> 0x10);
      uStack_18 = (undefined2)puVar7[3];
      uStack_16 = (undefined2)(puVar7[3] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x26;
      puStack_118 = puVar6;
      puVar7 = (uint *)thunk_FUN_00a8dac0();
      uStack_24 = *puVar7;
      puStack_20 = (undefined4 *)puVar7[1];
      uStack_1c = puVar7[2];
      uStack_18 = (undefined2)puVar7[3];
      uStack_16 = (undefined2)(puVar7[3] >> 0x10);
      uStack_14 = (undefined2)puVar7[4];
      uStack_12 = (undefined2)(puVar7[4] >> 0x10);
      uStack_8 = 0x27;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00a90610(param_1,&uStack_24);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x2b:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00b33310();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00b33310();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uStack_18 = (undefined2)*piVar10;
      uStack_16 = (undefined2)((uint)*piVar10 >> 0x10);
      uStack_14 = (undefined2)piVar10[1];
      uStack_12 = (undefined2)((uint)piVar10[1] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x22;
      puStack_118 = puVar6;
      puVar6 = (undefined4 *)FUN_00b331e0();
      uStack_18 = (undefined2)*puVar6;
      uStack_16 = (undefined2)((uint)*puVar6 >> 0x10);
      uStack_14 = (undefined2)puVar6[1];
      uStack_12 = (undefined2)((uint)puVar6[1] >> 0x10);
      uStack_8 = 0x23;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00b333e0(param_1,&uStack_18);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x2c:
    ExceptionList = &pvStack_10;
    uVar12 = FUN_00943500(&uStack_1c);
    uStack_8 = 0x20;
    FUN_00a92ff0(param_1,uVar12);
    thunk_FUN_00617ad0();
    ExceptionList = pvStack_10;
    return param_1;
  case 0x2d:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00a92b80();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00a92b80();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uVar1 = *(undefined8 *)piVar10;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[2];
      uStack_12 = (undefined2)((uint)piVar10[2] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x24;
      puStack_118 = puVar6;
      puVar5 = (undefined8 *)thunk_FUN_00a928f0();
      uVar1 = *puVar5;
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)*(undefined4 *)(puVar5 + 1);
      uStack_12 = (undefined2)((uint)*(undefined4 *)(puVar5 + 1) >> 0x10);
      uStack_8 = 0x25;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00a93010(param_1,&uStack_1c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x35:
    ExceptionList = &pvStack_10;
    FUN_00943300(&iStack_34);
    uStack_8 = 0x2f;
    iStack_124 = 0;
    iStack_120 = 0xf;
    auStack_134[0] = 0;
    FUN_005542c0("Signal ",7);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
    puVar6 = puStack_20 + 4;
    if (0xf < (uint)puStack_20[5]) {
      puStack_20 = (undefined4 *)*puStack_20;
    }
    FUN_00554150(puStack_20,*puVar6);
    FUN_0054ef20(auStack_134);
    FUN_005507b0();
    FUN_0087dc70();
    ExceptionList = pvStack_10;
    return param_1;
  case 0x36:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00da8f20();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00da8f20();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      iStack_2c = *piVar10;
      uStack_28 = piVar10[1];
      uStack_24 = piVar10[2];
      puStack_20 = (undefined4 *)piVar10[3];
      uVar1 = *(undefined8 *)(piVar10 + 4);
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[6];
      uStack_12 = (undefined2)((uint)piVar10[6] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x28;
      puStack_118 = puVar6;
      piVar10 = (int *)FUN_00da8c50();
      iStack_2c = *piVar10;
      uStack_28 = piVar10[1];
      uStack_24 = piVar10[2];
      puStack_20 = (undefined4 *)piVar10[3];
      uVar1 = *(undefined8 *)(piVar10 + 4);
      uStack_1c = (uint)uVar1;
      uStack_18 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_14 = (undefined2)piVar10[6];
      uStack_12 = (undefined2)((uint)piVar10[6] >> 0x10);
      uStack_8 = 0x29;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00da9180(param_1,&iStack_2c);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x37:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00da9bd0();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00da9bd0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = (uint *)(piVar2 + 2);
      if (piVar2[1] == 0) {
        puVar7 = (uint *)0x0;
      }
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x2a;
      puStack_118 = puVar6;
      puVar7 = (uint *)FUN_00da9ab0();
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_8 = 0x2b;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00da9ef0(param_1,&uStack_28);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x38:
    ExceptionList = &pvStack_10;
    uVar12 = FUN_00943620(&uStack_18);
    uStack_8 = 0x2c;
    FUN_00da73b0(param_1,uVar12);
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  case 0x39:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00da88a0();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00da88a0();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      uStack_18 = (undefined2)*piVar10;
      uStack_16 = (undefined2)((uint)*piVar10 >> 0x10);
      uStack_14 = (undefined2)piVar10[1];
      uStack_12 = (undefined2)((uint)piVar10[1] >> 0x10);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x2d;
      puStack_118 = puVar6;
      puVar6 = (undefined4 *)FUN_00da8790();
      uStack_18 = (undefined2)*puVar6;
      uStack_16 = (undefined2)((uint)*puVar6 >> 0x10);
      uStack_14 = (undefined2)puVar6[1];
      uStack_12 = (undefined2)((uint)puVar6[1] >> 0x10);
      uStack_8 = 0x2e;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00da8940(param_1,&uStack_18);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x3a:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00aa0140();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00aa0140();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = (uint *)(piVar2 + 2);
      if (piVar2[1] == 0) {
        puVar7 = (uint *)0x0;
      }
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
    }
    else {
      iStack_11c = *piVar2;
      puVar6 = (undefined4 *)piVar2[1];
      puStack_118 = (undefined4 *)0x0;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_114);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x31;
      puStack_118 = puVar6;
      puVar7 = (uint *)FUN_00aa00a0();
      uStack_28 = *puVar7;
      uStack_24 = puVar7[1];
      puStack_20 = (undefined4 *)puVar7[2];
      uStack_1c = puVar7[3];
      uVar1 = *(undefined8 *)(puVar7 + 4);
      uStack_18 = (undefined2)uVar1;
      uStack_16 = (undefined2)((ulonglong)uVar1 >> 0x10);
      uStack_14 = (undefined2)((ulonglong)uVar1 >> 0x20);
      uStack_12 = (undefined2)((ulonglong)uVar1 >> 0x30);
      uStack_8 = 0x32;
      if (puStack_118 != (undefined4 *)0x0) {
        (*(code *)puStack_118[2])(auStack_114);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00aa3850(param_1,&uStack_28);
    ExceptionList = pvStack_10;
    return param_1;
  case 0x3c:
    ExceptionList = &pvStack_10;
    piVar8 = (int *)FUN_00b38680();
    if (piVar10 == piVar8) {
      iVar4 = *piVar2;
      iVar9 = FUN_00b38680();
      if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar10 = piVar2 + 2;
      if (piVar2[1] == 0) {
        piVar10 = (int *)0x0;
      }
      iStack_12c = *piVar10;
      iStack_128 = piVar10[1];
      iStack_124 = piVar10[2];
      iStack_120 = piVar10[3];
    }
    else {
      puVar6 = (undefined4 *)piVar2[1];
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)*puVar6)(piVar2 + 2,auStack_1fc);
        puVar6 = (undefined4 *)piVar2[1];
      }
      uStack_8 = 0x33;
      piVar10 = (int *)thunk_FUN_00b38310();
      iStack_12c = *piVar10;
      iStack_128 = piVar10[1];
      iStack_124 = piVar10[2];
      iStack_120 = piVar10[3];
      uStack_8 = 0x34;
      if (puVar6 != (undefined4 *)0x0) {
        (*(code *)puVar6[2])(auStack_1fc);
      }
      uStack_8 = 0xffffffff;
    }
    FUN_00b418c0(param_1,&iStack_12c);
    ExceptionList = pvStack_10;
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(pcVar11,uVar12);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17280 ; VA 0x00958540 ; FUN_00958540 */

/* WARNING: Removing unreachable block (ram,0x009585b7) */
/* WARNING: Removing unreachable block (ram,0x009585ca) */
/* WARNING: Removing unreachable block (ram,0x009585d1) */
/* WARNING: Removing unreachable block (ram,0x009585d8) */

void FUN_00958540(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  iVar2 = FUN_00948040(&param_1);
  puVar1 = *(undefined4 **)(iVar2 + 8);
  if (*(undefined4 **)(iVar2 + 0xc) == puVar1) {
    FUN_0063d9b0(puVar1,&param_2);
  }
  else {
    *puVar1 = param_2;
    *(int *)(iVar2 + 8) = *(int *)(iVar2 + 8) + 4;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17281 ; VA 0x00958600 ; FUN_00958600 */

/* WARNING: Removing unreachable block (ram,0x00958694) */
/* WARNING: Removing unreachable block (ram,0x009586a7) */
/* WARNING: Removing unreachable block (ram,0x009586ae) */
/* WARNING: Removing unreachable block (ram,0x009586b5) */

void FUN_00958600(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  param_1 = *(undefined4 *)(param_1 + 0x10);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  iVar3 = FUN_00948040(&param_1);
  puVar1 = *(undefined4 **)(iVar3 + 8);
  if (*(undefined4 **)(iVar3 + 0xc) == puVar1) {
    FUN_0063d9b0(puVar1,&param_2);
  }
  else {
    *puVar1 = uVar2;
    *(int *)(iVar3 + 8) = *(int *)(iVar3 + 8) + 4;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17282 ; VA 0x009586d0 ; FUN_009586d0 */

void __fastcall FUN_009586d0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  uint uStack_4c;
  int aiStack_44 [8];
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc1d0;
  pvStack_10 = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar6 = 0x10;
  }
  else {
    iVar6 = (param_1[1] - *param_1 >> 4) * 2;
  }
  aiStack_44[0] = param_1[4];
  aiStack_44[1] = 0;
  aiStack_44[2] = 0;
  aiStack_44[3] = 0;
  aiStack_44[4] = 0;
  aiStack_44[5] = 0;
  aiStack_44[6] = 0;
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  FUN_0094a0d0();
  uStack_8 = 0;
  FUN_00945500(iVar6,aiStack_44,&uStack_11);
  FUN_0094a0d0();
  uStack_4c = param_1[4];
  iStack_50 = 0;
  iVar6 = *param_1;
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = uStack_4c;
  if (param_1[1] - iVar6 >> 4 != 0) {
    aiStack_44[7] = 0;
    do {
      puStack_18 = (uint *)(iVar6 + aiStack_44[7]);
      uVar7 = *puStack_18;
      uVar4 = uStack_1c;
      if (uVar7 != param_1[4]) {
        uVar8 = (iStack_58 - iStack_5c >> 4) - 1;
        uVar5 = 0;
        uVar4 = uVar7;
        do {
          uVar4 = uVar4 & uVar8;
          puVar3 = (uint *)(uVar4 * 0x10 + iStack_5c);
          if (*puVar3 == uStack_1c) {
            *puVar3 = uVar7;
            iStack_50 = iStack_50 + 1;
            uVar7 = *puStack_18;
            goto LAB_009587e5;
          }
          if (*puVar3 == uVar7) goto LAB_009587e5;
          uVar4 = uVar4 + 1 + uVar5;
          uVar5 = uVar5 + 1;
        } while (uVar5 <= uVar8);
        puVar3 = (uint *)0x0;
LAB_009587e5:
        *puVar3 = uVar7;
        param_1 = piStack_24;
        uVar4 = uStack_4c;
        if (puVar3 + 1 != puStack_18 + 1) {
          FUN_0093f230(puStack_18[1],puStack_18[2],aiStack_44[7]);
          param_1 = piStack_24;
          uVar4 = uStack_4c;
        }
      }
      uStack_1c = uVar4;
      uStack_20 = uStack_20 + 1;
      iVar6 = *param_1;
      aiStack_44[7] = aiStack_44[7] + 0x10;
    } while (uStack_20 < (uint)(param_1[1] - iVar6 >> 4));
  }
  if (param_1 != &iStack_5c) {
    *param_1 = iStack_5c;
    iVar1 = param_1[1];
    param_1[1] = iStack_58;
    iVar2 = param_1[2];
    param_1[2] = iStack_54;
    iStack_5c = iVar6;
    iStack_58 = iVar1;
    iStack_54 = iVar2;
  }
  FUN_0094a060();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17283 ; VA 0x00958880 ; FUN_00958880 */

void __fastcall FUN_00958880(int *param_1)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_18 = param_1[4];
  uStack_14 = uStack_14 & 0xffffff00;
  piStack_1c = param_1;
  FUN_0060e8c0(iVar5,&iStack_18,&uStack_5);
  uStack_14 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 3 != 0) {
    do {
      uVar4 = *(uint *)(iVar5 + uStack_10 * 8);
      puStack_c = (uint *)(iVar5 + uStack_10 * 8);
      if (uVar4 != param_1[4]) {
        uVar2 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_30 - iStack_34 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar2 = uVar2 & uVar7;
          puVar3 = (uint *)(iStack_34 + uVar2 * 8);
          if (*puVar3 == uStack_14) {
            *puVar3 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_0095892b;
          }
          if (*puVar3 == uVar4) goto LAB_0095892b;
          uVar2 = uVar2 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar3 = (uint *)0x0;
LAB_0095892b:
        *puVar3 = uVar4;
        *(undefined *)(puVar3 + 1) = *(undefined *)(puStack_c + 1);
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 3));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    param_1[1] = iStack_30;
    iVar1 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_2c = iVar1;
    iStack_34 = iVar5;
  }
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34 & 0xfffffff8;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 17284 ; VA 0x009589b0 ; FUN_009589b0 */

void * __thiscall FUN_009589b0(void *param_1,int param_2)

{
  void *pvVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvVar7;
  undefined4 uVar8;
  undefined *puVar9;
  undefined auStack_1c [4];
  int *piStack_18;
  void *pvStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc1e8;
  pvStack_10 = ExceptionList;
  pvVar7 = ExceptionList;
  if (param_1 != (void *)0x0) {
    pvVar1 = *(void **)((int)param_1 + 0x34);
    ppvVar3 = &pvStack_10;
    if ((pvVar1 != (void *)0x0) &&
       (param_1 = pvVar1, ppvVar3 = &pvStack_10, *(int *)((int)pvVar1 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      param_1 = (void *)FUN_005c8ac0();
      pvVar7 = param_1;
      ppvVar3 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar3;
    if (param_1 != (void *)0x0) {
      iVar2 = *(int *)((int)param_1 + 0xc);
      iVar4 = FUN_008a8c30();
      pvVar7 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
      if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <=
          (void *)(uint)*(ushort *)(iVar4 + 0x1da)) {
        piVar5 = (int *)FUN_005641e0();
        pvStack_14 = (void *)*piVar5;
        pvVar7 = pvStack_14;
        if ((pvStack_14 != (void *)0x0) &&
           (pvVar7 = (void *)CONCAT31((int3)((uint)pvStack_14 >> 8),
                                      *(char *)((int)pvStack_14 + 0x290)),
           *(char *)((int)pvStack_14 + 0x290) == '\0')) {
          FUN_0060e0c0(auStack_1c,param_2);
          iVar2 = *(int *)(param_2 + 0xc);
          uStack_8 = 0;
          iVar6 = FUN_00a34610();
          pvVar7 = (void *)(uint)*(ushort *)(iVar6 + 0x1da);
          iVar4 = 0;
          if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) <=
              pvVar7) {
            iVar4 = param_2;
          }
          if ((iVar4 == 0) && (pvVar7 = (void *)FUN_0094e480(auStack_1c), pvVar7 == (void *)0x0)) {
            puVar9 = auStack_1c;
            uVar8 = 0x958a9f;
            FUN_0094e480(puVar9);
            FUN_005587b0(auStack_1c);
            pvVar7 = (void *)FUN_00959050(uVar8,puVar9);
          }
          if (piStack_18 != (int *)0x0) {
            LOCK();
            piVar5 = piStack_18 + 2;
            iVar2 = *piVar5;
            pvVar7 = (void *)*piVar5;
            *piVar5 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              pvVar7 = (void *)(**(code **)(*piStack_18 + 4))();
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 17285 ; VA 0x00958ae0 ; FUN_00958ae0 */

int __thiscall FUN_00958ae0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc208;
  pvStack_10 = ExceptionList;
  iVar4 = param_1 + 0x78;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (iVar4 != param_1 + 0xf8) {
    puVar3 = (uint *)(param_1 + 0xb4);
    ExceptionList = &pvStack_10;
    do {
      uVar2 = *puVar3;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00958be0(uVar2 ^ (uint)puVar3,param_2,param_3);
      iVar4 = iVar4 + 0x40;
      puVar3 = puVar3 + 0x10;
    } while (iVar4 != param_1 + 0xf8);
  }
  param_1 = param_1 + 0xf8;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      param_1 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        param_1 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17286 ; VA 0x00958ba0 ; FUN_00958ba0 */

void FUN_00958ba0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00958bcd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*param_2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 17287 ; VA 0x00958be0 ; FUN_00958be0 */

int FUN_00958be0(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int *piStack_e0;
  int **ppiStack_dc;
  int **ppiStack_d8;
  int aiStack_c8 [8];
  int iStack_a8;
  uint uStack_88;
  int aiStack_80 [6];
  uint auStack_68 [2];
  int aiStack_60 [6];
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cc285;
  pvStack_10 = ExceptionList;
  ppiStack_d8 = (int **)param_1;
  uStack_8 = 0;
  uStack_7 = 0;
  ppiStack_dc = (int **)0x958c17;
  ExceptionList = &pvStack_10;
  iStack_14 = FUN_009edbb0();
  ppiStack_d8 = (int **)0x958c23;
  iVar2 = FUN_005817e0();
  piVar3 = param_3;
  if (iVar2 != 0) {
    if (iVar2 != 1) {
      ppiStack_d8 = (int **)0x958c84;
      iVar2 = FUN_00615970();
      if (iVar2 == -2) {
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[2] = param_3[2] + 1;
          UNLOCK();
        }
        ppiStack_dc = (int **)param_2;
        ppiStack_d8 = (int **)param_3;
        piStack_e0 = (int *)0x958cb8;
        FUN_009ecea0();
      }
      else {
        ppiStack_d8 = (int **)0x958cc8;
        FUN_009ed6b0();
        ppiStack_d8 = (int **)param_1;
        ppiStack_dc = (int **)0x958cce;
        piVar3 = (int *)FUN_012565c0();
        ppiStack_dc = (int **)0x958cdc;
        ppiStack_d8 = (int **)piVar3;
        FUN_009462d0();
        ppiStack_d8 = (int **)0xfffffffe;
        ppiStack_dc = (int **)param_1;
        uStack_8 = 1;
        piStack_e0 = (int *)0x958ce8;
        FUN_01257280();
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = 0;
        ppiStack_d8 = (int **)0x104;
        ppiStack_dc = (int **)0x1934178;
        piStack_e0 = (int *)0x958d0f;
        FUN_005542c0();
        ppiStack_d8 = (int **)auStack_48;
        uStack_8 = 2;
        ppiStack_dc = &piStack_1c;
        piStack_e0 = (int *)0x958d20;
        uVar4 = FUN_00886c00();
        piStack_e0 = (int *)&DAT_018bc9b8;
        uStack_8 = 3;
        iVar5 = FUN_009edf40(piVar3,uVar4);
        uStack_8 = 2;
        ppiStack_d8 = (int **)0x958d41;
        FUN_0056e380();
        ppiStack_d8 = (int **)0x958d49;
        FUN_0056e380();
        if (iVar5 != 0) {
          ppiStack_d8 = (int **)0xffffffff;
          piStack_e0 = (int *)0x958f90;
          ppiStack_dc = (int **)piVar3;
          ppiStack_d8 = (int **)FUN_00881a60();
          ppiStack_dc = (int **)0x958f9c;
          FUN_0054eff0();
          _uStack_8 = CONCAT31(uStack_7,4);
          ppiStack_d8 = (int **)0x958fa8;
          ppiStack_d8 = (int **)FUN_005543f0();
          ppiStack_dc = (int **)0x1934280;
                    /* WARNING: Subroutine does not return */
          piStack_e0 = (int *)0x958fb3;
          FUN_016757c0();
        }
        ppiStack_dc = (int **)0xffffd8f0;
        piStack_e0 = piVar3;
        ppiStack_d8 = (int **)iVar2;
        FUN_01256cb0();
        ppiStack_d8 = (int **)&param_2;
        ppiStack_dc = (int **)0x958d6c;
        FUN_00557fc0();
        ppiStack_d8 = &piStack_1c;
        uStack_8 = 5;
        piStack_e0 = (int *)0x958d7a;
        ppiStack_dc = (int **)piVar3;
        FUN_00da3620();
        uStack_8 = 2;
        ppiStack_d8 = (int **)0x958d89;
        FUN_00550b30();
        ppiStack_dc = (int **)0x2;
        piStack_e0 = piVar3;
        ppiStack_d8 = (int **)iVar5;
        iVar6 = FUN_0095b200();
        if (iVar6 == 1) {
          ppiStack_dc = (int **)(uint)DAT_01ee2ab1;
          ppiStack_d8 = (int **)iVar2;
          aiStack_c8[0] = iVar5;
          iStack_a8 = iVar5;
          FUN_00557fc0(&param_2);
          FUN_00942910(&uStack_24,FUN_00958fd0);
          ppiStack_d8 = (int **)0x0;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            piStack_1c[1] = piStack_1c[1] + 1;
            UNLOCK();
          }
          piStack_e0 = piStack_1c;
          ppiStack_dc = (int **)piStack_18;
          piVar3 = (int *)FUN_0093e6a0(uStack_24,uStack_20);
          if (aiStack_c8 != piVar3) {
            auStack_68[0] = 0;
            uStack_8 = 9;
            ppiStack_dc = (int **)0x958e34;
            ppiStack_d8 = (int **)piVar3;
            FUN_005880d0();
            ppiStack_d8 = (int **)aiStack_c8;
            ppiStack_dc = (int **)0x958e42;
            FUN_005880d0();
            ppiStack_d8 = (int **)auStack_68;
            ppiStack_dc = (int **)0x958e51;
            FUN_005880d0();
            uStack_8 = 10;
            if (((auStack_68[0] != 0) && ((auStack_68[0] & 1) == 0)) &&
               (*(code **)(auStack_68[0] & 0xfffffffe) != (code *)0x0)) {
              piStack_e0 = aiStack_60;
              ppiStack_d8 = (int **)0x2;
              ppiStack_dc = (int **)piStack_e0;
              (**(code **)(auStack_68[0] & 0xfffffffe))();
            }
          }
          uStack_8 = 0xb;
          if (((uStack_88 != 0) && ((uStack_88 & 1) == 0)) &&
             (*(code **)(uStack_88 & 0xfffffffe) != (code *)0x0)) {
            piStack_e0 = aiStack_80;
            ppiStack_d8 = (int **)0x2;
            ppiStack_dc = (int **)piStack_e0;
            (**(code **)(uStack_88 & 0xfffffffe))();
          }
          uStack_8 = 6;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              ppiStack_d8 = (int **)0x958eb9;
              (**(code **)*piStack_1c)();
              LOCK();
              piVar3 = piStack_1c + 2;
              iVar2 = *piVar3;
              *piVar3 = *piVar3 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                ppiStack_d8 = (int **)0x958ec8;
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
          FUN_00557fc0(&param_2);
          FUN_00942a30(&piStack_e0,FUN_00958ba0);
          FUN_0093ef40();
          ppiStack_d8 = (int **)0x40;
          ppiStack_dc = (int **)0x958f11;
          iStack_14 = FUN_01674e20();
          uStack_8 = 0xc;
          if (iStack_14 == 0) {
            ppiStack_d8 = (int **)0x0;
          }
          else {
            ppiStack_d8 = (int **)aiStack_c8;
            ppiStack_dc = (int **)0x958f2d;
            ppiStack_d8 = (int **)FUN_00945830();
          }
          ppiStack_dc = (int **)0x958f39;
          FUN_0095ab70();
          ppiStack_d8 = (int **)0x958f44;
          FUN_008c3510();
        }
        else {
          if (iVar6 != 0) {
            ppiStack_d8 = (int **)0x0;
            ppiStack_dc = (int **)0xffffffff;
            piStack_e0 = piVar3;
            ppiStack_d8 = (int **)FUN_01257440();
            ppiStack_dc = (int **)0x1934294;
                    /* WARNING: Subroutine does not return */
            piStack_e0 = (int *)&UNK_00958fcb;
            FUN_016757c0();
          }
          ppiStack_dc = (int **)0x958f53;
          ppiStack_d8 = (int **)iVar2;
          FUN_009ed680();
          *(undefined *)(param_2 + 0xed) = 0;
        }
        ppiStack_d8 = (int **)0x958f65;
        FUN_005507b0();
        ppiStack_d8 = (int **)0x958f6d;
        FUN_0089b430();
      }
      ppiStack_d8 = (int **)0x958f75;
      iVar2 = FUN_00550b30();
      ExceptionList = pvStack_10;
      return iVar2;
    }
    *(undefined *)(param_2 + 0xed) = 1;
    iVar2 = param_2;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar5 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      ppiStack_d8 = (int **)0x958c57;
      iVar2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        ppiStack_d8 = (int **)0x958c6a;
        iVar2 = (**(code **)(*piVar3 + 4))();
        ExceptionList = pvStack_10;
        return iVar2;
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 17288 ; VA 0x00958fd0 ; FUN_00958fd0 */

int FUN_00958fd0(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc208;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0094fe20(param_3);
  FUN_009edbb0(uVar3);
  iVar4 = FUN_009ed680(param_4);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17289 ; VA 0x00959050 ; FUN_00959050 */

int FUN_00959050(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc2a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 != 0) {
    if (DAT_01ee4207 != '\0') {
      piVar3 = *(int **)(iStack_18 + 0x28);
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_01677650(DAT_01ee4207,"RemoveScript %s",piVar3);
    }
    iVar2 = FUN_0094d320(iStack_18);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_14 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar3 = piStack_14 + 2;
      iVar1 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      iVar2 = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 17290 ; VA 0x00959110 ; FUN_00959110 */

undefined4 *** FUN_00959110(undefined4 *****param_1)

{
  undefined4 ***pppuVar1;
  char cVar2;
  undefined4 ***pppuVar3;
  int iVar4;
  undefined uVar5;
  undefined4 ***pppuVar6;
  undefined4 ****ppppuVar7;
  undefined4 *****pppppuVar8;
  undefined4 *****pppppuVar9;
  undefined4 ****appppuStack_dc [5];
  undefined4 uStack_c8;
  undefined4 ****ppppuStack_c4;
  undefined4 ****ppppuStack_c0;
  undefined4 ***pppuStack_bc;
  undefined4 ****ppppuStack_b8;
  undefined4 ****ppppuStack_b4;
  undefined4 ****ppppuStack_b0;
  undefined4 ****ppppuStack_ac;
  undefined4 ****ppppuStack_a8;
  undefined4 ****ppppuStack_a4;
  undefined4 **ppuStack_98;
  undefined4 **ppuStack_94;
  undefined4 **ppuStack_90;
  undefined4 **ppuStack_8c;
  undefined8 uStack_88;
  undefined4 ****appppuStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  undefined *puStack_68;
  undefined *puStack_64;
  undefined4 ****appppuStack_60 [4];
  int iStack_50;
  uint uStack_4c;
  undefined4 ****appppuStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 **ppuStack_30;
  undefined4 ****appppuStack_2c [3];
  undefined4 uStack_20;
  undefined4 ****ppppuStack_1c;
  undefined4 ***pppuStack_18;
  undefined4 **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  pppppuVar9 = param_1;
  puStack_c = &LAB_017cc33c;
  pvStack_10 = ExceptionList;
  ppuStack_30 = (undefined4 **)0x0;
  iStack_50 = 0;
  uStack_4c = 0xf;
  appppuStack_60[0] = (undefined4 ****)((uint)appppuStack_60[0] & 0xffffff00);
  ppppuStack_a4 = (undefined4 ****)0x0;
  ppppuStack_a8 = (undefined4 ****)0xffffffff;
  ppppuStack_ac = param_1;
  uStack_8 = 0;
  uStack_7 = 0;
  ppppuStack_b0 = (undefined4 ****)0x959160;
  ExceptionList = &pvStack_10;
  ppppuStack_a8 = (undefined4 ****)FUN_01257440();
  if (ppppuStack_a8 != (undefined4 ****)0x0) {
    ppppuVar7 = ppppuStack_a8;
    do {
      cVar2 = *(char *)ppppuVar7;
      ppppuVar7 = (undefined4 ****)((int)ppppuVar7 + 1);
    } while (cVar2 != '\0');
    if (ppppuVar7 != (undefined4 ****)((int)ppppuStack_a8 + 1)) {
      ppppuVar7 = ppppuStack_a8;
      do {
        cVar2 = *(char *)ppppuVar7;
        ppppuVar7 = (undefined4 ****)((int)ppppuVar7 + 1);
      } while (cVar2 != '\0');
      ppppuStack_a4 = (undefined4 ****)((int)ppppuVar7 - (int)((int)ppppuStack_a8 + 1));
      goto LAB_00959194;
    }
  }
  ppppuStack_a4 = (undefined4 ****)0x23;
  ppppuStack_a8 = (undefined4 ****)0x19348e4;
LAB_00959194:
  ppppuStack_ac = (undefined4 ****)0x95919c;
  FUN_005542c0();
  iVar4 = iStack_50;
  if (DAT_01d643b4 == 0) {
    param_1 = (undefined4 *****)0x3;
    if (DAT_01d64520 == '\0') {
      ppppuStack_a4 = &param_1;
      ppppuStack_a8 = pppppuVar9;
      ppppuStack_c4 = appppuStack_60;
      uStack_c8 = 0x95924b;
      FUN_0054ef60();
      ppppuStack_c4 = (undefined4 *****)0x959250;
      FUN_009497f0();
      ppppuStack_a4 = (undefined4 ****)0x0;
      ppppuStack_a8 = (undefined4 *****)0x0;
      ppppuStack_ac = (undefined4 *****)0x0;
      ppppuStack_b0 = pppppuVar9;
      ppppuStack_b4 = (undefined4 *****)0x95925f;
      FUN_009556b0();
    }
    else {
      ppppuStack_a4 = appppuStack_60;
      ppppuStack_a8 = (undefined4 ****)0x9591c5;
      FUN_0054ef60();
      ppppuStack_a4 = param_1;
      ppppuStack_a8 = (undefined4 ****)&ppuStack_30;
      uStack_8 = 1;
      ppppuStack_ac = appppuStack_48;
      uStack_20 = 0;
      ppppuStack_1c = (undefined4 *****)0x0;
      pppuStack_18 = (undefined4 ****)0x0;
      ppppuStack_b0 = (undefined4 ****)0x9591f1;
      FUN_00604490();
      ppppuStack_a4 = &param_1;
      uStack_8 = 2;
      ppppuStack_ac = (undefined4 ****)&uStack_20;
      ppppuStack_a8 = pppppuVar9;
      ppppuStack_b0 = (undefined4 ****)0x959203;
      FUN_00955da0();
      ppppuStack_a4 = (undefined4 ****)0x95920e;
      FUN_00577a40();
      ppppuStack_a4 = (undefined4 ****)FUN_005507b0;
      ppppuStack_a8 = (undefined4 ****)0x1;
      ppppuStack_ac = (undefined4 ****)0x18;
      ppppuStack_b0 = appppuStack_48;
      uStack_8 = 0;
      ppppuStack_b4 = (undefined4 ****)0x959224;
      FUN_016f32d1();
      ppppuStack_a4 = (undefined4 ****)0x0;
      ppppuStack_a8 = (undefined4 *****)0x0;
      ppppuStack_ac = (undefined4 *****)0x0;
      ppppuStack_b0 = pppppuVar9;
      ppppuStack_b4 = (undefined4 *****)0x959230;
      FUN_009556b0();
    }
  }
  else {
    uStack_8 = 3;
    ppppuStack_1c = (undefined4 *****)0x0;
    pppuStack_18 = (undefined4 ***)&DAT_0000000f;
    ppppuStack_a4 = (undefined4 ****)(iStack_50 + 5);
    appppuStack_2c[0] = (undefined4 ****)((uint)appppuStack_2c[0] & 0xffffff00);
    ppuStack_30 = (undefined4 **)0x1;
    ppppuStack_a8 = (undefined4 ****)0x959293;
    FUN_0058a190();
    ppppuStack_a4 = (undefined4 ****)iVar4;
    ppppuStack_a8 = appppuStack_60;
    if (0xf < uStack_4c) {
      ppppuStack_a8 = appppuStack_60[0];
    }
    ppppuStack_ac = (undefined4 ****)0x9592a8;
    FUN_00554150();
    ppppuStack_a4 = (undefined4 ****)0x5;
    ppppuStack_a8 = (undefined4 ****)0x1934908;
    ppppuStack_ac = (undefined4 ****)0x9592b7;
    FUN_00554150();
    ppppuStack_a4 = (undefined4 ****)0x0;
    ppppuStack_a8 = (undefined4 ****)0x1934908;
    ppppuStack_ac = appppuStack_2c;
    ppppuStack_b0 = pppppuVar9;
    ppppuStack_b4 = (undefined4 ****)0x9592c8;
    FUN_009556b0();
    ppppuStack_b4 = (undefined4 ****)&DAT_00000006;
    ppppuStack_b8 = appppuStack_2c;
    if (&DAT_0000000f < pppuStack_18) {
      ppppuStack_b8 = appppuStack_2c[0];
    }
    pppuStack_bc = (undefined4 ****)0x3;
    ppppuStack_c0 = (undefined4 ****)0x9592dd;
    FUN_0086edd0();
    uStack_8 = 0;
    uVar5 = uStack_8;
    uStack_8 = 0;
    if (&DAT_0000000f < pppuStack_18) {
      ppppuStack_a4 = (undefined4 ****)((int)pppuStack_18 + 1);
      pppppuVar8 = (undefined4 *****)appppuStack_2c[0];
      if ((undefined4 ****)0xfff < ppppuStack_a4) {
        pppppuVar8 = (undefined4 *****)appppuStack_2c[0][-1];
        ppppuStack_a4 = (undefined4 ****)(pppuStack_18 + 9);
        if (0x1f < (uint)((int)appppuStack_2c[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_a4 = (undefined4 ****)0x95963e;
          uStack_8 = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_ac = (undefined4 *****)0x959315;
      ppppuStack_a8 = pppppuVar8;
      FUN_01674ea0();
    }
  }
  if ((undefined4 **)ppuStack_14[0xa6] != (undefined4 **)0x0) {
    ppppuStack_1c = (undefined4 *****)0x0;
    pppuStack_18 = (undefined4 ****)0x0;
    uStack_38 = 0;
    uStack_34 = 0xf;
    appppuStack_48[0] = (undefined4 ****)((uint)appppuStack_48[0] & 0xffffff00);
    uStack_70 = 0;
    uStack_6c = 0xf;
    appppuStack_80[0] = (undefined4 ****)((uint)appppuStack_80[0] & 0xffffff00);
    ppppuStack_a4 = &param_1;
    _uStack_8 = CONCAT31(uStack_7,6);
    ppppuStack_a8 = &ppppuStack_1c;
    ppppuStack_ac = appppuStack_80;
    ppppuStack_b0 = appppuStack_48;
    ppppuStack_b4 = pppppuVar9;
    ppppuStack_b8 = (undefined4 *****)0x959374;
    FUN_0094f140();
    ppppuStack_a4 = (undefined4 ****)0x0;
    if (DAT_01d644f8 != '\0') {
      if (pppppuVar9 == (undefined4 *****)0x0) {
        ppppuStack_a4 = (undefined4 ****)0x0;
        ppppuStack_a8 = (undefined4 *****)0x0;
        ppppuStack_ac = (undefined4 *****)0x0;
        ppppuStack_b0 = (undefined4 *****)0x0;
        ppppuStack_b4 = (undefined4 *****)0x9593bb;
        pppuVar6 = (undefined4 ***)FUN_01255470();
      }
      else {
        ppppuVar7 = pppppuVar9[0x1b];
        ppuStack_98 = ppppuVar7[6];
        ppuStack_94 = ppppuVar7[7];
        ppuStack_90 = ppppuVar7[8];
        ppuStack_8c = ppppuVar7[9];
        pppuVar6 = &ppuStack_98;
        uStack_88 = *(undefined8 *)(ppppuVar7 + 10);
      }
      ppppuStack_a4 = (undefined4 ****)*pppuVar6;
      uStack_88 = *(undefined8 *)(pppuVar6 + 4);
    }
    param_1 = (undefined4 *****)&pppuStack_bc;
    ppppuStack_c0 = appppuStack_80;
    ppppuStack_c4 = (undefined4 ****)0x9593e1;
    FUN_0054ef60();
    pppuVar6 = pppuStack_18;
    ppuStack_30 = &ppppuStack_c4;
    if ((undefined4 ****)pppuStack_18 != (undefined4 ****)0x0) {
      LOCK();
      pppuStack_18[1] = (undefined4 ***)((int)pppuStack_18[1] + 1);
      UNLOCK();
    }
    ppppuStack_c4 = ppppuStack_1c;
    ppppuStack_c0 = (undefined4 ****)pppuStack_18;
    puStack_64 = (undefined *)appppuStack_dc;
    uStack_8 = 8;
    FUN_0054ef60(appppuStack_48);
    uStack_8 = 9;
    FUN_0054ef60(appppuStack_60);
    uStack_8 = 6;
    FUN_009490c0();
    uStack_8 = 5;
    uVar5 = uStack_8;
    uStack_8 = 5;
    if (0xf < uStack_6c) {
      ppppuStack_a4 = (undefined4 ****)(uStack_6c + 1);
      pppppuVar8 = (undefined4 *****)appppuStack_80[0];
      if (0xfff < ppppuStack_a4) {
        pppppuVar8 = (undefined4 *****)appppuStack_80[0][-1];
        ppppuStack_a4 = (undefined4 ****)(uStack_6c + 0x24);
        if (0x1f < (uint)((int)appppuStack_80[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_a4 = (undefined4 ****)0x959643;
          uStack_8 = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_ac = (undefined4 *****)0x959477;
      ppppuStack_a8 = pppppuVar8;
      FUN_01674ea0();
    }
    uStack_8 = 4;
    uVar5 = uStack_8;
    uStack_8 = 4;
    if (0xf < uStack_34) {
      ppppuStack_a4 = (undefined4 ****)(uStack_34 + 1);
      pppppuVar8 = (undefined4 *****)appppuStack_48[0];
      if (0xfff < ppppuStack_a4) {
        pppppuVar8 = (undefined4 *****)appppuStack_48[0][-1];
        ppppuStack_a4 = (undefined4 ****)(uStack_34 + 0x24);
        if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_a4 = (undefined4 ****)0x959648;
          uStack_8 = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_ac = (undefined4 *****)0x9594af;
      ppppuStack_a8 = pppppuVar8;
      FUN_01674ea0();
    }
    uStack_8 = 0;
    if ((undefined4 ****)pppuVar6 != (undefined4 ****)0x0) {
      LOCK();
      pppuVar3 = (undefined4 ***)((int)pppuVar6[1] + -1);
      pppuVar6[1] = pppuVar3;
      UNLOCK();
      if (pppuVar3 == (undefined4 ***)0x0) {
        ppppuStack_a4 = (undefined4 ****)0x9594ca;
        (*(code *)**pppuVar6)();
        LOCK();
        pppuVar3 = (undefined4 ***)((int)pppuVar6[2] + -1);
        pppuVar6[2] = pppuVar3;
        UNLOCK();
        if (pppuVar3 == (undefined4 ***)0x0) {
          ppppuStack_a4 = (undefined4 ****)0x9594db;
          (*(code *)(*pppuVar6)[1])();
        }
      }
    }
  }
  pppuVar6 = (undefined4 ***)ppuStack_14;
  if ((undefined4 **)ppuStack_14[0xa5] != (undefined4 **)0x0) {
    ppppuStack_1c = (undefined4 *****)0x0;
    pppuStack_18 = (undefined4 ****)0x0;
    ppppuStack_a4 = &param_1;
    uStack_8 = 10;
    ppppuStack_a8 = &ppppuStack_1c;
    ppppuStack_b0 = appppuStack_48;
    ppppuStack_ac = pppppuVar9;
    ppppuStack_b4 = (undefined4 *****)0x95950f;
    FUN_0094ef20();
    pppuVar3 = pppuStack_18;
    param_1 = &ppppuStack_a8;
    if ((undefined4 ****)pppuStack_18 != (undefined4 ****)0x0) {
      LOCK();
      pppuStack_18[1] = (undefined4 ***)((int)pppuStack_18[1] + 1);
      UNLOCK();
    }
    ppppuStack_a8 = ppppuStack_1c;
    ppppuStack_a4 = (undefined4 ****)pppuStack_18;
    puStack_68 = (undefined *)&ppppuStack_c0;
    uStack_8 = 0xc;
    ppppuStack_c4 = appppuStack_48;
    uStack_c8 = 0x95954c;
    FUN_0054ef60();
    uStack_8 = 0xd;
    appppuStack_dc[0] = appppuStack_60;
    FUN_0054ef60();
    uStack_8 = 0xb;
    appppuStack_dc[0] = (undefined4 ****)0x959570;
    pppuVar6 = (undefined4 ***)FUN_00949320();
    uStack_8 = 10;
    uVar5 = uStack_8;
    uStack_8 = 10;
    if (0xf < uStack_34) {
      ppppuStack_a4 = (undefined4 ****)(uStack_34 + 1);
      pppppuVar8 = (undefined4 *****)appppuStack_48[0];
      if (0xfff < ppppuStack_a4) {
        pppppuVar8 = (undefined4 *****)appppuStack_48[0][-1];
        ppppuStack_a4 = (undefined4 ****)(uStack_34 + 0x24);
        if (0x1f < (uint)((int)appppuStack_48[0] + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          ppppuStack_a4 = (undefined4 ****)0x95964d;
          uStack_8 = uVar5;
          FUN_017167a3();
        }
      }
      ppppuStack_ac = (undefined4 *****)0x9595a5;
      ppppuStack_a8 = pppppuVar8;
      pppuVar6 = (undefined4 ***)FUN_01674ea0();
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    appppuStack_48[0] = (undefined4 ****)((uint)appppuStack_48[0] & 0xffffff00);
    uStack_8 = 0;
    if ((undefined4 ****)pppuVar3 != (undefined4 ****)0x0) {
      LOCK();
      ppppuVar7 = (undefined4 ****)(pppuVar3 + 1);
      pppuVar1 = *ppppuVar7;
      pppuVar6 = *ppppuVar7;
      *ppppuVar7 = (undefined4 ***)((int)pppuVar1 + -1);
      UNLOCK();
      if ((undefined4 ***)((int)pppuVar1 + -1) == (undefined4 ***)0x0) {
        ppppuStack_a4 = (undefined4 ****)0x9595d2;
        (*(code *)**pppuVar3)();
        LOCK();
        ppppuVar7 = (undefined4 ****)(pppuVar3 + 2);
        pppuVar1 = *ppppuVar7;
        pppuVar6 = *ppppuVar7;
        *ppppuVar7 = (undefined4 ***)((int)pppuVar1 + -1);
        UNLOCK();
        if ((undefined4 ***)((int)pppuVar1 + -1) == (undefined4 ***)0x0) {
          ppppuStack_a4 = (undefined4 ****)0x9595e3;
          pppuVar6 = (undefined4 ***)(*(code *)(*pppuVar3)[1])();
        }
      }
    }
  }
  if ((undefined4 **)ppuStack_14[0xa7] != (undefined4 **)0x0) {
    ppppuStack_a4 = pppppuVar9;
    ppppuStack_a8 = (undefined4 *****)0x9595f7;
    pppuVar6 = (undefined4 ***)FUN_005e6780();
  }
  if (0xf < uStack_4c) {
    ppppuStack_a4 = (undefined4 ****)(uStack_4c + 1);
    pppppuVar9 = (undefined4 *****)appppuStack_60[0];
    if (0xfff < ppppuStack_a4) {
      pppppuVar9 = (undefined4 *****)appppuStack_60[0][-1];
      ppppuStack_a4 = (undefined4 ****)(uStack_4c + 0x24);
      if (0x1f < (uint)((int)appppuStack_60[0] + (-4 - (int)pppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        ppppuStack_a4 = (undefined4 ****)&UNK_00959652;
        FUN_017167a3();
      }
    }
    ppppuStack_ac = (undefined4 ****)0x959624;
    ppppuStack_a8 = pppppuVar9;
    pppuVar6 = (undefined4 ***)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return pppuVar6;
}



/* FUNCTION 17291 ; VA 0x00959660 ; FUN_00959660 */

void __thiscall FUN_00959660(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  char *pcVar7;
  undefined4 uVar8;
  undefined auStack_dc [48];
  undefined auStack_ac [64];
  undefined auStack_6c [24];
  undefined4 ***apppuStack_54 [4];
  int iStack_44;
  uint uStack_40;
  int aiStack_3c [2];
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc3b1;
  pvStack_10 = ExceptionList;
  if ((((DAT_01d64538 != '\0') && (0 < DAT_01ee29f8)) && (param_2 != 0)) && (param_1 != 0)) {
    iVar3 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    if ((iVar3 != 0) && (param_1 = iVar3, ExceptionList = &pvStack_10, *(int *)(iVar3 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar3 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) &&
       ((iVar3 = FUN_005f5170(), iVar3 != 0 && (cVar1 = FUN_00585a40(), cVar1 == '\0')))) {
      FUN_00587490(aiStack_3c);
      uStack_8 = 0;
      FUN_00950420(auStack_6c,aiStack_3c[0]);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_1c = CONCAT44(&DAT_01ee2ab4,(undefined4)uStack_1c);
      iVar3 = FUN_016dee6d(&DAT_01ee2ab4);
      if (iVar3 != 0) {
        FUN_016df3c9(iVar3);
      }
      uStack_8._0_1_ = 2;
      iVar3 = FUN_0076d640(auStack_6c);
      if (iVar3 == 0) {
        iVar3 = *DAT_01ee2aec;
        puVar5 = *(undefined4 **)(iVar3 + 4);
        uVar4 = FUN_0086f8b0(iVar3,puVar5,auStack_6c);
        if (DAT_01ee2af0 == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        DAT_01ee2af0 = DAT_01ee2af0 + 1;
        *(undefined4 *)(iVar3 + 4) = uVar4;
        *puVar5 = uVar4;
        FUN_005ca750(auStack_ac,*DAT_01ee2aec + 8,*DAT_01ee2aec);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        iVar3 = FUN_016deec8(&DAT_01ee2ab4);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (*(int *)(aiStack_3c[0] + 0x34) != 0) {
          aiStack_3c[0] = FUN_005c8ac0();
        }
        if (((aiStack_3c[0] == 0) ||
            (iVar3 = *(int *)(aiStack_3c[0] + 0xc), iVar2 = FUN_008dcf60(),
            (uint)*(ushort *)(iVar2 + 0x1da) <
            (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) ||
           (pcVar7 = "game.", aiStack_3c[0] == 0xc)) {
          pcVar7 = "nil.";
        }
        puVar5 = (undefined4 *)FUN_008a2380(auStack_34);
        uStack_8._0_1_ = 5;
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_01675640(auStack_dc,&DAT_01934bd4,pcVar7,puVar5);
        uStack_8._0_1_ = 7;
        FUN_005507b0();
        FUN_0054eff0(*(int *)(*(int *)(**(int **)(*(int *)(param_2 + 0x24) + 4 +
                                                 ((*(int *)(param_2 + 0x14) -
                                                  *(int *)(param_2 + 0x24)) / 0x18) * 0x18) + 0x18)
                             + 0x24) + 0x10);
        uStack_8._0_1_ = 8;
        FUN_00ae4430();
        FUN_009cc5b0(apppuStack_54);
        uStack_8._0_1_ = 9;
        uStack_1c = 0;
        iVar3 = FUN_008f7870(iStack_14);
        if (iVar3 == 0) {
          uVar4 = (undefined4)uStack_1c;
          uVar8 = uStack_1c._4_4_;
        }
        else {
          uVar4 = *(undefined4 *)(iVar3 + 0x440);
          uVar8 = *(undefined4 *)(iVar3 + 0x444);
        }
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 10;
        FUN_0151fbb0("unvId",uVar4,uVar8);
        if (iStack_44 == 0) {
          ppppuVar6 = (undefined4 ****)&DAT_018d0474;
        }
        else {
          ppppuVar6 = apppuStack_54;
          if (0xf < uStack_40) {
            ppppuVar6 = (undefined4 ****)apppuStack_54[0];
          }
        }
        FUN_0151f850(&DAT_018c1fd8,ppppuVar6);
        uVar4 = FUN_0058c540(auStack_34,0,0xff);
        uStack_8._0_1_ = 0xb;
        FUN_0151f950("script",uVar4);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        uVar4 = FUN_0058c540(auStack_34,0,0xff);
        uStack_8._0_1_ = 0xc;
        FUN_0151f950("function",uVar4);
        uStack_8._0_1_ = 10;
        FUN_005507b0();
        FUN_0151f950(&DAT_018d2350,auStack_6c);
        iVar3 = DAT_01ee29f8;
        uStack_24 = 0;
        uStack_20 = 0xf;
        auStack_34[0] = 0;
        FUN_005542c0("HungScript",10);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        FUN_01520d20(auStack_34,iVar3,0);
        FUN_005507b0();
        FUN_0151f7f0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
      }
      else {
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        iVar3 = FUN_016deec8(&DAT_01ee2ab4);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
      }
      FUN_005507b0();
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17292 ; VA 0x00959a90 ; FUN_00959a90 */

int FUN_00959a90(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  char *pcVar4;
  int iVar5;
  char *pcVar6;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cc3d8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  pcVar4 = (char *)FUN_01257440(param_1);
  if (pcVar4 != (char *)0x0) {
    pcVar6 = pcVar4;
    do {
      cVar3 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar3 != '\0');
    if (pcVar6 != pcVar4 + 1) {
      do {
        cVar3 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar3 != '\0');
    }
  }
  FUN_005542c0();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_0054ef60(auStack_2c);
  _uStack_8 = CONCAT31(uStack_7,1);
  iVar5 = FUN_00955bc0();
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (auStack_2c[0] - *(int *)(auStack_2c[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    iVar5 = FUN_01674ea0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17293 ; VA 0x00959bd0 ; FUN_00959bd0 */

int FUN_00959bd0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 *param_5,
                undefined4 param_6,undefined4 *param_7,undefined4 param_8,undefined4 param_9)

{
  undefined8 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  bool bVar6;
  char cVar7;
  int *piVar8;
  undefined4 uVar9;
  int iVar10;
  int *piVar11;
  undefined4 uStack_23c;
  undefined4 *puStack_238;
  undefined4 uStack_234;
  undefined4 *puStack_230;
  undefined **appuStack_22c [2];
  undefined4 *puStack_224;
  undefined4 uStack_21c;
  undefined *puStack_218;
  undefined4 uStack_214;
  int *piStack_210;
  undefined4 auStack_204 [2];
  undefined auStack_1fc [72];
  undefined4 uStack_1b4;
  undefined auStack_1ac [72];
  undefined4 uStack_164;
  undefined auStack_15c [72];
  undefined4 uStack_114;
  undefined auStack_10c [72];
  undefined4 uStack_c4;
  undefined auStack_bc [72];
  undefined4 auStack_74 [2];
  undefined auStack_6c [72];
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cc447;
  pvStack_10 = ExceptionList;
  iVar10 = 0;
  piVar11 = (int *)0x0;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  if (param_1 == 1) {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_214 = param_2;
    piStack_210 = param_3;
    puStack_218 = auStack_24;
    uStack_21c = 0x959c3d;
    piVar8 = (int *)FUN_009501f0();
    iVar10 = *piVar8;
    piVar11 = (int *)piVar8[1];
    *piVar8 = 0;
    piVar8[1] = 0;
    piStack_14 = piStack_20;
    iStack_1c = iVar10;
    piStack_18 = piVar11;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        piStack_210 = (int *)0x959c72;
        (**(code **)*piStack_20)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_210 = (int *)0x959c83;
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (iVar10 != 0) {
      *(undefined *)(iVar10 + 0xee) = 1;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_1 == 2) {
      ExceptionList = &pvStack_10;
      *param_7 = 4;
    }
  }
  piStack_20 = (int *)appuStack_22c;
  piStack_14 = (int *)param_2;
  puStack_230 = (undefined4 *)param_9;
  uStack_234 = param_8;
  puStack_238 = param_7;
  uStack_23c = param_6;
  uVar9 = *param_5;
  uVar3 = param_5[1];
  uVar4 = param_5[2];
  uVar5 = param_5[3];
  uVar1 = *(undefined8 *)(param_5 + 4);
  if (piVar11 != (int *)0x0) {
    LOCK();
    piVar11[1] = piVar11[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_009427b0(auStack_204,FUN_00953320,param_2,param_3,iVar10,piVar11,param_4,uVar9,uVar3,uVar4,
               uVar5,uVar1);
  uStack_1b4 = auStack_204[0];
  puStack_230 = (undefined4 *)auStack_1fc;
  uStack_234 = 0x959d53;
  FUN_00944dc0();
  uStack_164 = uStack_1b4;
  puStack_230 = (undefined4 *)auStack_1ac;
  appuStack_22c[0] = (undefined **)0x0;
  uStack_234 = 0x959d77;
  FUN_00944dc0();
  uStack_114 = uStack_164;
  puStack_230 = (undefined4 *)auStack_15c;
  uStack_234 = 0x959d95;
  FUN_00944dc0();
  auStack_74[0] = uStack_114;
  puStack_230 = (undefined4 *)auStack_10c;
  uStack_234 = 0x959dad;
  FUN_00944dc0();
  puStack_230 = auStack_74;
  uStack_234 = 0x959db6;
  cVar7 = FUN_00585a40();
  if (cVar7 == '\0') {
    uStack_c4 = auStack_74[0];
    puStack_230 = (undefined4 *)auStack_6c;
    uStack_234 = 0x959dd5;
    FUN_00944dc0();
    puStack_230 = (undefined4 *)0x50;
    uStack_8 = 7;
    uStack_234 = 0x959de0;
    puStack_224 = (undefined4 *)FUN_01674e20();
    if (puStack_224 == (undefined4 *)0x0) {
      puStack_224 = (undefined4 *)0x0;
    }
    else {
      puStack_230 = (undefined4 *)auStack_bc;
      *puStack_224 = uStack_c4;
      uStack_234 = 0x959e00;
      FUN_00944dc0();
    }
    puStack_230 = (undefined4 *)0x959e15;
    FUN_0056b650();
    puStack_230 = (undefined4 *)0x959e1d;
    FUN_0056b650();
    bVar6 = true;
  }
  else {
    puStack_230 = (undefined4 *)0x959e2e;
    FUN_0056b650();
    bVar6 = false;
  }
  puStack_230 = (undefined4 *)0x959e3d;
  FUN_0056b650();
  appuStack_22c[0] = &PTR_FUN_01934d2c;
  if (!bVar6) {
    appuStack_22c[0] = (undefined **)0x0;
  }
  puStack_230 = (undefined4 *)0x959e57;
  FUN_0056b650();
  puStack_230 = (undefined4 *)0x959e62;
  FUN_0056b650();
  puStack_230 = (undefined4 *)0x959e6d;
  FUN_0056b650();
  puStack_230 = (undefined4 *)0x3;
  uStack_234 = piStack_14;
  uStack_8 = 8;
  uVar9 = FUN_005c28f0();
  FUN_0060dcd0(&uStack_23c,uVar9);
  _uStack_8 = CONCAT31(uStack_7,1);
  iVar10 = FUN_00ae4ff0();
  if (piVar11 != (int *)0x0) {
    LOCK();
    piVar8 = piVar11 + 1;
    iVar2 = *piVar8;
    iVar10 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_210 = (int *)0x959eaf;
      (**(code **)*piVar11)();
      LOCK();
      piVar8 = piVar11 + 2;
      iVar2 = *piVar8;
      iVar10 = *piVar8;
      *piVar8 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_210 = (int *)0x959ebf;
        iVar10 = (**(code **)(*piVar11 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar11 = param_3 + 1;
    iVar2 = *piVar11;
    iVar10 = *piVar11;
    *piVar11 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_210 = (int *)0x959ed8;
      iVar10 = (**(code **)*param_3)();
      LOCK();
      piVar11 = param_3 + 2;
      iVar2 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_210 = (int *)0x959ee7;
        iVar10 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 17294 ; VA 0x00959f00 ; FUN_00959f00 */

/* WARNING: Removing unreachable block (ram,0x0095a039) */

undefined4 FUN_00959f00(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  undefined8 uVar7;
  int iStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc47e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888530();
  uStack_8 = 0;
  iStack_e8 = FUN_00888530();
  iStack_e4 = 0;
  uStack_8._0_1_ = 1;
  cVar2 = FUN_009d54a0(1,&iStack_e8);
  iVar3 = iStack_e8;
  if (cVar2 != '\0') {
    if (*(char *)(iStack_e8 + 0x21) != '\0') {
      if (param_1 == 0) {
        iVar3 = 0;
      }
      else {
        iVar3 = *(int *)(param_1 + 0x6c);
      }
      cVar2 = FUN_00973950(*(undefined4 *)(*(int *)(iVar3 + 0xc) + 4),1);
      if (cVar2 != '\0') {
        if (param_1 == 0) {
          iVar3 = 0;
        }
        else {
          iVar3 = *(int *)(param_1 + 0x6c);
        }
        cVar2 = FUN_00983210(*(undefined4 *)(*(int *)(iVar3 + 0xc) + 4));
        if (cVar2 == '\0') {
          uVar7 = FUN_00563790();
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("require(assetId) cannot be called from a client.  assetId = %lld",uVar7);
        }
      }
      FUN_01257280(param_1,0xfffffffe);
      uVar7 = FUN_00563790();
      uVar4 = FUN_0095a2c0(param_1,uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_e4 != 0) {
        (**(code **)(iStack_e4 + 8))(auStack_e0);
      }
      ExceptionList = pvStack_10;
      return uVar4;
    }
    iVar5 = FUN_0088cdc0();
    iVar1 = iStack_e8;
    if (iVar3 == iVar5) {
      iVar3 = FUN_0088cdc0();
      if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar6 = auStack_e0;
      if (iStack_e4 == 0) {
        puVar6 = (undefined *)0x0;
      }
      FUN_009431c0(&iStack_18,puVar6);
      uStack_8._0_1_ = 4;
      if (iStack_18 != 0) {
        FUN_01257280(param_1,0xfffffffe);
        if (iStack_14 != 0) {
          LOCK();
          *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
          UNLOCK();
        }
        uVar4 = FUN_0095a730(param_1,iStack_18,iStack_14);
        FUN_00550b30();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        if (iStack_e4 == 0) {
          ExceptionList = pvStack_10;
          return uVar4;
        }
        (**(code **)(iStack_e4 + 8))(auStack_e0);
        ExceptionList = pvStack_10;
        return uVar4;
      }
      uStack_8._0_1_ = 1;
      FUN_00550b30();
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Attempted to call require with invalid argument(s).");
}



/* FUNCTION 17295 ; VA 0x0095a140 ; FUN_0095a140 */

int FUN_0095a140(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc4a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0094fe20(param_3);
  FUN_009edbb0(uVar3);
  FUN_009ed730();
  FUN_00959110(param_3);
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8._0_1_ = 1;
  FUN_009ed270(&uStack_1c);
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("Requested module experienced an error while loading",0x33);
  uStack_8._0_1_ = 2;
  FUN_0094e0d0(&uStack_1c,auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  if (*(char *)(param_1 + 0xed) != '\0') {
    *(undefined *)(param_1 + 0xed) = 0;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    FUN_00958ae0(param_1,param_2);
  }
  iVar4 = FUN_00946e40();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17296 ; VA 0x0095a2c0 ; FUN_0095a2c0 */

undefined4 FUN_0095a2c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 uVar1;
  int *piVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  char cVar14;
  int iVar15;
  int iVar16;
  undefined4 *puVar17;
  undefined4 uVar18;
  uint uVar19;
  undefined **appuStack_168 [2];
  undefined4 *puStack_160;
  undefined4 uStack_158;
  uint *puStack_154;
  char *pcStack_150;
  char *pcStack_14c;
  char *pcStack_148;
  uint uStack_144;
  int *piStack_140;
  code *pcStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  int iStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  code *pcStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  int aiStack_84 [5];
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc4e8;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    iVar16 = 0;
  }
  else {
    iVar16 = *(int *)(param_1 + 0x6c);
  }
  piStack_140 = &param_2;
  iStack_14 = *(int *)(*(int *)(iVar16 + 0xc) + 4) + 0x1c8;
  uStack_144 = 0x95a307;
  ExceptionList = &pvStack_10;
  iVar15 = FUN_00947e30();
  iVar16 = *(int *)(iVar15 + 8);
  if (iVar16 != 0) {
    if (iVar16 == 1) {
      piStack_140 = (int *)param_1;
      uStack_144 = 0x95a658;
      piStack_140 = (int *)FUN_00d887b0();
      uStack_144 = *(int *)(iVar15 + 0x10);
      uStack_8 = 5;
      if (*(int *)(iVar15 + 0x14) == uStack_144) {
        pcStack_148 = (char *)0x95a67b;
        FUN_0093fe00();
      }
      else {
        uStack_144 = 0x95a66d;
        FUN_00d88710();
        *(int *)(iVar15 + 0x10) = *(int *)(iVar15 + 0x10) + 0x1c;
      }
      uStack_8 = 0xffffffff;
      piStack_140 = (int *)0x95a68a;
      FUN_00d88aa0();
      piStack_140 = (int *)0x0;
      uStack_144 = param_1;
      pcStack_148 = (char *)0x95a692;
      uVar18 = FUN_01258cc0();
      ExceptionList = pvStack_10;
      return uVar18;
    }
    if (iVar16 == 3) {
      piStack_140 = (int *)0x19337ec;
      uStack_144 = param_3;
      pcStack_148 = (char *)param_2;
      pcStack_14c = "Unable to find module for asset id";
      pcStack_150 = "%s %lld.  %s";
                    /* WARNING: Subroutine does not return */
      puStack_154 = (uint *)0x95a70f;
      FUN_016757c0();
    }
    if (iVar16 == 2) {
      pcStack_148 = (char *)(iVar15 + 0x18);
      pcStack_14c = (char *)0x95a6bd;
      FUN_00557fc0();
      pcStack_148 = (char *)param_1;
      pcStack_14c = (char *)0x95a6c3;
      uVar18 = FUN_0095a730();
      ExceptionList = pvStack_10;
      return uVar18;
    }
    if (iVar16 == 4) {
      piStack_140 = (int *)0x193384c;
      uStack_144 = param_3;
      pcStack_148 = (char *)param_2;
      pcStack_14c = "Downloading asset failed for asset id";
      pcStack_150 = "%s %lld.  %s";
                    /* WARNING: Subroutine does not return */
      puStack_154 = (uint *)&UNK_0095a729;
      FUN_016757c0();
    }
    piStack_140 = (int *)param_3;
    uStack_144 = param_2;
    pcStack_148 = "Unknown error with remote module loading asset id %lld";
                    /* WARNING: Subroutine does not return */
    pcStack_14c = (char *)0x95a6eb;
    FUN_016757c0();
  }
  piStack_140 = (int *)param_1;
  *(undefined4 *)(iVar15 + 8) = 1;
  uStack_144 = 0x95a325;
  piStack_140 = (int *)FUN_00d887b0();
  uStack_144 = *(int *)(iVar15 + 0x10);
  uStack_8 = 0;
  if (*(int *)(iVar15 + 0x14) == uStack_144) {
    pcStack_148 = (char *)0x95a348;
    FUN_0093fe00();
  }
  else {
    uStack_144 = 0x95a33a;
    FUN_00d88710();
    *(int *)(iVar15 + 0x10) = *(int *)(iVar15 + 0x10) + 0x1c;
  }
  uStack_8 = 0xffffffff;
  piStack_140 = (int *)0x95a357;
  FUN_00d88aa0();
  if (param_1 == 0) {
    iVar16 = 0;
  }
  else {
    iVar16 = *(int *)(param_1 + 0x6c);
  }
  iVar16 = *(int *)(*(int *)(iVar16 + 0xc) + 4);
  if (iVar16 != 0) {
    iVar15 = *(int *)(iVar16 + 0x34);
    if ((iVar15 != 0) && (iVar16 = iVar15, *(int *)(iVar15 + 0x34) != 0)) {
      piStack_140 = (int *)0x95a382;
      iVar16 = FUN_005c8ac0();
    }
    if (iVar16 != 0) {
      iVar16 = *(int *)(iVar16 + 0xc);
      piStack_140 = (int *)0x95a398;
      iVar15 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar16 + 0x1d8) - (uint)*(ushort *)(iVar15 + 0x1d8) <=
          (uint)*(ushort *)(iVar15 + 0x1da)) {
        piStack_140 = (int *)0x95a3bb;
        puVar17 = (undefined4 *)FUN_005c4070();
        piStack_140 = (int *)*puVar17;
        goto LAB_0095a3c1;
      }
    }
  }
  piStack_140 = (int *)0x0;
LAB_0095a3c1:
  uStack_144 = 0x95a3ca;
  iVar16 = FUN_008f7870();
  piVar2 = *(int **)(iVar16 + 0x43c);
  uStack_144 = piVar2[1] - (int)piVar2;
  pcStack_148 = (char *)(*piVar2 - (int)piVar2);
  puStack_154 = auStack_30;
  pcStack_14c = (char *)param_3;
  pcStack_150 = (char *)param_2;
  uStack_158 = 0x95a3ea;
  piStack_140 = (int *)FUN_00f87770();
  uStack_8 = 1;
  uStack_144 = 0x95a3fd;
  FUN_0054ef60();
  piStack_140 = aiStack_84;
  uStack_8._0_1_ = 2;
  uStack_144 = 0x95a40a;
  FUN_009cbbb0();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_1c) {
    piStack_140 = (int *)(uStack_1c + 1);
    uVar19 = auStack_30[0];
    if (0xfff < piStack_140) {
      uVar19 = *(uint *)(auStack_30[0] - 4);
      piStack_140 = (int *)(uStack_1c + 0x24);
      if (0x1f < (auStack_30[0] - uVar19) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_140 = (int *)0x95a6f0;
        FUN_017167a3();
      }
    }
    pcStack_148 = (char *)0x95a442;
    uStack_144 = uVar19;
    FUN_01674ea0();
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  piStack_140 = (int *)0x95a45c;
  puStack_18 = (undefined *)FUN_008ccd60();
  piStack_140 = &param_2;
  uStack_144 = 0x95a46b;
  iVar16 = FUN_00947e30();
  piStack_140 = (int *)param_1;
  iVar16 = iVar16 + 8;
  uStack_144 = 0x95a474;
  iStack_14 = FUN_0094fe20();
  piStack_140 = (int *)0x95a47f;
  puVar17 = (undefined4 *)FUN_01255560();
  if (param_1 == 0) {
    iVar15 = 0;
  }
  else {
    iVar15 = *(int *)(param_1 + 0x6c);
  }
  uStack_f4 = *puVar17;
  uStack_f0 = puVar17[1];
  uStack_ec = puVar17[2];
  uStack_e8 = puVar17[3];
  pcStack_c4 = FUN_00959bd0;
  uStack_fc = *(undefined4 *)(*(int *)(iVar15 + 0xc) + 4);
  uVar1 = *(undefined8 *)(puVar17 + 4);
  uStack_4c = iStack_14;
  uStack_b8 = uStack_68;
  uStack_3c = param_2;
  uStack_54._0_4_ = (undefined4)uVar1;
  uStack_54._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
  uStack_38 = param_3;
  uStack_a4 = (undefined4)uStack_54;
  uStack_a0 = uStack_54._4_4_;
  piStack_140 = (int *)0x1;
  uStack_144 = 3;
  pcStack_148 = puStack_18;
  uStack_9c = iStack_14;
  uStack_98 = uStack_48;
  uStack_90 = uStack_40;
  puStack_18 = (undefined *)appuStack_168;
  uStack_8c = CONCAT44(param_3,param_2);
  pcStack_104 = FUN_00959bd0;
  uStack_100 = uStack_c0;
  uStack_f8 = uStack_68;
  appuStack_168[0] = (undefined **)0x0;
  uStack_e4 = (undefined4)uStack_54;
  uStack_e0 = uStack_54._4_4_;
  uStack_dc = iStack_14;
  uStack_d8 = uStack_48;
  uStack_d0 = uStack_40;
  uStack_cc = param_2;
  uStack_c8 = param_3;
  iStack_d4 = iVar16;
  uStack_bc = uStack_fc;
  uStack_b4 = uStack_f4;
  uStack_b0 = uStack_f0;
  uStack_ac = uStack_ec;
  uStack_a8 = uStack_e8;
  iStack_94 = iVar16;
  uStack_6c = uStack_fc;
  uStack_64 = uStack_f4;
  uStack_60 = uStack_f0;
  uStack_5c = uStack_ec;
  uStack_58 = uStack_e8;
  uStack_54 = uVar1;
  iStack_44 = iVar16;
  cVar14 = FUN_00585a40(&pcStack_104);
  uVar13 = uStack_d8;
  uVar12 = uStack_dc;
  uVar11 = uStack_e0;
  uVar10 = uStack_e4;
  uVar9 = uStack_e8;
  uVar8 = uStack_ec;
  uVar7 = uStack_f0;
  uVar6 = uStack_f4;
  uVar5 = uStack_f8;
  uVar4 = uStack_fc;
  uVar18 = uStack_100;
  pcVar3 = pcStack_104;
  if (cVar14 == '\0') {
    iStack_44 = iStack_d4;
    uStack_40 = uStack_d0;
    uStack_3c = uStack_cc;
    uStack_38 = uStack_c8;
    puStack_160 = (undefined4 *)FUN_01674e20(0x40);
    if (puStack_160 == (undefined4 *)0x0) {
      appuStack_168[0] = &PTR_FUN_01934d48;
      puStack_160 = (undefined4 *)0x0;
    }
    else {
      *puStack_160 = pcVar3;
      puStack_160[1] = uVar18;
      puStack_160[2] = uVar4;
      puStack_160[3] = uVar5;
      puStack_160[4] = uVar6;
      puStack_160[5] = uVar7;
      puStack_160[6] = uVar8;
      puStack_160[7] = uVar9;
      puStack_160[8] = uVar10;
      puStack_160[9] = uVar11;
      puStack_160[10] = uVar12;
      puStack_160[0xb] = uVar13;
      puStack_160[0xc] = iStack_44;
      puStack_160[0xd] = uStack_40;
      puStack_160[0xe] = uStack_3c;
      puStack_160[0xf] = uStack_38;
      appuStack_168[0] = &PTR_FUN_01934d48;
    }
  }
  else {
    appuStack_168[0] = (undefined **)0x0;
  }
  FUN_008d0b40(aiStack_84,0x41f00000);
  piStack_140 = (int *)0x0;
  uStack_144 = param_1;
  pcStack_148 = (char *)0x95a5fc;
  uVar18 = FUN_01258cc0();
  if (0xf < uStack_70) {
    piStack_140 = (int *)(uStack_70 + 1);
    iVar16 = aiStack_84[0];
    if (0xfff < piStack_140) {
      iVar16 = *(int *)(aiStack_84[0] + -4);
      piStack_140 = (int *)(uStack_70 + 0x24);
      if (0x1f < (aiStack_84[0] - iVar16) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_140 = (int *)0x95a6f5;
        FUN_017167a3();
      }
    }
    pcStack_148 = (char *)0x95a632;
    uStack_144 = iVar16;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return uVar18;
}



/* FUNCTION 17297 ; VA 0x0095a730 ; FUN_0095a730 */

undefined4 FUN_0095a730(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 in_stack_ffffff74;
  int in_stack_ffffff78;
  undefined4 in_stack_ffffff7c;
  undefined4 *in_stack_ffffff80;
  int iVar5;
  undefined4 uVar6;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [8];
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cc518;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_0094fe20(param_1);
  uStack_14 = FUN_009edbb0(puStack_18);
  iStack_20 = FUN_005817e0();
  if (DAT_01d64518 != '\0') {
    FUN_012561a0(param_1,0xffffd8ee,"script");
    uStack_28 = 0;
    piStack_24 = (int *)0x0;
    in_stack_ffffff80 = &uStack_28;
    iStack_8._0_1_ = 1;
    in_stack_ffffff7c = 0xffffffff;
    in_stack_ffffff74 = 0x95a7b6;
    in_stack_ffffff78 = param_1;
    cVar2 = FUN_00da4680(param_1,0xffffffff,in_stack_ffffff80);
    if (cVar2 != '\0') {
      FUN_009431c0(&iStack_30,&uStack_28);
      iStack_8._0_1_ = 2;
      if (iStack_30 != 0) {
        iStack_1c = iStack_30;
        in_stack_ffffff7c = 0x95a7f7;
        FUN_00898570(auStack_38,0,&iStack_1c,param_3);
        in_stack_ffffff80 = (undefined4 *)0x95a814;
        cVar2 = FUN_009537a0(puStack_18,iStack_30,param_2);
        if (cVar2 != '\0') {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Requested module was required recursively");
        }
      }
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          iVar5 = piStack_2c[2] + -1;
          piStack_2c[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
    piVar3 = piStack_24;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (param_1 == 0) {
    in_stack_ffffff80 = (undefined4 *)0x0;
    in_stack_ffffff7c = 0x95a8a1;
    piVar3 = (int *)FUN_01255470(0,0,0,0);
  }
  else {
    iVar5 = *(int *)(param_1 + 0x6c);
    iStack_50 = *(int *)(iVar5 + 0x18);
    uStack_4c = *(undefined4 *)(iVar5 + 0x1c);
    uStack_48 = *(undefined4 *)(iVar5 + 0x20);
    uStack_44 = *(undefined4 *)(iVar5 + 0x24);
    piVar3 = &iStack_50;
    uStack_40 = *(undefined8 *)(iVar5 + 0x28);
  }
  iStack_68 = *piVar3;
  iStack_64 = piVar3[1];
  iStack_60 = piVar3[2];
  iStack_5c = piVar3[3];
  uVar6 = 5;
  uStack_58 = *(undefined8 *)(piVar3 + 4);
  piVar3 = &iStack_68;
  iVar5 = 0x95a8bd;
  cVar2 = FUN_01255580(piVar3,5);
  if ((cVar2 != '\0') && (*(char *)(param_2 + 0xec) == '\0')) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Cannot require a non-RobloxScript module from a RobloxScript");
  }
  iVar4 = iStack_20;
  if (iStack_20 == 0) {
    if (param_1 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = *(int *)(param_1 + 0x6c);
    }
    iStack_1c = *(int *)(*(int *)(iVar5 + 0xc) + 4);
    iStack_20 = CONCAT31((int3)((uint)iStack_1c >> 8),*(undefined *)(param_1 + 7));
    in_stack_ffffff7c = FUN_01255560();
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    in_stack_ffffff78 = 0x95a934;
    in_stack_ffffff80 = puStack_18;
    piVar3 = param_3;
    FUN_0095ccc0(in_stack_ffffff7c,puStack_18,param_2,param_3,iStack_20);
    uVar6 = 0x95a93c;
    iVar4 = FUN_005817e0();
    iVar5 = param_2;
  }
  if (iVar4 == 3) {
    uVar6 = FUN_00615970();
    FUN_01256cb0(param_1,0xffffd8f0,uVar6);
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar5 = param_3[1] + -1;
      param_3[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar3 = param_3 + 2;
        iVar5 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (iVar4 == 2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Requested module experienced an error while loading");
  }
  if (iVar4 == 1) {
    FUN_00d887b0(param_1);
    FUN_009ece40(in_stack_ffffff74,in_stack_ffffff78,in_stack_ffffff7c,in_stack_ffffff80,iVar5,
                 piVar3,uVar6);
    uVar6 = FUN_01258cc0(param_1,0);
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return uVar6;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unknown module state: %d",iVar4);
}



/* FUNCTION 17298 ; VA 0x0095aa00 ; FUN_0095aa00 */

int FUN_0095aa00(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc540;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_3);
  if (iVar3 == 1) {
    uVar4 = FUN_01258150(param_3,0xffffd8f0);
    uVar5 = FUN_0094fe20(param_3);
    FUN_009edbb0(uVar5);
    FUN_009ed780(uVar5,uVar4);
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_009ed270(&uStack_20);
    FUN_0095bd50(&uStack_20,uVar4);
    if (*(char *)(param_1 + 0xed) != '\0') {
      *(undefined *)(param_1 + 0xed) = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      FUN_00958ae0(param_1,param_2);
    }
    iVar3 = FUN_00946e40();
  }
  else {
    FUN_0086f2f0(3,"Module code did not return exactly one value");
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar3 = FUN_0095a140(param_1,param_2,param_3);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17299 ; VA 0x0095ab70 ; FUN_0095ab70 */

void __thiscall FUN_0095ab70(int *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *param_1;
  *param_1 = param_2;
  if (iVar1 != 0) {
    FUN_008c3510();
    FUN_01674ea0(iVar1,0x40);
  }
  return;
}



/* FUNCTION 17300 ; VA 0x0095aba0 ; FUN_0095aba0 */

undefined4 __thiscall FUN_0095aba0(int param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined *puVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  char *pcVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  undefined8 uVar12;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  int *piStack_34;
  int *piStack_30;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017cc590;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff60;
  iStack_8 = 0;
  if (param_2 == (int *)0x0) {
    iVar10 = 0;
  }
  else {
    iVar10 = param_2[2];
  }
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  puVar4 = &stack0xffffff60;
  if (DAT_01d64498 != '\0') {
    ExceptionList = &pvStack_10;
    iVar6 = FUN_008f7870(param_1);
    if ((iVar6 != 0) && (cVar5 = FUN_008f2030(), cVar5 != '\0')) {
      if (iVar10 == 0) {
        iVar10 = 0;
      }
      else {
        iVar10 = *(int *)(iVar10 + 0x6c);
      }
      puVar4 = puStack_14;
      if (*(int *)(*(int *)(iVar10 + 0xc) + 4) == param_1) goto LAB_0095ac27;
    }
    FUN_01675310("InvalidAccess",&DAT_018bc9b8);
    puVar4 = puStack_14;
  }
LAB_0095ac27:
  puStack_14 = puVar4;
  if ((param_2 == (int *)0x0) || (param_2[2] == 0)) {
    iStack_18 = 0;
  }
  else {
    iStack_18 = *(int *)(param_2[2] + 0x6c);
  }
  FUN_00587490(&piStack_34);
  iStack_8._0_1_ = 1;
  if ((param_2 == (int *)0x0) || (param_2[2] == 0)) {
    puVar7 = (undefined4 *)FUN_01255470(0,0,0,0);
  }
  else {
    iVar10 = *(int *)(param_2[2] + 0x6c);
    uStack_4c = *(undefined4 *)(iVar10 + 0x18);
    uStack_48 = *(undefined4 *)(iVar10 + 0x1c);
    uStack_44 = *(undefined4 *)(iVar10 + 0x20);
    uStack_40 = *(undefined4 *)(iVar10 + 0x24);
    puVar7 = &uStack_4c;
    uStack_3c = *(undefined8 *)(iVar10 + 0x28);
  }
  FUN_01255490(*puVar7,puVar7[1],puVar7[2],puVar7[3],puVar7[4],puVar7[5]);
  iStack_8._0_1_ = 2;
  uVar3 = (undefined)iStack_8;
  iStack_8._0_1_ = 2;
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar10 + 0x34) < DAT_01ee2b60) &&
     (iStack_8._0_1_ = uVar3, FUN_016f3809(&DAT_01ee2b60), DAT_01ee2b60 == -1)) {
    iStack_8._0_1_ = 3;
    uVar12 = FUN_0152dab0(&DAT_0191e450,"$Script",0xffffffff);
    DAT_01ee2b5c = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ee2b58 = (undefined4)uVar12;
    iStack_8._0_1_ = 2;
    FUN_016f37bf(&DAT_01ee2b60);
  }
  uStack_20 = DAT_01ee2b58;
  uStack_44 = DAT_01ee2b58;
  uStack_1c = DAT_01ee2b5c;
  uStack_40 = DAT_01ee2b5c;
  uStack_3c = FUN_0152d930(DAT_01ee2b58,DAT_01ee2b5c);
  iStack_8._0_1_ = 4;
  if ((*(int *)(iVar10 + 0x34) < DAT_01ee2b70) && (FUN_016f3809(&DAT_01ee2b70), DAT_01ee2b70 == -1))
  {
    iStack_8._0_1_ = 5;
    uVar12 = FUN_0152da50(&DAT_0191e450);
    DAT_01ee2b6c = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01ee2b68 = (undefined4)uVar12;
    iStack_8._0_1_ = 4;
    FUN_016f37bf(&DAT_01ee2b70);
  }
  if (piStack_34 == (int *)0x0) {
    pcVar8 = "Unknown";
  }
  else {
    pcVar8 = (char *)piStack_34[10];
    if (0xf < *(uint *)((int)pcVar8 + 0x14)) {
      pcVar8 = *(char **)pcVar8;
    }
  }
  FUN_0152d740(DAT_01ee2b68,DAT_01ee2b6c,pcVar8);
  puVar7 = *(undefined4 **)(param_1 + 0x2a4);
  iStack_24 = 0;
  if (*(undefined4 **)(param_1 + 0x2a8) == puVar7) {
    FUN_0063d9b0(puVar7,&iStack_24);
  }
  else {
    *puVar7 = 0;
    *(int *)(param_1 + 0x2a4) = *(int *)(param_1 + 0x2a4) + 4;
  }
  iStack_24 = *(int *)(param_1 + 400);
  if ((iStack_24 != 0) && (piStack_34 != (int *)0x0)) {
    uVar9 = (**(code **)(*piStack_34 + 0xac))();
    FUN_00f86be0(uVar9);
  }
  if (DAT_01ee4208 != '\0') {
    FUN_016774b0(DAT_01ee4208,"Resuming script: %p",piStack_34);
  }
  if ((piStack_34 != (int *)0x0) && (DAT_01ee4208 != '\0')) {
    FUN_01677760(DAT_01ee4208,"Pending script name: %s",piStack_34[10]);
  }
  if (param_2 == (int *)0x0) {
    iVar10 = 0;
  }
  else {
    iVar10 = param_2[2];
  }
  iVar10 = FUN_0095b200(iVar10,param_3,param_4);
  piVar1 = *(int **)(iStack_18 + 0x3c);
  if (piVar1 != (int *)0x0) {
    if (iVar10 == 0) {
      if (*piVar1 != 0) {
        iStack_8 = CONCAT31(iStack_8._1_3_,6);
        if (param_2 == (int *)0x0) {
          FUN_008927d0(0);
          uVar9 = FUN_0095aed6();
          return uVar9;
        }
        FUN_008927d0(param_2[2]);
        uVar9 = FUN_0095aed6();
        return uVar9;
      }
    }
    else if (((iVar10 != 1) && (iVar10 != 6)) && (piVar1[8] != 0)) {
      if (param_2 == (int *)0x0) {
        FUN_008927d0(0);
      }
      else {
        FUN_008927d0(param_2[2]);
      }
    }
  }
  if ((*(int *)(param_1 + 400) != 0) && (piStack_34 != (int *)0x0)) {
    uVar9 = (**(code **)(*piStack_34 + 0xac))();
    FUN_00f86cc0(uVar9);
  }
  if ((uint)(*(int *)(param_1 + 0x2a4) - *(int *)(param_1 + 0x2a0)) < 4) {
    if (DAT_01ee4208 != '\0') {
      FUN_016774b0(DAT_01ee4208,
                   "ScriptContext_PopActiveRegionsStackForResumeContext has no top element",0);
    }
  }
  else {
    iVar6 = *(int *)(*(int *)(param_1 + 0x2a4) + -4);
    cVar5 = DAT_01ee4208;
    if (0 < iVar6) {
      do {
        iVar11 = *(int *)(param_1 + 0x2a4) - *(int *)(param_1 + 0x2a0) >> 2;
        if (iVar11 == 0) {
          if (cVar5 != '\0') {
            FUN_016774b0(cVar5,"popProfilerUserActiveRegion - No active resume context.",0);
            cVar5 = DAT_01ee4208;
          }
        }
        else {
          iVar11 = *(int *)(param_1 + 0x2a0) + iVar11 * 4;
          iVar2 = *(int *)(iVar11 + -4);
          if (iVar2 == 0) {
            if (cVar5 != '\0') {
              FUN_016774b0(cVar5,
                           "popProfilerUserActiveRegion - No active profile annotation for context."
                           ,0);
              cVar5 = DAT_01ee4208;
            }
          }
          else {
            *(int *)(iVar11 + -4) = iVar2 + -1;
            iVar11 = *(int *)(param_1 + 0x2b0);
            FUN_0152dda0(*(undefined4 *)(iVar11 + -0x10),*(undefined4 *)(iVar11 + -0xc),
                         *(undefined4 *)(iVar11 + -8),*(undefined4 *)(iVar11 + -4));
            *(int *)(param_1 + 0x2b0) = *(int *)(param_1 + 0x2b0) + -0x10;
            cVar5 = DAT_01ee4208;
          }
        }
        iVar6 = iVar6 + -1;
      } while (iVar6 != 0);
    }
    *(int *)(param_1 + 0x2a4) = *(int *)(param_1 + 0x2a4) + -4;
  }
  iStack_8._0_1_ = 9;
  FUN_0152dda0(uStack_20,uStack_1c,(undefined4)uStack_3c,uStack_3c._4_4_);
  FUN_01255500();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar6 = piStack_30[2] + -1;
      piStack_30[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (iVar10 == 0) {
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar10 = *param_2;
      *param_2 = *param_2 + -1;
      UNLOCK();
      if ((iVar10 == 1) && (param_2 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(param_2,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return 0;
  }
  if ((iVar10 != 1) && (iVar10 != 6)) {
    if ((*(int *)(iStack_18 + 0x3c) == 0) || (*(int *)(*(int *)(iStack_18 + 0x3c) + 0x20) == 0)) {
      if (param_2 == (int *)0x0) {
        iVar10 = 0;
      }
      else {
        iVar10 = param_2[2];
      }
      FUN_00959110(iVar10);
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar10 = *param_2;
      *param_2 = *param_2 + -1;
      UNLOCK();
      if ((iVar10 == 1) && (param_2 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(param_2,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return 2;
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar10 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if ((iVar10 == 1) && (param_2 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17301 ; VA 0x0095ae61 ; Catch@0095ae61 */

undefined * Catch_0095ae61(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x28) + 4))();
  FUN_0054eff0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 8;
  if (*(int *)(unaff_EBP + 8) == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 8);
  }
  FUN_0087de50(uVar1,unaff_EBP + -0x60);
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_005507b0();
  if (*(int *)(*(int *)(unaff_EBP + 0xc) + 0x20) != 0) {
    if (*(int *)(unaff_EBP + 8) == 0) {
      uVar1 = 0;
    }
    else {
      uVar1 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 8);
    }
    FUN_008927d0(uVar1);
  }
  return &DAT_0095aec4;
}



/* FUNCTION 17302 ; VA 0x0095aed6 ; FUN_0095aed6 */

undefined4 FUN_0095aed6(void)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  char cVar7;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  int iVar8;
  
  *(undefined4 *)(unaff_EBP + -4) = 4;
  iVar8 = *(int *)(unaff_ESI + 400);
  *(int *)(unaff_EBP + 0xc) = iVar8;
  if ((iVar8 != 0) && (unaff_EDI != (int *)0x0)) {
    uVar5 = (**(code **)(*unaff_EDI + 0xac))();
    FUN_00f86cc0(uVar5);
  }
  if ((uint)(*(int *)(unaff_ESI + 0x2a4) - *(int *)(unaff_ESI + 0x2a0)) < 4) {
    if (DAT_01ee4208 != '\0') {
      FUN_016774b0(DAT_01ee4208,
                   "ScriptContext_PopActiveRegionsStackForResumeContext has no top element",0);
    }
  }
  else {
    iVar8 = *(int *)(*(int *)(unaff_ESI + 0x2a4) + -4);
    cVar7 = DAT_01ee4208;
    if (0 < iVar8) {
      do {
        iVar6 = *(int *)(unaff_ESI + 0x2a4) - *(int *)(unaff_ESI + 0x2a0) >> 2;
        if (iVar6 == 0) {
          if (cVar7 != '\0') {
            FUN_016774b0(cVar7,"popProfilerUserActiveRegion - No active resume context.",0);
            cVar7 = DAT_01ee4208;
          }
        }
        else {
          iVar6 = *(int *)(unaff_ESI + 0x2a0) + iVar6 * 4;
          iVar1 = *(int *)(iVar6 + -4);
          if (iVar1 == 0) {
            if (cVar7 != '\0') {
              FUN_016774b0(cVar7,
                           "popProfilerUserActiveRegion - No active profile annotation for context."
                           ,0);
              cVar7 = DAT_01ee4208;
            }
          }
          else {
            *(int *)(iVar6 + -4) = iVar1 + -1;
            iVar6 = *(int *)(unaff_ESI + 0x2b0);
            FUN_0152dda0(*(undefined4 *)(iVar6 + -0x10),*(undefined4 *)(iVar6 + -0xc),
                         *(undefined4 *)(iVar6 + -8),*(undefined4 *)(iVar6 + -4));
            *(int *)(unaff_ESI + 0x2b0) = *(int *)(unaff_ESI + 0x2b0) + -0x10;
            cVar7 = DAT_01ee4208;
          }
        }
        iVar8 = iVar8 + -1;
      } while (iVar8 != 0);
    }
    *(int *)(unaff_ESI + 0x2a4) = *(int *)(unaff_ESI + 0x2a4) + -4;
  }
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x18),
               *(undefined4 *)(unaff_EBP + -0x38),*(undefined4 *)(unaff_EBP + -0x34));
  FUN_01255500();
  puVar2 = *(undefined4 **)(unaff_EBP + -0x2c);
  *(undefined *)(unaff_EBP + -4) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    iVar8 = puVar2[1] + -1;
    puVar2[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*puVar2)();
      piVar3 = *(int **)(unaff_EBP + -0x2c);
      LOCK();
      piVar4 = piVar3 + 2;
      iVar8 = *piVar4 + -1;
      *piVar4 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar8 = *(int *)(unaff_EBP + 0x10);
  if (iVar8 == 0) {
    piVar4 = *(int **)(unaff_EBP + 8);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if ((iVar8 == 1) && (piVar4 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(piVar4,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return 0;
  }
  if ((iVar8 != 1) && (iVar8 != 6)) {
    iVar8 = *(int *)(*(int *)(unaff_EBP + -0x14) + 0x3c);
    if ((iVar8 == 0) || (*(int *)(iVar8 + 0x20) == 0)) {
      if (*(int *)(unaff_EBP + 8) == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = *(undefined4 *)(*(int *)(unaff_EBP + 8) + 8);
      }
      FUN_00959110(uVar5);
    }
    piVar4 = *(int **)(unaff_EBP + 8);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar8 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if ((iVar8 == 1) && (piVar4 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(piVar4,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return 2;
  }
  piVar4 = *(int **)(unaff_EBP + 8);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar8 = *piVar4;
    *piVar4 = *piVar4 + -1;
    UNLOCK();
    if ((iVar8 == 1) && (piVar4 != (int *)0x0)) {
      FUN_00d88950();
      FUN_01674ea0(piVar4,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 1;
}



/* FUNCTION 17303 ; VA 0x0095b200 ; FUN_0095b200 */

undefined4 __thiscall FUN_0095b200(int param_1,int param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  double *pdVar7;
  undefined4 uVar8;
  char *pcVar9;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc5a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d64498 != '\0') {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008f7870(param_1);
    if (iVar3 != 0) {
      cVar2 = FUN_008f2030();
      if (cVar2 != '\0') {
        if (param_2 == 0) {
          iVar3 = 0;
        }
        else {
          iVar3 = *(int *)(param_2 + 0x6c);
        }
        if (*(int *)(*(int *)(iVar3 + 0xc) + 4) == param_1) goto LAB_0095b269;
      }
    }
    FUN_01675310("InvalidAccess",&DAT_018bc9b8);
  }
LAB_0095b269:
  iVar3 = FUN_01689e40(&DAT_01ee2aa4);
  if (iVar3 == 0) {
    puVar4 = (undefined4 *)FUN_01674e20(4);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = 0;
    }
    puVar5 = (undefined4 *)FUN_01689e40(&DAT_01ee2aa4);
    iVar3 = DAT_01ee2aa8;
    uVar8 = DAT_01ee2aa4;
    if (puVar5 != puVar4) {
      if (DAT_01ee2aa8 != 0) {
        LOCK();
        *(int *)(DAT_01ee2aa8 + 4) = *(int *)(DAT_01ee2aa8 + 4) + 1;
        UNLOCK();
      }
      FUN_0168a720(&DAT_01ee2aa4,uVar8,iVar3,puVar4,1);
    }
  }
  piVar6 = (int *)FUN_01689e40(&DAT_01ee2aa4);
  if (*piVar6 < 0xc9) {
    piVar6 = (int *)FUN_01689e40(&DAT_01ee2aa4);
    iVar3 = *piVar6;
    piStack_18 = (int *)FUN_01689e40(&DAT_01ee2aa4);
    iVar1 = *piStack_18;
    *piStack_18 = iVar3 + 1;
    uStack_8 = 0;
    iStack_14 = iVar1;
    if (*(char *)(param_1 + 0x1b8) != '\0') {
      pdVar7 = (double *)FUN_016827e0(&uStack_20);
      if (*(double *)(param_1 + 0x1c0) <= *pdVar7 && *pdVar7 != *(double *)(param_1 + 0x1c0)) {
        FUN_016795b0();
        FUN_016795b0();
        pcVar9 = PTR_DAT_01d64548;
        do {
          cVar2 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar2 != '\0');
        FUN_01256930(param_2,PTR_DAT_01d64548,(int)pcVar9 - (int)(PTR_DAT_01d64548 + 1));
        *piStack_18 = iVar1;
        ExceptionList = pvStack_10;
        return 2;
      }
    }
    piVar6 = (int *)FUN_01689e40(&DAT_01ee2aa4);
    if (*piVar6 == 1) {
      puVar4 = (undefined4 *)FUN_016830f0(&uStack_20);
      *(undefined4 *)(param_1 + 0x390) = *puVar4;
      *(undefined4 *)(param_1 + 0x394) = puVar4[1];
    }
    piVar6 = (int *)FUN_01689e40(&DAT_01ee2aa4);
    if (*piVar6 == 1) {
      FUN_016827e0(&uStack_20);
      *(undefined4 *)(param_1 + 0x268) = uStack_20;
      *(undefined4 *)(param_1 + 0x26c) = uStack_1c;
    }
    if (param_4 == (undefined4 *)0x0) {
      uVar8 = FUN_01258a50(param_2,0,param_3);
    }
    else {
      puVar4 = param_4 + 4;
      if (0xf < (uint)param_4[5]) {
        param_4 = (undefined4 *)*param_4;
      }
      FUN_01256930(param_2,param_4,*puVar4);
      uVar8 = FUN_01258b90(param_2,0);
    }
    piVar6 = (int *)FUN_01689e40(&DAT_01ee2aa4);
    if (*piVar6 == 1) {
      pdVar7 = (double *)FUN_016827e0(&uStack_20);
      *(double *)(param_1 + 0x270) =
           (*pdVar7 - *(double *)(param_1 + 0x268)) * DAT_018c0d70 + *(double *)(param_1 + 0x270);
    }
    *piStack_18 = iVar1;
    ExceptionList = pvStack_10;
    return uVar8;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("C stack overflow");
}



/* FUNCTION 17304 ; VA 0x0095b4a0 ; FUN_0095b4a0 */

void FUN_0095b4a0(int *param_1,undefined4 param_2,uint param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_38 [24];
  undefined auStack_20 [12];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc5d8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_8 = 1;
  if (param_1 == (int *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = param_1[2];
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_009d5c60(param_2,iVar2);
  if (param_1 != (int *)0x0) {
    LOCK();
    *param_1 = *param_1 + 1;
    UNLOCK();
  }
  iVar2 = FUN_0095aba0(param_1,uVar1,0);
  if (iVar2 == 0) {
    if (param_3 != 0) {
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (param_1 == (int *)0x0) {
        iVar2 = 0;
      }
      else {
        iVar2 = param_1[2];
      }
      uVar1 = FUN_01256300(iVar2);
      if (param_1 == (int *)0x0) {
        iVar2 = 0;
      }
      else {
        iVar2 = param_1[2];
      }
      FUN_00949060(iVar2,uVar1);
      uStack_8 = 1;
    }
    if (param_1 == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      iVar2 = param_1[2];
    }
    FUN_01257280(iVar2,0);
    if (param_1 != (int *)0x0) {
      LOCK();
      iVar2 = *param_1;
      *param_1 = *param_1 + -1;
      UNLOCK();
      if ((iVar2 == 1) && (param_1 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(param_1,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    uStack_8 = 4;
  }
  else if (iVar2 == 1) {
    if (param_3 != 0) {
      if (param_1 == (int *)0x0) {
        iVar2 = 0;
      }
      else {
        iVar2 = param_1[2];
      }
      FUN_00949060(iVar2,0);
    }
    if (param_1 != (int *)0x0) {
      LOCK();
      iVar2 = *param_1;
      *param_1 = *param_1 + -1;
      UNLOCK();
      if ((iVar2 == 1) && (param_1 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(param_1,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    uStack_8 = 5;
  }
  else if (iVar2 == 2) {
    if (param_3 != 0) {
      uVar1 = FUN_00764410(0xffffffff);
      uVar1 = FUN_00881a60(uVar1);
      FUN_0054eff0(uVar1);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uVar1 = FUN_00764410(0);
      FUN_01257280(uVar1);
      FUN_005500e0(auStack_38);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    if (param_1 == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      iVar2 = param_1[2];
    }
    FUN_01257280(iVar2,0);
    FUN_0089b430();
    uStack_8 = 7;
  }
  else {
    if (param_1 != (int *)0x0) {
      LOCK();
      iVar2 = *param_1;
      *param_1 = *param_1 + -1;
      UNLOCK();
      if ((iVar2 == 1) && (param_1 != (int *)0x0)) {
        FUN_00d88950();
        FUN_01674ea0(param_1,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    uStack_8 = 8;
  }
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17305 ; VA 0x0095b6f4 ; Catch@0095b6f4 */

void Catch_0095b6f4(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_00764410(0);
  FUN_01257280(uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17306 ; VA 0x0095b720 ; FUN_0095b720 */

void __fastcall FUN_0095b720(int param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined8 uStack_130;
  undefined2 uStack_128;
  undefined auStack_120 [4];
  int *piStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined **appuStack_100 [2];
  int aiStack_f8 [4];
  int iStack_e8;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  int iStack_d0;
  undefined auStack_cc [12];
  int iStack_c0;
  int iStack_bc;
  undefined auStack_b8 [12];
  int iStack_ac;
  int iStack_a8;
  undefined auStack_a4 [12];
  int iStack_98;
  int iStack_94;
  undefined auStack_90 [12];
  int iStack_84;
  int iStack_80;
  undefined auStack_7c [12];
  int iStack_70;
  int iStack_6c;
  undefined auStack_68 [12];
  int iStack_5c;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  undefined *puStack_4c;
  int *piStack_48;
  int iStack_44;
  uint uStack_3c;
  int iStack_38;
  int *piStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  bool bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc665;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_110 = FUN_01675290(DAT_01ee2a70);
  iStack_8 = 0;
  uStack_50 = uStack_110;
  if (DAT_01ee4208 != '\0') {
    FUN_016774b0(DAT_01ee4208,"ScriptContext::resumeParallelWaitingScripts start",0);
  }
  iVar5 = FUN_008f7870(param_1);
  puStack_4c = (undefined *)(iVar5 + 0xd0);
  LOCK();
  *puStack_4c = 1;
  UNLOCK();
  if (*(int *)(param_1 + 0x16c) == 0) {
    uStack_134 = 0;
    uStack_130 = DAT_018c45c8;
    uStack_128 = 1;
    uStack_138 = 0;
    uStack_58 = 0;
    piStack_54 = (int *)0x0;
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    puVar6 = (undefined4 *)FUN_0151d9e0(auStack_120,&uStack_58,10,&uStack_138);
    uStack_114 = *puVar6;
    uStack_118 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x16c) = uStack_114;
    piStack_18 = *(int **)(param_1 + 0x170);
    *(undefined4 *)(param_1 + 0x170) = uStack_118;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar5 = piStack_18[2] + -1;
        piStack_18[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_11c;
    if (piStack_11c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_11c[1] + -1;
      piStack_11c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_11c)();
        LOCK();
        iVar5 = piStack_18[2] + -1;
        piStack_18[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    piStack_18 = piStack_54;
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_54[1] + -1;
      piStack_54[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        piVar7 = piStack_18 + 2;
        iVar5 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uStack_1c = 0;
  uStack_e0 = 0;
  uStack_dc = 0;
  uStack_d8 = 0;
  uStack_d4 = 0;
  uStack_10c = 0;
  uStack_108 = 0;
  uStack_104 = 0;
  FUN_0094a0d0();
  iStack_8._0_1_ = 2;
  FUN_00945500(0,&uStack_e0,&bStack_11);
  FUN_0094a0d0();
  uStack_3c = 0;
  iStack_38 = 0;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_30 = (int *)0x0;
  uStack_2c = 0;
  iStack_28 = 0;
  iStack_8._0_1_ = 4;
  if (0 < *(int *)(param_1 + 0x164)) {
    puVar1 = (uint *)(param_1 + 0x168);
    iStack_24 = *(int *)(param_1 + 0x164);
    do {
      iStack_24 = iStack_24 + -1;
      do {
        LOCK();
        uVar2 = *puVar1;
        *puVar1 = *puVar1 | 1;
        UNLOCK();
      } while ((uVar2 & 1) != 0);
      if (*(int *)(param_1 + 0x164) == 0) {
        *puVar1 = 0;
        break;
      }
      puVar6 = *(undefined4 **)(param_1 + 0x154);
      if (puVar6 != (undefined4 *)0x0) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_00947ad0(*(undefined4 *)(puVar6[1] + (puVar6[2] - 1 & *(uint *)(param_1 + 0x160)) * 4));
      FUN_00947910();
      piVar7 = (int *)(param_1 + 0x164);
      *piVar7 = *piVar7 + -1;
      if (*piVar7 == 0) {
        *(undefined4 *)(param_1 + 0x160) = 0;
      }
      else {
        *(int *)(param_1 + 0x160) = *(int *)(param_1 + 0x160) + 1;
      }
      *puVar1 = 0;
      if (piStack_30 == (int *)0x0) {
        iVar5 = 0;
      }
      else {
        iVar5 = piStack_30[2];
      }
      piStack_18 = *(int **)(iVar5 + 0x10);
      if ((uint)((iStack_44 - (int)piStack_48 >> 4) * 3) >> 2 <= uStack_3c) {
        FUN_009586d0();
      }
      iVar5 = FUN_009512f0(&piStack_18);
      puVar6 = *(undefined4 **)(iVar5 + 8);
      iStack_20 = iVar5 + 4;
      if (*(undefined4 **)(iVar5 + 0xc) == puVar6) {
        FUN_0093fa00(puVar6,&piStack_30);
      }
      else {
        *puVar6 = piStack_30;
        if (piStack_30 != (int *)0x0) {
          LOCK();
          *piStack_30 = *piStack_30 + 1;
          UNLOCK();
        }
        puVar6[1] = 0;
        puVar6[2] = 0;
        if (iStack_28 != 0) {
          LOCK();
          *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
          UNLOCK();
        }
        puVar6[1] = uStack_2c;
        puVar6[2] = iStack_28;
        *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 0xc;
      }
    } while (0 < iStack_24);
  }
  iStack_8._0_1_ = 3;
  FUN_00947910();
  piVar8 = (int *)0x0;
  piStack_18 = (int *)(iStack_44 - (int)piStack_48 >> 4);
  piVar7 = piStack_48;
  if (piStack_18 != (int *)0x0) {
    do {
      if (*piVar7 != iStack_38) break;
      piVar8 = (int *)((int)piVar8 + 1);
      piVar7 = piVar7 + 4;
    } while (piVar8 < piStack_18);
  }
  do {
    if (piVar8 == piStack_18) {
      FUN_0153a600(0);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_0094a060();
      uVar3 = uStack_50;
      LOCK();
      *puStack_4c = 0;
      UNLOCK();
      if (DAT_01ee4208 != '\0') {
        FUN_016774b0(DAT_01ee4208,"ScriptContext::resumeParallelWaitingScripts finish",0);
      }
      iStack_8 = 0xd;
      FUN_01675290(uVar3);
      ExceptionList = pvStack_10;
      return;
    }
    iStack_24 = *(int *)(param_1 + 0x16c);
    iStack_20 = (int)piVar8 * 0x10;
    iStack_d0 = piStack_48[(int)piVar8 * 4];
    FUN_00945610(piStack_48 + (int)piVar8 * 4 + 1);
    iStack_bc = iStack_d0;
    iStack_8._0_1_ = 5;
    iStack_c0 = param_1;
    FUN_00945610(auStack_cc);
    iStack_ac = iStack_c0;
    iStack_a8 = iStack_bc;
    iStack_8._0_1_ = 6;
    appuStack_100[0] = (undefined **)0x0;
    FUN_00945610(auStack_b8);
    iStack_98 = iStack_ac;
    iStack_94 = iStack_a8;
    iStack_8._0_1_ = 7;
    FUN_00945610(auStack_a4);
    iStack_84 = iStack_98;
    iStack_6c = iStack_94;
    iStack_8._0_1_ = 8;
    FUN_00945610(auStack_90);
    iStack_5c = iStack_84;
    iStack_8._0_1_ = 9;
    cVar4 = FUN_00585a40(&iStack_6c);
    if (cVar4 != '\0') {
      FUN_0094a0d0();
    }
    else {
      iStack_80 = iStack_6c;
      FUN_00945610(auStack_68);
      iStack_70 = iStack_5c;
      aiStack_f8[0] = iStack_80;
      iStack_8._0_1_ = 10;
      FUN_00945610(auStack_7c);
      iStack_e8 = iStack_70;
      FUN_0094a0d0();
      FUN_0094a0d0();
    }
    bStack_11 = cVar4 == '\0';
    FUN_0094a0d0();
    appuStack_100[0] = &PTR_FUN_01934d50;
    if (bStack_11 == false) {
      appuStack_100[0] = (undefined **)0x0;
    }
    FUN_0094a0d0();
    FUN_0094a0d0();
    FUN_0094a0d0();
    iStack_8._0_1_ = 0xb;
    FUN_006c74e0(appuStack_100,&uStack_e0);
    iStack_8._0_1_ = 0xc;
    if (appuStack_100[0] != (undefined **)0x0) {
      if ((((uint)appuStack_100[0] & 1) == 0) &&
         (*(code **)((uint)appuStack_100[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)appuStack_100[0] & 0xfffffffe))(aiStack_f8,aiStack_f8,2);
      }
      appuStack_100[0] = (undefined **)0x0;
    }
    piVar7 = (int *)(iStack_20 + (int)piStack_48);
    iStack_8._0_1_ = 3;
    do {
      piVar8 = (int *)((int)piVar8 + 1);
      piVar7 = piVar7 + 4;
      if ((int *)(iStack_44 - (int)piStack_48 >> 4) <= piVar8) break;
    } while (*piVar7 == iStack_38);
  } while( true );
}



/* FUNCTION 17307 ; VA 0x0095bd50 ; FUN_0095bd50 */

void FUN_0095bd50(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc0e8;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  ExceptionList = &pvStack_10;
  if (iVar3 != param_1[1]) {
    do {
      piVar1 = *(int **)(iVar3 + 0x14);
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + 1;
      UNLOCK();
      if (piVar1 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0;
      if ((piVar1 != (int *)0x0) && (iVar2 = piVar1[2], iVar2 != 0)) {
        if (piVar1 == (int *)0x0) {
          iVar2 = 0;
        }
        FUN_01256cb0(iVar2,0xffffd8f0,param_2);
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        FUN_0095aba0(piVar1,1,0);
      }
      uStack_8 = 0xffffffff;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar1,0x10);
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      iVar3 = iVar3 + 0x1c;
    } while (iVar3 != param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17308 ; VA 0x0095be40 ; FUN_0095be40 */

/* WARNING: Removing unreachable block (ram,0x0095bf5f) */
/* WARNING: Removing unreachable block (ram,0x0095bf81) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0095be40(undefined4 param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  double *pdVar7;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc680;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01ee2a70);
  iStack_8 = 0;
  uStack_20 = uVar4;
  if (DAT_01ee4208 != '\0') {
    FUN_016774b0(DAT_01ee4208,"ScriptContext::resumeWaitingScripts start",0);
  }
  uStack_11 = 0;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  iStack_8._0_1_ = 1;
  if (0 < *(int *)(iStack_18 + 0x14c)) {
    puVar1 = (uint *)(iStack_18 + 0x150);
    iStack_1c = *(int *)(iStack_18 + 0x14c);
    do {
      iStack_1c = iStack_1c + -1;
      do {
        LOCK();
        uVar3 = *puVar1;
        *puVar1 = *puVar1 | 1;
        UNLOCK();
      } while ((uVar3 & 1) != 0);
      if (*(int *)(iStack_18 + 0x14c) == 0) {
        *puVar1 = 0;
        break;
      }
      puVar5 = *(undefined4 **)(iStack_18 + 0x13c);
      if (puVar5 != (undefined4 *)0x0) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_00947ad0(*(undefined4 *)(puVar5[1] + (puVar5[2] - 1 & *(uint *)(iStack_18 + 0x148)) * 4));
      FUN_00947910();
      piVar2 = (int *)(iStack_18 + 0x14c);
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        *(undefined4 *)(iStack_18 + 0x148) = 0;
      }
      else {
        *(int *)(iStack_18 + 0x148) = *(int *)(iStack_18 + 0x148) + 1;
      }
      *puVar1 = 0;
      uVar6 = FUN_009d5c60(0,0);
      FUN_0095aba0(0,uVar6,0);
      pdVar7 = (double *)FUN_016830f0(auStack_2c);
      if ((double)CONCAT44(param_2,param_1) <= *pdVar7 &&
          *pdVar7 != (double)CONCAT44(param_2,param_1)) {
        uStack_11 = 1;
        break;
      }
    } while (0 < iStack_1c);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00947910();
  if ((*(int *)(iStack_18 + 0x17c) != 0) && (*(int *)(iStack_18 + 0x174) != 0)) {
    FUN_00d9e390(*(undefined8 *)(*(int *)(iStack_18 + 0x174) + 0x80),param_1,param_2,&uStack_11);
  }
  if (DAT_01ee4208 != '\0') {
    FUN_016774b0(DAT_01ee4208,"ScriptContext::resumeWaitingScripts finish",0);
  }
  iStack_8 = 2;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17309 ; VA 0x0095c050 ; FUN_0095c050 */

void __fastcall FUN_0095c050(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0095c05b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x40))();
  return;
}



/* FUNCTION 17310 ; VA 0x0095c060 ; FUN_0095c060 */

int __thiscall FUN_0095c060(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined auStack_a8 [24];
  undefined4 uStack_90;
  undefined4 uStack_70;
  undefined4 uStack_50;
  undefined4 uStack_44;
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined *puStack_38;
  int iStack_34;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc6b0;
  pvStack_10 = ExceptionList;
  puStack_38 = (undefined *)0x95c086;
  ExceptionList = &pvStack_10;
  iStack_34 = param_1;
  uStack_14 = FUN_008c0050();
  iVar4 = *(int *)(param_2 + 0xc);
  iStack_34 = 0x95c097;
  iVar3 = FUN_00a34610();
  iVar5 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar5 = param_2;
  }
  if (iVar5 != 0) {
    piStack_18 = (int *)auStack_a8;
    uStack_ac = 0;
    uStack_b0 = 0;
    FUN_01255470(2,0);
    uStack_8 = 0;
    goto LAB_0095c1e6;
  }
  puStack_38 = (undefined *)0x95c0fa;
  iStack_34 = param_1;
  cVar2 = FUN_00983210();
  if (cVar2 == '\0') {
    iStack_34 = 1;
    uStack_3c = 0x95c109;
    puStack_38 = (undefined *)param_1;
    cVar2 = FUN_00971ce0();
    if (cVar2 != '\0') goto LAB_0095c110;
  }
  else {
LAB_0095c110:
    if (*(char *)(param_1 + 0x6c) == '\0') {
      puStack_38 = auStack_1c;
      iStack_34 = param_2;
      uStack_3c = 0x95c120;
      puStack_38 = (undefined *)FUN_0060e0c0();
      iStack_34 = param_2;
      uStack_8 = 1;
      uStack_3c = 0;
      puStack_40 = auStack_24;
      uStack_44 = 0x95c13c;
      iVar4 = FUN_00940db0();
      if (piStack_18 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return iVar4;
      }
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar4 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 != 0) {
        ExceptionList = pvStack_10;
        return iVar5;
      }
      iStack_34 = 0x95c15a;
      iVar4 = (**(code **)(*piStack_18 + 4))();
      ExceptionList = pvStack_10;
      return iVar4;
    }
  }
  puStack_38 = auStack_24;
  iStack_34 = param_2;
  uStack_3c = 0x95c177;
  puStack_38 = (undefined *)FUN_0060e0c0();
  iStack_34 = param_2;
  uStack_8 = 2;
  uStack_3c = 0;
  puStack_40 = auStack_1c;
  uStack_44 = 0x95c193;
  FUN_00940db0();
  uStack_8 = 0xffffffff;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[2] + -1;
    piStack_20[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      iStack_34 = 0x95c1b0;
      (**(code **)(*piStack_20 + 4))();
    }
  }
  piStack_18 = (int *)auStack_a8;
  uStack_ac = 0;
  uStack_b0 = 0;
  FUN_01255470(2,0);
  uStack_8 = 3;
LAB_0095c1e6:
  uStack_50 = 0;
  uStack_70 = 0;
  uStack_90 = 0;
  FUN_0060e0c0(&uStack_b0,param_2);
  uStack_8 = 0xffffffff;
  iVar4 = FUN_0094a730();
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17311 ; VA 0x0095c220 ; FUN_0095c220 */

int __thiscall FUN_0095c220(int param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc6e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (DAT_01d644e8 == '\0') {
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    uStack_8 = 5;
    ExceptionList = &pvStack_10;
    if (param_2 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      *param_2 = *param_2 + 1;
      UNLOCK();
    }
    piStack_20 = param_2;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_1c = param_3;
    piStack_18 = param_4;
    FUN_009562d0(&piStack_20);
    iVar3 = FUN_00947910();
  }
  else {
    param_1 = param_1 + 0x2d4;
    ExceptionList = &pvStack_10;
    iStack_14 = param_1;
    iVar3 = FUN_016dee6d(param_1);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    uStack_8._0_1_ = 3;
    if (param_2 != (int *)0x0) {
      LOCK();
      *param_2 = *param_2 + 1;
      UNLOCK();
    }
    piStack_20 = param_2;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_1c = param_3;
    piStack_18 = param_4;
    FUN_009562d0(&piStack_20);
    FUN_00947910();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    iVar3 = FUN_016deec8(param_1);
    if (iVar3 != 0) {
      iVar3 = FUN_016df3c9(iVar3);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    iVar3 = iVar3 + -1;
    if ((iVar3 == 0) && (param_2 != (int *)0x0)) {
      FUN_00d88950();
      iVar3 = FUN_01674ea0(param_2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17312 ; VA 0x0095c3c0 ; FUN_0095c3c0 */

bool FUN_0095c3c0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00a34610();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_0095c3f2;
  }
  param_1 = 0;
LAB_0095c3f2:
  return param_1 != 0;
}



/* FUNCTION 17313 ; VA 0x0095c400 ; FUN_0095c400 */

void FUN_0095c400(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01675640(aiStack_28,&DAT_018bed48,param_1,param_2);
  uStack_8 = 0;
  if (0xf < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  FUN_0087c450(&DAT_018c5f98,"loadstring",puVar1,0,0,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17314 ; VA 0x0095c4a0 ; FUN_0095c4a0 */

int * __thiscall FUN_0095c4a0(int *param_1,char param_2)

{
  void *pvVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar1 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc70f;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)CONCAT31((int3)((uint)ExceptionList >> 8),param_2);
  ExceptionList = &pvStack_10;
  *(char *)(param_1 + 99) = param_2;
  if (param_2 == '\0') {
    param_1[100] = 0;
    piVar7 = (int *)param_1[0x65];
    param_1[0x65] = 0;
  }
  else {
    if (param_1[100] != 0) {
      ExceptionList = pvVar1;
      return piVar2;
    }
    piVar7 = (int *)param_1[0xd];
    piVar6 = param_1;
    if ((piVar7 != (int *)0x0) && (piVar6 = piVar7, piVar7[0xd] != 0)) {
      piVar2 = (int *)FUN_005c8ac0();
      piVar6 = piVar2;
    }
    if (piVar6 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
    iVar4 = piVar6[3];
    iVar3 = FUN_008a8c30();
    if ((int *)(uint)*(ushort *)(iVar3 + 0x1da) <
        (int *)((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      ExceptionList = pvStack_10;
      return (int *)(uint)*(ushort *)(iVar3 + 0x1da);
    }
    piVar2 = (int *)FUN_005cf9e0();
    if (*piVar2 == 0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
    iVar4 = FUN_01674e20(0x1c);
    uStack_8 = 0;
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00f86490();
    }
    uStack_8 = 0xffffffff;
    FUN_00941180(uVar5,iVar4);
    param_1[100] = 0;
    piVar7 = (int *)param_1[0x65];
    piVar2 = (int *)0x0;
    param_1[0x65] = 0;
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar6 = piVar7 + 1;
    iVar4 = *piVar6;
    piVar2 = (int *)*piVar6;
    *piVar6 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)*piVar7)();
      LOCK();
      piVar6 = piVar7 + 2;
      iVar4 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar2 = (int *)(**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 17315 ; VA 0x0095c5f0 ; FUN_0095c5f0 */

void __fastcall FUN_0095c5f0(int param_1)

{
  *(undefined *)(param_1 + 0xe0) = 1;
  return;
}



/* FUNCTION 17316 ; VA 0x0095c600 ; FUN_0095c600 */

void __thiscall FUN_0095c600(int param_1,undefined4 param_2)

{
  uint *puVar1;
  uint *puVar2;
  
  if ((uint *)(param_1 + 0x78) != (uint *)(param_1 + 0xf8)) {
    puVar2 = (uint *)(param_1 + 0xb4);
    do {
      if ((*puVar2 ^ (uint)puVar2) != 0) {
        *(undefined4 *)(*(int *)((*puVar2 ^ (uint)puVar2) + 0x10) + 0x3b0) = param_2;
      }
      puVar1 = puVar2 + 1;
      puVar2 = puVar2 + 0x10;
    } while (puVar1 != (uint *)(param_1 + 0xf8));
  }
  return;
}



/* FUNCTION 17317 ; VA 0x0095c640 ; FUN_0095c640 */

void __thiscall FUN_0095c640(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(*(int *)((*(uint *)(param_1 + 0xb4) ^ param_1 + 0xb4U) + 0x10) + 0x18) = param_2;
  *(undefined4 *)(param_1 + 0x3e4) = param_3;
  return;
}



/* FUNCTION 17318 ; VA 0x0095c670 ; FUN_0095c670 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0095c670(int param_1,double param_2)

{
  uint uVar1;
  double dVar2;
  double *pdVar3;
  undefined4 uVar4;
  undefined auStack_20 [8];
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0x1b8) == '\0') &&
     ((NAN(param_2) || NAN(_PTR_018c6f48)) == (param_2 == _PTR_018c6f48))) {
    puStack_18 = (uint *)(param_1 + 0x364);
    cStack_14 = '\0';
    ExceptionList = &pvStack_10;
    FUN_00587410();
    uStack_8 = 0;
    pdVar3 = (double *)FUN_016827e0(auStack_20);
    dVar2 = *pdVar3;
    *(undefined *)(param_1 + 0x1b8) = 1;
    *(double *)(param_1 + 0x1c0) = dVar2 + param_2;
    uStack_8 = 1;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17319 ; VA 0x0095c750 ; FUN_0095c750 */

int FUN_0095c750(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  undefined8 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  if (DAT_01d644d8 == '\0') {
    FUN_01255f00(param_1,0,0);
    FUN_01255f00(param_1,0,0);
    FUN_00880890(param_1,0xffffffff);
    FUN_01256930(param_1,&DAT_0191c860,7);
    FUN_01256aa0(param_1,0xffffd8ee);
    FUN_01257230(param_1,0xfffffffd);
    FUN_012570b0(param_1,0xfffffffe);
  }
  else {
    FUN_0094c7a0(param_1);
  }
  FUN_01256eb0(param_1,0xffffd8ee);
  uVar2 = *(undefined8 *)(param_2 + 4);
  uVar4 = param_2[1];
  uVar5 = param_2[2];
  uVar6 = param_2[3];
  if (param_1 == 0) {
    iVar8 = 0;
  }
  else {
    iVar8 = *(int *)(param_1 + 0x6c);
  }
  *(undefined4 *)(iVar8 + 0x18) = *param_2;
  *(undefined4 *)(iVar8 + 0x1c) = uVar4;
  *(undefined4 *)(iVar8 + 0x20) = uVar5;
  *(undefined4 *)(iVar8 + 0x24) = uVar6;
  *(undefined8 *)(iVar8 + 0x28) = uVar2;
  if (param_1 == 0) {
    iVar8 = 0;
  }
  else {
    iVar8 = *(int *)(param_1 + 0x6c);
  }
  if (param_1 == 0) {
    iVar7 = 0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0x6c);
  }
  *(undefined4 *)(iVar7 + 0x28) = *(undefined4 *)(*(int *)(iVar8 + 0xc) + 4);
  if (param_1 == 0) {
    iVar8 = 0;
  }
  else {
    iVar8 = *(int *)(param_1 + 0x6c);
  }
  iVar7 = param_3[1];
  if (iVar7 != 0) {
    LOCK();
    *(int *)(iVar7 + 8) = *(int *)(iVar7 + 8) + 1;
    UNLOCK();
    iVar7 = param_3[1];
  }
  iVar9 = *param_3;
  *(int *)(iVar8 + 0x34) = iVar9;
  piVar3 = *(int **)(iVar8 + 0x38);
  *(int *)(iVar8 + 0x38) = iVar7;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar8 = *piVar1;
    iVar9 = *piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0095c837. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar8 = (**(code **)(*piVar3 + 4))();
      return iVar8;
    }
  }
  return iVar9;
}



/* FUNCTION 17320 ; VA 0x0095c840 ; FUN_0095c840 */

/* WARNING: Removing unreachable block (ram,0x0095c8c4) */
/* WARNING: Removing unreachable block (ram,0x0095c8d7) */
/* WARNING: Removing unreachable block (ram,0x0095c8de) */
/* WARNING: Removing unreachable block (ram,0x0095c8e5) */

void __thiscall FUN_0095c840(int param_1,double param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  *(undefined4 *)(param_1 + 0x1a8) = param_2._0_4_;
  *(undefined4 *)(param_1 + 0x1ac) = param_2._4_4_;
  uStack_8 = 0;
  if (DAT_01ee4208 != '\0') {
    FUN_016774b0(DAT_01ee4208,"Set lua time out: %d",(int)param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17321 ; VA 0x0095c910 ; FUN_0095c910 */

undefined4 FUN_0095c910(undefined4 param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01255560();
  cVar4 = FUN_01255580(uVar5,1);
  if (cVar4 == '\0') {
    FUN_01255600(1,"settings()");
  }
  puVar6 = (undefined4 *)FUN_00910d90();
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_18 = *puVar6;
  piStack_14 = (int *)puVar6[1];
  uStack_8 = 0;
  FUN_00da3620(param_1,&uStack_18);
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17322 ; VA 0x0095c9f0 ; FUN_0095c9f0 */

int FUN_0095c9f0(void)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc730;
  pvStack_10 = ExceptionList;
  iVar4 = DAT_01ee2b08;
  if (DAT_01ee2b08 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar4 = *piVar2;
    puStack_18 = (uint *)(iVar4 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ee2b08 == 0) {
      FUN_00942e00(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar4,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    iVar4 = DAT_01ee2b08;
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17323 ; VA 0x0095cae0 ; FUN_0095cae0 */

undefined4 FUN_0095cae0(int param_1)

{
  undefined8 uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc76f;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01674e20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar2 == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3 = (int *)FUN_00d88510();
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    *piVar3 = *piVar3 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  iVar2 = FUN_01256300();
  if (0 < iVar2) {
    FUN_012565c0();
    FUN_00d887b0();
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    if (piStack_28 != (int *)0x0) {
      LOCK();
      *piStack_28 = *piStack_28 + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_01256aa0(param_1,1);
    if (piStack_28 == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      iVar2 = piStack_28[2];
    }
    FUN_01257960(param_1,iVar2,1);
    if (DAT_01d644e8 == '\0') {
      if (param_1 == 0) {
        iVar2 = 0;
      }
      else {
        iVar2 = *(int *)(param_1 + 0x6c);
      }
      if (*(int *)(*(int *)(*(int *)(iVar2 + 0xc) + 4) + 0x17c) != 0) {
        iVar2 = FUN_0095c9f0();
        if (piStack_28 == (int *)0x0) {
          iVar4 = 0;
        }
        else {
          iVar4 = piStack_28[2];
        }
        FUN_00d9e200(iVar4,*(undefined8 *)(iVar2 + 0x58));
      }
    }
    else {
      iVar2 = FUN_0095c9f0();
      uVar1 = *(undefined8 *)(iVar2 + 0x58);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        *piStack_28 = *piStack_28 + 1;
        UNLOCK();
      }
      FUN_00956580(piStack_28,uVar1);
    }
    FUN_01257280(param_1,0xfffffffe);
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = *piStack_28;
      *piStack_28 = *piStack_28 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piStack_28,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    FUN_00d88aa0();
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar3,0x10);
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return 0;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 17324 ; VA 0x0095ccc0 ; FUN_0095ccc0 */

int __thiscall
FUN_0095ccc0(int param_1,undefined4 param_2,int param_3,undefined4 param_4,int *param_5,
            undefined4 param_6)

{
  int *piVar1;
  undefined uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint *puVar8;
  int iVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  uint uVar12;
  bool bVar13;
  undefined4 ***pppuStack_f4;
  undefined8 uStack_f0;
  undefined4 uStack_b0;
  int *piStack_ac;
  undefined auStack_a8 [24];
  undefined4 uStack_90;
  undefined auStack_70 [4];
  int *piStack_6c;
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc825;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (DAT_01d64498 != '\0') {
    uStack_f0 = CONCAT44(param_1,0x95ccfb);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_008f7870();
    if (iVar5 != 0) {
      uStack_f0 = CONCAT44(0x95cd09,(int)uStack_f0);
      cVar4 = FUN_008f2030();
      if (cVar4 != '\0') {
        if (param_3 == 0) {
          iVar5 = 0;
        }
        else {
          iVar5 = *(int *)(param_3 + 0x6c);
        }
        if (*(int *)(*(int *)(iVar5 + 0xc) + 4) == param_1) goto LAB_0095cd35;
      }
    }
    uStack_f0 = 0x18bc9b80191e60c;
    pppuStack_f4 = (undefined4 ***)0x95cd32;
    FUN_01675310();
  }
LAB_0095cd35:
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_4;
  piStack_14 = param_5;
  uStack_8._0_1_ = 1;
  uStack_f0 = CONCAT44(param_6,&uStack_18);
  pppuStack_f4 = (undefined4 ***)0x0;
  FUN_00940eb0(auStack_70);
  uStack_8._0_1_ = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[2] + -1;
    piStack_14[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_f0 = CONCAT44(0x95cd82,(int)uStack_f0);
      (**(code **)(*piStack_14 + 4))();
    }
  }
  uStack_f0._4_4_ = param_3;
  uStack_f0._0_4_ = 0x95cd8a;
  uVar6 = FUN_012565c0();
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  uStack_f0 = CONCAT44(uStack_f0._4_4_,0x10);
  uStack_8._0_1_ = 2;
  pppuStack_f4 = (undefined4 ***)0x95cd9e;
  iStack_20 = FUN_01674e20();
  uStack_8._0_1_ = 3;
  if (iStack_20 == 0) {
    piVar7 = (int *)0x0;
  }
  else {
    uStack_f0 = CONCAT44(uVar6,0x95cdb4);
    piVar7 = (int *)FUN_00d88510();
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  uStack_f0 = CONCAT44(0xfffffffe,param_3);
  uStack_8._0_1_ = 4;
  pppuStack_f4 = (undefined4 ***)0x95cdd9;
  piStack_6c = piVar7;
  FUN_01257280();
  uStack_f0 = CONCAT44(param_3,0x95cde5);
  iStack_20 = FUN_009edbb0();
  if (piVar7 == (int *)0x0) {
    uStack_f0._0_4_ = 0;
  }
  else {
    uStack_f0._0_4_ = piVar7[2];
  }
  pppuStack_f4 = (undefined4 ***)((int)&uStack_f0 + 4);
  uStack_f0._4_4_ = (int)uStack_f0;
  FUN_00d890b0();
  uStack_f0 = CONCAT44(uStack_f0._4_4_,0x95ce09);
  FUN_009ed7b0();
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_4;
  piStack_14 = param_5;
  uStack_8._0_1_ = 5;
  if (piVar7 == (int *)0x0) {
    pppuStack_f4 = (undefined4 ***)0x0;
  }
  else {
    pppuStack_f4 = (undefined4 ***)piVar7[2];
  }
  uStack_f0 = CONCAT44(&uStack_18,param_2);
  FUN_0095c750();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar5 = param_5[1] + -1;
    param_5[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_f0 = CONCAT44(0x95ce57,(int)uStack_f0);
      (**(code **)*param_5)();
      LOCK();
      iVar5 = param_5[2] + -1;
      param_5[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_f0 = CONCAT44(0x95ce68,(int)uStack_f0);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if ((piVar7 == (int *)0x0) || (piVar7[2] == 0)) {
    uStack_f0 = 0;
    pppuStack_f4 = (undefined4 ***)0x0;
    puVar8 = (uint *)FUN_01255470(0);
  }
  else {
    iVar5 = *(int *)(piVar7[2] + 0x6c);
    uStack_68 = *(uint *)(iVar5 + 0x18);
    uStack_64 = *(undefined4 *)(iVar5 + 0x1c);
    uStack_60 = *(undefined4 *)(iVar5 + 0x20);
    uStack_5c = *(undefined4 *)(iVar5 + 0x24);
    puVar8 = &uStack_68;
    uStack_58 = *(undefined8 *)(iVar5 + 0x28);
  }
  pppuStack_f4 = (undefined4 ***)puVar8[3];
  uStack_f0 = *(undefined8 *)(puVar8 + 4);
  FUN_01255490(*puVar8,puVar8[1],puVar8[2]);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_4;
  piStack_14 = param_5;
  uStack_8._0_1_ = 7;
  if (piVar7 == (int *)0x0) {
    iVar5 = 0;
  }
  else {
    iVar5 = piVar7[2];
  }
  uStack_f0 = CONCAT44(&uStack_18,iVar5);
  pppuStack_f4 = (undefined4 ***)0x95cefe;
  FUN_00da3620();
  piVar3 = piStack_14;
  uStack_8._0_1_ = 6;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      uStack_f0 = CONCAT44(0x95cf1c,(int)uStack_f0);
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_f0 = CONCAT44(0x95cf2d,(int)uStack_f0);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piVar7 == (int *)0x0) {
    pppuStack_f4 = (undefined4 ***)0x0;
  }
  else {
    pppuStack_f4 = (undefined4 ***)piVar7[2];
  }
  uStack_f0 = 0x19342ccffffd8ee;
  FUN_01257030();
  if (piVar7 == (int *)0x0) {
    pppuStack_f4 = (undefined4 ***)0x0;
  }
  else {
    pppuStack_f4 = (undefined4 ***)piVar7[2];
  }
  uStack_f0 = 0x1ffffd8ee;
  FUN_012571e0();
  uStack_f0 = CONCAT44(&uStack_68,0x95cf72);
  uVar6 = FUN_008a2380();
  uStack_f0 = 0x10191bf9c;
  uStack_8._0_1_ = 8;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  pppuStack_f4 = (undefined4 ***)0x95cf99;
  FUN_005542c0();
  uStack_8._0_1_ = 9;
  uStack_f0 = CONCAT44(uVar6,auStack_50);
  pppuStack_f4 = apppuStack_38;
  FUN_00558ba0();
  uStack_8._0_1_ = 0xb;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_3c) {
    uVar11 = uStack_3c + 1;
    uVar12 = auStack_50[0];
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(auStack_50[0] - 4);
      uVar11 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar12) - 4) {
        uStack_f0 = CONCAT44(0x95d504,(int)uStack_f0);
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_f0 = CONCAT44(uVar11,uVar12);
    pppuStack_f4 = (undefined4 ****)0x95cfe3;
    FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_8._0_1_ = 0xc;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_58._4_4_) {
    uVar11 = uStack_58._4_4_ + 1;
    uVar12 = uStack_68;
    if (0xfff < uVar11) {
      uVar12 = *(uint *)(uStack_68 - 4);
      uVar11 = uStack_58._4_4_ + 0x24;
      if (0x1f < (uStack_68 - uVar12) - 4) {
        uStack_f0 = CONCAT44(0x95d509,(int)uStack_f0);
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_f0 = CONCAT44(uVar11,uVar12);
    pppuStack_f4 = (undefined4 ****)0x95d02d;
    FUN_01674ea0();
  }
  uStack_58 = 0xf00000000;
  uStack_68 = uStack_68 & 0xffffff00;
  bVar13 = false;
  uStack_f0 = CONCAT44(0x95d04f,(int)uStack_f0);
  iVar5 = FUN_00ae4430();
  if (*(int *)(iVar5 + 0x10) == 0) {
    ppppuVar10 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar10 = (undefined4 ****)apppuStack_38[0];
    }
    uStack_f0 = CONCAT44(&uStack_18,0x95d070);
    uVar6 = FUN_009ed300();
    uStack_8._0_1_ = 0xd;
    if (piVar7 == (int *)0x0) {
      pppuStack_f4 = (undefined4 ****)0x0;
    }
    else {
      pppuStack_f4 = (undefined4 ***)piVar7[2];
    }
    uStack_f0 = CONCAT44(ppppuVar10,uVar6);
    iVar5 = FUN_009edf40();
    uStack_8._0_1_ = 0xc;
    bVar13 = iVar5 == 0;
    uStack_f0 = CONCAT44(0x95d09e,(int)uStack_f0);
    FUN_0056e380();
    uStack_f0 = CONCAT44(0x95d0a6,(int)uStack_f0);
    FUN_0056e380();
  }
  else {
    uStack_f0 = CONCAT44(0x95d141,(int)uStack_f0);
    iVar5 = FUN_00762f90();
    if (iVar5 == 1) {
      ppppuVar10 = apppuStack_38;
      if (0xf < uStack_24) {
        ppppuVar10 = (undefined4 ****)apppuStack_38[0];
      }
      uStack_f0 = CONCAT44(0x95d15d,(int)uStack_f0);
      uVar6 = FUN_00ae4370();
      if (piVar7 == (int *)0x0) {
        pppuStack_f4 = (undefined4 ****)0x0;
      }
      else {
        pppuStack_f4 = (undefined4 ***)piVar7[2];
      }
      uStack_f0 = CONCAT44(ppppuVar10,uVar6);
      iVar5 = FUN_009edf40();
      bVar13 = iVar5 == 0;
    }
  }
  if (DAT_01d644b8 == '\0') {
LAB_0095d1d2:
    if (bVar13) {
      if (piVar7 == (int *)0x0) {
        iVar5 = 0;
      }
      else {
        iVar5 = piVar7[2];
      }
      *(undefined *)(iVar5 + 7) = (undefined)param_6;
      if (piVar7 == (int *)0x0) {
        iVar5 = 0;
      }
      else {
        iVar5 = piVar7[2];
      }
      uStack_f0 = CONCAT44(iVar5,0x95d27e);
      FUN_005e6780();
      if (piVar7 == (int *)0x0) {
        pppuStack_f4 = (undefined4 ***)0x0;
      }
      else {
        pppuStack_f4 = (undefined4 ***)piVar7[2];
      }
      uStack_f0 = 0;
      iVar5 = FUN_0095b200();
      if (piVar7 == (int *)0x0) {
        iVar9 = 0;
      }
      else {
        iVar9 = piVar7[2];
      }
      uStack_f0 = CONCAT44(iVar9,0x95d2a9);
      iVar9 = FUN_01256300();
      uVar2 = DAT_01ee2ab1;
      if (iVar5 == 0) {
        bVar13 = false;
        if (iVar9 == 1) {
          if (piVar7 == (int *)0x0) {
            iVar5 = 0;
          }
          else {
            iVar5 = piVar7[2];
          }
          uStack_f0 = CONCAT44(0xffffd8f0,iVar5);
          pppuStack_f4 = (undefined4 ***)0x95d43c;
          uVar6 = FUN_01258150();
          uStack_f0 = CONCAT44(uVar6,param_3);
          pppuStack_f4 = (undefined4 ***)0x95d44b;
          FUN_009ed780();
          goto LAB_0095d21c;
        }
      }
      else {
        if ((iVar5 == 1) || (iVar5 == 6)) {
          uStack_b0 = 0;
          uStack_90 = 0;
          uStack_8._0_1_ = 0x11;
          if (param_5 != (int *)0x0) {
            LOCK();
            param_5[1] = param_5[1] + 1;
            UNLOCK();
          }
          FUN_00942a30(&pppuStack_f4,FUN_0095aa00,param_4,param_5,uVar2);
          FUN_0093ef40();
          uVar2 = DAT_01ee2ab1;
          if (param_5 != (int *)0x0) {
            LOCK();
            param_5[1] = param_5[1] + 1;
            UNLOCK();
          }
          FUN_00942a30(&pppuStack_f4,FUN_0095a140,param_4,param_5,uVar2);
          FUN_0093ef40();
          if ((piVar7 == (int *)0x0) || (piVar7[2] == 0)) {
            iVar5 = 0;
          }
          else {
            iVar5 = *(int *)(piVar7[2] + 0x6c);
          }
          uStack_f0 = 0x400095d3cb;
          iVar9 = FUN_01674e20();
          uStack_8._0_1_ = 0x12;
          if (iVar9 == 0) {
            uVar6 = 0;
          }
          else {
            uStack_f0 = CONCAT44(&uStack_b0,0x95d3e7);
            uVar6 = FUN_00945830();
          }
          iVar9 = *(int *)(iVar5 + 0x3c);
          *(undefined4 *)(iVar5 + 0x3c) = uVar6;
          if (iVar9 != 0) {
            uStack_f0 = CONCAT44(0x95d401,(int)uStack_f0);
            FUN_008c3510();
            uStack_f0 = CONCAT44(0x40,iVar9);
            pppuStack_f4 = (undefined4 ***)0x95d409;
            FUN_01674ea0();
          }
          uStack_f0 = CONCAT44(0x95d417,(int)uStack_f0);
          FUN_008c3510();
          goto LAB_0095d21c;
        }
        bVar13 = true;
      }
      uStack_f0 = CONCAT44(0x95d2d5,(int)uStack_f0);
      FUN_009ed730();
      if ((bVar13) || (iVar9 == 1)) {
        if (piVar7 == (int *)0x0) {
          uStack_f0 = 0x95d470;
          FUN_00959110();
        }
        else {
          uStack_f0 = CONCAT44(piVar7[2],0x95d460);
          FUN_00959110();
        }
      }
      else {
        uStack_f0 = 0x193379800000003;
        pppuStack_f4 = (undefined4 ***)0x95d2f3;
        FUN_0086f2f0();
      }
      goto LAB_0095d21c;
    }
  }
  else if (bVar13) {
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
      LOCK();
      param_5[2] = param_5[2] + 1;
      UNLOCK();
    }
    uStack_b0 = param_4;
    piStack_ac = param_5;
    uStack_8._0_1_ = 0xe;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar5 = param_5[1] + -1;
      param_5[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        uStack_f0 = CONCAT44(0x95d10f,(int)uStack_f0);
        (**(code **)*param_5)();
        LOCK();
        iVar5 = param_5[2] + -1;
        param_5[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          uStack_f0 = CONCAT44(0x95d120,(int)uStack_f0);
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    uStack_f0 = CONCAT44(auStack_a8,0x95d12f);
    FUN_008a2380();
    uStack_8._0_1_ = 0xf;
    if (piVar7 == (int *)0x0) {
      iVar5 = 0;
    }
    else {
      iVar5 = piVar7[2];
    }
    uStack_f0 = CONCAT44(0xffffffff,iVar5);
    pppuStack_f4 = (undefined4 ***)0x95d190;
    FUN_00d886a0();
    iVar5 = iStack_1c;
    pppuStack_f4 = (undefined4 ***)(iStack_1c + 0x398);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    uStack_f0 = CONCAT44(&uStack_b0,*(int *)(iStack_1c + 0x39c));
    if (*(int *)(iStack_1c + 0x3a0) == *(int *)(iStack_1c + 0x39c)) {
      pppuStack_f4 = (undefined4 ****)0x95d1c3;
      FUN_0093fbb0();
    }
    else {
      FUN_00942ca0();
      *(int *)(iVar5 + 0x39c) = *(int *)(iVar5 + 0x39c) + 0x40;
    }
    uStack_8._0_1_ = 0xc;
    uStack_f0 = CONCAT44(0x95d1d2,(int)uStack_f0);
    FUN_00947650();
    goto LAB_0095d1d2;
  }
  uStack_f0 = CONCAT44(0x95d1e0,(int)uStack_f0);
  FUN_009ed730();
  if (piVar7 == (int *)0x0) {
    pppuStack_f4 = (undefined4 ***)0x0;
  }
  else {
    pppuStack_f4 = (undefined4 ***)piVar7[2];
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_f0 = CONCAT44(param_5,param_4);
  FUN_00959a90();
LAB_0095d21c:
  if (0xf < uStack_24) {
    uVar12 = uStack_24 + 1;
    ppppuVar10 = (undefined4 ****)apppuStack_38[0];
    if (0xfff < uVar12) {
      ppppuVar10 = (undefined4 ****)apppuStack_38[0][-1];
      uVar12 = uStack_24 + 0x24;
      if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar10))) {
        uStack_f0 = CONCAT44(&UNK_0095d50e,(int)uStack_f0);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_f0 = CONCAT44(uVar12,ppppuVar10);
    pppuStack_f4 = (undefined4 ***)0x95d47c;
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  apppuStack_38[0] = (undefined4 ***)((uint)apppuStack_38[0] & 0xffffff00);
  uStack_f0 = CONCAT44(0x95d49c,(int)uStack_f0);
  iVar5 = FUN_01255500();
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = *piVar7;
    *piVar7 = *piVar7 + -1;
    UNLOCK();
    iVar5 = iVar5 + -1;
    if (iVar5 == 0) {
      uStack_f0 = CONCAT44(0x95d4b3,(int)uStack_f0);
      FUN_00d88950();
      uStack_f0 = CONCAT44(0x10,piVar7);
      pppuStack_f4 = (undefined4 ***)0x95d4bb;
      iVar5 = FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar7 = param_5 + 1;
    iVar9 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar9 + -1;
    UNLOCK();
    if (iVar9 + -1 == 0) {
      uStack_f0 = CONCAT44(0x95d4de,(int)uStack_f0);
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar7 = param_5 + 2;
      iVar9 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        uStack_f0 = CONCAT44(0x95d4ed,(int)uStack_f0);
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17325 ; VA 0x0095d510 ; FUN_0095d510 */

void __thiscall
FUN_0095d510(int *param_1,int *param_2,int *param_3,undefined4 ****param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8,int param_9)

{
  int *piVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  int in_stack_00000044;
  uint in_stack_00000064;
  undefined auStack_114 [8];
  undefined auStack_10c [56];
  uint auStack_d4 [4];
  undefined4 uStack_c4;
  uint uStack_c0;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined auStack_b0 [16];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 ***pppuStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  char acStack_68 [4];
  int *piStack_64;
  int aiStack_60 [2];
  undefined4 ***pppuStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  int aiStack_40 [2];
  int *piStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cc8f1;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffee0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  piStack_28 = param_2;
  piStack_38 = param_2;
  piStack_34 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  piStack_1c = param_1;
  puVar2 = &stack0xfffffee0;
  if (param_2 == (int *)0x0) {
LAB_0095d5a7:
    puStack_14 = puVar2;
    piStack_20 = (int *)0x0;
  }
  else {
    piStack_20 = (int *)param_2[0xd];
    if (piStack_20 == (int *)0x0) {
      piStack_20 = param_2;
      puVar2 = &stack0xfffffee0;
    }
    else {
      puVar2 = &stack0xfffffee0;
      if (piStack_20[0xd] != 0) {
        piStack_20 = (int *)FUN_005c8ac0();
        puVar2 = puStack_14;
      }
    }
    puStack_14 = puVar2;
    puVar2 = puStack_14;
    if ((piStack_20 == (int *)0x0) ||
       (iVar6 = piStack_20[3], iVar4 = FUN_008a8c30(), puVar2 = puStack_14,
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) goto LAB_0095d5a7;
  }
  if (piStack_1c == (int *)0x0) {
LAB_0095d601:
    piVar5 = (int *)0x0;
  }
  else {
    piStack_18 = (int *)piStack_1c[0xd];
    if (piStack_18 == (int *)0x0) {
      piStack_18 = piStack_1c;
    }
    else if (piStack_18[0xd] != 0) {
      piStack_18 = (int *)FUN_005c8ac0();
    }
    if ((piStack_18 == (int *)0x0) ||
       (iVar6 = piStack_18[3], iVar4 = FUN_008a8c30(), piVar5 = piStack_18,
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) goto LAB_0095d601;
  }
  piVar1 = piStack_28;
  if (piStack_20 == piVar5) {
    (**(code **)(*piStack_28 + 0xb4))(acStack_68);
    uStack_8 = 2;
    if (acStack_68[0] != '\0') {
      if (3 < piStack_1c[0x68]) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("startScript re-entrancy has exceeded 3");
      }
      piStack_1c[0x68] = piStack_1c[0x68] + 1;
      if (DAT_01ee4208 != '\0') {
        FUN_016774b0(DAT_01ee4208,"Running script %p",piVar1);
      }
      iVar6 = FUN_0095c9f0();
      if (*(char *)(iVar6 + 0x68) != '\0') {
        puVar7 = (undefined4 *)FUN_008a2380(&pppuStack_58);
        uStack_8 = 3;
        if (0xf < (uint)puVar7[5]) {
          puVar7 = (undefined4 *)*puVar7;
        }
        FUN_0086f2f0(1,"Running Script \"%s\"",puVar7);
        FUN_005507b0();
      }
      _uStack_8 = CONCAT31(uStack_7,4);
      FUN_01255470(0,0,0,0);
      piStack_18 = (int *)piVar1[3];
      iVar6 = FUN_00a34610();
      if ((uint)*(ushort *)(iVar6 + 0x1da) <
          (uint)*(ushort *)(piStack_18 + 0x76) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
        pppuStack_98 = param_4;
        uStack_94 = param_5;
        uStack_90 = param_6;
        uStack_8c = param_7;
      }
      else {
        FUN_01255470(3,0,0,0);
        pppuStack_98 = pppuStack_58;
        uStack_94 = uStack_54;
        uStack_90 = uStack_50;
        uStack_8c = uStack_4c;
        param_8 = CONCAT44(uStack_44,uStack_48);
      }
      uStack_88 = param_8;
      if (DAT_01d644e8 == '\0') {
        piStack_20 = (int *)FUN_0094fde0(&pppuStack_98);
      }
      else {
        piStack_20 = (int *)FUN_0094ff40(&pppuStack_98,&piStack_38);
      }
      iVar6 = FUN_012565c0(piStack_20);
      if (iVar6 == 0) {
        FUN_0054db20();
        FUN_005c8aa0();
        uVar8 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Unable to create a new thread for %s",uVar8);
      }
      uStack_bc = 1;
      piStack_b8 = piStack_20;
      FUN_00557fc0(&piStack_38);
      uStack_8 = 6;
      FUN_0095c750(iVar6,&pppuStack_98,aiStack_40);
      uStack_8 = 5;
      FUN_00550b30();
      uVar8 = FUN_00d890b0(&piStack_18,iVar6);
      FUN_00947970(uVar8);
      FUN_0087dad0();
      piStack_24 = (int *)(**(code **)(*piVar1 + 0xac))();
      if (*(int *)((int)piStack_24 + 0x10) != 0) {
        piStack_18 = (int *)piVar1[10];
        FUN_00947b60(piStack_24);
        FUN_00551230(piStack_18);
        FUN_00947b60(piStack_24);
        FUN_00557fc0(&piStack_38);
        uStack_8 = 7;
        FUN_008a4660(aiStack_40);
        uStack_8 = 5;
        FUN_00550b30();
      }
      FUN_009462d0(iVar6);
      FUN_00557fc0(&piStack_38);
      uStack_8 = 9;
      FUN_00da3620(iVar6,auStack_30);
      uStack_8 = 8;
      FUN_00550b30();
      FUN_01257030(iVar6,0xffffd8ee,"script");
      FUN_012571e0(iVar6,0xffffd8ee,1);
      piStack_24 = (int *)FUN_008a2380(&uStack_80);
      uStack_8 = 10;
      uStack_a0 = 0;
      uStack_9c = 0xf;
      auStack_b0[0] = 0;
      FUN_005542c0(&DAT_0191bf9c,1);
      uStack_8 = 0xb;
      FUN_00558ba0(&pppuStack_58,auStack_b0,piStack_24);
      FUN_005507b0();
      uStack_8 = 0xe;
      FUN_005507b0();
      piStack_18 = aiStack_60;
      if (DAT_01d67698 == '\0') {
        piStack_18 = piStack_64;
      }
      FUN_008866d0();
      uStack_8 = 0xf;
      cVar3 = FUN_00554b40();
      if ((cVar3 != '\0') && (in_stack_00000064 != 0)) {
        uStack_8 = 0x10;
        uVar8 = FUN_00a33fa0();
        if (in_stack_00000064 == 0) {
          uVar8 = FUN_0054fda0();
          _uStack_8 = CONCAT31(uStack_7,0x11);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar8);
        }
        puVar7 = (undefined4 *)
                 (**(code **)((in_stack_00000064 & 0xfffffffe) + 4))
                           (auStack_d4,&stack0x0000006c,uVar8);
        uStack_80 = *puVar7;
        uStack_7c = puVar7[1];
        uStack_78 = puVar7[2];
        uStack_74 = puVar7[3];
        uStack_70 = *(undefined8 *)(puVar7 + 4);
        puVar7[4] = 0;
        puVar7[5] = 0xf;
        *(undefined *)puVar7 = 0;
        if (0xf < uStack_c0) {
          uVar11 = uStack_c0 + 1;
          uVar10 = auStack_d4[0];
          if (0xfff < uVar11) {
            uVar10 = *(uint *)(auStack_d4[0] - 4);
            uVar11 = uStack_c0 + 0x24;
            if (0x1f < (auStack_d4[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar10,uVar11);
        }
        uStack_c4 = 0;
        uStack_c0 = 0xf;
        auStack_d4[0] = auStack_d4[0] & 0xffffff00;
        uStack_8 = 0x12;
        uVar8 = FUN_00886c00(auStack_30,&uStack_80);
        _uStack_8 = CONCAT31(uStack_7,0x13);
        FUN_00886840(uVar8);
        FUN_0056e380();
        FUN_0056e380();
        FUN_005507b0();
        piStack_18 = aiStack_40;
        uStack_8 = 0xf;
        uStack_7 = 0;
      }
      if ((param_9 != 0) || (in_stack_00000044 != 0)) {
        piStack_24 = (int *)(*(int *)(iVar6 + 0x6c) + 0x3c);
        iStack_2c = FUN_01674e20(0x40);
        uStack_8 = 0x16;
        if (iStack_2c == 0) {
          uVar8 = 0;
        }
        else {
          uVar8 = FUN_009456f0(&param_9);
        }
        uStack_8 = 0xf;
        FUN_0095ab70(uVar8);
      }
      ppppuVar9 = &pppuStack_58;
      if (0xf < uStack_44) {
        ppppuVar9 = (undefined4 ****)pppuStack_58;
      }
      piVar5 = piStack_18;
      iVar4 = FUN_009edf40(iVar6,piStack_18,ppppuVar9);
      if (DAT_01d644b8 == '\0') {
        if (iVar4 == 0) goto LAB_0095db42;
LAB_0095dbc2:
        FUN_00557fc0(&piStack_38);
        FUN_00959a90(iVar6,piVar5,ppppuVar9);
        iVar4 = *(int *)(*(int *)(iVar6 + 0x6c) + 0x3c);
        if ((iVar4 != 0) && (*(int *)(iVar4 + 0x20) != 0)) {
          FUN_008927d0(iVar6);
        }
        FUN_01257280(iVar6,0xfffffffe);
      }
      else {
        if (iVar4 != 0) goto LAB_0095dbc2;
        piStack_24 = piStack_1c + 0xe6;
        uVar8 = FUN_00557fc0(&piStack_38);
        FUN_005587b0(uVar8);
        uStack_8 = 0x17;
        FUN_00550b30();
        FUN_008a2380(auStack_10c);
        uStack_8 = 0x18;
        FUN_00d886a0(iVar6,0xffffffff);
        uStack_8 = 0x19;
        FUN_00943000(auStack_114);
        uStack_8 = 0xf;
        FUN_00947650();
LAB_0095db42:
        FUN_005e6780(iVar6);
        if (piStack_28 != (int *)0x0) {
          LOCK();
          *piStack_28 = *piStack_28 + 1;
          UNLOCK();
        }
        FUN_0095aba0(piStack_28,0,0);
      }
      FUN_0056e380();
      FUN_0056e380();
      FUN_005507b0();
      FUN_0089b430();
      uStack_8 = 0x1a;
      FUN_01257280(piStack_20,0xfffffffe);
      piStack_1c[0x68] = piStack_1c[0x68] + -1;
      FUN_00946ed0();
      FUN_00550b30();
      goto LAB_0095d650;
    }
    FUN_00946ed0();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar6 = param_3[1] + -1;
    param_3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
LAB_0095d650:
  FUN_009476d0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17326 ; VA 0x0095dc01 ; Catch@0095dc01 */

void Catch_0095dc01(void)

{
  int *piVar1;
  int unaff_EBP;
  
  piVar1 = (int *)(*(int *)(unaff_EBP + -0x18) + 0x1a0);
  *piVar1 = *piVar1 + -1;
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17327 ; VA 0x0095dc58 ; Catch@0095dc58 */

void Catch_0095dc58(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0xb0);
  uVar3 = (**(code **)(*piVar1 + 4))();
  iVar2 = piVar1[3];
  FUN_0054db20();
  FUN_008a2380(unaff_EBP + -0x7c);
  *(undefined *)(unaff_EBP + -4) = 0x15;
  uVar4 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("%s(%d) - %s",uVar4,iVar2,uVar3);
}



/* FUNCTION 17328 ; VA 0x0095dca0 ; FUN_0095dca0 */

undefined4 FUN_0095dca0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc910;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(param_1 + 0x6c);
  }
  iVar3 = *(int *)(*(int *)(iVar3 + 0xc) + 4);
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    iVar4 = *(int *)(iVar3 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (iVar3 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_005c8ac0();
    }
    if ((iVar3 != 0) &&
       (iVar3 = *(int *)(iVar3 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      uVar5 = FUN_006fb410();
      goto LAB_0095dd1d;
    }
  }
  uVar5 = 0;
LAB_0095dd1d:
  puVar6 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar5);
  uStack_18 = *puVar6;
  piStack_14 = (int *)puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  uStack_8 = 1;
  FUN_00da3620(param_1,&uStack_18);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar2 = piStack_1c + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17329 ; VA 0x0095ddd0 ; FUN_0095ddd0 */

undefined4 FUN_0095ddd0(void)

{
  int *piVar1;
  int iVar2;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc930;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    iVar2 = FUN_008f7870(iStack_1c);
    if (iVar2 == 0) {
      iVar2 = 0;
    }
    else {
      iVar2 = iVar2 + 0xc;
    }
    FUN_008e9840(iVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0094ba20();
    FUN_008eb130();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17330 ; VA 0x0095de90 ; FUN_0095de90 */

undefined4 FUN_0095de90(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc930;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    iVar2 = FUN_008f7870(iStack_1c);
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"GC Job start, data model: %p",iVar2);
    }
    if (iVar2 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = iVar2 + 0xc;
    }
    FUN_008e9840(iVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0095e1b0();
    FUN_0094d070();
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"GC Job finish, data model: %p",iVar2);
    }
    FUN_008eb130();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17331 ; VA 0x0095df80 ; FUN_0095df80 */

undefined4 FUN_0095df80(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc930;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    iVar2 = FUN_008f7870(iStack_1c);
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"Waiting scripts start, data model: %p",iVar2);
    }
    if (iVar2 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = iVar2 + 0xc;
    }
    FUN_008e9840(iVar3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0095b720();
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"Waiting scripts finish, data model: %p",iVar2);
    }
    FUN_008eb130();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17332 ; VA 0x0095e070 ; FUN_0095e070 */

undefined4 __fastcall FUN_0095e070(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  double *pdVar4;
  undefined auStack_40 [12];
  int iStack_34;
  int *piStack_30;
  undefined8 uStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017cc950;
  pvStack_1c = ExceptionList;
  uStack_28 = (double)CONCAT44(param_1,(undefined4)uStack_28);
  ExceptionList = &pvStack_1c;
  FUN_00587490(&iStack_34);
  uStack_14 = 0;
  if (iStack_34 != 0) {
    iVar2 = FUN_008f7870(iStack_34);
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"Waiting scripts start, data model: %p",iVar2);
    }
    if (iVar2 == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = iVar2 + 0xc;
    }
    FUN_008e9840(iVar3);
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    pdVar4 = (double *)FUN_016830f0(auStack_40);
    uStack_28 = *(double *)(uStack_28._4_4_ + 0x128) + *pdVar4;
    FUN_0095be40(uStack_28);
    if (*(char *)(iStack_34 + 0x1b8) == '\0') {
      FUN_0095c600(0);
    }
    if (DAT_01d6514b != '\0') {
      FUN_016774b0(DAT_01d6514b,"Waiting scripts finish, data model: %p",iVar2);
    }
    FUN_008eb130();
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 1;
}



/* FUNCTION 17333 ; VA 0x0095e1b0 ; FUN_0095e1b0 */

void __fastcall FUN_0095e1b0(int param_1)

{
  double dVar1;
  short sVar2;
  double *pdVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  double dVar7;
  double dVar8;
  undefined auStack_1c [8];
  double dStack_14;
  undefined8 uStack_c;
  
  pdVar3 = (double *)FUN_01682800(auStack_1c);
  dStack_14 = (*pdVar3 - *(double *)(param_1 + 0x1e0)) * DAT_018c0d70;
  uStack_c = dStack_14;
  sVar2 = FUN_017265ed(&dStack_14);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x1e8);
    dVar8 = DAT_018c0d60 - dVar1;
    dVar7 = uStack_c;
    if (*(char *)(param_1 + 0x208) == '\0') {
      dVar7 = *(double *)(param_1 + 0x1f8) * dVar8 + dVar1 * uStack_c;
    }
    *(double *)(param_1 + 0x1f0) = uStack_c;
    *(undefined *)(param_1 + 0x208) = 0;
    *(double *)(param_1 + 0x1f8) = dVar7;
    *(double *)(param_1 + 0x200) =
         (uStack_c - dVar7) * (uStack_c - dVar7) * dVar1 + *(double *)(param_1 + 0x200) * dVar8;
  }
  puVar4 = (undefined4 *)FUN_01682800(auStack_1c);
  *(undefined4 *)(param_1 + 0x1e0) = *puVar4;
  *(undefined4 *)(param_1 + 0x1e4) = puVar4[1];
  FUN_016827e0(&uStack_c);
  piVar6 = (int *)(param_1 + 0xb4);
  *(undefined4 *)(param_1 + 0x260) = (undefined4)uStack_c;
  iVar5 = 2;
  *(undefined4 *)(param_1 + 0x264) = uStack_c._4_4_;
  do {
    if ((int *)*piVar6 != piVar6) {
      FUN_0095e440(piVar6 + -0xf);
    }
    piVar6 = piVar6 + 0x10;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  pdVar3 = (double *)FUN_016827e0(auStack_1c);
  *(double *)(param_1 + 0x278) = (*pdVar3 - *(double *)(param_1 + 0x260)) * DAT_018c0d70;
  dStack_14 = *(double *)(param_1 + 0x270);
  uStack_c = dStack_14;
  sVar2 = FUN_017265ed(&dStack_14);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x238);
    dVar8 = DAT_018c0d60 - dVar1;
    dVar7 = uStack_c;
    if (*(char *)(param_1 + 600) == '\0') {
      dVar7 = *(double *)(param_1 + 0x248) * dVar8 + dVar1 * uStack_c;
    }
    *(double *)(param_1 + 0x240) = uStack_c;
    *(undefined *)(param_1 + 600) = 0;
    *(double *)(param_1 + 0x248) = dVar7;
    *(double *)(param_1 + 0x250) =
         (uStack_c - dVar7) * (uStack_c - dVar7) * dVar1 + *(double *)(param_1 + 0x250) * dVar8;
  }
  *(undefined8 *)(param_1 + 0x270) = 0;
  dStack_14 = *(double *)(param_1 + 0x278);
  uStack_c = dStack_14;
  sVar2 = FUN_017265ed(&dStack_14);
  if (sVar2 < 1) {
    dVar1 = *(double *)(param_1 + 0x210);
    dVar8 = DAT_018c0d60 - dVar1;
    dVar7 = uStack_c;
    if (*(char *)(param_1 + 0x230) == '\0') {
      dVar7 = *(double *)(param_1 + 0x220) * dVar8 + dVar1 * uStack_c;
    }
    *(double *)(param_1 + 0x218) = uStack_c;
    *(undefined *)(param_1 + 0x230) = 0;
    *(double *)(param_1 + 0x220) = dVar7;
    *(double *)(param_1 + 0x228) =
         (uStack_c - dVar7) * (uStack_c - dVar7) * dVar1 + *(double *)(param_1 + 0x228) * dVar8;
  }
  return;
}



/* FUNCTION 17334 ; VA 0x0095e440 ; FUN_0095e440 */

void FUN_0095e440(double *param_1)

{
  double dVar1;
  int iVar2;
  double dVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  short sVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  double dVar11;
  double dVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cc98c;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01ee2b30) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee2b30), DAT_01ee2b30 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0(&DAT_0191e450,&DAT_0193460c,0xffffffff);
    if (DAT_01d7ad40 != '\0') {
      FUN_01532a30(uVar13);
    }
    uStack_8 = 0xffffffff;
    DAT_01ee2b28 = (int)uVar13;
    DAT_01ee2b2c = (int)((ulonglong)uVar13 >> 0x20);
    FUN_016f37bf(&DAT_01ee2b30);
  }
  uVar5 = DAT_01ee2b2c;
  uVar4 = DAT_01ee2b28;
  uVar13 = FUN_01532c80(DAT_01ee2b28,DAT_01ee2b2c);
  uStack_8 = 1;
  iVar7 = FUN_01256000(*(uint *)((int)param_1 + 0x3c) ^ (int)param_1 + 0x3cU,3,0);
  iVar8 = iVar7 - *(int *)(param_1 + 5);
  if (iVar8 < 1) {
    iVar8 = 0;
  }
  dVar11 = (double)iVar8;
  uStack_18 = dVar11;
  sVar6 = FUN_017265ed(&uStack_18);
  dVar3 = DAT_018c0d60;
  if (sVar6 < 1) {
    dVar1 = *param_1;
    dVar12 = dVar11;
    if (*(char *)(param_1 + 4) == '\0') {
      dVar12 = (DAT_018c0d60 - dVar1) * param_1[2] + dVar1 * dVar11;
    }
    param_1[1] = dVar11;
    param_1[2] = dVar12;
    *(undefined *)(param_1 + 4) = 0;
    param_1[3] = (dVar3 - dVar1) * param_1[3] + dVar1 * (dVar11 - dVar12) * (dVar11 - dVar12);
  }
  else {
    dVar12 = param_1[2];
  }
  iVar9 = DAT_01d643c8;
  if ((int)((double)DAT_01d643c0 * dVar12) < DAT_01d643c8) {
    iVar9 = (int)((double)DAT_01d643c0 * dVar12);
  }
  iVar10 = 1;
  if (1 < iVar9) {
    iVar10 = iVar9;
  }
  uStack_18 = (double)CONCAT44(iVar10,(undefined4)uStack_18);
  FUN_01256000(*(uint *)((int)param_1 + 0x3c) ^ (int)param_1 + 0x3cU,5,iVar10);
  iVar9 = FUN_01256000(*(uint *)((int)param_1 + 0x3c) ^ (int)param_1 + 0x3cU,3,0);
  *(int *)(param_1 + 5) = iVar9;
  if ((*(int *)(iVar2 + 0x34) < DAT_01ee2b40) && (FUN_016f3809(&DAT_01ee2b40), DAT_01ee2b40 == -1))
  {
    uStack_8._0_1_ = 2;
    uVar14 = FUN_0152da50(&DAT_0191e450);
    DAT_01ee2b3c = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01ee2b38 = (undefined4)uVar14;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01ee2b40);
  }
  FUN_0152d760(DAT_01ee2b38,DAT_01ee2b3c,"Allocated %d Kb (total %d Kb)",iVar8,iVar7);
  if ((*(int *)(iVar2 + 0x34) < DAT_01ee2b50) && (FUN_016f3809(&DAT_01ee2b50), DAT_01ee2b50 == -1))
  {
    uStack_8._0_1_ = 3;
    uVar14 = FUN_0152da50(&DAT_0191e450);
    DAT_01ee2b4c = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01ee2b48 = (undefined4)uVar14;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01ee2b50);
  }
  FUN_0152d760(DAT_01ee2b48,DAT_01ee2b4c,"Freed %d Kb (requested %d Kb)",iVar7 - iVar9,
               uStack_18._4_4_);
  uStack_8 = 4;
  FUN_0152dda0(uVar4,uVar5,uVar13);
  if (DAT_01d7ad40 != '\0') {
    FUN_01532d10(uVar4,uVar5,uVar13);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17335 ; VA 0x0095e770 ; FUN_0095e770 */

void __thiscall FUN_0095e770(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cc9a8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17336 ; VA 0x0095e800 ; FUN_0095e800 */

undefined4 FUN_0095e800(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cacf7;
  pvStack_10 = ExceptionList;
  if (DAT_01d644e8 != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_008f7870();
    if (param_1 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    *(undefined *)(iVar4 + 0x30) = 0;
    if ((iVar1 == 0) || (*(char *)(iVar1 + 0xd0) != '\0')) {
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + 1;
      UNLOCK();
      uStack_8 = 0;
      iVar1 = FUN_01674e20(0x10);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iVar1 == 0) {
        piVar2 = (int *)0x0;
      }
      else {
        piVar2 = (int *)FUN_00d88510(param_1);
      }
      if (piVar2 != (int *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00956580();
      uVar3 = FUN_01258cc0();
      ExceptionList = pvStack_10;
      return uVar3;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17337 ; VA 0x0095e900 ; FUN_0095e900 */

undefined4 FUN_0095e900(undefined4 param_1)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_01160660();
  FUN_012569a0(param_1,(double)fVar1);
  return 1;
}



/* FUNCTION 17338 ; VA 0x0095e920 ; FUN_0095e920 */

undefined4 FUN_0095e920(int param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = *(int *)(param_1 + 0x6c);
  }
  FUN_012569a0(param_1,*(undefined8 *)(*(int *)(*(int *)(*(int *)(iVar1 + 0xc) + 4) + 0x174) + 0x70)
              );
  return 1;
}



/* FUNCTION 17339 ; VA 0x0095e960 ; FUN_0095e960 */

void __fastcall FUN_0095e960(int param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  FUN_01682800(&uStack_10);
  if ((NAN(*(double *)(param_1 + 0x818)) || NAN((double)CONCAT44(uStack_c,uStack_10))) ==
      (*(double *)(param_1 + 0x818) == (double)CONCAT44(uStack_c,uStack_10))) {
    *(undefined4 *)(param_1 + 0x818) = uStack_10;
    *(undefined4 *)(param_1 + 0x81c) = uStack_c;
    uVar3 = FUN_016f3eb1();
    LOCK();
    uVar1 = *(uint *)(param_1 + 0x800);
    *(uint *)(param_1 + 0x800) = uVar3;
    UNLOCK();
    if (uVar1 < uVar3) {
      iVar2 = *(int *)(param_1 + 0x804);
      while (uVar1 = uVar1 + 1, uVar1 <= uVar3) {
        iVar4 = (int)*(char *)((uVar1 & 0x7ff) + param_1);
        if (0 < iVar4) {
          do {
            LOCK();
            *(int *)(param_1 + 0x808) = *(int *)(param_1 + 0x808) + -1;
            UNLOCK();
            iVar4 = iVar4 + -1;
          } while (iVar4 != 0);
        }
        *(char *)((uVar1 & 0x7ff) + param_1) = (char)iVar2;
        if (0 < iVar2) {
          iVar4 = iVar2;
          do {
            LOCK();
            *(int *)(param_1 + 0x808) = *(int *)(param_1 + 0x808) + 1;
            UNLOCK();
            iVar4 = iVar4 + -1;
          } while (iVar4 != 0);
        }
      }
    }
  }
  return;
}



/* FUNCTION 17340 ; VA 0x0095ea30 ; FUN_0095ea30 */

undefined2 FUN_0095ea30(undefined4 param_1,uint param_2)

{
  int iVar1;
  
  if (0xff < param_2) {
    return 0xffff;
  }
  iVar1 = FUN_0086e8f0(param_1);
  return *(undefined2 *)(iVar1 + 0x18);
}



/* FUNCTION 17341 ; VA 0x0095ea60 ; FUN_0095ea60 */

undefined4 FUN_0095ea60(undefined4 param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01255560();
  cVar4 = FUN_01255580(uVar5,0);
  if (cVar4 == '\0') {
    FUN_01255600(0,"UserSettings()");
  }
  puVar6 = (undefined4 *)FUN_00910e00();
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_18 = *puVar6;
  piStack_14 = (int *)puVar6[1];
  uStack_8 = 0;
  FUN_00da3620(param_1,&uStack_18);
  piVar1 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17342 ; VA 0x0095eb40 ; FUN_0095eb40 */

void FUN_0095eb40(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cca03;
  pvStack_10 = ExceptionList;
  if (param_1 == 0) {
    if (*(int *)(param_2 + 0x6c) != 0) {
      ExceptionList = &pvStack_10;
      FUN_009495f0(1);
    }
    *(undefined4 *)(param_2 + 0x6c) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_01674e20(0x40);
  if (puVar6 != (undefined4 *)0x0) {
    iVar2 = *(int *)(param_1 + 0x6c);
    *puVar6 = 0;
    puVar6[1] = 0;
    puVar6[2] = 0;
    puVar6[3] = 0;
    puVar6[4] = 0;
    if (*(int *)(iVar2 + 0x10) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar2 + 0x10) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar6[3] = *(undefined4 *)(iVar2 + 0xc);
    puVar6[4] = *(undefined4 *)(iVar2 + 0x10);
    piVar1 = *(int **)(iVar2 + 0x14);
    puVar6[5] = piVar1;
    if (piVar1 != (int *)0x0) {
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar3 = *(undefined4 *)(iVar2 + 0x1c);
    uVar4 = *(undefined4 *)(iVar2 + 0x20);
    uVar5 = *(undefined4 *)(iVar2 + 0x24);
    puVar6[6] = *(undefined4 *)(iVar2 + 0x18);
    puVar6[7] = uVar3;
    puVar6[8] = uVar4;
    puVar6[9] = uVar5;
    *(undefined8 *)(puVar6 + 10) = *(undefined8 *)(iVar2 + 0x28);
    *(undefined *)(puVar6 + 0xc) = 0;
    puVar6[0xd] = 0;
    puVar6[0xe] = 0;
    if (*(int *)(iVar2 + 0x38) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar2 + 0x38) + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar6[0xd] = *(undefined4 *)(iVar2 + 0x34);
    puVar6[0xe] = *(undefined4 *)(iVar2 + 0x38);
    puVar6[0xf] = 0;
    *(int *)puVar6[3] = *(int *)puVar6[3] + 1;
    FUN_00951290(puVar6);
    *(undefined4 **)(param_2 + 0x6c) = puVar6;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_2 + 0x6c) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17343 ; VA 0x0095ec80 ; FUN_0095ec80 */

undefined4 FUN_0095ec80(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00912100(aiStack_28);
  uStack_8 = 0;
  FUN_0087de50(param_1,uVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17344 ; VA 0x0095ed00 ; FUN_0095ed00 */

void FUN_0095ed00(int param_1)

{
  char cVar1;
  int iVar2;
  float10 fVar3;
  double dVar4;
  
  fVar3 = (float10)FUN_01257500(param_1,1,0);
  dVar4 = (double)fVar3;
  iVar2 = FUN_0095c9f0();
  if (*(double *)(iVar2 + 0x58) <= dVar4) {
    cVar1 = FUN_00c94370();
    if (cVar1 != '\0') {
      iVar2 = FUN_0095c9f0();
      dVar4 = *(double *)(iVar2 + 0x58);
    }
  }
  else {
    iVar2 = FUN_0095c9f0();
    dVar4 = *(double *)(iVar2 + 0x58);
  }
  if (param_1 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x6c);
  }
  if (*(int *)(*(int *)(*(int *)(iVar2 + 0xc) + 4) + 0x17c) != 0) {
    FUN_00d9e200(param_1,dVar4);
  }
  FUN_01258cc0(param_1,0);
  return;
}



/* FUNCTION 17345 ; VA 0x0095eda0 ; FUN_0095eda0 */

void FUN_0095eda0(undefined4 param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = 2;
  FUN_0094d4b0(param_1,&uStack_8);
  return;
}



/* FUNCTION 17346 ; VA 0x0095edc0 ; FUN_0095edc0 */

void __fastcall FUN_0095edc0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined8 uVar5;
  undefined4 uVar6;
  undefined uVar7;
  undefined4 in_stack_ffffffb0;
  double *pdStack_4c;
  double *pdStack_48;
  undefined auStack_38 [8];
  undefined auStack_30 [8];
  double dStack_28;
  double dStack_20;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cca18;
  pvStack_10 = ExceptionList;
  pdStack_48 = (double *)0x193459c;
  pdStack_4c = (double *)0x95edea;
  ExceptionList = &pvStack_10;
  FUN_0151a220();
  while( true ) {
    puStack_18 = (uint *)(param_1 + 0x364);
    cStack_14 = '\0';
    pdStack_48 = (double *)0x95ee07;
    FUN_00587410();
    pdStack_48 = (double *)auStack_30;
    uStack_8 = 0;
    pdStack_4c = (double *)0x95ee17;
    FUN_0168ea80();
    if (DAT_01ea94c0 == (code *)0x0) {
      uVar3 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
      DAT_01ea94c0 = (code *)GetProcAddress(uVar3);
      if (DAT_01ea94c0 == (code *)0x0) {
        DAT_01ea94c0 = FUN_005efd30;
      }
    }
    uVar5 = (*DAT_01ea94c0)();
    uVar3 = 100;
    uVar6 = 0;
    uVar7 = 1;
    FUN_005f0a90(&pdStack_4c,FUN_005f1e70,uVar5,100,0,1);
    FUN_00560fc0(&puStack_18,uVar5,uVar3,uVar6,uVar7,in_stack_ffffffb0);
    pdStack_48 = (double *)auStack_38;
    pdStack_4c = (double *)0x95ee98;
    FUN_0168ea80();
    if (*(char *)(param_1 + 0x38c) != '\0') break;
    pdStack_48 = &dStack_28;
    pdStack_4c = (double *)0x95eeb1;
    FUN_0151da60();
    pdStack_4c = &dStack_20;
    in_stack_ffffffb0 = 0x95eeba;
    FUN_016830f0();
    if ((((*(char *)(param_1 + 0x1b8) != '\0') && (*(double *)(param_1 + 0x1c0) <= dStack_20)) ||
        ((0.0 < *(double *)(param_1 + 0x1a8) &&
         (*(double *)(param_1 + 0x1a8) < dStack_20 - dStack_28)))) &&
       ((uint *)(param_1 + 0x78) != (uint *)(param_1 + 0xf8))) {
      puVar4 = (uint *)(param_1 + 0xb4);
      do {
        if ((*puVar4 ^ (uint)puVar4) != 0) {
          *(code **)(*(int *)((*puVar4 ^ (uint)puVar4) + 0x10) + 0x3b0) = FUN_00951360;
        }
        puVar1 = puVar4 + 1;
        puVar4 = puVar4 + 0x10;
      } while (puVar1 != (uint *)(param_1 + 0xf8));
    }
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar2 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          pdStack_48 = (double *)0x95ef4e;
          pdStack_48 = (double *)FUN_00554e40();
          pdStack_4c = (double *)0x95ef55;
          SetEvent();
        }
      }
    }
    uStack_8 = 0xffffffff;
  }
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar2 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        pdStack_48 = (double *)0x95ef91;
        pdStack_48 = (double *)FUN_00554e40();
        pdStack_4c = (double *)0x95ef98;
        SetEvent();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17347 ; VA 0x0095efd0 ; FUN_0095efd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0095efd0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088cbe0();
  *param_1 = uVar3;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  iVar2 = _tls_index;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ead3c8) {
    FUN_016f3809(&DAT_01ead3c8);
    if (DAT_01ead3c8 == -1) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
  }
  param_1[1] = &DAT_01ead3bc;
  return param_1;
}



/* FUNCTION 17348 ; VA 0x0095f080 ; FUN_0095f080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_0095f080(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cca4f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee32e4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee32e4);
    if (DAT_01ee32e4 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee32c0 = RBX::Reflection::RefType<class_RBX::Player*>::vftable;
      FUN_016f3654(&LAB_01885d20);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee32e4);
    }
  }
  uVar2 = FUN_00961580();
  FUN_009ca670(uVar2,&DAT_01ee32c0,param_2,param_3,param_7,param_8,param_9,param_10,param_11,
               param_11,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::Players,class_RBX::Player>::vftable;
  param_1[0xd] = (int)RBX::Reflection::RefPropDescriptor<class_RBX::Players,class_RBX::Player>::
                      vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Players,class_RBX::Player*>::
              GetImpl<class_RBX::Player*_(__thiscall_RBX::Players::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17349 ; VA 0x0095f1e0 ; FUN_0095f1e0 */

undefined4 * __thiscall
FUN_0095f1e0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00963440(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17350 ; VA 0x0095f2e0 ; FUN_0095f2e0 */

undefined4 * __thiscall FUN_0095f2e0(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  int *in_stack_00000028;
  uint auStack_64 [2];
  undefined auStack_5c [28];
  int *piStack_40;
  uint auStack_3c [2];
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cca78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00967510(&param_2);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00967510(auStack_64);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00967510(auStack_3c);
  ppuVar4 = &PTR_FUN_01936bac;
  cVar3 = FUN_00963550();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (auStack_3c[0] != 0) {
    if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_3c[0] & 0xfffffffe))(auStack_34,auStack_34,2);
    }
    auStack_3c[0] = 0;
  }
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_40[2] + -1;
    piStack_40[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_40 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (auStack_64[0] != 0) {
    if (((auStack_64[0] & 1) == 0) && (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_64[0] & 0xfffffffe))(auStack_5c,auStack_5c,2);
    }
    auStack_64[0] = 0;
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17351 ; VA 0x0095f430 ; FUN_0095f430 */

undefined4 * __thiscall
FUN_0095f430(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_009636f0(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17352 ; VA 0x0095f530 ; FUN_0095f530 */

undefined4 * __thiscall
FUN_0095f530(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00963800(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17353 ; VA 0x0095f630 ; FUN_0095f630 */

undefined4 * __thiscall FUN_0095f630(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936bd0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17354 ; VA 0x0095f760 ; FUN_0095f760 */

undefined4 * __thiscall
FUN_0095f760(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00963910(param_2,param_3,param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17355 ; VA 0x0095f860 ; FUN_0095f860 */

undefined4 * __thiscall FUN_0095f860(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936bfc;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17356 ; VA 0x0095f990 ; FUN_0095f990 */

undefined4 * __thiscall FUN_0095f990(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936cc0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 17357 ; VA 0x0095fac0 ; FUN_0095fac0 */

undefined4 * __thiscall
FUN_0095fac0(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  char cVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined auStack_f8 [56];
  uint auStack_c0 [2];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined auStack_68 [24];
  uint auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  undefined auStack_30 [24];
  uint *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccae8;
  pvStack_10 = ExceptionList;
  puStack_18 = auStack_88;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  auStack_88[0] = 0;
  if (param_2 != 0) {
    auStack_88[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_80,0);
    }
    else {
      uStack_80 = param_4;
      uStack_7c = param_5;
      uStack_78 = param_6;
      uStack_74 = param_7;
      uStack_70 = param_8;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  puStack_18 = auStack_50;
  uStack_8._0_1_ = 2;
  auStack_50[0] = 0;
  if (auStack_88[0] != 0) {
    auStack_50[0] = auStack_88[0];
    if ((auStack_88[0] & 1) == 0) {
      (**(code **)(auStack_88[0] & 0xfffffffe))(&uStack_80,&uStack_48,0);
    }
    else {
      uStack_48 = uStack_80;
      uStack_44 = uStack_7c;
      uStack_40 = uStack_78;
      uStack_3c = uStack_74;
      uStack_38 = uStack_70;
    }
  }
  uStack_8._0_1_ = 3;
  FUN_0054ef60(auStack_68);
  puStack_18 = auStack_c0;
  uStack_8._0_1_ = 4;
  auStack_c0[0] = 0;
  if (auStack_50[0] != 0) {
    auStack_c0[0] = auStack_50[0];
    if ((auStack_50[0] & 1) == 0) {
      (**(code **)(auStack_50[0] & 0xfffffffe))(&uStack_48,&uStack_b8,0);
    }
    else {
      uStack_b8 = uStack_48;
      uStack_b4 = uStack_44;
      uStack_b0 = uStack_40;
      uStack_ac = uStack_3c;
      uStack_a8 = uStack_38;
    }
  }
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_30);
  uStack_8._0_1_ = 6;
  cVar1 = FUN_00585a40(auStack_c0);
  if (cVar1 == '\0') {
    FUN_005e5f60(auStack_c0);
    uStack_8._0_1_ = 7;
    puStack_18 = (uint *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 8;
    if (puStack_18 == (uint *)0x0) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_005e5f60(auStack_f8);
    }
    param_1[2] = uVar2;
    FUN_005e6120();
    FUN_005e6120();
    cStack_11 = '\x01';
  }
  else {
    FUN_005e6120();
    cStack_11 = '\0';
  }
  FUN_005e6120();
  ppuVar3 = &PTR_FUN_01936c64;
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  FUN_005e6120();
  FUN_005e6120();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17358 ; VA 0x0095fcd0 ; FUN_0095fcd0 */

undefined4 __thiscall
FUN_0095fcd0(undefined4 param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ccb10;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_50,0);
    }
    else {
      uStack_50 = param_4;
      uStack_4c = param_5;
      uStack_48 = param_6;
      uStack_44 = param_7;
      uStack_40 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000024);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0095fac0();
  uStack_20 = 0x95fd60;
  FUN_005e6120();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17359 ; VA 0x0095fd80 ; FUN_0095fd80 */

undefined4 * __fastcall FUN_0095fd80(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined auStack_dc [40];
  undefined auStack_b4 [40];
  undefined auStack_8c [40];
  undefined auStack_64 [40];
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccb68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_008c1490(&stack0x00000004);
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_008c1490(auStack_dc);
  uStack_8._0_1_ = 2;
  FUN_008c1490(auStack_b4);
  uStack_8._0_1_ = 3;
  FUN_008c1490(auStack_8c);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_3c);
  if (cVar2 == '\0') {
    FUN_008c1490(auStack_3c);
    uStack_8._0_1_ = 5;
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 6;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_008c1490(auStack_64);
    }
    param_1[2] = uVar3;
    FUN_008c3670();
    FUN_008c3670();
    bVar1 = true;
  }
  else {
    FUN_008c3670();
    bVar1 = false;
  }
  FUN_008c3670();
  ppuVar4 = &PTR_FUN_01936c28;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_008c3670();
  FUN_008c3670();
  FUN_008c3670();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17360 ; VA 0x0095fed0 ; FUN_0095fed0 */

undefined4 * __thiscall FUN_0095fed0(undefined4 *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_19c [72];
  undefined4 uStack_154;
  undefined auStack_14c [72];
  undefined4 uStack_104;
  undefined auStack_fc [72];
  undefined4 uStack_b4;
  undefined auStack_ac [72];
  undefined4 auStack_64 [2];
  undefined auStack_5c [72];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccbcb;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_009682d0(&stack0x0000000c);
  uStack_154 = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_009682d0(auStack_19c);
  uStack_104 = uStack_154;
  uStack_8._0_1_ = 2;
  FUN_009682d0(auStack_14c);
  auStack_64[0] = uStack_104;
  uStack_8._0_1_ = 3;
  FUN_009682d0(auStack_fc);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_64);
  if (cVar2 == '\0') {
    uStack_b4 = auStack_64[0];
    FUN_009682d0(auStack_5c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_b4;
      FUN_009682d0(auStack_ac);
    }
    param_1[2] = puVar3;
    FUN_0096ca80();
    FUN_0096ca80();
    bVar1 = true;
  }
  else {
    FUN_0096ca80();
    bVar1 = false;
  }
  FUN_0096ca80();
  ppuVar4 = &PTR_FUN_01936c7c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_0096ca80();
  FUN_0096ca80();
  FUN_0096ca80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17361 ; VA 0x00960050 ; FUN_00960050 */

undefined4 * __thiscall
FUN_00960050(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccbf8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x9600bd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x960109);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01936cd8;
  cStack_11 = FUN_00963be0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x960193);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x9601ce);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x9601fc);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17362 ; VA 0x00960220 ; FUN_00960220 */

undefined4 __thiscall
FUN_00960220(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccc18;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00960050();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x9602be;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17363 ; VA 0x009602e0 ; FUN_009602e0 */

undefined4 * __thiscall
FUN_009602e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccc48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x96034d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x960399);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01936ce8;
  cStack_11 = FUN_00963d40();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x960423);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x96045e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x96048c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17364 ; VA 0x009604b0 ; FUN_009604b0 */

undefined4 __thiscall
FUN_009604b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccc68;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_009602e0();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x96054e;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17365 ; VA 0x00960570 ; FUN_00960570 */

undefined4 * __thiscall
FUN_00960570(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccc98;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x9605dd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x960629);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01936ce0;
  cStack_11 = FUN_00963ea0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x9606b3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x9606ee);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x96071c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17366 ; VA 0x00960740 ; FUN_00960740 */

undefined4 __thiscall
FUN_00960740(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cccb8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00960570();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x9607de;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17367 ; VA 0x00960800 ; FUN_00960800 */

undefined4 * __thiscall
FUN_00960800(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccce8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x96086d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x9608b9);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01936cf0;
  cStack_11 = FUN_00964000();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x960943);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x96097e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x9609ac);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17368 ; VA 0x009609d0 ; FUN_009609d0 */

undefined4 __thiscall
FUN_009609d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccd08;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00960800();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x960a6e;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17369 ; VA 0x00960a90 ; FUN_00960a90 */

undefined4 * __thiscall FUN_00960a90(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  uint in_stack_00000044;
  int *in_stack_00000068;
  undefined4 auStack_158 [23];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  undefined4 *puStack_f0;
  undefined auStack_dc [56];
  uint uStack_a4;
  undefined auStack_9c [28];
  int *piStack_80;
  undefined4 uStack_7c;
  undefined auStack_74 [56];
  uint uStack_3c;
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccd3b;
  pvStack_10 = ExceptionList;
  puStack_f0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_f4 = (undefined *)0x960ad4;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00968b60();
  uStack_7c = param_2;
  puStack_f0 = (undefined4 *)auStack_dc;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_f4 = (undefined *)0x960af6;
  FUN_00968b60();
  puStack_f0 = param_1 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puStack_14 = auStack_158;
  auStack_158[0] = uStack_7c;
  FUN_00968b60(auStack_74);
  ppuVar4 = &PTR_FUN_01936cc8;
  cVar3 = FUN_00964160();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_f0 = (undefined4 *)0x960b44;
      (**(code **)(*piStack_18 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = auStack_34;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0x960b65;
      puStack_f4 = puStack_f8;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  puStack_f0 = (undefined4 *)0x960b77;
  FUN_008c3170();
  if (piStack_80 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_80[2] + -1;
    piStack_80[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_f0 = (undefined4 *)0x960b8c;
      (**(code **)(*piStack_80 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_a4 != 0) {
    if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = auStack_9c;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0x960bb3;
      puStack_f4 = puStack_f8;
      (**(code **)(uStack_a4 & 0xfffffffe))();
    }
    uStack_a4 = 0;
  }
  puStack_f0 = (undefined4 *)0x960bcb;
  FUN_008c3170();
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000068 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_f0 = (undefined4 *)0x960bdf;
      (**(code **)(*in_stack_00000068 + 4))();
    }
  }
  uStack_8 = 5;
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      puStack_f8 = &stack0x0000004c;
      puStack_f0 = (undefined4 *)0x2;
      uStack_fc = 0x960c03;
      puStack_f4 = puStack_f8;
      (**(code **)(in_stack_00000044 & 0xfffffffe))();
    }
    in_stack_00000044 = 0;
  }
  puStack_f0 = (undefined4 *)0x960c15;
  FUN_008c3170();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17370 ; VA 0x00960c30 ; FUN_00960c30 */

undefined4 * __thiscall
FUN_00960c30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6)

{
  char cVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 *puStack_8;
  
  uStack_20 = param_2;
  uStack_1c = param_3;
  uStack_18 = param_4;
  uStack_14 = param_5;
  *param_1 = 0;
  uStack_10 = param_6;
  puStack_8 = param_1;
  cVar1 = FUN_00585a40(&uStack_20);
  if (cVar1 == '\0') {
    param_1[2] = uStack_20;
    param_1[3] = uStack_1c;
    param_1[4] = uStack_18;
    param_1[5] = uStack_14;
    *(undefined8 *)(param_1 + 6) = uStack_10;
    *param_1 = &DAT_01936cb1;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 17371 ; VA 0x00960ca0 ; FUN_00960ca0 */

undefined4 * __thiscall FUN_00960ca0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_19c [72];
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined auStack_14c [72];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_fc [72];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [72];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined auStack_5c [72];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccd9b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00968740(&stack0x0000000c);
  uStack_154 = param_2;
  uStack_150 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00968740(auStack_19c);
  uStack_104 = uStack_154;
  uStack_100 = uStack_150;
  uStack_8._0_1_ = 2;
  FUN_00968740(auStack_14c);
  uStack_64 = uStack_104;
  uStack_60 = uStack_100;
  uStack_8._0_1_ = 3;
  FUN_00968740(auStack_fc);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_64);
  if (cVar2 == '\0') {
    uStack_b4 = uStack_64;
    uStack_b0 = uStack_60;
    FUN_00968740(auStack_5c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_b4;
      puVar3[1] = uStack_b0;
      FUN_00968740(auStack_ac);
    }
    param_1[2] = puVar3;
    FUN_0096ca80();
    FUN_0096ca80();
    bVar1 = true;
  }
  else {
    FUN_0096ca80();
    bVar1 = false;
  }
  FUN_0096ca80();
  ppuVar4 = &PTR_FUN_01936c54;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_0096ca80();
  FUN_0096ca80();
  FUN_0096ca80();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17372 ; VA 0x00960e60 ; FUN_00960e60 */

int * __thiscall FUN_00960e60(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_0098d0e0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 17373 ; VA 0x00960eb0 ; FUN_00960eb0 */

int * __thiscall FUN_00960eb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_0098d150();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 17374 ; VA 0x00960f00 ; FUN_00960f00 */

void __thiscall FUN_00960f00(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccdb8;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uStack_3c = 0;
  uVar3 = param_1[0xe];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = param_1 + 0x10;
      uStack_4c = 0x960f66;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_1[0x10];
      uStack_30 = param_1[0x11];
      uStack_2c = param_1[0x12];
      uStack_28 = param_1[0x13];
      uStack_24 = *(undefined8 *)(param_1 + 0x14);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = param_1[6];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 8,&uStack_54,0);
    }
    else {
      uStack_54 = param_1[8];
      uStack_50 = param_1[9];
      uStack_4c = param_1[10];
      puStack_48 = (undefined4 *)param_1[0xb];
      uStack_44 = *(ulonglong *)(param_1 + 0xc);
    }
  }
  if (param_1[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = param_1[4];
  uVar5 = param_1[5];
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar6 = param_1[2];
  uVar7 = param_1[3];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1],uVar6,uVar7,uVar4,uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17375 ; VA 0x00961050 ; FUN_00961050 */

void __thiscall FUN_00961050(int param_1,undefined4 param_2,undefined4 *param_3,int *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  ulonglong uStack_54;
  uint uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccde8;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x5c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x5c) + 8);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_2c = *(undefined4 *)(param_1 + 0x58);
  uStack_28 = *(undefined4 *)(param_1 + 0x5c);
  uStack_8 = 0;
  uStack_4c = 0;
  uVar3 = *(uint *)(param_1 + 0x38);
  if (uVar3 != 0) {
    uStack_4c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_54 = ZEXT48(&uStack_44);
      iStack_58 = param_1 + 0x40;
      uStack_5c = 0x9610ea;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_44 = *(undefined4 *)(param_1 + 0x40);
      uStack_40 = *(undefined4 *)(param_1 + 0x44);
      uStack_3c = *(undefined4 *)(param_1 + 0x48);
      uStack_38 = *(undefined4 *)(param_1 + 0x4c);
      uStack_34 = *(undefined8 *)(param_1 + 0x50);
    }
  }
  uStack_8._0_1_ = 1;
  uVar3 = *(uint *)(param_1 + 0x18);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x20,&uStack_64,0);
    }
    else {
      uStack_64 = *(undefined4 *)(param_1 + 0x20);
      uStack_60 = *(undefined4 *)(param_1 + 0x24);
      uStack_5c = *(undefined4 *)(param_1 + 0x28);
      iStack_58 = *(int *)(param_1 + 0x2c);
      uStack_54 = *(ulonglong *)(param_1 + 0x30);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_1);
  puVar4 = (undefined4 *)param_4[1];
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar5 = *puVar4;
  uVar6 = puVar4[1];
  puVar4 = (undefined4 *)*param_4;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*puVar4,puVar4[1],uVar5,uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17376 ; VA 0x009611c0 ; FUN_009611c0 */

void __thiscall
FUN_009611c0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cce10;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uStack_3c = CONCAT44(*param_4,0x9611f4);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = 0;
  uStack_54 = 0;
  uVar3 = param_1[10];
  if (uVar3 != 0) {
    uStack_54 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = param_1 + 0xc;
      uStack_64 = 0x96123f;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_1[0xc];
      uStack_48 = param_1[0xd];
      uStack_44 = param_1[0xe];
      uStack_40 = param_1[0xf];
      uStack_3c = *(undefined8 *)(param_1 + 0x10);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = param_1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_1 + 4,&uStack_6c,0);
    }
    else {
      uStack_6c = param_1[4];
      uStack_68 = param_1[5];
      uStack_64 = param_1[6];
      puStack_60 = (undefined4 *)param_1[7];
      uStack_5c = *(ulonglong *)(param_1 + 8);
    }
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17377 ; VA 0x009612d0 ; FUN_009612d0 */

void __thiscall FUN_009612d0(int param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cce40;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uVar3 = *(undefined4 *)*param_4;
  uVar4 = *(uint *)(param_1 + 0x48);
  ExceptionList = &pvStack_10;
  if ((uVar4 != 0) && (ExceptionList = &pvStack_10, (uVar4 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar4 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar4 = *(uint *)(param_1 + 0x28);
  if ((uVar4 != 0) && ((uVar4 & 1) == 0)) {
    (**(code **)(uVar4 & 0xfffffffe))();
  }
  if (*(int *)(param_1 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(param_1);
  puVar5 = (undefined4 *)param_4[1];
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(uVar3,*puVar5,puVar5[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17378 ; VA 0x00961450 ; FUN_00961450 */

int __thiscall FUN_00961450(int param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cce60;
  pvStack_10 = ExceptionList;
  piVar8 = *(int **)(param_1 + 0x3c);
  uVar3 = *param_4;
  ExceptionList = &pvStack_10;
  if (piVar8 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(param_1 + 0x3c);
  }
  piVar9 = *(int **)(param_1 + 0x34);
  uVar4 = *(undefined4 *)(param_1 + 0x38);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = *(int **)(param_1 + 0x34);
  }
  uVar5 = *(undefined4 *)(param_1 + 0x30);
  uStack_8 = 1;
  pcVar6 = (code *)*param_3;
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
  }
  iVar7 = (*pcVar6)(param_1 + 8,param_1 + 0x28,uVar5,piVar9,uVar4,piVar8,uVar3);
  if (piVar9 != (int *)0x0) {
    piVar1 = piVar9 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar9 = piVar8 + 1;
    iVar2 = *piVar9;
    iVar7 = *piVar9;
    *piVar9 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*piVar8)();
      LOCK();
      piVar9 = piVar8 + 2;
      iVar2 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17379 ; VA 0x00961580 ; FUN_00961580 */

undefined * FUN_00961580(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cce7c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee30a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee32b8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee32b8);
      if (DAT_01ee32b8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Players",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01885d10);
        FUN_016f37bf(&DAT_01ee32b8);
      }
    }
    DAT_01ee30a8 = &DAT_01ee30b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee30a8;
}



/* FUNCTION 17380 ; VA 0x00961660 ; FUN_00961660 */

void FUN_00961660(void)

{
  int iVar1;
  
  if (DAT_01ee32bc == 0) {
    iVar1 = FUN_00961580();
    DAT_01ee32bc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 17381 ; VA 0x00961680 ; FUN_00961680 */

int FUN_00961680(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cce9b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_006a8fb0(param_1,param_2);
  uStack_8 = 0;
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  FUN_0054ef60(param_3 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_3 + 8);
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 17382 ; VA 0x009616ff ; Catch_All@009616ff */

void Catch_All_009616ff(void)

{
  int unaff_EBP;
  
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17383 ; VA 0x00961720 ; FUN_00961720 */

void FUN_00961720(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_008ed990(param_1,param_2);
  param_4 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_4[1];
  uVar2 = param_4[2];
  uVar3 = param_4[3];
  *(undefined4 *)(iVar4 + 8) = *param_4;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  *(undefined4 *)(iVar4 + 0x20) = 0;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  return;
}



/* FUNCTION 17384 ; VA 0x00961780 ; FUN_00961780 */

void FUN_00961780(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_008ed990(param_1,param_2);
  puVar1 = (undefined4 *)*param_4;
  *(undefined4 *)(iVar2 + 8) = *puVar1;
  *(undefined4 *)(iVar2 + 0xc) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x20) = 0;
  *(undefined4 *)(iVar2 + 0x24) = 0xf;
  *(undefined *)(iVar2 + 0x10) = 0;
  return;
}



/* FUNCTION 17385 ; VA 0x009617c0 ; FUN_009617c0 */

int FUN_009617c0(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cceb0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_009707a0();
  uStack_8 = 0;
  *(undefined2 *)(iVar2 + 0xc) = 0;
  puVar1 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar2 + 0x10) = *puVar1;
  *(undefined4 *)(iVar2 + 0x14) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  uVar3 = FUN_00575b30();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 17386 ; VA 0x0096183c ; Catch_All@0096183c */

void Catch_All_0096183c(void)

{
  int unaff_EBP;
  
  FUN_00970b90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17387 ; VA 0x00961860 ; FUN_00961860 */

int FUN_00961860(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccec8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00970770(param_1,param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_3 + 0x18);
  *(undefined4 *)(iVar2 + 0x38) = *(undefined4 *)(param_3 + 0x30);
  *(undefined4 *)(iVar2 + 0x3c) = 0;
  *(undefined4 *)(iVar2 + 0x40) = 0;
  if (*(int *)(param_3 + 0x38) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_3 + 0x38) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x3c) = *(undefined4 *)(param_3 + 0x34);
  *(undefined4 *)(iVar2 + 0x40) = *(undefined4 *)(param_3 + 0x38);
  *(undefined4 *)(iVar2 + 0x44) = 0;
  *(undefined4 *)(iVar2 + 0x48) = 0;
  if (*(int *)(param_3 + 0x40) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_3 + 0x40) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x44) = *(undefined4 *)(param_3 + 0x3c);
  *(undefined4 *)(iVar2 + 0x48) = *(undefined4 *)(param_3 + 0x40);
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 17388 ; VA 0x00961921 ; Catch_All@00961921 */

void Catch_All_00961921(void)

{
  int unaff_EBP;
  
  FUN_00977d00(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17389 ; VA 0x00961940 ; FUN_00961940 */

void FUN_00961940(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00970740(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uVar1 = param_3[7];
  uVar2 = param_3[8];
  uVar3 = param_3[9];
  *(undefined4 *)(iVar4 + 0x20) = param_3[6];
  *(undefined4 *)(iVar4 + 0x24) = uVar1;
  *(undefined4 *)(iVar4 + 0x28) = uVar2;
  *(undefined4 *)(iVar4 + 0x2c) = uVar3;
  *(undefined8 *)(iVar4 + 0x30) = *(undefined8 *)(param_3 + 10);
  return;
}



/* FUNCTION 17390 ; VA 0x009619a0 ; FUN_009619a0 */

void FUN_009619a0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_006a8fb0(param_1,param_2);
  *(undefined4 *)(iVar4 + 0x18) = 0;
  *(undefined4 *)(iVar4 + 0x1c) = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uVar1 = param_3[7];
  uVar2 = param_3[8];
  uVar3 = param_3[9];
  *(undefined4 *)(iVar4 + 0x20) = param_3[6];
  *(undefined4 *)(iVar4 + 0x24) = uVar1;
  *(undefined4 *)(iVar4 + 0x28) = uVar2;
  *(undefined4 *)(iVar4 + 0x2c) = uVar3;
  uVar1 = param_3[0xb];
  uVar2 = param_3[0xc];
  uVar3 = param_3[0xd];
  *(undefined4 *)(iVar4 + 0x30) = param_3[10];
  *(undefined4 *)(iVar4 + 0x34) = uVar1;
  *(undefined4 *)(iVar4 + 0x38) = uVar2;
  *(undefined4 *)(iVar4 + 0x3c) = uVar3;
  return;
}



/* FUNCTION 17391 ; VA 0x00961a00 ; FUN_00961a00 */

int FUN_00961a00(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_00970740(param_1,param_2);
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = param_3[1];
  *(undefined4 *)(iVar4 + 0x10) = param_3[2];
  *(undefined4 *)(iVar4 + 0x28) = 0;
  *(undefined4 *)(iVar4 + 0x2c) = 0;
  uVar1 = param_3[5];
  uVar2 = param_3[6];
  uVar3 = param_3[7];
  *(undefined4 *)(iVar4 + 0x18) = param_3[4];
  *(undefined4 *)(iVar4 + 0x1c) = uVar1;
  *(undefined4 *)(iVar4 + 0x20) = uVar2;
  *(undefined4 *)(iVar4 + 0x24) = uVar3;
  *(undefined8 *)(iVar4 + 0x28) = *(undefined8 *)(param_3 + 8);
  param_3[8] = 0;
  param_3[9] = 0xf;
  *(undefined *)(param_3 + 4) = 0;
  *(undefined4 *)(iVar4 + 0x30) = param_3[10];
  *(undefined4 *)(iVar4 + 0x34) = param_3[0xb];
  return iVar4;
}



/* FUNCTION 17392 ; VA 0x00961a70 ; FUN_00961a70 */

undefined4 * __thiscall
FUN_00961a70(int *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccee0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  if (*(char *)((int)param_2 + 0xd) == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00559300(param_2 + 4);
    uStack_8 = 0;
    puVar1[1] = param_3;
    *(undefined *)(puVar1 + 3) = *(undefined *)(param_2 + 3);
    if (*(char *)((int)puVar3 + 0xd) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_00961a70(*param_2,puVar1,param_4);
    *puVar1 = uVar2;
    uVar2 = FUN_00961a70(param_2[2],puVar1,param_4);
    puVar1[2] = uVar2;
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 17393 ; VA 0x00961b04 ; Catch_All@00961b04 */

void Catch_All_00961b04(void)

{
  int unaff_EBP;
  
  FUN_00576720(*(undefined4 *)(unaff_EBP + 0xc));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17394 ; VA 0x00961b20 ; FUN_00961b20 */

void FUN_00961b20(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 6;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      puVar1 = puVar6 + 8;
      puVar6 = puVar6 + 0xe;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 17395 ; VA 0x00961b90 ; FUN_00961b90 */

int __thiscall FUN_00961b90(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccef0;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  iVar2 = (int)(param_1[1] - *param_1) / 0x38;
  if (iVar2 == 0x4924924) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar2 + 1;
  uVar3 = (int)(param_1[2] - *param_1) / 0x38;
  uVar7 = uVar5;
  if ((uVar3 <= 0x4924924 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x38;
  if (uVar7 < 0x4924925) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_00961c56;
    if (uVar5 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00961c56:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00961de6;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  uStack_8 = 0;
  iVar4 = ((int)(param_2 - uVar1) / 0x38) * 0x38;
  *(undefined4 *)(iVar4 + uVar7) = *param_3;
  FUN_0054ef60(param_3 + 1);
  *(undefined4 *)(iVar4 + 0x20 + uVar7) = param_3[8];
  *(undefined4 *)(iVar4 + 0x24 + uVar7) = param_3[9];
  *(undefined4 *)(iVar4 + 0x28 + uVar7) = param_3[10];
  *(undefined4 *)(iVar4 + 0x2c + uVar7) = param_3[0xb];
  *(undefined4 *)(iVar4 + 0x30 + uVar7) = param_3[0xc];
  if (param_2 == param_1[1]) {
    FUN_00963180(*param_1,param_1[1],uVar7,param_1);
  }
  else {
    FUN_00963180(*param_1,param_2,uVar7,param_1);
    FUN_00963180(param_2,param_1[1],iVar4 + 0x38 + uVar7,param_1);
  }
  if (*param_1 != 0) {
    FUN_00961b20(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar1) / 0x38) * 0x38;
    uVar3 = uVar1;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar3) - 4) {
LAB_00961de6:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + (iVar2 + 1) * 0x38;
  param_1[2] = uVar5 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 17396 ; VA 0x00961dbd ; Catch_All@00961dbd */

void Catch_All_00961dbd(void)

{
  int unaff_EBP;
  
  FUN_009709b0(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_00875970(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17397 ; VA 0x00961df0 ; FUN_00961df0 */

int __thiscall FUN_00961df0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccf0b;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  iVar3 = (param_1[1] - iVar6) / 0x48;
  if (iVar3 == 0x38e38e3) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar4 = (param_1[2] - iVar6) / 0x48;
  uVar7 = uVar1;
  if ((uVar4 <= 0x38e38e3 - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar5 = FUN_008ee5b0(uVar7);
  iStack_8 = 0;
  iVar6 = ((param_2 - iVar6) / 0x48) * 0x48;
  puVar2 = (undefined4 *)(iVar6 + iVar5);
  *puVar2 = *param_3;
  puVar2[1] = param_3[1];
  puVar2[2] = 0;
  FUN_005880d0(param_3 + 2);
  iStack_8._0_1_ = 1;
  *(undefined4 *)(iVar6 + 0x28 + iVar5) = 0;
  FUN_005880d0(param_3 + 10);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (param_2 == param_1[1]) {
    FUN_00971200(*param_1,param_1[1],iVar5);
  }
  else {
    FUN_009710f0(*param_1,param_2,iVar5);
    FUN_009710f0(param_2,param_1[1],puVar2 + 0x12);
  }
  FUN_009707c0(iVar5,iVar3 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 17398 ; VA 0x00961f61 ; Catch_All@00961f61 */

void Catch_All_00961f61(void)

{
  int unaff_EBP;
  
  FUN_00970980(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_008f20b0(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17399 ; VA 0x00961f90 ; FUN_00961f90 */

int __thiscall FUN_00961f90(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccf20;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0x58;
  if (iVar2 == 0x2e8ba2e) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0x58;
  uVar7 = uVar1;
  if ((uVar3 <= 0x2e8ba2e - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006181a0(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0x58) * 0x58;
  iVar6 = iVar5 + iVar4;
  FUN_00965bb0(param_1,iVar6,param_3);
  if (param_2 == param_1[1]) {
    FUN_00971300(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_00971190(*param_1,param_2,iVar4);
    FUN_00971190(param_2,param_1[1],iVar6 + 0x58);
  }
  FUN_00970850(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 17400 ; VA 0x00961fb4 ; FUN_00961fb4 */

int __fastcall FUN_00961fb4(int *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int in_EAX;
  int iVar3;
  int iVar4;
  int unaff_EBP;
  uint uVar5;
  
  *(undefined **)(unaff_EBP + -0x10) = &stack0xfffffff8;
  *(int **)(unaff_EBP + -0x28) = param_1;
  iVar2 = *param_1;
  iVar3 = param_1[1];
  iVar4 = (int)((ulonglong)((longlong)in_EAX * (longlong)(param_2 - iVar2)) >> 0x20);
  *(int *)(unaff_EBP + -0x1c) = (iVar4 >> 4) - (iVar4 >> 0x1f);
  iVar3 = (iVar3 - iVar2) / 0x58;
  *(int *)(unaff_EBP + -0x24) = iVar3;
  if (iVar3 != 0x2e8ba2e) {
    uVar1 = iVar3 + 1;
    uVar5 = (param_1[2] - iVar2) / 0x58;
    if (0x2e8ba2e - (uVar5 >> 1) < uVar5) {
      *(uint *)(unaff_EBP + -0x20) = uVar1;
      uVar5 = uVar1;
    }
    else {
      uVar5 = (uVar5 >> 1) + uVar5;
      if (uVar5 < uVar1) {
        uVar5 = uVar1;
      }
      *(uint *)(unaff_EBP + -0x20) = uVar5;
    }
    iVar3 = FUN_006181a0(uVar5);
    *(undefined4 *)(unaff_EBP + -4) = 0;
    iVar4 = *(int *)(unaff_EBP + -0x1c) * 0x58;
    *(int *)(unaff_EBP + -0x2c) = iVar3;
    *(int *)(unaff_EBP + -0x18) = iVar4;
    iVar4 = iVar4 + iVar3;
    iVar2 = iVar4 + 0x58;
    *(int *)(unaff_EBP + -0x1c) = iVar2;
    *(int *)(unaff_EBP + -0x14) = iVar2;
    FUN_00965bb0(param_1,iVar4,*(undefined4 *)(unaff_EBP + 0xc));
    *(int *)(unaff_EBP + -0x14) = *(int *)(unaff_EBP + -0x18) + iVar3;
    if (*(int *)(unaff_EBP + 8) == param_1[1]) {
      FUN_00971300(*param_1,param_1[1],iVar3);
    }
    else {
      FUN_00971190(*param_1,*(int *)(unaff_EBP + 8),iVar3);
      *(int *)(unaff_EBP + -0x14) = iVar3;
      FUN_00971190(*(undefined4 *)(unaff_EBP + 8),param_1[1],*(undefined4 *)(unaff_EBP + -0x1c));
    }
    FUN_00970850(iVar3,*(int *)(unaff_EBP + -0x24) + 1,uVar5);
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return *param_1 + *(int *)(unaff_EBP + -0x18);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 17401 ; VA 0x009620c4 ; Catch_All@009620c4 */

void Catch_All_009620c4(void)

{
  int unaff_EBP;
  
  FUN_009709d0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0061a4a0(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17402 ; VA 0x009620f0 ; FUN_009620f0 */

void FUN_009620f0(undefined4 param_1,undefined4 param_2)

{
  FUN_01674ea0(param_2,0x40);
  return;
}



/* FUNCTION 17403 ; VA 0x00962110 ; FUN_00962110 */

undefined4 * FUN_00962110(uint *param_1)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccf30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_01674e20(0x30);
  uStack_8 = 0;
  *puVar5 = std::_Func_impl_no_alloc<class_<lambda_1993c8f80a19440b3c1114da67410a4c>,void>::vftable;
  puVar5[2] = 0;
  uVar2 = *param_1;
  if (uVar2 != 0) {
    puVar5[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 2,puVar5 + 4,0);
    }
    else {
      uVar2 = param_1[3];
      uVar3 = param_1[4];
      uVar4 = param_1[5];
      puVar5[4] = param_1[2];
      puVar5[5] = uVar2;
      puVar5[6] = uVar3;
      puVar5[7] = uVar4;
      *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(param_1 + 6);
    }
  }
  puVar5[10] = 0;
  puVar5[0xb] = 0;
  if (param_1[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[9] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  puVar5[10] = param_1[8];
  puVar5[0xb] = param_1[9];
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 17404 ; VA 0x009621c5 ; Catch_All@009621c5 */

void Catch_All_009621c5(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17405 ; VA 0x009621e0 ; FUN_009621e0 */

undefined4 * FUN_009621e0(int param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ccf40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x30);
  uStack_8 = 0;
  *puVar1 = std::_Func_impl_no_alloc<class_<lambda_1993c8f80a19440b3c1114da67410a4c>,void>::vftable;
  puVar1[2] = 0;
  FUN_005880d0(param_1);
  puVar1[10] = 0;
  puVar1[0xb] = 0;
  puVar1[10] = *(undefined4 *)(param_1 + 0x20);
  puVar1[0xb] = *(undefined4 *)(param_1 + 0x24);
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 17406 ; VA 0x0096226b ; Catch_All@0096226b */

void Catch_All_0096226b(void)

{
  int unaff_EBP;
  
  FUN_0054db70(*(undefined4 *)(unaff_EBP + -0x14),0x30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17407 ; VA 0x00962290 ; FUN_00962290 */

void __thiscall FUN_00962290(float *param_1,float *param_2,undefined4 *param_3,float *param_4)

{
  byte *pbVar1;
  float fVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  float fVar9;
  uint uVar10;
  float fVar11;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccf50;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  pfStack_18 = (float *)param_3;
  if (0xf < (uint)param_3[5]) {
    pfStack_18 = (float *)*param_3;
  }
  uVar7 = 0;
  uVar10 = 0x811c9dc5;
  if (param_3[4] != 0) {
    do {
      pbVar1 = (byte *)(uVar7 + (int)pfStack_18);
      uVar7 = uVar7 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar7 < (uint)param_3[4]);
  }
  fVar9 = param_1[3];
  uVar10 = (uint)param_1[6] & uVar10;
  fVar11 = param_1[1];
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  puVar4 = &stack0xffffffd0;
  if (fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
    fVar11 = **(float **)((int)fVar9 + 4 + uVar10 * 8);
    ExceptionList = &pvStack_10;
    while (puVar4 = puStack_14, fVar11 != *(float *)((int)fVar9 + uVar10 * 8)) {
      fVar11 = *(float *)((int)fVar11 + 4);
      piVar6 = (int *)((int)fVar11 + 8);
      if (0xf < *(uint *)((int)fVar11 + 0x1c)) {
        piVar6 = (int *)*piVar6;
      }
      puVar8 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar8 = (undefined4 *)*param_3;
      }
      cVar5 = FUN_0055c360(puVar8,param_3[4],piVar6,*(undefined4 *)((int)fVar11 + 0x18));
      fVar9 = param_1[3];
      if (cVar5 != '\0') {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_00970bb0(param_4);
        *param_2 = fVar11;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  puStack_14 = puVar4;
  pfStack_18 = param_4;
  fVar9 = *param_4;
  if (fVar11 != fVar9) {
    *(float *)param_4[1] = fVar9;
    **(float **)((int)fVar9 + 4) = fVar11;
    **(undefined4 **)((int)fVar11 + 4) = param_4;
    fVar2 = *(float *)((int)fVar11 + 4);
    *(undefined4 *)((int)fVar11 + 4) = *(undefined4 *)((int)fVar9 + 4);
    *(float *)((int)fVar9 + 4) = param_4[1];
    param_4[1] = fVar2;
  }
  fVar9 = param_1[3];
  fVar2 = *(float *)((int)fVar9 + uVar10 * 8);
  if (fVar2 == param_1[1]) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar10 * 8) = param_4;
  }
  else if (fVar2 == fVar11) {
    *(float **)((int)fVar9 + uVar10 * 8) = param_4;
  }
  else {
    pfVar3 = (float *)**(undefined4 **)((int)fVar9 + 4 + uVar10 * 8);
    *(float **)((int)fVar9 + 4 + uVar10 * 8) = pfVar3;
    if (pfVar3 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar10 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar10 * 8) + 4);
    }
  }
  fVar9 = param_1[7];
  uStack_8 = 2;
  fVar11 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
           (float)((double)(int)fVar9 + (double)(&DAT_018c0d90)[-((int)fVar9 >> 0x1f)]);
  if (*param_1 <= fVar11 && fVar11 != *param_1) {
    if ((uint)fVar9 < 0x200) {
      fVar9 = (float)((int)fVar9 << 3);
    }
    else if ((uint)fVar9 < 0x1fffffff) {
      fVar9 = (float)((int)fVar9 * 2);
    }
    FUN_005cb500(fVar9);
    pfVar3 = (float *)param_1[1];
    if ((float *)*pfVar3 != pfVar3) {
      fVar9 = pfVar3[1];
      do {
        fVar11 = *(float *)param_1[1];
        FUN_00962290(auStack_24,(int)fVar11 + 8,fVar11);
      } while (fVar11 != fVar9);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17408 ; VA 0x00962498 ; Catch_All@00962498 */

void Catch_All_00962498(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 0xc,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00966670(unaff_EBP + 8,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17409 ; VA 0x009624c0 ; FUN_009624c0 */

void __thiscall FUN_009624c0(float *param_1,float *param_2,int *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  uint uVar3;
  float fVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccf60;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pfStack_1c = param_1;
  uVar3 = FUN_005e6570(param_3);
  uVar3 = uVar3 & (uint)param_1[6];
  fVar4 = param_1[1];
  fVar5 = *(float *)((int)param_1[3] + uVar3 * 8);
  if (fVar4 != fVar5) {
    fVar4 = **(float **)((int)param_1[3] + 4 + uVar3 * 8);
    while (fVar4 != fVar5) {
      fVar4 = *(float *)((int)fVar4 + 4);
      if ((*param_3 == *(int *)((int)fVar4 + 8)) && (param_3[1] == *(int *)((int)fVar4 + 0xc))) {
        *(float *)param_4[1] = *param_4;
        *(float *)((int)*param_4 + 4) = param_4[1];
        param_1[2] = (float)((int)param_1[2] + -1);
        FUN_006552a0(param_4);
        *param_2 = fVar4;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  if (fVar4 != fVar5) {
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar4;
    **(undefined4 **)((int)fVar4 + 4) = param_4;
    fVar1 = *(float *)((int)fVar4 + 4);
    *(undefined4 *)((int)fVar4 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar3 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar3 * 8) = param_4;
  }
  else if (fVar1 == fVar4) {
    *(float **)((int)fVar5 + uVar3 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar3 * 8);
    *(float **)((int)fVar5 + 4 + uVar3 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar3 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar3 * 8) + 4);
    }
  }
  fVar4 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar4 + (double)(&DAT_018c0d90)[-((int)fVar4 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar4 < 0x200) {
      fVar4 = (float)((int)fVar4 << 3);
    }
    else if ((uint)fVar4 < 0x1fffffff) {
      fVar4 = (float)((int)fVar4 * 2);
    }
    FUN_005cb500(fVar4);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar4 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_009624c0(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar4);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17410 ; VA 0x00962677 ; Catch_All@00962677 */

void Catch_All_00962677(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00966720(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17411 ; VA 0x009626a0 ; FUN_009626a0 */

void __thiscall
FUN_009626a0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x7fffffd < (uint)param_1[1]) {
    FUN_00970a00(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00962752:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00962752;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 17412 ; VA 0x00962800 ; FUN_00962800 */

undefined4 * __thiscall
FUN_00962800(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined auStack_24 [8];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccf70;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    FUN_009626a0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar4 = (int *)*param_1;
  if (param_3 == (int *)*piVar4) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0, *param_4 < (uint)param_3[4]))))
    {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_009626a0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar4) {
    iVar1 = piVar4[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd0;
    if ((*(int *)(iVar1 + 0x14) <= (int)param_4[1]) &&
       ((*(int *)(iVar1 + 0x14) < (int)param_4[1] ||
        (ExceptionList = &pvStack_10, puStack_14 = &stack0xffffffd0,
        *(uint *)(iVar1 + 0x10) < *param_4)))) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd0;
      FUN_009626a0(param_2,0,iVar1,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar2 = &stack0xffffffd0;
    if (((int)param_4[1] <= param_3[5]) &&
       (((int)param_4[1] < param_3[5] ||
        (ExceptionList = &pvStack_10, puVar2 = &stack0xffffffd0, *param_4 < (uint)param_3[4])))) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar4 = (int *)FUN_0056f560();
      cVar3 = FUN_0096e550(*piVar4 + 0x10,param_4);
      puVar2 = puStack_14;
      if (cVar3 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_009626a0(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_009626a0(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    puStack_14 = puVar2;
    cVar3 = FUN_0096e550(param_3 + 4,param_4);
    if (cVar3 != '\0') {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      piVar4 = piStack_18;
      if ((*piVar5 == *param_1) || (cVar3 = FUN_0096e550(param_4,piStack_18 + 4), cVar3 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_009626a0(param_2,1,piVar4,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_009626a0(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00962a50(auStack_24,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17413 ; VA 0x00962a35 ; Catch_All@00962a35 */

void Catch_All_00962a35(void)

{
  int unaff_EBP;
  
  FUN_00970a00(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17414 ; VA 0x00962a50 ; FUN_00962a50 */

void __thiscall
FUN_00962a50(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccf80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar4 = '\x01';
  piVar2 = (int *)*param_1;
  piVar5 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    uVar1 = param_4[1];
    piVar2 = (int *)piVar2[1];
    do {
      piVar5 = piVar2;
      if (param_3 == '\0') {
        if ((piVar5[5] < (int)uVar1) || ((piVar5[5] <= (int)uVar1 && ((uint)piVar5[4] <= *param_4)))
           ) {
          cVar4 = '\0';
          goto LAB_00962add;
        }
        piVar2 = (int *)*piVar5;
        cVar4 = '\x01';
      }
      else {
        if (((int)uVar1 < piVar5[5]) || (((int)uVar1 <= piVar5[5] && (*param_4 <= (uint)piVar5[4])))
           ) {
          cVar4 = '\x01';
        }
        else {
          cVar4 = '\0';
        }
        if (cVar4 == '\0') {
LAB_00962add:
          piVar2 = (int *)piVar5[2];
        }
        else {
          piVar2 = (int *)*piVar5;
        }
      }
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    piVar2 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar5;
  if (cVar4 != '\0') {
    if (piVar5 == (int *)*piVar2) {
      cVar4 = '\x01';
      ExceptionList = &pvStack_10;
      goto LAB_00962afe;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  piVar2 = _param_3;
  if (((int)param_4[1] < _param_3[5]) ||
     (((int)param_4[1] <= _param_3[5] && (*param_4 <= (uint)_param_3[4])))) {
    FUN_00970a00(param_5);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00962afe:
  puVar3 = (undefined4 *)FUN_009626a0(&param_3,cVar4,piVar5,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17415 ; VA 0x00962b76 ; Catch_All@00962b76 */

void Catch_All_00962b76(void)

{
  int unaff_EBP;
  
  FUN_00970a00(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17416 ; VA 0x00962b90 ; FUN_00962b90 */

void __thiscall FUN_00962b90(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccf90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  while( true ) {
    if (param_3 == param_4) {
      ExceptionList = pvStack_10;
      return;
    }
    puVar1 = *(undefined4 **)(param_2 + 4);
    uVar2 = FUN_00961680(param_2,puVar1,param_3 + 2);
    if (*(int *)(param_1 + 4) == 0x3fffffe) break;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 1;
    *(undefined4 *)(param_2 + 4) = uVar2;
    *puVar1 = uVar2;
    param_3 = (undefined4 *)*param_3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 17417 ; VA 0x00962c0a ; Catch_All@00962c0a */

void Catch_All_00962c0a(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int unaff_EBP;
  
  puVar2 = *(undefined4 **)(unaff_EBP + -0x14);
  for (puVar1 = *(undefined4 **)(unaff_EBP + -0x20); puVar1 != puVar2;
      puVar1 = (undefined4 *)*puVar1) {
    FUN_00971400(*(undefined4 *)(*(int *)(unaff_EBP + 8) + 4));
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17418 ; VA 0x00962c60 ; FUN_00962c60 */

void FUN_00962c60(int param_1,undefined4 *param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccfab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00651cc0();
  *(undefined4 *)(param_1 + 8) = *param_2;
  *(undefined4 *)(param_1 + 0xc) = param_2[1];
  FUN_0054ef60(param_2 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_2 + 8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17419 ; VA 0x00962cdb ; Catch_All@00962cdb */

void Catch_All_00962cdb(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = *(undefined4 *)(unaff_EBP + -0x14);
  FUN_00971440(*(undefined4 *)(unaff_EBP + 8));
  FUN_009620f0(uVar1,*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17420 ; VA 0x00962d00 ; FUN_00962d00 */

void __thiscall FUN_00962d00(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccfc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::AbuseReporter::data>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17421 ; VA 0x00962d6e ; Catch_All@00962d6e */

void Catch_All_00962d6e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0096f430(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17422 ; VA 0x00962d90 ; FUN_00962d90 */

void __thiscall FUN_00962d90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccfd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::vector<struct_RBX::Players::PlayerNameRequest,class_std::allocator<struct_RBX::Players::PlayerNameRequest>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17423 ; VA 0x00962dfe ; Catch_All@00962dfe */

void Catch_All_00962dfe(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0096f290(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17424 ; VA 0x00962e20 ; FUN_00962e20 */

void __thiscall FUN_00962e20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccfe0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::vector<struct_RBX::Players::UserIdRequest,class_std::allocator<struct_RBX::Players::UserIdRequest>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17425 ; VA 0x00962e8e ; Catch_All@00962e8e */

void Catch_All_00962e8e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0096f330(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17426 ; VA 0x00962eb0 ; FUN_00962eb0 */

int __thiscall FUN_00962eb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ccff0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Value<bool>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17427 ; VA 0x00962f82 ; Catch_All@00962f82 */

void Catch_All_00962f82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17428 ; VA 0x00962fa0 ; FUN_00962fa0 */

int __thiscall FUN_00962fa0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd000;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::FriendPages*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17429 ; VA 0x00963072 ; Catch_All@00963072 */

void Catch_All_00963072(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17430 ; VA 0x00963090 ; FUN_00963090 */

int __thiscall FUN_00963090(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::StarterGear*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17431 ; VA 0x00963162 ; Catch_All@00963162 */

void Catch_All_00963162(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17432 ; VA 0x00963180 ; FUN_00963180 */

undefined4 *
FUN_00963180(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar7 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 6;
    puVar6 = param_3 + 1;
    do {
      *puVar7 = puVar5[-6];
      puVar6[4] = 0;
      puVar7 = puVar7 + 0xe;
      *(undefined4 *)((int)param_3 + (-0x38 - (int)param_1) + (int)(puVar5 + 0xe)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      *puVar6 = puVar5[-5];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -1);
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar6[7] = puVar5[2];
      puVar6[8] = puVar5[3];
      puVar6[9] = puVar5[4];
      puVar6[10] = puVar5[5];
      puVar6[0xb] = puVar5[6];
      puVar1 = puVar5 + 8;
      puVar5 = puVar5 + 0xe;
      puVar6 = puVar6 + 0xe;
    } while (puVar1 != param_2);
  }
  FUN_00961b20(puVar7,puVar7,param_4);
  return puVar7;
}



/* FUNCTION 17433 ; VA 0x00963220 ; FUN_00963220 */

void __thiscall FUN_00963220(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd020;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar6 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  for (; piVar6 = (int *)*piVar6, param_2 != param_3; param_2 = (undefined4 *)*param_2) {
    if (piVar6 == (int *)*param_1) goto LAB_00963275;
    FUN_00962c60(piVar6,param_2 + 2);
  }
LAB_009632bc:
  piVar3 = (int *)*param_1;
  if (piVar6 == (int *)*piVar3) {
    FUN_00973910();
    ExceptionList = pvStack_10;
    return;
  }
  while (piVar6 != piVar3) {
    piVar4 = (int *)*piVar6;
    *(int **)piVar6[1] = piVar4;
    *(int *)(*piVar6 + 4) = piVar6[1];
    param_1[1] = param_1[1] + -1;
    FUN_00651cc0();
    FUN_01674ea0(piVar6,0x40);
    piVar6 = piVar4;
  }
  ExceptionList = pvStack_10;
  return;
LAB_00963275:
  for (; param_2 != param_3; param_2 = (undefined4 *)*param_2) {
    iVar1 = *param_1;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar5 = FUN_00961680(iVar1,puVar2,param_2 + 2);
    if (param_1[1] == 0x3fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar5;
    *puVar2 = uVar5;
  }
  goto LAB_009632bc;
}



/* FUNCTION 17434 ; VA 0x0096332c ; Catch_All@0096332c */

void Catch_All_0096332c(void)

{
  FUN_00973910();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17435 ; VA 0x00963340 ; FUN_00963340 */

undefined FUN_00963340(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4,
                      undefined4 *param_5)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  undefined uVar6;
  
  cVar5 = FUN_00585a40(&param_1);
  piVar2 = param_4;
  piVar3 = param_2;
  if (cVar5 == '\0') {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    *param_5 = 0;
    param_5[1] = 0;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    *param_5 = param_1;
    param_5[1] = param_2;
    param_5[2] = 0;
    param_5[3] = 0;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    param_5[2] = param_3;
    param_5[3] = param_4;
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar4 = param_4[1] + -1;
      param_4[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    uVar6 = 1;
  }
  else {
    uVar6 = 0;
  }
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2 + -1;
      *piVar2 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar4 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return uVar6;
}



/* FUNCTION 17436 ; VA 0x00963440 ; FUN_00963440 */

undefined ** __thiscall
FUN_00963440(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936be0;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 17437 ; VA 0x00963550 ; FUN_00963550 */

undefined FUN_00963550(uint param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined uVar5;
  int *in_stack_00000028;
  undefined4 *in_stack_0000002c;
  uint auStack_64 [2];
  undefined auStack_5c [28];
  int *piStack_40;
  uint auStack_3c [2];
  undefined auStack_34 [28];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd057;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00967510(&param_1);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_3c);
  if (cVar3 == '\0') {
    FUN_00967510(auStack_3c);
    uStack_8._0_1_ = 2;
    iStack_14 = FUN_01674e20(0x28);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_14 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_00967510(auStack_64);
    }
    *in_stack_0000002c = uVar4;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (auStack_64[0] != 0) {
      if (((auStack_64[0] & 1) == 0) && (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_64[0] & 0xfffffffe))(auStack_5c,auStack_5c,2);
      }
      auStack_64[0] = 0;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar5 = 1;
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (auStack_3c[0] != 0) {
      if (((auStack_3c[0] & 1) == 0) && (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_3c[0] & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      auStack_3c[0] = 0;
    }
    uVar5 = 0;
  }
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000028 + 4))();
    }
  }
  uStack_8 = 7;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 17438 ; VA 0x009636f0 ; FUN_009636f0 */

undefined ** __thiscall
FUN_009636f0(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936bd8;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 17439 ; VA 0x00963800 ; FUN_00963800 */

undefined ** __thiscall
FUN_00963800(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936c04;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 17440 ; VA 0x00963910 ; FUN_00963910 */

undefined ** __thiscall
FUN_00963910(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  cVar3 = FUN_00963340(param_2,param_3,param_4,param_5,param_1 + 2,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936c0c;
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = (int)ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    ppuVar4 = (undefined **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      ppuVar4 = (undefined **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuVar4 = (undefined **)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      ppuVar4 = (undefined **)(**(code **)(*param_3 + 4))();
    }
  }
  return ppuVar4;
}



/* FUNCTION 17441 ; VA 0x00963a20 ; FUN_00963a20 */

void __thiscall FUN_00963a20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [24];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined auStack_54 [24];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [24];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cd0bf;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_80;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(param_4 + 4) = *(int *)(param_4 + 4) + 1;
    UNLOCK();
  }
  uStack_80 = param_3;
  iStack_7c = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_0054ef60(&stack0x00000010);
  uStack_3c = param_2;
  puStack_14 = &uStack_38;
  if (iStack_7c != 0) {
    LOCK();
    *(int *)(iStack_7c + 4) = *(int *)(iStack_7c + 4) + 1;
    UNLOCK();
  }
  uStack_38 = uStack_80;
  iStack_34 = iStack_7c;
  uStack_8 = 3;
  FUN_0054ef60(auStack_78);
  uStack_8 = 4;
  cVar2 = FUN_00585a40(&uStack_3c);
  if (cVar2 == '\0') {
    uStack_60 = uStack_3c;
    puStack_14 = &uStack_5c;
    if (iStack_34 != 0) {
      LOCK();
      *(int *)(iStack_34 + 4) = *(int *)(iStack_34 + 4) + 1;
      UNLOCK();
    }
    uStack_5c = uStack_38;
    iStack_58 = iStack_34;
    uStack_8 = 5;
    FUN_0054ef60(auStack_30);
    uStack_8 = 6;
    puVar3 = (undefined4 *)FUN_01674e20(0x24);
    uStack_8 = 7;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_60;
      puStack_18 = puVar3 + 1;
      *puStack_18 = 0;
      puVar3[2] = 0;
      if (iStack_58 != 0) {
        LOCK();
        *(int *)(iStack_58 + 4) = *(int *)(iStack_58 + 4) + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_5c;
      puVar3[2] = iStack_58;
      uStack_8 = 8;
      FUN_0054ef60(auStack_54);
    }
    param_1[2] = puVar3;
    FUN_006511a0();
    FUN_006511a0();
    bVar1 = true;
  }
  else {
    FUN_006511a0();
    bVar1 = false;
  }
  FUN_006511a0();
  ppuVar4 = &PTR_FUN_01936c98;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_006511a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17442 ; VA 0x00963be0 ; FUN_00963be0 */

undefined FUN_00963be0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd0ef;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 17443 ; VA 0x00963d40 ; FUN_00963d40 */

undefined FUN_00963d40(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd11f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 17444 ; VA 0x00963ea0 ; FUN_00963ea0 */

undefined FUN_00963ea0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd14f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 17445 ; VA 0x00964000 ; FUN_00964000 */

undefined FUN_00964000(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd17f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 17446 ; VA 0x00964160 ; FUN_00964160 */

undefined FUN_00964160(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined uVar5;
  uint in_stack_00000044;
  int *in_stack_00000068;
  int *in_stack_0000006c;
  undefined4 auStack_e4 [2];
  undefined auStack_dc [96];
  undefined4 uStack_7c;
  undefined auStack_74 [56];
  uint uStack_3c;
  undefined auStack_34 [28];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd1ba;
  pvStack_10 = ExceptionList;
  auStack_e4[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00968b60(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar3 = FUN_00585a40(auStack_e4);
  if (cVar3 == '\0') {
    uStack_7c = auStack_e4[0];
    FUN_00968b60(auStack_dc);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_01674e20(0x68);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uStack_7c;
      FUN_00968b60(auStack_74);
    }
    *in_stack_0000006c = (int)puVar4;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    uStack_8._0_1_ = 4;
    if (uStack_3c != 0) {
      if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_3c & 0xfffffffe))(auStack_34,auStack_34,2);
      }
      uStack_3c = 0;
    }
    FUN_008c3170();
    FUN_0096c4f0();
    uVar5 = 1;
  }
  else {
    FUN_0096c4f0();
    uVar5 = 0;
  }
  if (in_stack_00000068 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000068 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*in_stack_00000068 + 4))();
    }
  }
  uStack_8 = 5;
  if (in_stack_00000044 != 0) {
    if (((in_stack_00000044 & 1) == 0) &&
       (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000044 & 0xfffffffe))(&stack0x0000004c,&stack0x0000004c,2);
    }
    in_stack_00000044 = 0;
  }
  FUN_008c3170();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 17447 ; VA 0x009642d0 ; FUN_009642d0 */

void __thiscall
FUN_009642d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 auStack_28 [2];
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  auStack_28[0] = param_2;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  uStack_20 = param_4;
  piStack_1c = param_5;
  uStack_18 = param_6;
  uStack_14 = param_7;
  cVar3 = FUN_00585a40(auStack_28);
  if (cVar3 == '\0') {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_18;
    uStack_10 = uStack_14;
    param_1[2] = auStack_28[0];
    param_1[4] = 0;
    param_1[5] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[2] = piStack_1c[2] + 1;
      UNLOCK();
    }
    param_1[4] = uStack_20;
    param_1[5] = piStack_1c;
    param_1[6] = uStack_18;
    param_1[7] = uStack_14;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[2] + -1;
    param_5[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_5 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01936cb8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 4))();
    }
  }
  return;
}



/* FUNCTION 17448 ; VA 0x00964400 ; FUN_00964400 */

undefined FUN_00964400(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000054;
  int *in_stack_00000074;
  undefined auStack_ec [72];
  uint uStack_a4;
  undefined auStack_9c [24];
  undefined4 auStack_84 [2];
  undefined auStack_7c [72];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd1fa;
  pvStack_10 = ExceptionList;
  auStack_84[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00969050(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_84);
  uVar1 = auStack_84[0];
  if (cVar2 == '\0') {
    FUN_00969050(auStack_7c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x70);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00969050(auStack_ec);
    }
    *in_stack_00000074 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_a4 != 0) {
      if (((uStack_a4 & 1) == 0) && (*(code **)(uStack_a4 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_a4 & 0xfffffffe))(auStack_9c,auStack_9c,2);
      }
      uStack_a4 = 0;
    }
    FUN_0096cca0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_0096cca0();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_0096cca0();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000054 != 0) {
    if (((in_stack_00000054 & 1) == 0) &&
       (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000054 & 0xfffffffe))(&stack0x0000005c,&stack0x0000005c,2);
    }
    in_stack_00000054 = 0;
  }
  FUN_0096cca0();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 17449 ; VA 0x009645a0 ; FUN_009645a0 */

uint * FUN_009645a0(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,int param_9)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000003c;
  uint uStack_7c;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  undefined8 uStack_64;
  int aiStack_5c [5];
  uint uStack_48;
  int aiStack_44 [5];
  uint uStack_30;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd248;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_9);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(aiStack_44);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(aiStack_2c);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    iVar2 = aiStack_2c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_2c[0] + -4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_30) {
    uVar3 = uStack_30 + 1;
    iVar2 = aiStack_44[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_44[0] + -4);
      uVar3 = uStack_30 + 0x24;
      if (0x1f < (aiStack_44[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8._0_1_ = 4;
  uStack_7c = 0;
  if (param_2 != 0) {
    uStack_7c = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_74,0);
    }
    else {
      uStack_74 = param_4;
      uStack_70 = param_5;
      uStack_6c = param_6;
      uStack_68 = param_7;
      uStack_64 = param_8;
    }
  }
  uStack_8._0_1_ = 5;
  *param_1 = 0;
  if (uStack_7c != 0) {
    *param_1 = uStack_7c;
    if ((uStack_7c & 1) == 0) {
      (**(code **)(uStack_7c & 0xfffffffe))(&uStack_74,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_74;
      param_1[3] = uStack_70;
      param_1[4] = uStack_6c;
      param_1[5] = uStack_68;
      *(undefined8 *)(param_1 + 6) = uStack_64;
    }
  }
  uStack_8._0_1_ = 6;
  FUN_0054ef60(aiStack_5c);
  uStack_8._0_1_ = 7;
  if (((uStack_7c != 0) && ((uStack_7c & 1) == 0)) &&
     (*(code **)(uStack_7c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_7c & 0xfffffffe))(&uStack_74,&uStack_74,2);
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_48) {
    uVar3 = uStack_48 + 1;
    iVar2 = aiStack_5c[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_5c[0] + -4);
      uVar3 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar2) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  if (0xf < in_stack_0000003c) {
    uVar3 = in_stack_0000003c + 1;
    iVar2 = param_9;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_9 + -4);
      uVar3 = in_stack_0000003c + 0x24;
      if (0x1f < (param_9 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17450 ; VA 0x009647e0 ; FUN_009647e0 */

uint * FUN_009647e0(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,uint param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_10;
  puStack_c = &LAB_017cd280;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_9;
  if (param_10 != (int *)0x0) {
    piVar1 = param_10 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_20 = param_9;
  piStack_1c = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  uStack_40 = 0;
  if (param_2 != 0) {
    uStack_40 = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_38,0);
    }
    else {
      uStack_38 = param_4;
      uStack_34 = param_5;
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
    }
  }
  uStack_8._0_1_ = 3;
  *param_1 = 0;
  if (uStack_40 != 0) {
    *param_1 = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_38;
      param_1[3] = uStack_34;
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      *(undefined8 *)(param_1 + 6) = uStack_28;
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
  }
  param_1[8] = uStack_14;
  param_1[9] = (uint)piVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  piVar3 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17451 ; VA 0x009649e0 ; FUN_009649e0 */

uint * FUN_009649e0(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8,uint param_9,int *param_10)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_10;
  puStack_c = &LAB_017cd2b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_10[1] = param_10[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_9;
  if (param_10 != (int *)0x0) {
    piVar1 = param_10 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_20 = param_9;
  piStack_1c = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  uStack_40 = 0;
  if (param_2 != 0) {
    uStack_40 = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_38,0);
    }
    else {
      uStack_38 = param_4;
      uStack_34 = param_5;
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
    }
  }
  uStack_8._0_1_ = 3;
  *param_1 = 0;
  if (uStack_40 != 0) {
    *param_1 = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_38;
      param_1[3] = uStack_34;
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      *(undefined8 *)(param_1 + 6) = uStack_28;
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
  }
  param_1[8] = uStack_14;
  param_1[9] = (uint)piVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  piVar3 = param_10;
  if (param_10 != (int *)0x0) {
    LOCK();
    iVar2 = param_10[1] + -1;
    param_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_10)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17452 ; VA 0x00964be0 ; FUN_00964be0 */

undefined4 *
FUN_00964be0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd2e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00968160(param_3,param_4);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60();
  FUN_006511a0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000028) {
    if (0xfff < in_stack_00000028 + 1) {
      if (0x1f < (param_5 - *(int *)(param_5 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17453 ; VA 0x00964d10 ; FUN_00964d10 */

undefined4 *
FUN_00964d10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 17454 ; VA 0x00964e40 ; FUN_00964e40 */

undefined4 *
FUN_00964e40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd310;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_84 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_14;
      uStack_94 = 0x964ea7;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_14;
      uStack_78 = param_15;
      uStack_74 = param_16;
      puStack_70 = (undefined4 *)param_17;
      uStack_6c = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_9c,0);
    }
    else {
      uStack_9c = param_7;
      uStack_98 = param_8;
      uStack_94 = param_9;
      puStack_90 = param_10;
      uStack_8c = param_11;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_009683a0(param_3,param_4);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  uStack_6c = CONCAT44(uVar1,0x964f1e);
  FUN_009682d0();
  uStack_6c = CONCAT44(0x964f26,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_7;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0x964f47;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_14;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0x964f75;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17455 ; VA 0x00964f90 ; FUN_00964f90 */

undefined4 *
FUN_00964f90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,int *param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 *param_14,ulonglong param_15,uint param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined4 param_20,undefined4 param_21,
            undefined8 param_22)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 *puStack_a4;
  ulonglong uStack_a0;
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 *puStack_84;
  undefined8 uStack_80;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd358;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_98 = 0;
  ExceptionList = &pvStack_10;
  if (param_16 != 0) {
    uStack_98 = param_16;
    if ((param_16 & 1) == 0) {
      uStack_a0 = ZEXT48(&uStack_90);
      puStack_a4 = &param_18;
      uStack_a8 = 0x964ff8;
      ExceptionList = &pvStack_10;
      (**(code **)(param_16 & 0xfffffffe))();
    }
    else {
      uStack_90 = param_18;
      uStack_8c = param_19;
      uStack_88 = param_20;
      puStack_84 = (undefined4 *)param_21;
      uStack_80 = param_22;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 5;
  if (param_9 != 0) {
    if ((param_9 & 1) == 0) {
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_11;
      uStack_ac = param_12;
      uStack_a8 = param_13;
      puStack_a4 = param_14;
      uStack_a0 = param_15;
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[2] = param_6[2] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 4;
  uVar3 = FUN_00968950(param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  *param_1 = param_2;
  uStack_80 = CONCAT44(uVar3,0x9650dc);
  FUN_0096a4e0();
  uStack_80 = CONCAT44(0x9650e4,(undefined4)uStack_80);
  FUN_0096cbb0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0x9650fd,(undefined4)uStack_80);
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_80 = CONCAT44(0x96510d,(undefined4)uStack_80);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[2] + -1;
    param_6[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0x965122,(undefined4)uStack_80);
      (**(code **)(*param_6 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_80 = CONCAT44(0x965138,(undefined4)uStack_80);
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_80 = CONCAT44(0x965147,(undefined4)uStack_80);
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_84 = &param_11;
    uStack_80 = CONCAT44(2,puStack_84);
    uStack_88 = 0x965168;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_16 != 0) && ((param_16 & 1) == 0)) &&
     (*(code **)(param_16 & 0xfffffffe) != (code *)0x0)) {
    puStack_84 = &param_18;
    uStack_80 = CONCAT44(2,puStack_84);
    uStack_88 = 0x965196;
    (**(code **)(param_16 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17456 ; VA 0x009651b0 ; FUN_009651b0 */

undefined4 *
FUN_009651b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 *param_5)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  uint *puVar4;
  undefined4 **ppuVar5;
  undefined4 *puVar6;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  undefined4 in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 *in_stack_00000040;
  ulonglong in_stack_00000044;
  uint in_stack_0000004c;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000060;
  undefined8 in_stack_00000064;
  undefined4 *in_stack_0000006c;
  int *in_stack_00000070;
  undefined auStack_e8 [8];
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  undefined4 *puStack_d8;
  undefined4 uStack_d4;
  uint auStack_d0 [2];
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 *puStack_bc;
  ulonglong uStack_b8;
  uint auStack_b0 [2];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  undefined4 *puStack_90;
  int *piStack_8c;
  uint uStack_48;
  undefined4 auStack_40 [7];
  int *piStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017cd3b0;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)&puStack_90;
  ExceptionList = &pvStack_10;
  if (in_stack_00000070 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    in_stack_00000070[2] = in_stack_00000070[2] + 1;
    UNLOCK();
  }
  puStack_90 = in_stack_0000006c;
  piStack_8c = in_stack_00000070;
  puStack_18 = (undefined *)auStack_b0;
  puStack_1c = (undefined *)auStack_b0;
  uStack_8 = 4;
  uStack_7 = 0;
  auStack_b0[0] = 0;
  puVar4 = auStack_b0;
  ppuVar5 = &puStack_90;
  if (in_stack_0000004c != 0) {
    auStack_b0[0] = in_stack_0000004c;
    if ((in_stack_0000004c & 1) == 0) {
      uStack_b8 = ZEXT48(&uStack_a8);
      puStack_bc = &stack0x00000054;
      uStack_c0 = 0x965247;
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
      puVar4 = (uint *)puStack_18;
      ppuVar5 = (undefined4 **)puStack_14;
    }
    else {
      uStack_a8 = in_stack_00000054;
      uStack_a4 = in_stack_00000058;
      uStack_a0 = in_stack_0000005c;
      uStack_9c = in_stack_00000060;
      uStack_98 = in_stack_00000064;
      puVar4 = auStack_b0;
      ppuVar5 = &puStack_90;
    }
  }
  puStack_14 = (undefined *)ppuVar5;
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)auStack_d0;
  puStack_20 = (undefined *)auStack_d0;
  uStack_8 = 5;
  auStack_d0[0] = 0;
  puVar4 = auStack_d0;
  if (in_stack_0000002c != 0) {
    auStack_d0[0] = in_stack_0000002c;
    if ((in_stack_0000002c & 1) == 0) {
      puStack_d8 = &uStack_c8;
      uStack_d4 = 0;
      puStack_dc = &stack0x00000034;
      uStack_e0 = 0x965292;
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_c8 = in_stack_00000034;
      uStack_c4 = in_stack_00000038;
      uStack_c0 = in_stack_0000003c;
      puStack_bc = in_stack_00000040;
      uStack_b8 = in_stack_00000044;
      puVar4 = auStack_d0;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = auStack_e8;
  uStack_8 = 6;
  FUN_0054ef60(&param_5);
  uStack_8 = 3;
  piStack_8c = (int *)FUN_00968c50(param_3,param_4);
  _uStack_8 = CONCAT31(uStack_7,7);
  *param_1 = param_2;
  puStack_90 = (undefined4 *)0x9652d1;
  FUN_00968b60();
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[2] + -1;
    piStack_24[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_8c = (int *)0x9652e9;
      (**(code **)(*piStack_24 + 4))();
    }
  }
  uStack_8 = 8;
  if (((uStack_48 != 0) && ((uStack_48 & 1) == 0)) &&
     (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
    puStack_90 = auStack_40;
    piStack_8c = (int *)0x2;
    uStack_98 = CONCAT44(puStack_90,0x96530a);
    (**(code **)(uStack_48 & 0xfffffffe))();
  }
  piStack_8c = (int *)0x96531c;
  FUN_008c3170();
  uStack_8 = 2;
  uVar3 = uStack_8;
  uStack_8 = 2;
  if (0xf < in_stack_00000028) {
    piStack_8c = (int *)(in_stack_00000028 + 1);
    puVar6 = param_5;
    if (0xfff < piStack_8c) {
      puVar6 = (undefined4 *)param_5[-1];
      piStack_8c = (int *)(in_stack_00000028 + 0x24);
      if (0x1f < (uint)((int)param_5 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        piStack_8c = (int *)&UNK_009653e7;
        uStack_8 = uVar3;
        FUN_017167a3();
      }
    }
    uStack_98 = CONCAT44(0x965351,(undefined4)uStack_98);
    puStack_90 = puVar6;
    FUN_01674ea0();
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = (undefined4 *)((uint)param_5 & 0xffffff00);
  uStack_8 = 9;
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      puStack_90 = &stack0x00000034;
      piStack_8c = (int *)0x2;
      uStack_98 = CONCAT44(puStack_90,0x965387);
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  _uStack_8 = CONCAT31(uStack_7,10);
  if (in_stack_0000004c != 0) {
    if (((in_stack_0000004c & 1) == 0) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      puStack_90 = &stack0x00000054;
      piStack_8c = (int *)0x2;
      uStack_98 = CONCAT44(puStack_90,0x9653b2);
      (**(code **)(in_stack_0000004c & 0xfffffffe))();
    }
    in_stack_0000004c = 0;
  }
  if (in_stack_00000070 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000070 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      piStack_8c = (int *)0x9653d0;
      (**(code **)(*in_stack_00000070 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17457 ; VA 0x009653f0 ; FUN_009653f0 */

undefined4 *
FUN_009653f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18,undefined4 param_19)

{
  int iVar1;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  ulonglong uStack_90;
  uint uStack_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd3e8;
  pvStack_10 = ExceptionList;
  uStack_68 = param_19;
  uStack_8 = 2;
  uStack_88 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_88 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_90 = ZEXT48(&uStack_80);
      puStack_94 = &param_14;
      uStack_98 = 0x96545a;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_80 = param_14;
      uStack_7c = param_15;
      uStack_78 = param_16;
      uStack_74 = param_17;
      uStack_70 = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 3;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_a0,0);
    }
    else {
      uStack_a0 = param_7;
      uStack_9c = param_8;
      uStack_98 = param_9;
      puStack_94 = param_10;
      uStack_90 = param_11;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uStack_68 = FUN_009685d0(param_3,param_4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *param_1 = param_2;
  uStack_70 = CONCAT44(0x9654ee,(undefined4)uStack_70);
  FUN_009684d0();
  uStack_68 = 0x9654f6;
  FUN_008e9ba0();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[2] + -1;
    param_4[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_68 = 0x96550c;
      (**(code **)(*param_4 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    uStack_68 = 2;
    uStack_70 = CONCAT44(&param_7,&param_7);
    uStack_74 = 0x96552d;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    uStack_68 = 2;
    uStack_70 = CONCAT44(&param_14,&param_14);
    uStack_74 = 0x96555b;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17458 ; VA 0x00965570 ; FUN_00965570 */

undefined4 *
FUN_00965570(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,int *param_15,undefined4 param_16,int *param_17,undefined4 param_18,
            int *param_19,undefined4 param_20)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_19 != (int *)0x0) {
    LOCK();
    param_19[1] = param_19[1] + 1;
    UNLOCK();
  }
  if (param_17 != (int *)0x0) {
    LOCK();
    param_17[1] = param_17[1] + 1;
    UNLOCK();
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    param_15[1] = param_15[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uVar3 = FUN_00968ee0(param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12,
                       param_13,param_14,param_15,param_16,param_17,param_18,param_19,param_20);
  *param_1 = param_2;
  param_1[1] = param_3;
  FUN_00968e30(uVar3);
  FUN_0096cc40();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_15 != (int *)0x0) {
    LOCK();
    iVar2 = param_15[1] + -1;
    param_15[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_15)();
      LOCK();
      iVar2 = param_15[2] + -1;
      param_15[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_15 + 4))();
      }
    }
  }
  if (param_17 != (int *)0x0) {
    LOCK();
    iVar2 = param_17[1] + -1;
    param_17[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_17)();
      LOCK();
      iVar2 = param_17[2] + -1;
      param_17[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_17 + 4))();
      }
    }
  }
  if (param_19 != (int *)0x0) {
    LOCK();
    iVar2 = param_19[1] + -1;
    param_19[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_19)();
      LOCK();
      piVar1 = param_19 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_19 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 17459 ; VA 0x00965700 ; FUN_00965700 */

undefined4 *
FUN_00965700(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,uint param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined4 *param_12,ulonglong param_13,
            uint param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined4 param_18,undefined4 param_19,undefined8 param_20)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd420;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_14 != 0) {
    uStack_84 = param_14;
    if ((param_14 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_16;
      uStack_94 = 0x965767;
      ExceptionList = &pvStack_10;
      (**(code **)(param_14 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_16;
      uStack_78 = param_17;
      uStack_74 = param_18;
      puStack_70 = (undefined4 *)param_19;
      uStack_6c = param_20;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_7 != 0) {
    if ((param_7 & 1) == 0) {
      (**(code **)(param_7 & 0xfffffffe))(&param_9,&uStack_9c);
    }
    else {
      uStack_9c = param_9;
      uStack_98 = param_10;
      uStack_94 = param_11;
      puStack_90 = param_12;
      uStack_8c = param_13;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00968820(param_4,param_5);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_6c = CONCAT44(uVar1,0x9657ec);
  FUN_00968740();
  uStack_6c = CONCAT44(0x9657f4,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_7 != 0) && ((param_7 & 1) == 0)) && (*(code **)(param_7 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_9;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0x965815;
    (**(code **)(param_7 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_16;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0x965843;
    (**(code **)(param_14 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17460 ; VA 0x00965860 ; FUN_00965860 */

undefined4 *
FUN_00965860(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  undefined4 in_stack_0000002c;
  int *in_stack_00000030;
  undefined4 *in_stack_00000034;
  int *in_stack_00000038;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 *in_stack_00000050;
  ulonglong in_stack_00000054;
  uint in_stack_0000005c;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined *in_stack_00000070;
  undefined8 in_stack_00000074;
  undefined auStack_fc [24];
  undefined4 uStack_e4;
  int *piStack_e0;
  undefined4 *puStack_dc;
  int *piStack_d8;
  uint auStack_d4 [2];
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 *puStack_c0;
  ulonglong uStack_bc;
  uint auStack_b4 [2];
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 *puStack_a0;
  undefined8 uStack_9c;
  uint uStack_44;
  undefined auStack_3c [24];
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd483;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_b4;
  puStack_18 = (undefined *)auStack_b4;
  uStack_8 = 4;
  auStack_b4[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_b4;
  if (in_stack_0000005c != 0) {
    auStack_b4[0] = in_stack_0000005c;
    if ((in_stack_0000005c & 1) == 0) {
      uStack_bc = ZEXT48(&uStack_ac);
      puStack_c0 = &stack0x00000064;
      uStack_c4 = 0x9658c8;
      ExceptionList = &pvStack_10;
      (**(code **)(in_stack_0000005c & 0xfffffffe))();
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_ac = in_stack_00000064;
      uStack_a8 = in_stack_00000068;
      uStack_a4 = in_stack_0000006c;
      puStack_a0 = (undefined4 *)in_stack_00000070;
      uStack_9c = in_stack_00000074;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_b4;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puStack_18 = (undefined *)auStack_d4;
  puStack_1c = (undefined *)auStack_d4;
  uStack_8._0_1_ = 5;
  auStack_d4[0] = 0;
  puVar4 = auStack_d4;
  if (in_stack_0000003c != 0) {
    auStack_d4[0] = in_stack_0000003c;
    if ((in_stack_0000003c & 1) == 0) {
      puStack_dc = &uStack_cc;
      piStack_d8 = (int *)0x0;
      piStack_e0 = &stack0x00000044;
      uStack_e4 = 0x965913;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
      puVar4 = (uint *)puStack_18;
    }
    else {
      uStack_cc = in_stack_00000044;
      uStack_c8 = in_stack_00000048;
      uStack_c4 = in_stack_0000004c;
      puStack_c0 = in_stack_00000050;
      uStack_bc = in_stack_00000054;
      puVar4 = auStack_d4;
    }
  }
  puStack_18 = (undefined *)puVar4;
  puStack_1c = (undefined *)&puStack_dc;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    in_stack_00000038[1] = in_stack_00000038[1] + 1;
    UNLOCK();
  }
  puStack_dc = in_stack_00000034;
  piStack_d8 = in_stack_00000038;
  puStack_20 = (undefined *)&uStack_e4;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    in_stack_00000030[1] = in_stack_00000030[1] + 1;
    UNLOCK();
  }
  uStack_e4 = in_stack_0000002c;
  piStack_e0 = in_stack_00000030;
  puStack_24 = auStack_fc;
  uStack_8._0_1_ = 8;
  FUN_0054ef60(&param_5);
  uStack_8._0_1_ = 4;
  uVar5 = FUN_00969180(param_3,param_4);
  uStack_8._0_1_ = 9;
  *param_1 = param_2;
  uStack_9c = CONCAT44(uVar5,0x9659ab);
  FUN_00969050();
  uStack_8._0_1_ = 10;
  if (((uStack_44 != 0) && ((uStack_44 & 1) == 0)) &&
     (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
    puStack_a0 = (undefined4 *)auStack_3c;
    uStack_9c = CONCAT44(2,puStack_a0);
    uStack_a4 = 0x9659cc;
    (**(code **)(uStack_44 & 0xfffffffe))();
  }
  uStack_9c = CONCAT44(0x9659e1,(undefined4)uStack_9c);
  FUN_0096cca0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000028) {
    uVar7 = in_stack_00000028 + 1;
    uVar6 = param_5;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_5 - 4);
      uVar7 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar6) - 4) {
        uStack_9c = CONCAT44(&UNK_00965ae3,(undefined4)uStack_9c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_9c = CONCAT44(uVar7,uVar6);
    puStack_a0 = (undefined4 *)0x965a16;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000030;
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  if (in_stack_00000030 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000030[1] + -1;
    in_stack_00000030[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_9c = CONCAT44(0x965a44,(undefined4)uStack_9c);
      (**(code **)*in_stack_00000030)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_9c = CONCAT44(0x965a54,(undefined4)uStack_9c);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = in_stack_00000038;
  if (in_stack_00000038 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000038[1] + -1;
    in_stack_00000038[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_9c = CONCAT44(0x965a6a,(undefined4)uStack_9c);
      (**(code **)*in_stack_00000038)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_9c = CONCAT44(0x965a79,(undefined4)uStack_9c);
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      puStack_a0 = &stack0x00000044;
      uStack_9c = CONCAT44(2,puStack_a0);
      uStack_a4 = 0x965a9a;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
    }
    in_stack_0000003c = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_0000005c != 0) && ((in_stack_0000005c & 1) == 0)) &&
     (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
    puStack_a0 = &stack0x00000064;
    uStack_9c = CONCAT44(2,puStack_a0);
    uStack_a4 = 0x965ac8;
    (**(code **)(in_stack_0000005c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17461 ; VA 0x00965af0 ; FUN_00965af0 */

undefined4 * __thiscall FUN_00965af0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00923570;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17462 ; VA 0x00965bb0 ; FUN_00965bb0 */

void FUN_00965bb0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd4a3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *param_2 = *param_3;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  uStack_8 = 0;
  param_2[6] = 0;
  FUN_005880d0(param_3 + 6);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  param_2[0xe] = 0;
  FUN_005880d0(param_3 + 0xe);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17463 ; VA 0x00965c50 ; FUN_00965c50 */

undefined4 * FUN_00965c50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd4e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00dafde0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00db27e0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00962eb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17464 ; VA 0x00965d10 ; FUN_00965d10 */

undefined4 *
FUN_00965d10(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00e49a80();
  uVar4 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar3 + 0x1dc) != (undefined4 *)0x0) {
    uVar4 = **(undefined4 **)(iVar3 + 0x1dc);
  }
  uVar4 = FUN_01675290(uVar4);
  uStack_8 = 1;
  iVar3 = FUN_01674e20(0xbc);
  uStack_8._0_1_ = 2;
  if (iVar3 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *param_4;
    uVar1 = *param_2;
    uVar2 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar5 = FUN_00e4f7f0(uVar1,uVar2,param_3,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00962fa0(uVar5,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17465 ; VA 0x00965e10 ; FUN_00965e10 */

undefined4 *
FUN_00965e10(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00e49a80();
  uVar6 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar5 + 0x1dc) != (undefined4 *)0x0) {
    uVar6 = **(undefined4 **)(iVar5 + 0x1dc);
  }
  uVar6 = FUN_01675290(uVar6);
  uStack_8 = 1;
  iVar5 = FUN_01674e20(0xbc);
  uStack_8._0_1_ = 2;
  if (iVar5 == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = *param_4;
    uVar1 = param_3[1];
    uVar2 = *param_3;
    uVar3 = *param_2;
    uVar4 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    uVar7 = FUN_00e4f930(uVar3,uVar4,uVar2,uVar1,uVar7);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00962fa0(uVar7,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17466 ; VA 0x00965f10 ; FUN_00965f10 */

int FUN_00965f10(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1ac8;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_0064f8c0();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_008e28e0(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01eadc4c,&LAB_0064e290);
        uVar4 = FUN_0064e320();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17467 ; VA 0x00966060 ; FUN_00966060 */

undefined4 * FUN_00966060(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd560;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00bd39b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x54);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00bd4100();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00963090(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17468 ; VA 0x00966120 ; FUN_00966120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00966120(byte *param_1,int *param_2,int param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd578;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar5,iVar7,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    FUN_005d2a40();
    iVar7 = param_4;
    FUN_0054ef60(param_4);
    _DAT_00000020 = *(undefined4 *)(iVar7 + 0x18);
    uVar2 = *(uint *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      uVar8 = uVar2 >> 1;
      if (uVar8 + uVar2 <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005c9310(uVar8 + uVar2);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar7);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar9;
        while (puVar3 != (undefined4 *)0x0) {
          piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar4 = (int)puVar9;
            puVar9 = puVar3;
          }
          else {
            *puVar9 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar4;
            *(undefined4 **)*piVar4 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar9;
        }
      }
    }
    param_3 = 0;
    uVar6 = uVar5 % *(uint *)(param_1 + 4);
    piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    _DAT_00000004 = uVar5;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar4 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar9 = piVar4;
      _DAT_00000000 = *piVar4;
      *piVar4 = 0;
    }
    else {
      _DAT_00000000 = *piVar4;
      *(undefined4 *)*puVar9 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined *)(param_2 + 1) = 1;
  }
  else {
    *(undefined *)(param_2 + 1) = 0;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17469 ; VA 0x009662c0 ; FUN_009662c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_009662c0(byte *param_1,int *param_2,int param_3,int param_4)

{
  byte bVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar7 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd598;
  pvStack_10 = ExceptionList;
  bVar1 = *param_1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_005702d0(param_3);
  FUN_00562fc0(&param_3,uVar5,iVar7,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  if (param_3 == 0) {
    uStack_8 = 0;
    FUN_005d2a40();
    iVar7 = param_4;
    FUN_0054ef60(param_4);
    _DAT_00000020 = *(undefined4 *)(iVar7 + 0x18);
    uVar2 = *(uint *)(param_1 + 8);
    uVar6 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar6 = FUN_005c9310(uVar6);
      if (uVar6 <= *(uint *)(param_1 + 4)) {
        uVar6 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar6);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar6) {
      uVar8 = uVar2 >> 1;
      if (uVar8 + uVar2 <= uVar6) {
        uVar8 = 1;
      }
      iVar7 = FUN_005c9310(uVar8 + uVar2);
      if (iVar7 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar7);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar9;
        while (puVar3 != (undefined4 *)0x0) {
          piVar4 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar4 = (int)puVar9;
            puVar9 = puVar3;
          }
          else {
            *puVar9 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar4;
            *(undefined4 **)*piVar4 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar9;
        }
      }
    }
    param_3 = 0;
    uVar6 = uVar5 % *(uint *)(param_1 + 4);
    piVar4 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    _DAT_00000004 = uVar5;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar4 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar4 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar9 = piVar4;
      _DAT_00000000 = *piVar4;
      *piVar4 = 0;
    }
    else {
      _DAT_00000000 = *piVar4;
      *(undefined4 *)*puVar9 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined *)(param_2 + 1) = 1;
  }
  else {
    *(undefined *)(param_2 + 1) = 0;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17470 ; VA 0x00966460 ; FUN_00966460 */

int * __thiscall FUN_00966460(byte *param_1,int *param_2,int *param_3,int *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd5b8;
  pvStack_10 = ExceptionList;
  uVar11 = param_3[1];
  if (((int)uVar11 < 1) && ((int)uVar11 < 0)) {
    uVar11 = ~uVar11;
  }
  uVar11 = (uVar11 >> 2) + uVar11 * 0x40 + *param_3 ^ uVar11;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&iStack_14,uVar11,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    uStack_8 = 0;
    iStack_14 = 0;
    piVar9 = (int *)FUN_01674e20(0x18);
    iStack_14 = CONCAT22(iStack_14._2_2_,0x101);
    *piVar9 = 0;
    piVar9[1] = 0;
    piVar9[2] = 0;
    piVar9[3] = 0;
    piVar9[4] = 0;
    piVar9[5] = 0;
    iVar6 = param_4[1];
    iVar7 = param_4[2];
    iVar8 = param_4[3];
    piVar9[2] = *param_4;
    piVar9[3] = iVar6;
    piVar9[4] = iVar7;
    piVar9[5] = iVar8;
    uVar4 = *(uint *)(param_1 + 8);
    uVar10 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar10 = FUN_005c9310(uVar10);
      if (uVar10 <= *(uint *)(param_1 + 4)) {
        uVar10 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar10);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar10) {
      uVar12 = uVar4 >> 1;
      if (uVar4 + (uVar4 >> 1) <= uVar10) {
        uVar12 = 1;
      }
      uVar10 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
      puVar1 = (uint *)(param_1 + 4);
      if (uVar10 != *puVar1) {
        FUN_005d2b00(uVar10);
        puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar13;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4) == 0) {
            *piVar2 = (int)puVar13;
            puVar13 = puVar5;
          }
          else {
            *puVar13 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar13;
        }
      }
    }
    piVar9[1] = uVar11;
    uVar10 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar11 % uVar10) * 4);
    if ((int *)*piVar2 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar10) * 4) = piVar9;
      }
      *piVar2 = (int)piVar3;
      *piVar9 = *piVar3;
      *piVar3 = (int)piVar9;
    }
    else {
      *piVar9 = *(int *)*piVar2;
      *(int **)*piVar2 = piVar9;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar9;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = iStack_14;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17471 ; VA 0x00966670 ; FUN_00966670 */

void __thiscall FUN_00966670(int param_1,int *param_2,int *param_3)

{
  byte *pbVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  uint uVar6;
  
  piVar5 = param_3 + 2;
  if (0xf < (uint)param_3[7]) {
    piVar5 = (int *)*piVar5;
  }
  uVar3 = 0;
  uVar6 = 0x811c9dc5;
  if (param_3[6] != 0) {
    do {
      pbVar1 = (byte *)(uVar3 + (int)piVar5);
      uVar3 = uVar3 + 1;
      uVar6 = (*pbVar1 ^ uVar6) * 0x1000193;
    } while (uVar3 < (uint)param_3[6]);
  }
  iVar2 = (*(uint *)(param_1 + 0x18) & uVar6) * 8;
  piVar5 = *(int **)(*(int *)(param_1 + 0xc) + iVar2);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
  if ((int *)piVar4[1] == param_3) {
    if (piVar5 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar5 == param_3) {
    *piVar4 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00970bb0(param_3);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 17472 ; VA 0x00966720 ; FUN_00966720 */

void __thiscall FUN_00966720(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = FUN_005e6570(param_3 + 2);
  iVar1 = (uVar3 & *(uint *)(param_1 + 0x18)) * 8;
  piVar2 = *(int **)(*(int *)(param_1 + 0xc) + iVar1);
  piVar4 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar4[1] == param_3) {
    if (piVar2 == param_3) {
      *piVar4 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar4[1] = param_3[1];
    }
  }
  else if (piVar2 == param_3) {
    *piVar4 = *param_3;
  }
  iVar1 = *param_3;
  *(int *)param_3[1] = iVar1;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_006552a0(param_3);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 17473 ; VA 0x009667a0 ; FUN_009667a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_009667a0(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  code **ppcStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd5eb;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_f0 = (int *)0x9667cc;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0088cbe0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8) {
    piStack_f0 = &DAT_01ead3c8;
    puStack_f4 = (undefined *)0x96690c;
    FUN_016f3809();
    if (DAT_01ead3c8 == -1) {
      piStack_f0 = &DAT_01ead3c8;
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      puStack_f4 = (undefined *)0x966944;
      FUN_016f37bf();
    }
  }
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  ppcStack_1b8 = (code **)0x0;
  uStack_1bc = uVar4;
  (*DAT_01ead3bc)(&uStack_dc,auStack_1b4);
  ppcStack_1b8 = &DAT_01ead3bc;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  piStack_f0 = &uStack_dc;
  puStack_f4 = (undefined *)0x96689c;
  (*DAT_01ead3c4)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    piStack_f0 = (int *)0x2;
    uStack_fc = 0x9668c0;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_f0 = (int *)0x9668e3;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_f0 = (int *)0x9668f2;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17474 ; VA 0x00966950 ; FUN_00966950 */

/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_00966950(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  code **ppcStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd61b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_f0 = (int *)0x96697c;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008881d0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
    piStack_f0 = &DAT_01ea8a9c;
    puStack_f4 = (undefined *)0x966abc;
    FUN_016f3809();
    if (DAT_01ea8a9c == -1) {
      piStack_f0 = &DAT_01ea8a9c;
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      puStack_f4 = (undefined *)0x966af4;
      FUN_016f37bf();
    }
  }
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  ppcStack_1b8 = (code **)0x0;
  uStack_1bc = uVar4;
  (*DAT_01ea8a90)(&uStack_dc,auStack_1b4);
  ppcStack_1b8 = &DAT_01ea8a90;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  piStack_f0 = &uStack_dc;
  puStack_f4 = (undefined *)0x966a4c;
  (*DAT_01ea8a98)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    piStack_f0 = (int *)0x2;
    uStack_fc = 0x966a70;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_f0 = (int *)0x966a93;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_f0 = (int *)0x966aa2;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17475 ; VA 0x00966b00 ; FUN_00966b00 */

code * FUN_00966b00(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  undefined4 *puStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  undefined4 *puStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd64b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_f0 = (undefined4 *)0x966b2c;
  ExceptionList = &pvStack_10;
  uStack_1bc = FUN_0088cdc0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  puStack_f0 = (undefined4 *)0x966b72;
  puVar5 = (undefined4 *)FUN_006309e0();
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  puStack_1b8 = (undefined4 *)0x0;
  puVar4 = &uStack_1bc;
  if (puVar5 != (undefined4 *)0x0) {
    (*(code *)*puVar5)(&uStack_dc,auStack_1b4);
    puVar4 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar4;
  puStack_1b8 = puVar5;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  if (puVar5 != (undefined4 *)0x0) {
    puStack_f0 = &uStack_dc;
    puStack_f4 = (undefined *)0x966bdd;
    (*(code *)puVar5[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    puStack_f0 = (undefined4 *)0x2;
    uStack_fc = 0x966c01;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_f0 = (undefined4 *)0x966c24;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_f0 = (undefined4 *)0x966c33;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17476 ; VA 0x00966c50 ; FUN_00966c50 */

void FUN_00966c50(uint param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 uStack_1b8;
  undefined4 *puStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined4 *puStack_ec;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be3c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puStack_ec = (undefined4 *)0x966c7b;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088da50();
  uStack_dc = in_stack_00000024;
  uStack_d8 = in_stack_00000028;
  puStack_ec = (undefined4 *)0x966ca2;
  puVar3 = (undefined4 *)FUN_005c9e80();
  puStack_14 = (undefined *)&uStack_1b8;
  uStack_8._0_1_ = 1;
  puStack_1b4 = (undefined4 *)0x0;
  uStack_1b8 = uVar2;
  puVar1 = &uStack_1b8;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(&uStack_dc,auStack_1b0);
    puVar1 = (undefined4 *)puStack_14;
  }
  puStack_14 = (undefined *)puVar1;
  puStack_1b4 = puVar3;
  FUN_008c6ce0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 != (undefined4 *)0x0) {
    puStack_ec = &uStack_dc;
    puStack_f0 = (undefined *)0x966d0d;
    (*(code *)puVar3[2])();
  }
  uStack_8 = 3;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined4 *)0x2;
    uStack_f8 = 0x966d34;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17477 ; VA 0x00966d50 ; FUN_00966d50 */

void FUN_00966d50(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  uVar2 = *param_2;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = uVar2;
  param_1[1] = param_2[1];
  return;
}



/* FUNCTION 17478 ; VA 0x00966d80 ; thunk_FUN_0098cfc0 */

undefined * thunk_FUN_0098cfc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0e0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee334c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee334c);
    if (DAT_01ee334c == -1) {
      uStack_8 = 0;
      FUN_00e2cce0();
      FUN_016f3654(&LAB_01885bd0);
      FUN_016f37bf(&DAT_01ee334c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee32e8;
}



/* FUNCTION 17479 ; VA 0x00966d90 ; thunk_FUN_0098d050 */

undefined * thunk_FUN_0098d050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0e2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee33b4);
    if (DAT_01ee33b4 == -1) {
      uStack_8 = 0;
      FUN_009a0d40();
      FUN_016f3654(&LAB_01885bf0);
      FUN_016f37bf(&DAT_01ee33b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3350;
}



/* FUNCTION 17480 ; VA 0x00966da0 ; FUN_00966da0 */

void FUN_00966da0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd670;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar4 = thunk_FUN_005f33f0();
  if (iVar2 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar5 = piVar1 + 2;
  iVar2 = *param_2;
  if (piVar1[1] == 0) {
    piVar5 = (int *)0x0;
  }
  iVar4 = *(int *)(iVar2 + 0x270);
  iVar3 = *piVar5;
  iVar6 = FUN_0088cdc0();
  if (iVar4 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0x278;
  if (*(int *)(iVar2 + 0x274) == 0) {
    iVar4 = 0;
  }
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar2 = *param_2;
  uStack_8 = 0;
  iVar4 = *(int *)(iVar2 + 0x1a0);
  iVar6 = FUN_0088cb40();
  if (iVar4 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar4 = iVar2 + 0x1a8;
  if (*(int *)(iVar2 + 0x1a4) == 0) {
    iVar4 = 0;
  }
  FUN_0054ef60(iVar4);
  iVar2 = *param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar4 = *(int *)(iVar2 + 0xd0);
  iVar6 = FUN_0088cdc0();
  if (iVar4 == iVar6) {
    puVar7 = (undefined4 *)(iVar2 + 0xd8);
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar7[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0xffffffff;
    FUN_0097c260(param_1,iVar3,*puVar7,puVar7[1]);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17481 ; VA 0x00966f00 ; FUN_00966f00 */

void FUN_00966f00(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd698;
  pvStack_10 = ExceptionList;
  iVar7 = *param_2;
  iVar6 = *(int *)(iVar7 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = thunk_FUN_00bfa7a0();
  if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined4 *)(iVar7 + 0x1a8);
  iVar6 = *param_2;
  if (*(int *)(iVar7 + 0x1a4) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  iVar7 = *(int *)(iVar6 + 0xd0);
  uVar1 = *puVar4;
  iVar3 = FUN_0088cdc0();
  if (iVar7 == iVar3) {
    puVar4 = (undefined4 *)(iVar6 + 0xd8);
    if (*(int *)(iVar6 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar7 = puVar4[1];
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = puVar4[1];
    }
    uVar2 = *puVar4;
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    iVar6 = *param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar6 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      iVar6 = piVar5[1];
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = piVar5[1];
      }
      uStack_8 = 2;
      FUN_0096ebe0(*piVar5,iVar6,uVar2,iVar7,uVar1);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17482 ; VA 0x00967040 ; FUN_00967040 */

/* WARNING: Removing unreachable block (ram,0x0096718c) */
/* WARNING: Removing unreachable block (ram,0x0096714a) */
/* WARNING: Removing unreachable block (ram,0x00967158) */
/* WARNING: Removing unreachable block (ram,0x009671da) */
/* WARNING: Removing unreachable block (ram,0x00967168) */
/* WARNING: Removing unreachable block (ram,0x0096719a) */
/* WARNING: Removing unreachable block (ram,0x009671df) */
/* WARNING: Removing unreachable block (ram,0x009671aa) */

void FUN_00967040(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd6c8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*param_2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  iVar1 = *(int *)*param_2;
  iVar2 = FUN_0088cb40();
  if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 2;
  FUN_0096ea40(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c),uStack_44,
               uStack_40,uStack_3c,uStack_38,CONCAT44(uStack_30,uStack_34));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17483 ; VA 0x009671f0 ; FUN_009671f0 */

undefined4 FUN_009671f0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_0096736d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_0096736d;
  }
  iVar2 = thunk_FUN_005f3090();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00967318;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_005f3090();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_005ed5d0(&param_3);
      iVar4 = thunk_FUN_005f3090();
      iStack_ec = iVar4;
      iVar5 = thunk_FUN_005f3090();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00967318:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_005f3090();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 17484 ; VA 0x009673f0 ; FUN_009673f0 */

undefined4 * __thiscall FUN_009673f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd6fe;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8._0_1_ = 1;
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
    }
    else {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(param_2 + 0x12);
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  if (param_2[0x19] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0x19] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x18] = param_2[0x18];
  param_1[0x19] = param_2[0x19];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17485 ; VA 0x00967510 ; FUN_00967510 */

uint * __thiscall FUN_00967510(uint *param_1,uint *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  *param_1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar3;
      param_1[5] = uVar4;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  param_1[8] = 0;
  param_1[9] = 0;
  if (param_2[9] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[9] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  return param_1;
}



/* FUNCTION 17486 ; VA 0x00967590 ; FUN_00967590 */

int __thiscall FUN_00967590(int param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd723;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  if (*(int *)(param_2 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_2 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x18) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x1c) = *(undefined4 *)(param_2 + 0x1c);
  *(undefined4 *)(param_1 + 0x20) = 0;
  uVar2 = *(uint *)(param_2 + 0x20);
  uStack_8 = 1;
  if (uVar2 != 0) {
    *(uint *)(param_1 + 0x20) = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = *(undefined4 *)(param_2 + 0x2c);
      uVar4 = *(undefined4 *)(param_2 + 0x30);
      uVar5 = *(undefined4 *)(param_2 + 0x34);
      *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_2 + 0x28);
      *(undefined4 *)(param_1 + 0x2c) = uVar3;
      *(undefined4 *)(param_1 + 0x30) = uVar4;
      *(undefined4 *)(param_1 + 0x34) = uVar5;
      *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0x28,param_1 + 0x28,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17487 ; VA 0x00967650 ; FUN_00967650 */

undefined4 * __thiscall FUN_00967650(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd743;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17488 ; VA 0x00967750 ; FUN_00967750 */

undefined4 * __thiscall
FUN_00967750(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd79b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00961580();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Players,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cdc0();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    iStack_e4 = FUN_006309e0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17489 ; VA 0x009678f0 ; FUN_009678f0 */

undefined4 * __thiscall
FUN_009678f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd7fb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00961580();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Players,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17490 ; VA 0x00967a70 ; FUN_00967a70 */

undefined4 * __thiscall
FUN_00967a70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd85b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00961580();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::Players,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088cdc0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088da50();
    iStack_e4 = 0;
    uStack_e0 = *puVar2;
    uStack_dc = puVar2[1];
    iStack_e4 = FUN_005c9e80();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17491 ; VA 0x00967bf0 ; FUN_00967bf0 */

undefined4 * __fastcall FUN_00967bf0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ChatStyle");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ChatOption>::vftable;
  FUN_009caf20(&DAT_01d64738,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17492 ; VA 0x00967c50 ; FUN_00967c50 */

undefined4 * __fastcall FUN_00967c50(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("PlayerChatType");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::PlayerChatType>::vftable;
  FUN_009caf20(&DAT_01d64750,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17493 ; VA 0x00967cb0 ; FUN_00967cb0 */

undefined4 * __fastcall FUN_00967cb0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ThumbnailSize");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ThumbnailSize>::vftable;
  FUN_009caf20(&DAT_01d64780,7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17494 ; VA 0x00967d10 ; FUN_00967d10 */

undefined4 * __fastcall FUN_00967d10(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ThumbnailType");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Players::ThumbnailType>::vftable;
  FUN_009caf20(&DAT_01d64768,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17495 ; VA 0x00967d70 ; FUN_00967d70 */

undefined4 * __thiscall
FUN_00967d70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined auStack_f8 [216];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cd891;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,param_3,param_5,param_6,param_7);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Players,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Players::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_f8,&puStack_20,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_f8,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17496 ; VA 0x00967ea0 ; FUN_00967ea0 */

undefined4 * __thiscall
FUN_00967ea0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Players,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Players::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Players,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Players::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17497 ; VA 0x00967f80 ; FUN_00967f80 */

undefined4 * __thiscall
FUN_00967f80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017cd8c1;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00961580();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Players,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Players::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Players,void___cdecl(bool),class_rbx::remote_signal<void___cdecl(bool)>,class_rbx::remote_signal<void___cdecl(bool)>_RBX::Players::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 17498 ; VA 0x009680e0 ; FUN_009680e0 */

undefined4 * __thiscall FUN_009680e0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd8d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_0054ef60(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17499 ; VA 0x00968160 ; FUN_00968160 */

undefined4 * __thiscall
FUN_00968160(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cd918;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 1;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_0054ef60(aiStack_34);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar2 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}


